
/* worklets.js — FX_bank (R378). Quatre processeurs : qx-pitch, qx-freeze, qx-tune, qx-crush. */
function ringRead(buf, pos){ const N = buf.length; pos = ((pos % N) + N) % N; const i = Math.floor(pos), f = pos - i; return buf[i] * (1 - f) + buf[(i + 1) % N] * f; }
class Shifter {                       /* décaleur à deux lignes à retard modulées, fondu en sin² (somme = 1) */
  constructor(N, win){ this.N = N; this.win = win; this.b = new Float32Array(N); this.w = 0; this.ph = 0; }
  step(x, ratio){
    this.b[this.w] = x;
    this.ph += (1 - ratio) / this.win; if (this.ph >= 1) this.ph -= 1; else if (this.ph < 0) this.ph += 1;
    const p1 = this.ph, p2 = (this.ph + .5) % 1, g1 = Math.sin(Math.PI * p1), g2 = Math.sin(Math.PI * p2);
    const y = g1 * g1 * ringRead(this.b, this.w - 1 - p1 * this.win) + g2 * g2 * ringRead(this.b, this.w - 1 - p2 * this.win);
    this.w = (this.w + 1) % this.N; return y;
  }
}
class QxPitch extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'semi', defaultValue: 0, minValue: -36, maxValue: 36 }]; }
  constructor(){ super(); const win = Math.floor(sampleRate * .07); this.s = [new Shifter(win * 3, win), new Shifter(win * 3, win)]; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const r = Math.pow(2, par.semi[0] / 12), n = y[0].length;
    for (let c = 0; c < y.length; c++){ const xi = x[Math.min(c, x.length - 1)], sh = this.s[c]; for (let i = 0; i < n; i++) y[c][i] = sh.step(xi[i], r); }
    return true;
  }
}
registerProcessor('qx-pitch', QxPitch);

class QxFreeze extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'hold', defaultValue: 0, minValue: 0, maxValue: 1 }, { name: 'size', defaultValue: .2, minValue: .03, maxValue: .6 }]; }
  constructor(){ super(); this.N = Math.floor(sampleRate * .7); this.rb = [new Float32Array(this.N), new Float32Array(this.N)]; this.w = 0; this.fz = [new Float32Array(this.N), new Float32Array(this.N)]; this.L = 1; this.on = false; this.t = 0; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const n = y[0].length, hold = par.hold[0] >= .5, L = Math.max(64, Math.floor(par.size[0] * sampleRate));
    if (hold && !this.on){ this.on = true; this.L = L; this.t = 0; for (let c = 0; c < 2; c++) for (let i = 0; i < L; i++) this.fz[c][i] = this.rb[c][(this.w - L + i + this.N * 2) % this.N]; }
    else if (!hold) this.on = false;
    for (let i = 0; i < n; i++){
      for (let c = 0; c < y.length; c++){
        const xi = x[Math.min(c, x.length - 1)][i]; this.rb[c][this.w] = xi;
        if (this.on){ const p1 = this.t % this.L, p2 = (this.t + this.L / 2) % this.L, a = Math.sin(Math.PI * p1 / this.L), b = Math.sin(Math.PI * p2 / this.L);
          y[c][i] = a * a * this.fz[c][Math.floor(p1)] + b * b * this.fz[c][Math.floor(p2)]; }
        else y[c][i] = xi;
      }
      this.w = (this.w + 1) % this.N; if (this.on) this.t++;
    }
    return true;
  }
}
registerProcessor('qx-freeze', QxFreeze);

const SCALES = [[0,1,2,3,4,5,6,7,8,9,10,11],[0,2,4,5,7,9,11],[0,2,3,5,7,8,10],[0,2,4,7,9],[0,3,5,6,7,10]];  /* chromatique, majeure, mineure, pentatonique, blues */
class QxTune extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'speed', defaultValue: .3, minValue: 0, maxValue: 1 }, { name: 'scale', defaultValue: 1, minValue: 0, maxValue: 4 }, { name: 'root', defaultValue: 0, minValue: 0, maxValue: 11 }]; }
  constructor(){ super(); this.D = 2; this.W = 512; this.A = new Float32Array(2048); this.aw = 0; this.cnt = 0; this.ratio = 1; this.tgt = 1; this.d = new Float32Array(400); const win = Math.floor(sampleRate * .05); this.sh = new Shifter(win * 3, win); this.dec = 0; this.dc = 0; this.f0 = 0; }
  yin(){   /* YIN (de Cheveigné & Kawahara, 2002) sur le signal sous-échantillonné par 2 */
    const W = this.W, A = this.A, N = A.length, sr = sampleRate / this.D, tmax = Math.min(399, Math.floor(sr / 70)), tmin = Math.floor(sr / 1000), d = this.d;
    const base = this.aw - W - tmax; let e = 0;
    for (let k = 0; k < W; k++){ const v = A[(base + tmax + k + N * 2) % N]; e += v * v; }
    if (e / W < 1e-5) return 0;
    d[0] = 1; let run = 0, best = -1;
    for (let t = 1; t <= tmax; t++){ let s = 0; for (let k = 0; k < W; k++){ const a = A[(base + tmax + k + N * 2) % N], b = A[(base + tmax + k - t + N * 2) % N]; s += (a - b) * (a - b); } run += s; d[t] = s * t / (run || 1); }
    for (let t = tmin; t <= tmax; t++){ if (d[t] < .15){ while (t + 1 <= tmax && d[t + 1] < d[t]) t++; best = t; break; } }
    if (best < 0) return 0;
    const x0 = d[best - 1] || d[best], x2 = d[best + 1] || d[best], dn = x0 - 2 * d[best] + x2, off = dn ? .5 * (x0 - x2) / dn : 0;
    return sr / (best + off);
  }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const n = y[0].length, sp = par.speed[0], sc = SCALES[Math.max(0, Math.min(4, Math.round(par.scale[0])))], root = Math.round(par.root[0]);
    for (let i = 0; i < n; i++){
      const m = (x[0][i] + (x[1] ? x[1][i] : x[0][i])) * .5;
      if ((this.dec++ & 1) === 0){ this.A[this.aw] = m; this.aw = (this.aw + 1) % this.A.length; this.cnt++; if (this.cnt >= 256){ this.cnt = 0; const f = this.yin(); this.f0 = f; if (f > 0){
        const midi = 69 + 12 * Math.log2(f / 440); let best = midi, bd = 99;
        for (let o = -1; o <= 10; o++) for (const s of sc){ const mm = o * 12 + ((s + root) % 12); const dd = Math.abs(mm - midi); if (dd < bd){ bd = dd; best = mm; } }
        this.tgt = Math.pow(2, (best - midi) / 12); } else this.tgt = 1; } }
      const k = 1 - Math.exp(-1 / (sampleRate * (.002 + (1 - sp) * (1 - sp) * .25))); this.ratio += (this.tgt - this.ratio) * k;
      const v = this.sh.step(m, this.ratio);
      for (let c = 0; c < y.length; c++) y[c][i] = v;
    }
    return true;
  }
}
registerProcessor('qx-tune', QxTune);

class QxCrush extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'bits', defaultValue: 8, minValue: 2, maxValue: 16 }, { name: 'hold', defaultValue: 4, minValue: 1, maxValue: 64 }]; }
  constructor(){ super(); this.h = [0, 0]; this.c = 0; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const L = Math.pow(2, Math.round(par.bits[0]) - 1), H = Math.max(1, Math.round(par.hold[0])), n = y[0].length;
    for (let i = 0; i < n; i++){ if (this.c <= 0){ for (let c = 0; c < y.length; c++) this.h[c] = Math.round(x[Math.min(c, x.length - 1)][i] * L) / L; this.c = H; } this.c--; for (let c = 0; c < y.length; c++) y[c][i] = this.h[c]; }
    return true;
  }
}
registerProcessor('qx-crush', QxCrush);
