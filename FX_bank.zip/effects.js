
/* effects.js — FX_bank (R378). Exécuté par QFXE.loadBank(avec QFXE, H). Effets de banque : H.wfx = AudioWorklet (dérivation tant que le nœud n'est pas prêt). */
var def = QFXE.def, sm = H.sm, bq = H.bq, lfo = H.lfo, mixc = H.mixc;
def('pitch','cre','Décaleur de hauteur','Pitch shifter',3,[['a','Demi‑tons','Semitones',-12,12,7],['b','Fin (cents)','Fine (cents)',-50,50,0]],function(c){
  var u = H.wfx(c,'qx-pitch');
  u.onset = function(n,v){ n.parameters.get('semi').setTargetAtTime(Math.round(v.a*2)/2 + v.b/100, c.currentTime, .02); };
  return u; });
def('shim','spc','Shimmer','Shimmer',4,[['a','Taille','Size',0,1,.6],['b','Brillance','Bright',0,1,.6]],function(c){
  var i = c.createGain(), o = c.createGain(), cv = H.bankIR(c,'ir/hall.wav',2.4), lp = bq(c,'lowpass',9000,.5), g = c.createGain(), up = H.wfx(c,'qx-pitch');
  up.onset = function(n){ n.parameters.get('semi').value = 12; };
  i.connect(up.in); up.out.connect(cv); cv.connect(lp); lp.connect(g); g.gain.value = 1; g.connect(o);
  return { in:i, out:o, set:function(v){ sm(lp.frequency, mixc(1800,14000,v.b), c); sm(g.gain, .5 + v.a*.9, c); }, stop:function(){ up.stop(); } }; });
def('freeze','cre','Gel granulaire','Granular freeze',3,[['a','Gel (≥ 0,5)','Freeze (≥ 0.5)',0,1,0],['b','Grain (s)','Grain (s)',.05,.5,.2]],function(c){
  var u = H.wfx(c,'qx-freeze');
  u.onset = function(n,v){ n.parameters.get('hold').setValueAtTime(v.a >= .5 ? 1 : 0, c.currentTime); n.parameters.get('size').setTargetAtTime(v.b, c.currentTime, .02); };
  return u; });
def('tune','cre','Autotune','Autotune',4,[['a','Vitesse','Speed',0,1,.3],['b','Gamme (0‑4)','Scale (0‑4)',0,4,1],['c','Tonique (0‑11)','Root (0‑11)',0,11,0]],function(c){
  var u = H.wfx(c,'qx-tune');
  u.onset = function(n,v){ n.parameters.get('speed').setTargetAtTime(v.a, c.currentTime, .02); n.parameters.get('scale').value = Math.round(v.b); n.parameters.get('root').value = Math.round(v.c); };
  return u; });
def('crush2','col','Bitcrusher (échantillonnage)','Bitcrusher (sample rate)',2,[['a','Bits','Bits',2,16,8],['b','Taux','Rate',0,1,.5]],function(c){
  var u = H.wfx(c,'qx-crush');
  u.onset = function(n,v){ n.parameters.get('bits').value = Math.round(v.a); n.parameters.get('hold').value = 1 + Math.round(v.b*31); };
  return u; });
def('vib','mod','Vibrato','Vibrato',1,[['a','Vitesse','Rate',1,10,5],['b','Profondeur','Depth',0,1,.4]],function(c){
  var d = c.createDelay(.05), o = lfo(c,'sine',5), g = c.createGain(); d.delayTime.value = .008; o.connect(g); g.connect(d.delayTime);
  return { in:d, out:d, set:function(v){ sm(o.frequency,v.a,c); sm(g.gain,v.b*.0035,c); }, stop:function(){ try{o.stop();}catch(e){} } }; });
def('tape','spc','Délai cassette','Tape delay',2,[['a','Temps','Time',0,1,.4],['b','Répétitions','Repeats',0,.9,.45]],function(c,T){
  var i = c.createGain(), d = c.createDelay(2), fb = c.createGain(), lp = bq(c,'lowpass',3000,.5), hp = bq(c,'highpass',160,.5), o = lfo(c,'sine',.7), og = c.createGain(), out = c.createGain();
  i.connect(d); d.connect(lp); lp.connect(hp); hp.connect(fb); fb.connect(d); hp.connect(out); o.connect(og); og.connect(d.delayTime); og.gain.value = .0012;
  return { in:i, out:out, set:function(v){ sm(d.delayTime, Math.min(1.8, 60/Math.max(30,(T&&T.tempo)||90)*(.25+1.25*v.a)), c); sm(fb.gain, v.b, c); }, stop:function(){ try{o.stop();}catch(e){} } }; });
function irfx(id,fr,en,file,sec){
  def(id,'spc',fr,en,3,[['a','Amorti','Damping',0,1,.4],['b','Pré‑délai','Pre‑delay',0,.12,.02]],function(c){
    var pd = c.createDelay(.2), cv = H.bankIR(c,file,sec), lp = bq(c,'lowpass',9000,.5); pd.connect(cv); cv.connect(lp);
    return { in:pd, out:lp, set:function(v){ sm(pd.delayTime,v.b,c); sm(lp.frequency,mixc(15000,2000,v.a),c); }, stop:function(){} }; });
}
irfx('spring','Réverbération à ressort','Spring reverb','ir/spring.wav',1.6);
irfx('hall','Réverbération salle (hall)','Hall reverb','ir/hall.wav',2.4);
irfx('room','Petite pièce','Small room','ir/room.wav',.6);
def('vinyl','col','Disque vinyle','Vinyl',1,[['a','Craquements','Crackle',0,1,.4],['b','Usure','Wear',0,1,.4]],function(c){
  var i = c.createGain(), lp = bq(c,'lowpass',9000,.6), out = c.createGain(), ns = c.createBufferSource(), ng = c.createGain(), n = c.sampleRate*3, b = c.createBuffer(1,n,c.sampleRate), x = b.getChannelData(0), k;
  for(k=0;k<n;k++){ x[k] = Math.random() < .0009 ? (Math.random()*2-1) : (Math.random()*2-1)*.012; }
  ns.buffer = b; ns.loop = true; ns.connect(ng); ng.connect(out); ns.start(); i.connect(lp); lp.connect(out);
  return { in:i, out:out, set:function(v){ sm(ng.gain, v.a*.9, c); sm(lp.frequency, mixc(12000,2500,v.b), c); }, stop:function(){ try{ns.stop();}catch(e){} } }; }, 1);
