/* R407 : wave en demi-écran / plein écran, réglages, toucher interactif.
   - Appui long (0,5 s) sur la wave dépliée → demi-écran + feuille d'onglets ; Plein écran depuis la feuille.
   - En plein écran, la croix et la barre de lecture n'apparaissent qu'au toucher (≈2,6 s) ; le toucher reste actif.
   - Toucher : la nuée s'écarte du doigt (défaut : oui) ; voile d'énergie (défaut : non).
   - Réglages dans localStorage « qx.wset » ; API window.QWAVE.{get,set,params} (base des automations de wave, voie séparée de l'audio). */
(function(){
var LG=(function(){try{return localStorage.getItem('qx.lang')==='en'?'en':'fr';}catch(e){return 'fr';}})();
var T=function(fr,en){return LG==='en'?en:fr;};
var DEF={hue:0,sat:100,glow:100,spd:100,rep:1,frc:60,flo:0,trl:40,pal:0,tcu:0,tc:25};
var PAL=[['Signature',0,100,100,'#d98a4e'],['Braise',-18,130,105,'#ff5a2e'],['Aurore',110,110,110,'#5be39a'],['Lagon',165,115,105,'#38d6e0'],['Glacier',185,70,125,'#a8e4ff'],['Nuit',215,120,90,'#4a62ff'],['Orchidée',255,115,105,'#a46bff'],['Néon',290,160,110,'#ff3fd8'],['Rose',330,90,115,'#ff7aa8'],['Or',25,60,125,'#ffd34e'],['Cendre',0,10,100,'#b9b9c4'],['Encre',0,0,75,'#e8e8e8']];
var P=[
 {k:'hue',tab:'couleur',l:T('Teinte','Hue'),h:T('Fait tourner toutes les couleurs','Rotates every colour'),min:-180,max:180,u:'°'},
 {k:'sat',tab:'couleur',l:T('Intensité des couleurs','Colour intensity'),h:T('Pâle ↔ vive','Pale ↔ vivid'),min:0,max:200,u:'%'},
 {k:'glow',tab:'couleur',l:T('Luminosité','Brightness'),h:T('Sombre ↔ éclatant','Dim ↔ bright'),min:50,max:170,u:'%'},
 {k:'spd',tab:'reglages',l:T('Vitesse','Speed'),h:T('Ralentit ou accélère la nuée','Slows or speeds up the swarm'),min:20,max:200,u:'%'},
 {k:'frc',tab:'toucher',l:T('Force','Strength'),h:T('Taille de la zone repoussée','Size of the pushed-away area'),min:10,max:100,u:'%'},
 {k:'tc',tab:'toucher',l:T('Couleur de la traînée','Trail colour'),h:T('Teinte du voile, indépendante du rendu','Veil hue, independent of the look'),min:0,max:360,u:'°'},
 {k:'trl',tab:'toucher',l:T('Durée du voile','Veil length'),h:T('Court ↔ long','Short ↔ long'),min:10,max:100,u:'%'}];
var TG=[{k:'rep',tab:'toucher',l:T('Les nuées s’écartent','Swarms move away'),h:T('Les particules fuient la zone touchée','Particles flee the touched area')},
 {k:'tcu',tab:'toucher',l:T('Couleur de traînée personnalisée','Custom trail colour'),h:T('Sinon : suit la teinte du rendu','Otherwise: follows the look’s hue')},
 {k:'flo',tab:'toucher',l:T('Voile d’énergie','Energy veil'),h:T('Un sillage lumineux léger suit le doigt','A light glowing trail follows the finger')}];
var S={};try{S=JSON.parse(localStorage.getItem('qx.wset')||'{}')||{};}catch(e){}
Object.keys(DEF).forEach(function(k){if(typeof S[k]!=='number')S[k]=DEF[k];});
var LK=[['houle',T('Houle','Swell'),T('Houle cuivre et nuée rouge : elles se croisent en tourbillon.','Copper swell and red swarm: they cross in a whirl.')],['nuee',T('Nuée','Swarm'),T('Une nuée bleue qui suit l’aigu.','A blue swarm following the treble.')],['tourbillon',T('Tourbillon','Whirl'),T('Deux courants, violet et ambre, qui se répondent.','Two streams, violet and amber, answering each other.')],['constellation',T('Constellation','Constellation'),T('Des étoiles reliées ; le kick lance une onde.','Linked stars; the kick sends a ripple.')],['cellules',T('Cellules','Cells'),T('Des cellules vivantes qui gonflent au rythme.','Living cells swelling with the beat.')]];
if(typeof S.rd!=='string'||!LK.some(function(l){return l[0]===S.rd;}))S.rd='houle';
function save(){try{localStorage.setItem('qx.wset',JSON.stringify(S));}catch(e){}}
var wv,cv,ph=null,mode='',tab='rendu',sheet=null,ctl=null,ov=null,ovx=null,hideT=0,lp=0,lpx=0,lpy=0,down=false,trail=[],dust=[],ptrIn=false;
function $(i){return document.getElementById(i);}
function apply(){
 if(!cv)return;cv.style.filter=(S.hue||S.sat!==100||S.glow!==100)?'hue-rotate('+S.hue+'deg) saturate('+S.sat/100+') brightness('+S.glow/100+')':'';
 if(window.QWV){QWV.look&&QWV.look(S.rd);QWV.spd=S.spd/100;QWV.T.r=30+S.frc*1.1;QWV.T.f=900+S.frc*14;}}
/* API pour les automations (voie « wave », indépendante de l'audio) */
window.QWAVE={params:P.map(function(p){return {id:p.k,min:p.min,max:p.max,label:p.l};}),get:function(k){return S[k];},set:function(k,v){if(!(k in DEF))return;S[k]=+v;apply();save();if(sheet)sync();}};
/* ---------- feuille & commandes ---------- */
function css(){var s=document.createElement('style');s.textContent='.pal{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 10px}.pw{width:34px;height:34px;border-radius:50%;border:2px solid rgba(255,255,255,.15);padding:0;min-width:0;box-shadow:none}.pw.on{border-color:#fff;box-shadow:0 0 0 2px rgba(110,226,255,.7)}'+
'body>.qwv.wvh{position:fixed;left:0;right:0;top:0;height:44%;z-index:2147480000;border-radius:0 0 24px 24px;transition:none;background:#080D15;overflow:hidden;touch-action:none}'+
'body>.qwv.wvf{position:fixed;inset:0;height:auto;z-index:2147480100;border-radius:0;transition:none}'+
'#qCase .qwv{touch-action:none}body>.qwv.wvh #qFold,body>.qwv.wvf #qFold{display:none!important}'+
'#qwSheet{position:fixed;left:0;right:0;bottom:0;top:44%;z-index:2147480050;background:linear-gradient(#0a101c,#070b14);border-top:1px solid rgba(130,180,220,.18);display:none;flex-direction:column;color:#dbe7f5;font:500 14px/1.4 system-ui,sans-serif;-webkit-user-select:none;user-select:none}'+
'body.qwh #qwSheet{display:flex}'+
'#qwSheet .h{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 16px 6px}#qwSheet .h b{font:600 13px ui-monospace,monospace;letter-spacing:.16em;text-transform:uppercase}#qwSheet .h small{display:block;font:400 11px system-ui;letter-spacing:0;text-transform:none;color:#8aa0b6;margin-top:2px}'+
'#qwSheet .a{display:flex;gap:8px}#qwSheet .bg{height:38px;padding:0 14px;border-radius:14px;border:1px solid rgba(77,215,255,.6);background:rgba(77,215,255,.12);color:#4dd7ff;font:600 11px ui-monospace,monospace;letter-spacing:.12em;text-transform:uppercase;cursor:pointer}#qwSheet .bg.q{border-color:rgba(130,180,220,.25);color:#dbe7f5;background:transparent}'+
'#qwSheet .tb{display:flex;gap:4px;padding:4px 16px 0;border-bottom:1px solid rgba(130,180,220,.18);overflow-x:auto}#qwSheet .tb button{flex:none;height:36px;padding:0 12px;background:none;border:0;border-bottom:2px solid transparent;color:#8aa0b6;font:600 11px ui-monospace,monospace;letter-spacing:.1em;text-transform:uppercase;cursor:pointer}#qwSheet .tb button.on{color:#4dd7ff;border-bottom-color:#4dd7ff}'+
'#qwSheet .pn{flex:1;min-height:0;overflow-y:auto;padding:14px 16px calc(18px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;gap:14px}'+
'#qwSheet .hp{margin:0;font:400 12.5px/1.5 system-ui;color:#8aa0b6}'+
'#qwSheet .cd{display:flex;flex-direction:column;gap:6px;padding:10px;border-radius:16px;border:1px solid rgba(77,215,255,.75);background:rgba(10,16,28,.8);box-shadow:0 0 18px -6px rgba(77,215,255,.6)}#qwSheet .cd b{font:600 12px ui-monospace,monospace;letter-spacing:.06em}#qwSheet .cd span{font:400 11.5px/1.35 system-ui;color:#8aa0b6}'+
'#qwSheet .sl{display:grid;grid-template-columns:1fr 52px;column-gap:10px;align-items:center}#qwSheet .sl .qwl{font:600 12px system-ui}#qwSheet .sl .qwl em{display:block;font:400 11px system-ui;font-style:normal;color:#8aa0b6}#qwSheet .sl output{text-align:right;font:500 12px ui-monospace,monospace;color:#4dd7ff}#qwSheet .sl input{grid-column:1/3;width:100%;accent-color:#4dd7ff;height:30px;margin:0}'+
'#qwSheet .tg{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px 12px;border-radius:14px;border:1px solid rgba(130,180,220,.18);background:rgba(10,16,28,.6)}#qwSheet .tg .qwl{font:600 13px system-ui}#qwSheet .tg .qwl em{display:block;font:400 11.5px/1.35 system-ui;font-style:normal;color:#8aa0b6;margin-top:2px}#qwSheet .tg input{width:22px;height:22px;accent-color:#4dd7ff;flex:none}'+
'#qwSheet .rz{align-self:flex-start;height:36px;padding:0 14px;border-radius:12px;border:1px solid rgba(130,180,220,.25);background:transparent;color:#dbe7f5;font:600 11px ui-monospace,monospace;letter-spacing:.08em;cursor:pointer;text-transform:uppercase}'+
'#qwCtl{position:fixed;inset:0;z-index:2147480200;pointer-events:none;opacity:0;transition:opacity .45s;display:none}body.qwf #qwCtl{display:block}#qwCtl.show{opacity:1}'+
'#qwCtl button{pointer-events:none}#qwCtl.show button{pointer-events:auto}'+
'#qwX{position:absolute;left:max(14px,env(safe-area-inset-left,0px));top:calc(14px + env(safe-area-inset-top,0px));width:44px;height:44px;border-radius:50%;border:1px solid rgba(219,231,245,.3);background:rgba(7,11,20,.55);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:grid;place-items:center;cursor:pointer;color:#dbe7f5}'+
'#qwBar{position:absolute;left:max(14px,env(safe-area-inset-left,0px));right:max(14px,env(safe-area-inset-right,0px));bottom:calc(14px + env(safe-area-inset-bottom,0px));display:flex;align-items:center;gap:12px;padding:8px 14px 8px 8px;border-radius:999px;border:1px solid rgba(219,231,245,.22);background:rgba(7,11,20,.6);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);color:#8aa0b6;font:500 11px ui-monospace,monospace;letter-spacing:.1em}'+
'#qwPP{width:44px;height:44px;border-radius:50%;border:1px solid rgba(255,255,255,.4);background:transparent;display:grid;place-items:center;cursor:pointer;color:#dbe7f5;flex:none}'+
'#qwOv{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;display:none}'+
'#qwMsg{position:fixed;left:0;right:0;top:50%;z-index:2147480150;text-align:center;font:500 12px ui-monospace,monospace;letter-spacing:.14em;color:rgba(219,231,245,.7);pointer-events:none;opacity:0;transition:opacity .6s}';
document.head.appendChild(s);}
function build(){
 sheet=document.createElement('div');sheet.id='qwSheet';sheet.setAttribute('role','dialog');
 sheet.innerHTML='<div class="h"><div><b>Wave</b><small>'+T('Rendu Signature · houle cuivre et nuée rouge','Signature · copper swell and red swarm')+'</small></div><div class="a"><button class="bg" id="qwFull">'+T('Plein écran','Full screen')+'</button><button class="bg q" id="qwBack">'+T('Fermer','Close')+'</button></div></div><div class="tb" id="qwTb"></div><div class="pn" id="qwPn"></div>';
 document.body.appendChild(sheet);
 ctl=document.createElement('div');ctl.id='qwCtl';ctl.innerHTML='<button id="qwX" aria-label="'+T('Fermer le plein écran','Exit full screen')+'"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button><div id="qwBar"><button id="qwPP" aria-label="'+T('Lecture / pause','Play / stop')+'"><svg id="qwPPi" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></svg></button><span>'+T('BOUCLE EN COURS','LOOPING')+'</span></div>';
 document.body.appendChild(ctl);
 var m=document.createElement('div');m.id='qwMsg';m.textContent=T('TOUCHE L’ÉCRAN · LES NUÉES S’ÉCARTENT','TOUCH THE SCREEN · SWARMS MOVE AWAY');document.body.appendChild(m);
 $('qwFull').onclick=function(){set('f');};$('qwBack').onclick=function(){set('');};$('qwX').onclick=function(){set('h');};
 $('qwPP').onclick=function(){var b=$('bPlay');if(b)b.click();poke();setTimeout(ppi,150);};}
function ppi(){var b=$('bPlay'),on=false;try{on=!!(window.playing||(b&&/stop|■|pause/i.test(b.className+b.getAttribute('aria-pressed'))));}catch(e){}$('qwPPi').innerHTML=on?'<path d="M9 6v12M15 6v12"/>':'<path d="M8 5.5v13l11-6.5z"/>';}
function tabs(){var tb=$('qwTb');tb.innerHTML='';[['rendu',T('Rendu','Look')],['couleur',T('Couleur','Colour')],['reglages',T('Réglages','Settings')],['toucher',T('Toucher','Touch')]].forEach(function(t){var b=document.createElement('button');b.textContent=t[1];b.className=tab===t[0]?'on':'';b.onclick=function(){tab=t[0];tabs();pane();};tb.appendChild(b);});}
function pane(){var pn=$('qwPn');pn.innerHTML='';
 if(tab==='rendu'){pn.innerHTML='<p class="hp">'+T('Choisis le rendu de la wave.','Pick the wave look.')+'</p>';LK.forEach(function(l){var b=document.createElement('button');b.type='button';b.className='cd'+(S.rd===l[0]?' on':'');b.dataset.rd=l[0];b.style.cssText='text-align:left;width:100%;cursor:pointer;color:inherit;font:inherit;'+(S.rd===l[0]?'border-color:#4dd7ff;box-shadow:0 0 0 1px #4dd7ff;':'');b.innerHTML='<b>'+l[1]+'</b><span>'+l[2]+'</span>';b.onclick=function(){S.rd=l[0];apply();save();pane();};pn.appendChild(b);});return;}
 if(tab==='couleur'){var pw=document.createElement('div');pw.className='pal';PAL.forEach(function(q,i){var b=document.createElement('button');b.className='pw'+(S.pal===i?' on':'');b.style.background=q[4];b.title=q[0];b.setAttribute('aria-label',q[0]);b.onclick=function(){S.pal=i;S.hue=q[1];S.sat=q[2];S.glow=q[3];apply();save();pane();};pw.appendChild(b);});pn.appendChild(pw);}
 var hp=document.createElement('p');hp.className='hp';hp.textContent={couleur:T('Ajuste les couleurs du rendu.','Adjust the look’s colours.'),reglages:T('Comportement de la nuée.','Swarm behaviour.'),toucher:T('Pose le doigt sur la wave pour essayer.','Touch the wave to try it.')}[tab];pn.appendChild(hp);
 TG.filter(function(g){return g.tab===tab;}).forEach(function(g){var l=document.createElement('label');l.className='tg';l.innerHTML='<span class="qwl">'+g.l+'<em>'+g.h+'</em></span><input type="checkbox"'+(S[g.k]?' checked':'')+'>';l.querySelector('input').onchange=function(){S[g.k]=this.checked?1:0;if(g.k==='flo'){trail.length=0;dust.length=0;ovShow();}apply();save();};pn.appendChild(l);});
 P.filter(function(p){return p.tab===tab;}).forEach(function(p){var l=document.createElement('label');l.className='sl';l.dataset.k=p.k;l.innerHTML='<span class="qwl">'+p.l+'<em>'+p.h+'</em></span><output>'+S[p.k]+p.u+'</output><input type="range" min="'+p.min+'" max="'+p.max+'" value="'+S[p.k]+'">';l.querySelector('input').oninput=function(){S[p.k]=+this.value;l.querySelector('output').textContent=this.value+p.u;apply();save();};pn.appendChild(l);});
 var r=document.createElement('button');r.className='rz';r.textContent=T('Réinitialiser','Reset');r.onclick=function(){Object.keys(DEF).forEach(function(k){S[k]=DEF[k];});S.rd='houle';apply();save();pane();};pn.appendChild(r);}
function sync(){var pn=$('qwPn');if(!pn)return;[].forEach.call(pn.querySelectorAll('.sl'),function(l){var k=l.dataset.k,p=P.filter(function(q){return q.k===k})[0];if(!p)return;l.querySelector('input').value=S[k];l.querySelector('output').textContent=S[k]+p.u;});}
/* ---------- états ---------- */
function set(m){
 try{if(document.fullscreenElement&&m!=='f')document.exitFullscreen();}catch(e){}
 mode=m;down=false;ptrIn=false;QWV&&(QWV.T.on=false);trail.length=0;dust.length=0;
 wv.classList.toggle('wvh',m==='h'||m==='f');wv.classList.toggle('wvf',m==='f');
 document.body.classList.toggle('qwh',m==='h');document.body.classList.toggle('qwf',m==='f');
 if(m==='h'||m==='f'){if(!ph){ph=document.createElement('div');ph.style.cssText='height:'+wv.offsetHeight+'px;flex:none';wv.parentNode.insertBefore(ph,wv);document.body.appendChild(wv);}}
 else if(ph){ph.parentNode.insertBefore(wv,ph);ph.remove();ph=null;}
 if(m==='h'){tab=tab||'rendu';tabs();pane();}
 if(m==='f'){poke();var g=$('qwMsg');g.style.opacity=1;setTimeout(function(){g.style.opacity=0;},2600);try{var d=document.documentElement;if(d.requestFullscreen)d.requestFullscreen().catch(function(){});}catch(e){}ppi();}
 else ctl.classList.remove('show');
 ovShow();setTimeout(function(){window.dispatchEvent(new Event('resize'));},30);}
function poke(){if(mode!=='f')return;ctl.classList.add('show');clearTimeout(hideT);hideT=setTimeout(function(){ctl.classList.remove('show');},2600);}
/* ---------- toucher ---------- */
function xy(e){var r=wv.getBoundingClientRect();return {x:(e.clientX-r.left)/r.width*(window.QWV?QWV.W:360),y:(e.clientY-r.top)/r.height*(window.QWV&&QWV.H?QWV.H():84),px:e.clientX-r.left,py:e.clientY-r.top};}
function ovShow(){if(!ov)return;ov.style.display=(S.flo&&window.QWV)?'block':'none';}
function addTrail(px,py,now){var l=trail[trail.length-1];if(l&&Math.hypot(px-l.x,py-l.y)<4)return;trail.push({x:px,y:py,t:now});if(trail.length>90)trail.shift();if(Math.random()<.3&&dust.length<30)dust.push({x:px+(Math.random()-.5)*12,y:py+(Math.random()-.5)*12,vx:(Math.random()-.5)*14,vy:(Math.random()-.5)*14,l:1});}
function bind(){
 wv.addEventListener('pointerdown',function(e){if(e.target.tagName==='BUTTON'||wv.classList.contains('fold'))return;var p=xy(e);down=true;try{wv.setPointerCapture(e.pointerId);}catch(x){}
  if(S.rep){QWV.T.on=true;QWV.T.x=p.x;QWV.T.y=p.y;}poke();
  if(!mode){lpx=e.clientX;lpy=e.clientY;lp=setTimeout(function(){lp=0;set('h');},520);}});
 wv.addEventListener('pointermove',function(e){if(!down)return;var p=xy(e);if(S.rep){QWV.T.on=true;QWV.T.x=p.x;QWV.T.y=p.y;}poke();
  if(lp&&Math.hypot(e.clientX-lpx,e.clientY-lpy)>12){clearTimeout(lp);lp=0;}
  if(S.flo)addTrail(p.px,p.py,performance.now());});
 function up(){down=false;clearTimeout(lp);lp=0;if(window.QWV)QWV.T.on=false;poke();}
 ['pointerup','pointercancel','lostpointercapture'].forEach(function(n){wv.addEventListener(n,up);});
 window.addEventListener('blur',up);
 document.addEventListener('fullscreenchange',function(){if(!document.fullscreenElement&&mode==='f')set('h');});
 /* voile d'énergie : large, court, transparent (désactivé par défaut) */
 ov=document.createElement('canvas');ov.id='qwOv';wv.appendChild(ov);ovx=ov.getContext('2d');
 (function loop(){requestAnimationFrame(loop);if(!S.flo||!ovx)return;var r=wv.getBoundingClientRect(),w=Math.round(r.width),h=Math.round(r.height);if(ov.width!==w||ov.height!==h){ov.width=w;ov.height=h;}
  var c=ovx,now=performance.now(),keep=160+S.trl*3.2;c.clearRect(0,0,w,h);while(trail.length&&now-trail[0].t>keep)trail.shift();
  c.globalCompositeOperation='lighter';var th=S.tcu?S.tc:(25+S.hue+360)%360;
  for(var i=0;i<trail.length;i++){var q=trail[i],a=1-(now-q.t)/keep;if(a<=0)continue;var e=a*a*(3-2*a),rr=18+26*e,g=c.createRadialGradient(q.x,q.y,0,q.x,q.y,rr);g.addColorStop(0,'hsla('+th+',90%,72%,'+.09*e+')');g.addColorStop(1,'hsla('+th+',90%,55%,0)');c.fillStyle=g;c.fillRect(q.x-rr,q.y-rr,rr*2,rr*2);}
  for(var j=dust.length-1;j>=0;j--){var d=dust[j];d.x+=d.vx*.016;d.y+=d.vy*.016;d.l-=.02;if(d.l<=0){dust.splice(j,1);continue;}c.fillStyle='hsla('+th+',80%,85%,'+d.l*.4+')';c.fillRect(d.x-.6,d.y-.6,1.2,1.2);}
  c.globalCompositeOperation='source-over';})();
 ovShow();}
var n=0,iv=setInterval(function(){wv=document.querySelector('#qCase .qwv');cv=$('qWave');if(wv&&cv&&window.QWV){clearInterval(iv);css();build();bind();apply();}else if(++n>120)clearInterval(iv);},250);
})();
