/* QWV — wave du lecteur de Quantone (R398) : nuée rouge (caisse, aigus) + houle Cuivre (basse, kick) autour d'une silhouette de nuée.
   Rencontre « tourbillon » (C1) : les deux nuées se contournent, le recouvrement vire au vert-de-gris. Nourri par l'analyseur audio. */
(function(){'use strict';
var W=360,Hh=84,X0=14,X1=336,SP=[],DW=90,DH=21,GW=120,GH=28;var TCH={on:false,x:0,y:0,r:70,f:1400};
var S={t:0,k:0,s:0,h:0,b:0,p:0,bn:0,on:{k:0,s:0,h:0},tick:0,lv:{bass:0,mid:0,high:0}};
var EN=0;
  function hh(i,j,k){var h=(Math.imul(i,374761393)+Math.imul(j,668265263)+Math.imul(k,1274126177))|0;h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967295;}
  function nz(x,y,z){var xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),fx=x-xi,fy=y-yi,fz=z-zi;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);fz=fz*fz*(3-2*fz);
    var a=hh(xi,yi,zi),b=hh(xi+1,yi,zi),c=hh(xi,yi+1,zi),d=hh(xi+1,yi+1,zi),e=hh(xi,yi,zi+1),f=hh(xi+1,yi,zi+1),g=hh(xi,yi+1,zi+1),h=hh(xi+1,yi+1,zi+1);
    var x1=a+(b-a)*fx,x2=c+(d-c)*fx,x3=e+(f-e)*fx,x4=g+(h-g)*fx,y1=x1+(x2-x1)*fy,y2=x3+(x4-x3)*fy;return y1+(y2-y1)*fz;}
  function fbm(x,y,z){return nz(x,y,z)*.62+nz(x*2.03+5.2,y*2.03+1.3,z*1.3+7)*.38;}
  function ss(a,b,x){var t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);}
  var CFGX={den:1,sze:1,trb:1};
  var EN=0;   /* énergie lissée */
  /* ---- cadre rouge qui vibre (comme la frontière du jeu) ---- */
  var RIM=8;
  function rimPath(c,t,vib){var pts=[],i,n,x,y,P=[[RIM,RIM,W-RIM,RIM],[W-RIM,RIM,W-RIM,Hh-RIM],[W-RIM,Hh-RIM,RIM,Hh-RIM],[RIM,Hh-RIM,RIM,RIM]],e,L,seg;
    c.beginPath();var first=true;for(e=0;e<4;e++){var p=P[e];L=Math.hypot(p[2]-p[0],p[3]-p[1]);n=Math.ceil(L/5);for(i=0;i<n;i++){var u=i/n;x=p[0]+(p[2]-p[0])*u;y=p[1]+(p[3]-p[1])*u;var nx=p[3]-p[1],ny=-(p[2]-p[0]);var nl=Math.hypot(nx,ny)||1;nx/=nl;ny/=nl;var o=(nz(x*.09+e*9,y*.09,t*6)-.5)*(1.6+vib*7);x+=nx*o;y+=ny*o;if(first){c.moveTo(x,y);first=false;}else c.lineTo(x,y);}}c.closePath();}
  function rim(c,t,vib){rimPath(c,t,vib);c.lineJoin='round';c.strokeStyle='rgba(190,26,50,'+(.16+.14*vib)+')';c.lineWidth=5+3*vib;c.stroke();c.strokeStyle='rgba(214,56,76,'+(.55+.4*vib)+')';c.lineWidth=1.1+.5*vib;c.stroke();}
  function clipBox(c){c.beginPath();c.moveTo(RIM+6,RIM);c.arcTo(W-RIM,RIM,W-RIM,Hh-RIM,6);c.arcTo(W-RIM,Hh-RIM,RIM,Hh-RIM,6);c.arcTo(RIM,Hh-RIM,RIM,RIM,6);c.arcTo(RIM,RIM,W-RIM,RIM,6);c.closePath();c.clip();}
  function edgeD(x,y){return Math.min(x-RIM,y-RIM,W-RIM-x,Hh-RIM-y);}
  /* ---- mise en place d'un cadran ---- */
  function lowCanvas(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c;}

  function initA(m){var N=300,i;m.N=N;m.tc=lowCanvas(W*2,Hh*2);m.tx=m.tc.getContext('2d');m.tx.setTransform(2,0,0,2,0,0);m.gc=lowCanvas(GW,GH);m.gx=m.gc.getContext('2d');
    m.dc=lowCanvas(DW,DH);m.dx=m.dc.getContext('2d');m.di=m.dx.createImageData(DW,DH);m.den=new Float32Array(DW*DH);m.cnt=new Float32Array(DW*DH);
    m.B=[];for(i=0;i<N;i++){var a=Math.random()*6.28;m.B.push({x:RIM+10+Math.random()*(W-2*RIM-20),y:RIM+6+Math.random()*(Hh-2*RIM-12),vx:Math.cos(a)*20,vy:Math.sin(a)*20,h:Math.random()<.86?0:(1+(Math.random()*3|0)),edge:Math.random()<.35,ph:Math.random()*9});}
    m.t=0;m.CW=18;m.CX=Math.ceil(W/m.CW);m.CY=Math.ceil(Hh/m.CW);m.cells=[];for(i=0;i<m.CX*m.CY;i++)m.cells.push([]);m.cohB=0;m.sc=0;}
  function drawA(m,dt,tk){var c=m.c,tx=m.tx,B=m.B,N=m.N,i,j,lv=S.lv,E=Math.min(1,lv.bass*.8+lv.mid*.5+lv.high*.6);m.t+=dt;var t=m.t;
    if(S.on.k&&!m.noK){var ox=RIM+Math.random()*(W-2*RIM),oy=RIM+Math.random()*(Hh-2*RIM);for(i=0;i<N;i++){var b=B[i],dx=b.x-ox,dy=b.y-oy,l=Math.hypot(dx,dy)+8,f=95/(1+l*.03);b.vx+=dx/l*f*(.5+Math.random());b.vy+=dy/l*f*(.5+Math.random());}m.cohB=1;}
    if(S.on.s){var ph=Math.random()*6.28,dr=Math.random()<.5?1:-1;for(i=0;i<N;i++){var b3=B[i],w=Math.sin(b3.x*.045+ph);b3.vx+=-b3.vy*.0+dr*w*18;b3.vy+=dr*Math.cos(b3.x*.045+ph)*34;}}
    m.cohB*=Math.exp(-dt/.7);
    /* deux « nuages » qui errent : la nuée s'y rassemble, se déforme, se sépare */
    var A1x=W/2+Math.sin(t*.37)*110+Math.sin(t*.91+1)*35,A1y=Hh/2+Math.cos(t*.43)*14*(Hh/84),A2x=W/2+Math.cos(t*.29+2)*120+Math.sin(t*.77)*40,A2y=Hh/2+Math.sin(t*.51+1)*15*(Hh/84);
    var cells=m.cells,CX=m.CX,CY=m.CY,CW=m.CW;for(i=0;i<cells.length;i++)cells[i].length=0;
    for(i=0;i<N;i++){var q=B[i],cx=Math.max(0,Math.min(CX-1,q.x/CW|0)),cy=Math.max(0,Math.min(CY-1,q.y/CW|0));cells[cy*CX+cx].push(i);}
    var rb=m.rb==null?1:m.rb,sp0=20*(.65+1.1*(lv.mid+lv.high*.6)+1.4*S.k*rb),coh=.55+1.6*lv.bass*rb+1.8*m.cohB*rb+(rb<1?.9*lv.mid:0),ali=1.9+1.2*lv.mid,jit=S.h*55;
    for(i=0;i<N;i++){var p=B[i],cx2=Math.max(0,Math.min(CX-1,p.x/CW|0)),cy2=Math.max(0,Math.min(CY-1,p.y/CW|0)),n=0,sx=0,sy=0,svx=0,svy=0,fx=0,fy=0,ii,jj,c2;
      for(jj=-1;jj<=1;jj++)for(ii=-1;ii<=1;ii++){var X=cx2+ii,Y=cy2+jj;if(X<0||Y<0||X>=CX||Y>=CY)continue;c2=cells[Y*CX+X];for(var k=0;k<c2.length;k++){var o=B[c2[k]];if(o===p)continue;var dx2=o.x-p.x,dy2=o.y-p.y,d2=dx2*dx2+dy2*dy2;if(d2<420){n++;sx+=o.x;sy+=o.y;svx+=o.vx;svy+=o.vy;if(d2<14){fx-=dx2/(d2+1)*5;fy-=dy2/(d2+1)*5;}}}}
      var ax=fx*3,ay=fy*3;
      if(n){ax+=(sx/n-p.x)*coh*.9+(svx/n-p.vx)*ali*.55;ay+=(sy/n-p.y)*coh*.9+(svy/n-p.vy)*ali*.55;}
      /* courant tourbillonnant imprévisible */
      var ang=nz(p.x*.022+p.ph,p.y*.03,t*.35)*12.56,fl=16+30*E;ax+=Math.cos(ang)*fl;ay+=Math.sin(ang)*fl;
      var tgx=((p.ph|0)%2?A1x:A2x),tgy=((p.ph|0)%2?A1y:A2y);ax+=(tgx-p.x)*.35;ay+=(tgy-p.y)*.6;
      if(jit){ax+=(Math.random()-.5)*jit*4;ay+=(Math.random()-.5)*jit*4;}
      if(TCH.on){var rx0=p.x-TCH.x,ry0=p.y-TCH.y,rd=Math.hypot(rx0,ry0)+.1;if(rd<TCH.r){var rf=1-rd/TCH.r;rf*=rf*TCH.f;ax+=rx0/rd*rf;ay+=ry0/rd*rf;}}   /* R407 : le toucher écarte la nuée */
      var dL=p.x-RIM,dR=W-RIM-p.x,dT=p.y-RIM,dB=Hh-RIM-p.y,wall=9;
      if(dL<wall)ax+=(wall-dL)*14;if(dR<wall)ax-=(wall-dR)*14;if(dT<wall)ay+=(wall-dT)*14;if(dB<wall)ay-=(wall-dB)*14;
      if(p.edge){var m1=Math.min(dL,dR,dT,dB);if(m1>6){ /* quelques-uns longent la paroi */
        if(m1===dT)ay-=(dT-5)*2.2,ax+=Math.cos(t*.6+p.ph)*20;else if(m1===dB)ay+=(dB-5)*2.2,ax+=Math.cos(t*.6+p.ph)*20;else if(m1===dL)ax-=(dL-5)*2.2,ay+=Math.cos(t*.6+p.ph)*14;else ax+=(dR-5)*2.2,ay+=Math.cos(t*.6+p.ph)*14;}}
      p.vx+=ax*dt;p.vy+=ay*dt;var v=Math.hypot(p.vx,p.vy)||1,vt=Math.min(Math.max(v,sp0*.55),sp0*1.7+60*S.k);p.vx*=vt/v;p.vy*=vt/v;
      var ox2=p.x,oy2=p.y;p.x+=p.vx*dt;p.y+=p.vy*dt;p.x=Math.max(RIM+1,Math.min(W-RIM-1,p.x));p.y=Math.max(RIM+1,Math.min(Hh-RIM-1,p.y));p.ox=ox2;p.oy=oy2;}
    /* traînées = filaments */
    tx.globalCompositeOperation='destination-out';tx.fillStyle='rgba(0,0,0,'+(.07+.08*(1-E))+')';tx.fillRect(0,0,W,Hh);
    tx.globalCompositeOperation='lighter';tx.lineCap='round';
    for(i=0;i<N;i++){var q2=B[i],sp=Math.hypot(q2.vx,q2.vy),col=q2.h===0?'196,30,52':q2.h===1?'176,120,255':q2.h===2?'255,176,84':'96,214,255',al=(q2.h===0?.34:.16)*(.6+.7*E+.5*S.k);
      tx.strokeStyle='rgba('+col+','+al+')';tx.lineWidth=.55+.5*Math.min(1,sp/80);tx.beginPath();tx.moveTo(q2.ox,q2.oy);tx.lineTo(q2.x,q2.y);tx.stroke();}
    tx.globalCompositeOperation='source-over';
    /* densité → voile doux (comme les nuages de la nuée) */
    var cn=m.cnt,den=m.den,di=m.di.data,x,y;cn.fill(0);for(i=0;i<N;i++){var gx=Math.min(DW-1,B[i].x/4|0),gy=Math.min(DH-1,B[i].y*DH/Hh|0);for(var oy3=-1;oy3<=1;oy3++)for(var ox3=-1;ox3<=1;ox3++){var X3=gx+ox3,Y3=gy+oy3;if(X3>=0&&Y3>=0&&X3<DW&&Y3<DH)cn[Y3*DW+X3]+=(ox3||oy3)?.5:1;}}
    for(y=0;y<DH;y++)for(x=0;x<DW;x++){var k2=y*DW+x;den[k2]+=(Math.min(1,cn[k2]/7)-den[k2])*Math.min(1,dt*4);var d=den[k2],ed=edgeD(x*4+2,(y+.5)*Hh/DH),q3=k2*4;di[q3]=205;di[q3+1]=18+26*d;di[q3+2]=34+34*d*(.4+.6*nz(x*.1,y*.15,t*.4));di[q3+3]=ed>0?Math.min(255,255*d*(.3+.3*E)):0;}
    m.dx.putImageData(m.di,0,0);
    c.setTransform(2,0,0,2,0,0);c.globalCompositeOperation='source-over';c.fillStyle='#080D15';c.fillRect(0,0,W,Hh);
    c.save();clipBox(c);c.imageSmoothingEnabled=true;c.drawImage(m.dc,0,0,W,Hh);
    m.gx.globalCompositeOperation='copy';m.gx.drawImage(m.tc,0,0,GW,GH);c.globalCompositeOperation='lighter';c.globalAlpha=.7;c.drawImage(m.gc,0,0,W,Hh);c.globalAlpha=.9;c.drawImage(m.tc,0,0,W,Hh);c.globalAlpha=1;
    /* têtes : petits points, comme la nuée vue de loin */
    c.fillStyle='rgba(205,80,92,.22)';for(i=0;i<N;i+=2){c.fillRect(B[i].x-.4,B[i].y-.4,.9,.9);}
    c.globalCompositeOperation='source-over';if(m.over)m.over(m,c,dt,tk);else trait(c,tk,Hh/2,Math.min(1,E));c.restore();rim(c,t,Math.min(1,S.k*.8+lv.high*.4));}

  function mkOver(mode){return function(m){initA(m);var N=mode===2?120:mode===1?230:280,P=[],i;
    m.t2=lowCanvas(W*2,Hh*2);m.t2x=m.t2.getContext('2d');m.t2x.setTransform(2,0,0,2,0,0);m.g2=lowCanvas(GW,GH);m.g2x=m.g2.getContext('2d');m.col=new Array(170);
    for(i=0;i<N;i++)P.push({x:X0+Math.random()*(X1-X0),y:Hh/2+(Math.random()-.5)*30,ox:0,oy:0,vx:0,vy:0,ci:mode===2?(i%60)/60:Math.random(),side:mode===2?(i<60?-1:1):0,off:Math.random()*2-1,ph:Math.random()*9,c:Math.random(),ok:false});
    m.P2=P;
    m.over=function(m,c,dt,tk){var lv=S.lv,hi=Math.min(1,lv.high+S.h*.5),mid=Math.min(1,lv.mid+S.p*.4),cy=Hh/2,col=m.col,tx=m.t2x,t=m.t,k,idx,P=m.P2,n=Math.max(6,Math.round(P.length*Math.min(1,CFGX.den))),p,i;
      for(k=0;k<170;k++)col[k]=null;for(k=0;k<SP.length;k++){var q0=SP[k];idx=((q0.x-X0)/2)|0;if(idx>=0&&idx<170)col[idx]=q0;}
      tx.globalCompositeOperation='destination-out';tx.fillStyle='rgba(0,0,0,'+(mode===3?.22:.16)+')';tx.fillRect(0,0,W,Hh);tx.globalCompositeOperation='lighter';tx.lineCap='round';
      var prev=null;
      for(i=0;i<n;i++){p=P[i];idx=Math.max(0,Math.min(169,(p.ci*169)|0));var q=col[idx],has=q&&tk-q.t<80,gx=X0+idx*2,gy;
        if(has){var amp=Math.max(1.2,cy-q.a);
          if(mode===1){gy=(p.c<.45?2*cy-q.a:q.a)+p.off*(1.5+15*(S.h*.9+hi*.6));}
          else if(mode===2){gy=(p.side<0?q.a:2*cy-q.a)+Math.sin(t*4+p.ph+idx*.35)*(.8+9*(mid+S.s*.5));}
          else{gy=cy+p.off*amp*1.05;}
          var kk=mode===3?22:mode===2?46:30+22*(1-S.h);p.vx+=(gx-p.x)*kk*dt;p.vy+=(gy-p.y)*kk*dt;p.ok=true;}
        else{p.ok=false;}
        var ang=nz(p.x*.05+p.ph,p.y*.05,t*.8)*12.56,sw=CFGX.trb*(has?10:26)*(.4+(mode===1?hi:mid));p.vx+=Math.cos(ang)*sw*dt;p.vy+=Math.sin(ang)*sw*dt;
        if(mode===3&&S.s>.1)p.vy+=(Math.random()-.5)*S.s*140;if(mode===1&&S.h>.2){p.vx+=(Math.random()-.5)*S.h*60;p.vy+=(Math.random()-.5)*S.h*90;}
        p.vx*=Math.exp(-dt*(has?5:2.2));p.vy*=Math.exp(-dt*(has?5:2.2));p.ox=p.x;p.oy=p.y;p.x+=p.vx*dt;p.y+=p.vy*dt;
        if(p.x<RIM+1){p.x=RIM+1;p.vx*=-.5;}if(p.x>W-RIM-1){p.x=W-RIM-1;p.vx*=-.5;}if(p.y<RIM+1){p.y=RIM+1;p.vy*=-.5;}if(p.y>Hh-RIM-1){p.y=Hh-RIM-1;p.vy*=-.5;}
        var cl=mode===1?'104,196,255':mode===2?(p.c<.5?'168,128,255':'255,178,86'):'132,166,222',al=(mode===3?.5:.6)*(has?1:.45)*(.65+.5*(mode===1?hi:mid));
        tx.strokeStyle='rgba('+cl+','+al+')';tx.lineWidth=mode===2?1:.7;tx.beginPath();tx.moveTo(p.ox,p.oy);tx.lineTo(p.x,p.y+.01);tx.stroke();
        if(mode===2){if(prev&&prev.side===p.side&&prev.ok&&p.ok&&Math.abs(prev.x-p.x)<9){tx.strokeStyle='rgba(168,128,255,.2)';tx.lineWidth=.6;tx.beginPath();tx.moveTo(prev.x,prev.y);tx.lineTo(p.x,p.y);tx.stroke();}prev=p;}}
      tx.globalCompositeOperation='source-over';
      m.g2x.globalCompositeOperation='copy';m.g2x.drawImage(m.t2,0,0,GW,GH);c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(m.g2,0,0,W,Hh);c.globalAlpha=.95;c.drawImage(m.t2,0,0,W,Hh);c.globalAlpha=1;
      var cc=mode===1?'150,215,255':mode===2?'210,180,255':'175,200,240';c.fillStyle='rgba('+cc+',.7)';for(i=0;i<n;i++){p=P[i];c.fillRect(p.x-.45,p.y-.45,.9,.9);}c.globalCompositeOperation='source-over';};};}
  function mkHoule(cfg){return function(m){mkOver(3)(m);var o3=m.over,N=300,P=[],i,G=cfg.G;m.rb=.15;m.noK=true;
    m.t3=lowCanvas(W*2,Hh*2);m.t3x=m.t3.getContext('2d');m.t3x.setTransform(2,0,0,2,0,0);m.g3=lowCanvas(GW,GH);m.g3x=m.g3.getContext('2d');m.sp=0;m.spT=0;m.spK=0;m.nextS=2+Math.random()*3;
    for(i=0;i<N;i++)P.push({x:W/2+(Math.random()-.5)*80,y:Hh*.6+(Math.random()-.5)*14,ox:0,oy:0,vx:0,vy:0,r:Math.random(),z:Math.random(),g:i%G,a:Math.random()*6.28,ph:Math.random()*9});
    m.PB=P;
    function lerp(a,b,u){return [a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u,a[2]+(b[2]-a[2])*u];}
    m.over=function(m,c,dt,tk){o3(m,c,dt,tk);var P=m.PB,n=Math.max(6,Math.round(P.length*Math.min(1,CFGX.den))),t=m.t,lv=S.lv,k=Math.min(1,S.k),b=Math.min(1,S.b+lv.bass*.4),tx=m.t3x,i,p,pal=cfg.pal;
      /* subdivision : par moments, et au kick ; fusion lente ensuite */
      m.nextS-=dt;if(m.nextS<=0){m.spT=m.spT>.5?0:1;m.nextS=cfg.hold*(.6+Math.random()*.9);}
      if(S.on.k){m.spK=Math.min(1,m.spK+.55);}m.spK*=Math.exp(-dt/(cfg.hold*.35));
      var tgt=Math.min(1,m.spT*.9+m.spK*.7);m.sp+=(tgt-m.sp)*Math.min(1,dt*cfg.rate);
      var bn=S.bn||0,cx=W/2+Math.sin(t*.27)*95+Math.sin(t*.61)*28,cy=Hh*(.66-.03*bn)+Math.sin(t*.8)*3,j,C=[];
      for(j=0;j<G;j++){var aj=j*6.2832/G+t*.17+(G===2?0:.6),spread=m.sp*(62+38*nz(j*7.1,t*.18,3)),X=cx+Math.cos(aj)*spread,Y=cy+Math.sin(aj)*m.sp*13*(.6+nz(j*3.3,t*.22,9));
        C.push([Math.max(RIM+16,Math.min(W-RIM-16,X)),Math.max(RIM+12,Math.min(Hh-RIM-10,Y))]);}
      tx.globalCompositeOperation='destination-out';tx.fillStyle='rgba(0,0,0,'+cfg.fade+')';tx.fillRect(0,0,W,Hh);tx.globalCompositeOperation='lighter';tx.lineCap='round';
      /* RENCONTRE : densités des deux nuées sur une grille, réaction croisée */
      var it=cfg.inter,GX=30,GY=7,CW2=12,gc=m.gcu||(m.gcu=new Float32Array(GX*GY)),gr=m.grd||(m.grd=new Float32Array(GX*GY)),Bq=m.B,q,ci,sw0=0;
      function gi(x,y){return Math.max(0,Math.min(GY-1,y/CW2|0))*GX+Math.max(0,Math.min(GX-1,x/CW2|0));}
      function gd(g,x,y,dx,dy){var a=g[gi(x+dx,y+dy)],c0=g[gi(x-dx,y-dy)];return a-c0;}
      if(it){gc.fill(0);gr.fill(0);for(i=0;i<n;i++)gc[gi(P[i].x,P[i].y)]++;for(i=0;i<Bq.length;i++)if(!Bq[i].h)gr[gi(Bq[i].x,Bq[i].y)]++;
        if(!m.sk)m.sk=[];
        for(i=0;i<Bq.length;i++){q=Bq[i];if(q.h)continue;ci=gi(q.x,q.y);var dc=Math.min(1,gc[ci]/7);if(dc<.04)continue;
          var gx_=gd(gc,q.x,q.y,CW2,0),gy_=gd(gc,q.x,q.y,0,CW2),gl=Math.hypot(gx_,gy_)+1;
          q.vx+=(-gx_/gl*it.rep+(-gy_/gl)*it.swirl*(q.ph>4.5?-1:1))*dc*dt*60;q.vy+=(-gy_/gl*it.rep*.6+(gx_/gl)*it.swirl*(q.ph>4.5?-1:1))*dc*dt*60;}
        /* contacts → étincelles (cellules où les deux nuées se recouvrent) */
        for(ci=0;ci<GX*GY;ci++){var ct=Math.min(1,gc[ci]/6)*Math.min(1,gr[ci]/4);if(ct>.25&&Math.random()<dt*ct*it.spark&&m.sk.length<40)m.sk.push({x:(ci%GX+Math.random())*CW2,y:((ci/GX|0)+Math.random())*CW2,l:0,L:.5+Math.random()*.6,s:ct});}
        if(S.on.k&&it.shock){for(ci=0;ci<GX*GY;ci++){if(gc[ci]>2&&gr[ci]>1.5&&m.sk.length<40)m.sk.push({x:(ci%GX+.5)*CW2,y:((ci/GX|0)+.5)*CW2,l:0,L:.8,s:1,big:1});}}}
      var R=11+24*(b+k*.7);
      for(i=0;i<n;i++){p=P[i];if(Math.random()<dt*.35)p.g=(Math.random()*G)|0;   /* des particules passent d'un groupe à l'autre */
        var Cg=C[p.g],ang=p.a+t*(.3+b*.9)*(p.r<.5?1:-1),tx_=Cg[0]+Math.cos(ang)*R*(.25+p.r)*2.1,ty_=Cg[1]+Math.sin(ang)*R*(.25+p.r)*.75-5*b*p.z;
        var kk=cfg.k*(1+.8*k);p.vx+=(tx_-p.x)*kk*dt;p.vy+=(ty_-p.y)*kk*dt;
        var fa=nz(p.x*.035+p.ph,p.y*.05,t*.35)*12.56,fl=(10+22*m.sp)*(.6+b);p.vx+=Math.cos(fa)*fl*dt;p.vy+=Math.sin(fa)*fl*dt;
        var rd=0;if(it){ci=gi(p.x,p.y);rd=Math.min(1,gr[ci]/5);if(rd>.04){var rx=gd(gr,p.x,p.y,CW2,0),ry=gd(gr,p.x,p.y,0,CW2),rl=Math.hypot(rx,ry)+1;p.vx+=(-rx/rl*it.rep*.8+(-ry/rl)*it.swirl)*rd*dt*60;p.vy+=(-ry/rl*it.rep*.5+(rx/rl)*it.swirl)*rd*dt*60;}}
        p.rd=rd;
        var dm=Math.exp(-dt*cfg.damp);p.vx*=dm;p.vy*=dm;p.ox=p.x;p.oy=p.y;p.x+=p.vx*dt;p.y+=p.vy*dt;
        if(p.x<RIM+1){p.x=RIM+1;p.vx*=-.4;}if(p.x>W-RIM-1){p.x=W-RIM-1;p.vx*=-.4;}if(p.y<RIM+1){p.y=RIM+1;p.vy*=-.4;}if(p.y>Hh-RIM-1){p.y=Hh-RIM-1;p.vy*=-.4;}
        /* couleur : trois profondeurs + un reflet d'accent qui varie dans l'espace */
        var z=p.z,col=z<.5?lerp(pal.deep,pal.mid,z*2):lerp(pal.mid,pal.hi,(z-.5)*2),nv=nz(p.x*.03,p.y*.06,t*.25);if(nv>.62)col=lerp(col,pal.acc,Math.min(1,(nv-.62)*2.6)*.7);
        if(it&&p.rd>.05)col=lerp(col,it.tint,Math.min(1,p.rd*it.tm));
        var al=(z<.3?.13:.07+.2*z)*(.5+.35*b+.2*k)*(1+(it?p.rd*it.glow:0));
        tx.strokeStyle='rgba('+(col[0]|0)+','+(col[1]|0)+','+(col[2]|0)+','+al+')';tx.lineWidth=z<.3?1.7:.55+.5*z+.4*k;tx.beginPath();tx.moveTo(p.ox,p.oy);tx.lineTo(p.x,p.y+.01);tx.stroke();}
      tx.globalCompositeOperation='source-over';
      m.g3x.globalCompositeOperation='copy';m.g3x.drawImage(m.t3,0,0,GW,GH);c.globalCompositeOperation='lighter';c.globalAlpha=.5;c.drawImage(m.g3,0,0,W,Hh);c.globalAlpha=.8;c.drawImage(m.t3,0,0,W,Hh);c.globalAlpha=1;
      c.fillStyle='rgba('+pal.hi[0]+','+pal.hi[1]+','+pal.hi[2]+',.28)';for(i=0;i<n;i+=3){p=P[i];if(p.z>.6)c.fillRect(p.x-.45,p.y-.45,.9,.9);}if(it&&m.sk){var sk=m.sk,sj;for(sj=sk.length-1;sj>=0;sj--){var s_=sk[sj];s_.l+=dt;if(s_.l>=s_.L){sk.splice(sj,1);continue;}var u=s_.l/s_.L,a_=(1-u)*(1-u);
          c.strokeStyle='rgba('+it.sp+','+(a_*.5*s_.s)+')';c.lineWidth=.6;c.beginPath();c.arc(s_.x,s_.y,2+u*(s_.big?22:9),0,6.2832);c.stroke();
          c.fillStyle='rgba('+it.sp+','+(a_*.8)+')';c.fillRect(s_.x-.8,s_.y-.8,1.6,1.6);}}
      c.globalCompositeOperation='source-over';};};}


  /* ---- R417 : nouveaux rendus — constellation et cellules (superposés au fond de nuée, comme les autres) ---- */
  function pushT(p,dt){if(TCH.on){var dx=p.x-TCH.x,dy=p.y-TCH.y,d=Math.hypot(dx,dy)+.01;if(d<TCH.r){var f=(1-d/TCH.r)*TCH.f*dt;p.vx+=dx/d*f;p.vy+=dy/d*f;}}}
  function mkConst(){return function(m){initA(m);var N=60,P=[],i;for(i=0;i<N;i++)P.push({x:X0+Math.random()*(X1-X0),y:RIM+8+Math.random()*(Hh-2*RIM-16),vx:(Math.random()-.5)*14,vy:(Math.random()-.5)*8,ph:Math.random()*9,p:0});
    m.CP=P;m.pulses=[];
    m.over=function(m,c,dt,tk){var P=m.CP,n=Math.max(6,Math.min(P.length,Math.round(30*CFGX.den))),lv=S.lv,hi=Math.min(1,lv.high+S.h*.5),mid=Math.min(1,lv.mid+S.p*.4),t=m.t,i,j,p,q,D=(70+34*mid)*CFGX.sze,PL=m.pulses;
      if(S.on.k){var a=P[(Math.random()*n)|0];PL.push({x:a.x,y:a.y,r:0,a:1});a.p=1;}
      if(S.on.s){var b=P[(Math.random()*n)|0];b.p=1;}
      for(i=0;i<n;i++){p=P[i];var ang=nz(p.x*.02+p.ph,p.y*.03,t*.25)*12.56;p.vx+=Math.cos(ang)*9*dt*(1+3*mid)*CFGX.trb;p.vy+=Math.sin(ang)*5*dt*(1+3*mid)*CFGX.trb;p.vx*=Math.exp(-dt*.5);p.vy*=Math.exp(-dt*.5);pushT(p,dt);
        p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<X0){p.x=X0;p.vx=Math.abs(p.vx);}if(p.x>X1){p.x=X1;p.vx=-Math.abs(p.vx);}if(p.y<RIM+6){p.y=RIM+6;p.vy=Math.abs(p.vy);}if(p.y>Hh-RIM-6){p.y=Hh-RIM-6;p.vy=-Math.abs(p.vy);}p.p*=Math.exp(-dt/.35);}
      c.globalCompositeOperation='lighter';c.lineCap='round';
      for(i=0;i<n;i++){p=P[i];for(j=i+1;j<n;j++){q=P[j];var dx=q.x-p.x,dy=q.y-p.y,d=dx*dx+dy*dy;if(d>D*D)continue;d=Math.sqrt(d);var u=1-d/D,al=u*(.18+.5*hi+.4*Math.max(p.p,q.p));c.strokeStyle='rgba(150,205,255,'+al+')';c.lineWidth=.5+.9*u*(.4+hi);c.beginPath();c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);c.stroke();}}
      for(i=PL.length-1;i>=0;i--){var o=PL[i];o.r+=dt*210;o.a-=dt*1.6;if(o.a<=0){PL.splice(i,1);continue;}c.strokeStyle='rgba(190,230,255,'+o.a*.55+')';c.lineWidth=1;c.beginPath();c.arc(o.x,o.y,o.r,0,6.2832);c.stroke();}
      for(i=0;i<n;i++){p=P[i];var r=(1.1+1.4*mid+2.6*p.p)*CFGX.sze;c.fillStyle='rgba(215,238,255,'+(.55+.4*p.p)+')';c.beginPath();c.arc(p.x,p.y,r,0,6.2832);c.fill();if(p.p>.1){c.fillStyle='rgba(120,190,255,'+p.p*.25+')';c.beginPath();c.arc(p.x,p.y,r*4,0,6.2832);c.fill();}}
      c.globalCompositeOperation='source-over';};};}
  function mkCells(){return function(m){initA(m);var N=30,P=[],i;for(i=0;i<N;i++)P.push({x:X0+20+Math.random()*(X1-X0-40),y:Hh*.2+Math.random()*Hh*.6,vx:(Math.random()-.5)*12,vy:(Math.random()-.5)*8,r:9+Math.random()*9,k:0,ph:Math.random()*9,h:Math.random()<.5?168:38});
    m.CE=P;
    m.over=function(m,c,dt,tk){var P=m.CE,n=Math.max(4,Math.min(P.length,Math.round(15*CFGX.den))),lv=S.lv,hi=Math.min(1,lv.high+S.h*.5),mid=Math.min(1,lv.mid+S.p*.4),t=m.t,i,j,p,q;
      if(S.on.k)for(i=0;i<n;i++)P[i].k=Math.max(P[i].k,.6+Math.random()*.4);
      for(i=0;i<n;i++){p=P[i];var ang=nz(p.x*.02+p.ph,p.y*.03,t*.2)*12.56;p.vx+=Math.cos(ang)*8*dt*CFGX.trb;p.vy+=Math.sin(ang)*5*dt*CFGX.trb;
        for(j=i+1;j<n;j++){q=P[j];var dx=q.x-p.x,dy=q.y-p.y,d=Math.hypot(dx,dy)+.01,mn=(p.r+q.r)*.8;if(d<mn){var f=(mn-d)*3*dt;p.vx-=dx/d*f*10;p.vy-=dy/d*f*10;q.vx+=dx/d*f*10;q.vy+=dy/d*f*10;}}
        pushT(p,dt);p.vx*=Math.exp(-dt*.6);p.vy*=Math.exp(-dt*.6);p.x+=p.vx*dt;p.y+=p.vy*dt;
        if(p.x<X0+p.r){p.x=X0+p.r;p.vx=Math.abs(p.vx);}if(p.x>X1-p.r){p.x=X1-p.r;p.vx=-Math.abs(p.vx);}if(p.y<RIM+p.r*.6){p.y=RIM+p.r*.6;p.vy=Math.abs(p.vy);}if(p.y>Hh-RIM-p.r*.6){p.y=Hh-RIM-p.r*.6;p.vy=-Math.abs(p.vy);}p.k*=Math.exp(-dt/.3);}
      c.globalCompositeOperation='lighter';
      for(i=0;i<n;i++){p=P[i];var rr=p.r*CFGX.sze*(1+.12*Math.sin(t*1.7+p.ph)+.35*p.k+.18*mid),cl=p.h===168?'110,226,206':'255,184,96';
        var g=c.createRadialGradient(p.x,p.y,rr*.2,p.x,p.y,rr);g.addColorStop(0,'rgba('+cl+',.05)');g.addColorStop(1,'rgba('+cl+','+(.16+.12*p.k)+')');c.fillStyle=g;c.beginPath();c.arc(p.x,p.y,rr,0,6.2832);c.fill();
        c.strokeStyle='rgba('+cl+','+(.55+.4*p.k)+')';c.lineWidth=.8+.8*p.k;c.beginPath();c.arc(p.x,p.y,rr,0,6.2832);c.stroke();
        var nx=p.x+Math.cos(t*.9+p.ph)*rr*.35,ny=p.y+Math.sin(t*1.1+p.ph)*rr*.35;c.fillStyle='rgba('+cl+','+(.5+.4*hi)+')';c.beginPath();c.arc(nx,ny,1+rr*.12,0,6.2832);c.fill();}
      c.globalCompositeOperation='source-over';};};}
  var LOOKS={sig:function(){return mkHoule(CFG);},nuee:null,houle:null,const:null,cells:null,fluide:null},PLOOK={nuee:1,houle:1,const:1,cells:1,fluide:1},RD='sig';try{var _w=JSON.parse(localStorage.getItem('qx.wset')||'{}');if(_w&&_w.rd&&(_w.rd in LOOKS))RD=_w.rd;if(_w){['den','sze','trb'].forEach(function(k){if(typeof _w[k]==='number')CFGX[k]=_w[k]/100;});}}catch(e){}
  /* ═══ R422 : portage fidèle de l'aperçu wave-proto2 — Nuées, Houle, Constellation (canvas) ; Cellules, Fluide (WebGL, shader de l'aperçu) ═══ */
  var PS={pop:260,den:55,swm:2,spd:50,scl:50,trb:50,glw:55,q:'auto'};
  var PW={pf:1,cost:0,P:[],sp:{},gl:null,glc:null,prog:null,U:{},ok:null,pd:0,a:0,sc:.6,acc:0,nf:0,fps:0,mode:''};
  var CCP=[[90,44,28],[200,116,74],[246,210,160]];
  function pcol(i,a){var c=i%3===0?CCP[1]:i%3===1?CCP[2]:[(CCP[1][0]+CCP[2][0])/2,(CCP[1][1]+CCP[2][1])/2,(CCP[1][2]+CCP[2][2])/2];return 'rgba('+(c[0]|0)+','+(c[1]|0)+','+(c[2]|0)+','+a+')';}
  function psprite(i,r){var k=i+'_'+r;if(PW.sp[k])return PW.sp[k];var c=CCP[i],e=document.createElement('canvas');e.width=e.height=r*2;var x=e.getContext('2d'),g=x.createRadialGradient(r,r,0,r,r,r);
    g.addColorStop(0,'rgba('+c[0]+','+c[1]+','+c[2]+',1)');g.addColorStop(.35,'rgba('+c[0]+','+c[1]+','+c[2]+',.38)');g.addColorStop(1,'rgba('+c[0]+','+c[1]+','+c[2]+',0)');x.fillStyle=g;x.fillRect(0,0,r*2,r*2);return PW.sp[k]=e;}
  function pband(i){var lv=S.lv,e=i<4?lv.bass:i<8?lv.mid:lv.high;return Math.min(1,.22+e*.95);}
  function pFit(){var cap=PS.q==='low'?140:900,n=Math.max(40,Math.round(Math.min(PS.pop,cap)*PW.pf));while(PW.P.length<n)PW.P.push({x:Math.random()*W,y:Math.random()*Hh,vx:0,vy:0,s:PW.P.length%6,ph:Math.random()*6.28});PW.P.length=n;}
  function pStep(dt){if(dt>.05){pStep1(dt/2);pStep1(dt/2);}else pStep1(dt);}
  function pStep1(dt){var P=PW.P,t=PW.a,nS=Math.max(1,PS.swm|0),spread=(1.15-PS.den/100*.95),R=Math.max(70,Math.min(W,Hh)*.36)*(.6+TCH.r/90),force=TCH.f/1400*1.4,sv=.4+PS.spd/50*.6,on=TCH.on,i;
    for(i=0;i<P.length;i++){var p=P[i],s=p.s%nS,ccx=W*(.5+.36*Math.sin(t*.23*(1+s*.31)+s*2.1)),ccy=Hh*(.5+.3*Math.sin(t*.31*(1+s*.23)+s*1.7)),dx=ccx-p.x,dy=ccy-p.y,d=Math.hypot(dx,dy)+.01,rad=Math.min(W,Hh)*.45*spread*(.4+.6*Math.abs(Math.sin(p.ph+i))),k=(d-rad)*.0009;
      p.vx+=dx/d*k*60*dt+(-dy/d)*dt*60*.12*(.5+.5*Math.sin(p.ph))*sv;p.vy+=dy/d*k*60*dt+(dx/d)*dt*60*.12*(.5+.5*Math.sin(p.ph))*sv;
      p.vx+=(Math.random()-.5)*.08;p.vy+=(Math.random()-.5)*.08;
      if(on){var qx=p.x-TCH.x,qy=p.y-TCH.y,qd=Math.hypot(qx,qy)+.01;if(qd<R){var f=Math.pow(1-qd/R,2);p.vx+=qx/qd*f*force*2.4;p.vy+=qy/qd*f*force*2.4;p.vx+=-qy/qd*f*.5;p.vy+=qx/qd*f*.5;}}
      p.vx*=.955;p.vy*=.955;var sp=Math.hypot(p.vx,p.vy);if(sp>6){p.vx*=6/sp;p.vy*=6/sp;}
      p.x+=p.vx*60*dt*.5;p.y+=p.vy*60*dt*.5;
      if(p.x<0){p.x=0;p.vx=Math.abs(p.vx);}if(p.x>W){p.x=W;p.vx=-Math.abs(p.vx);}if(p.y<0){p.y=0;p.vy=Math.abs(p.vy);}if(p.y>Hh){p.y=Hh;p.vy=-Math.abs(p.vy);}}}
  var VSP='attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var FSP='#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n'+
'uniform vec2 uRes,uP;uniform float uT,uMode,uA,uB,uC,uScale,uSpd,uTurb,uGlow,uPD;uniform vec3 c0,c1,c2;\n'+
'float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}\n'+
'vec2 h22(vec2 p){float n=h21(p);return vec2(n,h21(p+n+17.1));}\n'+
'float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x),mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x),f.y);}\n'+
'float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*vn(p);p=p*2.03+vec2(11.7,3.1);a*=.5;}return s;}\n'+
'vec3 vor(vec2 p,float t){vec2 i=floor(p),f=fract(p);float d1=9.,d2=9.,id=0.;for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 g=vec2(float(x),float(y));vec2 o=h22(i+g);o=.5+.5*sin(t+6.2831*o);vec2 r=g+o-f;float d=dot(r,r);if(d<d1){d2=d1;d1=d;id=h21(i+g);}else if(d<d2)d2=d;}return vec3(sqrt(d1),sqrt(d2),id);}\n'+
'void main(){vec2 uv=(gl_FragCoord.xy-.5*uRes)/uRes.y;vec2 pp=(uP-.5*uRes)/uRes.y;float t=uT*uSpd;vec2 d=uv-pp;float dl=length(d);float rep=uPD*exp(-dl*dl*8.);vec2 w=uv+d/(dl+.001)*rep*.22;vec3 col;\n'+
'if(uMode<.5){vec2 p=w*uScale;p+=uTurb*.55*vec2(fbm(p*.7+t*.15),fbm(p*.7-t*.12+5.));vec3 v=vor(p*(1.+uA*.12),t*.5);float edge=v.y-v.x;float mem=1.-smoothstep(0.,.16+.05*uB,edge);float core=1.-smoothstep(0.,.045,edge);float tex=fbm(p*6.+t*.2);float inner=smoothstep(0.,.8,v.x)*(.35+.65*tex);\n'+
' col=mix(c0*.4,c0,inner*(.5+.5*v.z))+mem*mix(c1,c2,core)*(.55+.7*uGlow+uA*.7)*(.55+.45*tex)+c2*core*.5*uGlow+c1*rep*.35*(.5+uC);}\n'+
'else{vec2 q0=w-pp;float ang=rep*2.2;float cs=cos(ang),sn=sin(ang);vec2 p=(vec2(cs*q0.x-sn*q0.y,sn*q0.x+cs*q0.y)+pp)*uScale;vec2 q=vec2(fbm(p+vec2(0.,t*.12)),fbm(p+vec2(5.2,1.3)-t*.1));vec2 r=vec2(fbm(p+3.*uTurb*q+vec2(1.7,9.2)+t*.15),fbm(p+3.*uTurb*q+vec2(8.3,2.8)-t*.126));float f=fbm(p+3.*uTurb*r+uA*.4);\n'+
' col=mix(c0*.2,c0*.9,smoothstep(.25,.7,f));col=mix(col,c1,smoothstep(.42,.85,f)*.85);col=mix(col,c2,smoothstep(.68,1.,f+r.y*.3)*(.35+uGlow*.5));col*=.5+.8*f+uA*.3;col+=c2*rep*.1;}\n'+
'col*=.55+.45*smoothstep(1.5,.25,length(uv));gl_FragColor=vec4(col,1.);}';
  function pInitGL(){if(PW.ok!==null)return PW.ok;var c=document.createElement('canvas');c.width=c.height=16;var gl=null;try{gl=c.getContext('webgl',{antialias:false,alpha:false,powerPreference:'low-power',preserveDrawingBuffer:false});}catch(e){}
    if(!gl){PW.ok=false;return false;}
    function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return gl.getShaderParameter(o,gl.COMPILE_STATUS)?o:null;}
    var v=sh(gl.VERTEX_SHADER,VSP),f=sh(gl.FRAGMENT_SHADER,FSP);if(!v||!f){PW.ok=false;return false;}
    var pr=gl.createProgram();gl.attachShader(pr,v);gl.attachShader(pr,f);gl.linkProgram(pr);if(!gl.getProgramParameter(pr,gl.LINK_STATUS)){PW.ok=false;return false;}
    gl.useProgram(pr);var b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);var l=gl.getAttribLocation(pr,'a');gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,2,gl.FLOAT,false,0,0);
    ['uRes','uP','uT','uMode','uA','uB','uC','uScale','uSpd','uTurb','uGlow','uPD','c0','c1','c2'].forEach(function(n){PW.U[n]=gl.getUniformLocation(pr,n);});
    PW.gl=gl;PW.glc=c;PW.ok=true;return true;}
  function pGLSize(w,h){var c=PW.glc,sc=PS.q==='low'?.4:PS.q==='max'?1:PW.sc,ww=Math.max(32,Math.round(w*sc)),hh=Math.max(32,Math.round(h*sc));if(Math.abs(ww-c.width)/c.width>.12||Math.abs(hh-c.height)/c.height>.12||c.width===16){c.width=ww;c.height=hh;}}
  function pDrawGL(c2,dt,mode,pw,ph){var gl=PW.gl,U=PW.U;pGLSize(pw,ph);var c=PW.glc,k=c.width/W;gl.viewport(0,0,c.width,c.height);
    var a=pband(2),b=pband(6),h=pband(11);PW.pd+=((TCH.on?1:0)-PW.pd)*Math.min(1,dt*9);
    gl.uniform2f(U.uRes,c.width,c.height);gl.uniform2f(U.uP,TCH.x*k,(Hh-TCH.y)*k);gl.uniform1f(U.uT,PW.a);gl.uniform1f(U.uMode,mode==='cells'?0:1);gl.uniform1f(U.uA,a);gl.uniform1f(U.uB,b);gl.uniform1f(U.uC,h);
    gl.uniform1f(U.uScale,mode==='cells'?9-PS.scl/100*7:3.2-PS.scl/100*2.2);gl.uniform1f(U.uSpd,.15+PS.spd/100*1.6);gl.uniform1f(U.uTurb,.25+PS.trb/100*1.3);gl.uniform1f(U.uGlow,PS.glw/100*1.3);gl.uniform1f(U.uPD,PW.pd);
    CCP.forEach(function(cc,i){gl.uniform3f(U['c'+i],cc[0]/255,cc[1]/255,cc[2]/255);});gl.drawArrays(gl.TRIANGLES,0,3);
    c2.globalCompositeOperation='source-over';c2.drawImage(c,0,0,W,Hh);}
  function pDraw(c,dt,mode,pw,ph){var t0_=performance.now();pDraw1(c,dt,mode,pw,ph);var ms=performance.now()-t0_;PW.cost=PW.cost*.9+ms*.1;if(PS.q==='auto'){if(PW.cost>9)PW.pf=Math.max(.35,PW.pf*.97);else if(PW.cost<4)PW.pf=Math.min(1,PW.pf*1.01);}else PW.pf=1;}
  function pDraw1(c,dt,mode,pw,ph){
    PW.a+=dt;PW.acc+=dt;PW.nf++;if(PW.nf>=60){var avg=PW.acc/PW.nf*1000;PW.fps=Math.round(1000/Math.max(1,avg));if(PS.q==='auto'&&PW.ok){if(avg>24)PW.sc=Math.max(.3,PW.sc*.85);else if(avg<13)PW.sc=Math.min(.8,PW.sc*1.08);}PW.acc=0;PW.nf=0;}
    if(PW.mode!==mode){PW.mode=mode;c.fillStyle='#05080f';c.fillRect(0,0,W,Hh);}
    if(mode==='cells'||mode==='fluide'){if(pInitGL()){pDrawGL(c,dt,mode,pw,ph);return;}}
    pFit();
    if(mode==='nuee'){pStep(dt);c.fillStyle='rgba(5,8,15,.2)';c.fillRect(0,0,W,Hh);c.globalCompositeOperation='lighter';var s1=psprite(1,9),s2=psprite(2,7),P=PW.P,i;
      for(i=0;i<P.length;i++){var p=P[i];c.globalAlpha=.5;c.fillStyle=pcol(p.s,1);c.fillRect(p.x-.9,p.y-.9,1.8,1.8);if(i%6===0){c.globalAlpha=.55;c.drawImage(i%12===0?s2:s1,p.x-9,p.y-9,18,18);}}c.globalAlpha=1;c.globalCompositeOperation='source-over';}
    else if(mode==='houle'){c.fillStyle='rgba(5,8,15,.4)';c.fillRect(0,0,W,Hh);c.globalCompositeOperation='lighter';var amp=.06+PS.den/100*.2,sv=.4+PS.spd/50*.6,gl2=.5+PS.glw/100,t=PW.a,L,x;
      for(L=0;L<5;L++){var pts=[];for(x=0;x<=W;x+=6){var u=x/W,fu=u*10,fi=Math.floor(fu),ff=fu-fi,e=pband(fi)*(1-ff)+pband(fi+1)*ff,y=Hh*(.5+(L-2)*.07)+Math.sin(u*(6+L)+t*sv*(1+L*.3))*Hh*amp*(.4+e)+Math.sin(u*17-t*sv*2.1+L)*Hh*.03;
        if(TCH.on){var dd=Math.abs(x-TCH.x),dy=y-TCH.y,g2=Math.exp(-dd*dd/(2*900));y+=dy/(Math.abs(dy)+20)*g2*(TCH.r*.9)*Math.exp(-Math.abs(dy)/90);}pts.push([x,y]);}
        [[6,.07],[2.4,.16],[1,.55]].forEach(function(sl){c.strokeStyle=pcol(L%2?1:0,sl[1]*gl2*(.7+L*.1));c.lineWidth=sl[0];c.beginPath();pts.forEach(function(q,i){i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();});}
      c.globalCompositeOperation='source-over';}
    else{pStep(dt);c.fillStyle='rgba(5,8,15,.5)';c.fillRect(0,0,W,Hh);c.globalCompositeOperation='lighter';var D=50+PS.den*.8,D2=D*D,P2=PW.P,i2,j,B=[[],[],[]];
      c.fillStyle=pcol(1,.85);for(i2=0;i2<P2.length;i2++){var q=P2[i2];c.fillRect(q.x-1,q.y-1,2.4,2.4);
        for(j=i2+1;j<Math.min(P2.length,i2+10);j++){var r=P2[j],dx=q.x-r.x,dy=q.y-r.y,d2=dx*dx+dy*dy;if(d2<D2){B[d2<D2*.25?0:d2<D2*.6?1:2].push(q.x,q.y,r.x,r.y);}}}
      var AL=[.3,.17,.07],bi,k2;c.lineWidth=.8;for(bi=0;bi<3;bi++){var L2=B[bi];if(!L2.length)continue;c.strokeStyle=pcol(1,AL[bi]);c.beginPath();for(k2=0;k2<L2.length;k2+=4){c.moveTo(L2[k2],L2[k2+1]);c.lineTo(L2[k2+2],L2[k2+3]);}c.stroke();}
      c.globalCompositeOperation='source-over';}}
var CFG={G:2,hold:7,rate:.55,k:7,damp:2.6,fade:.055,pal:{deep:[92,38,34],mid:[192,100,68],hi:[242,172,118],acc:[66,138,148]},inter:{rep:55,swirl:70,tint:[96,170,160],tm:.7,glow:1.1,spark:0,shock:0,sp:'160,222,206'}};
var M=null,off=null,fd=null,pv={b:0,m:0,h:0},cd={k:0,s:0,h:0};
function band(an,lo,hi){var sr=(an.context&&an.context.sampleRate)||44100,bw=sr/an.fftSize,a=Math.max(1,Math.round(lo/bw)),z=Math.min(fd.length-1,Math.round(hi/bw)),i,t=0;for(i=a;i<=z;i++)t+=fd[i];return t/Math.max(1,z-a+1)/255;}
function norm(v){return Math.max(0,Math.min(1,(v-.28)/.5));}
function feed(an,dt){var b=0,m=0,h=0,e=Math.exp;
 if(an){if(!fd||fd.length!==an.frequencyBinCount)fd=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(fd);b=norm(band(an,30,160));m=norm(band(an,160,2000));h=norm(band(an,2000,12000));}
 S.on.k=S.on.s=S.on.h=0;cd.k-=dt;cd.s-=dt;cd.h-=dt;
 if(b-pv.b>.1&&b>.3&&cd.k<=0){S.on.k=1;S.k=1;cd.k=.11;}
 if(m-pv.m>.1&&m>.3&&cd.s<=0){S.on.s=1;S.s=1;cd.s=.09;}
 if(h-pv.h>.1&&h>.25&&cd.h<=0){S.on.h=1;S.h=1;cd.h=.06;}
 pv.b=b;pv.m=m;pv.h=h;
 S.k*=e(-dt/.16);S.s*=e(-dt/.14);S.h*=e(-dt/.08);S.b=b*.7;S.p=m*.6;
 S.lv.bass=Math.min(1,S.k+S.b*.45);S.lv.high=Math.min(1,S.h*.9+S.s*.75+h*.3);S.lv.mid=Math.min(1,S.s*.5+S.b*.6+S.p*.7);}
var FC={n:0,t:performance.now(),f:0,c:0};
window.QWV={T:TCH,spd:1,cfg:function(k,v){if(k in CFGX)CFGX[k]=v;},look:function(id){if(id in LOOKS)RD=id;},ps:function(k,v){if(k in PS)PS[k]=v;},fps:function(){return FC.f;},minEvery:function(){return PS.q==='low'?32:0;},cost:function(){return FC.c;},pf:function(){return PW.pf;},sc:function(){return PS.q==='low'?.4:PS.q==='max'?1:PW.sc;},lv:function(){return Math.min(1,Math.max(S.lv.bass,S.lv.mid,S.lv.high));},gl:function(){return PW.ok;},looks:function(){return Object.keys(LOOKS);},H:function(){return Hh;},W:W,draw:function(c,w,h,dt,tk,sp,an){dt*=(window.QWV.spd||1);var tn=performance.now();FC.n++;if(tn-FC.t>=1000){FC.f=Math.round(FC.n*1000/(tn-FC.t));FC.n=0;FC.t=tn;}
 var th=Math.max(60,Math.min(520,Math.round(W*h/w)));if(!M||Math.abs(th-Hh)>3){Hh=th;DH=Math.max(8,Math.round(Hh/4));GH=Math.max(8,Math.round(Hh/3));off=lowCanvas(W*2,Hh*2);M={c:off.getContext('2d')};initA(M);M.rd=RD;if(!PLOOK[RD])LOOKS[RD]()(M);}
 if(M.rd!==RD){var oc=M.c;M={c:oc};initA(M);M.rd=RD;if(!PLOOK[RD])LOOKS[RD]()(M);}
 SP=sp;S.t=tk;S.tick=tk;feed(an,dt);if(PLOOK[RD]){var oc2=M.c;oc2.setTransform(2,0,0,2,0,0);pDraw(oc2,Math.min(dt,.12),RD,w,h);oc2.setTransform(1,0,0,1,0,0);}else drawA(M,dt,tk);
 c.setTransform(1,0,0,1,0,0);c.globalCompositeOperation='source-over';c.globalAlpha=1;c.imageSmoothingEnabled=true;c.drawImage(off,0,0,w,h);FC.c=FC.c*.9+(performance.now()-tn)*.1;}};
})();
