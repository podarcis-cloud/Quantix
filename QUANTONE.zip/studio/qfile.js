/* QUANTONE — menu Fichier commun à Pattern et Track (R404).
   Un seul composant : mêmes sections, libellés FR/EN, icônes, ordre et hauteur dans les deux pages.
   Règle affichée : Enregistrer = garder dans Quantone (bibliothèque) ; Exporter = créer un fichier sur l'appareil.
   La page fournit ses actions : QFILE.mount({kind:'p'|'t', btn, ctx, save, copy, lib, neu, open, file, audio, np, seg, fmt, est}). */
(function(){
'use strict';
var I={
 save:'<svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/></svg>',
 copy:'<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>',
 lib:'<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg>',
 open:'<svg viewBox="0 0 24 24"><path d="M3 7h6l2 2h10v10H3z"/></svg>',
 plus:'<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
 file:'<svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/></svg>',
 wave:'<svg viewBox="0 0 24 24"><path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 11v2"/></svg>',
 pat:'<svg viewBox="0 0 24 24"><path d="M2 12c2.5-8 5.5-8 8 0s5.5 8 8 0 2.5-4 4-4"/></svg>',
 trk:'<svg viewBox="0 0 24 24"><path d="M3 6h9M7 12h12M3 18h7M14 18h7"/></svg>'};
var L={
 fr:{saveH:'Enregistrer',saveE:'dans Quantone',open:'Ouvrir',exp:'Exporter',expE:'fichier sur l’appareil',
  save:{p:'Enregistrer ce pattern',t:'Enregistrer cette track'},saveS:{p:'dans la bibliothèque',t:'dans Quantone'},
  copy:'Enregistrer une copie…',lib:'Bibliothèque…',libS:{p:'patterns, tracks, sons du jeu',t:'patterns, tracks, sons du jeu'},
  neu:{p:'Nouveau pattern',t:'Nouvelle track'},of:'Ouvrir un fichier…',ofS:{p:'.qpt, .qx, .json',t:'.qxp, .qpt, audio'},
  ef:{p:'Fichier pattern .qpt',t:'Fichier track .qxp'},efS:{p:'pour un autre appareil',t:'patterns compris'},snd:'avec le son',
  audio:'Audio',go:'Exporter l’audio',auto:'Brouillon gardé automatiquement',np:'Nouveau projet…',conf:'Confirmer ?',
  ctx:{p:'Pattern',t:'Track'},untitled:'sans nom',proj:'projet',
  st:{ok:'Enregistré',dirty:'Modifié · pas encore enregistré','new':'Pas encore enregistré'},ago:function(m){return m<1?'à l’instant':m<60?'il y a '+m+' min':m<1440?'il y a '+Math.floor(m/60)+' h':'il y a '+Math.floor(m/1440)+' j';},
  name:'Nom',ok:'OK',cancel:'Annuler'},
 en:{saveH:'Save',saveE:'in Quantone',open:'Open',exp:'Export',expE:'file on this device',
  save:{p:'Save this pattern',t:'Save this track'},saveS:{p:'to the library',t:'in Quantone'},
  copy:'Save a copy…',lib:'Library…',libS:{p:'patterns, tracks, game sounds',t:'patterns, tracks, game sounds'},
  neu:{p:'New pattern',t:'New track'},of:'Open a file…',ofS:{p:'.qpt, .qx, .json',t:'.qxp, .qpt, audio'},
  ef:{p:'Pattern file .qpt',t:'Track file .qxp'},efS:{p:'for another device',t:'patterns included'},snd:'with sound',
  audio:'Audio',go:'Export audio',auto:'Draft kept automatically',np:'New project…',conf:'Confirm?',
  ctx:{p:'Pattern',t:'Track'},untitled:'untitled',proj:'project',
  st:{ok:'Saved',dirty:'Changed · not saved yet','new':'Not saved yet'},ago:function(m){return m<1?'just now':m<60?m+' min ago':m<1440?Math.floor(m/60)+' h ago':Math.floor(m/1440)+' d ago';},
  name:'Name',ok:'OK',cancel:'Cancel'}};
function lang(){if(C&&C.lang){var g=C.lang();if(g==='en'||g==='fr')return g;}try{var l=localStorage.getItem('qx.lang');if(l==='en'||l==='fr')return l;}catch(e){}return (navigator.language||'fr').slice(0,2)==='fr'?'fr':'en';}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
var CSS='#qfPanel{position:fixed;left:8px;right:8px;margin:0 auto;max-width:440px;z-index:1000;display:none;box-sizing:border-box;border-radius:22px;background:#08101e;box-shadow:0 0 0 1px #243248,0 22px 44px rgba(0,0,0,.6);padding:10px;gap:8px;color:#e8f1fb;font:15px/1.3 "Space Grotesk","Avenir Next",system-ui,sans-serif;-webkit-text-size-adjust:100%;overflow-x:hidden;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}'+
 '#qfPanel.on{display:grid;animation:qfIn .16s ease-out}@keyframes qfIn{from{opacity:0;transform:translateY(-6px)}}#qfPanel *{box-sizing:border-box}'+
 '#qfPanel button{justify-content:flex-start;box-shadow:none;transform:none;text-transform:none;letter-spacing:normal;outline:none}#qfPanel .seg button,#qfPanel .ask button,#qfPanel .foot button{justify-content:center;display:inline-flex;align-items:center}'+
 '#qfPanel svg{width:20px;height:20px;flex:none;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}'+
 '#qfPanel .ctx{display:flex;align-items:center;gap:10px;padding:4px 6px 0;min-width:0}#qfPanel .ctx .dot{width:30px;height:30px;border-radius:10px;display:grid;place-items:center;background:rgba(110,226,255,.1);color:#6EE2FF;flex:none}'+
 '#qfPanel .ctx>div{min-width:0}#qfPanel .ctx b{display:block;font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#qfPanel .ctx span{display:block;font-size:12px;color:#6b7f99;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#qfPanel .ctx span.ok{color:#7fe0b0}#qfPanel .ctx span.dirty{color:#ffb93b}'+
 '#qfPanel .sec{border-radius:18px;background:rgba(255,255,255,.03);box-shadow:inset 0 0 0 1px rgba(130,180,220,.16);padding:9px 9px 10px;display:grid;gap:7px;min-width:0}'+
 '#qfPanel h5{margin:0 2px;font:600 10px/1.2 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.2em;text-transform:uppercase;color:#8fb8d8}#qfPanel h5 em{font-style:normal;color:#6b7f99;letter-spacing:.04em;text-transform:none;font:500 11px "Space Grotesk",system-ui,sans-serif;margin-left:6px}'+
 '#qfPanel .r2{display:grid;grid-template-columns:1fr 1fr;gap:7px;min-width:0}#qfPanel .r2:not(.fx) button.b{gap:7px;padding:0 8px;height:52px;font-size:13.5px;line-height:1.1}#qfPanel .r2:not(.fx) button.b>div{white-space:normal;max-height:46px}#qfPanel .r2.fx{grid-template-columns:minmax(0,1fr) auto}'+
 '#qfPanel button.b{min-height:44px;width:100%;margin:0;border-radius:14px;border:1px solid #243248;background:rgba(255,255,255,.02);color:#e8f1fb;display:flex;align-items:center;gap:10px;padding:0 11px;font:500 14px/1.2 "Space Grotesk","Avenir Next",system-ui,sans-serif;text-align:left;cursor:pointer;min-width:0;-webkit-tap-highlight-color:transparent}'+
 '#qfPanel button.b>div{min-width:0;overflow:hidden}#qfPanel button.b>div,#qfPanel button.b small{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}#qfPanel button.b svg{color:#8fb8d8}'+
 '#qfPanel button.b.pri{border-color:#6EE2FF;background:linear-gradient(180deg,rgba(110,226,255,.2),rgba(110,226,255,.06));font-weight:650}#qfPanel button.b.pri svg{color:#6EE2FF}'+
 '#qfPanel button.b small{display:block;font-size:11px;color:#6b7f99;font-weight:400}#qfPanel button.b:active{background:rgba(110,226,255,.12)}#qfPanel button.b[disabled]{opacity:.45}'+
 '#qfPanel button.arm{border-color:#FF5A78!important;color:#FFB0BE!important}'+
 '#qfPanel .snd{display:flex;align-items:center;gap:8px;min-height:44px;padding:0 10px;border-radius:14px;border:1px solid #243248;font:500 12px "Space Grotesk",system-ui,sans-serif;color:#8fb8d8;white-space:nowrap;cursor:pointer}#qfPanel .snd input{width:20px;height:20px;margin:0;accent-color:#6EE2FF}#qfPanel .snd.on{border-color:#4DB8FF;color:#e8f1fb}'+
 '#qfPanel .seg{display:grid;gap:6px}#qfPanel .seg button{height:40px;min-width:0;margin:0;padding:0 4px;border-radius:99px;border:1px solid #243248;background:none;color:#8fb8d8;font:600 13px "Space Grotesk",system-ui,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}#qfPanel .seg button.on{border-color:#6EE2FF;color:#e8f1fb;background:rgba(110,226,255,.12)}'+
 '#qfPanel .lab{font:600 9.5px ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.18em;color:#6b7f99;text-transform:uppercase;margin:1px 2px -2px}#qfPanel #xpI{margin:0 2px;font:500 11.5px "Space Grotesk",system-ui,sans-serif;color:#6b7f99;letter-spacing:.02em}'+
 '#qfPanel .foot{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:0 2px 0 6px;font-size:12px;color:#6b7f99;min-width:0}#qfPanel .foot span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}'+
 '#qfPanel .foot button{flex:none;min-height:40px;margin:0;border:1px solid rgba(255,138,122,.35);background:none;color:#FF8A7A;border-radius:99px;padding:0 14px;font:500 12.5px "Space Grotesk",system-ui,sans-serif;white-space:nowrap;cursor:pointer}'+
 '#qfPanel .ask{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:6px}#qfPanel .ask input{min-width:0;height:44px;border-radius:14px;border:1px solid #6EE2FF;background:#0b111b;color:#e8f1fb;padding:0 12px;font:16px "Space Grotesk",system-ui,sans-serif}#qfPanel .ask button{min-height:44px;margin:0;border-radius:14px;border:1px solid #243248;background:rgba(255,255,255,.03);color:#e8f1fb;padding:0 12px;font:600 13px "Space Grotesk",system-ui,sans-serif}#qfPanel .ask button.y{border-color:#6EE2FF}';
var C=null,P=null,TM=0;
function css(){if(document.getElementById('qfCss'))return;var s=document.createElement('style');s.id='qfCss';s.textContent=CSS;document.head.appendChild(s);}
function btn(ic,qf,t,s,cl,id){return '<button type="button" class="b '+(cl||'')+'" data-qf="'+qf+'"'+(id?' id="'+id+'"':'')+'>'+I[ic]+'<div>'+esc(t)+(s?'<small>'+esc(s)+'</small>':'')+'</div></button>';}
function render(){if(!P||!C)return;var lg=lang(),x=L[lg],k=C.kind,seg=C.seg?C.seg():{opts:[],v:null},fmt=C.fmt?C.fmt():'wav';
 P.className=(P.classList.contains('on')?'on ':'')+'qf-'+k;P.setAttribute('lang',lg);
 P.innerHTML='<div class="ctx"><span class="dot">'+I[k==='p'?'pat':'trk']+'</span><div><b id="qfName">'+x.ctx[k]+'</b><span id="qfState">…</span></div></div>'+
  '<div class="sec" id="qfS1"><h5>1 · '+x.saveH+'<em>'+x.saveE+'</em></h5>'+btn('save','save',x.save[k],x.saveS[k],'pri','qfSave')+btn('copy','copy',x.copy,'','','qfCopy')+'</div>'+
  '<div class="sec" id="qfS2"><h5>2 · '+x.open+'</h5>'+btn('lib','lib',x.lib,x.libS[k],'','qfLib')+'<div class="r2">'+btn('plus','neu',x.neu[k],'','','bNew')+btn('open','open',x.of,x.ofS[k],'','qfOpen')+'</div></div>'+
  '<div class="sec" id="qfS3"><h5>3 · '+x.exp+'<em>'+x.expE+'</em></h5><div class="r2 fx">'+btn('file','file',x.ef[k],x.efS[k],'','qfFile')+'<label class="snd'+(C.sound?' on':'')+'"><input type="checkbox" id="qfSnd"'+(C.sound?' checked':'')+'>'+x.snd+'</label></div>'+
   '<div class="lab">'+x.audio+'</div><div id="xpBox"><div class="seg" style="grid-template-columns:repeat('+Math.max(1,seg.opts.length)+',minmax(0,1fr))">'+seg.opts.map(function(o){return '<button type="button" data-l="'+o.v+'" class="'+(String(seg.v)===String(o.v)?'on':'')+'"'+(o.t?' title="'+esc(o.t)+'"':'')+'>'+esc(o.l)+'</button>';}).join('')+'</div>'+
   '<div class="seg" style="grid-template-columns:1fr 1fr;margin-top:6px"><button type="button" data-f="wav" class="'+(fmt==='wav'?'on':'')+'">WAV</button><button type="button" data-f="mp3" class="'+(fmt==='mp3'?'on':'')+'">MP3</button></div><p id="xpI">'+esc(C.est?C.est():'')+'</p></div>'+
   btn('wave','audio',x.go,'','','bExp')+'</div>'+
  '<div class="foot"><span>✓ '+x.auto+'</span><button type="button" data-qf="np" id="bNewP">'+x.np+'</button></div>';
 state();}
function state(){if(!C||!P||!C.ctx)return;var x=L[lang()],k=C.kind;C.ctx(function(c){c=c||{};var n=P.querySelector('#qfName'),s=P.querySelector('#qfState');if(!n||!s)return;
 n.textContent=x.ctx[k]+' · '+(c.name||x.untitled)+(c.sub?' · '+c.sub:'');
 var st=c.state||'new',t=x.st[st];if(st==='ok'&&c.at)t+=' '+x.ago(Math.max(0,Math.floor((Date.now()-c.at)/60000)));s.className=st;s.textContent='● '+t;});}
function arm(b,fn){if(b.dataset.arm){clearTimeout(b._t);delete b.dataset.arm;b.classList.remove('arm');fn();return;}
 b.dataset.arm='1';b.classList.add('arm');var d=b.querySelector('div')||b,old=d.innerHTML;d.textContent=L[lang()].conf;b._t=setTimeout(function(){if(!b.isConnected)return;delete b.dataset.arm;b.classList.remove('arm');d.innerHTML=old;},3200);}
function click(e){var t=e.target.closest&&e.target.closest('button,input');if(!t||!C)return;
 if(t.id==='qfSnd'){C.sound=t.checked;var lb=t.parentNode;lb.classList.toggle('on',t.checked);return;}
 var l=t.getAttribute('data-l'),f=t.getAttribute('data-f');
 if(l!=null&&C.seg){C.seg(l);[].forEach.call(P.querySelectorAll('[data-l]'),function(b){b.classList.toggle('on',b===t);});est();return;}
 if(f&&C.fmt){C.fmt(f);[].forEach.call(P.querySelectorAll('[data-f]'),function(b){b.classList.toggle('on',b===t);});est();return;}
 var a=t.getAttribute('data-qf');if(!a)return;
 if(a==='neu'||a==='np'){arm(t,function(){close();C[a]();});return;}
 if(a==='file'){C.file(!!C.sound);close();return;}
 if(a==='save'||a==='copy'){if(C[a](ask)!==false)close();return;}
 close();if(C[a])C[a]();}
function est(){var p=P&&P.querySelector('#xpI');if(p&&C.est)p.textContent=C.est();}
/* petite question « Nom » dans le menu (Track) : remplace la section 1 le temps de la réponse */
function ask(def,cb){var x=L[lang()],s=P.querySelector('#qfS1');if(!s)return;var h=s.innerHTML;
 s.innerHTML='<h5>1 · '+x.saveH+'<em>'+x.name+'</em></h5><div class="ask"><input id="qfAskIn" maxlength="40" value="'+esc(def)+'"><button type="button" id="qfAskN">'+x.cancel+'</button><button type="button" class="y" id="qfAskY">'+x.ok+'</button></div>';
 var i=s.querySelector('#qfAskIn');try{i.focus();i.select();}catch(e){}
 function done(ok){var v=(i.value||'').trim();if(ok&&!v)return;s.innerHTML=h;if(ok){close();cb(v);}}
 s.querySelector('#qfAskY').onclick=function(e){e.stopPropagation();done(true);};s.querySelector('#qfAskN').onclick=function(e){e.stopPropagation();done(false);};
 i.onkeydown=function(e){if(e.key==='Enter')done(true);if(e.key==='Escape')done(false);};}
function place(){if(!P||!C||!C.btn)return;var r=C.btn.getBoundingClientRect(),t=Math.max(4,Math.round(r.bottom+6));P.style.top=t+'px';P.style.maxHeight=Math.max(200,innerHeight-t-8)+'px';}   /* écran plus court (barres de Safari) : le panneau défile au lieu d'être coupé */
function open(){if(!P)return;render();P.classList.add('on');place();if(C.btn)C.btn.setAttribute('aria-expanded','true');clearInterval(TM);TM=setInterval(function(){if(!isOpen()){clearInterval(TM);return;}est();},1500);if(C.onopen)C.onopen();}
function close(){if(!P)return;P.classList.remove('on');if(C&&C.btn)C.btn.setAttribute('aria-expanded','false');clearInterval(TM);}
function isOpen(){return !!(P&&P.classList.contains('on'));}
function mount(cfg){css();C=cfg;C.sound=false;if(!P){P=document.createElement('div');P.id='qfPanel';P.setAttribute('role','dialog');document.body.appendChild(P);P.addEventListener('click',click);
  document.addEventListener('pointerdown',function(e){if(isOpen()&&!P.contains(e.target)&&!(C.btn&&C.btn.contains(e.target)))close();},true);
  addEventListener('keydown',function(e){if(e.key==='Escape'&&isOpen())close();});addEventListener('resize',function(){if(isOpen())place();});
  try{addEventListener('storage',function(e){if(e.key==='qx.lang'&&isOpen())render();});}catch(e){}}
 return api;}
/* MP3 (Track) : même encodeur local que Pattern, chargé à la demande, par petits blocs */
function lame(cb){if(window.lamejs&&lamejs.Mp3Encoder)return cb(true);var sc=document.createElement('script');sc.src='../assets/js/lame.min.js?v=R351';sc.onload=function(){cb(!!(window.lamejs&&lamejs.Mp3Encoder));};sc.onerror=function(){cb(false);};document.head.appendChild(sc);}
function mp3(b,kbps,cb,prog){lame(function(ok){if(!ok){cb(null);return;}
 var Lc=b.getChannelData(0),Rc=b.numberOfChannels>1?b.getChannelData(1):Lc,n=Lc.length,enc=new lamejs.Mp3Encoder(2,b.sampleRate,kbps||192),out=[],pos=0,blk=1152*16;
 function i16(a,s0,e0){var o=new Int16Array(e0-s0),k,v;for(k=0;k<o.length;k++){v=a[s0+k];o[k]=v<-1?-32768:v>1?32767:Math.round(v*32767);}return o;}
 (function step(){var t0=performance.now();while(pos<n&&performance.now()-t0<25){var e0=Math.min(n,pos+blk),m=enc.encodeBuffer(i16(Lc,pos,e0),i16(Rc,pos,e0));if(m.length)out.push(new Uint8Array(m));pos=e0;}
  if(pos<n){if(prog)prog(pos/n);setTimeout(step,0);return;}var f=enc.flush();if(f.length)out.push(new Uint8Array(f));cb(new Blob(out,{type:'audio/mpeg'}));})();});}
var api={mount:mount,open:open,close:close,toggle:function(){isOpen()?close():open();},isOpen:isOpen,refresh:function(){if(isOpen())render();},state:state,lang:lang,L:L,mp3:mp3,
 labels:function(){return P?[].map.call(P.querySelectorAll('h5,button,label'),function(e){return e.textContent.trim();}):[];}};
window.QFILE=api;
})();
