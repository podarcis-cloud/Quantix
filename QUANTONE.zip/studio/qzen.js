/* QZEN (R431) — « Détente » : cinq mondes de matière pour une boule anti-stress cosmique. Aucun score, aucune fin, aucun minuteur.
   Nuée quantique · Galaxie · Intrication · Chronos · Éther. Le doigt, l'appui long, l'inclinaison et la secousse agissent sur chaque monde à sa façon.
   Notes pentatoniques douces (son désactivé par défaut). Un seul canvas 2D, sprites pré-dessinés, nombre de particules adaptatif. */
(function(){
var root=null,cv=null,cx=null,raf=0,W=0,H=0,dpr=1,t=0,last=0,ptr={},cost=0,pf=1,hi=0,sx=0,sy=0,sprites={},snd=false,ac=null,lastPing=0,noiseB=null,tiltOn=false,tilt={x:0,y:0},tt={x:0,y:0},ref=null,mid='nuee',M=null,rings=[],flash=0,hintT=0,lvv=0;
function T(a,b){return (document.documentElement.lang||'fr').indexOf('en')===0?b:a;}
function rnd(a,b){return a+Math.random()*(b-a);}
function cl(v,a,b){return v<a?a:v>b?b:v;}
function spr(h){var k=((Math.round(h/12)%30)+30)%30,s=sprites[k];if(s)return s;var r=16,e=document.createElement('canvas');e.width=e.height=r*2;var x=e.getContext('2d'),g=x.createRadialGradient(r,r,0,r,r,r),c='hsla('+(k*12)+',88%,';
 g.addColorStop(0,c+'80%,1)');g.addColorStop(.28,c+'62%,.45)');g.addColorStop(1,c+'50%,0)');x.fillStyle=g;x.fillRect(0,0,r*2,r*2);return sprites[k]=e;}
function pl(){return Object.keys(ptr).map(function(k){return ptr[k];});}
/* ── son : gamme pentatonique mineure ── */
var SC=[0,3,5,7,10];
function note(y){var k=cl(Math.floor((1-y/H)*9.99),0,9);return 110*Math.pow(2,(SC[k%5]+12*Math.floor(k/5))/12);}
function tone(f,o){var t0=ac.currentTime,os=ac.createOscillator(),g=ac.createGain(),lp=ac.createBiquadFilter();os.type=o.ty||'sine';os.frequency.setValueAtTime(f,t0);if(o.sl)os.frequency.exponentialRampToValueAtTime(Math.max(30,f*o.sl),t0+o.d);lp.type='lowpass';lp.frequency.value=o.lp||2000;
 g.gain.setValueAtTime(0,t0+(o.dl||0));g.gain.linearRampToValueAtTime(o.g||.05,t0+(o.dl||0)+(o.a||.02));g.gain.exponentialRampToValueAtTime(.0006,t0+(o.dl||0)+o.d);os.connect(lp);lp.connect(g);g.connect(ac.destination);os.start(t0+(o.dl||0));os.stop(t0+(o.dl||0)+o.d+.1);}
function ping(x,y,kind){if(!snd)return;var n=performance.now();if(n-lastPing<(kind==='boom'?0:130))return;lastPing=n;
 try{if(!ac){var C=window.AudioContext||window.webkitAudioContext;ac=new C();}if(ac.state!=='running')ac.resume();var f=note(y);
  if(kind==='bell'){tone(f,{d:1.6,g:.05});tone(f*2.01,{d:.9,g:.015});}
  else if(kind==='pad'){tone(f/2,{ty:'triangle',a:.35,d:2.2,g:.045,lp:900});}
  else if(kind==='pair'){tone(f,{d:1.4,g:.04});tone(f*1.5,{d:1.4,g:.03,dl:.09});}
  else if(kind==='tick'){tone(f*2,{d:.5,g:.04,sl:.6});}
  else if(kind==='air'){if(!noiseB){noiseB=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);var d=noiseB.getChannelData(0),i;for(i=0;i<d.length;i++)d[i]=Math.random()*2-1;}
   var s=ac.createBufferSource(),b=ac.createBiquadFilter(),g=ac.createGain(),t0=ac.currentTime;s.buffer=noiseB;b.type='bandpass';b.frequency.value=f*3;b.Q.value=6;g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(.08,t0+.15);g.gain.exponentialRampToValueAtTime(.0006,t0+1.1);s.connect(b);b.connect(g);g.connect(ac.destination);s.start(t0);s.stop(t0+1.2);}
  else if(kind==='boom'){tone(f/4,{d:1.8,g:.09,sl:.5,lp:600});tone(f,{d:1.2,g:.03});}}catch(e){}}
/* ── aides de dessin ── */
function fade(a){cx.globalCompositeOperation='source-over';cx.globalAlpha=1;cx.fillStyle='rgba(5,8,15,'+a+')';cx.fillRect(0,0,W,H);cx.globalCompositeOperation='lighter';}
function dot(h,x,y,s,a){cx.globalAlpha=a;cx.drawImage(spr(h),x-s/2,y-s/2,s,s);}
function addRing(x,y,h,sp){rings.push({x:x,y:y,r:6,h:h,a:.55,v:sp||330});}
function drawRings(dt){var i,r;cx.globalCompositeOperation='lighter';for(i=rings.length-1;i>=0;i--){r=rings[i];r.r+=r.v*dt;r.a-=dt*.42;if(r.a<=0){rings.splice(i,1);continue;}cx.globalAlpha=r.a;cx.strokeStyle='hsl('+r.h+',85%,70%)';cx.lineWidth=1.2;cx.beginPath();cx.arc(r.x,r.y,r.r,0,6.2832);cx.stroke();}cx.globalAlpha=1;}
function cen(){return {x:W/2+tilt.x*46,y:H/2+tilt.y*46};}
function N(n){return Math.max(60,Math.round(n*pf));}
var GA=Math.PI*(3-Math.sqrt(5));
/* ═════ 1. NUÉE QUANTIQUE : superposition / mesure ═════ */
var nuee={id:'nuee',fr:'Nuée quantique',en:'Quantum cloud',hint:['Le doigt « mesure » : le nuage s’effondre en points nets.','Reste appuyé : la fonction d’onde se resserre. Relâche : elle se déploie.'],kind:'bell',P:[],
 init:function(){var n=N(260),R=Math.min(W,H)*.34,i,P=[];for(i=0;i<n;i++)P.push({x:W/2,y:H/2,vx:0,vy:0,hr:R*Math.sqrt((i+.5)/n),ha:i*GA,u:12,ph:rnd(0,6.28)});this.P=P;},
 step:function(dt){var P=this.P,c=cen(),i,k,q,ps=pl(),sp=dt*60,rot=t*.05,R=Math.min(W,H)*.2+34;
  for(i=0;i<P.length;i++){q=P[i];var a=q.ha+rot,hx=c.x+Math.cos(a)*q.hr,hy=c.y+Math.sin(a)*q.hr,tu=9+7*Math.sin(t*.8+q.ph),pull=0;
   q.vx+=(hx-q.x)*.012*sp;q.vy+=(hy-q.y)*.012*sp;
   for(k=0;k<ps.length;k++){var p=ps[k],dx=q.x-p.x,dy=q.y-p.y,d=Math.hypot(dx,dy)+.01;
    if(p.g){q.vx+=-dx*.02*sp+(dy/d)*.3*sp;q.vy+=-dy*.02*sp+(-dx/d)*.3*sp;tu=.6;}
    else if(d<R){var f=Math.pow(1-d/R,2)*2.4*sp;q.vx+=dx/d*f;q.vy+=dy/d*f;tu=Math.min(tu,.8+d/R*5);}}
   q.u+=(tu-q.u)*Math.min(1,dt*7);q.vx*=Math.pow(.9,sp);q.vy*=Math.pow(.9,sp);q.x+=q.vx*sp;q.y+=q.vy*sp;}},
 draw:function(dt){var P=this.P,i,q,lv=lvv;fade(.2);
  for(i=0;i<P.length;i++){q=P[i];var sh=q.u<3;
   if(sh){dot(196,q.x,q.y,11+lv*4,.95);dot(190,q.x,q.y,4,1);}
   else{var o=q.u*.9;dot(196,q.x,q.y,15+q.u*.5,.5);dot(210,q.x+rnd(-o,o),q.y+rnd(-o,o),14+q.u*.4,.22);if(i%2)dot(180,q.x+rnd(-o,o),q.y+rnd(-o,o),12,.16);}}
  drawRings(dt);},
 press:function(p){},hold:function(p){ping(p.x,p.y,'bell');},
 release:function(p,sh){var P=this.P,i,q,d,bx,by;addRing(p.x,p.y,196,380);addRing(p.x,p.y,215,250);for(i=0;i<P.length;i++){q=P[i];bx=q.x-p.x;by=q.y-p.y;d=Math.hypot(bx,by)+.01;q.vx+=bx/d*rnd(1,3)*Math.min(1,200/d)*2.4;q.vy+=by/d*rnd(1,3)*Math.min(1,200/d)*2.4;q.u=rnd(18,30);}ping(p.x,p.y,'boom');}};
/* ═════ 2. GALAXIE : orbites, puits de gravité, supernova ═════ */
var gal={id:'gal',fr:'Galaxie',en:'Galaxy',hint:['Ton doigt est un puits de gravité : les étoiles s’en approchent.','Reste appuyé : un trou noir. Relâche : supernova.'],kind:'pad',P:[],
 init:function(){var n=N(330),R=Math.min(W,H)*.42,i,P=[];for(i=0;i<n;i++){var r=14+R*Math.pow(Math.random(),.75),arm=i%3,th=arm*2.094+r*.017+rnd(-.35,.35);P.push({r:r,th:th,om:.62*Math.pow(70/(r+28),.75),dx:0,dy:0,dvx:0,dvy:0,x:0,y:0,hue:(38-Math.min(1,r/R)*150+360)%360,s:rnd(.6,1.4),ph:rnd(0,6.28)});}this.P=P;this.bh=0;},
 step:function(dt){var P=this.P,c=cen(),i,k,q,ps=pl(),sp=dt*60,R=Math.min(W,H)*.34,bh=0;
  for(i=0;i<P.length;i++){q=P[i];q.th+=q.om*dt;var bx=c.x+Math.cos(q.th)*q.r,by=c.y+Math.sin(q.th)*q.r*.86;
   q.dvx+=-q.dx*.035*sp;q.dvy+=-q.dy*.035*sp;
   for(k=0;k<ps.length;k++){var p=ps[k],ex=p.x-(bx+q.dx),ey=p.y-(by+q.dy),d=Math.hypot(ex,ey)+.01;
    if(p.g){bh=1;var f=(1.6+120/(d+30))*sp*.1;q.dvx+=ex/d*f+(-ey/d)*f*.5;q.dvy+=ey/d*f+(ex/d)*f*.5;}
    else if(d<R){var f2=Math.pow(1-d/R,2)*1.7*sp;q.dvx+=ex/d*f2;q.dvy+=ey/d*f2;}}
   q.dvx*=Math.pow(.93,sp);q.dvy*=Math.pow(.93,sp);q.dx+=q.dvx*sp;q.dy+=q.dvy*sp;q.x=bx+q.dx;q.y=by+q.dy;}this.bh=bh;},
 draw:function(dt){var P=this.P,i,q,c=cen(),lv=lvv;fade(.26);
  dot(34,c.x,c.y,150+lv*30,.5);dot(30,c.x,c.y,60,.7);
  for(i=0;i<P.length;i++){q=P[i];var tw=.7+.3*Math.sin(t*2+q.ph),sz=(8+q.s*8)*(1+lv*.3);dot(q.hue,q.x,q.y,sz,.55*tw+.25);if(q.s>1.15)dot(q.hue+20,q.x,q.y,3,.9);}
  var ps=pl();for(i=0;i<ps.length;i++){var p=ps[i];if(p.g){var g=cx.createRadialGradient(p.x,p.y,4,p.x,p.y,70);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(.35,'rgba(255,170,80,.35)');g.addColorStop(1,'rgba(255,170,80,0)');cx.globalCompositeOperation='source-over';cx.globalAlpha=1;cx.fillStyle=g;cx.fillRect(p.x-72,p.y-72,144,144);cx.globalCompositeOperation='lighter';}}
  drawRings(dt);},
 press:function(p){},hold:function(p){ping(p.x,p.y,'pad');},
 release:function(p){var P=this.P,i,q,bx,by,d;for(i=0;i<P.length;i++){q=P[i];bx=q.x-p.x;by=q.y-p.y;d=Math.hypot(bx,by)+.01;var f=Math.min(1,260/d)*rnd(2,5);q.dvx+=bx/d*f;q.dvy+=by/d*f;}addRing(p.x,p.y,40,420);addRing(p.x,p.y,200,300);flash=.2;ping(p.x,p.y,'boom');}};
/* ═════ 3. INTRICATION : paires jumelles en miroir ═════ */
var ent={id:'ent',fr:'Intrication',en:'Entanglement',hint:['Chaque point a un jumeau : ce que tu fais d’un côté se reproduit en miroir.','Reste appuyé : les jumeaux se rassemblent en deux pôles reliés. Relâche : ils jaillissent.'],kind:'pair',P:[],n:0,
 init:function(){var n=N(120),R=Math.min(W,H)*.36,i,P=[];for(i=0;i<n;i++){var hr=R*Math.sqrt((i+.5)/n),ha=i*GA;P.push({x:W/2,y:H/2,vx:0,vy:0,hr:hr,ha:ha,sg:1});}for(i=0;i<n;i++)P.push({x:W/2,y:H/2,vx:0,vy:0,hr:P[i].hr,ha:P[i].ha,sg:-1});this.P=P;this.n=n;},
 step:function(dt){var P=this.P,c=cen(),i,k,q,ps=pl(),sp=dt*60,rot=t*.045,R=Math.min(W,H)*.2+34;
  for(i=0;i<P.length;i++){q=P[i];var a=q.ha+rot,hx=c.x+q.sg*Math.cos(a)*q.hr,hy=c.y+q.sg*Math.sin(a)*q.hr;q.vx+=(hx-q.x)*.012*sp;q.vy+=(hy-q.y)*.012*sp;
   for(k=0;k<ps.length;k++){var p=ps[k],pxs=[p.x,2*c.x-p.x],pys=[p.y,2*c.y-p.y],m;for(m=0;m<2;m++){var dx=q.x-pxs[m],dy=q.y-pys[m],d=Math.hypot(dx,dy)+.01;
     if(p.g){if((m===0)===(q.sg===1)){q.vx+=-dx*.022*sp+(dy/d)*.18*sp;q.vy+=-dy*.022*sp+(-dx/d)*.18*sp;}}
     else if(d<R){var f=Math.pow(1-d/R,2)*2.4*sp;q.vx+=dx/d*f;q.vy+=dy/d*f;}}}
   q.vx*=Math.pow(.9,sp);q.vy*=Math.pow(.9,sp);q.x+=q.vx*sp;q.y+=q.vy*sp;}},
 draw:function(dt){var P=this.P,n=this.n,i,a,b;fade(.2);
  cx.lineWidth=.8;var B=[[],[],[]];
  for(i=0;i<n;i++){a=P[i];b=P[i+n];var d=Math.hypot(a.x-b.x,a.y-b.y),k=d<80?0:d<200?1:2;B[k].push(a.x,a.y,b.x,b.y);}
  var AL=[.30,.16,.08],bi,j;for(bi=0;bi<3;bi++){var L=B[bi];if(!L.length)continue;cx.globalAlpha=AL[bi];cx.strokeStyle='hsl('+(268+bi*10)+',80%,66%)';cx.beginPath();for(j=0;j<L.length;j+=4){cx.moveTo(L[j],L[j+1]);cx.lineTo(L[j+2],L[j+3]);}cx.stroke();}
  for(i=0;i<n;i++){a=P[i];b=P[i+n];dot(292,a.x,a.y,17,.7);dot(190,b.x,b.y,17,.7);dot(300,a.x,a.y,4,.9);dot(180,b.x,b.y,4,.9);}
  drawRings(dt);},
 press:function(p){},hold:function(p){ping(p.x,p.y,'pair');},
 release:function(p){var P=this.P,c=cen(),i,q,m,ps=[p,{x:2*c.x-p.x,y:2*c.y-p.y}];for(i=0;i<P.length;i++){q=P[i];for(m=0;m<2;m++){var bx=q.x-ps[m].x,by=q.y-ps[m].y,d=Math.hypot(bx,by)+.01;if(d<220){q.vx+=bx/d*rnd(2,5);q.vy+=by/d*rnd(2,5);}}}addRing(p.x,p.y,292,320);addRing(ps[1].x,ps[1].y,190,320);ping(p.x,p.y,'boom');}};
/* ═════ 4. CHRONOS : le temps ralentit autour du doigt ═════ */
var chr={id:'chr',fr:'Chronos',en:'Chronos',hint:['Autour de ton doigt, le temps ralentit.','Reste appuyé : une bulle de temps figé. Relâche : l’onde temporelle.'],kind:'tick',P:[],
 init:function(){var n=N(240),K=6,i,P=[],R=Math.min(W,H)*.43;for(i=0;i<n;i++){var k=i%K,r=R*(.2+.8*(k+1)/K);P.push({k:k,r:r,th:rnd(0,6.283),om:(k%2?-1:1)*(.9/(1+k*.35)),x:0,y:0,dx:0,dy:0,dvx:0,dvy:0,tau:1,bo:0,ph:rnd(0,6.28)});}this.P=P;this.K=K;this.R=R;},
 step:function(dt){var P=this.P,c=cen(),i,k,q,ps=pl(),sp=dt*60,R=Math.min(W,H)*.22+30;
  for(i=0;i<P.length;i++){q=P[i];var tau=1,hold=0;
   for(k=0;k<ps.length;k++){var p=ps[k],d=Math.hypot(q.x-p.x,q.y-p.y),Rr=p.g?R*1.6:R,s=Math.exp(-Math.pow(d/Rr,2)*1.6);tau=Math.min(tau,1-(p.g?.985:.9)*s);if(p.g&&d<Rr)hold=1;}
   q.bo*=Math.pow(.96,sp);tau=tau+q.bo*3;q.tau+=(tau-q.tau)*Math.min(1,dt*10);
   q.th+=q.om*dt*q.tau;q.dvx+=-q.dx*.03*sp;q.dvy+=-q.dy*.03*sp;q.dvx*=Math.pow(.92,sp);q.dvy*=Math.pow(.92,sp);q.dx+=q.dvx*sp;q.dy+=q.dvy*sp;
   q.x=c.x+Math.cos(q.th)*q.r+q.dx;q.y=c.y+Math.sin(q.th)*q.r+q.dy;}},
 draw:function(dt){var P=this.P,c=cen(),i,q,K=this.K;fade(.07);
  cx.globalAlpha=.07;cx.strokeStyle='hsl(170,60%,70%)';cx.lineWidth=1;for(i=0;i<K;i++){var r=this.R*(.2+.8*(i+1)/K);cx.beginPath();cx.arc(c.x,c.y,r,0,6.2832);cx.stroke();}
  var ang=t*.105;cx.globalAlpha=.14;cx.strokeStyle='hsl(42,80%,70%)';cx.beginPath();cx.moveTo(c.x,c.y);cx.lineTo(c.x+Math.cos(ang)*this.R,c.y+Math.sin(ang)*this.R);cx.stroke();
  for(i=0;i<P.length;i++){q=P[i];var sl=1-q.tau;dot(sl>.4?175:42,q.x,q.y,10+sl*14+(q.bo>.05?10:0),.5+sl*.45);if(i%4===0)dot(42,q.x,q.y,3,.9);}
  var ps=pl();for(i=0;i<ps.length;i++){var p=ps[i];if(p.g){cx.globalAlpha=.25;cx.strokeStyle='hsl(175,90%,75%)';cx.lineWidth=1.4;cx.beginPath();cx.arc(p.x,p.y,(Math.min(W,H)*.22+30)*1.6+Math.sin(t*4)*2,0,6.2832);cx.stroke();}}
  drawRings(dt);},
 press:function(p){},hold:function(p){ping(p.x,p.y,'tick');},
 release:function(p){var P=this.P,i,q;for(i=0;i<P.length;i++){q=P[i];if(Math.hypot(q.x-p.x,q.y-p.y)<Math.min(W,H)*.38)q.bo=1;}addRing(p.x,p.y,175,520);addRing(p.x,p.y,42,360);ping(p.x,p.y,'boom');}};
/* ═════ 5. ÉTHER : filaments de plasma dans un courant ═════ */
var eth={id:'eth',fr:'Éther',en:'Aether',hint:['Un courant d’énergie traverse l’éther : tes doigts y créent des tourbillons.','Reste appuyé : un puits aspire les filaments. Relâche : ils jaillissent.'],kind:'air',P:[],
 init:function(){var n=N(230),i,P=[];for(i=0;i<n;i++)P.push({x:rnd(0,W),y:rnd(0,H),px:0,py:0,age:rnd(0,6),life:rnd(4,9),b:i%3});this.P=P;},
 step:function(dt){var P=this.P,i,k,q,ps=pl(),sp=dt*60,a=.011,b=.013,c=.007,tt_=t;
  for(i=0;i<P.length;i++){q=P[i];q.px=q.x;q.py=q.y;q.age+=dt;
   var s1=Math.sin(a*q.x+.3*tt_),c1=Math.cos(a*q.x+.3*tt_),s2=Math.sin(b*q.y-.2*tt_),c2=Math.cos(b*q.y-.2*tt_),c3=Math.cos(c*(q.x+q.y)+.17*tt_);
   var vx=(-s1*s2*b+.6*c*c3)*3600+tilt.x*40,vy=-(a*c1*c2+.6*c*c3)*3600+tilt.y*40;
   for(k=0;k<ps.length;k++){var p=ps[k],dx=q.x-p.x,dy=q.y-p.y,d2=dx*dx+dy*dy+500,d=Math.sqrt(d2),f=(p.g?-1:1);
    vx+=(-dy/d)*9000/d*(p.g?1.2:1)+f*(p.g?-dx/d*160:0);vy+=(dx/d)*9000/d*(p.g?1.2:1)+f*(p.g?-dy/d*160:0);}
   q.x+=vx*dt;q.y+=vy*dt;
   if(q.age>q.life||q.x<-20||q.x>W+20||q.y<-20||q.y>H+20){q.x=rnd(0,W);q.y=rnd(0,H);q.px=q.x;q.py=q.y;q.age=0;q.life=rnd(4,9);}}},
 draw:function(dt){var P=this.P,i,q,B=[[],[],[]];fade(.1);
  for(i=0;i<P.length;i++){q=P[i];var al=Math.min(1,q.age*1.5,(q.life-q.age)*1.5);if(al<=.02)continue;B[q.b].push(q.px,q.py,q.x,q.y);if(i%3===0)dot(165+q.b*45,q.x,q.y,10,.35*al);}
  var HU=[165,205,270],bi,j;cx.lineWidth=1.3;for(bi=0;bi<3;bi++){var L=B[bi];cx.globalAlpha=.75;cx.strokeStyle='hsl('+HU[bi]+',85%,66%)';cx.beginPath();for(j=0;j<L.length;j+=4){cx.moveTo(L[j],L[j+1]);cx.lineTo(L[j+2],L[j+3]);}cx.stroke();}
  drawRings(dt);},
 press:function(p){},hold:function(p){ping(p.x,p.y,'air');},
 release:function(p){var P=this.P,i,q;for(i=0;i<P.length;i++){q=P[i];if(Math.hypot(q.x-p.x,q.y-p.y)<260){var a=Math.atan2(q.y-p.y,q.x-p.x);q.x+=Math.cos(a)*rnd(20,90);q.y+=Math.sin(a)*rnd(20,90);}}addRing(p.x,p.y,200,300);ping(p.x,p.y,'boom');}};
var MATS={nuee:nuee,gal:gal,ent:ent,chr:chr,eth:eth},ORD=['nuee','gal','ent','chr','eth'];
function setMat(id){if(!MATS[id])id='nuee';mid=id;M=MATS[id];rings=[];flash=0;M.init();cx.setTransform(dpr,0,0,dpr,0,0);cx.globalCompositeOperation='source-over';cx.globalAlpha=1;cx.fillStyle='#05080f';cx.fillRect(0,0,W,H);try{localStorage.setItem('qx.zen',id);}catch(e){}
 if(root){[].forEach.call(root.querySelectorAll('[data-m]'),function(b){b.style.background=b.getAttribute('data-m')===id?'rgba(77,215,255,.28)':'rgba(255,255,255,.08)';b.style.color=b.getAttribute('data-m')===id?'#eaf8ff':'#9fc4d8';});showHint(0);}}
function showHint(i){var h=document.getElementById('qZenH');if(!h)return;h.textContent=T(M.hint[i],M.hint[i]);h.style.transition='none';h.style.opacity=1;hintT=performance.now();setTimeout(function(){if(h){h.style.transition='opacity 1.6s';}},30);}
function resize(){W=innerWidth;H=innerHeight;dpr=Math.min(2,window.devicePixelRatio||1);cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);setMat(mid);}
function loop(n){raf=requestAnimationFrame(loop);if(document.hidden){last=n;return;}var dt=Math.min(.05,(n-(last||n))/1000);last=n;t+=dt;
 var a=performance.now(),i,ps=pl(),lv=0;try{lv=window.QWV&&QWV.lv?QWV.lv():0;}catch(e){}lvv+=(lv-lvv)*.2;
 tilt.x+=(tt.x-tilt.x)*.08;tilt.y+=(tt.y-tilt.y)*.08;
 for(i=0;i<ps.length;i++){var p=ps[i];if(!p.g&&!p.mv&&a-p.t0>380){p.g=true;M.hold(p);if(navigator.vibrate)try{navigator.vibrate(12);}catch(e){}}}
 if(hintT&&a-hintT>6500){var h=document.getElementById('qZenH');if(h)h.style.opacity=0;hintT=0;}
 M.step(dt);cx.setTransform(dpr,0,0,dpr,0,0);M.draw(dt);
 if(flash>0){cx.globalCompositeOperation='lighter';cx.globalAlpha=flash;cx.fillStyle='#ffd9a0';cx.fillRect(0,0,W,H);cx.globalAlpha=1;flash-=dt*.7;}
 var ps2=pl();cx.globalCompositeOperation='lighter';for(i=0;i<ps2.length;i++){var q=ps2[i],r=(q.g?58:88)+Math.sin(t*3)*4,g=cx.createRadialGradient(q.x,q.y,0,q.x,q.y,r);g.addColorStop(0,'rgba(200,230,255,.055)');g.addColorStop(1,'rgba(200,230,255,0)');cx.globalAlpha=1;cx.fillStyle=g;cx.fillRect(q.x-r,q.y-r,r*2,r*2);}
 cx.globalCompositeOperation='source-over';
 cost=cost*.92+(performance.now()-a)*.08;if(cost>9){slow++;if(slow>90&&pf>.5){pf=Math.max(.5,pf*.8);slow=0;M.init();}}else slow=0;}
var slow=0;
function down(e){e.preventDefault();ptr[e.pointerId]={x:e.clientX,y:e.clientY,t0:performance.now(),mv:false,g:false,sx:e.clientX,sy:e.clientY};try{cv.setPointerCapture(e.pointerId);}catch(x){}ping(e.clientX,e.clientY,M.kind);}
function move(e){var q=ptr[e.pointerId];if(!q)return;q.x=e.clientX;q.y=e.clientY;if(!q.g&&Math.hypot(q.x-q.sx,q.y-q.sy)>14)q.mv=true;if(q.mv)ping(q.x,q.y,M.kind);}
function up(e){var q=ptr[e.pointerId];if(!q)return;if(q.g)M.release(q);delete ptr[e.pointerId];}
function onOri(e){if(e.gamma==null)return;if(!ref)ref={g:e.gamma,b:e.beta};tt.x=cl((e.gamma-ref.g)/28,-1.3,1.3);tt.y=cl((e.beta-ref.b)/28,-1.3,1.3);}
var lastShake=0;function onMot(e){var a=e.acceleration;if(!a||a.x==null)return;var m=Math.hypot(a.x,a.y,a.z||0),n=performance.now();if(m>17&&n-lastShake>900){lastShake=n;M.release({x:W/2,y:H/2});}}
function setTilt(on){if(on===tiltOn)return;var b=root&&root.querySelector('[data-a=tl]');
 if(on){var go=function(){tiltOn=true;ref=null;window.addEventListener('deviceorientation',onOri);window.addEventListener('devicemotion',onMot);if(b)b.textContent=T('Incliner : oui','Tilt: on');};
  try{if(window.DeviceMotionEvent&&typeof DeviceMotionEvent.requestPermission==='function'){DeviceMotionEvent.requestPermission().then(function(r){if(r==='granted')go();else if(b)b.textContent=T('Incliner : refusé','Tilt: denied');}).catch(function(){});}else go();}catch(e){}}
 else{tiltOn=false;tt.x=tt.y=0;window.removeEventListener('deviceorientation',onOri);window.removeEventListener('devicemotion',onMot);if(b)b.textContent=T('Incliner : non','Tilt: off');}}
function open(id){if(root)return;var sv='nuee';try{sv=localStorage.getItem('qx.zen')||'nuee';}catch(e){}mid=id||sv;
 root=document.createElement('div');root.id='qZen';root.style.cssText='position:fixed;inset:0;z-index:2147482000;background:#05080f;touch-action:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none';
 var bs='height:40px;padding:0 14px;border-radius:20px;border:0;background:rgba(255,255,255,.10);color:#cfeaff;font:600 12.5px system-ui;';
 root.innerHTML='<canvas style="position:absolute;inset:0;width:100%;height:100%;display:block"></canvas>'+
 '<button data-a="x" aria-label="'+T('Quitter','Leave')+'" style="'+bs+'position:absolute;right:max(14px,env(safe-area-inset-right));top:calc(env(safe-area-inset-top,0px) + 12px);width:40px;padding:0;font-size:22px">×</button>'+
 '<div style="position:absolute;left:max(14px,env(safe-area-inset-left));top:calc(env(safe-area-inset-top,0px) + 12px);display:flex;gap:8px"><button data-a="s" style="'+bs+'">'+T('Son : non','Sound: off')+'</button><button data-a="tl" style="'+bs+'">'+T('Incliner : non','Tilt: off')+'</button></div>'+
 '<div id="qZenH" style="position:absolute;left:24px;right:24px;bottom:calc(env(safe-area-inset-bottom,0px) + 84px);text-align:center;color:rgba(207,234,255,.62);font:13px/1.4 system-ui;pointer-events:none;opacity:0"></div>'+
 '<div style="position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 16px);display:flex;gap:6px;justify-content:center;padding:0 8px">'+ORD.map(function(k){return '<button data-m="'+k+'" style="'+bs+'height:44px;padding:0 9px;font-size:11.5px">'+T(MATS[k].fr,MATS[k].en)+'</button>';}).join('')+'</div>';
 document.body.appendChild(root);cv=root.querySelector('canvas');cx=cv.getContext('2d');resize();
 cv.addEventListener('pointerdown',down);cv.addEventListener('pointermove',move);cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);window.addEventListener('resize',resize);
 root.addEventListener('click',function(e){var a=e.target.getAttribute&&e.target.getAttribute('data-a'),m=e.target.getAttribute&&e.target.getAttribute('data-m');
  if(a==='x')close();else if(a==='s'){snd=!snd;e.target.textContent=snd?T('Son : oui','Sound: on'):T('Son : non','Sound: off');if(snd)ping(W/2,H/2,'bell');}else if(a==='tl')setTilt(!tiltOn);else if(m){ptr={};setMat(m);}});
 last=0;raf=requestAnimationFrame(loop);}
function close(){if(!root)return;cancelAnimationFrame(raf);raf=0;setTilt(false);window.removeEventListener('resize',resize);root.remove();root=null;cv=null;cx=null;ptr={};rings=[];if(ac){try{ac.close();}catch(e){}ac=null;}}
window.QZEN={open:open,close:close,on:function(){return !!root;},set:function(id){if(root){ptr={};setMat(id);}},mat:function(){return mid;},mats:function(){return ORD.slice();},n:function(){return M?M.P.length:0;},cost:function(){return cost;},_p:function(){return M?M.P:[];},_ptr:function(){return ptr;}};
})();
