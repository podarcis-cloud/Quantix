/* qaide.js — R405 : aide contextuelle (lot 1) + « Atelier » (lot 2), commun à Pattern (quantone.html) et Track (morceau.html).
   Règles : jamais bloquant, rien d'obligatoire, aucun échec, état local seulement (localStorage, try/catch, effaçable),
   aucune capture des gestes (écouteurs passifs, aucune surcouche), détection des défis en LECTURE SEULE de l'état exposé
   (QUANTONE.state, QAUTO.AUT, QPATFILE, QEXPORT, QSMP côté Pattern ; MORCEAU.P() côté Track).
   Clés : qx.aide ('1'/'0', partagée Pattern/Track) · qx.aide.vu (astuces déjà montrées) · qx.atelier (progression) · qx.atelier.vu (panneau déjà ouvert). */
(function(){'use strict';
if(window.QAIDE)return;
var TRK=/morceau/.test(location.pathname),MEM={};
function ls(k,v){try{if(v===undefined){var r=localStorage.getItem(k);return r===null&&MEM[k]!==undefined?MEM[k]:r;}if(v===null){localStorage.removeItem(k);delete MEM[k];}else{localStorage.setItem(k,v);}}catch(e){if(v===null)delete MEM[k];else if(v!==undefined)MEM[k]=v;else return MEM[k]===undefined?null:MEM[k];}return null;}
function J(k,d){try{var r=ls(k);return r?JSON.parse(r):d;}catch(e){return d;}}
function $(i){return document.getElementById(i);}
function FR(){var b=$('bLang');if(b&&(b.textContent==='EN'||b.textContent==='FR'))return b.textContent==='EN';var l=ls('qx.lang');if(l==='en'||l==='fr')return l==='fr';return (navigator.language||'fr').slice(0,2)==='fr';}
function X(o){return o==null?'':(typeof o==='string'?o:(FR()?o.fr:o.en));}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

/* ───────── textes ───────── */
var TX={
 aide:{fr:'Aide contextuelle',en:'Contextual help'},
 revoir:{fr:'Revoir les astuces',en:'Show tips again'},
 revu:{fr:'Les astuces reviendront.',en:'Tips will show again.'},
 atelier:{fr:'Atelier',en:'Workshop'},
 defis:{fr:'Défis (Atelier) dans l’en-tête',en:'Challenges (Workshop) in header'},
 ex:{fr:'Écouter un exemple',en:'Hear an example'},
 exs:{fr:'Exemples',en:'Examples'},
 exMsg:{fr:'Touche ▶, puis change ce qui te plaît.',en:'Press ▶, then change whatever you like.'},
 exRep:{fr:'Remplacer ton dessin ?',en:'Replace your drawing?'},
 man:{fr:'Mode d’emploi',en:'User guide'},
 fermer:{fr:'Fermer',en:'Close'},
 indice:{fr:'Indice',en:'Hint'},
 passer:{fr:'Passer',en:'Skip'},
 reprendre:{fr:'Reprendre',en:'Resume'},
 reset:{fr:'Réinitialiser',en:'Reset'},
 sur:{fr:'Sûr ?',en:'Sure?'},
 facultatif:{fr:'Défis facultatifs, cochés tout seuls quand c’est fait. Rien n’est obligatoire : tu peux passer, fermer, y revenir.',en:'Optional challenges, ticked automatically when done. Nothing is required: skip, close, come back any time.'},
 bonus:{fr:'Bonus · jamais obligatoires',en:'Bonus · never required'},
 ailleursT:{fr:'À faire dans Track',en:'Done in Track'},
 ailleursP:{fr:'À faire dans Pattern',en:'Done in Pattern'},
 fait:{fr:'fait',en:'done'},passe:{fr:'passé',en:'skipped'},
 bravo:{fr:'✓ Défi réussi : ',en:'✓ Challenge done: '},
 nb:{fr:' faits',en:' done'},
 pat6:{fr:'Pattern : ',en:'Pattern: '}
};
function T(k){return X(TX[k]);}

/* ───────── aide contextuelle : réglage global ───────── */
var HINT_ON=null;
function defiOn(){return ls('qx.defi')==='1';}
function aideOn(){var v=ls('qx.aide');return v==='1';}   /* R405 : décochée par défaut (Simon) ; elle se coche dans « ? » */
function setAide(on){ls('qx.aide',on?'1':'0');HINT_ON=on;if(on)bind();else{unbind();hideTip();}var c=$('qaOn');if(c)c.checked=!!on;}
var SEEN=J('qx.aide.vu',[]);
function seen(id){return SEEN.indexOf(id)>=0;}
function mark(id){if(!seen(id)){SEEN.push(id);ls('qx.aide.vu',JSON.stringify(SEEN));}}

/* table des astuces : id · sélecteur (le plus précis d'abord) · phrase · section du manuel */
var H=[
 /* Pattern */
 {p:'p',id:'dk-draw',s:'#qdock .dk[data-m="draw"]',a:'outils',fr:'Trait : dessine librement. Appui long : correction vectorielle.',en:'Stroke: draw freely. Long press: vector smoothing.'},
 {p:'p',id:'dk-line',s:'#qdock .dk[data-m="line"]',a:'outils',fr:'Droite : relie des points. Appui long : multi-points ou courbe de Bézier.',en:'Line: joins points. Long press: multi-point or Bézier curve.'},
 {p:'p',id:'dk-point',s:'#qdock .dk[data-m="point"]',a:'outils',fr:'Point : pose une note isolée.',en:'Dot: places a single note.'},
 {p:'p',id:'dk-form',s:'#qdock .dk[data-m="form"]',a:'outils',fr:'Rond : forme prête à jouer. Appui long : choisir la forme.',en:'Round: a ready-made shape. Long press: pick the shape.'},
 {p:'p',id:'dk-erase',s:'#qdock .dk[data-m="erase"]',a:'outils',fr:'Gomme : efface un trait. Avec une sélection, efface la sélection.',en:'Eraser: removes a stroke. With a selection, removes the selection.'},
 {p:'p',id:'dk-move',s:'#qdock .dk[data-m="move"]',a:'outils',fr:'Déplacer : glisse un trait. Appui long sur un trait : réglages par note.',en:'Move: drag a stroke. Long press on a stroke: per-note settings.'},
 {p:'p',id:'dk-dup',s:'#qdock .dk[data-m="dup"]',a:'outils',fr:'Dupliquer : copie le trait ou la sélection.',en:'Duplicate: copies the stroke or selection.'},
 {p:'p',id:'dk-tool',s:'#qdock .dk',a:'outils',fr:'Outil de dessin : touche pour l’activer, appui long pour ses options.',en:'Drawing tool: tap to activate, long press for its options.'},
 {p:'p',id:'field',s:'#field',a:'rapide',fr:'Dessine ici : la hauteur donne la note, une forme fermée tourne en boucle.',en:'Draw here: height sets the note, a closed shape loops.'},
 {p:'p',id:'layers',s:'#layers .lb',a:'instruments',fr:'Instrument : choisis la voix du prochain trait. Re-touche pour fermer son éditeur.',en:'Instrument: picks the voice of your next stroke. Tap again to close its editor.'},
 {p:'p',id:'play',s:'#bPlay',a:'lecture',fr:'Écouter : joue ta boucle. Touche encore pour arrêter.',en:'Listen: plays your loop. Tap again to stop.'},
 {p:'p',id:'rec',s:'#bRec',a:'lecture',fr:'Live : enregistre ce que tu entends en fichier audio.',en:'Live: records what you hear to an audio file.'},
 {p:'p',id:'undo',s:'#bUndo',a:'lecture',fr:'Annuler le dernier geste.',en:'Undo the last gesture.'},
 {p:'p',id:'redo',s:'#bRedo',a:'lecture',fr:'Refaire le geste annulé.',en:'Redo the undone gesture.'},
 {p:'p',id:'clear',s:'#bClear',a:'lecture',fr:'Vider le champ (tu peux annuler).',en:'Clears the field (you can undo).'},
 {p:'p',id:'cpu',s:'#cpuB',a:'lecture',fr:'Charge audio estimée : si elle monte trop, allège (moins d’effets).',en:'Estimated audio load: if it climbs, lighten up (fewer effects).'},
 {p:'p',id:'wave',s:'#qWave',a:'lecture',fr:'Visuel du son en direct. La flèche le replie.',en:'Live sound visual. The arrow folds it.'},
 {p:'p',id:'worlds',s:'#worlds .wb',a:'master',fr:'Monde : une ambiance (tempo, écho, espace). Re-touche pour la retirer.',en:'World: a mood (tempo, echo, space). Tap again to remove it.'},
 {p:'p',id:'knobs',s:'#knobs',a:'auto',fr:'Réglages d’ambiance : glisse. Appui long sur un curseur : automation.',en:'Mood settings: drag. Long press a slider: automation.'},
 {p:'p',id:'master',s:'#qMaster',a:'master',fr:'Master : le son d’ensemble (monde, écho, égaliseur…).',en:'Master: the overall sound (world, echo, EQ…).'},
 {p:'p',id:'lib',s:'#qLibBtn',a:'biblio',fr:'Capture cette boucle dans la bibliothèque de ton projet, pour la poser dans Track.',en:'Captures this loop into your project library, to place it in Track.'},
 {p:'p',id:'libmgr',s:'#qLibMgr',a:'biblio',fr:'Bibliothèque : tes patterns, tes tracks et les sons du jeu.',en:'Library: your patterns, tracks and the game sounds.'},
 {p:'p',id:'file',s:'#qFileBtn',a:'fichiers',fr:'Fichier : enregistrer, ouvrir, exporter.',en:'File: save, open, export.'},
 {p:'p',id:'toTrack',s:'#qFloat',a:'track',fr:'Track : assemble tes patterns en morceau. Tu peux aussi glisser l’écran de côté.',en:'Track: assemble your patterns into a piece. You can also swipe sideways.'},
 /* Track */
 {p:'t',id:'t-file',s:'#bFile',a:'fichiers',fr:'Fichier : enregistrer la track, ouvrir, exporter.',en:'File: save the track, open, export.'},
 {p:'t',id:'t-qt',s:'#bQt',a:'track',fr:'Retour à Pattern : ta boucle en cours t’attend.',en:'Back to Pattern: your loop is waiting.'},
 {p:'t',id:'t-tools',s:'#tools button',a:'track',fr:'Outils d’édition des blocs : poser, déplacer, couper.',en:'Block editing tools: place, move, cut.'},
 {p:'t',id:'t-undo',s:'#bUndo',a:'track',fr:'Annuler le dernier geste dans la track.',en:'Undo the last gesture in the track.'},
 {p:'t',id:'t-redo',s:'#bRedo',a:'track',fr:'Refaire le geste annulé.',en:'Redo the undone gesture.'},
 {p:'t',id:'t-snap',s:'#snap',a:'track',fr:'Aimant : cale les blocs sur la mesure ou le temps.',en:'Snap: aligns blocks to the bar or beat.'},
 {p:'t',id:'t-pat',s:'#patSel',a:'biblio',fr:'Choisis une pattern de ton projet à poser comme bloc.',en:'Pick a pattern from your project to place as a block.'},
 {p:'t',id:'t-add',s:'#bAdd',a:'track',fr:'Ajoute une piste.',en:'Adds a track.'},
 {p:'t',id:'t-rows',s:'#rows',a:'track',fr:'Pistes : glisse un bloc. Appui long sur un bloc : volume, effets, couper, dupliquer.',en:'Tracks: drag a block. Long press a block: volume, effects, cut, duplicate.'},
 {p:'t',id:'t-ruler',s:'#ruler',a:'track',fr:'Règle : touche pour placer la tête de lecture ; deux curseurs bornent la boucle.',en:'Ruler: tap to place the playhead; two handles bound the loop.'},
 {p:'t',id:'t-play',s:'#bPlay',a:'track',fr:'Lecture de la track.',en:'Plays the track.'},
 {p:'t',id:'t-loop',s:'#bLoop',a:'track',fr:'Boucle : rejoue du début à la fin des blocs.',en:'Loop: replays from start to the end of the blocks.'},
 {p:'t',id:'t-bpm',s:'.mini',a:'track',fr:'Tempo de la track.',en:'Track tempo.'}
];
var HP=H.filter(function(h){return h.p===(TRK?'t':'p');});
function findHint(el){if(!el||!el.closest)return null;for(var i=0;i<HP.length;i++){var h=HP[i];try{if(el.closest(h.s))return h;}catch(e){}}return null;}

/* ───────── pastille ───────── */
var TIP=null,TT=0,TH=0,CSS=false;
function css(){if(CSS)return;CSS=true;var s=document.createElement('style');s.id='qaCss';s.textContent=
 '#qaTip{position:fixed;z-index:99990;max-width:248px;padding:8px 10px;border-radius:12px;background:#0b111b;color:#cfe3f7;box-shadow:0 0 0 1px #243248,0 10px 28px rgba(0,0,0,.55);font:500 12px/1.35 var(--ui,system-ui,sans-serif);pointer-events:none;animation:qaIn .16s ease-out}'+
 '#qaTip a{display:inline-block;margin-top:5px;padding:3px 9px;border-radius:99px;border:1px solid #6EE2FF;color:#6EE2FF;font:600 10px/1.4 var(--mono,monospace);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;pointer-events:auto;cursor:pointer}'+
 '@keyframes qaIn{from{opacity:0;transform:translateY(3px)}}'+
 '#bAtelier{height:26px;min-height:26px;width:26px;min-width:26px;padding:0;margin:0 0 0 -4px;border-radius:999px;border:1px solid #243248;background:rgba(255,255,255,.03);color:#9db0cc;display:inline-flex;align-items:center;justify-content:center;flex:none;cursor:pointer;box-shadow:none}'+
 '#bAtelier svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}#bAtelier.qa-new{color:#6EE2FF;border-color:#6EE2FF}'+
 '#qaMsg{position:fixed;left:50%;bottom:calc(76px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:99970;max-width:86vw;padding:9px 14px;border-radius:99px;background:#0b111b;color:#EAF6FF;box-shadow:0 0 0 1px #6EE2FF,0 8px 24px rgba(0,0,0,.5);font:600 12px/1.3 var(--ui,system-ui,sans-serif);pointer-events:none;text-align:center;animation:qaIn .2s ease-out}'+
 '#qaEx{position:absolute;left:50%;bottom:14px;transform:translateX(-50%);z-index:5;height:32px;padding:0 14px;border-radius:99px;border:1px solid #6EE2FF;background:rgba(10,16,26,.82);color:#EAF6FF;font:600 11px/1 var(--mono,monospace);letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;cursor:pointer;touch-action:manipulation}'+
 '#qaAt{position:fixed;left:0;right:0;bottom:0;z-index:99980;max-height:62vh;overflow:auto;-webkit-overflow-scrolling:touch;padding:12px 14px calc(14px + env(safe-area-inset-bottom,0px));border-radius:18px 18px 0 0;background:#070b13;box-shadow:0 0 0 1px #243248,0 -14px 40px rgba(0,0,0,.6);color:#cfe3f7;font:400 13px/1.4 var(--ui,system-ui,sans-serif);animation:qaUp .2s ease-out}@keyframes qaUp{from{transform:translateY(24px);opacity:0}}'+
 '#qaAt .qa-h{display:flex;align-items:center;gap:10px}#qaAt .qa-h b{font:600 12px var(--mono,monospace);letter-spacing:.2em;text-transform:uppercase;color:#EAF6FF}#qaAt .qa-h em{font:500 11px var(--mono,monospace);color:#6EE2FF;font-style:normal;flex:1}'+
 '#qaAt button,#qaBar button{min-height:30px;padding:0 12px;border-radius:99px;border:1px solid #243248;background:rgba(255,255,255,.03);color:#9db0cc;font:600 10px/1 var(--mono,monospace);letter-spacing:.1em;text-transform:uppercase;cursor:pointer}'+
 '#qaAt .qa-sub{margin:6px 0 8px;font-size:12px;color:#8ea3bf}#qaAt ol{list-style:none;margin:0;padding:0;display:grid;gap:8px}'+
 '#qaAt li{display:flex;gap:10px;padding:9px 10px;border-radius:12px;background:rgba(255,255,255,.03);box-shadow:inset 0 0 0 1px #1a2433}#qaAt li.done{box-shadow:inset 0 0 0 1px rgba(110,226,255,.5)}#qaAt li.skip{opacity:.65}#qaAt li.ail{opacity:.8}'+
 '#qaAt .n{flex:none;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:1px solid #33455f;font:600 11px var(--mono,monospace);color:#9db0cc}#qaAt li.done .n{background:#6EE2FF;border-color:#6EE2FF;color:#05070d}'+
 '#qaAt .t{font-weight:600;color:#EAF6FF}#qaAt .g{display:block;color:#a9bdd6;margin-top:1px}#qaAt .ih[hidden]{display:none}#qaAt .ih{display:block;margin-top:5px;padding:6px 8px;border-radius:8px;background:rgba(110,226,255,.07);color:#cfe3f7;font-size:12px}'+
 '#qaAt .bb{display:flex;flex-wrap:wrap;gap:6px;margin-top:7px}#qaAt h5{margin:12px 0 6px;font:600 10px var(--mono,monospace);letter-spacing:.16em;text-transform:uppercase;color:#8ea3bf}#qaAt .qa-f{display:flex;gap:8px;margin-top:12px}'+
 '#qaBar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;padding:6px 14px;border-bottom:1px solid #1a2433;background:#0a1018;flex:none;color:#cfe3f7;font:500 12px var(--ui,system-ui,sans-serif)}#qaBar label{display:inline-flex;align-items:center;gap:7px;min-height:30px}#qaBar input{width:18px;height:18px;accent-color:#6EE2FF}#qaBar .ex{display:flex;flex-wrap:nowrap;overflow-x:auto;-webkit-overflow-scrolling:touch;gap:6px;align-items:center;width:100%;padding-bottom:2px}#qaBar .ex button,#qaBar .ex span{flex:none}#qaBar .ex span{font-size:11px;color:#8ea3bf}#qaBar button{padding:0 9px;letter-spacing:.06em}#qaBar label{min-height:28px;font-size:11px}';
 document.head.appendChild(s);}
function hideTip(){clearTimeout(TT);clearTimeout(TH);if(TIP){TIP.remove();TIP=null;}}
function manual(a){var o=$('qHelpOv'),b=$('bHelp');if(!o&&b)b.click();setTimeout(function(){var f=document.querySelector('#qHelpOv iframe');if(f)f.src='manuel.html'+(a?'#'+a:'');},0);}
function showTip(h,el,pt){if(!aideOn()||seen(h.id)||$('qHelpOv')||$('qaAt'))return;css();hideTip();mark(h.id);
 var d=document.createElement('div');d.id='qaTip';d.setAttribute('role','status');d.innerHTML=esc(X(h))+'<br><a href="manuel.html#'+h.a+'" data-a="'+h.a+'">'+esc(T('man'))+'</a>';
 d.querySelector('a').addEventListener('click',function(e){e.preventDefault();hideTip();manual(h.a);});
 document.body.appendChild(d);TIP=d;
 var r=el.getBoundingClientRect(),w=d.offsetWidth,hh=d.offsetHeight,vw=innerWidth,vh=innerHeight,x,y;
 if(r.height>260){x=(pt&&pt.x!=null?pt.x:r.left+r.width/2)-w/2;y=Math.max(8,r.top+10);}   /* grande zone (champ, pistes) : pastille en haut de la zone */
 else{x=r.left+r.width/2-w/2;y=(vh-r.bottom>hh+14)?r.bottom+8:Math.max(8,r.top-hh-8);}
 d.style.left=Math.max(8,Math.min(vw-w-8,x))+'px';d.style.top=Math.max(8,Math.min(vh-hh-8,y))+'px';
 TT=setTimeout(hideTip,5200);}
/* écouteurs passifs : on ne capte, ne retarde et n'annule aucun geste */
function onDown(e){if(!HINT_ON)return;var t=e.target;if(TIP&&t&&t.closest&&!t.closest('#qaTip'))hideTip();var h=findHint(t);if(h&&!seen(h.id)){var el=t.closest(h.s);showTip(h,el,{x:e.clientX,y:e.clientY});}}
function onOver(e){if(!HINT_ON||e.pointerType!=='mouse')return;var t=e.target,h=findHint(t);clearTimeout(TH);if(h&&!seen(h.id)){TH=setTimeout(function(){showTip(h,t.closest(h.s),null);},450);}}
var BND=false;
function bind(){if(BND)return;BND=true;document.addEventListener('pointerdown',onDown,{capture:true,passive:true});document.addEventListener('pointerover',onOver,{capture:true,passive:true});}
function unbind(){if(!BND)return;BND=false;document.removeEventListener('pointerdown',onDown,{capture:true});document.removeEventListener('pointerover',onOver,{capture:true});}

/* ───────── petit message ───────── */
var MT=0;function msg(m,ms){css();var o=$('qaMsg');if(!o){o=document.createElement('div');o.id='qaMsg';o.setAttribute('role','status');document.body.appendChild(o);}o.textContent=m;clearTimeout(MT);MT=setTimeout(function(){var q=$('qaMsg');if(q)q.remove();},ms||3400);}

/* ───────── exemples (Pattern) : boucles au format .qx existant, synthèse intégrée du jeu, aucun audio embarqué ───────── */
function blob(cx,cy,rx,ry,a,ph,lay,n){var p=[],i,t,r;for(i=0;i<=n;i++){t=i/n*6.2832;r=1+a[0]*Math.cos(2*t+ph)+a[1]*Math.sin(3*t+ph*1.7);p.push([+(cx+rx*r*Math.cos(t)).toFixed(3),+(cy+ry*r*Math.sin(t)).toFixed(3)]);}p[n]=p[0].slice();return {l:lay,p:p};}
function wave(y0,amp,cyc,ph,lay,n,x0,x1){var p=[],i;for(i=0;i<=n;i++){p.push([+(x0+(x1-x0)*i/n).toFixed(3),+(y0+amp*Math.sin(i/n*6.2832*cyc+ph)).toFixed(3)]);}return {l:lay,p:p};}
var K0={tempo:80,echo:0,rev:0,breath:0,clar:.45,drone:0,grain:0,swing:0};
function dmr(o){var r=[],i;for(i=0;i<14;i++)r.push(o[i]?{on:o[i]}:undefined);return r;}
var DM_HH=dmr({0:[2,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0],1:[0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0],3:[1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0]});   /* hip-hop lent */
var DM_4=dmr({0:[2,0,0,0,2,0,0,0,2,0,0,0,2,0,0,0],1:[0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0],3:[0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0]});   /* quatre temps */
var EXS={
 neutre:{n:{fr:'Boucle neutre',en:'Neutral loop'},w:-1,root:4,scale:'pm',k:K0,D:DM_HH,S:function(){return [blob(.42,.4,.22,.16,[.1,.06],.6,0,48),blob(.55,.72,.3,.08,[.06,.04],1.4,1,40),wave(.9,.03,2,.4,4,36,.02,.98)];}},
 atelier:{n:{fr:'Atelier',en:'Workshop'},w:0,root:4,scale:'pm',D:DM_HH,k:{tempo:80,echo:.22,rev:.3,breath:.12,clar:.45,drone:.12,grain:.05,swing:.1},S:function(){return [blob(.4,.38,.22,.15,[.12,.07],.6,0,52),blob(.6,.62,.22,.13,[.1,.06],2.1,2,40),blob(.5,.8,.3,.07,[.05,.03],.8,1,36),wave(.92,.03,2,.4,4,36,.02,.98)];}},
 fonderie:{n:{fr:'Fonderie',en:'Foundry'},w:1,root:9,scale:'dor',D:DM_4,k:{tempo:62,echo:.2,rev:.25,breath:.15,clar:.3,drone:.15,grain:.1,swing:.2},S:function(){return [blob(.5,.74,.32,.1,[.08,.05],.3,1,44),blob(.4,.4,.18,.13,[.14,.05],1.9,3,44),wave(.92,.04,3,0,4,40,.02,.98)];}},
 chaine:{n:{fr:'Chaîne',en:'Chain'},w:2,root:7,scale:'pM',D:DM_HH,k:{tempo:84,echo:.3,rev:.3,breath:.12,clar:.55,drone:.1,grain:.05,swing:.05},S:function(){return [blob(.3,.42,.14,.12,[.1,.08],.2,0,40),blob(.7,.34,.14,.12,[.1,.08],1.7,0,40),blob(.5,.66,.26,.12,[.1,.05],2.6,2,44),wave(.92,.03,4,.2,4,40,.02,.98)];}},
 glacier:{n:{fr:'Glacier',en:'Glacier'},w:3,root:4,scale:'q',k:{tempo:56,echo:.3,rev:.5,breath:.1,clar:.65,drone:.1,grain:.03,swing:.1},S:function(){return [blob(.4,.34,.2,.14,[.06,.04],.5,7,44),blob(.58,.64,.26,.13,[.08,.05],2.2,2,44)];}}
};
var EXO=['neutre','atelier','fonderie','chaine','glacier'];
function exQx(id){var e=EXS[id];if(!e)return null;var st=window.QUANTONE&&QUANTONE.state;
 return {q:'quantix-qx',v:1,app:'Quantone',date:new Date().toISOString(),lang:FR()?'fr':'en',info:{world:Math.max(0,e.w),scale:e.scale,root:e.root,tempo:e.k.tempo,strokes:e.S().length,samples:0},
  preset:(function(){var p={quantone:1,world:Math.max(0,e.w),amb:e.w,wm:{},root:e.root,scale:e.scale,k:e.k,strokes:e.S()};if(e.D)p.dm={len:16,rows:e.D};return p;})(),samples:[]};}
function isEmpty(){try{return !!(window.QUANTONE&&QUANTONE.empty&&QUANTONE.empty());}catch(e){return true;}}
function loadEx(id,force){if(TRK||!window.QXIO)return false;if(!isEmpty()&&!force)return false;var j=exQx(id);if(!j)return false;var ok=false;try{ok=QXIO.open(j);}catch(e){ok=false;}if(ok){EXSIG=sig();mark('ex-'+id);msg(T('exMsg'));var p=$('qaEx');if(p)p.style.display='none';}return ok;}
function mountExPill(){if(TRK||$('qaEx'))return;var f=$('field');if(!f)return;css();var b=document.createElement('button');b.id='qaEx';b.type='button';b.textContent=T('ex');b.onclick=function(){loadEx('neutre');};f.appendChild(b);
 /* R437 : la proposition « Écouter un exemple » s'efface d'elle-même 3 s après son apparition (et revient si le champ se vide à nouveau) */
 var shownAt=0;
 setInterval(function(){var q=$('qaEx');if(!q)return;if(document.hidden)return;q.textContent=T('ex');var em=isEmpty();
  if(!em){shownAt=0;q.style.display='none';return;}
  if(!shownAt)shownAt=Date.now();q.style.display=Date.now()-shownAt>3000?'none':'';},300);}

/* ───────── Atelier : défis détectés en lecture seule ───────── */
function PS(){return window.QUANTONE&&QUANTONE.state?QUANTONE.state:null;}
function closed(s){var q=s.pts;if(!q||q.length<8)return false;var a=q[0],b=q[q.length-1];return Math.hypot(a[0]-b[0],a[1]-b[1])<.09;}
function lay(S,l){return S.strokes.filter(function(s){return (s.layer|0)===l&&s.pts&&s.pts.length>1;});}
var CH=[
 {id:'c0',n:0,pg:'p',t:{fr:'Premier son',en:'First sound'},g:{fr:'Fais une forme fermée qui tourne en boucle.',en:'Draw a closed shape that loops.'},h:{fr:'Dessine avec le doigt dans le champ, puis reviens à ton point de départ pour fermer la forme. Touche Écouter.',en:'Draw in the field, then come back to your start point to close the shape. Press Listen.'},a:'rapide',
  ok:function(S){return S.strokes.some(function(s){return (s.layer|0)!==4&&closed(s);});}},
 {id:'c1',n:1,pg:'p',t:{fr:'Deux voix',en:'Two voices'},g:{fr:'Pose une basse sous ta mélodie.',en:'Put a bass under your melody.'},h:{fr:'Touche la carte Bass, dessine bas dans le champ ; haut = aigu, bas = grave. Garde ta première forme.',en:'Tap the Bass card, draw low in the field; high = high pitch, low = low pitch. Keep your first shape.'},a:'instruments',
  ok:function(S){var b=lay(S,1).length>0,o=S.strokes.some(function(s){var l=s.layer|0;return l!==1&&l!==4&&s.pts.length>1;});return b&&o;}},
 {id:'c2',n:2,pg:'p',t:{fr:'Le rythme',en:'The beat'},g:{fr:'Choisis un motif Hip-hop, change 3 pas.',en:'Pick a Hip-hop pattern, change 3 steps.'},h:{fr:'Touche la carte Drums, trace une ligne en bas : la boîte à rythmes s’active. Choisis le motif, puis touche des pas pour les changer.',en:'Tap the Drums card and draw a line low down: the drum machine wakes up. Pick the pattern, then tap steps to change them.'},a:'instruments',
  ok:function(S){var n=lay(S,4).length>0,on=false;try{on=!!(window.dmAny&&window.dmAny());}catch(e){}return n&&on;}},
 {id:'c3',n:3,pg:'p',t:{fr:'La couleur',en:'The colour'},g:{fr:'Rends ta boucle sombre, puis lumineuse.',en:'Make your loop dark, then bright.'},h:{fr:'Choisis une gamme (pentatonique mineure est douce), touche un monde (Atelier, Fonderie…) et ajoute un peu d’écho.',en:'Pick a scale (minor pentatonic is gentle), tap a world (Workshop, Foundry…) and add a little echo.'},a:'gamme',
  ok:function(S){return S.scale&&S.scale!=='none'&&(S.amb|0)>=0&&S.k&&(S.k.echo>0||S.k.rev>0);}},
 {id:'c4',n:4,pg:'p',t:{fr:'Le mouvement',en:'Movement'},g:{fr:'Fais monter le filtre pendant 4 boucles.',en:'Raise the filter over 4 loops.'},h:{fr:'Appui long sur un curseur (par exemple Clarté) : ouvre l’automation, dessine une courbe sur 4 boucles, active-la.',en:'Long press a slider (for example Clarity): opens automation. Draw a curve over 4 loops and turn it on.'},a:'auto',
  ok:function(){var A=window.QAUTO&&QAUTO.AUT;if(!A)return false;return Object.keys(A).some(function(k){var a=A[k];return a&&a.on&&(a.len||1)>=2;});}},
 {id:'c5',n:5,pg:'p',t:{fr:'Garder et partager',en:'Keep and share'},g:{fr:'Enregistre ta boucle et exporte-la.',en:'Save your loop and export it.'},h:{fr:'Fichier › Enregistrer ce pattern (donne un nom), puis Fichier › Exporter l’audio (WAV ou MP3), ou ● Live.',en:'File › Save this pattern (give it a name), then File › Export audio (WAV or MP3), or ● Live.'},a:'fichiers',
  ok:function(){var s=false,e=false;try{s=!!(window.QPATFILE&&QPATFILE.edit&&QPATFILE.edit().id);}catch(x){}try{e=!!(window.QEXPORT&&QEXPORT.opt&&QEXPORT.opt.last);}catch(x){}try{if(window.QEXP&&QEXP.last)e=true;}catch(x){}return s||e;}},
 {id:'c6',n:6,pg:'t',t:{fr:'Le morceau',en:'The track'},g:{fr:'Un morceau de 4 blocs.',en:'A track of 4 blocks.'},h:{fr:'Dans Pattern, touche l’icône ≡＋ pour capturer ta boucle, puis dans Track choisis-la dans « Pattern… » et pose-la plusieurs fois. Appui long sur un bloc : couper.',en:'In Pattern, tap the ≡＋ icon to capture your loop, then in Track pick it in “Pattern…” and place it several times. Long press a block to cut.'},a:'track',
  ok:function(P){return P.clips&&P.clips.length>=3;}}
];
var BO=[
 {id:'b0',pg:'p',t:{fr:'Notes d’un trait',en:'Stroke notes'},g:{fr:'Change la vélocité de quelques notes.',en:'Change the velocity of a few notes.'},h:{fr:'Outil Déplacer, appui long sur un trait : feuille « Notes du trait ».',en:'Move tool, long press a stroke: the “Stroke notes” sheet.'},a:'outils',
  ok:function(S){return S.strokes.some(function(s){return s.nt&&Object.keys(s.nt).length;});}},
 {id:'b1',pg:'p',t:{fr:'Enveloppe d’une voix',en:'Voice envelope'},g:{fr:'Adoucis l’attaque d’une voix de batterie.',en:'Soften the attack of a drum voice.'},h:{fr:'Dans Drums, appui long sur une voix : fenêtre d’enveloppe, glisse le point A.',en:'In Drums, long press a voice: envelope window, drag point A.'},a:'instruments',
  ok:function(S){return !!(S.dm&&S.dm.rows&&S.dm.rows.some(function(r){return r.atk>0;}));}},
 {id:'b2',pg:'p',t:{fr:'Ton propre son',en:'Your own sound'},g:{fr:'Mets un son dans le Sampler.',en:'Put a sound in the Sampler.'},h:{fr:'Carte Sampler : Importer, ● Enregistrer au micro, ou la Banque de sons.',en:'Sampler card: Import, ● Record with the mic, or the Sound bank.'},a:'instruments',
  ok:function(){var M=window.QSMP&&QSMP.SMP;return !!M&&Object.keys(M).some(function(k){return M[k]&&M[k].d;});}},
 {id:'b3',pg:'p',t:{fr:'Recette du monde 1',en:'World 1 recipe'},g:{fr:'Recrée l’ambiance Atelier du jeu.',en:'Recreate the game’s Workshop mood.'},h:{fr:'Master › Fonctions › « Recette du monde 1 (Atelier) » règle tout d’un coup.',en:'Master › Functions › “World 1 recipe (Workshop)” sets everything at once.'},a:'master',
  ok:function(S){var e=S.eq;return !!e&&e.hp===1&&e.lo===-1&&e.mid===0&&e.hi===-3&&S.amb===0&&S.world===0;}}
];
var ALL=CH.concat(BO),EXSIG=null;
function sig(){try{return JSON.stringify(QUANTONE.preset());}catch(e){return null;}}
function prog(){return J('qx.atelier',{});}
function save(p){ls('qx.atelier',JSON.stringify(p));}
function stateOf(c){var p=prog()[c.id];return p&&p.d?'done':p&&p.s?'skip':'';}
function readState(c){return c.pg==='t'?(window.MORCEAU&&MORCEAU.P?MORCEAU.P():null):PS();}
function scan(){var p=prog(),ch=false,fresh=[],pgk=TRK?'t':'p';
 if(EXSIG){if(sig()===EXSIG)return [];EXSIG=null;}   /* un exemple intact ne coche rien : seuls tes changements comptent */
 ALL.forEach(function(c){if(c.pg!==pgk||(p[c.id]&&p[c.id].d))return;var S=null;try{S=readState(c);}catch(e){}if(!S)return;var ok=false;try{ok=!!c.ok(S);}catch(e){ok=false;}if(ok){p[c.id]={d:1,t:Date.now()};ch=true;fresh.push(c);}});
 if(ch){save(p);if(ls('qx.atelier.vu')==='1'&&fresh.length)msg(T('bravo')+X(fresh[0].t));badge();if($('qaAt'))renderAt();}
 return fresh.map(function(c){return c.id;});}
function badge(){var b=$('bAtelier');if(!b)return;var n=CH.filter(function(c){return stateOf(c)==='done';}).length;b.title=T('atelier')+' · '+n+' / '+CH.length;b.setAttribute('aria-label',b.title);}
function itemHtml(c,bonus){var s=stateOf(c),ail=(!bonus&&c.pg!==(TRK?'t':'p'))||(bonus&&c.pg!==(TRK?'t':'p'));
 var n=s==='done'?'✓':s==='skip'?'➜':(bonus?'★':String(c.n)),b='';
 if(ail)return '<li class="ail'+(s?' '+s:'')+'" data-id="'+c.id+'"><span class="n">'+n+'</span><div><span class="t">'+esc(X(c.t))+'</span><span class="g">'+esc(X(c.g))+' · '+esc(T(c.pg==='t'?'ailleursT':'ailleursP'))+(s==='done'?' · '+T('fait'):s==='skip'?' · '+T('passe'):'')+'</span></div></li>';
 if(s!=='done'){b+='<button type="button" data-a="hint">'+esc(T('indice'))+'</button>';b+=s==='skip'?'<button type="button" data-a="back">'+esc(T('reprendre'))+'</button>':'<button type="button" data-a="skip">'+esc(T('passer'))+'</button>';}
 b+='<button type="button" data-a="man" data-s="'+c.a+'">'+esc(T('man'))+'</button>';
 return '<li class="'+s+'" data-id="'+c.id+'"><span class="n">'+n+'</span><div><span class="t">'+esc(X(c.t))+'</span><span class="g">'+esc(X(c.g))+'</span><span class="ih" hidden>'+esc(X(c.h))+'</span><div class="bb">'+b+'</div></div></li>';}
var OPEN_H={};
function renderAt(){var o=$('qaAt');if(!o)return;var p=prog(),n=CH.filter(function(c){return stateOf(c)==='done';}).length,hs={};[].forEach.call(o.querySelectorAll('li'),function(li){var h=li.querySelector('.ih');if(h&&!h.hidden)hs[li.dataset.id]=1;});
 var sk=CH.filter(function(c){return stateOf(c)==='skip';}).length;
 o.innerHTML='<div class="qa-h"><b>'+esc(T('atelier'))+'</b><em>'+n+' / '+CH.length+esc(T('nb'))+(sk?' · '+sk+' '+esc(T('passe')):'')+'</em><button type="button" id="qaX">'+esc(T('fermer'))+'</button></div><p class="qa-sub">'+esc(T('facultatif'))+'</p>'+
  '<ol>'+CH.map(function(c){return itemHtml(c,false);}).join('')+'</ol><h5>'+esc(T('bonus'))+'</h5><ol>'+BO.map(function(c){return itemHtml(c,true);}).join('')+'</ol>'+
  '<div class="qa-f"><button type="button" id="qaRst">'+esc(T('reset'))+'</button><button type="button" id="qaMan" data-s="apprendre">'+esc(T('man'))+'</button></div>';
 [].forEach.call(o.querySelectorAll('li'),function(li){if(hs[li.dataset.id]){var h=li.querySelector('.ih');if(h)h.hidden=false;}});}
function openAt(){css();if($('qaAt'))return;hideTip();var o=document.createElement('div');o.id='qaAt';o.setAttribute('role','dialog');o.setAttribute('aria-label',T('atelier'));document.body.appendChild(o);ls('qx.atelier.vu','1');scan();renderAt();
 o.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button');if(!b)return;
  if(b.id==='qaX'){closeAt();return;}
  if(b.id==='qaMan'){closeAt();manual('apprendre');return;}
  if(b.id==='qaRst'){if(b.dataset.arm){ls('qx.atelier',null);ls('qx.atelier.vu',null);renderAt();badge();return;}b.dataset.arm='1';b.textContent=T('sur');setTimeout(function(){if(b.isConnected){delete b.dataset.arm;b.textContent=T('reset');}},3000);return;}
  var li=b.closest('li'),id=li&&li.dataset.id,c=ALL.filter(function(x){return x.id===id;})[0];if(!c)return;
  if(b.dataset.a==='hint'){var h=li.querySelector('.ih');h.hidden=!h.hidden;}
  else if(b.dataset.a==='skip'){var p=prog();p[id]={s:1};save(p);renderAt();badge();}
  else if(b.dataset.a==='back'){var p2=prog();delete p2[id];save(p2);renderAt();badge();}
  else if(b.dataset.a==='man'){closeAt();manual(c.a);}});}
function closeAt(){var o=$('qaAt');if(o)o.remove();}
function toggleAt(){if($('qaAt'))closeAt();else openAt();}

/* ───────── extension du panneau « ? » (R399) : réglage, « Revoir les astuces », Atelier, exemples ───────── */
function extendHelp(o){if(!o||$('qaBar'))return;css();var hb=o.querySelector('.hb');if(!hb)return;var bar=document.createElement('div');bar.id='qaBar';
 bar.innerHTML='<label><input type="checkbox" id="qaOn"'+(aideOn()?' checked':'')+'> '+esc(T('aide'))+'</label><button type="button" id="qaRev">'+esc(T('revoir'))+'</button><label><input type="checkbox" id="qaDf"'+(defiOn()?' checked':'')+'> '+esc(T('defis'))+'</label><button type="button" id="qaAtl">'+esc(T('atelier'))+'</button>'+
  (TRK?'':'<div class="ex"><span>'+esc(T('exs'))+' :</span>'+EXO.map(function(id){return '<button type="button" data-ex="'+id+'">'+esc(X(EXS[id].n))+'</button>';}).join('')+'</div>');
 hb.parentNode.insertBefore(bar,hb.nextSibling);
 bar.querySelector('#qaDf').onchange=function(){ls('qx.defi',this.checked?'1':'0');var b=$('bAtelier');if(b)b.style.display=this.checked?'':'none';};
 bar.querySelector('#qaOn').onchange=function(){setAide(this.checked);};
 bar.querySelector('#qaRev').onclick=function(){SEEN=[];ls('qx.aide.vu',JSON.stringify(SEEN));setAide(true);var c=$('qaOn');if(c)c.checked=true;msg(T('revu'));};
 bar.querySelector('#qaAtl').onclick=function(){if(window.QHELP)QHELP.close();openAt();};
 [].forEach.call(bar.querySelectorAll('[data-ex]'),function(b){b.onclick=function(){var id=b.dataset.ex;
  if(!isEmpty()&&!b.dataset.arm){b.dataset.arm='1';b.textContent=T('exRep');setTimeout(function(){if(b.isConnected){delete b.dataset.arm;b.textContent=X(EXS[id].n);}},3000);return;}
  if(window.QHELP)QHELP.close();loadEx(id,true);};});}

/* ───────── amorçage ───────── */
function addBtn(){var h=$('bHelp');if(!h||$('bAtelier'))return !!$('bAtelier');css();var b=document.createElement('button');b.id='bAtelier';b.type='button';b.title=T('atelier');b.setAttribute('aria-label',T('atelier'));
 b.innerHTML='<svg viewBox="0 0 24 24"><path d="M4.5 7.5l2 2 3-3.4M4.5 14.5l2 2 3-3.4M13 8h7M13 15h7"/></svg>';b.onclick=toggleAt;if(!defiOn())b.style.display='none';h.parentNode.insertBefore(b,h.nextSibling);badge();return true;}
var n0=0,iv=setInterval(function(){if(addBtn()||++n0>100)clearInterval(iv);if(n0>100||$('bAtelier')){clearInterval(iv);}},120);
try{new MutationObserver(function(m){for(var i=0;i<m.length;i++)for(var j=0;j<m[i].addedNodes.length;j++){var x=m[i].addedNodes[j];if(x.id==='qHelpOv')extendHelp(x);}}).observe(document.body,{childList:true});}catch(e){}
HINT_ON=aideOn();if(HINT_ON)bind();
if(!TRK){var n1=0,i1=setInterval(function(){if($('field')){clearInterval(i1);mountExPill();}else if(++n1>100)clearInterval(i1);},150);}
setInterval(function(){if(document.hidden)return;try{scan();}catch(e){}},1800);
window.QAIDE={on:aideOn,set:setAide,seen:function(){return SEEN.slice();},resetSeen:function(){SEEN=[];ls('qx.aide.vu',JSON.stringify(SEEN));},tip:function(id){var h=HP.filter(function(x){return x.id===id;})[0];if(!h)return false;var el=null;try{el=document.querySelector(h.s);}catch(e){}if(!el)return false;showTip(h,el,null);return !!TIP;},
 hints:function(){return HP.map(function(h){return {id:h.id,s:h.s,a:h.a,ok:!!document.querySelector(h.s)};});},
 example:loadEx,examples:EXO.slice(),open:openAt,close:closeAt,scan:scan,progress:prog,challenges:function(){return CH.map(function(c){return c.id;});},bonus:function(){return BO.map(function(c){return c.id;});},manual:manual};
})();
