/* QDIAG (R429) — panneau de diagnostic de performance, visible par-dessus la wave (y compris plein écran).
   Mesure ce que fait RÉELLEMENT l'appareil : cadence d'écran, blocages du fil principal, coût de la wave, horloge audio, mémoire si disponible.
   Bouton « Copier » : le rapport texte à coller dans le chat. Activé par Wave → Perf → « Diagnostic », mémorisé (qx.diag). */
(function(){
var on=false,box=null,pre=null,raf=0,tm=0,fr=[],lag=[],lastR=0,lastT=0,t0=0,a0=null,snap='',meas=0,ren='';
function now(){return performance.now();}
function st(a){if(!a.length)return {n:0,avg:0,p95:0,max:0};var b=a.slice().sort(function(x,y){return x-y}),s=0,i;for(i=0;i<a.length;i++)s+=a[i];return {n:a.length,avg:s/a.length,p95:b[Math.min(b.length-1,Math.floor(b.length*.95))],max:b[b.length-1]};}
function glr(){if(ren)return ren;try{var c=document.createElement('canvas'),g=c.getContext('webgl'),e=g&&g.getExtension('WEBGL_debug_renderer_info');ren=e?String(g.getParameter(e.UNMASKED_RENDERER_WEBGL)):(g?'WebGL (nom masqué)':'aucun WebGL');}catch(e){ren='?';}return ren;}
function ctx(){try{return window.QUANTONE&&QUANTONE.ctx&&QUANTONE.ctx();}catch(e){return null;}}
function build(){return window.QBUILD||'?';}
function lines(){
 var f=st(fr),l=st(lag),Q=window.QWV,A=window.QWAVE,c=ctx(),o=[],fps=f.avg?1000/f.avg:0,drop=fr.filter(function(x){return x>50;}).length;
 o.push('QUANTONE '+build()+' · '+new Date().toLocaleTimeString());
 o.push('ÉCRAN  '+fps.toFixed(0)+' i/s · image moy '+f.avg.toFixed(1)+' ms · p95 '+f.p95.toFixed(0)+' · max '+f.max.toFixed(0)+' ms · >50 ms: '+drop+'/'+f.n);
 o.push('BLOCAGES fil principal: moy '+l.avg.toFixed(1)+' ms · p95 '+l.p95.toFixed(0)+' · max '+l.max.toFixed(0)+' ms');
 if(Q){var cv=document.getElementById('qWave');o.push('WAVE   rendu '+(A&&A.get('rd'))+' · qualité '+(A&&A.get('q'))+' · '+(Q.fps?Q.fps():0)+' i/s · calcul '+(Q.cost?Q.cost().toFixed(1):'?')+' ms · charge '+(Q.pf?Math.round(Q.pf()*100):'?')+'% · GL×'+(Q.sc?Q.sc().toFixed(2):'?')+(Q.gl&&Q.gl()===false?' (sans WebGL)':''));
  if(cv)o.push('        canvas '+cv.width+'×'+cv.height+' px (affiché '+cv.clientWidth+'×'+cv.clientHeight+')');}
 if(c){var dr='';if(a0&&c.state==='running'){var da=(c.currentTime-a0[0])*1000,dp=now()-a0[1];if(dp>2000)dr=' · horloge audio/réelle '+(da/dp).toFixed(3);}
  o.push('AUDIO  '+c.state+' · '+c.sampleRate+' Hz · latence base '+((c.baseLatency||0)*1000).toFixed(0)+' ms · sortie '+((c.outputLatency||0)*1000).toFixed(0)+' ms'+dr);}
 else o.push('AUDIO  (pas encore démarré)');
 var pm=performance.memory;o.push('SYSTÈME '+(navigator.hardwareConcurrency||'?')+' cœurs · RAM '+(navigator.deviceMemory?navigator.deviceMemory+' Go':'n/d')+(pm?' · JS '+(pm.usedJSHeapSize/1048576).toFixed(0)+'/'+(pm.jsHeapSizeLimit/1048576).toFixed(0)+' Mo':' · mémoire JS n/d (Safari)')+' · DPR '+window.devicePixelRatio+' · fenêtre '+innerWidth+'×'+innerHeight);
 o.push('GPU    '+glr());
 o.push('NAVIG. '+(navigator.userAgent.match(/(iPhone OS|CPU OS|Android|Chrome|Version)[ /][\d_.]+/g)||[navigator.userAgent.slice(0,50)]).join(' ')+(document.hidden?' · MASQUÉ':''));
 if(snap)o.push('','— '+snap);
 return o;}
function paint(){if(!pre)return;pre.textContent=lines().join('\n');}
function tick(t){raf=requestAnimationFrame(tick);if(lastR){fr.push(t-lastR);if(fr.length>300)fr.shift();}lastR=t;}
function lg(){var n=now();if(lastT){lag.push(Math.max(0,n-lastT-100));if(lag.length>100)lag.shift();}lastT=n;var c=ctx();if(c&&c.state==='running'){if(!a0||a0[2]!==c)a0=[c.currentTime,n,c];}paint();}
function copy(){var tx=lines().join('\n'),ok=false;try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(tx);ok=true;}}catch(e){}
 if(!ok){try{var ta=document.createElement('textarea');ta.value=tx;ta.style.cssText='position:fixed;left:0;top:0;opacity:.01';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();ok=true;}catch(e){}}
 if(!ok){var r=document.createRange();r.selectNodeContents(pre);var s=getSelection();s.removeAllRanges();s.addRange(r);}
 var b=box.querySelector('[data-a=cp]');b.textContent=ok?'Copié ✓':'Sélectionné';setTimeout(function(){b.textContent='Copier';},1500);}
function measure(){if(meas)return;fr.length=0;lag.length=0;a0=null;snap='';meas=1;var b=box.querySelector('[data-a=ms]'),n=30;b.disabled=true;
 var iv=setInterval(function(){n--;b.textContent='Mesure '+n+' s';if(n<=0){clearInterval(iv);meas=0;b.disabled=false;b.textContent='Mesurer 30 s';var f=st(fr),l=st(lag);snap='MESURE 30 s : '+(f.avg?(1000/f.avg).toFixed(0):0)+' i/s · image moy '+f.avg.toFixed(1)+' ms · p95 '+f.p95.toFixed(0)+' · max '+f.max.toFixed(0)+' ms · blocages moy '+l.avg.toFixed(1)+' / max '+l.max.toFixed(0)+' ms';paint();}},1000);b.textContent='Mesure 30 s';}
function mk(){if(box)return;var s=document.createElement('style');s.textContent='#qDiag{position:fixed;left:6px;right:6px;top:calc(env(safe-area-inset-top,0px) + 6px);z-index:2147483000;background:rgba(5,8,15,.82);color:#bfe9ff;border:1px solid rgba(77,215,255,.35);border-radius:12px;padding:8px 10px;font:10.5px/1.45 ui-monospace,Menlo,monospace;pointer-events:none;max-height:60vh;overflow:hidden}#qDiag pre{margin:0;white-space:pre-wrap;word-break:break-word;font:inherit}#qDiag .bt{display:flex;gap:8px;margin-top:6px;pointer-events:auto}#qDiag button{font:600 11px system-ui;color:#04121a;background:#4dd7ff;border:0;border-radius:8px;padding:6px 10px}#qDiag button:disabled{opacity:.6}#qDiag button.g{background:rgba(255,255,255,.14);color:#bfe9ff}';document.head.appendChild(s);
 box=document.createElement('div');box.id='qDiag';box.innerHTML='<pre></pre><div class="bt"><button data-a="cp">Copier</button><button data-a="ms" class="g">Mesurer 30 s</button><button data-a="x" class="g">Fermer</button></div>';document.body.appendChild(box);pre=box.querySelector('pre');
 box.addEventListener('click',function(e){var a=e.target.getAttribute&&e.target.getAttribute('data-a');if(a==='cp')copy();else if(a==='ms')measure();else if(a==='x')set(false);});}
function set(v){on=!!v;try{localStorage.setItem('qx.diag',on?'1':'0');}catch(e){}
 if(on){mk();box.style.display='block';fr.length=0;lag.length=0;lastR=0;lastT=0;if(!raf)raf=requestAnimationFrame(tick);if(!tm)tm=setInterval(lg,100);paint();}
 else{if(box)box.style.display='none';if(raf){cancelAnimationFrame(raf);raf=0;}if(tm){clearInterval(tm);tm=0;}}
 var ck=document.querySelector('#qwPn input[data-dg]');if(ck)ck.checked=on;}
window.QDIAG={set:set,toggle:function(){set(!on);},on:function(){return on;},report:function(){return lines().join('\n');}};
try{if(localStorage.getItem('qx.diag')==='1')window.addEventListener('load',function(){set(true);});}catch(e){}
})();
