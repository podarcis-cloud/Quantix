/* QFXE — moteur d'effets de Quantone (R366). Partagé par Quantone et, au lot suivant, par les pistes de Track.
   Un effet = {id, fam, fr, en, cost 1–3, P:[[clé, fr, en, min, max, défaut]…], make(c,T) → {in,out,set(v),stop()}}.
   Une chaîne = jusqu'à 4 effets ; un effet « off » n'est JAMAIS construit (zéro calcul). Que des nœuds Web Audio natifs :
   fonctionne aussi dans un OfflineAudioContext (export, blocs Track). Les effets lourds (autotune, décaleur…) viendront de FX_bank. */
(function(){
'use strict';
var MAXFX=4,DEFS={},ORDER=[];
var FAM={dyn:['Dynamique & ton','Dynamics & tone'],col:['Couleur','Color'],mod:['Modulation','Modulation'],spc:['Espace','Space']};
function def(id,fam,fr,en,cost,P,make,nomix){var ex=!!DEFS[id];DEFS[id]={id:id,fam:fam,fr:fr,en:en,cost:cost,P:P,make:make,mix:!nomix};if(!ex)ORDER.push(id);}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function sm(p,v,c){ /* changement lissé d'un AudioParam (pas de clic) */
  try{p.setTargetAtTime(v,c.currentTime,.03);}catch(e){try{p.value=v;}catch(e2){}}}
function bq(c,type,f,q,g){var b=c.createBiquadFilter();b.type=type;b.frequency.value=f;if(q!=null)b.Q.value=q;if(g!=null)b.gain.value=g;return b;}
function lfo(c,type,f){var o=c.createOscillator();o.type=type;o.frequency.value=f;o.start();return o;}
function noiseBuf(c){if(c._qfxN)return c._qfxN;var n=Math.floor(c.sampleRate*2),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0),i;for(i=0;i<n;i++)d[i]=Math.random()*2-1;return (c._qfxN=b);}
var CV={};
function curve(kind,q){var k=kind+q;if(CV[k])return CV[k];var n=1024,a=new Float32Array(n),i,x,K;
  for(i=0;i<n;i++){x=i/(n-1)*2-1;
    if(kind==='s'){K=1+q/20*12;a[i]=Math.tanh(K*x)/Math.tanh(K);}                       /* saturation douce */
    else if(kind==='f'){K=1+q/20*7;a[i]=Math.sin(K*x*1.5707963);}                          /* repli d'onde */
    else{var L=Math.pow(2,q);a[i]=Math.round(x*L)/L;}}                                       /* bits */
  return (CV[k]=a);}
function irFor(c,sec){var key=Math.round(sec*10),M=c._qfxIR||(c._qfxIR={});if(M[key])return M[key];
  var sr=c.sampleRate,n=Math.max(1000,Math.floor(sr*key/10)),b=c.createBuffer(2,n,sr),ch,i,d,lp;
  for(ch=0;ch<2;ch++){d=b.getChannelData(ch);lp=0;for(i=0;i<n;i++){var t=i/n;lp+=((Math.random()*2-1)-lp)*(.55-.35*t);d[i]=lp*Math.pow(1-t,2.4)*(i<sr*.004?i/(sr*.004):1)*1.6;}}
  return (M[key]=b);}
function mixc(a,b,m){return a+(b-a)*m;}

/* ── Dynamique & ton ── */
def('eq3','dyn','Égaliseur 3 bandes','3‑band EQ',1,[['a','Graves','Low',-12,12,0],['c','Médiums','Mid',-12,12,0],['b','Aigus','High',-12,12,0]],function(c){
  var l=bq(c,'lowshelf',150,null,0),m=bq(c,'peaking',1000,.8,0),h=bq(c,'highshelf',5500,null,0);l.connect(m);m.connect(h);
  return {in:l,out:h,set:function(v){sm(l.gain,v.a,c);sm(m.gain,v.c,c);sm(h.gain,v.b,c);},stop:function(){}};},1);
def('comp','dyn','Compresseur','Compressor',1,[['a','Seuil','Threshold',-40,-4,-22],['b','Gain','Makeup',0,12,4]],function(c){
  var k=c.createDynamicsCompressor(),g=c.createGain();k.ratio.value=4;k.attack.value=.006;k.release.value=.16;k.knee.value=12;k.connect(g);
  return {in:k,out:g,set:function(v){sm(k.threshold,v.a,c);sm(g.gain,Math.pow(10,v.b/20),c);},stop:function(){}};},1);
def('wah','dyn','Filtre auto (wah)','Auto‑filter',2,[['a','Vitesse','Rate',.1,8,1.2],['b','Profondeur','Depth',0,1,.7]],function(c){
  var f=bq(c,'bandpass',900,4.5),o=lfo(c,'sine',1),g=c.createGain();o.connect(g);g.connect(f.frequency);f.frequency.value=900;
  return {in:f,out:f,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b*800,c);},stop:function(){try{o.stop();}catch(e){}}};});

/* ── Couleur ── */
def('sat','col','Saturation douce','Soft saturation',1,[['a','Drive','Drive',0,1,.4],['b','Ton','Tone',0,1,.7]],function(c){
  var w=c.createWaveShaper(),lp=bq(c,'lowpass',9000,.5);w.curve=curve('s',8);w.connect(lp);
  return {in:w,out:lp,set:function(v){w.curve=curve('s',Math.round(v.a*20));sm(lp.frequency,mixc(1500,14000,v.b),c);},stop:function(){}};});
def('fold','col','Repli d’onde','Wave folder',1,[['a','Intensité','Amount',0,1,.4],['b','Sortie','Output',0,1,.7]],function(c){
  var w=c.createWaveShaper(),g=c.createGain();w.curve=curve('f',8);w.connect(g);
  return {in:w,out:g,set:function(v){w.curve=curve('f',Math.round(v.a*20));sm(g.gain,v.b,c);},stop:function(){}};});
def('crush','col','Bits (lo‑fi numérique)','Bit crusher',1,[['a','Bits','Bits',3,12,6],['b','Éclat','Bright',0,1,.8]],function(c){
  var w=c.createWaveShaper(),lp=bq(c,'lowpass',9000,.5);w.curve=curve('b',6);w.connect(lp);
  return {in:w,out:lp,set:function(v){w.curve=curve('b',Math.round(v.a)||6);sm(lp.frequency,mixc(1200,16000,v.b),c);},stop:function(){}};});
def('lofi','col','Cassette','Cassette',2,[['a','Usure','Wear',0,1,.5],['b','Souffle','Hiss',0,1,.3]],function(c){
  var i=c.createGain(),lp=bq(c,'lowpass',4200,.6),hp=bq(c,'highpass',90,.5),dl=c.createDelay(.05),o=lfo(c,'sine',.55),og=c.createGain(),o2=lfo(c,'triangle',6.3),og2=c.createGain(),o3=c.createGain(),
    ns=c.createBufferSource(),ng=c.createGain(),out=c.createGain();
  dl.delayTime.value=.006;o.connect(og);og.connect(dl.delayTime);o2.connect(og2);og2.connect(dl.delayTime);i.connect(hp);hp.connect(lp);lp.connect(dl);dl.connect(out);
  ns.buffer=noiseBuf(c);ns.loop=true;ns.connect(ng);ng.connect(out);ns.start();
  return {in:i,out:out,set:function(v){sm(lp.frequency,mixc(7000,1800,v.a),c);sm(og.gain,.0004+v.a*.0016,c);sm(og2.gain,.00005+v.a*.0004,c);sm(ng.gain,v.b*.02,c);},stop:function(){try{o.stop();o2.stop();ns.stop();}catch(e){}}};},1);
def('ring','col','Modulation en anneau','Ring modulator',1,[['a','Fréquence','Frequency',0,1,.45],['b','Éclat','Bright',0,1,.6]],function(c){
  var g=c.createGain(),o=lfo(c,'sine',200),lp=bq(c,'lowpass',9000,.5);g.gain.value=0;o.connect(g.gain);g.connect(lp);
  return {in:g,out:lp,set:function(v){sm(o.frequency,40*Math.pow(60,v.a),c);sm(lp.frequency,mixc(1500,14000,v.b),c);},stop:function(){try{o.stop();}catch(e){}}};});

/* ── Modulation ── */
def('chorus','mod','Chorus','Chorus',2,[['a','Vitesse','Rate',.1,4,.8],['b','Profondeur','Depth',0,1,.5]],function(c){
  var i=c.createGain(),out=c.createGain(),d1=c.createDelay(.06),d2=c.createDelay(.06),o1=lfo(c,'sine',.8),o2=lfo(c,'sine',.93),g1=c.createGain(),g2=c.createGain(),w=c.createGain();
  d1.delayTime.value=.017;d2.delayTime.value=.024;o1.connect(g1);g1.connect(d1.delayTime);o2.connect(g2);g2.connect(d2.delayTime);i.connect(d1);i.connect(d2);d1.connect(w);d2.connect(w);w.gain.value=.7;w.connect(out);
  return {in:i,out:out,set:function(v){sm(o1.frequency,v.a,c);sm(o2.frequency,v.a*1.17,c);sm(g1.gain,v.b*.006,c);sm(g2.gain,v.b*.007,c);},stop:function(){try{o1.stop();o2.stop();}catch(e){}}};});
def('flanger','mod','Flanger','Flanger',2,[['a','Vitesse','Rate',.05,2,.3],['b','Résonance','Feedback',0,.9,.5]],function(c){
  var i=c.createGain(),out=c.createGain(),d=c.createDelay(.02),fb=c.createGain(),o=lfo(c,'sine',.3),g=c.createGain();
  d.delayTime.value=.004;g.gain.value=.0026;o.connect(g);g.connect(d.delayTime);i.connect(d);d.connect(out);d.connect(fb);fb.connect(d);
  return {in:i,out:out,set:function(v){sm(o.frequency,v.a,c);sm(fb.gain,v.b*.85,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('phaser','mod','Phaser','Phaser',2,[['a','Vitesse','Rate',.1,3,.5],['b','Profondeur','Depth',0,1,.6]],function(c){
  var i=c.createGain(),out=c.createGain(),o=lfo(c,'sine',.5),g=c.createGain(),ap=[],k,prev=i;
  o.connect(g);for(k=0;k<4;k++){var f=bq(c,'allpass',500+k*350,.7);g.connect(f.frequency);prev.connect(f);prev=f;ap.push(f);}
  prev.connect(out);
  return {in:i,out:out,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b*700,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('trem','mod','Trémolo','Tremolo',1,[['a','Vitesse','Rate',.5,14,5],['b','Profondeur','Depth',0,1,.6]],function(c){
  var g=c.createGain(),o=lfo(c,'sine',5),og=c.createGain();og.gain.value=.3;g.gain.value=.7;o.connect(og);og.connect(g.gain);
  return {in:g,out:g,set:function(v){sm(o.frequency,v.a,c);sm(og.gain,v.b*.5,c);sm(g.gain,1-v.b*.5,c);},stop:function(){try{o.stop();}catch(e){}}};},1);
def('pan','mod','Auto‑pan','Auto‑pan',1,[['a','Vitesse','Rate',.1,6,.6],['b','Largeur','Width',0,1,.7]],function(c){
  if(!c.createStereoPanner){var p0=c.createGain();return {in:p0,out:p0,set:function(){},stop:function(){}};}
  var p=c.createStereoPanner(),o=lfo(c,'sine',.6),g=c.createGain();o.connect(g);g.connect(p.pan);
  return {in:p,out:p,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b,c);},stop:function(){try{o.stop();}catch(e){}}};},1);

/* ── Espace ── */
def('ping','spc','Délai ping‑pong','Ping‑pong delay',2,[['a','Temps (tempo)','Time (tempo)',0,1,.35],['b','Répétitions','Repeats',0,.85,.4]],function(c,T){
  var i=c.createGain(),dL=c.createDelay(2),dR=c.createDelay(2),f1=c.createGain(),f2=c.createGain(),lp=bq(c,'lowpass',3800,.5),mg=c.createChannelMerger(2),out=c.createGain();
  i.connect(dL);dL.connect(lp);lp.connect(f1);f1.connect(dR);dR.connect(f2);f2.connect(dL);dL.connect(mg,0,0);dR.connect(mg,0,1);mg.connect(out);
  return {in:i,out:out,set:function(v){var t=Math.min(1.8,60/Math.max(30,T&&T.tempo||90)*(.25+.75*v.a));sm(dL.delayTime,t,c);sm(dR.delayTime,t,c);sm(f1.gain,v.b,c);sm(f2.gain,v.b,c);},stop:function(){}};});
def('plate','spc','Réverbération plaque','Plate reverb',3,[['a','Taille','Size',0,1,.5],['b','Amorti','Damping',0,1,.5]],function(c){
  var cv=c.createConvolver(),lp=bq(c,'lowpass',8000,.5),cur=-1;cv.connect(lp);
  return {in:cv,out:lp,set:function(v){var s=Math.round((.4+v.a*2)*10)/10;if(s!==cur){cur=s;cv.buffer=irFor(c,s);}sm(lp.frequency,mixc(14000,1800,v.b),c);},stop:function(){}};});

/* ── Chaînes prêtes ── */
var CHAINS={
  cassette:{fr:'Cassette chaude',en:'Warm cassette',list:[{t:'lofi',a:.6,b:.35,m:1},{t:'sat',a:.3,b:.5,m:.6},{t:'chorus',a:.4,b:.3,m:.3}]},
  espace:{fr:'Espace profond',en:'Deep space',list:[{t:'ping',a:.5,b:.45,m:.3},{t:'plate',a:.75,b:.6,m:.45}]},
  robot:{fr:'Robot',en:'Robot',list:[{t:'ring',a:.35,b:.5,m:.55},{t:'crush',a:6,b:.7,m:1},{t:'comp',a:-24,b:5,m:1}]},
  psyche:{fr:'Psychédélique',en:'Psychedelic',list:[{t:'phaser',a:.4,b:.8,m:.6},{t:'ping',a:.4,b:.5,m:.35},{t:'plate',a:.6,b:.4,m:.35}]},
  chaud:{fr:'Chaleur analogique',en:'Analog warmth',list:[{t:'eq3',a:3,c:-1,b:-2,m:1},{t:'sat',a:.35,b:.55,m:1},{t:'comp',a:-20,b:3,m:1}]}};

/* ── chaîne ── */
function norm(x){var d=DEFS[x.t],v={m:x.m==null?(d.mix?.5:1):x.m},k;d.P.forEach(function(p){v[p[0]]=x[p[0]]==null?p[5]:clamp(+x[p[0]],p[3],p[4]);});return v;}
function live(list){var o=[];(list||[]).forEach(function(x){if(x&&x.on!==0&&DEFS[x.t]&&o.length<MAXFX)o.push(x);});return o;}
function sig(list){return live(list).map(function(x){return x.t;}).join('|');}
function wrap(c,d,u,v){
  if(!d.mix)return {in:u.in,out:u.out,m:null};
  var i=c.createGain(),o=c.createGain(),dr=c.createGain(),wt=c.createGain();i.connect(dr);dr.connect(o);i.connect(u.in);u.out.connect(wt);wt.connect(o);
  return {in:i,out:o,dr:dr,wt:wt};}
/* ══ R423 : modulateurs — LFO (sinus, triangle, carré, dent, aléatoire) ou suiveur d'enveloppe, assignés à UN réglage d'un effet.
   x.mod={s:'lfo'|'env', k:clé du réglage, sh:forme, r:vitesse Hz, d:profondeur -1…1}. Pas de nouveau nœud audio : on rejoue set() à 25 Hz (direct) ou à 20 Hz via suspend() (export). */
var MODSH=['sine','tri','sq','saw','rnd'];
function mh(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function lfov(sh,r,t){var ph=t*r,f=ph-Math.floor(ph);
  if(sh==='tri')return 1-4*Math.abs(f-.5);if(sh==='sq')return f<.5?1:-1;if(sh==='saw')return 1-2*f;if(sh==='rnd')return mh(Math.floor(ph))*2-1;return Math.sin(ph*6.2832);}
var SEQ0=[0,.5,1,.5,0,.5,1,.5];
function seqv(m,t){var st=(m.st&&m.st.length>=2)?m.st:SEQ0,n=Math.min(16,st.length),ph=t*clamp(+m.r||2,.1,16),i=Math.floor(ph),f=ph-i,g=clamp(+m.g||0,0,1),a=+st[i%n]||0,b=+st[(i+1)%n]||0,k;
  if(g<=0)return clamp(a,0,1);k=clamp((f-(1-g))/g,0,1);k=k*k*(3-2*k);return clamp(a+(b-a)*k,0,1);}
function modOk(x){var m=x&&x.mod,d=x&&DEFS[x.t];if(!m||!d||(m.s!=='lfo'&&m.s!=='env'&&m.s!=='seq'))return null;var pp=null;d.P.forEach(function(p){if(p[0]===m.k)pp=p;});return pp;}
function mvals(x,t,lvl){var v=norm(x),pp=modOk(x);if(!pp)return v;var m=x.mod,d=clamp(+m.d||0,-1,1),rg=pp[4]-pp[3],u;
  u=m.s==='seq'?seqv(m,t)-.5:m.s==='env'?(lvl||0):lfov(MODSH.indexOf(m.sh)>=0?m.sh:'sine',clamp(+m.r||1,.05,12),t)*.5;
  v[m.k]=clamp(v[m.k]+d*rg*u,pp[3],pp[4]);return v;}
function envlv(q){if(!q.an)return 0;var a=q.an,b=q.buf||(q.buf=new Float32Array(a.fftSize)),i,s=0;try{a.getFloatTimeDomainData(b);}catch(e){return q.lv||0;}for(i=0;i<b.length;i++)s+=b[i]*b[i];var r=Math.min(1,Math.sqrt(s/b.length)*4);q.lv=Math.max(r,(q.lv||0)*.82);return q.lv;}
function modTick(c,U){U.forEach(function(q){if(!modOk(q.x))return;if(q.x.mod.s==='env'&&!q.an){try{q.an=c.createAnalyser();q.an.fftSize=256;q.w.in.connect(q.an);}catch(e){}}
  q.u.set(mvals(q.x,c.currentTime,q.x.mod.s==='env'?envlv(q):0));});}
function apply(c,U,list){var L=live(list);if(L.length!==U.length)return false;
  L.forEach(function(x,k){var u=U[k],v=norm(x);u.x=x;if(modOk(x))v=mvals(x,c.currentTime,u.lv||0);u.u.set(v);if(u.w.dr){sm(u.w.dr.gain,1-v.m,c);sm(u.w.wt.gain,v.m,c);}});return true;}
function chain(c,list,T){
  var L=live(list),ci=c.createGain(),co=c.createGain(),U=[],prev=ci,n0=0;
  L.forEach(function(x){var d=DEFS[x.t],u=d.make(c,T||{}),w=wrap(c,d,u),v=norm(x);if(modOk(x))v=mvals(x,0,0);u.set(v);if(w.dr){w.dr.gain.value=1-v.m;w.wt.gain.value=v.m;}prev.connect(w.in);prev=w.out;U.push({d:d,u:u,w:w,x:x});});
  prev.connect(co);var live_=typeof c.startRendering!=='function',tm=null,hasM=function(){return U.some(function(q){return modOk(q.x);});};
  if(live_){tm=setInterval(function(){if(hasM())modTick(c,U);},40);}else{c._qfxMods=(c._qfxMods||[]);c._qfxMods.push({U:U,has:hasM});}
  return {in:ci,out:co,units:U,sig:sig(list),cost:L.reduce(function(a,x){return a+DEFS[x.t].cost;},0),
    set:function(l){return apply(c,U,l);},
    kill:function(){if(tm)clearInterval(tm);U.forEach(function(q){try{q.u.stop();}catch(e){}try{if(q.an)q.an.disconnect();}catch(e){}});try{ci.disconnect();}catch(e){}U.forEach(function(q){try{q.w.in.disconnect();q.w.out.disconnect();}catch(e){}});try{co.disconnect();}catch(e){}}};}
function cost(list){return live(list).reduce(function(a,x){return a+DEFS[x.t].cost;},0);}

/* ══ R378 : banque FX (FX_bank.zip, à la racine du dépôt) — effets en plus, chargés à la demande ══
   Absente ou illisible : rien ne change (les effets de banque déjà dans un morceau restent en place mais muets).
   Contenu : effects.js (déclare des effets avec QFXE.def), worklets.js (AudioWorklet : décaleur, gel, autotune, bits), chains.json, ir/*.wav. */
var BANKIDS=['pitch','shim','freeze','tune','crush2','vib','tape','spring','hall','room','vinyl'];
var BANK={state:'none',ver:'',n:0,files:null},WK={code:''};
FAM.cre=['Créatif','Creative'];
function zipRead(buf){var u=new DataView(buf),b=new Uint8Array(buf),n=b.length,e=-1,i,out={};for(i=n-22;i>=Math.max(0,n-70000);i--){if(u.getUint32(i,true)===0x06054b50){e=i;break;}}if(e<0)return null;
  var cnt=u.getUint16(e+10,true),p=u.getUint32(e+16,true),k;
  for(k=0;k<cnt&&k<128;k++){if(p+46>n||u.getUint32(p,true)!==0x02014b50)break;var meth=u.getUint16(p+10,true),csz=u.getUint32(p+20,true),nl=u.getUint16(p+28,true),xl=u.getUint16(p+30,true),cl=u.getUint16(p+32,true),lo=u.getUint32(p+42,true),nm=new TextDecoder().decode(b.subarray(p+46,p+46+nl));
    if(meth===0&&lo+30<n){var ds=lo+30+u.getUint16(lo+26,true)+u.getUint16(lo+28,true);if(ds+csz<=n)out[nm]=b.subarray(ds,ds+csz);}p+=46+nl+xl+cl;}
  return out;}
/* AudioWorklet : le module est ajouté une fois par contexte ; l'effet démarre en dérivation (son direct) puis bascule quand le nœud est prêt.
   Dans un rendu hors ligne, startRendering attend la fin de ces ajouts : l'export contient donc bien l'effet. */
var REPW=`class QRep extends AudioWorkletProcessor{
constructor(o){super();var N=Math.ceil(sampleRate*8);this.N=N;this.bl=new Float32Array(N);this.br=new Float32Array(N);this.w=0;
 var H=N>>1;this.cl=new Float32Array(H);this.cr=new Float32Array(H);this.cg=0;
 this.p={iv:5,of:0,gr:2,va:0,ch:1,ga:8,pi:0,pd:0,de:.2,vo:0,mo:0,fl:0,fc:1000,fq:4,rp:0,tempo:90,t0:0,on:1};
 if(o&&o.processorOptions)Object.assign(this.p,o.processorOptions);this.vol=Math.pow(10,(this.p.vo||0)/20);this.act=false;this.lk=-1e9;this.pos=0;this.cyc=0;this.rem=0;this.age=0;this.f=[0,0,0,0,0,0,0,0,0,0];this.bq(); this.rpOn=false;
 var me=this;this.port.onmessage=function(e){Object.assign(me.p,e.data);me.bq();me.vol=Math.pow(10,(me.p.vo||0)/20);};}
bq(){var p=this.p,w=2*Math.PI*Math.min(p.fc,sampleRate*.45)/sampleRate,al=Math.sin(w)/(2*Math.max(.3,p.fq)),a0=1+al;this.k=[al/a0,0,-al/a0,-2*Math.cos(w)/a0,(1-al)/a0];}
start(){var p=this.p,IV=[.125,.25,.5,1,2,4,8,16],GR=[.125,.25,.5,1,2],beat=60/Math.max(30,p.tempo)*sampleRate,g=GR[Math.max(0,Math.min(4,Math.round(p.gr)))]*beat;
 if(p.va>0){g*=Math.pow(2,Math.round((Math.random()*2-1)*p.va*2));}g=Math.max(64,Math.min(this.cl.length-1,Math.floor(g)));
 var N=this.N,s=this.w-g;for(var i=0;i<g;i++){var j=(s+i+N)%N;this.cl[i]=this.bl[j];this.cr[i]=this.br[j];}this.cg=g;this.pos=0;this.cyc=0;this.age=0;this.act=true;}
process(ins,outs){var I=ins[0],O=outs[0];if(!O||!O[0])return true;var L=I&&I[0],R=I&&(I[1]||I[0]),oL=O[0],oR=O[1]||O[0],n=oL.length,p=this.p;
 if(!p.on){for(var z=0;z<n;z++){oL[z]=L?L[z]:0;oR[z]=R?R[z]:0;}return true;}
 var beat=60/Math.max(30,p.tempo)*sampleRate,IV=[.125,.25,.5,1,2,4,8,16],ivS=IV[Math.max(0,Math.min(7,Math.round(p.iv)))]*beat,gaS=Math.max(1,p.ga)*beat/4,ofS=p.of/16*ivS,k=this.k,f=this.f,N=this.N;
 for(var i=0;i<n;i++){var xl=L?L[i]:0,xr=R?R[i]:xl,t=currentFrame+i-p.t0*sampleRate;
  if(p.rp){if(!this.act){this.start();this.rem=1e9;}}else{this.rpOn=false;var kk=Math.floor((t-ofS)/ivS);if(kk!==this.lk){this.lk=kk;if(Math.random()<p.ch){this.start();this.rem=gaS;}}}
  var wl=0,wr=0,env=0;
  if(this.act){var semi=p.pi-p.pd*this.cyc*1.5,r=Math.pow(2,semi/12),ip=this.pos|0,fr=this.pos-ip,i2=ip+1>=this.cg?0:ip+1,gn=Math.pow(1-Math.min(.98,p.de),this.cyc)*this.vol;
   env=Math.min(1,this.age/96,this.rem/96);if(env<0)env=0;wl=(this.cl[ip]+(this.cl[i2]-this.cl[ip])*fr)*gn*env;wr=(this.cr[ip]+(this.cr[i2]-this.cr[ip])*fr)*gn*env;
   this.pos+=r;if(this.pos>=this.cg){this.pos-=this.cg;this.cyc++;}this.age++;this.rem--;if(this.rem<=0){this.act=false;}
   if(p.fl){var y=k[0]*wl+f[0];f[0]=f[1]+k[1]*wl-k[3]*y;f[1]=k[2]*wl-k[4]*y;wl=y;y=k[0]*wr+f[2];f[2]=f[3]+k[1]*wr-k[3]*y;f[3]=k[2]*wr-k[4]*y;wr=y;}}
  this.bl[this.w]=xl;this.br[this.w]=xr;this.w=this.w+1>=N?0:this.w+1;
  var d=p.mo===0?1:p.mo===1?1-env:0;oL[i]=xl*d+wl;oR[i]=xr*d+wr;}
 return true;}}
registerProcessor('qrep',QRep);
class QSpec extends AudioWorkletProcessor{
constructor(o){super();var N=1024,H=256,i;this.N=N;this.H=H;this.mode=(o&&o.processorOptions&&o.processorOptions.mode)|0;this.p={a:.5,b:.5};
 this.inb=new Float32Array(N);this.outb=new Float32Array(N);this.w=0;this.cnt=0;this.re=new Float64Array(N);this.im=new Float64Array(N);
 this.win=new Float64Array(N);for(i=0;i<N;i++)this.win[i]=.5-.5*Math.cos(2*Math.PI*i/N);
 this.cs=new Float64Array(N/2);this.sn=new Float64Array(N/2);for(i=0;i<N/2;i++){this.cs[i]=Math.cos(2*Math.PI*i/N);this.sn[i]=-Math.sin(2*Math.PI*i/N);}
 this.rev=new Uint16Array(N);var bits=Math.log2(N),j,r;for(i=0;i<N;i++){r=0;for(j=0;j<bits;j++)if(i&(1<<j))r|=1<<(bits-1-j);this.rev[i]=r;}
 this.sm=new Float64Array(N/2+1);this.hold=new Float64Array(N/2+1);this.acc=new Float64Array(N/2+1);this.held=false;this.mg=new Float64Array(N/2+1);this.ph=new Float64Array(N/2+1);this.m2=new Float64Array(N/2+1);this.p2=new Float64Array(N/2+1);
 var me=this;this.port.onmessage=function(e){Object.assign(me.p,e.data);};}
fft(inv){var N=this.N,re=this.re,im=this.im,rev=this.rev,i,j,k,t,len,h,st,a,b,wr,wi,xr,xi;
 for(i=0;i<N;i++){j=rev[i];if(j>i){t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;}}
 for(len=2;len<=N;len<<=1){h=len>>1;st=N/len;for(i=0;i<N;i+=len){for(k=0;k<h;k++){wr=this.cs[k*st];wi=inv?-this.sn[k*st]:this.sn[k*st];a=i+k;b=a+h;xr=re[b]*wr-im[b]*wi;xi=re[b]*wi+im[b]*wr;re[b]=re[a]-xr;im[b]=im[a]-xi;re[a]+=xr;im[a]+=xi;}}}}
frame(){var N=this.N,H=N/4,h=N>>1,re=this.re,im=this.im,w=this.w,k,i,a=this.p.a,b=this.p.b,mg=this.mg,ph=this.ph,mo=this.mode;
 for(k=0;k<N;k++){re[k]=this.inb[(w+k)%N]*this.win[k];im[k]=0;}
 this.fft(false);for(k=0;k<=h;k++){mg[k]=Math.sqrt(re[k]*re[k]+im[k]*im[k]);ph[k]=Math.atan2(im[k],re[k]);}
 var m2=this.m2,p2=this.p2;for(k=0;k<=h;k++){m2[k]=mg[k];p2[k]=ph[k];}
 if(mo===0){var kk=Math.min(.998,1-(1-Math.max(0,a))*.15),wd=Math.round(b*8),s,c,n;for(k=0;k<=h;k++)this.sm[k]=this.sm[k]*kk+mg[k]*(1-kk);
  for(k=0;k<=h;k++){s=0;c=0;for(n=-wd;n<=wd;n++){if(k+n>=0&&k+n<=h){s+=this.sm[k+n];c++;}}m2[k]=s/c;}for(k=0;k<=h;k++){if(mg[k]>=.5*this.sm[k]){this.acc[k]=ph[k];}else{this.acc[k]+=2*Math.PI*k*H/N;}p2[k]=this.acc[k];}}
 else if(mo===1){if(a>=.5){if(!this.held){for(k=0;k<=h;k++){this.hold[k]=mg[k];this.acc[k]=ph[k];}this.held=true;}
   for(k=0;k<=h;k++){this.acc[k]+=2*Math.PI*k*H/N+(Math.random()-.5)*b*3;m2[k]=this.hold[k];p2[k]=this.acc[k];}}else this.held=false;}
 else if(mo===2){var mx=0;for(k=0;k<=h;k++)if(mg[k]>mx)mx=mg[k];var th=a*mx,fl=b;for(k=0;k<=h;k++)if(mg[k]<th)m2[k]=mg[k]*fl;}
 else{var sh=Math.round(a),j2;for(k=0;k<=h;k++){j2=k-sh;if(j2>=0&&j2<=h){m2[k]=mg[j2];p2[k]=ph[j2];}else m2[k]=0;}if(b>0){for(k=0;k<=h;k++)m2[k]=mg[k]*(1-b)+m2[k]*b;}}
 for(k=0;k<=h;k++){re[k]=m2[k]*Math.cos(p2[k]);im[k]=m2[k]*Math.sin(p2[k]);}
 for(k=1;k<h;k++){re[N-k]=re[k];im[N-k]=-im[k];}im[0]=0;im[h]=0;
 this.fft(true);var sc=1/(N*1.5);for(k=0;k<N;k++)this.outb[(w+k)%N]+=re[k]*this.win[k]*sc;}
process(ins,outs){var o=outs[0],L=o[0],R=o[1]||o[0],I=ins[0],N=this.N,H=N/4,i,x,y,c0,c1;if(!I||!I.length){return true;}c0=I[0];c1=I[1]||I[0];
 for(i=0;i<L.length;i++){x=(c0[i]+c1[i])*.5;y=this.outb[this.w];this.outb[this.w]=0;this.inb[this.w]=x;this.w=(this.w+1)%N;L[i]=y;R[i]=y;this.cnt++;if(this.cnt>=H){this.cnt=0;this.frame();}}
 return true;}}
registerProcessor('qspec',QSpec);
`;
function prep(c){if(c._qfxWp!==undefined)return c._qfxWp;if(!c.audioWorklet||!window.AudioWorkletNode){return (c._qfxWp=null);}
  try{var u=URL.createObjectURL(new Blob([(WK.code||'')+'\n'+REPW],{type:'application/javascript'}));c._qfxWp=c.audioWorklet.addModule(u).then(function(){c._qfxWok=1;},function(){c._qfxWok=0;});}catch(e){c._qfxWp=null;}
  return c._qfxWp;}
function wnode(c,name,opts,cb){var p=prep(c);if(!p)return false;p.then(function(){if(!c._qfxWok)return;try{var oo=typeof opts==='function'?opts():opts;cb(new AudioWorkletNode(c,name,oo||{numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[2]}));}catch(e){}});return true;}
function wfx(c,name,onNode,optsFn){var i=c.createGain(),o=c.createGain(),pt=c.createGain(),U={in:i,out:o,node:null,last:null,dead:false};i.connect(pt);pt.connect(o);
  U.set=function(v){U.last=v;if(U.node&&U.onset)U.onset(U.node,v);};U.stop=function(){U.dead=true;try{if(U.node)U.node.disconnect();}catch(e){}};
  wnode(c,name,optsFn?function(){return optsFn(U);}:null,function(n){if(U.dead)return;i.connect(n);n.connect(o);pt.gain.value=0;U.node=n;if(onNode)onNode(n,U);if(U.last&&U.onset)U.onset(n,U.last);});return U;}
['OfflineAudioContext','webkitOfflineAudioContext'].forEach(function(k){var C=window[k];if(!C||!C.prototype||C.prototype._qfxPatched)return;var sr=C.prototype.startRendering;C.prototype._qfxPatched=1;
  C.prototype.startRendering=function(){var self=this,p=self._qfxWp;try{var Ms=(self._qfxMods||[]).filter(function(g){return g.has();});if(Ms.length&&self.suspend){var dur=self.length/self.sampleRate,tt;for(tt=.05;tt<dur&&tt<300;tt+=.05){(function(tq){self.suspend(tq).then(function(){Ms.forEach(function(g){modTick(self,g.U);});self.resume();}).catch(function(){});})(Math.round(tt*self.sampleRate/128)*128/self.sampleRate);}}}catch(e){}
   if(p&&p.then)return p.then(function(){return new Promise(function(r){setTimeout(r,0);});}).then(function(){return sr.call(self);});return sr.call(self);};});
function bankIR(c,name,fallbackSec){var cv=c.createConvolver();cv.buffer=irFor(c,fallbackSec||1.5);var f=BANK.files&&BANK.files[name];
  if(f){try{var ab=f.buffer.slice(f.byteOffset,f.byteOffset+f.byteLength),pr=c.decodeAudioData(ab,function(b){try{cv.buffer=b;}catch(e){}},function(){});if(pr&&pr.catch)pr.catch(function(){});}catch(e){}}
  return cv;}
var H={sm:sm,bq:bq,lfo:lfo,mixc:mixc,clamp:clamp,irFor:irFor,noiseBuf:noiseBuf,curve:curve,wfx:wfx,bankIR:bankIR};
function loadBank(done){var fin=function(){try{if(done)done(BANK);}catch(e){}try{window.dispatchEvent(new Event('qfx-bank'));}catch(e){}};
  function apply(man,fx,wk,ch,files){try{if(!man||!fx)return false;WK.code=wk||'';BANK.files=files||null;var n0=ORDER.length;(new Function('QFXE','H',fx))(window.QFXE,H);
    (ch||[]).forEach(function(q){if(q&&q.id&&q.list&&!CHAINS['b_'+q.id])CHAINS['b_'+q.id]={fr:q.fr,en:q.en,list:q.list};});
    BANK.state='ok';BANK.ver=String(man.version||'');BANK.n=ORDER.length-n0;return true;}catch(e){BANK.state='bad';return false;}}
  function cached(){try{var c=JSON.parse(localStorage.getItem('qx.fxbank')||'null');if(c&&apply(c.man,c.fx,c.wk,c.ch,null)){BANK.cache=true;}}catch(e){}fin();}
  if(location.protocol==='file:'){cached();return;}
  try{fetch('../FX_bank.zip',{cache:'no-cache'}).then(function(r){return r.ok?r.arrayBuffer():Promise.reject();}).then(function(buf){var z=zipRead(buf),dec=function(a){return new TextDecoder().decode(a);};
    if(!z||!z['manifest.json']||!z['effects.js'])return Promise.reject();var man=JSON.parse(dec(z['manifest.json'])),fx=dec(z['effects.js']),wk=z['worklets.js']?dec(z['worklets.js']):'',ch=z['chains.json']?JSON.parse(dec(z['chains.json'])):[],files={};
    Object.keys(z).forEach(function(k){if(/^ir\//.test(k))files[k]=z[k];});
    if(!apply(man,fx,wk,ch,files))return Promise.reject();try{localStorage.setItem('qx.fxbank',JSON.stringify({man:man,fx:fx,wk:wk,ch:ch}));}catch(e){}fin();}).catch(function(){cached();});}catch(e){cached();}}
/* ── R412 : Répéteur (Beat Repeat) — capture une tranche du son et la répète, calé sur le tempo. AudioWorklet 'qrep'. ── */
def('rep','cre','Répéteur','Beat Repeat',2,[['iv','Intervalle (1/32 … 4 mesures)','Interval',0,7,5],['of','Décalage (16es)','Offset',0,15,0],['gr','Grille (1/32 … 1/2)','Grid',0,4,2],['va','Variation','Variation',0,1,0],['ch','Chance','Chance',0,1,1],['ga','Gate (16es)','Gate',1,16,8],['pi','Hauteur (demi-tons)','Pitch',-24,0,0],['pd','Chute de hauteur','Pitch decay',0,1,0],['de','Décroissance','Decay',0,.9,.2],['vo','Volume (dB)','Volume',-24,6,0],['mo','Mode (0 Mix · 1 Insert · 2 Gate)','Mode (0 Mix · 1 Insert · 2 Gate)',0,2,0],['fl','Filtre (0/1)','Filter (0/1)',0,1,0],['fc','Filtre : fréquence (Hz)','Filter freq (Hz)',100,10000,1000],['fq','Filtre : largeur','Filter width',.3,8,4],['rp','Répéter en continu (0/1)','Repeat (0/1)',0,1,0]],
 function(c,T){function pr(v){var o={},k;v=v||{};for(k in v)o[k]=v[k];o.tempo=(T&&T.tempo)||90;o.t0=(T&&T.t0)||0;o.on=1;o.mo=Math.round(v.mo||0);o.fl=Math.round(v.fl||0)>0?1:0;o.rp=Math.round(v.rp||0)>0?1:0;return o;}
  var U=wfx(c,'qrep',null,function(u){return {numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[2],processorOptions:pr(u.last)};});U.onset=function(n,v){try{n.port.postMessage(pr(v));}catch(e){}};return U;},true);
/* ══ R414 : lot d'effets natifs (délais, distorsions, dynamique, utilitaires, résonateurs) — nœuds Web Audio seulement, export hors ligne compatible ══ */
function mkcurve(n,f){var a=new Float32Array(n),i;for(i=0;i<n;i++)a[i]=f(i/(n-1)*2-1);return a;}
function shp(c,f,n){var w=c.createWaveShaper();w.curve=mkcurve(n||1024,f);return w;}
var BEATS=[.25,.5,.75,1,1.5,2];
/* ── Délais ── */
def('dly','spc','Délai synchro','Sync delay',2,[['tm','Temps (1/16 … 1/2)','Time (1/16 … 1/2)',0,5,3],['b','Répétitions','Feedback',0,.92,.4],['c','Ton (Hz)','Tone (Hz)',500,12000,6000],['d','Écart stéréo','Stereo spread',0,1,.3]],function(c,T){
  var i=c.createGain(),dl=c.createDelay(4),dr=c.createDelay(4),fl=c.createGain(),fr=c.createGain(),lp=bq(c,'lowpass',6000,.7),lq=bq(c,'lowpass',6000,.7),m=c.createChannelMerger(2);
  i.connect(dl);i.connect(dr);dl.connect(lp);lp.connect(fl);fl.connect(dl);dr.connect(lq);lq.connect(fr);fr.connect(dr);lp.connect(m,0,0);lq.connect(m,0,1);
  return {in:i,out:m,set:function(v){var be=60/Math.max(30,(T&&T.tempo)||90),t=BEATS[Math.max(0,Math.min(5,Math.round(v.tm)))]*be;sm(dl.delayTime,Math.min(3.9,t),c);sm(dr.delayTime,Math.min(3.9,t*(1+.5*v.d)),c);sm(fl.gain,v.b,c);sm(fr.gain,v.b,c);sm(lp.frequency,v.c,c);sm(lq.frequency,v.c,c);},stop:function(){}};});
def('echo','spc','Écho bande','Tape echo',2,[['a','Temps (ms)','Time (ms)',60,900,320],['b','Répétitions','Feedback',0,.92,.45],['c','Usure','Wear',0,1,.5],['d','Scintillement','Flutter',0,1,.3]],function(c){
  var i=c.createGain(),dl=c.createDelay(2),fb=c.createGain(),sat=shp(c,function(x){return Math.tanh(2.2*x)/Math.tanh(2.2);}),lp=bq(c,'lowpass',4500,.6),hp=bq(c,'highpass',160,.6),o=lfo(c,'sine',.9),lg=c.createGain(),o2=lfo(c,'triangle',6.3),lg2=c.createGain();
  i.connect(dl);dl.connect(hp);hp.connect(sat);sat.connect(lp);lp.connect(fb);fb.connect(dl);o.connect(lg);lg.connect(dl.delayTime);o2.connect(lg2);lg2.connect(dl.delayTime);
  var out=c.createGain();lp.connect(out);
  return {in:i,out:out,set:function(v){sm(dl.delayTime,v.a/1000,c);sm(fb.gain,v.b,c);sm(lp.frequency,9000-7000*v.c,c);sm(lg.gain,.0012*v.d,c);sm(lg2.gain,.0004*v.d,c);},stop:function(){try{o.stop();o2.stop();}catch(e){}}};});
def('fdly','spc','Délai filtré (3 lignes)','Filter delay (3 taps)',3,[['tm','Temps (1/16 … 1/2)','Time (1/16 … 1/2)',0,5,3],['b','Répétitions','Feedback',0,.85,.35],['hp','Filtre grave (Hz)','Low cut (Hz)',40,2000,200],['lp','Filtre aigu (Hz)','High cut (Hz)',800,12000,5000]],function(c,T){
  var i=c.createGain(),o=c.createGain(),L=[1,1.5,2].map(function(k,j){var d=c.createDelay(4),f=c.createGain(),h=bq(c,'highpass',200,.7),l=bq(c,'lowpass',5000,.7),g=c.createGain();g.gain.value=[.8,.6,.45][j];i.connect(d);d.connect(h);h.connect(l);l.connect(f);f.connect(d);l.connect(g);g.connect(o);return {d:d,f:f,h:h,l:l,k:k};});
  return {in:i,out:o,set:function(v){var be=60/Math.max(30,(T&&T.tempo)||90),t=BEATS[Math.max(0,Math.min(5,Math.round(v.tm)))]*be;L.forEach(function(x){sm(x.d.delayTime,Math.min(3.9,t*x.k),c);sm(x.f.gain,v.b,c);sm(x.h.frequency,v.hp,c);sm(x.l.frequency,v.lp,c);});},stop:function(){}};});
/* ── Distorsions ── */
def('od','col','Overdrive','Overdrive',1,[['a','Drive','Drive',0,1,.45],['b','Ton (Hz)','Tone (Hz)',800,9000,4200],['c','Niveau (dB)','Level (dB)',-18,6,-4]],function(c){
  var hp=bq(c,'highpass',90,.7),pre=c.createGain(),w=c.createWaveShaper(),lp=bq(c,'lowpass',4200,.7),g=c.createGain(),last=-1;hp.connect(pre);pre.connect(w);w.connect(lp);lp.connect(g);
  return {in:hp,out:g,set:function(v){var k=1+v.a*18;if(Math.abs(k-last)>.3){last=k;w.curve=mkcurve(1024,function(x){var y=x*k;return y>=0?Math.tanh(y):Math.tanh(y*.8)*1.1;});}sm(pre.gain,1,c);sm(lp.frequency,v.b,c);sm(g.gain,Math.pow(10,v.c/20)/(1+v.a*1.5),c);},stop:function(){}};});
def('dist','col','Distorsion dure','Hard distortion',1,[['a','Drive','Drive',0,1,.6],['b','Ton (Hz)','Tone (Hz)',600,9000,3000],['c','Niveau (dB)','Level (dB)',-18,6,-6]],function(c){
  var hp=bq(c,'highpass',120,.7),pre=c.createGain(),w=c.createWaveShaper(),lp=bq(c,'lowpass',3000,.7),g=c.createGain(),last=-1;hp.connect(pre);pre.connect(w);w.connect(lp);lp.connect(g);
  return {in:hp,out:g,set:function(v){var k=1+v.a*40;if(Math.abs(k-last)>.5){last=k;w.curve=mkcurve(1024,function(x){var y=x*k;return Math.max(-.8,Math.min(.8,y));});}sm(lp.frequency,v.b,c);sm(g.gain,Math.pow(10,v.c/20)*(1.2/(1+v.a*.6)),c);},stop:function(){}};});
def('fuzz','col','Fuzz','Fuzz',1,[['a','Fuzz','Fuzz',0,1,.65],['b','Ton (Hz)','Tone (Hz)',500,8000,2500],['c','Niveau (dB)','Level (dB)',-18,6,-6]],function(c){
  var pre=c.createGain(),w=c.createWaveShaper(),lp=bq(c,'lowpass',2500,.9),hp=bq(c,'highpass',80,.7),g=c.createGain(),last=-1;pre.connect(w);w.connect(hp);hp.connect(lp);lp.connect(g);
  return {in:pre,out:g,set:function(v){var k=2+v.a*60;if(Math.abs(k-last)>.8){last=k;w.curve=mkcurve(1024,function(x){var y=x*k+.25*Math.tanh(x*k*.5);return y>0?Math.min(.9,y):Math.max(-.55,y*.7);});}sm(lp.frequency,v.b,c);sm(g.gain,Math.pow(10,v.c/20)*.9,c);},stop:function(){}};});
def('tube','col','Tube dynamique','Dynamic tube',2,[['a','Drive','Drive',0,1,.5],['b','Sensibilité','Sensitivity',0,1,.6],['c','Ton (Hz)','Tone (Hz)',1500,12000,7000]],function(c){
  var i=c.createGain(),dg=c.createGain(),w=shp(c,function(x){return Math.tanh(1.6*x+.15*x*x)/1.1;}),lp=bq(c,'lowpass',7000,.7),o=c.createGain(),ab=shp(c,Math.abs),el=bq(c,'lowpass',18,.5),eg=c.createGain();
  dg.gain.value=2;i.connect(dg);dg.connect(w);w.connect(lp);lp.connect(o);i.connect(ab);ab.connect(el);el.connect(eg);eg.connect(dg.gain);   /* l'enveloppe du signal pilote le drive */
  return {in:i,out:o,set:function(v){sm(dg.gain,1+v.a*5,c);sm(eg.gain,v.b*14,c);sm(lp.frequency,v.c,c);sm(o.gain,.85/(1+v.a*.8),c);},stop:function(){}};});
def('ero','col','Érosion','Erosion',2,[['a','Quantité','Amount',0,1,.4],['b','Fréquence (Hz)','Frequency (Hz)',300,9000,2500],['c','Largeur','Width',.3,8,1.5]],function(c){
  var i=c.createGain(),d=c.createDelay(.05),ns=c.createBufferSource(),bp=bq(c,'bandpass',2500,1.5),g=c.createGain();d.delayTime.value=.004;ns.buffer=noiseBuf(c);ns.loop=true;ns.start();ns.connect(bp);bp.connect(g);g.connect(d.delayTime);i.connect(d);
  return {in:i,out:d,set:function(v){sm(g.gain,.0035*v.a,c);sm(bp.frequency,v.b,c);sm(bp.Q,v.c,c);},stop:function(){try{ns.stop();}catch(e){}}};});
def('bus','col','Drum Buss','Drum Buss',3,[['a','Punch','Punch',0,1,.5],['b','Drive','Drive',0,1,.3],['c','Boom (dB)','Boom (dB)',0,12,4],['d','Cran (dB)','Crunch (dB)',0,9,2]],function(c){
  var k=c.createDynamicsCompressor(),sat=c.createWaveShaper(),lo=bq(c,'lowshelf',80,null,0),hi=bq(c,'highshelf',4500,null,0),g=c.createGain(),last=-1;k.ratio.value=4;k.attack.value=.02;k.release.value=.09;k.knee.value=4;k.connect(sat);sat.connect(lo);lo.connect(hi);hi.connect(g);
  return {in:k,out:g,set:function(v){var kk=1+v.b*7;if(Math.abs(kk-last)>.2){last=kk;sat.curve=mkcurve(1024,function(x){return Math.tanh(kk*x)/Math.tanh(kk);});}sm(k.threshold,-8-v.a*26,c);sm(lo.gain,v.c,c);sm(hi.gain,v.d,c);sm(g.gain,1.1,c);},stop:function(){}};});
/* ── Dynamique ── */
def('gate','dyn','Gate (porte)','Noise gate',2,[['a','Seuil (dB)','Threshold (dB)',-60,-10,-40],['b','Relâchement (ms)','Release (ms)',20,500,120]],function(c){
  var i=c.createGain(),g=c.createGain(),ab=shp(c,Math.abs),el=bq(c,'lowpass',30,.5),st=c.createWaveShaper(),eg=c.createGain();g.gain.value=0;i.connect(g);i.connect(ab);ab.connect(el);el.connect(st);st.connect(g.gain);
  return {in:i,out:g,set:function(v){var th=Math.pow(10,v.a/20);st.curve=mkcurve(2048,function(x){return x>=th?1:(x>th*.7?(x-th*.7)/(th*.3):0);});sm(el.frequency,Math.max(2,1000/v.b*3),c);},stop:function(){}};},1);
def('lim','dyn','Limiteur','Limiter',1,[['a','Entrée (dB)','Input (dB)',0,18,6],['b','Plafond (dB)','Ceiling (dB)',-12,0,-1]],function(c){
  var g=c.createGain(),k=c.createDynamicsCompressor(),o=c.createGain();k.ratio.value=20;k.knee.value=0;k.attack.value=.001;k.release.value=.08;k.threshold.value=-2;g.connect(k);k.connect(o);
  return {in:g,out:o,set:function(v){sm(g.gain,Math.pow(10,v.a/20),c);sm(k.threshold,v.b-1,c);sm(o.gain,Math.pow(10,(v.b)/20)/Math.pow(10,(v.b-1)/20)*.9,c);},stop:function(){}};},1);
def('glue','dyn','Compresseur de bus','Glue compressor',2,[['a','Seuil (dB)','Threshold (dB)',-40,0,-18],['b','Rapport','Ratio',1.5,8,2.5],['c','Relâchement (s)','Release (s)',.05,1.2,.3],['d','Gain (dB)','Makeup (dB)',0,12,3]],function(c){
  var k=c.createDynamicsCompressor(),g=c.createGain();k.attack.value=.03;k.knee.value=10;k.connect(g);
  return {in:k,out:g,set:function(v){sm(k.threshold,v.a,c);sm(k.ratio,v.b,c);k.release.value=v.c;sm(g.gain,Math.pow(10,v.d/20),c);},stop:function(){}};},1);
def('mband','dyn','Multibande','Multiband',3,[['a','Seuil (dB)','Threshold (dB)',-40,-4,-24],['b','Rapport','Ratio',1,10,3],['c','Gain graves (dB)','Low gain (dB)',-12,12,0],['d','Gain aigus (dB)','High gain (dB)',-12,12,0]],function(c){
  var i=c.createGain(),o=c.createGain(),bands=[['lowpass',250],['bandpass',1500],['highpass',5000]].map(function(b,j){var f=bq(c,b[0],b[1],j===1?.55:.7),f2=bq(c,b[0],b[1],j===1?.55:.7),k=c.createDynamicsCompressor(),g=c.createGain();k.attack.value=.01;k.release.value=.15;k.knee.value=8;i.connect(f);f.connect(f2);f2.connect(k);k.connect(g);g.connect(o);return {k:k,g:g};});
  return {in:i,out:o,set:function(v){bands.forEach(function(b,j){sm(b.k.threshold,v.a,c);sm(b.k.ratio,v.b,c);sm(b.g.gain,Math.pow(10,(j===0?v.c:j===2?v.d:0)/20)*1.3,c);});},stop:function(){}};},1);
/* ── Utilitaires ── */
def('util','dyn','Utilité','Utility',1,[['a','Gain (dB)','Gain (dB)',-24,12,0],['b','Panoramique','Pan',-1,1,0],['c','Largeur (0 mono · 1 normal · 2 large)','Width',0,2,1],['d','Inverser la phase (0/1)','Invert phase (0/1)',0,1,0]],function(c){
  var i=c.createGain(),sp=c.createChannelSplitter(2),m=c.createChannelMerger(2),pn=c.createStereoPanner?c.createStereoPanner():c.createGain(),g=c.createGain(),ll=c.createGain(),rl=c.createGain(),lr=c.createGain(),rr=c.createGain();
  i.channelCount=2;i.channelCountMode='explicit';i.connect(sp);sp.connect(ll,0);sp.connect(lr,0);sp.connect(rl,1);sp.connect(rr,1);ll.connect(m,0,0);rl.connect(m,0,0);lr.connect(m,0,1);rr.connect(m,0,1);m.connect(pn);pn.connect(g);
  return {in:i,out:g,set:function(v){var w=v.c,s=Math.round(v.d)>0?-1:1,dr=(1+w)/2*s,cr=(1-w)/2*s;sm(ll.gain,dr,c);sm(rr.gain,dr,c);sm(rl.gain,cr,c);sm(lr.gain,cr,c);if(pn.pan)sm(pn.pan,v.b,c);sm(g.gain,Math.pow(10,v.a/20),c);},stop:function(){}};},1);
/* ── Résonance & modulation ── */
var RCH=[[0,12,19,24,28],[0,7,12,19,24],[0,3,7,10,14],[0,4,7,11,14],[0,5,7,12,17],[0,1,6,7,13]];
def('rez','spc','Résonateurs (5 notes)','Resonators (5 notes)',3,[['n','Note (MIDI)','Note (MIDI)',28,72,48],['k','Accord (0 oct · 1 quinte · 2 mineur · 3 majeur · 4 sus · 5 cluster)','Chord',0,5,2],['q','Résonance','Resonance',6,80,34]],function(c){
  var i=c.createGain(),o=c.createGain(),B=[0,1,2,3,4].map(function(){var f=bq(c,'bandpass',220,30),g=c.createGain();g.gain.value=.5;i.connect(f);f.connect(g);g.connect(o);return f;});
  return {in:i,out:o,set:function(v){var ch=RCH[Math.max(0,Math.min(5,Math.round(v.k)))];B.forEach(function(f,j){sm(f.frequency,440*Math.pow(2,(v.n+ch[j]-69)/12),c);sm(f.Q,v.q,c);});},stop:function(){}};},1);
def('ens','mod','Ensemble (chorus 3 voix)','Ensemble (3 voices)',3,[['a','Vitesse','Rate',.1,3,.6],['b','Profondeur','Depth',0,1,.5]],function(c){
  var i=c.createGain(),o=c.createGain(),V=[[.0161,0],[.0221,2.1],[.0281,4.2]].map(function(x,j){var d=c.createDelay(.1),l=lfo(c,'sine',.5+j*.13),lg=c.createGain(),g=c.createGain();d.delayTime.value=x[0];l.connect(lg);lg.connect(d.delayTime);i.connect(d);d.connect(g);g.gain.value=.55;g.connect(o);return {l:l,lg:lg};});
  return {in:i,out:o,set:function(v){V.forEach(function(x,j){sm(x.l.frequency,v.a*(1+j*.27),c);sm(x.lg.gain,.0028*v.b,c);});},stop:function(){V.forEach(function(x){try{x.l.stop();}catch(e){}});}};});
/* ══ R418 : filtres, égaliseur, ampli/baffle, effets propres à Quantone (Pompe, Orbite) ══ */
var FTY=['lowpass','highpass','bandpass','notch'];
def('filt','dyn','Filtre balayé','Swept filter',2,[['ty','Type (0 grave · 1 aigu · 2 bande · 3 coupe)','Type',0,3,0],['f','Fréquence (Hz)','Frequency (Hz)',60,12000,1200],['q','Résonance','Resonance',.5,18,4],['sw','Balayage auto','Auto sweep',0,1,.3],['r','Vitesse (Hz)','Rate (Hz)',.05,8,.5]],function(c){
  var f=bq(c,'lowpass',1200,4),o=lfo(c,'sine',.5),g=c.createGain();o.connect(g);g.connect(f.detune);
  return {in:f,out:f,set:function(v){f.type=FTY[Math.max(0,Math.min(3,Math.round(v.ty)))];sm(f.frequency,v.f,c);sm(f.Q,v.q,c);sm(g.gain,1200*v.sw,c);sm(o.frequency,v.r,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('eq4','dyn','Égaliseur 4 bandes','4-band EQ',2,[['a','Graves (dB)','Low (dB)',-15,15,0],['b','Bas-médiums (dB)','Low-mid (dB)',-15,15,0],['c','Hauts-médiums (dB)','High-mid (dB)',-15,15,0],['d','Aigus (dB)','High (dB)',-15,15,0],['fm','Fréquence médiums (Hz)','Mid freq (Hz)',200,5000,1500]],function(c){
  var l=bq(c,'lowshelf',100,null,0),m1=bq(c,'peaking',500,1,0),m2=bq(c,'peaking',2500,1,0),h=bq(c,'highshelf',8000,null,0);l.connect(m1);m1.connect(m2);m2.connect(h);
  return {in:l,out:h,set:function(v){sm(l.gain,v.a,c);sm(m1.gain,v.b,c);sm(m2.gain,v.c,c);sm(h.gain,v.d,c);sm(m1.frequency,v.fm*.4,c);sm(m2.frequency,v.fm*1.6,c);},stop:function(){}};});
def('amp','col','Ampli','Amp',3,[['g','Gain','Gain',0,1,.5],['b','Graves (dB)','Bass (dB)',-10,10,0],['md','Médiums (dB)','Mid (dB)',-10,10,2],['tr','Aigus (dB)','Treble (dB)',-10,10,0],['v','Volume (dB)','Volume (dB)',-18,6,-3]],function(c){
  var hp=bq(c,'highpass',70,.7),pre=c.createGain(),w1=c.createWaveShaper(),mid=bq(c,'peaking',700,.8,0),w2=c.createWaveShaper(),lo=bq(c,'lowshelf',120,null,0),hi=bq(c,'highshelf',3500,null,0),cab=bq(c,'lowpass',5200,.8),g=c.createGain(),last=-1;
  hp.connect(pre);pre.connect(w1);w1.connect(mid);mid.connect(w2);w2.connect(lo);lo.connect(hi);hi.connect(cab);cab.connect(g);
  w2.curve=mkcurve(1024,function(x){return Math.tanh(1.5*x)/Math.tanh(1.5);});
  return {in:hp,out:g,set:function(v){var k=1+v.g*12;if(Math.abs(k-last)>.3){last=k;w1.curve=mkcurve(1024,function(x){var y=x*k+.1*k*x*x*.2;return Math.tanh(y)/Math.tanh(Math.min(k,6));});}sm(lo.gain,v.b,c);sm(mid.gain,v.md,c);sm(hi.gain,v.tr,c);sm(g.gain,Math.pow(10,v.v/20)*.8,c);},stop:function(){}};});
def('cab','col','Baffle','Cabinet',2,[['s','Taille (0 petit · 1 grand)','Size (0 small · 1 large)',0,1,.5],['r','Présence (dB)','Presence (dB)',-6,9,3]],function(c){
  var hp=bq(c,'highpass',80,.8),lp=bq(c,'lowpass',5000,.9),lp2=bq(c,'lowpass',7000,.5),pk=bq(c,'peaking',2800,1.2,0),bx=bq(c,'peaking',180,1,3);hp.connect(bx);bx.connect(pk);pk.connect(lp);lp.connect(lp2);
  return {in:hp,out:lp2,set:function(v){sm(hp.frequency,110-60*v.s,c);sm(bx.frequency,260-120*v.s,c);sm(lp.frequency,6500-2500*v.s,c);sm(pk.gain,v.r,c);},stop:function(){}};});
/* effets propres à Quantone */
def('pump','cre','Pompe','Pump',2,[['d','Profondeur','Depth',0,1,.6],['cd','Cadence (0 noire · 1 croche · 2 double)','Rate',0,2,0],['s','Forme','Shape',0,1,.5]],function(c,T){
  var i=c.createGain(),g=c.createGain(),o=lfo(c,'sawtooth',2),sh=c.createWaveShaper(),dg=c.createGain(),last=-1;g.gain.value=1;i.connect(g);o.connect(sh);sh.connect(dg);dg.connect(g.gain);
  return {in:i,out:g,set:function(v){var be=(T&&T.tempo)||90,f=be/60*[1,2,4][Math.max(0,Math.min(2,Math.round(v.cd)))];sm(o.frequency,f,c);var k=v.s;if(k!==last){last=k;sh.curve=mkcurve(512,function(x){var u=(x+1)/2;return -Math.pow(1-u,1+3*k);});}sm(dg.gain,v.d,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('orb','cre','Orbite','Orbit',3,[['r','Vitesse (Hz)','Rate (Hz)',.05,4,.35],['w','Largeur','Width',0,1,.8],['d','Profondeur de distance','Distance depth',0,1,.5]],function(c){
  var i=c.createGain(),sp=c.createStereoPanner?c.createStereoPanner():null,o=lfo(c,'sine',.35),og=c.createGain(),o2=lfo(c,'sine',.35),lp=bq(c,'lowpass',9000,.5),lg=c.createGain(),vg=c.createGain();
  i.connect(lp);lp.connect(vg);if(sp){vg.connect(sp);o.connect(og);og.connect(sp.pan);}o2.connect(lg);lg.connect(lp.frequency);
  return {in:i,out:sp||vg,set:function(v){sm(o.frequency,v.r,c);sm(o2.frequency,v.r,c);sm(og.gain,v.w,c);sm(lg.gain,5500*v.d,c);sm(vg.gain,1-.25*v.d,c);},stop:function(){try{o.stop();o2.stop();}catch(e){}}};});
/* ══ R419 : espaces — réverbération réglable, réverbération coupée, écho dub ══ */
function irMk(c,sec,gate,bright,seed){var key='g'+Math.round(sec*10)+'_'+gate+'_'+Math.round(bright*10),M=c._qfxIR||(c._qfxIR={});if(M[key])return M[key];
  var sr=c.sampleRate,n=Math.max(1000,Math.floor(sr*sec)),b=c.createBuffer(2,n,sr),ch,i,d,lp,t,env;
  for(ch=0;ch<2;ch++){d=b.getChannelData(ch);lp=0;for(i=0;i<n;i++){t=i/n;lp+=((Math.random()*2-1)-lp)*(.2+.6*bright-.4*t*(1-bright*.5));env=gate?(t<.82?1-.25*t:Math.max(0,(1-(t-.82)/.03))):Math.pow(1-t,2.2);d[i]=lp*env*(i<sr*.003?i/(sr*.003):1)*1.5;}}
  return (M[key]=b);}
def('verb','spc','Réverbération réglable','Tunable reverb',3,[['a','Taille','Size',0,1,.5],['b','Clarté','Brightness',0,1,.5],['pd','Pré-délai (ms)','Pre-delay (ms)',0,200,20],['w','Largeur','Width',0,1,1],['lc','Coupe-grave (Hz)','Low cut (Hz)',20,800,120]],function(c){
  var i=c.createGain(),pd=c.createDelay(.5),cv=c.createConvolver(),hp=bq(c,'highpass',120,.7),cur='';i.connect(pd);pd.connect(cv);cv.connect(hp);
  return {in:i,out:hp,set:function(v){var k=Math.round((.4+v.a*3.2)*10)/10+'|'+Math.round(v.b*10);if(k!==cur){cur=k;cv.buffer=irMk(c,.4+v.a*3.2,0,v.b);}sm(pd.delayTime,v.pd/1000,c);sm(hp.frequency,v.lc,c);},stop:function(){}};});
def('grev','spc','Réverbération coupée','Gated reverb',3,[['a','Longueur','Length',0,1,.5],['b','Clarté','Brightness',0,1,.6],['lc','Coupe-grave (Hz)','Low cut (Hz)',20,800,200]],function(c){
  var cv=c.createConvolver(),hp=bq(c,'highpass',200,.7),cur='';cv.connect(hp);
  return {in:cv,out:hp,set:function(v){var k=Math.round(v.a*10)+'|'+Math.round(v.b*10);if(k!==cur){cur=k;cv.buffer=irMk(c,.15+v.a*.6,1,v.b);}sm(hp.frequency,v.lc,c);},stop:function(){}};});
def('dub','spc','Écho dub','Dub echo',3,[['a','Temps (ms)','Time (ms)',80,1200,375],['b','Répétitions','Feedback',0,.95,.6],['hp','Filtre grave (Hz)','Low cut (Hz)',60,1500,300],['lp','Filtre aigu (Hz)','High cut (Hz)',600,9000,2800],['dr','Saturation','Drive',0,1,.3]],function(c){
  var i=c.createGain(),dl=c.createDelay(2),fb=c.createGain(),h=bq(c,'highpass',300,.9),l=bq(c,'lowpass',2800,.9),w=c.createWaveShaper(),o=c.createGain(),last=-1;
  i.connect(dl);dl.connect(h);h.connect(l);l.connect(w);w.connect(fb);fb.connect(dl);l.connect(o);
  return {in:i,out:o,set:function(v){sm(dl.delayTime,v.a/1000,c);sm(fb.gain,v.b,c);sm(h.frequency,v.hp,c);sm(l.frequency,v.lp,c);var k=1+v.dr*4;if(Math.abs(k-last)>.1){last=k;w.curve=mkcurve(512,function(x){return Math.tanh(k*x)/Math.tanh(k);});}},stop:function(){}};});
/* préréglages du Répéteur (clés de P ci-dessus) */
var REPPRE=[['Glitch Drums','Glitch Drums',{iv:2,of:5,gr:1,va:0,ch:.47,ga:11,pi:-11,pd:.06,de:.45,vo:0,mo:0}],['Bégaiement 1/16','Stutter 1/16',{iv:3,of:0,gr:1,va:0,ch:1,ga:4,pi:0,pd:0,de:.1,mo:1}],['Roulement de caisse claire','Snare roll',{iv:4,of:12,gr:0,va:0,ch:1,ga:4,pi:0,pd:0,de:.0,mo:1}],['Ralentissement bande','Tape stop',{iv:5,of:8,gr:3,va:0,ch:1,ga:8,pi:-12,pd:.9,de:.3,mo:1}],['Pluie de grains','Grain shower',{iv:2,of:0,gr:0,va:.8,ch:.7,ga:6,pi:0,pd:0,de:.3,mo:0}],['Écho rythmique','Rhythmic echo',{iv:3,of:0,gr:2,va:0,ch:1,ga:8,pi:0,pd:0,de:.35,mo:0}],['Radio cassée','Broken radio',{iv:3,of:0,gr:1,va:.4,ch:.6,ga:6,pi:0,pd:0,de:.2,mo:1,fl:1,fc:1800,fq:3}],['Plongée grave','Deep dive',{iv:5,of:0,gr:3,va:0,ch:1,ga:12,pi:-24,pd:.3,de:.4,mo:0}],['Mitraillette','Machine gun',{iv:3,of:0,gr:0,va:0,ch:1,ga:3,pi:0,pd:0,de:0,mo:1}],['Hasard doux','Soft chance',{iv:3,of:0,gr:2,va:.3,ch:.35,ga:8,pi:0,pd:0,de:.5,mo:0}],
 ['Drop stutter','Drop stutter',{iv:3,of:0,gr:1,va:0,ch:1,ga:6,pi:-7,pd:.5,de:.25,mo:1}],['Rewind dubstep','Dubstep rewind',{iv:4,of:0,gr:3,va:0,ch:1,ga:12,pi:-24,pd:1,de:.5,mo:1,fl:1,fc:2400,fq:2}],['Roulement de drop 1/16','Drop roll 1/16',{iv:4,of:8,gr:1,va:0,ch:1,ga:8,pi:0,pd:0,de:0,mo:1}],['Hachoir demi‑temps','Halftime chop',{iv:4,of:0,gr:2,va:.2,ch:.8,ga:8,pi:0,pd:0,de:.1,mo:2}],['Growl filtré','Filtered growl',{iv:3,of:0,gr:1,va:.3,ch:1,ga:4,pi:-5,pd:.2,de:.15,mo:1,fl:1,fc:700,fq:6}]];
/* aides d'interface partagées (Pattern + Track) pour les effets à valeurs discrètes */
var RN={iv:['1/32','1/16','1/8','1/4','1/2','1 mesure','2 mesures','4 mesures'],gr:['1/32','1/16','1/8','1/4','1/2'],mo:['Mix','Insert','Gate']},RB=[.125,.25,.5,1,2,4,8,16],RG=[.125,.25,.5,1,2],RD={iv:1,of:1,gr:1,ga:1,pi:1,mo:1,fl:1,rp:1};
function ufmt(t,k,v){if(t!=='rep')return null;v=+v;if(RN[k])return RN[k][Math.max(0,Math.min(RN[k].length-1,Math.round(v)))];if(k==='of'||k==='ga')return Math.round(v)+'/16';if(k==='pi')return Math.round(v)+' st';if(k==='fl'||k==='rp')return Math.round(v)?'oui':'non';if(k==='ch'||k==='de'||k==='va'||k==='pd')return Math.round(v*100)+' %';if(k==='vo')return v.toFixed(1)+' dB';if(k==='fc')return Math.round(v)+' Hz';return v.toFixed(2);}
function ustep(t,k){return t==='rep'&&RD[k]?1:null;}
function ustrip(x){var g=function(k,d){return x[k]==null?d:+x[k];},iv=RB[Math.round(g('iv',5))]||4,gr=RG[Math.round(g('gr',2))]||.5,ga=Math.max(1,g('ga',8))/4,o0=g('of',0)/16*iv,tot=Math.max(iv,o0+ga),n=Math.max(1,Math.min(40,Math.floor(ga/gr))),h='',i,de=g('de',.2);
 for(i=0;i<n;i++)h+='<i style="left:'+((o0+i*gr)/tot*100)+'%;width:'+Math.max(.8,gr/tot*100-.5)+'%;opacity:'+Math.max(.25,Math.pow(1-de,i))+'"></i>';
 return '<div class="repv">'+h+'<u style="left:'+(iv/tot*100)+'%"></u></div>';}
var NEWPRE={
 dly:[['Croches pointées','Dotted eighths',{tm:2,b:.45,c:5000,d:.4}],['Écho de drop','Drop echo',{tm:3,b:.5,c:3500,d:.5}],['Ping large','Wide ping',{tm:3,b:.35,c:7000,d:.9}],['Slap','Slap',{tm:0,b:.12,c:4000,d:.1}]],
 echo:[['Bande chaude','Warm tape',{a:340,b:.5,c:.6,d:.3}],['Vieille cassette','Old cassette',{a:240,b:.6,c:.9,d:.7}],['Rebond court','Short bounce',{a:110,b:.35,c:.3,d:.1}]],
 fdly:[['Triple sombre','Dark triple',{tm:3,b:.4,hp:150,lp:2500}],['Triple clair','Bright triple',{tm:2,b:.3,hp:400,lp:8000}]],
 od:[['Chaleur','Warm',{a:.3,b:3500,c:-4}],['Croustillant','Crunchy',{a:.65,b:5000,c:-7}]],
 dist:[['Industriel','Industrial',{a:.85,b:2500,c:-9}],['Mordant léger','Light bite',{a:.4,b:4500,c:-6}],['Growl dubstep','Dubstep growl',{a:.95,b:1800,c:-10}]],
 fuzz:[['Mur de fuzz','Fuzz wall',{a:.9,b:2200,c:-9}],['Fuzz doux','Soft fuzz',{a:.45,b:3200,c:-6}],['Grondement de sub','Sub rumble',{a:.8,b:1500,c:-8}]],
 tube:[['Chaud','Warm',{a:.4,b:.5,c:6000}],['Mordant','Biting',{a:.8,b:.8,c:9000}]],
 ero:[['Grain fin','Fine grain',{a:.3,b:6000,c:3}],['Rouille','Rust',{a:.8,b:1500,c:.8}]],
 bus:[['Batterie punchy','Punchy drums',{a:.7,b:.3,c:5,d:3}],['Boom','Boom',{a:.4,b:.2,c:10,d:1}]],
 gate:[['Sec','Tight',{a:-32,b:60}],['Naturel','Natural',{a:-45,b:200}],['Hachoir','Chopper',{a:-28,b:35}]],
 lim:[['Doux','Gentle',{a:3,b:-1}],['Brique','Brickwall',{a:12,b:-.5}]],
 glue:[['Liant','Glue',{a:-18,b:2.5,c:.3,d:3}],['Pompage','Pumping',{a:-26,b:6,c:.12,d:6}]],
 mband:[['Mastering doux','Gentle master',{a:-22,b:2,c:1,d:1}],['Écrasé','Crushed',{a:-32,b:6,c:3,d:2}]],
 filt:[['Wah lent','Slow wah',{ty:2,f:900,q:8,sw:.6,r:.4}],['Passe-bas sombre','Dark low-pass',{ty:0,f:500,q:2,sw:.1,r:.2}],['Balayage vif','Fast sweep',{ty:0,f:1500,q:10,sw:.9,r:2}],['Wobble 1/4 (140)','Wobble 1/4 (140)',{ty:0,f:380,q:10,sw:.9,r:2.3}],['Wobble 1/8 (140)','Wobble 1/8 (140)',{ty:0,f:420,q:9,sw:.85,r:4.7}],['Ouah de grenouille','Frog yow',{ty:2,f:700,q:14,sw:.8,r:2.3}]],
 eq4:[['Présence','Presence',{a:0,b:-2,c:4,d:3,fm:2000}],['Chaleur','Warmth',{a:4,b:2,c:-2,d:-3,fm:1200}],['Téléphone','Telephone',{a:-15,b:6,c:6,d:-15,fm:1500}]],
 amp:[['Clair','Clean',{g:.2,b:0,md:2,tr:2,v:-2}],['Rock','Rock',{g:.65,b:2,md:3,tr:0,v:-4}],['Lead saturé','Hot lead',{g:.95,b:1,md:4,tr:-1,v:-6}]],
 cab:[['Petit combo','Small combo',{s:.1,r:4}],['Grand baffle','Big stack',{s:.9,r:2}]],
 pump:[['Sidechain noire','Quarter sidechain',{d:.8,cd:0,s:.4}],['Croches','Eighths',{d:.55,cd:1,s:.6}],['Trémolo double','Double trem',{d:.4,cd:2,s:.1}],['Dubstep demi‑temps','Dubstep halftime',{d:.9,cd:0,s:.3}]],
 orb:[['Lente et large','Slow wide',{r:.15,w:1,d:.6}],['Tourbillon','Whirl',{r:2.2,w:.9,d:.3}]],
 verb:[['Petite pièce','Small room',{a:.15,b:.6,pd:5,w:1,lc:150}],['Cathédrale','Cathedral',{a:.95,b:.35,pd:40,w:1,lc:200}],['Voix aérienne','Airy vocal',{a:.55,b:.8,pd:60,w:1,lc:250}],['Hall de drop','Drop hall',{a:.85,b:.3,pd:20,w:.7,lc:200}]],
 grev:[['Années 80','80s',{a:.5,b:.7,lc:200}],['Coup sec','Snap',{a:.15,b:.5,lc:300}]],
 dub:[['Dub classique','Classic dub',{a:375,b:.65,hp:300,lp:2800,dr:.3}],['Spirale','Spiral',{a:250,b:.88,hp:400,lp:2000,dr:.5}],['Écho dubstep','Dubstep echo',{a:330,b:.6,hp:200,lp:2200,dr:.35}]],
 rez:[['Accord mineur','Minor chord',{n:48,k:2,q:34}],['Quinte vitreuse','Glassy fifth',{n:52,k:1,q:60}]],
 ens:[['Large','Wide',{a:.5,b:.8}],['Doux','Soft',{a:.25,b:.4}]]};NEWPRE.rep=REPPRE;
/* ══ R426 : famille spectrale (STFT 1024 / recouvrement ×4, un seul worklet, latence ≈ 23 ms) ══ */
function sdef(id,fr,en,P,mode,pre){def(id,'cre',fr,en,4,P,function(c){var u=wfx(c,'qspec',null,function(){return {numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[2],processorOptions:{mode:mode}};});u.onset=function(n,v){try{n.port.postMessage({a:v.a,b:v.b});}catch(e){}};return u;});NEWPRE[id]=pre;}
sdef('sblur','Flou spectral','Spectral blur',[['a','Étalement dans le temps','Time smear',0,1,.6],['b','Étalement des fréquences','Frequency smear',0,1,.2]],0,[['Brume douce','Soft haze',{a:.5,b:.2}],['Nappe infinie','Endless pad',{a:.95,b:.6}],['Voile fin','Fine veil',{a:.3,b:0}]]);
sdef('sfrz','Gel spectral','Spectral freeze',[['a','Gel (≥ 0,5)','Freeze (≥ 0.5)',0,1,1],['b','Scintillement','Shimmer',0,1,.15]],1,[['Drone fixe','Static drone',{a:1,b:0}],['Drone vivant','Living drone',{a:1,b:.5}]]);
sdef('sgat','Porte spectrale','Spectral gate',[['a','Seuil','Threshold',0,1,.25],['b','Reste (0 = coupé)','Leftover (0 = cut)',0,1,0]],2,[['Chuchotement','Whisper',{a:.2,b:0}],['Squelette','Skeleton',{a:.5,b:.05}],['Doux','Gentle',{a:.1,b:.3}]]);
sdef('sshf','Décalage spectral','Spectral shift',[['a','Décalage (bandes)','Shift (bins)',-60,60,8],['b','Quantité','Amount',0,1,1]],3,[['Métallique','Metallic',{a:8,b:1}],['Cloche grave','Low bell',{a:-12,b:.8}],['Étrange','Strange',{a:30,b:1}]]);
window.QFXE={mod:{ok:modOk,vals:mvals,shapes:MODSH,seq0:SEQ0},fmt:ufmt,step:ustep,strip:ustrip,presets:NEWPRE,defs:DEFS,order:ORDER,fam:FAM,chains:CHAINS,max:MAXFX,def:def,bank:BANK,loadBank:loadBank,prep:prep,H:H,bankIds:BANKIDS,chain:chain,sig:sig,cost:cost,live:live,norm:norm,
  fresh:function(t){var d=DEFS[t];if(!d)return null;var x={t:t,on:1,m:d.mix?.5:1};d.P.forEach(function(p){x[p[0]]=p[5];});return x;},
  clean:function(list){var o=[];(Array.isArray(list)?list:[]).forEach(function(x){if(x&&(DEFS[x.t]||BANKIDS.indexOf(x.t)>=0)&&o.length<MAXFX)o.push(JSON.parse(JSON.stringify(x)));});return o;}};
})();
