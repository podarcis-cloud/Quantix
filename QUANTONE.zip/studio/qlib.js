/* QUANTONE — Bibliothèque unique (R405), même composant dans Pattern et Track.
   Une seule base IndexedDB « qxlib » (magasin « items ») : patterns { id, name, col, proj, ver, cr, qx, au? }
   et tracks { id, kind:'track', name, proj, ver, cr, p } (p = format interne de Track, comme le brouillon).
   3 onglets : Patterns (groupés par projet) · Tracks · Sons du jeu.
   La page fournit ses actions : QLIB.mount({kind:'p'|'t', anchor, triggers, toast, save, cur, openP, useP, openT, addP, game, changed, renderAu}). */
(function(){
'use strict';
var L={
 fr:{title:'Bibliothèque',close:'Fermer',tabs:{p:'Patterns',t:'Tracks',g:'Sons du jeu'},search:'Chercher un pattern…',all:'Tous les projets',rec:'Récent',nm:'Nom',
  emptyP:'Bibliothèque vide : Fichier ▸ Enregistrer ce pattern.',emptyPP:'Aucun pattern dans ce projet pour l’instant.',noMatch:'Aucun pattern ne correspond.',
  emptyT:'Aucune track enregistrée. Dans Track : Fichier ▸ Enregistrer cette track.',
  open:'Ouvrir',use:{p:'Track ▸',t:'Poser'},useT:{p:'Utiliser dans Track',t:'Poser sur une piste'},ren:'Renommer',dup:'Dupliquer',del:'Supprimer',col:'Couleur',
  xq:'Exporter .qpt',xqx:'Exporter .qxp',xNo:'sans le son',xYes:'avec le son',goT:'Aller dans Track ?',name:'Nom',proj:'Projet',
  strokes:function(n){return n+' trait'+(n>1?'s':'');},tracks:function(n){return n+' piste'+(n>1?'s':'');},blocks:function(n){return n+' bloc'+(n>1?'s':'');},
  bis:' bis',noProj:'Sans projet',done:'Fichier prêt',noSnd:'Son pas encore calculé : fichier sans le son (ouvre le pattern puis Fichier ▸ Exporter avec le son)',
  gIntro:{p:'Ajoute la musique d’un niveau du jeu comme bloc audio dans Track.',t:'Ajoute la musique d’un niveau du jeu comme bloc audio.'},world:'Monde',level:'Niv.',gAdd:{p:'Ajouter dans Track ▸',t:'Ajouter à la track'},
  unavailable:'Bibliothèque indisponible sur cet appareil.',renamed:'Renommé',deleted:'Supprimé',copied:'Copie créée'},
 en:{title:'Library',close:'Close',tabs:{p:'Patterns',t:'Tracks',g:'Game sounds'},search:'Search a pattern…',all:'All projects',rec:'Recent',nm:'Name',
  emptyP:'Empty library: File ▸ Save this pattern.',emptyPP:'No pattern in this project yet.',noMatch:'No match.',
  emptyT:'No saved track yet. In Track: File ▸ Save this track.',
  open:'Open',use:{p:'Track ▸',t:'Place'},useT:{p:'Use in Track',t:'Place on a track'},ren:'Rename',dup:'Duplicate',del:'Delete',col:'Colour',
  xq:'Export .qpt',xqx:'Export .qxp',xNo:'without sound',xYes:'with sound',goT:'Go to Track?',name:'Name',proj:'Project',
  strokes:function(n){return n+' stroke'+(n>1?'s':'');},tracks:function(n){return n+' track'+(n>1?'s':'');},blocks:function(n){return n+' block'+(n>1?'s':'');},
  bis:' copy',noProj:'No project',done:'File ready',noSnd:'Sound not computed yet: file without sound (open the pattern, then File ▸ Export with sound)',
  gIntro:{p:'Adds the music of a game level as an audio block in Track.',t:'Adds the music of a game level as an audio block.'},world:'World',level:'Level',gAdd:{p:'Add in Track ▸',t:'Add to the track'},
  unavailable:'Library unavailable on this device.',renamed:'Renamed',deleted:'Deleted',copied:'Copy created'}};
var IC={
 trk:'<svg viewBox="0 0 24 24"><path d="M3 6h9M7 12h12M3 18h7M14 18h7"/></svg>',
 ren:'<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
 dup:'<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>',
 exp:'<svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/></svg>',
 del:'<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
 x:'<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>'};
var CSS='#qLibPanel{position:fixed;left:8px;right:8px;margin:0 auto;max-width:440px;z-index:1000;display:none;box-sizing:border-box;border-radius:22px;background:#08101e;box-shadow:0 0 0 1px #243248,0 22px 44px rgba(0,0,0,.6);padding:10px;color:#e8f1fb;font:14px/1.3 "Space Grotesk","Avenir Next",system-ui,sans-serif;-webkit-text-size-adjust:100%;overflow-x:hidden;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;text-align:left}'+
 '#qLibPanel.on{display:block;animation:qlIn .16s ease-out}@keyframes qlIn{from{opacity:0;transform:translateY(-6px)}}#qLibPanel *{box-sizing:border-box}'+
 '#qLibPanel button,#qLibPanel select,#qLibPanel input{font-family:"Space Grotesk","Avenir Next",system-ui,sans-serif;box-shadow:none;transform:none;text-transform:none;letter-spacing:normal;outline:none;margin:0}'+
 '#qLibPanel svg{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}'+
 '#qLibPanel .qlh{display:flex;align-items:center;gap:8px;margin:0 0 8px 4px}#qLibPanel .qlh b{flex:1;font:600 15px "Space Grotesk",system-ui,sans-serif}'+
 '#qLibPanel button{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:40px;min-width:40px;border:1px solid #243248;background:rgba(255,255,255,.03);color:#cfe0f5;border-radius:99px;padding:0 12px;font-weight:500;font-size:12.5px;white-space:nowrap;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
 '#qLibPanel button.on{color:#EAF6FF;border-color:#6EE2FF;background:rgba(110,226,255,.12)}#qLibPanel button:active{background:rgba(110,226,255,.12)}'+
 '#qLibPanel .qtab{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin:0 0 10px}#qLibPanel .qtab button{padding:0 6px;font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis}#qLibPanel .qtab button.on{border-color:#4DB8FF}'+
 '#qLibPanel .lt{display:flex;gap:6px;align-items:center;margin-bottom:8px}#qLibPanel .lt input{flex:1;min-width:0;height:40px;background:#0b111b;color:#EAF6FF;border:1px solid #243248;border-radius:99px;padding:0 14px;font-size:16px}'+
 '#qLibPanel .lc{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 8px}#qLibPanel .lc button{font-size:12px}'+
 '#qLibPanel .lr{display:grid;grid-template-columns:48px minmax(0,1fr);gap:6px 10px;align-items:center;padding:8px 4px;border-top:1px solid #16202f}#qLibPanel .lr.cur{background:rgba(110,226,255,.06);border-radius:12px}'+
 '#qLibPanel canvas,#qLibPanel .ti{width:48px;height:34px;border-radius:8px;background:#0b111b}#qLibPanel .ti{display:grid;place-items:center;color:#6EE2FF}'+
 '#qLibPanel .ln{min-width:0}#qLibPanel .ln b{display:block;font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#qLibPanel .ln small{display:block;color:#7f93b0;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}'+
 '#qLibPanel .ln input{width:100%;height:40px;background:#0b111b;color:#EAF6FF;border:1px solid #6EE2FF;border-radius:10px;padding:0 10px;font-size:16px;margin-top:4px}#qLibPanel .ln input:first-child{margin-top:0}'+
 '#qLibPanel .la{display:flex;gap:4px;flex-wrap:wrap;grid-column:1/3;justify-content:flex-end}#qLibPanel .la button{padding:0 8px;border-radius:12px}#qLibPanel .la button.ic{padding:0;width:40px}'+
 '#qLibPanel button.arm{background:#B3261E;border-color:#B3261E;color:#fff}#qLibPanel button.pri{border-color:#6EE2FF;color:#EAF6FF}'+
 '#qLibPanel .lx{grid-column:1/3;display:flex;gap:6px;align-items:center;justify-content:flex-end;flex-wrap:wrap;font-size:12px;color:#8fb8d8}'+
 '#qLibPanel .lh{color:#8fb8d8;font:600 10px ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.14em;text-transform:uppercase;margin:10px 2px 2px}#qLibPanel .le{color:#7f93b0;padding:14px 4px;font-size:13px}'+
 '#qLibPanel .gm{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}#qLibPanel .gm select{height:44px;border-radius:14px;border:1px solid #243248;background:#0b111b;color:#EAF6FF;padding:0 10px;font-size:16px;min-width:0}#qLibPanel .gm button{grid-column:1/3;min-height:44px;border-radius:14px}';
var C=null,P=null,TAB=null,MQ='',MP=null,MS='rec',REN=null,XP=null,CACHE=[],GW='1',GL='1';
function lang(){try{if(window.QFILE)return QFILE.lang();}catch(e){}try{var l=localStorage.getItem('qx.lang');if(l==='en'||l==='fr')return l;}catch(e){}return (navigator.language||'fr').slice(0,2)==='fr'?'fr':'en';}
function X(){return L[lang()];}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
/* ── base unique ── */
var DB0=null;   /* R410 LÉGÈRETÉ : une seule connexion IndexedDB réutilisée (avant : une nouvelle à chaque liste, jamais fermée) */
function db(cb){if(DB0)return cb(DB0);try{var r=indexedDB.open('qxlib',1);r.onupgradeneeded=function(){r.result.createObjectStore('items',{keyPath:'id'});};r.onsuccess=function(){DB0=r.result;DB0.onversionchange=function(){try{DB0.close();}catch(e){}DB0=null;};DB0.onclose=function(){DB0=null;};cb(DB0);};r.onerror=function(){cb(null);};}catch(e){cb(null);}}
function all(cb){db(function(d){if(!d)return cb(null);try{var q=d.transaction('items').objectStore('items').getAll();q.onsuccess=function(){cb(q.result||[]);};q.onerror=function(){cb(null);};}catch(e){cb(null);}});}
function put(it,cb){db(function(d){if(!d){if(cb)cb(false);return;}try{var tx=d.transaction('items','readwrite');tx.objectStore('items').put(it);tx.oncomplete=function(){if(cb)cb(true);};tx.onerror=function(){if(cb)cb(false);};}catch(e){if(cb)cb(false);}});}
function del(id,cb){db(function(d){if(!d){if(cb)cb(false);return;}try{var tx=d.transaction('items','readwrite');tx.objectStore('items').delete(id);tx.oncomplete=function(){if(cb)cb(true);};tx.onerror=function(){if(cb)cb(false);};}catch(e){if(cb)cb(false);}});}
function isT(it){return it&&it.kind==='track';}
function newId(p){return p+Date.now().toString(36)+Math.floor(Math.random()*1e4).toString(36);}
function pj(it){return it.proj||'Sans projet';}
function pjL(p){return p==='Sans projet'?X().noProj:p;}
function cur(){var c=(C&&C.cur&&C.cur())||{};return c;}
function toast(m,ms){if(C&&C.toast)C.toast(m,ms);}
/* ── rendu ── */
function thumb(cv,it){var c=cv.getContext('2d'),W=cv.width=96,H=cv.height=68,S=(it.qx&&it.qx.preset&&it.qx.preset.strokes)||[];c.clearRect(0,0,W,H);c.lineWidth=2.2;c.lineCap='round';c.lineJoin='round';
 S.forEach(function(s,i){var p=s.p||s.pts;if(!p||p.length<2)return;c.strokeStyle=it.col||'#72D6D2';c.globalAlpha=i%2?.6:.95;c.beginPath();p.forEach(function(q,k){var x=4+q[0]*(W-8),y=4+q[1]*(H-8);if(k)c.lineTo(x,y);else c.moveTo(x,y);});c.stroke();});c.globalAlpha=1;}
function dur(p){var e=0;((p&&p.clips)||[]).forEach(function(c){e=Math.max(e,(c.start||0)+(c.len||0));});e=Math.round(e);return Math.floor(e/60)+':'+('0'+e%60).slice(-2);}
function day(t){if(!t)return '';var d=new Date(t);return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2);}
function bt(a,txt,o){o=o||{};return '<button type="button" data-a="'+a+'"'+(o.cls?' class="'+o.cls+'"':'')+(o.lab?' aria-label="'+esc(o.lab)+'" title="'+esc(o.lab)+'"':'')+(o.st?' style="'+o.st+'"':'')+'>'+txt+'</button>';}
function render(useC){if(!P)return;(useC&&CACHE&&CACHE.length?function(f){f(CACHE);}:all)(function(LL){   /* R410 : la recherche relit la liste déjà chargée (pas toute la base à chaque frappe) */
if(!P.classList.contains('on'))return;var x=X(),k=C.kind;
 if(!LL){P.innerHTML='<div class="qlh"><b>'+x.title+'</b>'+bt('close',IC.x,{cls:'ic',lab:x.close})+'</div><div class="le">'+x.unavailable+'</div>';return;}
 CACHE=LL;var PL=LL.filter(function(i){return !isT(i);}),TL=LL.filter(isT),ae=document.activeElement&&P.contains(document.activeElement)?document.activeElement.id:null;
 var h='<div class="qlh"><b>'+x.title+'</b>'+bt('close',IC.x,{cls:'ic',lab:x.close})+'</div>'+
  '<div class="qtab" role="tablist">'+['p','t','g'].map(function(t){return '<button type="button" role="tab" data-tab="'+t+'" class="'+(TAB===t?'on':'')+'" aria-selected="'+(TAB===t)+'">'+x.tabs[t]+(t==='p'?' · '+PL.length:t==='t'?' · '+TL.length:'')+'</button>';}).join('')+'</div>';
 if(TAB==='p')h+=patsHtml(PL,x,k);else if(TAB==='t')h+=trksHtml(TL,x,k);else h+=gameHtml(x,k);
 P.innerHTML=h;
 if(TAB==='p')PL.forEach(function(it){var cv=P.querySelector('canvas[data-t="'+CSS_(it.id)+'"]');if(cv)thumb(cv,it);});
 var qi=P.querySelector('#qLibQ');if(qi){qi.oninput=function(){MQ=qi.value;var pos=qi.selectionStart;render2(1,function(){var n=P.querySelector('#qLibQ');if(n){n.focus();try{n.setSelectionRange(pos,pos);}catch(e){}}});};}
 var ri=P.querySelector('input[data-a="nm"]');if(ri){var rp=P.querySelector('input[data-a="pjn"]');try{ri.focus();ri.select();}catch(e){}
  var fin=function(ok){var it=find(REN);REN=null;if(ok&&it){var nv=(ri.value||'').trim(),np=rp?((rp.value||'').trim()||'Sans projet'):null,ch=false;if(nv&&nv!==it.name){it.name=nv;ch=true;}if(rp&&np!==pj(it)){it.proj=np;ch=true;}
    if(ch){it.ver=Date.now();put(it,function(){if(C.changed)C.changed('ren',it);render();});return;}}render();};
  var blur=function(e){var to=e.relatedTarget;if(to===ri||to===rp)return;fin(true);};ri.onblur=blur;if(rp)rp.onblur=blur;
  var kd=function(e){if(e.key==='Enter'){ri.onblur=null;if(rp)rp.onblur=null;fin(true);}else if(e.key==='Escape'){ri.onblur=null;if(rp)rp.onblur=null;fin(false);}};ri.onkeydown=kd;if(rp)rp.onkeydown=kd;}
 var gw=P.querySelector('#qlGw'),gl=P.querySelector('#qlGl');if(gw){gw.value=GW;gl.value=GL;gw.onchange=function(){GW=gw.value;};gl.onchange=function(){GL=gl.value;};}
 if(ae&&ae!=='qLibQ'){var a2=P.querySelector('#'+ae);if(a2)try{a2.focus();}catch(e){}}
 if(C.onrender)C.onrender();});}
function render2(u,cb){if(typeof u==='function'){cb=u;u=0;}var o=C.onrender;C.onrender=function(){C.onrender=o;if(cb)cb();if(o)o();};render(!!u);}
function CSS_(s){return String(s).replace(/["\\]/g,'\\$&');}
function patsHtml(PL,x,k){var c=cur(),cp=c.proj||'',scope=MP===null?(cp?cp:'*'):MP,cnt={},names=[];
 PL.forEach(function(it){var p=pj(it);if(!cnt[p]){cnt[p]=0;names.push(p);}cnt[p]++;});names.sort(function(a,b){return a.localeCompare(b);});
 var q=MQ.trim().toLowerCase(),rows=PL.filter(function(it){return (scope==='*'||pj(it)===scope)&&(!q||String(it.name||'').toLowerCase().indexOf(q)>=0);});
 rows.sort(function(a,b){return MS==='nm'?String(a.name).localeCompare(String(b.name)):(b.ver||0)-(a.ver||0);});
 var h='<div class="lt"><input id="qLibQ" type="search" autocomplete="off" placeholder="'+esc(x.search)+'" value="'+esc(MQ)+'">'+(C.addP?bt('add','＋',{cls:'ic',lab:k==='p'?(lang()==='fr'?'Enregistrer ce pattern':'Save this pattern'):''}):'')+'</div>';
 h+='<div class="lc">'+(cp&&cnt[cp]==null?'<button type="button" class="on" data-p="'+esc(cp)+'">'+esc(pjL(cp))+' · 0</button>':'')+names.map(function(p){return '<button type="button" data-p="'+esc(p)+'" class="'+(scope===p?'on':'')+'">'+esc(pjL(p))+' · '+cnt[p]+'</button>';}).join('')+'<button type="button" data-p="*" class="'+(scope==='*'?'on':'')+'">'+x.all+' · '+PL.length+'</button></div>';
 h+='<div class="lc"><button type="button" data-s="rec" class="'+(MS==='rec'?'on':'')+'">'+x.rec+'</button><button type="button" data-s="nm" class="'+(MS==='nm'?'on':'')+'">'+x.nm+'</button></div>';
 if(!rows.length)h+='<div class="le">'+(q?x.noMatch:(scope==='*'||!PL.length?x.emptyP:x.emptyPP))+'</div>';
 var lastP=null;h+='<datalist id="qlPjL">'+names.map(function(p){return '<option value="'+esc(p)+'">';}).join('')+'</datalist>';
 rows.forEach(function(it){if(scope==='*'&&pj(it)!==lastP){lastP=pj(it);h+='<div class="lh">'+esc(pjL(lastP))+'</div>';}var inf=(it.qx&&it.qx.info)||{};
  h+='<div class="lr'+(it.id===c.pid?' cur':'')+'" data-id="'+esc(it.id)+'"><canvas data-t="'+esc(it.id)+'"></canvas><div class="ln">'+
   (REN===it.id?'<input data-a="nm" id="qlRenN" value="'+esc(it.name)+'" maxlength="40" aria-label="'+x.name+'"><input data-a="pjn" id="qlRenP" list="qlPjL" value="'+esc(pj(it))+'" maxlength="40" aria-label="'+x.proj+'">':'<b>'+esc(it.name)+'</b><small>'+(inf.strokes!=null?x.strokes(inf.strokes):'')+(inf.tempo?' · '+inf.tempo+' bpm':'')+(scope==='*'?'':'')+'</small>')+'</div>'+
   '<div class="la">'+bt('col','',{cls:'ic',lab:x.col,st:'background:'+esc(it.col||'#72D6D2')+';border-color:transparent'})+bt('open',x.open)+bt('use',x.use[k],{lab:x.useT[k]})+bt('ren',IC.ren,{cls:'ic',lab:x.ren})+bt('dup',IC.dup,{cls:'ic',lab:x.dup})+bt('qpt',IC.exp,{cls:'ic'+(XP===it.id?' on':''),lab:x.xq})+bt('del',IC.del,{cls:'ic',lab:x.del})+'</div>'+
   (XP===it.id?'<div class="lx"><span>'+x.xq+'</span>'+bt('qpt0',x.xNo)+bt('qpt1',x.xYes,{cls:'pri'})+'</div>':'')+'</div>';});
 return h;}
function trksHtml(TL,x,k){var c=cur(),h='';TL=TL.slice().sort(function(a,b){return (b.ver||0)-(a.ver||0);});
 if(!TL.length)h+='<div class="le">'+x.emptyT+'</div>';
 TL.forEach(function(it){var p=it.p||{};
  h+='<div class="lr lrt'+(it.id===c.tid?' cur':'')+'" data-id="'+esc(it.id)+'"><span class="ti">'+IC.trk+'</span><div class="ln">'+
   (REN===it.id?'<input data-a="nm" id="qlRenN" value="'+esc(it.name)+'" maxlength="40" aria-label="'+x.name+'">':'<b>'+esc(it.name)+'</b><small>'+x.tracks((p.tracks||[]).length)+' · '+x.blocks((p.blocks||[]).length)+' · '+dur(p)+(it.proj?' · '+esc(pjL(it.proj)):'')+' · '+day(it.ver)+'</small>')+'</div>'+
   '<div class="la">'+bt('topen',x.open,{lab:k==='p'?x.goT:x.open})+bt('ren',IC.ren,{cls:'ic',lab:x.ren})+bt('dup',IC.dup,{cls:'ic',lab:x.dup})+bt('qxp',IC.exp,{cls:'ic',lab:x.xqx})+bt('del',IC.del,{cls:'ic',lab:x.del})+'</div></div>';});
 return h;}
function gameHtml(x,k){var i,w='',l='';for(i=1;i<=5;i++)w+='<option value="'+i+'">'+x.world+' '+i+'</option>';for(i=1;i<=12;i++)l+='<option value="'+i+'">'+x.level+' '+i+'</option>';
 return '<div class="le" style="padding:4px 4px 0">'+x.gIntro[k]+'</div><div class="gm"><select id="qlGw" aria-label="'+x.world+'">'+w+'</select><select id="qlGl" aria-label="'+x.level+'">'+l+'</select>'+bt('game',x.gAdd[k],{cls:'pri'})+'</div>';}
function find(id){return CACHE.filter(function(x){return x.id===id;})[0];}
/* ── fichiers depuis la bibliothèque ── */
function b64(ab){var u=new Uint8Array(ab),s='',i;for(i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s);}
function expQpt(it,ws){var x=X();function go(au){var o=QPT.fromQx(it.qx,{id:it.id,name:it.name,proj:it.proj,col:it.col,cr:it.cr,ver:it.ver},au||null);
  return QPT.slim(o).then(function(s2){var bl=new Blob([JSON.stringify(s2)],{type:'application/octet-stream'});C.save(bl,QPT.fileName(it.name,'qpt'));toast(x.done,1600);return s2;});}
 if(!ws)return go(null);if(it.au&&it.au.l)return go(it.au);
 var pr=C.renderAu?C.renderAu(it):null;return Promise.resolve(pr).then(function(au){if(!au)toast(x.noSnd,5000);return go(au);});}
function trkV1(p){var o=JSON.parse(JSON.stringify(Object.assign({},p,{blocks:[]})));o.blocks=(p.blocks||[]).map(function(b){var r={},k;for(k in b)if(k!=='data')r[k]=b[k];r=JSON.parse(JSON.stringify(r));if(b.data!=null)r.data=typeof b.data==='string'?b.data:b64(b.data);return r;});return o;}
function expQxp(it){var x=X();return QPT.packQxp(trkV1(it.p||{}),{name:it.name}).then(function(v2){var bl=new Blob([JSON.stringify(v2)],{type:'application/octet-stream'});C.save(bl,QPT.fileName(it.name,'qxp'));toast(x.done,1600);return v2;});}
function arm(t,lab,fn){if(t.dataset.armed==='1'){clearTimeout(t._t);t.dataset.armed='';fn();return;}
 t.dataset.armed='1';t.classList.add('arm');var old=t.innerHTML;if(lab)t.textContent=lab;t._t=setTimeout(function(){if(t.isConnected){t.dataset.armed='';t.classList.remove('arm');t.innerHTML=old;}},3000);}
function click(e){var t=e.target.closest&&e.target.closest('[data-a],[data-p],[data-s],[data-tab]');if(!t||!C||!P.contains(t))return;var x=X();
 if(t.dataset.tab){TAB=t.dataset.tab;REN=null;XP=null;render();return;}
 if(t.dataset.p!=null){MP=t.dataset.p;render();return;}if(t.dataset.s){MS=t.dataset.s;render();return;}
 var a=t.dataset.a;if(a==='close'){close();return;}
 if(a==='add'){close();if(C.addP)C.addP();return;}
 if(a==='game'){var w=(P.querySelector('#qlGw')||{}).value||GW,l=(P.querySelector('#qlGl')||{}).value||GL;GW=w;GL=l;close();if(C.game)C.game(w,l);return;}
 if(a==='nm'||a==='pjn')return;
 var row=t.closest('.lr'),it=row&&find(row.dataset.id);if(!it)return;
 if(a==='open'){if(C.openP&&C.openP(it)!==false)close();}
 else if(a==='use'){close();if(C.useP)C.useP(it);}
 else if(a==='topen'){if(C.kind==='p'){arm(t,x.goT,function(){close();C.openT(it);});return;}close();C.openT(it);}
 else if(a==='ren'){REN=it.id;XP=null;render();}
 else if(a==='col'){var CL=C.cols||['#72D6D2','#EE9AA8','#A99AEE','#EBC27A','#8ED9A0','#7FB4F0','#D58CE0','#F0AC8A'];it.col=CL[(CL.indexOf(it.col)+1)%CL.length];put(it,function(){if(C.changed)C.changed('col',it);render();});}
 else if(a==='dup'){var n=JSON.parse(JSON.stringify(Object.assign({},it,{p:undefined})));if(isT(it))n.p=dupP(it.p);n.id=newId(isT(it)?'t':'l');n.name=it.name+x.bis;n.ver=Date.now();n.cr=Date.now();
  if(it.au&&!isT(it))n.au=it.au;put(n,function(ok){if(ok){toast(x.copied+' : '+n.name,1600);if(C.changed)C.changed('dup',n);}render();});}
 else if(a==='qpt'){XP=XP===it.id?null:it.id;render();}
 else if(a==='qpt0'||a==='qpt1'){XP=null;render();expQpt(it,a==='qpt1');}
 else if(a==='qxp'){expQxp(it);}
 else if(a==='del'){arm(t,'',function(){del(it.id,function(){if(C.changed)C.changed('del',it);render();});});}}
function dupP(p){if(!p)return p;var o=Object.assign({},p);o.blocks=(p.blocks||[]).map(function(b){return Object.assign({},b);});return o;}   /* structured clone par IndexedDB : les ArrayBuffer audio sont copiés */
function place(){if(!P||!C)return;var a=C.anchor&&(typeof C.anchor==='function'?C.anchor():C.anchor),t=a?Math.round(a.getBoundingClientRect().bottom+6):8;t=Math.max(4,Math.min(t,innerHeight-220));P.style.top=t+'px';P.style.maxHeight=Math.max(200,innerHeight-t-8)+'px';}
function open(tab){if(!P)return;if(window.QFILE&&QFILE.isOpen())QFILE.close();if(tab)TAB=tab;if(!TAB)TAB=C.kind==='t'?'t':'p';MP=null;MQ='';REN=null;XP=null;P.classList.add('on');place();P.innerHTML='';render();(C.triggers||[]).forEach(function(b){if(b&&b.setAttribute)b.setAttribute('aria-expanded','true');});if(C.onopen)C.onopen();}
function close(){if(!P||!P.classList.contains('on'))return;CACHE=[];   /* R410 : liste libérée à la fermeture */P.classList.remove('on');REN=null;XP=null;(C.triggers||[]).forEach(function(b){if(b&&b.setAttribute)b.setAttribute('aria-expanded','false');});if(C.onclose)C.onclose();}
function isOpen(){return !!(P&&P.classList.contains('on'));}
function css(){if(document.getElementById('qlCss'))return;var s=document.createElement('style');s.id='qlCss';s.textContent=CSS;document.head.appendChild(s);}
function mount(cfg){css();C=cfg;if(!P){P=document.createElement('div');P.id='qLibPanel';P.setAttribute('role','dialog');document.body.appendChild(P);P.addEventListener('click',click);
  document.addEventListener('pointerdown',function(e){if(!isOpen()||P.contains(e.target))return;var tg=C.triggers||[];for(var i=0;i<tg.length;i++)if(tg[i]&&tg[i].contains&&tg[i].contains(e.target))return;close();},true);
  addEventListener('keydown',function(e){if(e.key==='Escape'&&isOpen()&&!REN)close();});addEventListener('resize',function(){if(isOpen())place();});
  try{addEventListener('storage',function(e){if(e.key==='qx.lang'&&isOpen())render();});}catch(e){}}
 return api;}
var api={mount:mount,open:open,close:close,toggle:function(tab){isOpen()?close():open(tab);},isOpen:isOpen,render:function(){if(isOpen())render();},
 state:function(){var c=cur(),cp=c.proj||'';return {open:isOpen(),tab:TAB,scope:MP===null?(cp||'*'):MP};},
 all:all,put:put,del:del,isTrack:isT,newId:newId,exportQpt:expQpt,exportQxp:expQxp,trkV1:trkV1,L:L};
window.QLIB=api;
})();
