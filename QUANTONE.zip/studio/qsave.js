/* R445 — Enregistrement de fichiers : UN SEUL code pour Pattern (quantone.html) et Track (morceau.html).
   Avant : trois copies (qxSaveSheet/qxDl dans Pattern, audOut/save dans Track, ancien partage direct pour le .qxp).
   API
     QSAVE.out(name, blob, {aud, handle})  écrit dans le fichier choisi (handle) ; sinon feuille « nom + emplacement »
                                            si le partage de fichiers existe (iPhone) ; sinon téléchargement direct.
     QSAVE.sheet(name, blob, aud)           la feuille seule (aud=true : « Exporter l’audio », Télécharger en premier)
     QSAVE.write(handle, blob)              écrit dans un fichier choisi (sélecteur natif)
     QSAVE.dl(name, blob)                   téléchargement direct (l’URL reste valable 120 s : iOS lit le fichier après l’appui)
     QSAVE.canShare(blob, name)             vrai si la feuille de partage de fichiers est disponible
   Les pages posent QSAVE.hooks = { toast(msg, ms), panel(titre, détail), lang() } (valeurs par défaut sûres). */
(function(){
 var Q=window.QSAVE=window.QSAVE||{};
 var H=Q.hooks={
  toast:function(){},
  panel:null,
  lang:function(){try{if(window.QFILE&&QFILE.lang)return QFILE.lang();}catch(e){}return 'fr';}
 };
 var TX={
  fr:{ok:'Fichier proposé au téléchargement.',no:'Téléchargement refusé ou indisponible ici.',aud:'Exporter l’audio',file:'Enregistrer le fichier',
      dl:'Télécharger',folder:'Choisir un autre dossier…',where:'Choisir l’emplacement…',cancel:'Annuler',
      wfail:'Écriture impossible',sfail:'Partage impossible',mo:' Mo',ko:' ko'},
  en:{ok:'File offered for download.',no:'Download declined or unavailable here.',aud:'Export audio',file:'Save file',
      dl:'Download',folder:'Choose a folder…',where:'Choose location…',cancel:'Cancel',
      wfail:'Saving failed',sfail:'Sharing failed',mo:' MB',ko:' kB'}
 };
 function T(k){return TX[H.lang()==='en'?'en':'fr'][k];}
 function fail(title,e){var d=(e&&(e.name+' : '+e.message))||'';if(H.panel)H.panel(title,d);else H.toast(title+(d?' — '+d:''),4000);}
 function size(b){return b.size>1e6?(b.size/1e6).toFixed(1)+T('mo'):Math.round(b.size/1e3)+T('ko');}

 function canShare(blob,name){try{return !!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([blob],name,{type:blob.type||'application/octet-stream'})]}));}catch(e){return false;}}

 function dl(name,blob){try{var a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download=name;document.body.appendChild(a);a.click();
  setTimeout(function(){a.remove();},2000);setTimeout(function(){URL.revokeObjectURL(u);},120000);H.toast(T('ok'));}catch(e){H.toast(T('no'));}}

 function write(h,blob){return h.createWritable().then(function(w){return w.write(blob).then(function(){return w.close();});});}

 /* sélecteur natif (ordinateur) ; exclu sous automatisation (les tests simulent la feuille) */
 function pickable(){return !!window.showSaveFilePicker&&!navigator.webdriver;}

 function sheet(name,blob,aud){
  var m=name.match(/^(.*?)(\.[A-Za-z0-9]+)?$/),base=m[1],ext=m[2]||'',o=document.getElementById('qxSv');if(o)o.remove();
  var d=document.createElement('div');d.id='qxSv';
  d.style.cssText='position:fixed;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom,0px) + 90px);z-index:99;background:#0E1826;border:1px solid #6EE2FF;border-radius:16px;padding:14px;color:#EAFCFF;font:14px/1.4 system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.6)';
  d.innerHTML='<b></b><div style="margin:10px 0;display:flex;gap:6px;align-items:center"><input id="qxSvN" style="flex:1;min-width:0;padding:10px 12px;border-radius:10px;border:1px solid #3A5A78;background:#08111C;color:#EAFCFF;font:inherit"><span></span></div><div style="display:flex;flex-wrap:wrap;gap:8px"></div>';
  d.querySelector('b').textContent=T(aud?'aud':'file')+' · '+size(blob);
  var inp=d.querySelector('input');inp.value=base;d.querySelector('span').textContent=ext;var row=d.lastChild;
  function nm(){return (inp.value.replace(/[\\/:*?"<>|]+/g,'-').trim()||base)+ext;}
  function btn(txt,prim,fn){var b=document.createElement('button');b.textContent=txt;b.style.cssText='padding:10px 16px;border-radius:999px;border:1px solid '+(prim?'#6EE2FF':'#3A5A78')+';background:'+(prim?'#12304A':'transparent')+';color:#EAFCFF;font:inherit';b.onclick=fn;row.appendChild(b);return b;}
  /* audio : iPhone = téléchargement direct sous le nom choisi (dossier : Réglages › Safari › Téléchargements) ; autre fichier : emplacement d’abord */
  if(aud)btn(T('dl'),true,function(){dl(nm(),blob);d.remove();});
  btn(T(aud?'folder':'where'),!aud,function(){var n=nm();
   if(window.showSaveFilePicker){window.showSaveFilePicker({suggestedName:n}).then(function(h){return write(h,blob);}).then(function(){d.remove();H.toast(T('ok'));},function(e){if(!e||e.name!=='AbortError'){dl(n,blob);d.remove();}});return;}
   if(canShare(blob,n)){navigator.share({files:[new File([blob],n,{type:blob.type||'application/octet-stream'})]}).then(function(){d.remove();H.toast(T('ok'));},function(e){if(e&&e.name!=='AbortError')fail(T('sfail'),e);});return;}
   dl(n,blob);d.remove();});
  if(!aud)btn(T('dl'),false,function(){dl(nm(),blob);d.remove();});
  btn(T('cancel'),false,function(){d.remove();});
  document.body.appendChild(d);}

 function out(name,blob,o){o=o||{};
  var h=o.handle;
  if(h&&h.name.split('.').pop().toLowerCase()===name.split('.').pop().toLowerCase()){
   write(h,blob).then(function(){H.toast(T('ok'));},function(e){fail(T('wfail'),e);dl(name,blob);});return;}
  if(canShare(blob,name)){sheet(name,blob,!!o.aud);return;}
  dl(name,blob);}

 Q.canShare=canShare;Q.dl=dl;Q.write=write;Q.pickable=pickable;Q.sheet=sheet;Q.out=out;
})();
