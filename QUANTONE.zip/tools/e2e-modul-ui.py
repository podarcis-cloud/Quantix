# R423 interface modulation : registre, chaîne, bypass réel, interface, sauvegarde, rendu hors ligne
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("(()=>{const st=QUANTONE.state,w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));st.strokes=[{layer:0,pts:w(40,(t,i)=>[.1+.5*t,.5+.2*Math.sin(t*6.28),i*30])},{layer:2,pts:w(30,(t,i)=>[.3+.5*t,.65+.1*Math.sin(t*5+1),i*30])},{layer:4,pts:w(40,(t,i)=>[.02+.96*t,.885+.04*Math.sin(t*12.6+.4),i*4.5])}];})()")
    pg.evaluate("QFX3.open(0)");pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('#ifxBox').open=true")
    pg.select_option('#ifxAdd','filt');pg.wait_for_timeout(300)
    chk(pg.evaluate("!!document.querySelector('#ifxBox .fxm select[data-md=s]')"),'ligne Modulation présente')
    pg.select_option('#ifxBox select[data-md=s]','lfo');pg.wait_for_timeout(300)
    chk(pg.evaluate("document.querySelectorAll('#ifxBox [data-md]').length")==5,'LFO : 5 commandes (source, règle, forme, vitesse, profondeur)')
    pg.select_option('#ifxBox select[data-md=k]','f');pg.select_option('#ifxBox select[data-md=sh]','tri')
    pg.evaluate("(()=>{const r=document.querySelector('#ifxBox input[data-md=r]');r.value=4;r.dispatchEvent(new Event('input',{bubbles:true}));})()")
    m=pg.evaluate("(()=>{const I=QUANTONE.state.inst[0];return JSON.stringify(I.fx[0].mod)})()")
    print(m);chk('"sh":"tri"' in m and '"r":4' in m and '"k":"f"' in m,'réglages stockés dans le trait')
    pg.select_option('#ifxBox select[data-md=s]','env');pg.wait_for_timeout(300)
    chk(pg.evaluate("document.querySelectorAll('#ifxBox [data-md]').length")==3,'suiveur : 3 commandes')
    pg.select_option('#ifxBox select[data-md=s]','');pg.wait_for_timeout(300)
    chk(pg.evaluate("!QUANTONE.state.inst[0].fx[0].mod"),'retrait de la modulation')
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
