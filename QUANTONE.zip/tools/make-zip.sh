#!/bin/bash
# R404 : DEUX zips de livraison, chacun < 25 Mo (limite d'envoi web de GitHub) :
#   QUANTIX-SITE.zip = le jeu (index.html, assets/, docs/, worker/, …) SANS studio/ ni tools/
#   QUANTONE.zip     = Quantone et Track (studio/*) + les outils et tests (tools/*)
# Le workflow .github/workflows/deploy-game.yml les assemble (jeu d'abord, Quantone par-dessus).
# À utiliser pour tout envoi de zip.
cd "$(dirname "$0")/.." || exit 1
OUT=/mnt/user-data/outputs
rm -f /tmp/G.zip /tmp/Q.zip
zip -qr /tmp/G.zip . -x "studio/*" -x "tools/*" -x "*.bak" -x "*/__pycache__/*" -x "docs/source-art/*" -x "docs/apercus/*" -x "assets/bank/*.bin" -x "KIT_bank.zip" -x "FX_bank.zip" -x "QUANTONE.zip" -x "QUANTIX-SITE.zip" || exit 1
zip -qr /tmp/Q.zip studio tools -x "*.bak" -x "*/__pycache__/*" || exit 1
cp /tmp/G.zip $OUT/QUANTIX-SITE.zip && cp /tmp/Q.zip $OUT/QUANTONE.zip || exit 1
ok=1
for f in QUANTIX-SITE QUANTONE; do
  s=$(stat -c %s $OUT/$f.zip); m=$(awk "BEGIN{printf \"%.1f\",$s/1048576}")
  if [ $s -gt 25165824 ]; then echo "❌ $f.zip = $m Mo : trop lourd (limite 25 Mo, marge 24 Mo)"; ok=0; else echo "✓ $f.zip = $m Mo"; fi
  unzip -tq $OUT/$f.zip | tail -1
done
unzip -l /tmp/Q.zip | grep -c "studio/quantone.html"
unzip -l /tmp/G.zip | grep -c "index.html"
[ $ok = 1 ]
