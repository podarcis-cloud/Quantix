# R437 : bandes de défilement sur les bords du champ (plus de trait par accrochage) + « Écouter un exemple » s'efface après 3 s
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_context(viewport={'width':390,'height':844}).new_page()
    er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    pg.evaluate("QXIO&&QUANTONE.clear&&QUANTONE.clear()")
    D="(function(){var q=document.getElementById('qaEx');return q?getComputedStyle(q).display:'absent'})()"
    pg.wait_for_timeout(300);chk(pg.evaluate("QUANTONE.empty()"),'champ vide au départ')
    chk(pg.evaluate(D)!='none','« Écouter un exemple » visible au début')
    pg.wait_for_timeout(3600);chk(pg.evaluate(D)=='none','« Écouter un exemple » disparu après 3 s')
    T=pg.evaluate("(function(){var f=document.getElementById('field'),cv=document.getElementById('cv');return [getComputedStyle(f).touchAction,getComputedStyle(cv).touchAction,getComputedStyle(document.querySelector('.scrl.l')).touchAction,getComputedStyle(document.querySelector('.scrl.r')).touchAction]})()")
    chk(T==['pan-y','none','pan-y','pan-y'],'touch-action : champ pan-y, dessin none, bandes pan-y '+str(T))
    r=pg.evaluate("(function(){var r=document.getElementById('cv').getBoundingClientRect();return [r.x,r.y,r.width,r.height]})()")
    n0=pg.evaluate("QUANTONE.state.strokes.length")
    for x in (r[0]+8,r[0]+r[2]-8):   # glisser verticalement sur les bandes : aucun trait
        pg.mouse.move(x,r[1]+r[3]*.3);pg.mouse.down()
        for i in range(8):pg.mouse.move(x,r[1]+r[3]*(.3+i*.05))
        pg.mouse.up()
    chk(pg.evaluate("QUANTONE.state.strokes.length")==n0,'glisser sur les bords : aucun trait créé')
    pg.mouse.move(r[0]+r[2]*.3,r[1]+r[3]*.5);pg.mouse.down()
    for i in range(10):pg.mouse.move(r[0]+r[2]*(.3+i*.03),r[1]+r[3]*(.5+.02*i))
    pg.mouse.up();pg.wait_for_timeout(200)
    chk(pg.evaluate("QUANTONE.state.strokes.length")==n0+1,'glisser au centre : un trait est bien créé')
    n1=pg.evaluate("QUANTONE.state.strokes.length")
    pg.mouse.move(r[0]+6,r[1]+r[3]*.7);pg.mouse.down()
    for i in range(12):pg.mouse.move(r[0]+6+i*14,r[1]+r[3]*.7)
    pg.mouse.up();pg.wait_for_timeout(200)
    chk(pg.evaluate("QUANTONE.state.strokes.length")==n1+1,'glissé HORIZONTAL parti du bord : un trait est créé (le bord reste utilisable)')
    chk(not er,'aucune erreur de page '+str(er[:2]))
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
