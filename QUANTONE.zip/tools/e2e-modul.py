# R423 : modulateurs (LFO / suiveur d'enveloppe) — rendu hors ligne
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
JS="""async(mod)=>{const sr=22050,len=sr*3,c=new OfflineAudioContext(1,len,sr);
 const b=c.createBuffer(1,len,sr),d=b.getChannelData(0);for(let i=0;i<len;i++){d[i]=(Math.random()*2-1)*(mod&&mod.s==='env'&&i>sr*1.5?0:.5);}
 const s=c.createBufferSource();s.buffer=b;
 const x=QFXE.fresh('filt');x.m=1;x.f=1500;x.q=1;x.sw=0;if(mod)x.mod=mod;
 const ch=QFXE.chain(c,[x],{tempo:90});s.connect(ch.in);ch.out.connect(c.destination);s.start();
 const o=await c.startRendering(),r=o.getChannelData(0),w=Math.floor(sr/4),out=[];
 for(let k=0;k<12;k++){let e=0;for(let i=k*w;i<(k+1)*w;i++)e+=r[i]*r[i];out.push(Math.sqrt(e/w));}
 return out;}"""
sd=lambda a:(sum((x-sum(a)/len(a))**2 for x in a)/len(a))**.5
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    base=pg.evaluate(JS,None)
    lf=pg.evaluate(JS,{'s':'lfo','k':'f','sh':'sine','r':1,'d':1})
    print('base',[round(v,3) for v in base]);print('lfo ',[round(v,3) for v in lf])
    chk(sd(lf)>sd(base)*3+.005,'LFO : le niveau varie dans le temps (σ %.3f vs %.3f)'%(sd(lf),sd(base)))
    rn=pg.evaluate(JS,{'s':'lfo','k':'f','sh':'rnd','r':3,'d':1});chk(sd(rn)>sd(base)*3+.005,'LFO aléatoire varie')
    ev=pg.evaluate(JS,{'s':'env','k':'f','d':1});print('env ',[round(v,3) for v in ev])
    chk(ev[2]>ev[10]*2 or ev[10]<.01,'Suiveur : réagit au signal (fort %.3f → silence %.3f)'%(ev[2],ev[10]))
    chk(pg.evaluate("QFXE.clean([{t:'filt',on:1,mod:{s:'lfo',k:'f',sh:'sine',r:2,d:.5}}])[0].mod.r")==2,'clean() conserve la modulation')
    chk(not pg.evaluate("!!QFXE.mod.ok({t:'filt',mod:{s:'lfo',k:'zzz'}})"),'clé inconnue ignorée (réel)')
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
