# R437 : choisir le nom et l'emplacement du fichier exporté (feuille « Enregistrer » → partage du système)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
INIT="""window.__sh=[];Object.defineProperty(navigator,'canShare',{value:function(d){return !!(d&&d.files&&d.files.length);},configurable:true});
Object.defineProperty(navigator,'share',{value:function(d){window.__sh.push({n:d.files[0].name,s:d.files[0].size});return Promise.resolve();},configurable:true});delete window.showSaveFilePicker;"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(INIT);pg=c.new_page()
    er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    cv=pg.evaluate("(function(){var r=document.getElementById('cv').getBoundingClientRect();return [r.x,r.y,r.width,r.height]})()")
    pg.mouse.move(cv[0]+cv[2]*.1,cv[1]+cv[3]*.5);pg.mouse.down()
    for i in range(30):pg.mouse.move(cv[0]+cv[2]*(.1+i*.027),cv[1]+cv[3]*(.5+.1*((i%6)/6)))
    pg.mouse.up();pg.wait_for_timeout(300)
    pg.evaluate("QEXPORT.opt.auto=false;QEXPORT.opt.loops=1;QEXPORT.opt.fmt='wav'");pg.evaluate("QEXPORT.run()")
    pg.wait_for_selector('#qxSv',timeout=5000)
    chk(pg.evaluate("document.getElementById('qxSvN').value.length>0 && document.querySelector('#qxSv span').textContent==='.zip'"),'AVANT le rendu : feuille de nom proposée (.zip)')
    chk(pg.evaluate("window.__sh.length==0 && !document.getElementById('toast').classList.contains('on')"),'rien n\'est encore calculé ni partagé')
    pg.fill('#qxSvN','Mon boucle: test/1')
    pg.evaluate("document.querySelectorAll('#qxSv button')[0].click()")      # « Lancer l'export »
    pg.wait_for_function("document.getElementById('qxSv')&&/(Save file|Enregistrer le fichier)/.test(document.querySelector('#qxSv b').textContent)",timeout=60000)
    chk(pg.evaluate("document.getElementById('qxSvN').value")=='Mon boucle- test-1','APRÈS le rendu : le nom choisi est repris')
    pg.evaluate("document.querySelectorAll('#qxSv button')[0].click()");pg.wait_for_timeout(400)
    sh=pg.evaluate("window.__sh");chk(len(sh)==1 and sh[0]['n']=='Mon boucle- test-1.zip' and sh[0]['s']>1000,'partage du système avec le nom choisi (caractères interdits remplacés) '+str(sh))
    chk(pg.evaluate("!document.getElementById('qxSv')"),'feuille fermée après enregistrement')
    pg.evaluate("QSAVE.saveFile('essai.qx',new Blob(['{}'],{type:'application/octet-stream'}))");pg.wait_for_selector('#qxSv')
    with pg.expect_download() as d: pg.evaluate("document.querySelectorAll('#qxSv button')[1].click()")
    chk(d.value.suggested_filename=='essai.qx','Télécharger : fichier téléchargé sous le nom proposé')
    chk(not er,'aucune erreur de page '+str(er[:2]))
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
