# R446 : Pattern calcule et range le son du pattern juste après l'enregistrement ; Track le trouve prêt (pas de page cachée)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
GET="""(function(){return new Promise(function(ok){var r=indexedDB.open('qxlib',1);r.onsuccess=function(){var q=r.result.transaction('items').objectStore('items').getAll();q.onsuccess=function(){ok(q.result.map(function(i){return {id:i.id,name:i.name,au:!!i.au,len:i.au&&i.au.len,h:i.auH||null};}));};};r.onerror=function(){ok([]);};});})()"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);c=b.new_context(viewport={'width':390,'height':844});pg=c.new_page()
    er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("localStorage.setItem('qx.bgau','1')")
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q);window.__saved=0;QLIBSAVE('Pat bg',function(){window.__saved=Date.now();},'Alpha');})()")
    pg.wait_for_function("window.__saved>0",timeout=20000)
    it=[i for i in pg.evaluate(GET) if i['name']=='Pat bg']
    chk(it and not it[0]['au'],'enregistrement immédiat : le pattern est rangé sans attendre le son')
    ok=False
    for i in range(60):
        pg.wait_for_timeout(1000)
        it=[i for i in pg.evaluate(GET) if i['name']=='Pat bg']
        if it and it[0]['au']:ok=True;break
    chk(ok and it[0]['len']>.2,'son rendu et rangé en arrière-plan avec le pattern (durée %s s)'%(it and it[0]['len']))
    chk(ok and bool(it[0]['h']),'empreinte du pattern enregistrée avec le son')
    # Track : le bloc se prépare sans recalcul
    pg2=c.new_page();er2=[];pg2.on('pageerror',lambda e:er2.append(str(e)))
    pg2.goto('http://localhost:8765/studio/morceau.html');pg2.wait_for_timeout(2500)
    id_=it[0]['id']
    t0=pg2.evaluate("Date.now()")
    pg2.evaluate("(function(){var s=document.getElementById('patSel');s.value='lib:%s';s.dispatchEvent(new Event('change'));})()"%id_)
    pg2.wait_for_function("MORCEAU.P().blocks.some(function(b){return b.lib==='%s'&&b.ch})"%id_,timeout=30000)
    r=pg2.evaluate("(function(){var b=MORCEAU.P().blocks.filter(function(b){return b.lib==='%s'})[0];return {ms:Date.now()-%d,len:b.len,au:b.au||0,frame:!!document.querySelector('iframe[src*=render]')};})()"%(id_,t0))
    chk(r['len']>.2 and r['au']==1,'Track : bloc construit depuis le son rangé (au=1)')
    chk(not r['frame'],'Track : aucune page cachée de rendu ouverte (%d ms)'%r['ms'])
    src=open('/home/claude/site/studio/morceau.html',encoding='utf-8').read()
    chk("msg(BUSY?(fr0?'Le pattern se prépare" in src and 'libFresh(it)' in src,'Track : message « le pattern se prépare » pendant la préparation + relecture du son rangé')
    chk(not er and not er2,'aucune erreur de page %s %s'%(er[:1],er2[:1]))
    b.close()
n=sum(res);print('RÉSULTAT %d/%d'%(n,len(res)))
