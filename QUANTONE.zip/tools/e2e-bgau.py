# R446 : Pattern calcule et range le son du pattern juste après l'enregistrement ; Track le trouve prêt (pas de page cachée)
from playwright.sync_api import sync_playwright
res=[]
from builtins import abs
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
GET="""(function(){return new Promise(function(ok){var r=indexedDB.open('qxlib',1);r.onsuccess=function(){var q=r.result.transaction('items').objectStore('items').getAll();q.onsuccess=function(){ok(q.result.map(function(i){return {id:i.id,name:i.name,au:!!i.au,len:i.au&&i.au.len,h:i.auH||null};}));};};r.onerror=function(){ok([]);};});})()"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);c=b.new_context(viewport={'width':390,'height':844});pg=c.new_page()
    er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("localStorage.setItem('qx.bgau','1')")
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q);window.__saved=0;QLIBSAVE('Pat bg',function(){window.__saved=Date.now();},'Alpha');})()")
    pg.wait_for_function("window.__saved>0",timeout=20000)
    it=[i for i in pg.evaluate(GET) if i['name']=='Pat bg']
    chk(it and not it[0]['au'],'enregistrement immédiat : le pattern est rangé sans attendre le son')
    ok=False
    for i in range(60):
        pg.wait_for_timeout(1000)
        it=[i for i in pg.evaluate(GET) if i['name']=='Pat bg']
        if it and it[0]['au']:ok=True;break
    chk(ok and it[0]['len']>.2,'son rendu et rangé en arrière-plan avec le pattern (durée %s s)'%(it and it[0]['len']))
    chk(ok and bool(it[0]['h']),'empreinte du pattern enregistrée avec le son')
    # Track : le bloc se prépare sans recalcul
    pg2=c.new_page();er2=[];pg2.on('pageerror',lambda e:er2.append(str(e)))
    pg2.goto('http://localhost:8765/studio/morceau.html');pg2.wait_for_timeout(2500)
    id_=it[0]['id']
    t0=pg2.evaluate("Date.now()")
    pg2.evaluate("(function(){var s=document.getElementById('patSel');s.value='lib:%s';s.dispatchEvent(new Event('change'));})()"%id_)
    pg2.wait_for_function("MORCEAU.P().blocks.some(function(b){return b.lib==='%s'&&b.ch})"%id_,timeout=30000)
    r=pg2.evaluate("(function(){var b=MORCEAU.P().blocks.filter(function(b){return b.lib==='%s'})[0];return {ms:Date.now()-%d,len:b.len,au:b.au||0,frame:!!document.querySelector('iframe[src*=render]')};})()"%(id_,t0))
    chk(r['len']>.2 and r['au']==1,'Track : bloc construit depuis le son rangé (au=1)')
    chk(not r['frame'],'Track : aucune page cachée de rendu ouverte (%d ms)'%r['ms'])
    src=open('/home/claude/site/studio/morceau.html',encoding='utf-8').read()
    chk("msg(BUSY?(fr0?'Le pattern se prépare" in src and 'libFresh(it)' in src,'Track : message « le pattern se prépare » pendant la préparation + relecture du son rangé')
    # R447 : pattern SANS son rangé (ancien) : on peut dessiner tout de suite, le son arrive ensuite
    pg.evaluate("localStorage.removeItem('qx.bgau')")
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.4],[.3,.5],[.5,.3],[.8,.6]]}];QXIO.open(q);window.__s2=0;QLIBSAVE('Pat sans son',function(){window.__s2=1;},'Alpha');})()")
    pg.wait_for_function("window.__s2==1",timeout=20000)
    id2=[i for i in pg.evaluate(GET) if i['name']=='Pat sans son'][0]['id']
    pg3=c.new_page();er3=[];pg3.on('pageerror',lambda e:er3.append(str(e)))
    pg3.goto('http://localhost:8765/studio/morceau.html');pg3.wait_for_timeout(2500)
    pg3.evaluate("(function(){var s=document.getElementById('patSel');s.value='lib:%s';s.dispatchEvent(new Event('change'));})()"%id2)
    pg3.wait_for_function("MORCEAU.P().blocks.some(function(b){return b.lib==='%s'})"%id2,timeout=8000)
    r=pg3.evaluate("(function(){var b=MORCEAU.P().blocks.filter(function(b){return b.lib==='%s'})[0];return {pend:!!b.pend,len:b.len};})()"%id2)
    chk(r['pend'] and abs(r['len']-12)<.2,'pattern sans son : bloc provisoire posé tout de suite, à la durée exacte rangée par Pattern (%.2f s)'%r['len'])
    chk(pg3.evaluate("document.getElementById('patSel').value==='lib:%s'"%id2),'le pattern est armé : on peut dessiner pendant le calcul')
    pg3.wait_for_function("MORCEAU.P().blocks.some(function(b){return b.lib==='%s'&&!b.pend&&b.libVer>0})"%id2,timeout=120000)
    r2=pg3.evaluate("(function(){var b=MORCEAU.P().blocks.filter(function(b){return b.lib==='%s'})[0];var s=0;for(var i=0;i<b.ch[0].length;i+=50)s=Math.max(s,Math.abs(b.ch[0][i]));return {len:b.len,peak:s};})()"%id2)
    chk(r2['peak']>0.001,'le son réel remplace le provisoire (durée %.2f s, crête %.3f)'%(r2['len'],r2['peak']))
    # un seul passage (boucles longues) : même durée, son présent
    f=pg.evaluate("new Promise(function(ok){QUANTONE.renderBlock(function(b,mt){var L=b.getChannelData(0),p=0,i;for(i=Math.round(mt.start*b.sampleRate);i<L.length;i+=40)p=Math.max(p,Math.abs(L[i]));ok({len:mt.len,start:mt.start,peak:p});},{full:true,fast:true});})")
    chk(abs(f['len']-12)<.2 and f['start']<.1 and f['peak']>.001,'rendu en un seul passage : durée %.2f s, départ %.2f s, crête %.3f'%(f['len'],f['start'],f['peak']))
    chk(not er3,'aucune erreur de page (Track 2) %s'%er3[:1])
    chk(not er and not er2,'aucune erreur de page %s %s'%(er[:1],er2[:1]))
    b.close()
n=sum(res);print('RÉSULTAT %d/%d'%(n,len(res)))
