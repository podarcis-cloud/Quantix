import sys;from playwright.sync_api import sync_playwright
n=[0,0]
def chk(c,m):
    n[1]+=1;n[0]+=bool(c);print(('OK   ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1200)
    pg.evaluate("""()=>{const P=MORCEAU.P();MORCEAU.addBlock({id:'b1',name:'B1',col:'#4DD7FF',len:4,kind:'audio',ch:[new Float32Array(100)],sr:1000});const t=P.tracks[0].id;P.clips.push({id:'c1',track:t,src:'b1',start:0,len:4,off:0,rate:1,gain:1},{id:'c2',track:t,src:'b1',start:6,len:4,off:0,rate:1,gain:1},{id:'c3',track:t,src:'b1',start:12,len:4,off:0,rate:1,gain:1});MORCEAU.render();}""")
    chk(pg.locator('#tools [data-tool=select]').count()==1,'outil Sélection présent')
    pg.click('#tools [data-tool=select]');chk(pg.locator('#tools [data-tool=select].on').count()==1,'outil actif')
    chk(not errs,'aucune erreur JS '+str(errs[:1]))
    cl=pg.locator('.clip');chk(cl.count()==3,'3 blocs posés')
    cl.nth(0).click(); cl.nth(1).click(); pg.wait_for_timeout(100)
    chk(pg.locator('.clip.ms').count()==2 and pg.locator('#qmb.show').count()==1,'touchers successifs : 2 blocs sélectionnés + barre')
    pg.click('#qmb [data-a=dup]');pg.wait_for_timeout(200);chk(pg.evaluate("MORCEAU.P().clips.length")==5,'Dupliquer : 5 blocs')
    pg.click('#qmb [data-a=mut]');pg.wait_for_timeout(100);chk(pg.evaluate("MORCEAU.P().clips.filter(c=>c.mute).length")==2,'Muet sur la sélection')
    pg.click('#qmb [data-a=del]');pg.wait_for_timeout(200);chk(pg.evaluate("MORCEAU.P().clips.length")==3,'Supprimer : 3 blocs')
    pg.click('#qmb [data-a=all]') if pg.locator('#qmb.show').count() else None
    pg.click('#qmb [data-a=x]');b0=pg.locator('.clip').first.bounding_box();b2=pg.locator('.clip').last.bounding_box()
    pg.mouse.move(b0['x']-6,b0['y']-4);pg.mouse.down();pg.mouse.move(b2['x']+b2['width']+4,b2['y']+b2['height']+4,steps=6);pg.mouse.up();pg.wait_for_timeout(150)
    chk(pg.locator('.clip.ms').count()==3,'rectangle : entoure les 3 blocs')
    s0=pg.evaluate("MORCEAU.P().clips.map(c=>c.start)");bb=pg.locator('.clip').nth(1).bounding_box()
    pg.mouse.move(bb['x']+10,bb['y']+8);pg.mouse.down();pg.mouse.move(bb['x']+10+72,bb['y']+8,steps=6);pg.mouse.up();pg.wait_for_timeout(200)
    s1=pg.evaluate("MORCEAU.P().clips.map(c=>c.start)");chk(all(abs((b-a)-(s1[0]-s0[0]))<1e-6 for a,b in zip(s0,s1)) and s1[0]>s0[0],'glisser un bloc sélectionné déplace tout le groupe')
    pg.click('#tools [data-tool=move]');pg.wait_for_timeout(100);chk(pg.evaluate("document.getElementById('qmb').classList.contains('show')")==False,'barre masquée hors sélection')
print('RÉSULTAT %d / %d'%tuple(n))
