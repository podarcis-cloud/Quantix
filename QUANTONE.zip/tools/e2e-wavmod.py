# R425 : modulation de la wave (LFO / suiveur) sur un réglage de la wave
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    F="document.getElementById('qWave').style.filter"
    chk(pg.evaluate("QWAVE.md().s")=='','modulation absente par défaut')
    pg.evaluate("QWAVE.md({s:'lfo',k:'hue',sh:'sine',r:2,d:1})")
    seen=set()
    for i in range(14):
        seen.add(pg.evaluate(F));pg.wait_for_timeout(70)
    chk(len(seen)>=5,'LFO : le réglage Teinte bouge (%d valeurs)'%len(seen))
    chk(pg.evaluate("QWAVE.get('hue')")==0,'la valeur de base du curseur reste intacte')
    pg.evaluate("QWAVE.md({s:'',k:'hue',sh:'sine',r:2,d:1})");pg.wait_for_timeout(200)
    a=pg.evaluate(F);pg.wait_for_timeout(300);c=pg.evaluate(F)
    chk(a==c,'modulation retirée : plus de mouvement')
    pg.evaluate("QWAVE.md({s:'env',k:'hue',d:1,r:1,sh:'sine'})");pg.wait_for_timeout(300)
    chk(not er,'suiveur sans erreur')
    # interface
    pg.evaluate("QWAVE.md({s:'',k:'dn',sh:'sine',r:.5,d:.5})")
    box=pg.locator('#qCase .qwv').bounding_box();pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);pg.mouse.down();pg.wait_for_timeout(800);pg.mouse.up();pg.wait_for_timeout(500)
    pg.click('#qwTb button:nth-child(3)');pg.wait_for_timeout(300)
    chk(pg.evaluate("!!document.querySelector('#qwPn select[data-md=s]')"),'feuille Réglages : ligne Modulation')
    pg.select_option('#qwPn select[data-md=s]','lfo');pg.wait_for_timeout(300)
    chk(pg.evaluate("document.querySelectorAll('#qwPn [data-md]').length")==5,'LFO : 5 commandes')
    pg.select_option('#qwPn select[data-md=k]','spd');pg.wait_for_timeout(200)
    chk(pg.evaluate("QWAVE.md().k")=='spd' and pg.evaluate("QWAVE.md().s")=='lfo','choix mémorisés')
    pg.select_option('#qwPn select[data-md=s]','');pg.wait_for_timeout(200)
    chk(pg.evaluate("QWAVE.md().s")=='','retrait')
    chk(not er,'aucune erreur de page %s'%er[:2])
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
