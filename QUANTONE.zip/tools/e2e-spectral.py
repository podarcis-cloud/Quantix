# R426 : famille spectrale (STFT) — rendu hors ligne
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
JS="""async([id,over])=>{const sr=44100,len=sr*2,c=new OfflineAudioContext(2,len,sr),b=c.createBuffer(1,len,sr),d=b.getChannelData(0);
 for(let i=0;i<len;i++){const t=i/sr;d[i]=t<.4?(Math.sin(t*2*Math.PI*440)*.4+Math.sin(t*2*Math.PI*660)*.2+(Math.random()-.5)*.1):0;}
 const s=c.createBufferSource();s.buffer=b;const x=id?QFXE.fresh(id):null;let o;
 if(x){x.m=1;Object.assign(x,over||{});const ch=QFXE.chain(c,[x],{tempo:90});s.connect(ch.in);ch.out.connect(c.destination);}else s.connect(c.destination);
 s.start();o=await c.startRendering();const r=o.getChannelData(0);let bad=0,e1=0,e2=0,tail=0;
 for(let i=0;i<len;i++){if(!isFinite(r[i]))bad++;}for(let i=0;i<sr*.4;i++)e1+=r[i]*r[i];for(let i=sr*.6;i<sr*1.2;i++)tail+=r[i]*r[i];
 return {bad:bad,e1:Math.sqrt(e1/(sr*.4)),tail:Math.sqrt(tail/(sr*.6)),sig:Array.from(r.slice(5000,5040))};}"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    dry=pg.evaluate(JS,[None,None])
    chk(all(pg.evaluate("(i)=>!!QFXE.defs[i]",i) for i in ['sblur','sfrz','sgat','sshf']),'4 effets déclarés')
    for id,ov in [('sblur',{'a':.97}),('sfrz',{'a':1}),('sgat',{'a':.5}),('sshf',{'a':12})]:
        r=pg.evaluate(JS,[id,ov]);print(id,round(r['e1'],3),round(r['tail'],4))
        chk(r['bad']==0 and r['e1']>.01,'%s : sortie saine et audible (%.3f)'%(id,r['e1']))
        diff=sum(abs(x-y) for x,y in zip(r['sig'],dry['sig']))
        chk(diff>.01,'%s : modifie le son'%id)
        if id in('sblur','sfrz'):chk(r['tail']>.01,'%s : le son persiste après la fin de la source (%.3f)'%(id,r['tail']))
    gt=pg.evaluate(JS,['sgat',{'a':.9,'b':0}]);chk(gt['e1']<dry['e1']*.9,'porte : un seuil haut réduit l’énergie')
    chk(all(len(pg.evaluate("(i)=>QFXE.presets[i]",i))>=2 for i in ['sblur','sfrz','sgat','sshf']),'préréglages présents')
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
