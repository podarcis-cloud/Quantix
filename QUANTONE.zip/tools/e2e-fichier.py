# R404 — menu Fichier commun (studio/qfile.js) : mêmes libellés, ordre et hauteur dans Pattern et Track, FR et EN,
# sans défilement à 390×844 ; actions câblées (enregistrer → bibliothèque ; exporter → fichier du bon format)
import sys, os, json, tempfile
from playwright.sync_api import sync_playwright
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
U = 'http://localhost:%d/studio/' % PORT
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m, flush=True)
TMP = tempfile.mkdtemp(prefix='qfile-')
SHAPE = """(()=>{const p=document.getElementById('qfPanel');if(!p||!p.classList.contains('on'))return null;const r=p.getBoundingClientRect();
 const items=[...p.querySelectorAll('h5,button,label.snd')].map(e=>{const b=e.getBoundingClientRect();return {k:e.tagName==='H5'?'h5':(e.dataset.qf||(e.dataset.l!=null?'l':'')||(e.dataset.f?'f:'+e.dataset.f:'')||e.id||'snd'),t:e.textContent.trim(),h:Math.round(b.height),w:Math.round(b.width),x:b.left,rx:b.right}});
 const ff=getComputedStyle(p.querySelector('button.b')).fontFamily,pri=getComputedStyle(p.querySelector('button.pri')).borderTopColor;
 return {top:r.top,bottom:r.bottom,h:Math.round(r.height),sh:p.scrollHeight,ch:p.clientHeight,sw:document.documentElement.scrollWidth,iw:innerWidth,items,ff,pri,name:document.getElementById('qfName').textContent,st:document.getElementById('qfState').className}})()"""
def opn(pg, btn):
    if not pg.evaluate("QFILE.isOpen()"): pg.click(btn); pg.wait_for_timeout(350)
def shape(pg, btn): opn(pg, btn); return pg.evaluate(SHAPE)
LIB = "(n)=>new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.filter(x=>!n||x.name===n).map(x=>({id:x.id,name:x.name,proj:x.proj,ver:x.ver})))}})"
TRKS = "new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.filter(x=>x.kind==='track').map(x=>({id:x.id,name:x.name})))}})"
QLIBTAB = lambda pg: pg.evaluate("QLIB.state().tab")
def dl(pg, sel, btn):
    opn(pg, btn)
    with pg.expect_download(timeout=120000) as d: pg.click(sel)
    p = os.path.join(TMP, d.value.suggested_filename); d.value.save_as(p); return d.value.suggested_filename, p
with sync_playwright() as pw:
    br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); er = []
    S = {}
    for lg in ('fr', 'en'):
        ctx = br.new_context(viewport={'width': 390, 'height': 844}, has_touch=True, accept_downloads=True)
        for page, btn in (('quantone.html', '#qFileBtn'), ('morceau.html', '#bFile')):
            pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append(str(e)))
            pg.goto(U + page); pg.evaluate("(l)=>localStorage.setItem('qx.lang',l)", lg); pg.reload(); pg.wait_for_timeout(1500)
            s = shape(pg, btn); S[(page, lg)] = s; tag = '%s %s' % ('Pattern' if page[0] == 'q' else 'Track', lg.upper())
            chk(s and s['bottom'] <= 844 and s['sh'] <= s['ch'] + 1, '%s : le panneau tient sans défiler (%d → %d px, hauteur %d)' % (tag, s['top'], s['bottom'], s['h']))
            chk(s['sw'] <= s['iw'], '%s : pas de défilement horizontal (%d ≤ %d)' % (tag, s['sw'], s['iw']))
            small = [(i['k'], i['h'], i['w']) for i in s['items'] if i['k'] != 'h5' and (i['h'] < 40 or i['w'] < 40)]
            chk(not small, '%s : zones tactiles ≥ 40 px %s' % (tag, small))
            chk(all(i['x'] >= 0 and i['rx'] <= 390 for i in s['items']), '%s : rien ne dépasse de l’écran' % tag)
            chk('Space Grotesk' in s['ff'] and s['pri'] == 'rgb(110, 226, 255)', '%s : charte (Space Grotesk, cyan #6EE2FF)' % tag)
            pg.close()
        ctx.close()
    for lg in ('fr', 'en'):
        P, T = S[('quantone.html', lg)], S[('morceau.html', lg)]
        kp, kt = [i['k'] for i in P['items']], [i['k'] for i in T['items']]
        n = lambda s: [i['k'] for i in s['items'] if i['k'] != 'l']
        chk(n(P) == n(T), '%s : mêmes sections et même ordre dans Pattern et Track (%s)' % (lg.upper(), ' · '.join(n(P))))
        chk(P['h'] == T['h'], '%s : même hauteur (%d / %d px)' % (lg.upper(), P['h'], T['h']))
        hp = [i['t'] for i in P['items'] if i['k'] == 'h5']; ht = [i['t'] for i in T['items'] if i['k'] == 'h5']
        chk(hp == ht and len(hp) == 3, '%s : mêmes titres de section %s' % (lg.upper(), hp))
    fr = lambda s: ' | '.join(i['t'] for i in s['items'])
    chk('Enregistrer ce pattern' in fr(S[('quantone.html', 'fr')]) and 'Enregistrer cette track' in fr(S[('morceau.html', 'fr')]), 'FR : « Enregistrer ce pattern » / « Enregistrer cette track »')
    chk('Save this track' in fr(S[('morceau.html', 'en')]) and 'Track file .qxp' in fr(S[('morceau.html', 'en')]) and 'Fichier' not in fr(S[('morceau.html', 'en')]), 'EN : Track traduit (%s…)' % fr(S[('morceau.html', 'en')])[:60])
    allfr = fr(S[('quantone.html', 'fr')]) + fr(S[('morceau.html', 'fr')])
    chk('la pattern' not in allfr.lower() and 'nouvelle pattern' not in allfr.lower() and 'Nouveau pattern' in allfr, 'vocabulaire : « le pattern », « Nouveau pattern »')
    gone = ['Préréglage', 'préréglages', 'coller un code', 'Track ▸', 'Mes préréglages', 'Bande son']
    chk(not any(g in allfr for g in gone), 'supprimés du menu : Préréglage .json, Mes préréglages, coller un code, Track ▸, Bande son')

    # ── actions Pattern ──
    ctx = br.new_context(viewport={'width': 390, 'height': 844}, has_touch=True, accept_downloads=True); pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append(str(e)))
    pg.goto(U + 'quantone.html'); pg.evaluate("localStorage.setItem('qx.lang','fr')"); pg.reload(); pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q)})()"); pg.wait_for_timeout(300)
    opn(pg, '#qFileBtn'); pg.click('#qfSave'); pg.wait_for_timeout(400)
    chk(pg.evaluate("document.getElementById('qFileBar').classList.contains('lib')&&!QFILE.isOpen()"), 'Enregistrer ce pattern (premier enregistrement) : demande le nom et le projet')
    pg.fill('#qLibPj', 'Essai'); pg.fill('#qLibIn', 'Mon pattern'); pg.click('#qLibOk')
    pg.wait_for_function("QPATFILE.edit().id&&!window.QCAPBUSY", timeout=60000); pg.wait_for_timeout(300)
    L = pg.evaluate(LIB, 'Mon pattern')
    chk(len(L) == 1 and L[0]['proj'] == 'Essai', '→ apparaît dans la bibliothèque (projet Essai)')
    s = shape(pg, '#qFileBtn'); chk(s['st'] == 'ok' and 'Mon pattern' in s['name'] and 'Essai' in s['name'], 'en-tête : « %s », état Enregistré' % s['name'])
    pg.evaluate("QFILE.close()"); pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.tempo=97;QXIO.open(q)})()"); pg.wait_for_timeout(200)
    s = shape(pg, '#qFileBtn'); chk(s['st'] == 'dirty', 'après une modification : « Modifié · pas encore enregistré »')
    pg.click('#qfSave'); pg.wait_for_function("!window.QCAPBUSY", timeout=60000); pg.wait_for_timeout(500)
    L2 = pg.evaluate(LIB, 'Mon pattern'); s = shape(pg, '#qFileBtn')
    chk(len(L2) == 1 and L2[0]['ver'] > L[0]['ver'] and s['st'] == 'ok', 'Enregistrer de nouveau : mise à jour du même élément, état Enregistré')
    pg.click('#qfCopy'); pg.wait_for_timeout(300); pg.fill('#qLibIn', 'Mon pattern bis'); pg.click('#qLibOk')
    pg.wait_for_function("QPATFILE.edit().name==='Mon pattern bis'&&!window.QCAPBUSY", timeout=60000)
    chk(len(pg.evaluate(LIB, None)) == 2, 'Enregistrer une copie… : un 2e élément')
    nm, p = dl(pg, '#qfFile', '#qFileBtn'); J = json.load(open(p))
    chk(nm == 'Mon-pattern-bis.qpt' and J.get('q') == 'quantone-pattern' and J.get('name') == 'Mon pattern bis' and J.get('proj') == 'Essai', 'Exporter ▸ Fichier pattern : %s (nom et projet compris)' % nm)
    opn(pg, '#qFileBtn'); pg.click('#xpBox [data-f="wav"]'); pg.click('#xpBox [data-l="1"]')
    nm, p = dl(pg, '#bExp', '#qFileBtn'); chk(nm.endswith('.zip') and os.path.getsize(p) > 10000, 'Exporter l’audio (WAV) : %s' % nm)
    opn(pg, '#qFileBtn'); pg.click('#xpBox [data-f="mp3"]')
    nm, p = dl(pg, '#bExp', '#qFileBtn'); chk(nm.endswith('.mp3') and open(p, 'rb').read(3) in (b'ID3',) or open(p, 'rb').read(1) == b'\xff', 'Exporter l’audio (MP3) : %s' % nm)
    opn(pg, '#qFileBtn'); pg.click('#qfLib'); pg.wait_for_timeout(300)
    chk(pg.evaluate("QLIBMGR.state().open&&!QFILE.isOpen()"), 'Bibliothèque… : ouvre le gestionnaire de bibliothèque')
    pg.evaluate("document.getElementById('qLibMgr').click()")
    opn(pg, '#qFileBtn')
    with pg.expect_file_chooser() as fc: pg.click('#qfOpen')
    chk(fc.value is not None, 'Ouvrir un fichier… : ouvre le sélecteur de fichiers')
    pg.keyboard.press('Escape')
    opn(pg, '#qFileBtn'); pg.click('#bNewP'); pg.wait_for_timeout(200)
    chk(pg.evaluate("QFILE.isOpen()&&document.getElementById('bNewP').textContent.indexOf('Confirmer')>=0"), 'Nouveau projet… : demande confirmation (premier toucher)')
    pg.wait_for_timeout(3500); chk(pg.evaluate("document.getElementById('bNewP').textContent.indexOf('Nouveau projet')>=0"), 'sans second toucher, la demande expire')
    pg.click('#bNew'); pg.click('#bNew'); pg.wait_for_timeout(2600)
    chk(pg.evaluate("QUANTONE.state.strokes.length") == 0 and len(pg.evaluate(LIB, None)) == 2, 'Nouveau pattern (2 touchers) : motif vidé, bibliothèque intacte')
    # changement de langue en direct
    pg.evaluate("document.getElementById('bLang').click()"); pg.wait_for_timeout(300)
    s = shape(pg, '#qFileBtn'); chk('Save this pattern' in fr(s), 'langue changée en direct : menu en anglais')
    pg.close()

    # ── actions Track ──
    pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('T:' + str(e)))
    pt.goto(U + 'morceau.html'); pt.evaluate("localStorage.setItem('qx.lang','fr')"); pt.reload(); pt.wait_for_timeout(1500)
    chk(pt.evaluate("(()=>{const P=MORCEAU.P();return P.master.comp===0&&P.tracks.every(k=>k.vol===1)})()"), 'nouveau projet Track : master neutre (pistes 1,0, compresseur 0)')
    pt.evaluate("(()=>{const n=44100,d=new Float32Array(n);for(let i=0;i<n;i++)d[i]=Math.sin(i/20)*.3*(1-i/n);const b=MORCEAU.addBlock({kind:'audio',name:'bip',sr:44100,ch:[d,d],len:1,loop:false});MORCEAU.place(b.id,0,0,1);})()")
    opn(pt, '#bFile'); pt.click('#qfSave'); pt.wait_for_timeout(300)
    chk(pt.evaluate("QFILE.isOpen()&&!!document.getElementById('qfAskIn')"), 'Enregistrer cette track (premier enregistrement) : demande le nom dans le menu')
    pt.fill('#qfAskIn', 'Ma track'); pt.click('#qfAskY'); pt.wait_for_timeout(600)
    T1 = pt.evaluate(TRKS)
    chk(len(T1) == 1 and T1[0]['name'] == 'Ma track', '→ rangée dans Quantone (%s)' % T1)
    s = shape(pt, '#bFile'); chk(s['st'] == 'ok' and 'Ma track' in s['name'], 'en-tête : « %s », état Enregistré' % s['name'])
    pt.evaluate("QFILE.close()"); pt.evaluate("MORCEAU.P().bpm=100"); s = shape(pt, '#bFile'); chk(s['st'] == 'dirty', 'après une modification : Modifié')
    pt.click('#qfSave'); pt.wait_for_timeout(600); T2 = pt.evaluate(TRKS); s = shape(pt, '#bFile')
    chk(len(T2) == 1 and s['st'] == 'ok', 'Enregistrer de nouveau : même track mise à jour')
    pt.click('#qfCopy'); pt.wait_for_timeout(200); pt.fill('#qfAskIn', 'Ma track 2'); pt.click('#qfAskY'); pt.wait_for_timeout(600)
    chk(len(pt.evaluate(TRKS)) == 2, 'Enregistrer une copie… : 2e track')
    nm, p = dl(pt, '#qfFile', '#bFile'); J = json.load(open(p))
    chk(nm == 'Ma-track-2.qxp' and J.get('q') == 'quantone-morceau' and J.get('v') == 2, 'Exporter ▸ Fichier track : %s (.qxp v2)' % nm)
    opn(pt, '#bFile'); pt.click('#xpBox [data-f="wav"]')
    nm, p = dl(pt, '#bExp', '#bFile'); chk(nm.endswith('.wav') and open(p, 'rb').read(4) == b'RIFF', 'Exporter l’audio (WAV) : %s' % nm)
    opn(pt, '#bFile'); pt.click('#xpBox [data-f="mp3"]')
    nm, p = dl(pt, '#bExp', '#bFile'); h = open(p, 'rb').read(3); chk(nm.endswith('.mp3') and (h == b'ID3' or h[0] == 0xFF), 'Exporter l’audio (MP3, nouveau dans Track) : %s' % nm)
    opn(pt, '#bFile'); pt.click('#qfLib'); pt.wait_for_timeout(500)
    txt = pt.evaluate("QLIB.isOpen()?document.getElementById('qLibPanel').textContent:''")
    chk('Ma track' in txt and 'Sons du jeu' in txt and QLIBTAB(pt) == 't', 'Bibliothèque… : onglet Tracks (tracks enregistrées), onglet Sons du jeu')
    pt.evaluate("document.querySelector('#qLibPanel .lr[data-id] button[data-a=\"topen\"]').click()"); pt.wait_for_timeout(800)
    chk(pt.evaluate("MORCEAU.trk().name") in ('Ma track', 'Ma track 2'), 'Ouvrir une track enregistrée')
    opn(pt, '#bFile'); pt.click('#bNew'); pt.click('#bNew'); pt.wait_for_timeout(300)
    chk(pt.evaluate("MORCEAU.P().clips.length===0&&!MORCEAU.trk().id"), 'Nouvelle track (2 touchers) : track vide')
    pt.evaluate("localStorage.setItem('qx.lang','en')"); pt.reload(); pt.wait_for_timeout(1300)
    chk(pt.evaluate("document.querySelector('#bFile span').textContent") == 'File', 'Track EN : bouton « File »')
    chk(not er, 'aucune erreur JS ' + str(er[:2]))
    br.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
sys.exit(0 if all(res) else 1)
