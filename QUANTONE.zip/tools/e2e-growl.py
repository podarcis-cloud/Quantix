# Instrument Growl (R439) : 13e calque, flèche discrète, présets, rendu hors ligne sans NaN
import sys,struct,base64
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
OUT=sys.argv[1] if len(sys.argv)>1 else None
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    chk(pg.locator('#layers .lb').count()==12,'12 calques visibles par défaut')
    t0=pg.locator('#layers .lb').nth(0).inner_text();t1=pg.locator('#layers .lb').nth(1).inner_text()
    chk('Pulsar' in t0,'premier calque en haut à gauche : la boîte à rythmes (%s)'%t0.split('\n')[0])
    chk('Gluon' in t1 and 'Acid Frog' in t1,'Acid Frog visible par défaut, en deuxième')
    chk(pg.locator('#layers .lmore').count()==1,'flèche discrète présente')
    h=pg.evaluate("document.querySelector('#layers .lmore').getBoundingClientRect().height");chk(h<=24,'flèche discrète (%d px de haut)'%h)
    pg.click('#layers .lmore');pg.wait_for_timeout(200)
    chk(pg.locator('#layers .lb').count()==13,'la flèche déroule le 13e calque')
    pg.locator('#layers .lb').nth(1).click();pg.wait_for_timeout(300)
    chk(pg.evaluate("QUANTONE.state.layer")==12,'le calque 13 se sélectionne')
    chk(pg.locator('#inEd .ipre button').count()==5,'5 préréglages')
    chk(pg.locator('#inEd [data-ik="vow"]').count()==1 and pg.locator('#inEd [data-ik="wob"]').count()==1,'voyelles et wobble réglables')
    pg.click('#inHear');pg.wait_for_timeout(600)
    for n in ['Reese','Wobble','Growl lourd','Triolet','Acid Frog']:
        pg.evaluate("(n)=>document.querySelector('#inEd [data-pr=\"'+n+'\"]').click()",n);pg.wait_for_timeout(250)
    chk(pg.evaluate("QUANTONE.state.inst[12].preset")=='Acid Frog','changement de préréglage')
    pg.locator('#layers .lb').nth(12).click();pg.wait_for_timeout(200)
    pg.locator('#layers .lmore').click();pg.wait_for_timeout(200)
    chk(pg.locator('#layers .lb').count()==12 and pg.evaluate("QUANTONE.state.layer")==4,'refermer depuis un calque caché ramène à la boîte à rythmes')
    # rendu : une note longue par préréglage
    names=['Acid Frog','Reese','Wobble','Growl lourd','Triolet']
    allpk=[]
    for n in names:
        pg.evaluate("""(n)=>{const st=QUANTONE.state;st.strokes=[{layer:12,pts:[[.05,.9,0],[.45,.9,400],[.5,.7,800],[.95,.7,1200]]}];st.inst[12].preset=n;st.inst[12].p=JSON.parse(JSON.stringify(QFX3.INST[12].pre[n]));st.k.tempo=140;}""",n)
        r=pg.evaluate("""()=>new Promise(ok=>{QEXPORT.render(b=>{if(!b)return ok(null);const d=b.getChannelData(0);let bad=0,pk=0,e=0;for(let i=0;i<d.length;i++){if(!isFinite(d[i]))bad++;const a=Math.abs(d[i]);if(a>pk)pk=a;e+=d[i]*d[i];}ok({bad,pk,rms:Math.sqrt(e/d.length),sr:b.sampleRate,n:d.length,pcm:Array.from(d.subarray(0,Math.min(d.length,44100*8)),x=>Math.round(Math.max(-1,Math.min(1,x))*32767))});});})""")
        if not r:chk(False,n+' : rendu vide');continue
        chk(r['bad']==0 and 0.02<r['pk']<=1.2 and r['rms']>.004,'%s : sans NaN, crête %.2f, rms %.3f'%(n,r['pk'],r['rms']))
        allpk.append(r['pk'])
        if OUT:
            pcm=[int(x) for x in r['pcm']];f=open('%s/growl-%s.wav'%(OUT,n.replace(' ','_')),'wb');ds=len(pcm)*2
            f.write(b'RIFF'+struct.pack('<I',36+ds)+b'WAVEfmt '+struct.pack('<IHHIIHH',16,1,1,r['sr'],r['sr']*2,2,16)+b'data'+struct.pack('<I',ds)+struct.pack('<%dh'%len(pcm),*pcm));f.close()
    # presets dubstep partout
    d=pg.evaluate("(()=>{QDMOT('dstep');const D=QUANTONE.state.dm,R=D.rows;return [R[0].on[0]>0,R[0].on[10]>0,R[1].on[8]>0,R[1].on[4]==0]})()")
    chk(all(d),'motif Dubstep : kick 1 et 4‑et, caisse claire sur le 3e temps %s'%d)
    chk(all(pg.evaluate("['dstep','riddim','brostep','drumstp','gar2'].map(k=>{try{QDMOT(k);return QUANTONE.state.dm.rows[0].on.some(x=>x)}catch(e){return false}})")),'les 5 motifs dubstep se posent')
    chk(pg.evaluate("QFXE.presets.rep.length")==15 and pg.evaluate("QFXE.presets.filt.length")==6,'Répéteur 15 préréglages, Filtre 6 (wobble)')
    chk(pg.evaluate("QFX3.INST[4].pre.Dubstep&&QFX3.INST[4].pre.Riddim")!=None,'sons de batterie Dubstep et Riddim')
    chk(not er,'aucune erreur de page %s'%er[:2])
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
