from playwright.sync_api import sync_playwright
n=[0,0]
def chk(c,m):
    n[1]+=1;n[0]+=bool(c);print(('OK   ' if c else 'ÉCHEC ')+m)
JS="""async(cfg)=>{const sr=44100,c=new OfflineAudioContext(2,sr*3,sr),b=c.createBuffer(1,sr*3,sr);const d=b.getChannelData(0);for(let i=0;i<200;i++)d[Math.round(sr*.40)+i]=Math.exp(-i/40)*.9;
 const s=c.createBufferSource();s.buffer=b;const ch=QFXE.chain(c,[Object.assign({t:'rep'},cfg)],{tempo:120});s.connect(ch.in);ch.out.connect(c.destination);s.start();
 const o=await c.startRendering();const L=o.getChannelData(0);const E=(a,z)=>{let e=0;for(let i=Math.round(a*sr);i<Math.round(z*sr);i++)e+=L[i]*L[i];return e;};
 return {pre:E(.38,.5),rep:E(.55,1.0),late:E(1.6,3.0),peak:(()=>{let m=0;for(let i=0;i<L.length;i++){const v=Math.abs(L[i]);if(v>m)m=v;}return m;})()};}"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("!!QFXE.defs.rep")and pg.evaluate("QFXE.presets.rep.length")==10,'effet « Répéteur » déclaré + 10 préréglages')
    r=pg.evaluate(JS,{'iv':3,'gr':1,'ga':4,'ch':1,'de':0,'mo':0})
    chk(r['pre']>1e-4,'son direct conservé (mode Mix) %.4f'%r['pre'])
    chk(r['rep']>1e-5,'répétitions audibles après la capture (%.5f)'%r['rep'])
    r2=pg.evaluate(JS,{'iv':3,'gr':1,'ga':4,'ch':0,'de':0,'mo':0})
    chk(r2['rep']<1e-9,'Chance 0 % : aucune répétition')
    r3=pg.evaluate(JS,{'iv':3,'gr':1,'ga':4,'ch':1,'de':.5,'mo':0})
    chk(0<r3['rep']<r['rep'],'décroissance : répétitions plus faibles')
    r4=pg.evaluate(JS,{'iv':3,'gr':1,'ga':4,'ch':1,'de':0,'mo':2})
    chk(r4['pre']<r['pre']*.5 or r4['pre']<1e-3 ,'mode Gate : le son direct est coupé')
    chk(max(r['peak'],r3['peak'],r4['peak'])<4,'niveau borné (pic %.2f)'%r['peak'])
    chk(not errs,'aucune erreur JS '+str(errs[:1]))
    pg.evaluate("""()=>{MORCEAU.addBlock({id:'b1',name:'B1',col:'#4DD7FF',len:4,kind:'audio',ch:[new Float32Array(100)],sr:1000});const t=MORCEAU.P().tracks[0].id;MORCEAU.P().clips.push({id:'c1',track:t,src:'b1',start:0,len:4,off:0,rate:1,gain:1});MORCEAU.render();MORCEAU.fxOpen('c1');}""")
    pg.select_option('#fxSel','rep');pg.wait_for_timeout(200)
    chk(pg.locator('.repv').count()==1 and pg.locator('select[data-a=pre]').count()==1,'panneau : visualiseur + préréglages')
    pg.select_option('select[data-a=pre]','0');pg.wait_for_timeout(200)
    fx=pg.evaluate("MORCEAU.P().clips[0].fx[0]");chk(fx['gr']==1 and fx['pi']==-11 and abs(fx['ch']-.47)<.01,'préréglage Glitch Drums appliqué')
    chk(pg.locator('.fr span').filter(has_text='1/16').count()>=1 and pg.locator('.fr span').filter(has_text='-11 st').count()==1,'valeurs lisibles (1/16, -11 st)')
    chk(pg.locator('.repv i').count()>=2,'barres de tranches affichées (%d)'%pg.locator('.repv i').count())
    chk(not errs,'aucune erreur JS (panneau) '+str(errs[:1]))
print('RÉSULTAT %d / %d'%tuple(n))
