# e2e-repeteur-trait.py — R413 : effets (dont le Répéteur) PAR TRAIT dans Pattern, indépendants de l'instrument.
import os
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_context(viewport={'width':390,'height':844}).new_page()
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("""(function(){var S=QUANTONE.state;S.strokes.length=0;S.strokes.push({layer:0,pts:[[.1,.3],[.9,.6]]},{layer:0,pts:[[.1,.7],[.9,.2]]});QFX3.target=S.strokes[0];QFX3.open(0);})()""");pg.wait_for_timeout(300)
    pg.click('#inOne');pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('ifxBox').open=true");pg.wait_for_timeout(100)
    chk(any(k in pg.evaluate("document.querySelector('#ifxBox summary').textContent") for k in ['ce trait','this stroke']),"l'en-tête Effets indique qu'il s'agit du trait")
    pg.select_option('#ifxAdd','rep');pg.wait_for_timeout(300)
    S="QUANTONE.state.strokes"
    chk(pg.evaluate(S+"[0].ip.fx&&"+S+"[0].ip.fx[0].t")=='rep','le Répéteur est dans la chaîne DU TRAIT')
    chk(not pg.evaluate("QUANTONE.state.inst[0].fx&&QUANTONE.state.inst[0].fx.length")," l'instrument entier n'est pas touché")
    chk(not pg.evaluate(S+"[1].ip"),"l'autre trait reste sans effet propre")
    chk(pg.locator('#ifxBox .repv').count()==1 and pg.locator('#ifxBox select[data-pre]').count()==1,'visualiseur de tranches + préréglages')
    pg.select_option('#ifxBox select[data-pre]','0');pg.wait_for_timeout(300)
    fx=pg.evaluate(S+"[0].ip.fx[0]");chk(fx['gr']==1 and fx['pi']==-11,'préréglage Glitch Drums appliqué au trait')
    chk(pg.locator('#ifxBox .fxs b').filter(has_text='-11 st').count()==1,'valeurs lisibles (−11 st)')
    chk('"rep"' in pg.evaluate("document.getElementById('code').value"),'la chaîne du trait est sauvegardée dans le pattern')
    pg.evaluate("QUANTONE.state.k.tempo=120")
    r=pg.evaluate("""()=>new Promise(res=>{QUANTONE.renderBlock((b,mt)=>{const d=b.getChannelData(0);let e=0;for(let i=0;i<d.length;i+=7)e+=d[i]*d[i];res({e:e,len:mt.len})})})""")
    chk(r['e']>0,'rendu hors ligne avec effet de trait : son présent (énergie %.3f)'%r['e'])
    chk(not errs,'aucune erreur JS '+str(errs[:1]))
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
