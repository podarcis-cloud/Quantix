#!/bin/bash
# R432 : UN SEUL repère de version. Lit le fichier BUILD (ex. R432) et l'écrit partout :
#   index.html (buildTag + ?v= des scripts), engine.js (cadre Quantone ?v= + journal console),
#   studio/quantone.html (QBUILD + ?v=), tests e2e-diag lisent BUILD.
# Appelé par make-zip.sh avant d'assembler les zips.
cd "$(dirname "$0")/.." || exit 1
B=$(tr -d ' \n\r' < BUILD); case "$B" in R[0-9]*) ;; *) echo "BUILD invalide : $B"; exit 1;; esac
sed -i -E "0,/build R[0-9]+/s//build $B/; s/\?v=R[0-9]+/?v=$B/g" index.html
sed -i -E "s/studio\/quantone\.html\?v=R[0-9]+/studio\/quantone.html?v=$B/; s/QUANTIX build R[0-9]+/QUANTIX build $B/" assets/js/engine.js
sed -i -E "s/window\.QBUILD=\"R[0-9]+\"/window.QBUILD=\"$B\"/; s/\?v=R[0-9]+/?v=$B/g" studio/quantone.html
sed -i -E "s/morceau\.html\?embed=1(&v=R[0-9]+)?/morceau.html?embed=1\&v=$B/" studio/quantone.html
echo "tampon $B appliqué"
