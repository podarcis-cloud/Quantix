# R441 · une sélection n'édite QUE ses traits (13 calques)
from playwright.sync_api import sync_playwright
import json
ok=0;tot=0
def chk(c,m):
    global ok,tot;tot+=1;ok+=bool(c);print(('OK   ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    n=pg.evaluate("QUANTONE.state.inst.length");chk(n==13,'13 instruments (%d)'%n)
    for L in range(n):
        for mode in ('multi','single'):
            pg.evaluate("""(L)=>{const st=QUANTONE.state;st.strokes=[0,1,2,3].map(i=>({layer:L,pts:[[.1+.2*i,.5,0],[.2+.2*i,.4,200],[.3+.2*i,.5,400]]}));window.__b=JSON.stringify(st.inst[L]);QUANTONE.setTool('move');QUANTONE.ed.ms=[];}""",L)
            pg.wait_for_timeout(150)
            if mode=='multi': pg.evaluate("QUANTONE.ed.ms=[QUANTONE.state.strokes[0],QUANTONE.state.strokes[1]]")
            else: pg.evaluate("(()=>{QFX3.target=QUANTONE.state.strokes[0];QFX3.open(QUANTONE.state.strokes[0].layer);})()")
            pg.wait_for_timeout(500)
            r=pg.evaluate("""(L)=>{const el=document.querySelector('#inEd input[type=range][data-ik]:not(#dmT)');if(!el)return {none:1};
              const k=el.dataset.ik,mid=(+el.min+ +el.max)/2;el.value=(+el.value===mid)?+el.min:mid;el.dispatchEvent(new Event('input',{bubbles:true}));return {k:k,v:+el.value}}""",L)
            pg.wait_for_timeout(500)
            if r.get('none'): chk(False,'L%d %s : aucun réglage trouvé'%(L,mode));continue
            q=pg.evaluate("""([L,k])=>{const st=QUANTONE.state;return {inst:JSON.stringify(st.inst[L])===window.__b,ip:st.strokes.map(s=>s.ip?s.ip.p[k]:null)}}""",[L,r['k']])
            want=[r['v'],r['v'] if mode=='multi' else None,None,None]
            chk(q['inst'],'L%d %s : l’instrument reste intact'%(L,mode))
            chk(q['ip'][2] is None and q['ip'][3] is None,'L%d %s : traits non sélectionnés intacts'%(L,mode))
            chk(q['ip'][0]==r['v'] and (mode=='single' or q['ip'][1]==r['v']),'L%d %s : traits sélectionnés modifiés %s'%(L,mode,q['ip'][:2]))
    # désélection : copie inchangée retirée
    pg.evaluate("""()=>{const st=QUANTONE.state;st.strokes=[0,1].map(i=>({layer:0,pts:[[.1,.5,0],[.3,.4,200]]}));QUANTONE.setTool('move');QUANTONE.ed.ms=[st.strokes[0]]}""");pg.wait_for_timeout(500)
    pg.evaluate("QUANTONE.ed.ms=[]");pg.evaluate("QFX3.target=null");pg.wait_for_timeout(300)
    chk(pg.evaluate("QUANTONE.state.strokes.every(s=>!s.ip)"),'copie inchangée retirée à la désélection')
    chk(not er,'aucune erreur de page %s'%er[:2])
    b.close()
print('RÉSULTAT %d/%d'%(ok,tot));print('FIN')
