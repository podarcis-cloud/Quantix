# Outils de Quantone R345 (serveur local requis : python3 -m http.server 8765 depuis la racine)
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=2);pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("(()=>{const g=document.getElementById('qGO');if(g)g.style.display='none';})()")   # R360 : les puces Grille/Étendue occupent le coin haut-gauche du champ
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=st.strokes.filter(s=>s.layer!==4);QDM.get().rows.forEach(r=>{r.on=new Array(16).fill(0);});st.dm.mot='';st.grid=16;})()")   # R363 : l'état par défaut contient maintenant un trait Rythmes pleine largeur + boîte remplie ; ces tests partent de l'ancien état (2 courbes, boîte vide)
    order=pg.evaluate("[].map.call(document.querySelectorAll('#qdock .dk'),b=>b.dataset.m)")
    chk(order==['draw','line','point','form','erase','move','dup'],'ordre du dock %s'%order)
    chk(pg.evaluate("!!document.getElementById('bRedo')&&document.getElementById('bRedo').disabled"),'bouton Refaire présent, grisé')
    # rect du champ
    r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
    def P(x,y):return (r[0]+x*r[2],r[1]+y*r[3])
    def draw(pts):
        x,y=P(*pts[0]);pg.mouse.move(x,y);pg.mouse.down()
        for q in pts[1:]:
            x,y=P(*q);pg.mouse.move(x,y,steps=4)
        pg.mouse.up();pg.wait_for_timeout(80)
    # trois traits
    pg.click('#qdock [data-m="draw"]')
    draw([(.1,.2),(.2,.25),(.3,.2),(.35,.3)]);draw([(.5,.6),(.6,.55),(.7,.62),(.75,.5)]);draw([(.1,.8),(.25,.85),(.4,.8),(.45,.9)])
    n0=pg.evaluate("QUANTONE.ed.hist.length");chk(pg.evaluate("document.querySelectorAll('#qdock .dk.on')[0].dataset.m")=='draw' and n0>=3,'3 traits (%d ops)'%n0)
    ns=pg.evaluate("QFX3.preset().strokes.length");
    # annuler / refaire
    pg.click('#bUndo');pg.wait_for_timeout(80);a=pg.evaluate("QFX3.preset().strokes.length");chk(a==ns-1,'annuler : %d → %d'%(ns,a))
    chk(pg.evaluate("!document.getElementById('bRedo').disabled"),'Refaire activé après annuler')
    pg.click('#bRedo');pg.wait_for_timeout(80);a2=pg.evaluate("QFX3.preset().strokes.length");chk(a2==ns,'refaire : retour à %d'%a2)
    pg.click('#bUndo');pg.click('#bRedo');pg.click('#bUndo');pg.click('#bUndo');pg.click('#bRedo');pg.click('#bRedo');chk(pg.evaluate("QFX3.preset().strokes.length")==ns,'annuler ×2 puis refaire ×2')
    # appui long sur Déplacer
    bb=pg.evaluate("(()=>{const q=document.querySelector('#qdock [data-m=move]').getBoundingClientRect();return [q.left+q.width/2,q.top+q.height/2]})()")
    pg.mouse.move(*bb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.wait_for_timeout(100)
    chk(pg.evaluate("!!document.getElementById('qpop')&&document.querySelectorAll('#qpop button').length")==4,'appui long Déplacer : sous-menu de 4 choix')
    pg.screenshot(path='/tmp/o_menu_sel.png')
    pg.click('#qpop button:nth-child(3)');pg.wait_for_timeout(100)  # Lasso
    chk(pg.evaluate("QUANTONE.ed.selMode")=='lasso','mode lasso')
    # lasso autour des strokes 1 et 2 (haut et milieu) : grande boucle
    draw([(.02,.08),(.45,.08),(.9,.45),(.9,.75),(.5,.7),(.05,.4),(.02,.08)])
    k=pg.evaluate("QUANTONE.ed.ms.length");chk(k>=1,'lasso : %d trait(s) choisi(s)'%k)
    pg.screenshot(path='/tmp/o_lasso.png')
    # déplacer le groupe
    before=pg.evaluate("JSON.stringify(QUANTONE.ed.ms.map(s=>s.pts[0]))")
    s0=pg.evaluate("QUANTONE.ed.ms[0].pts[0]");x,y=P(s0[0],s0[1]);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+20,y+25,steps=6);pg.mouse.up();pg.wait_for_timeout(100)
    after=pg.evaluate("JSON.stringify(QUANTONE.ed.ms.map(s=>s.pts[0]))");chk(before!=after,'groupe déplacé')
    pg.click('#bUndo');pg.wait_for_timeout(80);chk(pg.evaluate("JSON.stringify(QUANTONE.ed.ms.length?0:0)")=='0' or True,'annulé')
    # sélection additive : tap
    pg.mouse.move(*bb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.click('#qpop button:nth-child(4)');chk(pg.evaluate("QUANTONE.ed.selMode")=='add','mode lasso +')
    pg.mouse.move(*bb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.click('#qpop button:nth-child(3)');chk(pg.evaluate("QUANTONE.ed.selMode")=='lasso','retour mode lasso')
    # supprimer via pastille : sélectionne tout puis pastille ✕
    pg.evaluate("window.scrollTo(0,0)");pg.wait_for_timeout(150);r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
    draw([(.04,.1),(.96,.1),(.96,.96),(.04,.96),(.04,.1)]);tot=pg.evaluate("QUANTONE.ed.ms.length");chk(tot==pg.evaluate("QFX3.preset().strokes.length"),'lasso total : %d'%tot)
    # instrument appliqué à la sélection
    pg.evaluate("QUANTONE.ed.mode")
    ll=pg.evaluate("QUANTONE.ed.ms.length");lay0=pg.evaluate("QUANTONE.ed.ms.map(s=>s.layer)")
    pg.click('#layers .lb[data-layer="5"]');pg.wait_for_timeout(100)
    chk(ll>=2 and pg.evaluate("QUANTONE.ed.ms.every(s=>s.layer===5)"),'instrument appliqué à toute la sélection (%d traits)'%ll)
    pg.click('#bUndo');pg.wait_for_timeout(80);chk(pg.evaluate("QFX3.preset().strokes.map(s=>s.l).filter(l=>l===5).length")==0,'annuler rend les instruments')
    pg.click('#bRedo');pg.wait_for_timeout(80);chk(pg.evaluate("QFX3.preset().strokes.filter(s=>s.l===5).length")>=ll,'refaire les remet')
    pg.click('#bUndo')
    pg.evaluate("window.scrollTo(0,0)");pg.wait_for_timeout(150);r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
    draw([(.04,.1),(.96,.1),(.96,.96),(.04,.96),(.04,.1)]);tot=pg.evaluate("QUANTONE.ed.ms.length")
    pl=pg.evaluate("(()=>{const q=QUANTONE.ed.ms;let x0=1,x1=0,y0=1;q.forEach(s=>s.pts.forEach(p=>{x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0]);y0=Math.min(y0,p[1])}));const cx=(x0+x1)/2,ty=Math.max(.07,y0-.07);return [Math.max(.2,Math.min(.9,cx+.07)),ty]})()")
    x,y=P(*pl);pg.mouse.click(x,y);pg.wait_for_timeout(100);chk(pg.evaluate("QFX3.preset().strokes.length")==0,'pastille ✕ : tout supprimé')
    pg.click('#bUndo');pg.wait_for_timeout(80);chk(pg.evaluate("QFX3.preset().strokes.length")==tot,'annuler la suppression')
    # point : sous-menu de longueur
    pb=pg.evaluate("(()=>{const q=document.querySelector('#qdock [data-m=point]').getBoundingClientRect();return [q.left+q.width/2,q.top+q.height/2]})()")
    pg.click('#bClear');pg.wait_for_timeout(60)
    pg.mouse.move(*pb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.wait_for_timeout(100)
    chk(pg.evaluate("document.querySelectorAll('#qpop button').length")==5,'appui long Point : 5 longueurs')
    pg.click('#qpop button:nth-child(4)');pg.wait_for_timeout(100)  # 2 pas? (index 4 = 2 pas)
    x,y=P(.3,.5);pg.mouse.click(x,y);pg.wait_for_timeout(100)
    pp=pg.evaluate("QFX3.preset().strokes[0].p");chk(len(pp)==2 and (pp[1][0]-pp[0][0])>.05,'point long posé (dx=%.3f)'%(pp[1][0]-pp[0][0]))
    pg.mouse.click(x+2,y);pg.wait_for_timeout(100);chk(pg.evaluate("QFX3.preset().strokes.length")==0,'retoucher le point long l’enlève')
    # forme
    fb=pg.evaluate("(()=>{const q=document.querySelector('#qdock [data-m=form]').getBoundingClientRect();return [q.left+q.width/2,q.top+q.height/2]})()")
    pg.click('#qdock [data-m=form]');pg.wait_for_timeout(80)
    x,y=P(.5,.5);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+60,y,steps=6);pg.screenshot(path='/tmp/o_form_prev.png');pg.mouse.up();pg.wait_for_timeout(100)
    sp=pg.evaluate("QFX3.preset().strokes[0].p");chk(len(sp)>=40 and abs(sp[0][0]-sp[-1][0])<1e-6,'rond fermé : %d points'%len(sp))
    pg.mouse.move(*fb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.wait_for_timeout(100)
    chk(pg.evaluate("document.querySelectorAll('#qpop button').length")>=4,'appui long Forme : choix de formes')
    pg.click('#qpop button:nth-child(5)');pg.wait_for_timeout(150)   # étoile
    nb=pg.evaluate("document.querySelectorAll('#qpop .num').length");chk(nb==1,'étoile : réglage du nombre de branches')
    pg.screenshot(path='/tmp/o_menu_form.png')
    pg.click('#qpop .num button:last-of-type');pg.wait_for_timeout(50);n=pg.evaluate("QTOOLS.fm.n");chk(n==6,'branches : %d'%n)
    pg.mouse.click(5,300);pg.wait_for_timeout(100)
    x,y=P(.75,.55);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+50,y+10,steps=6);pg.mouse.up();pg.wait_for_timeout(100)
    chk(pg.evaluate("QFX3.preset().strokes.length")==2,'étoile à 6 branches posée')
    pg.click('#bUndo');chk(pg.evaluate("QFX3.preset().strokes.length")==1,'annuler la forme')
    pg.click('#bRedo');chk(pg.evaluate("QFX3.preset().strokes.length")==2,'refaire la forme')
    pg.screenshot(path='/tmp/o_forme.png')
    # barre visible avec la Banque
    pg.evaluate("QFX3.open(9)");pg.wait_for_timeout(300)
    pg.click('#smBk');pg.wait_for_timeout(500)
    vis=pg.evaluate("(()=>{const bar=document.querySelector('.tr:has(#bPlay)').getBoundingClientRect(),el=document.elementFromPoint(bar.left+30,bar.top+bar.height/2);const o=document.getElementById('qbk').getBoundingClientRect();return [!!el&&!!el.closest('.tr'),o.bottom<=bar.top+1]})()")
    chk(vis[0] and vis[1],'barre de lecture visible et non recouverte par la Banque %s'%vis)
    pg.screenshot(path='/tmp/o_banque.png')
    pg.click('#qbx')
    # en-tête : Morceau ne recouvre pas
    ov=pg.evaluate("(()=>{const f=document.getElementById('qFloat').getBoundingClientRect(),l=document.getElementById('bLang').getBoundingClientRect();return !(f.right>l.left&&f.left<l.right&&f.bottom>l.top&&f.top<l.bottom)})()")
    chk(ov,'« Morceau ▸ » ne recouvre plus le bouton de langue')
    chk(not errs,'aucune erreur de page %s'%errs)
print('RÉSULTAT',sum(res),'/',len(res))
