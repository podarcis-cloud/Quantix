# R414 : nouveaux effets natifs — rendu hors ligne fini, borné, audible
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
NEW="dly echo fdly od dist fuzz tube ero bus gate lim glue mband util rez ens".split()
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    chk(pg.evaluate("QFXE.order.length")>=30,'registre : %d effets'%pg.evaluate("QFXE.order.length"))
    chk(all(pg.evaluate("QFXE.order.includes('%s')"%i) for i in NEW),'16 nouveaux enregistrés')
    r=pg.evaluate("""async(ids)=>{const out={};for(const id of ids){try{const oc=new OfflineAudioContext(2,44100,44100),ch=QFXE.chain(oc,[QFXE.fresh(id)],{tempo:90}),o=oc.createOscillator(),g=oc.createGain();g.gain.value=.3;o.frequency.value=220;o.type='sawtooth';o.connect(g);g.connect(ch.in);ch.out.connect(oc.destination);o.start();
      const b=await oc.startRendering(),d=b.getChannelData(0);let bad=0,pk=0;for(let i=0;i<d.length;i++){if(!isFinite(d[i]))bad++;pk=Math.max(pk,Math.abs(d[i]));}out[id]=[bad,+pk.toFixed(3)];}catch(e){out[id]=['ERR '+e.message,0];}}return out;}""",NEW)
    print(r)
    chk(not [k for k,v in r.items() if v[0]!=0 or v[1]>4],'aucun NaN ni explosion %s'%[k for k,v in r.items() if v[0]!=0 or v[1]>4])
    chk(not [k for k,v in r.items() if v[1]<.0005],'tous audibles %s'%[k for k,v in r.items() if v[1]<.0005])
    chk(not er,'aucune erreur JS %s'%er[:2])
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
