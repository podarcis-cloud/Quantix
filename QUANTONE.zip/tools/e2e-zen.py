# R431 : mini-jeu Détente — cinq mondes (nuée quantique, galaxie, intrication, chronos, éther)
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
NEAR="(()=>{const P=QZEN._p();return P.filter(p=>Math.hypot(p.x-195,p.y-398)<70).length})()"
def drag(pg,x0,y0,n=12):
    pg.mouse.move(x0,y0);pg.mouse.down()
    for k in range(n):
        pg.mouse.move(x0+(k%3)*12,y0+(k%2)*12);pg.wait_for_timeout(40)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':797},has_touch=True);pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("!!window.QZEN")and not pg.evaluate("QZEN.on()"),'module chargé')
    box=pg.locator('#qCase .qwv').bounding_box();pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);pg.mouse.down();pg.wait_for_timeout(800);pg.mouse.up();pg.wait_for_timeout(400)
    chk(pg.evaluate("!!document.getElementById('qwZen')"),'bouton Détente dans la feuille Wave')
    pg.click('#qwZen');pg.wait_for_timeout(1200)
    chk(pg.evaluate("QZEN.on()")and pg.evaluate("QZEN.mats().join()")=='nuee,gal,ent,chr,eth','jeu ouvert, 5 mondes')
    for m in ['nuee','gal','ent','chr','eth']:
        pg.click('#qZen [data-m=%s]'%m);pg.wait_for_timeout(1200)
        n0=pg.evaluate(NEAR) if m in('nuee','gal') else 0
        drag(pg,195,398);pg.wait_for_timeout(300)
        ok=pg.evaluate("QZEN._p().every(p=>isFinite(p.x)&&isFinite(p.y))")
        chk(ok and pg.evaluate("QZEN.n()")>=60,'%s : %d particules, positions saines'%(m,pg.evaluate("QZEN.n()")))
        if m=='nuee':
            n1=pg.evaluate(NEAR);chk(n1<n0*.6,'nuée : le doigt repousse (%d → %d)'%(n0,n1))
        if m=='gal':
            n1=pg.evaluate(NEAR);chk(n1>n0*1.15,'galaxie : le doigt attire (%d → %d)'%(n0,n1))
        pg.mouse.up();pg.wait_for_timeout(600)
        # appui long : mode « g » puis relâchement sans erreur
        pg.mouse.move(120,260);pg.mouse.down();pg.wait_for_timeout(1000)
        g=pg.evaluate("Object.values(QZEN._ptr()).some(p=>p.g)");pg.mouse.up();pg.wait_for_timeout(500)
        chk(g and pg.evaluate("QZEN._p().every(p=>isFinite(p.x)&&isFinite(p.y))"),'%s : appui long puis éclosion, sain'%m)
        chk(pg.evaluate("QZEN.cost()")<8,'%s : coût %.1f ms'%(m,pg.evaluate("QZEN.cost()")))
    pg.click('#qZen [data-a=s]');pg.click('#qZen [data-a=tl]');pg.click('#qZen [data-a=s]')
    pg.click('#qZen [data-a=x]');pg.wait_for_timeout(300)
    chk(not pg.evaluate("QZEN.on()") and not pg.evaluate("!!document.getElementById('qZen')"),'quitter ferme proprement')
    pg.evaluate("localStorage.setItem('qx.zen','eth')");pg.evaluate("QZEN.open()");pg.wait_for_timeout(500)
    chk(pg.evaluate("QZEN.mat()")=='eth','dernier monde mémorisé');pg.evaluate("QZEN.close()")
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
