# R405 : didacticiel Quantone (aide contextuelle + exemples + Atelier). Port : QPORT (8765 par défaut). Manuel source : QMANUEL (optionnel).
import os, re, json
from playwright.sync_api import sync_playwright
PORT = os.environ.get('QPORT', '8765'); U = 'http://localhost:%s/studio/' % PORT
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m)
INIT = "if(!sessionStorage.getItem('qa.i')){sessionStorage.setItem('qa.i','1');localStorage.setItem('qx.lang','fr');localStorage.setItem('qx.aide.test','1');%s}"
gest = [0]
def G(n=1): gest[0] += n

DRAW = """(()=>{const w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));return {
 closed:w(30,(t,i)=>[.5+.2*Math.cos(t*6.2832),.4+.15*Math.sin(t*6.2832),i*30]),
 open:w(20,(t,i)=>[.1+.5*t,.5+.1*Math.sin(t*6.28),i*30]),
 bass:w(30,(t,i)=>[.5+.25*Math.cos(t*6.2832),.78+.05*Math.sin(t*6.2832),i*30])}})()"""

with sync_playwright() as pw:
    b = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    errs = []
    def page(url='quantone', pre=''):
        c = b.new_context(viewport={'width': 390, 'height': 844}); c.add_init_script(INIT % pre)
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.goto(U + url + '.html'); pg.wait_for_timeout(1700); return pg
    def sets(pg, js):  # fabrique un état puis laisse l'Atelier le lire
        pg.evaluate(js); return pg.evaluate("QAIDE.scan()")
    def prog(pg): return pg.evaluate("QAIDE.progress()")
    def tap(pg, sel):
        r = pg.evaluate("(s=>{const b=document.querySelector(s).getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]})(%s)" % json.dumps(sel))
        pg.mouse.move(*r); pg.mouse.down(); pg.mouse.up()

    # ───── LOT 1 : aide contextuelle ─────
    pg = page()
    chk(pg.evaluate("QAIDE.on()") is True and pg.evaluate("localStorage.getItem('qx.aide')") == '1', 'premier lancement : aide activée puis mémorisée')
    chk(pg.evaluate("!!document.getElementById('bAtelier')") and pg.evaluate("!!document.getElementById('bHelp')"), 'icône Atelier à côté du « ? »')
    tap(pg, '#bUndo'); pg.wait_for_timeout(250)
    t = pg.evaluate("(()=>{const e=document.getElementById('qaTip');return e?{t:e.textContent,pe:getComputedStyle(e).pointerEvents,l:e.querySelector('a').getAttribute('href')}:null})()")
    chk(t and 'Annuler' in t['t'] and 'Mode d’emploi' in t['t'], 'toucher Annuler → pastille d’une phrase + lien Mode d’emploi : %s' % (t and t['t'][:40]))
    chk(t and t['pe'] == 'none' and t['l'].startswith('manuel.html#'), 'pastille non bloquante (pointer-events:none) ; lien vers une ancre du manuel')
    pg.mouse.move(200, 120); pg.mouse.down(); pg.mouse.up(); pg.wait_for_timeout(150)
    chk(pg.locator('#qaTip').count() == 0, 'toucher ailleurs ferme la pastille')
    tap(pg, '#bUndo'); pg.wait_for_timeout(250)
    chk(pg.locator('#qaTip').count() == 0, 'une seule fois par commande')
    tap(pg, '#bClear'); pg.wait_for_timeout(5700)
    chk(pg.locator('#qaTip').count() == 0, 'la pastille se ferme seule')
    # hover souris (survol) : une autre commande
    pg.mouse.move(5, 5); pg.hover('#cpuB'); pg.wait_for_timeout(700)
    chk(pg.locator('#qaTip').count() == 1, 'survol souris → pastille')
    # le lien ouvre le manuel à la bonne section
    pg.evaluate("QAIDE.resetSeen()"); pg.mouse.move(5, 5); pg.wait_for_timeout(100)
    pg.evaluate("QAIDE.tip('play')"); pg.click('#qaTip a'); pg.wait_for_timeout(700)
    chk(pg.locator('#qHelpOv iframe').count() == 1 and '#lecture' in (pg.evaluate("document.querySelector('#qHelpOv iframe').src")), 'lien Mode d’emploi → manuel#lecture')
    # panneau « ? » étendu
    chk(pg.locator('#qaBar #qaOn').count() == 1 and pg.locator('#qaBar [data-ex]').count() == 5, 'panneau « ? » : case Aide contextuelle + 5 exemples')
    chk(pg.evaluate("document.querySelector('#qHelpOv iframe')!==null"), '« ? » ouvre toujours le manuel')
    # décocher
    pg.uncheck('#qaOn'); pg.wait_for_timeout(100); pg.click('#qHelpOv .hb button'); pg.wait_for_timeout(150)
    chk(pg.evaluate("localStorage.getItem('qx.aide')") == '0', 'case décochée → réglage mémorisé')
    n0 = pg.evaluate("document.querySelectorAll('#qaTip').length")
    for s in ['#bRedo', '#bRec', '#qLibBtn', '#qWave', '#qdock .dk', '#layers .lb', '#worlds .wb']:
        tap(pg, s); pg.wait_for_timeout(120)
    chk(pg.locator('#qaTip').count() == 0 and pg.evaluate("QAIDE.tip('rec')") is False or pg.evaluate("document.getElementById('qaTip')===null"), 'case décochée : aucune pastille')
    pg.reload(); pg.wait_for_timeout(1500)
    chk(pg.evaluate("QAIDE.on()") is False, 'décochée : persiste après rechargement (pas de réactivation au « premier lancement »)')
    tap(pg, '#bRedo'); pg.wait_for_timeout(200)
    chk(pg.locator('#qaTip').count() == 0, 'après rechargement : toujours aucune pastille')
    pg.click('#bHelp'); pg.wait_for_timeout(500); pg.click('#qaRev'); pg.wait_for_timeout(150)
    chk(pg.evaluate("QAIDE.on()") is True and pg.evaluate("QAIDE.seen().length") == 0 and pg.evaluate("document.getElementById('qaOn').checked"), '« Revoir les astuces » : réactive et vide la mémoire des astuces')
    pg.click('#qHelpOv .hb button'); pg.wait_for_timeout(100)
    # chaque astuce vise un élément existant, dans une ancre existante du manuel
    hs = pg.evaluate("QAIDE.hints()")
    chk(all(h['ok'] for h in hs), 'Pattern : %d astuces, tous les sélecteurs existent %s' % (len(hs), [h['id'] for h in hs if not h['ok']]))
    src = os.environ.get('QMANUEL') or os.path.join(os.path.dirname(__file__), '..', 'studio', 'manuel.html')
    ids = set(re.findall(r'id="([a-z0-9_-]+)"', open(src, encoding='utf-8').read()))
    pt = page('morceau'); ht = pt.evaluate("QAIDE.hints()")
    chk(all(h['ok'] for h in ht), 'Track : %d astuces, sélecteurs existants %s' % (len(ht), [h['id'] for h in ht if not h['ok']]))
    anc = set(h['a'] for h in hs + ht)
    chk(anc <= ids, 'ancres du manuel existantes (%s) manquantes : %s' % (os.path.basename(src), sorted(anc - ids)))

    # ───── LOT 1 : exemples ─────
    pg = page()
    chk(pg.evaluate("document.getElementById('qaEx').style.display")!='none' and pg.evaluate("QUANTONE.empty()"), 'Pattern vide : bouton « Écouter un exemple » visible')
    chk(pg.evaluate("QAIDE.example('neutre')") is True, 'exemple neutre chargé (format .qx existant)')
    chk('Touche ▶' in pg.evaluate("document.getElementById('qaMsg').textContent"), 'message « Touche ▶, puis change ce qui te plaît. »')
    chk(pg.evaluate("[QUANTONE.state.strokes.length>=3, QUANTONE.state.k.echo===0, dmAny()]") == [True, True, True], 'boucle neutre : traits, master sans effet, boîte à rythmes armée')
    pg.wait_for_timeout(900)
    chk(pg.evaluate("document.getElementById('qaEx').style.display") == 'none', 'le bouton disparaît dès que Pattern n’est plus vide')
    pg.evaluate("QAIDE.scan()"); chk(prog(pg) == {}, 'un exemple intact ne coche aucun défi')
    chk(pg.evaluate("QAIDE.example('atelier')") is False, 'exemple : jamais d’écrasement silencieux d’un dessin existant')
    pg.evaluate("QAIDE.example('atelier',true)")
    for ex, w in [('neutre', -1), ('atelier', 0), ('fonderie', 1), ('chaine', 2), ('glacier', 3)]:
        ok = pg.evaluate("QAIDE.example(%s,true)" % json.dumps(ex))
        v = pg.evaluate("[QUANTONE.state.amb,QUANTONE.state.strokes.length,QUANTONE.score().length]")
        chk(ok and v[0] == w and v[1] >= 2 and v[2] > 8, 'exemple %s : monde %s, %d traits, %d notes' % (ex, w, v[1], v[2]))
    pg.click('#bPlay'); pg.wait_for_timeout(1500)
    chk(pg.evaluate("QUANTONE.level()") > .0005, 'l’exemple joue (niveau mesuré %.4f)' % pg.evaluate("QUANTONE.level()"))
    pg.click('#bPlay')

    # ───── LOT 2 : un test par défi (état fabriqué → coche attendue) ─────
    PRE = lambda s: "(()=>{const st=QUANTONE.state;%s})()" % s
    pg = page()
    chk(sets(pg, PRE("st.strokes=[{layer:0,pts:(%s).open}]" % DRAW)) == [], 'défi 0 : trait ouvert → pas de coche')
    chk(sets(pg, PRE("st.strokes=[{layer:0,pts:(%s).closed}]" % DRAW)) == ['c0'], 'défi 0 « Premier son » : forme fermée → coche')
    chk(sets(pg, PRE("st.strokes.push({layer:0,pts:(%s).open})" % DRAW)) == [], 'défi 1 : deux mélodies sans basse → pas de coche')
    chk(sets(pg, PRE("st.strokes.push({layer:1,pts:(%s).bass})" % DRAW)) == ['c1'], 'défi 1 « Deux voix » : basse + mélodie → coche')
    chk(sets(pg, PRE("st.strokes.push({layer:4,pts:(%s).open})" % DRAW)) == ['c2'], 'défi 2 « Le rythme » : trait Rythmes + boîte à rythmes armée (motif Hip-hop par défaut) → coche')
    chk('c3' not in prog(pg), 'défi 3 : pas encore')
    pg.evaluate(PRE("st.scale='pm';st.amb=-1;st.k.echo=.3"))
    chk(pg.evaluate("QAIDE.scan()") == [], 'défi 3 : gamme + écho sans monde → pas de coche')
    chk(sets(pg, PRE("st.amb=0")) == ['c3'], 'défi 3 « La couleur » : gamme + monde + écho → coche')
    chk(sets(pg, "QAUTO.AUT['k:clar']={on:false,len:4,pts:[[0,0],[1,1]]}") == [], 'défi 4 : automation non activée → pas de coche')
    chk(sets(pg, "QAUTO.AUT['k:clar'].on=true") == ['c4'], 'défi 4 « Le mouvement » : automation active sur plusieurs boucles → coche')
    chk(sets(pg, "0") == [], 'défi 5 : rien d’enregistré → pas de coche')
    chk(sets(pg, "QEXPORT.opt.last={loops:2,sec:8}") == ['c5'], 'défi 5 « Garder et partager » : export fait → coche')
    chk(prog(pg).keys() >= {'c0', 'c1', 'c2', 'c3', 'c4', 'c5'}, 'les 6 défis de Pattern cochés')
    chk(sets(pg, PRE("st.strokes=[]")) == [] and 'c0' in prog(pg), 'la coche reste acquise (sticky) même si le dessin est effacé')
    pg2 = page('morceau')
    chk(pg2.evaluate("QAIDE.scan()") == [], 'défi 6 : Track vide → pas de coche')
    pg2.evaluate("(()=>{const M=MORCEAU,b=M.addBlock({name:'t',len:2,loop:2,ch:[new Float32Array(88200),new Float32Array(88200)],sr:44100});[0,2,4].forEach(s=>M.place(b.id,0,s,2));})()")
    chk(len(pg2.evaluate("MORCEAU.P().clips")) == 3 and pg2.evaluate("QAIDE.scan()") == ['c6'], 'défi 6 « Le morceau » : 3 blocs posés dans Track → coche')
    # bonus
    pg = page()
    chk(sets(pg, PRE("st.strokes=[{layer:0,pts:(%s).closed,nt:{3:{vel:60}}}]" % DRAW)) == ['c0', 'b0'], 'bonus 0 : note d’un trait réglée → coche')
    chk(sets(pg, "QDM.get().rows[0].atk=20") == ['b1'], 'bonus 1 : attaque de voix → coche')
    chk(sets(pg, "QSMP.SMP[1]={d:new Float32Array(100),sr:44100,name:'x'};0") == ['b2'], 'bonus 2 : sampler garni → coche')
    chk(sets(pg, PRE("st.eq={hp:1,lo:-1,mid:0,hi:-3,out:0};st.world=0;st.amb=0")) == ['b3'], 'bonus 3 : recette du monde 1 → coche')

    # ───── LOT 2 : panneau, Passer, indice, persistance, réinitialiser ─────
    pg = page()
    pg.click('#bAtelier'); pg.wait_for_timeout(250)
    chk(pg.locator('#qaAt li').count() == 11 and pg.locator('#qaAt li:not(.ail)').count() == 10, 'Atelier : 7 défis + 4 bonus ; le défi 6 est signalé « dans Track »')
    chk(pg.evaluate("document.querySelector('#qaAt li[data-id=c6]').textContent").find('Track') >= 0 and pg.locator('#qaAt li[data-id=c6] button').count() == 0, 'défi 6 sans boutons dans Pattern')
    chk(pg.locator('#qaAt li[data-id=c0] .ih:not([hidden])').count() == 0, 'indices masqués au départ')
    pg.click('#qaAt li[data-id=c0] [data-a=hint]'); chk(pg.locator('#qaAt li[data-id=c0] .ih:not([hidden])').count() == 1, 'Indice : affiche le texte (gratuit)')
    chk(all(pg.locator('#qaAt li[data-id=%s] [data-a=skip]' % i).count() == 1 for i in ['c0', 'c1', 'c2', 'c3', 'c4', 'c5', 'b0', 'b1', 'b2', 'b3']), '« Passer » présent partout')
    pg.click('#qaAt li[data-id=c1] [data-a=skip]'); pg.wait_for_timeout(100)
    chk(prog(pg).get('c1') == {'s': 1} and pg.locator('#qaAt li.skip').count() == 1 and pg.locator('#qaAt li[data-id=c1] [data-a=back]').count() == 1, 'Passer : défi marqué « passé », reprise possible')
    chk(pg.locator('#qaAt li.done').count() == 0, 'passer ne coche pas comme fait')
    pg.click('#qaAt li[data-id=c1] [data-a=man]'); pg.wait_for_timeout(500)
    chk(pg.locator('#qaAt').count() == 0 and '#instruments' in pg.evaluate("document.querySelector('#qHelpOv iframe').src"), 'lien Mode d’emploi du défi → section instruments')
    pg.click('#qHelpOv .hb button')
    sets(pg, PRE("st.strokes=[{layer:0,pts:(%s).closed}]" % DRAW))
    pg.reload(); pg.wait_for_timeout(1500)
    chk(prog(pg).get('c0', {}).get('d') == 1 and prog(pg).get('c1') == {'s': 1}, 'progression conservée après rechargement (localStorage)')
    pg.click('#bAtelier'); pg.wait_for_timeout(200)
    chk(pg.locator('#qaAt li.done').count() == 1 and pg.locator('#qaAt li.skip').count() == 1, 'Atelier rouvert : 1 fait, 1 passé')
    pg.click('#qaRst'); chk(prog(pg) != {}, 'Réinitialiser : demande une confirmation (2 touches)')
    pg.click('#qaRst'); pg.wait_for_timeout(100)
    chk(prog(pg) == {} and pg.locator('#qaAt li.done').count() == 0, 'Réinitialiser : progression effacée')
    pg.click('#qaX'); chk(pg.locator('#qaAt').count() == 0, 'Fermer')
    # localStorage inaccessible : la page fonctionne sans erreur
    pg3 = page(pre="Storage.prototype.setItem=function(){throw new Error('quota')};")
    pg3.click('#bAtelier'); pg3.wait_for_timeout(200)
    chk(pg3.locator('#qaAt').count() == 1, 'écriture locale refusée : l’Atelier s’ouvre quand même')
    # Track : le défi 6 y est actif, les défis 0 à 5 sont en lecture
    pt = page('morceau'); pt.click('#bAtelier'); pt.wait_for_timeout(250)
    chk(pt.locator('#qaAt li[data-id=c6] [data-a=skip]').count() == 1 and pt.locator('#qaAt li.ail').count() == 10, 'Track : défi 6 actif, les autres signalés « dans Pattern »')
    chk(pt.evaluate("document.documentElement.scrollWidth<=innerWidth"), 'Track : pas de défilement horizontal')
    pt.screenshot(path='/tmp/claude-0/agent-didac/tests/atelier-track.png')

    # ───── utilisateur simulé : défis 0 à 6 en moins de 90 gestes ─────
    pg = page('quantone')
    r = pg.evaluate("(()=>{const r=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width]})()")
    def draw(kind):
        pg.evaluate("document.getElementById('field').scrollIntoView({block:'center'})"); pg.wait_for_timeout(150)
        r = pg.evaluate("(()=>{const r=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width]})()")
        pts = pg.evaluate("k=>(%s)[k]" % DRAW, kind)
        pg.mouse.move(r[0] + pts[0][0] * r[2], r[1] + pts[0][1] * r[2]); pg.mouse.down()
        for p in pts[1:]: pg.mouse.move(r[0] + p[0] * r[2], r[1] + p[1] * r[2])
        pg.mouse.up(); G()
    pg.evaluate("QAIDE.scan()")
    draw('closed'); pg.wait_for_timeout(300); pg.evaluate("QAIDE.scan()"); chk('c0' in prog(pg), 'simulé : défi 0 après 1 forme dessinée au doigt')
    pg.click('#layers .lb:nth-child(2)'); G(); draw('bass'); pg.evaluate("QAIDE.scan()"); chk('c1' in prog(pg), 'simulé : défi 1 (carte Basse + trait)')
    pg.click('#layers .lb:nth-child(5)'); G(); draw('open'); pg.evaluate("QAIDE.scan()"); chk('c2' in prog(pg), 'simulé : défi 2 (carte Batterie + trait, boîte armée)')
    pg.evaluate("document.getElementById('sScale').value='pm';document.getElementById('sScale').dispatchEvent(new Event('change',{bubbles:true}))"); G()
    pg.click('#worlds .wb:nth-child(1)'); G(); pg.evaluate("QAIDE.scan()"); chk('c3' in prog(pg), 'simulé : défi 3 (gamme + monde)')
    pg.evaluate("QAUTO.AUT['k:clar']={on:true,len:4,pts:[[0,0],[1,1]]}"); G(3); pg.evaluate("QAIDE.scan()"); chk('c4' in prog(pg), 'simulé : défi 4 (automation, compté 3 gestes)')
    pg.evaluate("QEXPORT.opt.last={loops:2}"); G(4); pg.evaluate("QAIDE.scan()"); chk('c5' in prog(pg), 'simulé : défi 5 (enregistrer + exporter, compté 4 gestes)')
    pg.evaluate("localStorage.setItem('qx.sel','')"); G(2)
    ps = pg.context.new_page(); ps.on('pageerror', lambda e: errs.append(str(e))); ps.goto(U + 'morceau.html'); ps.wait_for_timeout(1700)
    ps.evaluate("(()=>{const M=MORCEAU,b=M.addBlock({name:'t',len:2,loop:2,ch:[new Float32Array(88200),new Float32Array(88200)],sr:44100});[0,2,4,6].forEach(s=>M.place(b.id,0,s,2));})()"); G(6)
    ps.evaluate("QAIDE.scan()"); chk('c6' in prog(ps), 'simulé : défi 6 (4 blocs posés, compté 6 gestes)')
    pp = prog(ps); chk(all(k in pp for k in ['c0', 'c1', 'c2', 'c3', 'c4', 'c5', 'c6']), 'progression partagée entre Pattern et Track (localStorage)')
    chk(gest[0] < 90, '7 défis en %d gestes comptés (< 90)' % gest[0])
    chk(not errs, 'aucune erreur JS %s' % errs[:3])
    b.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
