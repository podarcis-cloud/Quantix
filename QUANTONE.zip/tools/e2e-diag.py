# R429 : panneau de diagnostic de performance (QDIAG)
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-unsafe-swiftshader']);ctx=b.new_context(viewport={'width':390,'height':844},permissions=['clipboard-read','clipboard-write']);pg=ctx.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("!!window.QDIAG")and not pg.evaluate("QDIAG.on()"),'module chargé, éteint par défaut')
    pg.click('#bPlay');pg.wait_for_timeout(800)
    # via la feuille Wave → Perf
    box=pg.locator('#qCase .qwv').bounding_box();pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);pg.mouse.down();pg.wait_for_timeout(800);pg.mouse.up();pg.wait_for_timeout(400)
    pg.click('#qwTb button:nth-child(5)');pg.wait_for_timeout(300)
    chk(pg.evaluate("!!document.querySelector('#qwPn input[data-dg]')"),'Perf : case « Diagnostic »')
    pg.click('#qwPn input[data-dg]');pg.wait_for_timeout(2500)
    t=pg.evaluate("document.querySelector('#qDiag pre').textContent");print(t)
    chk(all(k in t for k in ['ÉCRAN','BLOCAGES','WAVE','AUDIO','SYSTÈME','GPU']),'rapport complet')
    chk('i/s' in t and 'AUDIO' in t and ('QUANTONE '+open(__import__('os').path.join(__import__('os').path.dirname(__file__),'..','BUILD')).read().strip()) in t,'cadence, audio et version lus')
    pg.click('#qDiag [data-a=cp]');pg.wait_for_timeout(300)
    cl=pg.evaluate("navigator.clipboard.readText()")
    chk('QUANTONE' in cl and 'ÉCRAN' in cl,'bouton Copier : rapport dans le presse-papiers')
    chk(pg.evaluate("localStorage.getItem('qx.diag')")=='1','état mémorisé')
    # plein écran : le panneau reste visible
    pg.click('#qwFull');pg.wait_for_timeout(800)
    chk(pg.evaluate("getComputedStyle(document.getElementById('qDiag')).display")=='block','visible en plein écran')
    pg.click('#qDiag [data-a=x]');pg.wait_for_timeout(200)
    chk(pg.evaluate("getComputedStyle(document.getElementById('qDiag')).display")=='none' and not pg.evaluate("QDIAG.on()"),'Fermer')
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
