# R434 : le message « Rendu… » ne reste jamais affiché (pendant un enregistrement, ou si le rendu échoue)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_context(viewport={'width':390,'height':844}).new_page()
    er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    cv=pg.evaluate("(function(){var r=document.getElementById('cv').getBoundingClientRect();return [r.x,r.y,r.width,r.height]})()")
    pg.mouse.move(cv[0]+cv[2]*.1,cv[1]+cv[3]*.5);pg.mouse.down()
    for i in range(30):pg.mouse.move(cv[0]+cv[2]*(.1+i*.027),cv[1]+cv[3]*(.5+.1*((i%6)/6)))
    pg.mouse.up();pg.wait_for_timeout(300)
    T="(function(){var t=document.getElementById('toast');return [t.classList.contains('on'),getComputedStyle(t).visibility,t.textContent]})()"
    pg.evaluate("document.getElementById('bPlay').click()");pg.wait_for_timeout(400)
    pg.evaluate("document.getElementById('bRec').click()");pg.wait_for_timeout(600)
    chk(pg.evaluate("QFX2.rec().rec"),'enregistrement en cours')
    pg.evaluate("QEXPORT.run()");pg.wait_for_timeout(9000)
    on,vis,tx=pg.evaluate(T);chk(not on and vis=='hidden','export pendant l\'enregistrement : message effacé (%s)'%tx)
    # rendu qui échoue : message d'erreur, puis effacé
    pg.evaluate("(function(){var P=OfflineAudioContext.prototype;P.startRendering=function(){return Promise.reject(new Error('mémoire'));};})()")
    pg.evaluate("QEXPORT.run()");pg.wait_for_timeout(1200)
    on,vis,tx=pg.evaluate(T);chk(on and ('impossible' in tx or 'failed' in tx),'rendu en échec : annoncé (%s)'%tx)
    pg.wait_for_timeout(3500)
    on,vis,tx=pg.evaluate(T);chk(not on and vis=='hidden','rendu en échec : message ensuite effacé')
    chk(not er,'aucune erreur de page '+str(er[:2]))
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
