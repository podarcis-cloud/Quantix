# R423 : ligne Modulation dans la feuille d'effets d'un bloc Track + rendu export
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
SETUP="""()=>{const M=MORCEAU,sr=22050,n=sr*3,a=new Float32Array(n);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*.5;
 const b=M.addBlock({name:'Bruit',ch:[a,a],sr:sr,len:3,col:'#4DD7FF'});const P=M.P();
 if(!P.tracks.length)document.getElementById('bAdd').click();
 const c=M.place(b.id,0,0,3);return c.id}"""
RMS="""async()=>{const b=await MORCEAU.exportBuf();const d=b.getChannelData(0),sr=b.sampleRate,o=[];
 for(let k=0;k<8;k++){let s=0,n=0;for(let i=Math.floor(k*.25*sr);i<Math.floor((k+1)*.25*sr)&&i<d.length;i++){s+=d[i]*d[i];n++}o.push(Math.sqrt(s/Math.max(1,n)))}return o}"""
sd=lambda a:(sum((x-sum(a)/len(a))**2 for x in a)/len(a))**.5
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(900)
    pg.evaluate(SETUP);pg.wait_for_timeout(300)
    box=pg.locator('.clip').first.bounding_box()
    pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);pg.mouse.down();pg.wait_for_timeout(750);pg.mouse.up()
    pg.click('#cm [data-a="fx"]');pg.wait_for_timeout(200)
    pg.select_option('#fxSel','filt');pg.wait_for_timeout(300)
    pg.evaluate("(()=>{const c=MORCEAU.P().clips[0];c.fx[0].m=1;c.fx[0].f=1500;c.fx[0].sw=0;})()")
    base=pg.evaluate(RMS)
    chk(pg.evaluate("!!document.querySelector('#cm select[data-md=s]')"),'ligne Modulation présente')
    pg.select_option('#cm select[data-md=s]','lfo');pg.wait_for_timeout(300)
    chk(pg.evaluate("document.querySelectorAll('#cm [data-md]').length")==5,'LFO : 5 commandes')
    pg.select_option('#cm select[data-md=k]','f')
    pg.evaluate("(()=>{const r=document.querySelector('#cm input[data-md=r]');r.value=2;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}));const d=document.querySelector('#cm input[data-md=d]');d.value=1;d.dispatchEvent(new Event('input',{bubbles:true}));d.dispatchEvent(new Event('change',{bubbles:true}));})()")
    m=pg.evaluate("JSON.stringify(MORCEAU.P().clips[0].fx[0].mod)");print(m)
    chk('"r":2' in m and '"d":1' in m and '"s":"lfo"' in m,'réglages stockés dans le bloc')
    mo=pg.evaluate(RMS);print([round(x,3) for x in base]);print([round(x,3) for x in mo])
    chk(sd(mo)>sd(base)*3+.003,'export : le niveau varie (σ %.3f vs %.3f)'%(sd(mo),sd(base)))
    pg.select_option('#cm select[data-md=s]','');pg.wait_for_timeout(200)
    chk(pg.evaluate("!MORCEAU.P().clips[0].fx[0].mod"),'retrait')
    chk(not er,'aucune erreur %s'%er[:2]);b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
