/* QXF2 : barre de l'aperçu des décors (aperçu seulement). __NIV__ et __FORCE__ sont remplacés par build-apercu.py.
   Rangée compacte : ◀ niveau ▶ · « Décor : nouveau / ancien » (bascule sans recharger) · ⋯ · Carte (sélecteur animé du monde)
   ⋯ = grille des 12 niveaux (un par monde ; le 12 est un niveau du jeu habillé du décor Fluides) + curseur Vie 0–3
       + « Carte : animée / ancienne » (coupe-circuit localStorage 'qxcarte') + événement rare (Magnétisme) + mesure. */
(function () {
  var N = __NIV__, FORCE = __FORCE__, k = 0;
  window.QXF2_FORCE = FORCE;                       // { idx: 'fluides' } : niveau du jeu habillé d'un décor sans niveau propre (monde 12)
  var B = 'height:32px;border-radius:999px;border:1px solid rgba(150,200,215,.28);background:rgba(120,170,190,.10);color:#d5e2e7;font:600 12px/1 ui-sans-serif,system-ui,sans-serif;letter-spacing:.03em;padding:0 10px;white-space:nowrap;touch-action:manipulation';
  function el(t, css, txt) { var x = document.createElement(t); if (css) x.style.cssText = css; if (txt) x.textContent = txt; return x; }
  var bar = el('div', 'position:fixed;left:50%;transform:translateX(-50%);top:calc(env(safe-area-inset-top,0px) + 46px);z-index:99998;display:flex;flex-direction:column;align-items:center;gap:6px;max-width:calc(100vw - 16px)');
  bar.id = 'qxNiv';
  var row = el('div', 'display:flex;gap:5px;align-items:center;padding:4px 5px;border-radius:999px;background:rgba(5,7,13,.74);border:1px solid rgba(150,200,215,.22)');
  var prev = el('button', B, '◀'), lab = el('span', 'min-width:40px;text-align:center;color:#e8d3b0;font:700 12px/1 ui-sans-serif,system-ui,sans-serif'), next = el('button', B, '▶');
  var dec = el('button', B), plus = el('button', B, '⋯'), carte = el('button', B, 'Carte');
  [prev, lab, next, dec, plus, carte].forEach(function (x) { if (x.tagName === 'BUTTON') x.type = 'button'; row.appendChild(x); });
  var pan = el('div', 'display:none;flex-direction:column;gap:8px;padding:8px;border-radius:14px;background:rgba(5,7,13,.86);border:1px solid rgba(150,200,215,.22)');
  var grille = el('div', 'display:grid;grid-template-columns:repeat(6,auto);gap:5px');
  var vrow = el('label', 'display:flex;align-items:center;gap:8px;color:#c9d8de;font:600 12px/1 ui-sans-serif,system-ui,sans-serif'), vtxt = el('span', 'min-width:44px'), vin = el('input');
  vin.type = 'range'; vin.min = '0'; vin.max = '3'; vin.step = '0.1'; vin.style.cssText = 'width:150px';
  vrow.appendChild(vtxt); vrow.appendChild(vin);
  var r2 = el('div', 'display:flex;gap:5px;flex-wrap:wrap;justify-content:center'), kc = el('button', B), evb = el('button', B, 'Événement rare');
  kc.type = evb.type = 'button'; r2.appendChild(kc); r2.appendChild(evb);
  var mes = el('div', 'color:#9fb3bb;font:500 11px/1.3 ui-monospace,monospace;text-align:center;max-width:300px');
  pan.appendChild(grille); pan.appendChild(vrow); pan.appendChild(r2); pan.appendChild(mes);
  bar.appendChild(row); bar.appendChild(pan);

  var VUES = ['vResult', 'vLevels', 'vPause', 'vSet', 'vWorld'];
  function fermer() { VUES.forEach(function (id) { var v = document.getElementById(id); if (v) show(v, false); }); try { cancelAdvance(); } catch (e) {} }
  function etiquette(i) { return FORCE[i] ? '12' : LEVELS[i].wd + '·' + (i % 12 + 1); }
  function mondeDe(i) { return FORCE[i] ? 12 : LEVELS[i].wd; }
  function aller(j) {
    k = (j + N.length) % N.length;
    try { fermer(); goto('game'); loadLevel(N[k]); } catch (e) { console.log(e); }
    maj();
  }
  function ouvrirCarte() {                          // sélecteur animé du monde courant (états réels du joueur)
    var i = N[k], w = mondeDe(i);
    fermer();
    if (w <= 11) { openWorld(w); return; }
    // monde 12 : aucun niveau propre → carte Fluides montée à la main sur le niveau habillé (états de démonstration)
    openWorld(LEVELS[i].wd);
    if (!(window.QXCARTE && QXCARTE.actif(12))) return;
    var et = [], fait = !!S.best[i];
    for (var q = 0; q < 12; q++) et.push({ i: 9000 + q, etat: q < 5 ? 'done' : q === 5 ? (fait ? 'done' : 'cur') : (q === 6 && fait ? 'cur' : 'open'), etoiles: q < 5 ? 3 - q % 3 : 0 });
    document.getElementById('wMap').innerHTML = '';
    QXCARTE.monter(document.getElementById('wMap'), { monde: 12, etats: et, depuis: -1, sobre: RM, son: function (n) { try { Audio1.playSfx(n); } catch (e) {} },
      choisir: function () { fermer(); S.zen = false; goto('game'); loadLevel(i); } });
    document.getElementById('wNum').textContent = 'MONDE 12'; document.getElementById('wName').textContent = 'Fluides';
    document.getElementById('wEl').textContent = 'décor seul (aucun niveau propre)'; document.getElementById('wStat').textContent = 'aperçu';
  }
  function carteLS() { try { return localStorage.getItem('qxcarte') !== '0'; } catch (e) { return true; } }
  function maj() {
    var i = N.indexOf(S.li); if (i >= 0) k = i;
    var l = LEVELS[N[k]]; lab.textContent = etiquette(N[k]); lab.title = FORCE[N[k]] ? 'Décor Fluides sur « ' + l.n + ' »' : l.n;
    for (var j = 0; j < grille.children.length; j++) grille.children[j].style.borderColor = j === k ? 'rgba(227,165,90,.95)' : 'rgba(150,200,215,.28)';
    var on = !!(window.QXF2 && QXF2.actifLS);
    dec.textContent = 'Décor : ' + (on ? 'nouveau' : 'ancien'); dec.style.color = on ? '#9fe3d0' : '#e8b98a';
    var ca = carteLS(); kc.textContent = 'Carte : ' + (ca ? 'animée' : 'ancienne'); kc.style.color = ca ? '#9fe3d0' : '#e8b98a';
    evb.style.display = mondeDe(N[k]) === 8 ? '' : 'none';
    var v = window.QXF2 ? QXF2.reglages.vie : 2.4; vtxt.textContent = 'Vie ' + (+v).toFixed(1); if (document.activeElement !== vin) vin.value = v;
    if (pan.style.display !== 'none' && window.QXF2 && QXF2.mesure) {
      var m = QXF2.mesure(false), a = m.anciens;
      mes.textContent = (m.nom || '—') + ' · ' + (+m.ema).toFixed(2) + ' ms/image · palier ' + m.degrade + (a ? ' · anciens ' + a.n + (a.ev ? ' · événement' : '') + (m.nom === 'magnetisme' ? ' · ferrofluide WebGL ' + (a.f4 ? 'oui' : 'non (2D)') : '') : '');
    }
  }
  N.forEach(function (i, j) {
    var l = LEVELS[i], x = el('button', B + ';min-width:44px;padding:0 6px', etiquette(i));
    x.type = 'button'; x.title = FORCE[i] ? 'Fluides (décor) sur « ' + l.n + ' »' : l.n;
    x.setAttribute('aria-label', FORCE[i] ? 'Monde 12, décor Fluides, sur le niveau ' + l.n : 'Monde ' + l.wd + ', niveau ' + (i % 12 + 1) + ' : ' + l.n);
    x.onclick = function () { aller(j); };
    grille.appendChild(x);
  });
  prev.onclick = function () { aller(k - 1); }; next.onclick = function () { aller(k + 1); };
  prev.setAttribute('aria-label', 'Niveau précédent'); next.setAttribute('aria-label', 'Niveau suivant'); plus.setAttribute('aria-label', 'Tous les niveaux et réglages');
  carte.setAttribute('aria-label', 'Sélecteur animé de ce monde');
  plus.onclick = function () { pan.style.display = pan.style.display === 'none' ? 'flex' : 'none'; maj(); };
  dec.onclick = function () { if (window.QXF2) QXF2.basculer(!QXF2.actifLS); maj(); };
  carte.onclick = ouvrirCarte;
  kc.onclick = function () { try { localStorage.setItem('qxcarte', carteLS() ? '0' : '1'); } catch (e) {} maj(); };
  evb.onclick = function () { if (window.QXF2) QXF2.evenement(); };
  vin.oninput = function () { if (window.QXF2) QXF2.vie(+vin.value); maj(); };
  document.body.appendChild(bar); maj(); setInterval(maj, 500);
})();
