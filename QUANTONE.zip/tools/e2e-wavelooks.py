# R422 : portage des rendus de l'aperçu (sig, nuee, houle, const, cells, fluide) + réglages par rendu + Perf
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("QWV.looks().join()")=='sig,nuee,houle,const,cells,fluide','6 rendus déclarés')
    N="(()=>{const c=document.getElementById('qWave');const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0,s=0;for(let i=0;i<d.length;i+=4){if(d[i]>60||d[i+1]>50||d[i+2]>60)n++;s+=d[i+1]*3+d[i+2]+d[i]}return [n,s]})()"
    pg.click('#bPlay');pg.wait_for_timeout(1500)
    sig={}
    for id in ['sig','nuee','houle','const','cells','fluide']:
        pg.evaluate("(id)=>QWV.look(id)",id);pg.wait_for_timeout(2500)
        n=pg.evaluate(N);sig[id]=n[1];chk(n[0]>500,'%s : se dessine (%d px)'%(id,n[0]))
    chk(len(set(sig.values()))>=5,'rendus visuellement différents')
    chk(pg.evaluate("QWV.gl()")in(True,False),'WebGL : %s'%pg.evaluate("QWV.gl()"))
    for id in ['nuee','const']:
        pg.evaluate("(id)=>QWV.look(id)",id);pg.evaluate("QWV.ps('pop',80)");pg.wait_for_timeout(1800);a=pg.evaluate(N)[0]
        pg.evaluate("QWV.ps('pop',600)");pg.wait_for_timeout(1800);bb=pg.evaluate(N)[0]
        chk(bb>a*1.05,'%s : nb de particules change le rendu (%d → %d)'%(id,a,bb))
    pg.evaluate("QWAVE.set('dn',30);QWAVE.set('sw',4);QWAVE.set('q','low')")
    chk(pg.evaluate("[QWAVE.get('dn'),QWAVE.get('sw'),QWAVE.get('q')].join()")=='30,4,low','réglages dans l’API d’automation')
    pg.evaluate("QWAVE.set('q','auto')")
    pg.evaluate("localStorage.setItem('qx.wset',JSON.stringify({rd:'cells'}))");pg.reload();pg.wait_for_timeout(1500)
    chk(pg.evaluate("(()=>{try{return JSON.parse(localStorage.getItem('qx.wset')).rd}catch(e){return ''}})()")=='cells','rendu mémorisé')
    chk(not er,'aucune erreur de page %s'%er[:2])
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
