# R417 : 5 rendus de wave sélectionnables (houle, nuée, tourbillon, constellation, cellules)
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("QWV.looks().join()")=='houle,nuee,tourbillon,constellation,cellules','5 rendus déclarés')
    N="(()=>{const c=document.getElementById('qWave');const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0,s=0;for(let i=0;i<d.length;i+=4){if(d[i]>60||d[i+1]>50||d[i+2]>60)n++;s+=d[i+1]+d[i+2]}return [n,s]})()"
    pg.evaluate("QWVSTUB=1") if False else None
    pg.click('#bPlay');pg.wait_for_timeout(1500)
    sig={}
    for id in ['houle','nuee','tourbillon','constellation','cellules']:
        pg.evaluate("(id)=>QWV.look(id)",id);pg.wait_for_timeout(2500)
        n=pg.evaluate(N);ms=pg.evaluate("(()=>new Promise(r=>{let n=0,t0=performance.now();const f=()=>{n++;if(n<40)requestAnimationFrame(f);else r((performance.now()-t0)/40)};f()}))()")
        sig[id]=n[1];chk(n[0]>800,'%s : se dessine (%d px, %.1f ms/image)'%(id,n[0],ms))
    chk(len(set(sig.values()))>=4,'les rendus sont visuellement différents')
    # sélecteur dans la feuille
    pg.click('#bPlay');pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('.qwv').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,pointerId:1}))")
    chk(not er,'aucune erreur de page %s'%er[:2])
    pg.evaluate("localStorage.setItem('qx.wset',JSON.stringify({rd:'cellules'}))");pg.reload();pg.wait_for_timeout(1500)
    chk(pg.evaluate("QWV.looks().length")==5 and pg.evaluate("(()=>{try{return JSON.parse(localStorage.getItem('qx.wset')).rd}catch(e){return ''}})()")=='cellules','réglage mémorisé')
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
