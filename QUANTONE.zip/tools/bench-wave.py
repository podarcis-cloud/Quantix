# Mesure : durée moyenne d'une image de wave par rendu, processeur ralenti x6 (simulation d'un vieil iPhone)
import sys,json
from playwright.sync_api import sync_playwright
RATE=float(sys.argv[1]) if len(sys.argv)>1 else 6
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']);pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=3)
    cdp=pg.context.new_cdp_session(pg);cdp.send('Emulation.setCPUThrottlingRate',{'rate':RATE})
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(2500)
    pg.click('#bPlay');pg.wait_for_timeout(1000)
    out={}
    for look in ['sig','nuee','houle','const','cells','fluide']:
        pg.evaluate("(l)=>QWV.look(l)",look);pg.wait_for_timeout(1500)
        # temps passé DANS QWV.draw (JS) et cadence réelle de rAF
        r=pg.evaluate("""()=>new Promise(res=>{const d=QWV.draw;let tot=0,n=0;QWV.draw=function(){const t=performance.now();const r=d.apply(this,arguments);tot+=performance.now()-t;n++;return r;};
          let f=0,t0=performance.now();const loop=()=>{f++;if(performance.now()-t0<3000)requestAnimationFrame(loop);else{QWV.draw=d;res({fps:f/3,ms:n?tot/n:0})}};requestAnimationFrame(loop);})""")
        out[look]=r;print('%-7s %5.1f i/s   %5.1f ms JS/image'%(look,r['fps'],r['ms']))
    b.close()
