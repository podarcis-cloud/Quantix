# R432 : ouvrir Quantone depuis le jeu ne doit déclencher AUCUN son du jeu (cause du clic : Audio1.unlock() dans openQt)
from playwright.sync_api import sync_playwright
import os
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
INIT=r"""(()=>{var L=window.__L=[];function lg(s){L.push(s);}
['OscillatorNode','AudioBufferSourceNode','ConstantSourceNode'].forEach(function(n){var P=window[n].prototype,s=P.start;P.start=function(){lg(n);return s.apply(this,arguments);};});
var pl=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){lg('media');return pl.apply(this,arguments);};
var A=window.AudioContext;window.AudioContext=function(){lg('ctx');return new A();};window.AudioContext.prototype=A.prototype;})();"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);ctx=b.new_context();ctx.add_init_script(INIT);pg=ctx.new_page()
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/index.html');pg.wait_for_timeout(1500);pg.mouse.click(200,300);pg.wait_for_timeout(500)
    n0=pg.evaluate("window.__L.length")
    pg.evaluate("QTOV.open()");pg.wait_for_timeout(1800)
    n1=pg.evaluate("window.__L.length")
    chk(n1==n0,'ouverture de Quantone : aucun son/contexte du jeu créé (%d -> %d)'%(n0,n1))
    chk(pg.evaluate("!document.getElementById('qtOv').hidden"),'cadre Quantone ouvert')
    src=pg.evaluate("document.getElementById('qtF').src")
    bd=open(os.path.join(os.path.dirname(__file__),'..','BUILD')).read().strip()
    chk(src.endswith('?v='+bd),'cadre Quantone chargé avec le tampon courant (%s)'%src[-30:])
    pg.evaluate("QTOV.close()");pg.wait_for_timeout(400)
    chk(pg.evaluate("document.getElementById('qtOv').hidden"),'fermeture ok')
    chk(not er,'aucune erreur de page '+str(er[:2]))
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
