# R432/R433 : ni l'ouverture du jeu ni celle de Quantone ne doivent créer de second contexte audio, de boucle média ni d'oscillateur ;
# elles jouent seulement le son d'ouverture (1 AudioBufferSource) dans l'unique contexte de sound.js (cause du clic : A0.unlock() créait un 2e contexte)
from playwright.sync_api import sync_playwright
import os
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
INIT=r"""(()=>{var L=window.__L=[];function lg(s){L.push(s);}
['OscillatorNode','AudioBufferSourceNode','ConstantSourceNode'].forEach(function(n){var P=window[n].prototype,s=P.start;P.start=function(){lg(n);return s.apply(this,arguments);};});
var pl=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){lg('media');return pl.apply(this,arguments);};
var A=window.AudioContext;window.AudioContext=function(){lg('ctx');return new A();};window.AudioContext.prototype=A.prototype;})();"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);ctx=b.new_context();ctx.add_init_script(INIT);pg=ctx.new_page()
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/index.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("window.__L.length")==0,'avant tout geste : aucun son ni contexte')
    pg.evaluate("document.getElementById('hCont').click()");pg.wait_for_timeout(1500)
    L=pg.evaluate("window.__L")
    chk(L.count('ctx')==1,'ouverture du jeu : un seul AudioContext (%d)'%L.count('ctx'))
    chk(pg.evaluate("Audio1.state()")=='running','contexte du jeu actif')
    pg.wait_for_timeout(2500)
    pg.evaluate("window.__L.length=0");pg.evaluate("QTOV.close&&0")
    pg.wait_for_timeout(3200)
    pg.evaluate("QTOV.open()");pg.wait_for_timeout(300)
    L=pg.evaluate("window.__L")
    chk(L.count('AudioBufferSourceNode')==1 and L.count('ctx')==0 and L.count('media')==0 and 'OscillatorNode' not in L,'ouverture de Quantone : seulement le son d\'ouverture '+str(L))
    pg.wait_for_timeout(1500)
    src=pg.evaluate("document.getElementById('qtF').src")
    bd=open(os.path.join(os.path.dirname(__file__),'..','BUILD')).read().strip()
    chk(src.endswith('?v='+bd),'cadre Quantone chargé avec le tampon courant (%s)'%src[-30:])
    pg.evaluate("QTOV.close()");pg.wait_for_timeout(400)
    chk(pg.evaluate("document.getElementById('qtOv').hidden"),'fermeture ok')
    chk(not er,'aucune erreur de page '+str(er[:2]))
    b.close()
print('RÉSULTAT %d/%d'%(sum(res),len(res)))
