"""build-dubpack.py (R439) — pack « Dubstep » de la banque de sons : voix, radio, animaux, grenouilles, FX de drop.
Tout est SYNTHÉTISÉ (aucun enregistrement) : sources glottales/impulsions + filtres à formants.
Usage : python3 tools/build-dubpack.py <dossier assets/bank> → écrit pack-dub.bin et ajoute le pack + les sons à bank.json (idempotent)."""
import json,sys,numpy as np
from scipy.signal import lfilter
SR=32000;R=np.random.default_rng(439)
def T(d):return np.arange(int(d*SR))/SR
def env(n,a=.005,r=.02):
    e=np.ones(n);na=max(1,int(a*SR));nr=max(1,int(r*SR));e[:na]=np.linspace(0,1,na);e[-nr:]*=np.linspace(1,0,nr);return e
def lin(pts,n):  # [(t01,val)] -> courbe de n points
    x=np.array([p[0] for p in pts]);y=np.array([p[1] for p in pts]);return np.interp(np.linspace(0,1,n),x,y)
def bq(x,f,Q,kind='bp'):
    w=2*np.pi*min(f,SR*.45)/SR;a=np.sin(w)/(2*Q);c=np.cos(w)
    if kind=='bp':b=[a,0,-a];A=[1+a,-2*c,1-a]
    elif kind=='lp':b=[(1-c)/2,1-c,(1-c)/2];A=[1+a,-2*c,1-a]
    else:b=[(1+c)/2,-(1+c),(1+c)/2];A=[1+a,-2*c,1-a]
    return lfilter(np.array(b)/A[0],np.array(A)/A[0],x)
def vbp(x,f,Q,blk=160):   # bande passante à fréquence variable (f = tableau), par blocs
    out=np.zeros_like(x);zi=None;n=len(x)
    for s in range(0,n,blk):
        fb=float(f[min(s,len(f)-1)]);w=2*np.pi*min(max(fb,40),SR*.45)/SR;a=np.sin(w)/(2*Q);c=np.cos(w)
        b=np.array([a,0,-a])/(1+a);A=np.array([1,-2*c/(1+a),(1-a)/(1+a)])
        if zi is None:zi=np.zeros(2)
        y,zi=lfilter(b,A,x[s:s+blk],zi=zi);out[s:s+blk]=y
    return out
def phase(f):return np.cumsum(f)/SR
def saw(f):return 2*(phase(f)%1)-1
def sq(f,w=.5):return np.where((phase(f)%1)<w,1.,-1.)
def noise(n):return R.standard_normal(n)
def soft(x,k):return np.tanh(k*x)/np.tanh(k)
F={'a':(800,1150,2900),'e':(400,1700,2600),'i':(270,2140,2950),'o':(450,800,2830),'u':(325,700,2700),'E':(660,1720,2410)}
def voice(vows,f0,d,breath=.05,vib=.0,gain=1,Q=9,pre=0):
    n=int(d*SR);f0=lin(f0,n) if not np.isscalar(f0) else np.full(n,f0);
    if vib:f0=f0*(1+vib*np.sin(2*np.pi*5.4*np.arange(n)/SR))
    src=saw(f0)+breath*noise(n);ks=np.linspace(0,1,len(vows));out=0
    for k in range(3):
        tr=np.interp(np.linspace(0,1,n),ks,[F[v][k] for v in vows]);out=out+vbp(src,tr,Q)*[3,2,1.2][k]
    if pre:  # consonne soufflée (h, y, ch)
        m=int(pre*SR);h=bq(noise(m),1800,1.2)*np.linspace(.2,1,m)*.9;out[:m]+=h*(np.abs(out).max()+1e-9)*.8
    return out*env(n,.012,.04)*gain
def pulsed(rate,f1,f2,d,noiseA=.05,q=12,wob=0,pw=1.0):
    n=int(d*SR);rt=lin(rate,n) if not np.isscalar(rate) else np.full(n,rate);ph=phase(rt);imp=(np.diff(np.floor(ph),prepend=0)>0).astype(float)
    imp=lfilter([1],[1,-.985*pw],imp)   # impulsion amortie = bouffée glottale
    a=lin(f1,n) if not np.isscalar(f1) else np.full(n,f1);b=lin(f2,n) if not np.isscalar(f2) else np.full(n,f2)
    if wob:a=a*(1+wob*np.sin(2*np.pi*6*np.arange(n)/SR));b=b*(1+.5*wob*np.sin(2*np.pi*6*np.arange(n)/SR))
    x=imp+noiseA*noise(n)*.2;y=vbp(x,a,q)*2+vbp(x,b,q)*1.1+vbp(x,a*.5,6)*.8
    sh=np.sin(np.pi*np.linspace(0,1,n))**.6
    return y*sh
def seqsum(parts,d):  # [(t,sig)] sommés dans un tampon de d secondes
    out=np.zeros(int(d*SR))
    for t,s in parts:
        i=int(t*SR);j=min(len(out),i+len(s))
        if j>i:out[i:j]+=s[:j-i]
    return out
def croak(rate,f1,f2,d,**k):return pulsed(rate,f1,f2,d,**k)*env(int(d*SR),.004,.03)
def chirp(f0,f1,d,vib=0,vr=30):
    n=int(d*SR);f=lin([(0,f0),(1,f1)],n);f=f*(1+vib*np.sin(2*np.pi*vr*np.arange(n)/SR));return np.sin(2*np.pi*phase(f))*env(n,.004,.01)*np.hanning(n)**.5
def radio(x):return soft(bq(bq(x,3200,.7,'lp'),380,.7,'hp'),2.2)
S=[]  # (fam,nom,signal)
def add(fam,nm,x):S.append((fam,nm,np.nan_to_num(x)))
# ── voix ──
add('voix','Hey',voice(['e','E','i'],[(0,210),(1,165)],.38,pre=.07))
add('voix','Yeah',voice(['i','E','E'],[(0,190),(.4,175),(1,140)],.5,pre=.05))
add('voix','Oh',voice(['o','o','u'],[(0,200),(1,130)],.55,vib=.01))
add('voix','Wah',voice(['u','a','a'],[(0,150),(.6,170),(1,150)],.38))
add('voix','Ha !',voice(['a','a'],[(0,240),(1,170)],.22,breath=.4,pre=.05))
add('voix','Yo',voice(['i','o'],[(0,180),(1,140)],.32,pre=.04))
add('voix','Woah',voice(['o','a','o'],[(0,150),(.35,260),(1,130)],.95,vib=.02))
ch=sum(voice(['o','u','u'],f,1.7,breath=.02,vib=.012,gain=.6) for f in [196,247,294,392,196*1.006])
add('voix','Chœur ooh',ch*np.minimum(1,np.arange(len(ch))/(.45*SR)))
add('voix','Chuchotis',voice(['a','e','i'],[(0,160),(1,160)],.8,breath=3.5,gain=.5))
rire=seqsum([(i*.22,voice(['a','a'],[(0,260-i*18),(1,200-i*18)],.17,breath=.3,pre=.04)) for i in range(4)],1.0)
add('voix','Rire',rire)
beg=seqsum([(i*.085,voice(['a','a'],160,.06,gain=1)) for i in range(8)],.8)
add('voix','Bégaiement',beg)
add('voix','Cri',soft(voice(['a','a','E'],[(0,320),(.3,440),(1,360)],.6,vib=.015),2.5))
# ── radio ──
n=int(1.0*SR);st=noise(n)*(.5+.5*np.sin(2*np.pi*3*np.arange(n)/SR)**2);cr=(R.random(n)>.9985)*R.standard_normal(n)*6
add('radio','Parasites',radio(bq(st,1800,.6)+cr)*env(n,.02,.1))
n=int(1.6*SR);fr=lin([(0,300),(.3,2600),(.55,800),(.8,3000),(1,500)],n);t=np.arange(n)/SR
add('radio','Recherche de station',radio(np.sin(2*np.pi*phase(fr))*.7+.5*noise(n)*np.abs(np.sin(2*np.pi*1.7*t)))*env(n,.03,.15))
bp=[];tt=0
for dd in [.07,.07,.18,.07,.18,.09]:bp.append((tt,np.sin(2*np.pi*880*np.arange(int(dd*SR))/SR)*env(int(dd*SR),.004,.008)));tt+=dd+.06
add('radio','Bips morse',radio(seqsum(bp,1.1)+.05*noise(int(1.1*SR))))
n=int(.45*SR);sq_=noise(n)*np.exp(-np.arange(n)/SR*18);sq_[:60]+=3
add('radio','Squelch radio',radio(sq_))
bab=seqsum([(i*.2,voice([R.choice(list(F)),R.choice(list(F))],[(0,R.uniform(110,170)),(1,R.uniform(100,150))],.17,breath=.15)) for i in range(7)],1.5)
add('radio','Voix de radio',radio(bab*1.5+.12*noise(len(bab))))
rb=np.concatenate([np.sin(2*np.pi*1200*np.arange(int(.1*SR))/SR),np.zeros(int(.02*SR)),np.sin(2*np.pi*800*np.arange(int(.1*SR))/SR)])
add('radio','Talkie bip',radio(rb*env(len(rb),.004,.01)+.04*noise(len(rb))))
n=int(1.2*SR);t=np.arange(n)/SR;add('radio','Brouillage AM',radio((.6+.4*np.sin(2*np.pi*100*t))*noise(n)*np.sin(np.pi*t/1.2)+.3*np.sin(2*np.pi*100*t)))
n=int(1.0*SR);vi=(R.random(n)>.9975)*R.standard_normal(n)*4;vi=lfilter([1],[1,-.8],vi)+.02*noise(n)
add('radio','Vieux phono',radio(vi*3)*env(n,.02,.1))
# ── grenouilles ──
add('grenouille','Coa',croak([(0,48),(1,34)],[(0,520),(1,330)],1500,.28))
add('grenouille','Croa long',croak([(0,40),(1,27)],[(0,430),(1,360)],1250,.7))
add('grenouille','Ouaouaron',croak([(0,22),(1,13)],[(0,230),(1,200)],700,1.0,q=9))
add('grenouille','Rainette',seqsum([(0,croak(70,[(0,2400),(1,2100)],3900,.1,q=16)),(.14,croak(70,[(0,2400),(1,2100)],3900,.12,q=16))],.3))
add('grenouille','Ribbit',seqsum([(0,croak([(0,55),(1,40)],[(0,280),(1,420)],1100,.16)),(.2,croak([(0,50),(1,36)],[(0,500),(1,900)],1900,.2))],.45))
add('grenouille','Triple coa',seqsum([(i*.23,croak([(0,46),(1,33)],[(0,500-i*40),(1,320)],1450,.2)) for i in range(3)],.75))
mare=seqsum([(R.uniform(0,1.9),croak([(0,R.uniform(30,60)),(1,R.uniform(22,40))],[(0,R.uniform(250,700)),(1,R.uniform(250,450))],R.uniform(900,1900),R.uniform(.12,.4))*R.uniform(.25,.8)) for _ in range(16)],2.2)
add('grenouille','Mare au crépuscule',mare)
n=int(.2*SR);tt=np.arange(n)/SR;g=np.sin(2*np.pi*phase(lin([(0,260),(1,900)],n)))*np.exp(-tt*22);g2=np.sin(2*np.pi*phase(lin([(0,330),(1,1100)],n)))*np.exp(-tt*28)
add('grenouille','Gloup',seqsum([(0,g),(.09,g2*.8)],.3))
cl=seqsum([(sum([.07+.006*i for i in range(k)]) if k else 0,bq(noise(int(.012*SR)),2600,5)*np.hanning(int(.012*SR))*6) for k in range(10)],.9)
add('grenouille','Cliquetis',cl)
add('grenouille','Coa wobble',croak([(0,38),(1,30)],[(0,450),(1,450)],1300,.85,wob=.55))
# ── animaux ──
oi=seqsum([(i*.17,chirp(R.uniform(3000,4200),R.uniform(4200,5600),.1,.03,40)) for i in range(4)],.75)
add('animal','Oiseau',oi)
add('animal','Corbeau',croak([(0,85),(1,60)],[(0,900),(1,700)],1500,.42,noiseA=1.2,q=7))
n=int(.85*SR);add('animal','Miaou',voice(['e','a','u'],[(0,380),(.35,760),(.7,640),(1,420)],.85,vib=.01,Q=7))
add('animal','Wouf',seqsum([(0,voice(['o','a'],[(0,210),(1,120)],.14,breath=.5,Q=6)*1.2),(.25,voice(['o','a'],[(0,200),(1,115)],.16,breath=.5,Q=6)*1.2)],.5))
add('animal','Loup',voice(['o','u','o'],[(0,300),(.35,540),(.7,480),(1,330)],2.0,breath=.03,vib=.018,Q=6))
n=int(2.3*SR);fb=lin([(0,120),(.3,260),(.6,170),(1,95)],n);t=np.arange(n)/SR
wh=sum(np.sin(2*np.pi*phase(fb*k)*1)*a for k,a in [(1,1),(2,.5),(3,.25),(4,.12)])*np.sin(np.pi*t/2.3)**.7
add('animal','Baleine',wh*(1+.06*np.sin(2*np.pi*3*t)))
n=int(.9*SR);t=np.arange(n)/SR;gr=sum(np.sin(2*np.pi*4400*t)*((t%.3)<.16)*(.5+.5*np.sin(2*np.pi*45*t)) for _ in [0])
add('animal','Grillon',gr*env(n,.01,.05)*.8)
hb=lambda:np.sin(2*np.pi*phase(lin([(0,420),(1,330)],int(.34*SR))))*env(int(.34*SR),.05,.12)+.25*np.sin(2*np.pi*phase(lin([(0,840),(1,660)],int(.34*SR))))*env(int(.34*SR),.05,.12)
add('animal','Hibou',seqsum([(0,hb()*.8),(.45,hb())],.9))
qk=lambda:croak(105,[(0,950),(1,800)],1950,.16,noiseA=.5,q=9)
add('animal','Canard',seqsum([(0,qk()),(.22,qk()*.9)],.45))
n=int(.9*SR);t=np.arange(n)/SR;ab=saw(190*(1+.02*np.sin(2*np.pi*7*t)))*(.6+.4*np.sin(2*np.pi*190*t));add('animal','Abeille',vbp(ab,np.full(n,1400),.9)*3*env(n,.05,.15))
# ── FX de drop ──
n=int(1.9*SR);t=np.arange(n)/SR;u=t/1.9
rs=vbp(noise(n),300*(8000/300)**u,2.2)*3*u**1.5+np.sin(2*np.pi*phase(110*(14)**u))*.35*u
add('dubfx','Riser',rs*env(n,.05,.02))
n=int(1.5*SR);t=np.arange(n)/SR;u=t/1.5
add('dubfx','Downlifter',(vbp(noise(n),7000*(250/7000)**u,2.2)*3+np.sin(2*np.pi*phase(1200*(.07)**u))*.3)*(1-u)**1.2*env(n,.01,.02))
n=int(1.5*SR);t=np.arange(n)/SR;im=np.sin(2*np.pi*phase(30+34*np.exp(-t*7)))*np.exp(-t*2.4)*1.1+bq(noise(n),900,.7,'lp')*np.exp(-t*9)*.9
add('dubfx','Impact sub',im*env(n,.001,.05))
n=int(1.7*SR);t=np.arange(n)/SR;u=t/1.7;add('dubfx','Crash inversé',bq(noise(n),1800,.6,'hp')*u**2.2*env(n,.01,.01)*1.3)
n=int(.6*SR);t=np.arange(n)/SR;u=t/.6;add('dubfx','Laser',soft(saw(6000*(.02)**u),3)*np.exp(-u*2.5)*env(n,.002,.03))
n=int(1.0*SR);t=np.arange(n)/SR;u=t/1.0;add('dubfx','Rembobinage',(np.sin(2*np.pi*phase(150*(40)**u))*.5+vbp(noise(n),200*(30)**u,3)*1.5)*u**.5*env(n,.01,.04))
n=int(1.6*SR);t=np.arange(n)/SR;add('dubfx','Sirène',np.sin(2*np.pi*phase(1000+380*np.sin(2*np.pi*1.25*t)))*env(n,.05,.1)*.8)
n=int(1.0*SR);t=np.arange(n)/SR;u=t/1.0;add('dubfx','Chute',(soft(saw(1800*(.05)**u),2)*.5+vbp(noise(n),2500*(.1)**u,2)*1.2)*(1-u)**.8*env(n,.003,.02))
n=int(1.6*SR);t=np.arange(n)/SR;sd=np.sin(2*np.pi*phase(90*(.3)**(t/1.6)));add('dubfx','Sub drop',soft(sd,2.5)*env(n,.004,.08)*(1-.3*t/1.6))
n=int(2.0*SR);t=np.arange(n)/SR;gg=sum(np.sin(2*np.pi*f*t+R.uniform(0,6))*a*np.exp(-t*d) for f,a,d in [(55,1,1.6),(131,.7,2.2),(203,.5,2.8),(317,.4,3.6),(441,.3,4.5),(611,.25,5.5)])
add('dubfx','Gong sombre',gg*env(n,.002,.1))
n=int(.45*SR);t=np.arange(n)/SR;sc=saw(250*(1+1.8*np.sin(2*np.pi*5*t)**3))*(.5+.5*np.sin(np.pi*t/.45));add('dubfx','Scratch',vbp(sc,1500+1000*np.sin(2*np.pi*5*t),2)*3*env(n,.005,.04))
n=int(1.1*SR);t=np.arange(n)/SR;u=t/1.1;vs=saw(380*(1-u)**1.5)*(1-u)+.08*noise(n)*(R.random(n)>.6);add('dubfx','Arrêt vinyle',bq(vs,2500,.7,'lp')*env(n,.003,.02))
def main(d):
    j=json.load(open(d+'/bank.json'));j['items']=[i for i in j['items'] if i.get('p')!='dub'];off=0;buf=[];items=[];cnt={}
    for fam,nm,x in S:
        x=np.asarray(x,float);x=x-np.mean(x);pk=np.abs(x).max()+1e-9;x=x/pk*.85;x=x*env(len(x),.002,.01);q=(x*32767).astype('<i2')
        cnt[fam]=cnt.get(fam,0)+1;ms=int(len(q)/SR*1000);sp=np.abs(np.fft.rfft(x[:int(.3*SR)]*np.hanning(min(len(x),int(.3*SR)))))+1e-9;fq=np.fft.rfftfreq(min(len(x),int(.3*SR)),1/SR)[:len(sp)]
        ce=float((sp*fq[:len(sp)]).sum()/sp.sum())
        items.append({'id':'dub-%03d'%(len(items)+1),'fam':fam,'d':'court' if ms<170 else 'moyen' if ms<450 else 'long','t':'sombre' if ce<1200 else 'medium' if ce<3500 else 'clair','p':'dub','off':off,'n':len(q),'ms':ms,'nm':nm,'g':'Dubstep'})
        buf.append(q.tobytes());off+=len(q)*2
    open(d+'/pack-dub.bin','wb').write(b''.join(buf));j['packs']['dub']={'file':'pack-dub.bin','bytes':off,'count':len(items)};j['items']+=items
    json.dump(j,open(d+'/bank.json','w'),ensure_ascii=False,separators=(',',':'))
    print('pack-dub.bin',off,'octets',len(items),'sons',cnt,'durée %.1f s'%(off/2/SR))
if __name__=='__main__':main(sys.argv[1])
