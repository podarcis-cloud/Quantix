# Lot LÉGÈRETÉ (R410) : cadre de rendu de Track en mode « render=1 » (sans animations, sans écrire le brouillon de Pattern),
# libéré après 20 s d'inactivité puis recréé à la demande ; recherche de la bibliothèque sans relire toute la base à chaque frappe.
import time
from playwright.sync_api import sync_playwright
U = 'http://localhost:8765/studio/'
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m, flush=True)
SEED = """(async(ids)=>{const db=await new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>r(o.result)});
 const tx=db.transaction('items','readwrite');ids.forEach((id,i)=>{const q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4-i*.1],[.6,.6],[.9,.5]]}];
 tx.objectStore('items').put({id:id,name:'Léger '+(i+1),proj:'Sans projet',col:'#72D6D2',ver:7+i,cr:7+i,qx:q});});await new Promise(r=>tx.oncomplete=r);db.close()})"""
FR = "()=>[...document.querySelectorAll('iframe')].map(f=>f.getAttribute('src')||'').filter(s=>s.indexOf('quantone')>=0)"
with sync_playwright() as pw:
    b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 390, 'height': 844}, has_touch=True); er = []
    pg.on('pageerror', lambda e: er.append(str(e)))
    pg.goto(U + 'quantone.html'); pg.wait_for_timeout(1500)
    chk(pg.evaluate("window.QRENDER") is False, 'Pattern normal : mode rendu inactif')
    pg.evaluate(SEED, ['lg1', 'lg2'])
    pg.goto(U + 'morceau.html'); pg.wait_for_function("()=>window.MORCEAU&&document.querySelector('#patSel option[value=\"lib:lg2\"]')", timeout=30000)
    pg.evaluate("localStorage.setItem('quantone.auto','SENTINELLE')")
    def pose(id):
        pg.select_option('#patSel','lib:'+id)
        pg.wait_for_function("(id)=>MORCEAU.P().blocks.some(b=>b.lib===id&&b.ch&&b.ch[0].length>1000)", arg=id, timeout=180000)
    t0 = time.time(); pose('lg1'); dt = time.time() - t0
    f = pg.evaluate(FR); chk(len(f) == 1 and 'render=1' in f[0], 'bloc calculé depuis le motif (%.1f s) dans un cadre « render=1 » %s' % (dt, f))
    fr = [x for x in pg.frames if 'render=1' in x.url][0]
    chk(fr.evaluate("window.QRENDER===true&&window.QNOSAVE===true"), 'cadre de rendu : QRENDER et QNOSAVE actifs')
    n = fr.evaluate("new Promise(r=>{let n=0;const t0=performance.now();(function f(){n++;if(performance.now()-t0<2500)requestAnimationFrame(f);else r(n)})()})")
    chk(n <= 5, 'cadre de rendu : animations à ≈ 1 image/s (%d images en 2,5 s)' % n)
    chk(fr.evaluate("!document.getElementById('qTrackFrame')"), 'cadre de rendu : pas de Track imbriqué')
    au = pg.evaluate("new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').get('lg1');g.onsuccess=()=>{r(!!(g.result&&g.result.au));o.result.close()}}})")
    chk(au, 'le son calculé est gardé dans l’élément (une seule fois)')
    pg.wait_for_timeout(23000)
    chk(pg.evaluate("localStorage.getItem('quantone.auto')") == 'SENTINELLE', 'le brouillon de Pattern n’est pas écrasé par le cadre de rendu')
    chk(len(pg.evaluate(FR)) == 0, 'après 20 s sans rendu, le cadre est libéré')
    t0 = time.time(); pose('lg2'); dt = time.time() - t0
    chk(len(pg.evaluate(FR)) == 1, 'nouveau rendu : cadre recréé, bloc prêt (%.1f s)' % dt)
    # bibliothèque : la recherche relit la liste en mémoire
    pg.select_option('#patSel', 'gear'); pg.wait_for_selector('#qLibPanel #qLibQ', timeout=5000); pg.wait_for_timeout(400)
    pg.evaluate("(()=>{window.__ga=0;const g=IDBObjectStore.prototype.getAll;IDBObjectStore.prototype.getAll=function(...a){window.__ga++;return g.apply(this,a)}})()")
    pg.locator('#qLibQ').type('Lég', delay=120); pg.wait_for_timeout(500)
    rows = pg.locator('#qLibPanel .lr').count()
    chk(pg.evaluate("window.__ga") == 0 and rows >= 1, 'recherche « Lég » : %d ligne(s), %d relecture(s) de la base' % (rows, pg.evaluate("window.__ga")))
    chk(pg.evaluate("document.activeElement&&document.activeElement.id") == 'qLibQ', 'le champ de recherche garde le focus')
    chk(not er, 'aucune erreur de page %s' % er[:2])
    b.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
