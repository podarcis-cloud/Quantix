# R405 — « Mes tracks » dans la bibliothèque unique (studio/qlib.js) : onglets Patterns · Tracks · Sons du jeu, identiques dans Pattern et Track.
# Enregistrer une track → visible dans l'onglet Tracks des DEUX pages → Ouvrir la restaure à l'identique → Renommer / Dupliquer / Exporter .qxp / Supprimer ;
# migration unique et idempotente de l'ancienne base « qxtracks » ; en-tête du menu Fichier fidèle (nom, projet, Enregistré / Modifié) ; sélecteur sans filtre.
import sys, os, json, tempfile
from playwright.sync_api import sync_playwright
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
U = 'http://localhost:%d/studio/' % PORT
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m, flush=True)
TMP = tempfile.mkdtemp(prefix='qtrk-')
ALL = "new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.map(x=>({id:x.id,kind:x.kind||'p',name:x.name,proj:x.proj||null,ver:x.ver,au:!!x.au,nb:x.p?(x.p.blocks||[]).length:0,sig:x.p?JSON.stringify({t:x.p.tracks,c:x.p.clips,m:x.p.master,l:x.p.loop,b:x.p.bpm}):null})))}})"
OLD = "new Promise(r=>{const o=indexedDB.open('qxtracks',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.map(x=>x.id+'|'+x.name))}})"
CUR = "JSON.stringify((()=>{const P=MORCEAU.P();return {t:P.tracks,c:P.clips,m:P.master,l:P.loop,b:P.bpm}})())"
HDR = "(()=>{QFILE.open();const r=[document.getElementById('qfName').textContent,document.getElementById('qfState').className,document.getElementById('qfState').textContent];QFILE.close();return r})()"
LAY = """(()=>{const p=document.getElementById('qLibPanel'),r=p.getBoundingClientRect(),bad=[];p.querySelectorAll('button,select,input').forEach(e=>{const b=e.getBoundingClientRect();if(b.width&&(b.height<40||b.width<40))bad.push((e.dataset.a||e.dataset.tab||e.id||e.tagName)+':'+Math.round(b.width)+'x'+Math.round(b.height));if(b.right>390.5||b.left<-.5)bad.push('dépasse:'+(e.dataset.a||e.id));});
 return {bad,sw:document.documentElement.scrollWidth,pw:p.scrollWidth,cw:p.clientWidth,bottom:r.bottom,ff:getComputedStyle(p).fontFamily,tabs:[...p.querySelectorAll('[data-tab]')].map(e=>e.textContent)}})()"""
def rows(pg): return pg.evaluate("[...document.querySelectorAll('#qLibPanel .lr')].map(e=>e.dataset.id+'|'+(e.querySelector('.ln b')||{}).textContent)")
def tab(pg, t): pg.click('#qLibPanel [data-tab="%s"]' % t); pg.wait_for_timeout(300)
def dl(pg, sel):
    with pg.expect_download(timeout=60000) as d: pg.click(sel)
    p = os.path.join(TMP, d.value.suggested_filename); d.value.save_as(p); return d.value.suggested_filename, p
with sync_playwright() as pw:
    br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); er = []
    ctx = br.new_context(viewport={'width': 390, 'height': 844}, has_touch=True, accept_downloads=True)
    pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('T:' + str(e)))
    pt.goto(U + 'morceau.html'); pt.evaluate("localStorage.setItem('qx.lang','fr');localStorage.setItem('qx.proj','Album')"); pt.reload(); pt.wait_for_timeout(1500)
    chk(not pt.evaluate("document.getElementById('fPr').hasAttribute('accept')"), 'Track : sélecteur de fichiers sans filtre (iPhone)')
    bad = os.path.join(TMP, 'note.txt'); open(bad, 'w').write('bonjour')
    pt.set_input_files('#fPr', bad); pt.wait_for_timeout(1200); m = pt.evaluate("document.getElementById('msg').textContent")
    chk('non reconnu' in m and 'note.txt' in m, 'fichier inconnu : message clair (%s)' % m[:70])
    # une track réelle : un bloc audio (données brutes) posé deux fois, tempo et master modifiés
    pt.evaluate("""(async()=>{const sr=44100,n=sr,b=new ArrayBuffer(44+n*2),v=new DataView(b),w=(p,s)=>{for(let k=0;k<s.length;k++)v.setUint8(p+k,s.charCodeAt(k))};
      w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVEfmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);
      for(let i=0;i<n;i++)v.setInt16(44+i*2,Math.round(Math.sin(i/15)*9000*(1-i/n)),true);
      const f=new File([b],'bip.wav',{type:'audio/wav'});MORCEAU.open([f]);})()""")
    pt.wait_for_function("MORCEAU.P().blocks.length===1", timeout=20000)
    pt.evaluate("(()=>{const b=MORCEAU.P().blocks[0];MORCEAU.place(b.id,0,0,1);MORCEAU.place(b.id,1,2,1);const P=MORCEAU.P();P.bpm=96;P.master.vol=.8;})()")
    pt.click('#bFile'); pt.wait_for_timeout(300); pt.click('#qfSave'); pt.wait_for_timeout(200); pt.fill('#qfAskIn', 'Ma track A'); pt.click('#qfAskY'); pt.wait_for_timeout(700)
    A = [x for x in pt.evaluate(ALL) if x['kind'] == 'track']
    chk(len(A) == 1 and A[0]['name'] == 'Ma track A' and A[0]['proj'] == 'Album' and A[0]['nb'] == 1, 'Enregistrer cette track → bibliothèque unique (kind track, projet Album) %s' % [(x['name'], x['proj']) for x in A])
    TID = A[0]['id']; SIG = A[0]['sig']
    h = pt.evaluate(HDR); chk('Ma track A' in h[0] and 'Album' in h[0] and h[1] == 'ok', 'en-tête Track : « %s » · %s' % (h[0], h[2]))
    pt.evaluate("MORCEAU.P().bpm=97"); h = pt.evaluate(HDR); chk(h[1] == 'dirty', 'après modification : %s' % h[2])
    pt.click('#bFile'); pt.wait_for_timeout(300); pt.click('#qfSave'); pt.wait_for_timeout(700)
    A2 = [x for x in pt.evaluate(ALL) if x['kind'] == 'track']; h = pt.evaluate(HDR)
    chk(len(A2) == 1 and A2[0]['id'] == TID and h[1] == 'ok', 'Enregistrer : met à jour la même track (pas de doublon), état Enregistré')
    SIG = A2[0]['sig']
    # onglet Tracks dans Track
    pt.click('#bFile'); pt.wait_for_timeout(300); pt.click('#qfLib'); pt.wait_for_timeout(500)
    chk(pt.evaluate("QLIB.isOpen()&&QLIB.state().tab") == 't' and any('Ma track A' in r for r in rows(pt)), 'Track ▸ Bibliothèque… : onglet Tracks, « Ma track A » listée')
    chk(pt.evaluate("document.querySelector('#qLibPanel .lr.cur')?.dataset.id") == TID, 'la track ouverte est mise en évidence')
    L = pt.evaluate(LAY); chk(not L['bad'] and L['sw'] <= 390 and L['pw'] <= L['cw'] + 1 and 'Space Grotesk' in L['ff'], 'Track : panneau 390 px sans débordement, cibles ≥ 40 px %s' % L['bad'][:4])
    for t in 'pg':
        tab(pt, t); L = pt.evaluate(LAY); chk(not L['bad'] and L['sw'] <= 390, 'Track, onglet %s : cibles ≥ 40 px, pas de débordement %s' % (t, L['bad'][:4]))
    chk(L['tabs'][0].startswith('Patterns') and L['tabs'][1].startswith('Tracks') and L['tabs'][2] == 'Sons du jeu', 'onglets FR : %s' % L['tabs'])
    pt.keyboard.press('Escape')
    # nouvelle track, puis Pattern
    pt.click('#bFile'); pt.wait_for_timeout(300); pt.click('#bNew'); pt.click('#bNew'); pt.wait_for_timeout(500)
    chk(pt.evaluate("MORCEAU.P().clips.length") == 0, 'Nouvelle track : track vide')
    pg = pt; pg.goto(U + 'quantone.html'); pg.wait_for_timeout(1500)
    pg.click('#qLibMgr'); pg.wait_for_timeout(400)
    L = pg.evaluate(LAY); chk(L['tabs'] and L['tabs'][1] == 'Tracks · 1', 'Pattern : même bibliothèque, onglet « %s »' % (L['tabs'][1] if L['tabs'] else None))
    tab(pg, 't'); R = rows(pg); chk(any(r.startswith(TID + '|Ma track A') for r in R), 'Pattern ▸ onglet Tracks : « Ma track A » listée')
    L = pg.evaluate(LAY); chk(not L['bad'] and L['sw'] <= 390, 'Pattern, onglet Tracks : cibles ≥ 40 px, pas de débordement %s' % L['bad'][:4])
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="topen"]' % TID); pg.wait_for_timeout(200)
    t1 = pg.evaluate("document.querySelector('#qLibPanel .lr[data-id=\"%s\"] [data-a=\"topen\"]').textContent" % TID)
    chk('Track' in t1 and pg.url.endswith('quantone.html'), 'Pattern ▸ Ouvrir une track : propose d’aller dans Track (« %s »)' % t1)
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="topen"]' % TID)
    pg.wait_for_url('**/morceau.html', timeout=15000); pg.wait_for_function("MORCEAU.trk().id===%s" % json.dumps(TID), timeout=30000); pg.wait_for_timeout(800)
    chk(pg.evaluate(CUR) == SIG and pg.evaluate("MORCEAU.P().blocks.length") == 1 and pg.evaluate("MORCEAU.P().blocks[0].len") > .9, '→ Track l’ouvre et la restaure à l’identique (pistes, blocs, master, boucle, tempo)')
    h = pg.evaluate(HDR); chk('Ma track A' in h[0] and h[1] == 'ok', 'en-tête après ouverture : « %s » · %s' % (h[0], h[2]))
    # Renommer / Dupliquer / Exporter / Supprimer (dans Track)
    pg.click('#bFile'); pg.wait_for_timeout(300); pg.click('#qfLib'); pg.wait_for_timeout(500)
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="ren"]' % TID); pg.wait_for_timeout(200)
    pg.fill('#qLibPanel input[data-a="nm"]', 'Ma track Z'); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
    chk(any(r == TID + '|Ma track Z' for r in rows(pg)) and pg.evaluate("MORCEAU.trk().name") == 'Ma track Z', 'Renommer : liste et track ouverte mises à jour')
    h = pg.evaluate(HDR); chk('Ma track Z' in h[0] and h[1] == 'ok', 'en-tête suit le renommage : « %s »' % h[0])
    if not pg.evaluate("QLIB.isOpen()"): pg.click('#bFile'); pg.wait_for_timeout(300); pg.click('#qfLib'); pg.wait_for_timeout(500)
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="dup"]' % TID); pg.wait_for_timeout(600)
    T = [x for x in pg.evaluate(ALL) if x['kind'] == 'track']; D = [x for x in T if x['id'] != TID]
    chk(len(T) == 2 and D and D[0]['name'] == 'Ma track Z bis' and D[0]['sig'] == SIG and D[0]['nb'] == 1, 'Dupliquer : copie complète « %s »' % (D[0]['name'] if D else None))
    nm, p = dl(pg, '#qLibPanel .lr[data-id="%s"] [data-a="qxp"]' % TID); J = json.load(open(p))
    blk = (J.get('blocks') or [{}])[0]
    chk(nm == 'Ma-track-Z.qxp' and J.get('q') == 'quantone-morceau' and J.get('v') == 2 and J.get('name') == 'Ma track Z' and len(J.get('clips', [])) == 2 and isinstance(blk.get('data'), str) and len(blk['data']) > 50000, 'Exporter .qxp : %s (v2, 2 clips, audio intégré)' % nm)
    pt2 = ctx.new_page(); pt2.on('pageerror', lambda e: er.append('T2:' + str(e))); pt2.goto(U + 'morceau.html'); pt2.wait_for_timeout(1200)
    pt2.set_input_files('#fPr', p); pt2.wait_for_function("MORCEAU.P().clips.length===2", timeout=30000)
    chk(pt2.evaluate(CUR) == SIG, 'le .qxp exporté se rouvre à l’identique'); pt2.close()
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="del"]' % D[0]['id']); pg.wait_for_timeout(150)
    chk(len(rows(pg)) == 2, 'Supprimer : un toucher ne supprime pas')
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="del"]' % D[0]['id']); pg.wait_for_timeout(500)
    chk(len([x for x in pg.evaluate(ALL) if x['kind'] == 'track']) == 1, 'second toucher : copie supprimée')
    pg.click('#qLibPanel .lr[data-id="%s"] [data-a="del"]' % TID); pg.click('#qLibPanel .lr[data-id="%s"] [data-a="del"]' % TID); pg.wait_for_timeout(500)
    h = pg.evaluate(HDR); chk(not pg.evaluate("MORCEAU.trk().id") and h[1] == 'new' and pg.evaluate("MORCEAU.P().clips.length") == 2, 'supprimer la track ouverte : son contenu reste à l’écran, en-tête « %s »' % h[2])
    # Pattern : en-tête et onglet Patterns
    pg.goto(U + 'quantone.html'); pg.wait_for_timeout(1500)
    pg.evaluate("""(async()=>{const q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.6,.6],[.9,.5]]}];const n=4410,l=new Int16Array(n);for(let i=0;i<n;i++)l[i]=Math.round(Math.sin(i/9)*5000);
      const db=await new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>r(o.result)});const tx=db.transaction('items','readwrite');tx.objectStore('items').put({id:'pp1',name:'Riff',proj:'Album',col:'#72D6D2',ver:5,cr:5,qx:q,au:{sr:44100,len:.1,l:l,r:l,src:'rendu'}});await new Promise(r=>tx.oncomplete=r)})()""")
    pg.click('#qLibMgr'); pg.wait_for_timeout(400)
    chk(pg.evaluate("QLIB.state().tab") == 'p' and any(r == 'pp1|Riff' for r in rows(pg)), 'Pattern ▸ onglet Patterns (projet en cours Album) : « Riff »')
    L = pg.evaluate(LAY); chk(not L['bad'] and L['sw'] <= 390, 'Pattern, onglet Patterns : cibles ≥ 40 px, pas de débordement %s' % L['bad'][:4])
    pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="qpt"]'); pg.wait_for_timeout(200)
    nm, p = dl(pg, '#qLibPanel .lr[data-id="pp1"] [data-a="qpt0"]'); J = json.load(open(p))
    chk(nm == 'Riff.qpt' and J.get('q') == 'quantone-pattern' and J.get('name') == 'Riff' and not J.get('au'), 'Exporter .qpt sans le son : %s' % nm)
    pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="qpt"]'); pg.wait_for_timeout(200)
    nm, p = dl(pg, '#qLibPanel .lr[data-id="pp1"] [data-a="qpt1"]'); J = json.load(open(p))
    chk(nm == 'Riff.qpt' and (J.get('au') or {}).get('codec') == 'pcm16', 'Exporter .qpt avec le son : son joint')
    pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="open"]'); pg.wait_for_timeout(500)
    h = pg.evaluate(HDR); chk('Riff' in h[0] and 'Album' in h[0] and h[1] == 'ok', 'Pattern : en-tête « %s » · %s' % (h[0], h[2]))
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.tempo=133;QXIO.open(q)})()"); h = pg.evaluate(HDR); chk(h[1] == 'dirty', 'Pattern modifié : %s' % h[2])
    pg.click('#qLibMgr'); pg.wait_for_timeout(400); pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="ren"]'); pg.wait_for_timeout(150)
    pg.fill('#qLibPanel input[data-a="nm"]', 'Riff 2'); pg.fill('#qLibPanel input[data-a="pjn"]', 'Album B'); pg.keyboard.press('Enter'); pg.wait_for_timeout(400)
    h = pg.evaluate(HDR); chk('Riff 2' in h[0] and 'Album B' in h[0], 'renommer / changer de projet : l’en-tête suit (« %s »)' % h[0])
    pg.click('#qLibMgr'); pg.wait_for_timeout(400); pg.click('#qLibPanel [data-p="*"]'); pg.wait_for_timeout(200)
    pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="del"]'); pg.click('#qLibPanel .lr[data-id="pp1"] [data-a="del"]'); pg.wait_for_timeout(400)
    h = pg.evaluate(HDR); chk(h[1] == 'new' and not pg.evaluate("QLIBAPI.id()"), 'supprimer le pattern ouvert : « %s »' % h[2])
    # Sons du jeu depuis Pattern
    pg.click('#qLibMgr'); pg.wait_for_timeout(400); tab(pg, 'g'); pg.select_option('#qlGw', '2'); pg.select_option('#qlGl', '3')
    pg.click('#qLibPanel [data-a="game"]'); pg.wait_for_url('**/morceau.html', timeout=15000)
    pg.wait_for_function("MORCEAU.P().blocks.some(b=>b.kind==='audio'&&/2.*3/.test(b.name))", timeout=30000)
    chk(True, 'Pattern ▸ Sons du jeu ▸ Ajouter dans Track : bloc « Monde 2 · niv. 3 » ajouté dans Track')
    # EN
    pg.evaluate("localStorage.setItem('qx.lang','en')"); pg.reload(); pg.wait_for_timeout(1300); pg.click('#bFile'); pg.wait_for_timeout(300); pg.click('#qfLib'); pg.wait_for_timeout(400)
    L = pg.evaluate(LAY); txt = pg.evaluate("document.getElementById('qLibPanel').textContent")
    chk(L['tabs'][2] == 'Game sounds' and 'Library' in txt and 'Bibliothèque' not in txt, 'EN : bibliothèque traduite (%s)' % L['tabs'])
    tab(pg, 'p'); txt = pg.evaluate("document.getElementById('qLibPanel').textContent"); chk('All projects' in txt and 'Tous' not in txt, 'EN : onglet Patterns traduit')
    ctx.close()

    # ── migration de l'ancienne base « qxtracks » ──
    ctx = br.new_context(viewport={'width': 390, 'height': 844}); pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append('M:' + str(e)))
    pg.goto(U + 'quantone.html'); pg.wait_for_timeout(400)
    pg.evaluate("""(async()=>{const mk=(id,nm,ab)=>({id,name:nm,ver:Date.now(),cr:1,p:{q:'quantone-morceau',v:1,bpm:91,tracks:[{id:'k1',name:'Piste 1',vol:1,pan:0,mute:false,solo:false,fx:{}}],clips:ab?[{id:'c1',track:'k1',src:'b1',start:0,len:.5,off:0,rate:1,gain:1,loop:false}]:[],master:{vol:1,lo:0,hi:0,comp:.4},loop:{on:true,a:0,b:null},
       blocks:ab?[{id:'b1',kind:'audio',name:'bip',len:.5,loop:false,lib:null,libVer:0,col:null,mime:'audio/wav',data:ab}]:[]}});
      const n=22050,b=new ArrayBuffer(44+n*2),v=new DataView(b),w=(p,s)=>{for(let k=0;k<s.length;k++)v.setUint8(p+k,s.charCodeAt(k))};w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVEfmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,44100,true);v.setUint32(28,88200,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);for(let i=0;i<n;i++)v.setInt16(44+i*2,Math.round(Math.sin(i/7)*8000),true);
      const db=await new Promise(r=>{const o=indexedDB.open('qxtracks',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>r(o.result)});
      const tx=db.transaction('items','readwrite');tx.objectStore('items').put(mk('told1','Vieille A',b));tx.objectStore('items').put(mk('told2','Vieille B',null));await new Promise(r=>tx.oncomplete=r);db.close();
      localStorage.removeItem('qx.trkMigr');localStorage.setItem('qx.trk',JSON.stringify({id:'told1',name:'Vieille A',sig:null,at:1}));})()""")
    pg.reload(); pg.wait_for_timeout(1800)
    M1 = sorted((x['id'], x['name']) for x in pg.evaluate(ALL) if x['kind'] == 'track')
    chk(M1 == [('told1', 'Vieille A'), ('told2', 'Vieille B')] and pg.evaluate("localStorage.getItem('qx.trkMigr')") == '1', 'migration : les 2 tracks de « qxtracks » entrent dans la bibliothèque (mêmes ids) %s' % M1)
    chk(len(pg.evaluate(OLD)) == 2, 'ancienne base « qxtracks » conservée (rien de perdu)')
    pg.evaluate("new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const tx=o.result.transaction('items','readwrite'),s=tx.objectStore('items'),g=s.get('told2');g.onsuccess=()=>{const i=g.result;i.name='Renommée';s.put(i)};tx.oncomplete=()=>r(1)}})")
    pg.evaluate("localStorage.removeItem('qx.trkMigr')"); pg.reload(); pg.wait_for_timeout(1500)
    pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('M:' + str(e))); pt.evaluate("0"); pt.goto(U + 'morceau.html'); pt.wait_for_timeout(1500)
    M2 = sorted((x['id'], x['name']) for x in pt.evaluate(ALL) if x['kind'] == 'track')
    chk(M2 == [('told1', 'Vieille A'), ('told2', 'Renommée')], 'migration idempotente (relancée par Pattern puis Track) : pas de doublon, renommage gardé %s' % M2)
    pt.evaluate("QLIB.open('t')"); pt.wait_for_timeout(400)
    chk(len(rows(pt)) == 2, 'Track ▸ onglet Tracks : les tracks migrées sont listées')
    pt.click('#qLibPanel .lr[data-id="told1"] [data-a="topen"]'); pt.wait_for_function("MORCEAU.trk().id==='told1'&&MORCEAU.P().blocks.length===1", timeout=20000); pt.wait_for_timeout(400)
    chk(pt.evaluate("MORCEAU.P().bpm") == 91 and pt.evaluate("MORCEAU.P().master.comp") == .4 and pt.evaluate("MORCEAU.P().blocks[0].len") > .4, 'une track migrée s’ouvre (audio, tempo, compresseur d’origine)')
    h = pt.evaluate(HDR); chk('Vieille A' in h[0] and h[1] == 'ok', 'en-tête : « %s » · %s' % (h[0], h[2]))
    ctx.close()
    chk(not er, 'aucune erreur JS ' + str(er[:3]))
    br.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
sys.exit(0 if all(res) else 1)
