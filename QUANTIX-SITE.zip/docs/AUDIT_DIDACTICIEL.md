# Audit du didacticiel (R185, 12 octobre 2026)

*Rendu visible dans le banc des rendus (section « Audit · didacticiel » et banc « Visière adaptative »). Rien n'est dans le jeu.*

## Méthode
Partie neuve simulée avec le code réel de `tuto.js` (catalogue `CAT`, `elemsOf`, `focusOf`, `avgY`, règle de position de
`showCard`), jouée dans l'ordre des 132 niveaux ; capture de chaque niveau concerné sans fiche (Chromium, 390 × 844).
Mesures par fiche (gabarit 300 px, position de la règle actuelle) : part de l'élément expliqué sous la fiche ; charge du fond
(part de pixels à fort contraste local) ; voile noir minimal pour un contraste 4,5 : 1 du texte courant #B4C2D0 sur le
95e centile de luminance du fond. Scripts : scratchpad `audit/sim.js`, `ana.py`, `ana2.py`.

## Constats
1. 17 niveaux montrent une fiche ; seul le niveau 1 a des consignes guidées.
2. Niveau 2 « Le pont » : cinq fiches d'affilée (4 outils + zone interdite).
3. La fiche cache l'élément expliqué : La lentille 57 %, Le portail 50 %, Le pont et Le souffle 31 %, La mesure 26 %,
   Tomber vers le haut 24 %. La règle actuelle ne regarde que le centre de l'élément, pas sa taille ni la hauteur de la fiche.
4. Fonds sombres (luminance 0,17–0,27) mais inégalement chargés (4–17 %) ; voile requis de 0 à 0,79 : un voile fixe ne convient pas.
5. La cellule (12), finale du monde 1, introduit un élément nouveau (paroi tunnel).

## Quand une fiche ne doit pas apparaître
- plus de deux fiches sur un niveau (regrouper les outils en une seule fiche) ;
- par-dessus la barre d'outils, « Lâcher » ou la consigne du bas ;
- sur l'élément qu'elle explique ;
- avant que le niveau soit lisible (~0,7 s), pendant la course, la relecture, « Voir la solution », le mode zen ;
- une seconde fois pour le même élément (ensuite seulement via « Aide du niveau ») ;
- sur un fond qui rend le texte illisible.

## Tableau
| Niv. | Niveau | Monde | Fiche | Position actuelle | Élément caché | Fond chargé | Voile requis | Recommandation |
|---|---|---|---|---|---|---|---|---|
| 1 | Le premier trait | Atelier | Les bases | haut | — | 10 % | 0.59 | consignes guidées (inchangé), voile adapté |
| 2 | Le pont | Atelier | Trait libre, Ligne droite, Gomme, Déplacer (4 fiches) | haut | — | 9 % | 0.45 | une seule fiche « Tes outils », projecteur sur la barre d’outils ⚠ |
| 2 | Le pont | Atelier | Zone interdite | bas | 31 % | 12 % | 0.52 | pleine, bas, contour tracé par-dessus (31 % recouvert) ⚠ |
| 3 | Le colimaçon | Atelier | Pointes | bas | 0 % | 17 % | 0.79 | pleine, bas ⚠ |
| 12 | La cellule | Atelier | Paroi tunnel | haut | 0 % | 8 % | 0.37 | pleine, haut |
| 13 | Le trampoline | Fonderie | Rebond | haut | 0 % | 4 % | 0.00 | pleine, haut |
| 25 | Le tapis | Chaîne | Tapis | haut | 0 % | 7 % | 0.00 | pleine, haut |
| 37 | Le lac | Glacier | Glace | bas | 14 % | 8 % | 0.58 | compacte, haut |
| 49 | Le souffle | Soufflerie | Vent | haut | 31 % | 11 % | 0.67 | pleine, haut, contour tracé par-dessus (31 % recouvert) ⚠ |
| 61 | Le piston | Mécanique | Paroi mobile | haut | 0 % | 8 % | 0.49 | pleine, haut |
| 73 | Tomber vers le haut | Gravité | Gravité | haut | 24 % | 8 % | 0.67 | compacte, haut ⚠ |
| 85 | La lentille | Magnétisme | Aimant | bas | 57 % | 11 % | 0.61 | pleine, haut ⚠ |
| 97 | Le portail | Faille | Portail | haut | 50 % | 7 % | 0.30 | compacte, haut ⚠ |
| 109 | Corde tendue | Filaments | Corde | haut | — | 7 % | 0.37 | fiche en haut, projecteur sur la puce Corde |
| 112 | La balle molle | Filaments | Balle molle | bas | 0 % | 12 % | 0.72 | pleine, bas ⚠ |
| 121 | Le lien | Quantique | Intrication | haut | 9 % | 8 % | 0.25 | pleine, haut |
| 123 | La mesure | Quantique | Superposition | bas | 26 % | 13 % | 0.56 | compacte, haut ⚠ |
| 123 | La mesure | Quantique | Détecteur | haut | 0 % | 8 % | 0.25 | pleine, haut |
| 125 | Le temps ralenti | Quantique | Temps ralenti | haut | 0 % | 7 % | 0.31 | pleine, haut |

## Solution proposée : Visière adaptative
La Visière validée (pas de surface, vignette animée 76 % × 116 px, ouverture depuis une ligne, fermeture inverse), plus :
1. **Projecteur** : l'écran s'assombrit (0,62) sauf autour de l'élément expliqué (trous doux d'après `focusOf`) ; pour les outils, la barre d'outils.
2. **Contour tracé** : le contour de l'élément se dessine (0,9 s) puis reste en pointillés de sa couleur, avec sa dimension
   réelle en unités ; atténué là où la fiche passe dessus (masque).
3. **Position et format calculés** : fiche pleine en haut (sous le titre du niveau, y = 64) et en bas (au-dessus de la barre),
   puis fiche compacte (vignette 132 × 84 à côté du titre) si la pleine cache > 10 % ; on garde la place qui cache le moins.
4. **Voile ajusté** : lecture des pixels du niveau sous la fiche (`getImageData`), α = clamp(requis + 0,08 ; 0,55 ; 0,88).
5. **Outils regroupés** : une fiche « Tes outils » (4 lignes) au lieu de quatre fiches, puis la fiche de l'élément (2 au plus).

Résultats sur les 4 niveaux témoins (calcul en direct dans le banc) : Le pont outils haut 0 % ; Le pont zone interdite
compacte bas 26 % (règle actuelle 36 %) ; Le colimaçon pleine bas 0 %, voile 0,84 ; La lentille compacte haut 0 %
(règle actuelle 69 %) ; Le souffle compacte haut 29 % (règle actuelle 46 %, colonne trop haute pour être libre : le contour
tracé la montre à travers la fiche).

## Pour l'intégrer au jeu (non fait)
`tuto.js` : regrouper TOOLS en une fiche ; remplacer la règle `avgY` par le calcul de recouvrement (comme `placeCoach`) ;
format compact ; projecteur et contour dessinés sur le calque du didacticiel ; voile d'après les pixels de `#cv`. CSS : gabarit
Visière. i18n : textes de la fiche « Tes outils » (FR/EN). Décider avec Simon du sort de la paroi tunnel au niveau 12.
