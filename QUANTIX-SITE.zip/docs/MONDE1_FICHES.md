# QUANTIX — Monde 1 · Atelier — les 12 fiches (R118)

> **Statut R209 : référence (fiches du monde 1).** Voir `INDEX_DOCUMENTS.md`.


*Vérité du monde : **le trait de lumière est la seule construction** — il devient tour à tour mur, pont, plafond, rampe ;
la gravité fait le reste. Machine type (cahier §3.3, adaptée à la décision R81 « machine physique ») : **une piste de
lumière qui descend en spirale / en vague**, faite de poutres et de courbes du niveau, jamais d'un rail visible.
Gabarit §6 : machines aux positions 3, 6, 8, 10, 12 ; finale en 12 (rappel renversé du niveau 1).
Jouabilité (R117) : positions 1–6 main levée, 7–12 éditeur admis. Seuils de coût minimal : 40 u (1–3), 80 u (4–8), 120 u (9–12).*

| Pos. | Temps | Forme | Titre | Type | Hypothèse qui tombe | Énigme (idée, geste) | Machine |
|---|---|---|---|---|---|---|---|
| 1 | Ki | Simple | Le premier trait | R‑01 Découvrir | H9 « le décor est inerte » | les poutres et le crochet (dessin de Simon) renvoient la particule vers les pointes : un **mur** à la sortie du crochet la rend au bassin | — |
| 2 | Ki | Simple | Le pont | R‑02 Ponter | « un vide se saute » | tout le ciel est interdit : **prolonger** la rampe jusqu'au bassin | — |
| 3 | Ki | **Relais** (révélation) | Le colimaçon | R‑05 Rattraper | H8 « il faut viser la zone » | la zone est sous un toit, inaccessible : il faut **viser le relais** (entonnoir) ; un déflecteur cueille la chute et la verse dedans | spirale descendante de poutres → zone |
| 4 | Shō | Simple | Le relais | R‑07 Relayer | H10 « un trait = un geste » | deux appuis : le premier lance, le second rattrape | — |
| 5 | Shō | Simple | Le demi‑tour (déplacé du 3) | R‑04 Inverser | H3 « le plus court est le mieux » | laisser partir la particule puis la **renvoyer** sous la rampe | — |
| 6 | Shō | **Relais** (récompense) | Les collines | R‑08 Protéger | H4 « les pointes sont à fuir » | le seul passage vers l'entonnoir est un lit de pointes : **le couvrir** — le trait se pose sur le danger et devient sol | vague : descente concave, vallée, décollage, dosseret (prototype p1) |
| 7 | Ten | Simple | Économie | R‑13 Économiser | H6 « plus d'énergie, plus de choix » | la grande rampe évidente coûte trop : un seul trait, au seul endroit où la pente fixe fait le reste | — |
| 8 | Ten | **Machine‑énigme** | La portée | R‑21 Lire la machine | H17 « la machine me sauve » | la machine éjecte la particule au‑dessus du vide : **préparer** avant de lâcher la rampe qui la recevra | vague courte → tremplin |
| 9 | Ten | Simple | Le détour | R‑11 Boucler | H15 « un élément = une fonction » | le même trait sert deux fois : aller, puis retour après le rebond sur le mur fixe | — |
| 10 | Ketsu | **Deux actes** | Le plafond | R‑19 Combiner | H1 « un trait est un sol » | acte 1 : une tôle **sous** le plafond de pointes renvoie la particule dans l'entonnoir ; la machine la dépose dans un second espace ; acte 2 : un pont vers la zone | spirale courte entre les deux actes |
| 11 | Ketsu | Simple | La moitié | R‑10 Détourner | H12 « monter exige une aide visible » | la poutre fixe n'est que la moitié d'une vallée : le trait est l'autre moitié, la chute donne l'élan de la remontée | — |
| 12 | Ketsu | **Finale** | L'établi | R‑20 Synthèse | rappel renversé du 1 | géométrie de Simon (Q‑01‑12) : trois gestes enchaînés (dévier, franchir, renvoyer) puis la grande spirale de l'Atelier jusqu'à la zone | grande spirale descendante |

## Règles de conception retenues pour ce monde (mesurées en R117)

- **Pas de jonction précise trait / pièce fixe** : un trait qui doit prolonger exactement un bout fixe échoue au doigt
  (diag du 11 : 20 échecs sur 30 au raccord). Préférer des gestes dont le résultat est insensible à ±10 u : murs, plafonds,
  déflecteurs larges, pentes qui finissent dans un entonnoir ou un bassin fermé.
- **Normaliser l'entrée des machines** par un entonnoir (§19) : la machine part toujours de la même vitesse.
- **Le relais (entonnoir) et la zone sont les éléments les plus lumineux** ; rien dans la zone ; machine en zone `mz` non traçable.
