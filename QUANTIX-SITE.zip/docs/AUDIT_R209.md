# QUANTIX — Audit général (R209, 15 octobre 2026)

*Audit complet du projet à la version R208 (dernier zip déployable), rédigé pour préparer la professionnalisation.
Chaque constat chiffré a été mesuré sur le code du zip R208 le 15 octobre 2026, sauf mention « historique » (repris des
documents du Projet ou des conversations précédentes). Documents liés : `CHARTE_EXIGENCES.md` (toutes les exigences de Simon),
`LEXIQUE.md` (vocabulaire commun), `REPRISE-SESSION.md` (état et prochain lot), `INDEX_DOCUMENTS.md` (quel document lire).*

---

## 0. Résumé exécutif

**Verdict.** Quantix possède trois choses rares pour un projet solo : un **moteur physique original et vérifiable** (132 niveaux,
solveur, reprise temporelle, éléments quantiques), une **identité visuelle forte et cohérente** (néon cosmique, « lumière
quantique », héros et épilogue cinématiques) et un **outillage de conception** que peu de studios ont (simulation sans tête,
détecteurs de contournement, éditeur de niveaux sur iPhone, banc des rendus, instrument Quantone). Il lui manque
l'essentiel d'un produit : **un contenu de niveaux homogène** (un tiers des niveaux des mondes 5 à 11 se contournent encore),
**une fin d'histoire écrite** (la narration vient d'être décidée, elle n'est pas encore jouée dans les niveaux), **un son
pour 10 mondes sur 11**, et **tout le socle de diffusion** (hors-ligne, magasins, légal, marque, page de présentation).

**La priorité n'est pas d'ajouter, c'est de finir.** Proposition : figer un périmètre de première version (« Quantix —
Chapitre 1 », mondes 1 à 4 + héros + fin provisoire), le rendre irréprochable et le publier sur itch.io et en PWA, puis
construire la suite sur des retours de vrais joueurs. Le reste du document détaille pourquoi et comment.

**Les cinq décisions qui débloquent tout** (à prendre par Simon, voir §19) :
1. Le périmètre de la première version publique.
2. Le nom (« Quantix » est probablement déjà pris comme marque : vérifier avant d'investir).
3. Le modèle économique de la première version (gratuit + soutien, ou démo + version complète).
4. Le dépôt GitHub connecté à la session (fin des zips, historique, tests automatiques).
5. Le statut de Zen Lab, Quantum Drop et de l'atelier de particule (finir, ou retirer du code).

---

## 1. L'état du projet en chiffres (mesuré sur R208)

| Domaine | Mesure |
|---|---|
| Niveaux | 132 en 11 mondes de 12 ; 6ᵉ et 12ᵉ de chaque monde = machines |
| Solutions de référence (`optsol`) | **95 / 132** (monde 1 : 12, 2 : 11, 3 : 12, 4 : 12, 5 : 7, 6 : 6, 7 : 6, 8 : 9, 9 : 8, 10 : 8, 11 : **4**) |
| Niveaux contournables sans leur mécanique (`bypass.js`, R201b) | **33 / 97 testés**, tous dans les mondes 5 à 11 |
| Niveaux « PRÊTS » selon l'ancien tableau (`ETAT_REFONTE_NIVEAUX.md`) | 13 / 132 — **tableau périmé** (calculé sur `difficulty_R116.json`) |
| Zones de réussite non dégagées (`zonepropre.js`) | 2 : #21 Le grand retour, #34 Relais d'élan |
| Zones non traçables invisibles (`mz`, interdites par la charte) | 6 niveaux (dont #3 Le colimaçon) |
| Tests par monde (`mondeN.js`) | mondes 1 à 5 seulement |
| Musique propre à un monde | **1 / 11** (W1N, Atelier) |
| Code du jeu (hors outils) | ≈ 0,75 Mo de JS + 96 Ko de CSS ; `engine.js` 145 Ko, `visuals.js` 181 Ko, `hero.js` 61 Ko |
| CSS | 15 blocs datés empilés (R186 → R208), 71 lignes avec `!important` |
| Textes FR/EN | parité exacte des clés (124/125 + 103/103) ; **13 chaînes françaises en dur** restent dans `engine.js` |
| Outils (`tools/`) | 113 fichiers, dont une trentaine de scripts ponctuels (w2*, w3*, hard*, tight*) |
| Documents | 50 dans `docs/`, 40 dans le Projet ; plus de la moitié sont historiques |
| Hors-ligne | **aucun service worker** : le jeu installé sur l'écran d'accueil ne marche pas sans réseau |
| Polices | chargées depuis Google Fonts (problème RGPD, voir §9) |
| Tests verts au 15 oct. | audit, strict, tutotest, monde1, monde2, render, replaytest, savetest, maptest, e2e-didacticiel 32/32, e2e-éditeur 25/25, e2e-Quantone 12/12 |

**Ce qui est dans le jeu aujourd'hui (R208)** : accueil Visière avec héros « L'odyssée », constellation, pages de monde,
132 niveaux jouables, plein cadre, didacticiel holographique (règles R202), bilan animé par issue, fin cinématique
« Les retrouvailles » (poursuite de retour à deux particules, plongée dans le trou noir, danse dans la sphère, titre
QUANTIX), bilan du parcours (9 mesures), Quantone intégré, sauvegarde locale, FR/EN.

**Ce qui est construit mais caché** : Zen Lab, Quantum Drop (une expérience par jour), atelier de particule (dessin de la
bille). **Ce qui est annoncé mais absent** : outil Ko-fi (code prêt, adresse manquante), musique des mondes 2 à 11,
fiches des outils Échelle et Aimant, mise en scène quantique des fiches (dessinées à la main).

---

## 2. Atouts et faiblesses

### Atouts (à protéger)

1. **Le geste est universel** : tracer un trait au doigt. Aucun apprentissage de commande, compréhensible à 6 ou à 60 ans.
2. **Une physique honnête et vérifiable** : chaque niveau est simulable sans tête ; on peut prouver qu'une solution existe et
   qu'un raccourci n'existe pas. Très peu de jeux du genre ont cette rigueur.
3. **Un thème scientifique réel et sourcé** : chaque monde évoque une expérience (chambre à bulles, anneau de stockage,
   effet Hall, cyclotron, Tonomura…). C'est un argument pour la presse, l'éducation et la vulgarisation.
4. **Une direction artistique singulière** : fond #05070D, néon, couche cosmique, murs en lumière, zones du vide, ferrofluide
   vivant, épilogue cinématique. Le jeu ne ressemble à aucun concurrent mobile.
5. **Des mécaniques rares** : reprise temporelle (frise), superposition et mesure, corps mou, cordes élastiques, pistes
   traversables, failles qui recousent l'univers.
6. **Une éthique claire** : pas de vies, pas d'énergie payante, pas de minuteur, pas de publicité après un échec. C'est un
   positionnement « premium respectueux » qui peut se dire et se vendre.
7. **Un outillage de studio** : éditeur de niveaux sur iPhone, aperçu jouable, banc des rendus, menu édition, détecteurs,
   générateurs de scènes du didacticiel, Quantone.
8. **Un directeur artistique exigeant** : Simon juge à l'œil et refuse le moyen. La qualité visuelle actuelle en est le résultat.

### Faiblesses (à traiter)

1. **Contenu inégal** : les mondes 1 à 4 sont refaits ; les mondes 5 à 11 mêlent machines spectaculaires et niveaux anciens
   contournables. Un joueur qui atteint le monde 6 tombe sur une qualité plus basse que ce que l'accueil promet.
2. **La promesse dépasse le produit** : l'accueil et la fin sont d'un niveau « vitrine » ; certains niveaux sont d'un niveau
   « prototype ». C'est le défaut que l'audit de septembre (Replit, « la promesse dépasse le produit ») signalait déjà.
3. **Le son** : seul le monde 1 a sa musique ; les effets sonores sont anciens ; le son de l'épilogue n'existe pas.
4. **Pas de joueurs** : aucun test hors de Simon et de la simulation. Ni la difficulté réelle, ni la compréhension des fiches,
   ni la durée de jeu ne sont connues.
5. **Pas de socle de diffusion** : hors-ligne, magasins, page de présentation, bande-annonce, politique de confidentialité.
6. **Dette de méthode** : 50 documents, plusieurs méthodes successives (protocoles R73, barre PRÊT R116, METHODE R122),
   outils ponctuels non rangés ; chaque conversation coûte un temps de remise en contexte élevé.
7. **Dépendance à une seule personne et à un seul canal** : Simon sur iPhone, le zip comme transport, des artefacts qui
   demandent une autorisation à chaque publication.
8. **Monolithes de code** : `engine.js` et `visuals.js` concentrent tout ; le CSS empile 15 blocs de surcharge.

### Opportunités

- **Éducation** (collèges, lycées, médiation scientifique) : chaque monde est une leçon de physique sans le dire.
- **itch.io et le web** : public curieux, tolérant aux jeux d'auteur, idéal pour un premier retour.
- **Créateurs de niveaux** : l'éditeur existe ; le partage de niveaux par lien prolongerait la vie du jeu.
- **Bande originale** : l'approche « une expérience → des formules → un son » est un récit en soi.

### Menaces

- **Marque** : « Quantix » est utilisé par plusieurs sociétés (logiciels, finance, biotech). Risque d'opposition.
- **Fatigue de projet** : 208 révisions en un mois ; sans jalon public, le projet peut s'épuiser avant de sortir.
- **Performances iPhone anciens** : WebGL du monde 8, épilogue, héros — non mesurés sur un appareil de 4 ans.
- **WebView iOS** (si emballage App Store) : audio et performances déjà problématiques par le passé (WAV, WKWebView).

---

## 3. Tous les chantiers laissés en suspens

*Classés par domaine ; origine entre parenthèses. « Bloquant » = bloque une première version publique.*

### 3.1 Niveaux

| Chantier | Origine | Bloquant ? |
|---|---|---|
| Refonte des mondes 7 à 11, un monde à la fois, sans allers-retours (commencer par le 7) | Simon, R201 | oui pour la version complète |
| 33 niveaux contournables (liste §Annexe A) | bypass R201b | oui |
| 37 niveaux sans solution de référence (dont 8 du monde 11) | mesure R209 | oui |
| Monde 11 : refondre 121–125 et 127–131 avec les éléments clarifiés, progression vers 126 et 132 | R156 | oui |
| 117 Le filet : aucune version qui tienne | R168/R177 | non (à refaire) |
| Faille 9 « Aller-retour » : aucune idée qui tienne | R164 | non |
| 48 Le pendule de glace : 63–70 % au lieu de 70 % | R162 | non |
| Monde 3 : deux machines à base de matière poreuse (niveaux à choisir avec Simon) | Simon | non |
| Machines Chaîne 3 et 9 proposées | REPRISE | non |
| Zones de réussite non dégagées : #21, #34 | zonepropre | oui (règle opposable) |
| Zones invisibles `mz` sur 6 niveaux (interdites par la charte) | mesure R209 | oui (règle) |
| Magnétisme 89, 92–95 : ancien gabarit (aimant au centre) | R157 | non |
| Niveau 1 : gagnable par un mur de 11–15 u ; niveau 9 : par un trait de 59 u | ETAT_REFONTE | non |
| Tableau de suivi à recalculer monde par monde (difficulty, enigme, zone, contournements) | R201b | oui (outil de pilotage) |

### 3.2 Son

| Chantier | Origine |
|---|---|
| Musique des mondes 2 à 11 (méthode W1N : une expérience → des formules → des textures) | SON_MONDES |
| Monde 1 trop chargé à partir du niveau 8 | Simon, CONSIGNES |
| Glacier : s'inspirer du préréglage 2 de Simon (quintes, acide grave réverbéré, lo-fi minimal) | Simon |
| Son du héros et de l'épilogue (aujourd'hui muets ou génériques) | R209 |
| Effets sonores : 17 MP3 anciens, à refaire dans la langue « bruitiste organique » | R209 |
| Diagnostic audio visible dans les Paramètres (panneau de développeur) | R209 |

### 3.3 Interface, didacticiel, navigation

| Chantier | Origine |
|---|---|
| Fiches des outils Échelle et Aimant | REPRISE |
| Scènes simulées (et non dessinées) pour les éléments quantiques et la bille molle | R141 |
| Zen Lab, Quantum Drop, atelier de particule : redéfinir avant de les remettre au menu | Simon, R115 |
| 13 chaînes françaises en dur dans `engine.js` (dont « Lâcher la balle », « Relancer », « Reprendre ici ») | mesure R209 |
| Texte « Ce mode n'est pas encore construit » (`soon()`) encore dans le code | mesure R209 |
| Paramètres : diagnostic audio à cacher, choix de langue à vérifier, effacement de progression | R209 |
| Bouton Ko-fi (adresse manquante) ; crédits retirés, à réécrire | R201–R202 |
| Libellés du bilan : « matière » alors que la barre dit « énergie » (voir LEXIQUE) | R209 |
| Leviers d'engagement non faits (distance au but, fantôme de l'essai précédent, carnet de découvertes, compteur de jours…) | ENGAGEMENT |

### 3.4 Narration

| Chantier | Origine |
|---|---|
| Le héros ne montre pas la séparation de la paire (la jumelle n'y apparaît pas) | NARRATION |
| La jumelle n'existe pas dans les niveaux (piste : mécanique du monde 11) | NARRATION |
| Texte final et crédits à écrire (« à creuser dans une direction différente ») | Simon, R202 |
| Une phrase par monde (titre de salle, une ligne énigmatique) cohérente avec la narration | R209 |

### 3.5 Technique et diffusion

| Chantier | Origine |
|---|---|
| Service worker (hors-ligne, mise à jour) | R209 |
| Polices auto-hébergées (RGPD) | R209 |
| Dépôt GitHub connecté, tests dans le workflow de déploiement | CONSIGNES (« à trancher ») |
| Mesure des performances sur iPhone réel (FPS, mémoire) | R209 |
| Artefact Quantone séparé non republié depuis R194 | REPRISE |
| Éditeur de niveaux à reconstruire quand les niveaux changent | méthode |

---

## 4. Dettes de code

| # | Dette | Risque | Correction proposée | Effort |
|---|---|---|---|---|
| C1 | 13 chaînes FR en dur dans `engine.js` (l. 1576, 1629, 1799–1812, 2066, 2109, 2130, 2330–2335, 2518) | anglais incomplet ; règle non négociable violée | clés `i18n` + `TR()` | court |
| C2 | Panneau de diagnostic audio visible dans les Paramètres | aspect « prototype » | n'afficher qu'avec `?debug` | court |
| C3 | Pas de service worker | jeu installé inutilisable hors réseau ; pas de mise à jour maîtrisée | `sw.js` avec cache versionné par tampon de build | moyen |
| C4 | Polices Google Fonts distantes | RGPD (jurisprudence allemande 2022 sur l'IP transmise à Google) ; rendu sans réseau | auto-héberger les 3 familles (licence OFL) dans `assets/fonts/` | court |
| C5 | CSS : 15 blocs datés empilés, 71 lignes `!important` | chaque retouche casse un ancien bloc ; lenteur de rendu | refonte en couches (jetons, composants, écrans) ; supprimer les blocs morts (R195 opaque…) | long |
| C6 | `engine.js` (145 Ko) mélange physique, rendu, interface, audio, sauvegarde | régressions, coût de lecture pour l'IA | découper en `physics.js`, `ui.js`, `save.js` (scripts classiques, ordre imposé) | long |
| C7 | `visuals.js` (181 Ko) | idem | séparer identités de monde, éléments, effets | long |
| C8 | `hero.js` porte le héros ET l'épilogue (61 Ko) | idem | `epilogue.js` séparé | court |
| C9 | Fonctions cachées encore présentes (Zen, Drop, atelier, `soon()`) | code mort, textes périmés | décider (§19) puis finir ou retirer | moyen |
| C10 | 6 niveaux avec `mz` invisible ; 2 zones de réussite occupées | règles de charte violées | corriger dans la refonte des mondes concernés | court |
| C11 | Tests de monde absents pour 6 à 11 ; aucun test dans le déploiement | régression invisible | `mondeN.js` générique ; étape « tests » dans `deploy.yml` | moyen |
| C12 | 113 outils dont ~30 ponctuels | confusion | ranger dans `tools/archive/` ; `tools/README.md` | court |
| C13 | Sauvegarde : schéma `v:1` enrichi au fil de l'eau (`jr`, `tuto`…) | migration implicite | numéroter les versions de schéma et écrire `migrate()` | court |
| C14 | Monde 8 en WebGL 2 (ferrofluide) | iPhone anciens / batterie | repli 2D si WebGL indisponible ou FPS bas | moyen |
| C15 | Pas de mesure de performance intégrée | régressions FPS invisibles | compteur FPS en `?debug`, budget par écran | court |
| C16 | Le solveur dérive de QuarkPhysics (historique) | licence à respecter | vérifier la licence d'origine et créditer (§9) | court |

---

## 5. Dettes produit

| # | Dette | Pourquoi c'est grave | Proposition |
|---|---|---|---|
| P1 | Qualité inégale des mondes | le joueur juge sur le pire niveau qu'il rencontre | finir monde par monde ; ne publier que des mondes finis |
| P2 | Aucun joueur extérieur | difficulté et compréhension inconnues | 5 testeurs sur 2 semaines (§7.4) avant toute sortie |
| P3 | Son incomplet | le son fait la moitié de l'émotion de la fin et des machines | une musique par monde publié, effets refaits |
| P4 | Fin d'histoire sans mots ni crédits | la fin est belle mais muette ; pas de signature | 3 lignes + crédits sobres (§14) |
| P5 | Modes cachés | promesses non tenues dans le code | trancher (§19) |
| P6 | Pas de page de présentation | personne ne peut découvrir le jeu | une page (itch.io + site) avec bande-annonce de 30 s |
| P7 | Pas de raison de revenir après la fin | durée de vie | niveaux de la communauté, défi du jour (Quantum Drop redéfini) |
| P8 | Didacticiel encore partiellement dessiné à la main | incohérence des fiches | scènes simulées pour toutes les fiches |
| P9 | Vocabulaire flottant (bassin/zone, matière/énergie) | confusion du joueur | appliquer `LEXIQUE.md` partout |
| P10 | Accessibilité non traitée | public réduit, exigence des magasins | contraste, daltonisme (couleurs + formes), animations réduites partout, taille des cibles |

---

## 6. Objectifs

### Court terme (2 à 4 semaines) — « Chapitre 1 publiable »

1. Trancher les cinq décisions du §0.
2. Dettes courtes : C1, C2, C4, C8, C10 (mondes 1–4), C12, C13.
3. Mondes 1 à 4 irréprochables : 0 contournement, 48 solutions de référence, zones propres, aucune `mz`, tests verts.
4. Musique des mondes 2, 3 et 4 (méthode W1N), monde 1 allégé à partir du niveau 8.
5. Fin provisoire du chapitre 1 (version courte de l'épilogue, ou héros inversé) + écran « à suivre ».
6. Service worker (C3) ; page itch.io ; 5 testeurs.

**Définition de « fini » pour un niveau** (remplace la barre PRÊT) : une idée en trois lignes (croit / découvre / geste),
solution de référence, 0 gagnant sans la mécanique, 0 trait « nu », zone propre, aucune `mz`, P_exec ≥ 70 % au modèle
éditeur, capture regardée, validé par Simon sur iPhone.

### Moyen terme (2 à 4 mois) — « Version complète »

1. Mondes 5 à 11 refaits un par un (ordre demandé par Simon : 7, 8, 9, 10, 11, puis 5 et 6).
2. Musique des 11 mondes ; effets refaits ; son du héros et de l'épilogue.
3. Narration jouée dans les niveaux (jumelle au monde 11, phrase par monde, héros qui montre la séparation).
4. Découpage `engine.js` / `visuals.js` / CSS (C5–C7) une fois le contenu stabilisé.
5. Emballage magasins (Capacitor), comptes développeur, fiches magasin, politique de confidentialité.
6. Décision sur Zen Lab, Quantum Drop, atelier de particule.

### Long terme (6 à 18 mois)

1. Éditeur de niveaux public et partage par lien (« laboratoire » communautaire).
2. Version éducation (parcours guidés, fiches pour l'enseignant, mode classe).
3. Version ordinateur (Steam / itch) avec souris et stylet.
4. Bande originale publiée ; Quantone comme application sœur.
5. Traductions supplémentaires (ES, DE, IT, JA) — la structure i18n le permet.

---

## 7. Professionnalisation : vers un produit fini, diffusable et installable

### 7.1 Les canaux possibles

| Canal | Coût d'entrée | Ce qu'il faut | Pour Quantix |
|---|---|---|---|
| **Web / PWA** (GitHub Pages actuel) | nul | service worker, manifeste complet, icônes masquables | vitrine et démo ; installable sur Android ; sur iPhone via « Sur l'écran d'accueil » |
| **itch.io** (jeu HTML5) | nul | zip du site, page, captures | **premier marché recommandé** : public curieux, retours rapides, paiement libre possible |
| **Google Play** (TWA ou Capacitor) | 25 $ une fois | compte, fiche, politique de confidentialité, classification | bon rapport coût/portée |
| **App Store** (Capacitor / WKWebView) | 99 $ par an | Mac + Xcode (ou service de compilation en ligne), revue Apple | public principal de Simon (iPhone) ; vigilance audio WebView |
| **Steam** (Tauri / Electron) | 100 $ par jeu | version ordinateur, souris, captures, bande-annonce | après la version complète |

### 7.2 Ce qu'un produit installable exige (liste de contrôle)

- Hors-ligne complet (service worker), mise à jour annoncée au joueur, numéro de version visible (tampon déjà présent).
- Icônes : 192, 512, masquable, icône Apple 180 ; écran de lancement ; nom court.
- Aucune ressource tierce au lancement (polices, scripts).
- Sauvegarde robuste : migration de schéma, export/import manuel de progression (utile pour changer d'appareil).
- Performance : 60 i/s sur un iPhone de 4 ans dans les écrans lourds (héros, épilogue, monde 8), sinon mode allégé automatique.
- Accessibilité : contraste, couleurs doublées de formes, « animations réduites » respecté partout (héros et épilogue compris).
- Légal : mentions, confidentialité (même « aucune donnée collectée » doit être écrit), licences tierces, crédits.
- Fiche magasin : titre, sous-titre, 5 captures par format, vidéo de 15 à 30 s, description FR/EN, mots-clés, classification.

### 7.3 Organisation du travail à professionnaliser

- **Dépôt GitHub** connecté à la session : fin des zips comme transport, historique, retour arrière possible, tests dans
  l'action de déploiement (audit, strict, render, mondes, replaytest).
- **Branches** : `main` = ce qui est en ligne ; une branche par lot ; Simon valide sur l'aperçu, puis fusion.
- **Versions** : garder le tampon `R###` pour le travail, ajouter une version publique (`1.0.0`) pour les magasins.
- **Journal des changements** public court (ce que le joueur voit), distinct de `REPRISE-SESSION.md`.

### 7.4 Tester avec de vrais joueurs (indispensable avant toute sortie)

- 5 personnes extérieures (dont un enfant de 10–12 ans et une personne qui ne joue jamais), sur leur propre téléphone.
- Consigne : jouer 20 minutes sans aide ; Simon note où ils bloquent, ce qu'ils disent, ce qu'ils ne lisent pas.
- Option éthique : un journal local (pas de serveur) que le testeur exporte volontairement (le bilan du parcours `JR`
  fournit déjà temps, lâchers, échecs, reprises).

---

## 8. Monétisation

**Décisions figées (historique, `ENGAGEMENT-ET-MONETISATION.md`)** : pas de vies, d'énergie, de minuteur, de monnaie
obligatoire, ni de publicité après un échec ; publicité récompensée tolérée seulement après une réussite et pour du bonus.

**Constat** : une publicité, même récompensée, abîme la direction artistique et demande une régie, un consentement et du
code tiers. Pour un jeu d'auteur premium, elle rapporte peu. **Recommandation : aucune publicité** dans la première année.

| Modèle | Pour | Contre | Recommandation |
|---|---|---|---|
| Gratuit + soutien (Ko-fi, « payez ce que vous voulez » itch) | zéro friction, image généreuse, retours rapides | revenus faibles | **version 1 (chapitre 1)** |
| Démo gratuite (mondes 1–2) + achat unique de la suite (« premium ») | cohérent avec l'éthique, simple | demande un contenu fini | **version complète** (mobile 4,99–6,99 € ; ordinateur 9,99 €) |
| Cosmétiques (traces, apparences de particule) | sans effet sur le jeu | demande l'atelier de particule fini | plus tard, en option |
| Licence éducation (établissement) | revenu par contrat bien supérieur | travail non ludique (suivi, fiches) | évaluer après la version complète |
| Bande originale | coût quasi nul (Quantone) | revenu marginal | bonus de lancement |

**Ordres de grandeur prudents** : un jeu d'auteur mobile premium sans budget marketing vend typiquement de quelques
centaines à quelques milliers d'unités ; les succès cités historiquement (Baba Is You, Poly Bridge) sont des exceptions,
avec des années de production. Le premier objectif économique réaliste est de **couvrir les frais** (comptes développeur,
nom de domaine) et de **constituer une audience** (liste de joueurs intéressés).

---

## 9. Aspect légal (repères, à faire valider par un professionnel — je ne suis pas juriste)

| Sujet | Constat | À faire |
|---|---|---|
| **Marque « QUANTIX »** | nom très utilisé (logiciels, finance, sciences) | recherche EUIPO, BOIP (Benelux), USPTO, magasins ; si conflit, choisir un nom avant tout investissement visible |
| **Statut de Simon** | en Belgique, indépendant envisagé (formation de gestion en septembre) | les revenus de vente et de dons sont des revenus imposables ; voir guichet d'entreprises / comptable ; Apple et Google collectent la TVA des ventes comme revendeurs, itch.io et Ko-fi : vérifier qui est redevable |
| **Polices** | Space Grotesk, Inter, JetBrains Mono : licence SIL OFL (libres, embarquables) | auto-héberger (RGPD) et joindre la licence |
| **Moteur physique** | solveur « transposé de QuarkPhysics » (historique) | vérifier la licence du projet d'origine et créditer dans les mentions |
| **Illustrations des mondes** | fournies par Simon (`docs/source-art/`), provenance non documentée | consigner l'origine (création, outil génératif, licence) ; les magasins demandent de déclarer les droits |
| **Sons** | effets générés, Quantone maison | consigner l'origine |
| **Données personnelles** | aucune collecte, sauvegarde locale | politique de confidentialité courte « aucune donnée collectée » (exigée par les magasins) ; pas de traceur |
| **Enfants** | jeu tout public | classification PEGI 3 / 4+ ; aucune publicité ni achat ciblant les enfants |
| **Mentions scientifiques** | expériences citées | garder la règle « sourcé ou marqué à sourcer » avant tout texte visible |
| **Dons (Ko-fi)** | prévu | mentionner qu'un don ne donne pas d'avantage de jeu |

---

## 10. Public cible

**Cœur** : adultes et adolescents (14–45 ans) amateurs de puzzles physiques et de jeux d'ambiance (références : Crayon
Physics, Brain It On, Cut the Rope, Monument Valley, Alto, Baba Is You), qui jouent par sessions de 5 à 20 minutes sur
téléphone et sont sensibles à la beauté d'un jeu.

**Secondaire** : curieux de science et de vulgarisation (abonnés de chaînes de physique), enseignants et élèves de collège
et lycée (mécanique, électromagnétisme, physique moderne), parents qui cherchent un jeu sans publicité pour leurs enfants.

**Ce que ce public attend** : une progression claire, l'impression de devenir compétent, des solutions multiples, de la
beauté, aucune manipulation. **Ce qu'il ne supporte pas** : un niveau injuste, un texte trop long, une publicité, un
geste imprécis.

**Conséquence pour la conception** : la difficulté doit venir de la compréhension (règle déjà posée), les textes rester
courts (audit de ton R201), et le premier quart d'heure être parfait (c'est là que se décide la note en magasin).

---

## 11. Génération de niveaux : méthode et automatisation

### 11.1 Ce qui existe

- **Moteur sans tête** (`tools/load.js`) : charge le vrai code du jeu dans Node, simule à 60 Hz, sans approximation.
- **Recherche de solutions** : `solver.js`, `optimal.js`, `lab.js` (gagnants avec et sans la mécanique), `rgen*.js`
  (recherche aléatoire de conceptions), `grid2.js` (deuxième trait).
- **Détecteurs** : `contournements.js` (traits « nus »), `bypass.js` (mécanique inutile), `zonepropre.js`, `courts.js`.
- **Jouabilité** : `difficulty.js` (modèle d'erreur de tracé, P_exec / P_int), `constance.js` (régularité des machines).
- **Correction** : `retune.js`, `fixstar.js` (noyau sur la trajectoire), `ndfix.js` (zones interdites qui ferment les raccourcis).
- **Construction** : `rail.js` (courbes harmonieuses), `flow.js` (poussière d'indice), `slotwrite.py` / `setlv.py` (écriture
  dans `levels.js`), `forge.json` (recettes de machines).
- **Collaboration** : éditeur de niveaux sur iPhone (base de données `niveaux`, documents `Q-MM-PP`).

### 11.2 Ce qui ne marche pas encore

- Les outils prouvent qu'un niveau **n'est pas cassé** ; ils ne disent pas s'il est **bon** (idée, surprise, beauté).
- Les essais sont dispersés dans le scratchpad (`m/`, `mg/`) et perdus d'une conversation à l'autre.
- Pas de pipeline unique : chaque monde a eu ses scripts (`w2*`, `w3*`).

### 11.3 Méthode proposée : « fiche → prototype → preuve → regard »

1. **Fiche** (une par niveau, dans `tools/fiches/N.js`) : l'expérience évoquée, l'idée en trois lignes (croit / découvre /
   geste), le leurre, la mécanique qui doit être indispensable, la place dans la progression du monde.
2. **Prototype** : géométrie avec `rail.js` ; machines à partir de recettes `forge.json` ; ou dessin de Simon dans l'éditeur.
3. **Preuve** (une commande, `tools/pipeline.py N`, sortie en 6 lignes) : solution de référence, 0 gagnant sans la
   mécanique, 0 trait « nu », zone propre, P_exec, familles de solutions, noyau.
4. **Regard** : capture, puis aperçu publié ; Simon juge sur iPhone.
5. **Archivage** : la fiche et les mesures restent dans `tools/fiches/` (plus de connaissance perdue dans le scratchpad).

**Automatisation raisonnable** : générer des **variantes** d'une idée (positions, angles, énergie) et garder celles qui
passent la preuve ; ne jamais générer l'idée elle-même. L'idée vient de la fiche (et de la `BIBLE_ENIGMES.md`).

### 11.4 Objectifs de parcours singulier (par monde)

Chaque monde doit avoir : (a) une **progression** (introduction → variations → retournement → combinaison → synthèse,
avec un écho final du premier niveau), (b) **deux machines** (6 et 12) qui contiennent le bonus du monde et une
trajectoire longue et belle, (c) **une identité visuelle animée** fondée sur son expérience, (d) **une musique**, (e) un
moment qui n'existe dans aucun autre monde (le cyclone de la Soufflerie est le modèle validé par Simon).

---

## 12. Contraintes esthétiques et charte graphique

Résumé (le détail opposable est dans `CHARTE_EXIGENCES.md` §B et `HANDBOOK.md` §6) :

- **Fond** #05070D, néon, couche cosmique ; transparences par couches animées (voiles, poussières, vortex, cordes, fentes).
- **Murs** en « lumière quantique » (rail de photons, cœur blanc, jonctions adaptatives) ; impacts gradués ; **rien dans la
  zone de réussite**.
- **Couleurs** : jetons du handbook (cyan #4DD7FF, violet #A878FF, or #FFD85A, vert arrivée #9BEB4B, danger rouge…) et leurs
  nuances seulement ; une couleur par matière, toujours la même.
- **Typographie** : Space Grotesk (titres), Inter (texte), JetBrains Mono (relevés) ; peu de texte, mots courts.
- **Interface « Visière »** : verre sombre, repères de coin, une ligne de lumière, ouverture en cascade, fiches holographiques
  (émetteur, rails, déroulement).
- **Animation** : subtile, au service de la mise en scène ; ralentis et accélérations plutôt que linéarité ; caméra sobre
  (un seul grand mouvement par séquence).
- **Interdits** : style « rétro plat », zones invisibles, image floue agrandie en fond, texte décoratif, guirlandes et
  « kitsch » (retour de Simon sur la fin R201).

**Écarts constatés** : CSS empilé (C5), `mz` invisibles (C10), panneau de diagnostic (C2).

---

## 13. Scénario : réinterprétation et amélioration

### 13.1 Ce qui existe (décidé R203 → R207, `NARRATION.md`)

Une paire de particules intriquées naît à l'horizon d'un trou noir ; la nôtre s'échappe (le héros) ; elle traverse onze
salles d'expérience ; à la fin, sa compagne apparaît au monde Quantique, elles refont le chemin ensemble, plongent dans le
trou noir d'origine et leur réunion crée une sphère où elles dansent ; le titre QUANTIX apparaît.

### 13.2 Les faiblesses

1. **Le début ne raconte pas la séparation** : le héros montre une particule seule ; la jumelle n'existe pas au départ.
2. **Le milieu ne parle pas de l'histoire** : les 132 niveaux ignorent la jumelle ; le joueur ne sait pas ce qu'il cherche.
3. **Deux versions de la compagne** : « restée derrière l'horizon » (R203) puis « née d'un dédoublement au monde Quantique »
   (R204). Il faut choisir.
4. **Le noyau** (étoile à ramasser) n'a pas de sens narratif.

### 13.3 Proposition d'histoire claire (à valider par Simon)

**Titre de travail : « Quantix — l'autre moitié ».**

- **Prologue (héros, accueil)** : au bord du vortex, une paire naît ; une particule violette est aspirée, la nôtre est
  projetée dans l'Atelier. *Une image, aucun mot.* (Correction du héros : 2 secondes de séparation au début de la boucle.)
- **Les onze salles (le jeu)** : la particule cherche à **redevenir entière**. Chaque **noyau** ramassé est un fragment de
  l'état commun : quand on le prend, un écho violet de la jumelle apparaît un instant (sa position anti-corrélée). Plus le
  joueur a de noyaux, plus l'écho est net. *Le noyau gagne un sens : retrouver l'autre.*
- **Monde 11 (Quantique)** : la jumelle devient une **mécanique** — elle bouge en miroir de la particule ; certaines portes
  ne s'ouvrent que si les deux sont mesurées ensemble. Le niveau 132 les réunit.
- **Épilogue** (déjà construit) : la poursuite à deux, le trou noir, la sphère, le titre. Le bilan devient « le carnet du
  laboratoire ».
- **Une phrase par salle** (titre de monde, une ligne, ton énigmatique et concis, déjà amorcé R201) : par exemple
  Atelier « Le trait est matière. », Fonderie « Ce qui frappe rend plus. », Chaîne « L'élan se transmet. », Glacier « Rien
  ne freine. », Soufflerie « L'invisible pousse. », Mécanique « Tout bat la mesure. », Gravité « Le bas change. »,
  Magnétisme « Attirer sans toucher. », Faille « L'espace se recoud. », Filaments « La corde répond. », Quantique « Deux
  chemins à la fois. » *(propositions à retravailler avec Simon)*.

### 13.4 Règles de narration

Aucun texte ne raconte l'histoire ; elle se lit dans les images, les noyaux et la fin. Les mots restent rares, courts,
énigmatiques. Toute affirmation scientifique visible est sourcée.

---

## 14. Cohérence et navigation

### 14.1 Parcours actuel

Accueil (héros) → **Continuer** (niveau en cours) / **Constellation** → page du monde → niveau → bilan → suivant.
Accueil → **Quantone** (plein écran) ; **Paramètres** (son, haptique, animations réduites, loupe, diagnostic audio,
explications, langue, progression). Pause : reprendre, état initial, niveaux, paramètres, accueil.

### 14.2 Constats

- L'accueil est de niveau « vitrine » et cohérent. Les éléments cachés (Zen, Drop, atelier) laissent des boutons et du code.
- Les **Paramètres** montrent un diagnostic technique (moteur, contexte, session iOS) : à cacher.
- Le **bilan** utilise « matière » alors que la barre de tracé dit « énergie » (LEXIQUE).
- La **constellation** et les **pages de monde** ne disent rien de l'histoire (une phrase par monde suffirait).
- La **fin du jeu** n'offre aucune suite (pas de retour au laboratoire, pas d'invitation à refaire les niveaux pour les
  étoiles manquantes) : ajouter après le bilan « Revoir la fin » et « Étoiles manquantes ».
- **Retour arrière** : bouton du niveau → page du monde (R136) ; vérifier sur iPhone que le geste de retour du système ne
  quitte pas l'application installée.

### 14.3 Recommandations

1. Un seul écran de réglages, sans diagnostic ; langue en évidence.
2. Les modes cachés : soit absents du code, soit présents et finis.
3. Une ligne d'histoire par monde sur sa page.
4. Après la fin : « Revoir la fin », « Constellation », « Étoiles manquantes ».

---

## 15. Quantone — audit dans l'audit

### 15.1 Ce que c'est

Un instrument de dessin sonore (anciennement « Résonateur ») : on trace des formes sur un champ ; x = temps (16 pas),
y = hauteur ; six instruments (Mélodie FM, Basse, Synthé, Acide TB-303, Rythmes, Effets), 32 préréglages, fonctions
mathématiques (d'après une vidéo fournie par Simon), chaîne d'effets (écho, flanger, filtre, réverbération), pad X-Y,
égaliseur, enregistrement en direct, export .wav, préréglages sauvegardés, duplication et réassignation d'un trait.
Fichier autonome `studio/quantone.html` (141 Ko), intégré au jeu (bouton d'accueil, plein écran) et publié en artefact.

### 15.2 Atouts

- Unique, ludique, cohérent avec le geste du jeu (tracer).
- Sert de **laboratoire du son du jeu** : les préréglages de Simon indiquent ses goûts (fa♯ lydien ; quintes Glacier).
- Peut devenir un produit à part (application sœur, bande originale).

### 15.3 Faiblesses

| # | Constat |
|---|---|
| Q1 | Deux versions qui divergent : celle du jeu est à jour (R194), l'artefact séparé ne l'est pas |
| Q2 | Le lien entre Quantone et la musique du jeu (W1N, `MFX`) est conceptuel : les fonctions sont « les mêmes » mais pas le même code |
| Q3 | Densité d'interface élevée pour un téléphone (réglages nombreux) ; pas de mode « simple » |
| Q4 | Saturation corrigée par un écrêteur (R114) : à surveiller sur les préréglages chargés |
| Q5 | Dans le jeu, Quantone n'a pas de rôle : c'est un bonus sans lien avec la progression |
| Q6 | Textes : Quantone a son propre dictionnaire, hors `i18n.js` (exception à la règle, à documenter) |

### 15.4 Recommandations

1. Une seule source : le jeu inclut `studio/quantone.html` ; l'artefact est reconstruit depuis ce fichier à chaque livraison.
2. Un **mode simple** (un instrument, une gamme, tracer-écouter) par défaut ; le mode complet en option.
3. Relier au jeu : débloquer un préréglage par monde terminé (« le son du Glacier »), sans contrainte.
4. Plus tard : Quantone comme application séparée (bande originale, préréglages partagés).

---

## 16. Les outils de création propres à Quantix

| Outil | Adresse / source | État | Recommandation |
|---|---|---|---|
| **Menu édition** (point d'entrée de tous les outils) | artefact 63wuCq6jdpwN6i7PWmyNkk ; `tools/build-menu.py` → `studio/menu-edition.html` | à jour R201 ; liens copiables | le republier seulement s'il change ; liens donnés en clair à chaque réponse |
| **Aperçu jouable** | artefact ASrEUAFnV6NoqYmm6zGkeC ; `tools/build-apercu.py N [U] [skipintro] [home] [fin]` | R208 (ouvre sur la fin) | toujours dire ce qu'il montre ; options documentées |
| **Éditeur de niveaux** | artefact 1a3sK3pRaLi1c9LDKJnGrp ; aperçu `1 11 skipintro` + `studio/editeur-niveaux.js` | reconstruit R198 | à reconstruire après chaque refonte de monde ; ne jamais écraser un document de Simon |
| **Banc des rendus** | artefact YLLD3eGHDLFWP3k44nfMxW ; `tools/build-galerie.py` | R197 | tout nouveau rendu y passe avant le jeu (règle de Simon) |
| **Quantone** | artefact AjzgmbymcAJkwqkWtKH2By ; `studio/quantone.html` | artefact en retard | voir §15 |
| **Atelier de particule** | dans le jeu, caché | à redéfinir | §19 |
| **Moteur sans tête et détecteurs** | `tools/` | 113 fichiers | ranger, `tools/README.md`, pipeline unique |

**Point faible commun** : chaque publication d'artefact demande une autorisation à Simon. Règle : regrouper, ne publier
que ce qui change, et préférer l'envoi de fichiers (aucune autorisation) pour les documents.

---

## 17. Méthode de travail : ce qui marche, ce qui coûte, la méthode ajustée

### Ce qui marche

- Les lots courts avec un résultat visible ; l'aperçu publié ; les captures regardées avant d'affirmer.
- Les correctifs comptés (OK / ÉCHEC) ; les tests rapides ; le tampon de version.
- Simon qui juge à l'œil et tranche vite.

### Ce qui coûte

- La remise en contexte à chaque conversation (documents nombreux, `REPRISE-SESSION.md` qui gonfle).
- Le zip comme transport (envoi, décompression, risque de version).
- Les essais longs qui finissent abandonnés (règle de Simon du 12 oct. : retravailler plutôt qu'abandonner).
- Les publications d'artefacts (une autorisation chacune).
- Les retours sur des points déjà tranchés (vocabulaire, styles rejetés) faute de charte unique.

### La méthode ajustée (appliquée dans `INSTRUCTIONS_PROJET.md` R209)

1. **Lire au démarrage** : `REPRISE-SESSION.md` (état, prochain lot), `CHARTE_EXIGENCES.md` (ce qui ne se rediscute pas),
   `LEXIQUE.md` (les mots). Rien d'autre sans besoin (`INDEX_DOCUMENTS.md` dit où chercher).
2. **Un lot = un monde ou une fonction**, annoncé en une phrase, terminé par un aperçu et un zip.
3. **Deux essais par problème**, puis élargir la palette (moteur, élément, géométrie) au lieu d'abandonner l'idée.
4. **Preuve en une commande** (`pipeline.py`), sortie courte.
5. **Fin de lot** : `REPRISE-SESSION.md` mis à jour (état en tête, journal en bas), fichiers du Projet remplacés et nommés.
6. **Liens** : tous les outils en clair à chaque réponse.

---

## 18. Questions à se poser pour professionnaliser

**Produit**
- Quel est le jeu en une phrase pour un inconnu ? (proposition : « Trace un trait, et la physique fait le reste — onze
  salles d'expérience, de l'atelier au monde quantique. »)
- Quelle est la première version qu'on accepte de montrer au public ?
- Que fait le joueur après la fin ?
- Quelle durée de jeu vise-t-on (≈ 4 à 6 h pour 132 niveaux) ?

**Marché**
- Pour qui, d'abord : joueurs de puzzles, curieux de science, ou école ?
- Quel prix, quelle plateforme d'abord, quel calendrier ?
- Comment les joueurs vont-ils découvrir le jeu (vidéo courte, presse, communautés de physique) ?

**Organisation**
- Combien d'heures par semaine Simon peut-il y consacrer jusqu'à la sortie ?
- Qui teste ? Qui relit les textes anglais ? Qui fait la bande-annonce ?
- Faut-il une structure (indépendant, société) avant de vendre ?

**Identité**
- Le nom est-il disponible ? Le logo et l'icône existent-ils en version définitive ?
- La narration (`NARRATION.md`) est-elle la bonne, et la compagne naît-elle à l'horizon ou au monde Quantique ?

---

## 19. Décisions attendues de Simon (liste unique)

| # | Décision | Options | Recommandation |
|---|---|---|---|
| D1 | Périmètre de la première version publique | chapitre 1 (mondes 1–4) / jeu complet | chapitre 1 |
| D2 | Nom | garder « Quantix » après vérification / renommer | vérifier d'abord (EUIPO, BOIP, magasins) |
| D3 | Modèle de la première version | gratuit + Ko-fi / démo + achat | gratuit + Ko-fi |
| D4 | Dépôt GitHub connecté à la session | oui / non | oui |
| D5 | Zen Lab, Quantum Drop, atelier de particule | finir / retirer du code / laisser caché | retirer du menu et du code jusqu'à redéfinition ; garder les sources en archive |
| D6 | Origine de la compagne | née à l'horizon (prologue) / née au monde Quantique | née à l'horizon, retrouvée au monde Quantique (§13.3) |
| D7 | Sens du noyau | fragment de l'état commun / simple bonus | fragment |
| D8 | Adresse Ko-fi et crédits | — | crédits sobres en fin de bilan |
| D9 | Vocabulaire de la ressource de tracé | énergie / matière | énergie (décision R23, voir LEXIQUE) |
| D10 | Ordre de refonte | 7 → 11 puis 5–6 (demande R201) / 5 → 11 | garder la demande de Simon, mais finir 1–4 d'abord si D1 = chapitre 1 |

---

## Annexe A — Liste des niveaux contournables (bypass R201b)

Mondes 5 à 11 : 50 53 55 56 58 · 61 62 63 64 67 69 · 77 79 80 81 82 83 · 89 92 94 · 104 107 · 118 119 ·
121 123 124 125 126 127 128 130 131.

## Annexe B — État des 132 niveaux (mesuré sur R208)

*Solution de référence = champ `optsol` ; contournable = liste bypass R201b ; `mz` = zone non traçable invisible
(interdite par la charte). Les jouabilités P_exec par niveau sont dans `ETAT_REFONTE_NIVEAUX.md` (périmé, R116) et sont à
recalculer monde par monde pendant la refonte.*

| # | Monde | Pos. | Nom | Solution de réf. | Contournable (bypass R201b) | Zone invisible `mz` | Rôle |
|---|---|---|---|---|---|---|---|
| 1 | Atelier | 1 | Le premier trait | oui | — | — |  |
| 2 | Atelier | 2 | Le pont | oui | — | — |  |
| 3 | Atelier | 3 | Le colimaçon | oui | — | oui |  |
| 4 | Atelier | 4 | Le relais | oui | — | — |  |
| 5 | Atelier | 5 | Le demi-tour | oui | — | — |  |
| 6 | Atelier | 6 | Les collines | oui | — | oui | machine |
| 7 | Atelier | 7 | Économie | oui | — | — |  |
| 8 | Atelier | 8 | La portée | oui | — | — |  |
| 9 | Atelier | 9 | Le détour | oui | — | — |  |
| 10 | Atelier | 10 | Le plafond | oui | — | — |  |
| 11 | Atelier | 11 | Le relais | oui | — | — |  |
| 12 | Atelier | 12 | La cellule | oui | — | — | finale du monde (machine) |
| 13 | Fonderie | 1 | Le trampoline | oui | — | — |  |
| 14 | Fonderie | 2 | Le ricochet | oui | — | — |  |
| 15 | Fonderie | 3 | La montée | oui | — | — |  |
| 16 | Fonderie | 4 | La hauteur juste | oui | — | — |  |
| 17 | Fonderie | 5 | Sol brûlant | oui | — | — |  |
| 18 | Fonderie | 6 | Ta plaque | oui | — | — | machine |
| 19 | Fonderie | 7 | Le four | **non** | — | — |  |
| 20 | Fonderie | 8 | Le tremplin | oui | — | — |  |
| 21 | Fonderie | 9 | Le grand retour | oui | — | — |  |
| 22 | Fonderie | 10 | Double rebond | oui | — | — |  |
| 23 | Fonderie | 11 | L’élan d’abord | oui | — | — |  |
| 24 | Fonderie | 12 | La fonte | oui | — | — | finale du monde (machine) |
| 25 | Chaîne | 1 | Le tapis | oui | — | — |  |
| 26 | Chaîne | 2 | Sens inverse | oui | — | — |  |
| 27 | Chaîne | 3 | Tapis et butée | oui | — | — |  |
| 28 | Chaîne | 4 | Le plafond bas | oui | — | — |  |
| 29 | Chaîne | 5 | Ton élan | oui | — | — |  |
| 30 | Chaîne | 6 | Saut de chaîne | oui | — | — | machine |
| 31 | Chaîne | 7 | Tapis et lames | oui | — | — |  |
| 32 | Chaîne | 8 | Deux tapis | oui | — | — |  |
| 33 | Chaîne | 9 | Chaîne montante | oui | — | — |  |
| 34 | Chaîne | 10 | Relais d’élan | oui | — | — |  |
| 35 | Chaîne | 11 | Le tri des tapis | oui | — | — |  |
| 36 | Chaîne | 12 | La chaîne complète | oui | — | — | finale du monde (machine) |
| 37 | Glacier | 1 | Le lac | oui | — | — |  |
| 38 | Glacier | 2 | Trop vite | oui | — | — |  |
| 39 | Glacier | 3 | Le saut | oui | — | — |  |
| 40 | Glacier | 4 | Le demi‑tour | oui | — | — |  |
| 41 | Glacier | 5 | La combe gelée | oui | — | — |  |
| 42 | Glacier | 6 | La piste glacée | oui | — | — | machine |
| 43 | Glacier | 7 | Deux étages | oui | — | — |  |
| 44 | Glacier | 8 | La patinoire | oui | — | — |  |
| 45 | Glacier | 9 | Le passage gardé | oui | — | — |  |
| 46 | Glacier | 10 | Verglas | oui | — | — |  |
| 47 | Glacier | 11 | La crevasse double | oui | — | — |  |
| 48 | Glacier | 12 | Le pendule de glace | oui | — | — | finale du monde (machine) |
| 49 | Soufflerie | 1 | Le souffle | oui | — | — |  |
| 50 | Soufflerie | 2 | Vent de face | oui | **oui** | — |  |
| 51 | Soufflerie | 3 | Vent descendant | oui | — | — |  |
| 52 | Soufflerie | 4 | Colonne étroite | oui | — | — |  |
| 53 | Soufflerie | 5 | Deux colonnes | **non** | **oui** | — |  |
| 54 | Soufflerie | 6 | La cascade inversée | oui | — | — | machine |
| 55 | Soufflerie | 7 | Vent et lame | **non** | **oui** | — |  |
| 56 | Soufflerie | 8 | Contre-courant | **non** | **oui** | — |  |
| 57 | Soufflerie | 9 | La rafale | **non** | — | — |  |
| 58 | Soufflerie | 10 | Le tunnel | **non** | **oui** | — |  |
| 59 | Soufflerie | 11 | La tempête | oui | — | — |  |
| 60 | Soufflerie | 12 | Le cyclone | oui | — | — | finale du monde (machine) |
| 61 | Mécanique | 1 | Le piston | **non** | **oui** | — |  |
| 62 | Mécanique | 2 | La navette | **non** | **oui** | — |  |
| 63 | Mécanique | 3 | Piston bas | **non** | **oui** | — |  |
| 64 | Mécanique | 4 | Deux pistons | **non** | **oui** | — |  |
| 65 | Mécanique | 5 | Le pendule | oui | — | — |  |
| 66 | Mécanique | 6 | L’escalier mécanique | oui | — | — | machine |
| 67 | Mécanique | 7 | Métronome | **non** | **oui** | — |  |
| 68 | Mécanique | 8 | L’engrenage | oui | — | — |  |
| 69 | Mécanique | 9 | Cadence double | **non** | **oui** | — |  |
| 70 | Mécanique | 10 | L’horloge | oui | — | — |  |
| 71 | Mécanique | 11 | Atelier mobile | oui | — | — |  |
| 72 | Mécanique | 12 | L’échappement | oui | — | — | finale du monde (machine) |
| 73 | Gravité | 1 | Tomber vers le haut | oui | — | — |  |
| 74 | Gravité | 2 | Gravité lourde | oui | — | — |  |
| 75 | Gravité | 3 | Le manège inversé | oui | — | oui |  |
| 76 | Gravité | 4 | Le champ de travers | oui | — | — |  |
| 77 | Gravité | 5 | Deux champs | **non** | **oui** | — |  |
| 78 | Gravité | 6 | La fronde | oui | — | — | machine |
| 79 | Gravité | 7 | Ascension | **non** | **oui** | — |  |
| 80 | Gravité | 8 | Champ et lame | **non** | **oui** | — |  |
| 81 | Gravité | 9 | Bascule | **non** | **oui** | — |  |
| 82 | Gravité | 10 | Apesanteur | **non** | **oui** | — |  |
| 83 | Gravité | 11 | Le puits | **non** | **oui** | — |  |
| 84 | Gravité | 12 | Relativité | oui | — | — | finale du monde (machine) |
| 85 | Magnétisme | 1 | La lentille | oui | — | — |  |
| 86 | Magnétisme | 2 | La feuille d’or | oui | — | — |  |
| 87 | Magnétisme | 3 | La dérive | oui | — | — |  |
| 88 | Magnétisme | 4 | Le dipôle | oui | — | — |  |
| 89 | Magnétisme | 5 | Aimant et mur | **non** | **oui** | — |  |
| 90 | Magnétisme | 6 | Le canon de Gauss | oui | — | oui | machine |
| 91 | Magnétisme | 7 | Le cyclotron | oui | — | — |  |
| 92 | Magnétisme | 8 | Slalom | **non** | **oui** | — |  |
| 93 | Magnétisme | 9 | Orbite | oui | — | — |  |
| 94 | Magnétisme | 10 | Champ magnétique | **non** | **oui** | — |  |
| 95 | Magnétisme | 11 | La capture | oui | — | — |  |
| 96 | Magnétisme | 12 | Le spectromètre | oui | — | oui | finale du monde (machine) |
| 97 | Faille | 1 | Le portail | **non** | — | — |  |
| 98 | Faille | 2 | À travers le mur | oui | — | — |  |
| 99 | Faille | 3 | Le geyser | oui | — | — |  |
| 100 | Faille | 4 | Portail et mur | oui | — | — |  |
| 101 | Faille | 5 | Deux failles | **non** | — | — |  |
| 102 | Faille | 6 | L’élan transmis | oui | — | — | machine |
| 103 | Faille | 7 | La sarbacane | oui | — | — |  |
| 104 | Faille | 8 | Boucle | **non** | **oui** | — |  |
| 105 | Faille | 9 | Aller-retour | oui | — | — |  |
| 106 | Faille | 10 | La couture | oui | — | — |  |
| 107 | Faille | 11 | Le pli | **non** | **oui** | — |  |
| 108 | Faille | 12 | L’univers torique | oui | — | — | finale du monde (machine) |
| 109 | Filaments | 1 | Corde tendue | oui | — | — |  |
| 110 | Filaments | 2 | Le hamac | **non** | — | — |  |
| 111 | Filaments | 3 | Corde et plaque | oui | — | — |  |
| 112 | Filaments | 4 | La balle molle | oui | — | — |  |
| 113 | Filaments | 5 | Molle et mince | oui | — | — |  |
| 114 | Filaments | 6 | Le lance-pierre | oui | — | — | machine |
| 115 | Filaments | 7 | Molle et lame | oui | — | — |  |
| 116 | Filaments | 8 | Deux cordes | oui | — | — |  |
| 117 | Filaments | 9 | Le filet | **non** | — | — |  |
| 118 | Filaments | 10 | Corde et colonne | **non** | **oui** | — |  |
| 119 | Filaments | 11 | Opus | **non** | **oui** | — |  |
| 120 | Filaments | 12 | Le relais des frondes | oui | — | — | finale du monde (machine) |
| 121 | Quantique | 1 | Le lien | oui | **oui** | — |  |
| 122 | Quantique | 2 | Opposition | oui | — | — |  |
| 123 | Quantique | 3 | La mesure | **non** | **oui** | — |  |
| 124 | Quantique | 4 | Deux possibles | **non** | **oui** | — |  |
| 125 | Quantique | 5 | Le temps ralenti | **non** | **oui** | — |  |
| 126 | Quantique | 6 | L’interféromètre | oui | **oui** | oui | machine |
| 127 | Quantique | 7 | Intrication double | **non** | **oui** | — |  |
| 128 | Quantique | 8 | Mesure tardive | **non** | **oui** | — |  |
| 129 | Quantique | 9 | Temps et rebond | **non** | — | — |  |
| 130 | Quantique | 10 | Le choix | **non** | **oui** | — |  |
| 131 | Quantique | 11 | Machine quantique | **non** | **oui** | — |  |
| 132 | Quantique | 12 | Quantix | oui | — | — | finale du monde (machine) |
