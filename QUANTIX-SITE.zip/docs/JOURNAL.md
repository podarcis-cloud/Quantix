# QUANTIX — Journal des lots (historique ; ne pas lire au démarrage)

*Extrait de l'ancien `REPRISE-SESSION.md` (R262). Le plus récent en bas. Journal R38 → R121 : `archive/archive_REPRISE-SESSION-R121.md`.*

## Journal R122 → R261
- **R243 (17 oct.)** : décisions de Simon sur `MONDE11_MOTEUR.md` : 1 recombineur, 2 paire opposée réelle, 3 dédoublements
  multiples, 4 zones invisibles — oui aux quatre. Faits : **paire opposée réelle** (`gateOpen` : une porte suit le spin du
  noyau le plus proche ; en `'opp'` le noyau B a le spin contraire ; « Opposition », niveau 2, phase de sa 2ᵉ porte
  inversée pour garder la même solution) ; **recombineur** `lv.rec=[x,y,r,angle°,(fenêtre=14)]` dans `quantum()` : deux
  copies qui le traversent à moins de 14 images d'écart fusionnent au centre et sortent par la voie constructive (vitesse
  moyenne) ; une copie seule le traverse sans effet ; dessin `VX.qrec` (lame semi-argentée, chevrons de sortie, franges
  à la fusion) ; fiche du didacticiel « Recombineur / Recombiner » (`tuto.js`, `i18n.js`) ; `tools/design.js` connaît `rec`.
  **Monde 11 – niveau 6 « L'interféromètre » refait** en vrai Mach-Zehnder : deux tubes, recombineur en bas ; ensemble
  les versions ressortent à gauche (pointes) ; boucher le tube de droite laisse passer la copie de gauche seule, qui garde
  sa route vers le bassin. Zones invisibles retirées (le niveau 12 n'en avait pas). Preuves : à vide échoue, sans
  quantique 0 gagnant, traits nus 0, P_exec 100 %. Tests : audit, strict, tutotest, render, replaytest, savetest,
  maptest, e2e-didacticiel 32/32 (compte des fiches passé à 25). Aperçu (monde 11) et Éditeur republiés ; `?v=R243`.
  À juger : le recombineur se voit peu sous la jonction des tubes.
  **Essais après R243 (sans livraison, code revenu à R243)** : niveaux 5, 7, 8 du Monde 11 sur l'appareil à tubes du niveau 6.
  Leçons : (1) l'interférence n'existe que si la particule tombe **à la verticale** dans le séparateur — toute entrée de
  biais désynchronise les copies (pas de fusion) ; un « Ensemble » où le joueur amène la particule au séparateur a donc
  échoué (et une copie s'échappait par-dessus les tubes : prévoir un mur de pointes à droite) ; (2) en haut des tubes les
  copies rebondissent de façon chaotique, d'où des P_exec faibles (bouclier de détecteur : 43 %) ; (3) un retard par la zone
  dorée est contourné par un trait qui retient la copie (étagère) : la dilatation n'est pas indispensable. Suite proposée :
  refaire le haut de l'appareil (séparateur propre, copies qui entrent droit dans les tubes), puis construire 5, 7–10 dessus.
- **R242 (17 oct.)** : `A_VERIFIER.md` créé (Projet) : tous les niveaux refaits à vérifier par Simon. **Monde 10** : essais
  « Le hamac » (corde qui amortit — le trait solide gagne aussi) et « Le retour » (trampoline au-dessus d'un mur — P 38 %),
  abandonnés ; monde mis en attente (§2). `tools/monde10.js`, `tools/monde11.js` créés. **Monde 11** : squelette commun —
  la particule tombe dans une zone de dédoublement, deux copies partent en diagonale. **niveau 3 « Deux possibles »** (une
  seule copie suffit : rattraper la copie de droite) ; **niveau 4 « La mesure »** (le détecteur rend réelle la copie qui le
  touche : détourner la copie de gauche) ; **niveau 11 « Machine quantique »** (la copie de gauche touche le noyau intriqué,
  la porte s'ouvre pour celle de droite). Mécanique retirée : 0 gagnant ; P_exec 93 / 100 / 93 %. Aperçu (monde 11) et
  Éditeur republiés ; `?v=R242`.
- **R241 (17 oct.)** : **Monde 9 Faille refondu**. Nouveaux : **niveau 1 « Le portail »** (le bassin est enfermé, la sortie
  verte est dedans ; un petit trait fait rouler la particule jusqu'au cercle bleu posé au sol) ; **niveau 5 « Le bord du
  monde »** (introduction de la couture : `wrap` limité à une bande ; un mur de pointes coupe l'écran ; sortir à droite par la
  bande, rentrer à gauche, tomber dans le bassin) ; **niveau 8 « Le trou de serrure »** (faille en plein vol, la traverser
  pour entrer dans le coffre) ; **niveau 9 « Aller-retour »** (synthèse : bord puis faille au sol) ; **niveau 11 « Le pli »**
  (bord puis faille juste après la couture, à traverser en vol). Le niveau 12 (L'univers torique) reste la machine du bord.
  Preuves : à vide échouent ; failles et coutures retirées (séparément et ensemble) 0 gagnant ; traits nus 0 ; zones
  propres ; P_exec (modèle éditeur officiel) 80 / 97 / 90 / 93 / 100 %. `tools/monde9.js` 12/12. Tests : audit, strict,
  tutotest, render, replaytest, savetest, maptest, monde7, monde8, monde9. Aperçu (monde 9) et Éditeur republiés ;
  `?v=R241`. Leçon : choisir la référence avec `difficulty.js` (son modèle diffère du mien : une rampe à 90 % chez moi
  tombait à 23 %).
- **R240 (17 oct.)** : Simon : l'icône de Quantone sur l'accueil (le noyau en pointillé) ne dit rien du son. Nouvelle icône
  `ICON.tone` (`engine.js`) : la particule qui émet trois ondes ; posée sur la ligne Quantone de l'accueil (`hSndI`).
  Tests : audit, strict, tutotest. Aperçu republié ; `?v=R240`.
- **R239 (17 oct.)** : Simon : Monde 8 – niveau 10 (L'accélérateur) illisible, « on ne comprend pas l'effet du magnétisme ».
  Décision de Simon : garder la mécanique, la présenter comme des aimants qui repoussent vers l'avant. `lv.kick` reçoit un
  7ᵉ champ (sens : 1 droite, −1 gauche) → `VX.kickMag` : fer à cheval cyan/violet enjambant la piste, lignes de champ qui
  bombent vers l'avant, chevrons qui glissent dans le sens de la poussée, l'aimant s'allume et une onde part quand la
  particule passe (`S.kickOn`, comme `S.coilOn`). Physique inchangée ; conseil FR/EN réécrit. Le cyclotron (niveau 7) garde
  ses fentes. Convention de Simon : « Monde X – niveau Y » (`LEXIQUE.md`). Monde 8 – niveau 8 (Le coussin) = respiration
  voulue. Tests : audit, strict, render, replaytest, monde8. Aperçu republié ; `?v=R239`.
- **R238 (16 oct.)** : **monde 8 Magnétisme refondu** (demande « continue sur la refonte des niveaux »). Trois niveaux neufs
  à la place des contournables : **89 « Le ricochet »** (champ magnétique sous vide au-dessus d'un bassin de pointes, plafond
  de pointes : à la verticale la particule s'enfonce puis remonte dans le plafond ; arrivée à plat, le champ la renvoie en
  ricochets jusqu'au bassin ; `bf` négatif, référence [[0,370],[70,395]]) ; **92 « Le coussin »** (pente de pointes sous
  laquelle sept aimants répulsifs forment un coussin : la particule lévite et glisse jusqu'au bassin ; plafond parallèle) ;
  **94 « L'accélérateur »** (accélérateur linéaire : trois fentes `kick` sur une piste poussent la particule jusqu'à 14 ;
  vitesse plafonnée, donc lancement identique quel que soit le trait ; sans fentes elle tombe dans le fossé). Preuves : à vide
  échouent, mécanique retirée 0 gagnant (balayages), traits nus 0, zones propres ; P_exec (modèle éditeur) 89 : 93 %,
  92 : 77 %, 94 : 93 %. **Zones invisibles** : 96 `mz` retirée (0 gagnant avec un trait dans l'ancienne zone) ; 90 `mz`
  → `nd` visible (sans elle, 34 traits partant de la colonne gagnaient bobines coupées). `tools/monde8.js` : 12/12.
  Tests : audit, strict, tutotest, render, replaytest, savetest, maptest, monde7, monde8. Aperçu (monde 8) et Éditeur
  republiés ; `?v=R238`. Captures regardées (89, 92, 94 à 0,4 / 1,8 / 3,4 s).
- **R237 (16 oct.)** : note de Simon (Banc de la fin, Mécanique 14,6 s) : la violette passait sous la plateforme. Cause :
  `PP.bounce2` (double réception) laissait la vitesse de chute du dernier rebond ; le `glide` suivant (Hermite) plongeait
  jusqu'à y 429 sous le sol (399/410). Correctif : `me.vy=0` à la fin de `bounce2` (toutes les doubles réceptions). Mesuré :
  violette ≤ 399 de 13,5 à 17 s et de 21,5 à 23,6 s. Note marquée vue dans la base (`seen:true`, réponse). Banc de la fin
  (avec la bande son) et Aperçu republiés ; `?v=R237`.
- **R236 (16 oct.)** : Simon : « le final n'est pas à jour dans le zip ». Vérifié : le zip R235 contenait bien la fin fin5
  (jouée par défaut), la bande son et les vibrations. Cause probable : cache du navigateur / de GitHub Pages (les scripts
  n'avaient pas de version dans leur adresse, l'ancien `hero.js` pouvait être resservi). Correctif : toutes les adresses de
  `index.html` versionnées (`assets/js/*.js?v=R236`, `quantix.css?v=R236`) et l'iframe Quantone (`studio/quantone.html?v=R236`
  dans engine.js) ; `build-apercu.py` accepte ces adresses. **À chaque tampon : remplacer `?v=Rnnn`** (index.html + engine.js).
  Vérifié : site servi en http, tampon R236, `QFINS`, `QHAP`, `QHERO.fin5` (45,3 s) chargés, aucune ressource en erreur ;
  tests audit, strict, tutotest, render, replaytest, savetest, maptest, monde7, e2e-didacticiel 32/32.
- **R235 (16 oct.)** : **Quantone** (bloc R235 dans le module des instruments, `studio/quantone.html`) — (1) **Grille** (`st.grid`,
  liste sous la Gamme : 8, 12, 16, 24, 32, 48, 64 croches) : longueur de la grille de dessin principale, repères verticaux
  (pas, mesures) dans le champ ; (2) **Boucle par instrument** (`st.inst[i].lp`, liste dans l'éditeur : « = grille » ou sa propre
  longueur) : le dessin de l'instrument s'étale sur sa boucle ; boucle générale = ppcm des boucles (≤ 192 croches) →
  polymétrie (ex. grille 32 + basse 12 → 96) ; (3) **Fonction par instrument** (`st.inst[i].fn`, liste dans l'éditeur) : une des
  dix fonctions musicales transforme les notes des traits de CET instrument (bégaiement, Fibonacci mod 4 → note de l'accord,
  ressort qui rebondit, onde de pendules qui filtre par hauteur, aspirateur, cycle des quintes, triton, triangle de Pascal,
  montée sans fin, final) ; les 10 fonctions globales restent. Les trois listes ont le menu « Valeur par défaut / Automation »
  (clés `grid`, `ifn:i`, `ilp:i`), sont sauvées dans le préréglage (`grid`, `ifn`, `ilp`) et s'appliquent à l'export .wav.
  Textes FR/EN (`TX6`). Tests e2e-quantone 12/12, e2e-quantone-editeur 9/9, test R235 10/10 (scratchpad `qt235.py`).
  Artefact Quantone et Aperçu republiés (les deux versions identiques, A17).
- **R234 (16 oct.)** : **bande son de la fin** — `assets/js/fin-sound.js` (global `QFINS`, nouveau, PAS chargé par le jeu) :
  partition WebAudio écrite sur la chronologie de fin5 (`QHERO.fin5.acts()` + nouveaux repères `QHERO.fin5.cues()` : tin, FTJ,
  FTF, DIVE, ATOM, VIBSC). Fa♯ lydien, notes ≤ 520 Hz ; la blanche en verre (`bell`), la violette en « guimauve » (`mallow`) ;
  le thème de cinq notes (MOTIF de sound.js) se dédouble au Quantique, passe en miroir à la Faille, dans le grave à la Gravité,
  en double hélice pendant le vol libre de l'Atelier, à l'unisson à la naissance. Une couleur par monde (corde des Filaments,
  arpège qui s'emballe au Magnétisme, horlogerie euclidienne de la Mécanique, houle de la Soufflerie, quintes et givre du
  Glacier, paquets ping-pong de la Chaîne, bulles et plaques de la Fonderie, crépitement → impact → poussière → siphon à
  l'Atelier, plongée dans le grave, naissance) ; danse en boucle de quatre figures (I, II, vi, I) sans fin ; bell quand QUANTIX
  apparaît. Mesuré (rendu hors ligne 60 s) : crêtes −4,6 à −18 dBFS, RMS −19 à −28 dB, énergie surtout entre 180 et 480 Hz
  (une première version trop grave a été remontée d'une octave). Banc de la fin : case « Son de la fin » (à ×1 seulement),
  `QFINS.sync(t, joue, vitesse)` dans la boucle (`build-banc-fin.py`). Vidéo du film avec le son :
  `quantix-fin-son-R234.mp4` (images du banc à 20 i/s + son rendu hors ligne). Non vérifié : écoute (Claude n'entend pas),
  iPhone (mode silencieux). **Branchée dans le jeu à la demande de Simon** (R234 b) : `fin-sound.js` chargé après `hero.js`
  (`index.html`, `build-apercu.py`), `finCine` appelle `QFINS.sync`, la musique du monde se tait pendant la fin et revient à
  `finStop` ; contexte audio partagé avec sound.js (`Audio1.ctx`, déverrouillé, session iOS). Vérifié dans l'aperçu `fin` : son actif.
  **R234 c** : bruitages d'impact pour chaque choc des DEUX particules (`ev` et `evB`, instrument `impact` : attaque
  claquée + corps qui chute + résonance de la matière du monde, table `MAT`), réceptions lourdes doublées, collision ;
  **vibrations branchées dans le jeu** : `haptics.js` chargé (`index.html`, `build-apercu.py`), `QHAP.set(OPT.hap)` au début de
  la fin → la partition `VIBSC` de hero.js joue (vérifié : 16 motifs dans les 14 premières secondes, moteur Android dans
  Chromium). iPhone : pas d'API web de vibration ; seul le « tic » de l'interrupteur iOS 18, jamais ressenti dans l'app Claude
  (R231) ; vraies vibrations iPhone = application native (Capacitor Haptics).
- **R233 (16 oct.)** : **fin `fin5` intégrée au jeu** (validée par Simon : `epilogue` joue fin5 par défaut, `QFIN_A=false` rétablit
  R207 ; `VX.finale` borne son âge ≥ 0) ; aperçu `fin` vérifié (la fin tourne dans le jeu, sans erreur). **Monde 7 Gravité
  refondu** (six niveaux contournables refaits, chacun avec solution de référence, 0 gagnant sans le champ, 0 trait nu) :
  77 **Le saut lunaire** (champ faible au-dessus d'un vide : trop loin pour un pont, un petit tremplin suffit ; P_exec 83 %) ·
  79 **Le plafond** (champ inversé sous des pointes : le joueur trace le plafond qui mène au balcon ; 97 %) · 80 **Le jet**
  (machine : colonne inversée qui projette la particule au plafond, un toit change la route du jet ; 93 %) · 81 **La frontière**
  (puits en V : la particule ondule sur la frontière de deux champs ; un trait incliné lui donne une direction ; 97 %) ·
  82 **La plume** (deux actes : un toit dépose le jet sur une corniche, un tremplin la fait flotter jusqu'à la zone ; un seul
  trait : 0 gagnant sur 5 001 ; 70 %) · 83 **Le miroir** (puits inversé au fond : seule elle rebondit sans fin sur le vide ;
  viser le bas pour monter à gauche ; 73 %). 75 : zone invisible `mz` retirée (1 gagnant sur 1 601, 0 nu). Essai abandonné :
  demi-tour autour d'une planète (le plafond de vitesse `VMAX` dissipe l'énergie près du noyau). Outils : `bypass.js` testait
  « avec la mécanique » après l'avoir retirée (corrigé) ; `contournements.js` chemin absolu → relatif ; nouveau `monde7.js`
  (12/12 ; 78 La fronde : la planète est un obstacle toujours actif, pas un contournement). Tests : audit, strict, tutotest,
  render, replaytest, savetest, maptest, monde7. Captures des 7 niveaux regardées (aperçu 7). Non vérifié : iPhone, œil de Simon.
- **R232 (16 oct.)** : **Quantone · boîte à rythmes à pas** (panneau sous l'éditeur d'instrument, bloc dans le module des instruments) : 8 voix (grosse caisse, caisse claire, clap, charley fermé, charley ouvert, cymbale métallique à 6 partiels, tom, percu), 16 pas (8 / 12 / 16), pas à trois états (éteint · allumé · accentué), aperçu de chaque voix en mini-grille, voix muette par son point, réglages par voix (accord ±12 demi-tons, déclin, niveau, panoramique), kits (les 5 de l'instrument Rythmes + « Quantique »), motifs (Pulsation, Brisé, Minimal, Quantique en rythmes euclidiens, Vide), « Répartir » (euclidien +1 coup), tête de lecture ; joue seule sans trait, sauvegardée dans le préréglage (`dm`). **Règle (Simon)** : toute nouvelle commande (bouton à valeur, curseur, potard, liste) reçoit le menu « Valeur par défaut / Automation » — appliquée : pas (`dp`), voix (`dmu`, muet), longueur (`dln`), kit (`dkit`), réglages (`dk`) ; les boutons d'action (motifs, Répartir, Effacer) ont le menu grisé. Tests e2e-quantone 12/12, e2e-quantone-editeur 9/9, menu sur chaque commande, pas automatisé qui passe éteint → allumé → accentué. Artefact Quantone republié. Proposition d'extension à 9 instruments faite à Simon (Corde, Écume, Onde) : en attente.
- **R231 (16 oct.)** : Fin — la trace déposée dans la sphère est un fil continu (plus de pointillé de carrés) ; vibrations iPhone : méthode de la bibliothèque ios-haptics (élément neuf dans `<head>`) + interrupteur visible de test dans le banc ; toujours rien sur l'iPhone de Simon (probablement l'app Claude / iframe : à tester dans Safari). **Quantone : menu de commande** (clic droit ou appui long 480 ms sur un potard, un curseur, une liste, une fonction musicale, le pad XY) : « Valeur par défaut », « Automation… », « Retirer l'automation » ; boutons sans valeur : menu grisé. **Automation** : courbe sur 1/2/4/8 boucles, linéaire / lisse / paliers, formes (montée, descente, vague, triangle, pulsation, hasard), points à ajouter, glisser, retirer (double toucher), tête de lecture en direct, repère pulsant sur les commandes automatisées, sauvegardée avec le préréglage (`auto`). Bloc `QAUTO` en fin de `studio/quantone.html` (textes FR/EN dans `TX4`). Tests e2e-quantone 12/12, e2e-quantone-editeur 9/9. Artefact Quantone republié ; le Quantone intégré à l'Aperçu sera à jour au prochain aperçu. Pas fait : automation dans l'export .wav ; enchaînement des deux loopings (Glacier → Chaîne) jugé brut, à retravailler.
- **R230 (16 oct.)** : **scénario vibratoire** de la fin (`VIBSC` + `vib5` dans hero.js) : une partition par acte, en temps local, à la place du déclenchement brut par évènement ; 5 motifs ajoutés au pool (cliquet, givre, houle, tension, envol ; 19 au total). Vibrations actives par défaut dans le Banc de la fin (case cochée ; un tic au bouton Lecture). Préchauffage d'une recherche sans vibration (`EP.warm`). Détail : `docs/VIBRATIONS.md`. Vérifié dans un navigateur de test (séquence de la Mécanique dans l'ordre) ; non vérifié sur iPhone.
- **R229 (16 oct.)** : traînées en **ruban continu** (`trail5` et nouveau `ribbon5` : points lissés Catmull-Rom, largeur qui s'effile, dégradé, trois couches remplies d'un seul tenant ; points trop proches écartés) — film et danse dans la sphère. **Doubles rebonds lourds** (`PP.bounce2` + évènement `thud` : choc sourd, secousse, écrasement, deux rebonds qui s'éteignent) : réception de la blanche et de la violette à la Mécanique, dernière plaque de la Fonderie. **Vibrations, proposition** : `assets/js/haptics.js` (global `QHAP`, PAS chargé par le jeu) — pool de 14 motifs (frôlement, petit rebond, rebond, impact lourd, double rebond, roulement, propulsion, portail, collision, crépitement, annihilation, battement, aspiration, naissance), trois moteurs (Capacitor natif : vraies intensités ; Android `navigator.vibrate` ; iPhone iOS 18+ : interrupteur caché `<input type=checkbox switch>`, un seul « tic » système, relief par le rythme), branché sur les évènements de la fin (`ev5`, entrée dans la zone, naissance de l'atome). Banc : panneau « Vibrations » (essai de chaque motif + vibrer pendant le film) ; `build-banc-fin.py` injecte `haptics.js` et le panneau. À vérifier sur iPhone par Simon. Pour le jeu : option dans les Paramètres (textes i18n), script dans `index.html`, puis choix des évènements. Tests render, strict, audit, replaytest.
- **R228 (16 oct.)** : Atelier — la plongée prolonge le siphon : chaque particule repart de sa place en fin de spirale avec la même vitesse angulaire (`DVW`), s'enfonce en rapetissant et s'éteint (plus de saut de position ni d'arrêt sur le disque). Zone finale recentrée sur la trajectoire du trait (`ZN[5]` y 112) ; avant l'impact la caméra amène la zone au centre avec un léger dézoom anticipé (0,8) et continue de dériver. Délitement : le sable du jeu (`VX.ndDust`) reçoit des points décimés (segments de 12 u) et deux réglages optionnels `sz`/`dn` (taille et densité des grains, défaut inchangé dans le jeu) ; photons d'annihilation courts. Vol libre plus long (`FTF` 3 900, trou noir à x −3 420, 4,5 tours d'hélice). Atelier ≈ 11 s. Tests render, strict, audit. Publié au Banc de la fin.
- **R227 (16 oct.)** : Mécanique — la dernière marche a la même longueur et le même aspect que les autres (contremarche comprise) ; la violette ne s'arrête plus : elle saute la dernière marche par-dessus la blanche et file au ras du sol ; la blanche, restée derrière, est éjectée par la marche (faisceau et anneaux recentrés sur elle) et se pose juste derrière sa compagne (`mecaFly`). Atelier — tournoiements supprimés : vol libre en **double hélice** (`dnaFly` : deux brins en antiphase autour d'une ligne médiane Hermite, écart qui s'ouvre puis se referme à l'entrée de la spirale, vitesse qui enfle puis se pose) ; vortex qui naît de loin et grandit sur 2,6 s ; la caméra glisse peu à peu du couple vers le trou noir, la plongée part du même cadrage. Notes plus anciennes encore ouvertes : Chaîne (saut + obstacle à la réception), Danse (traînée qui saute), montée des marches de la Mécanique, Fonderie (transition trop rapide). Publié au Banc de la fin.

- **R226 (16 oct.)** : Mécanique — seule la bille blanche est éjectée, la violette reste sur la dernière marche, barre cohérente (à confirmer à l'œil). Atelier — plus de faux rebond à l'entrée du vortex (spirale tangente) ; tracé orienté pour entrer **au centre** de la zone finale, élargie, et s'y consumer sur une trajectoire lisible ; pointe du trait en **aura d'énergie** (langues de plasma vers l'arrière, cœur blanc, halo cyan-violet qui pulse, anneau, étincelles le long du trait) ; zone finale : voile allégé, **comètes matière/antimatière** qui se cherchent et s'annihilent (éclair, 4 arcs, anneau, poussière qui retombe) ; **vol libre** : l'image de fond s'efface en 1,6 s, poussière d'étoiles en arrière-plan et éclats flous en avant-plan qui défilent avec la caméra, tournoiements, puis seulement le vortex (poussière d'étoiles). Atelier ≈ 9,8 s. Publié au Banc de la fin ; le jeu garde la fin R207 (drapeau `QFIN_A`).
- **R225 (16 oct.)** : Atelier plus posé — le trait est la vedette ≈ 3,4 s (cadre serré qui commence 1,9 s avant l'entrée dans la zone et tient 1,5 s après) ; particules plus lentes (saut à 5,4 s) ; caméra en trois cadrages **fondus** (couple + pointe → pointe → couple, transitions de 1,1 à 1,4 s, zoom en échelle logarithmique), plus de bascule brusque. Zones interdites **sobres et plus larges** (7 au lieu de 13) : voile léger, liseré fin, une impulsion lente, quelques paires discrètes ; à l'impact, deux ondes douces et un frisson de la membrane. Atelier ≈ 7,4 s. Publié au Banc de la fin.
- **R224 (16 oct.)** : notes de Simon. Fonderie : le trait de l'Atelier n'apparaît plus avant l'arrivée des particules (il naît sous elles). Atelier : le trait prend moins d'avance (≈ 0,7 s) ; il veut **monter** et la zone interdite le coupe : c'est la coupure qui forme le tremplin ; à l'approche de la zone, la caméra se resserre sur sa pointe (zoom 0,98) — le trait est la vedette — puis suit le couple qui saute vers le trou noir (`ORGP=[-1210,118]`). **Zones interdites « cinéma »** (`zoneFX`) : vide profond, nébuleuse qui respire, grain qui dérive, paires virtuelles rose/cyan qui naissent et s'annihilent, membrane lumineuse parcourue d'impulsions, coins repères ; à l'impact, la membrane frémit dans les deux sens et des ondes traversent le vide. Publié au Banc de la fin.
- **R223 (16 oct.)** : Atelier réécrit d'après Simon : les particules roulent et accélèrent sans s'arrêter ; le trait accélère plus et les devance, entre des zones interdites de tailles différentes (seul décor : `ZN`, rendu du jeu + bords et coins repères), dessine un tremplin arrondi, entre dans une zone interdite où il s'arrête (annihilation : onde + deux photons) et se délite (`VX.ndDust`, sans état) ; sa poussière monte allumer le trou noir (déplacé loin à gauche, `ORGP=[-1180,170]`) ; les particules sautent du tremplin et sont aspirées ; après le saut, tout le trait part en poussière. Caméra qui cadre couple + pointe (zoom ≥ 0,55). Trou noir et vortex de la fin en **poussière d'étoile** (`vortexQ(...,sd)` : grains en points, nuage de 520 poussières en orbite, sans arcs électriques ; le héros garde son rendu). Fond : le décalage de l'illustration est borné (plus de bande noire à gauche). Publié au Banc de la fin.
- **R222 (16 oct.)** : fin de l'Atelier réécrite en quatre temps lisibles : (1) dernier trait long (trois creux, 2,9 s), l'énergie naît **au bout du doigt** (la pointe : arcs qui en jaillissent, crépitement le long du trait) ; (2) charge à la pointe 0,5 s ; (3) décharge (éclair, deux ondes) puis le trait s'éteint et se dissout en étincelles qui montent ; (4) les étincelles **allument l'horizon** (le vortex n'apparaît qu'à ce moment, `FE_VO`), puis le couple quitte le trait et s'y enroule. Plus d'arcs vers le vortex. Atelier ≈ 6,5 s. Constantes `FE_DISC`, `FE_GO`, `FE_VO` (hero.js). Publié au Banc de la fin.
- **R221 (16 oct.)** : la remontée du voyage (R220) est abandonnée (Simon : « ça ne marche pas du tout »). Conclusion = le trait simple qui se dessine en direct sous les particules, plus long (deux creux, `TRA0`, 1,75 s) et de plus en plus électrique à mesure qu'il approche du trou : tremblement, double trait blanc et violet, fourches qui crépitent, halo à la pointe, arcs qui sautent vers l'horizon, éclats. Publié au Banc de la fin.
- **R220 · nouvelle conclusion (16 oct.)** : à l'Atelier, pendant que le couple glisse puis s'enroule vers l'horizon : recul (300–700 ms), **remontée du voyage** (700–1750 : la caméra file de l'Atelier jusqu'à l'Arrivée en révélant la route des deux particules, chaque tronçon dans la couleur de son monde, chocs en étoiles, les onze illustrations côte à côte comme une pellicule), puis **rembobinage** (1750–2700 : la route glisse comme un fil enroulé dans le trou noir, la caméra suit le bout du fil et revient sur l'horizon) ; la plongée et l'atome suivent. Code : `camW`, `routeDraw`, `route5`, `reelPos` (hero.js, bloc R220). Publié au Banc de la fin.
- **R219 (16 oct.)** : échos à la rencontre du couple pendant un tournoiement (début et fin de chaque fenêtre `tw`) : éclats blancs et violets + trois ondes décalées qui s'affaiblissent, avec six rayons (`EP.ech`). Publié au Banc de la fin. Question ouverte : comment conclure plus fort que le trait de l'Atelier (propositions faites à Simon).
- **R218 · notes de Simon (16 oct.)** : Mécanique = la marche de propulsion reste sous les particules et les pousse (elle ne les traverse plus) ; Glacier = rafales de givre en orbite autour du cyclone (34 traînées, plus vives quand le couple entre dans la boucle) et onde lente ; Fonderie = vols balistiques (gravité) au lieu de segments raides, couple plus serré ; **tournoiements** : fenêtre `tw:[[t0,t1,tours,ouverture]]` par scène, les deux particules tournent l'une autour de l'autre (Fonderie après le dernier plafond, Gravité pendant la chute, sens opposés). Publié au Banc de la fin.
- **R217 · captures de Simon (16 oct.)** : Fonderie = rebonds entre plaques du sol et plaques du plafond en zigzag descendant (dessin de Simon ; l'escalier faisait redite avec la Mécanique), pointes rouges du jeu (`VX.spikes`, exporté de visuals.js) ; Mécanique = marches au rendu du niveau 66 (pièce de lumière dorée jupe + dessus, `VX.curve` accent or) ; Atelier = un seul passage le long du trait, plus d'aller-retour. Nouvel outil `tools/build-banc-fin.py [source] [Rnnn]` : remplace seulement visuals.js et hero.js dans la page du Banc de la fin (annotation conservée). Publié au Banc de la fin. Le jeu garde R207.
- **R216 · Glacier et forge (16 oct.)** : Glacier = une seule boucle de glace autour du cyclone de glace (centre `GLC`, entrée et sortie tangentes en bas, plus de croisement poreux ni de pylônes), rail de glace du jeu (`VX.curve` matière 4), givre derrière les particules, la compagne suit en train. Fonderie = cascade écrite à la main : quatre rebonds rythmés de plaque en plaque (murs rebond du jeu, chauffés au choc), pointes du jeu au ras du bain ; creuset, ressorts, rivets et jets de flamme retirés ; 2,1 s au lieu de 1,1. **Livré dans le Banc de la fin d'origine (avec annotation)** : https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b — page de l'autre discussion conservée, seul le bloc `hero.js` remplacé (`studio/banc-fin.html`). Le jeu garde R207.
- **R215 · fin : base R213 reprise (16 oct.)** : Simon rejette R214 (« rendu cheap », planète et décors kitsch qui dénotent du jeu ; garde la vague) et veut les plans de la nouvelle discussion (escaliers à propulsion finale, magnétron avec rotation de caméra, cyclone de glace). `hero.js` = celui du banc R213 (fin5) + : Filaments = la vague R214 (les deux particules surfent la même impulsion) ; Gravité sans planète ni grille (zone Relativité du jeu `VX.gzone`, plafond et sol en murs du jeu, bascule de caméra ≈ 17°) ; sous chaque scène, le **fond animé du monde comme dans les niveaux** (`VX.back` dans une toile 2×, bords fondus, sans hélices ; pas au Magnétisme : le ferrofluide WebGL met 88 s à démarrer sans GPU) ; murs et lampes réagissent à la particule (`S.ball` posé pendant le dessin). Branchement : `QHERO.epilogue` passe par `fin5.render` si `window.QFIN_A` (le jeu garde R207). Le bloc R214 (`ZA`…) est retiré (copie : scratchpad `hero.R214.js`). Banc A republié (même adresse). Mesuré sans GPU : 20–50 ms/image sans le fond du jeu, ≈ 200 ms avec → **la fluidité sur iPhone est à juger dans le banc**. Notes de Simon dans la base du Banc de la fin (16 captures) lues : à traiter ensuite (Mécanique : les deux billes éjectées ; Glacier : courbe plus harmonieuse, sortie dans l'axe ; Fonderie : trop pauvre ; Chaîne : saut + obstacle à la réception ; danse : traînée qui saute).
- **R214 · fin, option A (16 oct.)** : diagnostic de la régression des bancs R210–R213 (lumière éparpillée en 4–8 petits éléments, deux particules qui font reculer la caméra, schémas au lieu d'objets, moteur à part corrigé par ajouts sur images fixes, jamais comparé au héros ; planche `heros_vs_fin.png`). Simon choisit **A** : la grammaire du héros, la compagne en invitée (Quantique, Faille, glace, Atelier). `hero.js` bloc R214 (`ZA`, `decoA`, `epChaseA`, export `chaseT`, `actsA`) derrière le drapeau `window.QFIN_A` → **le jeu garde R207**. Nouveau banc `tools/build-banc-finA.py` → `studio/banc-finA.html`, publié à part : https://claude.ai/artifact/SaibkuVYA4EjY9mZJMKGFf (héros et fin côte à côte, à la même seconde, ¼ ½ ×1, bouton « Jeu actuel (R207) »). Le Banc de la fin R210–R213 n'est pas touché (une autre conversation y publiait encore). Détail : `docs/NARRATION.md` § R214. Vérifié : captures de chaque acte + trois séquences en mouvement regardées, aucune erreur de page, tests audit/strict/tutotest/render/replaytest/savetest/maptest. Non vérifié : iPhone réel, œil de Simon. Pas de zip (jeu inchangé) : zip à l'intégration, après validation.
- **R210 · banc de la fin (15 oct.)** : saccade de la compagne diagnostiquée (copie retardée + filtre, saut à la couture de la Faille). Nouvelle chorégraphie à deux plans en profondeur avec caméra scriptée, DANS LE BANC SEULEMENT (https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b) : `studio/fin2.js`, `studio/banc-fin.tpl.html`, `tools/build-banc-fin.py`, détail `docs/FIN_DEUX_PLANS.md`. Le jeu (hero.js, engine.js) n'est pas modifié. Remplace la ligne G4 de la charte. Prochain : retours de Simon sur le banc, puis intégration dans hero.js, puis refonte du monde 7.

- **R209 — audit et reprise (15 oct.)** : `AUDIT_R209.md` (état, atouts/faiblesses, chantiers, dettes de code et de
  produit, objectifs CT/MT/LT, professionnalisation, monétisation, légal, public, génération de niveaux, charte, scénario,
  navigation, Quantone, outils, méthode, questions, décisions ; annexe des 132 niveaux) ; `CHARTE_EXIGENCES.md` (remplace
  `CONSIGNES_SIMON.md`) ; `LEXIQUE.md` ; `INDEX_DOCUMENTS.md` ; `METHODE.md` et `INSTRUCTIONS_PROJET.md` réécrits ;
  bannière « Statut R209 » sur tous les documents ; `ANNEXE_DESIGN_JONCTIONS.md` recopiée dans `docs/` ; nouvel outil
  `tools/preuve.py` (+ `preuve_ref.js`, option `n=N` de `bypass.js`). Le jeu ne change pas (tampon R209).


- Outils de tracé toujours visibles hors introduction (R122). Éditeur republié avec les niveaux actuels (clé `QED2:`).
- **Fonderie 6 « Ta plaque »** : serpentin dessiné par Simon, mis au propre (tube lissé, bonus rebond au virage droit), départ
  décalé à x = 40 — validé par Simon (R125).
- **Fonderie 12 « La fonte »** : esquisse de Simon rendue fonctionnelle (R126) : plaque du sol → tube en arche par dessous →
  plaque de relance → second tube → bassin perché en haut à gauche, abrité par un toit. Constance 89 %, ≈ 8 s, jouabilité
  indicative 37 %. Outils : scratchpad `m/tubes.js`, `m/m24d.js`, `m/g24.js` ; `tools/fiches/machines/fonte24.json`.
- **Chaîne 6 « Saut de chaîne »** (R128) : machine de sauts — tapis + tremplins + crochets tapissés qui cueillent le vol,
  trois sauts en zigzag ; le joueur pose le DERNIER maillon : un tapis dans le bon sens remonte la particule à la zone (structure
  et tapis à l'envers ne marchent pas). Constat physique : pas de looping possible en 2D, le tapis ne soulève pas à la verticale.
  Scratchpad `m/jump.js` → `tools/fiches/machines/chaine30.json`.
- **Chaîne 12 « La chaîne complète »** (R129) : VRAI LOOPING. Le joueur trace le maillon qui monte (tapis, sens imposé) ;
  la particule boucle tête en bas et traverse sa propre piste d'entrée grâce aux **pistes traversables** (moteur : champs
  `pass` et `pz` des courbes, `engine.js` curveExpand + collide). Proposition d'intégration : `docs/PISTES_TRAVERSABLES.md`.

- **R130 — repères de la paroi tunnel (W3N12 seulement, pour validation)** : la partie traversable d'une piste est
  marquée en bleu glacé #A9BCEB (gaine lumineuse, deux brins entrelacés qui ondulent = imbrication de la matière, bornes
  aux deux bouts ; les atomes s'écartent et un anneau s'élargit quand la particule passe). Fiche de didacticiel « Paroi
  tunnel » (FR/EN, démo : bille lente portée / bille rapide qui traverse). Poussière d'étoile (`lv.flow`, `VX.flow`) qui
  dérive du départ vers l'entrée de la machine. Noyau déplacé au sommet de la boucle (il masquait le croisement).
  Code : `visuals.js` tunnel/flow, `engine.js` (dessin), `tuto.js` (carte), `i18n.js`. **À étendre aux autres machines
  seulement après accord de Simon.**
- **R131 — poussière des machines (toutes)** : `lv.flow` = trajectoire de la solution dans la machine (+ courte amorce
  vers l'entrée), calculée par `node tools/flow.js 3 6 18 24 30 36` (à relancer si une machine change). `VX.flow` : grains à
  vitesses variées, les plus rapides laissent un fil, certains décrochent dans les virages serrés et filent tout droit.
  Fiche raccourcie : « Piste poreuse — lente, roule dessus ; rapide, passe au travers ». La piste poreuse n'existe qu'en 36.
  Aperçu : mondes 1 à 3 débloqués.
- **R132 — Atelier 12 « Le portail »** (remplace « L'établi ») : un mur poreux vertical coupe le terrain. Le joueur trace une
  rampe ; trop douce, la particule bute (vx < 4,5) ; assez raide, elle traverse et entre dans la machine « aiguille » : un tube
  qui coud la membrane trois fois (droite → gauche → droite) puis la traverse une dernière fois jusqu'au bassin abrité.
  Géométrie : scratchpad `m/p12.js` → `tools/fiches/machines/portail12.json`, `forge.json` clé `12_portail`. La fiche
  « Matière poreuse » apparaît ici pour la première fois. Mur entièrement poreux : dessiné seulement en gaine bleu pâle.
  Poussière plus dense (jusqu'à 280 grains, tailles et transparences variées, quelques halos).
- **R133** — Atelier 12 affiné : membrane courbe, parois du tube qui s'effacent dans la matière poreuse (ni nœud ni capuchon
  au contact, `visuals.js` jointsBuild), abri courbe du bassin, capot courbe à droite, zones interdites resserrées.
  **Glacier 6 « La piste glacée »** (remplace « La butée ») : tube de glace avec un vrai looping (croisement poreux `pz`,
  sans nœud), sortie lancée à pleine vitesse ; le joueur pose la butée derrière le bassin. Scratchpad `m/p42.js` →
  `tools/fiches/machines/luge42.json`, forge `42_luge`.
- **R134** — **Glacier 12 « Le pendule de glace »** (remplace « Le sérac ») : vasque de glace sans frottement, la particule
  s'y balance sans fin ; au fond, une fenêtre de glace poreuse (`pass` 6, `pz`) ne laisse passer qu'une chute franche ; dessous,
  entonnoir et tube de glace jusqu'au bassin. Plusieurs familles de solutions (≈ 3 % des traits au hasard gagnent : tremplins sur
  les flancs, déflecteurs). Scratchpad `m/p48e.js`, `g48.js` (recherche rapide) → `machines/pendule48.json`, forge `48_pendule`.
  Bouton retour du niveau → carte du monde (`engine.js` gBack). Aperçu : tous les mondes et niveaux ouverts
  (`build-apercu.py 4 11 skipintro`).
- **R135** — Outils **Échelle** et **Aimant** : dans le jeu (dock : `editor.js` mode `scale`, interrupteur `mag` mémorisé
  `QX_mag` ; l'encre suit la longueur, annulation prise en charge) et dans l'éditeur de niveaux (poignée carrée sous la forme,
  bouton ⊕, `QED_mag`). Éditeur republié.
- **R136** — retour du niveau → page illustrée du monde (`openWorld`). **R137 — Atelier 12 « La cellule »** (remplace « Le
  portail ») : cellule ronde de structure (r 88) percée d'un pore poreux (`pz`, `pass` 3.2) en bas à droite, bassin-noyau à
  l'intérieur, orbite concentrique (r 130) autour. La particule tombe dans l'orbite et oscille ; le joueur barre l'orbite juste
  après le pore : elle rebondit et traverse. Aucun raccourci depuis le haut (recherche). Scratchpad `m/c12.js` →
  `machines/cellule12.json`, forge `12_cellule`. 
- **R138 — Soufflerie 6 « La cascade inversée »** (remplace « Vent et plafond ») : une colonne d'air (vent −1,3) entre deux
  parois de verre ; cinq plafonds en zigzag que la particule remonte comme l'eau descend un escalier ; en haut, une crosse la
  rejette à gauche vers le bassin. Le joueur la fait entrer par le bas (rampe sous la paroi droite). ≈ 6,5 s. Scratchpad
  `m/w54.js`, `run54c.sh` → `machines/cascade54.json`, forge `54_cascade`.
- **R139 — Soufflerie 12 « Le cyclone »** (remplace « La veine ») : tambour de structure (r 90) parcouru par un tourbillon
  (quatre champs tangents, invisibles : 7ᵉ valeur = 1) dessiné en spirale (`lv.vortex`, `VX.vortex`) ; la particule y tourne
  sans fin au‑dessus d'une fente ; le joueur glisse une lame qui l'arrache vers l'entonnoir et le bassin. Scratchpad `m/v60.js`
  → `machines/cyclone60.json`, forge `60_cyclone`. Essai d'entrée tangentielle en spirale abandonné (trajectoire chaotique).
- **R140** — Soufflerie 6 recomposée (vase de verre courbe, plafonds détachés des parois — plus de nœuds —, colonne d'air
  dessinée en filets montants `lv.updraft`/`VX.updraft`, champ de vent caché). **Mécanique 6 « L'escalier mécanique »** :
  quatre marches mobiles dorées en contretemps (`mov` avec `ph` phase, `v` vitesse transmise à la balle, `ck` bielle à
  coulisse dessinée `VX.yoke`) alternent avec des paliers fixes : la particule monte seule ; le joueur la pose sur la
  première marche. **Mécanique 12 « L'échappement »** : boîtier d'horloge en arche, balancier et ancre (`lv.pend`,
  `VX.pendulum`), palettes coulissantes (`pl`) qui libèrent un palier par battement ; le joueur jette un pont au‑dessus du
  fond mortel. Moteur : `moverSeg` (phase, vitesse) et `collide` (vitesse relative) — sans effet sur les anciens niveaux
  (options absentes). Zones nettoyées : 48 (bout du tube retiré, lèvre à droite du bassin), 60 (entonnoir raccourci).
  Scratchpad `m/s66.js`, `m/e72.js` → `machines/escalier66.json`, `echappement72.json`.
- **Leçon (Simon, 10 oct.)** : le cyclone est le modèle — un concept fort ET une esthétique singulière qui sert le jeu
  (dessin dédié de la mécanique : tourbillon, filets d'air, bielles, balancier). À systématiser. Éviter la redondance des
  cercles et des échelles de plafonds.
- **R141 — Didacticiel harmonisé** : les fiches d'éléments physiques (zone interdite, pointes, rebond, élan, poreux, glace,
  vent, gravité, aimant, portail, paroi mobile) ne sont plus chorégraphiées à la main : chaque scène est décrite en données
  (`tools/tuto-scenes-src.js`, repère 232 × 104), simulée par le vrai moteur (`node tools/tutoscenes.js` → `assets/js/
  tuto-scenes.js`, `window.TSC`) et rejouée par un lecteur unique (`tuto.js` `scene()`) : le doigt trace, la bille part, elle
  suit la trajectoire calculée, pause. Même rendu que le jeu (murs, courbes, filets d'air, poreux). Restent dessinées à la main :
  outils (gestes), puces de matière, éléments quantiques (intrication, superposition, détecteur, dilatation) et bille molle.
  Pour ajouter/modifier une fiche : éditer la source, relancer le générateur.
- **R142 — Gravité 6 « La fronde »** : une planète (`lv.well=[x,y,m,r]`, attraction m/d² dans `engine.js` fields, noyau de
  structure) au milieu ; la toile de l'espace se creuse autour (`VX.well`, grille déformée violette + niveaux d'énergie).
  Le joueur vise à côté de la planète, sa gravité courbe la fin de la trajectoire vers le bassin (≈ 1 % des traits au hasard).
  **Gravité 12 « Relativité »** (Escher) : zones à leur propre bas (`grav` 7ᵉ valeur = 1, `VX.gzone` : lignes d'horizon
  perpendiculaires à la pesanteur locale + fil à plomb) ; la particule roule vers la droite, le joueur trace sur la paroi de
  droite une pente qui « descend » vers le haut, elle file au plafond, une crosse la rend au bassin central. Pas de poussière
  d'indice sur ces deux niveaux (elle révélerait la solution). Scratchpad `m/g78.js`, `m/r84.js`.
- **R143 — Magnétisme 6 « Les états de bord »** : champ magnétique uniforme (`lv.bf=[x,y,w,h,B,vide?]`, force de Lorentz :
  la vitesse tourne sans changer de valeur ; `VX.bfield` : trame ⊙/⊗ qui respire). Avec la pesanteur, la particule fait des
  cycloïdes qui dérivent de côté ; le joueur dresse un bord : elle le longe en sautillant (orbites rasantes, les « états de bord »
  de l'effet Hall quantique) jusqu'au bassin. **Magnétisme 12 « Le cyclotron »** : deux « D » sous vide (`bf` 6ᵉ valeur = 1)
  et une fente accélératrice (`lv.kick`, poussée dans le sens de la course, `VX.kickgap`) ; la particule part de la source au
  centre et s'enroule en spirale de plus en plus large ; le joueur place le déflecteur d'extraction vers le bassin
  (≈ 0,7 % des traits au hasard). ≈ 13 s. Scratchpad `m/b90.js`, `m/c96.js`.
- **R144** — Gravité 6 : planète plus grosse (noyau r 34) et poussière. Gravité 12 refaite d'après le croquis de Simon :
  plafond en arc gracieux plus bas, zone du haut agrandie (x 120–360, y 0–140), colonne de droite élargie → bien plus
  facile (15 pentes sur 18 gagnent) ; zones « Relativité » plus visibles (teinte, bas local éclairé, contour pointillé).
  **Faille 6 « L'élan transmis »** : failles orientées (`port` 5ᵉ/6ᵉ valeurs : angle de sortie, 1 = absolu) ; ce qui tombe
  dans la faille du fond ressort à l'horizontale aussi vite ; le joueur choisit la hauteur de plongée (un trait dans le puits).
  Bouches dessinées en « corral quantique » (`VX.rift` : anneau d'atomes, onde stationnaire, chevrons de sortie).
  **Faille 12 « L'univers torique »** : bords gauche et droit recousus (`lv.wrap=[y0,y1]`, coutures `VX.seam`, éclair aux deux
  bords) ; la particule descend une hélice de quatre tours qui traverse la couture ; le joueur la fait sortir à droite pour
  qu'elle entre à gauche dans le bassin abrité. `slotwrite.py` écrit désormais `port` et `wrap`.
- **R145 — Filaments (monde 10) réordonné** à la demande de Simon : anciens 2–6 → 1–5, anciens 8–12 → 7–11 ; les anciens 1 et
  7 sont remplacés par deux machines aux **cordes élastiques** (`lv.elastic` : rebond des cordes du joueur, 0,86 ≈ 65 % de la
  hauteur ; `lv.strings=[[x1,y1,x2,y2]]` : cordes tendues du décor, `lv.strE` ; dessin `VX.harp`). **Filaments 6 « La harpe »** :
  trois cordes, il en manque une ; le joueur la tend au bon endroit (9 placements sur 16 gagnent). **Filaments 12 « La toile
  élastique »** (renommée : « Le trampoline » existe déjà au monde 2) : la particule tombe sur une corde tendue presque à plat ;
  le joueur tend la seconde corde qui la relance jusqu'au bassin perché. Colonne non traçable à gauche (`nd` x < 110) : sans
  elle, une corde sous la chute gagnait sans la corde du décor (raccourci). Sans la corde du décor : 0 gagnant sur 5 730 traits ;
  14 familles ; P_exec 63 % (sous les 70 % visés), noyau pris 52 %. Le bouton Fermer de la constellation ramène à l'accueil.
- **R146 — Filaments 6 et 12 refaits en vraies machines** (Simon : la harpe et la toile « ne font pas machine »).
  Moteur : cordes du décor **entraînées** (`strings` : `[x1,y1,x2,y2, amp, vitesse, phase, bout(0 les deux), wv, dx, dy]` ;
  `wv` > 0 = fronde : tension lente pendant la fraction `wv` du cycle puis détente brusque ; `dx,dy` = axe de traction) ;
  vitesse d'entraînement transmise à la balle au contact ; `lv.sling={z:[x,y,w,h],amp,spd,ph,wv,d:[dx,dy],e}` : une corde du
  joueur dont les deux bouts sont dans la zone devient l'élastique d'une fronde. Visuels : `VX.harp` (la corde frappée vibre sur
  le mode dont le ventre est au point d'impact, nœuds marqués), `VX.fork` (`lv.fork` : diapason de Melde, élastiques qui
  rougissent à la tension, onde de choc à la détente ; `player:1` = fronde vide en pointillé).
  **Filaments 6 « Le lance-pierre »** : la bille roule dans la poche, le diapason tire, l'arc retombe sur la rampe et revient
  dans la poche — boucle perpétuelle stable (période 140 images) ; le joueur coupe la boucle avec une corde pour l'envoyer dans le
  bassin de gauche. Fronde immobile : 0 gagnant sur 1 460 ; famille de référence 97 % au doigt.
  **Filaments 12 « Le relais des frondes »** : deux diapasons se passent la bille en zigzag montant ; le joueur tend la
  troisième fronde (zone `sling`) : il faut une POCHE (trait en V) — 0 bande droite gagnante sur 415, 0 trait hors fronde sur
  2 965, 0 poche inerte ; ≈ 8 s ; jouabilité au doigt 50–83 % selon la poche (référence ≈ 77 %).
- **R147** — Outil Échelle : le rond central déplace la ligne, plus de poignée de rotation (textes fr/en mis à jour).
  **Texture de fond** (tous les mondes sauf la Chaîne) : plus aucune sphère (globes et coquilles de points retirés) ; trois
  nappes de fils de soie très fins dont les angles diffèrent → moiré qui glisse, trois familles de transparence, grain d'étoiles
  (`vlSilk`, `vlSilkDraw`, `vlGrainDraw` dans `visuals.js`) ; hélices deux fois plus petites et plus fines.
  **Magnétisme 6 « Le canon de Gauss »** : nouvel élément `lv.coil=[[x,y,ax,ay,portée,force,(vide)]]` (bobine qui tire la
  particule vers son centre le long de l'axe puis se coupe, `VX.coil` : spires, lignes de champ, flèche quand elle s'allume).
  Quatre bobines lancent la particule dans un J, puis dans le champ magnétique (`bf`) où elle sautille en cycloïdes jusqu'au mur
  gauche et retombe dans le canon : boucle perpétuelle autour du bassin ; le joueur la fait tomber au cœur. Zone de machine
  invisible (`mz`) sur la descente de gauche (sinon une rampe directe gagnait). Bobines coupées : 0 gagnant sur 7 350 ;
  au doigt 87–100 %.
  **Magnétisme 12 « Le spectromètre »** (Aston 1919) : trois colonnes au‑dessus du canon (5, 4 ou 3 bobines à franchir) ;
  la vitesse fixe le rayon du demi‑cercle dans la chambre sous vide (collimateur vertical, champ au‑dessus d'une bande de
  pesanteur pour que la particule se pose) ; orbites de référence en pointillé et raies sur la plaque (`lv.spectro`,
  `VX.spectro`). Défaut : colonne de droite → trop lent. Bobines coupées : 0 gagnant ; référence 60 % au doigt (sous 70 %).
- **R148** — Texture de fond étendue à TOUS les mondes (la Chaîne aussi) : cinq nappes de fils (maille 4 à 24 u, cinq
  opacités) + grain dense + **mycélium de lumière** (`myBuild`/`myDraw` : réseau de capillaires qui pousse depuis les bords,
  dessiné une fois dans un calque ; des éclats partent des racines, se divisent aux fourches et laissent une traînée qui
  s'éteint). **Magnétisme 6** : looping après trois bobines (rail guidé `look:'track'` dessiné comme une courbe, capture
  seulement si la vitesse ≥ `vmin` = 10 → bobines coupées : 0 gagnant sur 10 506) ; bassin déplacé [96,372,92] ; 241 traits
  gagnants sur 3 480 ; référence 100 % au doigt ; noyau au sommet du J (le rail ne ramasse pas le noyau).
- **R149** — Texture du Magnétisme refaite d'après la vidéo de ferrofluide de Simon (`ferro2`) : plus de goutte/bulle ;
  cinq plages qui dérivent, de tailles et de finesses différentes (cellules fines, moyennes, grandes) ; rendu en veines
  connectées (champ f2−f1 sur grille 96×128, graines rangées par cases, image lissée) + contours fins ; éclats rares qui
  suivent les parois (`fvSparks`), un sur cinq finit en rouge/orangé/pourpre (`WARM`). Mycélium de tous les mondes : plus fin
  (traits 0,42 u, alpha divisé par deux), plus régulier, éclats rares (≈ 1 toutes les 1,5 s, 6 au plus), plus doux, un sur
  cinq vire au chaud.
- **R150** — Simon préfère la texture discrète des niveaux 6 et 12 du Magnétisme : labyrinthe atténué partout (veines 0,2,
  contours 0,38/0,42). Éclats rendus perceptibles (mycélium : ≈ 1 toutes les 0,6 s, 9 au plus ; parois : 8 au plus, plus
  lumineux). Zones de champ magnétique (`VX.bfield`) lisibles : voile rose qui respire, bande de lumière qui balaie, liseré
  en pointillé, coins marqués, symboles ⊙/⊗ plus nets.
- **R151** — Magnétisme : labyrinthe plus présent (veines 0,34, contours 0,6) ; plus aucune bille qui flotte (gouttelettes
  et poussière du ferrofluide retirées) ; mycélium coupé dans ce monde. **Flux d'énergie** (`fvFlow`) : une impulsion naît
  sur une veine (crête du champ f2−f1), suit la crête de case en case, se ramifie aux carrefours, laisse une traînée lissée ;
  une sur cinq glisse vers rouge/orangé/pourpre. Même rendu sur les 12 niveaux du monde (vérifié en planche).
- **R152** — Captures de Simon : le niveau 4 (sans mur) montrait des cellules très marquées, le 12 (beaucoup de murs) presque
  rien, car `ffClear` effaçait la texture à 46 u de chaque mur. Désormais : effacement seulement à 6–28 u des pièces et jamais
  sous 35 % ; contours atténués (0,4 / 0,36). Planche 1, 4, 6, 12 : même densité.
- **R153 — RÉGRESSION CORRIGÉE.** En R147–R148 j'avais appliqué à tout le jeu une demande qui visait le Magnétisme : voiles en
  volume de chaque monde remplacés par une nappe de fils, hélices réduites, réseau capillaire partout. Rétabli : voiles 3D,
  hélices et hélice fantôme comme en R146 ; réseau capillaire retiré (le Magnétisme garde ferrofluide + flux + soie). Ajouts :
  nouvelles formes de voiles par monde (galaxie spirale, nœud de trèfle, réseau cristallin, solénoïde : Soufflerie disk/cyl,
  Mécanique lattice/torus, Gravité disk, Faille et Filaments knot, Quantique lattice/tetra) ; chaque niveau compose ses voiles
  autrement (position, taille, ordre, sens). **Mécanique décorative** (monde 6, `D.mech`, `mechDeco`) : trains d'engrenages
  engrenés, bielle‑manivelle sur glissière, échappement à ancre, came et poussoir, posés hors des pièces de jeu, 4 par niveau.
  **Leçon : une remarque sur un monde ne s'étend jamais aux autres sans le dire.**
- **R154** — Bruit de vent persistant (musique) : les bruits continus du monde 1 (chœur d'air, grondement, frottement de
  `W1N`) gardaient leur dernier volume quand on quittait le niveau (menu, constellation, autre monde). `W1N.hush()` les
  ramène à 0 dans l'état menu et hors du monde 1 ; `W1N.bar` ne joue rien en menu ; constellation et page du monde passent
  la musique en état menu. Ligne de diagnostic du son retirée de l'accueil.
- **R155** — Tracés du joueur en rebond (1) et accélérateur (3) dessinés avec `VX.curve` comme les pièces du niveau (fin, lumineux) au lieu des planches épaisses `plate`/`boostPad`.
- **R156 — Monde 11 Quantique, apothéose (en cours)** :
  - Éléments quantiques redessinés (`visuals.js` : `VX.qent/qgate/qsup/qdet/qtdil`, couleurs par paire `QCOL`) :
    qubit = sphère de Bloch + flèche de spin ; lien en double hélice entre les deux qubits d'une paire (signe = / ≠), fils
    pointillés vers les portes qu'elle commande ; porte fermée = barrière de champ, ouverte = fantôme pointillé ; séparateur =
    losange + franges ; détecteur = diaphragme, armé seulement quand une branche existe, fil vers la paire `d[3]` ; dilatation
    = cadran d'horloge.
  - Moteur : la branche MESURÉE devient la particule réelle ; `det[3]` = rang de la paire basculée par la mesure ; champ `bf`
    7e valeur `'atom'` (halo, orbites, noyau).
  - **126 « L'interféromètre »** : deux chemins qui basculent chacun la paire → la porte reste fermée ; il faut boucher un
    chemin. Sans trait : échec ; solution : réussite + noyau.
  - **132 « Quantix » (finale du jeu)** : particule en orbite fermée dans un « atome » magnétique, séparateur → deux orbites,
    la mesure rend la branche réelle et ouvre la porte intriquée ; le joueur éjecte la particule par un trait de rebond →
    entonnoir, ralenti, porte, bassin. Sans trait : orbite sans fin ; solution : réussite (≈ image 137) + noyau ; 19 % des
    traits de rebond essayés gagnent. Hélices de décor retirées sur ce niveau.
  - **Fin du jeu** : `VX.finale` — onde depuis le bassin, 11 fusées aux couleurs des 11 mondes, constellation des mondes,
    « Félicitations » + sous-titre (i18n `finTitle`, `finSub`, `completeSub`), panneau de résultat retardé de 7,6 s.
  - **Constat** : les solutions de référence de 122–125 et 127–131 échouent (déjà vrai en R155) → ces niveaux sont à refondre.
- **R157 — Magnétisme 1, 2, 7 refaits de zéro** (Simon : 1–4 et 7 « beaucoup trop similaires ») :
  - **85 « La lentille »** (attracteur) : on dévie la particule dans un grand champ qui la recourbe jusqu'au bassin.
    Éditeur 92 %, doigt 60 %, 0 gagnant sans l'aimant. Zone de tracé limitée (`mz`) au champ.
  - **86 « La feuille d'or »** (Rutherford) : nouveau **répulseur** (`mag` à force négative, rendu cyan, grains et ondes qui
    partent du cœur, `engine.js`). Bassin sous un toit : on pousse doucement la particule au bout du toit, le noyau la renvoie
    dessous. Éditeur ≈ 80 % (68–87 % selon le tirage), 0 gagnant sans le noyau.
  - **91 « Le cyclotron »** (Lawrence 1931) : tube d'injection en glace traversable (`curves` m:4, pass:3), champ en vide,
    fente accélératrice (`kick`, inutilisée jusqu'ici) → spirale qui grandit jusqu'au rayon final ; le joueur pose le
    **déflecteur d'extraction**. Sans trait : orbite sans fin (échec à 20 s). Solution ≈ 15 s ; éditeur 82 %, doigt 72 %.
  - **Non faits : 87 et 88 (niveaux 3 et 4)** — essais abandonnés (demi-tour dans le champ, ricochet, dérive g×B, dipôle) :
    trop fragiles ou contournables. Pistes : dérive en boucles (spectaculaire), dipôle attracteur + répulseur.
  - Les niveaux 89, 92–95 suivent encore l'ancien gabarit (aimant au centre, bassin en bas à droite) — non demandés.
  - Prototypes : scratchpad `mg/` (`mg.js` banc, `tune.js`, `fam.js`, `dr.py`).
- **R158 — Contournements** (Simon : « trop facile d'éviter la difficulté », photos Quantique 2 et Filaments 7) :
  - Détecteur `tools/contournements.js` → `docs/AUDIT_CONTOURNEMENTS.md` : **88/132 niveaux** se gagnent d'un trait sans toucher
    aucun élément. Liste classée, à traiter par lots.
  - Corrigés : **122 Opposition** (plancher plein, portes = seuls passages, une seule bascule ; deux = refermé), **112 La balle
    molle** (étagère pleine + entonnoir sur la fente), **115 Molle et lame** (fente puis pointes : 2e trait de rattrapage),
    **100 Portail et mur** (plafond plein, l'élan traverse la faille). Éditeur 70–100 %, 0 victoire nue.
  - **Balle molle** : la compression dans une fente n'avait jamais fonctionné (liens de flexion trop raides) → souplesse par niveau
    (`softball:0.15`, `engine.js`) ; rendu en nuage de points étiré selon la déformation (`VX.softball`).
  - Reporté : 65 Le pendule (ni toit ni barre ne changent l'issue → refonte), puis le reste de la liste.
- **R159 — Contournements, lot 2 (Faille)** — consigne Simon : chaque niveau renforcé gagne un mouvement, une particularité,
  de l'élégance, comme les 6 et 12 :
  - **98 « À travers le mur »** (ex-Portail court) : mur plein, la faille le perce, la parabole se prolonge de l'autre côté.
    Éditeur 83 %, doigt 55 %.
  - **99 « Le geyser »** (ex-Portail montant) : la particule tombe seule dans la faille (rotation 180°) et jaillit plus haut que
    son départ ; le joueur pose le déflecteur qui envoie le jet dans la loge perchée. Éditeur 100 %, doigt 88 %.
  - **103 « La sarbacane »** (ex-Portail et lame) : faille à 90°, une chute droite devient un tir horizontal à travers une
    galerie de lames inclinée vers la chambre du bassin ; on la fait longer le mur pour qu'elle tombe droit. Éditeur 93 %.
  - Tous : 0 victoire nue, 0 gagnant sans la faille. Reportés : 105 Aller-retour, 106 Faille interdite, 65 Le pendule…
- **R160 — lot 3** : **106 « La couture »** (ex-Faille interdite) : faille du centre → réapparition au fond d'une poche
  fermée → roule dans la 2e faille → loge du bassin. Éditeur 85 %, 0 victoire nue.
  - **Essais abandonnés** (limites du moteur à connaître) : (a) « Le bac » pour 70 L'horloge — une barre mobile en diagonale
    porte bien la balle si elle tombe dessus, mais l'embarquement est trop rare (0–4 gagnants), et une barre qui MONTE à travers
    un plancher ne soulève pas la balle (elle passe au travers) ; (b) `pend` (pendule) n'est qu'un DÉCOR, sans physique →
    pas de « marteau » possible pour 65 Le pendule sans écrire une mécanique. Reste à faire : 65, 70, 105 Aller-retour.
- **R161 — Pendule actif + lot 4** :
  - **Moteur** : `pend=[px,py,L,spd,amp,ph,actif,rayon,restitution]` ; `pend[6]=1` → la masse frappe la particule et lui transmet
    sa vitesse (`pendHit` dans `stepBranch`, même calcul que le dessin) ; masse dessinée pleine (`VX.pendulum`). Plusieurs
    pendules possibles. Sans `pend[6]` : décor inchangé (L'échappement).
  - **65 « Le pendule »** : amener la particule au creux de l'arc ; le marteau la frappe, elle grimpe un tremplin jusqu'à un
    bassin plus haut que le départ. Éditeur 87 %, 0 gagnant sans le marteau.
  - **41 « La combe gelée »** (ex-Glace interdite) : un val de glace (la glace ne freine pas) ; posée en douceur sur le rebord,
    la particule remonte jusqu'au bassin perché ; un impact brutal fait perdre l'énergie. Éditeur 97 %, 0 gagnant en piste
    ordinaire.
  - **Détecteur corrigé** : seuil de contact R+5 (au lieu de R+3, plus petit que la distance d'une balle qui roule) →
    **51 niveaux** restent contournables, pas 88. `docs/AUDIT_CONTOURNEMENTS.md` réécrit.
  - Abandonnés (limites, voir l'audit) : Corde tendue en trampoline, Verglas en double val, L'horloge en bac.
- **CONSIGNE DE MÉTHODE (Simon, 12 oct.)** : ne plus abandonner une idée après un long travail. Quand une idée ne tient pas,
  la RETRAVAILLER jusqu'à satisfaction en élargissant la palette (modifier le moteur, ajouter un élément, changer la géométrie,
  combiner des mécaniques) plutôt que de passer à une autre : chaque abandon gaspille le calcul déjà dépensé. Idées en suspens à
  reprendre ainsi : Corde tendue (trampoline), Verglas (double val), L'horloge (bac), Magnétisme 3 et 4, Faille 9 ; Glacier 5
  (combe gelée) jugé beaucoup trop facile.
- **R162 — idées reprises jusqu'au bout (consigne Simon)** :
  - **Moteur** : (1) glace sans perte — sur une courbe de glace (non traversable), un contact rasant (< ~20°) réoriente la
    vitesse sans la diminuer ; un choc franc reste amorti ; (2) adhérence des pièces mobiles `m.grip` (0–1) : la balle suit la
    plateforme (bac porteur) ; (3) cordes réglables par niveau `ropeIter` (raideur) et `ropeDamp`.
  - **41 La combe gelée** durcie : départ au centre, loge du bassin fermée (fente au ras du rebord), bassin à la limite de
    l'énergie : une longue rampe (qui freine) échoue, un court tremplin (vol libre puis glace) réussit. Éditeur 97 %, doigt 72 %,
    intention 38 % (au lieu de 70 %).
  - **46 Verglas** : deux vals de glace et une crête ; marche descendante à l'entrée de la loge ; lèvre de glace allongée.
    Éditeur 93 %, doigt 52 %, 0 gagnant en piste ordinaire.
  - **70 L'horloge** : la particule part posée sur le bac (barre mobile `grip` 0,6) qui fait la navette au-dessus du vide ; le
    joueur pose un butoir au-delà de la portée de la barre, qui se dérobe et lâche la particule dans le bassin. Éditeur 100 %,
    doigt 90 %.
  - **109 Corde tendue** : trampoline — corde du joueur raide (`ropeIter` 10) et sur-élastique (1,25), mur à franchir, murs de
    fond. Éditeur 68–76 %, doigt 80 %.
  - **48 Le pendule de glace** (régression causée par la glace sans perte, réparée et améliorée) : départ posé sur la courbe,
    zone poreuse ±80, seuil 4,5. Éditeur 63–70 % (35 % avant R162) — encore un peu sous 70 %.
  - Détecteur : échantillonnage à chaque image + seuil R+9 (plaques orange plus épaisses) → la Fonderie n'est plus faussement
    signalée.
- **R163 — zones de Pauli + Magnétisme 3 et 4** :
  - **Rendu des zones interdites (idée : principe d'exclusion de Pauli)** : une zone interdite est une région déjà pleine —
    chaque place y est occupée par une paire d'états (spin haut / spin bas), rien d'autre ne peut s'y loger. Rendu
    (`visuals.js` `nd()`) : voile rose-rouge très léger, réseau hexagonal de paires de points liés qui tournent en sens
    opposés, onde lumineuse lente, liseré et deux pulsations qui ne courent que sur les bords exposés (jamais entre deux
    zones accolées) ; un trait refusé (`S.ndHit`, `engine.js`) envoie une onde de refus et un anneau au point touché.
    15 niveaux passent de la zone invisible `mz` à la zone visible `nd` (L'horloge, La lentille, La feuille d'or, La dérive,
    Le cyclotron, À travers le mur, Le geyser, Portail et mur, La sarbacane, La couture, Opposition, Le pendule, La combe
    gelée, Verglas, Corde tendue) — les 132 solutions de référence réussissent toujours.
  - **87 La dérive** (Magnétisme 3) : éditeur 72 %, doigt 80 %, 0 gagnant sans champ.
  - **88 Le dipôle** (Magnétisme 4, remplace « Deux aimants ») : la particule tombe sur un toit plat que le répulseur cyan
    fait rouler À RECULONS, chute dans l'attracteur rose qui l'enroule en crochet jusqu'au bassin. Trop vite → elle est
    capturée en orbite sans fin. Balayage : 169 gagnants avec les deux aimants, 0 avec le répulseur seul, 0 avec
    l'attracteur seul, 0 sans aimant. Solution de référence : éditeur 93 %, doigt 47 %. Noyau (198,428) au creux d'un
    crochet serré : réservé aux lâchers très doux (≈ 25 % des solutions, éditeur 35–65 %), la solution de référence ne le
    prend pas.
  - Magnétisme 1, 2, 3, 4 et 7 sont désormais tous refaits (demande de Simon sur la redondance).
- **R164 — spins agrandis + Soufflerie 4** :
  - Zones de Pauli : motifs agrandis pour l'écran de téléphone (maille 15 → 22, points 1,15 → 1,8, écart de la paire ×1,6),
    demande de Simon.
  - **52 Colonne étroite** refaite (était contournable : 28 gagnants « nus » sur 35). La particule part plus BAS que le bassin :
    sans le courant, aucune énergie ne permet d'y monter (contournement impossible par construction : 0 gagnant sans vent).
    Le courant est mince : une particule qui le traverse en roulant n'est presque pas soulevée. Idée : poser une BUTÉE dans la
    colonne pour que la particule s'y attarde ; elle monte alors contre la butée jusqu'au plafond incliné qui la verse dans
    le bassin. Un seul trait droit : 11 gagnants sur 17 430 (fragile) ; rampe + butée : 60/60 perturbés. Éditeur 100 %,
    doigt 82 % ; noyau (210,286) au ras de la butée dans la colonne : éditeur 97 %, doigt 63 %. Un trait libre en « J »
    est une deuxième famille.
  - **93 Orbite** (Magnétisme 9) — essais NON aboutis, consignés pour reprendre : (1) fronde vers un bassin perché : impossible,
    l'énergie ne suffit pas ; (2) capture puis sortie par un trait : la capture vient du plafond de vitesse VMAX (dissipatif),
    la particule capturée n'a plus l'énergie de ressortir ; (3) zone de tracé réservée à l'intérieur de l'orbite (aucun
    contournement possible sans aimant) : 81 gagnants mais jouabilité 30–45 % (régime chaotique : aimant 1,5 → tout gagne,
    1,8 → tout est capturé) ; (4) coup de pouce rebond / élan dans l'orbite : la sortie part dans toutes les directions.
    Piste suivante : apesanteur locale (`grav` qui annule la pesanteur) pour de vraies orbites conservatives, ou un
    entonnoir de sortie.
  - Note : la solution de référence du Dipôle (88) ne prend pas son noyau (choix délibéré, voir R163) ; à revoir si le
    test du monde 8 l'exige.
- **R165 — ESSAI de rendu « fluctuations quantiques du vide » pour les zones interdites** (document de Simon) :
  - `visuals.js` : `nd()` aiguille selon `ND_MODE` ('vide' par défaut ; 'pauli' rétablit R163/R164, fonction `ndPauli`).
    Rendu `ndVac` : voile rose très léger ; paires matière (rose-rouge) / antimatière (blanc rosé) qui naissent au hasard
    par cellule (Poisson éclairci, sans état), s'écartent puis se rejoignent en accélérant et s'annihilent dans un
    micro-éclair ; plus la paire est énergique, plus elle s'écarte et moins elle vit (ΔE·Δt ≥ ħ/2). Frontière vibrante
    (somme de sinus) et lueur intérieure tracées seulement là où la zone touche l'espace libre (test point par point —
    corrige aussi les côtés à moitié exposés) et jamais sur le cadre. Trait refusé : une antiparticule jaillit, rejoint la
    pointe du trait, deux photons partent dos à dos (e⁺e⁻ → 2γ) avec une onde de choc.
  - Fiche du didacticiel `td_nd` réécrite (FR/EN) : le vide bouillonne, ton trait n'y survit pas.
  - **Écart avec le document** : dans Quantix, la zone interdite refuse le TRAIT ; la particule la traverse librement
    (plusieurs niveaux en dépendent : Le dipôle, L'horloge, La lentille…). La rendre mortelle changerait la règle de 15
    niveaux ; l'annihilation est donc appliquée au trait refusé. La mort de la particule existe déjà (matière « danger »).
- **R166 — zones du vide retravaillées + banc des rendus** (consignes Simon : la zone reste interdite au tracé seulement) :
  - Paires : petits éclairs brisés de deux couleurs opposées (rose-rouge matière, cyan antimatière) qui errent par des routes
    imprévisibles (angle et vacillement tirés par paire), avec une traînée, avant de se rejoindre en un point qui a dérivé et
    de se déliter en poussière d'étoile (9 grains, trois teintes). `visuals.js` `ndVac`.
  - Trait tenté dans la zone (`engine.js` : `S.ndg`, `S.ndgCur`, pointeur) : il s'affiche ~0,25 s en tremblant, blanchit,
    puis se délite en sable cosmique qui tombe et disparaît (~1,2 s) — `VX.ndDust`. Sortir de la zone reprend un trait normal.
    L'encre n'est pas consommée.
  - **Nouvel artefact « banc des rendus »** : tout rendu passe par lui avant validation. Source `studio/galerie-rendus.tpl.html`,
    construit par `python3 tools/build-galerie.py` (inline `visuals.js`) → `quantix-galerie-rendus.html`. Les deux rendus de
    zone (vide, Pauli) y tournent avec un trait de démonstration toutes les 5 s, et on peut y tracer.
  - Dans le jeu (zip) : le rendu du vide et le trait qui se délite sont ACTIFS (`ND_MODE='vide'`), mais marqués à valider ;
    `ND_MODE='pauli'` rétablit l'ancien.
- **R167** : rendu « fluctuations du vide » et trait qui se délite **validés par Simon** et gardés dans le jeu (`ND_MODE='vide'`).
- **R168** : (1) BOGUE corrigé — en R166 l'appel `VX.ndDust` avait été inséré entre le `if` du rendu des zones et son `else`,
  si bien que l'ancien hachurage de secours s'affichait aussi dans le jeu (signalé par Simon) ; (2) paires du vide en
  « comètes » : tête brillante, queue brisée qui suit la route réellement parcourue et s'efface vers l'arrière, lueur légère
  dans la traînée, longueur propre à chaque particule (0,7–1,6 ×).
  - Niveaux en cours d'étude (non intégrés) : 117 Le filet (corde-filet qui cueille une chute rapide vers un socle sans
    rebords : 24 gagnants corde contre 9 structure dans l'essai f2 ; à durcir), 68 L'engrenage (barre porteuse + plaque :
    pas encore de version qui tient). Audit relancé : les niveaux 13, 17, 20 ne sont plus contournables ; restent surtout
    117, 129, 68, 111, 63, 67, 101, 116, 123, 71, 95, 97, 130, 59, 104, 124.
- **R169 — texture du Magnétisme, À VALIDER (pas active dans le jeu)** : les « bords » que Simon voit sont les contours des
  cellules du ferrofluide (`ferro2` : ombre portée + trait coloré + liseré clair, et la bande nette des veines). Interrupteur
  `VX.ffSoft(doux, sansSoie)` (`FF_SOFT`, `FF_NOSILK`, défaut false) : en doux, aucun contour, veines seulement floutées
  (3,5 px et 11 px) ; « sans soie » retire aussi les fils fins (`vlSilkDraw`, monde 8 seulement). Banc des rendus : bouton
  Doux / Doux sans soie / Actuel, et six niveaux (1, 2, 3, 4, 6, 12) avec le vrai fond du monde. Pour activer : mettre
  `FF_SOFT=true` (et `FF_NOSILK` selon le choix de Simon).
- **R170 — texture du Magnétisme REFAITE DE ZÉRO, À VALIDER (pas active)** : demandes et références consignées dans
  `docs/TEXTURE_MAGNETISME.md`. Nouveau rendu `ferro3` (veines de lumière calculées à 1 u, aucun contour, halo sans filtre,
  deux états fondus, impulsions sur les crêtes, sans fils de soie dans ce monde). Interrupteur `F3_ON` (faux) ; banc des rendus :
  Nouveau / Actuel sur six niveaux. L'essai R169 (`FF_SOFT`) est abandonné (jugé pixelisé).
- **R171 — texture du Magnétisme : SIMULATION Gray‑Scott en WebGL 2 (`ferro4`), À VALIDER (pas active)** : voir
  `docs/TEXTURE_MAGNETISME.md` §5. Interrupteur `F3_ON` (faux) ; banc des rendus : Nouveau / Actuel.
- **R172 — ferrofluide vivant VALIDÉ et ACTIF dans le jeu** : attiré par les aimants et bobines du niveau selon leur force,
  couronne autour des répulseurs, gouttelettes de tailles variées en bordure (`docs/TEXTURE_MAGNETISME.md` §6).
- **R173** : ferrofluide sur tout le fond à trois échelles, opacités/luminosités variables, vitesse aléatoire accélérée près
  des aimants (`TEXTURE_MAGNETISME.md` §7). **Bogue** : avec l'outil Droite (éditeur), un trait vers une zone interdite était
  seulement coupé (cadre rouge) — maintenant la partie entrée dans la zone s'y montre puis se délite (`editor.js` : `ghostLine`,
  geste `gline`, `deny` → `S.ndHit`). Effet renforcé (halo, maintien 0,33 s, grains plus gros).
- **R174** : comètes de la zone interdite plus rares (≈ 1/3 de moins), plus fines, taille (0,5–1,25) et opacité (0,25–1) propres à
  chaque paire, éclair d'annihilation adouci, poussière qui s'effondre sur elle-même en tournant (zone morte).
- **R175** : comètes un peu plus présentes (opacité +40 %, un peu plus nombreuses) ; lueur large laissée derrière leur passage,
  qui s'éteint plus lentement que les particules (`glw`) ; à la rencontre, choc électrique délicat (4 arcs brisés qui crépitent
  + anneau fin) avant l'effondrement de la poussière.
- **R176 — raccourcis fermés (outil `tools/ndfix.js N`)** : énumère les traits gagnants (grille du détecteur + 1 800 traits
  au hasard), sépare ceux qui ne touchent aucun élément (« nus ») et cherche 1 ou 2 zones interdites (60–240 u) qui les
  suppriment en gardant les solutions qui passent par la mécanique, jamais sur le départ, le bassin ni la chute initiale.
  Appliqué : 61 Le piston, 63 Piston bas, 97 Le portail, 104 Boucle, 124 Deux possibles, 129 Temps et rebond, 130 Le choix,
  16 La hauteur juste → **0 raccourci** au détecteur ; 67 Métronome, 101 Deux failles, 123 La mesure → **1** restant.
  Ces niveaux n'ont toujours pas de solution de référence (`optsol`) sauf le 16. Sauvegarde : scratchpad `levels.r175.js`.
  Les huit à reconcevoir : sept faits en R177, reste 117 Le filet.
- **R177 — sept niveaux reconçus de zéro** (la mécanique est la seule source d'énergie ou le seul chemin ; 0 gagnant sans
  elle ; solution de référence + noyau ; nom et conseil fr/en ; P_exec mesuré au modèle éditeur) :
  - **59 La tempête** (Soufflerie) : la tempête souffle à gauche plus fort que la pesanteur, le « bas » penche de côté :
    une pente qui MONTE vers la gauche devient une descente. Bassin plus haut que le départ. P_exec 100 %, 1 famille.
  - **68 L'engrenage** (Mécanique) : deux ascenseurs ; le premier ne monte pas assez haut, il faut redescendre vers le
    second au bon moment (pont entre les deux puits). P_exec 77 %, 1 famille, noyau non discriminant.
  - **71 Atelier mobile** : ascenseur puis navette oblique (`mov` avec `grip` 0,15) ; on pose un quai là où la navette
    passe prendre la particule. P_exec 90 %.
  - **93 Orbite** (Magnétisme) : répulseur = ressort (seule énergie), attracteur sous le bassin flottant ; seule, la
    particule se balance sous l'aimant pour toujours ; un mur dans sa course la fait boucler et retomber par-dessus.
    P_exec 100 %, 17 familles.
  - **95 La capture** : même couple ressort/attracteur, autre pensée : lancée trop haut elle est capturée en orbite ;
    un plafond posé sur le ressort la fait passer DESSOUS, l'aimant la hisse dans le bassin. Noyau sur le passage bas
    (48 % des gagnants). P_exec 90 %.
  - **111 Corde et plaque** (Filaments, palette corde seule, `elastic` 1,3, `ropeIter` 10) : la corde rend plus qu'elle ne
    reçoit, rebond après rebond la particule monte dans le puits ; la plaque du haut la renvoie au bassin. Structure : 0.
    P_exec 87 %.
  - **116 Deux cordes** : deux puits, deux pompes en relais ; une seule corde ne suffit jamais (0 gagnant à un trait,
    bande interdite sur la cloison). P_exec 77 %.
  - Mesures : `allsol` 132/132, `difficulty.js` ci-dessus, détecteur de raccourcis 0 « nu » sur les sept, monde1/2,
    replaytest, tutotest, audit, maptest, strict, qprobe OK. Captures regardées (La tempête, plateaux des autres
    derrière les fiches du didacticiel).
  - **117 Le filet : PAS refait.** Essais : corde molle qui retient sur une pente (la structure fait aussi bien avec un coin),
    filet qui attrape une balle rapide (structure : 427 gagnants contre 1 003), périscope à deux cordes élastiques
    (P_exec ≈ 5 %, chaotique). Piste à proposer à Simon dans l'éditeur.
  - Constats moteur utiles : la corde par défaut renvoie 20 % (amortit, plie) ; `elastic` > 1 pompe l'énergie ;
    `ropeIter` 10 rend la corde prévisible ; une chaîne de deux rebonds élastiques précis est injouable au doigt ;
    un attracteur seul ne peut pas faire monter (champ conservatif) : il faut un répulseur pour l'énergie.
  - Scratchpad : `mg/t*.json` (tempête), `e6`, `a15`, `oA`, `cA`, `k2`, `r2` ; outils `abl.js`, `ablm.js`, `arcg.js`,
    `grid2.js` (2e trait, 1er fixé), `rgen.js`/`rgen2.js`/`rgen3.js` (recherche aléatoire de conceptions), `best.js`
    (P_exec des gagnants), `stp.js` (noyau qui partage les gagnants), `pert3.js`. Entrées ajoutées à `tools/forge.json`.
- **R178 — didacticiel holographique, 3 propositions dans le banc des rendus (rien dans le jeu)** : A Projection (fente de
  lumière au-dessus des outils, faisceau, lame qui se déroule sous un balayage), B Visière (aucune surface, voile radial,
  lentille ronde à anneaux d'interférence, rail gradué), C Lame (verre fin en biais, bord irisé tournant, trois plans en
  profondeur). Chacune : fiche « Zone interdite » + consigne « Dévier » + repère, sur captures réelles (`studio/captures/`).
  Source `studio/galerie-holo.html`, injectée par `tools/build-galerie.py` (`__HOLO__`). En attente du choix de Simon.
- **R179 — Simon retient C** avec la surface de A, plus transparente (30 %). Apparition = déploiement mécanique (1,9 s) :
  pivot → rail cranté → montants qui se dressent → trois lames de verre qui se relèvent → équerres verrouillées + bord irisé
  → contenu ; repli inverse 1,2 s ; durées × `--sp` (bouton « Ralenti ×4 »). Toujours dans le banc seulement, pas en jeu.
- **R180 — essai « Mât »** (classe `.dep2`, par défaut dans le banc ; bouton pour revenir au « Rail ») : origine en bas au
  centre de l'écran → tige qui traverse la barre d'outils → mât jusqu'en haut de la fiche → deux volets de verre qui
  pivotent autour du mât vers les côtés, rails et montants suivent → verrous, bord irisé, contenu (1,9 s). Repli inverse.
- **R181 — essai « Tiroirs »** (`.dep3`, par défaut) : consigne de Simon, RIEN ne passe sur l'éditeur de ligne (origine juste
  au-dessus des outils ; la tige du Mât est supprimée aussi). Mât qui monte lentement-vite-lentement, graduations cran par
  cran ; puis 4 rangées de tiroirs sortent de part et d'autre, de bas en haut, easing (.72,0,.18,1) = départ doux,
  accélération, atterrissage en douceur ; arête lumineuse + poignée par façade, cote « ◂ 339 u ▸ » qui compte l'ouverture,
  grains qui s'échappent du mât. 2,8 s ; fermeture 2 s (tiroirs du haut vers le bas, puis le mât redescend).
- **R182 — essai « Tiroirs verticaux »** (`.dep4`, par défaut) : fente qui s'ouvre au-dessus des outils, puis 4 tiroirs
  qui montent l'un après l'autre en sortant de derrière celui du dessous (même courbe partout : départ doux, accélération,
  atterrissage doux) ; arête + poignée + glissières par façade, jointures fines au repos, cote de hauteur réelle (« ▴ N u »,
  mesurée en JS), montants qui suivent. 3 s. FERMETURE = miroir exact ×0,85 : texte (bas → haut), verrous, tiroirs (le dernier
  sorti rentre le premier), montants et cote, fente, origine. Bogue corrigé : `--n` doit être posé sur `.hc`/`.hk`
  (sinon les calc du bord irisé et du texte sont invalides et ces pièces apparaissent d'emblée).
- **R183** — Simon : les déploiements mécaniques sont trop compliqués, pas assez fluides (mis de côté, gardés dans le banc).
  Retour à **B Visière**, avec la démonstration dans une grande fenêtre (pleine largeur × 156 px au lieu de la lentille de
  96 px) : sans bordure, bords dissous dans le voile, franges d'interférence fines, 4 repères d'angle ; apparition = mise au
  point (flou → net) + franges qui se resserrent + repères qui se posent, puis titre condensé (1,1 s). À valider.
- **R184** — Visière : vignette réduite (76 % × 116 px) ; ouverture en un seul geste (ligne de lumière au centre → la fiche
  s'ouvre vers le haut et le bas, courbe expo) ; fermeture = même geste inversé ; vignetage des bords de l'écran
  (`.hvig`, via `:has(.hc.in)`), plus léger pour une consigne. À valider.
- **R185 — audit du didacticiel** (`docs/AUDIT_DIDACTICIEL.md`) + solution « Visière adaptative » dans le banc (4 niveaux
  témoins, calcul en direct) : projecteur sur l'élément, contour tracé, position/format calculés, voile ajusté au fond, outils
  regroupés. Source `studio/galerie-audit.html` (injectée avec `__HOLO__`), captures `studio/captures/h*.jpg`. Pas dans le jeu.
- **R186 — DIDACTICIEL VISIÈRE ADAPTATIVE DANS LE JEU** (validée par Simon) : `tuto.js` (fiche « Tes outils » au lieu de 4,
  `vsPlace` position/format calculés sur la vraie géométrie, `vsVeil` voile d'après les pixels de `#cv`, `vsSpot` projecteur
  dans `#tshield`, `vsOutline` contour tracé `#tout`, ouverture depuis une ligne `.tvl`, fermeture `vsClose`, attente 0,7 s,
  `frStart` neutralisé, anneaux de cible remplacés), CSS bloc R186 en fin de `quantix.css`, i18n `tt_tools`, `td_tools`,
  `cat_tools`, `ts_*` FR/EN, `index.html` (`.tvl`). Tests mis à jour : tutotest (fiche outils), e2e-didacticiel (2 fiches,
  24 entrées d'explications : le 23 était périmé depuis la paroi tunnel) → 38/38. Captures regardées (niveaux 2, 3, 49, 1).
  Non regardé : monde 8 (WebGL trop lent sans GPU).
- **R187 — audit de l'interface** (`docs/AUDIT_INTERFACE.md`) + maquette d'accueil Visière avec héros animé, pause,
  paramètres, barres d'outils harmonisées (banc des rendus). Pas dans le jeu.
- **R188 — accueil Visière + héros « L'odyssée » (DANS LE JEU)** : `assets/js/hero.js` (nouveau, global `QHERO`) : boucle
  de ≈ 20 s, la particule jaillit d'un vortex et traverse les 11 mondes (trait qui se trace, plaques de rebond sur lave,
  looping, pont de glace + tremplin, colonne d'air + cyclone, escalier mécanique qui monte, gravité renversée avec roulis de
  caméra, fronde magnétique, faille + portails, corde-tremplin + harpe, dédoublement + détecteur), tombe dans le bassin qui
  s'ouvre en vortex et reboucle. Fonds : `assets/img/hero/h01–h11.jpg` (540 px, tirés de `assets/img/worlds`). Branché dans
  `engine.js hStep` (l'ancienne simulation reste en secours si `QHERO` manque). Accueil : héros plein cadre (64 % de
  hauteur), marque en haut, nom du monde traversé sous la devise, bouton « Continuer » à sous-ligne (monde · n / 12 · nom,
  `#hContSub`), lignes Constellation / Quantone / Paramètres, statistiques ; ouverture animée (CSS, bloc R188 en fin de
  `quantix.css`). i18n `continueQ`. `build-apercu.py` : `hero` embarqué + option `home` (aperçu ouvert sur l'accueil).
  Vérifié : audit, strict, tutotest, monde1/2, replaytest, maptest, qprobe, savetest, e2e-didacticiel 38/38, e2e-editeur
  25/25, e2e-son 7/7 ; captures 390×844, 375×667, 1280×800, anglais. Non fait : passage du héros au banc des rendus,
  harmonisation pause/paramètres/codex/Quantone/barres (maquettes seulement).
- **R189 — odyssée retouchée (retour de Simon)** : vortex d'arrivée refait en disque d'accrétion texturé (`vortexQ` : 340 grains
  aux couleurs des onze mondes en arcs elliptiques, horizon sombre, anneau de photons, arc de lentille, bras en pointillés,
  arcs électriques ; il se referme au départ). Chocs : bibliothèque d'impacts du jeu exportée (`VX.impact` / `VX.impacts`
  dans `visuals.js`), doublée sur les chocs forts, éclair local + onde double, écrasement de la particule, secousse et arrêt
  sur image de 60 ms. Fonds plus sombres (opacité .6, vignette renforcée). Décors du jeu ajoutés : poussière d'étoile
  (`VX.flow`, Atelier), chambre à bulles (Fonderie), puits d'espace-temps (`VX.well`, Gravité), corral de la faille
  (`VX.rift`), lame de superposition + détecteur (`VX.qsup`, `VX.qdet`), ciel étoilé à l'arrivée.
- **R190 — odyssée fluide** : départs/arrivées de segments jamais à vitesse nulle (`ease` adouci), plus d'éclair blanc ni
  d'arrêt sur image, secousses réduites ; la boucle passe par l'horizon (le vortex s'élargit, l'image plonge dans le noir,
  le départ en émerge). **Audit de l'espace de jeu** (`docs/AUDIT_ESPACE_JEU.md`) : la toile est limitée par la LARGEUR sur
  tous les téléphones récents ; prototype « Plein cadre » (`studio/proto-plein-cadre.css/.js`, injecté seulement par
  `build-apercu.py … plein`) : reflet flou du rendu jusqu'aux bords, coins repères, titre sur une ligne, étoiles retirées,
  fil d'énergie dans l'écran, outils en icônes en Visière. **Pas dans le site** : en attente de validation.
- **R191 — dans le site** : panneaux Visière (bloc R191 de `quantix.css`, aucune balise changée) pour bilan, pause, paramètres,
  explications, constellation, atelier : voile en vignette, verre sombre, repères de coin, ligne de lumière, poussière qui
  dérive, titre qui s'allume, lignes à chevron au lieu des pilules secondaires, bouton principal en lumière, ouverture en
  cascade. Bulle « Zone interdite » retirée du tracé à la droite (`editor.js`). Astuce du bas cachée ; elle apparaît en
  hologramme après 3 lâchers sans réussite ou 45 s (`HINT`, `hintCheck` dans la boucle — pas de minuterie, sinon les tests
  node ne s'arrêtent plus). Prototype plein cadre : marge de zone sûre du haut retirée (l'aperçu dans l'application Claude en
  déclarait une fausse). Tests : audit, strict, tutotest, monde1, replaytest, e2e-didacticiel 38/38, e2e-editeur 25/25.
  À voir : les textes d'aide de la relecture et de la solution passent aussi par l'astuce, donc cachés pour l'instant.
- **R192 — dans le site** : bilan sans titre ni phrases : en-tête animé par issue (`VX.resAnim` dans visuals.js : win/complete
  spirale + colonne + satellites d'or, sol géodésique, out paquet d'ondes hors cadre, spike annihilation, stuck puits de
  potentiel amorti, long lemniscate + cadran) ; critères en trois médaillons, mesures en deux chiffres (i18n `r_matter`,
  `r_time`) ; actions en tuiles icône + mot : État initial, Bifurquer, Trajectoire, Géodésique, Poursuivre (i18n FR/EN
  changés) ; pause en tuiles. Astuce holographique dans l'en-tête à la place du titre (12 s, toucher le titre la rappelle).
  Prototype plein cadre : contours en dégradé comme l'accueil, titre discret. **MENU édition** :
  https://claude.ai/artifact/63wuCq6jdpwN6i7PWmyNkk (`python3 tools/build-menu.py` → `studio/menu-edition.html`, style
  `tools/menu-style.css`, docs `docs/menu-docs.json`) — à donner à CHAQUE tour, republier seulement s'il change.
- **R193 — dans le site** : animation de victoire renforcée (hélice lumineuse, éclosion, 16 rayons, triple onde, gerbe de
  90 éclats, couronne d'orbites, constellation des trois critères reliés). Livré : zip du site seul (demande de Simon).
- **R194 — dans le site** : PLEIN CADRE intégré (bloc R194 de quantix.css, `pfLayout` dans engine.js ; l'option `plein` de
  build-apercu est désactivée). Astuces retirées (`hintShow` neutralisé, `.tip` caché). Didacticiel apaisé : niveau 1 sans
  fiche, consigne seule dès l'ouverture (étape 0 « Les bases » qui cède au premier trait ou après 8 s), jamais sur l'en-tête,
  ni sur la particule ou le noyau ; pointes nommées sur le terrain et marquées vues en fin d'intro ; une notion par niveau
  (« Tes outils » attend un niveau sans élément nouveau) ; 1,8 s avant une fiche ; zone interdite en un seul contour
  (`ndEdges`, bords exposés) ; voile des fiches en flou + assombrissement d'arrière-plan (la ligne nette au bord du voile venait
  du dégradé : supprimé). Énergie relevée pour que la solution de référence soit traçable : #34 → 420, #72 → 300,
  #84 → 270, #116 → 320 (aucun raccourci « nu » au scan). Quantone : barre Écouter collante (toujours visible), un trait
  sélectionné change d'instrument en touchant une puce (annulable), consigne de Dupliquer complétée. Tests : audit, strict,
  tutotest, monde1/2, replaytest, maptest, savetest, e2e-didacticiel 38/38, e2e-editeur 25/25, e2e-quantone 12/12,
  e2e-quantone-editeur 9/9. Non republié : l'artefact Quantone séparé (le Quantone du jeu et de l'aperçu est à jour).
- **R195 — dans le site** : fiches du didacticiel en verre OPAQUE (bloc R195 de quantix.css : panneau sombre plein, voile
  supprimé, repères de coin gardés). Plus de partie guidée au niveau 1 : fiches « Les bases » puis « Pointes » (onLoad, et
  `mark('basics')` pose l'intro faite). Zones interdites retirées des niveaux 2 et 3 (le 1 n'en avait pas) → « Tes outils »
  au niveau 2, « Zone interdite » au niveau 4. Mesure : #2 Le pont a désormais 33 traits droits gagnants dont 1 « nu »
  (contourne l'idée) ; #3 23 gagnants, 0 nu. Tests adaptés (tutotest, e2e-didacticiel 32/32, e2e-editeur 25/25 sur le
  niveau 5). Banc des rendus : section R195 (`studio/galerie-r195.html`, captures `studio/captures/r195_*.jpg`).
- **R196 — dans le site** : fiche holographique = proposition A du banc (bloc R196 de quantix.css + éléments `.hd` dans
  #tcard : émetteur, faisceau, poussière, rails, ligne de lecture, filament, relevé `#thud` ; pied `.hfoot` onde + bouton).
  Verre translucide sombre et flouté. Déploiement : émetteur → rails → panneau déroulé (clip-path) → coins → texte ; fermeture
  inverse ; `htop` (vsPlace) met le projecteur du côté du bord. Niveau 2 « Le pont » : pilier [150,0,150,112] (0 trait « nu »,
  P_exec 100 %), conseil FR/EN mis à jour. Fiche « Zone interdite » au niveau 4 « Le relais » (premier niveau où les zones
  dessinent tout le couloir). Banc : section R196 avec animation WebP capturée dans le jeu (`studio/captures/r196_*`).
- **R197 — dans le site** : vignettes des fiches au rendu fin de la proposition A (tuto.js : `neon`, `wall`, `zone`, `cup`,
  `dball` redessinés en traits fins, sol en perspective qui défile dans `demoLoop`, courbes des scènes en traits fins) ; plus
  de quadrillage plat CSS. Banc republié (animation et captures refaites).
- **R198** : décor des fiches toujours à l'encre cyan (`--hk:#4DD7FF`), la couleur de l'élément reste sur la pastille et les
  mots-clés. Éditeur de niveaux reconstruit avec les niveaux actuels (aperçu `1 11 skipintro` + `studio/editeur-niveaux.js`
  injecté avant `</body>`, titre « Quantix Éditeur », capacités db + downloads conservées) et republié. Menu édition : liens
  en `target="_top"` (ouverture dans la visionneuse Claude, à confirmer sur iPhone) ; les liens sont aussi redonnés dans chaque réponse.
- **R199** : délitement du trait dans la zone interdite en grains ronds et fins (visuals.js `ndDust` : plus de carrés), trait
  instable plus fin. Fiche « Zone interdite » : démonstration propre `ndDemo` (tuto.js, d'après la proposition A) — le trait
  entre, tremble, se délite en sable ; paires qui s'annihilent ; la particule contourne.
- **R200** : Constellation sans défilement (carte 2:3 dimensionnée sur la hauteur disponible, « Fermer » collant). Rappel : le
  PLEIN CADRE est actif dans le site depuis R194 (bloc R194 de quantix.css + `pfLayout`).
- **R201** : (1) vortex du héros allégé (340 → 210 grains, bras 46 → 30 segments). (2) MENU édition : `target=_top` ne
  s'ouvrait pas dans l'app iPhone → lien simple + adresse visible + bouton « Copier » ; toujours donner les liens en clair.
  (3) **Audit de ton** : didacticiel (ti_*, td_*), sous-titres de carte, aide de la frise et 6 conseils du monde 1 réécrits
  courts et énigmatiques (une règle, un verbe), FR et EN. Règle : ≤ 80 signes, pas de lyrisme, la physique dite en une image.
  (4) **Fin du jeu** : `VX.finale` refaite sans texte — « Naissance » : onze comètes aux couleurs des mondes s'enroulent dans le
  bassin, le point se charge puis se contracte, la particule naît au centre d'un disque d'émission qui glisse au milieu de
  l'écran, le ciel s'allume, la constellation des onze mondes se trace ; l'interface du niveau s'efface (`#app.fin`). À
  500 images, **générique holographique** `#vFin` (même langage que la fiche A) : « Elle est réelle. », crédits, bouton
  Ko-fi (`var KOFI=''` dans engine.js : vide = bouton masqué), « Bilan » ouvre le panneau de résultat. (5) Dette réglée : plus
  de français en dur pour la maîtrise (oneShot / usedRewind[s]).
- **R201 b — audit externe (GPT) vérifié** : `render.js` affichait OK malgré « VX is not defined » (le banc Node ne
  rendait pas `window.VX` global) → corrigé dans `load.js`, et le banc échoue désormais sur toute erreur de rendu.
  `bypass.js` : 33 / 97 contournables, tous dans les mondes 5 à 11 (50 53 55 56 58 · 61 62 63 64 67 69 · 77 79 80 81 82 83 ·
  89 92 94 · 104 107 · 118 119 · 121 123 124 125 126 127 128 130 131) — c'est la liste de travail de la refonte 7→11, puis 5–6.
  Faux positifs : images `hero/h01–h11` (chemin construit dans hero.js) ; `user-scalable=no` voulu (le pincement gênerait le tracé).
  Tableau de suivi encore calculé sur `difficulty_R116.json` : à recalculer monde par monde pendant la refonte.
- **R202 · fin du jeu refaite en scène cinématique** (R201 jugée kitsch par Simon : guirlande, matières pauvres). Prélude de
  1,5 s dans le niveau (`VX.finale` : le niveau s'assombrit, le bassin se charge), puis **`QHERO.epilogue`** (hero.js) en plein
  écran sur `#finCv` : le bassin d'arrivée émerge du noir → la particule remonte l'odyssée À REBOURS (8 s, les décors se
  défont) → le vortex de départ se rouvre et l'avale → puits harmonique fait d'une paroi du jeu : période fixe, énergie qui
  décroît, un photon aux couleurs d'un monde à chaque niveau quitté (n = 10 → 0) → état fondamental (point zéro, nuage |ψ₀|²).
  Le texte vient quand l'état fondamental est atteint : « ÉTAT FONDAMENTAL · n = 0 / Équilibre. / Toute l'énergie est rendue.
  Il ne reste que le frémissement du vide. » **Crédits retirés** (Simon : texte final à creuser plus tard). Ko-fi : code prêt,
  bouton masqué (`KOFI` vide). Aperçu de la fin : `build-apercu.py 1 11 skipintro fin`.
- **R202 · règles des fiches du didacticiel** (bug : après la fin du jeu, toutes les fiches du monde Quantique s'affichaient —
  la fiche « en attente » du dernier niveau survivait à la réussite). Règles écrites en tête de `onLoad` (tuto.js) : (1) une
  fiche ne s'ouvre qu'à l'arrivée dans un niveau, avant le premier lâcher ; (2) seulement les notions de CE niveau jamais
  expliquées ; (3) niveau déjà réussi : aucune fiche ; (4) deux fiches au plus par arrivée ; (5) la fiche en attente est
  abandonnée au lâcher, à la réussite, à l'échec ou en quittant. Mémoire = sauvegarde du jeu (même stockage que la
  progression) : effacer les données du site ou changer d'aperçu (chaque version d'artefact a sa propre mémoire) = tout
  réexpliquer.
- **R203 · NARRATION décidée (choix C, `docs/NARRATION.md`)** : paire intriquée née à l'horizon (le vortex du héros), la
  nôtre s'échappe ; la fin = retrouvailles, puis fentes de Young où chaque niveau réussi devient un point (Tonomura).
  **Épilogue refait** (`QHERO.epilogue`, remplace R202 « puits ») : poursuite de RETOUR (11 → 1, ×1,15) avec une figure par
  monde absente du héros (tunnel, corps mou, univers recousu, cyclotron, assistance gravitationnelle, pendule, allée de
  Kármán, bosses de glace, anneau de stockage, chambre à bulles, ricochets) + fil d'intrication vers l'origine ; horizon :
  la jumelle émerge, spirale avec ondes, nuage bistable ; plaque de détection : un point puis un point par niveau réussi
  (couleur du monde, `opts.solved` depuis `S.best`), franges révélées. Texte : « INTRICATION · UN SEUL ÉTAT / Réunies. /
  Chaque point est une de tes expériences. » ≈ 25 s. L'aperçu `fin` marque tous les niveaux réussis.
- **R204 · fin refaite d'après Simon** : la compagne (aspect de la branche de superposition) naît au monde Quantique du
  retour et fait toute la poursuite (harmonie ↔ séparation, caméra qui recule pour le couple) ; Glacier = demi-lune avec
  caméra qui se balance/zoome ; fusion à l'horizon puis **danse dans une sphère** (3D, sans texte, bouton Bilan seul).
  Écran des fentes supprimé. Détail dans `docs/NARRATION.md`. ≈ 18 s de poursuite + 2,6 s de fusion + danse (bouton à 7 s).
- **R205 · fin moins linéaire** : rythme variable (ralentis/accélérations), cadrages variés, Gravité avec tour de caméra complet, accélérateur linéaire, paire en V, double hélice, danse à quatre figures (`docs/NARRATION.md` § R205).
- **R206 · fin « un seul mouvement »** : compagne en canon/valse au lieu des miroirs, un seul basculement (Gravité), transitions de fin continues, décors mécaniques et hélices du jeu réutilisés (`VX.mech`, `VX.helix`, `VX.torusCells` exportés de visuals.js). Détail : `docs/NARRATION.md` § R206.
- **R207** : Gravité = basculement aller-retour (plus de tourbillon) ; les particules plongent dans le trou noir, puis la sphère ; titre QUANTIX qui apparaît en haut pendant la danse (`fin_title`). Zip livré pour déploiement ; aperçu non republié.
- **R208 · bilan du parcours** : journal `JR` (engine.js, sauvegardé avec la progression, clé `jr`) : temps de jeu (écran de jeu visible, hors Zen), lâchers, échecs, réussites, traits, matière engagée dans les réussites (unités d'encre), reprises. Bilan final (`#vResult.jfinal`) : grille de 9 mesures — étoiles x/396, expériences x/132, parfaites (3 étoiles), matière tracée, temps, lâchers, échecs, traits, reprises. Libellés i18n `jr_*`. Les parties antérieures à R208 partent de zéro pour ces compteurs (étoiles et expériences, elles, viennent de la sauvegarde existante).
- **Reste** : fiches des outils Échelle et Aimant ; scènes simulées pour les éléments quantiques ; machines du monde 3
  (Chaîne 3 et 9 proposés) ; mondes 7 à 11.
- **À faire (demandé par Simon)** : (1) didacticiels harmonisés, non codés en dur ; (2) deux machines manquantes du monde 3
  à base de matière poreuse (niveaux à confirmer avec Simon).
- Connu, non traité : zone de réussite non propre aux niveaux 21 et 34.

- **R211 · refonte totale de la fin, dans le banc (15 oct., soir)** : audit du héros (`docs/AUDIT_HEROS_FIN.md`) puis nouvelle chorégraphie `studio/fin3.js` (remplace `fin2.js`, gardé pour mémoire). Départ en couple tressé sur un seul trajet (bassin · Quantique · Faille · Mécanique · Magnétisme) ; séparation à mi-parcours à la Fonderie (rotation de plus en plus vite, éclat, ralenti, arrêt sur image) ; deux plans : Gravité (devant) | Glacier (derrière), plan large, traversée de l'avant-plan en bokeh, zoom sur l'arrière-plan, retournement complet, chute sur la Chaîne (tresse) ; Atelier puis fusion et danse inchangées. Billes à rayon constant, traînée en ruban, traits de vitesse, éclairs, étirement/écrasement, chocs (éclat, anneau, rayons), lueur, roulis léger, arrêts sur image et ralentis. Vérifié : captures de chaque acte, continuité de position (aucun saut hors téléportation de la Faille), pas d'erreur console, 15–50 ms/image sans GPU à 860×1520 (lueur comprise : +20 ms sans GPU). NON vérifié : iPhone réel, fluidité réelle, jugement de l'œil de Simon. Rien dans le jeu. Le banc corrige à la volée un bord net de la lueur de la glace (`fillRect(60,260,240,140)` de `hero.js`) : à reporter dans `hero.js` à l'intégration.

**R244 (17 oct.)** — Monde 11 – niveau 8 (Mesure tardive) refait selon la répartition validée : la particule se dédouble, la copie
de droite doit être menée sur le détecteur (relié à la paire 0) qui la rend réelle et ouvre la porte-toit du bassin juste
sous elle ; l'autre copie tombe sur le sol à pointes. Zone traçable x 200–360, y 180–400 ; encre 120. Preuves : référence
`[[200,228],[292,267]]` P_exec 100 % (modèle éditeur) ; 0 gagnant sans quantique, 0 gagnant sans détecteur ; 0 trait nu ;
étoile (250,300) hors du chemin direct (meilleur trait étoilé 57 %). Tests : audit, strict, tutotest, render, replaytest,
savetest, maptest, monde11 OK (4 « problèmes » = niveaux 5, 7, 9, 10 sans référence, à refaire). Aperçu non republié
(groupé avec le prochain niveau). Ordre validé par Simon : finir le Monde 11 (10, 7, 5, 9, 6), puis prototype de l'échantillonneur Quantone.
Simon demande le zip complet à chaque tour.
Même tour : **piège « même squelette »** repéré (la première version du niveau 8 recopiait le départ, le bassin et le séparateur
du niveau 11). Niveau 8 refait sur un squelette propre (départ à gauche, bassin en hauteur derrière une porte verticale ;
réf. `[[112,230],[204,269]]` 85 %, étoile (30,380) 53 %). Scan `tools/squelettes.js` (nouveau) sur les 132 niveaux : restent
Monde 11 niveaux 3/4 et 4/11, Monde 9 niveaux 9/11 (à différencier, notés dans `A_VERIFIER.md`).
**Monde 11 – niveau 10 (Le choix)** refait : deux détecteurs sur une seule paire opposée ; la copie de gauche tombe d'elle-même
dans l'entonnoir et sur son détecteur, ce qui ouvre le bassin central mais referme la porte de l'entonnoir (elle est
piégée) ; il faut détourner la copie de droite sur le détecteur central avant. Réf. `[[288,170],[214,238]]` 98 % ; 0 sans
quantique, 0 sans détecteur ; étoile (250,250) 37 % (par l'autre copie). `bypass.js` le dit « décoratif » à tort (il retire
les portes) ; `monde11.js` fait foi : sans quantique, échoue.

**R245 (17 oct.)** — **Monde 11 – niveau 7 (Intrication double)** refait : une particule, deux paires (une « same », une « opp »),
trois portes. Le noyau A1 est sur la chute évidente : le toucher d'abord referme le passage (porte de la paire opposée) vers
le noyau de la première paire. Il faut dévier la particule dans le passage (noyau A0), puis elle touche l'autre noyau B1 de
la paire opposée : les deux toits du bassin (bas gauche) s'ouvrent. Réf. `[[196,172],[292,144]]` 100 % ; 0 sans quantique ;
étoile (160,125) 60 %.
**Monde 11 – niveau 5 (Le temps ralenti)** refait : une lame à pointes (barre mobile `mov` en matière pointes, `v:1,m:X_`,
longue de 1000 et d'amplitude 1000 : elle se retire d'un coup vers la droite vers t≈180 et ne revient qu'après t≈600) barre
le puits au-dessus du bassin. La chute directe arrive trop tôt ; un petit trait dans la bande étroite (x 222–252, y 70–155)
envoie la particule dans le couloir gauche, doré (×0,18), qui la fait arriver après le retrait. Réf. `[[224,124],[249,107]]`
88 % ; 0 gagnant sans zone dorée au balayage fin (pas 2, 0,1 rad) ; étoile (150,290) 47 %.
**Pièges déjoués ce tour (et règle de Simon appliquée)** : (1) une barre mobile *porteuse* permet d'attendre (la particule se
pose et attend l'ouverture) → une barrière temporelle doit être *mortelle* (matière pointes) ou ne jamais porter ;
(2) un trait presque plat retarde autant qu'on veut → bande traçable étroite (≤ 30 px) pour qu'aucun trait plat ne retienne ;
(3) une barre périodique courte ouvre plusieurs fenêtres → lame très longue et très ample : une seule ouverture franche.
Scan des autres niveaux pour ces pièges : seuls le Monde 6 (11 niveaux sur 12) et le Monde 11 – niveau 5 ont des barres
mobiles. Au Monde 6 les barres sont des plateformes porteuses voulues (piège 1 sans objet), mais le piège 2 (trait plat qui
attend la barre au lieu de viser le bon moment) peut y contourner l'énigme de rythme : **à vérifier niveau par niveau au
prochain passage sur le Monde 6** (noté dans `A_VERIFIER.md`). Reste à faire au Monde 11 : niveau 9 (Les jumeaux, en plein air) et niveau 6 (machine spectaculaire), puis les
squelettes 3/4/11 et Monde 9 niveaux 9/11.

**R246 (17 oct.)** — **Monde 11 – niveau 9 « Les jumeaux »** (remplace « Temps et rebond »), en plein air : séparateur horizontal
(angle 1,5) sous la chute, deux poteaux (x 100 et 260) renvoient les copies qui se recroisent au recombineur (180,302, rayon
40, fenêtre 70, sortie 15°) ; la zone dorée (200,130,60,100) ne ralentit que la copie de droite. Il faut retenir la copie de
gauche par un petit trait dans la fenêtre traçable (x 104–156, y 130–172) pour qu'elles se retrouvent ; recombinée, la
particule part vers le bassin perché à droite. Réf. `[[132,166],[105,153]]` 87 % ; 0 sans quantique, 0 sans recombineur ;
étoile (150,100) 37 %. `monde11.js` : 12/12 OK.
Pièges de ce tour : (1) bassin au sol accessible à un simple trait (338 contournements) → bassin perché, fenêtre traçable
réduite à la zone où l'on agit sur une seule copie ; (2) `squelettes.js` comptait les bords du cadre comme murs communs →
corrigé (bords ignorés) ; nouveau scan : restent Monde 11 niveaux 4/11 et Monde 9 niveaux 9/11.

**R247 (17 oct.)** — **Machine du Monde 11 – niveau 6 (L'interféromètre)**, au Banc des rendus (section `b-r247`), **pas encore
active dans le jeu** : `VX.qmach(c,lv,S,layer)` (visuals.js) dessine un banc d'optique quand le niveau porte `mach:'mz'` —
plaque gravée et vissée, bras de verre qui s'allument au passage d'une version (onde qui court), miroirs argentés aux coudes,
cube séparateur, collimateur de source, écran de franges (franges si deux versions, tache si une). engine.js l'appelle sous
les murs (layer 0) et après les murs (layer 1). Pour l'activer après validation de Simon : ajouter `mach:'mz'` à l'entrée
du niveau 6 dans levels.js. Mécanique inchangée.

**R248 (17 oct.)** — Retour de Simon sur **Monde 11 – niveau 9 (Les jumeaux)** : « pas clair, difficile à reproduire, on ne
comprend pas la force qui dévie la bille vers le trou ». Cause : le recombineur ne faisait que réorienter (un trait peut en
faire autant → invisible et contournable) et la fenêtre traçable était minuscule. Correctifs :
(1) **moteur** : `rec[5]` = vitesse de lancement — réunies, les deux versions sont *lancées* (ici 14 px/image à −82°) ;
(2) **rendu** (`VX.qrec`) : l'arc de lancement est dessiné d'avance en pointillés lumineux ; un anneau se vide autour du
recombineur pendant qu'une version attend sa jumelle (fenêtre) ;
(3) niveau : bassin perché à droite (280,254) que seule la particule lancée atteint ; zone dorée déplacée (215,130,45,110)
pour que l'arc ne la traverse pas ; fenêtre traçable agrandie (x 104–150 et 104–176 selon la hauteur, y 130–300).
Réf. `[[132,194],[110,155]]` 83 % ; 489 gagnants (216 avant) ; 0 sans quantique, 0 sans recombineur ; étoile (150,100) 27 %.
Piège noté et scanné : *une trajectoire imposée (lancement, sortie de recombineur) qui traverse une zone dorée est ralentie
et ne va plus où l'on croit* — seul le niveau 9 combine `rec` et `tdil` : rien d'autre à corriger.
**Squelettes** : Monde 11 – niveau 4 (La mesure) refait (départ à droite, détecteur contre le mur droit, bassin perché à
gauche ; réf. `[[310,164],[355,164]]` 100 %, étoile (280,400) 57 %, 0 sans quantique) ; Monde 9 – niveau 11 (Le pli) mis en
miroir (départ et bassin à gauche, même énigme, monde9 12/12). `squelettes.js` : **0 paire trop proche** sur les 132 niveaux.

**R249 (17 oct.)** — Demande de Simon : « le recombineur doit être plus visible ; vérifier que tous les éléments jouants sont
visibles et clairs ; scan complet ». Nouvel outil `tools/visibles.py` (Playwright, ×2 ; ×1 pour les mondes 8 et 10, trop
lourds) : chaque élément jouable est photographié avec et sans lui ; l'écart dans sa boîte, moins le bruit d'animation,
dit s'il se voit (résultats `tools/visibles.jsonl`, vignettes /tmp/visibles). Mondes 1–7, 9–11 scannés ; Monde 8 vérifié à
l'œil (captures des 12 niveaux : aimants, champs, bobines, poussoirs lisibles).
Corrigé : **recombineur** (disque de verre sombre, anneau plein, deux demi-anneaux cyan / violet qui tournent) ;
**porte ouverte** (elle était presque invisible : un simple trou) → deux jambages lumineux, battants rentrés, seuil en
pointillés blancs, halo de la couleur de sa paire ; **vent** et **zones de gravité** (voile, liseré et chevrons / flèches
plus marqués, engine.js) ; **colonne d'air** (stries plus visibles) ; **champ magnétique uniforme** (voile plus dense).
Les « faibles » restants au scan sont des éléments animés (barres mobiles, portails, fronde) dont le bruit d'animation
fausse la mesure ; vus à l'œil, ils sont lisibles. Piège noté : *capturer à ×1 sous-estime la lisibilité réelle (iPhone ×3)*.

- **R250** (17 oct., soir) : Quantone — 4 instruments (Corde, Écume, Onde, Sampler), 10 fonctions (11–20), `e2e-sampler.py`, `allow="microphone"`.

- **R251** (17 oct., nuit) : volumes 0–300 %, boîte à rythmes (×2,2, 16 motifs, geste multi‑cases, Rythmes = boîte seule), instruments Accords et Voix (12 au total).

- **R252** (17 oct., nuit) : rythmique fusionnée (boîte dans l'éditeur Rythmes, trait = ouverture de la boîte), préréglages du sampler qui gardent l'échantillon.

- **R253** (17 oct., soir) : pad X‑Y façon zone interdite avec trait désintégré qui suit le doigt ; boîte à rythmes jouable sans aucun trait (play, fx, .wav) ; test e2e ajouté (27/27).

- **R254** (17 oct., soir) : message d'erreur micro lisible (panneau + toast remonté), tests 27/27 · 12/12 · 9/9.

- **R255** (17 oct., soir) : bouton de secours d'enregistrement par l'appareil quand le micro est bloqué.

- **R256** (17 oct., nuit) : sampler refait (pastilles, sections repliables, onde plus grande), micro : messages précis + plein écran, bouton capture retiré.

- **R257** (18 oct., nuit) : import de tout fichier son (cascade de décodeurs, multi‑fichiers, glisser‑déposer, plus de filtre accept).

- **R258** (18 oct., nuit) : module Rythmes unique, motifs en menu (49), tempo, 14 voix + 8 kits + saturation/salle, fonctions sur la boîte, panneau fonctions global retiré, vent du jeu suspendu, échelle dans l'outil Déplacer.

- **R259** (18 oct., nuit) : jeu suspendu sous Quantone (tous les AudioContext + boucle), ouverture .json corrigée, garde-fous audio (plafond de voix, try/catch, shaper partagé, reprise iOS).

- **R260** (18 oct., nuit) : traits de percussion sur `dmHit`, barre de lecture fixe, mini CPU, gamme/grille en haut, format .qx (préréglage + samples).
- **R261** (22 oct.) : jauge d'encre (règle sans trait = pleine, visible sous 600 px), Échelle dans Déplacer, Quantone : réglages indépendants par trait ; scan132.js.
- **R262** (22 oct.) : refonte des documents (ETAT, REGLES, TECHNIQUE, JOURNAL, INDEX, prompt maître) ; aucun changement de code.

## Anciens blocs « ÉTAT » (R249 → R260)
## 0. ÉTAT AU R260
**R260** : (1) **« Ce trait seulement » sur Rythmes** : les traits de percussion passaient par l'ancien synthé `drum()`, qui ignorait Saturation et Salle (seuls réglages visibles du module) ; ils passent maintenant par `dmHit`, le même moteur que la boîte (kick=ligne 0, caisse=1, charley fermé=3, ouvert=4) ; le choix de kit de la boîte agit sur le trait sélectionné quand « Ce trait seulement » est actif. Les lignes de la boîte (accord, durée, niveau, pan) restent propres à la boîte. (2) **Barre de lecture fixe** (`position:fixed`, plus `sticky` qui disparaissait) + marge basse de la page. (3) **Mini diagramme CPU** dans la barre : même valeur que la jauge « Charge » (`window.QLV`), courbe sur ~6 s, couleurs vert/ambre/rouge de la jauge. Estimation (voix vivantes + retard d'ordonnancement), pas un vrai CPU. (4) **Gamme, tonique et grille** remontées sous le champ (bloc `#sgrow`, avant les instruments). (5) **Format .qx** : bouton « Enregistrer en .qx » (panneau Enregistrer et partager) ; fichier JSON `{q:'quantix-qx',v:1,info,preset,samples[]}` avec le préréglage complet (dessin, réglages, boîte, fonctions) et les 8 samples en PCM 16 bits ; l'ouverture (`#file`, sans filtre) reconnaît .qx par contenu (`QXIO.open`), sinon .json comme avant. Test : `tools/e2e-quantone-barre.py` (11/11). Non vérifié sur iPhone : tenue de la barre fixe avec le clavier/la barre Safari, écoute du rendu des traits de percussion.

## ÉTAT AU R259
**R259** : (1) **Le jeu se tait et se fige sous Quantone** : un script en tête d'`index.html` enregistre tous les `AudioContext` de la page (`window.__ACS`) ; à l'ouverture de Quantone ils sont tous suspendus (vent, boucles, musique, fin), les `<audio>` en lecture mis en pause, et la boucle principale du jeu ne calcule ni ne dessine plus (`window.__QTOPEN`) ; tout est repris à la fermeture. Avant R259 seul le contexte de `sound.js` était visé (cause du vent qui continuait : le jeu en a deux). Testé : les deux contextes passent `suspended` puis `running`. (2) **Ouvrir un préréglage .json** : le bouton « Ouvrir » appliquait d'abord le texte du cadre de code (qui contient toujours le préréglage courant) et n'ouvrait donc jamais le sélecteur ; il ouvre maintenant toujours le sélecteur (sans filtre `accept`, comme pour les sons) ; nouveau bouton « Charger le code du cadre » pour le texte collé. (3) **Robustesse audio** (retours « lag, plante, la lecture ne reprend pas », annexe 3 s de sample + batterie avec fonction 1) : impossible de reproduire en Chromium (charge ≈ 15–23 %, 0 erreur, ordonnanceur < 13 ms) ; mesures prises quand même : plafond de 44 voix simultanées (grosse caisse/caisse claire toujours jouées), `try/catch` autour de chaque voix (une exception ne tue plus l'ordonnanceur), un seul shaper de saturation par graphe et par instrument (au lieu d'un par coup), reprise du contexte au toucher suivant après une interruption iOS, contexte `closed` recréé. Le jeu en pause sous Quantone doit aussi alléger beaucoup l'iPhone. À vérifier sur iPhone avec l'annexe.

## 0octies. ÉTAT AU R258
**R258** : (1) **Rythmes = un seul module** : la boîte à rythmes est dans l'éditeur de l'instrument (plus de second cadre). Doublons retirés (CC ton, CC timbre, Clap, Charley, Percussions : valeurs gardées par les kits, plus affichées). Sous la boîte : sections repliables « Son et style » (Couleur, Saturation, Salle, Volume, Réverb, Delay) et « Fonction et boucle » (les 20 fonctions mathématiques agissent aussi sur la boîte : elles décalent l'accord/le pitch des voix, répètent, filtrent les pas). (2) **Motifs en menu déroulant** (`#dmMo`, 5 familles, 49 motifs) : Bases, Genres, Esprit Aphex Twin (6), Univers QUANTIX (12 : pendule, rebond, orbite, désintégration, tunnel quantique, superposition, intrication, interférence, effondrement, zone interdite, aimant, paires du vide), Singularités (11 : Fibonacci, premiers, Thue‑Morse, π, nombre d'or, Collatz, automates règle 30/90/110, palindrome, éclat unique). Automation `dmo`. (3) **Tempo général** dans la boîte : curseur 40–180 (clé `k:tempo`, menu valeur par défaut / automation), −/+ et TAP ; la plage du bouton Tempo passe à 40–180. (4) **Batterie** : 14 voix (+ Rimshot, Bloc de bois, Shaker, Conga, Laser, Impact), 8 nouveaux kits (909 sec, Poussière lo‑fi, Industriel, Brosses, Glitch, Dub chambre, Cinéma, Verre éthéré), 2 réglages de style : Saturation (`grit`) et Salle (`room`). (5) **Panneau global « Fonctions musicales » retiré** (masqué, fonctions désactivées au chargement) : elles ne sont plus que dans les réglages de chaque instrument. (6) **Vent du jeu** : le contexte audio du jeu est suspendu pendant Quantone et repris à la fermeture. (7) **Outil Déplacer** : poignée d'échelle ⤢ (coin bas‑droit de la sélection) + pincement à deux doigts qui agrandit/réduit (15 % à 600 %), annulable. e2e : sampler 35/35, quantone 12/12, éditeur 11/11. Non vérifié : écoute des 14 voix et des kits sur iPhone ; silence du vent à l'oreille.

## 0septies. ÉTAT AU R257
**R257** : import du Sampler pour tout fichier son. Le champ fichier n'a plus de filtre `accept` (le filtre `audio/*,.json,.qsmp` grisait les .m4a du Dictaphone sur iPhone) et accepte plusieurs fichiers (remplissent les emplacements suivants) ; dépôt par glisser‑déposer sur le panneau. Décodage en cascade : `decodeAudioData` du navigateur → lecteurs maison WAV (PCM 8/16/24/32, float, A‑law, µ‑law, extensible), AIFF/AIFC, AU → lecture réelle d'un élément média capturée (30 s max, pour tout format que le navigateur sait jouer sans le décoder). Testé (Chromium) : wav 16/24/float/µ‑law, aiff, au, ogg, flac, mp3, opus (natif et sans décodeur natif). Non testables ici : .m4a/.caf/.wma (Chromium sans AAC) — sur iPhone Safari le décodeur natif lit m4a/caf. À vérifier avec un fichier Dictaphone réel.

## 0sexies. ÉTAT AU R256
**R256** : refonte du panneau Sampler (Quantone). Ordre : en‑tête → 8 pastilles d'emplacement (point = rempli) → forme d'onde 124 px (repères glissables) + info → Importer / ● Enregistrer → message d'erreur micro dédié → puces d'édition (Couper, Normaliser, Inverser, Annuler, Vider) → sections repliables Lecture (Note|Tranches, note d'origine ou nb de tranches, fondus, boucle, inversé), Hauteur et vitesse, Filtres et son, Niveau et effets, Préréglages, Fonction et boucle, Micro et fichiers (export .wav, tout exporter/importer, entrée audio). Retiré : le bouton « enregistrer avec l'appareil » (donnait de la vidéo), les curseurs Emplacement/Début/Fin/Mode (remplacés par pastilles, repères, segment). Micro : message selon l'erreur réelle (refusé / fenêtre intégrée / aucun micro / occupé) avec le nom de l'erreur entre parenthèses ; nouvel essai avec `{audio:true}` si les contraintes échouent ; bouton « Ouvrir en plein écran » si Quantone est dans un iframe sur un domaine non‑Claude. Tests e2e‑sampler adaptés (sections ouvertes d'office). Non vérifié : micro réel sur iPhone (diagnostic par le nom d'erreur affiché).

## 0quinquies. ÉTAT AU R255
**R255** : micro bloqué dans les artefacts (aucune capacité micro n'existe côté hôte, vérifié dans le contrat 0.2.85) → bouton de secours « Enregistrer avec l'appareil » (`<input type=file accept=audio/* capture=microphone>`, `#smCap`), affiché dans le message d'erreur ; l'enregistrement passe par le même import. Marche selon l'appareil (Android : enregistreur ; iPhone : non vérifié, probablement Dictaphone/Fichiers). Enregistrement micro direct : seulement sur le site hébergé (GitHub Pages) ouvert hors artefact. À vérifier sur iPhone.

## 0quater. ÉTAT AU R254
**R254** : micro du Sampler indisponible dans un artefact (l'hôte bloque getUserMedia) : message clair affiché dans le panneau Sampler (rouge, persistant) + toast remonté au‑dessus de la barre de lecture (6 s), qui masquait l'erreur. Le micro ne peut marcher que dans le jeu hébergé (iframe `allow=microphone`) ; dans l'Aperçu/Quantone publiés, importer un fichier (Dictaphone → Fichiers).

## 0ter. ÉTAT AU R253 (Quantone : X‑Y façon zone interdite, boîte seule)
**R253** : (1) **Pad X‑Y** : rendu zone interdite du jeu (fond rose‑rouge, lueur de bords, paires particule/antiparticule qui s'annihilent, onde au toucher) ; le doigt laisse un trait de la couleur du monde qui tremble ~20 ticks puis tombe en sable cosmique (~84 ticks), comme le trait refusé du jeu. Animé en continu tant que le panneau est ouvert. (2) **Boîte à rythmes sans trait** : elle joue seule, même avec un effet actif (avant : refus « vide » si un effet était activé) et à l'export .wav. e2e : sampler 27/27, quantone 12/12, éditeur 9/9. Non écouté / non vu sur iPhone. Quantone et Aperçu en ligne = anciennes versions (non republiés).

## 0bis. ÉTAT AU R252 (Quantone : rythmique fusionnée)

**R252** : (1) **Un seul menu pour la rythmique** : la boîte à rythmes n'apparaît plus que dans l'éditeur du calque Rythmes (sous le même cadre) ; le menu classique garde les réglages du kit (cc ton, timbre, clap, charley, percussions, couleur, volume, réverb, delay) ; sont masqués ce qui faisait doublon : préréglages classiques (le kit se choisit dans la boîte, liste Kit, automatable), accord / durée de la grosse caisse (réglés voix par voix), fonction et boucle (la boîte a sa propre longueur). (2) **Un trait du calque Rythmes ouvre la boîte sur son étendue horizontale** (sans trait Rythmes, la boîte joue partout ; boîte vide = silence) ; le trait lui‑même ne produit aucune note. (3) **Sampler** : changer de préréglage garde l'échantillon, la zone, la boucle et la note d'origine choisis ; ▶ sur un emplacement vide affiche « Vide ». Test : `e2e-sampler.py` 26/26.

## 0quater. Avant : ÉTAT AU R251 (Quantone : volumes, 12 instruments, boîte à rythmes)

**R251** (Quantone uniquement) : (1) **Volume** de chaque instrument (et de chaque trait « Ce trait seulement ») : 0 = muet réel, jusqu'à 300 % (avant : 0–100 %). (2) **Boîte à rythmes** : niveau des voix ×2,2 et curseur Niveau jusqu'à 240 % ; **le calque Rythmes ne joue plus que la boîte** (un trait dessiné sur Rythmes est muet ; boîte vide par défaut) ; **16 nouveaux motifs** (House, Techno, Hip‑hop, Trap, Drum & bass, Breakbeat, Reggaeton, Dub, Bossa, Afro, Jersey club, Électro, Shuffle 12 pas, Valse 12 pas, Demi‑temps, Funk, avec accents) ; **glisser le doigt peint plusieurs cases d'un geste** (la valeur du premier pas touché est appliquée à tous les pas survolés). (3) **12 instruments** : **Accords** (un trait joue un accord de la gamme : triade, septième, sus2, sus4, neuvième, quinte ; étalement ou arpège ; 4 timbres) et **Voix** (chœur à formants a·é·i·o·ou, morphing d'une voyelle à l'autre, 1–3 voix, souffle, vibrato). Test : `tools/e2e-sampler.py` 22/22. Non publié : ni Quantone ni Aperçu republiés à ce tour (économie de crédits) ; le zip contient tout.

## 0ter. Avant : ÉTAT AU R250 (Quantone : Sampler, 3 instruments, 10 fonctions)

**R250** (aucun changement de niveau) : `studio/quantone.html` passe à **10 instruments** — Corde (Karplus‑Strong), Écume
(résonateurs sur bruit), Onde (morphing de deux timbres), **Sampler** (8 emplacements de 30 s, gardés dans IndexedDB, export
.wav et bibliothèque .qsmp). Sampler : import de fichier, micro / interface (liste des entrées, ● Enregistrer), forme d'onde
avec repères glissables (début, fin, boucle), Couper / Normaliser / Inverser / Annuler / Vider, lecture en note transposée
(note d'origine) ou en tranches, hauteur, vitesse (avec « garder la hauteur » par étirement granulaire), fondus, filtres
passe‑haut / passe‑bas, bitcrush, saturation, compresseur, chorus, panoramique + réverb et delay du bus. **Tous les réglages
sont des commandes à valeur : menu Valeur par défaut / Automation** (clés `ik:9:<réglage>`). Dix **nouvelles fonctions** (11 à 20,
d'après les vidéos « Jersey Club II » et « Math functions that go way too hard ») dans la liste Fonction de chaque instrument :
Fibonacci mod 3, une note sur deux (accord), percussion première (pas premiers), battement de cœur (5 cloches P‑Q‑R‑S‑T),
la goutte (+7 demi‑tons en 40 ms), triangle arcsin(sin x), montée · chute · boucle, pédale tanh (k = 1, 3, 9, 27), chirp de trous
noirs (f ∝ (tc−t)^−3/8), final II (cœur + tanh). Grille des instruments : 4 colonnes. `allow="microphone"` sur l'iframe du jeu.
Test : `tools/e2e-sampler.py` (16/16) ; e2e Quantone 12/12 et éditeur 9/9 inchangés.
**Pas encore fait** : les 10 nouvelles fonctions ne sont pas dans le panneau « Fonctions musicales » R107 (processus globaux) ;
le sampler ne sait pas encore lire un échantillon pendant l'export .wav en tranches avec la position verticale (retombe sur la note) ;
l'automation n'est pas encore dans l'export .wav ; micro non vérifié sur iPhone (testé avec fausse entrée Chromium) ;
dans l'artefact Quantone publié, le micro dépend de la fenêtre hôte (pas de capacité micro offerte) — l'import de fichier marche.

## 0bis. Avant : ÉTAT AU R249

**Dernier zip** : `QUANTIX-SITE.zip`, tampon **« build R249 · Lisibilité des éléments jouables »**. Vérifier avant tout travail :
`grep -o 'build R[0-9]*' index.html` doit afficher R249 (sinon ce n'est pas le dernier zip : le demander à Simon).

**Depuis R209** : nouvelle fin `fin5` construite dans le **Banc de la fin** (R210–R231, annotations de Simon), **validée et jouée
par le jeu depuis R233** (`window.QFIN_A=false` rétablit la fin R207, pour le banc seulement) ; monde 7 Gravité refondu (R233) ; monde 8 Magnétisme refondu (R238 : 89, 92, 94 nouveaux, `mz` retirées) ; monde 9 Faille refondu (R241 : niveaux 1, 5, 8, 9, 11 nouveaux) ; vibrations proposées (`haptics.js`, non chargé par le jeu) ;
Quantone : menu de commande + automation (R231), boîte à rythmes à pas (R232). Détail : `PASSATION_R232.md`.

**Dans le jeu (déployable)** : accueil Visière + héros « L'odyssée » ; Constellation, pages de monde ; 132 niveaux ; plein
cadre ; didacticiel holographique (règles R202) ; bilan animé par issue ; **fin « Les retrouvailles »** (prélude dans le
niveau, poursuite de retour à deux particules, plongée dans le trou noir, danse dans la sphère, titre QUANTIX, bouton
Bilan) ; **bilan du parcours** (9 mesures, journal `JR` sauvegardé) ; Quantone intégré ; FR/EN ; sauvegarde locale.

**Construit mais caché** : Zen Lab, Quantum Drop, atelier de particule (D5). **Prêt mais inactif** : bouton Ko-fi (`KOFI=''`).

**Chiffres (16 oct., R233)** : solutions de référence 104/132 ; contournables 24 (mondes 5, 6, 9–11 ; mondes 7 et 8 : 0) ; zones de réussite
occupées 2 (#21, #34) ; zones invisibles `mz` 3 niveaux (R238) ; musique propre 1 monde sur 11 ; 13 chaînes FR en dur.

**Tests verts (16 oct.)** : audit, strict, tutotest, monde1 à monde5, **monde7** (R233), **monde8** (R238), **monde9** (R241), render, replaytest, savetest, maptest, e2e-didacticiel 32/32,
e2e-éditeur 25/25, e2e-Quantone 12/12.

**En cours (R234)** : bande son de la fin (`assets/js/fin-sound.js`, dans le jeu et l'aperçu), à écouter par Simon ;
monde 7 refondu (R233), monde 8 refondu (R238, aperçu publié), à juger ; ensuite monde 9.
Quantone : choix des 3 nouveaux instruments, automation dans l'export .wav, Quantone de l'Aperçu à mettre à jour (questions
reposées R233). Vibrations : tests iPhone.

**Jamais vérifié** : performances sur iPhone réel (héros, épilogue, monde 8), avis de joueurs extérieurs.

- **R263** (22 oct.) : régression du fond Magnétisme non reproduite (niveaux 85–86 chargés directement, Chromium sans GPU) ; `tools/probe_ferro.py` ; `DEMARRAGE.md`.
- **R264** (22 oct.) : inventaire, exigences à maintenir et liste de nettoyage (`NETTOYAGE.md`) ; Menu édition supprimé (`studio/menu-edition.html` retiré, `build-menu.py` et `MENU_EDITION.md` archivés).
- **R265** (23 oct.) : nettoyage (`NETTOYAGE.md` §5) : `DEMARRAGE.md`, `probe_ferro.py`, 4 documents de la fin et `redundancy.js` rapatriés dans le zip ; 34 documents retirés du Projet ; 15 mis à jour ; artefact Menu édition supprimé sur accord de Simon (23 oct.). Aucun changement de code.
- **R266** (23 oct.) : journal local des essais (`runlog.js`, `quantix.runs.v1`, plafond 1 500, traits réduits à 28 points, identifiant aléatoire, aucun envoi) ; Paramètres « Mes parties » : Exporter (partage ou téléchargement du JSON), Effacer (double toucher) ; textes FR/EN. Tests : audit, strict, savetest, tutotest, essai Chromium (essai enregistré, abandon, export, effacement). Non testé : iPhone, partage de fichier Safari.
- **R267** (23 oct.) : envoi anonyme des parties (`runlog.js`, Web3Forms) : choix unique Oui/Non à la 1re réussite (consentement explicite, pas de case pré-cochée : demande de Simon adaptée au RGPD), case par niveau, lots de 40 essais, 1 envoi max / 90 s, envoi forcé à la fermeture de la page ; réglage Paramètres ; inactif tant que `SHARE_KEY` est vide. Testé avec un faux service (Chromium) : invite, Oui, case, requête (clé, objet, 1 essai), marquage envoyé. Non testé : vrai service, iPhone.
- **R268** (23 oct.) : clé Web3Forms posée (`SHARE_KEY`), envoi actif ; test réel impossible depuis la session (proxy 403) : à vérifier sur iPhone par Simon.
- **R269** (23 oct.) : invite d'envoi refaite sur retour de Simon (texte invisible, bouton mal rendu, bilan pollué) : fenêtre à part au 1er « Suivant/Continuer » sans réponse, bilan inchangé tant qu'il n'y a pas de Oui, puis une ligne discrète (case cochée). Vérifié sur captures Chromium (bilan propre, fenêtre) et requête simulée. Non vu : la ligne discrète après Oui, iPhone.
- **R270** (23 oct.) : mail des parties : objet « Niveau N « nom » · réussi · x essai(s) », corps en champs (Joueur, Statistiques, message = détail par niveau, Donnees_JSON), pièce jointe `.json` tentée d'abord (multipart) puis repli JSON texte. Testé (Chromium, faux service, les deux voies). Non vérifié : si l'offre gratuite Web3Forms accepte la pièce jointe.
- **R271** (23 oct.) : clé de consentement renouvelée (ancien « non » de R268 bloquait l'invite sur carrière commencée). Hypothèse, non reproduite sur iPhone.
- **R272** (23 oct.) : banc des rendus : aspiration par le trou noir (canvas autonome, texture fractale en 3 couches, spirale, étirement, éclat). Vérifié sur captures Chromium ; non vérifié sur iPhone ni dans le jeu.
- **R273** (23 oct.) : refonte du banc : 3 propositions d'aspiration (A/B/C), charte du héros ; captures Chromium ; non vérifié iPhone.
- **R274** (23 oct.) : banc : variantes B2/B3 de la toile (poussière en sprites + voiles de bruit, anneaux rose/blanc/cyan, cœur blanc texturé, flash à 3,2 s). Captures Chromium ; non vérifié iPhone.
- **R275** (23 oct.) : banc : début de niveau, deux propositions (studio/galerie-naissance.html). Captures Chromium ; non vérifié iPhone.
- **R276** (23 oct.) : banc : vraie particule (VX.ball), explosion verte soignée. Captures Chromium ; non vérifié iPhone ; « b1 » interprété comme B2.
- **R277** (23 oct.) : banc : naissance A fronde / B chute, fondu progressif, trajectoires précalculées. Captures Chromium ; non vérifié iPhone.
- **R278** (23 oct.) : banc : naissance sur niveau réel, vraie particule non teintée, fronde / ressort. Vérifié sur captures Chromium ; non vérifié iPhone. Le banc complet ne se charge pas dans Chromium sans GPU (non lié).
- R279 : banc des rendus — fin de niveau refaite sur la vraie zone d'arrivée (niveau 41, bille réelle sans teinte, anneau vert = trou noir, explosion verte) ; entrée = variante A (fronde) seule. Jeu non modifié. Intégration à valider.
- R280 : intégration des transitions (transitions.js) : aspiration à la réussite (bilan à 3 s) et fronde à l'entrée de niveau ; jeu modifié.
- R281 : grille de fond retirée des transitions (entrée et sortie).
- R282 : entrée retardée tant qu'un voile (carte du monde…) couvre le niveau.
- R283 : entrée jouée aussi quand l'outil sélection/échelle est actif (condition EDT.active retirée).
- R284 : effets sonores d'entrée et de sortie de la particule (6 sons procéduraux, discrets), level_success calé sur l'éclat.
- R285 : sons de transition renforcés (plus forts, registre plus haut).
- R286 : sons ×0,75 ; captation parcours (runlog bp+onrun, apercu-capture.js, build-apercu capture + runlog inclus) ; docs/PARCOURS_BETA.md.
- R287 : runlog tl (outils), parcours-rapport.py, protocole de révision dans PARCOURS_BETA.md.
- R288 : EDT.hook (mesure outils) ; analyse du 2e passage (110 essais).
- R289 : events.js (journal d'événements), EDT.hook multiple, Aperçu→evenements_beta, docs/AUDIT_DONNEES.md.
- R290 : worker/ (ingestion), consentement dès le 1er essai, panneau données, i18n.
- R291 : ENDPOINT Worker branché ; Worker + D1 déployés par Simon.
- R292 : diagnostic d'envoi visible dans le panneau ; lot borné, sans keepalive.
- R293 : tools/rapport-evenements.py (export serveur, base Aperçu, anciens essais) ; /export?dl=1 dans worker/ingest.js (à redéployer).
- R294 : admin.html (export par clé), bouton d'export des événements dans l'app, journal riche validé de bout en bout.
- R295 : géométrie finale des traits à chaque lancer (la.g), déplacements mov dx/dy, distance tracé↔référence dans le rapport.
- R296 : animations d'entrée/sortie (trou noir) actives par défaut (le réglage iOS « réduire » n'est plus repris d'office) ; « Relancer » grisé pendant l'aspiration.
- R296 (scan) : 28 niveaux scannés de plus (128/132) ; tools/scan-rapport.py + docs/SCAN132_RAPPORT.md ; 30/114/120/132 trop lourds.
- R297 : calibrage de l'encre (docs/CALIBRAGE_ENCRE.md, tools/calibrage-encre.py) ; règle à 3 profils proposée, rien appliqué.
- R297 : encre resserrée sur 7 niveaux (60, 90, 97, 103, 113, 121, 122) ; règle d'encre validée dans REGLES.md.
- R297 (banc) : 3 propositions de lisibilité des zones interdites dans le banc des rendus (v31) ; rien dans le jeu.
- R297 (banc v32) : zones interdites = rendu d'origine + texture d'encre (3 variantes) ; essais précédents écartés.
- R297 (banc v33) : Nervures animées (sobre/riche) pour les zones interdites ; rien dans le jeu.
- R297 (banc v34) : nervures animées 4x plus vives ; analyse export 4 joueurs (N21/N22 durs).
- R297 (banc v35) : nervures sobre ajustée (voile léger, contraste derrière) ; docs/STRATEGIE_DONNEES.md.

- 2026-10-25 · Banc v36 : variante zones « sobre ajustée, rouge, plus rapide » (banc seul, jeu inchangé R297).
- 2026-10-25 · Banc v37 : variante zones allégée (opacité globale, brume réduite, respiration d'opacité).
- 2026-10-25 · R298 : nervures rouges animées intégrées sous les zones interdites (atlas WebP, repli automatique).
- 2026-10-25 · Outil replay-reel.js (rejeu des tracés réels, contrefactuel) ; test N21.
- 2026-10-25 · Audit de conception des 132 niveaux (AUDIT_CONCEPTION.md), outils audit-*.
- 2026-10-25 · MODES_DIFFICULTE.md (spécification 3 modes + enjeu, réflexion sur les vies).
- 2026-10-25 · Refonte simulée du monde 3 (banc tools/refonte, 2 aperçus).
- 2026-10-25 · R299 : ruban réglé (moteur, non-régression 132 niveaux) ; refonte monde 3 v2 (aperçu).
- 2026-10-25 · R300 : code couleur de vitesse des rubans ; refonte monde 3 v4 (fiches Opus, 11 niveaux redessinés, aperçu).
- 2026-10-25 · R301 : refonte monde 3 v5 (machines à vitesses, « Après ton passage », îlot lent ; aperçu).
- 2026-10-25 · R301 : refonte monde 3 intégrée au jeu (niveaux 27–36, courbes avec vitesse, tracé pendant la course) ; zip envoyé.
- 2026-10-25 · R302 : monde 5 lot 1 intégré (49,50,51,52,54,57,60), bouton rejouer pour le noyau ; zip envoyé.
- 2026-10-25 · R303 : icône animée du noyau sur le bouton rejouer ; fiches monde 9 Faille lancées.
- 2026-10-25 · R304 : icône du bouton rejouer = noyau d'Enneper allégé (remplace l'étoile).
- 2026-10-25 · R305 : icône du bouton rejouer = contours blancs (option E) ; banc des 6 propositions publié.
- 2026-10-25 · R306 : icône du bouton rejouer = deux boucles blanches, halo bleuté.
- 2026-10-25 · R307 : icône rejouer réparée, aperçu avec nervures, règles (nommage, géodésique par le joyau) ; banc des portails publié ; refonte monde 9 niveaux 6/7/8/10/11 en cours.
- 2026-10-25 · R308 : icône du bouton rejouer (carré bleu ::before supprimé, canvas animé en boucle).
- 2026-10-25 · R309 : poussière de machine corrigée (6 et 12 seulement) ; banc portails v2.
- 2026-10-25 · R310 : portail unifié intégré (VX.portal) ; aperçu monde 9 sur niveaux réels.
- 2026-10-25 · R311 : axe de sortie des portails (portal-axes.js), hélices loin des portails, Faille 1 hélice.
- 2026-10-26 · Monde 9 v2 (niveaux 6,7,8,10,11) assemblé en aperçu ; flow.js par rang ; emit.js grav.
- 2026-10-26 · R312 : portails devant le vortex d'arrivée.
- 2026-10-26 · R313 : monde 9 v2 intégré.
- 2026-10-26 · R314 : monde 11 refondu (12 niveaux).
- 2026-10-26 · R315 : monde 11 niveau 12 ancien restauré, nouveau Quantix devient niveau 6 « L'atome ».
- 2026-10-26 · R316 : monde 11 partiellement restauré (garde 2, 4, 7 et L'atome en 6).

- 2026-10-27 · R317 : intrication v2 intégrée (lien chaos + jumeau + anneau, radar D1, losange R2) ; niveaux monde 11 à un seul noyau.
- 2026-10-27 · R318 : fin des mails par partie ; alerte unique nouveau joueur.- 2026-10-27 · R319 : monde 11 refait (12 niveaux), radar/jumeau/mèche redessinés, 10 fiches quantiques.

- 2026-10-27 · R319 : monde 11 refait (agent) ; R320 : musique monde 2 générative, son coupé en arrière-plan.
- 2026-10-27 · R321 : monde 3 musique générative branchée ; aperçu jouable des sons (mondes 2-3) + monde 11 publié.
- 2026-10-27 · R322 : sons v2 (progression plus rapide, rythme dès niveau 2), aperçu publié.- 2026-10-27 · R323 : batterie (kits) + beat brisé/bégaiement dès niv. 6, monde 4 sonore, zip avec studio/quantone.html (make-zip.sh).
- 2026-10-27 · R324 : socle sonore = extraits des rendus Quantone, cloches/arpèges retirés.
- 2026-10-27 · R325 : BO mondes 4-5 (socle Quantone + textures), aperçu v18 ; mondes 6-7 en rendu.
- 2026-10-27 · R326 : mondes 4-5 jouent fidèlement les rendus Quantone (plus de filtre/nappe/aléatoire).
- 2026-10-27 · R327 : BO mondes 1-5 complète (60 rendus), Quantone +5 fonctions équations, liste triée par type.
- 2026-10-27 · R328 : Quantone — boîte propre à chaque trait Rythmes, 20 motifs Esprit Aphex Twin, pool de samples, outil Point.
- 2026-10-27 · R329 : Quantone — 62 gammes par familles.
- 2026-10-28 · R330 : éditeur de morceaux multipiste (studio/morceau.html), mixeur + master + FX, import audio, export WAV.
- 2026-10-28 · R331 : menu Fichier simplifié, boîte à rythme (réglages par voix, samples, motifs perso), passerelle Quantone/Morceau, FORMATS.md.
- 2026-10-28 · R332 : 80 samples de pool, 30 kits texturés par thème, gamme « Aucune ».
- 2026-10-28 · R333 : traits Rythmes superposés jouent tous.
- 2026-10-28 · R334 : gamme Aucune par défaut, réglages de trait conservés au changement d'instrument, « Style @ ».
- 2026-10-28 · R335 : bibliothèque de boucles partagée, palette + outils dessiner/effacer/déplacer/couper dans Morceau, aller-retour Quantone.
- 2026-10-28 · R336 : Morceau habillé aux couleurs de Quantone/Quantix (icônes SVG, néons, balle-tête de lecture, animations).
- R337 (28 oct.) : BO fins de monde allégées (niv. 9–12, mondes 1–5), gain −3 %/niveau dès le 7, w5 sans sifflements.
- R338 (28 oct.) : BO 11 mondes complète, blancs supprimés, fondu 7 s entre mondes, musique −3 dB en page de niveau, vortex balle molle.
- R339 (28 oct.) : BO v2 — recettes par monde, 6 bégaiements Quantone, samples assagis/recréés, aigus supprimés.
- R340 (29 oct.) : arrêt de la refonte audio R319–R339 (BO R339 gelée, rejetée) ; pack de passation REFONTE_AUDIO_00…07 + dossier externe + outils `tools/bo` ; code inchangé ; réversible : oui (documents seuls).
- R340b (30 oct.) : quiz de reprise audio mené ; `traversee_rythme.mp3` rejeté (refaire autrement) ; décisions D1–D10 dans `DECISIONS_AUDIO.md` ; lot A accepté, attend le zip du site R339 ; code inchangé ; réversible : oui (documents seuls).
- R340c (30 oct.) : lot A — audit d'exécution audio (`AUDIT_EXECUTION_AUDIO.md`, `tools/audio-trace.js/.py`) : 2 contextes dont 1 silencieux, erreur NaN `TXN.bar` après mute, impacts bas vs musique ; rien écouté ; code inchangé R339 ; réversible : oui.
- R340d (30 oct.) : lot B — `BIBLE_SONORE_V2.md` (règles R1–R11, 11 fiches rythme/matière, matrice de différenciation vérifiée) ; réponses de Simon au lot A consignées (impacts, tracé, accueil) ; documents seuls, aucun son ; réversible : oui.
- R340e (30 oct.) : lot C — prototype Atelier (`LOT_C_ATELIER.md`, `lotC*.py`) : v1 bois seul rejetée (squelette, 55–84 % de silence), v2 remixée des rendus Quantone aimés (mosaïque 1077 tranches, groove 76 BPM, lit de grain, réverb) « mieux » ; v2 corrigée (grincement = pics fixes 366/658/784/1978/2351 Hz du lit supprimés ; niveau −33,5 dBFS RMS) ; verdict attendu ; aucun fichier du jeu modifié ; réversible : oui.
- R341 (30 oct.) : Quantone stable — Q1 banc de mesure (`QUANTONE_BANC_Q1.md`, `q1-*`), Q2 Morceau allégé (`studio/morceau.html` : effets à la demande, clips par fenêtre de 24 s, IR/courbe en cache ; graphe 493→61 ms, export 74→11,6 s, RSS lecture 821→551 Mo) ; tampon R341 ; `tools/e2e-morceau.py` ; chantier audio en pause ; réversible : oui (restaurer `studio/morceau.html` R339 et le tampon).
- R342 (30 oct.) : Quantone — banque de 399 sons en 2 packs hors zip (`packs/`), catalogue `assets/bank/bank.json`, écran Banque dans le sampler, caches de variantes bornés (40 Mo) ; workflow GitHub : ligne de copie `packs/`→`_site/assets/bank/` ; `tools/e2e-banque.py` 8/8 ; réversible : oui (restaurer `studio/quantone.html` R341 et le tampon).
- R343 (31 oct.) : Banque — pack FX synthétisé (245 sons, 8 familles), 644 sons en 3 packs ; packs à la racine du dépôt, workflow `cp -a pack-*.bin` ; e2e-banque 10/10 ; réversible : oui (retirer `pack-fx.bin` et restaurer `bank.json`/quantone R342).
- R344 (31 oct.) : Quantone — arrêt sans reconstruction du moteur (impulsion en cache, renouvellement différé), relance protégée, filet d'erreurs affiché ; `tools/e2e-arret.py` ; réversible : oui (restaurer `studio/quantone.html` R343 et le tampon).
