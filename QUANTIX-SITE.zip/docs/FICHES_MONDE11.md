# QUANTIX — Monde 11 « Quantique » : 12 fiches de conception (monde 11, niveaux 1 à 12)

26 oct. 2026 · concepteur de niveaux · **géométrie chiffrée et prouvée au banc** (vrai moteur R313, emplacements 120–131).
Refonte de fond : remplace les 12 niveaux actuels (`levels.js`, `wd:11`). Ce document ne modifie rien d'autre.
Source unique des candidats : `scratchpad/m11/v1.js` (format de `m9/v2.js`, rubans par `tools/refonte/rib.js`).
Mesures : P_ligne sur 40 tracés bruités (σ = 3), P_hasard sur 2 500 lignes droites au hasard, retrait de chaque élément.
Nommage : toujours « monde 11, niveau M ».

## 0. Résumé du monde

**Phrase du monde : « Deux chemins à la fois. »** Le monde a un instrument : **le cœur** — deux miroirs courbes qui
reçoivent les deux copies nées du dédoublement, comme les deux bras d'un interféromètre. Le cœur revient d'un niveau à
l'autre et change de sens : on y apprend qu'**il suffit d'une** copie (1), qu'**il faut les deux** (5), et à la fin qu'**il
ne faut pas les deux** (11). La finale (12) le referme sur un **atome** : les jumelles réunies tournent sans fin jusqu'à ce
qu'on les libère.

**Courbe (Ki → Ketsu)**
- **Ki (1–3)** : se dédoubler et sauver une seule copie (1) ; la mesure choisit la copie réelle — on sauve celle qu'elle a
  choisie (2) ; l'une ouvre la porte de l'autre (3).
- **Shō (4–6)** : le temps de chaque copie — ralentir la seconde pour qu'elle arrive après (4) ; les réunir (5) ; un seul
  trait pour deux chemins, dans une machine à rubans (6, machine).
- **Ten (7–9)** : compter les bascules (7) ; mesurer pour ouvrir, en mesurant la bonne (8) ; gagner du temps pour
  se rejoindre (9).
- **Ketsu (10–12)** : une porte ou l'autre, la mesure choisit (10) ; renversement : fermer un chemin pour passer (11) ;
  Quantix, la synthèse à deux traits (12, finale, machine).

**Éléments introduits, dans l'ordre** (tutoriel demandé) : dédoublement `sup` (1) · détecteur `det` (2) · intrication
`ent` + porte `gate` (3) · dilatation du temps `tdil` (4) · recombineur `rec` (5) · rubans réglés `curves` v=10/2 et
poussière `flow` (6, machine) · parité d'une paire (7) · mesure qui bascule une paire `det[3]` (8) · or + recombineur (9)
· paire opposée `'opp'` (10) · guides d'onde (parois doubles + zones interdites) (11) · champ magnétique `bf` (vide),
détecteur-gardien, rubans (12).

**Cibles** (Simon, DIFFICULTY_PROTOCOL) : P_hasard niveaux 1–5 ≤ 3 % · 6–9 de ≤ 3 % à ≤ 1,5 % (6 ≤ 3 · 7 ≤ 2,5 · 8 ≤ 2 ·
9 ≤ 1,5) · 10–12 ≤ 1 %. P_ligne ≥ 85 %. Sans trait, la balle échoue ; la référence passe **toujours par le noyau**.

### Bilan mesuré (banc, moteur réel R313, `v1.js`, 2 500 lignes, 40 tracés bruités)

| Niveau | Titre | Brique | Encre réf / dispo | Durée réf | Sans trait | Réf + noyau | P_ligne | P_hasard | cible | conforme |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Deux chemins | sup | 50 / 62 | 1,8 s | échoue | oui | 90 | 2,68 | ≤ 3 | oui |
| 2 | La mesure | det | 147 / 170 | 3,1 s | échoue | oui | 100 | 0,04 | ≤ 3 | oui |
| 3 | Le lien | ent + gate | 43 / 62 | 1,9 s | échoue | oui | 95 | 2,32 | ≤ 3 | oui |
| 4 | Le temps ralenti | tdil | 90 / 110 | 3,8 s | échoue | oui | 100 | 0,68 | ≤ 3 | oui |
| 5 | Réunies | rec | 64 / 90 | 1,9 s | échoue | oui | 90 | 0,44 | ≤ 3 | oui |
| **6** | **L'interféromètre** (machine) | rubans + rec | 112 / 140 | 2,5 s | échoue | oui | 100 | ≤ 3 | oui |
| 7 | Pair, impair | parité | 61 / 80 | 1,8 s | échoue | oui | 88 | ≤ 2,5 | oui |
| 8 | La mesure-clé | det[3] | 75 / 84 | 1,9 s | échoue | oui | 100 | 1,80 | ≤ 2 | oui |
| 9 | Gagner du temps | tdil + rec | 115 / 120 | 1,9 s | échoue | oui | 93 | 1,80 | ≤ 1,5 | **écart 0,3 pt** |
| 10 | Le choix | det + `opp` | 59 / 70 | 2,5 s | échoue | oui | 85 | 0,72 | ≤ 1 | oui |
| 11 | Fermer un chemin | rec (renversé) | 38 / 50 | 1,9 s | échoue | oui | 100 | 0,92 | ≤ 1 | oui |
| **12** | **Quantix** (finale) | tout + `bf` | 143 / 200 (2 traits) | 2,9 s | échoue | oui | 83 | ≤ 1 | P_ligne 83 (écart 2 pts) ; P_hasard 0,08 |

« Hors idée » = lignes au hasard gagnantes **sans** l'événement requis (`need` dans `v1.js` : dédoublement, mesure,
bascule, fusion). Mesuré : 0 partout, sauf niveau 6 (1 / 2 500) et 9 (1 / 2 500) ; niveau 12 : 0 / 2 500.
Vérification du pipeline : `levels.js` émis par `emit.js` (copie de travail étendue) chargé dans le moteur — les 12
niveaux échouent sans trait et réussissent avec `optsol`, noyau pris (`m11/chk_emit.js`).

---

## 1. Cadre commun (à lire avant les fiches)

### 1.1 Ce que le moteur fait (lu dans `engine.js`, voir `MONDE11_MOTEUR.md`) et ce que le banc a appris
1. **Dédoublement** : rotation ±angle de la vitesse à l'entrée du rectangle `sup` ; une fois par essai. Tous les niveaux
   partent du même geste : la balle tombe 26 u et se dédouble en (165..195, 56..80), angle 1,2 rad (niveau 1 : 0,8).
2. **Recharge des noyaux : 18 images** (`st.cd`). Deux contacts à moins de 19 images d'écart **ne comptent qu'une fois** —
   piège réel (niveau 7 : le noyau A a été remonté pour que les deux passages comptent).
3. **Une copie posée à moins de 20 u d'un noyau le bascule toutes les 19 images** (métronome involontaire). Règle de
   construction : aucun noyau près d'un point de repos ; le noyau B d'une trappe est placé **sous** elle, à > 20 u du fond
   du bassin (niveaux 3, 4, 10).
4. **Le détecteur n'agit que pendant la superposition** ; après un effondrement (copie morte), il est inerte (niveau 12 :
   s'en servir comme **gardien** — une copie seule y est mesurée et referme la sortie, la particule réunie passe).
5. **Le recombineur** pose la particule réunie au centre, avec une vitesse **imposée** (`rec[5]`) : trajectoire réunie
   déterministe, indépendante du trait. C'est ce qui permet le bassin de côté (5), le tir de la machine (6) et l'orbite (12).
6. **`bf` vide** (`bf[5]=1`) : orbite circulaire de rayon v/ω (ω = 0,133 → r ≈ 38 pour v = 5). Une particule **créée** dans
   le champ (recombineur) peut y tourner sans fin ; une particule qui y entre de l'extérieur en ressort.
7. **Rubans réglés** (R299) : tendent vers la vitesse cible ; servent ici à **régulariser le temps** (machine 6, finale 12,
   lanes lentes des niveaux 2 et 4) et à donner le rythme (blanc 10 → violet 7 → turquoise 2/3).
8. **Leçons de construction** : un miroir courbe doit **commencer en amont** de la trajectoire de la copie (sinon la copie
   heurte son extrémité et rebondit) ; un trou de trappe n'avale une copie que si elle arrive lentement ou verticalement ;
   tout « attendre devant la porte » contourne une énigme de retard → trappes **en pente** (niv. 4) ou zone interdite.

### 1.2 Raccourcis génériques (cherchés dans chaque niveau)
- **R-a** dévier la balle avant le dédoublement : interdit partout (bande `nd` du haut, y < 96).
- **R-b** **empêcher** au lieu de **provoquer** : empêcher un événement ponctuel (une mesure, une bascule) est presque
  toujours facile au hasard (premiers essais du niveau 2 : 13 % ; niveau 11 sans guides : 16 %). Règle retenue : **chaque
  niveau demande de provoquer** quelque chose (toucher, mesurer, réunir, libérer) ; là où il faut empêcher (11), l'endroit
  d'action est réduit à une **fenêtre** dans un guide.
- **R-c** **attendre** : une copie qui patiente devant une porte fermée annule toute énigme de temps (traité aux niveaux 4 et 7).
- **R-d** **la copie seule** : dans les niveaux à recombineur, une copie seule (non réunie) ne doit jamais atteindre le
  bassin : lèvre à pointes (5), mur au-dessus du bassin (6), zone interdite sous le croisement (9, 11), gardien (12).
- **R-e** tir au hasard (P_hasard), tri « dans l'idée » par événements.

### 1.3 Non-redondance
Chaque niveau a un verbe propre (matrice en fin de document). Les éléments des mondes précédents sont rares et ont une
fonction : rubans réglés (monde 3) aux niveaux 2, 4 (régulateurs), 6 et 12 (machine) ; pointes (monde 2) en garde.

### 1.4 Langage visuel requis (rendu ; voir points à vérifier)
- Le **cœur** : deux miroirs-lumière symétriques ; il doit se lire comme un instrument, pas comme un décor.
- **Liaison détecteur → paire** (`det[3]`) et **paire → porte** : un fil visible (niveaux 8, 10, 12). Les noyaux posés
  dans la bande du haut (8, 10, 12) sont des **témoins** de l'état (inaccessibles) : à dessiner plus petits.
- **Paire opposée** (niveau 10) : spins contraires dessinés (`VX.qent` le fait).
- **Guides d'onde** (niveau 11) : les zones interdites qui remplissent les guides (24 rectangles) doivent se lire comme
  l'intérieur des guides (texture « Nervures » sobre), fenêtres nettes.

---

## Monde 11, niveau 1 · Deux chemins
- **Temps** : Ki 1. **Type** : SAUVER UNE COPIE. **Élément introduit** : dédoublement.
- **Idée** : la balle tombe dans le dédoublement juste au-dessus du bassin ; sans lui, elle y tomberait droit. Les deux
  copies s'écartent en fontaine et tombent sur les pointes de part et d'autre. Un seul trait sauve **une** copie : il suffit
  qu'une arrive.
- **Ce que ça enseigne** : les deux copies sont réelles en même temps ; une copie peut mourir sans que l'essai échoue.
- **Géométrie** : balle (180,30) ; `sup` [165,56,30,24, 0,8] ; bassin [154,476,52,'B'] entre deux sols à pointes ;
  murs latéraux ; `nd` [0,0,360,96] ; encre 62 ; noyau (122,358).
- **Trajectoire de référence (1,8 s)** : trait (30,376)→(76,396) dans le coin gauche ; la copie gauche y rebondit, décrit
  un arc et retombe dans le bassin en prenant le noyau ; la droite meurt.
- **Contournements écartés** : dévier avant le dédoublement (nd) ; deux familles symétriques (gauche/droite), le noyau
  récompense la gauche.
- **Rôle des obstacles** : `sup` (retiré → la balle tombe seule dans le bassin : indispensable) ; sols à pointes (sanction
  des deux copies) ; murs (bornes).
- **Mesures** : 2,68 % ; P_ligne 90. **Point faible** : niveau sobre (fontaine nue) ; l'aisance au hasard est due aux deux
  familles symétriques — voulu pour un premier niveau.

## Monde 11, niveau 2 · La mesure
- **Temps** : Ki 2. **Type** : LA MESURE A CHOISI. **Élément introduit** : détecteur.
- **Idée** : la copie droite a sa route vers le bassin (cascade de trois lanes turquoise lentes, v=2) ; sans détecteur, elle
  y arriverait seule. Mais la copie gauche traverse le détecteur dès sa naissance (dans la bande interdite : impossible à
  empêcher) : elle devient réelle, la droite s'efface. Il faut donc **emmener la copie mesurée sur la route de l'autre** :
  un long pont sous la cloison jusqu'à la lane 3.
- **Ce que ça enseigne** : la copie touchée devient la seule réelle ; on ne sauve plus celle qu'on voulait.
- **Géométrie** : miroir gauche T ; cloison (176,100)→(176,276) ; lanes v=2 : (222,120)→(318,186), (334,214)→(232,266),
  (204,318)→(304,382) ; `det` (132,96, r18) ; bassin [276,476,80,'B'] ; encre 170 ; noyau (150,286).
- **Référence (3,1 s)** : (60,280)→(202,318) ; la copie mesurée rebondit sur le haut du trait, roule sous la cloison, prend
  le noyau, descend la lane 3 et tombe dans le bassin.
- **Contournements écartés** : empêcher la mesure (détecteur dans la bande interdite) ; la cascade attrape tout ce qui
  tombe du centre → cloison, et la lane 3 commence à droite de la cloison (premier essai sans cloison : 4,8 %).
- **Rôle** : `det` (retiré → la copie droite réussit seule : indispensable) ; cloison (empêche la récupération facile) ;
  lanes lentes (le chemin « de l'autre », lisible et lent).
- **Mesures** : 0,04 % ; P_ligne 100. **Point faible** : très peu de familles (P_hasard quasi nul) ; trait long (147).

## Monde 11, niveau 3 · Le lien
- **Temps** : Ki 3. **Type** : COOPÉRER. **Élément introduit** : intrication et porte.
- **Idée** : la copie droite se pose sur une trappe fermée au-dessus du bassin. Le noyau A est de l'autre côté de la
  cloison, à l'écart de la chute de la copie gauche ; le noyau B est sous la trappe, dans le bassin. Un petit déflecteur
  envoie la gauche sur A : la trappe s'ouvre, la droite tombe (et referme la porte en passant devant B).
- **Ce que ça enseigne** : une copie agit pour l'autre ; toucher un noyau change l'état de son jumeau.
- **Géométrie** : miroir gauche T ; cloison (204,250)→(204,476) ; `ent` A (150,300) – B (285,436) ; `gate`
  (232,410)→(338,410) ; bassin [230,476,110,'B'] ; encre 62 ; noyau (122,272).
- **Référence (1,9 s)** : (58,280)→(96,300).
- **Contournements écartés** : la gauche qui ouvre puis passe elle-même (cloison) ; noyau trop près de la chute (déplacé).
- **Rôle** : `ent`+porte (retirés → la réf échoue ; porte retirée → la droite réussit seule) ; cloison (indispensable).
- **Mesures** : 2,32 % ; P_ligne 95.

## Monde 11, niveau 4 · Le temps ralenti
- **Temps** : Shō 4. **Type** : PERDRE DU TEMPS. **Élément introduit** : dilatation du temps.
- **Idée** : deux **tuyaux d'or** côte à côte. La copie gauche descend le premier (lente) et touche A en bas : la trappe
  s'ouvre tard (≈ 2 s). La droite file sur une lane en pente (v=3), passe sur la trappe encore fermée et meurt. Il faut la
  jeter dans le second tuyau d'or : ralentie à son tour, elle tombe à la verticale sur la trappe **après** son ouverture.
- **Ce que ça enseigne** : l'or ne change pas le chemin, seulement l'heure d'arrivée ; deux copies, deux temps.
- **Géométrie** : deux miroirs T ; tuyau L x 56–110 (or ×0,2, y 150–382), sol à pointes y 392 ; tuyau R2 x 112–164 (or ×0,2,
  y 170–382) ; lane (330,366)→(164,420) v=3 ; trappe (164,420)→(112,437) ; `ent` A (80,350) – B (250,452) ; bassin
  [112,476,52] (fond seul + murs) ; `nd` bande du bas [100,372,260,78] ; encre 110 ; noyau (138,290).
- **Référence (3,8 s)** : pont (262,130)→(176,156) du miroir droit vers le haut de R2.
- **Contournements écartés** : attendre sur la trappe (zone interdite sur la lane et la trappe ; sans elle : 1,9 %) ;
  retards « par détour » (la marge naturelle est de 50 images : un rebond ne suffit pas).
- **Rôle** : or R2 (retiré → réf échoue) ; or L (crée le retard de l'ouvreuse : sans lui, une simple chute dans R2 suffit —
  il rend l'or R2 nécessaire) ; porte (idem : sans porte le temps ne compte plus) ; lane en pente (empêche l'attente).
- **Mesures** : 0,68 % ; P_ligne 100. **Point faible** : deux éléments (or L, porte) ne cassent pas la référence quand on les
  retire seuls — ils rendent l'idée nécessaire (fiche honnête) ; zone interdite basse visible.

## Monde 11, niveau 5 · Réunies
- **Temps** : Shō 5. **Type** : RÉUNIR (« il faut les deux »). **Élément introduit** : recombineur.
- **Idée** : le cœur complet à droite, brisé à gauche (une brèche dans le bas du miroir). Les copies se croisent en bas,
  au recombineur : réunies, elles repartent vers la droite (v=8) et sautent dans le bassin ; seule, une copie traverse
  sans effet et file aux pointes. Il faut **combler la brèche**.
- **Ce que ça enseigne** : au niveau 1 une copie suffisait ; ici il faut les deux, au même instant.
- **Géométrie** : miroir droit complet F, miroir gauche T + B avec brèche (60,326)–(92,348) ; couvercles (0..118, 242..356,
  y 96) ; `rec` (180,398, r14, −15°, fenêtre 20, v 8) ; bassin [250,476,100,'B'] sous un toit (244..356, y 372) avec lèvre à
  pointes (250,412)–(250,424) ; encre 90 ; noyau (104,332).
- **Référence (1,9 s)** : (52,310)→(96,356).
- **Contournements écartés** : copie seule déviée vers le bassin (toit, lèvre à pointes : 20 → 0 « hors idée ») ; copie
  passant par-dessus un miroir (couvercles).
- **Rôle** : `rec` (indispensable) ; miroir droit (indispensable) ; couvercles, toit, lèvre (gardes).
- **Mesures** : 0,44 % ; P_ligne 90.

## Monde 11, niveau 6 · L'interféromètre  *(MACHINE)*
- **Temps** : Shō 6, **Relais + machine**. **Type** : UN TRAIT POUR DEUX.
- **Idée** : le cœur devient machine : bras en rubans **blancs v=10** (descente rapide) puis crochets **turquoise v=2**
  (freinage net) ; les deux copies tombent des crochets au même instant. Le joueur pose **un seul trait-plancher** passant
  par le recombineur : les deux copies y roulent l'une vers l'autre et fusionnent ; la particule réunie est tirée (v=13)
  par-dessus un mur dans le bassin.
- **Ce que ça enseigne** : un trait peut servir aux deux copies à la fois.
- **Géométrie** : rubans T (10,10,10,10,10,2,2,2,2) et miroir ; `rec` (180,392, r14, −10°, fenêtre 30, v 13) ; bassin
  [296,476,60,'B'] + mur (296,404)–(296,420) ; poussière `flow` (trajectoire de référence) ; encre 140 ; noyau (250,380).
- **Trajectoire (2,5 s)** : chute, fourche, deux descentes blanches symétriques, freinage turquoise, chute, roulement,
  fusion (éclair), tir tendu, bassin. Rythme : lent → très vite → frein → lent → tir.
- **Référence** : (124,404)→(236,404).
- **Contournements écartés** : copie seule qui roule au bout du trait (mur haut du bassin).
- **Rôle** : rubans (retirés → réf échoue pour les bras), `rec` (indispensable), mur (garde).
- **Mesures** : P_hasard 0,12 % (2 500), P_ligne 100, réf 147 images, encre 112/140. **Point faible** : trajectoire encore courte pour une machine (2,5 s) ; piste : une boucle `bf` après
  le tir (non faite).

## Monde 11, niveau 7 · Pair, impair
- **Temps** : Ten 7. **Type** : COMPTER (parité). **Élément** : une seule paire, deux noyaux sur le même chemin.
- **Idée** : la copie droite descend un **guide en crosse** (miroir + paroi intérieure) qui la mène, par une cheminée, sur
  la trappe du bassin. En route elle frôle A (la trappe s'ouvre) puis B (elle se referme) : deux bascules s'annulent. B est
  au bord du guide, accessible depuis l'intérieur du cœur : il faut y envoyer la **copie gauche** pour une **troisième**
  bascule.
- **Ce que ça enseigne** : l'état d'une paire est une parité ; un contact de plus rouvre.
- **Géométrie** : miroir gauche T ; guide droit F/G (symétriques, jusqu'à la cheminée x 176–204) ; `ent` A (256,140) –
  B (188,344) (A remonté : passages espacés de 23 images > recharge 18) ; trappe (176,420)→(204,420) ; bassin
  [176,476,28,'B'] ; encre 80 ; noyau (176,252).
- **Référence (1,8 s)** : (68,157)→(128,167) ; la gauche glisse, tombe droit sur B (3ᵉ bascule, image 73).
- **Contournements écartés** : « retirer » une bascule (bloquer la droite dans son guide → elle n'atteint plus la trappe) ;
  contacts trop proches (recharge).
- **Rôle** : paire (indispensable), porte (retirée → réussit seule), guide (indispensable).
- **Mesures** : P_hasard 1,04 % (2 500), P_ligne 88, réf 109 images, encre 61/80. **Point faible** : la recharge de 18 images est invisible pour le joueur (ne jamais en faire une
  énigme).

## Monde 11, niveau 8 · La mesure-clé
- **Temps** : Ten 8. **Type** : MESURER LA BONNE. **Élément** : la mesure bascule une paire (`det[3]`).
- **Idée** : la copie droite s'enroule dans un bol et attend sur la trappe fermée. Un détecteur au centre ouvre la trappe
  quand il mesure. Le piège : mesurer la droite (elle part vers la gauche de la cloison) ou mesurer la gauche… qui efface
  justement celle qui attendait. La solution : mesurer la **gauche** en la jetant à travers le détecteur **par-dessus la
  cloison** : réelle, elle retombe dans le bol et passe la trappe qu'elle a ouverte.
- **Ce que ça enseigne** : la mesure agit (ouvre) **et** choisit qui existe ; il faut que ce soit la copie capable de passer.
- **Géométrie** : miroir gauche court T ; miroir droit F enroulé en bol ; cloison (180,300)→(180,420) ; `det` (180,262,
  r15, paire 0) ; témoins de la paire (60,30) et (300,30) ; trappe (186,420)→(246,420) ; bassin [186,476,60,'B'] ; encre 84 ;
  noyau (150,240).
- **Référence (1,9 s)** : (67,219)→(125,266).
- **Rôle** : `det` (indispensable) ; porte (retirée → réussit seule) ; cloison (sépare le bon et le mauvais côté).
- **Mesures** : 1,80 % ; P_ligne 100.

## Monde 11, niveau 9 · Gagner du temps
- **Temps** : Ten 9. **Type** : GAGNER DU TEMPS POUR SE REJOINDRE. **Rappel renversé du niveau 4.**
- **Idée** : le cœur complet, mais le bras droit traverse une **zone d'or** : la droite arrive en retard au recombineur,
  pas de fusion, les copies seules meurent. Il faut lui faire **éviter l'or** par une corde intérieure, pour qu'elle arrive
  à l'heure. Réunies, elles partent à gauche dans le bassin.
- **Ce que ça enseigne** : au niveau 4 on perdait du temps ; ici on en gagne — le recombineur exige le même instant.
- **Géométrie** : cœur complet ; or [262,150,74,190, ×0,4] ; `rec` (180,398, r12, 195°, fenêtre 8, v 8) ; bassin
  [10,476,100,'B'] sous un toit (0..116, y 372) et lèvre à pointes ; `nd` sous le croisement [116,380,244,100] ; encre 120 ;
  noyau (238,246).
- **Référence (1,9 s)** : corde (276,150)→(248,262).
- **Contournements écartés** : copie seule rabattue dans le bassin (zone interdite sous le croisement).
- **Rôle** : or (retiré → réussit seul) ; `rec` (indispensable).
- **Mesures** : 1,80 % ; P_ligne 93. **Écart** : cible 1,5 % ; une deuxième famille (retarder la gauche d'autant) existe,
  dans l'idée (se synchroniser).

## Monde 11, niveau 10 · Le choix
- **Temps** : Ketsu 10. **Type** : UNE PORTE OU L'AUTRE. **Élément introduit** : paire **opposée** (`'opp'`).
- **Idée** : deux trappes au fond du cœur, liées à une paire opposée : la gauche est **ouverte** (sur des pointes), la droite
  **fermée** (sur le bassin). La gauche tombe donc dans la mort ; la droite attend. Mesurer la **droite** au détecteur (qui
  bascule la paire) l'efface de l'autre et **échange les portes**. Mesurer trop tard : la gauche est déjà morte, le
  détecteur est inerte.
- **Ce que ça enseigne** : une bascule ouvre une porte en fermant l'autre ; la mesure décide de la réalité et de la porte.
- **Géométrie** : cœur fermé en V ; cloison (180,330)→(180,420) ; `det` (244,240, r12, paire 0) ; `ent` 'opp' témoins
  (330,40) / (30,40) ; trappes (152,394)→(180,400) [gauche, ouverte au repos] et (180,400)→(208,394) [droite, fermée] ;
  bassin [180,476,56,'B'], pointes sous la gauche ; encre 70 ; noyau (250,250).
- **Référence (2,5 s)** : (317,235)→(258,240) : la droite roule dans le détecteur (image 52) puis tombe par sa porte.
- **Contournements écartés** : mesurer la gauche et la faire traverser (détecteur placé à droite, loin de la gauche) ;
  « courses » trop tardives (gauche morte à l'image 81).
- **Rôle** : `det` (indispensable) ; paire opposée (fait l'échange) ; cloison (indispensable : retirée → réussit seule).
- **Mesures** : 0,72 % ; P_ligne 85 (limite basse).

## Monde 11, niveau 11 · Fermer un chemin  *(renversement)*
- **Temps** : Ketsu 11. **Type** : NE PAS LES RÉUNIR. **Renversement des niveaux 5, 6 et 9.**
- **Idée** : le cœur devient un interféromètre à **guides d'onde** (miroir + paroi intérieure, intérieur interdit au
  tracé) ; réunies, les copies sont jetées droit sur les pointes. Seule, la copie droite traverse et roule dans le bassin.
  Chaque guide a une **fenêtre** : barrer la fenêtre **gauche** (la droite passe seule : gagné) ; barrer la droite (la
  gauche passe seule… aux pointes).
- **Ce que ça enseigne** : l'interférence a un prix ; connaître le chemin (en fermer un) change l'issue.
- **Géométrie** : cœur complet + parois intérieures G ; `rec` (180,398, r16, 90°, fenêtre 30, v 6) ; bassin
  [8,476,146,'L'] + butée (154,456)–(154,476) ; `nd` : bande haute, zone sous le croisement, 22 rectangles dans les guides,
  fenêtres y 258–280 ; encre 50 ; noyau (118,430) (sur la course de la copie seule).
- **Référence (1,9 s)** : barre (55,268)→(93,270).
- **Contournements écartés** : sans guides protégés, n'importe quel trait qui dérange la gauche suffit (16 %) ; le
  mauvais côté échoue (vérifié).
- **Rôle** : `rec` (retiré → réussit seul) ; guides (indispensables).
- **Mesures** : 0,92 % ; P_ligne 100. **Point faible** : beaucoup de rectangles `nd` (rendu à soigner).

## Monde 11, niveau 12 · Quantix  *(FINALE, machine)*
- **Temps** : Ketsu 12. **Type** : COMPOSER (coopérer + réunir + libérer). Deux traits, encre 200, palette S+B.
- **Idée** : le cœur-machine (rubans blancs puis violets) se termine par **deux portes** symétriques. Une seule paire les
  commande ; son noyau A est un peu en retrait du bras gauche, gardé par un **détecteur-piège**. Premier trait : une corde
  qui fait frôler A à la gauche (sans toucher le détecteur) — les deux portes s'ouvrent **ensemble**, les jumelles
  repartent du même pas et **fusionnent** à l'entrée de l'**atome** : un champ magnétique vide, cerclé de pointes, où la
  particule réunie tourne sans fin (r ≈ 38). Second trait : **l'arracher à son orbite** par la porte du bas ; un tremplin
  en ruban la lance dans le bassin.
- **Ce que ça enseigne** : tout le monde à la fois — l'une ouvre la porte de l'autre, elles se réunissent, et c'est
  ensemble qu'elles deviennent une seule particule.
- **Géométrie** : bras T (10,10,10,10,7,7,7) et miroir ; portes (128,270)–(128,306) et (232,270)–(232,306) (paire 0, A
  (116,258)) ; `det` piège (134,232, r16) ; `rec` (180,310, r18, 0°, fenêtre 30, v 5) ; `bf` [110,298,140,100, 0,133, vide] ;
  coquille à pointes : arcs centrés (180,356) r 62 de −38° à 68° et de 112° à 218° ; gardien `det` (180,404, r14, paire 1) +
  trappe (156,416)–(204,416) ouverte au repos ; tremplin ruban (166,428)…(266,440) v 10/10/7/7 ; bassin [290,476,64,'B'] ;
  `flow` ; noyau (222,350) sur l'orbite.
- **Trajectoire de référence (2,9 s)** : fourche, deux descentes blanches, contact A (image 40), portes ouvertes, fusion
  (53), orbite, noyau (61), libération, chute par la trappe, tremplin, vol, bassin. Rythme : très vite → violet → éclair →
  lent (orbite) → chute → très vite (tremplin) → arrêt.
- **Références** : trait 1 (70,240)→(136,302) ; trait 2 (169,359)→(159,410).
- **Contournements écartés** : sans le premier trait, les deux copies attendent derrière leurs portes ; une copie seule
  (sans fusion) entre dans l'atome **encore superposée** → le gardien la mesure et referme la trappe (sans gardien, une
  copie seule plongeait droit dans le bassin) ; corde trop profonde → détecteur-piège (filtre 20 % des cordes).
- **Rôle** : portes + paire (sans elles, pas de coopération) ; `rec` (avec le gardien, indispensable) ; `bf` (retiré →
  réf échoue) ; coquille (tue les copies seules) ; tremplin (dernier changement de vitesse).
- **Mesures** : P_hasard 0,08 % (2 500), P_ligne 83 (écart 2 pts ; fusion `rec` élargie r22 fenêtre 42, était 75), réf 171 images, encre 143/200. **Points faibles** : l'orbite n'est vue que sur ¾ de tour ; le second trait a beaucoup de positions
  gagnantes (geste de libération, pas une énigme).

---

## Matrice de non-redondance

| Niv. | Titre | Ce qui est nouveau | Verbe | Éléments | Geste du trait |
|---|---|---|---|---|---|
| 1 | Deux chemins | deux copies réelles | SAUVER UNE | sup | rampe sous une copie |
| 2 | La mesure | la mesure efface l'autre | SAUVER LA MESURÉE | det, lanes v2 | long pont vers la route de l'autre |
| 3 | Le lien | une copie ouvre pour l'autre | COOPÉRER | ent, gate | déflecteur vers un noyau |
| 4 | Le temps ralenti | temps propre à chaque copie | PERDRE DU TEMPS | tdil ×2, lane v3 | pont vers le tuyau d'or |
| 5 | Réunies | il faut les deux | RÉUNIR | rec | combler une brèche du miroir |
| 6 | L'interféromètre | un trait pour deux | PARTAGER | rubans 10/2, rec | plancher commun |
| 7 | Pair, impair | parité | COMPTER | ent (2 passages) | envoyer la seconde sur B |
| 8 | La mesure-clé | la mesure ouvre | MESURER LA BONNE | det[3] | jeter la gauche à travers l'œil |
| 9 | Gagner du temps | se synchroniser | GAGNER DU TEMPS | tdil, rec | corde qui évite l'or |
| 10 | Le choix | portes opposées | CHOISIR LA PORTE | det, 'opp' | pousser la droite dans l'œil |
| 11 | Fermer un chemin | interférence = perte | FERMER | rec, guides | barrer une fenêtre |
| 12 | Quantix | tout + orbite | COMPOSER / LIBÉRER | tout, bf | corde + libération |

Parentés assumées : 1/5/11 (le cœur : une suffit / il faut les deux / il ne faut pas les deux) ; 4/9 (perdre / gagner du
temps) ; 2/8/10 (la mesure efface / ouvre / échange) — trois sens distincts.

## Ce qui reste à vérifier sur iPhone
- Lisibilité du cœur et des miroirs courbes ; des liaisons détecteur→paire→porte (8, 10, 12) et des témoins dans la bande
  du haut ; des fenêtres de guide du niveau 11 (rendu des 24 zones interdites).
- Niveau 7 : que la double bascule (ouvre/ferme) soit **visible** sur la trappe.
- Niveau 12 : spectacle de l'orbite et de la coquille à pointes (`m:2` sur courbes) ; durée ressentie de la finale.
- Toute la cinématique quantique (dédoublement, effacement, fusion) en temps réel ; sons `quantum.*`.
