# QUANTONE — Lot Q3 : banque de sons et caches bornés (R342, 30 oct. 2026)

**Fait / vérifié**
- Banque de 399 sons (famille : grave 60, tic 85, bois 95, métal 40, aigu 60, bruit 3, texture 45, effet 11), mono 32 kHz Int16. Sources : 1 077 tranches des rendus aimés + coupes d'attaque du pool (136 mp3) + extraits de 1,5 s + effets. Sélection par k-means par famille (représentant le plus central). Script : `build_bank.py`.
- Packs plats : `pack-rythme.bin` (340 sons, 4 857 274 o), `pack-matiere.bin` (59 sons, 4 509 772 o) ; catalogue `bank.json` (id, famille, durée, pack, offset, longueur). Taille vérifiée au chargement (pack tronqué = refusé).
- Quantone : `QBANK.open` (recherche, famille, ▶, → emplacement). Pack/catalogue absents : message, aucune erreur de page.
- Caches : `smArr` et `smBuf` plafonnés (40 Mo cumulés, éviction des plus anciens).
- Tests : `e2e-banque.py` 8/8, `e2e-sampler.py` 37/37, `e2e-morceau.py` 6/6.

**Faiblesses connues** : peu de sons « bruit » (3) et « effet » (11) faute de matière source ; sources limitées aux 3 rendus + pool (bois/clics dominants) ; pas de sample de verre pour la Faille ; stockage Float32 en RAM ; `.qx` embarque le PCM.

**Déploiement** : déposer `packs/pack-rythme.bin` et `pack-matiere.bin` dans un dossier `packs/` à la racine du dépôt GitHub ; le workflow (ligne ajoutée) les copie dans `assets/bank/`.
