# QUANTIX — Analyse de l'état des 132 niveaux et priorités (R116)

*9 octobre 2026. Toutes les mesures ont été refaites ce jour sur le build R116 (aucune reprise de chiffres anciens pour la
jouabilité) : `difficulty.js` sur les 132 niveaux (modèle du doigt, `DIFFICULTY_PROTOCOL.md`), simulation sans trait,
`zonepropre.js`, comptage des solutions de référence, des machines et des courbes. Les notes A/B/C/D, le contrôle
d'énigme et le registre des fiches viennent de `FINITION.md`, `enigme_status.json` et `registre.json` (R92–R96 ; aucun
niveau n'a changé depuis). Le tableau §6 se régénère : `python3 tools/etat.py`.*

---

## 1. Verdict en une phrase

**Sur 132 niveaux, 2 cochent aujourd'hui toutes les cases (3 « Le demi‑tour » et 4 « Le relais ») ; 17 seulement sont
jouables au doigt (P_exec ≥ 70 %) ; et la note A, qui ne mesure pas la jouabilité, a laissé passer des niveaux
injouables (10 « Le plafond » 13 %, 12 « L'établi » 3 %, 75 « Le manège inversé » 27 %).**

## 2. Chiffres clés

| Mesure | Résultat | Cible |
|---|---|---|
| Niveaux jouables au doigt (P_exec ≥ 70 %) | **17 / 132** (médiane par monde : 27 à 57 %) | 132 |
| Énigme validée (ÉNIGME ✓) | 25 / 132 | 132 |
| Note A (finition) | 19 / 132 — dont 13 sous 70 % de jouabilité | — |
| Cochent tout (A + ÉNIGME ✓ + jouable + zone dégagée) | **2** (3, 4) ; 14, 44, 51 à un détail près | 132 |
| Sans solution de référence (`optsol`) | **80** : 19, 41, 46, 52–72, 77–132 | 0 |
| Se gagnent **sans rien tracer** | 3 : 102, 105, 115 | 0 |
| Aucun trait droit ne gagne (balayage) | 5 : 60, 72, 96, 114, 121 | 0 |
| Noyau inatteignable (P_noyau = 0 %) | 49 | 0 |
| Un trait court (< seuil de position) suffit | 63 (finition) | 0 |
| Élément dans la zone de réussite | 3 : 11, 21, 34 | 0 |
| Machines (cahier §6 : positions 3, 6, 8, 10, 12) | **1 / 55** (75) ; courbes : 10, 73, 75 | 55 |
| Tests de non‑régression par monde | mondes 1 à 5 ; **6 à 11 absents** | 11 |

## 3. Par monde

| Monde | A | C | D | Jouables ≥ 70 % | ÉNIGME ✓ | Prêts | Identité visuelle | Musique |
|---|---|---|---|---|---|---|---|---|
| 1 Atelier | 4 | 8 | 0 | 3 | 8 | 3, 4 | ADN, cosmos | **W1N (neuve)** |
| 2 Fonderie | 3 | 8 | 1 | 1 | 4 | 14 | chambre à bulles | ancienne |
| 3 Chaîne | 1 | 11 | 0 | 1 | 1 | — | anneau de stockage | ancienne |
| 4 Glacier | 6 | 4 | 2 | 1 | 7 | 44 | partielle (franges, tourbillons) | ancienne |
| 5 Soufflerie | 1 | 2 | 9 | 3 | 1 | 51 | provisoire | ancienne |
| 6 Mécanique | 0 | 0 | 12 | 1 | 0 | — | provisoire | ancienne |
| 7 Gravité | 4 | 0 | 8 | 0 | 4 | — | provisoire | ancienne |
| 8 Magnétisme | 0 | 0 | 12 | 2 | 0 | — | ferrofluide | ancienne |
| 9 Faille | 0 | 0 | 12 | 3 | 0 | — | provisoire | ancienne |
| 10 Filaments | 0 | 0 | 12 | 1 | 0 | — | provisoire | ancienne |
| 11 Quantique | 0 | 0 | 12 | 1 | 0 | — | provisoire | ancienne |

## 4. Les faiblesses de fond, par ordre d'impact

**F1 — Les outils de conception ne mesurent pas ce que le joueur vit (cause racine).** `fiche.js` valide la
« jouabilité » en décalant les deux bouts de la solution de ±3 u (P_ligne) ; `difficulty.js` modélise un vrai doigt
(décalage 6 u, bouts 9 u, rotation 4°, longueur ±10 %, ondulation). Les niveaux construits par fiche passent la porte
P_ligne ≥ 85 % puis tombent à 3–40 % au doigt. **Tant que la porte n'est pas la bonne, chaque refonte produit des
niveaux injouables** — c'est ce qui est arrivé à 10, 12, 37, 47, 75.

**F2 — Le jeu contient des niveaux cassés.** 3 se gagnent sans trait (102, 105, 115), 5 n'ont aucune solution à un
trait trouvée (60, 72, 96, 114, 121 — peut‑être solubles à plusieurs traits, non prouvé). En ligne, c'est le défaut le
plus visible.

**F3 — 80 niveaux sans solution de référence.** Pas de bouton « solution optimale » fiable, pas de relecture testée,
pas de noyau posé sur une trajectoire réelle (d'où 49 noyaux inatteignables), et une mesure de jouabilité faite sur le
meilleur trait trouvé au hasard, pas sur la solution voulue.

**F4 — Énigmes : 107 niveaux non validés, 63 se gagnent avec un trait court.** C'est le constat de R61 et R73,
inchangé hors mondes 1, 4 et 7.

**F5 — L'architecture du cahier (machines, relais, deux actes, finales) n'existe presque pas dans le jeu : 1 machine
sur 55.** Les mondes se ressemblent dans leur forme ; c'est la promesse « contempler » du cahier §1 qui manque.

**F6 — Finitions locales** : 3 éléments dans la zone (11, 21, 34) ; identité visuelle propre seulement pour les mondes 1,
2, 3, 8 (4 partielle) ; musique neuve seulement pour le monde 1 ; tests absents pour les mondes 6 à 11.

## 5. Ordre de travail recommandé

| Rang | Tâche | Pourquoi d'abord | Coût |
|---|---|---|---|
| **0** | **Mettre la porte au bon endroit** : `fiche.js` et `pipeline.py` jugent la jouabilité avec le modèle du doigt de `difficulty.js` (P_exec ≥ 70 %), refusent un niveau gagné sans trait, vérifient le noyau ; `etat.py` régénère ce bilan | sans cela toute refonte est à refaire (F1) | court |
| **1** | **Réparer les 8 niveaux cassés** (102, 105, 115 ; 60, 72, 96, 114, 121) au minimum jouable, avec solution de référence | le jeu publié ne doit jamais être cassé (F2) | court |
| **2** | **Monde 1 complet, 12/12 prêts**, avec sa forme du cahier (machines 3, 6, 8, 10, 12 ; finale 12) : refaire 1, 2, 5–9, 11 ; reprendre la jouabilité de 10 et 12 | c'est l'entrée du jeu et le modèle des 10 autres ; validation chronologique demandée par Simon | moyen |
| 3 | Monde 2, puis 3, puis 4 (ordre du jeu), même méthode | progression du joueur | moyen × 3 |
| 4 | Mondes 5 à 11 (73 niveaux à reconcevoir) par gabarits scénarisés, machines comprises | la masse du travail | long |
| ∥ | En parallèle, quand un monde est validé : son identité visuelle, sa musique (méthode W1N), son test `mondeN.js` | ne bloque pas les niveaux | — |
| ∥ | Didacticiel : finitions plus tard (demande de Simon) | — | — |

**Règle de livraison qui en découle** : un niveau n'est « prêt » que s'il passe ensemble ENIGME ✓, P_exec ≥ 70 %,
aucun trait court, zone dégagée, solution de référence avec noyau, et le test du monde. Plus de note A sans jouabilité.

## 7. Fait dans la session R117 (après cette analyse)

- **Rang 0 fait** : `fiche.js` juge la jouabilité avec le modèle du doigt (`difficulty.js`, P_exec ≥ 70 %, `PEMIN=`) ; P_ligne n'est plus
  qu'un indicateur ; la meilleure réalisation et la meilleure variante sont choisies au doigt. Outils : `tools/diag.js` (pourquoi un geste
  échoue), `tools/repairs_check.js` (seul / solution / noyau), `tools/etat.py` (ce tableau), `solver.js ONLY=…`.
- **Rang 1 fait (réparation provisoire)** : 102, 105, 115 ne se gagnent plus seuls ; 72, 114, 121 ont une solution ; les six ont une solution
  de référence et un noyau atteignable. Ils restent notés D (à reconcevoir avec leur monde). 60 et 96 étaient solubles d'un trait brisé.
- **Monde 1** : 1 « Le premier trait » (géométrie de Simon, le trait est un mur) et 2 « Le pont » refaits : ÉNIGME ✓, 87 % au doigt.
- **Constat sur 10, 12, 37, 47, 75** (`diag.js`) : ce n'est pas l'encre (×2 ne change rien) mais la précision demandée — jonction
  trait/mur fixe, tôle à hauteur exacte, trois gestes enchaînés. **Question ouverte (décision de Simon)** : le modèle du doigt date
  d'avant l'éditeur (R34) ; il suppose un trait à main levée, d'un seul geste. Avec Droite (accroche), Déplacer/Pivoter (magnétisme R117)
  et la loupe, la précision réelle est meilleure. Faut‑il recalibrer le modèle pour l'éditeur, ou garder l'exigence « jouable à main levée » ?

## 6. Tableau des 132 niveaux (mis à jour R117)

### Monde 1 — Atelier

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 1 | 1 | Le premier trait | C | 87 % | 43 % | trait de 15 u suffit |
| 2 | 2 | Le pont | A | 87 % | 87 % | — |
| 3 | 3 | Le demi-tour | A | 83 % | 53 % | — |
| 4 | 4 | Le relais | A | 90 % | 53 % | — |
| 5 | 5 | La douceur | C | 63 % | 63 % | jouabilité 63 % ; trait de 17 u suffit ; sans fiche |
| 6 | 6 | Le fil | C | 33 % | 27 % | jouabilité 33 % ; énigme non validée ; sans fiche |
| 7 | 7 | Économie | C | 23 % | 23 % | jouabilité 23 % ; trait de 15 u suffit ; sans fiche |
| 8 | 8 | La portée | C | 63 % | 60 % | jouabilité 63 % ; énigme non validée ; sans fiche |
| 9 | 9 | Le détour | C | 33 % | 33 % | jouabilité 33 % ; trait de 97 u suffit ; énigme non validée ; sans fiche |
| 10 | 10 | Le plafond | A | 13 % | 13 % | jouabilité 13 % |
| 11 | 11 | Le relais | C | 7 % | 0 % | jouabilité 7 % ; noyau inatteignable ; élément dans la zone ; sans fiche |
| 12 | 12 | L’établi | A | 3 % | 0 % | jouabilité 3 % ; noyau inatteignable |

### Monde 2 — Fonderie

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 13 | 1 | Le trampoline | C | 50 % | 40 % | jouabilité 50 % ; trait de 28 u suffit ; énigme non validée ; sans fiche |
| 14 | 2 | Le ricochet | A | 77 % | 50 % | — |
| 15 | 3 | La montée | A | 20 % | 20 % | jouabilité 20 % |
| 16 | 4 | La hauteur juste | C | 63 % | 63 % | jouabilité 63 % ; trait de 50 u suffit ; énigme non validée ; sans fiche |
| 17 | 5 | Sol brûlant | C | 33 % | 30 % | jouabilité 33 % ; trait de 39 u suffit ; énigme non validée ; sans fiche |
| 18 | 6 | Ta plaque | C | 17 % | 3 % | jouabilité 17 % ; énigme non validée ; sans fiche |
| 19 | 7 | Le four | D | 17 % | 0 % | jouabilité 17 % ; pas de solution de référence ; noyau inatteignable ; trait de 47 u suffit ; énigme non validée ; sans fiche |
| 20 | 8 | Le tremplin | A | 20 % | 20 % | jouabilité 20 % |
| 21 | 9 | Le grand retour | C | 40 % | 40 % | jouabilité 40 % ; élément dans la zone ; énigme non validée ; sans fiche |
| 22 | 10 | Double rebond | C | 27 % | 0 % | jouabilité 27 % ; noyau inatteignable ; trait de 17 u suffit ; énigme non validée ; sans fiche |
| 23 | 11 | L’élan d’abord | C | 40 % | 40 % | jouabilité 40 % ; trait de 62 u suffit ; énigme non validée ; sans fiche |
| 24 | 12 | La fonte | C | 33 % | 17 % | jouabilité 33 % ; trait de 30 u suffit |

### Monde 3 — Chaîne

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 25 | 1 | Le tapis | A | 33 % | 33 % | jouabilité 33 % |
| 26 | 2 | Sens inverse | C | 63 % | 33 % | jouabilité 63 % ; trait de 35 u suffit ; énigme non validée ; sans fiche |
| 27 | 3 | Tapis et butée | C | 63 % | 17 % | jouabilité 63 % ; trait de 21 u suffit ; énigme non validée ; sans fiche |
| 28 | 4 | Le plafond bas | C | 50 % | 50 % | jouabilité 50 % ; trait de 19 u suffit ; énigme non validée ; sans fiche |
| 29 | 5 | Ton élan | C | 93 % | 60 % | trait de 70 u suffit ; ligne directe ; énigme non validée ; sans fiche |
| 30 | 6 | Saut de chaîne | C | 27 % | 20 % | jouabilité 27 % ; énigme non validée ; sans fiche |
| 31 | 7 | Tapis et lames | C | 40 % | 20 % | jouabilité 40 % ; trait de 55 u suffit ; énigme non validée ; sans fiche |
| 32 | 8 | Deux tapis | C | 23 % | 7 % | jouabilité 23 % ; énigme non validée ; sans fiche |
| 33 | 9 | Chaîne montante | C | 53 % | 47 % | jouabilité 53 % ; énigme non validée ; sans fiche |
| 34 | 10 | Relais d’élan | C | 40 % | 27 % | jouabilité 40 % ; ligne directe ; élément dans la zone ; énigme non validée ; sans fiche |
| 35 | 11 | Le tri des tapis | C | 37 % | 37 % | jouabilité 37 % ; ligne directe ; énigme non validée ; sans fiche |
| 36 | 12 | La chaîne complète | C | 7 % | 3 % | jouabilité 7 % ; trait de 75 u suffit ; énigme non validée ; sans fiche |

### Monde 4 — Glacier

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 37 | 1 | Le lac | A | 43 % | 43 % | jouabilité 43 % |
| 38 | 2 | Trop vite | C | 13 % | 13 % | jouabilité 13 % ; énigme non validée ; sans fiche |
| 39 | 3 | Le saut | A | 40 % | 37 % | jouabilité 40 % |
| 40 | 4 | Le demi‑tour | A | 60 % | 50 % | jouabilité 60 % |
| 41 | 5 | Glace interdite | D | 20 % | 17 % | jouabilité 20 % ; pas de solution de référence ; trait de 8 u suffit ; énigme non validée ; sans fiche |
| 42 | 6 | La butée | C | 50 % | 50 % | jouabilité 50 % ; trait de 36 u suffit ; énigme non validée ; sans fiche |
| 43 | 7 | Deux étages | C | 57 % | 57 % | jouabilité 57 % ; trait de 40 u suffit ; énigme non validée ; sans fiche |
| 44 | 8 | La patinoire | A | 70 % | 70 % | — |
| 45 | 9 | Le passage gardé | C | 20 % | 20 % | jouabilité 20 % ; trait de 9 u suffit |
| 46 | 10 | Verglas | D | 60 % | 23 % | jouabilité 60 % ; pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche |
| 47 | 11 | La crevasse double | A | 27 % | 23 % | jouabilité 27 % |
| 48 | 12 | Le sérac | A | 33 % | 23 % | jouabilité 33 % |

### Monde 5 — Soufflerie

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 49 | 1 | Le souffle | C | 40 % | 40 % | jouabilité 40 % ; énigme non validée ; sans fiche |
| 50 | 2 | Vent de face | C | 30 % | 27 % | jouabilité 30 % ; énigme non validée ; sans fiche |
| 51 | 3 | Vent descendant | A | 70 % | 70 % | — |
| 52 | 4 | Colonne étroite | D | 50 % | 50 % | jouabilité 50 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 53 | 5 | Deux colonnes | D | 50 % | 0 % | jouabilité 50 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 54 | 6 | Vent et plafond | D | 77 % | 40 % | pas de solution de référence ; trait de 14 u suffit ; énigme non validée ; sans fiche |
| 55 | 7 | Vent et lame | D | 17 % | 0 % | jouabilité 17 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 56 | 8 | Contre-courant | D | 83 % | 0 % | pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 57 | 9 | La rafale | D | 57 % | 0 % | jouabilité 57 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 58 | 10 | Le tunnel | D | 37 % | 13 % | jouabilité 37 % ; pas de solution de référence ; trait de 42 u suffit ; énigme non validée ; sans fiche |
| 59 | 11 | La tempête | D | 43 % | 27 % | jouabilité 43 % ; pas de solution de référence ; trait de 44 u suffit ; énigme non validée ; sans fiche |
| 60 | 12 | La veine | D | — | — | **aucun trait droit ne gagne** ; pas de solution de référence ; énigme non validée ; sans fiche |

### Monde 6 — Mécanique

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 61 | 1 | Le piston | D | 67 % | 60 % | jouabilité 67 % ; pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche |
| 62 | 2 | La navette | D | 17 % | 0 % | jouabilité 17 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 63 | 3 | Piston bas | D | 63 % | 0 % | jouabilité 63 % ; pas de solution de référence ; noyau inatteignable ; trait de 14 u suffit ; énigme non validée ; sans fiche |
| 64 | 4 | Deux pistons | D | 40 % | 0 % | jouabilité 40 % ; pas de solution de référence ; noyau inatteignable ; trait de 17 u suffit ; énigme non validée ; sans fiche |
| 65 | 5 | Le pendule | D | 80 % | 0 % | pas de solution de référence ; noyau inatteignable ; trait de 28 u suffit ; énigme non validée ; sans fiche |
| 66 | 6 | Va-et-vient | D | 63 % | 0 % | jouabilité 63 % ; pas de solution de référence ; noyau inatteignable ; trait de 15 u suffit ; énigme non validée ; sans fiche |
| 67 | 7 | Métronome | D | 57 % | 0 % | jouabilité 57 % ; pas de solution de référence ; noyau inatteignable ; trait de 33 u suffit ; énigme non validée ; sans fiche |
| 68 | 8 | L’engrenage | D | 50 % | 0 % | jouabilité 50 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 69 | 9 | Cadence double | D | 13 % | 3 % | jouabilité 13 % ; pas de solution de référence ; trait de 82 u suffit ; énigme non validée ; sans fiche |
| 70 | 10 | L’horloge | D | 60 % | 0 % | jouabilité 60 % ; pas de solution de référence ; noyau inatteignable ; trait de 35 u suffit ; énigme non validée ; sans fiche |
| 71 | 11 | Atelier mobile | D | 57 % | 0 % | jouabilité 57 % ; pas de solution de référence ; noyau inatteignable ; trait de 17 u suffit ; énigme non validée ; sans fiche |
| 72 | 12 | Le régulateur | C | 83 % | 67 % | trait de 11 u suffit ; énigme non validée ; sans fiche |

### Monde 7 — Gravité

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 73 | 1 | Tomber vers le haut | A | 33 % | 33 % | jouabilité 33 % |
| 74 | 2 | Gravité lourde | A | 40 % | 40 % | jouabilité 40 % |
| 75 | 3 | Le manège inversé | A | 27 % | 27 % | jouabilité 27 % |
| 76 | 4 | Le champ de travers | A | 47 % | 13 % | jouabilité 47 % |
| 77 | 5 | Deux champs | D | 43 % | 7 % | jouabilité 43 % ; pas de solution de référence ; trait de 14 u suffit ; énigme non validée ; sans fiche |
| 78 | 6 | Champ et mur | D | 43 % | 13 % | jouabilité 43 % ; pas de solution de référence ; trait de 22 u suffit ; énigme non validée ; sans fiche |
| 79 | 7 | Ascension | D | 63 % | 0 % | jouabilité 63 % ; pas de solution de référence ; noyau inatteignable ; trait de 10 u suffit ; énigme non validée ; sans fiche |
| 80 | 8 | Champ et lame | D | 13 % | 0 % | jouabilité 13 % ; pas de solution de référence ; noyau inatteignable ; trait de 29 u suffit ; énigme non validée ; sans fiche |
| 81 | 9 | Bascule | D | 13 % | 3 % | jouabilité 13 % ; pas de solution de référence ; trait de 8 u suffit ; énigme non validée ; sans fiche |
| 82 | 10 | Apesanteur | D | 30 % | 20 % | jouabilité 30 % ; pas de solution de référence ; trait de 13 u suffit ; énigme non validée ; sans fiche |
| 83 | 11 | Le puits | D | 67 % | 0 % | jouabilité 67 % ; pas de solution de référence ; noyau inatteignable ; trait de 60 u suffit ; énigme non validée ; sans fiche |
| 84 | 12 | Le pèse-matière | D | 40 % | 0 % | jouabilité 40 % ; pas de solution de référence ; noyau inatteignable ; trait de 96 u suffit ; énigme non validée ; sans fiche |

### Monde 8 — Magnétisme

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 85 | 1 | L’aimant | D | 47 % | 43 % | jouabilité 47 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 86 | 2 | Aimant fort | D | 33 % | 23 % | jouabilité 33 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 87 | 3 | Aimant haut | D | 7 % | 0 % | jouabilité 7 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 88 | 4 | Deux aimants | D | 70 % | 40 % | pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche |
| 89 | 5 | Aimant et mur | D | 60 % | 0 % | jouabilité 60 % ; pas de solution de référence ; noyau inatteignable ; trait de 47 u suffit ; énigme non validée ; sans fiche |
| 90 | 6 | Le couloir | D | 10 % | 0 % | jouabilité 10 % ; pas de solution de référence ; noyau inatteignable ; trait de 78 u suffit ; énigme non validée ; sans fiche |
| 91 | 7 | Aimant et lame | D | 43 % | 33 % | jouabilité 43 % ; pas de solution de référence ; trait de 17 u suffit ; énigme non validée ; sans fiche |
| 92 | 8 | Slalom | D | 47 % | 43 % | jouabilité 47 % ; pas de solution de référence ; trait de 30 u suffit ; énigme non validée ; sans fiche |
| 93 | 9 | Orbite | D | 40 % | 0 % | jouabilité 40 % ; pas de solution de référence ; noyau inatteignable ; trait de 104 u suffit ; énigme non validée ; sans fiche |
| 94 | 10 | Champ magnétique | D | 23 % | 0 % | jouabilité 23 % ; pas de solution de référence ; noyau inatteignable ; trait de 22 u suffit ; énigme non validée ; sans fiche |
| 95 | 11 | La capture | D | 80 % | 0 % | pas de solution de référence ; noyau inatteignable ; trait de 20 u suffit ; énigme non validée ; sans fiche |
| 96 | 12 | Le solénoïde | D | — | — | **aucun trait droit ne gagne** ; pas de solution de référence ; énigme non validée ; sans fiche |

### Monde 9 — Faille

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 97 | 1 | Le portail | D | 10 % | 10 % | jouabilité 10 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 98 | 2 | Portail court | D | 27 % | 3 % | jouabilité 27 % ; pas de solution de référence ; trait de 27 u suffit ; énigme non validée ; sans fiche |
| 99 | 3 | Portail montant | D | 70 % | 0 % | pas de solution de référence ; noyau inatteignable ; trait de 18 u suffit ; énigme non validée ; sans fiche |
| 100 | 4 | Portail et mur | D | 47 % | 0 % | jouabilité 47 % ; pas de solution de référence ; noyau inatteignable ; trait de 35 u suffit ; énigme non validée ; sans fiche |
| 101 | 5 | Deux failles | D | 23 % | 3 % | jouabilité 23 % ; pas de solution de référence ; trait de 39 u suffit ; énigme non validée ; sans fiche |
| 102 | 6 | Portail et vent | C | 73 % | 73 % | trait de 18 u suffit ; énigme non validée ; sans fiche |
| 103 | 7 | Portail et lame | D | 27 % | 3 % | jouabilité 27 % ; pas de solution de référence ; trait de 39 u suffit ; énigme non validée ; sans fiche |
| 104 | 8 | Boucle | D | 47 % | 0 % | jouabilité 47 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 105 | 9 | Aller-retour | C | 77 % | 77 % | trait de 100 u suffit ; énigme non validée ; sans fiche |
| 106 | 10 | Faille interdite | D | 10 % | 7 % | jouabilité 10 % ; pas de solution de référence ; trait de 38 u suffit ; énigme non validée ; sans fiche |
| 107 | 11 | Le pli | D | 53 % | 0 % | jouabilité 53 % ; pas de solution de référence ; noyau inatteignable ; trait de 38 u suffit ; énigme non validée ; sans fiche |
| 108 | 12 | La singularité | D | 13 % | 13 % | jouabilité 13 % ; pas de solution de référence ; énigme non validée ; sans fiche |

### Monde 10 — Filaments

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 109 | 1 | La corde | D | 17 % | 17 % | jouabilité 17 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 110 | 2 | Corde tendue | D | 47 % | 0 % | jouabilité 47 % ; pas de solution de référence ; noyau inatteignable ; trait de 13 u suffit ; énigme non validée ; sans fiche |
| 111 | 3 | Le hamac | D | 27 % | 0 % | jouabilité 27 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 112 | 4 | Corde et plaque | D | 33 % | 0 % | jouabilité 33 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 113 | 5 | La balle molle | D | 63 % | 0 % | jouabilité 63 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 114 | 6 | Molle et mince | C | 57 % | 53 % | jouabilité 57 % ; énigme non validée ; sans fiche |
| 115 | 7 | Molle et pente | C | 67 % | 67 % | jouabilité 67 % ; trait de 13 u suffit ; ligne directe ; énigme non validée ; sans fiche |
| 116 | 8 | Molle et lame | D | 33 % | 0 % | jouabilité 33 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 117 | 9 | Deux cordes | D | 17 % | 13 % | jouabilité 17 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 118 | 10 | Le filet | D | 57 % | 0 % | jouabilité 57 % ; pas de solution de référence ; noyau inatteignable ; énigme non validée ; sans fiche |
| 119 | 11 | Corde et colonne | D | 47 % | 0 % | jouabilité 47 % ; pas de solution de référence ; noyau inatteignable ; trait de 27 u suffit ; énigme non validée ; sans fiche |
| 120 | 12 | Opus | D | 7 % | 0 % | jouabilité 7 % ; pas de solution de référence ; noyau inatteignable ; trait de 77 u suffit ; énigme non validée ; sans fiche |

### Monde 11 — Quantique

| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |
|---|---|---|---|---|---|---|
| 121 | 1 | Le lien | C | 47 % | 47 % | jouabilité 47 % ; énigme non validée ; sans fiche |
| 122 | 2 | Opposition | D | 27 % | 0 % | jouabilité 27 % ; pas de solution de référence ; noyau inatteignable ; trait de 8 u suffit ; énigme non validée ; sans fiche |
| 123 | 3 | La mesure | D | 27 % | 0 % | jouabilité 27 % ; pas de solution de référence ; noyau inatteignable ; trait de 11 u suffit ; énigme non validée ; sans fiche |
| 124 | 4 | Deux possibles | D | 20 % | 0 % | jouabilité 20 % ; pas de solution de référence ; noyau inatteignable ; trait de 29 u suffit ; énigme non validée ; sans fiche |
| 125 | 5 | Le temps ralenti | D | 27 % | 3 % | jouabilité 27 % ; pas de solution de référence ; trait de 11 u suffit ; énigme non validée ; sans fiche |
| 126 | 6 | Lien et porte | D | 47 % | 0 % | jouabilité 47 % ; pas de solution de référence ; noyau inatteignable ; trait de 12 u suffit ; énigme non validée ; sans fiche |
| 127 | 7 | Intrication double | D | 3 % | 0 % | jouabilité 3 % ; pas de solution de référence ; noyau inatteignable ; trait de 13 u suffit ; énigme non validée ; sans fiche |
| 128 | 8 | Mesure tardive | D | 17 % | 3 % | jouabilité 17 % ; pas de solution de référence ; trait de 29 u suffit ; énigme non validée ; sans fiche |
| 129 | 9 | Temps et rebond | D | 50 % | 0 % | jouabilité 50 % ; pas de solution de référence ; noyau inatteignable ; trait de 17 u suffit ; énigme non validée ; sans fiche |
| 130 | 10 | Le choix | D | 37 % | 0 % | jouabilité 37 % ; pas de solution de référence ; noyau inatteignable ; trait de 28 u suffit ; énigme non validée ; sans fiche |
| 131 | 11 | Machine quantique | D | 73 % | 0 % | pas de solution de référence ; noyau inatteignable ; trait de 50 u suffit ; énigme non validée ; sans fiche |
| 132 | 12 | Quantix | D | 50 % | 0 % | jouabilité 50 % ; pas de solution de référence ; noyau inatteignable ; trait de 27 u suffit ; énigme non validée ; sans fiche |
