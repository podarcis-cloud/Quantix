# QUANTIX — Son des mondes (documentation au fil du travail)

> **Statut R209 : référence (W1N) ; mondes 2–11 à faire.** Voir `INDEX_DOCUMENTS.md`.


*Méthode (CONSIGNES §6) : l'expérience physique du monde → des formules → des textures ; bruitisme organique qui respire,
parcimonie, rien ne sature. Mesures : `Audio1._render` (crête, RMS, part de silence = fenêtres de 0,1 s sous RMS 0,004).*

## Monde 1 — Atelier (moteur W1N, `assets/js/sound.js`) [validé]

- **Expérience** : l'Atelier n'évoque pas d'expérience précise (avant‑propos) ; motif : l'assemblage, la respiration de la pièce.
- **Formules** : souffle B(t) (deux respirations, rapport φ) ; marée sin²(πu) sur le cycle ; crépitement Poisson × Pareto ;
  grains par carte logistique (r 3,62 → 3,92) ; bois aux modes d'Euler‑Bernoulli (1 : 2,756 : 5,404) en rythme euclidien ;
  frottement en banc résonant ; basse triton‑ressort ; nappe sinus Fibonacci ; vent de Shepard ; bégaiement.
- **R113** : version initiale (construction niveau par niveau, cycle de 16 mesures).
- **Retour de Simon (9 oct.)** : bonne base ; souffle / vent rémanent toujours présent qui gêne ; progression trop lente.
- **R118 — corrections** :
  - le grondement et le chœur d'air n'ont plus de fond permanent : ils suivent la respiration B(t) jusqu'à zéro
    (vrais creux) et baissent (grondement ×0,085·B·(0,3+0,7·marée), chœur ×(0,035+0,05·marée)) ;
  - **cycle de 8 mesures** au lieu de 16 (la marée revient deux fois plus vite) ;
  - **pulsation dès le niveau 1** : le bois euclidien joue partout (2 coups sur 8 au niveau 1), **groove** installé
    au niveau 3–4 (4 à 5 coups sur 8), plus dense ensuite.
- **Mesures (40 s)** : avant R118 — niveau 1 et 4 : crête 0,08, RMS 0,013, **0 % de silence** ; après — niveau 1 : crête 0,05,
  RMS 0,007, 53 % ; niveau 4 : crête 0,06, RMS 0,008, 48 %.
- **Rendus** : `quantix-W1N-R118-niveau1.mp3`, `quantix-W1N-R118-niveau4.mp3` (volume +12 dB pour l'écoute).

## Mondes 2 à 4 — à venir (variante légère de W1N avec les paramètres de l'expérience du monde, CONSIGNES §9)
