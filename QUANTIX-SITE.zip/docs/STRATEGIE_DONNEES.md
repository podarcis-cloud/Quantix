# Stratégie de correction des niveaux par les données (24 oct. 2026, R297)

## Ce que les 4 premiers joueurs (59 niveaux, 255 essais) apprennent
1. **Échec de précision ≠ échec de découverte.** Test « distance minimale de la balle au but » (calibré : une réussite passe en médiane à 24 px, p90 44 px ; seuil « presque » = 45 px). N21 : 29 échecs, 0 à moins de 45 px (médiane 167 px) ; N22 : 28 échecs, 4 près du but ; N18 médiane 92 ; N53 110. → Élargir le bassin ne servirait à rien : l'idée n'est pas trouvée. Le scan synthétique ne pouvait pas le dire.
2. **La référence n'est pas toujours découvrable** (N21 : aucun joueur ne trouve le trait unique prévu ; ils passent par 3-4 traits). La « géodésique » doit être aussi la solution *trouvable*, pas seulement la plus économe.
3. **Le joueur règle plus qu'il ne redessine** : déplacer 325 fois, échelle 60, gomme 36, annuler 32 ; 40 % des essais suivant un échec rejouent les mêmes traits retouchés.
4. **L'encre n'est un enjeu qu'au N7** (96 % utilisée) ; ailleurs 8–45 %. ~20 niveaux gagnés avec beaucoup moins d'encre que la référence.
5. **Lecture longue** (N3, N5, N7, N9 : 1–2 min avant le premier trait) = compréhension, pas difficulté physique.

## Coût (mesuré)
- Volume : ≈ 130 octets/événement, ≈ 60 Ko/session, ≈ 150 Ko/joueur. D1 gratuit (5 Go) ≈ 30 000 joueurs ; envoi par lots de 200 événements, quelques requêtes par session.
- Appareil : négligeable (journal en mémoire, 1 envoi / ≈ 20 s) ; coût réel = consentement et confiance, déjà traités (Oui/Non, panneau « Ce que collecte Quantix »).
- Coût humain/crédits : surtout l'analyse. Déjà outillée (`rapport-evenements.py`, `admin.html`) : un export + un rapport ≈ quelques minutes.
- **Verdict** : coût marginal quasi nul ; la valeur dépend de ce qu'on branche dessus (ci-dessous). Jusqu'ici, AUCUN niveau n'a encore été corrigé à partir des événements : on a surtout validé la chaîne.

## À brancher, par ordre de valeur / coût
1. **Fiche de santé par niveau** (auto) : scan synthétique + événements → diagnostic typé (découverte / précision / lecture / encre sans enjeu / contournement) et action suggérée (indice visuel, déplacer zone, élargir bassin, resserrer encre, réécrire la référence). Coût : faible.
2. **Rejeu contrefactuel** : rejouer dans le moteur headless les tracés réels (`la.g`) sur une variante corrigée du niveau → « cette correction aurait sauvé x % des échecs réels » avant de la livrer. Coût : moyen (outil `replay-reel.js`) ; valeur : élevée.
3. **Extraction de solutions** : regrouper les réussites par famille ; proposer en `optsol` la solution la plus trouvable/économe réellement jouée ; détecter contournements (réussite sans la mécanique).
4. **Courbe de difficulté** : essais médians + temps de préparation par niveau → réordonner/rééquilibrer les mondes ; cible P(1er essai).
5. **Aide adaptative** (jeu) : après N échecs loin du but, suggérer sans pénalité (jamais de vies/minuteurs/pub) ; mesurer si elle aide.
6. **À ajouter à la collecte** si besoin : cause d'échec « encre vide », usage d'indice, fps/perf appareil.

## Limites
4 joueurs, tous proches de Simon (experts) : indicatif, jamais définitif sous ≥ 3 joueurs par niveau et idéalement ≥ 10 ; biais « borne basse de difficulté ». Ne pas corriger sur 1 joueur : prioriser N21/N22 car 2 joueurs convergent.

## Rejeu contrefactuel : outil livré (25 oct. 2026)
`node tools/replay-reel.js EXPORT.json [--lv N] [--patch '{champ:valeur}'] [--v]` rejoue les tracés réels (`la.g`, final de chaque essai) dans le moteur headless.
- **Fidélité** : sur l'export 202610241553, 201 essais sur 231 (87 %) retrouvent le résultat réel (N21 27/30, N22 25/30). Écarts : déplacements en cours d'essai non rejoués, traits simplifiés. Indicatif, pas exact.
- **N21, contrefactuels testés** (30 essais réels, 2 réussites réelles) : bassin élargi 86→140 = 3 réussites (inchangé) ; zone interdite supprimée = 3 (inchangé) ; balle décalée = 0. → Confirme que ni le bassin ni la zone ne bloquent : l'idée n'est pas trouvée. Piste réelle : indice visuel / réécriture de la référence (aucun joueur ne tente le trait long prévu).
- Limite : valide une correction *physique* ; l'effet d'un indice visuel ne se mesure que par de nouveaux joueurs.
