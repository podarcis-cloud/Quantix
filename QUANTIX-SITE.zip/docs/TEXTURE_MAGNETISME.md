# Texture du Magnétisme (monde 8) — demandes de Simon, références, cahier de rendu

> **Statut R209 : référence (monde 8).** Voir `INDEX_DOCUMENTS.md`.


*Consigné le 12 octobre 2026 (R170), à la demande de Simon : « reprends depuis zéro cette texture en retrouvant toutes mes
demandes précédentes ». Sources : `REPRISE-SESSION.md` (R47–R153), archive `REPRISE-SESSION-R121.md`, discussions
précédentes (« Conception d'un didacticiel interactif par monde »), captures envoyées par Simon.*

## 1. Références fournies

| Référence | Contenu | Où |
|---|---|---|
| Vidéo `fsaver_87960.mp4` (27 s, 720×1280) | ferrofluide noir sous un aimant (verre) : labyrinthe de veines lisses et reliées, cellules serrées au cœur, doigts qui s'étirent vers l'extérieur, gouttelettes détachées en bordure, traîne derrière la goutte quand l'aimant se déplace | envoyée en R47, renvoyée le 11 oct. (uploads de la session) |
| Captures du 11 oct. 04 h 07 | « Deux aimants » (Magnétisme 4) : cellules très marquées ; « Le spectromètre » (12) : texture presque invisible | uploads de la session |
| Capture du 12 oct. 15 h 45 | « La dérive » : zone entourée en rouge — des « bords » (contours de cellules) et des traits | uploads de la session |

## 2. Demandes de Simon, dans l'ordre

1. **R47** — imiter la vidéo de ferrofluide dans un monde (le Magnétisme).
2. **R50** — « c'est mieux mais elle brouille la lecture du parcours » : transparence localisée, poussière animée à transparence aléatoire.
3. **R52** — refaire d'après la vidéo : cellules près de la goutte, filaments étirés derrière, gouttelettes.
4. **R149** — refaite d'après la vidéo (plages qui dérivent, cellules de tailles différentes, veines connectées, éclats rares).
5. **R150** — préfère la texture **discrète des niveaux 6 et 12**.
6. **R151** — labyrinthe un peu plus présent ; **plus aucune bille qui flotte** ; un **flux d'énergie** qui parcourt les veines.
7. **R152** — le niveau 4 montrait des cellules très marquées, le 12 presque rien : **même densité sur les 12 niveaux**.
8. **R153** — la demande ne vise **que** le Magnétisme (régression corrigée sur les autres mondes).
9. **12 oct.** — « il persiste comme des **bords** à la texture alors qu'elle **ne devrait pas contenir de trait** » ; aligner sur la
   douceur des niveaux 6 et 12 ; des **différences entre les rendus** d'un niveau à l'autre ; livrer dans le banc des rendus.
10. **12 oct.** — l'essai « doux » (veines floutées) : « elle semble toute **pixelisée** » → refaire **de zéro**, avec élégance.

## 3. Cahier de rendu (ce que la texture doit être)

- **Forme** : celle de la vidéo — veines lisses et connectées, cellules serrées au cœur, doigts radiaux en bordure, traîne, gouttelettes.
- **Matière** : de la lumière, pas un dessin : **aucun contour, aucune ombre portée, aucun liseré, aucun fil droit** ; bords adoucis.
- **Netteté** : calculée à la résolution du jeu, jamais une petite grille agrandie (cause de la pixelisation).
- **Discrétion** : celle des niveaux 6 et 12 ; elle ne concurrence jamais les murs, la balle, le bassin.
- **Constance** : même densité sur les 12 niveaux ; elle recule près des pièces (jusqu'à 35 %) sans disparaître.
- **Vie** : lente — le fluide respire (deux états qui se fondent), rares impulsions de lumière le long des veines ; pas de bille flottante.
- **Couleurs** : jetons du jeu — cyan au cœur, violet, rose en bordure ; une impulsion sur cinq vire au chaud.

## 4. Réalisation R170 (`ferro3` dans `visuals.js`, à valider dans le banc des rendus)

- Trois foyers placés autrement à chaque niveau (`f3Foyers`), chacun avec sa traîne.
- Champ F2 − F1 calculé une fois par niveau à 1 u, dans une métrique étirée (cellules rondes au cœur, doigts radiaux au‑delà),
  bord adouci sur ~2 u ; fragments et gouttelettes (disques lissés) en bordure ; voile très léger dans les cellules du cœur.
- Halo tiré du même calque par réduction ×4 puis agrandissement (flou sans `ctx.filter`, compatible iPhone).
- Deux états A/B fondus sur ~23 s, respiration de l'opacité, dérive de ±1,2 u ; impulsions qui suivent les crêtes.
- Les fils de soie (`vlSilkDraw`) ne sont plus dessinés dans ce monde quand `ferro3` est actif.
- Coût : ~170 ms au chargement du niveau (navigateur de bureau, deux calques), ~1 ms par image.
- Interrupteur : `F3_ON` (faux par défaut) — **la texture n'est pas active dans le jeu tant que Simon ne l'a pas validée**.

## 5. R171 — repris de zéro pour de bon : simulation (`ferro4`)

Retour de Simon sur R170 : animation invisible, et « loin d'un travail repris depuis zéro » (c'était encore le même réseau
de cellules de Voronoï). R171 change de nature :
- **Physique** : le labyrinthe d'un ferrofluide (instabilité de Rosensweig) est reproduit par la réaction‑diffusion de
  Gray‑Scott. Réglages vérifiés sur processeur avant intégration : F = 0,029, k = 0,057 → labyrinthe ; F = 0,030,
  k = 0,0625 → gouttes ; F = 0,010, k = 0,075 → rien. Chaque aimant impose ces régimes du cœur vers l'extérieur.
- **Moteur** : WebGL 2, grille 240 × 320 en demi‑flottants, 12 pas par image ; rendu à 540 × 720 par seuillage doux du champ
  interpolé (corps du fluide), reflet sur le bord (gradient), halo léger ; couleur cyan → violet → rose selon la distance à l'aimant.
- **Vie** : deux aimants qui dérivent (un tour en 40 à 70 s) ; un faible tourbillon fait couler la matière ; l'aimant rallume
  la matière là où il passe ; les gouttes abandonnées s'éteignent.
- **Règles** : masque calculé par niveau (`ffClear` × zone du bassin à 0, bord fondu sur 16 u) — plus de découpe rectangulaire ;
  pas de fils de soie dans ce monde ; repli `ferro3` sans WebGL 2.
- **Non vérifié** : iPhone (performance, prise en charge des textures en demi‑flottants).

## 6. R172 — validé par Simon, actif dans le jeu, sollicité par les aimants

- **Sources** (`f4Src`) : chaque aimant `mag` du niveau (force k → s = 0,35 + 0,5·√|k|, bornée 0,5–1,2 ; rayon du motif
  1,35 × rayon de l'aimant, 70–200 u, grandit avec la force) et chaque bobine `coil`. Un aimant attire le fluide (légère
  aspiration vers son centre) ; un **répulseur** (k < 0) vide son cœur et repousse le fluide en **couronne**. Sans aimant
  attractif (La dérive, Le cyclotron…), deux foyers dérivent comme en R171.
- **Gouttelettes** : deux couches (cellules ≈ 9 u et ≈ 4,6 u), tailles variées, placées seulement dans les vides en bordure
  du fluide (là où il n'y a pas de fluide mais où il y en a juste à côté).
- `F3_ON` vrai par défaut. Repli sans WebGL 2 : `ferro3` (R170, fixe).

## 7. R173 — partout, à plusieurs échelles, vitesse variable (demande de Simon)

- **Trois nappes** (`F4_LAYERS`) : large (grille 100 × 134, opacité 0,40), moyenne (160 × 214, 0,72) et fine (240 × 320, 1).
  Les deux premières couvrent **tout le fond** par plaques qui dérivent lentement (bruit fbm) et restent attirées par les
  aimants ; la fine vit autour des aimants (labyrinthe, couronne des répulseurs, gouttelettes).
- **Opacité et luminosité** varient d'une région à l'autre (deux champs de bruit lents par nappe) ; teinte décalée par nappe.
- **Vitesse** : pas de temps local de la réaction‑diffusion, tiré d'un bruit qui change dans le temps (0,35 à 1,25), multiplié
  par la proximité des aimants (jusqu'à × 1,9 près d'un aimant fort) et réduit près d'un répulseur.
