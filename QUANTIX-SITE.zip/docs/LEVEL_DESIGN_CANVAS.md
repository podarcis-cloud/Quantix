# QUANTIX — fiche de conception d'un niveau (Level Design Canvas)

*Une fiche par niveau. Elle se remplit dans l'ordre de la méthode §9 de
`MASTER_LEVEL_DESIGN_PROTOCOL.md` — pas après coup, pas comme une
justification a posteriori d'un niveau déjà construit. Un niveau n'est
« terminé » que lorsque sa fiche passe les dix portes de la section 4.*

Le gabarit ci-dessous, puis un exemple rempli sur le niveau #1 (« La
ligne », monde 1 Atelier) pour prouver que la fiche est utilisable en
pratique, pas seulement lisible en théorie.

---

## 1. Gabarit

```markdown
### Niveau #N — <nom>, monde <M> <nom du monde>

## Identité
- Concept (une phrase) :
- Mécanique dominante :
- Intention (pourquoi ce niveau existe) :
- Position dans l'arc du monde (introduction / variation / combinaison /
  complication / renversement / synthèse — voir §4 du protocole maître) :

## Gameplay
- Mécanique principale :
- Mécaniques secondaires :
- Trajectoire(s) prévue(s) — décrire au moins la voie principale et une
  voie alternative légitime si elle existe :
- Trajectoires à exclure (raccourcis) et comment elles sont fermées :
- Décisions que le joueur doit prendre, et à quel moment :
- Condition de victoire exacte :

## Dramaturgie
- Introduction :
- Apprentissage (rappel ou nouveauté ?) :
- Développement :
- Complication :
- Fausse piste (s'il y en a une) :
- Renversement (s'il y en a un) :
- Résolution :
- Payoff — en quoi la résolution est-elle satisfaisante :

## Cognition
- Information présentée au joueur :
- Information volontairement cachée (et l'indice qui la rend déductible) :
- Ce que le niveau demande : anticipation / observation / mémoire /
  expérimentation (une ou plusieurs) :
- Type d'erreur attendu si le joueur échoue (§5 du protocole maître) et ce
  que cet échec lui apprend :

## Émotion
- Émotion recherchée dominante :
- Évolution émotionnelle (tension → ? → ?) :
- Moment de tension le plus fort :
- Moment de soulagement :

## Son
- Ambiance du monde (héritée de `WD[]`) :
- Événements sonores spécifiques à ce niveau (impact, rebond, portail...) :
- Un climax sonore existe-t-il à la résolution ? Lequel :

## Différenciation
- Comparé au niveau précédent :
- Comparé au niveau suivant :
- Autre niveau du jeu employant une mécanique ou une trajectoire proche,
  et ce qui distingue les deux :

## Robustesse — vérifié comment, pas juste affirmé
- Solution principale : [tracé exact, testé et collé ici]
- Solution(s) alternative(s) légitime(s) trouvée(s) :
- Contournements cherchés et fermés (méthode `nd`/géométrie, référence
  `bypass.js`) :
- Softlocks cherchés (le joueur peut-il se coincer sans pouvoir recommencer
  autrement qu'en abandonnant ?) :
- Budget d'encre (`ink`) : suffisant pour la solution prévue, insuffisant
  pour un raccourci de secours :

## Portes de validation (voir §4 ci-dessous)
- [ ] A — Fonction
- [ ] B — Identité
- [ ] C — Gameplay
- [ ] D — Progression
- [ ] E — Cognition
- [ ] F — Émotion
- [ ] G — Surprise (si le concept s'y prête)
- [ ] H — Son
- [ ] I — Robustesse
- [ ] J — Différenciation
```

---

## 2. Note sur le champ « Décisions que le joueur doit prendre »

C'est le champ le plus souvent vide dans les niveaux actuels du jeu, et
c'est symptomatique du problème diagnostiqué (redondance, obstacles sans
fonction). Un niveau digne de ce nom doit pouvoir répondre à cette question
sans détour. « Le joueur trace un mur vers la zone » n'est pas une
décision — c'est l'absence de niveau. Une décision ressemble à : *« le
joueur doit choisir entre économiser son budget pour la mécanique
principale, ou en garder assez pour corriger une erreur d'angle »*, ou
*« le joueur doit choisir quel des deux portails emprunter, chacun menant
à une contrainte différente en aval »*.

---

## 3. Note sur « Trajectoires à exclure »

C'est ici que la méthode technique acquise sur les mondes 2 et 3
(`BYPASS-RAPPORT.md`) s'insère dans la fiche : fermer un raccourci n'est
plus une fin en soi, c'est une case à remplir à l'intérieur d'une
conception plus large. La méthode du couloir de non-tracé (`nd`) reste
valable comme *outil*, mais son usage doit maintenant être justifié par
l'intention du niveau, pas appliqué mécaniquement à chaque niveau qui
échoue à `bypass.js`.

---

## 4. Les dix portes de validation

Un niveau ne passe en « terminé » que si les dix portes sont cochées. Si
une porte échoue, le niveau retourne en conception — pas de « presque
bon ».

| Porte | Question | Preuve attendue dans la fiche |
|---|---|---|
| **A — Fonction** | Chaque élément placé a une fonction dans au moins une des quatre familles (§6 du protocole maître) | Section Gameplay + Différenciation |
| **B — Identité** | Le niveau est immédiatement différenciable des autres | Section Identité + Différenciation |
| **C — Gameplay** | La mécanique dominante est réellement nécessaire, pas contournable | Section Robustesse, `bypass.js` |
| **D — Progression** | Le niveau a une évolution interne (pas un seul geste répété) | Section Dramaturgie |
| **E — Cognition** | Le joueur apprend ou affine quelque chose de précis | Section Cognition |
| **F — Émotion** | Une expérience intentionnelle est provoquée, pas laissée au hasard | Section Émotion |
| **G — Surprise** | Quand le concept s'y prête, la résolution a un élément mémorable, préparé (§3 du protocole maître) | Section Dramaturgie, champ Payoff |
| **H — Son** | Le son accompagne réellement le gameplay, pas seulement l'ambiance de fond | Section Son |
| **I — Robustesse** | Le niveau fonctionne techniquement, rien n'est une hypothèse non vérifiée | Section Robustesse, traces de simulation réelle |
| **J — Différenciation** | Le niveau ne reproduit pas une structure déjà utilisée ailleurs | Section Différenciation, `tools/redundancy.js` |

---

## 5. Niveau #1 — traité pour de vrai, monde 1 Atelier

*Premier niveau réellement mis en chantier selon la méthode (pas un
exemple théorique). Correction au passage : une première version de cette
fiche l'appelait « La ligne » et omettait son noyau bonus — erreur de
recopie, corrigée ici après relecture des données réelles
(`assets/js/levels.js`, niveau d'indice 0). Le vrai nom est **La rampe**.*

### Niveau #1 — La rampe, monde 1 Atelier

## Identité
- Concept : *la toute première rampe que le joueur trace de sa vie dans ce
  jeu — la promesse du jeu tenue en une seule action.*
- Mécanique dominante : aucune — zéro mécanique par construction (`pal`
  par défaut = structure seule, aucun mur fixe hormis le bassin d'arrivée).
- Intention : prouver en un geste que dessiner un mur suffit à faire
  quelque chose, et introduire discrètement — sans l'imposer — l'idée
  qu'il existe toujours plus d'une façon de réussir.
- Position dans l'arc du monde : introduction absolue (position 1/12).

## Gameplay
- Données réelles : `ball:[52,44]`, `cup:[240,452,110,'R']`,
  **Refonte du 26/09** : `star:[200,100]`, `ink:480`, et surtout un mur fixe `[20,70,90,88]` — un rail déjà posé par le monde, que le joueur prolonge plutôt que de dessiner depuis une page blanche. Vérifié : le rail seul ne suffit pas (`sans suite : fail`), une continuation raisonnable réussit. Le noyau (200,100) reste à l'écart de la continuation directe (`gotStar:false`) et n'est atteint que par un détour délibéré (`gotStar:true`).
- Mécanique principale : tracer un mur de structure, la gravité fait le
  reste.
- Mécaniques secondaires : aucune, volontairement.
- Trajectoire prévue : une diagonale de la balle (52,44) vers la zone
  (240-350, 404-452). Le conseil du niveau (« passe par le noyau si tu
  peux ») pointe vers le noyau à (150,246), sans l'exiger.
- Trajectoires à exclure : aucune — c'est le seul niveau du jeu où un
  raccourci ne peut pas exister, puisque le tracé direct *est* une
  solution voulue.
- Décision que le joueur doit prendre : **vérifiée réelle, pas supposée**.
  Deux tracés testés par simulation directe : un tracé bas
  (`[30,300]→[250,440]`) atteint la zone sans le noyau (`gotStar:false`) ;
  un tracé qui dévie vers `(100,325)` l'obtient (`gotStar:true`). Les
  deux réussissent. **Correction faite après relecture** : à la position
  d'origine (150,246), le noyau était ramassé par le rayon de collecte
  (R+10) même sans viser — la « décision » n'en était pas une, juste un
  bonus automatique. Déplacé à (100,325), vérifié à l'écart de tout
  tracé direct raisonnable (`gotStar:false` sur plusieurs tracés directs
  testés) et atteignable seulement par un détour volontaire — désormais
  un vrai choix dès le premier niveau, pas supposé, mesuré.
- Condition de victoire : entrer dans la zone.

## Dramaturgie
- Introduction : l'écran de jeu lui-même — balle, doigt, zone, noyau
  visibles sans ambiguïté.
- Apprentissage : « tracer un mur, la balle roule dessus » — l'essentiel
  de la leçon.
- Développement : la présence du noyau, discrète, sans obligation.
- Complication : aucune.
- Fausse piste : aucune.
- Renversement : aucun.
- Résolution : la balle entre dans la zone après un unique tracé.
- Payoff : la simplicité elle-même, avec une nuance — *« c'est simple, et
  j'ai déjà une raison d'y revenir voir si je peux faire mieux »* si le
  joueur a manqué le noyau.

## Cognition
- Information présentée : position de la balle, forme de la zone,
  position du noyau — tout visible d'un coup d'œil.
- Information cachée : aucune.
- Ce que le niveau demande : observation minimale + un geste ; une
  amorce d'arbitrage si le joueur remarque le noyau.
- Type d'erreur attendu : erreur d'exécution seulement (tracé mal placé) —
  jamais erreur de compréhension.

## Émotion
- Émotion recherchée : compétence immédiate — *« je sais déjà jouer »*.
- Évolution émotionnelle : curiosité (l'écran) → geste → confirmation.
- Moment de tension : minime, volontairement.
- Moment de soulagement : la balle entre dans la zone, noyau optionnel.

## Son
- Ambiance du monde : Atelier — fondamentale 53, mode éolien, 60 bpm, onde
  sinusoïdale, la plus douce du jeu (`WD[0]`).
- Événements sonores : **vérifiés par instrumentation réelle** (écoute des
  événements `BUS`, pas une lecture du code). Pour le tracé qui passe par
  le noyau, la séquence observée est : plusieurs `ball.impact` pendant le
  glissement le long du mur tracé, `star.collect` exactement au passage
  du noyau, puis d'autres `ball.impact`, puis `level.complete` — dans cet
  ordre, sans accroc.
- Climax sonore à la résolution : le son de réussite standard, sans
  variation — cohérent, ce n'est pas ici qu'il faut surprendre.

## Différenciation
- Comparé au niveau suivant (#2 Le seuil) : #2 ajoute un premier mur
  (`[186,0,186,248]`, une cloison qui descend du plafond sans toucher le
  sol) — la première vraie variable géométrique. Escalade correcte.
- Comparé aux autres niveaux du monde — **mesuré, pas supposé** :
  `node tools/redundancy.js 1` place #1 en paire suspecte avec 8 des 11
  autres niveaux du monde, dont un score de 0,99 avec #8 « La portée ».
  Examen à la main : #8 a un `nd` qui interdit tout le centre du niveau et
  force un détour (« construis un tremplin ») — une contrainte réelle que
  #1 n'a pas du tout, mais que l'outil ne voit pas (limite déjà documentée
  dans `REDUNDANCY_ANALYSIS.md`). La paire est donc un faux positif de
  l'outil, pas une vraie redondance. #2 (0,96), #7 « Le col » (0,93),
  #10 « Économie » (0,92) et #5 « Le goulot » (0,90) ont chacun plusieurs
  murs (vérifié : #5 en a cinq segments, #7 quatre, #10 deux) — une vraie
  silhouette, pas un décor. Leur score élevé avec #1 vient de l'angle et
  de la distance départ→arrivée qui restent proches (30 % + 15 % du
  score) ; sans avoir vérifié *par simulation* si ces murs imposent un
  détour réel ou ne font que longer la trajectoire directe, je ne peux
  pas encore dire si c'est un faux positif comme #8 ou une vraie
  redondance — c'est la vérification à faire quand leur tour viendra, pas
  ici, pour ne pas disperser le travail sur #1. **Conclusion pour #1** :
  rien à corriger ici — sa fonction est justement d'être le plancher sans
  contrainte. Le travail revient aux niveaux #2, #5, #7, #10 quand vient
  leur tour : vérifier qu'ils escaladent réellement au-delà de « #1 plus
  un mur », pas seulement en silhouette.

## Robustesse — vérifié par simulation directe, pas affirmé
- Solution principale (sans noyau) : `[[30,300],[250,440]]` → `success`,
  `gotStar:false`.
- Solution alternative (avec noyau) : `[[24,80],[150,246],[260,440]]` →
  `success`, `gotStar:true`.
- Solution alternative (directe, obtient aussi le noyau par proximité de
  trajectoire) : `[[24,80],[250,440]]` → `success`, `gotStar:true` — le
  rayon de collecte du noyau (`R+10` = 20,5 unités) est assez généreux
  pour qu'une diagonale raisonnablement haute le traverse sans viser
  spécifiquement — cohérent avec un niveau d'introduction qui ne doit
  punir personne.
- Contournements : sans objet, rien à contourner à ce stade.
- Softlocks : aucun trouvé.
- Budget d'encre : 480, très large par rapport aux tracés testés (~250 à
  350 de longueur) — cohérent avec l'absence de contrainte voulue.

## Portes de validation
- [x] A — Fonction (le mur a la seule fonction possible : exister ; le
  noyau introduit un premier micro-arbitrage sans jamais forcer)
- [x] B — Identité (premier niveau, identité = simplicité absolue)
- [x] C — Gameplay (aucune mécanique à vérifier)
- [ ] D — Progression — non applicable par nature : ce niveau est le degré
  zéro contre lequel la progression du jeu se mesure ensuite.
- [x] E — Cognition (une leçon immédiatement acquise, plus une amorce de
  décision)
- [x] F — Émotion (compétence immédiate, intentionnelle)
- [ ] G — Surprise — non applicable, le concept ne s'y prête pas.
- [x] H — Son (séquence d'événements vérifiée par instrumentation réelle)
- [x] I — Robustesse (trois tracés simulés et réussis, aucun softlock trouvé)
- [x] J — Différenciation (mesurée par `redundancy.js`, le seul score
  élevé restant expliqué et écarté ; le travail correctif revient aux
  niveaux voisins, pas à #1)

**Verdict : niveau #1 validé.** Deux portes non cochées (D, G) le sont
légitimement, documenté ci-dessus. C'est le premier niveau du jeu à passer
par la méthode complète, avec preuve par simulation à chaque porte qui
s'y prêtait — pas une lecture du code, une exécution réelle.

---

*Ce niveau sert aussi de référence de calibrage : une fiche remplie
honnêtement peut avoir des portes non cochées sans que le niveau soit
invalide — à condition que l'absence soit justifiée par l'intention, pas
par la paresse. Le protocole ne demande pas dix portes vertes partout, il
demande une réponse honnête à chacune, et une preuve pour celles qui
peuvent en avoir une.*

---

## 6. Niveau #2 — Le seuil, monde 1 Atelier

### Niveau #2 — Le seuil, monde 1 Atelier

## Identité
- Concept : *la première chose qui se met entre la balle et l'arrivée —
  et la première fois que l'esquiver doit être un choix, pas un hasard.*
- Mécanique dominante : aucune (monde sans mécanique) — premier obstacle
  géométrique pur.
- Intention : faire du contournement d'obstacle une décision consciente,
  pas quelque chose que le joueur fait sans s'en apercevoir.
- Position dans l'arc du monde : premier temps de variation (2/12).

## Gameplay
- Données réelles : `ball:[46,40]`, `cup:[246,456,106,'R']`,
  `star:[212,300]`, `ink:580`, mur fixe `[186,0,186,248]` (cloison qui
  descend du plafond, s'arrête à y=248 sans toucher le sol à y=456).
- **Défaut trouvé et corrigé avant validation** : dans sa forme d'origine,
  une diagonale directe et naïve (`[16,70]→[260,430]`) passait déjà sous
  la cloison sans que le joueur ait besoin d'y penser — vérifié par
  simulation, pas supposé. La cloison ne remplissait aucune fonction
  réelle (porte A du protocole maître échouait). Corrigé par un couloir
  `nd:[[136,0,224,260]]` qui force le tracé à rester à gauche de la
  cloison tant qu'il n'est pas descendu sous sa hauteur — la balle,
  elle, n'est jamais gênée par le `nd`, seul le geste du joueur l'est.
- Trajectoire prévue : descendre dans le couloir libre (x<136), bifurquer
  vers la zone une fois sous y=260, soit directement soit en passant par
  le noyau (212,300) au passage.
- Trajectoires à exclure : la diagonale directe qui ignore la cloison —
  désormais fermée (voir Robustesse).
- Décision que le joueur doit prendre : où et quand amorcer la
  bifurcation vers la droite — trop tôt, le tracé entre dans le `nd` et
  est refusé ; trop tard, il faut plus d'encre. Une vraie décision
  spatiale, la première du jeu.
- Condition de victoire : rester dans la zone plus de 16 frames
  consécutives (~0,27 s) — pas seulement y entrer. Détail important
  découvert en testant : un tracé trop rapide fait rebondir la balle hors
  de la zone avant que ça compte (voir Robustesse).

## Dramaturgie
- Introduction : la cloison est visible d'emblée, son arrêt avant le sol
  aussi — rien de caché.
- Apprentissage : rappel du geste de #1, avec une première contrainte.
- Développement : la cloison impose un détour réel, pour la première fois.
- Complication : aucune au-delà de la cloison elle-même — le monde ne
  complique pas encore deux choses à la fois.
- Fausse piste : la diagonale directe *est* une fausse piste plausible et
  naturelle (ce que ferait un joueur qui n'a pas encore remarqué la
  cloison) — désormais elle échoue proprement plutôt que de réussir par
  accident, ce qui est la vraie leçon du niveau.
- Renversement : aucun, prématuré à ce stade.
- Résolution : la balle descend, bifurque, se pose dans la zone.
- Payoff : élégant — une fois vu, le passage sous la cloison est évident ;
  la satisfaction vient de la simplicité de la solution une fois comprise
  (protocole maître §3, deuxième temps : *« tout était là depuis le
  début »*).

## Cognition
- Information présentée : la cloison et son arrêt avant le sol, visibles
  sans ambiguïté.
- Information cachée : aucune — la solution est déductible à l'œil.
- Ce que le niveau demande : observation + une décision spatiale simple.
- Type d'erreur attendu : erreur de compréhension pour un joueur qui
  n'aurait pas remarqué que la cloison s'arrête (essaierait de la
  contourner par le haut, ou de tracer à travers) — l'échec doit lui
  montrer que le bas est libre.

## Émotion
- Émotion recherchée : la première petite fierté de « j'ai vu la
  solution ».
- Évolution émotionnelle : reconnaissance de l'obstacle → bref temps de
  lecture → confiance en traçant.
- Moment de tension : au moment de décider où bifurquer.
- Moment de soulagement : la balle se pose et y reste.

## Son
- Ambiance du monde : Atelier, `WD[0]`, inchangée.
- Événements sonores — **vérifiés par instrumentation réelle** sur la
  solution avec noyau : cinq `ball.impact` pendant la descente le long du
  tracé, `star.collect` au passage du noyau, cinq autres `ball.impact`,
  puis `level.complete`. Dans l'ordre, sans accroc.
- Climax sonore : son de réussite standard — cohérent avec un niveau
  encore très tôt dans la progression.

## Différenciation
- Comparé à #1 : #1 n'a aucune contrainte ; #2 introduit la première —
  escalade correcte et maintenant **vérifiée**, pas seulement supposée
  (voir la fausse alerte de redondance ci-dessous).
- Mesuré : `redundancy.js` donne toujours 0,96 avec #1 — l'outil ne voit
  pas les zones `nd` (limite documentée dans `REDUNDANCY_ANALYSIS.md`) et
  reste donc aveugle à la différence de geste maintenant réelle entre les
  deux niveaux. Confirmé faux positif par la vérification ci-dessus, pas
  seulement par hypothèse.
- Comparé au niveau suivant (#3 La corniche) : à vérifier à son tour —
  devrait varier l'orientation ou la forme de l'obstacle, pas répéter une
  cloison verticale identique.

## Robustesse — vérifié par simulation directe
- **Défaut initial trouvé** : diagonale directe `[16,70]→[260,430]`
  réussissait sans détour. Non conforme à l'intention du niveau.
- **Piège technique découvert en corrigeant** : allonger simplement la
  cloison (au lieu d'ajouter un couloir `nd`) risque de faire « coller »
  la balle contre elle — un mur vertical a un frottement tangentiel
  proche de 1 (`FRIC=.995`), donc une balle qui la frôle glisse à peine et
  peut sembler bloquée pendant des centaines de frames. Écarté au profit
  d'un couloir `nd` qui ne touche jamais la cloison.
- Solution principale (avec noyau) : `[[16,70],[100,240],[212,300],
  [280,448]]` → `success`, `gotStar:true`. Vérifié via le vrai
  `loadLevel()`/`physics()` du moteur, pas une approximation.
- Solution alternative (sans noyau) : `[[16,70],[100,240],[260,440]]` →
  `success`, `gotStar:false`.
- Contournement fermé : la diagonale directe d'origine échoue maintenant
  (bloquée par le `nd`), confirmé par relecture du tracé.
- Point d'attention appris ici, à généraliser : la condition de victoire
  exige de **rester** dans la zone 16 frames, pas seulement d'y entrer —
  une approche trop rapide rebondit hors de la zone avant que ça compte.
  À vérifier systématiquement sur tout niveau où l'approche finale est
  raide.
- Softlocks : aucun trouvé sur les tracés testés — le couloir `nd` reste
  large (88 unités) et loin de la cloison réelle (50 unités de marge),
  donc pas de risque de collage contre un mur que le joueur aurait
  lui-même dessiné trop près de la cloison fixe.
- Budget d'encre : 580 ; la solution avec noyau en consomme environ 480 —
  marge raisonnable sans être extravagante.

## Portes de validation
- [x] A — Fonction (la cloison impose maintenant un vrai détour, corrigé
  et vérifié — elle ne remplissait aucune fonction avant correction)
- [x] B — Identité (premier niveau du monde avec un obstacle réel)
- [x] C — Gameplay (sans objet au sens mécanique — pas de mécanique à ce
  monde — mais l'obstacle géométrique, lui, est vérifié indispensable)
- [x] D — Progression (une évolution interne réelle : lecture, décision,
  exécution — pas un seul geste répété)
- [x] E — Cognition (une décision spatiale simple, déductible à l'œil)
- [x] F — Émotion (petite fierté de la première lecture réussie)
- [ ] G — Surprise — non applicable, le concept ne s'y prête pas encore
  (rien n'est caché ni retourné à ce stade du monde).
- [x] H — Son (séquence vérifiée par instrumentation réelle)
- [x] I — Robustesse (défaut trouvé, corrigé, revérifié par simulation ;
  piège de collage identifié et évité ; aucun softlock trouvé)
- [x] J — Différenciation (écart avec #1 maintenant réel et vérifié, pas
  seulement mesuré par un outil aveugle aux `nd`)

**Verdict : niveau #2 validé, après correction.** C'est le premier niveau
de cette refonte où la méthode a trouvé un vrai défaut avant de le
corriger plutôt que de simplement confirmer que tout allait bien — exactement
ce que la méthode est censée faire.

---

## 7. Refonte du 26/09 — géométrie réelle, pas des paramètres

*Suite à un retour direct : les corrections précédentes sur #1 et #2 ne
touchaient qu'un bonus ou un couloir de non-tracé, jamais la forme du
niveau. Correction en profondeur ci-dessous, vérifiée par simulation, pas
seulement décrite.*

**Niveau #1 — La rampe.** Un mur fixe existe désormais dès le départ
(`[20,70,90,88]`) : le tout premier geste du jeu n'est plus « trace
n'importe quoi », c'est « termine ce qui a déjà commencé ». Vérifié :
sans aucun tracé du joueur, le niveau échoue (le rail seul ne mène nulle
part) ; une continuation raisonnable réussit. Le noyau (200,100) est à
l'écart de cette continuation directe et n'est obtenu que par un détour
volontaire — les deux confirmés par simulation directe.

**Niveau #2 — Le seuil.** Remplacé la cloison unique par une vraie porte
à deux battants (`[186,0,186,180]` et `[186,456,186,280]`) : une fenêtre
de 100 unités que tout trajet doit traverser, plus de couloir de
non-tracé nécessaire pour fermer un raccourci. Effet secondaire trouvé en
testant, gardé parce qu'il est bon : viser le haut de la fenêtre manque
le noyau, viser le bas l'obtient — la précision du seuil détermine le
bonus, dans le même geste. Vérifié : passage haut → succès sans noyau ;
passage bas → succès avec noyau ; sans rien tracer → échec.

Les deux aperçus jouables ont été régénérés avec cette géométrie.

---

## 8. Niveau #3 — La corniche, monde 1 Atelier (26/09)

Contrairement à #1 et #2, la géométrie existante était déjà juste : la
balle démarre *au-dessus* de l'auvent (`w:[[120,170,360,170]]`), donc le
premier réflexe naïf (ne rien faire, ou tracer vaguement vers la zone)
la pose sur l'auvent, immobile — vérifié (`sans rien : fail`, la balle se
fige à (320,156)). Il faut activement dégager le bord de l'auvent (x=120)
avant que la chute n'y colle la balle. Rien à changer dans les murs.

**Seul défaut trouvé** : le noyau (180,240) était placé sous une portion
de l'auvent inatteignable par un détour naturel — vérifié en mesurant où
un tracé passe *réellement* (pas où on croit qu'il passe), pas une seule
tentative ne s'en approchait à moins de 100 unités. Déplacé à (250,130),
sur le trajet d'un détour qui dégage le bord plus tôt puis revient sous
l'auvent — vérifié à moins de 14 unités (rayon de collecte 20,5), et à
l'écart de la solution directe (48 unités). Aperçu :
https://claude.ai/artifact/UVZY2AAVpCS1xJ7ypRBxeR

---

## 9. Niveau #1 — refonte 2, une vraie fourche (26/09, suite au retour direct)

*Le retour était juste : ajouter un rail ne suffisait pas à changer
fondamentalement le niveau. Ajouté depuis : après le rail, une zone
interdite au tracé (`nd:[[150,180,60,160]]`) sépare deux routes réelles
vers le même bassin — une échappée courte, une qui remonte par le noyau
avant de redescendre. Ce n'est plus une option cachée, c'est une
bifurcation visible dans la géométrie même du niveau.*

**Ce qui a résisté et pourquoi j'ai changé d'approche en cours de route** :
une première tentative utilisait un vrai mur vertical pour séparer les
deux routes plutôt qu'un `nd`. Les deux tentatives se sont coincées contre
ce mur (la balle s'y immobilise, glissement quasi nul sur un mur vertical
dans ce moteur — même limite que sur #2). Remplacé par un `nd`, qui ne
touche jamais la balle. Une troisième route (plus large, à droite) a été
tentée et abandonnée après plusieurs échecs : le moteur ne « rattrape »
pas bien une balle déjà lancée vite par un nouveau segment de tracé — pas
un défaut de conception, une limite technique constatée, documentée plutôt
que masquée.

Vérifié par simulation directe via le vrai `loadLevel()` : sans tracé,
échec ; route courte, réussite sans noyau ; route par le noyau, réussite
avec noyau. Aperçu : https://claude.ai/artifact/MgZrcEgWJ9FVmKip1T5STr

---

## 10. Niveau #1 — refonte 3, une vraie courbe (26/09, suite au retour « pas de lignes droites »)

*Remplacé le rail droit et la fourche par une courbe de Bézier continue
(25 segments courts approximant un arc en S) — un geste sculpté, pas une
ligne ni un angle. Deux tentatives précédentes ont échoué avant celle-ci :
une spirale (coincée — courbure trop serrée pour ce moteur) et un grand
arc à centre unique (jamais atteint par la balle — mauvais raccordement).
La courbe de Bézier, à courbure progressive sans inversion brutale, est
celle qui a fonctionné.*

Vérifié : la courbe seule ne suffit pas (`sans rien : fail`) — elle
s'arrête juste assez tôt pour que le dernier geste, un court trait avant
le bassin, reste au joueur. Avec ce geste : réussite. Le noyau (300,410)
est cueilli par ce même geste final dans tous les essais — pas un choix
séparé ici, plutôt la récompense naturelle d'une exécution propre.

Aperçu : https://claude.ai/artifact/MgZrcEgWJ9FVmKip1T5STr

---

## Règle apprise en test réel (26/09) — le budget d'encre se calcule au doigt, pas à la règle

« Le premier trait » était réglé à 35 d'encre : suffisant pour un trait
parfaitement droit (~30), insuffisant pour un vrai trait au doigt, qui
ondule. Signalé en test sur téléphone. Mesure : aucune solution hors de
l'idée du niveau n'existe jusqu'à 120 d'encre — la contrainte de 35
n'empêchait rien, elle ne faisait que frustrer. Passé à 80.

**Règle pour tous les niveaux** : le budget d'encre doit valoir au moins
**2× la longueur en ligne droite** de la solution prévue. Ne le resserrer
davantage que si un balayage prouve qu'un budget plus large ouvre un
contournement — jamais par précaution.

---

## 11. Monde 1 — L'Atelier, refonte complète R30 (fiche de synthèse)

*Cette section remplace les fiches §5 à §10 ci-dessus, qui documentent les
étapes intermédiaires (conservées pour l'historique des erreurs).*

**Thème du monde : « le trait est matière ».** Pas de mécanique spéciale —
l'identité vient de ce que le trait apprend à faire, un geste par niveau.
Émotion dominante : la compétence qui s'étend, niveau après niveau.

| # | Niveau | Geste appris | Arc | Chute (payoff) | Noyau récompense | Encre |
|---|---|---|---|---|---|---|
| 1 | Le premier trait | dévier | introduction | « c'est tout ? » — un petit trait inverse le trajet | la précision | 120 |
| 2 | Le pont | porter | introduction | la balle roule sur *ta* ligne | l'audace (tremplin, 3× plus souvent) | 200 |
| 3 | Le demi-tour | renvoyer | variation (direction) | le bassin était derrière toi | les renvois amples | 200 |
| 4 | Le relais | enchaîner | variation (nombre) | deux gestes qui se répondent | un lancer précis entre les îlots | 420 |
| 5 | La douceur | freiner | variation (intensité) | le problème n'est pas où, mais à quelle vitesse | les freinages amples | 240 |
| 6 | Le fil | protéger | contrainte (danger) | funambule au-dessus des pointes | le risque (raser le danger) | 360 |
| 7 | Économie | utiliser le décor | contrainte (budget) | le chemin existait déjà | le raccord précis | 70 |
| 8 | La portée | lancer | combinaison | premier tir balistique | les tirs en cloche | 400 |
| 9 | Le leurre | détourner | fausse piste | l'aide évidente est le piège | le chemin humble | 100 |
| 10 | Le col | viser | complication | tout se décide au départ | l'entrée centrée | 260 |
| 11 | Le plafond | rabattre | renversement | le trait au-dessus de la balle | le rabat précis | 200 |
| 12 | L'établi | tout | synthèse | dévier + franchir la fosse + renvoyer | le tremplin (rappel du #2) | 600 |

**Portes de validation — vérifiées par outil, pas déclarées :**
- A Fonction / C Gameplay : chaque élément fixe est nécessaire — `design.js`
  (0 solution hors idée ; #12 : 0 trait unique sur 33 337 ne remplace les
  deux derniers gestes).
- B Identité / J Différenciation : `redundancy.js 1` v2 → 0 paire suspecte.
- I Robustesse : `monde1.js` → 12/12, tolérance au doigt ≥ 72 %.
- D Progression, E Cognition, F Émotion, G Surprise : tableau ci-dessus —
  chaque niveau a un geste, un arc, une chute nommée.
- H Son : **non traité en R30** — les événements sonores existants se
  déclenchent (impact, noyau, réussite), mais aucun son propre au monde 1
  n'a été conçu. Reste ouvert (voir `SOUND_DESIGN_PROTOCOL.md` §3.1).

**Non vérifié** : le ressenti sur appareil réel (seul l'utilisateur peut le
faire), et la lisibilité visuelle des zones interdites dans le vrai jeu.
