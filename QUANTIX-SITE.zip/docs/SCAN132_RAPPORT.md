# Scan des 132 niveaux — rapport par monde

Mesurés : 128/132 · non mesurés (trop lourds ?) : [30, 114, 120, 132]

## Monde 1

- N1 Le premier trait · encre 128 · ref 86% · gagnants droits 148/14290 · ⚠ murs muets : [2]
- N2 Le pont · encre 234 · ref 47% · gagnants droits 64/17880 · ⚠ murs muets : [1]
- N3 Le colimaçon · encre 204 · ref 54% · gagnants droits 28/3718 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [0]
- N4 Le relais · encre 420 · ref 53% · gagnants droits 0/3735
- N5 Le demi-tour · encre 214 · ref 75% · gagnants droits 74/11238
- N6 Les collines · encre 193 · ref 77% · gagnants droits 1/2964 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [1]
- N7 Économie · encre 188 · ref 85% · gagnants droits 16/16330
- N8 La portée · encre 246 · ref 89% · gagnants droits 6/17880 · ⚠ murs muets : [0]
- N9 Le détour · encre 355 · ref 77% · gagnants droits 15/5161
- N10 Le plafond · encre 113 · ref 62% · gagnants droits 5/9938 · ⚠ murs muets : [0]
- N11 Le relais · encre 258 · ref 87% · gagnants droits 1/15914 · ⚠ murs muets : [0]
- N12 La cellule · encre 90 · ref 50% · gagnants droits 13/11972 · ⚠ la référence gagne sans la mécanique (contournement)

## Monde 2

- N13 Le trampoline · encre 155 · ref 39% · gagnants droits 462/16330
- N14 Le ricochet · encre 577 · ref 38% · gagnants droits 27/19048
- N15 La montée · encre 432 · ref 37% · gagnants droits 16/19048
- N16 La hauteur juste · encre 220 · ref 52% · gagnants droits 178/14672
- N17 Sol brûlant · encre 220 · ref 39% · gagnants droits 132/17880 · ⚠ murs muets : [0]
- N18 Ta plaque · encre 227 · ref 77% · gagnants droits 14/32170 · ⚠ la référence gagne sans la mécanique (contournement)
- N19 Le four · encre 640 · ref –% · gagnants droits 67/20464 · ⚠ pas de référence ; murs muets : [0]
- N20 Le tremplin · encre 297 · ref 95% · gagnants droits 72/35378 · ⚠ référence = 95% de l'encre (très serré)
- N21 Le grand retour · encre 273 · ref 74% · gagnants droits 32/14944
- N22 Double rebond · encre 313 · ref 78% · gagnants droits 5/19048
- N23 L’élan d’abord · encre 284 · ref 81% · gagnants droits 25/33338 · ⚠ murs muets : [0]
- N24 La fonte · encre 143 · ref 77% · gagnants droits 34/20935 · ⚠ murs muets : [2]

## Monde 3

- N25 Le tapis · encre 102 · ref 75% · gagnants droits 0/11972
- N26 Sens inverse · encre 300 · ref 64% · gagnants droits 161/11308
- N27 Tapis et butée · encre 300 · ref 63% · gagnants droits 169/19048
- N28 Le plafond bas · encre 210 · ref 70% · gagnants droits 90/8128 · ⚠ murs muets : [2]
- N29 Ton élan · encre 514 · ref 53% · gagnants droits 0/57144
- N31 Tapis et lames · encre 320 · ref 61% · gagnants droits 0/25355 · ⚠ murs muets : [0, 1]
- N32 Deux tapis · encre 300 · ref 85% · gagnants droits 1/22457 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [0]
- N33 Chaîne montante · encre 272 · ref 90% · gagnants droits 26/51708 · ⚠ la référence gagne sans la mécanique (contournement)
- N34 Relais d’élan · encre 420 · ref 87% · gagnants droits 0/57144 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [0]
- N35 Le tri des tapis · encre 309 · ref 89% · gagnants droits 0/54808 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [0, 1, 2, 3, 4]
- N36 La chaîne complète · encre 203 · ref 77% · gagnants droits 0/31154 · ⚠ la référence gagne sans la mécanique (contournement)

## Monde 4

- N37 Le lac · encre 160 · ref 74% · gagnants droits 25/16330 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [3]
- N38 Trop vite · encre 118 · ref 77% · gagnants droits 13/11319 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [2]
- N39 Le saut · encre 111 · ref 77% · gagnants droits 10/14290
- N40 Le demi‑tour · encre 355 · ref 77% · gagnants droits 4/19048 · ⚠ la référence gagne sans la mécanique (contournement)
- N41 La combe gelée · encre 120 · ref 50% · gagnants droits 64/2859 · ⚠ murs muets : [0, 1]
- N42 La piste glacée · encre 220 · ref 59% · gagnants droits 268/17880 · ⚠ la référence gagne sans la mécanique (contournement)
- N43 Deux étages · encre 229 · ref 55% · gagnants droits 47/13411 · ⚠ la référence gagne sans la mécanique (contournement)
- N44 La patinoire · encre 153 · ref 77% · gagnants droits 0/16330 · ⚠ la référence gagne sans la mécanique (contournement)
- N45 Le passage gardé · encre 74 · ref 66% · gagnants droits 5/5734 · ⚠ murs muets : [2]
- N46 Verglas · encre 120 · ref 46% · gagnants droits 188/3124 · ⚠ lignes droites gagnantes fréquentes (6.0%) ; réussite au hasard 6% ; murs muets : [0]
- N47 La crevasse double · encre 330 · ref 77% · gagnants droits 0/11767 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [5]
- N48 Le pendule de glace · encre 160 · ref 37% · gagnants droits 895/16330 · ⚠ la référence gagne sans la mécanique (contournement) ; lignes droites gagnantes fréquentes (5.5%) ; réussite au hasard 5%

## Monde 5

- N49 Le souffle · encre 232 · ref 77% · gagnants droits 41/17880
- N50 Vent de face · encre 265 · ref 77% · gagnants droits 28/19048 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [1]
- N51 Vent descendant · encre 169 · ref 77% · gagnants droits 54/16330
- N52 Colonne étroite · encre 330 · ref 90% · gagnants droits 0/10768 · ⚠ murs muets : [0]
- N53 Deux colonnes · encre 700 · ref –% · gagnants droits 16/19048 · ⚠ pas de référence
- N54 La cascade inversée · encre 120 · ref 42% · gagnants droits 24/14290
- N55 Vent et lame · encre 660 · ref –% · gagnants droits 20/19048 · ⚠ pas de référence ; murs muets : [0]
- N56 Contre-courant · encre 700 · ref –% · gagnants droits 75/19048 · ⚠ pas de référence
- N57 La rafale · encre 700 · ref –% · gagnants droits 9/15192 · ⚠ pas de référence
- N58 Le tunnel · encre 720 · ref –% · gagnants droits 62/19048 · ⚠ pas de référence
- N59 La tempête · encre 240 · ref 83% · gagnants droits 0/10775 · ⚠ murs muets : [1]
- N60 Le cyclone · encre 120 · ref 21% · gagnants droits 470/14290 · ⚠ référence = 21% de l'encre (encre très généreuse)

## Monde 6

- N61 Le piston · encre 660 · ref –% · gagnants droits 271/16997 · ⚠ pas de référence
- N62 La navette · encre 660 · ref –% · gagnants droits 140/19048 · ⚠ pas de référence
- N63 Piston bas · encre 640 · ref –% · gagnants droits 534/15111 · ⚠ pas de référence
- N64 Deux pistons · encre 740 · ref –% · gagnants droits 200/19048 · ⚠ pas de référence
- N65 Le pendule · encre 120 · ref 83% · gagnants droits 17/1819 · ⚠ murs muets : [0]
- N66 L’escalier mécanique · encre 200 · ref 44% · gagnants droits 257/17880 · ⚠ murs muets : [0]
- N67 Métronome · encre 700 · ref –% · gagnants droits 252/11612 · ⚠ pas de référence
- N68 L’engrenage · encre 160 · ref 34% · gagnants droits 3/9615 · ⚠ murs muets : [0, 1, 4]
- N69 Cadence double · encre 740 · ref –% · gagnants droits 30/19048 · ⚠ pas de référence ; murs muets : [0]
- N70 L’horloge · encre 120 · ref 38% · gagnants droits 241/8552 · ⚠ murs muets : [0]
- N71 Atelier mobile · encre 120 · ref 46% · gagnants droits 42/11497 · ⚠ murs muets : [0, 1, 4]
- N72 L’échappement · encre 300 · ref 87% · gagnants droits 0/19048 · ⚠ la référence gagne sans la mécanique (contournement) ; murs muets : [0]

## Monde 7

- N73 Tomber vers le haut · encre 178 · ref 77% · gagnants droits 49/16330
- N74 Gravité lourde · encre 155 · ref 77% · gagnants droits 36/16330
- N75 Le manège inversé · encre 300 · ref 77% · gagnants droits 0/19048 · ⚠ murs muets : [0]
- N76 Le champ de travers · encre 132 · ref 77% · gagnants droits 0/12490
- N77 Le saut lunaire · encre 64 · ref 94% · gagnants droits 58/9284 · ⚠ murs muets : [1]
- N78 La fronde · encre 160 · ref 50% · gagnants droits 377/16330 · ⚠ la référence gagne sans la mécanique (contournement)
- N79 Le plafond · encre 200 · ref 90% · gagnants droits 54/17880 · ⚠ murs muets : [2]
- N80 Le jet · encre 80 · ref 88% · gagnants droits 146/11972 · ⚠ murs muets : [0, 2, 4, 5]
- N81 La frontière · encre 80 · ref 68% · gagnants droits 156/11972 · ⚠ référence hors noyau ; murs muets : [0]
- N82 La plume · encre 130 · ref 91% · gagnants droits 0/14290 · ⚠ référence hors noyau ; murs muets : [0, 1, 2, 3, 5, 6]
- N83 Le miroir · encre 70 · ref 50% · gagnants droits 81/9284 · ⚠ référence hors noyau ; murs muets : [0]
- N84 Relativité · encre 270 · ref 84% · gagnants droits 7/19048

## Monde 8

- N85 La lentille · encre 160 · ref 88% · gagnants droits 127/4224
- N86 La feuille d’or · encre 120 · ref 42% · gagnants droits 72/1387 · ⚠ lignes droites gagnantes fréquentes (5.2%) ; réussite au hasard 5%
- N87 La dérive · encre 260 · ref 73% · gagnants droits 319/5461 · ⚠ lignes droites gagnantes fréquentes (5.8%) ; réussite au hasard 6%
- N88 Le dipôle · encre 200 · ref 50% · gagnants droits 60/1447 · ⚠ référence hors noyau ; murs muets : [2]
- N89 Le ricochet · encre 90 · ref 82% · gagnants droits 120/10327
- N90 Le canon de Gauss · encre 200 · ref 21% · gagnants droits 622/13121 · ⚠ référence = 21% de l'encre (encre très généreuse) ; murs muets : [0]
- N91 Le cyclotron · encre 120 · ref 50% · gagnants droits 355/10318
- N92 Le coussin · encre 80 · ref 88% · gagnants droits 11/11972 · ⚠ murs muets : [0, 1, 2, 5]
- N93 Orbite · encre 120 · ref 67% · gagnants droits 143/13116 · ⚠ murs muets : [1]
- N94 L’accélérateur · encre 80 · ref 66% · gagnants droits 52/6322 · ⚠ murs muets : [0, 1, 5]
- N95 La capture · encre 120 · ref 42% · gagnants droits 164/13196 · ⚠ murs muets : [1]
- N96 Le spectromètre · encre 200 · ref 35% · gagnants droits 60/17880 · ⚠ murs muets : [0, 2, 4, 5]

## Monde 9

- N97 Le portail · encre 120 · ref 28% · gagnants droits 218/12528 · ⚠ référence hors noyau ; murs muets : [1, 2, 4]
- N98 À travers le mur · encre 200 · ref 75% · gagnants droits 206/6959 · ⚠ murs muets : [0, 1]
- N99 Le geyser · encre 160 · ref 63% · gagnants droits 293/7396 · ⚠ murs muets : [0]
- N100 Portail et mur · encre 300 · ref 50% · gagnants droits 59/4660
- N101 Le bord du monde · encre 110 · ref 91% · gagnants droits 105/6062 · ⚠ référence hors noyau ; murs muets : [0, 1, 2, 6]
- N102 L’élan transmis · encre 120 · ref 39% · gagnants droits 169/14290
- N103 La sarbacane · encre 200 · ref 15% · gagnants droits 56/3262 · ⚠ référence = 15% de l'encre (encre très généreuse) ; murs muets : [0, 2, 4]
- N104 Le trou de serrure · encre 110 · ref 91% · gagnants droits 27/12539 · ⚠ murs muets : [0, 1, 2, 3, 4]
- N105 Aller-retour · encre 110 · ref 91% · gagnants droits 99/5100 · ⚠ murs muets : [0, 1, 8]
- N106 La couture · encre 160 · ref 63% · gagnants droits 9/1197 · ⚠ murs muets : [0, 2, 3, 4]
- N107 Le pli · encre 110 · ref 91% · gagnants droits 91/5100 · ⚠ référence hors noyau ; murs muets : [0, 1, 3, 6]
- N108 L’univers torique · encre 160 · ref 50% · gagnants droits 173/16330

## Monde 10

- N109 Corde tendue · encre 220 · ref 64% · gagnants droits 0/1754 · ⚠ murs muets : [0, 1, 3]
- N110 Le hamac · encre 820 · ref –% · gagnants droits 67/30950 · ⚠ pas de référence ; murs muets : [0]
- N111 Corde et plaque · encre 160 · ref 88% · gagnants droits 0/2798 · ⚠ murs muets : [0, 1, 3]
- N112 La balle molle · encre 300 · ref 43% · gagnants droits 39/19048
- N113 Molle et mince · encre 640 · ref 17% · gagnants droits 201/19048 · ⚠ référence = 17% de l'encre (encre très généreuse) ; murs muets : [2]
- N115 Molle et lame · encre 400 · ref 56% · gagnants droits 0/19048 · ⚠ murs muets : [4]
- N116 Deux cordes · encre 320 · ref 85% · gagnants droits 0/3714 · ⚠ murs muets : [0, 1, 2, 4]
- N117 Le filet · encre 720 · ref –% · gagnants droits 99/30566 · ⚠ pas de référence ; murs muets : [0]
- N118 Corde et colonne · encre 820 · ref –% · gagnants droits 193/38096 · ⚠ pas de référence ; murs muets : [0]
- N119 Opus · encre 880 · ref –% · gagnants droits 288/57144 · ⚠ pas de référence ; murs muets : [0, 2]

## Monde 11

- N121 Le lien · encre 660 · ref 24% · gagnants droits 24/19048 · ⚠ référence = 24% de l'encre (encre très généreuse) ; la référence gagne sans la mécanique (contournement)
- N122 Opposition · encre 300 · ref 13% · gagnants droits 258/10418 · ⚠ référence = 13% de l'encre (encre très généreuse) ; la référence gagne sans la mécanique (contournement) ; murs muets : [3]
- N123 Deux possibles · encre 120 · ref 58% · gagnants droits 112/907 · ⚠ lignes droites gagnantes fréquentes (12.3%) ; réussite au hasard 12% ; murs muets : [0, 1, 2]
- N124 La mesure · encre 120 · ref 38% · gagnants droits 187/238 · ⚠ référence hors noyau ; lignes droites gagnantes fréquentes (78.6%) ; réussite au hasard 79% ; murs muets : [1, 3]
- N125 Le temps ralenti · encre 100 · ref 30% · gagnants droits 2/36 · ⚠ référence hors noyau ; la référence gagne sans la mécanique (contournement) ; lignes droites gagnantes fréquentes (5.6%) ; réussite au hasard 6% ; murs muets : [0, 1, 2, 3, 4, 5]
- N126 L’interféromètre · encre 120 · ref 33% · gagnants droits 824/4732 · ⚠ lignes droites gagnantes fréquentes (17.4%) ; réussite au hasard 17% ; murs muets : [0, 1, 7, 9, 10, 11, 13, 14, 15]
- N127 Intrication double · encre 120 · ref 83% · gagnants droits 139/8340 · ⚠ référence hors noyau ; la référence gagne sans la mécanique (contournement) ; murs muets : [0, 2, 3]
- N128 Mesure tardive · encre 120 · ref 83% · gagnants droits 55/7791 · ⚠ référence hors noyau ; murs muets : [0, 1]
- N129 Les jumeaux · encre 120 · ref 38% · gagnants droits 63/466 · ⚠ référence hors noyau ; lignes droites gagnantes fréquentes (13.5%) ; réussite au hasard 14% ; murs muets : [0, 1, 2, 3, 4]
- N130 Le choix · encre 120 · ref 83% · gagnants droits 70/6294 · ⚠ référence hors noyau ; la référence gagne sans la mécanique (contournement) ; murs muets : [0, 1, 2, 3, 4, 5, 6, 7]
- N131 Machine quantique · encre 120 · ref 84% · gagnants droits 93/2536 · ⚠ référence hors noyau ; murs muets : [0, 1, 3]

Niveaux avec signal : 99/128