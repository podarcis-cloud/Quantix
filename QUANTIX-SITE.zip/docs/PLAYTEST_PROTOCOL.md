# QUANTIX — protocole de test de niveau

*Distinct de la séquence technique du handbook §10 (syntaxe, assets,
non-régression). Ici, il s'agit de vérifier qu'un niveau fonctionne comme
**expérience**, pas seulement comme mécanisme. Les deux sont obligatoires
et ne se substituent pas l'une à l'autre.*

---

## Avant de commencer

Un niveau ne passe en test que si son `LEVEL_DESIGN_CANVAS.md` est déjà
rempli jusqu'à la section Robustesse — le test sert à vérifier les
hypothèses de la fiche, pas à en tenir lieu.

---

## Déroulé du test — dans l'ordre

1. **Solution principale** — le tracé prévu dans la fiche fonctionne-t-il
   exactement comme décrit ? Vérifier par simulation directe
   (`tools/load.js`), pas seulement en jouant une fois à la main.
2. **Solutions alternatives légitimes** — si la fiche en prévoit, les
   vérifier aussi. Si une solution non prévue apparaît en testant, décider :
   fait-elle partie de l'expérience voulue (plusieurs voies valables), ou
   est-ce un raccourci à fermer ?
3. **Recherche de contournement** — `node tools/bypass.js <monde>` puis, si
   le niveau reste douteux, `node tools/deep.js`. Un contournement trouvé
   invalide la porte C (Gameplay) de la fiche.
4. **Recherche de softlock** — le joueur peut-il placer un tracé qui laisse
   la balle immobile ou hors de portée de toute solution, sans qu'`Annuler`
   ou `Recommencer` suffisent à s'en sortir normalement ? Vérifié par
   simulation directe en testant des tracés délibérément mauvais, pas
   seulement le tracé gagnant. C'est exactement le type de défaut confirmé
   sur #114 « Molle et mince » — un niveau peut être « raisonnablement
   conçu » et pourtant structurellement bloqué (voir
   `WORLD_IDENTITY_FRAMEWORK.md`, monde 10).
5. **Vérification du budget d'encre** — le budget permet-il la solution
   prévue avec une marge raisonnable, sans permettre un raccourci de
   secours coûteux en matière mais qui contourne la mécanique ?
6. **Lecture du type de difficulté** — l'échec le plus probable
   correspond-il à un type identifiable (§5 du protocole maître :
   compréhension / timing / exécution / stratégie / anticipation) ? Si
   l'échec ressemble à un accident plutôt qu'à une leçon, retour en
   conception.
7. **Différenciation** — `node tools/redundancy.js <monde>` : le niveau
   fraîchement testé apparaît-il dans une paire suspecte avec un niveau
   déjà validé ? Si oui, statuer explicitement (voir
   `REDUNDANCY_ANALYSIS.md`).
8. **Son** — les événements sonores prévus dans la fiche se déclenchent-ils
   au bon moment ? Vérifiable par instrumentation (`BUS.on(...)` dans une
   session `node -e`, à défaut d'un appareil sous la main).

---

## Rapport de test — gabarit court

```markdown
### Test — Niveau #N <nom>, <date ou session>

- Solution principale : [succès / échec — si échec, à quelle étape]
- Alternatives testées : [liste, résultat de chacune]
- Contournement : [aucun trouvé / trouvé — description]
- Softlock : [aucun trouvé / trouvé — tracé qui le déclenche]
- Budget d'encre : [marge observée]
- Type de difficulté à l'échec probable : [catégorie]
- Redondance : [aucune paire / paire avec #M — décision prise]
- Son : [conforme / écart — description]
- Verdict : [validé / retour en conception — raison]
```

Un rapport par niveau testé, conservé dans l'historique de la session
(`docs/REPRISE.md` référence le dernier état, pas l'historique complet des
tests — les rapports individuels n'ont pas besoin d'être archivés
séparément sauf décision contraire).
