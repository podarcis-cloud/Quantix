# QUANTIX — audit de reprise, R29

*Fait à partir du dossier de passation reçu. Séquence de vérification du
handbook §10 exécutée avant, pendant et après chaque correctif — rien
ci-dessous n'est annoncé sans avoir été vérifié en le faisant tourner.*

---

## 1. Ce qui a été vérifié, et comment

| Vérification | Méthode | Résultat |
|---|---|---|
| Syntaxe des 4 sources | `node --check` | OK |
| Chargement moteur, chemins, assets orphelins | `tools/audit.js` | OK — 39 chemins, tous présents |
| Rendu, niveau de référence, 11 cartes | `tools/render.js` | OK |
| Gestionnaires de l'interface | `tools/strict.js` (réparé) | OK, 1 faux positif documenté |
| Résolvabilité des 132 niveaux | `tools/solver.js` (réparé) | 117/132 |
| Contournement des 132 niveaux | `tools/bypass.js` | 106/112 testés contournables |
| Recherche renforcée sur les résistants | `tools/deep.js` (réparé) | 15/16 tombent à la structure pure |
| Mécaniques quantiques, non-régression | `tools/qprobe.js` (réparé) | OK |
| Sauvegarde : écriture, schéma inconnu, JSON corrompu, quota plein | `tools/savetest.js` (réparé) | OK, 4/4 |
| Chaînage carte du monde, clés i18n orphelines | `tools/maptest.js` (réparé) | OK après correction d'une attente obsolète |
| Symétrie bilingue complète (pas seulement `data-t`) | simulation directe succès/échec FR et EN | OK après correctif |

Aucune de ces lignes n'était disponible telle quelle au début de cette
reprise : cinq des dix outils de vérification étaient cassés (§2).

---

## 2. Ce qui a été corrigé dans cette session

### 2.1 Outillage de vérification — cinq outils sur dix étaient morts

`solver.js`, `strict.js`, `qprobe.js`, `savetest.js`, `deep.js` référençaient
`testq.js`, `test6.js` ou `quantix-RNN.html` : des artefacts de l'ancien
build en fichier unique, jamais migrés vers `tools/load.js` lors du passage
au site statique. `maptest.js` référençait un `harness.js` qui n'a jamais
existé dans ce dossier. `scenetest.js` était cassé de la même façon et, de
plus, faisait doublon avec `render.js` — supprimé plutôt que réparé.

Chacun a été migré vers `require('./load.js')`, le harnais déjà utilisé avec
succès par `render.js` et `bypass.js`, puis **exécuté réellement** (pas
seulement vérifié en syntaxe) pour confirmer qu'il produit un résultat
exploitable. `strict.js` et `maptest.js` ont chacun révélé une attente
obsolète dans le test lui-même (un id de bouton disparu, un monde qui a
depuis reçu son illustration) — corrigées, pas les niveaux de faux positifs
ignorés.

**Conséquence directe :** la tâche n°1 de `TACHES.md` (rescénariser les
niveaux) dépend de `solver.js` pour confirmer qu'un niveau corrigé reste
résolvable. Cet outil était inutilisable avant cette session.

### 2.2 L'ampleur du problème de contournement était sous-mesurée

`BYPASS-RAPPORT.md` ne couvrait que les mondes 2 à 5 (41/45 contournables).
Le balayage complet des 132 niveaux donne **106 niveaux sur 112 testés
contournables (95 %)**, mondes 6 à 11 compris — jamais mesurés jusqu'ici,
**et surtout les 12 niveaux du monde 11 (quantique), tous contournables sans
exception**. `deep.js`, réparé, montre en plus que 15 des 16 niveaux les
plus résistants tombent à un simple toboggan de matière structure, sans
toucher à leur mécanique ni à une matière spéciale. Un seul niveau sur 132,
**#72 Le régulateur**, résiste à ce jour à toute tentative de contournement
mesurée.

C'est la découverte la plus importante de cet audit : le problème n'est pas
« beaucoup de niveaux sont contournables », documenté précédemment, mais
**la quasi-totalité du jeu, y compris son identité conceptuelle (le
quantique)**. Détail complet dans `BYPASS-RAPPORT.md`, réécrit.

### 2.3 Le bilingue n'était pas complet, malgré le ✅

`DICT.fr`/`DICT.en` sont parfaitement symétriques (104 clés chacun) et tous
les `data-t` de `index.html` étaient couverts — c'est ce qu'un test de
couverture des clés peut voir. Mais l'écran de résultat (titre de succès et
d'échec, sous-titre du critère de maîtrise, bouton suivant/recommencer),
Zen Lab, le titre de Quantum Drop, et les en-têtes Pause/Paramètres
écrivaient des chaînes françaises **en dur dans le code**, en cour-circuitant
`i18n.js` — alors que les clés anglaises correspondantes existaient déjà,
simplement jamais appelées. Un joueur en anglais voyait « Expérience
réussie » après chaque niveau gagné.

9 remplacements dans `engine.js`, 2 dans `index.html`, 2 clés ajoutées à
`i18n.js` (`retryLevel`, `failMastery` — la phrase du critère d'échec n'avait
pas d'équivalent existant). Vérifié en simulant un succès et un échec dans
les deux langues via le moteur réel, pas seulement l'absence d'erreur.

C'est le genre de dette que les tests de couverture de clés ne voient pas
par construction : ils vérifient que les clés existantes sont utilisées
quelque part, pas que tout le texte visible passe par une clé. À garder en
tête pour la suite — un `grep` périodique des chaînes entre guillemets
assignées à `.textContent`/`.innerHTML` dans `engine.js` détecterait la
récidive.

### 2.4 Documentation mise à jour en conséquence

`REPRISE.md`, `TACHES.md`, `BYPASS-RAPPORT.md` et `docs/HANDBOOK.md` (§11-12)
reflètent maintenant R29, le balayage complet, l'outillage réparé et le
correctif bilingue. Le tampon de version et le `console.log` de démarrage
étaient déjà à R29 dans le code reçu ; aucun document ne l'indiquait avant
cette session.

---

## 3. Ce qui reste ouvert — pas corrigé, à trancher

**`auWarn` est du code mort.** L'avertissement « le navigateur bloque
l'audio dans cet aperçu » existe dans `index.html`, `display:none`, texte
français sans `data-t`, et rien dans `engine.js` ne le rend jamais visible.
Non corrigé : l'activer correctement suppose de savoir sur quel état exact
d'`Audio1` se déclencher, et la règle 5 du protocole (instrumenter avant de
supposer) s'applique justement à l'audio en vue web intégrée — sujet où onze
tours ont déjà été perdus par le passé sur des hypothèses non vérifiées.

**La règle de palette ne correspond pas à la réalité du code.** Le
handbook §6 documente 11 jetons ; plus de 80 couleurs hexadécimales
distinctes vivent dans `quantix.css`, `engine.js` et `index.html`. Ce sont
très probablement des teintes et nuances du moodboard (dégradés, halos,
transparences), pas une dérive de charte — mais je n'ai pas le moodboard
sous la main pour vérifier couleur par couleur, et la règle telle qu'écrite
est actuellement invérifiable. Deux options : documenter la palette étendue
réelle (probablement la bonne réponse), ou auditer chaque couleur contre le
moodboard une à une.

**Les instructions de ce Projet Claude sont celles de l'ancien build.**
`docs/PROJET-PROMPT.md`, dans ce dossier, est à jour et correspond au canon
actuel (site statique). Ce qui est collé dans les instructions
personnalisées du Projet décrit encore `build/shell.html` et
`quantix-RXX.html`. Seul toi peux le recoller depuis l'interface Claude.

---

## 4. Feuille de route priorisée

1. **Rescénariser les niveaux** — inchangé en tête, mais la cible est
   maintenant mesurée précisément : 106 niveaux à corriger, pas 41.
   `BYPASS-RAPPORT.md` donne la méthode et l'ordre (monde par monde,
   `bypass.js` puis `solver.js` après chaque lot). #72 Le régulateur comme
   référence de ce à quoi ressemble un niveau qui résiste déjà — vaut la
   peine d'être étudié avant de rescénariser les autres, pour comprendre ce
   qui le rend différent.
2. Trancher `auWarn` et la palette étendue (§3) — rapide, mais bloque
   proprement la prochaine vérification audio et empêche la règle §6 de
   continuer à être fausse dans les faits.
3. Tutoriel gestuel, historique personnel, transitions — inchangé.
4. Vérification hors simulateur (Android, bureau, Safari mode silencieux).
5. Éditeur de niveaux et partage par lien.
6. Découpe gratuit/payant.

Les huit leviers d'engagement (`ENGAGEMENT-ET-MONETISATION.md`) s'insèrent
après le point 3, comme déjà acté — non rediscutés ici.

---

## 5. Ce qui manque pour un produit concurrentiel — au-delà de la liste existante

Ce qui suit reste dans les limites déjà actées : pas de vies, pas d'énergie,
pas de publicité déclenchée par l'échec, pas de serveur (canon : site
statique, chemins relatifs). Ce ne sont pas des ajouts à la liste
d'engagement existante — je ne rouvre pas ce qui est tranché — mais des
manques structurels que l'audit fait ressortir.

### 5.1 Le problème de fond n'est pas seulement les niveaux, c'est l'absence de contrat de conception

Rien dans le format d'un niveau (`docs/HANDBOOK.md` §3) n'encode *pourquoi*
la mécanique est nécessaire. `bypass.js` mesure la conséquence a posteriori ;
rien n'empêche d'en réintroduire en l'écrivant. Une piste concrète, dans le
prolongement direct de l'outillage qui existe déjà : ajouter un champ optionnel
`assert` au format de niveau — une trace ou une région que le solveur doit
*ne pas* pouvoir atteindre sans la mécanique — et faire tourner `bypass.js`
en CI (le dossier a déjà `.github/workflows/`) à chaque modification de
`assets/js/levels.js`, pas seulement à la demande. Ça transforme un audit
ponctuel en garde-fou permanent, dans l'esprit exact de la règle 4 du
protocole (« vérifier avant de livrer, jamais après »).

### 5.2 Le quantique est thématique, pas mécanique — c'est l'angle le plus différenciant du jeu, et il est inexploité

Aucun jeu de puzzle physique grand public n'a de vrai mécanisme
d'intrication ou de superposition comme condition de passage — la plupart
des jeux « quantiques » sont des habillages. `bypass.js` montre que Quantix,
tel quel, en est un aussi : les 12 niveaux du monde 11 se résolvent sans
toucher au quantique. C'est une occasion manquée plus qu'un défaut cosmétique
— c'est exactement l'endroit où ce jeu pourrait ne ressembler à aucun autre.
Concrètement, dans la rescénarisation du monde 11 : des configurations où
**seule** une trajectoire en superposition peut satisfaire deux contraintes
géométriquement incompatibles à la fois (un mur qui bloque un chemin classique
mais qu'une branche fantôme traverse avant effondrement), plutôt que des
niveaux où la mécanique quantique est une option parmi d'autres pour
atteindre la même zone. Le moteur (`QP`, `S.branch`, `S.collapsed`,
`S.ent`) le permet déjà — c'est un problème de conception de niveau, pas
un problème d'ingénierie.

### 5.3 Zéro test sur les contraintes qui définissent réellement l'expérience mobile

`docs/TACHES.md` liste « Android, navigateur de bureau, Safari en mode
silencieux » comme un point unique en fin de liste. Vu le passé du projet
sur l'audio (§5 de `REPRISE.md`, onze tours perdus), et vu que c'est un jeu
tactile en portrait, je le remonterais avant l'éditeur de niveaux et la
découpe gratuit/payant : livrer une monétisation sur une base non testée
hors simulateur est le genre de decision qui coûte cher à défaire.

### 5.4 Accessibilité daltonienne — non mentionnée nulle part dans la doc existante

Le jeu distingue ses matières et dangers par la couleur seule (`--danger`
rouge pour les piques, `--matter` cyan pour la structure, `--boost` violet
pour l'élan). Sur un daltonisme rouge-vert, la distinction piques/structure
sur certains fonds de monde peut devenir difficile. Une passe de forme ou de
motif (déjà présente dans l'atelier de particule pour la cosmétique — le
mécanisme existe, il suffit de l'étendre aux matières) réglerait ça sans
toucher à la palette.

---

## 6. Ce que je n'ai pas fait, et pourquoi

Je n'ai pas commencé la rescénarisation des niveaux elle-même : c'est un
travail de conception niveau par niveau, pas un correctif, et le protocole
(règle 2) demande un but par conversation. L'audit et la remise en état de
l'outillage qui la rend vérifiable étaient un préalable nécessaire — les
deux ne pouvaient pas être faits en même temps sans perdre en fiabilité sur
les deux.

Je n'ai pas touché à la palette de couleurs ni activé `auWarn` : les deux
demandent une décision ou une vérification que je ne peux pas prendre à ta
place depuis ici (le moodboard pour l'une, un appareil réel pour l'autre).

Je n'ai pas rouvert les huit leviers d'engagement ni la position sur la
monétisation : déjà tranchés, documentés, et cohérents avec la recherche
citée dans `ENGAGEMENT-ET-MONETISATION.md`.
