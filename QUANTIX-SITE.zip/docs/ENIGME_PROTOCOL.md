# QUANTIX — Protocole « énigme » (R74)

> **Statut R209 : référence (bibliothèque).** Voir `INDEX_DOCUMENTS.md`.


*Retour de Simon (test de la Chaîne) : « des obstacles absolument inutiles ; une ligne droite de la particule à la zone avec
l'accélérateur suffit ; chaque élément doit avoir une fonction précise et répondre à un scénario ; il doit être impossible
d'éviter par un raccourci la difficulté du niveau. » Puis : « une solution peut être un raccourci ou un sens de parcours
insoupçonné — il faut multiplier les types de résolution, que chaque niveau amène le joueur à changer de manière de penser. »*

## 1. Ce qui distingue une énigme d'un parcours

- **Une idée, une famille de solutions.** La famille est définie par ce que la solution utilise : les éléments que sa
  trajectoire touche ou les champs qu'elle traverse. Une solution qui n'utilise pas tout cela est un raccourci.
- **Chaque élément a un rôle**, écrit dans la fiche : il **porte** la solution, il **ferme** un raccourci nommé, ou il **tend**
  un piège. Retirer un élément doit changer le niveau ; sinon il est inutile et on le supprime.
- **L'idée peut être inattendue** (un sens de parcours insoupçonné, un détour) : ce n'est pas un raccourci si c'est l'idée
  voulue. Ce qui est interdit, c'est qu'une **autre** idée plus simple contourne la difficulté.
- **Chaque niveau change la manière de penser** : deux niveaux d'un même monde ne doivent pas se résoudre par le même type de
  raisonnement (voir §4).

## 2. Contrôle automatique (`tools/enigme.js`)

1. Idée = ensemble U des éléments touchés (contact ≈ 14,5 u du mur) et des champs traversés par la solution de référence.
   **U vide → « idée absente »** : la solution n'utilise rien du niveau.
2. Raccourcis **cherchés exprès** : lignes directes particule → zone (3 départs × 3 décalages × 3 arrivées × 3 hauteurs, dans
   chaque matière permise), puis 2 500 traits au hasard. Toute réussite qui n'utilise pas tout U est un raccourci.
3. Rôle de chaque élément hors U : le retirer doit **créer** des solutions qui n'existaient pas. Sinon : inutile.
4. Verdict « ÉNIGME ✓ » seulement si : idée présente, 0 raccourci, 0 élément inutile.

## 3. Audit des niveaux « refaits » (R74)

| Niveau | Verdict | Problème |
|---|---|---|
| 25 Le tapis | ✗ | 12 raccourcis — dont la ligne directe vers la zone |
| 26 Sens inverse | ✗ | le sol est inutile |
| 27 Tapis et butée | ✗ | 28 raccourcis |
| 28 Le plafond bas | ✗ | les pointes du plafond sont inutiles |
| 29 Ton élan | ✗ | 17 raccourcis (accélérateur direct) |
| 30 Saut de chaîne | ✗ | le tapis est inutile |
| 31 Tapis et lames | ✗ | la solution n'utilise aucun élément |
| 32–34 | ✗ | un tapis inutile chacun |
| 35, 36 | ✗ | la solution n'utilise aucun élément |
| **37 Le lac** | **✓** | — |
| 38 Trop vite | ✗ | 2 raccourcis ; pointes inutiles |
| 39, 40, 44, 45, 47, 50 | ✗ | pointes (ou mur) **redondantes** : le vide tuait déjà |
| 48 Le sérac | ✗ | 2 raccourcis |
| 49 Le souffle | ✗ | 2 raccourcis |
| **51 Vent descendant** | **✓** | — |

**Constat : 2 niveaux sur 22 sont de vraies énigmes.** Tout le monde 3 est à reconstruire, ce que Simon a constaté en jouant.
Pour plusieurs niveaux du Glacier, le défaut est mineur et réparable : des pointes posées là où le vide est déjà fatal
(décor, pas énigme) — à retirer, ou à placer là où elles ferment vraiment un chemin.

## 4. Les types de résolution — monde 3 (Chaîne : l'élan)

Chaque niveau du monde doit exiger un raisonnement **différent** :

| # | Type de raisonnement | Énigme (idée à trouver) |
|---|---|---|
| 1 | **Découvrir** | seul le tapis donne l'élan de monter : il faut y amener la particule |
| 2 | **Inverser le sens** | le tapis pousse vers les pointes ; la zone est derrière : prendre l'élan à rebours (rebondir et revenir) |
| 3 | **Doser** | le tapis lance trop fort : il faut l'y faire entrer moins vite, ou plus bas |
| 4 | **Relayer** | un tapis ne suffit pas, deux à la suite oui ; le trait relie les deux |
| 5 | **Fabriquer** | aucun tapis : le joueur trace le sien — mais l'énergie ne permet qu'un tapis court, au seul endroit utile |
| 6 | **Éviter** | le tapis visible est un piège (il mène aux pointes) : l'idée est de **ne pas** l'utiliser et de passer ailleurs |
| 7 | **Détour** | la zone est juste à côté mais inaccessible ; il faut faire le tour par le haut, le tapis donnant l'élan du détour |
| 8 | **Boucle** | la particule doit passer **deux fois** sur le même tapis (une boucle qu'on construit) |
| 9 | **Orienter** | le tapis tracé par le joueur pousse dans le sens du geste : le tracer à l'envers est la clé |
| 10 | **Économie** | l'accélérateur coûte cher : un seul tapis court ET un mur, à répartir |
| 11 | **Contre‑pied** | l'évidence (ligne directe) est fermée ; la solution part dans la direction opposée |
| 12 | **Synthèse** | deux idées du monde enchaînées |

## 5. Méthode de construction (mise à jour)

1. Choisir le type de raisonnement du niveau (§4), écrire l'idée et la liste des raccourcis qu'un joueur essaierait.
2. Poser les éléments un par un, **chacun avec son rôle écrit** (porter / fermer tel raccourci / piéger).
3. `fiche.js` (critères R61–R72) puis **`enigme.js`** : ÉNIGME ✓ obligatoire.
4. Regarder le niveau, puis **ton test** : le défi se comprend‑il, et as‑tu trouvé un autre chemin ?
