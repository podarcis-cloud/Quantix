# QUANTIX — Index des documents (R262)

*Quel document ouvrir selon la tâche. Ne jamais tout lire : ouvrir la section utile (`grep -n '^#' fichier`).*

## 1. Socle (ordre de priorité en cas de contradiction)

| Priorité | Document | Rôle | Quand le lire |
|---|---|---|---|
| 1 | Message de Simon dans la conversation | la demande du moment | toujours |
| 2 | Instructions du Projet (copie : `INSTRUCTIONS_PROJET.md`) | prompt maître, court | chargé d'office |
| 3 | `ETAT.md` | **source de vérité** : version, chantiers, décisions, liens | au début de chaque session |
| 4 | `REGLES.md` | exigences (A–J), méthode d'un lot (K), passation (L), économie (M) | avant de modifier code, niveau ou rendu |
| 5 | `TECHNIQUE.md` | fichiers, globaux, commandes, pièges, fin, Quantone | avant de toucher au code |
| — | `LEXIQUE.md` | nos mots | si un terme est flou |
| — | `A_VERIFIER.md` | liste à cocher par Simon | quand Simon envoie ses remarques ; à tenir à jour |
| — | `JOURNAL.md` | historique des lots | seulement pour retrouver un lot passé |

Une contradiction entre deux documents se **signale** à Simon avant toute modification risquée ; le document de priorité
plus haute l'emporte en attendant.

## 2. Références par sujet (ouvrir seulement si la tâche les touche)

| Sujet | Document |
|---|---|
| État des lieux complet, dettes, feuille de route, décisions D1–D10 | `AUDIT_R209.md` (daté : mesures à régénérer par `tools/scan132.js`) |
| Design d'énigmes, hypothèses du joueur, leurres | `BIBLE_ENIGMES.md`, `ENIGME_PROTOCOL.md` |
| Difficulté et faisabilité au doigt (P_exec, P_int) | `DIFFICULTY_PROTOCOL.md` |
| Fiches de niveaux | `MONDE1_FICHES.md`, `MONDE7_FICHES.md` |
| Monde 11 (moteur quantique) | `MONDE11_MOTEUR.md` |
| Murs, courbes, jonctions, lumière quantique | `CAHIER_DES_CHARGES_GENERATION.md` §17–§25, `ANNEXE_DESIGN_JONCTIONS.md` |
| Moteur, rendu, jetons de couleur (§6) | `HANDBOOK.md` |
| Identité visuelle et physique de chaque monde | `QUANTUM_VISUAL_NARRATIVE.md` |
| Ferrofluide du Magnétisme | `TEXTURE_MAGNETISME.md` |
| Pistes poreuses (effet tunnel) | `PISTES_TRAVERSABLES.md` |
| Didacticiel | `DIDACTICIEL_DESIGN.md` |
| Narration, héros, épilogue | `NARRATION.md` |
| Son des mondes | `SON_MONDES.md`, `SOUND_DESIGN_PROTOCOL.md` |
| Vibrations | `VIBRATIONS.md` |
| Éthique d'engagement, monétisation | `ENGAGEMENT-ET-MONETISATION.md` |
| Trace de la refonte documentaire R262 | `MATRICE_DOCUMENTS.md` |
| Inventaire, exigences à maintenir, nettoyage R264 | `NETTOYAGE.md` |
| Démarrage d'une session (erreurs à ne pas refaire) | `DEMARRAGE.md` |

*Les références « graphisme » et « niveaux » ci‑dessus seront fusionnées en `CHARTE_GRAPHIQUE.md` et `METHODE_NIVEAUX.md`
(`ETAT.md` §3 n° 11 et 12) ; d'ici là, ce sont les sources qui font foi.*

## 3. Archive (`docs/archive/` ; ne pas ouvrir sauf demande précise)

Anciens prompts (`PROJET-PROMPT*.md`, `CONSIGNES_SIMON.md`), anciennes reprises (`REPRISE-SESSION.md` jusqu'à R261,
`REPRISE.md`, `archive_REPRISE-SESSION-R121.md`), `CHARTE_EXIGENCES.md`, `METHODE.md`, `PASSATION_R232.md` et
`INDEX_DOCUMENTS.md` (fusionnés dans le socle), audits et mesures R29 → R190, anciens protocoles R30 → R97. Dans le
Projet seulement : `claude/FINALE_R213.md`, `claude/FINALE_FIL.md`, `claude/AUDIT_HEROS_FIN.md`,
`claude/FIN_DEUX_PLANS.md` (travail de la fin, validée R233), `redundancy.js`.
| + | `PARCOURS_BETA.md` | base des parcours joueurs (Aperçu, collection parcours_beta), schéma, import mail | calibrage encre/niveaux |
| + | `AUDIT_DONNEES.md` | audit : quelles données capter (court/moyen/long terme), architecture, lots L1–L3 | collecte, bêta |
