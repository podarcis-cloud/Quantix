# QUANTIX — liste de tâches

*Canon : le fichier unique. Replit écarté.*

Ordre établi par dépendance, pas par envie. Chaque tâche qui en débloque d'autres passe avant celles qui n'en débloquent aucune.

---

## FAIT

### ✅ 1. Sauvegarde locale — `quantix.save.v1`

Livré en R20. Conserve étoiles, records de matière, déblocage, dernière expérience vue, et les cinq réglages plus le choix du moteur audio. Écriture différée de 300 ms, jamais pendant une frame.

Testé : écriture et relecture, schéma inconnu rejeté, JSON corrompu toléré, quota plein toléré, stockage inaccessible toléré. Dans tous les cas d'échec le jeu continue sans sauvegarde au lieu de planter.

Un bouton **Effacer** à double confirmation dans les réglages.

---

## À FAIRE, DANS CET ORDRE

### 2. Bilingue FR/EN — *bloque tout le reste*

Chaque écran ajouté avant cette tâche devra être retraduit après. C'est la seule raison pour laquelle elle passe avant le tutoriel, qui a pourtant plus d'impact sur le premier contact.

Portée : environ 60 chaînes d'interface, 132 noms de niveaux, 132 conseils. Un dictionnaire `T.fr` / `T.en`, un sélecteur dans les réglages, la langue sauvegardée dans `quantix.save.v1` — le champ existe déjà.

*Acceptation* : aucune chaîne en dur hors du dictionnaire. Bascule sans recharger la page.

### 3. Vocabulaire Quantix

Se fait dans le même fichier que le point 2, donc juste après, jamais avant. « Matière » devient particule ou énergie selon le contexte, « bassin » devient zone, « noyau » garde son sens quantique.

*Acceptation* : relecture complète des 132 conseils au vocabulaire du brief.

### 4. Tutoriel gestuel

Le manque le plus coûteux en abandon. Rien n'indique au joueur qu'il faut **tracer**. Une main animée sur le niveau 1, qui disparaît au premier trait et ne revient jamais.

*Acceptation* : un joueur qui n'a jamais vu le jeu trace un mur sans qu'on lui explique.

### 5. Historique personnel par niveau

Le levier de rejouabilité le moins cher. À chaque réussite, garder les cinq dernières tentatives : matière, durée, reprises. Les afficher sur l'écran de résultat avec le record en évidence.

C'est le principe d'Opus Magnum, sans serveur : on se compare à soi.

*Acceptation* : l'écran de résultat montre si la tentative améliore le record, et de combien.

### 6. Transitions et états pressés

Ce qui sépare un prototype d'un produit. Fondu entre écrans, apparition des panneaux, pulsation sur la réussite, état pressé sur chaque gélule. Le moodboard les liste tous.

### 7. Vérification hors simulateur

Android, navigateur de bureau, et Safari avec le mode silencieux — cette dernière clôt définitivement la question audio.

*Acceptation* : images par seconde mesurées sur un téléphone d'entrée de gamme, pas estimées.

### 8. Éditeur de niveaux et partage par lien

Le multiplicateur de durée de vie des deux références du genre, et le seul moyen de dépasser 132 niveaux sans les écrire un par un. Un niveau partagé est aussi un canal d'acquisition gratuit.

Encodage du niveau en base64 dans l'URL, pas de serveur.

### 9. Passage en dossier

`index.html` plus un dossier d'assets. Lève la contrainte qui empêche d'héberger les sons séparément — peut-être la seule issue au problème audio — et permet le cache navigateur.

À faire après le point 7, qui dira si c'est nécessaire.

### 10. Décision commerciale

Deux mondes gratuits en navigateur, le reste vendu. Ou licence d'établissement. À trancher quand 2 à 8 sont faits, pas avant.

---

## Règles de méthode, issues des erreurs de cette session

1. Tout script de correction compte ses remplacements et le dit. Un remplacement silencieux qui échoue coûte trois tours.
2. Tout test exécute le code qu'il prétend couvrir. Un test de chargement qui s'arrête à l'accueil ne teste pas le rendu du jeu.
3. Toute publication porte un numéro neuf et un tampon visible à l'écran. Republier sous le même nom fait servir le cache.
4. Remonter l'erreur exacte avant de formuler une hypothèse. Chaque déblocage de cette session est venu d'un message d'erreur affiché, jamais d'un raisonnement à vide.
