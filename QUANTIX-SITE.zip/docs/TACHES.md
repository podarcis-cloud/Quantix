# QUANTIX — liste de tâches

*Canon : le site statique. Ordre établi par dépendance.*

## FAIT

- ✅ Sauvegarde locale `quantix.save.v1`
- ✅ Bilingue FR/EN complet — 132 noms, 132 conseils, 11 mondes, 42 éléments.
  Complété en R29 : l'écran de résultat, Zen Lab, Quantum Drop et les titres
  Pause/Paramètres écrivaient du français en dur, hors i18n.js. Corrigé et
  vérifié en simulant succès/échec dans les deux langues.
- ✅ Zen Lab et Quantum Drop
- ✅ Atelier de particule — motif et forme
- ✅ 11 illustrations de monde, cartes en constellation
- ✅ Architecture site statique, déployable GitHub Pages
- ✅ Décor flouté, grille effacée, tracé d'essai lisible
- ✅ 11 ambiances distinctes, volumes au curseur, atelier sonore caché
- ✅ Détecteur de contournement `tools/bypass.js`
- ✅ Outillage de vérification complet et fonctionnel — `solver.js`,
  `strict.js`, `qprobe.js`, `savetest.js`, `deep.js`, `maptest.js`
  réparés en R29 (restes de l'ancien build), `scenetest.js` supprimé
  (doublon cassé de `render.js`). Les dix outils de `tools/` s'exécutent
  tous réellement, pas seulement `node --check`.

## À FAIRE, DANS CET ORDRE

### 1. Rescénariser les niveaux — priorité absolue

97 niveaux sur 112 testés restent contournables (monde 2 fait : 0/10,
voir `BYPASS-RAPPORT.md`). Méthode : couloir étroit de non-tracé (`nd`)
autour du départ, fermé jusqu'à hauteur de la mécanique ; vérifier chaque
niveau par simulation directe en plus de `bypass.js`/`solver.js`, dont la
recherche heuristique ne retrouve pas toujours une solution qui existe bel
et bien (attendu, handbook §4). Prochain : monde 3 (élan), même méthode.

*Acceptation* : zéro niveau contournable sur les 132. Le nombre "prouvé
résolvable" par `solver.js` baissera mécaniquement à mesure que les niveaux
perdent leurs raccourcis — ce n'est pas un signal d'alerte en soi, voir
`BYPASS-RAPPORT.md`.

### 2. ~~Étendre la mesure aux mondes 1, 6 à 11~~ — fait en R29

Balayage complet des 132 niveaux effectué. Résultat : 106/112 testés
contournables, mondes 6 à 11 compris, quantique compris. Voir
`BYPASS-RAPPORT.md`. Ce point n'occupe plus de rang séparé : il fusionne
avec le point 1, dont la cible reste zéro niveau contournable sur les 132.

### 3. Tutoriel gestuel

Rien n'indique au joueur qu'il faut **tracer**. Une main animée sur le niveau 1,
qui disparaît au premier trait.

*Acceptation* : un joueur qui n'a jamais vu le jeu trace un mur sans explication.

### 4. Historique personnel par niveau

Cinq dernières tentatives : matière, durée, reprises. Affichées sur l'écran de
résultat avec le record en évidence. Le levier de rejouabilité le moins cher.

### 5. Transitions et états pressés

Fondu entre écrans, apparition des panneaux, pulsation sur la réussite.

### 6. Vérification hors simulateur

Android, navigateur de bureau, et **Safari en mode silencieux** — cette dernière
clôt la question audio.

### 7. Éditeur de niveaux et partage par lien

Encodage du niveau en base64 dans l'URL, pas de serveur.

### 8. Découpe gratuit/payant

Mondes 1 et 2 gratuits, déblocage unique pour les 108 autres.

## Règles de méthode

0. Recoller `docs/PROJET-PROMPT.md` dans les instructions personnalisées
   du Projet Claude — celles actuellement collées décrivent encore
   l'ancien build en fichier unique (R22).
1. Tout script de correction compte ses remplacements **et** on vérifie leur
   présence dans le fichier par `grep` avant de livrer.
2. Tout test exécute le code qu'il prétend couvrir.
3. Toute publication porte un numéro neuf et un tampon visible.
4. Remonter l'erreur exacte avant de formuler une hypothèse.
5. Vérifier qu'un identifiant est libre avant de l'introduire.
