# QUANTIX — analyse de redondance

*Ce document accompagne `tools/redundancy.js`. Il donne la méthode, le
résultat mesuré à ce jour, et comment lire ce résultat sans le
sur-interpréter.*

---

## Méthode

Pour chaque niveau, l'outil calcule une signature purement géométrique et
mécanique :

- l'ensemble des mécaniques présentes (matières spéciales des murs,
  champs de vent/gravité/aimant, portails, mobiles, quantique, corps mou,
  corde) ;
- l'angle et la distance départ → zone d'arrivée, dans le repère du monde
  de référence (360×480) ;
- le nombre de murs fixes (silhouette grossière du niveau) ;
- le budget d'encre rapporté à la distance à parcourir.

Deux niveaux dont l'ensemble de mécaniques diffère de plus de moitié ne
sont jamais comparés (`mechSim < 0.5` → non comparable, pas de score).
Pour les autres, un score pondéré (mécanique 35 %, angle 30 %, distance
15 %, silhouette 10 %, budget 10 %) donne la similarité. Seuil de
signalement : 0,78.

C'est une mesure de **forme**, pas de **ressenti**. Un score élevé ne
prouve pas qu'un niveau est inutile — il signale une paire à examiner à
la main contre le principe du protocole maître (§7) : *si deux niveaux
peuvent raisonnablement être résolus de manière identique, ils sont
suspects*. Le jugement final reste humain.

---

## Résultat mesuré (état R29, avant refonte)

```
node tools/redundancy.js          # par monde
node tools/redundancy.js --all    # tous mondes confondus
node tools/redundancy.js N        # un seul monde N
```

**334 paires suspectes au total, comparées monde par monde.** Répartition :

| Monde | Paires suspectes |
|---|---|
| 1 Atelier | 52 |
| 2 Fonderie | 27 |
| 3 Chaîne | 27 |
| 4 Glacier | 36 |
| 5 Soufflerie | 31 |
| 6 Mécanique | 22 |
| 7 Gravité | 43 |
| 8 Magnétisme | 38 |
| 9 Faille | 31 |
| 10 Filaments | 15 |
| 11 Quantique | 12 |

Aucun monde n'est épargné. Plusieurs paires atteignent un score de 1,00
exact — mécanique identique, angle identique, distance identique à moins
de 1 % près : par exemple #73 « Gravité faible » et #74 « Gravité lourde »,
ou #85 « L'aimant », #86 « Aimant fort » et #87 « Aimant haut », qui
forment un groupe de trois quasi indiscernables par cette mesure. Ce
résultat **confirme objectivement, avec un outil indépendant du jugement
subjectif**, le diagnostic de redondance qui motive la refonte complète.

Note de lecture : le monde 1 (Atelier, sans mécanique) a le score le plus
élevé — attendu, puisque sans mécanique la seule source de différenciation
possible est la géométrie pure, que cet outil mesure justement en
premier lieu (voir le risque déjà identifié dans
`WORLD_IDENTITY_FRAMEWORK.md`, monde 1).

---

## Comment utiliser ce résultat pendant la refonte

1. Avant de retravailler un niveau, lancer `node tools/redundancy.js <monde>`
   et repérer les paires qui l'impliquent.
2. Pour chaque paire signalée, décider explicitement (et noter dans la
   fiche du niveau, champ Différenciation) : différencier fortement l'un
   des deux, fusionner leurs concepts, en supprimer un, ou transformer
   complètement l'un des deux.
3. Après refonte d'un niveau, relancer l'outil sur son monde — un score
   qui reste élevé avec un niveau déjà retravaillé signale soit un travail
   insuffisant, soit que la paire était en réalité justifiée (deux
   niveaux proches par construction, par exemple un niveau d'introduction
   et son rappel immédiat) — à documenter explicitement dans ce dernier
   cas plutôt que de forcer une différence artificielle.

## Limites connues de l'outil

- Il ne voit pas les zones de non-tracé (`nd`) ni les murs de piégeage
  fins — deux niveaux à la silhouette proche peuvent avoir un `nd` très
  différent qui change complètement le geste demandé. L'outil sous-estime
  donc parfois la différenciation réelle.
- Il ne mesure pas le rythme ni la dramaturgie (§5 de
  `MASTER_LEVEL_DESIGN_PROTOCOL.md`) — deux niveaux à la géométrie proche
  peuvent raconter des choses très différentes si l'un enseigne et l'autre
  combine. C'est précisément ce que la fiche de conception doit trancher,
  pas l'outil.
- Un score sous le seuil ne garantit pas l'absence de redondance
  *ressentie* — deux niveaux géométriquement différents peuvent
  paraître identiques si le geste du joueur (grosso modo : « tracer une
  diagonale ») ne change jamais. L'outil est un filtre de première
  passe, pas un jugement final.

---

## v2 (R30) — le décor et l'espace traçable comptent

La v1 ne voyait ni les zones `nd` ni la forme des murs : elle jugeait
« identiques » un demi-tour, un relais à deux traits et un freinage, parce
que tous partent en haut à gauche et visent le bas. Sur le monde 1 refondu,
elle signalait encore 39 paires — presque toutes fausses.

La v2 ajoute deux masques sur une grille 12×16 (cases de 30 u) : **cases
traversées par les murs** et **cases où l'on peut tracer**, comparés par
Jaccard. Pondération : mécaniques 20 %, angle 15 %, distance 10 %, forme du
décor 25 %, espace traçable 20 %, nombre de murs 5 %, encre 5 %.

Résultat : monde 1 refondu → 0 paire (après mise en miroir d'Économie, qui
ressemblait vraiment au Demi-tour). Mondes non refondus : 2 à 22 paires —
l'outil reste sévère là où la redondance est réelle (magnétisme 22,
glace 17, gravité 15).
