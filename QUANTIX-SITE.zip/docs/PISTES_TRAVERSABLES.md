# QUANTIX — Pistes traversables : l'effet tunnel (proposition R129)

*Né du looping de la Chaîne 12. Une piste peut être solide pour une particule lente et transparente pour une particule
rapide. Dans le moteur : champ `pass` d'une courbe (seuil de vitesse perpendiculaire, en u/image) et `pz` (zone de la courbe
concernée). Tout ce qui suit est une proposition, à valider par Simon.*

## Le sens quantique

En mécanique quantique, une particule peut franchir une barrière qu'elle ne devrait pas pouvoir franchir : c'est l'**effet
tunnel** (microscope à effet tunnel, radioactivité alpha). La probabilité dépend de l'énergie de la particule et de
l'épaisseur de la barrière. Le jeu en garde l'intuition, sans le hasard : **une paroi de lumière « fine » laisse passer
une particule assez énergique, et retient celle qui la frôle.**

## Ce que ça ouvre comme énigmes

1. **Prendre de l'élan pour traverser** : le chemin évident bute sur une barrière ; il faut d'abord faire tomber ou accélérer
   la particule (tapis, plaque de rebond) pour qu'elle passe au travers.
2. **Ralentir pour être porté** : la même barrière sert de sol si l'on y arrive doucement (trait en pente douce) — et de porte
   si l'on y arrive vite. Un seul élément, deux rôles selon le geste du joueur.
3. **Croisements** : des pistes qui se croisent (loopings, huit, tresses) — impossibles en 2D jusqu'ici.
4. **Choix à l'aveugle** (monde Quantique) : une barrière dont le seuil n'est révélé qu'au premier passage (« mesure »).

## Intégration proposée

- **Matière visible** : « barrière tunnel » — filet de lumière en pointillés qui scintillent, plus pâle que la structure ;
  au passage d'une particule rapide, onde concentrique et bref voile (la barrière « s'ouvre »). Rien d'invisible.
- **Didacticiel** : une fiche « Effet tunnel » (même gabarit que les autres) la première fois qu'elle apparaît.
- **Éditeur** : option « traversable » sur une courbe ou un mur (avec le seuil : doux 3, fort 5).
- **Progression** : apparition discrète en finale de la Chaîne (looping), puis un niveau par monde à partir de la Soufflerie,
  et un vrai rôle d'énigme dans le monde Quantique (11), où elle rejoint la superposition et la mesure.
- **Joueur** : peut-on tracer soi-même une barrière tunnel ? À décider (coût d'encre plus élevé, comme la plaque de rebond).

## À faire si validé
Rendu propre de la matière (visuals.js), fiche de didacticiel (tuto.js + i18n fr/en), option de l'éditeur, champ `pass` sur
les murs `w` (aujourd'hui seulement sur les courbes), son du passage.
