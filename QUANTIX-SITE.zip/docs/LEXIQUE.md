# QUANTIX — Lexique commun (R209, 15 octobre 2026)

*Les mots de Simon et de Claude pour parler du projet, et les mots que voit le joueur. Trois colonnes : ce qu'on dit entre
nous (atelier), ce qui est affiché dans le jeu (interface FR / EN), et le nom dans le code. Quand un mot d'atelier diffère
du mot du jeu, c'est voulu : l'atelier parle de construction, le jeu parle au joueur.*

**Règle** : dans les textes visibles, toujours le mot de la colonne « Jeu ». Une nouvelle notion s'ajoute ici avant
d'apparaître dans `i18n.js`.

---

## 1. Le jeu et ses objets

| Atelier (Simon ↔ Claude) | Jeu (FR / EN) | Code | Définition |
|---|---|---|---|
| la **particule** (anciennement « la bille », « la balle ») | particule / particle | `S.ball`, `R` = 10,5 | l'objet que le joueur guide ; jamais touchée directement |
| la **compagne**, la **jumelle** | — (aucun mot visible) | `comp()` dans `hero.js` | la seconde particule de la paire intriquée (épilogue) ; aspect de la branche de superposition |
| le **bassin** | **zone** / zone | `lv.cup` | l'arrivée ; « bassin » reste le mot d'atelier, le jeu dit « zone » (décision R23) |
| le **noyau** | noyau / core | `lv.star` | l'objet facultatif qui donne une étoile ; sens narratif proposé : fragment de l'état commun |
| le **trait**, la **ligne** | trait / line | `S.strokes` | ce que le joueur trace ; devient un mur |
| l'**encre** | **énergie** / energy | `S.ink`, `S.inkMax`, `COST` | la ressource de tracé ; le jeu dit « énergie » (décision R23) ; ⚠ le bilan dit encore « matière » (à corriger) |
| la **matière** (d'un trait) | puce / chip : structure, rebond, élan, corde | `S.tool`, `mat` 0/1/3/5 | le type de trait : structure (×1), rebond (×1,9), élan (×1,7), corde (×1,4) |
| **lâcher** | Lâcher / Release | `bPlay`, `ball.launch` | libérer la particule |
| la **reprise**, **revenir dans le temps** | Bifurquer / Branch off | `rScrub`, `S.reprises` | remonter la frise et reprendre de là |
| la **frise** | frise / timeline | `scrub` | la ligne du temps de la tentative |
| les **étoiles** | étoiles / stars | `S.best[i]` (0–3) | objectif + noyau + maîtrise (sans reprise) |
| la **maîtrise** | Maîtrise / Mastery | critère 3 | réussir sans reprise |
| la **solution optimale** | Géodésique / Geodesic | `optsol`, `optmat` | la solution de référence, montrée sur demande |
| **revoir ma partie** | Trajectoire / Trajectory | `rReplay` | relecture de la tentative |
| **recommencer** | État initial / Initial state | `pRestart` | remettre le niveau à zéro |
| **continuer** (après échec long) | Poursuivre / Continue | `rContinue` | +20 s de vol |

## 2. Les lieux et la structure

| Atelier | Jeu | Code | Définition |
|---|---|---|---|
| un **niveau** | une **expérience** / experiment | `LEVELS[i]` (132) | une énigme ; le jeu dit « expérience » |
| un **monde** | monde (avec son nom) / world | `lv.wd` 1–11 ; `WORLDS` | 12 niveaux ; Atelier, Fonderie, Chaîne, Glacier, Soufflerie, Mécanique, Gravité, Magnétisme, Faille, Filaments, Quantique |
| la **machine**, les « **montagnes russes** » | — | niveaux 6 et 12 | séquence spectaculaire faite des éléments du monde |
| la **constellation** | Constellation | `vLevels`, `openMap` | la carte des 11 mondes |
| la **page du monde** | (nom du monde) | `openWorld` | illustration + 12 niveaux |
| l'**accueil** | — | `#home` | héros + Continuer + menus |
| le **héros**, « **L'odyssée** » | — | `QHERO.frame` (`hero.js`) | animation d'accueil : la particule traverse les 11 mondes |
| l'**épilogue**, la **fin**, « **Les retrouvailles** » | — (titre QUANTIX) | `QHERO.epilogue`, `#finCv`, `finCine` | scène de fin : poursuite de retour à deux, trou noir, sphère |
| le **vortex**, le **trou noir**, l'**horizon** | — | `vortexQ` | disque d'accrétion du héros et de l'épilogue ; lieu de naissance de la paire |
| la **sphère**, la **danse** | — | `epDance` | la sphère créée par la réunion ; quatre figures |
| le **bilan** | — (tuiles) | `#vResult`, `resAnim` | l'écran de résultat d'un niveau ; bilan final = `jfinal` |
| le **plein cadre** | — | bloc R194, `pfLayout` | la mise en page de l'écran de jeu |
| la **Visière** | — | blocs R186–R191 | le langage des panneaux (verre sombre, coins, ligne de lumière) |
| la **fiche** (holographique) | — | `#tcard`, `tuto.js` | une carte du didacticiel |
| le **codex**, les **explications** | Explications / How things work | `vCodex` | toutes les fiches vues |

## 3. Les éléments physiques

| Atelier | Jeu | Code |
|---|---|---|
| zone interdite, **zone du vide** | Zone interdite / Forbidden zone | `lv.nd` (visible) ; `lv.mz` (invisible, interdit par la charte) |
| pointes | Pointes / Spikes | matière 2 |
| paroi rebond, plaque | Paroi rebond / Bounce wall | matière 1 |
| tapis d'élan | Tapis d'élan / Boost belt | matière 3 |
| glace | Glace / Ice | matière 4 |
| corde, corde élastique | Corde / Rope | matière 5, `lv.elastic`, `ropeIter` |
| matière poreuse, paroi tunnel, **piste traversable** | Matière poreuse / Porous matter | `curves` `pass`, `pz` |
| vent, colonne d'air, tempête | Vent / Wind | `lv.wind`, `lv.updraft` |
| gravité locale, zones « Relativité » | Gravité locale / Local gravity | `lv.grav` |
| planète, puits | — | `lv.well` |
| aimant (attracteur), répulseur | Aimant / Magnet | `lv.mag` (force négative = répulseur) |
| champ magnétique, cyclotron, fente accélératrice | — | `lv.bf`, `lv.kick` |
| bobine (canon de Gauss) | — | `lv.coil` |
| portail, faille, couture (univers torique) | Portail / Portal | `lv.port`, `lv.wrap` |
| paroi mobile, ascenseur, navette, bac | Paroi mobile / Moving wall | `lv.mov` (`grip`, `ph`) |
| pendule (actif = marteau) | — | `lv.pend` |
| corps mou, balle molle | Corps mou / Soft body | `QP.soft`, `softball` |
| fronde, diapason, harpe | — | `lv.sling`, `lv.fork`, `lv.strings` |
| intrication, qubit, porte | Intrication / Entanglement | `lv.ent`, `lv.gate` |
| superposition, branche, séparateur | Superposition | `lv.sup`, `S.branch` |
| détecteur, mesure | Détecteur / Detector | `lv.det` |
| dilatation du temps | Dilatation du temps / Time dilation | `lv.tdil` |
| poussière d'étoile (indice de machine) | — | `lv.flow`, `VX.flow` |

## 4. Les outils du joueur

| Atelier | Jeu | Code |
|---|---|---|
| trait libre, main levée | Trait libre / Freehand | outil 0 |
| ligne droite | Ligne droite / Straight line | `editor.js` |
| gomme | Gomme / Eraser | `editor.js` |
| déplacer et pivoter | Déplacer et pivoter / Move and rotate | `editor.js` |
| échelle | Échelle / Scale | mode `scale` |
| aimant (accroche des extrémités) | Aimant / Snap | `QX_mag` |
| loupe | Loupe de tracé / Drawing magnifier | `OPT.loupe` |

## 5. Les outils de l'atelier (jamais montrés au joueur)

| Mot | Ce que c'est |
|---|---|
| **MENU édition** | page qui rassemble tous les outils, fichiers et la méthode (artefact) |
| **aperçu** | version jouable publiée en artefact, ouverte sur ce qu'il faut juger |
| **éditeur de niveaux** | artefact où Simon dessine (documents `Q-MM-PP`) |
| **banc des rendus** | artefact où l'on valide un rendu avant de l'intégrer |
| **Quantone** | instrument de dessin sonore (6 instruments) |
| **W1N** | moteur de musique « bruitiste organique » du monde 1 (`sound.js`) |
| **MFX** | fonctions mathématiques de la musique (`sound.js`) |
| **tampon** (`build R###`) | numéro de version visible ; une livraison = un tampon neuf |
| **lot** | une unité de travail (un monde ou une fonction) |
| **correctif compté** | modification par remplacement exact vérifié (OK / ÉCHEC) |
| **trait « nu »** | trait gagnant qui ne touche aucun élément (raccourci) |
| **contournable** | niveau gagnable sans sa mécanique (`bypass.js`) |
| **P_exec / P_int** | probabilités de réussite au modèle de tracé (exécution / intention) |
| **solution de référence** | `optsol` du niveau |
| **scratchpad** | dossier de travail temporaire de la session (perdu à la fin) |
| **R###** | numéro de révision ; R209 = cet audit |

## 6. Mots à éviter dans le jeu

| Éviter | Préférer | Pourquoi |
|---|---|---|
| balle, bille | particule | thème |
| bassin | zone | décision R23 |
| matière (pour la ressource) | énergie | décision R23 ; « matière » est le type de trait |
| niveau | expérience | thème |
| Félicitations, Bravo | (rien : l'animation dit l'issue) | règle « peu de texte », refus du kitsch |
| Game over, perdu, échec (en titre) | (animation de l'issue) | vocabulaire non punitif |
