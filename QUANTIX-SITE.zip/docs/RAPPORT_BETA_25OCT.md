# Rapport parcours joueurs

Sources : export serveur · 4 joueur(s), 18 session(s), 499 essai(s), 10560 événements

## 1. Joueurs et sessions
- sessions par joueur : médiane 4.0 · max 9
- durée active par session : médiane 137 s, max 4588 s (17 sessions mesurées)
- retour : 16 reprises mesurées, délai médian 0.0 h ; retour ≥ 20 h : 0
- pays : {'BE': 4}
- versions : {'R295': 12, 'R291': 2, 'R292': 1, 'R294': 1, 'R302': 2}

## 2. Progression et décrochage
- niveaux terminés par joueur : moyenne 37.2, médiane 31.0, max 87 ; plus haut niveau terminé : médiane 45.0
- **dernier niveau vu (où le joueur s'est arrêté)** : {0: 1, 3: 1, 55: 1, 87: 1}

| niv | nom | joueurs | terminé | échecs/essai | 1er essai réussi | essais médian | abandons |
|--|--|--|--|--|--|--|--|
| 1 | Le premier trait | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 2 | Le pont | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 3 | Le colimaçon | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 4 | Le relais | 1 | 100 % | 2/3 | 0 % | 3 | 0 |
| 5 | Le demi-tour | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 6 | Les collines | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 7 | Économie | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 8 | La portée | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 9 | Le détour | 1 | 100 % | 0/1 | 100 % | 1 | 0 |
| 10 | Le plafond | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 11 | Le relais | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 12 | La cellule | 1 | 100 % | 3/5 | 0 % | 5 | 1 |
| 13 | Le trampoline | 2 | 100 % | 4/6 | 0 % | 3.0 | 0 |
| 14 | Le ricochet | 2 | 100 % | 4/6 | 0 % | 3.0 | 0 |
| 15 | La montée | 2 | 100 % | 4/8 | 0 % | 4.0 | 2 |
| 16 | La hauteur juste | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 17 | Sol brûlant | 1 | 100 % | 2/5 | 0 % | 3 | 1 |
| 18 | Ta plaque | 1 | 100 % | 9/10 | 0 % | 10 | 0 |
| 19 | Le four | 1 | 100 % | 3/4 | 0 % | 4 | 0 |
| 20 | Le tremplin | 1 | 100 % | 6/7 | 0 % | 7 | 0 |
| 21 | Le grand retour | 2 | 100 % | 29/32 | 0 % | 16.0 | 1 |
| 22 | Double rebond | 2 | 100 % | 28/30 | 0 % | 15.0 | 0 |
| 23 | L’élan d’abord | 2 | 100 % | 4/6 | 0 % | 3.0 | 0 |
| 24 | La fonte | 2 | 100 % | 17/21 | 50 % | 7.5 | 1 |
| 25 | Le tapis | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 26 | Sens inverse | 2 | 100 % | 1/4 | 50 % | 1.5 | 0 |
| 27 | Trois couleurs | 2 | 100 % | 0/3 | 100 % | 1.0 | 0 |
| 28 | La chute est un él | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 29 | Le sas | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 30 | Le second souffle | 2 | 100 % | 4/7 | 50 % | 3.0 | 0 |
| 31 | Le courant | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 32 | Rendre l’élan | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 33 | L’escalier lent | 2 | 100 % | 4/6 | 0 % | 3.0 | 0 |
| 34 | L’îlot lent | 2 | 100 % | 2/6 | 0 % | 3.0 | 2 |
| 35 | Après ton passage | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 36 | La grande chaîne | 2 | 100 % | 2/4 | 50 % | 2.0 | 0 |
| 37 | Le lac | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 38 | Trop vite | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 39 | Le saut | 2 | 100 % | 2/4 | 0 % | 2.0 | 0 |
| 40 | Le demi‑tour | 2 | 100 % | 4/7 | 0 % | 3.5 | 1 |
| 41 | La combe gelée | 2 | 100 % | 1/4 | 50 % | 2.0 | 1 |
| 42 | La piste glacée | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 43 | Deux étages | 2 | 100 % | 1/4 | 0 % | 2.0 | 1 |
| 44 | La patinoire | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 45 | Le passage gardé | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 46 | Verglas | 2 | 100 % | 3/5 | 50 % | 2.5 | 0 |
| 47 | La crevasse double | 2 | 100 % | 3/5 | 0 % | 2.5 | 0 |
| 48 | Le pendule de glac | 2 | 100 % | 1/4 | 0 % | 2.0 | 1 |
| 49 | Le souffle | 2 | 100 % | 3/7 | 0 % | 2.5 | 1 |
| 50 | La couche | 2 | 100 % | 1/5 | 50 % | 1.5 | 0 |
| 51 | L’ascenseur | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 52 | Ramer | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 53 | Deux colonnes | 2 | 100 % | 30/36 | 0 % | 10.5 | 3 |
| 54 | La cascade inversé | 2 | 100 % | 0/3 | 50 % | 1.5 | 1 |
| 55 | Vent et lame | 2 | 100 % | 6/8 | 0 % | 4.0 | 0 |
| 56 | Contre-courant | 2 | 100 % | 5/8 | 50 % | 3.0 | 0 |
| 57 | Le carrefour | 2 | 100 % | 11/14 | 50 % | 6.0 | 0 |
| 58 | Le tunnel | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 59 | La tempête | 2 | 100 % | 2/4 | 50 % | 2.0 | 0 |
| 60 | Le cyclone | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 61 | Le piston | 2 | 100 % | 4/7 | 50 % | 2.0 | 0 |
| 62 | La navette | 2 | 100 % | 1/5 | 100 % | 1.0 | 0 |
| 63 | Piston bas | 2 | 100 % | 2/6 | 50 % | 2.0 | 0 |
| 64 | Deux pistons | 2 | 100 % | 7/9 | 50 % | 4.5 | 0 |
| 65 | Le pendule | 2 | 100 % | 7/9 | 0 % | 4.5 | 0 |
| 66 | L’escalier mécaniq | 2 | 100 % | 0/2 | 100 % | 1.0 | 0 |
| 67 | Métronome | 2 | 100 % | 1/6 | 50 % | 2.0 | 1 |
| 68 | L’engrenage | 2 | 100 % | 5/7 | 50 % | 3.5 | 0 |
| 69 | Cadence double | 2 | 100 % | 2/4 | 50 % | 2.0 | 0 |
| 70 | L’horloge | 2 | 100 % | 1/5 | 100 % | 1.0 | 0 |
| 71 | Atelier mobile | 2 | 100 % | 4/7 | 50 % | 2.5 | 0 |
| 72 | L’échappement | 2 | 100 % | 0/3 | 50 % | 1.5 | 1 |
| 73 | Tomber vers le hau | 2 | 100 % | 2/4 | 50 % | 2.0 | 0 |
| 74 | Gravité lourde | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 75 | Le manège inversé | 2 | 100 % | 1/3 | 50 % | 1.5 | 0 |
| 76 | Le champ de traver | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 77 | Le saut lunaire | 1 | 100 % | 0/1 | 100 % | 1 | 0 |
| 78 | La fronde | 1 | 100 % | 0/1 | 100 % | 1 | 0 |
| 79 | Le plafond | 1 | 100 % | 3/4 | 0 % | 4 | 0 |
| 80 | Le jet | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 81 | La frontière | 1 | 100 % | 0/1 | 100 % | 1 | 0 |
| 82 | La plume | 1 | 100 % | 1/3 | 0 % | 3 | 1 |
| 83 | Le miroir | 1 | 100 % | 13/16 | 0 % | 16 | 2 |
| 84 | Relativité | 1 | 100 % | 14/17 | 0 % | 15 | 1 |
| 85 | La lentille | 1 | 100 % | 1/2 | 0 % | 2 | 0 |
| 86 | La feuille d’or | 1 | 100 % | 3/4 | 0 % | 4 | 0 |
| 87 | La dérive | 1 | 100 % | 3/5 | 0 % | 5 | 1 |
| 132 | Quantix | 1 | 100 % | 0/1 | 100 % | 1 | 0 |

## 3. Qualité des niveaux (signaux)
- **N3 Le colimaçon** ⚠ n=2 (indicatif) : lecture longue (préparation médiane 73 s)
- **N4 Le relais** ⚠ n=1 (indicatif) : encre généreuse (45 % de l'encre utilisée en médiane)
- **N5 Le demi-tour** ⚠ n=1 (indicatif) : lecture longue (préparation médiane 60 s)
- **N7 Économie** ⚠ n=1 (indicatif) : encre très serrée (96 %) ; lecture longue (préparation médiane 111 s)
- **N9 Le détour** ⚠ n=1 (indicatif) : lecture longue (préparation médiane 120 s)
- **N11 Le relais** ⚠ n=1 (indicatif) : encre généreuse (37 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/1) : contournement ? référence non optimale ?
- **N12 La cellule** ⚠ n=1 (indicatif) : échecs récurrents : {'stuck': 3}
- **N13 Le trampoline** ⚠ n=2 (indicatif) : réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 4}
- **N14 Le ricochet** ⚠ n=2 (indicatif) : encre généreuse (22 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 4}
- **N15 La montée** ⚠ n=2 (indicatif) : encre généreuse (20 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 4}
- **N17 Sol brûlant** ⚠ n=1 (indicatif) : encre généreuse (20 % de l'encre utilisée en médiane) ; réussite avec encre << référence (2/2) : contournement ? référence non optimale ?
- **N18 Ta plaque** ⚠ n=1 (indicatif) : encre généreuse (37 % de l'encre utilisée en médiane) ; difficile : 10 essais médians avant réussite ; échecs récurrents : {'out': 5, 'stuck': 4}
- **N19 Le four** ⚠ n=1 (indicatif) : encre généreuse (17 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 3}
- **N20 Le tremplin** ⚠ n=1 (indicatif) : encre généreuse (44 % de l'encre utilisée en médiane) ; difficile : 7 essais médians avant réussite ; échecs récurrents : {'out': 6}
- **N21 Le grand retour** ⚠ n=2 (indicatif) : difficile : 16.0 essais médians avant réussite ; échecs récurrents : {'out': 29}
- **N22 Double rebond** ⚠ n=2 (indicatif) : encre généreuse (41 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; difficile : 15.0 essais médians avant réussite ; échecs récurrents : {'out': 28}
- **N23 L’élan d’abord** ⚠ n=2 (indicatif) : échecs récurrents : {'out': 3, 'long': 1}
- **N24 La fonte** ⚠ n=2 (indicatif) : réussite avec encre << référence (1/3) : contournement ? référence non optimale ? ; difficile : 7.5 essais médians avant réussite ; échecs récurrents : {'long': 2, 'out': 15}
- **N26 Sens inverse** ⚠ n=2 (indicatif) : encre généreuse (15 % de l'encre utilisée en médiane) ; réussite avec encre << référence (3/3) : contournement ? référence non optimale ?
- **N27 Trois couleurs** ⚠ n=2 (indicatif) : encre généreuse (13 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/3) : contournement ? référence non optimale ?
- **N28 La chute est un élan** ⚠ n=2 (indicatif) : encre généreuse (38 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ?
- **N29 Le sas** ⚠ n=2 (indicatif) : encre généreuse (45 % de l'encre utilisée en médiane)
- **N30 Le second souffle** ⚠ n=2 (indicatif) : encre généreuse (35 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 3, 'stuck': 1}
- **N32 Rendre l’élan** ⚠ n=2 (indicatif) : encre généreuse (23 % de l'encre utilisée en médiane)
- **N33 L’escalier lent** ⚠ n=2 (indicatif) : échecs récurrents : {'out': 4}
- **N34 L’îlot lent** ⚠ n=2 (indicatif) : encre généreuse (44 % de l'encre utilisée en médiane)
- **N40 Le demi‑tour** ⚠ n=2 (indicatif) : encre généreuse (39 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 3, 'stuck': 1}
- **N41 La combe gelée** ⚠ n=2 (indicatif) : encre très serrée (100 %)
- **N42 La piste glacée** ⚠ n=2 (indicatif) : encre généreuse (18 % de l'encre utilisée en médiane) ; réussite avec encre << référence (2/2) : contournement ? référence non optimale ?
- **N43 Deux étages** ⚠ n=2 (indicatif) : encre généreuse (22 % de l'encre utilisée en médiane) ; réussite avec encre << référence (2/2) : contournement ? référence non optimale ?
- **N45 Le passage gardé** ⚠ n=1 (indicatif) : encre très serrée (100 %)
- **N46 Verglas** ⚠ n=2 (indicatif) : réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'stuck': 3}
- **N47 La crevasse double** ⚠ n=2 (indicatif) : échecs récurrents : {'out': 2, 'stuck': 1}
- **N49 Le souffle** ⚠ n=2 (indicatif) : échecs récurrents : {'out': 3}
- **N52 Ramer** ⚠ n=2 (indicatif) : encre généreuse (37 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ?
- **N53 Deux colonnes** ⚠ n=2 (indicatif) : encre généreuse (30 % de l'encre utilisée en médiane) ; difficile : 10.5 essais médians avant réussite ; échecs récurrents : {'out': 30}
- **N55 Vent et lame** ⚠ n=2 (indicatif) : encre généreuse (26 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 6}
- **N56 Contre-courant** ⚠ n=2 (indicatif) : encre généreuse (27 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 5}
- **N57 Le carrefour** ⚠ n=2 (indicatif) : encre généreuse (34 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/3) : contournement ? référence non optimale ? ; difficile : 6.0 essais médians avant réussite ; échecs récurrents : {'spike': 1, 'out': 10}
- **N58 Le tunnel** ⚠ n=2 (indicatif) : encre généreuse (44 % de l'encre utilisée en médiane)
- **N60 Le cyclone** ⚠ n=2 (indicatif) : encre généreuse (37 % de l'encre utilisée en médiane)
- **N61 Le piston** ⚠ n=2 (indicatif) : encre généreuse (8 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 3, 'stuck': 1}
- **N62 La navette** ⚠ n=2 (indicatif) : encre généreuse (16 % de l'encre utilisée en médiane)
- **N63 Piston bas** ⚠ n=2 (indicatif) : encre généreuse (25 % de l'encre utilisée en médiane)
- **N64 Deux pistons** ⚠ n=2 (indicatif) : encre généreuse (6 % de l'encre utilisée en médiane) ; échecs récurrents : {'out': 7}
- **N65 Le pendule** ⚠ n=2 (indicatif) : réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 4, 'spike': 3}
- **N66 L’escalier mécanique** ⚠ n=2 (indicatif) : encre généreuse (21 % de l'encre utilisée en médiane) ; réussite avec encre << référence (2/2) : contournement ? référence non optimale ?
- **N67 Métronome** ⚠ n=2 (indicatif) : encre généreuse (12 % de l'encre utilisée en médiane)
- **N68 L’engrenage** ⚠ n=2 (indicatif) : encre généreuse (33 % de l'encre utilisée en médiane) ; échecs récurrents : {'spike': 5}
- **N69 Cadence double** ⚠ n=2 (indicatif) : encre généreuse (9 % de l'encre utilisée en médiane)
- **N71 Atelier mobile** ⚠ n=2 (indicatif) : encre généreuse (0 % de l'encre utilisée en médiane) ; réussite avec encre << référence (2/3) : contournement ? référence non optimale ? ; échecs récurrents : {'spike': 4}
- **N76 Le champ de travers** ⚠ n=1 (indicatif) : encre très serrée (100 %)
- **N77 Le saut lunaire** ⚠ n=1 (indicatif) : encre très serrée (100 %)
- **N78 La fronde** ⚠ n=1 (indicatif) : encre généreuse (22 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/1) : contournement ? référence non optimale ?
- **N79 Le plafond** ⚠ n=1 (indicatif) : encre généreuse (42 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/1) : contournement ? référence non optimale ? ; échecs récurrents : {'spike': 2, 'out': 1}
- **N82 La plume** ⚠ n=1 (indicatif) : encre très serrée (96 %)
- **N83 Le miroir** ⚠ n=1 (indicatif) : difficile : 16 essais médians avant réussite ; échecs récurrents : {'out': 13}
- **N84 Relativité** ⚠ n=1 (indicatif) : encre généreuse (42 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/2) : contournement ? référence non optimale ? ; difficile : 15 essais médians avant réussite ; échecs récurrents : {'stuck': 14}
- **N85 La lentille** ⚠ n=1 (indicatif) : encre généreuse (28 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/1) : contournement ? référence non optimale ?
- **N86 La feuille d’or** ⚠ n=1 (indicatif) : encre généreuse (28 % de l'encre utilisée en médiane) ; échecs récurrents : {'stuck': 1, 'out': 2}
- **N87 La dérive** ⚠ n=1 (indicatif) : encre généreuse (21 % de l'encre utilisée en médiane) ; réussite avec encre << référence (1/1) : contournement ? référence non optimale ? ; échecs récurrents : {'out': 3}
- **N132 Quantix** ⚠ n=1 (indicatif) : encre généreuse (18 % de l'encre utilisée en médiane)

## 4. Où la particule sort (échecs « out »)
- N13 : 4 sorties ; zones (case 60 px, x,y) : (300,180)×2, (300,420)×2
- N14 : 4 sorties ; zones (case 60 px, x,y) : (300,240)×2, (300,420)×2
- N15 : 4 sorties ; zones (case 60 px, x,y) : (180,420)×2, (240,420)×1, (300,420)×1
- N18 : 5 sorties ; zones (case 60 px, x,y) : (60,420)×3, (0,420)×2
- N19 : 3 sorties ; zones (case 60 px, x,y) : (300,120)×2, (300,360)×1
- N20 : 6 sorties ; zones (case 60 px, x,y) : (0,420)×3, (0,300)×1, (0,180)×1
- N21 : 29 sorties ; zones (case 60 px, x,y) : (300,420)×11, (300,240)×4, (60,420)×2
- N22 : 28 sorties ; zones (case 60 px, x,y) : (0,420)×6, (300,420)×5, (240,420)×3
- N23 : 3 sorties ; zones (case 60 px, x,y) : (60,420)×1, (0,420)×1, (120,420)×1
- N24 : 15 sorties ; zones (case 60 px, x,y) : (0,420)×7, (300,420)×5, (300,240)×1
- N30 : 3 sorties ; zones (case 60 px, x,y) : (0,420)×2, (120,420)×1
- N33 : 4 sorties ; zones (case 60 px, x,y) : (0,420)×3, (60,420)×1
- N40 : 3 sorties ; zones (case 60 px, x,y) : (180,420)×1, (300,420)×1, (120,420)×1
- N49 : 3 sorties ; zones (case 60 px, x,y) : (0,420)×1, (300,420)×1, (300,240)×1
- N53 : 30 sorties ; zones (case 60 px, x,y) : (300,420)×13, (240,420)×5, (60,420)×5
- N55 : 6 sorties ; zones (case 60 px, x,y) : (180,420)×3, (120,420)×3
- N56 : 5 sorties ; zones (case 60 px, x,y) : (300,420)×3, (180,420)×2
- N57 : 10 sorties ; zones (case 60 px, x,y) : (300,420)×5, (60,420)×2, (180,420)×2
- N61 : 3 sorties ; zones (case 60 px, x,y) : (0,420)×1, (120,420)×1, (60,420)×1
- N64 : 7 sorties ; zones (case 60 px, x,y) : (120,420)×3, (300,420)×2, (300,360)×2
- N65 : 4 sorties ; zones (case 60 px, x,y) : (0,0)×1, (0,420)×1, (0,300)×1
- N83 : 13 sorties ; zones (case 60 px, x,y) : (0,180)×5, (0,120)×2, (0,240)×2
- N87 : 3 sorties ; zones (case 60 px, x,y) : (60,420)×2, (300,420)×1

## 5. Logique de résolution (familles de solutions réussies)
- N1 : 2 trait(s) mat[0] départ(60,240) ↘ ×1 ; 1 trait(s) mat[0] départ(60,180) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,180) ↘) : 1/2
- N2 : 2 trait(s) mat[0] départ(120,120) → ×2 · proche de la référence (1 trait(s) mat[0] départ(120,180) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2}
- N3 : 1 trait(s) mat[0] départ(0,0) ↘ ×1 ; 1 trait(s) mat[0] départ(0,0) → ×1 · proche de la référence (1 trait(s) mat[0] départ(0,0) ↘) : 1/2 · outils avant réussite {'mov': 1, 'und': 1}
- N4 : 2 trait(s) mat[0] départ(0,120) ↘ ×1 · outils avant réussite {'mov': 1}
- N5 : 2 trait(s) mat[0] départ(240,120) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(180,240) ↗) : 0/1 · outils avant réussite {'del': 1, 'und': 2, 'mov': 2, 'scl': 1}
- N6 : 1 trait(s) mat[0] départ(240,60) ← ×1 ; 1 trait(s) mat[0] départ(120,60) → ×1 · proche de la référence (1 trait(s) mat[0] départ(240,0) ←) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 1, 'mov': 1}
- N7 : 1 trait(s) mat[0] départ(0,240) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,240) ↘) : 1/1 · outils avant réussite {'mov': 3, 'scl': 3, 'del': 2}
- N8 : 2 trait(s) mat[0] départ(300,240) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(360,360) ↙) : 0/1 · outils avant réussite {'del': 1, 'mov': 2}
- N9 : 1 trait(s) mat[0] départ(0,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(0,120) →) : 1/1 · outils avant réussite {'del': 1, 'mov': 1}
- N10 : 1 trait(s) mat[0] départ(120,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(180,120) →) : 0/1 · outils avant réussite {'del': 1, 'mov': 5}
- N11 : 1 trait(s) mat[0] départ(120,300) ↘ ×1 · proche de la référence (2 trait(s) mat[0] départ(180,180) ↙) : 0/1 · outils avant réussite {'del': 1}
- N12 : 1 trait(s) mat[0] départ(240,300) ↓ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,300) ↓) : 1/1 · outils avant réussite {'mov': 10, 'scl': 2}
- N13 : 1 trait(s) mat[0] départ(0,300) ↘ ×1 ; 3 trait(s) mat[0] départ(180,240) ↑ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,300) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3, 'del': 1}
- N14 : 2 trait(s) mat[0] départ(240,360) ↗ ×1 ; 2 trait(s) mat[0] départ(300,360) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(360,360) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3}
- N15 : 2 trait(s) mat[0] départ(0,120) ↙ ×1 ; 1 trait(s) mat[0] départ(0,120) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(120,120) ↙) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 1, 'mov': 1, 'del': 1}
- N16 : 2 trait(s) mat[0] départ(0,120) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,240) ↗) : 0/1 · outils avant réussite {'scl': 1, 'mov': 1}
- N17 : 1 trait(s) mat[0] départ(0,120) → ×1 ; 1 trait(s) mat[0] départ(0,120) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,180) ↗) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 4}
- N18 : 1 trait(s) mat[1] départ(0,300) → ×1 · proche de la référence (1 trait(s) mat[1] départ(0,300) →) : 1/1 · outils avant réussite {'mov': 1}
- N19 : 2 trait(s) mat[0] départ(0,60) ↘ ×1 · outils avant réussite {'mov': 2}
- N20 : 2 trait(s) mat[0, 1] départ(0,300) → ×1 · proche de la référence (1 trait(s) mat[1] départ(0,300) ↑) : 0/1 · outils avant réussite {'mov': 1}
- N21 : 3 trait(s) mat[0] départ(300,240) ↙ ×1 ; 4 trait(s) mat[0] départ(300,240) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(300,240) ↑) : 0/2 ⚠ aucune solution du type prévu
- N22 : 2 trait(s) mat[0] départ(0,180) ↘ ×1 ; 4 trait(s) mat[0] départ(0,180) ↘ ×1 · proche de la référence (2 trait(s) mat[0] départ(60,60) ↗) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2}
- N23 : 2 trait(s) mat[0, 1] départ(300,0) ↘ ×1 ; 2 trait(s) mat[0] départ(300,60) ↖ ×1 · proche de la référence (2 trait(s) mat[1] départ(120,120) ↙) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'und': 5, 'scl': 1, 'mov': 1}
- N24 : 1 trait(s) mat[0] départ(0,300) ↘ ×1 ; 2 trait(s) mat[0] départ(0,300) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,240) ↓) : 0/3 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 1, 'mov': 3}
- N25 : 2 trait(s) mat[0] départ(0,300) ↘ ×1 ; 1 trait(s) mat[0] départ(180,300) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(180,300) ↗) : 1/2 · outils avant réussite {'del': 3, 'mov': 2}
- N26 : 1 trait(s) mat[0] départ(300,240) ↙ ×1 ; 1 trait(s) mat[0] départ(300,180) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(180,300) ↗) : 0/3 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2}
- N27 : 1 trait(s) mat[0] départ(0,240) ↘ ×2 ; 2 trait(s) mat[0] départ(0,240) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,240) ↘) : 3/3
- N28 : 1 trait(s) mat[0] départ(0,240) ↘ ×1 ; 1 trait(s) mat[0] départ(0,180) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,240) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 1, 'mov': 1}
- N29 : 2 trait(s) mat[3] départ(0,240) ↗ ×1 ; 1 trait(s) mat[3] départ(60,240) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,180) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 2, 'mov': 3}
- N30 : 2 trait(s) mat[0] départ(120,300) ↓ ×1 ; 1 trait(s) mat[0] départ(120,300) ↓ ×1 · proche de la référence (1 trait(s) mat[3] départ(240,240) →) : 0/3 ⚠ aucune solution du type prévu · outils avant réussite {'del': 1, 'mov': 1, 'scl': 1}
- N31 : 1 trait(s) mat[3] départ(0,240) ↗ ×2 · proche de la référence (1 trait(s) mat[0] départ(120,180) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'del': 1, 'mov': 3}
- N32 : 3 trait(s) mat[0] départ(0,240) ↗ ×1 ; 3 trait(s) mat[0] départ(60,180) ↓ ×1 · proche de la référence (2 trait(s) mat[0] départ(0,180) ↘) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 1}
- N33 : 3 trait(s) mat[0, 3] départ(300,240) ↙ ×1 ; 1 trait(s) mat[3] départ(60,180) ← ×1 · proche de la référence (1 trait(s) mat[0] départ(240,120) ↑) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2}
- N34 : 1 trait(s) mat[3] départ(120,300) ↗ ×1 ; 3 trait(s) mat[0, 3] départ(120,300) ↗ ×1 · proche de la référence (2 trait(s) mat[3] départ(0,360) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 5, 'scl': 1}
- N35 : 1 trait(s) mat[3] départ(240,180) ← ×1 ; 1 trait(s) mat[3] départ(240,180) ↖ ×1 · proche de la référence (1 trait(s) mat[3] départ(180,360) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3}
- N36 : 1 trait(s) mat[3] départ(0,240) → ×1 ; 1 trait(s) mat[3] départ(60,240) ↗ ×1 · proche de la référence (1 trait(s) mat[3] départ(0,240) →) : 1/2 · outils avant réussite {'scl': 4, 'mov': 7}
- N37 : 2 trait(s) mat[0] départ(120,240) → ×1 ; 1 trait(s) mat[0] départ(120,240) → ×1 · proche de la référence (1 trait(s) mat[0] départ(120,240) →) : 2/2 · outils avant réussite {'mov': 2, 'scl': 2, 'del': 1}
- N38 : 2 trait(s) mat[0] départ(300,300) ↗ ×1 ; 1 trait(s) mat[0] départ(300,240) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,300) ↗) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 10, 'scl': 1}
- N39 : 2 trait(s) mat[0] départ(120,240) ↗ ×1 ; 1 trait(s) mat[0] départ(120,240) → ×1 · proche de la référence (1 trait(s) mat[0] départ(120,240) →) : 1/2 · outils avant réussite {'scl': 1}
- N40 : 2 trait(s) mat[0] départ(240,180) ↓ ×1 ; 3 trait(s) mat[0] départ(300,180) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(300,180) ↙) : 1/2 · outils avant réussite {'mov': 3, 'scl': 1}
- N41 : 1 trait(s) mat[0] départ(180,0) ← ×1 ; 1 trait(s) mat[0] départ(240,0) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(180,0) ↙) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 1}
- N42 : 1 trait(s) mat[0] départ(240,360) ↓ ×1 ; 1 trait(s) mat[0] départ(300,360) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(300,300) ↓) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'und': 1, 'mov': 1}
- N43 : 2 trait(s) mat[0] départ(0,120) ↘ ×1 ; 1 trait(s) mat[0] départ(180,180) → ×1 · proche de la référence (1 trait(s) mat[0] départ(300,240) ←) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 4, 'scl': 1}
- N44 : 3 trait(s) mat[0] départ(300,60) ↓ ×1 ; 3 trait(s) mat[0] départ(240,360) ↓ ×1 · proche de la référence (2 trait(s) mat[0] départ(300,60) ↓) : 1/2 · outils avant réussite {'scl': 2, 'mov': 2}
- N45 : 1 trait(s) mat[0] départ(60,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,180) →) : 0/1 · outils avant réussite {'und': 1, 'mov': 4}
- N46 : 1 trait(s) mat[0] départ(120,0) → ×1 ; 1 trait(s) mat[0] départ(180,60) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,0) ↘) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2, 'scl': 1}
- N47 : 3 trait(s) mat[0] départ(120,120) → ×1 ; 2 trait(s) mat[0] départ(120,120) → ×1 · proche de la référence (2 trait(s) mat[0] départ(120,120) →) : 2/2 · outils avant réussite {'mov': 5, 'scl': 2}
- N48 : 3 trait(s) mat[0] départ(300,120) ↓ ×1 ; 1 trait(s) mat[0] départ(300,120) ↖ ×1 · proche de la référence (1 trait(s) mat[0] départ(300,180) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 4}
- N49 : 2 trait(s) mat[0] départ(0,360) → ×2 ; 1 trait(s) mat[0] départ(0,360) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,300) ↘) : 0/3 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3}
- N50 : 1 trait(s) mat[0] départ(0,60) → ×2 ; 2 trait(s) mat[0] départ(60,180) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,60) →) : 2/4 · outils avant réussite {'mov': 10, 'scl': 6}
- N51 : 2 trait(s) mat[0] départ(0,60) → ×1 ; 2 trait(s) mat[0] départ(120,360) → ×1 · proche de la référence (1 trait(s) mat[0] départ(180,240) ↗) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 1, 'mov': 1}
- N52 : 1 trait(s) mat[0] départ(0,300) → ×1 ; 2 trait(s) mat[0] départ(0,240) ↘ ×1 · proche de la référence (1 trait(s) mat[3] départ(60,240) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2}
- N53 : 2 trait(s) mat[0] départ(0,60) → ×1 ; 5 trait(s) mat[0] départ(0,360) → ×1
- N54 : 1 trait(s) mat[0] départ(300,420) ↗ ×1 ; 3 trait(s) mat[0] départ(300,420) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(120,120) ↑) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 5}
- N55 : 3 trait(s) mat[0] départ(0,180) → ×1 ; 3 trait(s) mat[0] départ(0,120) → ×1 · outils avant réussite {'mov': 1}
- N56 : 1 trait(s) mat[0] départ(300,60) ↙ ×1 ; 1 trait(s) mat[0] départ(60,120) → ×1 · outils avant réussite {'mov': 1, 'scl': 1}
- N57 : 1 trait(s) mat[0] départ(0,60) → ×1 ; 1 trait(s) mat[0] départ(240,360) ↓ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,300) ↙) : 0/3 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 1}
- N58 : 3 trait(s) mat[0] départ(0,120) ↘ ×1 ; 3 trait(s) mat[0] départ(0,360) → ×1 · outils avant réussite {'mov': 2, 'und': 1}
- N59 : 1 trait(s) mat[0] départ(240,300) ↖ ×1 ; 1 trait(s) mat[0] départ(120,120) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,360) ↖) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 8, 'scl': 4}
- N60 : 1 trait(s) mat[0] départ(120,300) ↓ ×1 ; 1 trait(s) mat[0] départ(120,300) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(120,180) ↗) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3}
- N61 : 1 trait(s) mat[0] départ(0,120) ↘ ×1 ; 1 trait(s) mat[0] départ(60,120) ↖ ×1 · outils avant réussite {'und': 1, 'scl': 1, 'mov': 4}
- N62 : 4 trait(s) mat[0] départ(0,120) ↘ ×1 ; 2 trait(s) mat[0] départ(0,120) ↘ ×1 · outils avant réussite {'del': 2, 'mov': 6, 'scl': 2}
- N63 : 4 trait(s) mat[0] départ(0,180) ↘ ×1 ; 3 trait(s) mat[0] départ(0,180) ↘ ×1 · outils avant réussite {'del': 1, 'scl': 1, 'mov': 4}
- N64 : 1 trait(s) mat[0] départ(0,60) ↘ ×1 ; 1 trait(s) mat[0] départ(0,60) → ×1
- N65 : 2 trait(s) mat[0] départ(0,120) → ×1 ; 1 trait(s) mat[0] départ(0,180) → ×1 · proche de la référence (1 trait(s) mat[0] départ(0,120) ↘) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'del': 1}
- N66 : 1 trait(s) mat[0] départ(0,360) ↘ ×1 ; 1 trait(s) mat[0] départ(0,300) → ×1 · proche de la référence (1 trait(s) mat[0] départ(0,360) ↘) : 1/2 · outils avant réussite {'mov': 1}
- N67 : 2 trait(s) mat[0] départ(0,240) ↘ ×2 ; 2 trait(s) mat[0] départ(0,60) ↘ ×1 · outils avant réussite {'mov': 4}
- N68 : 1 trait(s) mat[0] départ(120,300) → ×1 ; 1 trait(s) mat[0] départ(60,300) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,300) →) : 1/2 · outils avant réussite {'scl': 2}
- N69 : 1 trait(s) mat[0] départ(0,60) ↘ ×1 ; 2 trait(s) mat[0] départ(0,180) ↘ ×1 · outils avant réussite {'mov': 1}
- N70 : 2 trait(s) mat[0] départ(300,240) ↙ ×2 ; 1 trait(s) mat[0] départ(300,240) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(120,240) ↓) : 0/4 ⚠ aucune solution du type prévu · outils avant réussite {'scl': 3, 'mov': 6}
- N71 : 2 trait(s) mat[0] départ(60,240) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,240) →) : 0/1
- N72 : 2 trait(s) mat[0] départ(60,420) → ×1 ; 1 trait(s) mat[0] départ(60,360) → ×1 · proche de la référence (1 trait(s) mat[0] départ(0,420) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 7}
- N73 : 1 trait(s) mat[0] départ(60,360) → ×1 ; 3 trait(s) mat[0] départ(60,360) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,300) →) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 2, 'und': 1}
- N74 : 2 trait(s) mat[0] départ(0,60) → ×1 ; 2 trait(s) mat[0] départ(180,360) → ×1 · proche de la référence (1 trait(s) mat[0] départ(120,180) ←) : 0/2 ⚠ aucune solution du type prévu · outils avant réussite {'mov': 3, 'scl': 1}
- N75 : 1 trait(s) mat[0] départ(0,60) → ×2 · proche de la référence (1 trait(s) mat[0] départ(0,60) →) : 2/2 · outils avant réussite {'mov': 1}
- N76 : 2 trait(s) mat[0] départ(180,240) → ×1 · proche de la référence (1 trait(s) mat[0] départ(300,240) ←) : 0/1 · outils avant réussite {'mov': 4, 'scl': 2}
- N77 : 1 trait(s) mat[0] départ(60,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,120) →) : 1/1 · outils avant réussite {'mov': 1}
- N78 : 1 trait(s) mat[0] départ(120,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,120) →) : 0/1
- N79 : 2 trait(s) mat[0] départ(120,120) → ×1 · proche de la référence (1 trait(s) mat[0] départ(60,180) →) : 0/1 · outils avant réussite {'mov': 5, 'del': 1, 'und': 1, 'scl': 1}
- N80 : 1 trait(s) mat[0] départ(120,120) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,60) →) : 0/1 · outils avant réussite {'scl': 1, 'mov': 3}
- N81 : 1 trait(s) mat[0] départ(0,180) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,240) →) : 0/1
- N82 : 2 trait(s) mat[0] départ(0,120) → ×1 · proche de la référence (2 trait(s) mat[0] départ(0,60) ↗) : 0/1 · outils avant réussite {'mov': 10, 'scl': 1}
- N83 : 3 trait(s) mat[0] départ(240,60) ↙ ×1 · proche de la référence (1 trait(s) mat[0] départ(240,360) ↙) : 0/1 · outils avant réussite {'mov': 1}
- N84 : 1 trait(s) mat[0] départ(300,420) ↑ ×1 ; 1 trait(s) mat[0] départ(300,420) ↗ ×1 · proche de la référence (1 trait(s) mat[0] départ(300,420) ↑) : 1/2 · outils avant réussite {'und': 1, 'scl': 1}
- N85 : 1 trait(s) mat[0] départ(60,180) ↑ ×1 · proche de la référence (1 trait(s) mat[0] départ(60,180) ↓) : 0/1 · outils avant réussite {'und': 1, 'scl': 1, 'mov': 6}
- N86 : 1 trait(s) mat[0] départ(0,60) ↓ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,60) →) : 0/1 · outils avant réussite {'mov': 1}
- N87 : 1 trait(s) mat[0] départ(0,180) ↘ ×1 · proche de la référence (1 trait(s) mat[0] départ(0,60) ↘) : 0/1 · outils avant réussite {'scl': 1, 'mov': 2}
- N132 : 1 trait(s) mat[0] départ(240,240) ↓ ×1 · proche de la référence (1 trait(s) mat[1] départ(240,240) ↘) : 0/1

- distance moyenne tracé final ↔ solution de référence (px, 0 = identique) : N1 : 8 px (n=2) ; N2 : 14 px (n=2) ; N3 : 13 px (n=2) ; N5 : 12 px (n=1) ; N6 : 2 px (n=2) ; N7 : 4 px (n=1) ; N8 : 30 px (n=1) ; N9 : 11 px (n=1) ; N10 : 16 px (n=1) ; N11 : 67 px (n=1) ; N12 : 2 px (n=1) ; N13 : 76 px (n=2) ; N14 : 33 px (n=2) ; N15 : 40 px (n=2) ; N16 : 93 px (n=1) ; N17 : 33 px (n=2) ; N18 : 11 px (n=1) ; N20 : 51 px (n=1) ; N21 : 25 px (n=2) ; N22 : 54 px (n=2) ; N23 : 20 px (n=2) ; N24 : 21 px (n=3) ; N25 : 6 px (n=2) ; N26 : 47 px (n=3) ; N27 : 28 px (n=3) ; N28 : 18 px (n=2) ; N29 : 94 px (n=2) ; N30 : 91 px (n=3) ; N31 : 110 px (n=2) ; N32 : 30 px (n=2) ; N33 : 110 px (n=2) ; N34 : 101 px (n=2) ; N35 : 190 px (n=2) ; N36 : 14 px (n=2) ; N37 : 5 px (n=2) ; N38 : 11 px (n=2) ; N39 : 12 px (n=2) ; N40 : 37 px (n=2) ; N41 : 14 px (n=2) ; N42 : 35 px (n=2) ; N43 : 29 px (n=2) ; N44 : 13 px (n=2) ; N45 : 19 px (n=1) ; N46 : 163 px (n=2) ; N47 : 8 px (n=2) ; N48 : 9 px (n=2) ; N49 : 77 px (n=3) ; N50 : 78 px (n=4) ; N51 : 144 px (n=2) ; N52 : 86 px (n=2) ; N54 : 363 px (n=2) ; N57 : 95 px (n=3) ; N59 : 20 px (n=2) ; N60 : 85 px (n=2) ; N65 : 32 px (n=2) ; N66 : 35 px (n=2) ; N68 : 6 px (n=2) ; N70 : 28 px (n=4) ; N71 : 6 px (n=1) ; N72 : 13 px (n=2) ; N73 : 28 px (n=2) ; N74 : 76 px (n=2) ; N75 : 1 px (n=2) ; N76 : 9 px (n=1) ; N77 : 6 px (n=1) ; N78 : 50 px (n=1) ; N79 : 25 px (n=1) ; N80 : 74 px (n=1) ; N81 : 54 px (n=1) ; N82 : 12 px (n=1) ; N83 : 226 px (n=1) ; N84 : 30 px (n=2) ; N85 : 35 px (n=1) ; N86 : 38 px (n=1) ; N87 : 108 px (n=1) ; N132 : 44 px (n=1)

- après un échec, l'essai suivant (304 cas) : 48 % mêmes traits (rejeu ou micro-réglage), 29 % trait ajouté, 19 % trait déplacé/changé, 5 % trait retiré

## 6. Outils d'édition
- modes choisis : {'erase': 42, 'line': 210, 'move': 202, 'draw': 47}
- opérations : {'del': 48, 'mov': 680, 'scl': 185, 'und': 62}
- niveaux où gomme/déplacer/échelle servent : [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 79, 80, 82, 83, 84, 85, 86, 87]

---
Limites : voir `docs/PARCOURS_BETA.md`. Décision définitive seulement avec ≥ 3 joueurs ; les débutants mesurent la vraie difficulté.