# Refonte du monde 3 « Chaîne » — v6 (25 oct. 2026)

Méthode : fiches écrites par un agent Opus (`FICHES_MONDE3.md`, validées par Simon), géométrie et preuves au banc (`tools/refonte/m3.js`, harness, search, focus36). Aperçu seul : le jeu principal garde les niveaux d'origine.

## Code couleur de vitesse des rubans (R300, dans le moteur)
ambre = frein (0) · turquoise = lent (≈2) · violet = standard (7, rubans ordinaires) · blanc-cyan = rapide (≥10). Animation des cellules proportionnelle à la vitesse ; légende discrète en bas à droite sur les niveaux qui ont un ruban à vitesse cible.

## Les 12 niveaux (banc : P_ligne = réussite avec bruit de doigt σ=3, P_hasard = traits au hasard)
| N | Titre | Raisonnement | P_ligne | P_hasard | Note |
|---|---|---|---|---|---|
| 25 | Le ruban | Convertir | 98 | 0 | conservé (v1) |
| 26 | Dans le bon sens | Orienter | 88 | 0,7 | conservé (v1) |
| 27 | Trois couleurs | Lire la vitesse | 100 | 0,3 | 3 couloirs v2, aiguillage |
| 28 | La chute est un élan | Récupérer la chute | 98 | 0,1 | le ruban ne suffit pas (encre) |
| 29 | Le sas | Ralentir pour gagner | 80 | 2,5–3 | zone ouverte : seule la vitesse nulle gagne |
| 30 | Le second souffle | Recharger en haut, puis la machine (montagnes russes) | 83 | 0,17 | pont en ruban, puis toboggan en vague de rubans COURBES 10/7/10/2 (R301) ; gouffre sous le pont fermé (poche) |
| 31 | Le courant | Isoler d'un courant | 95 | 0,3 | tranchée à courant rapide, zone interdite |
| 32 | Rendre l'élan | Synthèse (ex-36) | 90 | 0 | rattraper la chute, la relever, la machine la rend (10/7/2/0) |
| 33 | L'escalier lent | Descendre pour monter | 70 | 0,5 | ruban lent sur pente raide |
| 34 | L'îlot lent | Sauter avant, relancer après | 80 | 0 | un îlot lent éteint l'élan ; aucune solution à 1 trait ; 2 rubans |
| 35 | Après ton passage | Séquencer : tracer pendant la course | — | 0 (tracé avant) | prison d'élan (rubans 8 et 10) ; le tracé avant bloque l'aller ; fenêtre de tracé élargie (R301b) : presque tout instant après l'aller, ≈ 15 images de bonne fenêtre sur 18 ; rubans 5 et 6 |
| 36 | La grande chaîne | Finale : machine à vitesses | 93 | 0 | ancienne machine allongée : descente 10, demi-tour, chicane 10/2/7, frein 0 ; 229 images |

## Esthétique des trajectoires (principe, à appliquer à chaque refonte et surtout aux machines)
- La trajectoire est un spectacle : une machine se juge au dessin de la course autant qu'à sa logique. Pas de zigzag : courbes lisses (Catmull-Rom), pentes douces, enchaînements sans angle vif.
- **Détours d'harmonie** autorisés et voulus : un virage, une vague, une bosse ou une boucle qui n'ajoute aucune difficulté mais donne du rythme et du suspense ; ils portent les changements de vitesse (10 → 7 → 2) pour que la couleur du ruban raconte le tempo.
- Règle de conception : tout élément d'une machine est courbe sauf s'il doit être droit pour une raison de lecture (pont, sol). Un ruban de vitesse peut être une courbe (`curves` avec `v`, R301).
- Modèles : 12 « La grande chaîne » (demi-tour, chicane, frein) et 6 refait en vague. À reprendre : les autres machines et les rubans droits des niveaux 27, 31, 33, 36 s'ils paraissent anguleux au jeu.

## État (v5)
- **Fait / vérifié** : 12 niveaux réussis dans le moteur réel (le 35 par un tracé fait pendant la course, mécanisme `optat` ajouté au moteur : démonstration de solution) ; 30 : sans trait échoue, hasard 0,25 % ; 34 : aucun trait unique ne gagne (4000 essais) ; 35 : 800 traits au hasard avant la course, 0 réussite.
- **Retrait** : « Le ruban-mur » (trop direct) ; « Le bon ruban » (contournable) remplacé par « Après ton passage » ; 34 « Le bout utile » remplacé par « L'îlot lent ».
- **Ordre** : 32 = « Rendre l'élan » (ex-36), 36 = machine d'origine allongée.
- **Non testé** : iPhone réel ; robustesse du 34 (P_ligne 80 %, sous la cible 85 %) ; fenêtre de tracé du 35 sur doigt réel ; non-régression des 132 niveaux non rejouée (ajout au moteur inerte hors démonstration).
