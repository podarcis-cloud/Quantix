# QUANTIX — audit et protocole de sound design

*Le son n'est pas une couche décorative posée après coup — c'est une
composante du gameplay au même titre qu'un mur ou une mécanique. Ce
document audite ce qui existe réellement dans `assets/js/engine.js`
(pas ce qu'on croit y avoir mis), puis fixe le protocole pour l'amener à
la hauteur de l'intention narrative du jeu.*

---

## 1. Ce qui existe déjà — audit de code

**Les effets ponctuels sont solides.** 16 événements sont déclarés dans
`BANK` et les 16 fichiers `.mp3` correspondants existent dans
`assets/audio/sfx/` : lancer de balle, impact (structure/rebond/glace),
piquant, tapis d'élan, portail, corde (pose/impact), collecte de noyau,
entrée en zone, réussite/échec de niveau, retour dans le temps, deux sons
d'interface. Chacun a des paramètres distincts (fréquence, forme d'onde,
enveloppe) — ce n'est pas un unique « bip » réutilisé. **Cette couche
répond déjà, pour l'essentiel, à la demande du §19 du master prompt
(feedback audio-ludique par événement).**

**L'ambiance de fond existe et diffère par monde**, via `WD[11]` :
fondamentale, mode, tempo, forme d'onde, désaccord, filtre, densité —
onze jeux de paramètres distincts, construits par `build()` et pilotés
par `setWorld()` à chaque changement de monde. Ce n'est donc pas vrai que
« seuls deux mondes ont une musique » au sens des données : les onze
existent et sont différentes entre elles.

**Ce qui explique l'impression contraire, trouvé dans le code (`MIX`,
ligne 94 de `engine.js`)** :

```
MIX = { nappe:  [1, 1, 1, 1, .7, .6],   // menu draw run tension success failure
        basse:  [0, .35, 1, 1, 0, 0],
        arpège: [0, 0, .6, .9, .45, 0],
        texture:[.3, .5, .4, .9, 0, .2] }
```

La couche `nappe` (le drone pur, fait des deux oscillateurs `o1`/`o2` et
du filtre modulé) est à pleine puissance dans **presque tous les états**,
y compris `draw` — l'état où le joueur passe la majorité de son temps
réel (il regarde, réfléchit, trace). Les couches rythmiques (`basse`,
`arpège`, qui portent la vraie identité mélodique et rythmique du monde
via `tick()`) sont à **zéro pendant `draw`** et ne s'activent qu'en `run`
— quelques secondes, le temps que la bille tombe. Un joueur qui passe 90 %
de son temps à dessiner entend donc, 90 % du temps, une nappe continue et
seulement un aperçu bref, quelques secondes par tentative, de ce qui rend
chaque monde réellement différent. **Ce n'est pas un bug d'absence, c'est
un déséquilibre de mixage** — la donnée existe, sa fenêtre d'audibilité
est trop courte.

**Diagnostic non confirmé, à vérifier sur appareil** : au-delà de ce
déséquilibre structurel, il reste possible qu'un bug distinct limite la
robustesse de `setWorld()` sur des changements de monde répétés
(transition croisée sur plusieurs oscillateurs avec `setTimeout` en
cascade). Règle 5 du protocole : instrumenter avant de conclure — ne pas
traiter cette hypothèse comme acquise sans mesure sur appareil réel.

---

## 2. Cadre théorique — superposition verticale et réenchaînement horizontal

Deux techniques documentées de musique adaptative (voir sources en fin de
document), et Quantix en utilise déjà une, partiellement :

- **Superposition verticale (« vertical layering »)** : plusieurs couches
  simultanées dont le mixage varie avec l'état du jeu. C'est exactement
  l'architecture `MIX`/`LAYERS` actuelle — la structure est la bonne, le
  réglage des poids ne l'est pas encore (§1).
- **Réenchaînement horizontal (« horizontal re-sequencing »)** : des
  segments musicaux distincts s'enchaînent selon les événements, plutôt
  que de superposer des couches d'un même segment. Quantix n'en fait
  aucun usage aujourd'hui — chaque monde a un seul jeu de paramètres fixe,
  pas de segments distincts pour, par exemple, l'approche d'un piège
  contre une phase de réflexion calme.

Les jeux les plus aboutis combinent les deux (ex. *Halo*, documenté dans
les sources). Quantix a la base technique pour la superposition verticale
(à rééquilibrer) ; le réenchaînement horizontal est un chantier neuf.

---

## 3. Ce qui doit changer — dans l'ordre de valeur/coût

### 3.1 Rééquilibrer `MIX` (coût faible, valeur immédiate)

Faire entendre l'identité de chaque monde **pendant qu'on trace**, pas
seulement pendant la chute. Piste concrète : introduire un état
intermédiaire entre `draw` et `run` (par exemple `aim`, actif une fois le
premier point du tracé posé) où `basse` et `arpège` montent
progressivement plutôt que de rester à zéro jusqu'à `run`. Le rôle du
protocole maître (§2, canal de flow) s'applique ici aussi : le son doit
suivre l'engagement croissant du joueur, pas basculer tout ou rien.

### 3.2 Sonoriser la proximité du danger (coût moyen, très haute valeur narrative)

Aucun signal sonore continu n'existe aujourd'hui pour la proximité d'un
piège pendant la simulation (`run`) — seul l'impact final (`spike_hit`)
existe, après coup. Piste : moduler `texture` (déjà une couche existante
dans `MIX`) en fonction de la distance minimale entre la balle et le
piquant le plus proche pendant la simulation — un principe déjà
documenté dans l'industrie (*Dead Space 2*, couches liées à la distance
aux ennemis). C'est directement ce que demande le §18 du master prompt
(« proximité d'un danger ») et ce que le moteur QP calcule déjà pour la
détection de collision — la donnée existe, il manque le branchement vers
`Audio1`.

### 3.3 Réenchaînement horizontal par monde (coût élevé, valeur structurelle)

Pour les mondes à forte identité dramaturgique (Faille, Quantique en
particulier — voir `WORLD_IDENTITY_FRAMEWORK.md`), envisager un segment
sonore dédié au moment de bascule (franchissement de portail,
effondrement par mesure) plutôt qu'un simple effet ponctuel — un bref
réenchaînement horizontal calé sur l'événement, pas seulement une
superposition de plus.

### 3.4 Climax de résolution différencié (coût faible à moyen)

`level_success` est aujourd'hui un unique son fixe, indépendant de la
manière dont le niveau a été résolu. Le protocole de dramaturgie
(`DRAMATURGY_FRAMEWORK.md` — payoff spectaculaire, élégant ou surprenant
selon le niveau) suggère que certains niveaux méritent un climax sonore
spécifique plutôt que le son générique — en particulier les niveaux de
synthèse en fin de monde (position 12 dans l'arc, §4 du protocole
maître).

---

## 4. Grille de decision — associer un événement à une fonction sonore

Reprend et complète le tableau du §19 du master prompt, avec l'état
d'implémentation réel :

| Événement | Son existant | Fonction | État |
|---|---|---|---|
| Collision structure | `impact_solid` | confirmer un contact neutre | ✅ câblé |
| Rebond | `impact_bounce` | signaler un gain d'énergie | ✅ câblé |
| Glace | `impact_ice` | signaler l'absence de perte de vitesse | ✅ câblé, mais voir §monde 4 de `WORLD_IDENTITY_FRAMEWORK.md` — le son existe, l'usage mécanique qui le justifierait reste à vérifier niveau par niveau |
| Élan | `boost_whoosh` | signaler le déclenchement de l'interrupteur de vitesse | ✅ câblé |
| Portail | `portal` | signaler la discontinuité | ✅ câblé |
| Piquant | `spike_hit` | sanctionner, immédiatement compréhensible | ✅ câblé |
| Proximité d'un danger | — | faire monter la tension *avant* l'impact | ⬜ à construire, §3.2 |
| Quasi-réussite | — | frustration productive (protocole maître §5) | ⬜ à construire |
| Franchissement de portail répété / boucle | `portal` répété | lisibilité d'un parcours complexe | 🔶 câblé mais non différencié par répétition |
| Réussite | `level_success` | payoff | ✅ câblé, non différencié par niveau, §3.4 |
| Échec | `level_fail` | information sur le type d'erreur (protocole maître §5) | 🔶 câblé mais un seul son pour tout type d'échec — perd l'occasion de distinguer, par exemple, une sortie de terrain d'un contact avec un piquant |

---

## 5. Ce que ce document ne fait pas

Il ne propose pas de composer de nouvelles ambiances monde par monde dans
l'abstrait — la conception sonore de chaque monde doit être décidée dans
la fiche de ce monde-là (champ « Son » de `LEVEL_DESIGN_CANVAS.md`),
au moment de sa refonte, pas à l'avance et hors contexte.

---

## Sources

- Superposition verticale et réenchaînement horizontal : documentés
  depuis *Monkey Island 2* (moteur iMUSE, 1991) jusqu'aux usages actuels
  (*Dead Space 2* — couches liées à la proximité de la menace ; *Halo* —
  combinaison des deux techniques avec randomisation ; *Hades II*,
  2024 — montée progressive pendant le combat).
- Le déséquilibre de mixage §1 et les pistes §3 sont une lecture directe
  du code de ce projet (`assets/js/engine.js`, fonctions `build`, `mix`,
  `tick`, objet `MIX`), pas une hypothèse externe.
