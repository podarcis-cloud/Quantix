# AUDIT DES DONNÉES DE JEU — quoi récolter, pourquoi, quand (R288, 24 oct. 2026)

But : décider de la matière à capter **dans la version en ligne** (pas seulement l'Aperçu), pour réviser les niveaux, calibrer l'encre,
comprendre la logique de résolution, repérer le décrochage, et préparer les bêta-testeurs. Principe : on capte des **événements bruts datés**
(journal d'événements), jamais seulement des résumés — on peut toujours recalculer un résumé, jamais l'inverse.

## 0. Constats sur l'existant (R266–R288)
- Récolte actuelle = 1 enregistrement par *lâcher* (tracés réduits, encre, issue, trajectoire). Perdu : tout ce qui se passe **avant** le lâcher
  (hésitations, tracés effacés, outils, annulations), **entre** les essais, et **hors niveau** (menus, sessions, abandons).
- Outils d'édition : mesure défaillante (R287 : mode jamais capté ; seuls ~10 essais/110 avaient `tl`). Cause du comptage `add` non élucidée → il faut
  instrumenter à la **source** (dans engine/editor, au moment de l'action), pas par enveloppe externe.
- Envoi mail (Web3Forms) = par lots à la réussite d'un niveau : perd les sessions qui s'arrêtent sur un échec — **précisément les décrochages**.
- Aperçu (base artefact) : réservé à Simon ; la version en ligne n'a aucune base.

## 1. Catalogue des données (priorité P1 = indispensable bêta, P2 = utile, P3 = long terme)
### A. Session et rétention (réponse à « où les joueurs décrochent »)  — P1
| donnée | détail | usage |
| session | id anonyme joueur, id session, début/fin, durée active (hors onglet caché), nb de sessions, délai entre sessions (J+1, J+7) | rétention |
| progression | niveau atteint max, niveaux terminés, dernier niveau joué avant arrêt, monde | courbe de décrochage, « niveau moyen terminé » |
| funnel par niveau | entrées, premières tentatives, réussites, abandons *sans* réussite, temps total par niveau, nb d'essais avant réussite | difficulté réelle, décrochage |
| sortie de session | dernier événement avant fermeture (via `visibilitychange`/`pagehide`) | savoir sur quel niveau/étape le joueur part |
| onboarding | écrans vus, didacticiel terminé/sauté, temps au 1er niveau | accueil |
| contexte | appareil (largeur, dpr, orientation), langue, navigateur, mode réduit, version du jeu, pays (grossier, côté serveur) | segmentation, bugs |
### B. Logique de résolution (le cœur de la révision) — P1
| journal de dessin | chaque trait : matière, points (réduits), début/fin, **ordre**, durée, vitesse moyenne | familles de solutions |
| édition | chaque opération : ajout, gomme, déplacer, échelle, tout effacer, annuler (+ cible, longueur avant/après), changement d'outil | usage réel des outils, hésitation |
| état au lâcher | traits présents, encre restante, temps depuis arrivée/dernier événement | « lire » le niveau |
| trajectoire | positions bille (≈ 1 point / 100 ms), **contacts** (mur, matière, objet, zone), vitesses aux contacts, point et cause d'échec | analyse physique, `out` : où et comment |
| essais successifs | diff entre essai n et n+1 (trait ajouté / déplacé / matière changée) | comment le joueur corrige = sa logique |
| rejouer / voir la solution / indice | usage, moment, niveau | niveaux opaques |
| objectifs optionnels | étoile prise ou non, temps, encre | challenge d'encre |
### C. Qualité de niveau (dérivé, calculé côté analyse) — P1/P2
taux de réussite 1er essai, médiane d'essais, encre min/médiane/max des réussites vs max alloué vs référence (`optsol`), distance à la géodésique, part de
solutions « famille ≠ référence », contournements (réussite très économe/hors famille), points de sortie du terrain (carte de chaleur), temps de première pensée.
### D. Engagement et économie (court/moyen terme) — P2
écran Bilan : relancer / niveau suivant / quitter ; réglages touchés (son, vibrations, langue) ; partage ; retour au monde ; achats/pubs **seulement** si un jour
la monétisation existe (jamais de pub après échec) — voir `ENGAGEMENT-ET-MONETISATION.md`.
### E. Perception (avec bêta-testeurs) — P2
mini-questionnaire optionnel après un niveau choisi : difficulté perçue (3 boutons), « compris le but ? », commentaire libre ; bouton « signaler un problème » avec
instantané (niveau, traits, build). Sans identité.
### F. Long terme — P3
cohortes par version (A/B de réglages d'encre), modèles de difficulté prédite, génération assistée (poids appris sur les familles de solutions), carte des
« idées de joueurs » réutilisables comme solutions alternatives, mesure de l'apprentissage (progrès entre mondes).

## 2. Ce qu'on ne capte pas
Nom, e-mail, IP stockée, identifiants publicitaires, localisation précise, contenu de saisie libre non sollicité, aucune donnée sur l'appareil au-delà du technique.
Âge/pays : **pays grossier côté serveur seulement** ; pas de date de naissance. Déclaration d'âge (« 13 ans ou plus ? ») seulement si Simon décide d'une segmentation.
(Cadre légal belge/UE — RGPD, consentement, mineurs : à valider ; ce document n'est pas un avis juridique. Décision D11 « mineurs » toujours ouverte.)

## 3. Architecture proposée (stable, simple, peu coûteuse)
1. **Journal d'événements** unique côté jeu (`events.js`) : `ev(type, data)` ; chaque événement = `{t (ms depuis session), sid, pid, lvl, n, type, d}` ; écrit dans une file locale
   (IndexedDB/localStorage) **avant** tout envoi → rien n'est perdu hors connexion.
2. **Envoi par lots** (toutes les ~20 s si événements, à `pagehide` via `sendBeacon`, au retour en ligne) vers un **point d'ingestion** ; idempotent (id d'événement) ; compression des tracés.
3. **Instrumentation à la source** (appels `ev()` dans engine/editor aux vrais endroits) — remplace les enveloppes externes.
4. **Stockage** interrogeable par Claude (même format que `parcours_beta` ; l'Aperçu continue d'alimenter la base de l'artefact).
5. **Rapports** : étendre `tools/parcours-rapport.py` : funnel/décrochage, rétention, logique de résolution (diff d'essais), outils, carte de chaleur des `out`.
6. **Consentement** : demande unique claire à la 1ʳᵉ ouverture (le mécanisme existe : `quantix.runs.consent2`), refus = rien capté ; page « ce qui est collecté ».

## 4. Backend en ligne — options (décision de Simon)
| option | + | − |
| A. Google Apps Script → Feuille Google (gratuit) | zéro serveur à gérer, Simon voit les données | quotas, lent, hébergé chez Google |
| B. Cloudflare Worker + KV/D1 (gratuit au départ) | rapide, fiable, sendBeacon OK, pays natif | un petit compte à ouvrir, un peu de code |
| C. Supabase/Firebase (gratuit au départ) | base complète, requêtes | compte + règles de sécurité à configurer |
| D. Rester sur e-mail (Web3Forms) | déjà là | pas fiable pour le décrochage, pas de flux continu — **à abandonner pour le gros du volume** |
Recommandation : B ou C ; dans tous les cas le jeu écrit via `ev()`, donc changer de backend n'impose pas de réinstrumenter.

## 5. Lots proposés
- L1 : `events.js` + instrumentation source (session, niveau, dessin, édition, essais, trajectoire+contacts, indices, sortie) + file locale + export JSON + Aperçu → base. *Sans backend.*
- L2 : backend choisi + envoi par lots + consentement + page « données collectées ».
- L3 : rapports (funnel/décrochage, rétention, logique de résolution, outils, chaleur des `out`), puis protocole de révision automatisé.
