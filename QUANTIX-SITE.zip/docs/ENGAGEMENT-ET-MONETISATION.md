# QUANTIX — engagement et monétisation

## 1. Ce que dit réellement la recherche

Le modèle le plus solide sur l'attachement aux jeux est celui de Ryan, Rigby et Przybylski, fondé sur la théorie de l'autodétermination. Quatre études montrent que **l'autonomie et la compétence perçues prédisent le plaisir, la préférence et le jeu futur**, indépendamment du contenu. Les besoins d'autonomie, de compétence et de relation prédisent chacun séparément le plaisir et l'intention de rejouer.

Le point décisif pour nous : ce n'est pas la récompense qui retient, c'est **le sentiment de devenir compétent**. La compétence est liée au caractère intuitif des commandes et au sentiment de présence.

Autrement dit, le levier le plus puissant dont Quantix dispose est déjà là — il est sous-exploité, pas absent.

## 2. Ce que dit la recherche sur les vies et l'énergie

Les systèmes de vies, d'énergie et de rendez-vous quotidiens sont classés comme **dark patterns temporels**. Une étude de 1 496 jeux montre que les modèles gratuits en contiennent significativement plus que les autres, et que ces mécaniques figurent parmi celles que les joueurs citent spontanément comme **frustrantes**.

L'exemple le plus proche de ce que tu proposes est documenté explicitement : l'échelle de récompenses de Candy Crush qui pousse à acheter des boosters après des échecs répétés **exploite la frustration**.

Le mécanisme est décrit sans ambiguïté : ces conceptions s'appuient sur des heuristiques mal adaptées — peur de manquer, aversion à la perte — pour manipuler l'architecture de choix et maximiser la monétisation, en **subvertissant délibérément l'autonomie du joueur**.

Or l'autonomie est précisément ce qui prédit le jeu futur.

## 3. La contradiction, et ce que j'en fais

Ton §22 interdit les vies, l'énergie, les timers et la monnaie obligatoire. Tu me demandes maintenant des vies achetables ou débloquables par publicité.

Les deux ne sont pas conciliables, et ce n'est pas un scrupule de ma part : **acheter une vie après un échec, c'est monétiser la frustration**. Ça détruit le sentiment d'autonomie, qui est le moteur de la rétention durable que tu cherches. Tu paierais des installations pour perdre des joueurs au jour 7.

Je ne construirai pas de système de vies. Je construis tout le reste, et je pense pouvoir te donner quelque chose de plus obsédant que des vies.

## 4. Les huit leviers à intégrer — condition sine qua non

### 4.1 Rendre la compétence visible seconde par seconde

Le joueur doit voir qu'il progresse **pendant** la tentative, pas seulement après. La frise de reprise existe déjà : elle devient une preuve de progression si on y affiche le point d'échec précédent. « Tu es allé 40 % plus loin qu'au coup d'avant. »

### 4.2 Le quasi-échec, rendu lisible

Le moteur connaît la distance exacte entre la particule immobilisée et la zone. L'afficher — « 14 px » — transforme un échec en information. C'est le mécanisme du quasi-gain, mais employé honnêtement : il informe au lieu de leurrer, parce que l'écart est **réel et réductible par l'habileté**.

### 4.3 L'effet Zeigarnik, sans pénalité

Une tâche interrompue occupe la mémoire plus qu'une tâche finie. L'accueil doit montrer **l'expérience en cours, à l'endroit exact où tu t'es arrêté**, avec sa dernière trajectoire ratée en pointillé. Pas de compte à rebours, pas de perte : juste un travail inachevé, visible.

### 4.4 La récompense variable en **magnitude**, jamais en **accès**

C'est la distinction éthique centrale. Rendre aléatoire *ce que tu découvres* est stimulant. Rendre aléatoire *si tu peux jouer* est prédateur.

Concrètement : des découvertes de laboratoire déclenchées par des comportements physiques rares et non annoncés — un rebond à plus de 14 unités, une superposition résolue sans détecteur, une corde qui porte la balle plus de 5 secondes. Le joueur ne sait pas qu'elles existent. Elles s'inscrivent dans un carnet.

### 4.5 La série qui ne se casse jamais

Les séries fonctionnent, mais leur perte est une punition et une source d'anxiété. Solution : une série qui **s'accumule et ne se réinitialise pas**. Le compteur de jours d'expérimentation ne fait que monter. Aucune peur, tout le bénéfice.

### 4.6 L'autonomie : plusieurs solutions vraies

Le solveur automatique prouve déjà que la plupart des niveaux ont des dizaines de solutions. Il faut le **dire** au joueur : « ta solution est la 3ᵉ forme différente que tu trouves ici ». C'est de l'autonomie rendue perceptible.

### 4.7 La densité de retour à la réussite

Le moment où la particule entre dans la zone doit être disproportionné : ralenti automatique sur les 400 dernières millisecondes, onde, son cristallin, vibration. C'est le seul endroit où l'excès est justifié.

### 4.8 Le micro-objectif toujours visible

Trois étoiles existent déjà mais restent abstraites pendant le jeu. Afficher en permanence celle qui est encore atteignable dans la tentative en cours.

## 5. Monétisation — trois couches, aucune ne touche au jeu

### Couche 1 — Premium, le socle

Mondes 1 et 2 gratuits, soit 24 expériences. Déblocage unique des 108 restantes. C'est le modèle que la direction artistique appelle, et le seul qui n'introduit aucun dark pattern.

### Couche 2 — Publicité récompensée, découplée de l'échec

La règle absolue : **jamais après un échec, jamais pour débloquer une progression**. Une publicité qui arrive quand le joueur est frustré est exactement le mécanisme documenté de Candy Crush.

Ce qui reste, et qui fonctionne :

- **Le Quantum Drop bonus** — une seconde expérience du jour, proposée après une réussite, jamais après un échec. Le joueur est en état positif, il choisit librement, et l'objet offert est du contenu, pas un déblocage.
- **La révélation d'une solution alternative** — après avoir résolu un niveau, voir comment une autre forme le résout. Ça ne contourne rien : c'est un bonus pédagogique offert à quelqu'un qui a déjà gagné.

Format : jamais d'interstitielle, jamais de lecture automatique, toujours un bouton explicite qui annonce la durée.

### Couche 3 — Cosmétique

Traces de particule, thèmes de laboratoire, apparences. Le carnet de découvertes en débloque gratuitement une partie par le jeu ; le reste s'achète. Aucun effet sur la physique.

### Ce que je refuse de construire, et pourquoi

Les vies, l'énergie, les compteurs de temps, et toute publicité déclenchée par un échec. Non par principe abstrait : parce que ça monétise la frustration, que ça subvertit l'autonomie, et que l'autonomie est ce qui prédit le jeu futur. Ce serait payer cher un revenu immédiat contre la rétention que tu veux.

## 6. Ordre d'intégration proposé

Ces mesures s'insèrent dans la liste existante, elles ne la remplacent pas.

1. Distance au but affichée à l'échec — le moins cher, le plus immédiat *(4.2)*
2. Reprise de l'expérience en cours sur l'accueil, avec trajectoire fantôme *(4.3)*
3. Densité de retour à la réussite : ralenti, onde, son *(4.7)*
4. Micro-objectif visible pendant la tentative *(4.8)*
5. Carnet de découvertes, douze entrées non annoncées *(4.4)*
6. Progression comparée à sa propre tentative précédente *(4.1)*
7. Compteur de jours d'expérimentation, sans remise à zéro *(4.5)*
8. Compteur de formes de solution distinctes par niveau *(4.6)*

Puis seulement : découpage gratuit/payant, et publicité récompensée sur les deux points définis.
