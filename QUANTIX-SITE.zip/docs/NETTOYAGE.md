# QUANTIX — Inventaire, exigences à maintenir, nettoyage (R264, 22 octobre 2026)

*Base saine et légère pour la suite. §1–§2 : ce qui reste et pourquoi. §3 : les exigences à maintenir, chantier par
chantier, avec leurs sources (rien ne se perd). §4 : le superflu. §5 : la liste à exécuter dans une conversation neuve.*

## 1. Le nécessaire — socle actif (lu ou tenu à chaque lot)

| Document | Rôle | Où |
|---|---|---|
| `ETAT.md` | source de vérité : version, chantiers, décisions, liens | zip + Projet |
| `DEMARRAGE.md` | erreurs de session à ne pas refaire (1 page) | zip + Projet |
| `REGLES.md` | exigences A–J, méthode d'un lot K, passation L, économie M | zip + Projet |
| `TECHNIQUE.md` | fichiers, globaux, commandes, pièges, fin, Quantone | zip + Projet |
| `LEXIQUE.md` | nos mots | zip + Projet |
| `A_VERIFIER.md` | liste à cocher par Simon | zip + Projet |
| `INDEX.md` | quel document pour quelle tâche | zip + Projet |
| `JOURNAL.md` | historique (on y ajoute une ligne par lot, on ne le lit pas) | **zip seulement** |
| `INSTRUCTIONS_PROJET.md` | copie de secours des instructions du Projet | zip seulement |

## 2. Le nécessaire — références à garder (ouvertes seulement si la tâche les touche)

| Sujet | Documents | Devenir |
|---|---|---|
| Graphisme | `HANDBOOK.md` (§6 jetons de couleur), `QUANTUM_VISUAL_NARRATIVE.md`, `CAHIER_DES_CHARGES_GENERATION.md` §17–§25, `ANNEXE_DESIGN_JONCTIONS.md`, `TEXTURE_MAGNETISME.md`, `DIDACTICIEL_DESIGN.md` | fusion → `CHARTE_GRAPHIQUE.md` |
| Niveaux | `BIBLE_ENIGMES.md`, `ENIGME_PROTOCOL.md`, `DIFFICULTY_PROTOCOL.md`, `CAHIER_DES_CHARGES_GENERATION.md` §1–§16, `MONDE1_FICHES.md`, `MONDE7_FICHES.md`, `PISTES_TRAVERSABLES.md`, `MONDE11_MOTEUR.md` | fusion → `METHODE_NIVEAUX.md` |
| Son | `SON_MONDES.md`, `SOUND_DESIGN_PROTOCOL.md` | gardés |
| Récit | `NARRATION.md` | gardé |
| Vibrations | `VIBRATIONS.md` | gardé |
| Éthique, modèle économique | `ENGAGEMENT-ET-MONETISATION.md` | gardé |
| État des lieux daté | `AUDIT_R209.md` | gardé jusqu'au scan des 132 niveaux, puis archivé |
| Trace des refontes | `MATRICE_DOCUMENTS.md`, ce document | zip seulement |

## 3. Exigences à maintenir (ne se perdent pas dans le nettoyage)

### 3.1 Toujours en vigueur — `REGLES.md`
- **A. Travail** : produire du visible et jouable (A1) ; ambition, une idée par niveau (A2) ; Simon juge à l'œil sur iPhone
  (A3–A4) ; ne jamais abandonner une idée, élargir la palette (A7) ; vérifier avant d'affirmer, dire ce qui est vérifié
  ou non (A9–A11) ; ne jamais écraser un document de Simon (A13) ; une remarque sur un monde ne s'étend pas aux autres
  (A14) ; banc des rendus avant le jeu (A15) ; communication directe (A16).
- **E. Interface** : aucun texte hors `i18n.js`, FR + EN (E1) ; peu de texte (E2) ; ton concis ≤ 80 signes (E3) ; fiches
  holographiques, une notion à la fois (E4–E5) ; éditeur soigné, Échelle dans Déplacer (E6) ; bilan sans phrases (E7–E8) ;
  liens des outils à chaque réponse (E9).
- **F. Son**, **G. Narration et fin**, **H. Technique**, **I. Livraison**, **J. Refus définitifs**, **K. Méthode d'un
  lot**, **L. Passation**, **M. Économie et communication** : inchangés.
- **Quantone** : toute commande à valeur reçoit le menu « Valeur par défaut / Automation », textes FR + EN dans ses
  dictionnaires (`TECHNIQUE.md` §4.4).

### 3.2 Pour la future `CHARTE_GRAPHIQUE.md` (à construire quand Simon la convoque)
- `REGLES.md` §B en entier : néon + couche cosmique sur #05070D, jetons du `HANDBOOK.md` §6 seulement ; ⛔ rétro plat,
  ⛔ kitsch ; visuels éthérés en couches animées ; murs en lumière quantique ; **rien dans la zone de réussite** ;
  identité visuelle animée **par monde**, fondée sur une expérience réelle et sourcée ; parti pris tranché, règles
  strictes, pas de valeurs en dur ; plein écran sans image floue ; terrain fixe ; **aucune zone invisible** ; zone
  interdite = fluctuations du vide ; ferrofluide du Magnétisme ; Mécanique décorative et cyclone comme modèles ;
  illustrations étalonnées.
- Demandes du 22 oct. : **test automatique de régression des fonds de chaque monde** (le fond du Magnétisme figé n'a été
  vu qu'à l'œil) ; **Gravité** : points animés de tailles et d'opacités variées, noyés dans la poussière astrale,
  qui suivent la direction et la force de la gravité du niveau et servent d'information au joueur ; quelque chose
  d'osé, dans la charte, plus d'harmonie et d'originalité (vidéo de référence de Simon) ; **Soufflerie** : décor et
  mise en scène du thème à repenser.
- Sources : tableau §2, ligne « Graphisme » ; archive `WORLD_IDENTITY_FRAMEWORK.md` (identité par monde, R29).

### 3.3 Pour la future `METHODE_NIVEAUX.md` (charte des niveaux mise à jour)
- `REGLES.md` §C et §D : énigmes, pas réglages ; **0 gagnant sans la mécanique, 0 trait « nu »** ; difficulté =
  comprendre (P_exec ≥ 70 % au modèle éditeur) ; plusieurs familles de solutions ; noyau qui récompense un choix ; un
  niveau qui ne tient pas se refait à partir d'une idée ; machines des niveaux 6 et 12 faites des éléments du monde,
  jamais de rail visible.
- Demandes du 22 oct. :
  1. **Erreurs fatales d'abord** : encre de départ, niveau résoluble avec son encre, réussite détectée — priorité absolue.
  2. **Encre calibrée au scénario** de chaque niveau ; ni jauge vide, ni encre à peine entamée dès le premier essai.
  3. **Géodésique** (solution de référence) : gagne, se trace au doigt, et c'est la plus économe en encre connue (pas
     d'encre inutile) ; si l'optimum n'est pas prouvé, le dire.
  4. **Aucune redondance** : chaque niveau apporte sa pièce (idée, difficulté, nouveauté) ; aucun obstacle sans intérêt
     de jeu ou contournable spontanément ; Chaîne puis Soufflerie d'abord.
  5. **Méthode non reproductiviste** : une logique propre au monde, une logique propre au niveau qui reste dans celle du
     monde ; capable d'aller chercher de la documentation et de construire de nouveaux schémas logiques et psychologiques.
  6. **L'expérience du joueur comme prisme** : public cible établi par une recherche documentée et actuelle, qui fixe le
     type de défi et le niveau de complexité.
  7. **Données réelles** : collecte des parties des bêta‑testeurs avec consentement explicite (pas implicite), données
     minimales (pas de géolocalisation précise, âge en tranche facultative), export volontaire d'abord ; réinjection pour
     calibrer les niveaux et le générateur.
  8. **Futur monde** (peut‑être caché) : mécanique des fluides — concevoir sa grammaire physique avant ses niveaux.
- Outils de preuve : `preuve.py`, `difficulty.js`, `scan132.js`, `bypass.js`, `contournements.js`, `zonepropre.js`.
- Sources : tableau §2, ligne « Niveaux » ; archives `MASTER_LEVEL_DESIGN_PROTOCOL.md`, `LEVEL_DESIGN_CANVAS.md`,
  `SCENARIO_PROTOCOL.md`, `DRAMATURGY_FRAMEWORK.md`, `PLAYTEST_PROTOCOL.md`, `REFERENCE_DESIGN_ENIGMES.md`,
  `CAHIER_DES_CHARGES_NIVEAUX.md`, `AUDIT_CONTOURNEMENTS.md` (à relire pour la fusion, puis laissées en archive).

## 4. Le superflu

- **Menu édition** : supprimé (demande du 22 oct.) — `studio/menu-edition.html` retiré, `tools/build-menu.py`,
  `MENU_EDITION.md`, `menu-docs.json` archivés ; l'artefact reste à supprimer (§5).
- **Documents fusionnés ou périmés** : déjà dans `docs/archive/` du zip (37 fichiers) ; à retirer du Projet (§5).
- **Outils** : `tools/` contient ≈ 115 scripts, dont beaucoup liés à des refontes passées (`w2*`, `w3*`, `*.json` de
  mesures R28–R116, `livrer.py` aux anciens chemins). À trier plus tard : un outil non cité dans `TECHNIQUE.md` ni dans
  `REGLES.md` et non appelé par un autre outil va dans `tools/archive/`. Pas urgent : ils ne sont jamais lus au démarrage.

## 5. Liste à exécuter (premier lot de la conversation neuve, sans rien décider d'autre)

**Exécutée le 23 oct. 2026 (R265)**, étapes 1–4 et 6 ; l'étape 5 (artefact) attend l'accord de Simon.

1. Décompresser le zip dans `/home/claude/site` (voir `DEMARRAGE.md`).
2. **Ramener du Projet dans le zip** avant toute suppression (lecture `project_read`, écriture dans le zip) :
   `claude/DEMARRAGE.md` → `docs/` ; `claude/probe_ferro.py` → `tools/` ; `claude/FINALE_R213.md`,
   `claude/FINALE_FIL.md`, `claude/AUDIT_HEROS_FIN.md`, `claude/FIN_DEUX_PLANS.md`, `redundancy.js` → `docs/archive/`.
3. **Supprimer du Projet** (`project_delete`), 34 documents :
   `claude/probe_ferro.py`, `claude/JOURNAL.md`, `claude/PASSATION_R232.md`, `claude/FINALE_R213.md`,
   `claude/FINALE_FIL.md`, `claude/AUDIT_HEROS_FIN.md`, `claude/FIN_DEUX_PLANS.md`, `claude/INDEX_DOCUMENTS.md`,
   `claude/CHARTE_EXIGENCES.md`, `claude/MENU_EDITION.md`, `claude/AUDIT_ESPACE_JEU.md`, `claude/AUDIT_INTERFACE.md`,
   `claude/AUDIT_DIDACTICIEL.md`, `claude/AUDIT_CONTOURNEMENTS.md`, `claude/INSTRUCTIONS_PROJET.md`,
   `claude/AUDIT_METHODE.md`, `claude/METHODE.md`, `archive/REPRISE-SESSION-R121.md`, `claude/ETAT_REFONTE_NIVEAUX.md`,
   `claude/CONSIGNES_SIMON.md`, `claude/ANALYSE_R116.md`, `REPRISE-SESSION.md`, `SCENARIO_PROTOCOL.md`, `FINITION.md`,
   `WORLD_IDENTITY_FRAMEWORK.md`, `MASTER_LEVEL_DESIGN_PROTOCOL.md`, `LEVEL_DESIGN_CANVAS.md`, `redundancy.js`,
   `DRAMATURGY_FRAMEWORK.md`, `REDUNDANCY_ANALYSIS.md`, `TRIAGE_R73.md`, `PLAYTEST_PROTOCOL.md`, `PROTOCOLE.md`.
4. **Remplacer dans le Projet par la version du zip** (`project_write` avec `local_path`, même chemin) — les copies du
   Projet datent du 8 oct. : `BIBLE_ENIGMES.md`, `DIFFICULTY_PROTOCOL.md`, `HANDBOOK.md`,
   `CAHIER_DES_CHARGES_GENERATION.md`, `MONDE7_FICHES.md`, `QUANTUM_VISUAL_NARRATIVE.md`, `SOUND_DESIGN_PROTOCOL.md`,
   `ENIGME_PROTOCOL.md`, `ENGAGEMENT-ET-MONETISATION.md` ; et dans `claude/` : `ETAT.md`, `REGLES.md`, `TECHNIQUE.md`,
   `INDEX.md`, `LEXIQUE.md`, `NETTOYAGE.md`.
5. **Artefact Menu édition** (https://claude.ai/artifact/63wuCq6jdpwN6i7PWmyNkk) : le supprimer après confirmation de
   Simon dans la conversation (action irréversible).
6. Contrôle : `project_info` → il doit rester le socle (§1, sauf `JOURNAL.md` et `INSTRUCTIONS_PROJET.md`) et les
   références (§2), rien d'autre. Zip renvoyé, une ligne « R265 : nettoyage exécuté » dans `JOURNAL.md`, `ETAT.md` §3
   ligne 0 retirée.
