# Audit — espace de jeu (R190, 13 octobre 2026)

## Mesures (Chromium, niveau 15 « La montée »)

| Écran | Toile de jeu | Part de la hauteur | Limite |
|---|---|---|---|
| 390 × 844 (iPhone 12–15), actuel | 384 × 512 | 61 % | **largeur** |
| 390 × 844, prototype Plein cadre | 390 × 520 | 62 % | largeur |
| 375 × 667 (iPhone SE), actuel | 358 × 477 | 72 % | hauteur |
| 375 × 667, prototype | 371 × 494 | 74 % | largeur (presque) |

Le monde fait 360 × 480 (3:4), et un téléphone récent est en 9:19,5. **Sur tous les téléphones récents, l'écran de jeu
est déjà limité par la largeur** : déplacer le titre, l'énergie ou les outils ne peut pas l'agrandir de plus de 2 à 4 %
(les 6 px de marge latérale de `resize()`). Sans changer la géométrie des 132 niveaux, on ne peut pas faire mieux.

## Pourquoi il paraît petit

1. **Dans l'aperçu** (artefact dans l'application Claude), la barre de l'application et ses marges réduisent la
   hauteur : la toile devient limitée par la hauteur et rétrécit. L'application installée depuis Safari a toute la hauteur
   et la toile y prend toute la largeur. L'impression « petite fenêtre » vient donc surtout de l'aperçu.
2. **Le cadre** : la toile est une carte aux coins arrondis sur un fond différent, avec des bandes vides au-dessus et en
   dessous. L'œil voit une fenêtre posée dans un écran, pas un monde.
3. **Le haut empilé** : titre (2 lignes), étoiles et barre d'énergie avec son mot prennent 81 px.
4. **Le bas empilé** : outils avec libellés, puis annuler/effacer/Lâcher/ralenti, puis l'astuce : 150 px.

## Proposition « Plein cadre » (prototype dans l'aperçu, pas dans le site)

- **Le monde va jusqu'aux bords** : un reflet flou du vrai rendu (toile réduite 1/6, flou CSS) remplit tout l'écran, et
  le haut et le bas de la toile se fondent dedans (14 px). Le moteur n'est pas modifié : même toile, mêmes coordonnées, même
  collision.
- **La limite physique est marquée par quatre repères de coin** (fines croix cyan), comme la maquette d'accueil, au lieu
  d'un cadre.
- **Titre minimisé** sur une ligne (« FONDERIE · 3 / 12 La montée »), **étoiles supprimées**.
- **Énergie** : un fil de lumière de 2 px dans le haut de l'écran de jeu, sans le mot.
- **Barre d'outils et Lâcher** : posées sur le monde en Visière (verre sombre), outils en icônes sans libellé, Lâcher en
  bouton de lumière ; l'astuce flotte juste au-dessus.

Pistes non retenues : fusionner outils et Lâcher sur une seule ligne (dix boutons sur 366 px, trop serrés au doigt et
sans gain : la largeur reste la limite) ; poser les outils sur le monde (ils masqueraient les éléments du bas des
niveaux) ; recadrer les côtés (change la géométrie des niveaux).

## À valider par Simon avant intégration

Libellés des outils supprimés (premier niveau : le didacticiel « Tes outils » les nomme encore) ; position du fil
d'énergie ; intensité du reflet. Intégration : bloc CSS + script (≈ 40 lignes) déplacés de `studio/proto-plein-cadre.*`
vers `quantix.css` / `engine.js`, puis tests e2e du didacticiel et de l'éditeur (positions des fiches Visière).
