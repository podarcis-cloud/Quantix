# QUANTIX — Consignes de Simon (version R122, 10 octobre 2026)

> **Statut R209 : HISTORIQUE — remplacé par CHARTE_EXIGENCES.md (R209).** Voir `INDEX_DOCUMENTS.md`.


*Cette version remplace celle du 9 octobre (mandat de refonte autonome des 132 niveaux, barre « PRÊT » à dix critères,
§9 « priorité quota »). La méthode qui en découle est `METHODE.md` ; le constat qui l'a motivée est `AUDIT_METHODE.md`.*

## Ce qui reste vrai

- **Le but** : des niveaux qui ont chacun une idée, et un moment spectaculaire par monde (une machine faite des éléments du
  monde, aux courbes harmonieuses, entrée fluide).
- **Simon juge à l'œil**, sur iPhone, à partir d'un aperçu jouable. Il retouche ensuite dans l'éditeur s'il le souhaite.
- **Ordre** : on valide les niveaux dans l'ordre, monde par monde.
- **Éditeur de niveaux** (artefact https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp) : ne jamais écraser un document que Simon
  a enregistré lui‑même (Q‑01‑01, Q‑01‑02, Q‑01‑12 au 9 octobre) ; écrire une variante `Q-MM-PP-claude` et le signaler.
- **Son** : base W1N ; souffle qui respire jusqu'au silence, pulsation tôt, rien d'oppressant (le monde 1 est trop chargé à
  partir du niveau 8).
- **Didacticiel** : fiches en surimpression, terrain fixe ; finitions plus tard.
- **Quota** : économiser ; une conversation par lot ; ne pas calculer longtemps sans résultat visible.

## Décisions récentes

- 9 oct. : ne revoir que les montagnes russes du monde 1 (faites : 3 et 6) ; monde 2 : machines 6 et 12 seulement
  (18 faite, 24 non).
- 9 oct. : la jouabilité se mesure avec l'éditeur de ligne (outil Droite, déplacement aimanté), plus au doigt.
- 10 oct. : refonte de la méthode (audit) ; les protocoles deviennent une bibliothèque, plus des cases à cocher.

## À trancher

- Périmètre de la première version publiée.
- Connexion du dépôt GitHub du site.
