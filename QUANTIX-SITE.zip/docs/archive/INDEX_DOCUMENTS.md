# QUANTIX — Index des documents (R232, 16 octobre 2026)

*Quel document lire, quand, et lesquels ne plus ouvrir. Tous existent dans le Projet claude.ai et dans `docs/` du zip.
Chaque document porte en tête une ligne « Statut R209 » qui répète son classement.*

## 1. À lire au début de chaque conversation (≈ 15 minutes)

| Document | Rôle |
|---|---|
| `REPRISE-SESSION.md` | état du jeu, prochain lot, décisions attendues, commandes, pièges, journal |
| `CHARTE_EXIGENCES.md` | toutes les exigences de Simon, en une charte (remplace `CONSIGNES_SIMON.md`) |
| `LEXIQUE.md` | nos mots (atelier / jeu / code) |
| `PASSATION_R232.md` | ce qui a changé depuis R209, la fin `fin5`, le Banc de la fin et ses annotations, l'architecture de Quantone, les règles de passation entre conversations |
| *(instructions du Projet)* `INSTRUCTIONS_PROJET.md` | le prompt, à coller dans les instructions personnalisées |

## 2. Références à consulter quand la tâche l'exige

| Document | Quand |
|---|---|
| `AUDIT_R209.md` | état des lieux complet, dettes, feuille de route, décisions |
| `METHODE.md` | déroulé d'un lot, preuve d'un niveau, livraison |
| `NARRATION.md` | histoire du jeu, héros, épilogue « Les retrouvailles » |
| `VIBRATIONS.md` | vibrations : moteurs, pool de motifs, partition de la fin, limites de l'iPhone |
| `HANDBOOK.md` | moteur, rendu, jetons de couleur (§6), séquence de vérification (§10), règles de conception (§11) |
| `CAHIER_DES_CHARGES_GENERATION.md` | §17–§25 : courbes, grille d'or, jonctions, lumière quantique, zone dégagée, animations, chocs |
| `ANNEXE_DESIGN_JONCTIONS.md` | où trouver le code et les règles des murs, jonctions, chocs |
| `QUANTUM_VISUAL_NARRATIVE.md` | l'expérience de physique de chaque monde et son identité visuelle (sources) |
| `WORLD_IDENTITY_FRAMEWORK.md` | mécanique et identité par monde (audit R29, partiellement périmé) |
| `BIBLE_ENIGMES.md` | idées d'énigmes, hypothèses du joueur, leurres |
| `ENIGME_PROTOCOL.md` | critères d'une énigme (bibliothèque, pas une case à cocher) |
| `DIFFICULTY_PROTOCOL.md` | modèle de tracé, P_exec / P_int, `difficulty.js` |
| `AUDIT_CONTOURNEMENTS.md` | raccourcis par niveau (R161 ; liste à jour : `AUDIT_R209.md` annexe A) |
| `PISTES_TRAVERSABLES.md` | moteur des pistes poreuses (`pass`, `pz`) |
| `TEXTURE_MAGNETISME.md` | ferrofluide du monde 8 (WebGL), demandes et références |
| `DIDACTICIEL_DESIGN.md`, `AUDIT_DIDACTICIEL.md` | didacticiel (Visière, fiches holographiques) |
| `AUDIT_INTERFACE.md`, `AUDIT_ESPACE_JEU.md` | interface, plein cadre |
| `SON_MONDES.md`, `SOUND_DESIGN_PROTOCOL.md` | son par monde (W1N), protocole sonore |
| `ENGAGEMENT-ET-MONETISATION.md` | éthique d'engagement, refus, monétisation (complété par `AUDIT_R209.md` §8) |
| `MENU_EDITION.md` | contenu du Menu édition (outils, fichiers, méthode) |
| `MONDE1_FICHES.md`, `MONDE7_FICHES.md` | fiches de conception par niveau |

## 3. Historique (ne pas ouvrir sauf demande précise)

| Document | Pourquoi |
|---|---|
| `CONSIGNES_SIMON.md` | remplacé par `CHARTE_EXIGENCES.md` (R209) |
| `AUDIT_METHODE.md` | pourquoi la méthode R122 ; conclusions reprises dans `METHODE.md` |
| `ETAT_REFONTE_NIVEAUX.md` | tableau R116, mesures périmées ; à régénérer monde par monde |
| `ANALYSE_R116.md` | analyse des niveaux à R116 |
| `TRIAGE_R73.md`, `REDUNDANCY_ANALYSIS.md`, `redundancy.js` | triage et redondance des anciens niveaux |
| `MASTER_LEVEL_DESIGN_PROTOCOL.md`, `LEVEL_DESIGN_CANVAS.md`, `SCENARIO_PROTOCOL.md`, `DRAMATURGY_FRAMEWORK.md`, `PLAYTEST_PROTOCOL.md`, `FINITION.md`, `PROTOCOLE.md` | anciens protocoles (R30–R97), devenus bibliothèque |
| `archive/REPRISE-SESSION-R121.md` | journal R38 → R121 |
