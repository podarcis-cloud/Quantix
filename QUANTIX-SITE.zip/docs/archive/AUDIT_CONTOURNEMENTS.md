# Audit des contournements (R161)

> **Statut R209 : référence datée (R161) ; liste à jour dans AUDIT_R209.md annexe A.** Voir `INDEX_DOCUMENTS.md`.


*Détecteur : `tools/contournements.js A B` (niveaux A à B, résultats dans `contournements.jsonl`). Pour chaque niveau, tous les traits
droits uniques (pas 24 u, 11 angles, longueurs 60 à 320 u dans l'encre, hors zones interdites) ; une victoire est **nue** quand la
trajectoire reste à plus de R+5 u de tout mur, courbe, champ ou élément du niveau (hors bassin) : le niveau ne sert à rien.*

**Correction R161** : jusqu'en R160 le seuil de contact était R+3 u, inférieur à la distance d'une balle qui ROULE sur une paroi
(R+3,4) ; tout roulement passait pour « ne rien toucher ». Le chiffre de 88 niveaux était donc surévalué. Seuil juste : **51 niveaux**
sur 132 (scan du 11 octobre, après les corrections R158–R161).

Dans les mondes 1 à 4, l'outil du joueur EST la mécanique (rebond en Fonderie…) : une victoire nue y signifie que les obstacles
ne comptent pas (moins grave en position 1–2). Ailleurs, l'élément signature est contourné.

## Corrigés

| # | Niveau (nouveau nom) | Lot | Nues |
|---|---|---|---|
| 100 | Portail et mur | R158 | 0 |
| 112 | La balle molle | R158 | 0 |
| 115 | Molle et lame | R158 | 0 |
| 122 | Opposition | R158 | 0 |
| 98 | À travers le mur | R159 | 0 |
| 99 | Le geyser | R159 | 0 |
| 103 | La sarbacane | R159 | 0 |
| 106 | La couture | R160 | 0 |
| 65 | Le pendule | R161 | 0 |
| 41 | La combe gelée | R161 | 0 |

## Restant (seuil corrigé)

| # | Monde | Pos. | Niveau | Nues | Gagnants |
|---|---|---|---|---|---|
| 13 | Fonderie | 1 | Le trampoline | 93 | 155 |
| 16 | Fonderie | 4 | La hauteur juste | 65 | 71 |
| 117 | Filaments | 9 | Le filet | 45 | 45 |
| 17 | Fonderie | 5 | Sol brûlant | 43 | 50 |
| 129 | Quantique | 9 | Temps et rebond | 39 | 60 |
| 68 | Mécanique | 8 | L’engrenage | 38 | 38 |
| 111 | Filaments | 3 | Corde et plaque | 38 | 40 |
| 63 | Mécanique | 3 | Piston bas | 35 | 249 |
| 93 | Magnétisme | 9 | Orbite | 35 | 35 |
| 67 | Mécanique | 7 | Métronome | 30 | 133 |
| 52 | Soufflerie | 4 | Colonne étroite | 28 | 35 |
| 87 | Magnétisme | 3 | Aimant haut | 28 | 74 |
| 101 | Faille | 5 | Deux failles | 27 | 64 |
| 116 | Filaments | 8 | Deux cordes | 24 | 24 |
| 123 | Quantique | 3 | La mesure | 21 | 90 |
| 71 | Mécanique | 11 | Atelier mobile | 20 | 20 |
| 95 | Magnétisme | 11 | La capture | 20 | 23 |
| 97 | Faille | 1 | Le portail | 19 | 85 |
| 130 | Quantique | 10 | Le choix | 18 | 93 |
| 59 | Soufflerie | 11 | La tempête | 16 | 17 |
| 46 | Glacier | 10 | Verglas | 15 | 117 |
| 105 | Faille | 9 | Aller-retour | 15 | 76 |
| 61 | Mécanique | 1 | Le piston | 14 | 128 |
| 104 | Faille | 8 | Boucle | 14 | 37 |
| 124 | Quantique | 4 | Deux possibles | 14 | 119 |
| 14 | Fonderie | 2 | Le ricochet | 13 | 16 |
| 20 | Fonderie | 8 | Le tremplin | 12 | 17 |
| 64 | Mécanique | 4 | Deux pistons | 12 | 94 |
| 127 | Quantique | 7 | Intrication double | 12 | 121 |
| 110 | Filaments | 2 | Le hamac | 11 | 11 |
| 118 | Filaments | 10 | Corde et colonne | 11 | 60 |
| 94 | Magnétisme | 10 | Champ magnétique | 9 | 46 |
| 102 | Faille | 6 | L’élan transmis | 9 | 74 |
| 107 | Faille | 11 | Le pli | 9 | 20 |
| 109 | Filaments | 1 | Corde tendue | 9 | 75 |
| 70 | Mécanique | 10 | L’horloge | 8 | 147 |
| 79 | Gravité | 7 | Ascension | 8 | 83 |
| 57 | Soufflerie | 9 | La rafale | 7 | 7 |
| 125 | Quantique | 5 | Le temps ralenti | 7 | 149 |
| 23 | Fonderie | 11 | L’élan d’abord | 6 | 6 |
| 53 | Soufflerie | 5 | Deux colonnes | 6 | 24 |
| 11 | Atelier | 11 | Le relais | 5 | 6 |
| 19 | Fonderie | 7 | Le four | 5 | 5 |
| 83 | Gravité | 11 | Le puits | 5 | 80 |
| 89 | Magnétisme | 5 | Aimant et mur | 5 | 78 |
| 69 | Mécanique | 9 | Cadence double | 4 | 40 |
| 92 | Magnétisme | 8 | Slalom | 4 | 106 |
| 119 | Filaments | 11 | Opus | 4 | 25 |
| 128 | Quantique | 8 | Mesure tardive | 4 | 66 |
| 131 | Quantique | 11 | Machine quantique | 2 | 25 |
| 22 | Fonderie | 10 | Double rebond | 1 | 2 |

## Méthode de correction

- Fermer le passage : l'obstacle va d'un bord à l'autre, l'élément du niveau devient le seul passage.
- Interdire le tracé (`mz`) là où un trait remplacerait l'élément.
- Donner un mouvement et une décision (consigne Simon, comme les 6 et 12) : parabole qui traverse le mur, geyser, sarbacane,
  couture, marteau, glissade sans frottement…
- Vérifier : 0 victoire nue, 0 gagnant sans la mécanique, P_exec ≥ 70 % (modèle éditeur).

## Limites du moteur rencontrées

- Cordes du joueur : rebond élastique trop chaotique pour un trampoline fiable (Corde tendue, essai R161 : 6–26 %).
- Barre mobile : l'embarquement en marche est rare, et une barre qui monte à travers un plancher ne soulève pas la balle.
- Deux vals de glace à la suite : la piste ordinaire y fait mieux que la glace (l'idée « la glace garde l'énergie » ne tient que sur un val).
- L'échappement (72) : 0 % de jouabilité déjà en R160 (machine au réglage exact), à reprendre.
