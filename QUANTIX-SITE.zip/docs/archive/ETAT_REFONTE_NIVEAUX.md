# QUANTIX — ÉTAT DE LA REFONTE, NIVEAU PAR NIVEAU

> **Statut R209 : HISTORIQUE — mesures R116 périmées ; état à jour : AUDIT_R209.md annexe B.** Voir `INDEX_DOCUMENTS.md`.


*Généré par `python3 tools/etat.py` (ne pas modifier à la main). Critères : `CONSIGNES_SIMON.md` §2. Jouabilité : `difficulty.js`, modèle par position (1–6 main levée, 7–12 éditeur admis, R117).*

## Synthèse

| Critère | Niveaux qui le remplissent |
|---|---|
| Énigme ✓ | 31 / 132 |
| Pas de trait court ni ligne directe | 56 / 132 |
| Jouable au doigt ≥ 70 % | 55 / 132 |
| Noyau atteignable | 82 / 132 |
| Solution de référence | 58 / 132 |
| Zone dégagée | 129 / 132 |
| Fiche écrite | 31 / 132 |
| Machine constante (≥ 98 %) quand il y en a une | 131 / 132 |
| Test du monde | 60 / 132 |
| Son neuf du monde | 12 / 132 |
| PRÊT (toutes les cases sauf son) | 13 / 132 |

**Niveaux PRÊTS** : 2 « Le pont », 3 « Le colimaçon », 4 « Le relais », 5 « Le demi-tour », 6 « Les collines », 7 « Économie », 8 « La portée », 10 « Le plafond », 14 « Le ricochet », 20 « Le tremplin », 44 « La patinoire », 47 « La crevasse double », 51 « Vent descendant »

| Monde | Prêts | Énigme ✓ | Doigt ≥ 70 % | Réf. | Niveaux spectaculaires (≥ 1) | Test | Son neuf |
|---|---|---|---|---|---|---|---|
| 1 Atelier | 8/12 | 12/12 | 10/12 | 12/12 | 2 | oui | oui |
| 2 Fonderie | 2/12 | 6/12 | 7/12 | 11/12 | 0 | oui | non |
| 3 Chaîne | 0/12 | 1/12 | 7/12 | 12/12 | 0 | oui | non |
| 4 Glacier | 2/12 | 7/12 | 5/12 | 10/12 | 0 | oui | non |
| 5 Soufflerie | 1/12 | 1/12 | 5/12 | 3/12 | 0 | oui | non |
| 6 Mécanique | 0/12 | 0/12 | 5/12 | 1/12 | 0 | non | non |
| 7 Gravité | 0/12 | 4/12 | 2/12 | 4/12 | 0 | non | non |
| 8 Magnétisme | 0/12 | 0/12 | 3/12 | 0/12 | 0 | non | non |
| 9 Faille | 0/12 | 0/12 | 5/12 | 2/12 | 0 | non | non |
| 10 Filaments | 0/12 | 0/12 | 3/12 | 2/12 | 0 | non | non |
| 11 Quantique | 0/12 | 0/12 | 3/12 | 1/12 | 0 | non | non |

## Niveau par niveau

### Monde 1 — Atelier

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Le premier trait | C | 97 % | 80 % | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | trait de 16 u suffit ; reporté : coût : un mur de 11 à 15 u suffit (seuil 40) — à reprendre ; meilleure variante jouable conservée (97 % au doigt) |
| 2 | 2 | Le pont | A | 87 % | 43 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 3 | 3 | Le colimaçon | A | 90 % | 87 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 4 | 4 | Le relais | A | 90 % | 53 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 5 | 5 | Le demi-tour | C | 90 % | 57 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 6 | 6 | Les collines | C | 77 % | 77 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 7 | 7 | Économie | C | 97 % | 97 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 8 | 8 | La portée | C | 100 % | 97 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 9 | 9 | Le détour | C | 87 % | 67 % | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | trait de 59 u suffit ; reporté : coût : un trait de 59 u gagne (seuil 120) — à reprendre |
| 10 | 10 | Le plafond | A | 77 % | 77 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 11 | 11 | Le relais | C | 20 % | 13 % | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | jouabilité 20 % ; élément dans la zone ; reporté : ancien niveau conservé (jouabilité 20 %, élément dans la zone) ; fiche « La moitié » sans réalisation — à reprendre |
| 12 | 12 | L’établi | A | 23 % | 20 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 23 % ; reporté : ancien niveau conservé (jouabilité 23 %, pas de machine) ; machine finale (lacets + verse) plafonnée à 67 % éditeur en 6 itérations — à reprendre |

### Monde 2 — Fonderie

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 13 | 1 | Le trampoline | C | 87 % | 77 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | trait de 13 u suffit ; énigme non validée |
| 14 | 2 | Le ricochet | A | 73 % | 30 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 15 | 3 | La montée | A | 27 % | 20 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 27 % |
| 16 | 4 | La hauteur juste | C | 100 % | 100 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 50 u suffit ; énigme non validée ; sans fiche |
| 17 | 5 | Sol brûlant | C | 80 % | 80 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 39 u suffit ; énigme non validée ; sans fiche |
| 18 | 6 | Ta plaque | C | 37 % | 17 % | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 37 % ; trait de 13 u suffit |
| 19 | 7 | Le four | D | 27 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 27 % ; noyau inatteignable ; pas de solution de référence ; trait de 47 u suffit ; énigme non validée ; sans fiche |
| 20 | 8 | Le tremplin | A | 73 % | 33 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 21 | 9 | Le grand retour | C | 73 % | 63 % | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ | élément dans la zone ; énigme non validée ; sans fiche |
| 22 | 10 | Double rebond | C | 53 % | 23 % | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 53 % ; trait de 17 u suffit ; sans fiche |
| 23 | 11 | L’élan d’abord | C | 80 % | 80 % | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 62 u suffit ; sans fiche |
| 24 | 12 | La fonte | C | 50 % | 43 % | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 50 % ; trait de 65 u suffit ; énigme non validée |

### Monde 3 — Chaîne

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 25 | 1 | Le tapis | A | 33 % | 33 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 33 % |
| 26 | 2 | Sens inverse | C | 63 % | 33 % | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 63 % ; trait de 35 u suffit ; énigme non validée ; sans fiche |
| 27 | 3 | Tapis et butée | C | 63 % | 17 % | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 63 % ; trait de 21 u suffit ; énigme non validée ; sans fiche |
| 28 | 4 | Le plafond bas | C | 50 % | 50 % | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 50 % ; trait de 19 u suffit ; énigme non validée ; sans fiche |
| 29 | 5 | Ton élan | C | 93 % | 60 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 70 u suffit ; ligne directe ; énigme non validée ; sans fiche |
| 30 | 6 | Saut de chaîne | C | 27 % | 20 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 27 % ; énigme non validée ; sans fiche |
| 31 | 7 | Tapis et lames | C | 97 % | 87 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 55 u suffit ; énigme non validée ; sans fiche |
| 32 | 8 | Deux tapis | C | 70 % | 30 % | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | énigme non validée ; sans fiche |
| 33 | 9 | Chaîne montante | C | 100 % | 100 % | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | énigme non validée ; sans fiche |
| 34 | 10 | Relais d’élan | C | 93 % | 93 % | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ | ligne directe ; élément dans la zone ; énigme non validée ; sans fiche |
| 35 | 11 | Le tri des tapis | C | 87 % | 87 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ligne directe ; énigme non validée ; sans fiche |
| 36 | 12 | La chaîne complète | C | 77 % | 23 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 75 u suffit ; énigme non validée ; sans fiche |

### Monde 4 — Glacier

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 37 | 1 | Le lac | A | 43 % | 43 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 43 % |
| 38 | 2 | Trop vite | C | 13 % | 13 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 13 % ; énigme non validée ; sans fiche |
| 39 | 3 | Le saut | A | 40 % | 37 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 40 % |
| 40 | 4 | Le demi‑tour | A | 60 % | 50 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 60 % |
| 41 | 5 | Glace interdite | D | 20 % | 17 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 20 % ; pas de solution de référence ; trait de 8 u suffit ; énigme non validée ; sans fiche |
| 42 | 6 | La butée | C | 50 % | 50 % | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 50 % ; trait de 36 u suffit ; énigme non validée ; sans fiche |
| 43 | 7 | Deux étages | C | 83 % | 83 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | trait de 40 u suffit ; énigme non validée ; sans fiche |
| 44 | 8 | La patinoire | A | 97 % | 97 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 45 | 9 | Le passage gardé | C | 77 % | 77 % | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | trait de 9 u suffit |
| 46 | 10 | Verglas | D | 80 % | 17 % | ❌ | ❌ | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche |
| 47 | 11 | La crevasse double | A | 97 % | 97 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 48 | 12 | Le sérac | A | 67 % | 50 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | jouabilité 67 % |

### Monde 5 — Soufflerie

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 49 | 1 | Le souffle | C | 40 % | 40 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 40 % ; énigme non validée ; sans fiche |
| 50 | 2 | Vent de face | C | 30 % | 27 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 30 % ; énigme non validée ; sans fiche |
| 51 | 3 | Vent descendant | A | 70 % | 70 % | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| 52 | 4 | Colonne étroite | D | 50 % | 50 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 50 % ; pas de solution de référence ; énigme non validée ; sans fiche |
| 53 | 5 | Deux colonnes | D | 50 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 50 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche |
| 54 | 6 | Vent et plafond | D | 77 % | 40 % | ❌ | ❌ | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | pas de solution de référence ; trait de 14 u suffit ; énigme non validée ; sans fiche |
| 55 | 7 | Vent et lame | D | 33 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 33 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche |
| 56 | 8 | Contre-courant | D | 100 % | 0 % | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche |
| 57 | 9 | La rafale | D | 90 % | 0 % | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche |
| 58 | 10 | Le tunnel | D | 73 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 42 u suffit ; énigme non validée ; sans fiche |
| 59 | 11 | La tempête | D | 63 % | 57 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | jouabilité 63 % ; pas de solution de référence ; trait de 44 u suffit ; énigme non validée ; sans fiche |
| 60 | 12 | La veine | D | — | — | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ | aucun trait droit ne gagne ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche |

### Monde 6 — Mécanique

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 61 | 1 | Le piston | D | 67 % | 60 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 67 % ; pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 62 | 2 | La navette | D | 17 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 17 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 63 | 3 | Piston bas | D | 63 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 63 % ; noyau inatteignable ; pas de solution de référence ; trait de 14 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 64 | 4 | Deux pistons | D | 40 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 40 % ; noyau inatteignable ; pas de solution de référence ; trait de 17 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 65 | 5 | Le pendule | D | 80 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 28 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 66 | 6 | Va-et-vient | D | 63 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 63 % ; noyau inatteignable ; pas de solution de référence ; trait de 15 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 67 | 7 | Métronome | D | 73 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 33 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 68 | 8 | L’engrenage | D | 77 % | 0 % | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 69 | 9 | Cadence double | D | 10 % | 3 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 10 % ; pas de solution de référence ; trait de 82 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 70 | 10 | L’horloge | D | 90 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 35 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 71 | 11 | Atelier mobile | D | 60 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 60 % ; noyau inatteignable ; pas de solution de référence ; trait de 17 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 72 | 12 | Le régulateur | C | 97 % | 93 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | trait de 11 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |

### Monde 7 — Gravité

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 73 | 1 | Tomber vers le haut | A | 33 % | 33 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | jouabilité 33 % ; pas de test du monde |
| 74 | 2 | Gravité lourde | A | 40 % | 40 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | jouabilité 40 % ; pas de test du monde |
| 75 | 3 | Le manège inversé | A | 27 % | 27 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | jouabilité 27 % ; machine : constance non mesurée ou < 98 % ; pas de test du monde |
| 76 | 4 | Le champ de travers | A | 47 % | 13 % | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | jouabilité 47 % ; pas de test du monde |
| 77 | 5 | Deux champs | D | 43 % | 7 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 43 % ; pas de solution de référence ; trait de 14 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 78 | 6 | Champ et mur | D | 43 % | 13 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 43 % ; pas de solution de référence ; trait de 22 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 79 | 7 | Ascension | D | 90 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 10 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 80 | 8 | Champ et lame | D | 30 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 30 % ; noyau inatteignable ; pas de solution de référence ; trait de 29 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 81 | 9 | Bascule | D | 40 % | 7 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 40 % ; pas de solution de référence ; trait de 8 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 82 | 10 | Apesanteur | D | 57 % | 27 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 57 % ; pas de solution de référence ; trait de 13 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 83 | 11 | Le puits | D | 97 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 60 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 84 | 12 | Le pèse-matière | D | 53 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 53 % ; noyau inatteignable ; pas de solution de référence ; trait de 96 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |

### Monde 8 — Magnétisme

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 85 | 1 | L’aimant | D | 47 % | 43 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 86 | 2 | Aimant fort | D | 33 % | 23 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 33 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 87 | 3 | Aimant haut | D | 7 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 7 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 88 | 4 | Deux aimants | D | 70 % | 40 % | ❌ | ❌ | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 89 | 5 | Aimant et mur | D | 60 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 60 % ; noyau inatteignable ; pas de solution de référence ; trait de 47 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 90 | 6 | Le couloir | D | 10 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 10 % ; noyau inatteignable ; pas de solution de référence ; trait de 78 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 91 | 7 | Aimant et lame | D | 57 % | 57 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 57 % ; pas de solution de référence ; trait de 17 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 92 | 8 | Slalom | D | 87 % | 83 % | ❌ | ❌ | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | pas de solution de référence ; trait de 30 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 93 | 9 | Orbite | D | 53 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 53 % ; noyau inatteignable ; pas de solution de référence ; trait de 104 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 94 | 10 | Champ magnétique | D | 47 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; noyau inatteignable ; pas de solution de référence ; trait de 22 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 95 | 11 | La capture | D | 100 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 20 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 96 | 12 | Le solénoïde | D | — | — | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | aucun trait droit ne gagne ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |

### Monde 9 — Faille

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 97 | 1 | Le portail | D | 10 % | 10 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 10 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 98 | 2 | Portail court | D | 27 % | 3 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 27 % ; pas de solution de référence ; trait de 27 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 99 | 3 | Portail montant | D | 70 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 18 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 100 | 4 | Portail et mur | D | 47 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; noyau inatteignable ; pas de solution de référence ; trait de 35 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 101 | 5 | Deux failles | D | 23 % | 3 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 23 % ; pas de solution de référence ; trait de 39 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 102 | 6 | Portail et vent | C | 73 % | 73 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | trait de 18 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 103 | 7 | Portail et lame | D | 57 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 57 % ; noyau inatteignable ; pas de solution de référence ; trait de 39 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 104 | 8 | Boucle | D | 90 % | 0 % | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 105 | 9 | Aller-retour | C | 90 % | 90 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | trait de 100 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 106 | 10 | Faille interdite | D | 10 % | 10 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 10 % ; pas de solution de référence ; trait de 38 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 107 | 11 | Le pli | D | 100 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 38 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 108 | 12 | La singularité | D | 10 % | 7 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 10 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |

### Monde 10 — Filaments

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 109 | 1 | La corde | D | 17 % | 17 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 17 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 110 | 2 | Corde tendue | D | 47 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; noyau inatteignable ; pas de solution de référence ; trait de 13 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 111 | 3 | Le hamac | D | 27 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 27 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 112 | 4 | Corde et plaque | D | 33 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 33 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 113 | 5 | La balle molle | D | 63 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 63 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 114 | 6 | Molle et mince | C | 57 % | 53 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 57 % ; énigme non validée ; sans fiche ; pas de test du monde |
| 115 | 7 | Molle et pente | C | 93 % | 93 % | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | trait de 13 u suffit ; ligne directe ; énigme non validée ; sans fiche ; pas de test du monde |
| 116 | 8 | Molle et lame | D | 40 % | 0 % | ❌ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 40 % ; noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 117 | 9 | Deux cordes | D | 23 % | 20 % | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 23 % ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 118 | 10 | Le filet | D | 73 % | 0 % | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; énigme non validée ; sans fiche ; pas de test du monde |
| 119 | 11 | Corde et colonne | D | 70 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 27 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 120 | 12 | Opus | D | 13 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 13 % ; noyau inatteignable ; pas de solution de référence ; trait de 77 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |

### Monde 11 — Quantique

| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 121 | 1 | Le lien | C | 47 % | 47 % | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; énigme non validée ; sans fiche ; pas de test du monde |
| 122 | 2 | Opposition | D | 27 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 27 % ; noyau inatteignable ; pas de solution de référence ; trait de 8 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 123 | 3 | La mesure | D | 27 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 27 % ; noyau inatteignable ; pas de solution de référence ; trait de 11 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 124 | 4 | Deux possibles | D | 20 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 20 % ; noyau inatteignable ; pas de solution de référence ; trait de 29 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 125 | 5 | Le temps ralenti | D | 27 % | 3 % | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 27 % ; pas de solution de référence ; trait de 11 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 126 | 6 | Lien et porte | D | 47 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 47 % ; noyau inatteignable ; pas de solution de référence ; trait de 12 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 127 | 7 | Intrication double | D | 23 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 23 % ; noyau inatteignable ; pas de solution de référence ; trait de 13 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 128 | 8 | Mesure tardive | D | 37 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 37 % ; noyau inatteignable ; pas de solution de référence ; trait de 29 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 129 | 9 | Temps et rebond | D | 90 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 17 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 130 | 10 | Le choix | D | 83 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 28 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 131 | 11 | Machine quantique | D | 93 % | 0 % | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | noyau inatteignable ; pas de solution de référence ; trait de 50 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
| 132 | 12 | Quantix | D | 60 % | 0 % | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | jouabilité 60 % ; noyau inatteignable ; pas de solution de référence ; trait de 27 u suffit ; énigme non validée ; sans fiche ; pas de test du monde |
