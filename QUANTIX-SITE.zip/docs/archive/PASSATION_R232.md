# QUANTIX — Passation R232 (16 octobre 2026)

*À lire juste après `REPRISE-SESSION.md` par toute conversation qui reprend le travail. Ce document comble les trous qui ont
obligé Simon à revenir dans l'ancienne conversation : une conversation neuve ne savait pas ce qui avait été fait ailleurs,
travaillait sur un code plus ancien, ignorait le fonctionnement du Banc de la fin et republiait par‑dessus.*

## 1. Règles de passation (nouvelles, à respecter)

1. **Une seule conversation travaille à la fois.** Celle qui livre le dernier zip est la référence. Avant de toucher au code,
   vérifier le tampon : `grep -o 'build R[0-9]*' index.html` doit afficher le tampon annoncé en tête de `REPRISE-SESSION.md`.
   S'il est plus ancien, demander le dernier zip à Simon ; ne jamais reconstruire de mémoire.
2. **Le zip est la seule source du code.** Chaque conversation a son propre espace de travail : les fichiers modifiés dans une
   autre conversation n'existent pas chez toi tant que le zip n'est pas joint et décompressé.
3. **Les artefacts sont partagés.** Une autre conversation peut les avoir republiés : avant de republier, lire l'artefact
   (action `read`), fusionner, puis publier à la même adresse. Ne jamais créer une adresse nouvelle pour un outil existant.
4. **Fin de chaque lot** : zip complet envoyé, `REPRISE-SESSION.md` (état en tête **et** journal) envoyé au Projet, ce
   document mis à jour si l'architecture ou un outil change.

## 2. Ce qui a changé depuis R209 (fichier par fichier)

| Fichier | Changement | Dans le jeu ? |
|---|---|---|
| `assets/js/hero.js` | nouvelle fin `fin5` (scènes R213 + tout le travail R214–R231) **jouée par le jeu depuis R233** (validée par Simon) ; `window.QFIN_A=false` rétablit la fin R207 (banc) | oui (R233) |
| `assets/js/visuals.js` | `VX.spikes` exporté ; `ndDust` accepte `sz`/`dn` (taille, densité des grains ; défaut inchangé) | oui, sans effet visible |
| `assets/js/haptics.js` | **nouveau** : vibrations (`QHAP`), pool de 19 motifs, trois moteurs (natif, Android, iPhone) | non (pas chargé par `index.html`) |
| `studio/quantone.html` | menu de commande + automation (R231), boîte à rythmes à pas (R232) | Quantone autonome oui ; Quantone de l'Aperçu au prochain aperçu |
| `studio/banc-fin.html` | Banc de la fin (page de l'autre conversation, annotation conservée) reconstruit à chaque lot | outil |
| `tools/build-banc-fin.py` | reconstruit le banc : remplace seulement `visuals.js` et `hero.js`, injecte `haptics.js` et le panneau Vibrations | outil |
| `index.html`, `engine.js` | tampon R232 | oui |
| `docs/` | `VIBRATIONS.md`, ce document, `REPRISE-SESSION.md` | — |

## 3. La fin (`fin5` dans `hero.js`) : comment elle est construite

- **Scènes** : `SC.push({w, nm, build(a,b), cam(lt), tw, lag, sync, nosafe})`. `w` = monde (11 la coupe … 0 Atelier),
  `build` reçoit l'état de sortie de la scène précédente et rend deux trajets `A` (blanche) et `B` (violette).
- **Trajets** : classe `Path` — `glide(x,y,vx,vy,d)` (Hermite), `fn(f,d,x,y,vx,vy)`, `w(d)` (attente), `e(type,…)`
  (évènement), `run({surf,until})` (physique simplifiée), `bounce2(dir,dx1,h1,d1,dx2,h2,d2)` (réception lourde + deux rebonds).
- **Évènements** (`ev5`) : `hit`, `thud`, `launch`, `thrust`, `portal`, `seam`, `coll`, `boost`, `absorb`…
- **Décors** : `DECO[w](c,z,lt,A,B,now)` ; fond animé du monde (`backS5`, `bg5`) ; vol libre de l'Atelier : `spaceDeco`.
- **Atelier** (le dernier trait) : constantes `ORGP, FX0, FXE, FTS, FTJ, FR0, FR1, FZX, FTF`, zones `ZN` (la 6ᵉ est la zone
  finale), trait `TY(x)`, pointe `xTip/tTip`, aura `kiAura`, comètes dans `zoneFX`, vol en double hélice `dnaFly`, siphon
  `spiral`, plongée qui reprend la vitesse angulaire (`DVW`).
- **Traînées** : `trail5` / `ribbon5` (rubans lissés), trace de la danse en fil continu (`epDance`).
- **Vibrations** : partition `VIBSC` (une par acte) jouée par `vib5` ; détail `VIBRATIONS.md`.
- **Rendu absolu** : `fin5.render(c,w,h,t,opt)` ; une recherche (saut de temps) rejoue 900 ms en arrière sans vibrer.
- **Intégration** : faite en R233 (`epilogue` joue fin5 par défaut). Aperçu de la fin : `python3 tools/build-apercu.py 1 11 skipintro fin`.
  (`python3 tools/build-apercu.py 1 11 skipintro fin`), tests, zip.

## 3 bis. La bande son de la fin (R234, `assets/js/fin-sound.js`, global `QFINS`)

- Partition = liste de notes `{t (ms du film), d, k (instrument), a (arguments)}` construite une fois (`build`) depuis
  `QHERO.fin5.acts()` et `QHERO.fin5.cues()` ; la danse est générée à la demande (`dance`), sans fin.
- Instruments (`V`) : `bell` (blanche), `mallow` (violette), `pluck`, `pad`, `sub`, `thump`, `breath`, `grain`, `wood`, `drop`,
  `glide`, `whoosh`, `riser`, `suck` ; sortie commune : réverbération (convolution 4,2 s), écho ping-pong filtré, compresseur doux.
- Lecture : `QFINS.sync(tFilm, joue, vitesse)` à chaque image ; recherche > 180 ms → coupe et relance (notes en cours reprises
  avec un fondu) ; dérive plus faible → horloge recalée doucement ; muet hors ×1. `QFINS.unlock()` sur un geste (iOS).
- Rendu hors ligne : `QFINS.render(ctxOffline, dest, t0, t1)` (scratchpad `snd/render.py` : WAV + crêtes/RMS par seconde).
- Changer un acte : modifier son bloc dans `build()` (un bloc commenté par monde).

## 4. Le Banc de la fin et ses annotations (procédure)

- Adresse : https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b — reconstruire avec
  `python3 tools/build-banc-fin.py studio/banc-fin.html Rnnn`, puis publier **à la même adresse**.
- Simon capture une image, l'annote et l'envoie : document dans la collection **`captures`** de la base de l'artefact
  (`act`, `t` en ms, `note`, `asset`). Lire les nouvelles : `ArtifactData query` sur `captures` avec `where at > <date du
  dernier lot>` ; l'image : `Artifact read` avec `path` = `asset`.
- `__banc.seek(t)` (temps absolu) pilote le banc ; scripts de capture Playwright : voir la fin de ce document.
- Chaque lot de la fin : lire **toutes** les notes non traitées (un oubli a déjà coûté un retour de Simon), répondre à
  chacune, dire lesquelles restent ouvertes.

## 5. Quantone : architecture (pour y ajouter du code sans casser)

- Un seul `<script>` : un module externe (état `st`, `KN`, `KE`, `play`, `stop`, `score`, `sched`, `preset`, `loadPreset`,
  `voice`, `applyK`…) qui contient des **blocs** successifs ; chaque bloc remplace des fonctions par enveloppe
  (`var preset2=preset;preset=function(){…}`).
- Le bloc des instruments (`INST`, `NAMES`, `COLS`, `drum`, `send`, `nz`, `O`, `REG`, `edUI`, `layUI`) est **privé** : le
  code qui en a besoin (ex. boîte à rythmes) s'insère **dans** ce bloc, juste avant `window.QFX3=…`.
- Textes : dictionnaires propres à Quantone (`T`, `TX`, `TX2`, `TX3`, `TX4` menu/automation, `TX5` boîte à rythmes), FR/EN.
- **Règle (Simon, R232)** : toute nouvelle commande à valeur (bouton à états, curseur, potard, liste) reçoit le menu
  « Valeur par défaut / Automation » : une clé dans `auKey` (où elle est touchée) et une description dans `auDesc`
  (lire, écrire, défaut, format). Les boutons d'action pure ont le menu grisé.
- Clés existantes : `k:` potards, `eq:`, `ef:`, `ik:<instr>:<réglage>`, `sel:` listes, `fx:` fonctions, `dk:` réglages de voix,
  `dp:<voix>:<pas>`, `dmu:<voix>`, `dln`, `dkit`. R235 : `grid`, `ifn:<instr>`, `ilp:<instr>` (descriptions dans `QFX3.fnDesc`).
- Tests : `python3 tools/e2e-quantone.py` (12/12), `e2e-quantone-editeur.py` (9/9).

## 6. Vibrations : ce qu'on sait

- iPhone : pas d'API de vibration web ; seul le « tic » d'un interrupteur (`<input type=checkbox switch>`, iOS 18+). Sur
  l'iPhone de Simon, **rien ne vibre dans l'artefact ouvert dans l'app Claude** (R231). Test à faire par Simon : basculer
  lui-même l'interrupteur du panneau, puis ouvrir le banc dans Safari. Sinon : application native (Capacitor Haptics).

## 7. En attente (au 16 octobre, 6 h)

- Fin : validée par Simon et intégrée au jeu (R233). Monde 7 Gravité refondu (R233), à juger dans l'aperçu.
- Quantone : choix de Simon parmi les 3 instruments proposés (Corde, Écume, Onde ; alternative Spectre) ; automation dans
  l'export .wav ; Aperçu à refaire pour embarquer le nouveau Quantone.
- Vibrations : résultat des tests iPhone de Simon ; option « Vibrations » dans les Paramètres du jeu (non commencée).
- Toujours valables : `REPRISE-SESSION.md` §2 (refonte monde 7 ou Chapitre 1) et §3 (décisions D1–D10).

## 8. Scripts utiles (à recréer dans le bloc‑notes si besoin)

Capture d'une plage du banc (Playwright, Chromium préinstallé) :
```python
# python3 capR.py <t0> <t1> <pas_ms> <préfixe>
import asyncio,sys
from playwright.async_api import async_playwright
t0,t1,st,pre=float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),sys.argv[4]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':420,'height':900})
    await pg.goto('file:///…/site/q/studio/banc-fin.html'); await pg.wait_for_timeout(1000)
    t=t0-600;await pg.evaluate(f"__banc.seek({t})");k=0;nx=t0
    while t<t1:
      t+=40;await pg.evaluate(f"__banc.seek({t})")
      if t>=nx:
        nx+=st;await pg.locator('#stage').screenshot(path=f"{pre}{k:02d}.png");k+=1
    await b.close()
asyncio.run(main())
```
Durées des actes : `node -e` qui charge `visuals.js` puis `hero.js` et affiche `QHERO.fin5.acts()` (nom, `t0`, `d`, évènements).
