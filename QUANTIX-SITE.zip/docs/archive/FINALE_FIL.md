# FINALE « LE FIL » (R212) — remplace FIN_DEUX_PLANS.md (R211, obsolète)

Banc seulement (studio/fin4/*.js, QHERO.fin4) ; le jeu n'est pas modifié. Non vérifié sur iPhone.

## Histoire
La bille naît seule dans la coupe. Le module de division quantique la divise : un FIL d'intrication naît de la division et devient le personnage du film (détendu, tendu, pincé, accroché, coupé, traversant les failles). Chaque monde est poussé au bout de sa mécanique, avec des trajectoires simulées ou calculées. Fin : horizon (Quantix 2), fusion, sphère, titre.

## Storyboard (module → concept poussé)
1 Coupe : chute et lancement. 2 Quantique : division, branche au temps dilaté et barrière poreuse (tunnel). 3 Filaments : lasso autour d'un pylône ; le fil tendu arrache la bille, qui joue la harpe. 4 Faille : échange de hauteurs, le fil traverse les deux portes. 5 Magnétisme : pincement vers le pôle, fil accroché au pôle, quasi-contact, inversion, claquement du fil. 6 Fonderie : enclumes (hauteurs +52 % par coup) ; l'onde de choc sépare les plans. 7 Mécanique | Glacier : escalier d'horlogerie devant ; dalles poreuses traversées derrière (le piège de la glace devient un élément dynamique). 8 Gravité | Soufflerie : pesanteur inversée (seule rotation de caméra, motivée) ; courant ascendant et sillage de Kármán. 9 Chaîne : maillons imbriqués, les plans se rejoignent. 10 Quantix 2 « La limite » : mouvement hyperbolique, contraction, lumière jamais rejointe. 11 Atelier : le trait est de la matière, la jumelle rebondit sur le trait de la bille. 12 Quantix 2 « L'horizon » : spirale à moment cinétique conservé, étirement, fusion.

## Règles
Aucun basculement de caméra gratuit ; pas de tresse systématique ; chocs en temps réel pendant les arrêts sur image ; rayon de bille constant ; profondeur par le décor.

## À faire
Réglages à l'œil (cadrage, durées, chocs), son, intégration dans hero.js (dont le correctif de lueur du Glacier) après validation de Simon, puis refonte des niveaux du monde 7.
