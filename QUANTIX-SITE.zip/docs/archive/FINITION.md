# QUANTIX — Compte rendu de finition des 132 niveaux

> **Statut R209 : historique (bibliothèque).** Voir `INDEX_DOCUMENTS.md`.


*Généré par `tools/rapport-finition.py` à partir des mesures. Aucun niveau n'a encore passé ton test : A = « candidat ».*

| Note | Niveaux |
|---|---|
| A | 20 |
| B | 0 |
| C | 38 |
| D | 74 |

| Monde | A | B | C | D |
|---|---|---|---|---|
| 1 Atelier | 5 | 0 | 7 | 0 |
| 2 Fonderie | 3 | 0 | 8 | 1 |
| 3 Chaîne | 1 | 0 | 11 | 0 |
| 4 Glacier | 6 | 0 | 4 | 2 |
| 5 Soufflerie | 1 | 0 | 2 | 9 |
| 6 Mécanique | 0 | 0 | 1 | 11 |
| 7 Gravité | 4 | 0 | 0 | 8 |
| 8 Magnétisme | 0 | 0 | 0 | 12 |
| 9 Faille | 0 | 0 | 2 | 10 |
| 10 Filaments | 0 | 0 | 2 | 10 |
| 11 Quantique | 0 | 0 | 1 | 11 |

**A** : 2 Le pont, 3 Le demi-tour, 4 Le relais, 10 Le plafond, 12 L’établi, 14 Le ricochet, 15 La montée, 20 Le tremplin, 25 Le tapis, 37 Le lac, 39 Le saut, 40 Le demi‑tour, 44 La patinoire, 47 La crevasse double, 48 Le sérac, 51 Vent descendant, 73 Tomber vers le haut, 74 Gravité lourde, 75 Le manège inversé, 76 Le champ de travers

**B** : 

### Monde 1 — Atelier

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 1 | Le premier trait | **C** | 15 u | un trait de 15 u suffit |
| 2 | Le pont | **A** | 100 u | — |
| 3 | Le demi-tour | **A** | 111 u | — |
| 4 | Le relais | **A** | — | — |
| 5 | La douceur | **C** | 17 u | un trait de 17 u suffit; pas de fiche |
| 6 | Le fil | **C** | 138 u | contrôle énigme ✗; pas de fiche |
| 7 | Économie | **C** | 15 u | un trait de 15 u suffit; pas de fiche |
| 8 | La portée | **C** | 121 u | contrôle énigme ✗; pas de fiche |
| 9 | Le détour | **C** | 97 u | un trait de 97 u suffit; contrôle énigme ✗; pas de fiche |
| 10 | Le plafond | **A** | — | — |
| 11 | Le relais | **C** | — | mur dans la zone; pas de fiche |
| 12 | L’établi | **A** | — | — |

### Monde 2 — Fonderie

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 13 | Le trampoline | **C** | 28 u | un trait de 28 u suffit; contrôle énigme ✗; pas de fiche |
| 14 | Le ricochet | **A** | 51 u | — |
| 15 | La montée | **A** | — | — |
| 16 | La hauteur juste | **C** | 50 u | un trait de 50 u suffit; contrôle énigme ✗; pas de fiche |
| 17 | Sol brûlant | **C** | 39 u | un trait de 39 u suffit; contrôle énigme ✗; pas de fiche |
| 18 | Ta plaque | **C** | — | contrôle énigme ✗; pas de fiche |
| 19 | Le four | **D** | 47 u | un trait de 47 u suffit; aucune solution enregistrée; pas de fiche |
| 20 | Le tremplin | **A** | 87 u | — |
| 21 | Le grand retour | **C** | 164 u | mur dans la zone; pas de fiche |
| 22 | Double rebond | **C** | 17 u | un trait de 17 u suffit; pas de fiche |
| 23 | L’élan d’abord | **C** | 62 u | un trait de 62 u suffit; pas de fiche |
| 24 | La fonte | **C** | 30 u | un trait de 30 u suffit |

### Monde 3 — Chaîne

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 25 | Le tapis | **A** | — | — |
| 26 | Sens inverse | **C** | 35 u | un trait de 35 u suffit; contrôle énigme ✗; pas de fiche |
| 27 | Tapis et butée | **C** | 21 u | un trait de 21 u suffit; contrôle énigme ✗; pas de fiche |
| 28 | Le plafond bas | **C** | 19 u | un trait de 19 u suffit; contrôle énigme ✗; pas de fiche |
| 29 | Ton élan | **C** | 70 u | un trait de 70 u suffit; ligne directe gagnante (7); contrôle énigme ✗; pas de fiche |
| 30 | Saut de chaîne | **C** | 106 u | contrôle énigme ✗; pas de fiche |
| 31 | Tapis et lames | **C** | 55 u | un trait de 55 u suffit; contrôle énigme ✗; pas de fiche |
| 32 | Deux tapis | **C** | 114 u | contrôle énigme ✗; pas de fiche |
| 33 | Chaîne montante | **C** | — | contrôle énigme ✗; pas de fiche |
| 34 | Relais d’élan | **C** | 176 u | ligne directe gagnante (2); mur dans la zone; contrôle énigme ✗; pas de fiche |
| 35 | Le tri des tapis | **C** | — | ligne directe gagnante (4); contrôle énigme ✗; pas de fiche |
| 36 | La chaîne complète | **C** | 75 u | un trait de 75 u suffit; contrôle énigme ✗; pas de fiche |

### Monde 4 — Glacier

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 37 | Le lac | **A** | 53 u | — |
| 38 | Trop vite | **C** | 47 u | contrôle énigme ✗; pas de fiche |
| 39 | Le saut | **A** | 103 u | — |
| 40 | Le demi‑tour | **A** | 193 u | — |
| 41 | Glace interdite | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée; pas de fiche |
| 42 | La butée | **C** | 36 u | un trait de 36 u suffit; pas de fiche |
| 43 | Deux étages | **C** | 40 u | un trait de 40 u suffit; pas de fiche |
| 44 | La patinoire | **A** | — | — |
| 45 | Le passage gardé | **C** | 9 u | un trait de 9 u suffit |
| 46 | Verglas | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée; pas de fiche |
| 47 | La crevasse double | **A** | — | — |
| 48 | Le sérac | **A** | — | — |

### Monde 5 — Soufflerie

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 49 | Le souffle | **C** | 85 u | contrôle énigme ✗; pas de fiche |
| 50 | Vent de face | **C** | — | mécanique inutile; contrôle énigme ✗; pas de fiche |
| 51 | Vent descendant | **A** | 137 u | — |
| 52 | Colonne étroite | **D** | 196 u | aucune solution enregistrée; pas de fiche |
| 53 | Deux colonnes | **D** | 135 u | aucune solution enregistrée; pas de fiche |
| 54 | Vent et plafond | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée; pas de fiche |
| 55 | Vent et lame | **D** | 106 u | aucune solution enregistrée; pas de fiche |
| 56 | Contre-courant | **D** | — | aucune solution enregistrée; pas de fiche |
| 57 | La rafale | **D** | 140 u | aucune solution enregistrée; pas de fiche |
| 58 | Le tunnel | **D** | 42 u | un trait de 42 u suffit; aucune solution enregistrée; pas de fiche |
| 59 | La tempête | **D** | 44 u | un trait de 44 u suffit; aucune solution enregistrée; pas de fiche |
| 60 | La veine | **D** | 149 u | aucune solution enregistrée; pas de fiche |

### Monde 6 — Mécanique

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 61 | Le piston | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée; pas de fiche |
| 62 | La navette | **D** | 110 u | aucune solution enregistrée; pas de fiche |
| 63 | Piston bas | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée; pas de fiche |
| 64 | Deux pistons | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée; pas de fiche |
| 65 | Le pendule | **D** | 28 u | un trait de 28 u suffit; aucune solution enregistrée; pas de fiche |
| 66 | Va-et-vient | **D** | 15 u | un trait de 15 u suffit; aucune solution enregistrée; pas de fiche |
| 67 | Métronome | **D** | 33 u | un trait de 33 u suffit; aucune solution enregistrée; pas de fiche |
| 68 | L’engrenage | **D** | 160 u | aucune solution enregistrée; pas de fiche |
| 69 | Cadence double | **D** | 82 u | un trait de 82 u suffit; aucune solution enregistrée; pas de fiche |
| 70 | L’horloge | **D** | 35 u | un trait de 35 u suffit; aucune solution enregistrée; pas de fiche |
| 71 | Atelier mobile | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée; pas de fiche |
| 72 | Le régulateur | **C** | 11 u | un trait de 11 u suffit; pas de fiche |

### Monde 7 — Gravité

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 73 | Tomber vers le haut | **A** | 113 u | — |
| 74 | Gravité lourde | **A** | 96 u | — |
| 75 | Le manège inversé | **A** | — | — |
| 76 | Le champ de travers | **A** | — | — |
| 77 | Deux champs | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée; pas de fiche |
| 78 | Champ et mur | **D** | 22 u | un trait de 22 u suffit; aucune solution enregistrée; pas de fiche |
| 79 | Ascension | **D** | 10 u | un trait de 10 u suffit; aucune solution enregistrée; pas de fiche |
| 80 | Champ et lame | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée; pas de fiche |
| 81 | Bascule | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée; pas de fiche |
| 82 | Apesanteur | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée; pas de fiche |
| 83 | Le puits | **D** | 60 u | un trait de 60 u suffit; aucune solution enregistrée; pas de fiche |
| 84 | Le pèse-matière | **D** | 96 u | un trait de 96 u suffit; aucune solution enregistrée; pas de fiche |

### Monde 8 — Magnétisme

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 85 | L’aimant | **D** | 48 u | aucune solution enregistrée; pas de fiche |
| 86 | Aimant fort | **D** | 84 u | aucune solution enregistrée; pas de fiche |
| 87 | Aimant haut | **D** | 44 u | aucune solution enregistrée; pas de fiche |
| 88 | Deux aimants | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée; pas de fiche |
| 89 | Aimant et mur | **D** | 47 u | un trait de 47 u suffit; aucune solution enregistrée; pas de fiche |
| 90 | Le couloir | **D** | 78 u | un trait de 78 u suffit; aucune solution enregistrée; pas de fiche |
| 91 | Aimant et lame | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée; pas de fiche |
| 92 | Slalom | **D** | 30 u | un trait de 30 u suffit; aucune solution enregistrée; pas de fiche |
| 93 | Orbite | **D** | 104 u | un trait de 104 u suffit; aucune solution enregistrée; pas de fiche |
| 94 | Champ magnétique | **D** | 22 u | un trait de 22 u suffit; aucune solution enregistrée; pas de fiche |
| 95 | La capture | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée; pas de fiche |
| 96 | Le solénoïde | **D** | 202 u | aucune solution enregistrée; pas de fiche |

### Monde 9 — Faille

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 97 | Le portail | **D** | 40 u | aucune solution enregistrée; pas de fiche |
| 98 | Portail court | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée; pas de fiche |
| 99 | Portail montant | **D** | 18 u | un trait de 18 u suffit; aucune solution enregistrée; pas de fiche |
| 100 | Portail et mur | **D** | 35 u | un trait de 35 u suffit; aucune solution enregistrée; pas de fiche |
| 101 | Deux failles | **D** | 39 u | un trait de 39 u suffit; aucune solution enregistrée; pas de fiche |
| 102 | Portail et vent | **C** | 18 u | un trait de 18 u suffit; mécanique inutile; pas de fiche |
| 103 | Portail et lame | **D** | 39 u | un trait de 39 u suffit; aucune solution enregistrée; pas de fiche |
| 104 | Boucle | **D** | 173 u | aucune solution enregistrée; pas de fiche |
| 105 | Aller-retour | **C** | 100 u | un trait de 100 u suffit; mécanique inutile; pas de fiche |
| 106 | Faille interdite | **D** | 38 u | un trait de 38 u suffit; aucune solution enregistrée; pas de fiche |
| 107 | Le pli | **D** | 38 u | un trait de 38 u suffit; aucune solution enregistrée; pas de fiche |
| 108 | La singularité | **D** | — | aucune solution enregistrée; pas de fiche |

### Monde 10 — Filaments

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 109 | La corde | **D** | 42 u | aucune solution enregistrée; pas de fiche |
| 110 | Corde tendue | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée; pas de fiche |
| 111 | Le hamac | **D** | 131 u | aucune solution enregistrée; pas de fiche |
| 112 | Corde et plaque | **D** | 133 u | aucune solution enregistrée; pas de fiche |
| 113 | La balle molle | **D** | 118 u | aucune solution enregistrée; pas de fiche |
| 114 | Molle et mince | **C** | 91 u | pas de fiche |
| 115 | Molle et pente | **C** | 13 u | un trait de 13 u suffit; ligne directe gagnante (3); pas de fiche |
| 116 | Molle et lame | **D** | 186 u | aucune solution enregistrée; pas de fiche |
| 117 | Deux cordes | **D** | 125 u | aucune solution enregistrée; pas de fiche |
| 118 | Le filet | **D** | 138 u | aucune solution enregistrée; pas de fiche |
| 119 | Corde et colonne | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée; pas de fiche |
| 120 | Opus | **D** | 77 u | un trait de 77 u suffit; aucune solution enregistrée; pas de fiche |

### Monde 11 — Quantique

| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |
|---|---|---|---|---|
| 121 | Le lien | **C** | — | mécanique inutile; pas de fiche |
| 122 | Opposition | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée; pas de fiche |
| 123 | La mesure | **D** | 11 u | un trait de 11 u suffit; aucune solution enregistrée; pas de fiche |
| 124 | Deux possibles | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée; pas de fiche |
| 125 | Le temps ralenti | **D** | 11 u | un trait de 11 u suffit; aucune solution enregistrée; pas de fiche |
| 126 | Lien et porte | **D** | 12 u | un trait de 12 u suffit; aucune solution enregistrée; pas de fiche |
| 127 | Intrication double | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée; pas de fiche |
| 128 | Mesure tardive | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée; pas de fiche |
| 129 | Temps et rebond | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée; pas de fiche |
| 130 | Le choix | **D** | 28 u | un trait de 28 u suffit; aucune solution enregistrée; pas de fiche |
| 131 | Machine quantique | **D** | 50 u | un trait de 50 u suffit; aucune solution enregistrée; pas de fiche |
| 132 | Quantix | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée; pas de fiche |
