# Audit de l'interface (R187, 12 octobre 2026)

> **Statut R209 : référence (R187).** Voir `INDEX_DOCUMENTS.md`.


*Visible dans le banc des rendus (« Audit · interface » et maquette « Accueil · héros et menus en Visière »). Rien de cette
refonte n'est dans le jeu ; seul le didacticiel Visière adaptative y est (R186).*

## Mesures (build R186)
- 2 langages visuels : Visière (didacticiel) et panneaux opaques arrondis + gélules pleines (tout le reste).
- 11 rayons d'angle, 22 tailles de texte (8 à 28 px), 72 couleurs hexadécimales pour 11 jetons, 33 styles en ligne dans index.html.

## Constats
1. Accueil : héros = vignette encadrée (balle qui rebondit sur deux traits) ; ne montre ni le geste, ni le bassin, ni le noyau.
   Quatre gélules de même largeur ; « Jouer » ne dit pas où l'on en est.
2. Pause, Constellation, Explications, Paramètres : panneaux opaques et piles de gélules ; explications = une boîte colorée par entrée.
3. Paramètres : diagnostics audio (moteur, session iOS, navigateur, échantillons) montrés au joueur ; bouton de curseur orange
   (couleur du rebond) ; langue et effacement en boutons bordés en ligne.
4. Quantone : deux titres empilés ; onglets et instruments en boîtes ; barre d'outils (Draw, Line, Eraser, Move, Duplicate,
   Shape) différente du jeu (libellés, ordre) ; langue prise au navigateur quand la page parente n'est pas lisible
   (aperçu, fichier local) → anglais dans un jeu français.
5. Barre d'outils du jeu : la partie la plus juste ; base à étendre à Quantone.

## Proposition : une seule langue, la Visière
1. Surfaces : voile radial + quatre croix de repérage ; plus de panneau opaque.
2. Actions : une gélule de lumière par écran (Continuer, Compris) ; le reste en lignes de lumière (icône au trait, chevron).
3. Texte : titres dédoublés cyan/violet ; étiquettes et chiffres en chasse fixe ; 7 tailles (8,5 · 11,5 · 13,5 · 15 · 17 · 21 · 34).
4. Rayons : 3 (gélule 999 px, vignette 10 px, ligne 0).
5. Mouvement : ouverture depuis une ligne de lumière, fermeture sur elle.
6. Héros : la boucle du jeu en 9 s (tracer, lâcher, noyau, bassin) avec VX.stroke / VX.ball / VX.core ; la devise s'allume
   mot à mot (Dessine / Expérimente / Maîtrise) ; reflet sur le nom à la réussite ; 3 tracés ; le trait se défait en sable.
7. Menu d'accueil : « Continuer » + monde, niveau et nom ; Constellation, Quantone, Paramètres en lignes ; progression en chasse fixe.
8. Quantone : un seul en-tête ; langue transmise par le jeu ; même barre d'outils (icônes, mots FR, ordre) + Dupliquer et Forme.
9. Paramètres : groupes Son, Affichage, Aide et langue, Progression ; curseurs et interrupteurs fins aux couleurs de
   l'interface ; diagnostics repliés sous « Infos techniques ».

## Source
`studio/galerie-interface.html` (injectée par `tools/build-galerie.py`, marqueur `__HOLO__`), captures `studio/captures/ui_*.jpg`.
