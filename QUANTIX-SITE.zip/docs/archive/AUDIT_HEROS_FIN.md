# AUDIT — pourquoi le héros d'accueil lit mieux que la célébration finale (R210)

Source : lecture de `hero.js` (`Z`, `deco`, `frame`, `epilogue`, `ZR`) et de `studio/fin2.js`. Constat par lecture du code et des captures du banc ; rien n'est mesuré sur iPhone.

## Ce que fait le héros (et que la fin ne fait pas)
1. **Un seul acteur, toujours à la même taille.** La bille garde son rayon R, la caméra la suit (zoom 1, ou 1,12 en « pouvoir »). Tout déplacement latéral se lit comme un déplacement : le fond bouge, la bille non.
   Dans la fin, la bille D est reculée en profondeur : son échelle varie avec la distance, donc un déplacement latéral est lu comme « elle rétrécit ».
2. **Chaque segment finit sur un événement.** 12 scènes, 1 à 5 événements chacune (`hit`, `boost`, `warp`, `freeze`, `collapse`) : `VX.impact` (poussière, arcs, onde), onde double additive, écrasement (`sq`), secousse (`shake`), arrêt sur image (`hold`), éclats (`burst`). Le mouvement est ponctué ; l'œil sait où regarder.
   Dans la fin, la bille D n'a presque aucun événement propre (le plan arrière n'a que `EP.pD`, rarement déclenché).
3. **La vitesse se lit par la traîne.** 26 points, largeur proportionnelle à l'âge, additive, couleur du monde. La longueur de la traîne EST la vitesse.
   Dans la fin, `gTrail` de D est courte, fine, et passée au flou/alpha du plan : elle disparaît.
4. **La vitesse varie, avec des accélérations nommées** (`'in'`, `'out'`, `'io'`, `'loop'`) : départ lent, bond, chute, sortie. Le « pouvoir » ajoute double image + anneau qui pulse.
   Dans la fin, D suit des courbes longues à vitesse presque constante : rien ne dit « elle accélère ».
5. **Le décor est l'obstacle, à l'échelle 1, net, avec un fond-illustration du monde en parallaxe (18 %).** Un monde = une couleur = un fond.
   Dans la fin, deux plans de profondeur + bokeh + roulis dégradent la netteté des deux.
6. **Une seule histoire à la fois.** ~1,7 s par scène, une attention.
   Dans la fin, deux histoires parallèles se disputent le regard.
7. **Caméra simple** : suit la bille, amortie, roulis unique (monde 7, un demi-tour). La fin cumule zoom, roulis, ancre moyennée, mise au point, décalages.

## Diagnostic
Le héros est lisible parce qu'il est **un seul acteur net, suivi, ponctué d'impacts, avec une traîne qui dit la vitesse**. La fin brise ces quatre règles : deux acteurs, l'un en profondeur (échelle variable), peu d'impacts sur D, traînée écrasée par le flou, caméra trop composée.

## Règles à reprendre dans la refonte (propositions)
- R1 Rayon de bille constant à l'écran pour les deux billes ; la profondeur se dit par le DÉCOR (échelle, flou, teinte), jamais par la bille.
- R2 Les deux billes ont la traîne du héros (26 points, additive), allongée avec la vitesse ; D a de plus des traits d'accélération (stries dans l'axe du mouvement) et un éclair court au départ de chaque segment rapide.
- R3 Chaque obstacle traversé se termine par un événement visible (impact, onde, écrasement) pour chaque bille.
- R4 Départ COMMUN : les deux billes sont une seule paire (double image du « pouvoir »), la caméra suit la paire.
- R5 La séparation de plans se joue en un seul endroit (Fonderie), puis chaque bille a SON obstacle ; les décors des deux plans partagent palette, grain et fond du monde (harmonie).
- R6 Une seule transformation de caméra à la fois (large → zoom → retournement → chute), jamais deux.
