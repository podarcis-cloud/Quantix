# QUANTIX — Fin « deux billes » (R211, banc)

*Statut : EN VALIDATION dans le banc de la fin ; rien dans le jeu. Remplace la version R210 (deux plans dès l'acte 1, compagne en profondeur dès le départ), jugée illisible par Simon (déplacements latéraux de la 2ᵉ bille pris pour un rétrécissement, pas de traînée ni d'effet de mouvement).*

## Demande (15 oct.)
Les deux billes commencent le parcours ensemble ; la différenciation de plan se fait à la Fonderie, ramenée vers la moitié de l'animation ; chaque bille parcourt un obstacle propre, les obstacles sont graphiquement harmonieux ; qualité professionnelle (« rendu Pixar »), tout dynamique et cohérent. D'abord un audit du héros : `AUDIT_HEROS_FIN.md`.

## Scénario (≈ 22,9 s de poursuite en temps réel, puis fusion 2,3 s et danse)
| # | Acte | Quoi | Camera |
|---|------|------|--------|
| 0 | Départ (bassin) | le couple sort du bassin | large → plan moyen |
| 1 | Quantique | le couple traverse | calme |
| 2 | Faille | plongée par la couture, réapparition en haut | recul pendant la plongée |
| 3 | Mécanique | le balancier frappe le couple : arrêt sur image, écrasement, onde | zoom d'impact |
| 4 | Magnétisme | spirale, le couple s'écarte | gros plan → large |
| 5 | **Fonderie (mi-parcours)** | le couple se resserre et tourne de plus en plus vite, ralenti, éclat, puis se sépare : l'une plonge, l'autre monte | poussée → recul |
| 6 | Gravité \| Glacier | plan large avec les deux obstacles ; la caméra avance vers l'arrière-plan en traversant l'avant-plan (la bille de devant passe en grand disque flou) ; zoom sur la bille du Glacier ; roulis jusqu'à l'envers | dolly + rack focus + roulis |
| 7 | Chaîne | chute (roulis jusqu'au tour complet), les plans se confondent, elles se tressent sur l'accélérateur | zoom arrière avec l'accélération |
| 8 | Atelier | elles se rejoignent, double hélice, remontée | zoom lent |
| – | Fusion, danse | inchangées (R208) | |

Obstacles harmonieux : Gravité (violet-bleu) devant, Glacier (cyan froid) derrière, teinte commune sur le plan arrière.

## Règles tirées de l'audit du héros
Rayon de bille quasi constant à l'écran (profondeur par le décor) · traînée en ruban (22 points, 20 ms) · traits de vitesse et éclairs au-delà de ~0,5 px/ms · étirement le long du mouvement, écrasement au choc · un choc visible par obstacle (éclat, anneau, rayons, secousse, flash) · arrêts sur image (110, 100, 90 ms) et ralentis aux instants forts · une seule transformation de caméra à la fois · léger roulis dans les virages · lueur douce.

## Modèle
Couple : chaque bille = trajet + (−/+) ρ·sin φ·n (n = normale lissée du trajet) ; ρ et la vitesse angulaire sont des courbes du temps ; la bille « devant » (cos φ) se dessine en dernier et grossit de 12 %. Après la séparation, deux plans F et D (k = s0·zoom / (1 + 0,5·(profondeur − mise au point))). Le tout est une fonction pure du temps (temps de film ≠ temps réel à cause des arrêts et ralentis ; les chocs, eux, vivent en temps réel).

## Fichiers
`studio/fin3.js` (chorégraphie), `studio/banc-fin.tpl.html` (interface), `tools/build-banc-fin.py` (assemblage ; remplace aussi à la volée le rectangle de lueur de la glace), `docs/AUDIT_HEROS_FIN.md`. `studio/fin2.js` = version R210, gardée pour mémoire.

## À trancher / limites
- Ordre des mondes modifié (bassin, Quantique, Faille, Mécanique, Magnétisme, Fonderie, Gravité|Glacier, Chaîne, Atelier) ; Filaments, Soufflerie et le reste du retour ne sont plus visités.
- Coût : lueur et calques de plan à vérifier sur iPhone ; la lueur est coupable en premier si ça rame.
- Intégration dans `hero.js` seulement après validation de Simon.
