# QUANTIX — Méthode de travail (R209, 15 octobre 2026)

> **Statut R209 : en vigueur.** Remplace la version R122. Le pourquoi : `AUDIT_R209.md` §17 (et `AUDIT_METHODE.md`,
> historique). Les exigences de Simon : `CHARTE_EXIGENCES.md`. Une règle nouvelle remplace une ligne de ce document.

---

## 1. Le but

Un jeu publiable, beau et intelligent : chaque niveau porte **une idée** (ce que le joueur croit, ce qu'il découvre, le
geste qui en découle), chaque monde a **deux machines** spectaculaires (6 et 12) faites de ses éléments, une **identité
visuelle animée** et une **musique**. Simon juge à l'œil, sur iPhone. Les outils servent à ne rien casser.

## 2. Démarrer une conversation (≈ 15 minutes de lecture)

1. `REPRISE-SESSION.md` en entier : bloc « ÉTAT » en tête, prochain lot, décisions attendues, commandes, pièges.
2. `CHARTE_EXIGENCES.md` (ne se rediscute pas) et `LEXIQUE.md` (nos mots).
3. Le zip `QUANTIX-SITE.zip` joint par Simon (ou le dépôt GitHub s'il est connecté) : `unzip -q QUANTIX-SITE.zip -d site/q`.
   Sans zip, le demander avant de toucher au code. Le kit de reprise `docs/` du zip contient tous les documents du Projet.
4. Vérifier que le socle est vert : `cd site/q/tools && for t in audit strict tutotest monde1 monde2 render replaytest; do node $t.js | tail -1; done`.

## 3. Le lot

Un lot = **un monde** (refonte de niveaux) **ou une fonction** (rendu, son, interface). Il s'annonce en une phrase.

### 3.1 Un niveau

1. **Fiche** (trois lignes, dans `tools/fiches/N.js` ou en tête du message à Simon) : *le joueur croit… / il découvre… /
   le geste*. Plus : l'expérience évoquée, la mécanique indispensable, le leurre, la place dans le monde.
2. **Construction** : géométrie dans `levels.js` (correctifs comptés), courbes avec `tools/rail.js`, machines à partir de
   `tools/forge.json` ; si Simon a dessiné dans l'éditeur, partir de son dessin (lire la base `niveaux`, document `Q-MM-PP`).
3. **Preuve en une commande** : `python3 tools/preuve.py N` → référence gagne, à vide échoue, zone propre, pas de zone
   invisible, mécanique indispensable (`bypass.js n=N`), traits droits « nus » (`contournements.js N N`).
   Puis, une fois : `node tools/difficulty.js N` (P_exec ≥ 70 % au modèle éditeur), noyau.
4. **Capture regardée** (Playwright) ; puis, en fin de monde, `node tools/mondeN.js` (à créer pour 6 à 11 sur le modèle de
   `monde2.js`) et `replaytest.js`.

**« Fini »** = fiche + les six lignes de `preuve.py` à OK + P_exec ≥ 70 % + capture regardée + validé par Simon sur iPhone.

### 3.2 Un rendu

Banc des rendus d'abord (`studio/galerie-*.html`, `python3 tools/build-galerie.py`), validation de Simon, puis intégration
dans `visuals.js` / `hero.js` / `quantix.css` (nouveau bloc daté en fin de fichier, à résorber lors de la refonte CSS).

### 3.3 Un son

Méthode W1N (`SON_MONDES.md`) : l'expérience du monde → des formules → des textures ; mesurer crête, RMS et part de silence
avec `Audio1._render` ; rendus d'écoute envoyés en fichier.

## 4. Budget et arrêt

- **Deux essais par problème**, puis montrer l'état et deux options.
- **Ne jamais abandonner une idée** après un long travail : élargir la palette (moteur, élément, géométrie, combinaison).
- Une commande < 280 s, un niveau par commande, aucun calcul parallèle ni en arrière-plan.
- Pas de recherche automatique longue sans l'annoncer ; sorties filtrées.

## 5. Livrer

1. Tests : audit, strict, tutotest, render, replaytest, savetest, maptest, `mondeN` des mondes touchés ; e2e (didacticiel,
   éditeur, Quantone) si l'interface change.
2. **Tampon neuf** : `index.html` (`#buildTag`, « build R### · intitulé ») et `engine.js` (console « QUANTIX build R### · »).
3. **Zip** : `cd site/q && zip -qr /mnt/user-data/outputs/QUANTIX-SITE.zip . -x '*.pyc' -x '__pycache__/*' -x '.git/*'`,
   vérifier le tampon dans le zip, envoyer le fichier.
4. **Aperçu** : `python3 tools/build-apercu.py N [U] [skipintro] [home] [fin]` → publier
   `quantix-apercu-mondeN.html` à l'adresse de l'aperçu ; dire ce qu'il montre.
   Éditeur de niveaux : aperçu `1 11 skipintro` + `studio/editeur-niveaux.js` injecté avant `</body>` (voir REPRISE §6).
5. **Documents** : `REPRISE-SESSION.md` (bloc ÉTAT réécrit, entrée de journal ajoutée), autres documents touchés ; les
   envoyer au Projet (`project_write`) et dire lesquels ont changé.
6. **Liens** en clair à la fin de chaque réponse (Menu édition, Aperçu, Éditeur, Banc des rendus, Quantone).

## 6. Règles techniques

- Correctifs comptés (OK / ÉCHEC) ; jamais de réécriture complète d'un fichier de code.
- Chemins relatifs ; monde 360 × 480 ; aucun texte visible hors de `i18n.js` (FR + EN).
- `node -e` : jamais de variable `L`, `S`, `T` ; identifiant libre vérifié avant introduction.
- Publications d'artefacts : le moins possible (une autorisation chacune) ; un fichier envoyé n'en demande pas.

## 7. La bibliothèque

Voir `INDEX_DOCUMENTS.md` : quoi lire, quand, et ce qui est historique.
