# FINALE R213 — la fin refaite sur le modèle du héros (remplace FINALE_FIL / FIN_DEUX_PLANS)

Statut : dans le banc seulement (`studio/fin5.js`), le jeu n'est pas modifié. À valider par Simon avant intégration dans `hero.js`.

## Ce qui a été rejeté (retours de Simon, 15 oct.)
Fil entre les particules, plans de profondeur, tressage systématique, bascules de caméra gratuites, ralentis incohérents, décors qui ne sont pas ceux du héros, traînée étrangère, pas de gravité sentie, thèmes des mondes méconnaissables, structure finale sans sens.

## Analyse du rythme du héros (à retenir)
- Une scène par monde, 1,3–2,9 s ; un acteur net ; chaque obstacle finit sur un événement (choc, passage, mise en orbite).
- Vitesses variées mais jamais nulles : entrée = sortie de la scène précédente (+360 px), pas d'arrêt.
- Physique réelle (chute, rebond avec restitution, roulement, ressort de la corde, champ de puits) ; libération (vol, spirale, orbite) seulement à des moments choisis.
- Décor = fond du monde + éléments du jeu dessinés par `VX` ; traînée courte, effilée, additive.

## Méthode R213
1. Le film est une chaîne de 12 scènes écrites une à une (coupe → Atelier), chacune avec ses surfaces, ses champs et ses événements.
2. Physique : `sim()` au pas de 1 ms (g, rebonds, roulement, ressorts, champs) ; `Path` assemble : kick, run, glide (Hermite), orbit, loopPath.
3. Chaînage : sortie de la scène n = entrée de n+1 ; vitesses recopiées ; décalage A/B plafonné à 220 ms (`sync` pour égaliser) ; rien ne démarre à l'arrêt.
4. Rendu : `drawWorldBg` + décors par monde (`DECO[w]`) + `VX.impacts` + traînée `trail5` (distance plafonnée, effilée) + traits de vitesse + écrasement ; caméra qui suit sans roulis.
5. Départ : la bille seule dans la coupe du dernier niveau ; le module de division (Quantique) la sépare ; la seconde bille naît à B0. Aucun fil.
6. Fin : plongée dans le vortex puis atome (11 orbites, paire, titre).
7. Preuve : `node w5/h.js` (tableau de la chaîne : entrées, sorties, vitesses), planches de captures, absence d'erreur console.

## État (chaîne propre)
S11 1509 ms · S10 1563 · S9 1566 · S8 1296 · S7 2394 · S6 1461 · S5 1556 · S4 2432 · S3 1045 · S2 2004 · S1 1828 · S0 2186 ; entrées toutes à x≈358, sorties à x≈−2.

## Retours du 15 oct. 21:40 → v2
- Magnétisme refait : cyclotron (deux dees, fente à champ alterné, ω constant, rayon qui croît à chaque traversée ; A et B tournent en sens opposés, instants de sortie différents).
- Glacier : vasque de glace + vortex de cristaux, trois membranes poreuses, entrée en plongée tangentielle puis remontée sur la lèvre.
- Plus de décalage entre les billes (écart plafonné 330 ms au lieu de 220), chocs plus nets (secousse et zoom proportionnels à l'impact), traits de vitesse plein écran.
- Fin : la sphère de danse est LA ORIGINALE du héros (`epDance`, intouchée) ; seule la transition est refaite : l'hélice accélère, plongée en spirale serrée dans le vortex, éclat, puis la danse.

## v3–v5 (15 oct., 22 h → 23 h) — retours de Simon et captures annotées
- **Banc** : ligne du temps agrandie, pas fins (±1 s, ±0,1 s), bouton Capturer (image figée, crayon, cercle, texte, 4 couleurs, annuler, note) ; envoi dans la base du banc (collection `captures` : t, act, note, asset) lue par Claude via ArtifactData ; images lues avec Artifact read `path=<id>`. Repli : télécharger.
- **Magnétisme** : trois temps — rayon qui croît à la fente (2,5 tours), plateau, spirale d'effondrement (ω croissant) ; collision au centre (arrêt 70 ms, flash, onde, secousse), éjection vers Gravité. Caméra ×1,42. 4,3 s.
- **Glacier** (niveau 6 « La piste glacée ») : rail de montagnes russes (deux rails, traverses, pylônes) avec boucle qui se croise ; zone poreuse = rails dissous en pointillés ; vitesse par conservation de l'énergie ; vortex de glace qui s'emballe au passage. Caméra ×1,35.
- **Chaîne → Fonderie** : la rampe se termine par un saut balistique (plus de glissade) ; chaque plaque de la Fonderie est posée là où le vol précédent retombe (la première inclinée dans le sens de la vitesse). Piques rouges au sol (fondu aux bords). Caméra ×1,28 dans la boucle.
- **Mécanique** : plaques déjà levées avant la première balle (montée 460 ms, 820 ms avant le choc), tiges à double filet régulières, lueurs adoucies.
- **Fin** : au bout du trait, spirale d'absorption (ω ∝ 1/r², 1,5 / 2 tours) jusqu'à l'ellipse du disque ; billes qui rétrécissent et disparaissent au centre avant l'éclat ; sphère de danse d'origine inchangée.
- **Bogue du banc corrigé** : le pré-déroulé de la danse appelait `epDance` avec de mauvais arguments → traînée à lignes droites après un déplacement sur la ligne du temps (capture « Danse 30,8 s »).
- Ordre de chaîne (ms) : S7 4323 · S6 1520 · S5 1563 · S4 2512 · S3 1469 · S2 1420 · S1 804 · S0 1838.

## Non vérifié
iPhone réel ; fluidité réelle ; jugement de l'œil. Fonderie très courte (0,8 s) ; réception du saut jugée sur captures seulement. Modules « Quantix 2 » pas encore faits.

## Ensuite
Retours de Simon → intégration dans `hero.js` (avec le correctif de lueur du Glacier `fillRect(0,250,360,260)`) → refonte des niveaux (Gravité 73–84 d'abord).

## v6 (15 oct. 2026) — reprise sur les 4 captures annotées
- Glacier : deux grands loopings (boucle verticale haute puis grand cercle), rails qui se croisent en zones poreuses (pointillés, anneaux), un événement « pass » par croisement ; caméra z 1,12.
- Mécanique : toutes les marches partent du sol et montent, durée proportionnelle à la hauteur, terminées juste après le choc (dépassement en ressort, plus fort pour la plus haute). Interprétation à confirmer : « la dernière » = la plus haute.
- Gravité : planète texturée (bandes de nuages qui défilent, tempête, terminateur), anneau avant/arrière, deux lunes, orbites pointillées, lignes de force avec grains qui tombent ; zone inversée en colonne douce à chevrons (plus de grille).
- Fonderie : rebonds ralentis (×1,75, sortie à vitesse inchangée → 1273 ms au lieu de 796), nappe de lave qui respire, jets là où une bille frappe.
- Mesures : jerk de zoom inchangé (max 0,042), perf ok, aucune erreur page. Non vérifié sur iPhone.

- Mécanique (suite) : « dernière » = dernière marche touchée (la plus basse) ; elle monte avec un fort dépassement et les billes en sont propulsées (kick) vers la Soufflerie ; scène 2036 ms.

- Glacier (capture « dans l axe de sortie ») : la fin du rail monte à gauche en courbe et les billes en sortent dans la tangente (vitesse suivant l axe, plus à plat) ; Chaîne reçoit le saut ; zoom inchangé.

- Chaîne : l accélérateur est réorienté dans l axe de sortie du Glacier (tapis incliné qui monte à gauche, boucle déplacée en haut à gauche, rampe + saut remontés de 90 px) ; scène 924 ms.
- Mécanique : la dernière marche touchée (la plus basse) donne un coup de piston (+46 px), colonne de lumière, anneaux, étincelles, et lance les billes (kick plus fort).

- Mécanique (capture annotée verte) : la dernière marche devient un pas de tir large ; piston, puis montée presque verticale à travers deux anneaux, arc vers la gauche (vitesse par l énergie) ; B part de la même marche.
- Magnétisme : rotation de caméra d un tour complet (même sens que l orbite, départ et arrivée à vitesse nulle, orientation finale identique) pendant la phase d orbite ; l arrière-plan reste fixe.

## v7 (16 oct. 2026) — six nouvelles captures
- Chaîne : arcs électriques le long du tapis (accélérateur), spirale d énergie autour des billes qui s y engagent, pylône à bobine en décor (ses arcs rejoignent le tapis au passage).
- Mécanique : les deux billes sont éjectées par la dernière marche (B attend A sur la marche), la marche monte de 96 px au lieu de 46.
- Glacier : entrée en S plus douce, boucle plus ronde.
- Gravité : refonte dans la charte du monde (R142) : grille de l espace-temps qui se creuse vers la masse et sous chaque bille, niveaux d énergie en ondes stationnaires, masse sombre granuleuse (plus de planète à anneau), débris en orbite képlérienne, zone inversée = composant du jeu (gzone).
- Fonderie : bain de lave (croûte, veines, bulles), piques en fer noir aux pointes chauffées, dalles d acier rivetées sur ressorts, étincelles aux chocs, jets de flamme réactifs, creuset suspendu qui verse du métal.
- Mesures : zoom max 0,042, perf ok, aucune erreur. Non vérifié sur iPhone.

## v7b — la ligne droite de la Danse
- Cause : dancePos mélange deux figures par interpolation linéaire puis normalisation ; quand les deux points sont antipodes la normalisation bascule (saut de 3 rad à t=3617 ms de danse, environ 27,3 s de film) : la bille saute de l autre côté de la sphère et la traînée trace une corde à travers le centre pendant ~0,5 s.
- Correctif (banc seulement, hero.js intact) : build-banc-fin.py remplace dancePos par studio de tools/dancepos_fix.js (interpolation courbe sans singularité), subdivise la traînée et le nuage de points quand l écart entre deux images est grand. À reporter dans hero.js à l intégration, avec la lueur du Glacier.
- Mesure : plus aucun saut supérieur à 0,2 rad par pas de 8 ms sur 30 s (avant : 1 saut de 3,03 rad).
