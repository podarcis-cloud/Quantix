# QUANTIX — Monde 3 « Chaîne » : 12 fiches de conception (niveaux 25–36)

25 oct. 2026 · concepteur d'énigmes · **aucune géométrie** : idées, raisonnements, leurres, rôles. L'ingénieur valide au banc.
Ne remplace rien : proposition à comparer à `tools/refonte/chaine.js` et à `REFONTE_MONDE3.md`.

## 0. Cadre commun (à lire avant les fiches)

**Grammaire du monde : la vitesse est une chose qu'on LIT, qu'on DOSE, qu'on REÇOIT et qu'on REND.**
- Ki (25–27) : on la reçoit (le ruban donne), on la dirige (le geste), on la lit (la couleur).
- Shō (28–30) : on la dose (la chute vaut mieux que le ruban ; le sas l'efface ; on la recharge en haut).
- Ten (31–33) : elle se retourne contre nous (le courant), la matière change de rôle (le mur), la lenteur porte (l'escalier).
- Ketsu (34–36) : on l'économise, on la séquence, on la rend (la finale finit à vitesse zéro, sur l'ambre).

**Trois faits du moteur qui structurent les fiches**
1. **Arriver = arriver lent.** La victoire exige la balle dans la zone à moins de 2,2 de vitesse pendant 17 trames
   (`engine.js`, test de zone). Une balle rapide traverse la zone sans gagner : c'est un échec lisible qu'on exploite
   (29, 32, 36). Corollaire : toute zone « dos au vide » ferme le raccourci « fonce dedans ».
2. **Le ruban tracé plafonne à 7,2** : il n'ajoute rien à une balle déjà rapide, et deux rubans à la suite au même niveau
   ne font pas plus qu'un (28, 30, 34).
3. **Un ruban à contre-sens ne freine pas finement : il renvoie** (constaté en R298). Deux bornes qui se renvoient la balle
   font une **prison** (oscillation sans fin). On s'en sert comme piège lisible (31, 35, 36) et comme « temps offert » (35).

**Langage visuel requis (contrainte pour tous les niveaux)**
- Code couleur des rubans v2 : **ambre = frein (0)**, **turquoise = lent (2)**, **violet = standard (7)**, **blanc-cyan = rapide (10)**.
  Le ruban tracé par le joueur est violet.
- Chevrons animés dans le sens de poussée, **qui s'allument seulement quand le ruban pousse** : sans ce retour, les
  leurres de 28, 30 et 34 (« le ruban ne fait rien ») ne sont pas lisibles. C'est la condition n°1 de ce monde.

**Hypothèses nouvelles introduites (à ajouter au registre de la Bible, IX.2)**
H19 « la balle avance d'elle-même sur un trait » · H21 « pour monter, il faut de la vitesse » · H22 « plus vite, c'est
toujours mieux » · H23 « l'élan se donne au départ » · H24 « un ruban est un sol qui pousse, rien d'autre » · H25 « un ruban
plus long pousse plus fort » · H26 « ce qui m'a aidé au début m'aidera encore ».

**Risque global G1 (à tester AVANT tout)** : un ruban tracé **incliné et posé en l'air** fait-il grimper la balle sans fin
(poussée 0,62 > composante de gravité 0,4·sin θ) ? Si oui, c'est un escalier universel qui ouvre tous les niveaux à palette
« élan » : l'encre doit alors interdire partout un ruban montant assez long pour atteindre la zone. Les fiches indiquent où.

---

## 25 · Le ruban
- **Temps** : Ki 1, Simple. Raison d'être : enseigner sans mots que le ruban donne une vitesse, et qu'une vitesse se change en hauteur.
- **Type** : CONVERTIR (découvrir).
- **Vérité** : le ruban donne de la vitesse, pas de la hauteur ; c'est un trait incliné qui change l'une en l'autre.
- **Phrase** : « Laisse le ruban lancer la balle ; ton trait relève sa course. »
- **Hypothèse** : H19 (la balle avance d'elle-même sur un trait).
- **Leurre** : une rampe tracée depuis la balle immobile jusqu'à la zone haute. Sur la rampe, la balle ne bouge pas : rien ne la pousse.
- **Scénario** : sans tracé, la balle tombe sur le ruban fixe, file et plonge dans le vide sous la zone (on voit la vitesse) ; il trace une rampe depuis le départ, la balle reste immobile ; il comprend que la vitesse vient du ruban et place le relèvement **à sa sortie**.
- **Éléments** : ruban fixe violet sous la chute (PORTER) ; vide sous la zone (PIÉGER : rend la vitesse visible au premier essai) ; zone haute adossée à un mur (PORTER : arrêt lent).
- **Raccourcis** : un pont plat vers la zone (fermé : la zone est plus haute que le ruban) ; un trait qui fait rouler la balle hors du ruban avant (fermé : la balle tombe d'en haut, droit sur le ruban).
- **Contraintes** : palette structure seule ; encre moyenne (un trait) ; pas de nd ; aucun v2. Zone à une hauteur que seul l'élan du ruban atteint.
- **Unique** : seul niveau où le ruban est **déjà là et juste** ; tout le reste du monde le discute.
- **Variante dure** : le ruban est court et la zone est loin : la sortie doit être une rampe longue et douce (pas un pic), sinon la balle monte à pic et retombe.

## 26 · Dans ton sens
- **Temps** : Ki 2, Simple. Raison d'être : le joueur trace son premier ruban ; le sens du geste est le sens de l'élan.
- **Type** : ORIENTER.
- **Vérité** : un ruban tracé pousse de son premier point vers son dernier.
- **Phrase** : « Trace le ruban vers la zone, pas vers ta main. »
- **Hypothèse** : H11 (le sens du tracé n'importe pas).
- **Leurre** : le geste d'habitude (de gauche à droite, pour un droitier) : la balle part vers la droite, à l'opposé de la zone.
- **Scénario** : il trace sous la balle « naturellement », la balle file vers les pointes de droite, chevrons visibles ; il comprend que le ruban a une direction et retrace dans l'autre sens.
- **Éléments** : balle posée à plat (PORTER : sans élan propre, seul le ruban la met en mouvement) ; pointes au bout du côté opposé à la zone (PIÉGER : rendent le mauvais sens fatal, donc lisible) ; zone de l'autre côté, adossée (PORTER).
- **Raccourcis** : un ruban vertical qui « pousse » la balle (fermé : encre pour un seul ruban court) ; G1, ruban montant direct (fermé : zone à la hauteur du sol).
- **Contraintes** : palette élan seule ; encre serrée (un ruban) ; pas de nd ; aucun v2. Le côté gauche (zone) doit être celui que le geste « naturel » ne vise pas.
- **Unique** : seul niveau dont la difficulté est le geste lui-même ; jamais repris tel quel.
- **Variante dure** : zone en haut à gauche ; il faut un ruban tracé de droite à gauche **et** vers le haut (sous réserve de G1).

## 27 · Trois couleurs
- **Temps** : Ki 3, **Relais / Machine-énigme** (révélation de la machine du monde : le rail coloré). Raison d'être : apprendre à lire la vitesse d'un ruban à sa couleur.
- **Type** : LIRE (anticiper par la couleur).
- **Vérité** : un ruban v2 impose sa vitesse ; la vitesse fait la portée.
- **Phrase** : « Choisis le couloir dont la couleur porte jusqu'au récepteur. »
- **Hypothèse** : H22 (plus vite, c'est toujours mieux).
- **Leurre** : le couloir blanc-cyan, le plus rapide (et celui que la balle prend sans tracé) : elle survole le récepteur et finit sur la paroi à pointes.
- **Scénario** : premier lancer, la balle prend le rapide et passe au-dessus ; il essaie le turquoise, elle tombe juste derrière la lèvre ; il comprend que la couleur **est** une distance et choisit le violet.
- **Éléments** : trois couloirs v2 (turquoise, violet, blanc-cyan) qui finissent sur la même lèvre (PORTER, et lecture) ; un aiguillage à tracer (le seul geste) ; paroi à pointes au-delà (PIÉGER : rend le « trop » lisible) ; vide avant le récepteur (PIÉGER : rend le « trop peu » lisible) ; récepteur puis machine (rail qui dépose dans la zone).
- **Raccourcis** : tracer un pont de la lèvre au récepteur (fermé : nd sur tout l'espace de vol) ; dévier la balle en vol (fermé : même nd).
- **Contraintes** : palette structure ; encre serrée (juste l'aiguillage) ; nd large sur la trajectoire ; **3 rubans v2 requis** ; couloirs larges (≥ 40 u), aiguillage tolérant.
- **Unique** : seul niveau où l'on choisit sans rien construire de porteur ; il installe le vocabulaire des couleurs pour 29, 33 et 36.
- **Variante dure** : quatre couloirs (ajout d'un ambre qui garde la balle à jamais) et récepteur placé entre deux portées, atteint seulement par le violet **après** un rebond sur la lèvre.

## 28 · La chute est un élan
- **Temps** : Shō 4, Simple. Raison d'être : combiner avec le monde 1 (le trait-pente) ; première fois que le ruban est le mauvais outil.
- **Type** : RÉCUPÉRER LA CHUTE (l'idée est de **ne pas** tracer de ruban).
- **Vérité** : le ruban plafonne ; une chute rattrapée en pente vaut plus que lui ; tomber à plat gaspille tout.
- **Phrase** : « Rattrape la balle en l'air ; sa chute te lance plus loin qu'un ruban. »
- **Hypothèse** : H12 (monter ou sauter loin exige une aide visible).
- **Leurre** : le ruban (offert, le monde le désigne) posé au sol sous la chute : la balle atterrit à plat, le ruban la relance à 7,2, elle tombe dans le vide **toujours au même point**, juste avant l'autre bord.
- **Scénario** : il trace un ruban, la balle saute court ; il l'allonge, elle saute pareil (chevrons éteints au-delà du plafond) ; il comprend que la vitesse est ailleurs : dans la hauteur de la chute, perdue en atterrissant à plat ; il trace une pente sous la chute.
- **Éléments** : départ très haut au-dessus d'un sol plat (PORTER la vitesse, PIÉGER : le sol plat l'efface) ; vide plus large que le saut d'un ruban (FERMER le ruban) ; zone de l'autre côté, adossée (PORTER : arrivée lente).
- **Raccourcis** : un ruban incliné qui rattrape la chute (même idée, acceptable ; l'encre le rend trop court, coût 1,7) ; G1, ruban montant (fermé : encre).
- **Contraintes** : palette structure + élan ; encre moyenne (une pente ≈ deux fois plus longue qu'un ruban possible) ; pas de nd ; aucun v2. Pente tolérante : toute inclinaison de 30 à 60° sous la colonne de chute réussit.
- **Unique** : seul niveau du monde résolu **sans ruban** ; il fait comprendre le plafond.
- **Variante dure** : la colonne de chute passe derrière un plafond bas : il faut rattraper la balle plus bas, donc plus vite, et la pente devient courte et raide.

## 29 · Le sas
- **Temps** : Shō 5, Simple. Raison d'être : combiner avec le monde 2 (rebond) ; première impasse sérieuse.
- **Type** : VISER LE SAS (oublier l'entrée).
- **Vérité** : un ruban lent efface la vitesse d'entrée : quoi qu'il reçoive, il rend 2 (et 2 < 2,2 : on gagne en roulant).
- **Phrase** : « Vise le ruban turquoise, pas la zone : il calme tout. »
- **Hypothèse** : H8 (il faut viser la zone).
- **Leurre** : la paroi rebond orientée pour envoyer la balle droit dans la zone : elle y entre à pleine vitesse, la zone s'allume et la balle ressort dans le vide.
- **Scénario** : il vise la zone, la balle la traverse ; il tente un rebond plus doux, impossible (le rebond rend toujours trop) ; il remarque que le turquoise mène à la zone et que tout ce qui le touche ralentit ; il vise le sas, « trop fort » ne compte plus.
- **Éléments** : chute au-dessus du vide (PIÉGER : oblige le rebond) ; ruban v2 turquoise qui conduit à la zone (PORTER) ; zone sans paroi du côté du vide (FERMER le tir direct) ; aucune pointe nécessaire.
- **Raccourcis** : coincer la balle contre un bord de zone (fermé : zone dos au vide) ; rebondir deux fois pour ralentir (fermé : encre pour une seule paroi).
- **Contraintes** : palette rebond seule ; encre serrée (une paroi) ; nd éventuel autour de la zone ; **ruban v2 lent requis**, assez long pour ramener 12 à 2 ; sas en gouttière pour garder la balle qui arrive de biais.
- **Unique** : seul niveau où la vitesse en trop n'est pas un problème : le sas la fait oublier ; seul usage du rebond dans le monde.
- **Variante dure** : un second ruban violet à côté du turquoise : viser au mauvais endroit relance la balle au lieu de la calmer (il faut lire la couleur sous le point d'impact).

## 30 · Le second souffle
- **Temps** : Shō 6, **Relais** (machine-récompense). Raison d'être : comprendre que l'élan se recharge, mais seulement là où la balle a ralenti.
- **Type** : RELAYER EN HAUT (recharger).
- **Vérité** : un ruban ne pousse que ce qui est lent : il faut dépenser l'élan en hauteur avant d'en recevoir un second.
- **Phrase** : « Le pont du haut doit être un ruban : c'est là qu'elle est lente. »
- **Hypothèse** : H23 (l'élan se donne au départ).
- **Leurre A** : un second ruban au sol, à la suite du ruban fixe : chevrons éteints (plafond), la balle monte la pente et tombe dans la brèche du haut. **Leurre B** : un pont de structure sur la brèche : elle passe, mais n'a plus de souffle pour le tremplin final et revient.
- **Scénario** : il double le ruban du bas, rien ne change ; il jette un pont, elle passe sans force ; il comprend que l'élan manque **en haut**, là où la balle est lente : le pont devient un ruban.
- **Éléments** : ruban fixe au sol, balle posée dessus (PORTER : premier élan) ; pente fixe qui monte (PORTER : convertit l'élan en hauteur) ; brèche au sommet (FERMER : oblige un trait en l'air, donc un ruban flottant, sans le problème du ruban collé à une surface) ; tremplin fixe vers le récepteur (PORTER) ; machine courte jusqu'à la zone.
- **Raccourcis** : un ruban montant du bas jusqu'au récepteur (G1 ; fermé : encre = longueur de la brèche) ; sauter la brèche avec un ruban du bas (fermé : plafond 7,2).
- **Contraintes** : palette structure + élan, **structure sélectionnée par défaut** ; encre : un trait de la longueur de la brèche, ruban compris ; pas de nd ; aucun v2 (sauf la machine).
- **Unique** : seul niveau où l'on trace un ruban **en hauteur, en guise de pont** ; il retourne l'hypothèse « l'élan au départ ».
- **Variante dure** : deux brèches étagées, une seule encre de ruban : seul le pont le plus haut doit être un ruban, l'autre de structure.

## 31 · Le courant
- **Temps** : Ten 7, Simple. **Retournement** : le ruban est contre le joueur.
- **Type** : COUVRIR (neutraliser).
- **Vérité** : un ruban n'agit qu'au contact ; un trait posé au-dessus l'éteint.
- **Phrase** : « Couvre le courant d'un ruban qui pousse dans l'autre sens. »
- **Hypothèse** : H5 (la mécanique du monde aide).
- **Leurre** : un mur-ruban dressé devant les pointes : la balle s'y écrase et reste plaquée par le courant, immobile, loin de la zone.
- **Scénario** : la balle tombe dans la tranchée et file aux pointes ; il dresse une butée, elle est plaquée ; il pose un ruban vers la gauche au bord de la tranchée, la balle ne l'atteint jamais ; il comprend qu'il faut que la balle **ne touche plus** le courant : il tend un ruban par-dessus la tranchée, vers la zone.
- **Éléments** : tranchée au fond tapissé d'un ruban v2 blanc-cyan vers les pointes (PIÉGER) ; pointes au bout (PIÉGER : rendent le courant fatal) ; tranchée plus profonde qu'un doigt n'est précis (FERMER le problème « trait coïncident » : tout couvercle est assez haut) ; zone sur une corniche adossée, de l'autre côté (PORTER).
- **Raccourcis** : rattraper la balle en l'air au-dessus de la tranchée (c'est l'idée) ; un ruban qui l'emmène ailleurs (fermé : un seul côté mène à la zone) ; G1 (fermé : encre = largeur de la tranchée).
- **Contraintes** : palette élan seule ; encre serrée ; nd au-dessus des pointes ; **ruban v2 rapide requis** au fond de la tranchée.
- **Unique** : seul niveau où un trait sert à **isoler** d'un ruban fixe ; le décor qui portait au 25 tue ici.
- **Variante dure** : le couvercle doit aussi relever la balle (zone plus haute) : il faut le tracer légèrement montant, ce qui exige d'avoir compris le 25 **et** le 26.

## 32 · Le ruban-mur
- **Temps** : Ten 8, Simple (la Machine-énigme du gabarit est placée au 27, voir §critique). Raison d'être : la matière change de rôle.
- **Type** : DÉTOURNER LA MATIÈRE (le ruban comme butée).
- **Vérité** : un ruban est d'abord un mur ; sa poussée ne compte que le long de lui.
- **Phrase** : « Dresse ton ruban debout : c'est un mur qui arrête la balle. »
- **Hypothèse** : H24 (un ruban est un sol qui pousse, rien d'autre ; parent de H1).
- **Leurre** : un ruban à plat dans la zone, à contre-sens, pour freiner : il freine puis **renvoie**, la balle ressort par où elle est venue.
- **Scénario** : la balle arrive vite et file dans le vide au-delà de la zone ; il pose un ruban contraire, elle repart en arrière ; il l'allonge, même chose ; il comprend que le ruban n'a pas à pousser : debout au bord du vide, c'est une butée ; la balle s'y arrête et tombe dans la zone.
- **Éléments** : ruban fixe violet qui amène la balle (PORTER : vitesse connue) ; zone ouverte sur le vide (FERMER : « elle s'arrêtera seule ») ; vide (PIÉGER) ; aucune structure dans la palette (FERMER le mur ordinaire, qui rendrait le niveau trivial).
- **Raccourcis** : doser un frein à contre-sens pour arriver lent (fermé : exigerait une longueur au millimètre, rejeté par la tolérance) ; ruban vertical dans les deux sens (les deux doivent réussir : le sens n'est pas l'énigme).
- **Contraintes** : palette élan seule ; encre serrée (un trait court, insuffisant pour un frein long) ; nd au-dessus du vide au-delà de la butée ; aucun v2 nécessaire.
- **Unique** : seul niveau où l'on trace un ruban **pour qu'il ne pousse pas**.
- **Variante dure** : la butée doit aussi renvoyer la balle vers une zone située en amont : il faut l'incliner pour qu'elle tombe du bon côté.

## 33 · L'escalier lent
- **Temps** : Ten 9, **Relais**. Raison d'être : seconde face de la vérité : la lenteur porte.
- **Type** : MONTER LENTEMENT (descendre pour monter).
- **Vérité** : un ruban lent porte la balle sur une pente raide ; la force n'est pas la vitesse.
- **Phrase** : « Fais tomber la balle au pied du turquoise : il la monte doucement. »
- **Hypothèse** : H21 (pour monter, il faut de la vitesse).
- **Leurre** : le tremplin fixe du chemin haut (et tout tremplin tracé) : la balle saute vers la niche et finit dans les pointes du surplomb qui la coiffe.
- **Scénario** : sans tracé, la balle prend le tremplin et s'empale ; il trace un tremplin plus plat, elle heurte la paroi sous la niche ; il remarque que le seul accès sans surplomb est la paroi turquoise qui part du fond du puits ; il dévie la balle **vers le bas**, dans le puits ; l'escalier la monte au pas.
- **Éléments** : chemin haut terminé par un tremplin fixe (PIÉGER : le leurre est joué au premier lancer) ; niche coiffée d'un surplomb à pointes (FERMER toute arrivée en vol) ; ruban v2 turquoise sur la paroi raide du puits, jusqu'à la niche-récepteur (PORTER) ; puits (PORTER : le chemin contre-intuitif) ; machine courte de la niche à la zone.
- **Raccourcis** : un ruban tracé montant (fermé : palette structure seule) ; arriver au pied trop vite (sans effet : le v2 freine à 2, l'idée tient).
- **Contraintes** : palette structure ; encre serrée (un déflecteur) ; nd au-dessus du tremplin fixe (on ne le corrige pas) ; **ruban v2 lent requis**, pente ≤ 70° (contact garanti).
- **Unique** : seul niveau où l'on descend pour monter et où la couleur « lente » est la bonne.
- **Variante dure** : deux parois de puits, l'une turquoise, l'autre blanc-cyan ; le blanc-cyan monte aussi, mais jette la balle dans le surplomb.

## 34 · Le bout utile
- **Temps** : Ketsu 10, **Deux actes** (ZJ1 → récepteur → machine → ZJ2 → zone). Raison d'être : une encre pour deux actes ; la première décision conditionne la seconde.
- **Type** : ÉCONOMISER.
- **Vérité** : un ruban donne tout son élan en une courte longueur ; au-delà, il ne coûte que de l'encre.
- **Phrase** : « Un ruban court suffit : garde l'encre pour le second acte. »
- **Hypothèses** : H25 (un ruban plus long pousse plus fort) et H6 (plus d'énergie, plus de choix).
- **Leurre** : un ruban long et généreux à l'acte 1 : il réussit l'acte 1, puis la jauge est vide devant le pont de l'acte 2.
- **Scénario** : il réussit l'acte 1 avec un long ruban, la machine dépose la balle au bord de la brèche de l'acte 2, plus d'encre ; il trace d'abord le pont de l'acte 2, il ne reste qu'un bout d'encre ; il essaie un ruban court, et la balle atteint le récepteur aussi bien.
- **Éléments** : balle posée à plat, tremplin fixe vers le récepteur de l'acte 1 (PORTER) ; machine (rail) entre les actes (PORTER, spectacle) ; brèche de l'acte 2 (FERMER : exige l'encre restante) ; zone finale adossée (PORTER).
- **Raccourcis** : un pont de l'acte 2 fait en ruban (sans gain, plus cher : fermé par l'encre) ; G1 à l'acte 1 (fermé : encre).
- **Contraintes** : palette structure + élan ; encre **calculée** = ruban court (≈ longueur qui atteint 7,2, avec marge) + pont ; jauge très visible ; pas de nd ; aucun v2 (sauf la machine).
- **Unique** : seul niveau où l'énigme est le **partage** de l'encre entre deux endroits.
- **Variante dure** : l'acte 2 demande lui aussi un ruban court (recharge du 30) : deux rubans courts et un pont, encre au plus juste.

## 35 · Après ton passage
- **Temps** : Ketsu 11, Simple. Raison d'être : moment unique : le trait se trace **pendant** le jeu, et le monde offre le temps de le faire.
- **Type** : SÉQUENCER (tracer après le passage).
- **Vérité** : deux rubans qui se renvoient la balle la gardent prisonnière, et ce va-et-vient laisse tout le temps de tracer.
- **Phrase** : « Laisse-la passer, puis trace la rampe qu'elle prendra au retour. »
- **Hypothèse** : H2 (on trace avant de lâcher).
- **Leurre** : tracer la rampe avant de lâcher : la balle bute contre son dessous à l'aller et ne passe jamais.
- **Scénario** : sans tracé, la balle fait l'aller-retour sans fin (le ruban fixe la renvoie) ; il trace la rampe avant, la balle est bloquée à l'aller ; il remarque que la balle repasse toujours, sans menace ; il trace pendant qu'elle est de l'autre côté ; au retour elle prend la rampe.
- **Éléments** : ruban fixe violet au sol sous le départ (PORTER l'aller, PIÉGER le retour : la prison) ; passage étroit au ras du sol (FERMER : une rampe tracée avant le bouche) ; pente fixe de l'autre côté (PORTER : renvoie la balle) ; zone en hauteur, adossée, au-dessus du départ (PORTER).
- **Raccourcis** : couvrir le ruban fixe pour casser la prison (fermé : nd sur le ruban) ; tremplin sur la pente de droite (fermé : surplomb ou distance, la zone n'est atteignable que par le retour).
- **Contraintes** : palette élan (ou structure si G1 est faux) ; encre serrée ; nd sur le ruban fixe et la pente ; aucun v2. **À confirmer : le tracé en cours de jeu est autorisé hors Zen Lab, et le pied de rampe se raccorde au sol sans « bout qui dépasse ».**
- **Unique** : seul niveau du jeu (à ce stade) où l'ordre « lâcher puis tracer » est la clé ; la prison devient un temps offert, jamais un minuteur.
- **Variante dure** : il faut deux tracés à deux passages différents (la rampe, puis un couvercle au passage suivant).

## 36 · Rendre l'élan
- **Temps** : Ketsu 12, **Finale** (ZJ → récepteur → grande machine → zone). Rappel renversé du 25.
- **Type** : SYNTHÈSE (25 convertir, 28 récupérer la chute, 31 éviter le contact).
- **Vérité** : l'élan se reçoit, se garde et se rend : la machine finale le ramène à zéro, couleur par couleur.
- **Phrase** : « Rattrape la chute au-dessus du ruban, relève-la vers le récepteur. »
- **Hypothèse** : H26 (ce qui m'a aidé au début m'aidera encore).
- **Leurre** : le réflexe du 25 : la balle tombe sur le même ruban fixe, mais il pousse vers le vide ; un ruban tracé par-dessus vers la droite plus un tremplin (26 + 31) donne 7,2 et la balle retombe sous le récepteur.
- **Scénario** : même image d'ouverture que le 25, en miroir : la balle tombe sur le ruban et file au vide ; il couvre le ruban et relance, il manque le récepteur de peu ; il se souvient que la chute vaut plus que le ruban ; il rattrape la balle en l'air, au-dessus du ruban fixe, et la relève d'un tremplin.
- **Éléments** : ruban fixe violet sous la chute, vers le vide (PIÉGER : le héros du 25 devenu piège) ; départ haut (PORTER) ; récepteur haut de l'autre côté (FERMER le ruban, hors de portée à 7,2) ; grande machine : gamme décroissante blanc-cyan → violet → turquoise → ambre, qui arrête la balle dans la zone (PORTER, spectacle, récapitulatif du code couleur).
- **Raccourcis** : une seule pente directe jusqu'au récepteur (si l'encre le permet, c'est la même idée en un trait : acceptable) ; G1 (fermé : encre).
- **Contraintes** : palette structure + élan ; encre moyenne (deux traits : pente + tremplin) ; nd autour de la machine ; **rubans v2 requis** (machine) ; dernière image = décor du monde 4.
- **Unique** : seul niveau qui finit à vitesse nulle (« rendre ») et qui montre les quatre couleurs ensemble.
- **Variante dure** : la pente doit passer sous un plafond, puis une brèche demande un ruban de recharge en hauteur (30) avant le récepteur.

---

## Auto-critique (une ligne par niveau, honnête)
- **25** : risque de trivialité (l'idée « tremplin » est connue du monde 1) ; tolérable en Ki 1, c'est sa fonction.
- **26** : énigme de geste plus que de pensée ; un gaucher la résout sans le vouloir. Court et nécessaire, mais faible en « eurêka ».
- **27** : choix à trois issues, donc résoluble par essais (trois lancers au plus). Accepté en Ki ; à surveiller : si P_hasard est élevé, supprimer le turquoise et garder deux couloirs plus une paroi.
- **28** : raccourci possible si l'encre permet un ruban incliné assez long (G1). Sinon solide : c'est l'impasse la plus franche du monde.
- **29** : risque physique (la balle rebondit-elle sur le sas au lieu d'y rester ?) et raccourci « coincer la balle contre un bord » si la zone a la moindre paroi côté vide.
- **30** : risque de trivialité : avec la palette « élan », le joueur peut poser un ruban sur la brèche par réflexe, sans comprendre. Atténuation : structure sélectionnée par défaut ; à mesurer au test.
- **31** : risque de raccourci si un ruban posé dans la tranchée près du fond ne la couvre qu'à moitié et que le comportement est ambigu ; la profondeur de tranchée est la vitre.
- **32** : le plus menacé de trivialité : un joueur qui pense « mur » d'emblée réussit au premier essai. L'impasse repose sur H24 ; si les tests montrent qu'elle ne tombe pas, remplacer par la variante dure.
- **33** : risque physique (contact sur paroi raide) ; risque de lecture si le turquoise ressemble à un mur décoratif : il faut des chevrons très visibles.
- **34** : raccourci si l'encre est mal calculée (trop large = pas d'énigme ; trop juste = précision de longueur) ; la marge doit absorber ±20 % de longueur de ruban.
- **35** : dépend de deux faits non vérifiés (tracé en cours de jeu, raccord du pied de rampe) ; le plus original, le plus fragile.
- **36** : proche du 28 (même idée « rattraper la chute ») ; c'est le rappel voulu, mais la finale doit montrer davantage : voir la variante dure.
- **Écarts au gabarit** : 8 Simples (cible 5–6) ; la Machine-énigme est au 27, pas au 8 : une machine déterministe se lit en un lancer, donc l'eurêka y est faible ; je l'ai gardée là où l'on apprend à lire, plutôt que d'inventer une machine décorative en position 8.

## Tableau récapitulatif
| N | Titre | Type de raisonnement | Hypothèse | Élément clé | Encre | Ruban v2 |
|---|---|---|---|---|---|---|
| 25 | Le ruban | Convertir | H19 | ruban fixe + relèvement tracé | moyenne | non |
| 26 | Dans ton sens | Orienter | H11 | ruban tracé, sens du geste | serrée | non |
| 27 | Trois couleurs | Lire (machine) | H22 | trois couloirs colorés, aiguillage | serrée | oui (3) |
| 28 | La chute est un élan | Récupérer la chute (sans ruban) | H12 | pente sous la chute, ruban-leurre | moyenne | non |
| 29 | Le sas | Viser le sas | H8 | rebond + sas turquoise | serrée | oui (lent) |
| 30 | Le second souffle | Relayer en haut | H23 | ruban-pont sur la brèche haute | serrée | non (machine seule) |
| 31 | Le courant | Couvrir | H5 | couvercle-ruban sur courant rapide | serrée | oui (rapide) |
| 32 | Le ruban-mur | Détourner la matière | H24 | ruban dressé en butée | serrée | non |
| 33 | L'escalier lent | Monter lentement | H21 | paroi turquoise au fond du puits | serrée | oui (lent) |
| 34 | Le bout utile | Économiser | H25 / H6 | ruban court + pont, encre partagée | calculée | non (machine seule) |
| 35 | Après ton passage | Séquencer (tracer pendant) | H2 | prison d'élan + rampe tracée au retour | serrée | non |
| 36 | Rendre l'élan | Synthèse | H26 | chute rattrapée au-dessus du ruban, gamme finale | moyenne | oui (machine) |

Hors du schéma « rampe vers un ruban » : 27, 28, 29, 31, 32, 33, 35 (7 sur 12).

## Faisabilité : à tester d'abord
0. **G1 (préalable)** : le ruban tracé incliné en l'air fait-il grimper la balle sans fin ? La réponse fixe l'encre de 26, 28, 30, 31, 34, 36.
1. **29 Le sas** : un ruban v2 lent ramène-t-il une balle à 10–12 à moins de 2,2 sur une longueur jouable, et la balle reste-t-elle au contact après un rebond ?
   *Rechange* : même idée sans rebond : palette structure, chute haute, le joueur dévie la balle sur le sas au lieu de la zone (on perd la combinaison avec le monde 2, on garde H8).
2. **35 Après ton passage** : tracé autorisé en cours de jeu ; prison stable (pas d'échappée) ; pied de rampe qui se raccorde au sol.
   *Rechange* : « Le pont à deux étages » : le ruban tracé avant le lancer sert d'abord de plafond (la balle passe dessous à l'aller), puis de sol (une courbe fixe la ramène par-dessus au retour) ; même famille (le trait sert deux fois, H15), sans tracé en cours de jeu.
3. **33 L'escalier lent** : un ruban v2 lent garde-t-il le contact et monte-t-il la balle sur une pente de 60–70° jusqu'en haut, sans la décoller au sommet ?
   *Rechange* : remplacer la paroi raide par une pente douce et longue en turquoise, le surplomb à pointes imposant toujours une arrivée « au pas » ; l'idée « la lenteur est la bonne réponse » reste.
