# Calibrage de l'encre (R297)

**Règle proposée.** Le quota découle de la meilleure solution connue : `Q = k × encre(référence) + c`, avec trois profils choisis par niveau — **défi d'encre** (k=1,2 ; c=10 ; l'encre fait partie du puzzle), **standard** (k=1,6 ; c=20), **découverte** (k=2 ; c=40, cf. DIFFICULTY_PROTOCOL §6). Garde-fous : la référence doit gagner, être dessinable au doigt et rester la plus économe connue (aucune ligne droite gagnante à moins de 80 % de son coût) ; un quota inférieur à 1,15 × la référence est refusé (un tracé au doigt dépasse toujours un peu). Les chiffres des beta-testeurs (encre utilisée, essais) ajusteront ensuite chaque niveau.

**Décisions de Simon (24 oct.)** : règle à 3 profils validée ; niveaux « défi d'encre » définis d'après les événements des bêta-testeurs ; **resserrés (R297)** les 7 niveaux à encre sans enjeu : 60 (120→90), 90 (200→120), 97 (120→110), 103 (200→100), 113 (640→260), 121 (660→360), 122 (300→120) ; scan relancé : référence gagne, niveau vide échoue. **Les 18 niveaux trop serrés ne sont pas touchés** (en attente de confirmation).

Répartition actuelle : serré 32, généreux 28, standard 52 (sur 112 niveaux avec référence ; 16 sans).

## Monde 1

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 1 | Le premier trait | 128 | 110 | 1.16 | serré | 20 | gagnable avec une ligne de 20 (réf 110) : l'encre ne protège rien |
| 2 | Le pont | 234 | 110 | 2.13 | généreux | 80 | référence non économe (ligne droite à 80 vs 110) |
| 3 | Le colimaçon | 204 | 110 | 1.85 | standard | 35 | référence non économe (ligne droite à 35 vs 110) |
| 4 | Le relais | 420 | 222 | 1.89 | standard | – |  |
| 5 | Le demi-tour | 214 | 160 | 1.34 | standard | 55 | référence non économe (ligne droite à 55 vs 160) |
| 6 | Les collines | 193 | 148 | 1.30 | standard | 150 |  |
| 7 | Économie | 188 | 160 | 1.18 | serré | 55 | référence non économe (ligne droite à 55 vs 160) |
| 8 | La portée | 246 | 220 | 1.12 | serré | 110 | **300** trop serré (×1.12); référence non économe (ligne droite à 110 vs 220) |
| 9 | Le détour | 355 | 273 | 1.30 | standard | 20 | gagnable avec une ligne de 20 (réf 273) : l'encre ne protège rien |
| 10 | Le plafond | 113 | 70 | 1.61 | standard | 55 | référence non économe (ligne droite à 55 vs 70) |
| 11 | Le relais | 258 | 225 | 1.15 | serré | 200 | **300** trop serré (×1.15) |
| 12 | La cellule | 90 | 45 | 2.00 | standard | 20 | référence non économe (ligne droite à 20 vs 45) |

## Monde 2

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 13 | Le trampoline | 155 | 61 | 2.54 | généreux | 20 | référence non économe (ligne droite à 20 vs 61) |
| 14 | Le ricochet | 577 | 219 | 2.63 | généreux | 20 | gagnable avec une ligne de 20 (réf 219) : l'encre ne protège rien |
| 15 | La montée | 432 | 160 | 2.70 | généreux | 20 | gagnable avec une ligne de 20 (réf 160) : l'encre ne protège rien |
| 16 | La hauteur juste | 220 | 115 | 1.91 | standard | 20 | gagnable avec une ligne de 20 (réf 115) : l'encre ne protège rien |
| 17 | Sol brûlant | 220 | 85 | 2.59 | généreux | 20 | gagnable avec une ligne de 20 (réf 85) : l'encre ne protège rien |
| 18 | Ta plaque | 227 | 174 | 1.30 | standard | 38 | gagnable avec une ligne de 38 (réf 174) : l'encre ne protège rien |
| 20 | Le tremplin | 297 | 282 | 1.05 | serré | 20 | **380** trop serré (×1.05); gagnable avec une ligne de 20 (réf 282) : l'encre ne protège rien |
| 21 | Le grand retour | 273 | 203 | 1.34 | standard | 20 | gagnable avec une ligne de 20 (réf 203) : l'encre ne protège rien |
| 22 | Double rebond | 313 | 244 | 1.28 | standard | 55 | gagnable avec une ligne de 55 (réf 244) : l'encre ne protège rien |
| 23 | L’élan d’abord | 284 | 231 | 1.23 | serré | 20 | gagnable avec une ligne de 20 (réf 231) : l'encre ne protège rien |
| 24 | La fonte | 143 | 110 | 1.30 | standard | 20 | gagnable avec une ligne de 20 (réf 110) : l'encre ne protège rien |

## Monde 3

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 25 | Le tapis | 102 | 77 | 1.32 | standard | – |  |
| 26 | Sens inverse | 300 | 191 | 1.57 | standard | 20 | gagnable avec une ligne de 20 (réf 191) : l'encre ne protège rien |
| 27 | Tapis et butée | 300 | 190 | 1.58 | standard | 20 | gagnable avec une ligne de 20 (réf 190) : l'encre ne protège rien |
| 28 | Le plafond bas | 210 | 148 | 1.42 | standard | 20 | gagnable avec une ligne de 20 (réf 148) : l'encre ne protège rien |
| 29 | Ton élan | 514 | 273 | 1.88 | standard | – |  |
| 31 | Tapis et lames | 320 | 195 | 1.64 | standard | – |  |
| 32 | Deux tapis | 300 | 255 | 1.18 | serré | 80 | référence non économe (ligne droite à 80 vs 255) |
| 33 | Chaîne montante | 272 | 244 | 1.11 | serré | 20 | **330** trop serré (×1.11); gagnable avec une ligne de 20 (réf 244) : l'encre ne protège rien |
| 34 | Relais d’élan | 420 | 365 | 1.15 | serré | – |  |
| 35 | Le tri des tapis | 309 | 276 | 1.12 | serré | – | **370** trop serré (×1.12) |
| 36 | La chaîne complète | 203 | 156 | 1.30 | standard | – |  |

## Monde 4

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 37 | Le lac | 160 | 118 | 1.36 | standard | 35 | gagnable avec une ligne de 35 (réf 118) : l'encre ne protège rien |
| 38 | Trop vite | 118 | 91 | 1.30 | standard | 20 | gagnable avec une ligne de 20 (réf 91) : l'encre ne protège rien |
| 39 | Le saut | 111 | 85 | 1.31 | standard | 80 |  |
| 40 | Le demi‑tour | 355 | 273 | 1.30 | standard | 200 | référence non économe (ligne droite à 200 vs 273) |
| 41 | La combe gelée | 120 | 60 | 2.00 | standard | 20 | référence non économe (ligne droite à 20 vs 60) |
| 42 | La piste glacée | 220 | 130 | 1.69 | standard | 20 | gagnable avec une ligne de 20 (réf 130) : l'encre ne protège rien |
| 43 | Deux étages | 229 | 125 | 1.83 | standard | 20 | gagnable avec une ligne de 20 (réf 125) : l'encre ne protège rien |
| 44 | La patinoire | 153 | 118 | 1.30 | standard | – |  |
| 45 | Le passage gardé | 74 | 49 | 1.51 | standard | 20 | référence non économe (ligne droite à 20 vs 49) |
| 46 | Verglas | 120 | 55 | 2.18 | généreux | 20 | référence non économe (ligne droite à 20 vs 55) |
| 47 | La crevasse double | 330 | 254 | 1.30 | standard | – |  |
| 48 | Le pendule de glace | 160 | 59 | 2.71 | généreux | 20 | référence non économe (ligne droite à 20 vs 59) |

## Monde 5

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 49 | Le souffle | 232 | 178 | 1.30 | standard | 35 | gagnable avec une ligne de 35 (réf 178) : l'encre ne protège rien |
| 50 | Vent de face | 265 | 204 | 1.30 | standard | 150 | référence non économe (ligne droite à 150 vs 204) |
| 51 | Vent descendant | 169 | 130 | 1.30 | standard | 20 | gagnable avec une ligne de 20 (réf 130) : l'encre ne protège rien |
| 52 | Colonne étroite | 330 | 296 | 1.11 | serré | – | **390** trop serré (×1.11) |
| 54 | La cascade inversée | 120 | 50 | 2.40 | généreux | 20 | référence non économe (ligne droite à 20 vs 50) |
| 59 | La tempête | 240 | 200 | 1.20 | serré | – |  |
| 60 | Le cyclone | 120 | 25 | 4.80 | généreux | 20 | **90** encre sans enjeu (×4.8) |

## Monde 6

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 65 | Le pendule | 120 | 100 | 1.20 | serré | 55 | référence non économe (ligne droite à 55 vs 100) |
| 66 | L’escalier mécanique | 200 | 87 | 2.30 | généreux | 20 | gagnable avec une ligne de 20 (réf 87) : l'encre ne protège rien |
| 68 | L’engrenage | 160 | 55 | 2.91 | généreux | 35 | référence non économe (ligne droite à 35 vs 55) |
| 70 | L’horloge | 120 | 46 | 2.61 | généreux | 20 | référence non économe (ligne droite à 20 vs 46) |
| 71 | Atelier mobile | 120 | 55 | 2.18 | généreux | 20 | référence non économe (ligne droite à 20 vs 55) |
| 72 | L’échappement | 300 | 261 | 1.15 | serré | – | **350** trop serré (×1.15) |

## Monde 7

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 73 | Tomber vers le haut | 178 | 137 | 1.30 | standard | 20 | gagnable avec une ligne de 20 (réf 137) : l'encre ne protège rien |
| 74 | Gravité lourde | 155 | 119 | 1.30 | standard | 110 |  |
| 75 | Le manège inversé | 300 | 231 | 1.30 | standard | – |  |
| 76 | Le champ de travers | 132 | 102 | 1.29 | standard | – |  |
| 77 | Le saut lunaire | 64 | 60 | 1.07 | serré | 20 | **90** trop serré (×1.07); référence non économe (ligne droite à 20 vs 60) |
| 78 | La fronde | 160 | 80 | 2.00 | standard | 20 | gagnable avec une ligne de 20 (réf 80) : l'encre ne protège rien |
| 79 | Le plafond | 200 | 180 | 1.11 | serré | 110 | **240** trop serré (×1.11); référence non économe (ligne droite à 110 vs 180) |
| 80 | Le jet | 80 | 70 | 1.14 | serré | 20 | **100** trop serré (×1.14); gagnable avec une ligne de 20 (réf 70) : l'encre ne protège rien |
| 81 | La frontière | 80 | 54 | 1.48 | standard | 20 | référence non économe (ligne droite à 20 vs 54) |
| 82 | La plume | 130 | 118 | 1.10 | serré | – | **160** trop serré (×1.10) |
| 83 | Le miroir | 70 | 35 | 2.00 | standard | 20 | référence non économe (ligne droite à 20 vs 35) |
| 84 | Relativité | 270 | 227 | 1.19 | serré | 80 | référence non économe (ligne droite à 80 vs 227) |

## Monde 8

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 85 | La lentille | 160 | 140 | 1.14 | serré | 20 | **190** trop serré (×1.14); gagnable avec une ligne de 20 (réf 140) : l'encre ne protège rien |
| 86 | La feuille d’or | 120 | 50 | 2.40 | généreux | 20 | référence non économe (ligne droite à 20 vs 50) |
| 87 | La dérive | 260 | 190 | 1.37 | standard | 20 | gagnable avec une ligne de 20 (réf 190) : l'encre ne protège rien |
| 88 | Le dipôle | 200 | 100 | 2.00 | standard | 20 | gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 89 | Le ricochet | 90 | 74 | 1.22 | serré | 20 | gagnable avec une ligne de 20 (réf 74) : l'encre ne protège rien |
| 90 | Le canon de Gauss | 200 | 41 | 4.88 | généreux | 20 | **120** encre sans enjeu (×4.9); référence non économe (ligne droite à 20 vs 41) |
| 91 | Le cyclotron | 120 | 60 | 2.00 | standard | 20 | référence non économe (ligne droite à 20 vs 60) |
| 92 | Le coussin | 80 | 70 | 1.14 | serré | 20 | **100** trop serré (×1.14); gagnable avec une ligne de 20 (réf 70) : l'encre ne protège rien |
| 93 | Orbite | 120 | 80 | 1.50 | standard | 20 | gagnable avec une ligne de 20 (réf 80) : l'encre ne protège rien |
| 94 | L’accélérateur | 80 | 53 | 1.51 | standard | 20 | référence non économe (ligne droite à 20 vs 53) |
| 95 | La capture | 120 | 50 | 2.40 | généreux | 20 | référence non économe (ligne droite à 20 vs 50) |
| 96 | Le spectromètre | 200 | 70 | 2.86 | généreux | 20 | gagnable avec une ligne de 20 (réf 70) : l'encre ne protège rien |

## Monde 9

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 97 | Le portail | 120 | 34 | 3.53 | généreux | 20 | **110** encre sans enjeu (×3.5); référence non économe (ligne droite à 20 vs 34) |
| 98 | À travers le mur | 200 | 150 | 1.33 | standard | 20 | gagnable avec une ligne de 20 (réf 150) : l'encre ne protège rien |
| 99 | Le geyser | 160 | 100 | 1.60 | standard | 20 | gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 100 | Portail et mur | 300 | 150 | 2.00 | standard | 20 | gagnable avec une ligne de 20 (réf 150) : l'encre ne protège rien |
| 101 | Le bord du monde | 110 | 100 | 1.10 | serré | 20 | **140** trop serré (×1.10); gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 102 | L’élan transmis | 120 | 47 | 2.55 | généreux | 20 | référence non économe (ligne droite à 20 vs 47) |
| 103 | La sarbacane | 200 | 30 | 6.67 | généreux | 20 | **100** encre sans enjeu (×6.7); référence non économe (ligne droite à 20 vs 30) |
| 104 | Le trou de serrure | 110 | 100 | 1.10 | serré | 55 | **140** trop serré (×1.10); référence non économe (ligne droite à 55 vs 100) |
| 105 | Aller-retour | 110 | 100 | 1.10 | serré | 20 | **140** trop serré (×1.10); gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 106 | La couture | 160 | 100 | 1.60 | standard | 80 |  |
| 107 | Le pli | 110 | 100 | 1.10 | serré | 20 | **140** trop serré (×1.10); gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 108 | L’univers torique | 160 | 80 | 2.00 | standard | 20 | gagnable avec une ligne de 20 (réf 80) : l'encre ne protège rien |

## Monde 10

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 109 | Corde tendue | 220 | 140 | 1.57 | standard | – |  |
| 111 | Corde et plaque | 160 | 140 | 1.14 | serré | – | **190** trop serré (×1.14) |
| 112 | La balle molle | 300 | 130 | 2.31 | généreux | 80 | référence non économe (ligne droite à 80 vs 130) |
| 113 | Molle et mince | 640 | 110 | 5.82 | généreux | 55 | **260** encre sans enjeu (×5.8); référence non économe (ligne droite à 55 vs 110) |
| 115 | Molle et lame | 400 | 222 | 1.80 | standard | – |  |
| 116 | Deux cordes | 320 | 273 | 1.17 | serré | – |  |

## Monde 11

| N | nom | quota | réf | ×réf | bande | ligne min | proposition |
|--|--|--|--|--|--|--|--|
| 121 | Le lien | 660 | 160 | 4.12 | généreux | 35 | **360** encre sans enjeu (×4.1); gagnable avec une ligne de 35 (réf 160) : l'encre ne protège rien |
| 122 | Opposition | 300 | 40 | 7.50 | généreux | 20 | **120** encre sans enjeu (×7.5); référence non économe (ligne droite à 20 vs 40) |
| 123 | Deux possibles | 120 | 70 | 1.71 | standard | 20 | gagnable avec une ligne de 20 (réf 70) : l'encre ne protège rien |
| 124 | La mesure | 120 | 45 | 2.67 | généreux | 20 | référence non économe (ligne droite à 20 vs 45) |
| 125 | Le temps ralenti | 100 | 30 | 3.33 | généreux | 20 | référence non économe (ligne droite à 20 vs 30) |
| 126 | L’interféromètre | 120 | 40 | 3.00 | généreux | 20 | référence non économe (ligne droite à 20 vs 40) |
| 127 | Intrication double | 120 | 100 | 1.20 | serré | 20 | gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 128 | Mesure tardive | 120 | 100 | 1.20 | serré | 20 | gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 129 | Les jumeaux | 120 | 45 | 2.67 | généreux | 20 | référence non économe (ligne droite à 20 vs 45) |
| 130 | Le choix | 120 | 100 | 1.20 | serré | 20 | gagnable avec une ligne de 20 (réf 100) : l'encre ne protège rien |
| 131 | Machine quantique | 120 | 101 | 1.19 | serré | 20 | gagnable avec une ligne de 20 (réf 101) : l'encre ne protège rien |

Sans référence (rien à calibrer avant d'en poser une) : [19, 53, 55, 56, 57, 58, 61, 62, 63, 64, 67, 69, 110, 117, 118, 119]