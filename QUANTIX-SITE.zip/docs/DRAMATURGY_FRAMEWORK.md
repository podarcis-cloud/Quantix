# QUANTIX — cadre de dramaturgie du gameplay

*Chaque niveau est une petite histoire, sans avoir besoin d'un mot de
texte pour la raconter — la géométrie, la physique et le rythme du tracé
la racontent à sa place. Ce document donne la structure en huit temps et
comment la lire dans un niveau de puzzle physique, pas dans un récit
linéaire.*

---

## La structure en huit temps

| # | Temps | Ce que c'est dans Quantix |
|---|---|---|
| 1 | **Introduction** | Le joueur voit départ, arrivée, et ce qui s'interpose, en un coup d'œil — pas de lecture cachée nécessaire pour comprendre le problème posé. |
| 2 | **Apprentissage** | La mécanique du niveau est rappelée ou introduite — si elle est nouvelle, elle doit être isolée (§4 du protocole maître) ; si elle est connue, le niveau peut aller plus vite ici. |
| 3 | **Développement** | La mécanique est utilisée une première fois dans sa forme la plus directe. |
| 4 | **Complication** | Une contrainte change la donne : un budget serré, un danger à éviter, une seconde mécanique qui interagit avec la première. |
| 5 | **Fausse piste** *(facultative)* | Une trajectoire semble évidente et ne marche pas — ou marche, mais mal (touche un piquant, manque la zone de peu). Elle doit être *plausible*, jamais un piège gratuit (protocole maître §2 : jamais de difficulté injuste). |
| 6 | **Renversement** *(facultatif)* | Une information déjà visible depuis le début prend un sens nouveau — ce n'est jamais une règle qui change sans indice, c'est un regard qui change sur une règle stable. |
| 7 | **Résolution** | Le joueur trouve et exécute la solution. |
| 8 | **Payoff** | La sensation laissée par la résolution — voir la typologie ci-dessous. |

Tous les temps ne sont pas obligatoires à chaque niveau. Un niveau
d'introduction (position 1-2 dans l'arc d'un monde, §4 du protocole
maître) peut légitimement n'avoir que 1-2-3-7-8 : pas de complication, pas
de fausse piste, pas de renversement. Un niveau de synthèse (position 12)
devrait, lui, viser les huit.

---

## La typologie du payoff

Le protocole maître demande une résolution qui cherche son équivalent
d'une chute de film, d'un tour de magie, d'un puzzle ou d'une blague — pas
une liste à cocher, une famille à choisir consciemment pour chaque niveau :

- **Spectaculaire** — la résolution est visuellement ou physiquement
  impressionnante (une trajectoire longue et continue à travers plusieurs
  mécaniques, un enchaînement rapide).
- **Élégante** — la solution est la plus simple possible une fois vue,
  et cette simplicité *est* la satisfaction (deuxième temps du §3 du
  protocole maître : *« tout était là depuis le début »*).
- **Drôle** — un décalage entre ce que le joueur attend et ce qui arrive,
  sans que ce soit injuste (ex. : un tracé prudent qui produit un résultat
  exagérément énergique, ou l'inverse).
- **Surprenante** — voir §3 du protocole maître, l'écart d'information de
  Loewenstein : préparée, jamais arbitraire.
- **Cathartique** — après une tension prolongée (plusieurs échecs
  informatifs, §5 du protocole maître), une résolution nette.
- **Mécaniquement ingénieuse** — la solution combine des éléments d'une
  façon que le niveau n'avait pas explicitement montrée, mais que ses
  règles permettaient depuis le début.

Un niveau peut viser plusieurs familles à la fois. Ce qu'il ne doit jamais
être : sans famille du tout — une résolution qui n'est ni spectaculaire,
ni élégante, ni surprenante, ni drôle, ni cathartique, ni ingénieuse est
un symptôme direct de la redondance diagnostiquée dans
`REDUNDANCY_ANALYSIS.md`.

---

## Lecture rapide pour remplir la fiche

Dans `LEVEL_DESIGN_CANVAS.md`, section Dramaturgie : renseigner chaque
temps présent, laisser vide (pas "sans objet" générique, vide et assumé)
les temps facultatifs absents, et pour le champ Payoff, nommer
explicitement la ou les familles visées ci-dessus — pas une description
vague de "satisfaction".
