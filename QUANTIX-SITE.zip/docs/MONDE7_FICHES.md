# QUANTIX — Monde 7 · Gravité — les 12 fiches (R94)

*Vérité du monde : le haut n'est plus le haut — dans un champ, la chute change de force et de sens. Machine type (cahier §3.3) :
une piste que la particule parcourt À L'ENVERS, plaquée par la gravité inversée. Gabarit §6 : machines aux positions 3, 6,
8, 10 et 12.*

| Pos. | # | Temps | Forme | Type | Hypothèse qui tombe | Énigme (idée) | État |
|---|---|---|---|---|---|---|---|
| 1 | 73 | Ki | Simple | R‑01 Découvrir | « le haut est le haut » | la colonne inversée hisse la particule ; la voûte devient une pente vers le balcon | **A** |
| 2 | 74 | Ki | Simple | R‑06 Doser | « la mécanique aide » | sous gravité lourde, la pente doit être plus courte | **A** |
| 3 | 75 | Ki | **Relais** | R‑01 (révélation de la machine) | « on roule toujours sur le dessus » | atteindre l'entonnoir ; la machine montre la particule rouler À L'ENVERS sous une voûte inversée | **A** (constance 91 %) |
| 4 | 76 | Shō | Simple | R‑04 Inverser | « tomber, c'est vers le bas » | « Le champ de travers » : partie trop bas, rien à construire sous elle ; un champ oblique la porte au‑dessus du vide | **A** |
| 5 | 77 | Shō | Simple | R‑02 Ponter | « un pont est horizontal » | en gravité faible la particule flotte : un pont en pente suffit, un pont droit la laisse dériver | à refaire |
| 6 | 78 | Shō | **Relais** | R‑06 Doser (récompense) | « plus vite, mieux c'est » | entrer dans l'entonnoir LENTEMENT ; machine : descente en spirale à gravités alternées | à construire |
| 7 | 79 | Ten | Simple | R‑09 Éviter | « le champ est une aide » | le champ inversé visible mène aux pointes : le contourner | à refaire |
| 8 | 80 | Ten | **Machine‑énigme** | R‑21 Lire la machine | « la machine me sauve » | la machine éjecte la particule vers le haut : préparer le toit qui la renverra dans la zone | à construire |
| 9 | 81 | Ten | Simple | R‑12 Orienter | « le sens du trait n'importe pas » | sous gravité inversée, une rampe tracée « à l'envers » devient la bonne pente | à refaire |
| 10 | 82 | Ketsu | **Deux actes** | R‑19 Combiner | « un trait = un geste » | acte 1 : la faire monter ; la machine la dépose ; acte 2 : la faire redescendre ailleurs | à construire |
| 11 | 83 | Ketsu | Simple | R‑14 Contre‑pied | « il faut viser la zone » | viser le bas pour atteindre le haut | à refaire |
| 12 | 84 | Ketsu | **Finale** | R‑20 Synthèse | rappel renversé du 73 | grand manège : montée inversée, voûte, chute lourde, saut — vers la zone | à construire |
