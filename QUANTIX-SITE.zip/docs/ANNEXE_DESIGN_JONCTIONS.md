# QUANTIX — ANNEXE : design des murs et JONCTIONS (où tout se trouve)

*Annexe de reprise, R115 (9 octobre 2026). À lire avant toute tâche sur l'aspect des murs, des courbes,
des jonctions, des impacts ou de la zone de réussite. Elle ne remplace rien : elle indique où se trouve
chaque information et résume les règles en vigueur.*

> **Statut R209** : référence toujours valable pour les murs, jonctions et chocs. Niveaux fautifs à jour : #21 et #34
> (le #11 est corrigé). Voir `INDEX_DOCUMENTS.md`.

---

## 1. Où se trouve chaque information

| Sujet | Document (Projet Claude et `docs/` du zip) | Section |
|---|---|---|
| Jetons de couleur (11 jetons, interdiction d'en inventer) | `HANDBOOK.md` | §6 « Jetons de style » |
| Pièces courbes : physique et composition | `CAHIER_DES_CHARGES_GENERATION.md` | §17 |
| Grille d'or (axe x = 180, lignes d'or x 137,5 / 222,5, y 183 / 297) | idem | §18 |
| Règles des descentes concaves, virage par l'intérieur, lèvre, dosseret | idem | §17, §19 |
| Finition des pièces courbes (7 couches) | idem | §20 (dessin acier, remplacé au §23) |
| Connecteurs v1 (embout, platine, manchon, gousset, collier) | idem | §21 — **historique, remplacé par §22** |
| **Jonction adaptative universelle** (nœuds, bras, L/T/X/Y/étoile) | idem | **§22** |
| **Langue « lumière quantique »** (murs, lentilles, atomes, perles, ancrages) | idem | **§23** |
| Zone de réussite dégagée (règle opposable) | idem | §23 |
| Petites animations (halo, poussières, photons, ondes du cœur‑atome) | idem | §24 |
| Animations de choc (4 paliers) | idem | §25 |
| Journal des versions R85 à R90 (ce qui a été fait, dans quel ordre) | `archive/REPRISE-SESSION-R121.md` | entrées R85 à R90 |
| Identité visuelle par monde | `QUANTUM_VISUAL_NARRATIVE.md`, `WORLD_IDENTITY_FRAMEWORK.md` | en entier |

## 2. Où se trouve le code (zip du site)

Tout le rendu vit dans **`assets/js/visuals.js`** (portée privée, un seul global `window.VX`).
Chercher par nom de fonction (`grep -n "function joints" assets/js/visuals.js`), jamais par numéro de ligne.

| Fonction | Rôle |
|---|---|
| `var C={…}` (début du fichier) | couleurs en RVB dérivées des jetons : `matter`, `boost`, `reward`, `goal`, `danger`, `bounce`, `white`… |
| `jointsBuild(lv,segs)` | **analyse** : relève les pièces (murs droits + courbes `lv._cv`), leurs bouts, les rencontres bout/bout (< 9 u), bout/corps (< 8 u → T), corps/corps (intersection → X, `cross:1`) ; fabrique des **nœuds** `{x,y,m,arms:[[dx,dy]…]}` ; deux bras à moins de 16° sont fusionnés ; renvoie `{nodes, ends}` (bouts libres) |
| `hull(pts)` | enveloppe convexe (chaîne monotone) : la forme de la lentille épouse les bras |
| `joints(c,segs,lv)` | **dessin** : cache par niveau (`lv._jn`, clé `lv._jnKey`) ; pour chaque nœud à ≥ 2 bras : lentille (dégradé radial, liseré lumineux), bague par bras (L = 10, W = 6,5), cœur‑atome (noyau blanc, halo, orbites, électron, onde qui s'échappe) ; bouts libres : perle de lumière ; bords d'écran : ancrage lumineux. Teinte = matière dominante (glace givre, tapis `boost`, rebond `bounce`, sinon `matter`) |
| `curve(c,P,mat,opt)` → `VX.curve` | dessine toute pièce (courbe **et** droite) dans la langue lumineuse : rail de photons, âme translucide, constellation, photons qui circulent, lampes qui s'éveillent près de la particule |
| `back(c,lv)` | décor du monde, masque autour du bassin (zone dégagée) ; appelle `joints(c,segs,lv)` |
| `impactFx(e)` / `drawImpacts(c)` | chocs gradués, branchés sur les événements `ball.impact` et `ball.bounce` |

Côté moteur (`assets/js/engine.js`) : `curveSample(P,step)` et `curveExpand(lv)` transforment `lv.curves = [{pts,m}]`
en segments jointifs de ~9 u pour la physique (`lv._cv`) ; les segments issus d'une courbe portent `w[5] = 1`
et sont **exclus** de `jointsBuild` (une courbe ne se joint pas à elle‑même). Les murs de bassin (`isCupWall`)
et les pointes (matière 2) sont aussi exclus ; les parois mobiles n'ont pas de jonction.

## 3. Les règles en vigueur (résumé de §22 à §25)

**Jonction adaptative universelle (§22)**
- Toute rencontre devient un nœud décrit par ses bras : un bras par pièce qui en part ; une pièce qui traverse donne
  deux bras opposés.
- Cas couverts : angle L, Y, étoile (bouts qui se touchent) ; T (bout posé sur le corps d'une autre pièce, courbes comprises) ;
  croisement X (corps contre corps, intersection calculée segment par segment) ; croisement poutre × glace et glace × glace.
- Le cœur est l'enveloppe convexe des bagues : il s'adapte à n'importe quel nombre de bras et d'angles.
- Calcul une fois par niveau (cache) ; jamais de chevauchement brut de deux murs.

**Langue « lumière quantique » (§23)** — plus d'acier :
- murs = lumière tenue (rail de photons, cœur blanc, âme translucide, réseau en constellation, photons qui circulent) ;
- jonction = **lentille** de verre sombre au cœur teinté + **petit atome** (noyau, halo, orbites elliptiques, électron) ;
- bout libre = **perle de lumière** ; bord d'écran = **ancrage lumineux** à deux points ;
- le bassin parle la même langue, teinté de la couleur de la zone.

**Zone de réussite dégagée (§23, opposable)** : aucun élément de niveau dans l'intérieur du bassin
(contrôle `node tools/zonepropre.js`) ; aucun motif de décor autour du bassin (masque dans `back()`).
Niveaux encore fautifs au R209 : 21, 34.

**Animations (§24) et chocs (§25)** : halo qui respire, poussières qui montent, photons qui s'éveillent, onde du cœur‑atome,
perles qui pulsent ; chocs en 4 paliers selon la vitesse normale v (< 1,6 grains · 1,6–3 poussière fine · 3–5 + arcs électriques
et anneau · > 5 + onde de choc et étoile), couleur de la matière mêlée de blanc.

**Composition (§17‑§19)** : lecture en diagonale ; respiration (tiers haut libre pour le geste) ; alternance droites/courbes ;
hiérarchie (zone et relais les plus lumineux, machine en retrait) ; une seule langue pour droites et courbes ; grille d'or.

## 4. Vérifier visuellement

- **Planche des jonctions** : `python3 tools/planche-jonctions.py` → `docs/design/planche-jonctions.png`
  (vrai jeu dans Chromium). À relancer **après toute modification** de `joints`, `jointsBuild`, `hull` ou `curve`, et
  **regarder l'image** avant d'affirmer que le rendu fonctionne. *(R209 : ce script n'est plus dans `tools/` ; le banc des
  rendus et les captures Playwright le remplacent.)*
- **Dans un niveau** : `page.goto('file:///…/index.html')`, `page.evaluate("goto('game');loadLevel(i)")`, `page.screenshot`.
- **Banc d'essai** (prototypes de machines, planche) : `python3 tools/build-banc.py` (panneau `tools/banc-panel.html`).

## 5. Ce que Simon a demandé (à ne pas perdre)

- « Connecteurs trop anecdotiques ; quand deux murs se croisent, ils se chevauchent simplement » → jonctions réelles
  pour chaque cas, ou jonction adaptative universelle (§22).
- « Soigne le design… professionnel… univers quantique onirique cosmique » ; « design plus luminescent, ajoute du détail,
  petites animations » (§23‑§24).
- « Je n'aime pas que des éléments se trouvent au sein même de la zone de réussite, ça fait brouillon » (§23).
- « Petits arcs électriques et poussière lumineuse très fine » aux impacts, gradués selon la force (§25).
- Composition : symétries, nombre d'or, équilibre, zones qui respirent, ne pas surcharger (§18).

## 6. Pistes ouvertes

- Corriger les niveaux 21, 34 (élément dans la zone).
- Mesurer le coût d'affichage des jonctions sur téléphone (jamais mesuré sur appareil réel).
- Décliner la teinte et le « cœur » des jonctions par monde si l'identité de monde le demande (non fait).
