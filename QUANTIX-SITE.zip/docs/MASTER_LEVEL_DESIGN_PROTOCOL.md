# QUANTIX — protocole maître de conception des niveaux

*Ce document remplace, pour tout ce qui touche à la conception d'un niveau,
les approches précédentes fondées sur la seule fermeture géométrique des
raccourcis. Il ne les annule pas : la vérification technique (`bypass.js`,
`solver.js`, simulation directe) reste obligatoire, mais elle devient une
étape parmi d'autres, pas la définition de "niveau terminé". Un niveau
non-contournable et vide de sens reste un niveau raté.*

*Fondé sur des sources vérifiables, citées à l'endroit où elles s'appliquent.
Aucune affirmation neuroscientifique n'est faite sans support direct — quand
la littérature ne dit que "attention", "mémoire de travail" ou "prédiction
d'erreur", le document dit ça, pas "zone cérébrale X".*

---

## 0. Principe fondamental

**Un niveau = une expérience, pas une variation.**

Un niveau ne doit jamais exister seulement parce qu'il faut remplir un
numéro dans une progression. Avant toute conception, il doit pouvoir
répondre à : *pourquoi ce niveau existe-t-il ?* Si la seule réponse est
« il en fallait un de plus », le niveau est invalide et doit être repensé
ou fusionné avec un autre.

Ce principe prime sur tout : la quantité, la vitesse de production, la
complexité apparente. En cas de conflit :

```
INTENTION → GAMEPLAY → APPRENTISSAGE → EXPÉRIENCE → RÉSOLUTION → POLISH
```

et jamais l'inverse (`QUANTITÉ → RAPIDITÉ → RÉPÉTITION`).

---

## 1. Le cadre théorique — trois échelles de lecture

Emprunté au **framework MDA** (Hunicke, LeBlanc & Zubek, *MDA: A Formal
Approach to Game Design and Game Research*, GDC San Jose 2001-2004) : tout
niveau se lit à trois échelles, et un problème doit être nommé à la bonne
échelle avant d'être corrigé.

| Échelle | Ce qu'elle contient dans Quantix | Question de diagnostic |
|---|---|---|
| **Mécaniques** | `w`, `nd`, `wind`, `grav`, `mag`, `port`, `mov`, `ent`, `gate`, `sup`, `det`, `tdil`, le budget `ink`, la matière `pal` | Les règles sont-elles correctement posées ? |
| **Dynamiques** | Ce que ces règles produisent une fois qu'un joueur trace — les trajectoires réellement empruntées, les stratégies qui émergent | Le comportement qui émerge est-il celui voulu ? |
| **Esthétiques** | Ce que le joueur ressent — curiosité, tension, soulagement, fierté | L'expérience vécue correspond-elle à l'intention ? |

Le designer construit du bas vers le haut (mécaniques → en espérant
l'esthétique voulue) ; le joueur rencontre le jeu du haut vers le bas
(l'émotion d'abord, les règles ensuite, s'il y réfléchit). Un niveau qui
"fonctionne" mécaniquement (non contournable, prouvé résoluble) peut encore
échouer en dynamique (une seule trajectoire triviale s'impose) ou en
esthétique (rien n'est ressenti). Les trois doivent être vérifiées
séparément — voir `LEVEL_DESIGN_CANVAS.md`.

---

## 2. L'équilibre défi / compétence — pourquoi la difficulté doit naître de la compréhension

Fondé sur la **théorie du flow** (Csíkszentmihályi, 1975 ; reprise pour le
jeu vidéo par de nombreux travaux ultérieurs — voir par ex. la synthèse dans
Chen, *Flow in Games*, thèse de master USC). Le flow apparaît dans le
« canal » où le défi perçu et la compétence perçue sont proches et élevés
tous les deux : au-dessus, anxiété ; en dessous, ennui.

Conséquence directe pour Quantix : **la difficulté doit venir d'une
compréhension plus profonde du système, jamais d'un empêchement arbitraire.**

Interdit :
- passage plus étroit que nécessaire sans raison de jeu ;
- minutage arbitrairement serré ;
- information cachée sans indice préalable ;
- collision « injuste » (le joueur a bien compris et bien exécuté, et perd
  quand même).

Le test : après un échec, le joueur doit pouvoir se dire *« je n'y arrivais
pas parce que je n'avais pas compris »*, jamais *« je n'y arrivais pas parce
que le jeu m'en empêchait »*.

Comme la difficulté doit progresser avec la compétence acquise (le canal de
flow monte avec le joueur), **chaque monde doit être une rampe**, pas un
plateau : le niveau 1 d'un monde enseigne, le niveau 12 combine tout ce que
le monde a enseigné.

---

## 3. La surprise comme mécanique, pas comme décoration

Fondé sur la **théorie de l'écart d'information** (Loewenstein, 1994, *The
Psychology of Curiosity: A Review and Reinterpretation*, Psychological
Bulletin) : la curiosité naît d'un écart perçu entre ce que l'on sait et ce
que l'on voudrait savoir — et elle est maximale quand cet écart est
spécifique et semble comblable, pas quand il est vague ou insurmontable.

Application : une surprise de niveau ne doit jamais être arbitraire. Elle
doit être **préparée** par ce que le niveau a déjà montré, de sorte que la
réaction du joueur ait deux temps :

1. *« Ah, je n'avais pas vu ça. »*
2. *« En fait, tout était là depuis le début. »*

Le second temps est le test de validité. Une surprise qui ne produit que le
premier (un piège non préparé, une règle qui change sans indice) n'est pas
de la surprise, c'est de l'arbitraire — et ça casse la confiance plutôt que
de la nourrir (règle 11 : jamais de difficulté injuste).

---

## 4. Enseigner sans texte — la leçon de Portal, Baba Is You, The Witness

Documenté dans la pratique de conception de ces trois jeux (voir sources en
fin de document) : la règle constante est **une idée nouvelle par niveau
d'introduction**, isolée de toute autre difficulté, dans un espace où
l'échec est sans conséquence et l'expérimentation encouragée. Valve a
ajouté la majorité des salles-tests de Portal *après coup*, précisément aux
endroits où les tests joueurs montraient de la confusion — la leçon n'est
pas seulement "isole une idée", c'est aussi "vérifie par test que
l'isolement a fonctionné".

Application à la structure d'un monde Quantix (12 niveaux) :

| Position | Fonction | Contrainte |
|---|---|---|
| 1-2 | Introduire la mécanique seule, sans risque | Échec sans frustration ; la mécanique est la seule chose nouvelle |
| 3-5 | Faire réagir à une variante (direction, intensité, timing) | Une seule variable change à la fois |
| 6-8 | Combiner avec un élément déjà connu d'un monde précédent, ou avec une contrainte (danger, budget) | La combinaison doit être *nécessaire*, pas cosmétique |
| 9-10 | Complication — une fausse piste plausible existe | Le joueur doit pouvoir se tromper *utilement* (voir §6) |
| 11 | Renversement — un savoir acquis doit être réévalué | Change la lecture, ne change pas les règles |
| 12 | Synthèse — combine l'essentiel du monde | Le niveau doit être impossible sans avoir traversé 1-11 |

---

## 5. L'erreur doit informer

Repris de la pratique documentée sur *Mushroom 11* (Itay Keren, GDC —
*Teaching by Design*) : un tutoriel efficace ne minimise pas l'échec, il le
rend **instructif**. Chaque échec doit produire une information exploitable
au prochain essai, jamais juste une pénalité.

Grille de lecture d'un échec dans Quantix — à quel type appartient-il ?

- **Erreur de compréhension** — le joueur n'a pas encore le modèle mental
  correct de la mécanique. Le niveau doit le lui révéler *par l'échec
  lui-même* (ex. : la balle rebondit dans une direction inattendue et cette
  direction, une fois vue, explique tout).
- **Erreur de timing** — le modèle est correct, l'exécution était en avance
  ou en retard.
- **Erreur d'exécution** — le tracé était globalement juste, imprécis dans
  le détail.
- **Erreur stratégique** — plusieurs approches existaient, celle-ci n'était
  pas la bonne.
- **Erreur d'anticipation** — une conséquence différée n'a pas été prévue.

Si l'échec d'un niveau ne peut être rangé dans aucune de ces catégories —
s'il ressemble à un accident plutôt qu'à une leçon — le niveau est mal
conçu, quelle que soit sa difficulté nominale.

---

## 6. Fonction obligatoire de chaque élément

Aucun élément interactif ne doit exister « parce qu'il serait intéressant ».
Pour chaque obstacle, bonus, ou mécanique placé dans un niveau, la fiche du
niveau (`LEVEL_DESIGN_CANVAS.md`) doit répondre aux quatre familles de
questions ci-dessous. Si un élément ne remplit aucune fonction suffisamment
importante dans au moins une famille : **le supprimer.**

**Fonction ludique** — obstacle ? accélérateur ? ralentisseur ? piège ?
bonus ? ressource ? contrainte ? élément de navigation ? de puzzle ? fausse
piste ? transformation ?

**Fonction dramaturgique** — pourquoi intervient-il *maintenant*, pas avant,
pas après ? Quelle tension crée-t-il ? Quelle attente ? Pourquoi est-il
absent des niveaux précédents, pourquoi le sera-t-il des suivants ?

**Fonction cognitive** — quelle décision impose-t-il ? Quelle information le
joueur doit-il mémoriser ou observer ? Demande-t-il anticipation, réaction,
exploration, ou expérimentation ? (Ces catégories — anticipation, mémoire
de travail, reconnaissance de patterns — sont documentées dans la
littérature sur la charge cognitive et l'apprentissage par erreur ; voir
§13 sur les limites de ce qu'on peut affirmer.)

**Fonction émotionnelle** — tension ? surprise ? curiosité ? satisfaction ?
soulagement ? frustration productive ? émerveillement ?

---

## 7. Différenciation obligatoire

Avant qu'un niveau soit considéré terminé, il doit être comparé :

- au niveau précédent et au niveau suivant du même monde ;
- aux autres niveaux du même monde ;
- à tout niveau utilisant la même mécanique ailleurs dans le jeu.

Si deux niveaux se résolvent raisonnablement de la même façon (même
trajectoire type, même rythme, même décision au même moment), ils sont
**suspects**. Alors : différencier fortement l'un des deux, fusionner leurs
concepts, en supprimer un, ou transformer complètement l'un des deux.

Un outil concret existe pour objectiver une partie de ce diagnostic —
`tools/redundancy.js`, voir `REDUNDANCY_ANALYSIS.md`. Il détecte les
similarités *mesurables* (forme du tracé solution, mécaniques employées,
distance géométrique départ→arrivée) ; il ne remplace pas le jugement sur
le *ressenti*, qui reste humain.

---

## 8. Interdiction de la difficulté artificielle — rappel opérationnel

Reprend et précise §2. En pratique, avant de valider un niveau, vérifier
qu'aucune de ses difficultés ne provient uniquement de :

- un passage plus étroit que la géométrie du jeu ne l'exige (rayon de la
  particule `R=10.5`, ou `12.5` pour un corps mou — voir la découverte sur
  #114 dans `docs/AUDIT-R29.md` et le futur audit du monde 10) ;
- un minutage qui ne laisse pas de marge d'erreur raisonnable ;
- une information nécessaire à la résolution mais jamais montrée ni
  suggérée ailleurs dans le monde ;
- un placement d'obstacle qui n'a pas été vérifié par simulation.

---

## 9. Méthode de travail — dans l'ordre, sans sauter d'étape

Pour **chaque niveau**, dans cet ordre :

1. **Autopsie** — que fait le niveau actuellement ? Qu'est-ce qui, dans sa
   conception présente, mérite d'être gardé ?
2. **Intention** — pourquoi ce niveau existe-t-il ? Une phrase, pas un
   paragraphe.
3. **Concept** — quelle est son identité en une phrase mémorable ?
4. **Simulation des trajectoires** *(avant* de placer un seul obstacle) —
   point de départ, objectif, trajectoires naturelles, raccourcis
   accidentels, zones mortes, zones de décision. Utiliser `tools/load.js`
   pour simuler réellement, pas pour deviner.
5. **Dramaturgie** — dérouler la structure introduction → apprentissage →
   développement → complication → (fausse piste) → renversement →
   résolution → payoff — structure complète et typologie du payoff dans
   `DRAMATURGY_FRAMEWORK.md`.
6. **Construction** — placer les éléments, un par un, chacun justifié par
   §6 ci-dessus.
7. **Son** — feedback sonore des événements clés (voir
   `SOUND_DESIGN_PROTOCOL.md`).
8. **Test réel** — simulation directe, pas seulement `solver.js`/`bypass.js`.
9. **Mesure** — les comportements observés correspondent-ils à l'intention ?
10. **Itération** — corriger ce qui ne correspond pas.
11. **Validation** — passer les *gates* de `LEVEL_DESIGN_CANVAS.md`.
12. **Archivage** — noter ce qui a été appris, dans la fiche du niveau elle-même.

**Un niveau à la fois.** Ne jamais traiter plusieurs dizaines de niveaux
simultanément et superficiellement — c'est exactement le mode de production
qui a produit la redondance actuelle.

---

## 10. Règle anti-économie

Ne jamais économiser du travail sur une étape qui conditionne la qualité
des suivantes. En particulier : ne pas répliquer une structure qui a
fonctionné pour aller vite ; ne pas multiplier les objets pour simuler de
la variété ; ne pas déclarer un niveau terminé parce qu'il est jouable — il
doit fonctionner comme *expérience*, pas seulement comme mécanisme.

L'objectif n'est pas de réduire le travail : c'est de réduire le travail
**inutile** en augmentant la qualité de chaque décision.

---

## 11. Ce que ce document ne remplace pas

`docs/HANDBOOK.md` reste la référence technique (physique, format de
niveau, pièges de code, séquence de vérification). `docs/PROTOCOLE.md`
reste la référence de méthode de travail au sens outillage (correctifs
comptés, lecture ciblée, etc.). Ce document régit la **conception**, pas
l'implémentation ni la vérification technique — les deux sont nécessaires,
aucune ne suffit seule.

---

## Sources

- Hunicke, R., LeBlanc, M., Zubek, R. (2004). *MDA: A Formal Approach to
  Game Design and Game Research.* AAAI Workshop, GDC San Jose 2001-2004.
- Csíkszentmihályi, M. (1975). *Beyond Boredom and Anxiety.* Repris pour le
  jeu vidéo dans de nombreux travaux ultérieurs (canal de flow, modèle à
  quatre canaux de Massimini & Carli).
- Loewenstein, G. (1994). *The Psychology of Curiosity: A Review and
  Reinterpretation.* Psychological Bulletin, 116(1), 75-98.
- Valve Corporation — pratique documentée de conception de *Portal*
  (playtesting itératif, salles ajoutées après coup pour lever la
  confusion) ; largement documentée dans les rétrospectives GDC et la
  presse spécialisée du jeu.
- Keren, I. — *Teaching by Design: Tips for Effective Tutorials from
  'Mushroom 11'*, GDC Vault.
- Pratiques de conception documentées de *Baba Is You* (Teikari) et *The
  Witness* (Blow) — itération par élimination, enseignement sans texte par
  l'espace de jeu lui-même.
- Techniques de musique adaptative : superposition verticale (« vertical
  layering ») et réenchaînement horizontal (« horizontal re-sequencing »),
  documentées depuis *Monkey Island 2* (moteur iMUSE) jusqu'à des usages
  modernes (*Dead Space 2*, *Halo*, *Hades II*).
