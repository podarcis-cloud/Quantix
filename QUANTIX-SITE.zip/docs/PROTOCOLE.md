# QUANTIX — protocole d'utilisation

*Objectif : obtenir un travail correct en consommant le moins possible. Toute la consommation vient de trois sources — lire trop, écrire trop, et refaire ce qui était déjà fait.*

---

## Règle 1 — Ne jamais lire le jeu en entier

`quantix-R22.html` fait 268 Ko. Le charger dans la conversation coûte l'équivalent de plusieurs tours de travail, pour rien.

**Lire uniquement par extraction ciblée :**

```bash
grep -n "motif" build/engine.js | head
sed -n '1200,1260p' build/engine.js
```

Le handbook §0 indique quelles sections ouvrir selon la tâche. Ouvrir ces sections, pas le reste.

---

## Règle 2 — Un but par conversation

Une conversation qui poursuit quatre objectifs les traite tous mal et coûte quatre fois. La liste `TACHES.md` est ordonnée : prendre le premier point non fait, le finir, publier, s'arrêter.

Formule d'ouverture qui marche :

> Reprends Quantix. Lis `REPRISE.md`, puis le handbook §2 et §9. Tâche : *un seul point*. Ne touche à rien d'autre.

---

## Règle 3 — Modifier par correctif, jamais par réécriture

Réécrire un fichier de 2 000 lignes pour changer trois lignes coûte cent fois le nécessaire. Les modifications passent par un script Python qui **compte ses remplacements** :

```python
def rep(a,b,label):
    global s,n
    if a in s: s=s.replace(a,b,1); n+=1; print(label,'OK')
    else: print(label,'ÉCHEC')
```

Un `ÉCHEC` doit arrêter le travail, pas être ignoré. Chaque remplacement silencieux de cette session a coûté deux à trois tours.

---

## Règle 4 — Vérifier avant de livrer, jamais après

Publier puis découvrir le défaut via une capture d'écran coûte un aller-retour complet, plus le temps de l'utilisateur. La séquence du handbook §10 coûte trente secondes de machine.

Ordre imposé :

1. `node --check`
2. `scenetest.js`
3. `strict.js`
4. contrôle des identifiants manquants
5. publication, **sous un numéro neuf**

---

## Règle 5 — Faire parler l'erreur avant de formuler une hypothèse

Chaque déblocage de la session précédente est venu d'un message d'erreur affiché à l'écran. Aucun n'est venu d'un raisonnement à vide. Onze tours ont été perdus à supposer au lieu d'instrumenter.

Quand quelque chose ne marche pas chez l'utilisateur : **d'abord ajouter l'affichage de l'état exact dans l'interface**, ensuite seulement corriger.

---

## Règle 6 — Le solveur ne tourne que si les niveaux changent

`solver.js` prend une dizaine de minutes. Il est indispensable après toute modification de niveau, inutile sinon.

---

## Règle 7 — Les tests doivent exécuter le code testé

Avant d'écrire un test, se demander quelle fonction il fait tourner. Un test de chargement qui s'arrête à l'accueil n'exécute jamais le rendu du jeu.

---

## Règle 8 — Ce qui est décidé ne se rediscute pas

Les décisions figées sont dans `REPRISE.md` §3 : le canon, la palette, la typographie, le refus des vies et de la publicité après échec, le monde de référence 360×480.

Les rouvrir coûte un tour et ne produit rien.

---

## Budget indicatif par type de tâche

| Tâche | Lectures | Tours |
|---|---|---|
| Corriger un libellé | `i18n.js` seul | 1 |
| Ajouter un niveau | handbook §3, §4 | 1 + solveur |
| Ajouter une mécanique | handbook §2, §3, §9 | 2 à 3 |
| Retoucher l'interface | handbook §6, §7 | 1 à 2 |
| Nouveau mode de jeu | handbook §2, §7, §9 | 3 à 4 |

Au-delà de quatre tours sur une tâche : s'arrêter, écrire ce qui bloque dans `REPRISE.md`, et ouvrir une conversation neuve. Une conversation longue coûte de plus en plus cher à chaque message, parce qu'elle recharge tout son historique.
