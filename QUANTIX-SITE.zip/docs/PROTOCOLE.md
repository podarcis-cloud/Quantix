# QUANTIX — protocole d'utilisation

*Objectif : obtenir un travail correct en consommant le moins possible. Toute la consommation vient de trois sources — lire trop, écrire trop, et refaire ce qui était déjà fait.*

---

## Règle 1 — Ne jamais lire une source en entier

`assets/js/engine.js` fait plus de 2000 lignes. Le charger dans la
conversation coûte l'équivalent de plusieurs tours de travail, pour rien.

**Lire uniquement par extraction ciblée :**

```bash
grep -n "motif" assets/js/engine.js | head
sed -n '1200,1260p' assets/js/engine.js
```

Le handbook §0 indique quelles sections ouvrir selon la tâche. Ouvrir ces sections, pas le reste.

---

## Règle 2 — Un but par conversation

Une conversation qui poursuit quatre objectifs les traite tous mal et coûte
quatre fois. La liste `TACHES.md` est ordonnée : prendre le premier point
non fait, le finir, vérifier, s'arrêter.

Formule d'ouverture qui marche :

> Reprends Quantix. Lis `docs/REPRISE.md`, puis le handbook §0 pour choisir
> tes sections. Tâche : *un seul point*. Ne touche à rien d'autre.

---

## Règle 3 — Modifier par correctif, jamais par réécriture

Réécrire un fichier de 2000 lignes pour changer trois lignes coûte cent fois
le nécessaire. Les modifications passent par un script Python qui **compte
ses remplacements** :

```python
def rep(a,b,label):
    global s,n
    if a in s: s=s.replace(a,b,1); n+=1; print(label,'OK')
    else: print(label,'ÉCHEC')
```

Un `ÉCHEC` doit arrêter le travail, pas être ignoré. Chaque remplacement
silencieux a coûté deux à trois tours par le passé — un script de correction
qui meurt avant d'écrire annonce des `OK` sans rien enregistrer.

**Exception légitime** : un document markdown de `docs/` qu'une tâche fait
substantiellement évoluer (pas une simple phrase à corriger) peut être
réécrit en entier — une réécriture qui laisse le sens inchangé ne valait pas
la peine d'être faite, mais une mise à jour de fond gagne en clarté à être
réécrite plutôt que rapiécée de correctif en correctif. Ça ne s'applique
jamais au code : `assets/js/*.js` et `index.html` passent toujours par des
correctifs comptés.

---

## Règle 4 — Vérifier avant de livrer, jamais après

Publier puis découvrir le défaut via une capture d'écran coûte un
aller-retour complet, plus le temps de l'utilisateur. La séquence du
handbook §10 coûte quelques secondes de machine — **tous les outils de
`tools/` fonctionnent** (R29 ; cinq étaient cassés avant, restes de l'ancien
build, voir handbook §9.3).

Ordre imposé, à exécuter réellement — pas seulement `node --check` :

1. `node --check` sur les 4 sources
2. `cd tools && node audit.js && node render.js`
3. `node strict.js`, `node maptest.js`, `node savetest.js`, `node qprobe.js`
4. `node solver.js` si un niveau a changé ; `node bypass.js` en plus si un
   niveau a été rescénarisé (voir handbook §11)
5. Contrôle des identifiants manquants (script du handbook §10)
6. Contrôle des chaînes hors `i18n.js` si du texte visible a été touché
   (script du handbook §9.6)

**Vérifier veut dire lire la sortie, pas seulement un code de retour à
zéro.** Un script qui affiche `OK` pour chaque étape mais dont le résultat
final contredit l'intention (ex. un niveau resté contournable) n'a rien
vérifié d'utile.

---

## Règle 5 — Faire parler l'erreur avant de formuler une hypothèse

Chaque déblocage utile est venu d'un message d'erreur affiché à l'écran, ou
d'une mesure directe. Aucun n'est venu d'un raisonnement à vide. Onze tours
ont été perdus par le passé à supposer, sur l'audio, au lieu d'instrumenter.

Quand quelque chose ne marche pas chez l'utilisateur : **d'abord ajouter
l'affichage de l'état exact dans l'interface**, ensuite seulement corriger.
`auWarn` (handbook §5) est un exemple actuel d'endroit où céder à la
tentation de deviner serait une erreur : il faut d'abord savoir, sur
appareil réel, quel état déclenche le problème.

---

## Règle 6 — Les outils tournent vite ; ça ne dispense pas de les lancer

`solver.js` et `bypass.js` s'exécutent en quelques secondes sur les 132
niveaux (pas en dix minutes — chiffre de l'ancien build, jamais réajusté
avant R29). Ce n'est pas une raison de les lancer moins souvent : c'est une
raison de ne jamais avoir d'excuse pour ne pas les lancer après une
modification de niveau.

---

## Règle 7 — Les tests doivent exécuter le code testé

Avant d'écrire un test, se demander quelle fonction il fait tourner. Un test
de chargement qui s'arrête à l'accueil n'exécute jamais le rendu du jeu —
c'est pour ça que `render.js` force `data-screen='game'` (handbook §9.3).

Un test qui échoue peut aussi avoir tort : le faux DOM de `tools/load.js` ne
parse pas le HTML injecté dynamiquement (handbook §9.5), et une recherche de
candidats heuristique peut ne pas trouver une solution qui existe (handbook
§11). Un échec de test mérite d'être compris avant d'être traité comme un
bug du jeu.

---

## Règle 8 — Un test heuristique qui ne trouve rien n'est pas une preuve d'échec

Spécifique à la scénarisation des niveaux (handbook §11), assez important
pour être sa propre règle : après avoir fermé une échappatoire avec un `nd`,
`solver.js` peut ne plus prouver la résolvabilité d'un niveau qui reste
pourtant parfaitement gagnable — sa recherche de candidats est simple par
construction. **Vérifier par simulation directe** avant de conclure qu'un
correctif a cassé le niveau, ou avant de l'assouplir par réflexe.

---

## Règle 9 — Ce qui est décidé ne se rediscute pas

Les décisions figées sont dans `docs/REPRISE.md` §3 : le canon (site
statique multi-fichiers, chemins relatifs, pas de build), la palette, la
typographie, le refus des vies et de la publicité après échec, le monde de
référence 360×480, les huit leviers d'engagement de
`ENGAGEMENT-ET-MONETISATION.md`.

Les rouvrir coûte un tour et ne produit rien.

---

## Règle 10 — Les noms courts du moteur collisionnent, y compris dans tes propres scripts

`L`, `S`, `T` et quelques autres identifiants à une lettre sont déjà pris
par `engine.js`. Avant d'en introduire un nouveau dans le jeu :
`grep -c "\bNOM\b" assets/js/*.js`. Et dans un script `node -e` de
diagnostic ponctuel, ne jamais nommer une variable `L` ou `S` — la
collision s'y manifeste différemment (`SyntaxError` au moment même du
chargement du moteur, avant que ton code ne s'exécute) et coûte un tour à
comprendre si on ne s'y attend pas. Détail et raison exacte : handbook §9.1.

---

## Budget indicatif par type de tâche

| Tâche | Lectures | Tours |
|---|---|---|
| Corriger un libellé | `assets/js/i18n.js` seul | 1 |
| Ajouter un niveau | handbook §3, §4 | 1 + solveur |
| Rescénariser un niveau contournable | handbook §11 | 1 par niveau, en général |
| Ajouter une mécanique | handbook §2, §3, §9 | 2 à 3 |
| Retoucher l'interface | handbook §6, §7 | 1 à 2 |
| Nouveau mode de jeu | handbook §2, §7, §9 | 3 à 4 |

Au-delà de quatre tours sur une tâche : s'arrêter, écrire ce qui bloque dans
`docs/REPRISE.md`, et ouvrir une conversation neuve. Une conversation longue
coûte de plus en plus cher à chaque message, parce qu'elle recharge tout son
historique.
