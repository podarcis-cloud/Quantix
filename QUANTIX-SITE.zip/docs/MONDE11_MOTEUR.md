# QUANTIX — Monde 11 Quantique : le moteur, précisément (R242, 17 octobre 2026)

*Document de référence avant la refonte du Monde 11. Tout ce qui suit est lu dans `engine.js` (fonctions `quantum`,
`stepBranch`, `physics`, `gateOpen`, `timeScaleAt`) et `visuals.js` (`qsup`, `qdet`, `qent`, `qgate`, `qtdil`), pas
supposé. Convention : « Monde 11 – niveau Y ».*

---

## 1. Les quatre briques telles qu'elles fonctionnent aujourd'hui

### 1.1 Le dédoublement (superposition) — `lv.sup = [[x, y, w, h, angle]]`

- **Déclenchement** : la première fois que la particule entre dans le rectangle. **Une seule fois par essai** : après
  un effondrement (mesure, arrivée, mort d'une copie), plus aucun dédoublement possible (`S.collapsed`).
- **Effet** : deux copies au même endroit, à la **même vitesse**, directions tournées de **+angle** et **−angle**
  (radians ; 0,7 ≈ 40°). Aucune énergie créée.
- **Les deux copies sont des particules classiques complètes** : chacune tombe, rebondit sur les murs et les traits,
  déclenche noyaux, détecteurs, failles, ramasse le noyau-étoile. Elles **ne se voient pas** l'une l'autre (pas de
  collision, pas d'interaction).
- **Mort** : une copie qui meurt disparaît (« effondrement ») ; l'essai n'échoue que si **les deux** meurent.
- **Arrivée** : la **première copie** qui se pose dans la zone (vitesse < 2,2) devient la réelle, l'autre s'efface.
- Rendu : la copie est violette, un fil les relie, traînée propre (`S.gtrail`).

### 1.2 Le détecteur (mesure) — `lv.det = [[x, y, rayon, (paire)]]`

- **N'agit que pendant la superposition.** Une copie qui entre dans le cercle **devient la réelle**, l'autre est
  effacée, et la superposition est finie pour l'essai.
- **Optionnel** : `det[3]` = numéro d'une paire intriquée ; la mesure **bascule** cette paire (ouvre ou ferme ses portes).
- Le détecteur est « armé » (dessin actif) seulement quand deux copies existent.

### 1.3 L'intrication et les portes — `lv.ent = [[ax, ay, bx, by, 'same'|'opp', départ]]`, `lv.gate = [[x1, y1, x2, y2, paire, phase]]`

- Deux **noyaux liés** (qubits dessinés) partagent un seul état `on`. Une copie qui passe à **moins de 20** de
  **l'un ou l'autre** bascule l'état ; puis 18 images de répit.
- Chaque passage **re-bascule** : toucher deux fois = revenir au départ.
- Une **porte** est un mur plein quand elle est fermée. `phase 0` : fermée au repos, s'ouvre quand la paire est `on` ;
  `phase 1` : l'inverse. Une même paire peut commander plusieurs portes (dont des portes opposées).
- ⚠ **`'same'` et `'opp'` font exactement la même chose dans le moteur** (seul le dessin change : flèches de spin
  parallèles ou opposées). La « corrélation opposée » n'existe pas physiquement dans le jeu aujourd'hui.

### 1.4 La dilatation du temps — `lv.tdil = [[x, y, w, h, facteur]]`

- Dans le rectangle, **tout** ralentit pour la copie qui s'y trouve (déplacement et forces × facteur, 0,22 à 0,45) :
  **même trajectoire, plus lentement**. Elle ne change jamais une forme de chemin.
- Elle ne compte donc que **par rapport à quelque chose qui bouge** : une barre mobile, une fronde… ou **l'autre copie**.
- Chaque copie a son propre temps : une copie ralentie **arrive plus tard** que sa jumelle. C'est la propriété la plus
  riche du monde et elle n'est presque pas utilisée : **le temps décide quelle copie touche en premier** un noyau, un
  détecteur ou la zone.

---

## 2. Ce que le jeu dit vrai, et ce qu'il arrange

| Brique | Physique réelle | Dans Quantix |
|---|---|---|
| Superposition | une onde qui explore les deux chemins | deux particules classiques, sans interférence entre elles |
| Mesure | réduit l'état ; le résultat est aléatoire selon les probabilités | la copie touchée devient la réelle, **sans hasard** (le jeu reste rejouable) |
| Intrication | résultats de mesure corrélés à distance, sans signal | toucher un noyau bascule l'autre ; une porte s'ouvre à distance |
| Interférence | les deux chemins se recombinent : on peut annuler une sortie | **absente** ; l'interféromètre (niveau 6) l'imite par parité (deux bascules = porte fermée) |
| Dilatation du temps | relativité (pas quantique) | zone dorée où le temps s'étire, copie par copie |

Le parti pris est bon pour le jeu : **déterministe, lisible, rejouable**. Le hasard réel est exclu (refus du
« perdu par malchance »).

---

## 3. Limites et défauts relevés

1. `'opp'` = `'same'` dans le moteur (§1.3).
2. Un seul dédoublement par essai ; une copie ne peut pas se re-dédoubler.
3. Les copies ne s'influencent jamais (pas de recombinaison, pas d'interférence).
4. Zones invisibles `mz` encore présentes dans les deux machines (niveaux 6 et 12) — interdit par la charte.
5. Le noyau-étoile est ramassé par n'importe quelle copie, même condamnée (peut rendre l'étoile trop facile).

---

## 4. Fonctions nouvelles possibles (moteur), par ordre d'intérêt

| # | Fonction | Ce qu'elle permettrait | Coût |
|---|---|---|---|
| A | **Recombineur** (lame séparatrice de sortie) `lv.rec` : si les deux copies y passent à peu près ensemble, elles **fusionnent** et sortent par une seule voie (« constructive ») ; si une seule arrive, elle ressort tout droit | une **vraie interférence de Mach-Zehnder** : bloquer un chemin change la sortie de l'autre — le cœur du monde, spectaculaire | moyen (moteur + dessin + fiche) |
| B | **`'opp'` réel** : la paire opposée garde des états contraires ; deux portes qui ne peuvent jamais être ouvertes ensemble | énigmes d'exclusion (« une porte ou l'autre ») | faible |
| C | **Dédoublements multiples** (une copie qui repasse dans une zone se re-dédouble, 4 copies au plus) | arbres de chemins, machine finale | moyen |
| D | **Gomme quantique** : un « effaceur » qui annule une mesure faite plus tôt | niveau-énigme fin de monde | moyen |
| E | **Effet Zénon** : une suite de détecteurs qui fige la copie | curiosité, faible valeur de jeu | faible |

---

## 5. Les douze niveaux : ce que chacun enseigne (plan proposé)

| Niveau | État | Brique enseignée |
|---|---|---|
| 1 Le lien | bon | intrication : toucher un noyau ouvre une porte à distance |
| 2 Opposition | bon | une bascule ouvre, deux referment |
| 3 Deux possibles | **refait R242** | dédoublement : une seule copie suffit |
| 4 La mesure | **refait R242** | détecteur : la copie touchée devient réelle |
| 5 Le temps ralenti | à refaire | **dilatation : retarder une copie** pour qu'elle passe après sa jumelle (ex. la jumelle touche d'abord le noyau qui ouvre la porte, puis la copie ralentie la franchit) |
| 6 L'interféromètre | machine (mz à retirer) | parité de chemins (ou vraie interférence si A) |
| 7 Intrication double | à refaire | deux paires, ordre des contacts (ou exclusion si B) |
| 8 Mesure tardive | à refaire | mesurer au bon moment : le détecteur qui ouvre la porte doit attraper la bonne copie |
| 9 Temps et rebond | à refaire | dilatation + rebond : la course entre les deux copies |
| 10 Le choix | à refaire | deux détecteurs : décider laquelle survit (par le temps) |
| 11 Machine quantique | **refait R242** | une copie ouvre la porte, l'autre la franchit |
| 12 Quantix | finale (mz à retirer) | tout réuni |

---

## 6. Décisions de Simon (17 oct.) : oui aux quatre

Fait en R243 : 1 (recombineur `lv.rec`), 2 (paire opposée réelle), 4 (zones invisibles du niveau 6 ; le niveau 12 n'en
avait pas). À faire : 3 (dédoublements multiples, lot séparé).

### Rappel des propositions

1. Ajouter le **recombineur** (A) pour avoir une vraie interférence — recommandé : c'est l'expérience emblématique du
   quantique et l'identité « franges » du monde.
2. Rendre **`'opp'` réel** (B) — recommandé, coût faible.
3. **Dédoublements multiples** (C) : plus tard, pour la finale.
4. Retirer les **zones invisibles** des niveaux 6 et 12 (charte) — à faire dans tous les cas.
