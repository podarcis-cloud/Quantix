# QUANTIX — Monde 9 « Faille » : 12 fiches de conception (monde 9, niveaux 1 à 12)

25 oct. 2026, **niveaux 6, 7, 8, 10, 11 refaits le 26 oct.** (`scratchpad/m9/v2.js`) · concepteur de niveaux · **géométrie chiffrée et prouvée au banc** (`tools/refonte/harness.js`, moteur réel R287,
emplacements 96–107). Refonte de fond : remplace les 12 niveaux actuels (`levels.js`, `wd:9`). Ce document ne modifie rien d'autre.
Mesures : P_ligne sur 40 tracés bruités (σ = 3), P_hasard sur 2 500 lignes droites au hasard (une seule matière : S).

## 0. Résumé du monde

**Phrase du monde : « L'espace se plie. »** La faille n'est pas un raccourci : c'est une **transformation** de la course.
Elle **déplace** (niveau 1), **garde le sens** (2), **relance ce qu'elle avale** (3), le monde **se recoud** par ses bords (4),
elle **tourne** la course (5), elle **rapporte** ce que la machine emporte (6, machine), elle ouvre **un ciel à l'envers** (7),
elle **rend la vitesse** que le ruban a réglée, au second temps (8), elle **pompe** l'élan quand on referme sa boucle (9),
elle **renvoie à rebours** (10), elle **rend le départ** avec l'élan (11), et tout se **compose** (12).

**Courbe (Ki → Ketsu)**
- Ki (1–3) : une porte vers un lieu clos (1) ; ce qui entre à gauche ressort à gauche (2) ; la porte proche donne un jet faible, la porte profonde un jet fort (3).
- Shō (4–6) : sortir par un bord pour rentrer par l'autre (4) ; un quart de tour ne suffit pas, il en faut deux (5) ; la machine fait le tour de l'écran et ramène la balle sur le trait : il faut l'orienter pour le retour (6, machine).
- Ten (7–9) : derrière la faille, on tombe vers le haut et l'on roule sous le trait (7) ; rattraper le premier tir, trop fort, pour que le ruban rende le second juste (8) ; refermer la boucle et laisser la faille fabriquer l'élan (9, machine-énigme).
- Ketsu (10–12) : l'anneau du côté de la zone renvoie à l'opposé, il faut viser l'autre (10) ; la sortie est le point de départ : il faut entrer en montant pour repartir en montant (11) ; l'univers torique, deux traits, deux failles, un ruban, la couture (12, finale).

**Éléments introduits, dans l'ordre** : paire simple (1) · sortie en lieu clos à droite / à gauche (2) · faille orientée (flag) + deux entrées pour une sortie (3) · couture `wrap` (4) · faille tournante 90° (5) · trois failles en chaîne, rubans 2 / 10 / 10, sortie au-dessus du trait (6) · zone de pesanteur inversée `grav` (élément du monde 7) (7) · tube scellé + deux entrées réglées (fort / ruban 7) (8) · boucle d'élan à éjection automatique (9) · faille tournante 180°, deux entrées (10) · sortie = point de départ, tube en U violet (11) · deux paires + couture + ruban 10 + double trait (12).

**Cibles de P_hasard (Simon, DIFFICULTY_PROTOCOL)** : niveaux 1–5 ≤ 3 % · 6–9 de ≤ 3 % à ≤ 1,5 % (progressif ; niveau 8 ≤ 1,5 %) · 10–12 ≤ 1 %. P_ligne ≥ 85 %. Sans trait, la balle échoue ; la référence passe **toujours par le noyau** (vérifié partout).

**Bilan banc (v2, 26 oct.)** : `scratchpad/m9/v2.js`, moteur réel R287, emplacements 96–107, **4 000 lignes au hasard** par niveau, P_ligne sur 40 tracés bruités (σ = 3). Sans trait : échoue partout. Référence : réussit **avec le noyau** partout.

| Niveau | Titre | P_ligne | P_hasard | cible | conforme |
|---|---|---|---|---|---|
| 1 | La porte | 100 | 2,02 | ≤ 3 | oui |
| 2 | Le même élan | 70 | 2,40 | ≤ 3 | P_ligne à consolider (inchangé) |
| 3 | Le geyser | 80 | 1,43 | ≤ 3 | P_ligne à consolider (inchangé) |
| 4 | Le bord du monde | 100 | 2,75 | ≤ 3 | oui |
| 5 | Deux quarts de tour | 100 | 0,85 | ≤ 3 | oui |
| **6** | **La navette** (machine) | 100 | 0,10 | ≤ 3 | oui |
| **7** | **L'autre ciel** | 93 | 0,92 | ≤ 2,5 | oui |
| **8** | **Le métronome** (durci) | 100 | 0,73 | ≤ 1,5 | oui |
| 9 | Le moulin | 93 | 1,38 | ≤ 1,5 | oui |
| **10** | **Le contre-pied** | 93 | 0,13 | ≤ 1 | oui |
| **11** | **La reprise** | 100 | 0,38 | ≤ 1 | oui |
| 12 | L'univers torique | 88 | 0,10 | ≤ 1 | oui |

Deux traits au hasard (800 paires) : niveau 6 : 0 % · 7 : 1,88 % · 8 : 1,50 % · 10 : 0,88 % · 11 : 0,13 %. Le bruit à 40 essais fait varier P_ligne de ± 7 points.

**Ce que la refonte garde** : l'idée de l'actuel « Le bord du monde » (emplacement 101 de `levels.js`, devenu niveau 4, noyau déplacé) : prouvé, contournement bas, raisonnement pur. **Retirés** : « Le portail » et « À travers le mur » (la faille sert de porte, sans idée ; murs muets, scan 132) ; « Le geyser » actuel (refait au niveau 3 avec deux entrées) ; « Portail et mur », « L'élan transmis », « La sarbacane » (doser une chute vers une sortie : redondants entre eux) ; « Aller-retour », « La couture », « Le pli » (variantes du niveau 4, murs muets) ; « L'univers torique » actuel (un trait, contournable par patience) refait au niveau 12 ; le 26 oct., après le jeu de l'aperçu par Simon : « Au-dessus » (trop facile, pas une machine), « À travers » (ancien « Le trou de serrure » : ni énigme ni esthétique), « Le tir dans le dos » et « La faille dessinée » (trop semblables ; la seconde exigeait E-F).

---

## 1. Cadre commun (à lire avant les fiches)

### 1.1 Ce que la faille fait dans le moteur actuel (`engine.js`, `fields()` l. 587–595, `stepBranch()` l. 667)
1. `port:[[xA,yA,xB,yB,angle?,flag?]]`. Testé à **chaque sous-pas** (5 par trame) : centre de la balle à < 16 u de A → la balle est posée en B. **Sens unique** : B n'est jamais une entrée. Recharge : 14 trames (aucune paire n'agit pendant ce temps).
2. **Sans flag** : la vitesse est **tournée** de `angle` degrés (sens horaire à l'écran, y vers le bas). Angle 0 ou absent : vitesse intacte. 90 : chute → vers la gauche ; vers la droite → chute ; vers la gauche → montée ; montée → vers la droite.
3. **Avec flag** (`[…, angle, 1]`) : la balle ressort dans la direction `angle` (0 = droite, 90 = bas, 180 = gauche, −90 = haut) avec la **même norme** de vitesse. La direction d'entrée est oubliée ; seule la vitesse compte.
4. Plusieurs paires : la première dont A est touché gagne. Deux A peuvent mener au même B (niveaux 3, 8, 10).
5. **Couture** `wrap:[y0,y1]` : entre y0 et y1, x < 0 → x + 360 et x > 360 → x − 360 (l. 667). Les murs de bord doivent laisser la bande ouverte.
6. **Énergie gratuite** : B plus haut que A rend la balle plus haut sans la ralentir. C'est la source des boucles d'élan (niveau 9), des jets (niveau 3) et de la reprise (niveau 11). VMAX = 15,5 plafonne tout.
7. Ce qui compte pour la construction (leçons du banc) :
   - **Le roulement coûte cher** : FRIC = 0,995 par sous-pas de contact, soit ≈ 2,5 % de vitesse par trame en roulant. Les trajets roulés longs tuent l'élan ; préférer les vols et les pentes courtes.
   - **Une balle qui tombe sur une surface plate perd sa composante normale** (REST = 0,34) : l'énergie d'une chute ne se garde que par une réception tangente.
   - **Un tube de guidage fait ≥ 40 u de large** (balle 21 + 2 × 4 de contact + jeu) : à 28 u, la balle frotte les deux parois et perd la moitié de sa vitesse (niveau 5).
   - **B à ≥ 15 u de toute surface à pointes** (rayon 10,5 + épaisseur 4) : sinon la balle meurt en sortant (ancien niveau 8).
   - **Une petite bosse fait sauter la faille** : A a un rayon de 16 ; tout rebond de 20 u la fait manquer. Les jonctions courbe/sol doivent être tangentes (niveaux 2, 5).
   - **Un trait descendant ne rattrape pas un vol rapide et plat** : il reste sous la trajectoire. Pour capter un tir horizontal, incliner la sortie (niveau 12 : flag 160°), proposer un tremplin montant, ou **cueillir le vol à son sommet** (niveau 8 : vitesse verticale nulle, réception douce).
8. Rubans réglés (`curves` avec `v`, R299/R301) : tendent vers la vitesse cible (accélèrent ou **freinent**) de 0,62 par contact. Construits avec `ribbon(V, SP)` de `tools/refonte/rib.js` (Catmull-Rom dense découpé en tronçons de même vitesse). Ambre 0 · turquoise 2 · violet 7 · blanc-cyan 10.

### 1.2 Raccourcis génériques (à chercher dans chaque niveau)
- **R-a** ligne droite balle → zone (fermé partout : zones closes, sous plafond, ou derrière un mur plein).
- **R-b** **contourner la faille** : atteindre la zone sans passer par elle (boîtes scellées niveaux 1, 6, 12 ; mur plein niveaux 2, 4, 7) ; **zone plus haute que le départ** (niveaux 6, 10, 11 : aucun trait ne l'atteint sans l'énergie de la faille).
- **R-c** **la patience** : une boucle de failles qui finit par réussir au hasard d'un tour (niveau 12 avant correction ; niveau 10 avant ses murs à pointes, 0,9 → 0,13 %). Règle : **toute boucle non voulue doit finir sur des pointes** (niveau 12 : étagère à pointes sous le vol).
- **R-d** **la sortie touchée par la mauvaise face** : une trajectoire qui frôle A en rebondissant (bout de trait) ; mesuré dans P_hasard.
- **R-e** tir au hasard (P_hasard). Méthode qui a marché partout : **laisser dessinables les zones des leurres** (le joueur doit pouvoir se tromper), interdire seulement ce qui contourne.

### 1.3 Règle de non-redondance avec les autres mondes
La faille ne doit jamais servir de simple porte vers une rampe (monde 1), de tremplin (monde 3), ni de « pente qui monte » (monde 7). Chaque fiche dit ce que la faille **transforme** (position, sens, direction, vitesse, nombre de passages) ; si on la remplace par un trou ou un tunnel, le niveau doit devenir impossible. Le ruban (monde 3) apparaît aux niveaux 5, 6, 7, 8, 11, 12, toujours comme **régulateur** ou **chorégraphie**, jamais comme solution. Éléments d'autres mondes : la pesanteur inversée (monde 7) au niveau 7 seulement.

### 1.4 Langage visuel requis
- A bleu, B vert (existants). Faille orientée : `VX.rift` (corral d'atomes + onde stationnaire, R144) ; **E-V0 (rendu seul, petite)** : une flèche fine dans l'onde de B indique la direction de sortie (niveaux 3, 6, 7, 8, 9, 12). Sans elle, les niveaux 8 et 9 se lisent mal.
- Faille tournante (niveaux 5 et 10) : B dessiné avec un **arc fléché** (quart de cercle au 5, demi-cercle au 10). **E-V1 (rendu seul, petite)**. Niveau 11 : l'anneau vert entoure la balle au départ, il doit se voir avant le lancer.
- Paires multiples (niveaux 3, 6, 8, 10, 12) : couleur partagée par paire (teinte de l'anneau A = teinte de l'anneau B) ; deux A pour un B : deux fils de lumière convergents.
- Couture : `VX.seam` (existant) sur les deux bords, mêmes hauteurs.
- Machine (niveau 6) : la traînée s'étire avec la vitesse (lent sur le turquoise, très vite sur le J) ; ciel inversé (niveau 7) : rendu existant des zones `grav` du monde 7.

### 1.5 Hypothèses nouvelles (à ajouter au registre, Bible IX.2)
H38 « une faille est une porte : peu importe comment on y entre » (niveaux 2, 11) · H39 « la porte la plus proche est la meilleure » (3) · H40 « une faille qui tourne d'un quart ne peut pas renverser » (5) · H41 « un trait ne sert qu'une fois » (6) · H41b « on trace toujours sous la balle » (7) · H42 « freiner, c'est poser un obstacle ; il faut agir avant la faille » (8) · H43 « la faille ne crée rien » (9) · H44 « pour atteindre ce qui est à gauche, il faut aller à gauche » (10) · H45 « un piège sans fin est un échec » (6, 9) · H46 « la faille rend la hauteur, pas l'élan » (11).

---

## Monde 9, niveau 1 · La porte
- **Temps** : Ki 1, Simple, découverte. **Type** : ENTRER (conduire la balle à la faille).
- **Idée** : la boîte est scellée ; la seule entrée est l'anneau bleu, au bout d'une pente qu'il faut rejoindre.
- **Leurre** : viser la boîte (fermée par un toit et des nd) ; ne rien faire (la balle tombe sur les pointes).
- **Géométrie** (format `levels.js`) :
```js
{n:'La porte',ink:112,pal:'S',ball:[50,30],cup:[226,452,120,'B'],star:[186,148],
 w:[[0,470,220,470,2],[0,0,0,470,0],[290,262,356,262,0],[356,200,356,262,0],
    [220,360,352,360,0],[220,360,220,470,0],[352,360,352,452,0],[220,470,226,452,0]],
 curves:[{pts:[[138,114],[175,150],[220,210],[262,246],[292,262]],m:0}],
 nd:[[0,0,360,44],[0,130,360,350],[150,44,210,86]],
 port:[[326,251,286,400]],
 sol:[[[32,72],[136,106]]],solmat:0,tip:'La boîte est fermée. Le cercle bleu y mène.'}
```
- **Trajectoire de référence** : la balle tombe 30 u sur le pont, roule (≈ 3 u/trame), quitte le pont en (136,106), plonge le long de la pente courbe en prenant de la vitesse, passe le noyau (186,148), file sur la corniche jusqu'à A (326,251), réapparaît dans la boîte en (286,400) avec sa vitesse vers la droite, frappe la paroi droite et s'arrête au fond. ≈ 2,5 s.
- **Anti-contournement** : boîte à toit plein (y 360) et nd sur toute la moitié basse ; fenêtre dessinable limitée à la bande y 44–130 côté gauche : le trait doit relier la chute de la balle au **haut** de la pente (un trait plus bas laisse la balle tomber sous la pente, sur les pointes). Les traits gagnants au hasard sont tous des ponts presque horizontaux (même idée).
- **Extension** : aucune.
- **Difficulté visée / mesurée** : découverte, P_hasard ≤ 3 % → **2,19 %** ; P_ligne **100 %**.

## Monde 9, niveau 2 · Le même élan
- **Temps** : Ki 2, Simple. **Type** : ORIENTER L'ENTRÉE.
- **Idée** : la faille rend la balle **dans le sens où elle est entrée** ; entrée vers la gauche, elle ressort vers la gauche… dans les pointes ; il faut la faire entrer vers la droite.
- **Hypothèse** : H38. **Leurre** : laisser la balle dévaler la vallée (elle entre vers la gauche, ressort vers la gauche, meurt contre la paroi à pointes de la chambre) ; poser un frein devant la faille (elle entre lentement, toujours vers la gauche).
- **Géométrie** :
```js
{n:'Le même élan',ink:48,pal:'S',ball:[336,96],cup:[6,214,140,'R'],star:[120,420],
 w:[[0,56,152,56,0],[152,56,152,214,0],[0,56,0,214,2],[356,0,356,120,0]],
 curves:[{pts:[[352,96],[334,220],[300,360],[250,438],[180,452],[116,446],[66,418],[34,368],[20,300]],m:0}],
 nd:[[0,0,360,40],[0,40,160,180],[290,40,70,240],[0,452,360,28]],
 port:[[180,441,44,176]],
 sol:[[[256,446],[216,428]]],solmat:0,tip:'Ce qui entre dans la faille en ressort avec le même élan, dans le même sens.'}
```
- **Trajectoire de référence** : la balle dévale la grande courbe (une seule pièce, tangente au fond), rencontre le petit tremplin posé au pied (256,446)→(216,428), **saute par-dessus A**, retombe sur le flanc gauche de la vallée, remonte, redescend et repasse A **vers la droite** (≈ 4 u/trame) ; elle ressort en (44,176) vers la droite, roule sur le fond de la chambre et s'arrête contre la paroi droite. Le saut au-dessus de la faille, puis le retour dans l'autre sens, dessinent un « S » lisible.
- **Anti-contournement** : chambre scellée (toit y 56, paroi x 152) ; paroi gauche de la chambre en pointes : toute sortie vers la gauche meurt (pas de rebond salvateur, piège trouvé au banc) ; vallée étroite (pied gauche à x 72) pour que le retour garde sa vitesse ; encre 48 (un tremplin court seulement). Ouvrir les zones hautes au dessin (leurres possibles) a fait passer P_hasard de 3,8 à 2,2 %.
- **Extension** : aucune.
- **Difficulté** : Ki 2, P_hasard ≤ 3 % → **2,2–2,4 %** ; P_ligne **78–85 %** (à consolider : la vitesse de retour est juste ; piste : vallée gauche plus haute, ou chambre plus basse de 10 u).

## Monde 9, niveau 3 · Le geyser
- **Temps** : Ki 3, Relais (révélation de la faille orientée). **Type** : DESCENDRE POUR MONTER.
- **Idée** : deux anneaux bleus mènent au même geyser ; la faille relance vers le haut **aussi vite** que la balle est entrée : la porte proche (chute courte) donne un jet trop faible, il faut l'enjamber pour plonger dans la porte profonde.
- **Hypothèse** : H39. **Leurre** : ne rien faire (la balle roule dans la porte proche ; jet de 60 u, elle retombe dans le puits à pointes : premier lancer instructif) ; aider la balle à « mieux » entrer dans la porte proche.
- **Géométrie** :
```js
{n:'Le geyser',ink:110,pal:'S',ball:[26,36],cup:[96,292,92,'R'],star:[320,330],
 w:[[0,476,360,476,2],[40,262,40,476,0],[84,236,84,476,0],[356,0,356,476,0],
    [292,206,292,456,0],[292,456,356,456,0],[84,292,96,292,0],[188,250,188,292,0]],
 curves:[{pts:[[4,40],[30,104],[80,146],[130,160],[284,164]],m:0},              // corniche
         {pts:[[40,270],[42,232],[56,206],[86,192],[124,196],[150,212]],m:0}],  // hotte du geyser
 nd:[[0,0,360,80],[0,176,360,304],[284,80,76,96]],
 port:[[190,150,56,452,-90,1],[324,442,56,452,-90,1]],
 sol:[[[120,162],[210,118]]],solmat:0,tip:'La faille relance vers le haut ce qu’elle avale, aussi vite. Plus la chute est longue, plus le jet monte.'}
```
- **Trajectoire de référence** : la balle dévale la corniche, monte sur le **pont-capot** posé au-dessus de la porte proche (passe à 28 u de A1, au-delà des 16), s'envole au bout du pont, tombe dans le puits droit sur 280 u, entre dans A2 (324,442) à ≈ 13 u/trame, jaillit de B (56,452) vers le haut le long de la paroi du tube, épouse la hotte courbe, bascule vers la droite et tombe dans la zone. Le jet monte de 260 u en une seconde : moment fort.
- **Anti-contournement** : puits du geyser et hotte sous nd ; mur x 292 qui ferme le puits profond par la gauche ; un trait qui « freine » la balle avant A1 ne change rien (le jet reste faible) ; enjamber A1 demande un pont montant de 90–100 u. Au hasard, **0,9–1,4 %**.
- **Extension** : E-V0 (flèche de sortie) très utile ; non bloquante.
- **Difficulté** : P_hasard ≤ 3 % → conforme ; P_ligne **73–83 %** (à consolider : le pont doit passer assez haut au-dessus de A1 ; piste : abaisser A1 de 6 u, ou élargir le puits droit à 70 u).

## Monde 9, niveau 4 · Le bord du monde  *(gardé, noyau déplacé)*
- **Temps** : Shō 4, Simple. **Type** : SORTIR PAR LE BORD.
- **Idée** : entre les deux coutures, le bord droit et le bord gauche sont un seul lieu ; la zone, derrière un mur de pointes, s'atteint en sortant à droite.
- **Leurre** : chercher un passage dans le mur (pointes sur toute la hauteur, nd sur toute la moitié gauche).
- **Géométrie** :
```js
{n:'Le bord du monde',ink:110,pal:'S',ball:[290,40],cup:[12,470,140,'B'],star:[30,410],
 w:[[180,0,180,476,2],[180,476,360,476,2],[0,0,0,330,0],[0,400,0,476,0],[360,0,360,330,0],[360,400,360,476,0],[0,476,180,476,0]],
 nd:[[0,0,186,480]],wrap:[330,400],
 sol:[[[254,326],[346,365]]],solmat:0,tip:'Entre les deux bandes vertes, le bord droit et le bord gauche se touchent.'}
```
- **Trajectoire de référence** : chute de 280 u, la pente envoie la balle vers la droite ; elle franchit x 360 à y 359, réapparaît à gauche en (11,376), passe le noyau, tombe dans la zone.
- **Anti-contournement** : mur de pointes plein, sol de droite en pointes ; la bande est étroite (70 u) et basse. Au hasard **2,56 %**.
- **Extension** : aucune. **Difficulté** : P_hasard ≤ 3 % → conforme ; P_ligne **100 %**.

## Monde 9, niveau 5 · Deux quarts de tour
- **Temps** : Shō 5, **Relais**. **Type** : COMPOSER UNE ROTATION (passer deux fois par la même faille).
- **Idée** : la faille tourne la course d'un quart de tour ; une chute ressort vers la gauche, une course vers la gauche ressort vers le haut ; pour monter, il faut y entrer **deux fois**.
- **Hypothèse** : H40. **Leurre** : ne rien faire (tir horizontal qui meurt sur la bande de pointes ou contre la paroi gauche) ; attendre un tir vers le haut d'une seule entrée.
- **Géométrie** :
```js
{n:'Deux quarts de tour',ink:200,pal:'S',ball:[60,40],cup:[150,346,90,'L'],star:[200,420],
 w:[[0,0,0,480,2],[0,452,96,452,0],[96,452,250,452,2],[250,452,360,452,0],[310,270,310,384,0],[350,230,350,452,0]],
 curves:ribbon([[350,250],[330,212],[300,196],[262,200],[234,222],[220,258],[214,294]],[7,7,7,2,2,2]),
 nd:[[0,0,360,330],[0,330,84,150],[300,330,60,150]],
 port:[[60,441,330,402,90]],
 sol:[[[250,428],[86,446]]],solmat:0,tip:'La faille tourne la course d’un quart de tour.'}
```
- **Trajectoire de référence** : 1er passage, la balle tombe de 400 u dans A ; elle ressort en (330,402) **vers la gauche** à ≈ 15 u/trame, vole bas, se pose sur la longue passerelle (au-dessus de la bande de pointes), roule et repasse dans A **vers la gauche** ; 2e passage, elle ressort **vers le haut**, monte dans le tube (40 u), le ruban violet 7 l'enroule en arc, le turquoise 2 la ralentit et la dépose dans la zone. Chorégraphie : chute, tir rasant, retour, jaillissement, boucle.
- **Anti-contournement** : bande de pointes au sol entre la sortie et A ; toute la moitié haute en nd (la colonne de départ ne se touche pas) ; la passerelle doit être presque plate (une rampe raide fait entrer la balle de biais et le second tir part en diagonale dans le tube).
- **Extension** : E-V1 (quart de cercle fléché sur B) recommandé.
- **Difficulté** : P_hasard ≤ 3 % → **0,96 %** ; P_ligne **95–100 %**.

## Monde 9, niveau 6 · La navette  *(MACHINE, refaite le 26 oct.)*
- **Temps** : Shō 6, **Relais + machine** (montagnes russes de failles, REGLES §D). **Type** : SERVIR DEUX FOIS (le trait sert à l'aller et au retour).
- **Idée** : le trait lance la machine ; la machine fait tout le tour de l'écran et **rapporte** la balle sur le trait (l'anneau vert de la faille 2 plane juste au-dessus de lui) ; au retour, la balle remonte le trait et s'envole par son bout haut. Il faut donc orienter le trait **pour le retour** : son bout haut doit viser l'anneau bleu du coin, plus haut que le départ (inaccessible autrement).
- **Hypothèse** : « un trait ne sert qu'une fois ». **Leurre** : le pont évident balle → ruban turquoise (la machine tourne, la balle revient, remonte le trait, s'envole trop bas et meurt sur l'étagère à pointes) ; un trait trop plat (la balle retombe sur le turquoise : la machine tourne à vide jusqu'à l'échec au temps).
- **Géométrie** (format `levels.js`) :
```js
{n:'La navette',ink:135,pal:'S',ball:[110,80],cup:[130,272,100,'B'],star:[44,360],
 w:[[0,0,0,480,0],[356,0,356,480,0],[0,476,360,476,2],[120,200,240,200,2],[120,200,120,272,0],[240,200,240,272,0],[0,250,60,250,2]],
 curves:[].concat(
  ribbon([[156,166],[190,168],[230,170],[260,172],[276,176]],[2,2,2,2]),                                   // turquoise : départ lent
  ribbon([[300,140],[312,200],[318,265],[312,325],[292,382],[252,422],[196,444],[150,450],[120,450]],[10,10,10,10,10,10,10,10]), // J blanc-cyan
  ribbon([[30,440],[29,390],[33,346],[50,312],[80,292],[112,286]],[10,10,10,10,10])),                    // quart de tube
 nd:[[0,0,360,40]],
 port:[[110,439,42,440,-90,1],[262,331,140,126,208,1],[58,38,180,232,0,1]],
 sol:[[[64,60],[150,150]]],solmat:0,tip:'Ce que la machine emporte, elle le rapporte.'}
```
- **Trajectoire de référence (≈ 3,5 s)** : chute courte sur le trait, roulé jusqu'au ruban **turquoise 2** (lenteur, la machine s'éveille) ; chute le long du grand **J blanc-cyan 10** (la balle s'emballe, file au ras du sol vers la gauche) ; faille 1 → **geyser** vertical (−90°) ; quart de tube **10** qui la couche vers la droite ; vol ; faille 2 en plein vol → l'anneau vert posé au-dessus du trait la relance **vers le haut-gauche (208°)** ; elle remonte le trait, s'envole par son bout haut, passe la faille 3 du coin et tombe dans la boîte, sous le toit à pointes. Rythme : lent, très vite, jet, courbe, vol, retour, envol. Trois failles, trois sorties orientées (−90°, 208°, 0°), deux vitesses de ruban (2 et 10, contraste lent / très rapide).
- **Anti-contournement** : l'anneau du coin est **au-dessus du départ** (énergie : aucun trait ne l'atteint à l'aller) ; boîte de la zone fermée (toit à pointes) ; étagère à pointes à gauche (la retombée d'un mauvais retour meurt) ; sans trait, la balle tombe sur le toit à pointes.
- **Mesures (moteur R287, 4 000 lignes)** : sans trait **échoue** ; référence **réussit, noyau pris** ; P_hasard **0,10 %** (cible ≤ 3) ; deux traits au hasard 0 / 800 ; P_ligne **100 %** ; famille de solutions large (tout trait dont le bout haut vise l'anneau : 73–100 %).
- **Points faibles** : le raisonnement se découvre au premier essai (on voit la balle revenir) : c'est voulu pour une machine ; le noyau est sur le geyser (tous les déclenchements le prennent).
- **Extension** : aucune. E-V0 (flèche de sortie) utile pour la faille 2.

## Monde 9, niveau 7 · L'autre ciel  *(refait le 26 oct.)*
- **Temps** : Ten 7, Simple. **Type** : PENSER À L'ENVERS (derrière la faille, la pesanteur est retournée : élément du monde 7).
- **Idée** : la moitié droite est un ciel inversé, scellé ; la seule entrée est la faille. La balle y « tombe » vers le haut ; sous un trait, elle roule **contre sa face inférieure**, et « descend » vers son bout **le plus haut**. La zone est une poche au plafond, contre le mur central.
- **Hypothèse** : « un trait se pose sous la balle et elle descend vers son bout bas ». **Leurre** : incliner le trait vers la poche comme une rampe ordinaire, bout bas côté poche (la balle roule à l'opposé et meurt au plafond à pointes, vérifié) ; poser le trait sous la sortie (la balle s'en éloigne).
- **Géométrie** :
```js
{n:'L’autre ciel',ink:110,pal:'S',ball:[50,40],cup:[182,120,90,''],star:[300,130],
 w:[[0,0,0,480,0],[180,0,180,476,0],[356,0,356,480,0],[0,476,360,476,2],[182,60,272,60,0],[272,30,356,30,2]],
 curves:ribbon([[30,64],[34,150],[56,260],[96,360],[150,428]],[7,7,7,7]),   // glissade violette 7
 grav:[[182,0,178,480,0,-0.4]],                                              // ciel inversé
 nd:[[0,0,180,480]],
 port:[[158,434,220,330,75,1]],
 sol:[[[350,150],[276,80]]],solmat:0,tip:'Derrière la faille, on tombe vers le haut.'}
```
- **Trajectoire de référence (≈ 3,2 s)** : à gauche, la balle glisse le long du ruban **violet 7** en grande courbe jusqu'à la faille ; elle ressort à droite en plongeant (75°), freine, s'arrête et **remonte en accélérant** : un arc en U, miroir exact d'une chute ; elle frappe le dessous du trait, roule contre lui vers son bout haut, entre dans la poche et vient se poser contre le mur central, au plafond.
- **Anti-contournement** : mur central plein ; toute la moitié gauche en nd ; plafond à pointes hors de la poche ; plancher de la poche (ligne de la zone) qui ferme l'entrée par en dessous.
- **Mesures** : sans trait **échoue** ; référence **réussit, noyau pris** ; P_hasard **0,92 %** (cible ≤ 2,5) ; deux traits 1,88 % (15 / 800) ; P_ligne **93 %**.
- **Points faibles** : l'idée vient du monde 7 (gravité) ; la faille y est la seule porte (essentielle mais simple) ; la zone, dessinée comme une coupe ordinaire, se lit « à l'envers » (rendu à vérifier sur iPhone).
- **Extension** : aucune (zone `grav` existante).

## Monde 9, niveau 8 · Le métronome  *(durci le 26 oct.)*
- **Temps** : Ten 8, Relais. **Type** : RÉGULER EN DEUX TEMPS (rattraper le premier tir, trop fort, pour que le ruban le rende juste).
- **Idée** : même esprit (le ruban violet livre la vitesse 7), mais la balle tombe d'abord seule, au fond d'un tube, dans la faille 1 : le tir part à pleine vitesse et passe très au-dessus de la zone. Le joueur ne peut rien faire avant ; il doit **rattraper ce premier tir à son sommet** et le confier au ruban, dont le bout est une **seconde entrée vers la même sortie** : le second tir, à 7, est le bon.
- **Hypothèse** : H42 « freiner, c'est poser un obstacle » ; « il faut agir avant la faille ». **Leurre** : chercher à freiner la chute (tube en nd) ; renvoyer le tir fort vers la zone (garage couvert, entrée basse en nd) ; le renvoyer dans le tube (tir fort de nouveau).
- **Géométrie** :
```js
{n:'Le métronome',ink:85,pal:'S',ball:[20,40],cup:[130,452,80,'B'],star:[150,410],
 w:[[0,0,0,480,0],[40,0,40,476,0],[0,476,360,476,2],[356,0,356,300,0],[356,300,356,480,2],[130,350,216,350,0]],
 curves:ribbon([[246,184],[280,204],[308,224],[330,234],[346,232],[352,222]],[7,7,7,7,7]),
 nd:[[0,0,44,480],[44,340,180,136]],
 port:[[20,436,100,430,-80,1],[334,220,100,430,-80,1]],
 sol:[[[208,156],[280,176]]],solmat:0,tip:'La faille rend la vitesse qu’on lui donne. Le ruban, lui, la règle.'}
```
- **Trajectoire de référence (≈ 3,2 s)** : chute dans le tube (15 u/trame), faille 1, **grand tir** à −80° qui monte presque jusqu'en haut ; à son sommet la balle se pose en douceur sur le trait (vitesse verticale nulle), roule, glisse dans le **creux violet 7**, entre dans la faille 2 à 7 ; même anneau vert, **petit tir** mesuré qui passe sous le toit du garage et se pose dans la zone. Deux battements : fort, puis juste.
- **Anti-contournement** : tube scellé et nd (aucun frein possible avant la faille) ; garage à toit, entrée basse en nd (le tir fort ne s'y dépose pas) ; mur droit à pointes sous y 300 et sol à pointes (le tir fort non rattrapé meurt) ; le creux violet est hors de la retombée libre du tir fort (il passe à x 300 vers y 390).
- **Mesures** : sans trait **échoue** ; référence **réussit, noyau pris** ; P_hasard **0,73 %** (cible ≤ 1,5) ; deux traits 1,50 % (12 / 800) ; P_ligne **100 %** (famille : rampe descendante posée sous le sommet, 83–100 %).
- **Points faibles** : deux anneaux bleus pour un vert rappellent le niveau 3 (raisonnement différent : vitesse réglée, pas profondeur de chute) ; le creux violet est court (100 u).
- **Extension** : E-V0 utile (direction du tir).

## Monde 9, niveau 9 · Le moulin
- **Temps** : Ten 9, **Machine-énigme**. **Type** : FERMER LA BOUCLE (laisser la faille fabriquer l'élan).
- **Idée** : la sortie est plus haute que l'entrée ; un trait qui ramène la balle de la sortie à l'entrée referme une boucle, et chaque tour la relance plus vite, jusqu'à ce qu'elle s'en échappe d'elle-même par-dessus la faille.
- **Hypothèse** : H43, H45. **Leurre** : chercher une rampe vers la zone (trop haute, pointes partout) ; croire qu'un tour « pour rien » est un échec.
- **Géométrie** :
```js
{n:'Le moulin',ink:200,pal:'S',ball:[204,360],cup:[262,452,90,'B'],star:[120,330],
 w:[[0,0,0,480,0],[0,476,256,476,2],[256,452,262,452,0],[256,452,256,476,0],[356,0,356,452,0],
    [188,414,232,414,0],[232,414,232,452,0],[188,414,188,430,0]],
 nd:[[0,0,360,200],[0,452,360,28],[240,380,120,100]],
 port:[[208,400,30,300,0,1]],
 sol:[[[24,322],[190,414]]],solmat:0,tip:'Ce qui tombe dans la faille ressort à l’horizontale, aussi vite.'}
```
- **Trajectoire de référence** (3 tours, puis éjection) : chute courte dans A (≈ 4,6 u/trame) → B (30,300) vers la droite → réception douce sur la longue rampe → roule jusqu'au plateau de A ; 2e tour à ≈ 7,5 ; 3e tour à ≈ 11,6 : la parabole passe **par-dessus** A, frappe la paroi droite et retombe dans la zone. Trois arcs de plus en plus longs, comme une roue qui s'emballe : le spectacle *est* la solution.
- **Anti-contournement** : sol à pointes sur toute la largeur sous la rampe ; la sortie est à gauche, la zone à droite derrière la faille : seule une boucle donne assez de vitesse pour franchir le plateau. Les traits gagnants au hasard sont des rampes partielles qui referment aussi la boucle (même idée).
- **Machine (révélation, ≈ 4 s)** : la boucle elle-même ; proposer en finition un compteur de tours visuel (anneau B qui s'illumine un cran par passage, rendu seul).
- **Extension** : aucune requise.
- **Difficulté** : P_hasard ≤ 1,5 % → **1,07–1,28 %** ; P_ligne **88–90 %**.

## Monde 9, niveau 10 · Le contre-pied  *(refait le 26 oct.)*
- **Temps** : Ketsu 10, Simple. **Type** : PRENDRE À REBOURS (la faille tournante 180° renvoie tout dans l'autre sens).
- **Idée** : deux anneaux bleus mènent au même anneau vert, qui **retourne** la course (180°). La zone est en haut à gauche, plus haut que le départ. Celui du côté de la zone (gauche) renvoie la balle vers la droite ; il faut l'envoyer **à l'opposé**, dans l'anneau de droite, pour qu'elle reparte vers la gauche, en haut.
- **Hypothèse** : H44 « pour atteindre ce qui est à gauche, il faut aller à gauche ». **Leurre** : ne rien faire (la rampe fixe mène à l'anneau gauche : la balle ressort vers le haut-droite et meurt au mur à pointes, premier lancer instructif) ; rattraper ce tir (zone haute en nd).
- **Géométrie** :
```js
{n:'Le contre-pied',ink:110,pal:'S',ball:[200,200],cup:[4,120,90,''],star:[110,50],
 w:[[0,0,0,150,0],[0,150,0,480,2],[356,0,356,480,2],[0,476,360,476,2]],
 curves:[{pts:[[232,236],[200,250],[170,266],[140,286]],m:0}],      // rampe fixe vers la porte gauche
 nd:[[0,0,360,30],[110,30,250,170]],
 port:[[40,420,170,160,180],[314,340,170,160,180]],                  // deux entrées, une sortie tournante 180°
 sol:[[[194,222],[256,246]]],solmat:0,tip:'Ce qui entre dans la faille en ressort à rebours.'}
```
- **Trajectoire de référence (≈ 2 s)** : la balle roule vers la droite sur le trait, plonge dans l'anneau droit en descendant vers la droite ; l'anneau vert la rend **en montant vers la gauche**, comme un film rembobiné : grand arc qui passe le noyau et retombe dans la zone haute.
- **Anti-contournement** : zone plus haute que le départ (aucun trait direct) ; nd sur tout le haut (le tir faux ne se rattrape pas) ; mur gauche à pointes sous la zone et mur droit à pointes (les retombées et les boucles d'un tour à l'autre meurent : la patience ne paie pas, P_hasard passé de 0,9 à 0,13 %).
- **Mesures** : sans trait **échoue** ; référence **réussit, noyau pris** ; P_hasard **0,13 %** (cible ≤ 1) ; deux traits 0,88 % (7 / 800) ; P_ligne **93 %** (famille 83–98 %).
- **Points faibles** : rotation déjà vue au niveau 5 (90°) ; le « 180° » doit se lire sur l'anneau vert (E-V1) ; une fois le retournement vu au premier lancer, la solution suit vite.
- **Extension** : E-V1 recommandé (demi-cercle fléché sur B).

## Monde 9, niveau 11 · La reprise  *(refait le 26 oct., moteur actuel, remplace « La faille dessinée »)*
- **Temps** : Ketsu 11, moment unique. **Type** : REPARTIR DU DÉPART (la sortie de la faille est le point de départ de la balle).
- **Idée** : l'anneau vert entoure la balle au départ. Tout ce qui entre dans l'anneau bleu **repart de là**, avec sa vitesse et sa direction. La zone est en haut à gauche, plus haut que le départ : il faut qu'elle reparte **en montant vers la gauche**, donc qu'elle entre dans l'anneau en montant, par le tube violet en U.
- **Hypothèse** : « la faille rend la hauteur, pas l'élan » / « viser l'anneau suffit ». **Leurre** : faire tomber la balle droit dans l'anneau par le trou du toit (petit trait presque vertical, par exemple (192,118)→(199,155) : elle repart du départ… vers le bas, et meurt) ; la jeter vers la gauche (rien).
- **Géométrie** :
```js
{n:'La reprise',ink:110,pal:'S',ball:[210,60],cup:[4,62,130,''],star:[140,40],
 w:[[0,0,0,480,0],[356,0,356,480,0],[0,476,360,476,2],[256,290,302,290,2],[302,196,302,290,2]],
 curves:ribbon([[344,140],[346,220],[340,290],[322,336],[296,358],[266,360],[244,346],[228,322]],[7,7,7,7,7,7,7]),
 nd:[[0,0,360,20],[0,20,160,60],[220,286,90,100]],
 port:[[238,308,210,60]],                       // B = le départ
 sol:[[[200,100],[280,124]]],solmat:0,tip:'La faille te rend ton départ, avec ton élan.'}
```
- **Trajectoire de référence (≈ 2,7 s)** : la balle roule sur le trait, est jetée dans le haut du couloir droit, glisse dans le **U violet 7**, remonte et traverse l'anneau bleu **en montant** ; elle réapparaît **à son point de départ** et part en grand arc vers la gauche, passe le noyau et se pose au fond de la zone. Le geste se lit comme une seconde chance : même départ, avec l'élan en plus.
- **Anti-contournement** : zone au-dessus du départ (énergie) ; toit à pointes au-dessus du U, percé seulement au-dessus de l'anneau (l'entrée par le haut reste possible, c'est le leurre) ; paroi à pointes qui ne laisse entrer dans le U que par le haut du couloir ; nd dans le U.
- **Mesures** : sans trait **échoue** ; référence **réussit, noyau pris** ; P_hasard **0,38 %** (cible ≤ 1) ; deux traits 0,13 % (1 / 800) ; P_ligne **100 %** (famille 90–100 %) ; seconde famille rare : rouler dans le bas du U par la gauche (même idée).
- **Points faibles** : parent du niveau 2 (la faille garde l'élan) ; le toit et la paroi à pointes sont des obstacles de fermeture, peu « naturels ».
- **Extension** : **aucune** (E-F n'est plus nécessaire).

## Monde 9, niveau 12 · L'univers torique
- **Temps** : Ketsu 12, **Finale, NIVEAU SPÉCIAL** (deux traits qui coopèrent). **Rappel renversé du niveau 1** : au niveau 1 la faille menait dans la boîte ; ici il faut deux failles, la couture et deux traits pour y parvenir.
- **Type** : COMPOSER (déplacer + régler + recoudre + rattraper).
- **Idée** : le ruban blanc donne à la balle une vitesse exacte, la faille orientée la tire vers la gauche, la couture la rend par la droite, et un second trait la soulève dans la galerie dont la faille mène à la boîte.
- **Leurre** : un seul trait (la boucle tourne sans fin : ruban → faille → tir → retombée → ruban…, jusqu'à ce que le tir manqué se pose sur l'étagère à pointes) ; viser la boîte directement (scellée) ; entrer dans la galerie par la gauche (mur et toit).
- **Géométrie** :
```js
{n:'L’univers torique',ink:130,pal:'S',ball:[40,40],cup:[134,100,92,'B'],star:[330,200],
 w:[[0,476,360,476,2],[0,0,0,100,0],[0,220,0,476,0],[360,0,360,100,0],[360,220,360,476,0],
    [128,20,232,20,0],[128,20,128,100,0],[232,20,232,100,0],              // boîte scellée
    [190,250,262,250,0],[190,210,262,210,0],[190,210,190,250,0],          // galerie ouverte à droite
    [246,340,356,340,2]],                                                 // étagère à pointes sous le vol
 curves:ribbon([[56,130],[96,156],[126,214],[146,296],[184,384],[236,438],[300,452],[352,452]],[10,10,10,10,10,10,10]),
 wrap:[100,220],
 nd:[[0,0,360,60],[120,0,120,110],[0,330,360,150]],
 port:[[300,441,40,170,160,1],[214,236,180,60]],
 sol:[[[16,96],[52,128]],[[316,262],[262,250]]],solmat:0,tip:'Les bords se touchent, les failles relient : deux traits, une seule trajectoire.'}
```
- **Trajectoire de référence** : trait 1, un court pont pose la balle au sommet du ruban blanc ; longue descente en S réglée à 10 jusqu'à A1 (300,441) ; B1 (40,170) la tire vers la gauche, légèrement plongeante (160°) ; elle franchit le bord gauche dans la bande, réapparaît à droite, passe le noyau (330,200), rencontre le trait 2, petit tremplin **montant** vers la gauche, qui la hisse dans la galerie ; elle roule jusqu'à A2 (214,236) et réapparaît dans la boîte (180,60). ≈ 2 s, une seule ligne continue à travers trois plis de l'espace.
- **Anti-contournement** : boîte scellée ; galerie fermée à gauche et en haut (le contournement « un trait, droit dans A2 » mesuré à 4,4 % avant fermeture) ; étagère à pointes sous le vol (avant elle, la boucle sans fin finissait par réussir au hasard d'un tour : raccourci R-c, mesuré) ; sortie inclinée à 160° pour que le vol descende assez pour être capté (un vol horizontal passe au-dessus de tout trait descendant).
- **Extension** : E-V0 recommandé (direction du tir de B1).
- **Difficulté** : P_hasard ≤ 1 % → **0,12 %** (un trait), **0,20 %** (deux traits au hasard, 1 500 paires) ; P_ligne **90–95 %**.

---

## Matrice de non-redondance

| Niveau | Titre | Ce que la faille transforme | Raisonnement (verbe) | Faille | Autres éléments | Geste du trait |
|---|---|---|---|---|---|---|
| 1 | La porte | position (lieu clos) | ENTRER | simple, 0° | courbe fixe | pont vers une pente |
| 2 | Le même élan | sens conservé | ORIENTER L'ENTRÉE | simple, 0° | vallée courbe | tremplin pour **sauter la faille** et revenir |
| 3 | Le geyser | direction imposée, vitesse gardée | DESCENDRE POUR MONTER | orientée −90°, **2 entrées → 1 sortie** | hotte courbe | capot **au-dessus** d'une porte |
| 4 | Le bord du monde | position par la couture | SORTIR PAR LE BORD | — (wrap) | mur de pointes | pente vers le bord |
| 5 | Deux quarts de tour | rotation 90°, **deux passages** | COMPOSER UNE ROTATION | tournante 90° | **ruban 7 → 2** | passerelle **après** la faille |
| 6 | La navette | ramène la balle au trait, par en dessous | SERVIR DEUX FOIS | **3 paires** orientées (−90°, 208°, 0°) | **rubans 2 / 10 / 10**, toit à pointes | trait **orienté pour le retour** |
| 7 | L'autre ciel | passage vers une pesanteur inversée | PENSER À L'ENVERS | orientée 75° | **`grav` inversée** (monde 7), ruban 7 | trait **au-dessus**, incliné vers son bout haut |
| 8 | Le métronome | vitesse rendue, deux entrées | RÉGULER EN DEUX TEMPS | orientée −80°, **2 entrées → 1 sortie** | tube scellé, **creux ruban 7**, garage | rampe sous le **sommet** du premier tir |
| 9 | Le moulin | énergie gratuite (B > A) | FERMER LA BOUCLE | orientée 0° | — | rampe de retour **sortie → entrée** |
| 10 | Le contre-pied | course retournée | PRENDRE À REBOURS | **tournante 180°**, 2 entrées | rampe fixe, murs à pointes | rampe vers **la porte opposée** |
| 11 | La reprise | renvoi **au point de départ**, élan gardé | REPARTIR DU DÉPART | simple, B = départ | **U ruban 7**, toit percé | jet vers le haut du couloir (entrer **en montant**) |
| 12 | L'univers torique | tout | COMPOSER | orientée 160° + simple | wrap, **ruban 10** | **deux traits** : pont + tremplin montant |

Aucun verbe ne se répète. Parentés assumées : 2 et 11 (la faille garde l'élan) — sens gauche/droite au 2, montée/descente et retour au départ au 11 ; 3 et 8 (deux entrées, une sortie) — profondeur de chute au 3, vitesse réglée par le ruban au 8 ; 5 et 10 (faille tournante) — composer deux quarts au 5, choisir la porte opposée au 10. Rubans : 5, 6, 7, 8, 11, 12 (régulateurs ou chorégraphie, jamais la solution).

## Extensions moteur proposées (hiérarchisées)
1. **E-V0 · Flèche de sortie des failles orientées (rendu seul, très petite)** : une flèche fine dans l'onde de `VX.rift`, orientée selon `pp[4]`. Requise pour la lisibilité des niveaux 8 et 9 ; utile aux niveaux 3, 6 et 12.
2. **E-V1 · Quart de cercle fléché sur B des failles tournantes (rendu seul, petite)** : signe l'angle de rotation (`pp[4]` sans flag). Requise pour les niveaux 5 et 10 (90° et 180° ; sans elle, la rotation se découvre au premier lancer : acceptable, mais muet).
3. **E-V2 · Compteur de passages (rendu seul, petite)** : l'anneau B s'illumine d'un cran à chaque passage (remis à zéro au lâcher). Utile au niveau 9 (on voit la boucle s'emballer).
4. **E-F · Faille dessinée (moyenne, ≈ ½ lot)** : **plus nécessaire** — le niveau 11 « La reprise » est natif (26 oct.). Gardée pour mémoire (piste pour un monde ultérieur).
- **Non requises (pour mémoire)** : couture verticale (haut/bas) — séduisante (« chute sans fin » native), mais une paire verticale donne déjà cette image ; faille mobile (`mov` sur `port`) — introduit le minutage, contraire aux règles ; filtre par la recharge de 14 trames (A posé sur B) — trop fragile, invisible.

## Auto-critique (une ligne par niveau)
- **Niveau 1** : découverte honnête ; le geste (un pont) est du monde 1, l'enjeu (la boîte) suffit pour un premier niveau.
- **Niveau 2** : le meilleur eurêka du début (sauter la faille pour y rentrer à l'envers) ; P_ligne fragile (70 % au banc v2), la vitesse de retour est juste.
- **Niveau 3** : deux portes vers un geyser, très lisible ; P_ligne 80 % : le pont doit passer à > 16 u de A1, marge à élargir.
- **Niveau 4** : gardé tel quel ; simple, nécessaire pour annoncer le niveau 12.
- **Niveau 5** : composition élégante (90° + 90° = 180°) et chorégraphie ruban ; on peut réussir sans formuler la règle, c'est le propre d'un Relais.
- **Niveau 6** : vraie machine (3 failles, 3 rubans à 2 vitesses, 7 changements de rythme) ; l'énigme (orienter le trait pour le retour) se découvre en un essai : c'est un Relais, pas un casse-tête.
- **Niveau 7** : le plus beau miroir du monde (l'arc en U) ; l'idée est empruntée au monde 7, la faille n'y est qu'une porte, mais la seule.
- **Niveau 8** : le ruban garde son rôle de métronome ; le second temps est réellement plus difficile (il faut renoncer à agir avant la faille) ; parenté de structure avec le niveau 3.
- **Niveau 9** : la machine-énigme du monde ; la boucle tolère des rampes partielles (même idée) ; l'éjection automatique est le moment le plus spectaculaire.
- **Niveau 10** : renversement net de H44 sans couture ; la rotation rappelle le niveau 5 ; une fois le retournement vu, la solution suit vite.
- **Niveau 11** : natif, image forte (la balle repart de son propre départ) ; parent du niveau 2 par la conservation de l'élan ; toit et paroi à pointes un peu artificiels.
- **Niveau 12** : vraie finale à deux traits, contournements mesurés et fermés ; la galerie demande un tremplin montant court (P_ligne 88–95).

## Ordre de construction recommandé
1. **Niveaux 1, 4, 5, 6, 8, 11** : natifs, prouvés, P_ligne 100.
2. **Niveaux 7, 9, 10, 12** : natifs, prouvés (P_ligne 88–93) ; poser E-V0 / E-V1 en même temps (rendu seul).
3. **Niveaux 2, 3** : natifs, prouvés, **P_ligne à remonter ≥ 85** (pistes dans chaque fiche) avant intégration.
Source unique : `scratchpad/m9/v2.js` (12 entrées, format `levels.js`, rubans par `tools/refonte/rib.js`). Rejouer ensuite `tools/hasard.js` sur les 12 (3 000 / 6 000 tirages) et vérifier chaque niveau sur iPhone (non testé ici : rendu de la zone du niveau 7, lisibilité du 180° au niveau 10, de l'anneau vert autour de la balle au niveau 11).
