# QUANTIX — Cahier des charges de la conception des niveaux

*Version R75. Ce document remplace, pour la conception des niveaux, toutes les règles antérieures (§11 du handbook,
DIFFICULTY_PROTOCOL, SCENARIO_PROTOCOL, ENIGME_PROTOCOL). Il est opposable : un niveau qui ne le respecte pas n'entre pas
dans le jeu.*

---

## 1. Finalité

**Chaque niveau est une énigme unique et référencée.** Il pose une question précise ; une seule idée y répond ; tout ce qui
est posé à l'écran sert cette question ; aucun chemin de traverse ne permet d'éviter la difficulté. D'un niveau à l'autre, le
joueur doit **changer de manière de penser** : deux niveaux d'un même monde ne se résolvent jamais par le même raisonnement.

**Rien n'est laissé au hasard** : ni la géométrie (dessinée d'après des mesures du moteur, §6), ni la difficulté (mesurée,
§8), ni l'absence de raccourci (cherchée activement, §8), ni la place du niveau dans le jeu (registre, §10).

---

## 2. Vocabulaire (définitions opposables)

| Terme | Définition |
|---|---|
| **Énigme** | la question posée par le niveau, formulée en une phrase (« comment monter plus haut que le départ ? ») |
| **Idée** (ou clé) | la réponse, formulée en une phrase (« le tapis est la seule source d'élan : il faut une rampe à sa sortie ») |
| **Type de raisonnement** | la manière de penser que l'idée exige, choisie dans le référentiel §4 (code `R‑xx`) |
| **Famille de solutions** | l'ensemble des solutions qui mettent l'idée en œuvre ; techniquement : celles qui utilisent **tous** les éléments porteurs (§3) |
| **Élément** | tout objet posé : mur, plaque, tapis, glace, pointes, zone interdite, champ (vent, gravité, aimant, portail, paroi mobile), noyau, matière offerte au joueur |
| **Rôle** | la fonction d'un élément dans l'énigme : PORTER, FERMER, PIÉGER, SIGNALER (§3) |
| **Raccourci** | toute solution qui réussit sans appartenir à la famille de l'idée |
| **Leurre** | la fausse bonne idée que le joueur essaiera d'abord ; elle doit échouer, de manière visible et compréhensible |
| **Chute** | le moment où le joueur comprend ; on doit pouvoir le décrire (« en voyant la particule caler au milieu du pont plat ») |
| **Référence** | l'identifiant unique du niveau : `Q‑MM‑PP‑Rxx` (monde, position, type de raisonnement) |

---

## 3. Les rôles des éléments — aucun élément sans rôle

Chaque élément posé reçoit **un rôle écrit** dans la fiche du niveau :

| Rôle | Signification | Preuve exigée (contrôle automatique) |
|---|---|---|
| **PORTER** | la solution s'appuie dessus (contact) ou le traverse (champ) | la trajectoire de la solution de référence le touche ou le traverse |
| **FERMER (raccourci nommé)** | il interdit un chemin précis, nommé dans la fiche | le retirer **ouvre** ce chemin : au moins une solution hors famille apparaît |
| **PIÉGER** | il rend le leurre séduisant puis le fait échouer | sans lui, le leurre ne serait pas tenté **ou** réussirait |
| **SIGNALER** | il rend lisible un danger déjà réel (pointes au fond d'un vide qui tue déjà) | **interdit sauf exception notée** : un signal est un décor ; il est retiré ou converti en élément qui ferme un chemin |

**Règle de sobriété** : à énigme égale, le niveau qui a le moins d'éléments est le meilleur. Tout élément dont le retrait ne
change rien est supprimé.

**Matières offertes au joueur** (structure, rebond, élan, corde…) : ce sont des éléments comme les autres. On n'offre une
matière que si l'idée l'exige ou si elle porte le leurre ; chaque matière offerte doit avoir été testée dans la recherche de
raccourcis (§8). Un accélérateur ou une plaque de rebond offerts librement créent de l'énergie n'importe où : ils ne sont
offerts que si l'énigme en dépend et si les raccourcis qu'ils ouvrent sont fermés.

---

## 4. Référentiel des types de raisonnement (`R‑xx`)

Chaque type décrit une **manière de penser**, indépendante de la mécanique ; chaque monde la **réécrit** avec sa mécanique.

| Code | Type | Ce que le joueur doit comprendre |
|---|---|---|
| R‑01 | **Découvrir** | ce nouvel élément sert à quelque chose : il faut y amener la particule |
| R‑02 | **Ponter** | un vide fatal se franchit en construisant dessus |
| R‑03 | **Sauter** | le vide est trop large (énergie insuffisante pour un pont) : il faut prendre de la hauteur avant |
| R‑04 | **Inverser** | la zone est derrière : il faut un demi‑tour |
| R‑05 | **Rattraper** | elle va trop vite / trop loin : la cueillir en vol, plus loin qu'on ne croit |
| R‑06 | **Doser** | trop d'élan est aussi grave que pas assez : réduire, retarder, entrer plus bas |
| R‑07 | **Relayer** | un appui ne suffit pas ; deux, placés l'un après l'autre, oui |
| R‑08 | **Protéger** | une suite de dangers gardés : poser des boucliers aux bons endroits |
| R‑09 | **Éviter** | l'élément visible est un piège : la clé est de ne **pas** l'utiliser |
| R‑10 | **Détourner** | le chemin direct est fermé : faire le tour (par le haut, par l'arrière) |
| R‑11 | **Boucler** | la particule doit repasser deux fois au même endroit |
| R‑12 | **Orienter** | le sens du tracé compte (tapis tracé à l'envers, rampe inclinée dans l'autre sens) |
| R‑13 | **Économiser** | l'énergie ne permet qu'une seule construction utile : la trouver |
| R‑14 | **Contre‑pied** | l'évidence est fermée ; la solution part à l'opposé |
| R‑15 | **Synchroniser** | le bon moment compte (paroi mobile, porte) |
| R‑16 | **Tracer en vol** | une partie de la construction se fait pendant la chute |
| R‑17 | **Utiliser le danger** | l'élément dangereux est aussi la clé (rebondir près des pointes, passer dans le vent contraire) |
| R‑18 | **Choisir** | deux chemins ou deux versions de la particule ; un seul mène à la zone (quantique) |
| R‑19 | **Combiner** | deux mécaniques du monde qui ne fonctionnent qu'ensemble |
| R‑20 | **Synthèse** | fin de monde : enchaîner deux raisonnements déjà vus, dans un ordre imposé |

**Règle d'unicité** : dans un monde, **un type au plus une fois** (sauf R‑20 en position 12). D'un monde à l'autre, un type
peut revenir s'il est transformé par la mécanique (R‑02 « ponter » au Glacier ≠ R‑02 dans un vent contraire).

---

## 5. La fiche du niveau (obligatoire, écrite AVANT toute géométrie)

```
Référence      : Q-05-02-R17
Titre (fr/en)  : Vent de face / Headwind
Énigme         : comment traverser quand le vent repousse ?
Idée           : donner au pont assez de pente pour vaincre le vent
Raisonnement   : R-17 Utiliser le danger
Leurre         : un pont en pente douce (suffirait sans vent ; cale avec)
Chute          : la particule cale au milieu du pont doux et revient
Raccourcis à fermer, et par quoi :
  K1 ligne directe départ → zone        → fermé par : la fosse (aucune ligne ne la survole sans pente)
  K2 rebond sur la paroi droite          → fermé par : (rien : vérifier — le contrôle dira s'il existe)
Éléments et rôles :
  pente de départ  PORTER
  zone de vent     PORTER (c'est l'obstacle de l'idée) + PIÉGER (fait échouer le leurre)
  poteau du plateau PORTER (la zone en hauteur)
Matières offertes : structure seule (l'élan offrirait K3 : traverser en accélérant)
Étalonnage utilisé : vent fx 0,16 ; pente nécessaire > 25° (mesure §6)
Énergie         : 1,3 × coût de la solution de référence
Position / cible : P2 — P_hasard ≤ 4 %, coût minimal ≥ 40 u
```

La fiche est rangée dans `tools/fiches/NN.js` (paramètres + boîtes du geste + leurre) **et** dans le registre (§10).

---

## 6. Étalonnage des mécaniques (mesuré dans le moteur, `tools/banc.js`)

On ne dessine jamais une énigme sans connaître ce que la mécanique permet. Mesures R75 :

| Mécanique | Mesure | Conséquence de conception |
|---|---|---|
| **Changement de pente** (structure jointive) | vitesse conservée à 99–107 % de 10° à 90° | les virages ne cassent pas la vitesse si les segments sont **jointifs** ; les arrêts observés auparavant venaient de bouts qui dépassent ou de fentes plus étroites que la particule (21 u) |
| **Tapis d'élan** | hauteur gagnée sur une rampe de 15° : **≈ 40 u, quelle que soit la longueur du tapis** (40 à 240 u) | le tapis est un interrupteur, pas un amplificateur : une zone ne peut pas être plus de ~40 u au‑dessus du tapis ; un tapis long n'apporte rien |
| **Plaque de rebond** | remonte à 150–200 % de la hauteur de chute | le rebond **crée** de l'énergie : c'est la mécanique de la hauteur ; offerte au joueur, elle ouvre presque toujours des raccourcis |
| **Saut depuis la glace** | après 60 u de descente : 96 u de portée avant de perdre 40 u ; après 120 u : 137 u | dimensionner les crevasses : plus larges que la portée = pont obligatoire ; moins larges = saut possible |
| **Colonne d'air montante** (90 u, force −0,45 à −0,65) | soulève de 500 à 700 u : sort toujours par le haut | une colonne verticale seule ne dépose nulle part : il faut une composante latérale ou un toit pour en sortir |
| **Vent latéral** | dérive de ~24 u par 0,1 de force sur 200 u de chute | un vent de 0,2 décale une chute de ~50 u : de quoi manquer une zone de 60 u |

**À mesurer avant de concevoir les mondes suivants** : gravité locale (sens, intensité), aimant (rayon utile, force à la
distance), portails (vitesse et direction conservées), parois mobiles (période, amplitude), corde et corps mou, effets
quantiques (superposition, détecteur, dilatation).

---

## 7. Règles de conception

1. **Énergie** : encre = 1,2 à 1,3 × coût de la solution de référence. La solution doit **consommer** l'énergie.
2. **Coût minimal** : aucun trait plus court que 40 u (positions 1–3), 80 u (4–8), 120 u (9–12) ne réussit, ou bien le niveau
   exige deux traits.
3. **Jouable au doigt** : la solution de référence, tracée à la ligne droite avec ±3 u d'erreur aux extrémités, réussit ≥ 85 %
   (exception motivée et notée à 80 %).
4. **Marges** : aucune fente plus étroite que 30 u ; aucun bout de segment qui dépasse dans la trajectoire ; un vide qui tue
   tue vraiment (sinon la particule « continue » sur l'étage du dessous et l'énigme s'effondre).
5. **Lisibilité** : l'énigme doit être perceptible en 10 s de regard : le danger, la zone et l'élément porteur sont visibles ;
   les zones interdites ne cachent pas l'élément porteur.
6. **Noyau** : placé sur la trajectoire de la solution de référence, à un endroit qui récompense l'idée (pas sur le chemin
   d'un raccourci).
7. **Conseil (tip)** : il nomme l'énigme, jamais l'idée (« le vent la repousse… », pas « fais un pont pentu »).

---

## 8. Validation — les portes (toutes obligatoires, dans l'ordre)

| Porte | Contrôle | Outil | Critère de passage |
|---|---|---|---|
| **G0** | Fiche complète (§5), type de raisonnement libre dans le monde (§4), rôles écrits | relecture | aucun champ vide |
| **G1** | Géométrie : échec sans trait ; solution de référence réussit ; P_ligne ≥ 0,85 ; coût minimal ; P_hasard ≤ cible ; énergie serrée ; noyau sur la trajectoire ; champ indispensable (ou champ‑obstacle prouvé) | `fiche.js` | « CONFORME » |
| **G2** | Énigme : idée présente (éléments PORTER touchés), **0 raccourci** (lignes directes dans chaque matière + 2 500 traits au hasard + raccourcis nommés de la fiche), **0 élément inutile** | `enigme.js` | « ÉNIGME ✓ » |
| **G3** | Lecture : capture du niveau et de la solution ; énigme lisible en 10 s | `fview.py` + capture en jeu | relu et décrit en une phrase |
| **G4** | Unicité : type de raisonnement absent du reste du monde ; niveau non jumeau d'un autre (même gabarit + même mise en scène) | registre §10 | aucune redite |
| **G5** | **Test de Simon** : défi compris ? autre chemin trouvé ? | jeu | validé, ou retour consigné et niveau repris |

Un niveau n'est marqué **fait** qu'après G5. Avant, il est **candidat**.

---

## 9. Progression et difficulté

| Position | Rôle dans le monde | P_hasard | Coût minimal |
|---|---|---|---|
| 1–2 | présenter la mécanique (R‑01 de préférence) | 1 à 4 % | 40 u |
| 3–5 | premières variations | 0,4 à 1,5 % | 40–80 u |
| 6–9 | idées contre‑intuitives (R‑09, R‑12, R‑14, R‑17…) | 0,1 à 0,5 % | 80 u |
| 10–12 | deux traits, synthèse (R‑19, R‑20) | ≤ 0,2 % (un trait : ~0) | 120 u ou deux traits |

---

## 10. Registre de référence (plan des 132 niveaux)

*État au R75 : ✓ = énigme validée par G2 (reste G5) ; ○ = à reconstruire ; les types sont **planifiés** — G0 peut les échanger
à l'intérieur d'un monde, jamais les dupliquer.*

### Monde 1 — Atelier (structure)
| Pos. | Réf. | État | Type |
|---|---|---|---|
| 1 | Q‑01‑01 | ○ (le trait n'utilise aucun élément) | R‑01 Découvrir (le trait comme pont) |
| 2 | Q‑01‑02 | ✓ Le pont | R‑02 Ponter |
| 3 | Q‑01‑03 | ✓ Le demi‑tour | R‑04 Inverser |
| 4 | Q‑01‑04 | ✓ Le relais | R‑07 Relayer |
| 5 | Q‑01‑05 | ✓ La douceur | R‑06 Doser |
| 6 | Q‑01‑06 | ○ (pointes inutiles) | R‑10 Détourner |
| 7 | Q‑01‑07 | ✓ Économie | R‑13 Économiser |
| 8 | Q‑01‑08 | ○ | R‑05 Rattraper |
| 9 | Q‑01‑09 | ○ | R‑09 Éviter |
| 10 | Q‑01‑10 | ○ (un mur inutile) | R‑14 Contre‑pied |
| 11 | Q‑01‑11 | ✓ Le relais | — *(doublon de type avec 4 : à reprendre en R‑08 Protéger)* |
| 12 | Q‑01‑12 | ○ (deux éléments inutiles) | R‑20 Synthèse |

### Monde 2 — Fonderie (rebond)
| Pos. | Type planifié | État mesuré |
|---|---|---|
| 13 | R‑01 Découvrir (la plaque fait monter) | ○ 5 raccourcis |
| 14 | R‑04 Inverser (ricochet) | ✓ |
| 15 | R‑03 Sauter | ✓ |
| 16 | R‑06 Doser (la hauteur juste) | ○ 2 raccourcis |
| 17 | R‑17 Utiliser le danger (rebondir près du sol brûlant) | ○ |
| 18 | R‑12 Orienter (plaque tracée par le joueur) | ○ idée absente |
| 19–24 | R‑07, R‑09, R‑10, R‑11, R‑19, R‑20 | à auditer (contrôle interrompu au 18) |

### Monde 3 — Chaîne (élan) — **entièrement à reconstruire** (audit R74 : 0/12)
| Pos. | Type | Énigme planifiée (contrainte d'étalonnage) |
|---|---|---|
| 25 | R‑01 Découvrir | la zone est ≤ 40 u au‑dessus du tapis et au‑dessus du départ : seul le tapis y mène |
| 26 | R‑04 Inverser | le tapis pousse vers les pointes, la zone est derrière : prendre l'élan à rebours |
| 27 | R‑06 Doser | le tapis lance trop loin : entrer dans la zone par le haut, freinée par une montée |
| 28 | R‑07 Relayer | deux tapis à deux hauteurs ; le trait relie le premier au second (+40 u puis +40 u) |
| 29 | R‑12 Orienter | le joueur trace le tapis : son sens décide de tout |
| 30 | R‑09 Éviter | le tapis visible mène aux pointes ; la clé passe par une pente sans tapis |
| 31 | R‑10 Détourner | la zone est derrière un mur : le tapis donne l'élan d'un détour par le haut |
| 32 | R‑11 Boucler | deux passages sur le même tapis (la boucle se construit) |
| 33 | R‑13 Économiser | élan offert mais cher : un seul tapis court, au seul endroit utile |
| 34 | R‑14 Contre‑pied | la ligne directe est fermée ; la solution part dans l'autre sens |
| 35 | R‑16 Tracer en vol | le second appui se trace pendant le vol |
| 36 | R‑20 Synthèse | Relayer + Orienter |

### Mondes 4 à 11 — types planifiés (énigmes à écrire en G0)
| Monde | Mécanique | Types (positions 1 → 12) |
|---|---|---|
| 4 Glacier | glace (on ne freine plus) | R‑02 ✓Le lac · R‑05 · R‑03 · R‑04 · R‑06 · R‑13 · R‑10 · R‑08 · R‑14 · R‑09 · R‑07 · R‑20 |
| 5 Soufflerie | vent | R‑01 · R‑17 · ✓R‑19 (51) · R‑12 · R‑07 · R‑09 · R‑06 · R‑10 · R‑08 · R‑16 · R‑14 · R‑20 |
| 6 Mécanique | parois mobiles | R‑01 · R‑15 · R‑02 (où la paroi ne passe pas) · R‑17 (la paroi pousse) · R‑10 · R‑09 · R‑16 · R‑07 · R‑11 · R‑14 · R‑19 · R‑20 |
| 7 Gravité | gravité locale | R‑01 (tomber vers le haut) · R‑04 · R‑06 · R‑02 · R‑05 · R‑12 · R‑10 · R‑11 · R‑13 · R‑09 · R‑14 · R‑20 |
| 8 Magnétisme | aimant | R‑01 (tirer au‑dessus du vide) · R‑09 (l'aimant détourne) · R‑06 · R‑11 (orbite) · R‑07 · R‑08 · R‑12 · R‑10 · R‑13 · R‑17 · R‑14 · R‑20 |
| 9 Faille | portails | R‑01 · R‑12 (la sortie conserve la direction) · R‑05 · R‑11 · R‑10 · R‑04 · R‑07 · R‑06 · R‑09 · R‑13 · R‑14 · R‑20 |
| 10 Filaments | corde, corps mou | R‑02 (pont souple) · R‑06 · R‑17 (la corde relance) · R‑07 · R‑08 · R‑10 · R‑12 · R‑13 · R‑09 · R‑19 · R‑14 · R‑20 |
| 11 Quantique | superposition, détecteur, intrication, dilatation | R‑18 · R‑01 · R‑15 · R‑06 · R‑19 · R‑12 · R‑10 · R‑09 · R‑13 · R‑14 · R‑11 · R‑20 |

---

## 11. Organisation du travail

1. **Un monde à la fois**, dans l'ordre : Chaîne (monde témoin), puis reprise des mondes 1, 2, 4, 5 (niveaux ○), puis 6 à 11.
2. Pour chaque monde : **étalonner** sa mécanique (§6) → écrire les **12 fiches** (G0) et les soumettre à Simon **avant** de
   construire → construire et valider (G1–G4) → livrer l'aperçu du monde → **test de Simon (G5)**.
3. Livraison : seuls les niveaux ayant passé G4 entrent dans le zip ; les autres restent ○ dans le registre, avec l'ancien
   niveau en place.
4. Chaque échec de conception est consigné (cause mesurée) dans la fiche : une idée abandonnée l'est pour une raison écrite.
