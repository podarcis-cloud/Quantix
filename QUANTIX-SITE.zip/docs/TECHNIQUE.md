# QUANTIX — Référence technique (code, commandes, pièges)

*À ouvrir avant de toucher au code. Fusion de l'ancien `REPRISE-SESSION.md` §5–§7 et de `PASSATION_R232.md` §3–§8 (R262).*

## 1. Le jeu : fichiers et systèmes

**Fichiers** (`site/q/`) : `index.html` (structure, aucun script en ligne ; ordre des scripts imposé : `worldart.js`,
`i18n.js`, `levels.js`, `visuals.js`, `tuto-scenes.js`, `tuto.js`, `editor.js`, `hero.js`, `engine.js`, `runlog.js` (R266, journal local des essais, global `QRUNS`), `sound.js`) ;
`assets/css/quantix.css` (blocs datés en fin de fichier) ; `assets/img/worlds/` (illustrations), `assets/img/hero/h01–h11.jpg`
(fonds du héros, chemins construits dans `hero.js`), `assets/img/ui/` ; `assets/audio/sfx/` (17 MP3) ;
`manifest.webmanifest` ; `.github/workflows/deploy.yml` (GitHub Pages) ; `studio/` (Quantone, éditeur, bancs) ;
`tools/` (113 outils) ; `docs/` (documents).

**Globaux** : `S` (état), `LEVELS`, `WORLDS`, `BUS` (événements : `ball.launch`, `ball.fail` + `reason`, `level.complete`,
`ball.impact`, `ball.bounce`…), `VX` (rendu), `QHERO` (`frame`, `epilogue`, `epReset`), `TUTO`, `Audio1`, `W1N`, `MFX`,
`JR` (journal du parcours), `TR()`/`DICT`/`LANG`, `OPT`, `QP` (cordes, corps mou), `EDT`, `PEDIT`, `KOFI`.

**Écrans** : `#home`, `#game` ; voiles `vResult` (bilan, `jfinal` au final), `vPause`, `vLevels` (constellation),
`vWorld`, `vSet`, `vCodex`, `vFin` (bouton Bilan de fin), `#finCv` (canevas de l'épilogue), `#tcard` (fiche).

**Fin du jeu** : `level.complete` du dernier niveau → `app.classList.add('fin')` → prélude `VX.finale` 1,5 s → `finCine()`
→ `QHERO.epilogue(cx,w,h,now,{solved,title})` sur `#finCv` → `finShow()` quand la danse est installée → « Bilan » →
`vResult.jfinal`. Arrêt : `finStop()` (chargement d'un niveau, sortie du jeu).

**Épilogue** (`hero.js`) : `ZR` (zones de retour : segments `A` de la particule, `B` ou `Bf` de la compagne, `ev`/`evB`
événements, `cam` caméra), `epChase`, `epFuse`, `epDance` (`fig` : 4 figures), temps à vitesse variable (`EP.ts`),
décors `decoR` (réutilise `VX.mech`, `VX.helix`, `VX.torusCells`, `VX.qsup`, `VX.qtdil`, `VX.bfield`, `VX.well`).

**Sauvegarde** : `localStorage` clé `quantix.save.v1` : `best`, `bestMat`, `unlocked`, `seen`, `jr`, `lang`, `tuto`,
`skinS`, `shape`, `opt`. Chaque version d'artefact d'aperçu a sa propre mémoire.

**Didacticiel** : règles R202 en tête de `onLoad` (`tuto.js`) ; scènes simulées `tools/tuto-scenes-src.js` →
`node tools/tutoscenes.js` → `assets/js/tuto-scenes.js`.

## 2. Commandes essentielles

| Besoin | Commande |
|---|---|
| Socle de tests | `cd tools && for t in audit strict tutotest monde1 monde2 render replaytest savetest maptest; do node $t.js \| tail -1; done` |
| Tests navigateur | `python3 tools/e2e-didacticiel.py` · `e2e-editeur.py` · `e2e-quantone.py` · `e2e-quantone-editeur.py` · `e2e-son.py` |
| **Preuve d'un niveau** | `python3 tools/preuve.py N` |
| Jouabilité | `node tools/difficulty.js N` |
| Contournements | `node tools/bypass.js W` (monde) ou `node tools/bypass.js n=N` (niveau) ; `node tools/contournements.js A B` |
| Zone propre | `node tools/zonepropre.js [N]` |
| Fermer un raccourci | `node tools/ndfix.js N` |
| Courbes | `node tools/rail.js` (voir en-tête) |
| Poussière d'indice | `node tools/flow.js 3 6 18 …` |
| Aperçu | `python3 tools/build-apercu.py N [U] [skipintro] [home] [fin]` → `/mnt/user-data/outputs/quantix-apercu-mondeN.html` |
| Éditeur de niveaux | `python3 tools/build-apercu.py 1 11 skipintro`, puis injecter `studio/editeur-niveaux.js` dans un `<script>` avant le dernier `</body>`, titre « Quantix Éditeur » → publier à l'adresse de l'éditeur (capacités `db` + `downloads`) |
| Banc des rendus | `python3 tools/build-galerie.py` |
| Zip | `cd site/q && zip -qr /mnt/user-data/outputs/QUANTIX-SITE.zip . -x '*.pyc' -x '__pycache__/*' -x '.git/*'` |

## 3. Pièges connus (chacun a déjà coûté du temps)

**Règle de Simon (17 oct.) : chaque fois qu'un piège de construction est repéré et déjoué, scanner systématiquement tous
les autres niveaux pour ce même piège**, outiller le scan si possible, et noter le résultat ici et dans `A_VERIFIER.md`.
Scans outillés : `tools/visibles.py W [n1 n2]` (lisibilité : chaque élément jouable avec / sans, écart moins bruit d'animation, `DPR=1` pour les mondes lourds) ; `tools/squelettes.js [monde]` (même entrée graphique : départ, bassin, séparateur, murs communs) ;
`tools/monde11.js` (mécanique quantique décorative : les portes deviennent des murs — `bypass.js` retire les portes et
signale à tort « décorative » quand une porte ferme le bassin).

1. **Tests Node** : une minuterie (`setInterval`) dans le moteur empêche les tests de se terminer → utiliser des
   vérifications dans la boucle. `load.js` rend `window.VX` global après chargement (sinon le rendu plante en silence).
2. **Deux fonctions `rgba`** : celle de `visuals.js` prend un **tableau** `[r,g,b]`, celle de `hero.js` une **couleur hex**.
   Une hex passée à la première ne dessine rien.
3. **Polices** : Google Fonts est bloqué dans l'aperçu et dans Playwright (`page.route('**/fonts.g*/**', abort)`).
4. **Monde 8** (WebGL) très lent sans GPU : ne pas le capturer en boucle.
5. **Épilogue** : il dépend de `performance.now()` ; pour capturer une image précise, piloter l'horloge (script `capepi.py`
   de R203–R207 : remplacer `performance.now` et avancer par pas de 16 ms).
6. **Mémoire des aperçus** : chaque version d'artefact a son propre stockage → le didacticiel se réaffiche (normal).
7. **Liens dans l'app iPhone** : `target="_top"` n'ouvre rien ; donner les liens en clair.
8. **Ne jamais insérer de code entre un `if` et son `else`** (bogue R168).
9. **Une remarque sur un monde ne s'étend pas aux autres** sans le dire (régression R147–R153).
10. **Éditeur** : ne jamais écraser un document de Simon (`Q-MM-PP`) ; écrire `Q-MM-PP-claude`.
11. **Audio iOS** : WAV incompatible avec WKWebView (historique) → MP3 ; diagnostic dans les Paramètres (à cacher).
12. `pkill -f motif` tue aussi la commande qui le contient.
15. **Cache des scripts** (R236) : les adresses de `index.html` portent `?v=Rnnn` ; les changer à chaque tampon, sinon un
    navigateur peut rejouer l'ancienne version (ex. l'ancienne fin).
13. `contournements.js` et `bypass.js` explorent un ensemble fini de traits : « 0 » n'est pas une preuve absolue.
14. Le tableau `archive/ETAT_REFONTE_NIVEAUX.md` est périmé (R116) : ne pas s'y fier.
16. **Scripts de correctif en Python** : borner la recherche du repère après le point de départ (`s.index(repère, début)`) ;
    un repère présent plus haut a déjà dupliqué du code (R257).
17. **Le bloc‑notes d'une session disparaît** avec elle : tout résultat de calcul utile (scan, mesures) se copie dans
    `tools/` ou `docs/` avant la livraison.
18. **Deux contextes audio dans le jeu** (`engine.js` et `sound.js`) : tout ce qui suspend le son passe par `window.__ACS`
    (R259), jamais par un seul contexte.
19. **Long calcul** : le lancer en arrière‑plan, prévenir Simon avant, et lui écrire au moins toutes les quelques étapes
    (session de 25 min sans message le 22 oct.).


## 4. La fin, le Banc de la fin, Quantone, vibrations (ex-PASSATION_R232)

### 4.1 La fin (`fin5` dans `hero.js`) : comment elle est construite

- **Scènes** : `SC.push({w, nm, build(a,b), cam(lt), tw, lag, sync, nosafe})`. `w` = monde (11 la coupe … 0 Atelier),
  `build` reçoit l'état de sortie de la scène précédente et rend deux trajets `A` (blanche) et `B` (violette).
- **Trajets** : classe `Path` — `glide(x,y,vx,vy,d)` (Hermite), `fn(f,d,x,y,vx,vy)`, `w(d)` (attente), `e(type,…)`
  (évènement), `run({surf,until})` (physique simplifiée), `bounce2(dir,dx1,h1,d1,dx2,h2,d2)` (réception lourde + deux rebonds).
- **Évènements** (`ev5`) : `hit`, `thud`, `launch`, `thrust`, `portal`, `seam`, `coll`, `boost`, `absorb`…
- **Décors** : `DECO[w](c,z,lt,A,B,now)` ; fond animé du monde (`backS5`, `bg5`) ; vol libre de l'Atelier : `spaceDeco`.
- **Atelier** (le dernier trait) : constantes `ORGP, FX0, FXE, FTS, FTJ, FR0, FR1, FZX, FTF`, zones `ZN` (la 6ᵉ est la zone
  finale), trait `TY(x)`, pointe `xTip/tTip`, aura `kiAura`, comètes dans `zoneFX`, vol en double hélice `dnaFly`, siphon
  `spiral`, plongée qui reprend la vitesse angulaire (`DVW`).
- **Traînées** : `trail5` / `ribbon5` (rubans lissés), trace de la danse en fil continu (`epDance`).
- **Vibrations** : partition `VIBSC` (une par acte) jouée par `vib5` ; détail `VIBRATIONS.md`.
- **Rendu absolu** : `fin5.render(c,w,h,t,opt)` ; une recherche (saut de temps) rejoue 900 ms en arrière sans vibrer.
- **Intégration** : faite en R233 (`epilogue` joue fin5 par défaut). Aperçu de la fin : `python3 tools/build-apercu.py 1 11 skipintro fin`.
  (`python3 tools/build-apercu.py 1 11 skipintro fin`), tests, zip.

### 4.2 La bande son de la fin (R234, `assets/js/fin-sound.js`, global `QFINS`)

- Partition = liste de notes `{t (ms du film), d, k (instrument), a (arguments)}` construite une fois (`build`) depuis
  `QHERO.fin5.acts()` et `QHERO.fin5.cues()` ; la danse est générée à la demande (`dance`), sans fin.
- Instruments (`V`) : `bell` (blanche), `mallow` (violette), `pluck`, `pad`, `sub`, `thump`, `breath`, `grain`, `wood`, `drop`,
  `glide`, `whoosh`, `riser`, `suck` ; sortie commune : réverbération (convolution 4,2 s), écho ping-pong filtré, compresseur doux.
- Lecture : `QFINS.sync(tFilm, joue, vitesse)` à chaque image ; recherche > 180 ms → coupe et relance (notes en cours reprises
  avec un fondu) ; dérive plus faible → horloge recalée doucement ; muet hors ×1. `QFINS.unlock()` sur un geste (iOS).
- Rendu hors ligne : `QFINS.render(ctxOffline, dest, t0, t1)` (scratchpad `snd/render.py` : WAV + crêtes/RMS par seconde).
- Changer un acte : modifier son bloc dans `build()` (un bloc commenté par monde).

### 4.3 Le Banc de la fin et ses annotations (procédure)

- Adresse : https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b — reconstruire avec
  `python3 tools/build-banc-fin.py studio/banc-fin.html Rnnn`, puis publier **à la même adresse**.
- Simon capture une image, l'annote et l'envoie : document dans la collection **`captures`** de la base de l'artefact
  (`act`, `t` en ms, `note`, `asset`). Lire les nouvelles : `ArtifactData query` sur `captures` avec `where at > <date du
  dernier lot>` ; l'image : `Artifact read` avec `path` = `asset`.
- `__banc.seek(t)` (temps absolu) pilote le banc ; scripts de capture Playwright : voir la fin de ce document.
- Chaque lot de la fin : lire **toutes** les notes non traitées (un oubli a déjà coûté un retour de Simon), répondre à
  chacune, dire lesquelles restent ouvertes.

### 4.4 Quantone : architecture (pour y ajouter du code sans casser)

- Un seul `<script>` : un module externe (état `st`, `KN`, `KE`, `play`, `stop`, `score`, `sched`, `preset`, `loadPreset`,
  `voice`, `applyK`…) qui contient des **blocs** successifs ; chaque bloc remplace des fonctions par enveloppe
  (`var preset2=preset;preset=function(){…}`).
- Le bloc des instruments (`INST`, `NAMES`, `COLS`, `drum`, `send`, `nz`, `O`, `REG`, `edUI`, `layUI`) est **privé** : le
  code qui en a besoin (ex. boîte à rythmes) s'insère **dans** ce bloc, juste avant `window.QFX3=…`.
- Textes : dictionnaires propres à Quantone (`T`, `TX`, `TX2`, `TX3`, `TX4` menu/automation, `TX5` boîte à rythmes), FR/EN.
- **Règle (Simon, R232)** : toute nouvelle commande à valeur (bouton à états, curseur, potard, liste) reçoit le menu
  « Valeur par défaut / Automation » : une clé dans `auKey` (où elle est touchée) et une description dans `auDesc`
  (lire, écrire, défaut, format). Les boutons d'action pure ont le menu grisé.
- Clés existantes : `k:` potards, `eq:`, `ef:`, `ik:<instr>:<réglage>`, `sel:` listes, `fx:` fonctions, `dk:` réglages de voix,
  `dp:<voix>:<pas>`, `dmu:<voix>`, `dln`, `dkit`. R235 : `grid`, `ifn:<instr>`, `ilp:<instr>` (descriptions dans `QFX3.fnDesc`).
- Tests : `python3 tools/e2e-quantone.py` (12/12), `e2e-quantone-editeur.py` (9/9).

**Ajouts R253–R261** : chaîne `voice` = plafond de voix (`VLIVE`, 44) → fonctions (`voiceF`, lit `ev.ip.fn` avant
`st.inst[k].fn`) → synthèse (lit `ev.ip.p`). « Ce trait seulement » = `trait.ip` (copie de l'instrument : `p`, `preset`,
`fn`, `lp`, et pour Rythmes `dm` = sa propre boîte). La boîte éditée est `DMC()` (celle du trait ciblé, sinon `st.dm`) ;
l'automation agit toujours sur `st.dm`. Un trait Rythmes ouvre une fenêtre de temps où joue sa boîte (`scoreD`, `_gl`).
Fichier `.qx` : `QXIO.build()/open()` = préréglage complet + 8 samples PCM 16 bits. Crochets de test : `QUANTONE`, `QFX3`,
`QDM`, `QSMP`, `QXIO`. Tests : `e2e-quantone*.py`, `e2e-sampler.py`, `e2e-quantone-traits.py`.

### 4.5 Vibrations : ce qu'on sait

- iPhone : pas d'API de vibration web ; seul le « tic » d'un interrupteur (`<input type=checkbox switch>`, iOS 18+). Sur
  l'iPhone de Simon, **rien ne vibre dans l'artefact ouvert dans l'app Claude** (R231). Test à faire par Simon : basculer
  lui-même l'interrupteur du panneau, puis ouvrir le banc dans Safari. Sinon : application native (Capacitor Haptics).

### 4.6 Scripts utiles (à recréer dans le bloc‑notes si besoin)

Capture d'une plage du banc (Playwright, Chromium préinstallé) :
```python
# python3 capR.py <t0> <t1> <pas_ms> <préfixe>
import asyncio,sys
from playwright.async_api import async_playwright
t0,t1,st,pre=float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),sys.argv[4]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':420,'height':900})
    await pg.goto('file:///…/site/q/studio/banc-fin.html'); await pg.wait_for_timeout(1000)
    t=t0-600;await pg.evaluate(f"__banc.seek({t})");k=0;nx=t0
    while t<t1:
      t+=40;await pg.evaluate(f"__banc.seek({t})")
      if t>=nx:
        nx+=st;await pg.locator('#stage').screenshot(path=f"{pre}{k:02d}.png");k+=1
    await b.close()
asyncio.run(main())
```
Durées des actes : `node -e` qui charge `visuals.js` puis `hero.js` et affiche `QHERO.fin5.acts()` (nom, `t0`, `d`, évènements).
