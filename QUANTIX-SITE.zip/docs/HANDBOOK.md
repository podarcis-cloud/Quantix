# QUANTIX — Handbook

*Référence technique du projet. Version du jeu : R22. À lire par sections, jamais en entier.*

---

## 0. Carte de lecture — lis uniquement ce dont tu as besoin

| Ta tâche | Sections à ouvrir |
|---|---|
| Ajouter ou corriger un niveau | 3, 4, 9 |
| Toucher à la physique | 2, 9 |
| Ajouter une mécanique | 2, 3, 5, 9 |
| Toucher à l'interface ou au style | 6, 7 |
| Ajouter du texte visible | 8 |
| Toucher au son | 5 |
| Construire et publier | 1, 9, 10 |

---

## 1. Structure du dépôt

Le jeu n'est plus un fichier unique. C'est un site statique à chemins relatifs,
déployable tel quel sur GitHub Pages.

```
index.html                 structure seule, aucun script en ligne
manifest.webmanifest       installation sur l'écran d'accueil
.nojekyll                  désactive le traitement Jekyll
.github/workflows/         déploiement Pages à chaque push sur main
assets/
  css/quantix.css          styles et jetons de couleur
  js/worldart.js           chemins des illustrations, fiches de monde, CPOS
  js/i18n.js               DICT fr/en, LV_EN_N[132], LV_EN_T[132], TR LN LT WN WE
  js/levels.js             WORLDS[11], ZEN, LEVELS[132], worldRange()
  js/engine.js             audio, physique, solveur QP, quantique, rendu, interface
  img/worlds/wNN-nom.jpg   11 illustrations, 900 px de large, chargées à la demande
  img/ui/                  bandeau d'accueil, affiche de constellation, icônes
  audio/sfx/*.mp3          17 effets
  audio/silent.mp3         boucle silencieuse, contournement iOS
tools/                     harnais node, hors production
docs/                      cette documentation
```

**Aucune construction.** Il n'y a plus de coque à assembler : on modifie
directement les fichiers de `assets/`.

**L'ordre de chargement est imposé** — `worldart`, `i18n`, `levels`, `engine` —
parce que `engine.js` lit `LEVELS` et `WORLDS` dès son exécution.

**Scripts classiques, pas modules ES.** Choix délibéré : le jeu s'ouvre en
double-cliquant `index.html`, sans serveur. Conséquence : les 167 déclarations
de premier niveau sont globales. Voir §9.1 avant d'introduire un identifiant.

**Chemins relatifs uniquement.** Un seul chemin commençant par `/` casserait le
déploiement en sous-dossier `github.io/quantix/`.

## 2. Physique

**Monde de référence : 360 × 480 unités.** Toutes les coordonnées de niveau sont dans ce repère. Le canvas se met à l'échelle, le monde jamais.

### Constantes

```
R=10.5      rayon de la particule
G=.40       gravité par frame
REST=.34    restitution des surfaces ordinaires
FRIC=.995   frottement tangentiel
PADE=1.52   restitution des plaques de rebond
BOOSTF=.62  poussée des tapis d'élan
VMAX=15.5   vitesse maximale
```

### Boucle

Horloge fixe à 60 Hz avec accumulateur, au maximum 4 pas de rattrapage par frame. `S.acc += dt * (S.slow?.4:1) * S.tmul`. Le ralenti ralentit le temps simulé, il ne saute pas de frames.

Chaque tick appelle `physics()`, qui fait **5 sous-pas**. Chaque sous-pas : `qpStep(5)` puis `stepBranch(b,5)` pour la branche principale et pour la branche de superposition si elle existe.

`stepBranch` enchaîne : échelle de temps locale, champs, déplacement, plafonnement de vitesse, `collide(b)`, `collideRopes(b)`, `quantum(b)`.

### Collision

Cercle contre segment. Point le plus proche, correction de position le long de la normale **signée**, réflexion de la composante normale, amortissement de la tangentielle. `break` absent : tous les segments sont traités.

### Solveur à contraintes — objet `QP`

Modèle transposé de QuarkPhysics : dynamique basée sur les positions, pas d'impulsions.

- Particules en intégration de Verlet, amortissement `.994`
- Contraintes de distance (`t:0`) et d'aire (`t:1`, déplacement le long de la bissectrice)
- 3 itérations par sous-pas, puis une passe de collision contre les segments statiques
- `qpBuild()` reconstruit tout : cordes tracées, balle molle si `softball`
- `qpSave()` / `qpLoad()` sérialisent l'état complet pour la reprise temporelle

**Règle** : toute modification des traits appelle `qpBuild()`.

---

## 3. Format d'un niveau

```js
{wd:3,                       // monde, 1 à 11
 n:'Le tapis',               // nom français
 ink:520,                    // budget de matière
 eleg:.55,                   // seuil de sobriété (défaut .62)
 ball:[46,40],               // départ
 cup:[240,430,112,'R'],      // x, sol, largeur, lèvre 'L' 'R' ou 'B'
 star:[322,336],             // noyau facultatif
 pal:'SBAC',                 // matières déposables (défaut 'S')
 softball:true,              // la particule devient un corps mou
 w:[[x1,y1,x2,y2,MAT]],      // murs fixes
 nd:[[x,y,w,h]],             // zones où tracer est interdit
 wind:[[x,y,w,h,fx,fy]],     // champ de force
 grav:[[x,y,w,h,gx,gy]],     // gravité locale, gy remplace G
 mag:[[x,y,rayon,force]],    // attracteur
 port:[[ax,ay,bx,by]],       // portail, A vers B
 mov:[{seg:[x1,y1,x2,y2],amp,spd,ax,ay}],
 ent:[[ax,ay,bx,by,'same',0]],   // paire intriquée
 gate:[[x1,y1,x2,y2,idPaire,phase]], // phase 0 fermée au repos, 1 ouverte
 sup:[[x,y,w,h,angle]],      // zone de dédoublement
 det:[[x,y,rayon]],          // détecteur de mesure
 tdil:[[x,y,w,h,echelle]],   // dilatation temporelle
 tip:'…'}                    // conseil français
```

**Matières** : `S_`=0 structure, `B_`=1 rebond, `X_`=2 piques, `A_`=3 élan, `I_`=4 glace, `ROPE`=5 corde.

`cup` est développé automatiquement en sol + lèvres + `zone` au chargement. Ne jamais écrire `zone` ni `walls` à la main.

**Coûts de matière** : structure ×1, rebond ×1,9, élan ×1,7, corde ×1,4.

---

## 4. Ajouter ou corriger un niveau

1. Écrire l'objet dans `levels-a.js` (mondes 1 à 5) ou `levels-b.js` (6 à 11).
2. Reconstruire.
3. **Lancer `solver.js`.** Il rejoue tous les niveaux. Un niveau non prouvé n'est pas forcément injouable, mais trois niveaux réellement impossibles ont été trouvés comme ça.

Règles de conception apprises à la dure :

- Le bassin doit être **sous** la particule, sauf si vent, rebond, gravité inversée ou portail fournissent la montée.
- Une porte qui fait couvercle ne sert à rien si le bassin reste ouvert par le côté. Ajouter un mur permanent.
- Un couloir entre deux obstacles doit faire plus de `2*(R+4)` = 29 unités.
- Une plaque de rebond ne doit pas chevaucher la lèvre d'un bassin.

---

## 5. Audio

`Audio1` expose : `unlock, setWorld, playSfx, playImpact, playMusicState, setMusic, setSfx, setHaptics, buzz, state, media, session, sampReady, sampErr, test`.

**Deux voies.** `window.__QXSAMPLES` à `true` : lecture d'échantillons MP3 par éléments `<audio>`. À `false` : synthèse Web Audio.

**Contraintes iOS établies par mesure** — ne pas les redécouvrir :

- Une vue web intégrée refuse les URI `data:` pour les médias → passer par `URL.createObjectURL`
- Elle ne décode pas le WAV, quelle que soit la profondeur de bits → MP3 obligatoire
- Web Audio sort sur la voie sonnerie ; `navigator.audioSession.type='playback'` et une boucle silencieuse **en lecture continue** sont nécessaires
- Le contournement doit s'exécuter **avant** la création du contexte et sans dépendre de sa réussite

`atelier-sonore.html` régénère la banque et le runtime.

---

## 6. Jetons de style

Relevés sur le moodboard, panneau PALETTE DE COULEURS. **Ne jamais introduire une couleur hors de cette liste.**

```
--bg:#05070D  --surface:#0F131B  --surface-2:#1A202A
--border:#22303F  --text:#F1F4F6  --muted:#8A97A6
--matter:#4DD7FF  --boost:#A678FF  --goal:#9BEB4B
--danger:#FF5252  --reward:#FFD85A  --bounce:#FFAA3C
```

Typographie : **Space Grotesk** pour titres, noms et boutons ; **Inter** pour le texte courant.

Composants : gélules entièrement arrondies, majuscules espacées `.17em` pour les boutons, boutons ronds de 44 px pour les outils, étoiles dorées pleines en `clip-path`.

`--accent` change avec le monde courant. Violet en Zen Lab.

---

## 7. Écrans et interface

`#app[data-screen]` vaut `home` ou `game`. Les panneaux sont des `.veil` que `show(v,on)` bascule.

`resize()` refuse de calculer tant que la scène n'est pas mesurable et réessaie à la frame suivante. Un `ResizeObserver` prend le relais. **Ne jamais calculer l'échelle depuis un élément masqué.**

Le terrain se met à l'échelle du plus contraignant des deux axes. Chaque rangée ajoutée vole de la hauteur et rétrécit le terrain. Des règles `@media (max-height:720px)` et `600px` sacrifient le décor avant le terrain.

---

## 8. Texte et bilingue

**Aucune chaîne visible ne vit hors de `i18n.js`.**

- Statique : attribut `data-t="cle"` dans la coque, `applyLang()` parcourt `[data-t]`
- Dynamique : `TR('cle')`
- Niveaux : `LN(i)` pour le nom, `LT(i)` pour le conseil
- Mondes : `WN(w)`, `WE(w)`

Ajouter une chaîne = ajouter la clé dans `DICT.fr` **et** `DICT.en`. Un test vérifie qu'aucune clé française n'est orpheline.

---

## 9. Pièges connus

### 9.1 Collisions de noms — trois occurrences dans ce projet

Tout vit dans une IIFE unique. `S.ghost` a été réutilisé pour la superposition alors qu'il désignait la trajectoire ratée. `th` a collisionné. `T` était la palette et est devenu la fonction de traduction.

**Avant d'introduire un identifiant, vérifier qu'il est libre :**

```bash
grep -c "\bNOM\b" build/*.js
```

### 9.2 Les remplacements silencieux

Tout script de correction **compte ses remplacements et le dit**. Un motif qui ne correspond plus échoue sans bruit et coûte plusieurs tours.

```python
def rep(a,b,label):
    global s,n
    if a in s: s=s.replace(a,b,1); n+=1; print(label,'OK')
    else: print(label,'ÉCHEC')
```

### 9.3 Les tests qui ne couvrent pas le code

`scenetest.js` force `data-screen='game'` **parce qu'un test qui s'arrête à l'accueil n'exécute jamais `scene()`**. Un bug y est resté trois tours.

### 9.4 Le cache de l'aperçu

Republier sous le même nom fait servir l'ancienne version. **Numéro neuf à chaque publication**, plus un tampon visible à l'écran et un `console.log` au démarrage.

### 9.5 Le faux DOM doit refléter le vrai

Si `querySelectorAll` renvoie toujours `[]`, un bug de traduction passe inaperçu. Si `children` n'existe pas, le code qui l'utilise n'est pas testé.

---

## 10. Séquence de vérification avant toute publication

```sh
cd tools
node audit.js      # base64 résiduel, chemins morts, assets orphelins, démarrage
node render.js     # 12 frames de rendu, niveau de référence, 11 cartes de monde
node solver.js     # si les niveaux ont changé (lent, ~10 min)
node savetest.js   # si la sauvegarde a changé
```

`audit.js` sort en code d'erreur : il peut servir d'étape bloquante avant
déploiement. Il vérifie notamment qu'aucun asset n'est référencé sans exister,
et qu'aucun fichier ne dort sans être référencé.

## 11. État — R22

132 niveaux, 11 mondes, 119 prouvés résolvables. Sauvegarde `quantix.save.v1`. Bilingue FR/EN complet. Zen Lab et Quantum Drop opérationnels. Audio fonctionnel hors vue web intégrée en mode silencieux.

**Reste** : les 8 leviers d'engagement, le vocabulaire quantique des libellés, le tutoriel gestuel, l'éditeur de niveaux, la découpe gratuit/payant.
