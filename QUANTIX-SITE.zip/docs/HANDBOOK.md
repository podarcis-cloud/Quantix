# QUANTIX — Handbook

*Référence technique du projet. Version du jeu : R29. À lire par sections, jamais en entier.*

---

## 0. Carte de lecture — lis uniquement ce dont tu as besoin

| Ta tâche | Sections à ouvrir |
|---|---|
| Ajouter ou corriger un niveau | 3, 4, 9 |
| Rescénariser un niveau contournable | 4, 11 |
| Toucher à la physique | 2, 9 |
| Ajouter une mécanique | 2, 3, 5, 9 |
| Toucher à l'interface ou au style | 6, 7 |
| Ajouter du texte visible | 8, 9.6 |
| Toucher au son | 5 |
| Vérifier avant de publier | 9, 10 |
| Écrire un script ponctuel avec `node -e` | 9.1 |

---

## 1. Structure du dépôt

Le jeu est un site statique à chemins relatifs, déployable tel quel sur
GitHub Pages. Il n'y a **aucune construction** : on modifie directement les
fichiers d'`assets/`, il n'y a pas de coque à assembler ni de fichier de
sortie à régénérer.

```
index.html                 structure seule, aucun script en ligne
manifest.webmanifest       installation sur l'écran d'accueil
.nojekyll                  désactive le traitement Jekyll
.github/workflows/         déploiement Pages à chaque push sur main
assets/
  css/quantix.css          styles et jetons de couleur
  js/worldart.js           chemins des illustrations, fiches de monde, CPOS
  js/i18n.js               DICT fr/en, LV_EN_N[132], LV_EN_T[132], TR LN LT WN WE
  js/levels.js              WORLDS[11], ZEN, LEVELS[132], worldRange()
  js/engine.js              audio, physique, solveur QP, quantique, rendu, interface
  img/worlds/wNN-nom.jpg    11 illustrations, 900 px de large, chargées à la demande
  img/ui/                   bandeau d'accueil, affiche de constellation, icônes
  audio/sfx/*.mp3           17 effets
  audio/silent.mp3          boucle silencieuse, contournement iOS
tools/                      harnais node, hors production — voir §10
docs/                       cette documentation
```

**L'ordre de chargement est imposé** — `worldart`, `i18n`, `levels`, `engine` —
parce qu'`engine.js` lit `LEVELS` et `WORLDS` dès son exécution.

**Scripts classiques, pas modules ES.** Choix délibéré : le jeu s'ouvre en
double-cliquant `index.html`, sans serveur. Conséquence : toutes les
déclarations de premier niveau des quatre fichiers sont globales, dans le
**même espace de noms**. Voir §9.1 avant d'introduire un identifiant — y
compris dans un script `node -e` ponctuel, où le piège est différent et
plus surprenant.

**Chemins relatifs uniquement.** Un seul chemin commençant par `/` casserait
le déploiement en sous-dossier `github.io/quantix/`.

## 2. Physique

**Monde de référence : 360 × 480 unités.** Toutes les coordonnées de niveau sont dans ce repère. Le canvas se met à l'échelle, le monde jamais.

### Constantes

```
R=10.5      rayon de la particule
G=.40       gravité par frame
REST=.34    restitution des surfaces ordinaires
FRIC=.995   frottement tangentiel
PADE=1.52   restitution des plaques de rebond
BOOSTF=.62  poussée des tapis d'élan
VMAX=15.5   vitesse maximale
```

### Boucle

Horloge fixe à 60 Hz avec accumulateur, au maximum 4 pas de rattrapage par frame. `S.acc += dt * (S.slow?.4:1) * S.tmul`. Le ralenti ralentit le temps simulé, il ne saute pas de frames.

Chaque tick appelle `physics()`, qui fait **5 sous-pas**. Chaque sous-pas : `qpStep(5)` puis `stepBranch(b,5)` pour la branche principale et pour la branche de superposition si elle existe.

`stepBranch` enchaîne : échelle de temps locale, champs, déplacement, plafonnement de vitesse, `collide(b)`, `collideRopes(b)`, `quantum(b)`.

### Collision

Cercle contre segment. Point le plus proche, correction de position le long de la normale **signée**, réflexion de la composante normale, amortissement de la tangentielle. `break` absent : tous les segments sont traités.

### Solveur à contraintes — objet `QP`

Modèle transposé de QuarkPhysics : dynamique basée sur les positions, pas d'impulsions.

- Particules en intégration de Verlet, amortissement `.994`
- Contraintes de distance (`t:0`) et d'aire (`t:1`, déplacement le long de la bissectrice)
- 3 itérations par sous-pas, puis une passe de collision contre les segments statiques
- `qpBuild()` reconstruit tout : cordes tracées, balle molle si `softball`
- `qpSave()` / `qpLoad()` sérialisent l'état complet pour la reprise temporelle

**Règle** : toute modification des traits appelle `qpBuild()`.

---

## 3. Format d'un niveau

```js
{wd:3,                       // monde, 1 à 11
 n:'Le tapis',               // nom français
 ink:520,                    // budget de matière
 eleg:.55,                   // seuil de sobriété (défaut .62)
 ball:[46,40],               // départ
 cup:[240,430,112,'R'],      // x, sol, largeur, lèvre 'L' 'R' ou 'B'
 star:[322,336],             // noyau facultatif
 pal:'SBAC',                 // matières déposables (défaut 'S')
 softball:true,              // la particule devient un corps mou
 w:[[x1,y1,x2,y2,MAT]],      // murs fixes
 nd:[[x,y,w,h]],             // zones où tracer est interdit
 wind:[[x,y,w,h,fx,fy]],     // champ de force
 grav:[[x,y,w,h,gx,gy]],     // gravité locale, gy remplace G
 mag:[[x,y,rayon,force]],    // attracteur
 port:[[ax,ay,bx,by]],       // portail, A vers B
 mov:[{seg:[x1,y1,x2,y2],amp,spd,ax,ay}],
 ent:[[ax,ay,bx,by,'same',0]],   // paire intriquée
 gate:[[x1,y1,x2,y2,idPaire,phase]], // phase 0 fermée au repos, 1 ouverte
 sup:[[x,y,w,h,angle]],      // zone de dédoublement
 det:[[x,y,rayon]],          // détecteur de mesure
 tdil:[[x,y,w,h,echelle]],   // dilatation temporelle
 tip:'…'}                    // conseil français
```

**Matières** : `S_`=0 structure, `B_`=1 rebond, `X_`=2 piques, `A_`=3 élan, `I_`=4 glace, `ROPE`=5 corde.

`cup` est développé automatiquement en sol + lèvres + `zone` au chargement.
Ne jamais écrire `zone` ni `walls` à la main — mais les **lire** pour un
diagnostic est utile et sûr :

```js
X.loadLevel(i); console.log(X.LEVELS[i].zone, X.LEVELS[i].walls);
```

**Coûts de matière** : structure ×1, rebond ×1,9, élan ×1,7, corde ×1,4.

---

## 4. Ajouter ou corriger un niveau

1. Écrire ou modifier l'objet directement dans `assets/js/levels.js` — un seul
   fichier, pas de reconstruction.
2. **Lancer `tools/solver.js`.** Il rejoue les 132 niveaux (≈ 2 secondes, pas
   dix minutes — voir §10). Un niveau non prouvé par sa recherche heuristique
   n'est pas forcément injouable : elle est volontairement simple et rate des
   solutions réelles, surtout depuis que les niveaux sont scénarisés (§11).
   En cas de doute, vérifier par simulation directe (§11).

Règles de conception apprises à la dure :

- Le bassin doit être **sous** la particule, sauf si vent, rebond, gravité inversée ou portail fournissent la montée.
- Une porte qui fait couvercle ne sert à rien si le bassin reste ouvert par le côté. Ajouter un mur permanent.
- Un couloir entre deux obstacles doit faire plus de `2*(R+4)` = 29 unités.
- Une plaque de rebond ne doit pas chevaucher la lèvre d'un bassin.
- **Un niveau résolvable n'est pas un niveau fini** — voir §11, c'est
  maintenant la priorité de conception numéro un du projet.

---

## 5. Audio

`Audio1` expose notamment : `unlock, setWorld, playSfx, playImpact, setMusic,
setSfx, setMusicVol, setSfxVol, world, params, tune, state, media, session, test`.

**Fichiers réels.** Les 17 effets sont des MP3 dans `assets/audio/sfx/`, la
boucle silencieuse est `assets/audio/silent.mp3`. Plus aucun `data:` URI ni Blob.

**Ambiances.** `WD[11]` donne pour chaque monde : fondamentale, mode, tempo,
timbre, désaccord, filtre, densité. Les onze sont nettement distinctes —
11 tempos différents, battements de 0,3 à 6,8 Hz.

**Atelier sonore caché.** Cinq appuis sur le tampon de version, en bas de
l'accueil. `Audio1.tune({...})` applique à chaud et reconstruit la nappe ;
`Audio1.params()` renvoie les valeurs du monde courant.

**Contraintes iOS établies par mesure** — ne pas les redécouvrir :

- Une vue web intégrée refuse les URI `data:` pour les médias
- Elle ne décode pas le WAV, quelle que soit la profondeur de bits
- Web Audio sort sur la voie sonnerie ; `navigator.audioSession.type='playback'`
  et une boucle silencieuse **en lecture continue** sont nécessaires
- Le contournement doit s'exécuter **avant** la création du contexte

**`auWarn` est du code mort** (R29) : l'avertissement « le navigateur bloque
l'audio » existe dans `index.html`, `display:none`, et rien ne le rend jamais
visible. Ne pas l'activer sans avoir d'abord vérifié sur un appareil réel sur
quel état exact d'`Audio1` se déclencher — c'est la règle 5 du protocole,
justement née de cette enquête audio.

## 6. Jetons de style

Relevés sur le moodboard, panneau PALETTE DE COULEURS. Onze jetons de base :

```
--bg:#05070D  --surface:#0F131B  --surface-2:#1A202A
--border:#22303F  --text:#F1F4F6  --muted:#8A97A6
--matter:#4DD7FF  --boost:#A678FF  --goal:#9BEB4B
--danger:#FF5252  --reward:#FFD85A  --bounce:#FFAA3C
```

**Ce que le code contient réellement** (constaté R29) : plus de 80 couleurs
hexadécimales distinctes dans `quantix.css`, `engine.js` et `index.html` —
très probablement des teintes et nuances dérivées de ces onze jetons
(dégradés, halos, transparences par monde), pas une dérive de charte, mais
non vérifié couleur par couleur contre le moodboard. **Ne pas introduire une
couleur qui n'est ni un des onze jetons ni une nuance clairement dérivée
d'un jeton existant**, et signaler explicitement toute couleur nouvelle
introduite pour une tâche, plutôt que de la faire passer inaperçue dans un
dégradé.

Typographie : **Space Grotesk** pour titres, noms et boutons ; **Inter** pour le texte courant.

Composants : gélules entièrement arrondies, majuscules espacées `.17em` pour les boutons, boutons ronds de 44 px pour les outils, étoiles dorées pleines en `clip-path`.

`--accent` change avec le monde courant. Violet en Zen Lab.

---

## 7. Écrans et interface

`#app[data-screen]` vaut `home` ou `game`. Les panneaux sont des `.veil` que `show(v,on)` bascule.

`resize()` refuse de calculer tant que la scène n'est pas mesurable et réessaie à la frame suivante. Un `ResizeObserver` prend le relais. **Ne jamais calculer l'échelle depuis un élément masqué.**

Le terrain se met à l'échelle du plus contraignant des deux axes. Chaque rangée ajoutée vole de la hauteur et rétrécit le terrain. Des règles `@media (max-height:720px)` et `600px` sacrifient le décor avant le terrain.

---

## 8. Texte et bilingue

**Aucune chaîne visible ne vit hors de `i18n.js`.**

- Statique : attribut `data-t="cle"` dans la coque, `applyLang()` parcourt `[data-t]`
- Dynamique : `TR('cle')`
- Niveaux : `LN(i)` pour le nom, `LT(i)` pour le conseil
- Mondes : `WN(w)`, `WE(w)`

Ajouter une chaîne = ajouter la clé dans `DICT.fr` **et** `DICT.en`.

**Ce qu'un test de couverture des clés ne voit pas** (trouvé et corrigé en
R29, voir §9.6) : que toutes les clés `DICT` existantes soient utilisées, et
que tous les `data-t` du HTML aient une clé, ne prouve PAS que tout le texte
visible passe par `i18n.js`. Une chaîne française assignée directement à
`.textContent`/`.innerHTML` dans `engine.js` est invisible à ce genre de
test. Voir §9.6 pour la méthode de détection.

---

## 9. Pièges connus

### 9.1 Collisions de noms — dans le jeu, et dans tes propres scripts de diagnostic

Tout vit dans le même espace de noms global entre les quatre fichiers.
`S.ghost` a été réutilisé pour la superposition alors qu'il désignait la
trajectoire ratée. `th` a collisionné. `T` était la palette et est devenu la
fonction de traduction.

**Avant d'introduire un identifiant dans le jeu, vérifier qu'il est libre :**

```bash
grep -c "\bNOM\b" assets/js/*.js
```

**Piège différent et plus surprenant dans un script `node -e` de
diagnostic** (rencontré plusieurs fois en R29) : `engine.js` déclare des
globales courtes et courantes — `L` (accesseur de niveau), `S` (état du
jeu), entre autres. Si ton script `node -e "..."` déclare `const L = …` ou
`const S = …` **n'importe où dans la même chaîne**, même après
`require('./load.js')`, Node échoue avec `SyntaxError: Identifier 'L' has
already been declared` — **au moment même où `load.js` évalue le moteur**,
avant que ton propre code ne s'exécute. En cause : `node -e` place les
déclarations `const`/`let` de premier niveau dans l'environnement lexical
global du realm, le même que celui où l'`eval` indirect de `load.js` écrit
les globales du jeu ; elles se percutent, peu importe l'ordre d'écriture
dans le fichier.

**Parade : ne jamais nommer une variable de script `L`, `S`, `T`, ou toute
autre globale à une lettre du moteur.** Utiliser `LV`, `ST`, `X.S`,
`X.LEVELS[i]`, etc. Ce piège n'existe pas de la même façon dans un fichier
`tools/*.js` classique (chaque `require()` a sa propre portée de module) —
il est spécifique aux scripts passés en ligne de commande avec `node -e`.

### 9.2 Les remplacements silencieux

Tout script de correction **compte ses remplacements et le dit**. Un motif qui ne correspond plus échoue sans bruit et coûte plusieurs tours.

```python
def rep(a,b,label):
    global s,n
    if a in s: s=s.replace(a,b,1); n+=1; print(label,'OK')
    else: print(label,'ÉCHEC')
```

### 9.3 Les tests qui ne couvrent pas le code

`render.js` force `data-screen='game'` **parce qu'un test qui s'arrête à
l'accueil n'exécute jamais la boucle de jeu**. `scenetest.js`, qui faisait la
même chose sur l'ancien build en fichier unique, a été supprimé en R29 :
cassé (référençait `quantix-R27.html`, disparu depuis le site statique) et
redondant avec `render.js`.

**Rappel R29** : cinq autres outils (`solver.js`, `strict.js`, `qprobe.js`,
`savetest.js`, `deep.js`, `maptest.js`) ont été trouvés cassés de la même
façon — écrits pour l'ancien build, jamais migrés, jamais relancés depuis.
Après toute migration d'architecture, **relancer chaque outil du dossier
`tools/` au moins une fois**, pas seulement ceux que la documentation
courante mentionne.

### 9.4 Le cache de l'aperçu

Republier sous le même nom fait servir l'ancienne version. **Numéro neuf à chaque publication**, plus un tampon visible à l'écran et un `console.log` au démarrage.

### 9.5 Le faux DOM doit refléter le vrai

Si `querySelectorAll` renvoie toujours `[]`, un bug de traduction passe
inaperçu. Si `children` n'existe pas, le code qui l'utilise n'est pas testé.

Corollaire trouvé en R29 : le faux DOM de `tools/load.js` ne parse pas le
HTML injecté par `.innerHTML =`. Un bouton créé dynamiquement (ex. `dropGo`
dans `hDrop`) n'existe donc pas pour `document.getElementById` dans le
harnais, même s'il fonctionne très bien dans un vrai navigateur. Un échec de
`strict.js` sur un id qui n'existe que dans du HTML injecté est un faux
positif attendu, pas un bug du jeu — à documenter dans le test lui-même,
pas à ignorer silencieusement.

### 9.6 Une chaîne peut être bilingue « sur le papier » et fausse à l'exécution

Trouvé en R29 : l'écran de résultat, Zen Lab, Quantum Drop et deux titres
écrivaient des chaînes françaises en dur dans `engine.js`/`index.html`, en
court-circuitant `i18n.js`, alors que les clés anglaises correspondantes
existaient déjà dans `DICT.en`, simplement jamais appelées. Un test qui
vérifie la symétrie `DICT.fr`/`DICT.en` et la couverture des `data-t` ne
voit pas ça, puisque le problème est du texte qui **n'utilise aucune clé du
tout**.

**Détection** : chercher les assignations de chaîne entre guillemets à
`.textContent`/`.innerHTML` qui ne passent pas par `TR()`/`LN()`/`LT()`/
`WN()`/`WE()` :

```bash
grep -n "textContent=\|innerHTML=" assets/js/engine.js | grep -v "TR(\|LN(\|LT(\|WN(\|WE(\|+\|ico(\|className\|dataset"
```

**Vérification, pas seulement une relecture** : simuler l'événement en
français puis en anglais via `tools/load.js` et lire le texte réellement
posé dans le DOM simulé — voir l'exemple dans `docs/AUDIT-R29.md` §2.3.

---

## 10. Séquence de vérification avant toute publication

```sh
cd tools
node audit.js      # base64 résiduel, chemins morts, assets orphelins, démarrage
node render.js     # 12 frames de rendu, niveau de référence, 11 cartes de monde
node strict.js     # tous les gestionnaires de l'interface, sans exception
node maptest.js    # chaînage carte du monde, clés i18n orphelines
node savetest.js   # écriture, schéma inconnu, JSON corrompu, quota plein
node qprobe.js     # mécaniques quantiques, non-régression
node solver.js     # si les niveaux ont changé — ≈ 2 secondes, pas dix minutes
node bypass.js     # si un niveau a été rescénarisé — voir §11
node deep.js       # recherche renforcée si bypass.js laisse un niveau douteux
```

Les dix outils fonctionnent tous (R29). `audit.js` sort en code d'erreur : il
peut servir d'étape bloquante avant déploiement. Il vérifie notamment
qu'aucun asset n'est référencé sans exister, et qu'aucun fichier ne dort
sans être référencé.

Plus, systématiquement, et manuellement après tout ajout de chaîne visible :

```bash
grep -n "textContent=\|innerHTML=" assets/js/engine.js | grep -v "TR(\|LN(\|LT(\|WN(\|WE(\|+\|ico(\|className\|dataset"
```

## 11. Scénarisation des niveaux

Un niveau résolvable n'est pas un niveau fini. `tools/bypass.js` désactive la
mécanique signature et relance la recherche de solution : si le niveau reste
résolvable, la mécanique est décorative et le joueur la contournera.

Mesure R29 (balayage complet des 132 niveaux) : **97 niveaux contournables
sur 112 testés**, y compris tout le monde quantique (11) — voir
`BYPASS-RAPPORT.md`. Le monde 2 (Fonderie, 10 niveaux à mécanique) est
corrigé, 0/10.

### La méthode qui a marché sur le monde 2 — couloir de non-tracé

Un `nd` (zone où le joueur ne peut pas tracer) ne bloque **que le tracé du
joueur**, jamais le vol de la particule — donc un rebond, une fois déclenché
par un mur fixe du niveau, porte la particule à travers une zone `nd` sans
problème. C'est ce qui rend la méthode possible :

1. Repérer la hauteur de la mécanique signature (ex. la plaque de rebond,
   généralement proche du bas du monde de référence).
2. Ajouter un `nd` qui bloque **toute la largeur** du niveau, de `y:0`
   jusqu'à juste au-dessus de cette hauteur, **sauf un couloir étroit**
   (60 à 90 unités) centré sur la position de départ de la particule.
3. Le joueur ne peut plus tracer un raccourci direct vers le bassin, où que
   soit ce dernier : tout tracé qui s'en approche depuis le haut traverse le
   `nd`. Il ne peut que guider la particule, dans le couloir, jusqu'à la
   hauteur de la mécanique — au-delà, sans `nd`, il peut viser librement la
   plaque, et la physique fait le reste.

```js
// avant — le bassin est atteignable par un tracé direct depuis le départ
{ball:[50,40], cup:[240,300,112,'R'], w:[[30,442,150,442,B_]]}

// après — seul un couloir de 60 unités autour du départ reste tracable
// au-dessus de la plaque (y:0 à 440) ; en dessous, tout l'espace est libre
{ball:[50,40], cup:[240,300,112,'R'], w:[[30,442,150,442,B_]],
 nd:[[170,0,190,440]]}
```

Quand le départ et la mécanique ne sont **pas** dans la même moitié du
niveau (ex. deux plaques éloignées l'une de l'autre), le couloir doit encore
partir du point de départ — la particule, une fois lâchée dans la zone libre
sous le `nd`, peut ensuite voler librement d'une plaque à l'autre : c'est le
vol, pas le tracé, qui les relie.

Cas particulier : si le bassin est **plus bas** que la mécanique plutôt que
plus haut (ex. #19 Le four), le raccourci exploité n'est souvent pas un
raccourci vers le bassin mais une **fuite par un interstice** entre deux
murs fixes (ex. entre une zone de piques et la plaque). Fermer spécifiquement
cet interstice avec un petit `nd`, en plus du couloir général.

### Vérifier qu'un niveau rescénarisé reste gagnable

`solver.js` et `bypass.js` utilisent une recherche de candidats
volontairement simple (quelques dizaines de tracés à 1-3 segments). Une fois
un niveau rescénarisé, cette recherche **rate souvent la solution qui
existe bel et bien** — ce n'est pas une régression, c'est la limite connue
de l'outil (§4, §9.3). Ne jamais conclure qu'un niveau est cassé sur la
seule foi d'un `solver.js` qui ne le prouve pas.

**Vérifier par simulation directe** avant de considérer un correctif comme
acquis :

```js
require('./load.js');
const X = globalThis.__X;
X.loadLevel(idx);
X.S.strokes.push({pts:[[x1,y1],[x2,y2]], len:0, birth:0, mat:0});
X.qpBuild(); X.S.mode = 'run';
for (let f=0; f<900 && X.S.mode==='run'; f++) X.physics();
console.log(X.S.mode); // 'success' attendu
```

Si aucun tracé simple ne marche à la main, balayer systématiquement (voir
`docs/AUDIT-R29.md` §2 pour un exemple complet de balayage utilisé sur les
niveaux #14 et #20 du monde 2, qui ont eu besoin d'un angle précis ou d'un
tracé à trois segments).

### Cible

Zéro niveau contournable sur les 132. Monde par monde, dans l'ordre de
`TACHES.md` : `bypass.js N` après chaque lot, `solver.js` ou vérification
manuelle pour confirmer, `bypass.js` complet avant de publier.

## 12. État — R29

132 niveaux, 11 mondes. Site statique déployé. Sauvegarde `quantix.save.v1`.
Bilingue FR/EN réellement complet depuis R29 (l'écran de résultat et
quelques titres écrivaient du français en dur jusque-là — §9.6). Zen Lab,
Quantum Drop, atelier de particule, atelier sonore caché opérationnels. Les
dix outils de `tools/` fonctionnent tous.

**Scénarisation** : monde 2 fait (0/10 contournable). 97 niveaux
contournables restants sur les 9 autres mondes à mécanique.

**Reste** : rescénarisation des mondes 3 à 11, tutoriel gestuel, historique
personnel, transitions, éditeur de niveaux, découpe gratuit/payant, décision
sur `auWarn` (code mort) et sur la palette étendue (§6).
