# QUANTIX — La référence du design d'énigmes

*Version 1 (R77). Document de fond, destiné à être enrichi sur plusieurs séries. Chaque affirmation sur un auteur ou un jeu
renvoie à une source (§10) ; ce qui relève de mon analyse est signalé « (analyse) ». Retour de Simon à l'origine : « Relais 2 :
des éléments de décor inutiles ; Tapis roulant : rien de surprenant ; monde 1 : aucune différence, pas à la hauteur du cahier
des charges. »*

---

## 0. Diagnostic : pourquoi mes niveaux sont plats

Mes contrôles vérifient qu'un niveau n'a **pas de défaut** (pas de raccourci, pas d'élément inutile). Ils ne vérifient pas
qu'il a une **qualité** : une surprise, une idée qui change la manière de voir. « Le tapis » est correct et sans intérêt : la
réponse est exactement ce que le joueur pense en premier. **Un niveau sans fausse piste, sans impasse, sans retournement n'est
pas une énigme, même s'il est irréprochable.** (analyse)

Les sources ci‑dessous convergent : la valeur d'une énigme vient d'une **hypothèse du joueur qui se révèle fausse**.

---

## 1. Couche 1 — Ce qu'est une énigme (définitions des professionnels)

| Auteur | Idée | Conséquence pour Quantix |
|---|---|---|
| **Scott Kim** (concepteur d'énigmes, chroniqueur de *Discover*) | une énigme est un problème amusant à résoudre et qui a une bonne réponse — il peut y en avoir plusieurs | « unique » = une seule **idée**, pas un seul tracé au pixel |
| **Jonathan Blow** (*Braid*, *The Witness*) | il préfère sacrifier le « fun » pour atteindre quelque chose de plus profond et complet ; les mécaniques de *The Witness* sont nées de l'exploration du système, pas d'une décision a priori | chaque monde doit **explorer une vérité** de sa mécanique, pas aligner des obstacles |
| **Blow & Marc ten Bosch** (*Miegakure*) | explorer un système (« si X arrive, quelles conséquences ? ») pour en trouver les idées centrales, opposé aux techniques « combinatoires » traditionnelles | le contraire exact de ma forge (combinaisons d'éléments) |
| **Alan Hazelden** (*Sokobond*, *A Monster's Expedition*), via le créateur de *Pipe Push Paradise* | on doit pouvoir **formuler clairement l'idée** de chaque énigme ; si on ne peut pas dire ce qui la rend unique, ce n'est pas une énigme spéciale | test de verbalisation obligatoire (§7, étape 3) |
| **Le même** | la difficulté n'est pas ce qui rend une énigme intéressante ; toute énigme digne de ce nom illustre une vérité du système | on ne règle pas l'intérêt par la difficulté (mes P_hasard) mais par l'idée |
| **Mouvement « thinky games »** | des énigmes « honnêtes » : là pour communiquer des idées intéressantes, pas pour rallonger la durée ou masquer une mécanique faible | chaque niveau doit dire **quelque chose de nouveau** sur la physique du monde |

---

## 2. Couche 2 — Ce qui se passe dans la tête du joueur (sciences cognitives)

La psychologie de l'**insight** (moment « Aha ! ») décrit une séquence : exploration → **impasse** → changement de
représentation → solution. L'impasse est un état où l'on ne sait plus quoi faire ; on en sort en **changeant la représentation
du problème**, par deux mécanismes : **relâcher une contrainte que l'on s'était imposée** et **décomposer un « bloc » perçu**
d'un seul tenant (Knoblich, Ohlsson et al., 1999). Atteindre l'impasse **augmente** la probabilité d'une solution par insight.

Conséquence directe pour la conception (analyse) :

1. **Une énigme doit provoquer une impasse.** Si la première idée du joueur marche (« Le tapis »), il n'y a pas d'impasse,
   donc pas d'« Aha ».
2. **L'impasse vient d'une contrainte que le joueur s'impose sans qu'on la lui dise.** Le concepteur doit connaître ces
   contraintes implicites et **en choisir une à faire tomber** (§5).
3. **Le leurre n'est pas un piège gratuit** : c'est l'outil qui amène à l'impasse. Il doit échouer de façon **instructive**
   (on voit pourquoi).
4. **Décomposer un bloc** : un élément perçu comme un tout (« le mur ») a en fait des parties utilisables (son bout, son angle,
   son dessous).

---

## 3. Couche 3 — Structures de conception éprouvées

### 3.1 Hypothèse → piège → révélation (GMTK, Mark Brown)
Une bonne énigme repose sur une **hypothèse** du joueur, un **piège** (« catch ») qui la contredit, et une **révélation**.
Une bonne part de la conception consiste à **empêcher** le joueur de faire certaines choses plutôt qu'à les lui permettre.

### 3.2 Concevoir à l'envers (Arvi Teikari, *Baba Is You*)
Teikari part d'une **interaction intéressante**, c'est‑à‑dire de la solution, puis **remonte** en posant des restrictions qui la
protègent ; la solution peut être simple, l'énigme vient de ce qu'elle est cachée derrière une suite de problèmes. Variante
documentée : décrire la solution, puis **retirer tout ce qu'on n'a pas mentionné**.

### 3.3 Fermer les solutions imprévues (Valve, *Portal*)
Dans le commentaire de *Portal*, une énigme devait enseigner le lien entre cubes et boutons ; une solution astucieuse de joueurs
la contournait, elle a donc été jugée comme un **échec**, et une **vitre** a été ajoutée pour l'empêcher. Autre cas : des
testeurs sautaient le long des rails jusqu'à la sortie. *Portal* est décrit par ses auteurs comme un long exercice
d'apprentissage ; une énigme qui présentait trop de concepts à la fois a été déplacée. Le studio testait chaque semaine et
mettait chaque niveau en test en deux à cinq jours.

### 3.4 Le niveau comme récit en quatre temps (Nintendo, *kishōtenketsu*)
Koichi Hayashida (*Super Mario 3D Land*, *Galaxy 2*) structure chaque niveau autour d'un concept central porté jusqu'au bout :
**introduction, développement, retournement, conclusion**, une structure issue du manga et transmise par Miyamoto. Mark Brown
résume : un mécanisme enseigné, développé, retourné puis abandonné en cinq minutes.
→ **Pour Quantix (analyse)** : cette structure s'applique à l'échelle d'un **monde de 12 niveaux** (§6), et dans un niveau à
deux temps (le leurre = « ce que tu crois », la solution = « le retournement »).

### 3.5 Le paquet de niveaux comme contrat (ZeptoLab, *Cut the Rope*)
Les niveaux sont regroupés par 25 dans une « boîte » au thème propre qui introduit une nouvelle mécanique ; le joueur sait qu'il
aura le temps de la maîtriser avant la suivante. La difficulté vient du nombre d'interactions, du timing et de la dextérité.
→ Quantix a choisi l'inverse sur la dextérité (« comprendre, pas réussir à tracer ») : garder la boîte, retirer la dextérité.

### 3.6 Deux philosophies opposées, à connaître
| Énigme **fermée** (Baba Is You, Sausage Roll, Snakebird) | Énigme **ouverte** (Crayon Physics, Brain It On, Zachtronics) |
|---|---|
| une idée à trouver ; le reste est fermé | Petri Purho a refusé les restrictions habituelles (ressources limitées, une ou deux solutions) pour laisser le joueur inventer |
| la difficulté vient de l'impasse | Zachtronics livre des énigmes que l'équipe n'a pas résolues elle‑même ; la profondeur vient de l'optimisation (histogrammes de temps, de coût, de taille) |
| **Brain It On** : plusieurs façons de résoudre chaque énigme, « trouver la meilleure » |

**Position de Quantix (décision proposée)** : *énigme fermée pour réussir, ouverte pour exceller.* L'**idée** est unique et
obligatoire ; la **réalisation** est libre (tolérance au doigt) ; la **maîtrise** (noyau, énergie économisée) offre une seconde
couche ouverte, à la manière des optimisations Zachtronics. (analyse)

---

## 4. Couche 4 — Corpus de jeux à étudier (et ce qu'on leur prend)

*Sourcé = mentionné dans les sources du §10 ; les autres sont des références classiques du genre, à étudier en détail dans les
séries suivantes.*

| Jeu | Auteur | À prendre pour Quantix |
|---|---|---|
| *Braid* (sourcé) | J. Blow | une mécanique (le temps) explorée jusqu'à ses conséquences ; minimalisme, ruptures de motif |
| *The Witness* (sourcé) | J. Blow | une grammaire qui s'apprend sans mots ; chaque panneau ajoute une vérité |
| *Miegakure* (sourcé) | M. ten Bosch | révéler la nature d'un système |
| *Baba Is You* (sourcé) | A. Teikari | concevoir à rebours depuis la solution |
| *Stephen's Sausage Roll* (sourcé) | S. Lavelle | dépouillement radical ; fermer tout ce qui n'est pas l'idée ; un monde = une nouvelle vérité sans nouvel objet |
| *English Country Tune* (sourcé) | S. Lavelle | changer d'objectif à chaque série avec les mêmes règles |
| *Sokobond*, *Cosmic Express*, *A Monster's Expedition* (sourcés) | A. Hazelden | verbaliser l'idée ; écueil signalé : des niveaux qui se ressemblent (« beaucoup de gras ») |
| *Pipe Push Paradise* (sourcé) | C. Zamudio | aucun remplissage : une énigme = une idée formulée |
| *Portal* (sourcé) | Valve | apprentissage en couches, fermeture des solutions imprévues, test hebdomadaire |
| *Super Mario 3D Land / 3D World* (sourcés) | Nintendo | kishōtenketsu : introduire, développer, retourner, conclure |
| *Cut the Rope* (sourcé) | ZeptoLab | boîtes thématiques, une mécanique par boîte |
| *Crayon Physics Deluxe* (sourcé) | P. Purho | le dessin devient physique ; liberté de solution |
| *Brain It On!*, *Shatterbrain* (sourcés) | Orbital Nine | physique + dessin, plusieurs solutions, « penser hors du cadre » |
| *Drawtopia* (sourcé) | — | une couleur de salle = une mécanique (gravité, portails) |
| *SpaceChem*, *Opus Magnum* (sourcés) | Zachtronics | optimisation comme seconde couche |
| *World of Goo*, *Poly Bridge*, *Bridge Constructor*, *Fantastic Contraption*, *The Incredible Machine* | — | construire sous contrainte de matériau ; Rube Goldberg |
| *Snakebird*, *Patrick's Parabox*, *Antichamber*, *Fez*, *Monument Valley*, *Outer Wilds*, *Return of the Obra Dinn* | — | à étudier : impasse dure, récursivité, perception, connaissance comme clé, déduction |

---

## 5. Couche 5 — Le moteur créatif : les hypothèses du joueur de Quantix

C'est le cœur du protocole. Une énigme naît d'une **hypothèse implicite** que le joueur porte et qu'on va faire tomber
(relâchement de contrainte, §2). Voici l'inventaire des hypothèses qu'un joueur de Quantix porte probablement (analyse —
**à confirmer par tes tests**) :

| # | Hypothèse implicite | Le niveau qui la fait tomber |
|---|---|---|
| H1 | « Un trait est un sol » | le trait est un **mur**, un **plafond**, un **déflecteur** en plein vol |
| H2 | « On trace avant de lâcher la balle » | il faut tracer **pendant la chute** |
| H3 | « La zone s'atteint par le chemin le plus court » | elle s'atteint par **le détour** (passer derrière, au‑dessus, revenir) |
| H4 | « Les pointes sont à éviter » | elles **ferment** le leurre mais **pas** la solution : rebondir juste à côté |
| H5 | « La mécanique du monde aide » | elle **gêne** ici (vent contraire, tapis piège) |
| H6 | « Plus d'énergie = plus de possibilités » | l'énergie est **juste** : un seul trait, au seul endroit |
| H7 | « La particule doit rester à l'écran » | elle sort par le haut et **revient** |
| H8 | « Il faut viser la zone » | il faut viser **un mur**, et c'est le rebond qui mène à la zone |
| H9 | « Le décor est inerte » | un mur fixe est la **moitié** d'une construction que le trait complète |
| H10 | « Un trait = un geste » | deux traits dont **l'ordre** compte (le second se trace pendant la chute) |
| H11 | « La direction du trait n'importe pas » | le tapis tracé **à l'envers** est la clé |
| H12 | « Monter est impossible sans aide visible » | une **chute** plus haute donne l'élan pour remonter ailleurs |
| H13 | « Le noyau est sur le chemin » | le noyau est sur le **leurre** : le prendre force à trouver une seconde idée |
| H14 | « Ce qui est loin ne compte pas » | l'élément décisif est à l'autre bout de l'écran |

**Règle** : chaque niveau d'un monde fait tomber **une** hypothèse différente ; la même hypothèse ne revient dans un autre monde
que transformée par sa mécanique.

---

## 6. Couche 6 — L'échelle du monde et l'enchaînement des mondes

**Un monde = un kishōtenketsu en 12 temps (analyse, d'après §3.4)** :

| Positions | Temps | Rôle |
|---|---|---|
| 1–3 | **Ki** (introduire) | la mécanique, sa vérité simple ; hypothèses faciles (H1, H8) |
| 4–6 | **Shō** (développer) | combinaisons avec ce qui est déjà su ; premières impasses |
| 7–9 | **Ten** (retourner) | la mécanique se retourne contre le joueur (H5), ou se révèle autre (H11, H12) |
| 10–12 | **Ketsu** (conclure) | deux idées du monde enchaînées ; le niveau 12 rappelle le niveau 1 en le renversant |

**Enchaînement des mondes** : chaque monde apporte **une vérité physique nouvelle** (la glace : on ne freine plus ; le vent :
une force sans contact ; la gravité : le haut n'est plus le haut…). Le premier niveau d'un monde reprend une hypothèse déjà
tombée dans un monde précédent et montre qu'avec la nouvelle vérité, **elle revient vraie ou fausse autrement**.

---

## 7. Le protocole de génération (version 1)

| Étape | Action | Sortie | Contrôle |
|---|---|---|---|
| 1 | **Explorer la mécanique** (Blow) : banc d'essai, situations limites, « que se passe‑t‑il si… » | liste de vérités mesurées | `banc.js` |
| 2 | **Choisir l'hypothèse à faire tomber** (§5) et la vérité qui la contredit | une ligne : « le joueur croit X ; en vérité Y » | unicité dans le monde |
| 3 | **Verbaliser l'idée** (Hazelden) en une phrase | phrase d'idée | si elle n'est pas claire : abandonner |
| 4 | **Écrire la solution, puis remonter** (Teikari) : retirer tout ce qu'elle n'utilise pas | géométrie minimale | tout élément = PORTER |
| 5 | **Construire le leurre** : la solution qu'impose l'hypothèse X ; il doit échouer **visiblement** | leurre + raison d'échec visible | le leurre échoue ; on voit pourquoi |
| 6 | **Fermer les solutions imprévues** (Portal) : pour chaque raccourci trouvé, **une** restriction nommée | éléments FERMER | `enigme.js` : 0 raccourci |
| 7 | **Vérifier l'impasse** : le leurre doit être la **première** idée d'un joueur (test des intuitions : ligne directe, pont, rampe) | liste des 3 premiers essais probables | ils échouent tous |
| 8 | **Jouabilité** : tolérance au doigt, énergie, marges | — | `fiche.js` |
| 9 | **Place dans le monde** (§6) : temps du kishōtenketsu, distance avec les niveaux voisins | registre | aucune redite |
| 10 | **Test de Simon**, observé comme chez Valve : ce qu'il essaie d'abord, où il bloque, quand il comprend | notes de test | l'impasse a eu lieu, puis l'« Aha » |

**Le critère de qualité qui manquait** : un niveau n'est accepté que si l'on peut écrire **« le joueur va d'abord essayer A,
qui échoue parce que B ; il comprend alors C »** — et si le test le confirme.

---

## 8. Anti‑modèles (constatés dans Quantix)

| Anti‑modèle | Exemple | Pourquoi c'est mauvais |
|---|---|---|
| Solution = première idée | 25 « Le tapis » | pas d'impasse, pas d'« Aha » |
| Élément décoratif | 11 « Le relais » (mur inutile), pointes au fond d'un vide déjà fatal | brouille la lecture, ment au joueur |
| Matière offerte qui ouvre tout | l'accélérateur dans la Chaîne | crée de l'énergie partout |
| Niveaux jumeaux | plusieurs « ponts » au Glacier | même idée, pas de nouveau raisonnement |
| Difficulté par imprécision | 38 (P_ligne 80 %) | on échoue sans avoir mal compris |
| Génération combinatoire | la forge | des chiffres conformes, aucune intention |

---

## 9. Ce que ce document doit encore devenir (séries suivantes)

1. Analyse détaillée, niveau par niveau, de 10 énigmes de référence (*Baba Is You*, *Sausage Roll*, *The Witness*, *Portal*,
   *Brain It On*, *Crayon Physics*) : quelle hypothèse elles font tomber, comment le leurre est construit.
2. Lecture des sources primaires (conférences GDC : Menzel 2016, Barth 2019, Rix et Voinov ; commentaire complet de *Portal* ;
   travaux de Knoblich et Öllinger).
3. Validation des hypothèses H1–H14 par tes tests (lesquelles portes‑tu vraiment ?).
4. Réécriture du cahier des charges à partir des §5–7, puis refonte d'un monde témoin.

---

## 10. Sources

- Game Developer — Blow à IndieCade, conception des énigmes de *Braid* et *The Witness* : gamedeveloper.com/design/indiecade-inside-jonathan-blow-s-puzzle-design-process
- Marc ten Bosch — « Designing to Reveal the Nature of the Universe » : marctenbosch.com/news/?p=181
- Notes de Juha‑Matti Santala, synthèse de conférences sur le design d'énigmes : notes.hamatti.org/gaming/puzzle-game-design
- Transcription GMTK « How Baba Is You Works » : amara.org (sous‑titres GMTK Most Innovative 2019)
- Xbox Wire — *Pipe Push Paradise* (conseil d'Alan Hazelden) : news.xbox.com/en-us/2019/02/11/pipe-push-paradise-xbox-one
- Thinky Games — dix ans de *Stephen's Sausage Roll* : thinkygames.com/features/10-years-of-grilling-stephens-sausage-roll…
- CESCG 2023 — « Designing Thinky Games » (honest puzzle games) : cescg.org/?p=5943
- Knoblich, Ohlsson, Haider, Rhenius (1999), *JEP:LMC* — Constraint relaxation and chunk decomposition in insight problem solving
- Frontiers in Human Neuroscience (2018) — modèle par étapes de l'insight (impasse, changement de représentation)
- Commentaire des développeurs de *Portal* : theportalwiki.com/wiki/Portal_developer_commentary
- MCV — Kim Swift sur le test de jeu : mcvuk.com (« Student Union »)
- Game Developer — Hayashida, « The secret to Mario level design » : gamedeveloper.com/design/the-secret-to-i-mario-i-level-design
- MCV — GMTK sur le kishōtenketsu : mcvuk.com/development/video-nintendos-level-design-secrets-in-four-steps
- Mechanics of Magic — analyse de *Cut the Rope* : mechanicsofmagic.com/?p=20270
- GDC Vault — Level Design Case Studies: *Trainyard* and *Cut the Rope* : gdcvault.com/play/1015344
- NBC News — entretien Petri Purho : nbcnews.com/id/wbna28628780
- TIGSource — entretien Petri Purho (Level) : tigsource.com/?p=19404
- Wikipédia — Zachtronics ; GDC Vault — « Open‑Ended Puzzle Design at Zachtronics » : gdcvault.com/play/1025715
- App Store — *Shatterbrain* ; ModDB — *Brain It On!* ; Microsoft Store — *Drawtopia*
- Scott Kim, TED « The art of puzzles » (définition)
