# QUANTIX — Méthode de travail (R122, 10 octobre 2026)

*La seule règle de méthode du projet. Elle remplace les protocoles, les consignes empilées et la barre « PRÊT » à dix critères.
Deux pages au plus : une nouvelle règle en remplace une, elle ne s'ajoute pas. Le pourquoi est dans `AUDIT_METHODE.md`.*

---

## 1. Le but

Un jeu publiable, beau et intelligent : chaque niveau porte **une idée** (ce que le joueur croit, ce qu'il découvre, le geste
qui en découle) et chaque monde a **un moment spectaculaire** (une machine faite des éléments du niveau). Simon juge à l'œil, sur
iPhone. Les outils servent à éviter de casser le jeu, pas à décider s'il est bon.

## 2. Le lot de travail

Un lot = **1 à 3 niveaux, ou une fonctionnalité précise**. Il se déroule toujours ainsi :

1. **Idée** — pour chaque niveau, trois lignes : *le joueur croit… / il découvre… / le geste*. Montrées à Simon avant de
   construire si le lot est nouveau ; sinon on avance.
2. **Construction** — géométrie dans `levels.js`, courbes et machines avec `tools/rail.js` (virages doux, lèvre posée sur la
   trajectoire, trémie + goulotte pour une entrée constante). Si Simon a dessiné le niveau dans l'éditeur, on part de son dessin.
3. **Quatre vérifications bloquantes** (et seulement celles‑là) :
   - le niveau se gagne avec une solution de référence (`optsol`), et ne se gagne pas sans rien tracer ;
   - aucun élément dans la zone de réussite (`node tools/zonepropre.js`) ;
   - le test du monde passe (`node tools/mondeN.js`) et `replaytest.js` reste vert ;
   - **une capture regardée** (Playwright) avant d'affirmer quoi que ce soit sur le rendu.
4. **Indicateurs, non bloquants** (à donner en une ligne, jamais à poursuivre en boucle) : jouabilité avec l'éditeur
   (`difficulty.js`, modèle éditeur), raccourcis (`enigme.js`), noyau, régularité d'une machine (`constance.js`).
5. **Aperçu** publié pour Simon, avec une phrase : *quel monde, quels niveaux regarder, quoi juger*.

## 3. Budget et arrêt

- **Deux essais par problème.** Au troisième, on s'arrête et on montre à Simon l'état + deux options.
- Pas de recherche automatique (balayage de paramètres) de plus d'une commande sans l'avoir annoncée.
- Un niveau ancien qui ne tient pas se **refait** à partir d'une idée ; on ne le règle pas au pixel.
- Si une règle de ce document empêche un résultat que Simon voudrait, on le lui dit au lieu de la contourner.

## 4. Sessions et livraison

- **Une conversation par lot.** Au début : lire `METHODE.md` et `REPRISE-SESSION.md` (une page), rien d'autre par défaut.
- **Le code vient du zip joint** (ou du dépôt GitHub s'il est connecté). Sans lui, demander avant de toucher au code.
- **Livrer** : le zip du site (fichier envoyé) et l'aperçu du monde travaillé, republié à la même adresse
  (`python3 tools/build-apercu.py N`, titre « Quantix Monde N »), en disant clairement quel monde la page montre.
- **Réécrire** `REPRISE-SESSION.md` (une page : état, ce qui est dans le jeu, prochain lot) et l'envoyer au Projet.
- Dire ce qui est dans le jeu et ce qui ne l'est pas ; ce qui a été vérifié et ce qui ne l'a pas été.

## 5. Ce que Simon attend (repères de goût)

- **Visuel** : néon sur fond #05070D, couche cosmique, murs en lumière quantique, éthéré et subtil ; rien dans la zone ;
  jetons de couleur du `HANDBOOK.md` §6. Pas de « rétro plat ».
- **Machines** : amples, lisibles, harmonieuses (courbes calculées, jamais tracées à la main), entrée fluide, faites des
  éléments du monde ; **chaque machine contient un bonus de son monde (ex. un rebond en Fonderie) et une trajectoire longue,
  amusante à regarder** (règle de Simon, 10 oct.).
- **Aucune zone invisible** : pas de zone non traçable cachée (`mz`) ; toute interdiction de tracer est visible (hachures).
- **Son** : organique, qui respire, doux, jamais strident (notes ≤ 520 Hz, partiels ≤ 1,5 kHz) ; base W1N dans `sound.js`.
- **Textes** : français et anglais dans `i18n.js` uniquement ; ton dramaturgique, précis.
- **Interface** : le terrain ne change jamais de taille ; l'éditeur doit rester utilisable au doigt sur iPhone.

## 6. Règles techniques (inchangées, courtes)

- Modifier par correctif compté (OK / ÉCHEC) ; jamais de réécriture complète d'un fichier de code.
- Chemins relatifs ; aucun texte visible hors de `i18n.js`.
- Dans `node -e`, ne jamais nommer une variable `L`, `S` ou `T` ; vérifier qu'un identifiant est libre avant de l'introduire.
- Pas de vies, d'énergie payante, de minuteur, ni de publicité après un échec (`ENGAGEMENT-ET-MONETISATION.md`).

## 7. La bibliothèque (à consulter, jamais à cocher)

`BIBLE_ENIGMES.md` (idées d'énigmes, hypothèses du joueur), `QUANTUM_VISUAL_NARRATIVE.md` (l'expérience de chaque monde),
`HANDBOOK.md` (moteur, rendu, jetons), `CAHIER_DES_CHARGES_GENERATION.md` §17–§25 (langue visuelle, courbes, jonctions),
`ANNEXE_DESIGN_JONCTIONS.md`, `DIDACTICIEL_DESIGN.md`, `SON_MONDES.md`. Les autres protocoles (difficulté, scénario, finition,
dramaturgie, canevas, triage…) sont des archives : ne pas les lire sauf demande.
