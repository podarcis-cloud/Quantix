# QUANTIX — narration et identité visuelle des mondes

*Chaque monde raconte une expérience de physique réelle, et son décor animé
la met en scène. La mécanique de jeu du monde et l'expérience qu'il évoque
doivent dire la même chose : le décor n'est pas une tapisserie, c'est le
laboratoire dans lequel le joueur se trouve.*

*Statut des affirmations : les expériences marquées **[source]** sont
vérifiées par les références en fin de document. Celles marquées
**[à sourcer]** relèvent de la culture scientifique générale et devront
être vérifiées avant toute mention dans un texte visible du jeu. Le décor,
lui, est une interprétation artistique, jamais une affirmation.*

---

## Le fil narratif du jeu

**Une particule remonte l'histoire de la physique, de l'établi jusqu'au
cœur quantique.** Le monde 1 est l'atelier où l'on apprend que le trait
est matière. Chaque monde suivant est une salle d'expérience plus
étrange, jusqu'au monde 11, où la particule cesse d'être une bille et
devient ce qu'elle a toujours été : une onde de probabilité.

Progression graphique : du **concret** (poutres, charpente, atelier)
vers le **lumineux** (champs, faisceaux) puis vers le **probabiliste**
(nuages de points, franges, états superposés). Les structures perdent
leur matière au fil des mondes : acier → verre → lumière → pointillés.

---

## Références d'animation fournies par l'utilisateur

Trois vidéos d'**illusions bistables** (capsule, sphère, anneau en nuages de
points en rotation 3D). Intention de l'utilisateur : ce sont des exemples
d'**animations fondées sur les mathématiques**, qui ajoutent de la
crédibilité quantique — à utiliser pour construire **l'identité visuelle
animée de chaque monde** (fonds, champs, phénomènes), pas pour créer un
nouveau noyau par monde.

## Le noyau (joyau) — une signature commune, déclinée par monde

**Référence visuelle fournie : illusions bistables** — nuages de milliers de
points en rotation 3D (capsule, sphère, anneau) dont le sens de rotation est
ambigu : le cerveau hésite entre deux lectures et peut basculer de l'une à
l'autre. C'est une métaphore juste de la **superposition** : deux états à
la fois, jusqu'à ce qu'on « tranche ».

**Forme de base** : un noyau en nuage de points sphérique (dégradé rose →
violet → cyan, rotation sans indice de profondeur, donc sens ambigu),
ceint d'une orbite elle-même en nuage de points (anneau). Rayon visuel
≈ 18 u, cohérent avec le rayon de capture réel (R + 10 = 20,5 u).

**Déclinaison par monde** : la forme du nuage change (sphère, capsule,
anneau, double lobe), la palette suit le monde, et la capture « effondre »
le nuage en un point (la mesure fige l'état) avant l'éclat.

---

## Monde par monde

### 1 · Atelier — « Le code de la matière »
- **Expérience évoquée** : aucune en particulier — l'atelier est
  l'avant-propos. Motif : la double hélice (le code, l'assemblage).
- **Identité graphique** : charpente d'acier en treillis, câbles, piliers ;
  voile cosmique cyan-violet ; poussière d'étoiles ; hélices ADN.
- **Décor animé** : hélices en rotation composées selon chaque niveau,
  poussière qui s'écarte de la balle, nébuleuses qui respirent.
- **Noyau** : sphère de points bistable, orbite annulaire.
- **État** : aperçu v2 (décor composé par niveau) réalisé.

### 2 · Fonderie (rebond) — « La chambre à bulles »
- **Expérience évoquée [à sourcer]** : la chambre à bulles, où les
  particules chargées laissent des traces qui s'enroulent en spirales
  sous un champ magnétique — l'image emblématique de la physique des
  particules.
- **Lien avec la mécanique** : le rebond rend de l'énergie ; les traces
  en spirale montrent l'énergie qui se dépense tour après tour.
- **Identité graphique** : fonte incandescente (orange rebond `#FFAA3C`,
  braise), fond rouge sombre, bulles.
- **Décor animé** : traces de particules qui naissent au bord et
  s'enroulent en spirales qui se resserrent ; chapelets de bulles qui
  montent ; à chaque rebond de la balle, une nouvelle trace part du
  point d'impact.
- **Noyau** : nuage en capsule, orange et or.

### 3 · Chaîne (élan) — « L'anneau de stockage »   ✅ intégré au jeu (R35)
- **Expériences et faits évoqués [source]** :
  - Dans un anneau de stockage, une **cavité radiofréquence** redonne aux
    particules l'énergie perdue et maintient le faisceau **à énergie fixe**
    (SEES, *Synchrotron Radiation*). Les cavités supraconductrices ont la
    forme d'une **suite de bulbes reliés** — une chaîne.
  - Quand un aimant de courbure dévie les particules, la **lumière synchrotron
    est émise en tangente** à leur trajectoire, en éventail dans le plan de
    l'anneau (SLAC-PUB-9006) ; chaque aimant alimente des **lignes de lumière**
    tangentes.
  - Les particules circulent **en paquets** ; la lumière arrive **en
    impulsions** (DESY, *How does a synchrotron radiation source work?*).
- **Lien avec la mécanique** : le tapis d'élan est un **interrupteur** (mesuré
  R29 : la balle repart à ~7,2–7,8 u/image quelle que soit la longueur du
  tapis) — exactement le rôle d'une cavité RF, qui ramène toujours à la même
  énergie. Le tapis **est** une cavité RF.
- **Gimmick visuel propre au monde — la lumière synchrotron de la balle** :
  dès que la balle tourne vite (variation d'angle × vitesse), un rayon part
  **en tangente** à sa trajectoire. Aucun autre monde ne fait ça ; c'est la
  physique réelle de l'accélérateur, appliquée au joueur.
- **Tapis d'élan (cavité RF)** : chaîne de cellules violettes derrière la
  surface de roulement ; une onde lumineuse la parcourt **dans le sens de la
  poussée** (chevrons) — la direction de l'élan se lit d'un coup d'œil ;
  toute la chaîne s'illumine au contact (`ball.boost`).
- **Décor** : anneau de stockage (deux lignes droites, deux arcs) qui
  **encadre** la scène près des bords ; six aimants de courbure d'où partent
  des lignes de lumière tangentes parcourues d'impulsions ; quatre paquets à
  **vitesse fixe** qui flashent en traversant la cavité RF de l'anneau.
- **Noyau** : sphère bistable ceinte d'un anneau parcouru par trois paquets.
- **Code** : `assets/js/visuals.js` — `drawRing`, `synchro`, `boostPad`.
- **Reste** : les **niveaux** du monde 3 sont encore ceux de R29 (à refondre
  selon la méthode des mondes 1–2 et le protocole de difficulté).

### 4 · Glacier (glace) — « Le condensat »
- **Expérience évoquée [à sourcer]** : le condensat de Bose-Einstein
  (1995) — refroidis près du zéro absolu, des milliers d'atomes se
  comportent comme une seule onde ; son image en fausses couleurs est
  un pic qui émerge d'un nuage.
- **Lien** : sur la glace, rien ne freine — le mouvement se conserve,
  comme un superfluide qui s'écoule sans frottement.
- **Identité** : cyan très pâle, blanc, cristaux, halos froids.
- **Décor animé** : réseau de tourbillons figés qui tournent lentement ;
  givre qui pousse le long des surfaces de glace ; pic du condensat qui
  pulse au loin.
- **Noyau** : nuage qui se contracte en un pic unique, puis se relâche.

### 5 · Soufflerie (vent) — « Stern et Gerlach »
- **Expérience évoquée [source]** : un faisceau d'atomes d'argent, traversant
  un champ magnétique non uniforme, se sépare en deux taches distinctes
  sur la plaque — la quantification de l'espace.
- **Lien** : le vent est une force continue qui dévie en vol, comme le
  gradient de champ dévie le faisceau.
- **Identité** : faisceaux, gris-argent, bleu glacé.
- **Décor animé** : un faisceau de points traverse le fond et se scinde
  en deux lobes ; les zones de vent sont dessinées comme des gradients de
  champ, lignes qui s'écartent.
- **Noyau** : deux lobes (haut et bas) qui se partagent les points —
  capturer le noyau fusionne les deux lobes.

### 6 · Mécanique (barres mobiles) — « Le piège à ions »
- **Expérience évoquée [à sourcer]** : des ions piégés, alignés en
  chapelet, qui oscillent et servent d'horloges atomiques.
- **Lien** : le monde du timing — tout bat, tout oscille.
- **Identité** : or, métal usiné, graduations d'horloge.
- **Décor animé** : chapelets d'ions qui oscillent en rythme avec les
  barres mobiles ; aiguilles et graduations qui battent la mesure.
- **Noyau** : chapelet de points qui oscille.

### 7 · Gravité — « Le puits de potentiel »
- **Expérience évoquée [à sourcer]** : la particule dans un puits — ses
  états possibles sont des ondes stationnaires à niveaux d'énergie
  discrets.
- **Lien** : les champs de gravité sont des puits et des bosses que la
  particule doit gravir ou dévaler.
- **Identité** : vert arrivée `#9BEB4B` sur fond profond, courbes de
  niveau, grille déformée.
- **Décor animé** : grille de l'espace qui se creuse sous les zones de
  gravité ; ondes stationnaires qui vibrent dans les puits.
- **Noyau** : nuage en couches concentriques (niveaux d'énergie).

### 8 · Magnétisme (aimants) — « La précession »
- **Expérience évoquée [à sourcer]** : le spin d'une particule tourne
  autour d'un champ magnétique comme une toupie qui penche.
- **Lien** : l'aimant est le seul champ dont la force dépend de la
  trajectoire exacte — le décor montre des lignes de champ.
- **Identité** : lignes de champ, violet et cyan, flèches de spin.
- **Décor animé** : lignes de champ autour de chaque aimant, toupies de
  spin qui précessent ; la limaille de points s'aligne quand la balle
  passe.
- **Noyau** : sphère de points avec un axe qui précesse.

### 9 · Faille (portails) — « L'effet tunnel »
- **Expérience évoquée [à sourcer]** : une particule franchit une barrière
  qu'elle ne devrait pas pouvoir franchir ; le microscope à effet tunnel
  permet de voir les atomes, et des atomes disposés en cercle font
  apparaître des ondes stationnaires (le « corral quantique »).
- **Lien** : le portail est un passage à travers la barrière, vitesse
  conservée.
- **Identité** : paysages atomiques (reliefs de points), barrières
  translucides.
- **Décor animé** : chaque portail est entouré d'un anneau d'atomes où
  des ondes stationnaires vibrent ; l'onde de la balle « fuit » à
  travers les murs sous forme d'une trace exponentielle qui s'éteint.
- **Noyau** : anneau d'atomes avec une onde centrale.

### 10 · Filaments (corde, corps mou) — « Les modes de vibration »
- **Expérience évoquée** : les modes propres d'une corde vibrante —
  nœuds et ventres — image classique qui fonde l'idée d'états quantifiés.
- **Lien** : la corde et le corps mou se déforment ; leurs formes
  possibles sont des modes.
- **Identité** : fils lumineux, harmoniques, rose et violet.
- **Décor animé** : cordes tendues en fond qui vibrent sur leurs
  harmoniques ; la corde du joueur montre ses nœuds quand la balle la
  touche.
- **Noyau** : anneau qui vibre en mode 2, 3, 4.

### 11 · Quantique — « Les fentes de Young »
- **Expériences évoquées [source]** :
  - *Construction d'une figure d'interférence électron par électron*
    (Tonomura et al., Hitachi, 1989) : des impacts isolés, apparemment
    aléatoires, finissent par dessiner des franges.
  - *Holographie biphotonique* (Zia et al., *Nature Photonics*, 2023) :
    image, reconstruite par interférence, de l'état de deux photons
    intriqués — un symbole yin-yang.
- **Lien avec les mécaniques** : superposition (dédoublement de la
  balle), mesure (le détecteur effondre l'état), intrication (portes
  liées).
- **Identité** : tout devient pointillé ; plus de poutres pleines, des
  surfaces faites d'impacts.
- **Décor animé** :
  - un écran de fond qui **accumule des impacts** tout au long du
    niveau : d'abord aléatoires, ils dessinent peu à peu des franges ;
  - quand la balle passe devant un **détecteur**, les franges s'effacent
    et laissent place à deux bandes simples — l'observation change ce
    qu'on voit ;
  - les paires **intriquées** sont reliées par une figure en deux
    moitiés complémentaires qui tournent ensemble.
- **Noyau** : sphère de points qui se dédouble en deux moitiés
  complémentaires tant qu'elle n'est pas capturée.

---

## Règles de production du décor

1. **Le décor ne gêne jamais la lecture du jeu** : il se place dans les
   zones vides, loin des structures, du bassin, du noyau et de la
   colonne de chute (composition automatique, voir l'aperçu v2).
2. **Le décor réagit au joueur** : la poussière s'écarte, une trace naît
   d'un rebond, les franges s'effacent devant un détecteur. Un décor qui
   ne réagit à rien est une tapisserie.
3. **Chaque niveau a sa variante** : orientation, placement et teinte
   dérivés de la géométrie et de l'humeur du niveau.
4. **Couleurs** : jetons du handbook §6 et leurs nuances uniquement.
5. **Coût** : les couches lourdes (nébuleuses) sont pré-calculées une
   fois par niveau ; seul ce qui bouge est redessiné.

---

## Sources

- Tonomura A., Endo J., Matsuda T., Kawasaki T., Ezawa H. (1989).
  *Demonstration of single-electron buildup of an interference pattern.*
  American Journal of Physics 57, 117–120.
- Zia D., Dehghan N., D'Errico A., Sciarrino F., Karimi E. (2023).
  *Interferometric imaging of amplitude and phase of spatial biphoton
  states.* Nature Photonics 17, 1009. DOI 10.1038/s41566-023-01272-3.
- Schmidt-Böcking H. et al. (2019). *The Stern-Gerlach experiment
  re-examined by an experimenter.* Europhysics News 50(3), 15 — séparation
  du faisceau d'argent en deux composantes.
- SLAC-PUB-9006, *Radiation protection at synchrotron radiation facilities* —
  émission tangentielle en éventail aux aimants de courbure.
- SEES, *Synchrotron Radiation* (seescience.org) — cavité RF, énergie fixe,
  faisceaux aux tangentes de chaque aimant.
- DESY Photon Science, *How does a synchrotron radiation source work?* —
  paquets, impulsions.
- Références visuelles fournies par l'utilisateur : trois illusions
  bistables en nuage de points (capsule, sphère, anneau).
