# QUANTIX — Système visuel du didacticiel (R116)

> **Statut R209 : référence (didacticiel) ; règles d'affichage à jour : REPRISE R202.** Voir `INDEX_DOCUMENTS.md`.


*Document opposable. Il remplace toutes les retouches antérieures du didacticiel (R38, R116 a–c).
Toute fiche, consigne ou explication du jeu suit ces règles ; aucune valeur n'est écrite en dur :
elles vivent dans les jetons `--tu-*` de `quantix.css` (bloc « SYSTÈME DIDACTICIEL ») et le dessin du cadre
(`drawFrame` dans `tuto.js`) les lit avec `getComputedStyle`.*

---

## 1. Parti pris : la fiche est un instrument de mesure

Le didacticiel ouvre sur « Avant d'être mesurée, elle est partout et nulle part ». Le ton retenu en R38 est celui du
**carnet de laboratoire**. La fiche est donc une **plaque d'instrument** posée sur l'expérience : un verre sombre,
un cadre de lumière tenue qui reprend **exactement** la langue des murs (CAHIER §22–§24 : filets de lumière qui se
rencontrent en **jonctions** — lentille de verre sombre et petit atome), un viseur autour de la figure, une lecture
en caractères à chasse fixe. Rien n'est décoratif : chaque signe dit « on observe, on mesure ».

## 2. Un seul composant, deux formats

| Format | Quand | Anatomie | Bloque le jeu |
|---|---|---|---|
| **Fiche** (`.tcard`) | ouverture du niveau 1, nouvel outil, nouvel élément, aide du niveau, explications | repère · progression — figure animée — titre — texte — action principale — « Passer » | oui (voile) |
| **Consigne** (`.tcoach`) | pendant la première partie : dévier, lâcher, corriger | repère · progression · « Passer » — titre — texte | non : le doigt la traverse, elle s'efface pendant le tracé, disparaît pendant le lancer |

Même cadre, même typographie, mêmes points de progression, même animation d'apparition. La consigne est la fiche
sans figure ni bouton : jamais une autre proposition.

## 3. Couleur — deux rôles, jamais mélangés

1. **L'interface parle en `--tu-ink`** (= `--accent`, la couleur du monde) : cadre, jonctions, photon, repère, points de
   progression, viseur de la figure, action principale (la même gélule que « Lâcher la balle »).
2. **La couleur de l'élément (`--tc`) n'apparaît que dans ce qu'elle désigne** : le contenu de la figure animée, le
   soulignement du mot‑clé, et la pastille (losange) du repère — un échantillon de matière, comme sur une étiquette.

Interdit : teinter le cadre, le fond, l'ombre ou le bouton avec la couleur de l'élément (c'était l'effet « arc‑en‑ciel »
du niveau 2 : quatre fiches, quatre couleurs de cadre). Aucune couleur hors des onze jetons (HANDBOOK §6) et de leurs nuances.

## 4. Le cadre (dessiné, pas une bordure CSS)

- Quatre **filets** de 1 px, `--tu-ink` à `--tu-line` d'opacité, avec un halo très faible (3 px, `--tu-halo`).
- Aux quatre coins, une **jonction en L de la langue des murs** : `VX.joints` (le code même des niveaux), réduite à
  l'échelle `--tu-node`, teinte `--tu-ink`. Pas de perle ni d'ancrage : le cadre est fermé.
- Retrait du cadre dans le verre : `--tu-inset`.

## 5. Mouvement — une seule animation par rôle, lente, au rythme du jeu

Le rythme de référence est le **tour du noyau : 6 s** (R57–R58).

| Rôle | Animation | Jeton |
|---|---|---|
| Apparition | **la mesure** : deux copies décalées et floues (superposition) se réduisent en une seule fiche nette | `--tu-enter` (480 ms) |
| Veille | **un photon** parcourt le cadre (tête blanche, traîne à la couleur de l'interface) | `--tu-photon` (12 s = deux tours de noyau) |
| Jonctions | l'atome des coins tourne et émet son onde, comme sur les murs | (celui des murs) |
| Attention | seule l'action principale respire (halo) ; rien d'autre ne clignote | `--tu-breath` (6 s) |
| Mouvement réduit | tout est figé ; apparition en fondu | `prefers-reduced-motion` |

## 6. Mesures (grille de 4 px)

| Jeton | Valeur | Usage |
|---|---|---|
| `--tu-r` | 14 px | rayon du verre (fiche et consigne) |
| `--tu-pad` | 18 px | marge intérieure de la fiche |
| `--tu-pad-s` | 14 px | marge intérieure de la consigne |
| `--tu-inset` | 6 px | retrait du cadre dessiné |
| `--tu-gap` | 8 px | écart entre blocs |
| `--tu-glass` | #05070D à 90 % | verre (le fond du jeu, jamais une autre teinte) |
| `--tu-blur` | 14 px | flou d'arrière‑plan |

Typographie (HANDBOOK §6) : repère en chasse fixe 9,5 px, majuscules espacées .2em ; titre Space Grotesk 20 px ;
texte Inter 13,5 px / 1,5 ; la première phrase d'ambiance en italique (R38).

## 7. Placement

- Le terrain ne change **jamais** de taille ni de place : tout est en surimpression.
- Rien ne couvre la barre du bas (Lâcher, outils) : limite `--tfh`, mesurée.
- La fiche se pose à l'opposé de ce qu'elle désigne ; la consigne à l'opposé du bassin.
- Si la place manque, la fiche défile au doigt ; la figure n'est retirée qu'en dernier recours.

## 8. Vérification

`node tools/tutotest.js`, `python3 tools/e2e-didacticiel.py`, captures Chromium du niveau 1 (ouverture + consigne),
du niveau 2 (série d'outils + zone interdite : un seul cadre, une seule couleur d'interface) et d'un élément coloré
(pointes, rebond). Toujours regarder les captures.
