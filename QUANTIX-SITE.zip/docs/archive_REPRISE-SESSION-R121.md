# QUANTIX — REPRISE DE SESSION (à lire EN PREMIER, puis s'arrêter là)

*Ce fichier remplace la relecture de la conversation précédente, devenue trop
longue et trop coûteuse. Il suffit à reprendre le travail. Version : **R121**.*

## ⟶ ÉTAT AU R121 (9 octobre 2026, après-midi) — LIRE CE BLOC D'ABORD

**Décisions de Simon** : (1) monde 2 : ne faire que les machines 6 et 12, laisser les autres niveaux ; (2) **la réussite facile au
doigt n'est plus exigée : on mesure avec l'éditeur de ligne** (outil Droite, déplacement aimanté) — `difficulty.js` utilise
désormais le modèle ÉDITEUR à toutes les positions (`DOIGT=1` rétablit l'ancien modèle). Seuil P_exec ≥ 70 % inchangé.

**Fait (zip QUANTIX-R121, tampon `build R121 · Monde 2 : mesure éditeur, creuset du 18`, aperçu du monde 2 publié à la même adresse)**
- Remesure du monde 2 (modèle éditeur) : P_exec ≥ 70 % pour 13, 14, 16, 17, 18, 20, 21, 23, 24 ; sous 70 % : 15, 19, 22.
  PRÊTS : 14, 20. Ce qui bloque les autres : traits courts (13, 16, 17, 18, 22, 23, 24), énigme (13, 16, 17, 21), élément dans
  la zone (21), pas de solution (19).
- **18 Ta plaque — machine « creuset »** : le joueur fabrique sa plaque, la particule est versée dans un creuset à bras courbes
  (en haut à droite), une goulotte la redresse, une plaque fixe la relance dans le bassin, abrité sous le bras droit, avec un
  dosseret. Constance 195/200, ≈ 4,6 s. Géométrie : `tools/fiches/machines/plaque18.json` ; recherche : scratchpad
  `m/s18b.js`, `m/s18c.js` (balayage plaque × bassin sur le vrai moteur). Idée déclarée : passage par la goulotte
  (registre `U:['P0'], pass`). À reprendre : un trait de 39 u suffit ; la plaque fixe n'est pas utilisée par toutes les solutions.
- **24 La fonte — machine finale NON faite** : le jeu de rebonds du joueur est chaotique, le creuset n'y trouve pas de place stable
  (essais `m/s24.js`, `m/s24b.js`). Piste : machine AU DÉPART (lacets déterministes qui amènent la particule au point de départ
  actuel), constance 100 % par construction.
- Outils : `fiches/auto.js` (fiche générique de réparation : bassin déplacé/élargi, dosseret optionnel) — peu efficace sur le
  monde 2 au modèle doigt ; `autoplan.py N` (plan slotwrite avec noms/conseils actuels) ; `constance.js` lit `EY2` (borne basse
  de la détection d'entrée) et trace avec la matière de la fiche (`F.mat`) ; `fiche.js SOFT=1` tolère P_hasard.
- Tests : monde1 12/12, monde2 11/11, replaytest OK, tutotest OK.

**Suite R121 (10 oct.)** — rien de neuf dans le jeu :
- Machine AU DÉPART du 24 essayée (`fiches/24.js`, `machines/fonte24.json`, scratchpad `m/m24.js`) : les lacets fonctionnent,
  mais la particule arrive avec plus d'énergie que l'ancien départ à l'arrêt. L'énigme des rebonds se dégrade (P_exec 30 %,
  plaque du sol plus utilisée, trait de 13 u suffit). **Ancien 24 restauré** (P_exec 67–70 %, énigme ✓).
  Piste : freiner la particule en fin de lacets (remontée qui l'arrête) pour qu'elle reparte comme à l'arrêt en (40, 360).
- Traits courts du monde 2 analysés (`tools/courts.js N [nd]`) : sur 16 et 23, les traits courts gagnants SONT la solution
  voulue en plus court (rampe près de la balle, déflecteur au‑dessus de la plaque). Les fermer par des zones interdites
  casserait l'énigme ; le seuil de coût ne convient pas à ces idées. Décision à prendre avec Simon.

## (historique) ⟶ ÉTAT AU R120 (9 octobre 2026, matin) — LIRE CE BLOC D'ABORD

**Retour de Simon après R119** : refonte jugée superficielle ; machines 3 et 6 peu élégantes (« courbes tracées par un enfant ») ;
son presque oppressant à partir du niveau 8 ; mur dans la zone du niveau 11 ; consigne du didacticiel du niveau 1 qui gêne le tracé.
Consigne : **ne revoir que les montagnes russes** (design harmonieux, entrée fluide) + corriger le didacticiel.

**Fait (zip QUANTIX-R120, tampon `build R120 · Machines 3 et 6 refaites`, aperçu republié à la même adresse)**
- **Nouvel outil `tools/rail.js`** : pistes en « tortue » (droites + virages à courbure sinusoïdale, raccord G2) et mesure des
  à‑coups d'un trajet. Les crochets en J sont posés par simulation : la lèvre épouse la trajectoire de vol à 0,8 u près
  (rayon de contact réel = R + 3,2 = 13,7 u pour une courbe), puis le virage retourne la particule. Scripts de conception :
  scratchpad `m3.js`, `m6.js` ; géométrie figée dans `tools/fiches/machines/lacets3.json` et `collines6.json`.
- **3 Le colimaçon** : lacets à trois crochets (droite/gauche/droite), courbe d'accueil, zone déplacée à droite (215).
  Constance 200/200, ≈ 3,2 s avec la solution de référence (médiane 5,5 s sur 200 entrées). PRÊT. Idée déclarée dans le registre
  (`U:['c1','c2']`), zone interdite réduite (190,40,110,100). Fiche acceptée avec réserve P_hasard 2,2 % (`SOFT=1` tolère
  désormais P_hasard, qui n'est pas dans la barre §9).
- **6 Les collines** : vague d'un seul tenant — crochet d'accueil, descente, vallée, crête où la particule décolle, dosseret.
  Constance 200/200, 4,2 s. PRÊT.
- **11** : mur retiré de la zone (il la traversait), zone interdite raccourcie ; énigme ✓ ; reste sous la barre (jouabilité).
- **Didacticiel niveau 1** : la consigne (`placeCoach` dans `tuto.js`) se pose dans le coin le plus libre, en priorité sur la
  barre du haut (titre, énergie) : elle ne couvre plus la zone de tracé. Vérifié en capture 390×780 et 375×667.
- Moteur : `curveSample(cv.pts, cv.st||9)` (pas d'échantillonnage réglable par courbe, inutilisé pour l'instant).
- Tests : monde1 12/12, replaytest OK, tutotest OK, zone propre sur tout le monde 1. **9 niveaux PRÊTS sur 12** (2–8, 10) ;
  à reprendre : 1, 9, 11, 12.

**Non fait / à faire** : son trop dense à partir du niveau 8 (alléger W1N aux niveaux 8–12) ; machines 8 et 10 non retouchées
(simples tremplins) ; finale 12 sans machine. Méthode rail.js à réutiliser pour toute machine (mondes 2 à 4).

## (historique) ⟶ ÉTAT AU R119 (9 octobre 2026) — LIRE CE BLOC D'ABORD

**Règle en vigueur : `claude/CONSIGNES_SIMON.md` §9 « Priorité quota »** (l'emporte sur §2–§6). But : mondes 1 à 4 déployables.
Une discussion par monde ; à la fin : zip du site (fichier) + aperçu publié à la même adresse
(https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC, `python3 tools/build-apercu.py N`, titre « Quantix Monde N »),
puis état + reprise dans le Projet.

**Monde 1 livré (zip QUANTIX-R119, tampon `build R119 · Monde 1 livré (8/12 prêts)`)**
- PRÊTS (barre §9 complète) : 2 Le pont, 3 Le colimaçon (machine lacets), 4 Le relais, 5 Le demi-tour, 6 Les collines (machine vague),
  7 Économie, 8 La portée (machine-énigme), 10 Le plafond.
- À REPRENDRE (dans le jeu, marqués `reporte` dans `tools/fiches/registre.json`) :
  - 1 Le premier trait (géométrie de Simon, 97 % au doigt, énigme ✓) : un mur de 11–16 u suffit (seuil 40).
  - 9 Le détour (87 %, énigme ✓) : 59 u suffisent (seuil 120).
  - 11 : ancien niveau conservé (20 % au doigt, élément dans la zone) ; fiche « La moitié » sans réalisation.
  - 12 : ancien niveau conservé (23 %, pas de machine, obligatoire §9) ; fiche lacets + trait qui cueille et verse plafonnée
    à 67 % (modèle éditeur) en 6 itérations.
  Ces quatre niveaux ne passent pas la barre ; ni l'ancien ni le nouveau 11/12 ne la passent → ancien gardé.
- Tests : monde1 12/12, replaytest OK, tutotest OK. Captures regardées : carte, niveau 3, niveau 6.
- Son W1N corrigé (R118) : vrais creux, cycle de 8 mesures, pulsation dès le niveau 1 — `docs/SON_MONDES.md`, mp3 niveaux 1 et 4 envoyés.
- Didacticiel : laissé tel quel (système `docs/DIDACTICIEL_DESIGN.md`), à finir plus tard.
- Éditeur : magnétisme du déplacement livré (R117) ; republication + préréglages `Q-MM-PP` seulement après le monde 4.

**Outils clés** : `tools/valide.py N plan.json [MACHINE=EX,EY,ER] [ZONE=…] [NOYAU=1]` (installe + toutes les vérifications + ligne d'état) ;
`fiche.js` avec `F.space` + `BUDGET` (exploration aléatoire), `SOFT=1`, `SHOW=1` ; `difficulty.js` modèles EXEC (pos. 1–6) / EDIT (7–12) ;
`enigme.js` tient compte des courbes et de `mz` (avant R118 il les ignorait) ; `python3 tools/etat.py` régénère
`docs/ETAT_REFONTE_NIVEAUX.md`. Leçons de géométrie : `docs/MONDE1_FICHES.md` (pas de jonction précise trait/pièce, faire TOMBER
la balle sur le trait, lèvre au-dessus de l'arrivée, fermer les raccourcis de machine par `nd`/gardes).

**Prochaine tâche : monde 2** (nouvelle discussion, joindre QUANTIX-R119.zip). Ordre : lire l'état du monde 2 dans
`ETAT_REFONTE_NIVEAUX.md`, ne pas toucher aux PRÊTS (14 Le ricochet), refaire les autres via fiche → `valide.py`
(6 itérations max par niveau), machines obligatoires en 6 et 12, variante légère de W1N, livraison comme ci-dessus.

## (historique) ⟶ ÉTAT AU R117 (9 octobre 2026, nuit) — LIRE CE BLOC D'ABORD

**Lire `docs/ANALYSE_R116.md`** : analyse mesurée des 132 niveaux (jouabilité au doigt refaite sur tous), faiblesses de fond classées,
ordre de travail, tableau régénérable (`python3 tools/etat.py`). En bref : 2 niveaux cochent tout ; 17 jouables au doigt ; la note A ne
mesurait pas la jouabilité ; 74 niveaux sans solution de référence ; 1 machine sur 55.

**Dans le jeu (zip QUANTIX-R117, tampon `build R117 · Magnétisme et analyse`)**
- **Magnétisme de l'outil Déplacer** (`editor.js`, `moveTargets`/`magnet`) : pendant le glissement, le bout de la ligne déplacée le plus proche
  (< 13 u) d'un bout existant (autre trait, mur, courbe ; pas les pointes) vient s'y poser exactement ; c'est la ligne déplacée qui s'aligne ;
  anneau + vibration comme l'outil Droite. Testé (horizontale + verticale → angle droit exact) ; e2e‑editeur 25/25.
- **Niveaux 1 et 2 refaits** : 1 « Le premier trait » = géométrie dessinée par Simon (Q‑01‑01), le trait est un MUR à la sortie du crochet
  (87 % au doigt, ÉNIGME ✓, exception documentée : un mur de 15 u suffit — c'est la leçon) ; 2 « Le pont » (87 %, ÉNIGME ✓, A).
- **Réparations provisoires** : 102, 105, 115 ne se gagnent plus seuls ; 72, 114, 121 ont une solution ; solution de référence + noyau
  pour les six (restent D, à reconcevoir avec leur monde).
- Tests : mondes 1–5 OK, relecture 12/12, didacticiel OK, e2e‑editeur 25/25. Didacticiel inchangé depuis R116 d (demande de Simon : on finira plus tard).

**Outils** : `fiche.js` juge au DOIGT (P_exec ≥ 70 % via `difficulty.js`, `PEMIN=`), P_ligne = indicateur (`PLGATE=1` pour l'ancienne porte),
`SOFT=1` = garder avec réserves ; `diag.js N -|fiche '{P}' '[sol]'` = où et pourquoi les gestes échouent ; `repairs_check.js` ;
`solver.js ONLY=60,72` ; `etat.py` ; mesures `difficulty_R116.json`.

**Question posée à Simon (bloque le calibrage)** : le modèle du doigt suppose un trait à main levée d'un seul geste ; avec l'éditeur
(Droite + accroche, Déplacer/Pivoter + magnétisme, loupe) la précision réelle est meilleure. Recalibrer pour l'éditeur, ou garder
« jouable à main levée » ? Les niveaux 10, 12, 37, 47, 75 (notés A) échouent au doigt par précision (jonction trait/mur, hauteur exacte, 3 gestes).

**Prochaines tâches** : (1) réponse de Simon sur le calibrage ; (2) monde 1 : 5, 6 (machine « Les collines » `fiches/p1.js`, accès à changer :
le pont est déjà pris par 2), 7, 8 (machine‑énigme), 9, 11 (`fiches/11.js` : la jonction courbe/trait est fragile — prévoir une jonction tolérante),
puis la jouabilité de 10 et 12 ; (3) mondes 2, 3, 4 dans l'ordre.

## (historique) ⟶ ÉTAT AU R116 (9 octobre 2026, nuit) — LIRE CE BLOC D'ABORD

**Le jeu (zip QUANTIX-R116, tampon `build R116 · Didacticiel unifié`)** — seul changement : le didacticiel.
- **Défaut signalé par Simon** : le bandeau « Mission » du niveau 1 était dans le flux de la page ; sa hauteur suivait la longueur du message,
  donc le terrain changeait de taille à chaque message (mesuré à 390×664 : 328 → 381 px) et, sur petit écran, il ne restait presque rien ;
  les fiches d'élément « en bas » couvraient la barre du bas (Lâcher, outils) et ne défilaient pas.
- **Correctif (gabarit unique, `tuto.js` + bloc R116 en fin de `quantix.css` + `index.html`)** :
  bandeau à hauteur CONSTANTE `--tcH` (mesurée une fois sur le plus long des 4 messages, remesurée à la rotation), bouton Suivant dans l'en‑tête,
  place gardée pendant le lancer (classe `idle`, estompé) → terrain fixe (390×664 : 396 px à chaque message ; 375×553 : 309 px) ;
  fiches (outils, éléments, aide, explications) bornées au‑dessus de la barre du bas (`--tfh` posé sur la racine : la fiche est hors de `#game`),
  défilement au doigt si le contenu dépasse, figure retirée si la place manque (classe `tight`).
- **Bas de l'écran rogné sur iPhone dans la visionneuse (carte du monde, Lâcher)** : `#app` valait `100svh` = hauteur de l'ÉCRAN, alors que la
  visionneuse fait tourner le jeu dans un cadre plus petit. Corrigé : `#app` = hauteur visible du document (`--appH`, `fitApp()` en fin d'`engine.js`,
  plus petite valeur entre innerHeight, clientHeight et visualViewport, recalculée à chaque redimensionnement) ; `.panel` borné sur `--appH`.
  Non reproductible dans Chromium (vérifié seulement que rien ne casse) : **à confirmer sur iPhone**.
- **R116 b — didacticiel en SURIMPRESSION (choix de Simon : « le terrain ne doit jamais changer de format ni de place »)** :
  l'ouverture du niveau 1 est une fiche comme les autres (même gabarit, animation `basics`, repères particule/zone/noyau visibles sous le voile,
  « MISSION · BASES », Suivant / Passer) ; les consignes pendant le jeu (tracer, lâcher, corriger) sont une bulle de verre posée au‑dessus de la
  barre du bas, qui laisse passer le doigt, s'efface pendant le tracé (`ghost`) et disparaît pendant le lancer. Le bandeau dans le flux et sa
  hauteur fixe (`--tcH`, `fitCoach`) ne servent plus. Habillage des fiches et de la bulle refait dans la charte : verre sombre sur #05070D,
  nébuleuse teintée par la couleur de l'élément, poussière d'étoiles, filet néon, bouton à la couleur de l'élément. `e2e-didacticiel.py` adapté : 38/38.
- **R116 c — cadre en langue « lumière quantique »** : fiches et bulle encadrées par quatre rails de lumière (`VX.curve`) qui se rencontrent aux coins
  en jonctions en L (lentille + cœur‑atome, `VX.joints`, exporté ; option `lv.jA` = teinte imposée), teintés par l'élément ; bordure CSS retirée.
  Bulle posée du côté opposé au bassin (`side-l`/`side-r`). Violet hors charte remplacé par le jeton --boost. Paramètres : **Introduction → Rejouer**
  (l'aperçu se souvient qu'elle a été faite : c'est ce bouton qui la relance).
- **R116 d — SYSTÈME DIDACTICIEL (remplace a, b, c ; retour de Simon : « bricolage, manque de cohérence et de recherche »)** :
  règles opposables dans **`docs/DIDACTICIEL_DESIGN.md`** — parti pris « la fiche est un instrument de mesure » ; un composant, deux formats
  (fiche / consigne) ; l'interface parle en `--tu-ink` (= couleur du monde), la couleur de l'élément n'est que dans la figure, le mot‑clé et la
  pastille ; cadre = filets 1 px + jonctions des murs (`VX.joints` à l'échelle `--tu-node`) ; une animation par rôle au rythme du noyau (6 s) :
  apparition « mesure » (deux états superposés qui se réduisent), un photon qui fait le tour du cadre en 12 s, seule l'action principale respire ;
  tous les nombres dans les jetons `--tu-*` (bloc « SYSTÈME DIDACTICIEL » de `quantix.css`), lus par `drawFrame` (`tuto.js`).
  Consigne : titre ajouté (`ti_draw_h`, `ti_release_h`, `ti_adjust_h`, fr/en). Les blocs CSS R116 a–c sont supprimés.
- Tests : tutotest OK, e2e‑didacticiel 36/36, monde1 12/12, relecture 12/12 ; fiches vérifiées à 360×640 et 320×568 (aucune ne couvre la barre).
  **Pas testé sur iPhone.**

**Refonte des niveaux du monde 1 — EN COURS, rien d'installé dans `levels.js`**
- À refaire (FINITION) : 1, 2, 5, 6, 7, 8, 9, 11 (3, 4, 10, 12 sont en A).
- `tools/fiches/1.js` : **géométrie dessinée par Simon (Q‑01‑01)** — poutres + crochet en C qui renvoie la particule vers un tapis de pointes ;
  le trait = une tablette au‑dessus des pointes. Mesuré (variante pe 160, cx 188) : P_ligne 97 %, P_hasard 1,5 %, mais un trait de 13 u gagne parfois → réserve.
- `tools/fiches/2.js` « Le pont » : CONFORME (P_ligne 100 %, P_hasard 0,24 %, encre 228) — prolonger la rampe jusqu'au bassin, haut de l'écran interdit.
- `tools/fiche.js` : nouveau mode `SOFT=1` (garde la meilleure variante en listant ses réserves au lieu de tout rejeter).
- `tools/fiches/simon1.js` : conversion brute du niveau de Simon (lecture seule).
- Piste pour 6 : reprendre le prototype `fiches/p1.js` « Les collines » (forme Relais du monde 1).
- Ensuite : livrer les niveaux en préréglages de l'éditeur (collection `niveaux`, documents `Q-01-PP`) + aperçu jouable.

## (historique) ⟶ ÉTAT AU R115 (8 octobre 2026, soir) — LIRE CE BLOC D'ABORD

**Le jeu (zip QUANTIX-R115, tampon `build R115 · Quantone dans le jeu`)**
- 132 niveaux, 11 mondes ; finition mesurée inchangée (A 19 · C 33 · D 80, `docs/FINITION.md`).
- **Menu d'accueil** : Jouer · Constellation · **Quantone** · Paramètres. Zen Lab, Atelier de particule et Quantum Drop sont RETIRÉS du menu
  (à redéfinir) : boutons gardés cachés (`hidden`) pour ne rien casser dans `engine.js`.
- **Quantone intégré** : bouton d'accueil et Paramètres → plein écran par‑dessus le jeu (`#qtOv`, iframe `studio/quantone.html`), bouton Fermer ;
  la musique du jeu se tait pendant Quantone et revient à la fermeture (la lecture de Quantone est arrêtée). Langue = celle du jeu.
  Aperçu autonome : `build-apercu.py` embarque Quantone (`window.QT_SRC`). Code : fin de `engine.js` (bloc R115, `window.QTOV`).
- **Musique du monde 1 = W1N (R113)** : bruitisme organique depuis zéro (voir entrée R113 plus bas) ; mondes 2 à 11 inchangés.
- Tests R115 : monde1 12/12, monde2 11/11, relecture 12/12, aucune erreur console, menu et Quantone vérifiés en capture (Chromium).

**Quantone (studio/quantone.html)** — artefact « Quantone · six instruments » https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By (capacités db + downloads ; v4 = R114) :
six instruments éditables avec préréglages (Mélodie FM, Basse, Synthé, Acide 303, Rythmes, Effets), réglage par trait, outils Trait/Droite/Gomme/Déplacer/Dupliquer/Modeler,
10 fonctions musicales de la vidéo, effets (delay ping‑pong, flanger, filtre, réverbe), égaliseur, pad X‑Y, jauge de charge, « ● Live », export .wav en .zip, préréglages gardés.
La version du jeu (R115) ajoute seulement : langue reprise du jeu. L'artefact n'est pas republié pour R115 (inutile).
Préréglages de Simon : `docs/quantone-presets-simon/` (1 = fa♯ lydien, point de départ du monde 1 ; 2 = Glacier, quintes, inspiration possible pour le monde 4).

**Éditeur de niveaux v11** : artefact https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp ; niveaux de Simon dans `docs/niveaux-simon/` (non analysés).

**Prochaines tâches, dans l'ordre**
1. Retour de Simon sur la musique W1N du monde 1 (rendus `quantix-monde1-nivN-R113.wav`) et sur Quantone dans le jeu (iPhone).
2. Glacier (monde 4) : musique dans l'esprit W1N, s'inspirer du préréglage 2 (quintes ouvertes, acide grave réverbéré, lo‑fi minimal, glitch/impact).
3. Mondes 2, 3, 5 à 11 : même méthode (une expérience → des formules → des textures), avec parcimonie.
4. Redéfinir Zen Lab, Atelier de particule, Quantum Drop avant de les remettre au menu.
5. Analyser les niveaux de Simon (éditeur), reprendre la refonte des niveaux vers A.

## (historique) ÉTAT AU R106 (8 octobre 2026)

**Dans le jeu (zip QUANTIX-R106, tampon `build R106 · Atelier en fonctions`)**
- 132 niveaux, 11 mondes. Finition mesurée (docs/FINITION.md) : A 19 · C 33 · D 80 ; A = 3,4,10,12,14,15,20,25,37,39,40,44,47,48,51,73,74,75,76.
- **R107 — Musique du monde 1 refaite avec les fonctions de la VIDÉO de référence** (`fsaver_42704.mp4`, « Math functions that go even harder », 10 fonctions ;
  la version R106 « Galilée / nombre d'or » était hors sujet : Simon voulait les fonctions de la vidéo). `assets/js/sound.js`, objet `MFX` + style `atelier` :
  onde de pendules (6 pendules, Nₖ = 3…8 en 16 temps, notes du MOTIF au passage du milieu, réalignement toutes les 2 mesures),
  ressort amorti (basse 3‑3‑2, hauteur 1,3·e^(−2,4t)·cos(6πt) demi‑tons), Fibonacci mod 4 (arpège 6 contre 8), bégaiement (dernier temps ×2^k, e^(−13t')).
  Écoute : `quantix-monde1-musique-avant.wav` / `quantix-monde1-musique-R107.wav`.
  Mondes 2 à 11 inchangés. **Non écouté par Simon.**
- Vérifié : monde1.js 12/12, monde2.js 11/11, replaytest.js OK, aucune erreur console, tampon affiché dans la console.

**Hors jeu (outils de studio)**
- **Éditeur de niveaux v11** (`studio/editeur-niveaux.js` → `quantix-editeur.html`, artefact https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp, capacités db + downloads) :
  jauge d'énergie refaite comme celle du jeu (piste fine 5 px, échelle fixe 0 → encre max du jeu, consommation cyan→vert par‑dessus,
  encre max du niveau en ambre dessous, repère fin ; on règle le max en glissant n'importe où sur la jauge ; plus de curseur natif ni de cadre noir) ;
  les outils se **désélectionnent** (retoucher l'outil actif → ✥) ; **les traits d'essai s'éditent comme un joueur** : ✥ choisir/déplacer,
  poignées de bout (un trait main levée s'étire), poignée de rotation, ⌫ gomme, ⧉ dupliquer, changer la matière (bouton matière ou panneau),
  et nouvel essai **en ligne droite** (╱ vert dans la rangée d'essai). Testé dans Chromium ; **pas testé sur iPhone**.
- **Quantone R107** (`studio/quantone.html`, artefact https://claude.ai/artifact/CzoWYZZrtEv2nF9q8cjiq5) : panneau **Fonctions musicales** = les 10 fonctions de la vidéo
  comme processus sonores calés sur le tempo (bégaiement, Fibonacci mod 4, ressort amorti, onde de pendules, aspirateur, cycle des quintes, triton, triangle de Pascal,
  montée sans fin de Shepard, final), cumulables avec ou sans dessin, tracé animé façon vidéo, formules affichées, adoucies au timbre Quantix ;
  bouton **Recette du monde 1** (pendules · ressort · Fibonacci · bégaiement = la recette du jeu) ; **Égaliseur** (passe‑haut 80 Hz, grave/médium/aigu ±12 dB, sortie — d'après le Channel EQ envoyé) ;
  **Pad X‑Y** (deux réglages au choix pilotés d'un doigt — d'après le Fruity X‑Y controller). Préréglage enrichi du champ `eq`.
  Limite connue : dans la visionneuse d'artefacts, les boutons de téléchargement (.wav, préréglage) ne fonctionnent pas (capacité `downloads` non câblée) ; ils marchent en fichier local.
- Niveaux enregistrés par Simon dans l'éditeur (base de l'artefact, collection `niveaux`) : Q‑01‑01, Q‑01‑02, Q‑01‑12 → copiés dans `docs/niveaux-simon/`. **Pas encore analysés.**

**Quantone R108–R109 (8 oct.) — publié dans un NOUVEL artefact « Quantone · six instruments » https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By (capacités db + downloads ; l'ancien artefact CzoWYZZrtEv2nF9q8cjiq5 reste en R107). Source `studio/quantone.html`** :
- R108 : moteur propre (limiteur, réverbe lisse), nappe seulement avec un dessin, vrai delay ping‑pong synchronisé, vrai flanger, filtre passe‑bas/haut/bande résonant,
  réverbe réglable ; enregistrement clair : « ● Live » (MediaRecorder, .webm/.mp4), export .wav dans un .zip (la visionneuse refuse le .wav seul),
  préréglages gardés dans la base de l'artefact (collection `quantone`) + .json. À publier avec `capabilities: {db:{}, downloads:true}`.
- R109 : **six instruments**, chacun cliquable avec son éditeur et ses préréglages (défaut en pointillés) : Mélodie (FM : Verre, Marimba, Cloche, Kalimba, Flûte),
  Basse (Ronde, Sub 808, Pluck, Analogique, Contrebasse), Synthé (Nuage, Lead doux, Cordes, Supersaw, Orgue), Acide TB‑303 (Acid classique, Squelch, Caoutchouc, Carré, Doux ;
  accent = pente forte, glissé = notes sur pas voisins), Rythmes (808 doux, 909 club, Lo‑fi, Minimal, Percussions ; y = fût), Effets (Gouttes, Laser, Bulles, Souffle, Glitch, Impact, Pluie).
  Lecture du dessin : une note par pas traversé. Tous les préréglages rendus sans erreur (Chromium) ; pas écoutés par Simon.

**Quantone R110 (même artefact AjzgmbymcAJkwqkWtKH2By)** : surcharge sur iPhone corrigée par un bus par instrument (plus de panoramique ni de saturation par note),
polyphonie bornée (40 voix, plafond par instrument), notes tenues fusionnées, rattrapage du retard sans rafale ; jauge CHARGE (voix, retard, à‑coups) ; flou lumineux coupé sur écran tactile ;
relance garantie (moteur recréé s'il est figé) ; curseurs larges, touchables partout sur la piste ; ondes en icônes. Test Chromium : 12 traits à 110 bpm, charge 47–63 %, relance OK. Pas testé sur iPhone.

**R111 Quantone** : réglage PAR TRAIT (Déplacer → toucher un trait → « Tout l'instrument » / « Ce trait seulement » ; losange au départ du trait ;
le trait garde son préréglage et ses réglages, bus propre) ; outils DUPLIQUER (copie décalée déjà prise en main) et MODELER (10 poignées le long du tracé,
déformation douce, forme fermée conservée). Testé Chromium.
**R112 JEU — musique du monde 1 refaite avec les instruments de Quantone** (`sound.js`, objet `W1`, style `atelier`) : cycle de 16 mesures par niveau,
A Éveil (cloche FM Verre, gouttes, souffle) · B Mécanique (onde de pendules, basse ressort) · C Atelier (basse 3‑3‑2, Kalimba Fibonacci, rythmes Minimal
avec charleston = triangle de Pascal, Acide Doux à glissés, flanger sur la cloche, bulles) · D Respiration (nappe, cloche grave, gouttes, bégaiement avant retour).
Le monde se construit niveau après niveau (niveau 1 : cloche + nappe … niveau 12 : tout, basse en cycle des quintes). Rendus 2 min : niveaux 1, 7, 12
(`quantix-monde1-niveauN-R112.wav`). Tests monde1 12/12, relecture OK. Tampon `build R112`. Pas encore écouté par Simon.

**R113 JEU — monde 1 refait DEPUIS ZÉRO (demande : « bruitisme, organique, qui respire, formules → texture »)** : `sound.js`, objet `W1N`
(style `atelier` avec `noPad` ; W1 R112 reste dans le fichier mais n'est plus appelé). Point de départ : préréglage Quantone envoyé par Simon
(fa♯ lydien, grave +9,5 / médium −7,5, flanger profond, lo‑fi, gouttes, nappe sinus lente résonante, triton + ressort).
Couches : souffle B(t) (deux respirations, rapport φ), marée sin²(πu) sur 16 mesures, chœur d'air (bruit rose → 4 passe‑bande, Q 3→28 : les notes émergent du bruit),
crépitement Poisson × Pareto, grains par carte logistique (r 3,62→3,92), bois (modes Euler‑Bernoulli 1 : 2,756 : 5,404, rythme euclidien), frottement (banc résonant harmonique,
marche brownienne, rebond de ressort), gouttes, basse triton‑ressort, nappe sinus Fibonacci, vent de Shepard sur bruit, bégaiement. Tout dans un flanger lent.
Construction niveau par niveau (0 souffle → 11 tout). Bug évité : le résonateur en peigne à réinjection explosait (NaN) → remplacé par un banc de filtres stable.
Rendus 2 min niveaux 1, 5, 8, 12 (`quantix-monde1-nivN-R113.wav`) : respiration ~11 s et marée visibles dans l'enveloppe. Pas écouté par Simon.

**R114 Quantone (artefact AjzgmbymcAJkwqkWtKH2By v4)** : deux préréglages envoyés par Simon gardés dans `docs/quantone-presets-simon/`.
Le second a révélé deux défauts corrigés : (1) un trait dupliqué gardait l'identifiant de réglage de l'original (bus partagé) → identifiant retiré à la copie, dédoublonné au chargement ;
(2) SATURATION : son préréglage rendait à RMS 0,54 avec crêtes > 1 (basse en boucle fermée + Acide avec delay 0,97) → bus d'instrument à 0,6, envois réverbe/delay atténués, basse et acide moins forts,
sortie générale à 0,5, limiteur −8 dB puis écrêteur doux (jamais > 0,98), et polyphonie appliquée aussi au rendu .wav (le rendu ressemble au live). Même préréglage : RMS 0,21, crête 0,91.

**Pièces jointes de Simon (8 oct.) non traitées** : capture d'écran « Expérience réussie » avec l'emblème du haut entouré en rouge
(intention à confirmer : remplacer l'emblème ?), carte « Contact létal », image de carte des mondes (îles flottantes en orbite autour d'un noyau —
référence probable pour la carte des mondes), capture R62 « Le sérac », vidéos d'illusions bistables (`references/`), article sur les fentes de Young (attachment.txt).

**Prochaines tâches, dans l'ordre**
1. Retour de Simon sur l'éditeur v11 (iPhone) et sur la musique du monde 1 ; puis analyser ses niveaux `docs/niveaux-simon/` (débrief).
2. Clarifier l'emblème entouré sur la carte de résultat et l'image de carte des mondes.
3. Musique des mondes 2 à 11 avec les autres fonctions de la vidéo (pistes : quintes et Pascal pour la Chaîne, montée sans fin pour la Gravité, triton pour le Magnétisme, final pour le monde 11) — à valider avec Simon.
4. Refonte des niveaux vers A, monde par monde, par la méthode de l'éditeur (défi → dessin de Simon → analyse).
5. Câbler `window.claude.downloads` dans Quantone pour que les téléchargements marchent dans l'artefact.

**Outils perdus puis restaurés** : le conteneur a été réinitialisé ; `tools/pipeline.py`, `tools/livrer.py`, `tools/fiches/77.js` ont été reconstitués
depuis la conversation. `tools/monde6.js` à `monde11.js` n'existent pas dans le zip (jamais livrés) : à recréer sur le modèle de `monde2.js` si besoin.

## 0 septemsexagies. R105 — éditeur v8 : **palette par monde** (seuls les éléments du monde ; positions 10–12 = + deux mondes précédents ; Quantique = presque tout) ; objets des mondes 8–11 (aimant 🧲 [x,y,r,s], portail ◐ [x1,y1,x2,y2], porte ⊟, intrication ∞, superposition ⋔, détecteur ◎ [x,y,r], dilatation ⌛ (zone), corps mou) ; **✦ Essai** = traits du joueur (D.essais, matières du monde : ▬ ◉ » 〰) distincts de la **solution de référence** (D.ref, transparente, 👁 pour masquer, rejouée instantanément à chaque modification : trajectoire et ✔/✕) ; **jauge d'encre** (curseur = encre max du niveau, remplissage = encre des essais, rouge si dépassement ; le test refuse au‑delà). Fichier : + obj, soft, ink, essais, ref.

## 0 sexsexagies. R103 — enregistrement de l'éditeur : la visionneuse refuse le stockage local → **base de l'artefact** (capacités `db` + `downloads`, publiées). Chaque défi = document `niveaux/<Q-MM-PP>` {json, code, fichier, date} ; **Claude les lit avec l'outil Artifact, action `read_db`, url https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp, collection `niveaux`**. Bouton 💾 = fichier proposé au téléchargement (confirmation de la visionneuse).

## 0 quinquesexagies. R102 — éditeur v5 : ⧉ dupliquer ; aimantation des BOUTS lors du déplacement d'une forme entière (13 u : le bout se pose exactement sur le bout existant) ; l'outil ◠ ajuste aussi la courbe choisie ; trajectoire de la tentative précédente conservée (pointillés) ; parois mobiles ↕ (m = 6) et ↔ (m = 7) → `mov` {seg, amp 50, spd .022, ax/ay} — mondes 1 à 6 couverts.

## 0 quattuorsexagies. R101 — éditeur v4 : toile en haut, barre d'icônes dessous sans défilement (outils ✎ ╱ ◠ ▭ ⌫ ✥, ↶ ↷, ▶ test intégré ; matières ▬ ❄ » ◉ ▲ ✦ et zones ⊘ ⇡ ⇢ ⇠ ⇅ ◌ ⬇), puis DÉFI et FICHIERS en défilant. **Test intégré** : le moteur tourne derrière l'éditeur, particule et traînée dessinées sur la toile, verdict ✔/✕. Matière **✦ Solution du joueur** (m = 9) : traits utilisés comme tracé du joueur au test, exclus du décor — le fichier contient donc la solution voulue. Avec ✥, toucher une matière l'applique à l'objet choisi ; poignée d'angle pour la largeur de la zone ; Refaire.

## 0 tersexagies. R100 — éditeur v3 : menus OUTILS (main levée, ligne droite, courbe, zone, gomme, déplacer/tourner — poignée ronde au‑dessus du centre, pas de 5°) et MATIÈRE (structure, glace, accélérateur, rebond, pointes ; zone interdite, vents, gravités) ; point exactement sous le doigt (loupe) ; toile pleine largeur sans décalage pendant les gestes ; formes main levée = {pts:[…],m}.

## 0 duosexagies. R99 — ÉDITEUR v2 (utilisable sur iPhone) : `studio/editeur-niveaux.js` → `quantix-editeur.html`
- Édition sur une toile dédiée ; « ▶ Tester dans le jeu » charge le niveau dans le VRAI jeu, dans le monde du défi (bouton Lâcher du jeu), « ✎ Retour à l'éditeur ».
- Outils : Choisir/déplacer (déplacement RELATIF, poignées carrées = bouts, ronde = courbure, coin = taille d'un champ), Mur, Courbe (Bézier quadratique), Champ (zone interdite, vent ↑ → ←, gravité inversée/faible/lourde). Matières : Structure, Glace, Rebond, Tapis, Pointes. Aimantation bouts/grille 5 u/axe/lignes d'or, loupe, coordonnées.
- **132 cartes de défi** générées (monde, position, temps, forme — machines en 3, 6, 8, 10, 12 —, type R‑xx, hypothèse, vérité du monde, éléments).
- **Fichiers** : `Q-MM-PP_<monde>-niv###.json` (ex. `Q-07-05_gravite-niv077.json`) : {fichier, defi, ball, cup:[x,y,largeur], w:[[x1,y1,x2,y2,mat]], curves:[{a,b,ctl,m}], fields:[[x,y,w,h,type]], note}. Sauvegarde locale automatique par défi (clé `QED:Q-MM-PP`).
- Conversion vers le jeu : courbes → Bézier quadratique 9 points ; champs : nd ; w_up [0,−.6] ; w_r [.3,0] ; w_l [−.3,0] ; g_inv gy −.45 ; g_low .12 ; g_hi .9.

## 0 unsexagies. R98 — ÉDITEUR DE NIVEAUX (nouvelle méthode de travail avec Simon)
- `studio/editeur-niveaux.js`, injecté dans l'aperçu → `quantix-editeur.html` (vrai moteur). Outils : Mur, Courbe (Bézier : départ, arrivée, puis poignée), Déplacer (bouts et poignées), Gomme, Particule, Zone ; matières Structure/Glace/Rebond/Tapis/Pointes ; aimantation (bouts, grille 10 u, axe et lignes d'or), loupe ×3, point visé 28 u au‑dessus du doigt, longueur affichée, Annuler, Jouer/Éditer, Exporter/Importer un code `QNIV:{…}` + note.
- Méthode : Claude donne une carte de défi (position, type, hypothèse, contraintes) → Simon dessine sur iPhone et colle le code → Claude analyse (fiche.js/enigme.js/finition.js sur la géométrie importée : courbes = {a,b,ctl,m}, à échantillonner en Bézier quadratique 9 points) → débrief → intégration.

## 0 sexagies. R97 — ÉCONOMIE DE CALCUL (demande de Simon : quota hebdomadaire presque épuisé)
- **Règles** : (1) un niveau = `python3 tools/pipeline.py N plan.json [PMIN= MINL=]` (fiche → installation → énigme → finition → monde, résumé en 5 lignes) ;
  (2) une livraison = `python3 tools/livrer.py RXX "libellé" MONDE` (tampon, tests essentiels, rapport, banc, zip) ;
  (3) plus de captures d'écran ni de suites lourdes (Chromium) à chaque niveau — seulement à la livraison d'un monde ;
  (4) sorties toujours filtrées (`grep`, `cut`), jamais de trajectoires complètes ; (5) messages courts.
- 77 « Le saut lunaire » (saut en gravité faible) : **abandonné** — un saut est trop sensible (tremplins de 11 à 29 u qui suffisent, ou fragile). Leçon déjà connue (51) : éviter les idées de saut sans normaliseur. Autre idée à trouver pour 77.

## 0 novemquinquagies. R96 — **76 « Le champ de travers »** (A) : la particule part trop bas, rien à construire sous elle ; un champ oblique (gravité vers le haut et la gauche) la porte au‑dessus du vide jusqu'à la zone. Le mur prévu s'est révélé inutile (retiré). 19 niveaux en A.

## 0 octoquinquagies. R94–R95 — monde 7 Gravité, au complet en fiches ; 18 niveaux en A
- **Plan des 12 niveaux du monde 7 : `docs/MONDE7_FICHES.md`** (formes, types, hypothèses, cinq machines aux positions 3, 6, 8, 10, 12).
- **73 « Tomber vers le haut »** (A) : la particule part plus bas que la zone ; colonne inversée + voûte qui devient pente.
- **75 « Le manège inversé »** (A, forme Relais, montagnes russes) : rampe vers l'entonnoir ; descente, fond, remontée, voûte où la particule roule À L'ENVERS sous gravité inversée, chute dans la zone. Constance 91 % (objectif 98 %).
- `enigme.js` : la fiche peut nommer les éléments de l'idée (`U`) et des passages obligés (`pass`, ex. gorge d'entonnoir) — registre `tools/fiches/registre.json`.
- Suite : 76 à 84 selon le plan (machines 78, 80, 82, 84).

## 0 septenquinquagies. R93 — **16 niveaux en A** (+12 « L’établi », +48 « Le sérac »). Éléments inutiles retirés : 12, 24, 38, 48, 49. Niveau 24 : zone interdite au‑dessus de la plaque, énergie 286, plaque de rebond retirée des matières offertes (énigme ✓ mais un trait de 30 u suffit encore → C). Niveau 75 : vrai raccourci (ligne de 210 u qui évite la gravité) — non corrigé. `enigme.js` : tirage reproductible par niveau, `NS=` pour le nombre de traits. Sauvegarde `/tmp/levels_avant_R93.js`.

## 0 sexquinquagies. R92 — **14 niveaux en A** (3, 4, 10, 14, 15, 20, 25, 37, 39, 40, 44, 47, 51, 74). Glacier : pointes/poteaux redondants retirés (39, 40, 44, 45, 47 ; conseils fr/en adaptés). Registre des fiches `tools/fiches/registre.json`, résultats d'énigme `tools/enigme_status.json`, compte rendu régénérable : `python3 tools/rapport-finition.py` → `docs/FINITION.md` (avec le plan). Sauvegardes : `/tmp/levels_avant_R92.js`.

## 0 quinquinquagies. R91 — **compte rendu de finition des 132 niveaux : `docs/FINITION_R91.md`** (outil `tools/finition.js`, données `tools/finition.json`) : A 3 · B 10 · C 37 · D 82. Niveau 11 « La moitié » toujours non conforme (fiche `tools/fiches/11.js`).

## 0 quattuorquinquagies. R90 — animations de choc graduées (poussière lumineuse, arcs, onde, éclat) ; refonte du 11 « La moitié » en cours (non conforme : raccourcis). Cahier §25.

## 0 terquinquagies. R89 — détails animés ; plaques et tapis droits dans la langue lumineuse ; **Q‑01‑10 « Le plafond »** refondu et intégré (ÉNIGME ✓). Cahier §24.

## 0 duoquinquagies. R88 — langue « lumière quantique » (murs, jonctions, bassin, pylônes) ; zone de réussite dégagée (`tools/zonepropre.js`, masque du décor) ; 4 niveaux encore à corriger (10, 11, 21, 34). Cahier §23.

## 0 unquinquagies. R87 — jonction adaptative universelle (L, T, X, Y, étoile ; courbes et glace comprises), cahier §22. Planche des jonctions au banc d'essai. Visible dans tout le jeu.

## 0 quinquagies. R86 — connecteurs (embout, platine, manchon, gousset, collier) et poutres droites au dessin des courbes (cahier §21). Visible dans tout le jeu.

## 0 undequinquagies. R85 — finition des pièces courbes (`VX.curve`, cahier §20). Banc d'essai reconstruit.

## 0 duodequinquagies. R84 — trois histoires distinctes, courbes redessinées
- Fiches `tools/fiches/p1.js` (Les collines), `p3.js` (L'ascenseur), `p4.js` (Le grand tremplin) ; `VX.curve` redessiné ; panneau du banc `tools/banc-panel.html`. Voir `CAHIER_DES_CHARGES_GENERATION.md` §19.

## 0 septenquadragies. R83 — composition d'or, trois machines de monde
- Gabarit `tools/fiches/lacets.js`, prototypes `p1` (Atelier), `p3` (Chaîne), `p4` (Glacier), mesure `tools/constance.js` (99 % chacun). Banc d'essai avec les trois. Voir `CAHIER_DES_CHARGES_GENERATION.md` §18. `fview.py` accepte `fiche@niveau`.

## 0 sexquadragies. R82 — éléments courbes + composition
- `lv.curves` (physique en segments jointifs, rendu continu `VX.curve`) ; règles des virages et de composition : `CAHIER_DES_CHARGES_GENERATION.md` §17. Prototype v3 au banc d'essai (98 % d'arrivées). Outils : 1 200 images comme le jeu.

## 0 quinquadragies. R81 — machine physique (sans rail)
- Voir `CAHIER_DES_CHARGES_GENERATION.md` §16. Zone de machine `mz` (non traçable, invisible). Prototype « La grande descente » au banc d'essai (`tools/build-banc.py`).

## 0 quaterquadragies. R80 — rail guidé (machines) dans le moteur
- Voir `CAHIER_DES_CHARGES_GENERATION.md` §15. Banc d'essai `quantix-banc-essai.html` : prototype « Le relais » injecté à l'exécution (pas dans le jeu).

## 0 terquadragies. R79 — CAHIER DES CHARGES DE LA GÉNÉRATION (v3) + machines
- **Document opposable : `docs/CAHIER_DES_CHARGES_GENERATION.md`** (remplace `CAHIER_DES_CHARGES_NIVEAUX.md`). Nouveauté demandée par Simon : **buts intermédiaires et machines** — un niveau = des actes (zone jouable, relais, machine, arrivée) ; formes Simple / Relais / Deux actes / Finale / Machine‑énigme ; machine déterministe sur **rail guidé** (à implémenter : `rails`, `relais`, lanceur, zone interdite automatique), chorégraphie, identité par monde ; gabarit de monde mis à jour (machines aux positions 3, 6, 8, 10, 12) ; portes P1–P10 ; pipeline avec validation des fiches par Simon.
- Bible complétée (partie XI, sources S‑42 à S‑45). **Jeu inchangé.** Suite : implémenter le rail guidé et prototyper un niveau Relais (monde 1) et une Finale (monde 3) au banc d'essai.

## 0 duoquadragies. R78 — LA BIBLE DU DESIGN D'ÉNIGMES (v2)
- **Lire `docs/BIBLE_ENIGMES.md`** (remplace `REFERENCE_DESIGN_ENIGMES.md`) : 41 sources (concepteurs, psychologie de l'insight, recherche sur la génération contrainte), anatomie d'une énigme (GMTK, Tyroller, Taylor), 22 stratégies de création de Traynor traduites pour Quantix, cas des jeux de physique (brute force, déterminisme, émergence), gabarit de monde en kishōtenketsu, 16 hypothèses du joueur, fiche v2, portes P1–P8. **Jeu inchangé.**
- Reste (§IX.6) : conférences primaires à résumer, dix niveaux de référence à décortiquer, validation des hypothèses par Simon, matrice des paires de mécaniques.

## 0 unquadragies. R77 — RÉFÉRENCE DU DESIGN D'ÉNIGMES (v1)
- **Lire `docs/REFERENCE_DESIGN_ENIGMES.md`** avant toute conception : sources professionnelles (Blow, ten Bosch, Hazelden, Teikari, Valve/Swift, Nintendo/Hayashida, ZeptoLab, Purho, Zachtronics), psychologie de l'insight (impasse, relâchement de contrainte), corpus de jeux, **inventaire des hypothèses du joueur (H1–H14)**, monde = kishōtenketsu en 12 temps, protocole en 10 étapes. Retour de Simon : niveaux corrects mais sans surprise.
- Document **à enrichir** sur plusieurs séries (§9 du document). **Jeu inchangé.**

## 0 quadragies. R76 — premier niveau selon le cahier des charges + banc d'essai
- **Q‑03‑01‑R01 « Le tapis »** (25) construit selon le cahier : zone à portée des ~40 u d'élan mesurés du tapis et au‑dessus du départ ; ÉNIGME ✓ (idée = pente + tapis + poteau, 0 raccourci, 0 élément inutile), P_ligne 100 %, encre 102.
- **Banc d'essai** : `quantix-banc-essai.html` = aperçu tous mondes ouverts + panneau « BANC D'ESSAI » (11 niveaux ayant passé le contrôle énigme : 2, 3, 4, 5, 7, 11, 14, 15, 25, 37, 51). Construit en post‑traitant `build-apercu.py 1 11 skipintro` (script dans la session R76). Panneau en français seulement : outil de test, pas dans le jeu.

## 0 undequadragies. R75 — CAHIER DES CHARGES DES NIVEAUX (document de référence)
- **Lire d'abord `docs/CAHIER_DES_CHARGES_NIVEAUX.md`** : il remplace toutes les règles de conception antérieures. Énigme unique et référencée (`Q‑MM‑PP‑Rxx`), rôles obligatoires des éléments (PORTER / FERMER / PIÉGER), référentiel de 20 types de raisonnement (un par niveau dans un monde), fiche obligatoire avant géométrie, étalonnage mesuré des mécaniques (`tools/banc.js`), portes de validation G0 à G5 (G5 = test de Simon), registre des 132 niveaux.
- Audit énigme : monde 1 6/12 ✓ (2, 3, 4, 5, 7, 11), monde 2 2/6 audités ✓ (14, 15), monde 3 0/12, Glacier 1 (37), Soufflerie 1 (51).
- **Jeu inchangé.** Suite : soumettre à Simon les 12 fiches de la Chaîne (G0) avant de construire.

## 0 duodequadragies. R74 — protocole « énigme »
- **Lire `docs/ENIGME_PROTOCOL.md`** : contrôle `tools/enigme.js` (idée = éléments utilisés, raccourcis cherchés exprès, rôle de chaque élément), audit des niveaux refaits (2 vraies énigmes sur 22 : 37 et 51), 12 types de raisonnement pour la Chaîne. **Jeu inchangé.**
- Suite : reconstruire la Chaîne niveau par niveau, un type de raisonnement par niveau, ÉNIGME ✓ obligatoire.

## 0 septentricies. R73 — tri de tous les niveaux restants
- **Lire `docs/TRIAGE_R73.md`** : `tools/triage.js` (tri automatique). 76 niveaux non refaits : 3 bons (51, 74, 75 — installés), 73 à reconcevoir. Stratégie proposée : bibliothèque de gabarits scénarisés déclinés par mécanique.
- Outils : `w3apply.py` sait écrire une solution dans un ancien niveau qui n'en avait pas ; `design.js` installe tous les champs quantiques ; tests `monde6.js` à `monde11.js` créés.

## 0 sextricies. R72 (outils et documentation) — 51 non abouti
- Voir `SCENARIO_PROTOCOL.md` (51, `leurreBoxes`). **Jeu inchangé depuis R71.**

## 0 quinquatricies. R71 — Soufflerie : 50 « Vent de face »
- Champ‑obstacle dans `fiche.js`. Soufflerie : 2/12 (49, 50). `fview.py` affiche désormais le vrai vent.

## 0 quattuortricies. R70 — Soufflerie : 49 « Le souffle » par fiche
- Test « échoue sans le vent » intégré à `fiche.js`. `tools/monde5.js` : 1/1 sur les niveaux refaits. Voir `SCENARIO_PROTOCOL.md` §9.

## 0 tertricies. R69 — extension à la Soufflerie (mesures et fiches), 41 non abouti
- Mesure : dans la Soufflerie actuelle, le vent ne sert pas (51, 53, 57, 60 se résolvent aussi sans vent) ; 50, 54, 58 se gagnent avec 14 à 35 u. Fiches des 12 niveaux écrites (`SCENARIO_PROTOCOL.md` §7). Outils étendus aux champs (vent, gravité, aimant, portails, parois mobiles) : `design.js` (installation), `slotwrite.py` (écriture). `tools/monde5.js` créé.
- 41 « Le virage » : un bouclier seul reste trivial ; idée à changer (§8). `fiche.js` accepte `MINL=` (seuil de coût minimal).
- **Jeu inchangé depuis R68.**

## 0 duotricies. R68 — 40 « Le demi‑tour » et 45 « Le passage gardé » par fiche
- `monde4.js` 10/10. Glacier : 8 niveaux sur 12 faits par fiche (37, 38, 39, 40, 44, 45, 47, 48) ; restent 41, 42, 43, 46.

## 0 untricies. R68 (documentation seulement) — 46 « Le pendule » non abouti
- Voir la leçon dans `SCENARIO_PROTOCOL.md` : l'histoire est incompatible avec la physique (énergie perdue à chaque jointure). Fiche à changer.

## 0 tricies. R67 — 38 « Trop vite » par fiche (nouvelle histoire)
- Tremplin de glace → vol trop long vers les pointes ; zone interdite sur le haut du vol ; rattraper plus bas. P_ligne 80 % (exception documentée). `fiche.js` accepte `PMIN=`.

## 0 undetricies. R66 — 39 « Le saut » par fiche ; 38 en échec documenté
- 39 : tremplin obligatoire (le pont coûte plus que l'énergie). `monde4.js` OK. 38 : voir `SCENARIO_PROTOCOL.md` (leçons R66).

## 0 duodetricies. R65 — 47 « La crevasse double » par fiche
- Deux lacs, deux crevasses à pointes au fond, deux ponts nécessaires. `monde4.js` 9/9. Voir `SCENARIO_PROTOCOL.md` §6.

## 0 septemvicies. R64 — construction par fiche
- Nouvel outil `tools/fiche.js` + fiches `tools/fiches/N.js` (voir `SCENARIO_PROTOCOL.md` §5–6).
- 44 « La patinoire » refait par fiche : lacets de glace, un îlot de pointes au bout de chaque descente, deux boucliers à poser. `monde4.js` 8/8.

## 0 sexvicies. R63 — « Le sérac » (48) jugé impossible par Simon
- Mesure de l'ancien 48 : solutions existantes mais introuvables (0,34 % au hasard ; la seule voie était un trait vertical collé aux pointes, sans rapport avec l'histoire ; la glace plate laissait la balle immobile ; la matière rebond du joueur donnait des solutions de 13 u sans rapport avec le niveau).
- Refait d'après la fiche : la glace descend vers les pointes ; il faut **construire la rampe** qui remonte jusqu'à la zone. Plaque de rebond et matière rebond retirées (elles n'avaient pas de rôle). Plus petit trait gagnant 75 u, encre 150, P_hasard 0,10 %, P_ligne 97 %, `monde4.js` 7/7.
- Anciens niveaux du Glacier encore en place, mesurés : 40 (0,96 %), 41 (2,1 %), 44 (**0,06 % — presque impossible**), 46 (2,3 %), 47 (2,7 %). À refaire par fiche, 44 en priorité.

## 0 quinvicies. R62 — loupe dégagée, sons de réussite et de chocs pétillants
- Loupe : plus de poignées (croix de déplacement, rotation), plus de repères d'accroche ; réticule ouvert (centre libre).
- Son (`sound.js`) : nouvelle fonction `sparkle` (grains de 3 ms très bas, dispersés, panoramiques, envoyés dans la « seconde vie ») ; réussite = accord lent de 3 notes rondes + 22 grains (crête de la séquence zone + réussite 0,26 → 0,14) ; zone (trou noir) à moitié volume ; chocs 2,5 fois plus bas avec une pincée de grains.

## 0 quatervicies. R61 — scénariser les niveaux (retour Simon : « trop simples, 10 % de la matière, défi non identifié »)
- **Lire `docs/SCENARIO_PROTOCOL.md`** : diagnostic mesuré (16 niveaux des mondes 1–3 et les niveaux 37–38 se gagnent avec un trait de 10 à 25 u), méthode « fiche scénario d'abord » (histoire, obstacle, geste, leurre, chute, énergie), critère du **coût minimal** (intégré à `forge.js`), énergie serrée (`tighten.js`), fiches des 12 niveaux du Glacier.
- **Preuve de méthode** : 37 « Le lac » construit à la main d'après sa fiche — pente de glace, lac coupé par un trou, plafond de pointes qui interdit le saut ; il faut **un pont** (plus petit trait gagnant : 119 u ; encre 160 ; la butée‑leurre échoue ; P_hasard 0,13 % ; P_ligne 97 %).
- **Suite** : fiches 38 à 48, puis les 16 niveaux triviaux des mondes 1–3.

## 0 tervicies. R60 — sons de la carte et de l'interface adoucis (retour Simon : « très dérangeants »)
- Causes : la carte jouait le son du noyau (cloches FM au rapport 3,5, éclat métallique) et la validation ; le toucher était un grain de bruit filtré à 1,5 kHz.
- Correctif (`sound.js`) : nouvelle voix `soft` (sinus + octave discrète, attaque 12 à 80 ms, filtrée sous 1,1 kHz) pour `ui_tap`, `ui_confirm`, et deux sons dédiés à la carte `map_done` / `map_next` (`engine.js`) ; le noyau passe au rapport 2 (harmonique).

## 0 duovicies. R59 — Glacier (monde 4), six niveaux forgés
- Voir l'annexe R59 de `DIFFICULTY_PROTOCOL.md`. Restent anciens : 40, 41, 44, 46, 47, 48 (gabarits de glace à varier d'abord).
- Test : `node tools/monde4.js` (6/6 sur les niveaux refondus).

## 0 unvicies. R58 — correction : c'était le NOYAU (joyau) qu'il fallait changer
- La particule redevient la sphère d'origine (cyan‑blanc, cerclée de blanc).
- Le **noyau** devient la surface d'Enneper de la vidéo (`core` dans `visuals.js`, nuage `ennBuild`) : 900 points, un tour en 6 s, **taille ≈ 2 × la particule**, **couleurs de la charte** (or → ambre → rose → blanc chaud) au lieu de l'arc‑en‑ciel, halo doré qui respire. Retour de Simon : « échelle trop petite, couleurs qui détonnent ».

## 0 vicies. R57 — la particule d'après la vidéo de Simon (fsaver_04673)
- Analyse image par image (15 i/s sur 12 s) : la forme est une **surface d'Enneper** (carré aux côtés creusés, quatre lobes qui se replient), nuage de points très fin sans contour, projection orthogonale (rotation bistable), **un tour en 6,0 s** (corrélation 0,993 à 6 s), mouvement régulier ; couleur : teinte arc‑en‑ciel liée à l'angle autour de la surface, saturation ≈ 0,55–0,65, points peu lumineux qui s'additionnent.
- Reproduction : `ball()` dans `visuals.js` — 900 points tirés uniformément sur la surface (centre clairsemé comme la vidéo), 24 teintes, rotation au temps réel, collision inchangée (cercle R). Coût mesuré : 1,6 ms par dessin (navigateur de test sans GPU).
- Distinction avec le noyau (doré, grappe de nucléons, orbites) : couleur, forme et mouvement n'ont plus rien en commun.

## 0 novodecies. R56 — forge de niveaux, noyau doré
- **Forge** (`tools/forge.js`, `tools/slotwrite.py`) : voir l'annexe R56 de `DIFFICULTY_PROTOCOL.md`. 10 niveaux des mondes 1–3 redessinés. Bilan 33 / 36.
- **Noyau redessiné** (`core` dans `visuals.js`) : grappe dorée de nucléons, deux orbites, éclat qui s'efface aux pointes — plus rien de commun avec la particule (sphère lisse cyan‑blanc). Retour de Simon : on les confondait.
- **Monde 4** : générateur « glace » prêt ; candidat trouvé pour le niveau 38 (`tools/forge.json`, clé 38_269), pas encore installé.

## 0 octodecies. R55 — refonte des niveaux (suite)
- Niveaux 2, 3, 5, 6, 7, 8, 13 resserrés par `hardtune.js` (vérification à 3 000 lignes, levier « zone interdite » avec `ND=1`). Bilan : **24 / 36 conformes** (annexe R55 de `DIFFICULTY_PROTOCOL.md`).
- Restent à redessiner : #6, #7, #9, #10, #11, #20, #21, #22, #23, #34, #35, #36.
- Sauvegarde de `levels.js` avant R55 : non conservée dans le site (à reprendre du zip R54 si besoin).

## 0 septendecies. R54 — bible sonore réalisée
- Voir `docs/AUDIT_R52.md` §6. Test : `python3 tools/e2e-son.py` (7/7 : couverture, boucles vent/aimant/gravité/dilatation, silence hors partie, crête < 0,5 dans les 11 mondes).
- **Écoute non faite** : c'est à Simon de juger, monde par monde.

## 0 sedecies. R53 — éditeur de lignes dans Quantone
- `studio/quantone.html` : dock Trait / Droite / Gomme / Déplacer (même dessin que le jeu), ligne droite à glisser ou à deux touchers avec accroche aux extrémités et aux angles de 45°, gomme (toucher ou glisser), déplacer + poignée de rotation + rotation à deux doigts (accroche 15°), le tracé est décalé pour rester dans le champ au lieu de bloquer le geste ; **Annuler** défait ajout, effacement, déplacement et « Effacer ».
- Une ligne droite reçoit des points espacés régulièrement : la partition la lit comme un geste régulier.
- Tests : `python3 tools/e2e-quantone-editeur.py` (9/9) et `e2e-quantone.py` (12/12).

## 0 quindecies. R52 — audit et correctifs
- **Lire `docs/AUDIT_R52.md`** : audit du son (technique, couverture, perception, esthétique, identité par monde) avec la **bible des sons** (un son par événement, par obstacle, par bonus, matière par monde) et les objectifs mesurables ; audit du menu après niveau ; audit de Quantum Drop, Zen Lab, Atelier de particule.
- Correctifs : craquements (ducking sans saut de gain, réverbération 2,4 s, ferrofluide allégé) ; loupe sans étiquettes (`window.__LOUPE`) ; emblème animé du résultat (`resEmb` dans `engine.js`) ; ferrofluide v2 (`ferro2` dans `visuals.js`, ~22 ms par scène sans GPU).
- **Suite** : réaliser la bible sonore (§1.6), puis menu après niveau, puis les modes.

## 0 quattuordecies. R51 — méthode de difficulté refaite pour l'éditeur
- Lire **`docs/DIFFICULTY_PROTOCOL.md`, annexe R51** : nouveau critère P_hasard (lignes droites aléatoires gagnantes), cibles par position, P_ligne ≥ 85 %, fins de monde à deux traits.
- Outils : `tools/hasard.js` (mesure), `tools/hardtune.js` (resserrage), `w3apply.py` lit maintenant `SRC=…`.
- Appliqué : 28, 30, 33 resserrés (monde 3 toujours 12/12). Mesures des mondes 1 à 3 dans l'annexe : la majorité des niveaux du monde 1 et plusieurs du monde 2 dépassent la cible.
- **Suite** : redessiner 34, 35, 36 à deux traits ; puis resserrer/redessiner les niveaux hors cible des mondes 1 et 2.

## 0 terdecies. R50
- **L'outil s'appelle Quantone** (Quantix + tone), `studio/quantone.html` ; les anciens préréglages « Résonateur » restent lisibles.
- **iPhone en mode silencieux** (Quantone) : boucle silencieuse générée en mémoire (élément audio actif) + `navigator.audioSession.type='playback'`. Ajouté aussi au jeu (`sound.js`). **Non vérifiable ici : à tester sur ton iPhone.**
- **Arrêter coupe vraiment** (Quantone) : la sortie est fermée en 0,12 s, puis une chaîne audio neuve est construite. Test : niveau de sortie 0,00000 après l'arrêt (`e2e-quantone.py`, 12/12).
- **Zone = aspiration par un trou noir** (`blackHole` dans `sound.js`) : souffle qui monte en se refermant, grave qui plonge de 190 à 34 Hz, coupure nette, puis une cloche lointaine.
- **Effets distincts de la musique** : réverbération des effets divisée par 2,2 (ils restent proches et secs) ; la musique s'efface de 5 dB pendant ~0,35 s à chaque effet. Crête mesurée en jeu rejoué : 0,46.
- **Texture du monde 8** : trous de transparence qui dérivent lentement, texture effacée autour des murs, du départ, du bassin et du noyau, 80 grains de poussière à transparence aléatoire ; opacité 0,75 → 0,6. 15 ms par scène.

## 0 duodecies. R49 — effets sonores, aimant, ferrofluide
- **Effets sonores refaits** (`sound.js`, bloc « bruitages (R49) ») dans l'esprit d'Aphex Twin (ambient, Drukqs) : piano préparé feutré (`prep`), cloches FM dont l'éclat s'éteint (`fmBell`), grappes de grains (`grains`), ralenti de bande à l'échec (`tapeStop`), « wow » de bande commun. Impacts : la note tourne dans l'échelle du monde (jamais deux fois la même), la vitesse change la brillance plus que le volume.
- **Anti‑saturation** : budget de 12 voix compté en temps audio, effets plus bas (bus × 0,8), sortie à 0,85, **limiteur** en fin de chaîne (−6 dB, 20:1). Mesure sur les vrais événements de 4 niveaux + un pic de réussite empilé : crête 0,26 (1,0 = saturation), le pic n'ajoute que 4 dB.
- **Aimant** : force × 1,7 et profil 1 − (d/r)² (`magF`, `MAGK` dans `engine.js`) ; nouveau rendu (halo, 16 lignes de champ parcourues de grains qui convergent, ondes qui se resserrent). Solveur : monde 8 toujours 12/12 résoluble. **Non mesuré** : si certains niveaux du monde 8 deviennent trop faciles (monde non refondu).
- **Ferrofluide** : contour vectoriel (carrés de marche) en trois couleurs selon la distance à l'aimant, recalculé une image sur six. 18 ms par scène complète sans GPU.
- Garde ajoutée dans `criteria()` (tests Node) : `solver.js` plantait sur l'écran de résultat de R46.

## 0 undecies. R48 — le Résonateur
- `studio/quantone.html` : instrument autonome (voir `CAHIER_DES_CHARGES_R39.md` §9). Entrée « Résonateur » dans les paramètres du jeu (lien relatif, nouvel onglet). **Pas encore verrouillé** derrière un achat ; la musique du jeu ne lit pas encore ses préréglages.

## 0 decies. R47
- **Anneau de cellules** (vidéo « quatrième dimension ») dans la Chaîne : `torusCells(c,cx,cy,Rgrand,Rpetit,opacité)`.
- **Ferrofluide** (vidéo) dans Magnétisme : `ferro(c)`, grille 96 × 128, 2 itérations par image, 14 ms par scène complète mesurées sans GPU. Monde 8 sans hélices ADN (comme 4).
- **Son par niveau** : `lvVar()` dans `sound.js` (niveau lu dans `S.li` au `setWorld`).
- Reste : outil de création sonore avec interface (cahier §8 N), ferrofluide à affiner, réglage du monde 3 (26, 27, 30 à 36), monde 4.

## 0 nonies. R46 — zip allégé, écran de résultat, constellation, éditeur
- **Zip** : 44 Mo → ~11 Mo (dossier) : deux WAV de démonstration retirés de `docs/`. Ne jamais remettre d'audio ou de vidéo dans le site.
- **Résultat** : indicateurs branchés (`criteria()` dans `engine.js`), nouveau design noyau + orbitales.
- **Constellation** : nouvelle affiche, positions `CPOS` relevées sur l'image.
- **Éditeur** : l'outil choisi reste actif (test `e2e-editeur.py` adapté).
- Reste : voir `CAHIER_DES_CHARGES_R39.md` §8 (outil sonore avec interface, préréglages par niveau, deux vidéos à étudier).

## 0 octies. R45 — son plus grave et plus doux (retour Simon : « le son qu'on entend le plus est trop aigu, strident, fait mal à la tête »)
- Constat : sur un haut-parleur de téléphone, les graves disparaissent ; il ne restait que les cloches du thème (600 à 1 100 Hz, sinus purs) → perçues comme stridentes. Mesure avec un filtre « téléphone » (`/tmp/phone.py`, rien sous 300 Hz).
- Correctif : plafond de hauteur abaissé à do 5 (523 Hz ; Glacier ré dièse 5, 622 Hz) ; thème et bruitages une octave plus bas ; partiel métallique supprimé, remplacé par une voix jumelle désaccordée (chaleur) ; filtres plus bas ; en sortie −9 dB au-dessus de 1,5 kHz et coupure à 3,5 kHz ; nappe du Glacier une octave plus bas ; volume de la musique −30 %.
- Mesuré, simulation téléphone : fréquence dominante 657 → 495 Hz, note nette la plus haute 1 109 → 554 Hz. **Écoute sur téléphone réel : à faire par Simon.**

## 0 septies. R44 — musique aérée (retour Simon : « trop saturé, surtout Glacier »)
- Diagnostic mesuré : aucun écrêtage, mais un mur continu (1 à 2 % du temps « respirant »). Nappe qui ne s'arrêtait jamais, queues d'écho et de réverbération qui s'empilaient.
- Correctif : la nappe s'éteint avant l'accord suivant (`fill` par monde), réverbération plus courte et plus basse (3,0 s, retour 0,36), écho plus bas (0,34) et moins réinjecté ; Glacier : nappe divisée par 2, écho 0,5 → 0,22, cloches plus courtes et moins nombreuses.
- Mesuré : temps « respirant » Atelier 30 %, Fonderie 31 %, Chaîne 29 %, Glacier 46 % (avant : 1 à 2 %).

## 0 sexies. R43 — aigus plafonnés (retour Simon : tintements trop aigus)
- `cap()` dans `sound.js` : toute note au-dessus du plafond (≈ 990 Hz, si 5 ; Glacier 1 180 Hz) est repliée d'une octave, autant qu'il faut — même note, registre doux. Tableau `CEIL` par monde.
- Partiel métallique des cloches supprimé au-dessus de 1,8 kHz ; en sortie, étagère −6 dB au-dessus de 2,5 kHz et passe-bas à 6 kHz.
- Mesuré (musique des mondes 1 à 4) : énergie au-dessus de 1 kHz 21 % → 4 %, au-dessus de 2 kHz 7,3 % → 0,02 %.

## 0 quinquies. R42 — retours de Simon
- Cloches trop agressives : attaque passée de 10–18 ms à 70–100 ms, partiel métallique divisé par 2,5, filtre plus doux (`glass`, `bell` dans `sound.js`).
- Fiche en double dans un monde (« Tapis d'élan » puis « Matière : élan ») : un élément fixe et la matière correspondante du joueur forment désormais UNE notion (`PAIR` dans `tuto.js` : élan, rebond). Le texte de l'élément annonce la puce. Vérifié dans l'aperçu, niveau par niveau : 25 → « Tapis d'élan », 26 à 36 → aucune fiche.
- « Fiches pas au bon moment » : **non reproduit** (elles s'ouvrent au chargement du premier niveau qui contient l'élément, jamais sous la carte) ; demander à Simon un exemple précis.
- Aperçu du monde 3 construit avec `build-apercu.py 3 4 skipintro` : le Glacier (monde 4) est accessible pour écouter sa musique.

## 0 quater. R41 — musiques des mondes 1 à 4 (retour Simon : nappe « sirène », oppressante, oscillation trop rapide)

- **Cause** : les accords de la nappe glissaient d'une note à l'autre (portamento) → effet sirène. **Corrigé** : les accords ne glissent plus, chacun naît en 2,5 s pendant que le précédent s'éteint en 3 s ; nappe nettement plus basse ; filtre fixe ; trémolo lent (0,07 à 0,25 Hz, profondeur 10 %).
- **Ajouté** : écho ping-pong filtré (réglé par monde) en plus de la réverbération ; balance gauche/droite qui tourne très lentement.
- **Fil conducteur** : le même motif de cinq notes (`MOTIF`) dans tous les mondes, transformé par la physique du monde. **Musiques propres** (`STY` dans `sound.js`) :
  Atelier = verre lent, le motif puis sa réponse qui retombe ; Fonderie = motif en rebond (chaque intervalle vaut 72 % du précédent), voix chaude, bulles ; Chaîne = paquets de trois notes sur une pulsation régulière, écho rythmé ; Glacier = motif très aigu, notes tenues longtemps, accords figés, scintillement.
- **Mesuré** (40 s par monde, `docs/quantix-musique-mondes1-4.wav`) : centre spectral Atelier ≈ 500 Hz, Fonderie ≈ 400 Hz (chaud, 60 % sous 200 Hz), Chaîne ≈ 570 Hz, Glacier ≈ 1 460 Hz (6 % sous 200 Hz). **Écoute non faite ici.**
- Mondes 5 à 11 : reprennent provisoirement le style des mondes 1 à 4 ; leur musique propre est à écrire.

## 0 ter. R40 — son éthéré (`assets/js/sound.js`)

- **Intégré** : remplace la musique et les bruitages d'Audio1 (API inchangée), chargé après `engine.js`. Plus aucun échantillon mp3 joué (les fichiers restent dans `assets/audio/`, inutilisés). Synthèse pure : pas de `blob:` (piste pour le son muet signalé dans l'aperçu publié — **non vérifié** dans l'environnement de publication).
- **Musique** : thème de 5 notes (pentatonique de mi mineur, comme les vidéos de référence) en voix de verre, varié par 5 motifs ; nappe à 6 voix désaccordées + grave doux, filtre qui respire ; une couleur par monde (Atelier mi mineur, Fonderie la dorien, Chaîne sol pentatonique majeur, Glacier quintes ouvertes cristallines ; 5 à 11 déclinés). Couches mixées selon l'état (menu, dessin, chute, tension, réussite, échec).
- **Bruitages** : voix « guimauve » (triangle filtré, attaque 11 à 25 ms), verre, souffle filtré ; tous accordés sur l'échelle du monde et envoyés dans la même réverbération générée (3,6 s). Impacts limités à un toutes les 60 ms.
- **Mesuré (rendu hors ligne, scène de 36 s)** : centre spectral 561 Hz (anciens bruitages : 2 600 à 2 900 Hz ; référence vidéo : 928 Hz) ; énergie > 4 kHz 0,5 % (anciens : 24 à 29 % ; référence 3 %) ; 63 % de l'énergie entre 250 Hz et 1 kHz (référence 58 %). Extrait audio : `docs/quantix-son-demo-R40.wav`.
- **Non vérifié** : l'écoute (impossible ici) — c'est Simon qui juge. Réglages dans `sound.js` : tableau `WORLDS` (tonalité, filtre, tempo, brillance), `MOTIF`, `MIX`, fonctions `SFX`.

## 0 bis. R39 — monde 3 refondu (lire aussi `docs/REPONSES_R38.md`)

| Élément | État | Preuve |
|---|---|---|
| Monde 3 · Chaîne : 12 niveaux neufs | **Intégré** (`levels.js`, candidats `tools/w3cand.js`) | `node tools/monde3.js` → 12/12 ; balayage : 0 gagnant sans tapis sur les 12 |
| Jouabilité au doigt monde 3 | **Conformes** : 25 (92 % / 60 %), 28 (98 / 72), 29 (98 / 75). **Pas conformes** : 26 (63 %), 27 (63 %), 30 (~23 %), 31 à 36 non remesurés | `difficulty.js`, `retune.js` (étendu au monde 3), `tools/w3retune.json` |
| Retours de Simon (questionnaire) | Appliqués : zones interdites renforcées, carte plus lumineuse, tourbillons du monde 4 à échelles variées, didacticiel (phrase d'ambiance en italique, filet lumineux, ton plus fort) | captures, `e2e-didacticiel.py` 36/36 |

**Didacticiel dans les aperçus (R39, correctif)** : `build-apercu.py N … skipintro` traite désormais le joueur comme ayant fini les mondes précédents (intro faite, fiches d'outils vues, éléments des niveaux précédents vus) ; seules les règles nouvelles du monde s'affichent, et l'état n'est plus remis à zéro à chaque ouverture. Dans le jeu, une fiche vue ne revient jamais (vérifié : niveau 2 → outils + zone interdite ; 13 → rebond seul ; 25 → tapis seul ; 26 → rien).
**Règle apprise (monde 3)** : une balle qui démarre au repos sur un sol plat rend le niveau injouable au doigt (un trait décalé la laisse immobile) ; démarrer plus haut (y ≈ 196) donne de l'élan et de la tolérance, mais ouvre des contournements, à fermer en élargissant la zone interdite (pas en réduisant l'encre, sans effet).
**Suite** : régler 26, 27, puis 30 à 36 (`OUT=w3retune.json TMAX=… NG=… SP=… node retune.js N`, vérifier le contournement avec `node w3lab.js old:N`, écrire avec `python3 w3apply.py N`, relancer `monde3.js`). Puis monde 4, puis son (phase de recherche).

## 0. R38 — ce qui a changé (lire avec `docs/CAHIER_DES_CHARGES_R39.md`)

| Élément | État | Preuve |
|---|---|---|
| **Éditeur de lignes** (droite, gomme, déplacer/pivoter, historique unifié) | **Intégré** : `assets/js/editor.js`, dock `#dock` | `python3 tools/e2e-editeur.py` → 25/25 (souris, Chromium) |
| **Didacticiel refondu** (design, tonalité « carnet de laboratoire », 4 fiches d'outils) | **Intégré** | `node tools/tutotest.js` ; `python3 tools/e2e-didacticiel.py` → 36/36 |
| **Voiles de points** (3 couches translucides, mondes 1 à 4) | **Intégré** : `veils()` dans `visuals.js` | captures Chromium ; 13 ms/scène sans GPU |
| **Monde 4 : décor** (franges de Young, tourbillons, globe de fils, condensat) | **Décor seulement — les 12 niveaux du monde 4 sont encore les anciens (R29)** | captures |
| **Carte d'un monde éthérée** | **Intégré** | captures |
| Son (musique mélodique, bruitages texturés) | **Non commencé** ; analyse des vidéos faite | `CAHIER_DES_CHARGES_R39.md` §6 |
| Jouabilité au doigt avec l'éditeur | **Non remesurée** | §5 du cahier des charges |
| **Monde 3 (Chaîne)** | Niveaux jamais refondus ; précède le monde 4 | — |

**Limites de vérification** : captures avec police de secours (pas de réseau) ; aucun test sur téléphone réel ;
aucune écoute possible ; démos de fiches illustratives, pas la physique du moteur.
`python3 tools/build-apercu.py N [U] [skipintro]` : `skipintro` considère le didacticiel d'ouverture comme fait
(nécessaire pour voir le dock dans un aperçu qui n'ouvre pas sur le niveau 1).

## Phrase d'ouverture à coller dans une conversation neuve

> Reprends Quantix. Lis `docs/REPRISE-SESSION.md` en entier, puis seulement
> les sections du handbook qu'il indique. Tâche : **[une seule tâche de la
> liste §4]**. Applique la méthode §3. Livre un aperçu jouable publié, puis
> le zip.

## 1. Où en est le jeu (vérifié par les tests, pas déclaré)

| Élément | État | Preuve |
|---|---|---|
| Monde 1 · Atelier | **Refondu, 12/12** | `node tools/monde1.js` |
| Monde 2 · Fonderie | **Refondu 11/12** — #19 est l'ANCIEN « Le four » (R29), à reconcevoir | `node tools/monde2.js` → 11/11 ; `bypass.js 2` → 0/11 |
| Mondes 3 à 11 | Anciens niveaux (R29), à refondre | — |
| Solution optimale (bouton) | Mondes 1 et 2 : chaque niveau refondu a son `optsol` (+ `optmat` si matière rebond), noyau compris | `node tools/replaytest.js` |
| Revoir ma partie | Fonctionne (relit `S.rec`, sans physique) | `replaytest.js` |
| Rebond sans fin | Arrêt à **20 s** de vol → « Rebond sans fin » + bouton **Continuer** (+20 s) | testé R32 |
| **Nouveau rendu (R33)** | **Intégré au jeu** : `assets/js/visuals.js` (portée privée, un seul global `window.VX`). Structures en treillis, plaques incandescentes, pointes cristallines, cuve, zones interdites, ruban d'énergie, noyau et **balle en nuage de points bistable**, **accueil animé**. Décor : monde 1 = cosmos + hélices ADN composées par niveau ; monde 2 = chambre à bulles ; **monde 3 = anneau de stockage (cavités RF, lumière synchrotron de la balle) — R35** ; **mondes 4–11 = cosmos aux couleurs du monde (provisoire, à doter de leur identité propre)** | captures Chromium réelles (Playwright disponible : `/tmp/shot.py` à recréer, voir §5) ; appels comptés dans le moteur |

| **Didacticiel (R37)** | **Intégré au jeu** : première partie guidée dans le niveau 1 ; fiche d'élément à la première rencontre (détection sur les données du niveau, 18 éléments, tous mondes) ; « Aide du niveau » (pause) ; « Explications » (paramètres). Voir handbook §13 | `node tools/tutotest.js` ; parcours Chromium réel (échec, persistance, aide, explications, anglais, 360×640) |

**Aperçus publiés** (claude.ai) : Atelier 12/12 et Fonderie 10 niveaux —
sources dans `docs/apercus/` ; code des décors dans `tools/apercu/`.

## 2. Ce que l'utilisateur veut (ne pas le perdre)

- **Refonte niveau par niveau**, ambitieuse, jamais un simple correctif :
  chaque niveau = une idée, une chute, un noyau qui récompense un choix.
- **Chaque monde a sa narration et son identité visuelle animée forte** —
  fondée sur une expérience de physique réelle (`docs/QUANTUM_VISUAL_NARRATIVE.md`).
  Les vidéos d'illusions bistables (nuages de points en rotation) sont des
  **références d'animation mathématique** pour ces identités de monde — pas
  une demande de nouveau noyau par monde.
- **Toujours un aperçu jouable** du travail en cours, qui soit fidèle au jeu.
- Style de décor retenu : **néon + couche cosmique** (hélices ADN, poussière
  d'étoiles, voile de nébuleuses), décliné par monde (Fonderie = chambre à
  bulles). Le style « rétro plat » a été **rejeté**.
- Réponses en **français**. Ne pas se contenter de documenter : produire.

## 3. Méthode qui marche (outils dans `tools/`)

1. Concevoir des candidats dans un fichier `wNcand.js` (format de `levels.js`).
2. `lab.js` : pour chaque candidat — échec sans trait, gagnants AVEC la
   mécanique, gagnants SANS elle (doit être 0). Script modèle : `w2redo.js`.
3. `w2finish.js` (généraliser en `wNfinish.js`) : noyau placé où passent
   15–35 % des solutions, solution avec noyau la plus tolérante au doigt
   (±4 px, seuil ≥ 50 %). **Un niveau par commande** (`OUT=wN_k.json
   STEP=14 DA=.34 NT=30 timeout 285 node …`) — la machine n'a **qu'un
   processeur**, rien en parallèle, rien en arrière-plan (ne survit pas).
4. Vérifier que les gagnants utilisent **vraiment** chaque élément prévu
   (rendre l'élément inerte, compter ceux qui échouent).
5. Écrire dans `levels.js` (+ `optsol`/`optmat`) et `i18n.js` (EN), puis
   un test `mondeN.js` sur le modèle de `monde2.js`.
6. Aperçu : partir de `docs/apercus/monde2-fonderie.html` (collision
   **identique** au moteur : contact à R+4 murs, R+3,2 traits, pointes
   mortelles). Remplacer le décor par celui du monde. Vérifier que chaque
   solution y gagne avec le noyau avant de publier.
7. Séquence handbook §10 + `monde1.js` `monde2.js` `replaytest.js`, tampon
   de version neuf, zip.

**Règles de conception apprises** : handbook §11 ter (monde 1) et
§11 quinquies (monde 2 — principe d'énergie : bassin plus haut que le
départ ⇒ rebond indispensable ; la plaque ne projette vers le haut que
frappée **en vol** ; éviter les demi-tours avec rebond et les rebonds entre
deux parois).

## 4. Prochaines tâches, dans l'ordre

**Didacticiel — reste à faire** : (a) test sur de vrais joueurs débutants, sur téléphone ; (b) lorsqu'un monde est refondu, vérifier que chaque élément nouveau arrive **seul** en position 1 ou 2 (relevés au handbook §13) ; (c) les démos de fiche sont illustratives, pas la physique du moteur : à remplacer si l'écart gêne ; (d) l'étape « Voir la solution optimale » et le score en étoiles ne sont pas expliqués hors de l'écran de résultat.

0. **EN COURS (R34) : jouabilité au doigt** — correction appliquée à 16 niveaux,
   bilan au §8 de `docs/DIFFICULTY_PROTOCOL.md`. Reste : reconcevoir #12, #15,
   #16, #17, #18, #19 (géométrie convergente) ; revoir les noyaux trop faciles.
   Outils : `retune.js` (correction), `fixstar.js` (noyau sur la trajectoire
   exacte), `difficulty.js` (mesure). Historique de la tâche :
   **rendre les mondes 1 et 2 jouables au doigt** — test réel :
   difficulté excessive, marge d'erreur trop faible, pas d'alternative à la
   solution parfaite. Mesuré (`docs/DIFFICULTY_PROTOCOL.md`,
   `node tools/difficulty.js N`) : quasiment aucun niveau n'atteint
   P_exec ≥ 70 %. Corriger la **géométrie** niveau par niveau (§6 du
   protocole) — une aide « tracé redressé » a été mesurée inutile.
   L'ancienne tolérance ±4 u (0,6 mm) est **obsolète**.

1. **Monde 2 #19** (rôle « combinaison ») — 9 concepts rejetés, listés au
   handbook §11 quinquies. Piste non essayée : combiner avec *Le col* ou
   *Le leurre* du monde 1, en gardant une arrivée **en vol** sur la plaque.
2. **Monde 2 : réduire la redondance** (`redundancy.js 2` → 8 paires) —
   varier la position du départ et de la plaque entre niveaux proches.
3. **Monde 3 · Chaîne (élan)** — narration « anneau d'accélération ».
   Principe à vérifier d'abord : le tapis d'élan est un *interrupteur* de
   vitesse (~7,4 constant), pas un curseur.
4. Doter chaque monde 3–11 de son identité animée propre dans `visuals.js`
   (fonction `back()` : aiguillage par `D.wd`), d'après `QUANTUM_VISUAL_NARRATIVE.md`.
5. Mondes 4 à 11, puis #114 (monde 10, infranchissable) et monde 11
   (12/12 contournable) — priorités connues.

## 4 bis. Règles de livraison et de charte (demandes utilisateur, R36)

- **Ne livrer que l'aperçu du monde en cours**, ouvert directement sur sa
  carte avec ses niveaux débloqués : `python3 tools/build-apercu.py N`
  → `quantix-apercu-mondeN.html` (publier comme artefact). Plus de version
  « jeu complet » à chaque livraison : l'utilisateur devait rejouer tous les
  niveaux pour atteindre le monde travaillé. Le zip reste le livrable du site.
- **Illustrations** : jamais utilisées brutes (trop saturées, trop claires pour
  la charte néon sur fond #05070D). `python3 tools/grade-art.py` les étalonne
  (saturation ×0,48, luminosité ×0,70, virage nuit → couleur du monde → cyan
  pâle, vignettage) depuis les **originaux conservés** dans `docs/source-art/`.
  Toute nouvelle illustration : la déposer dans `docs/source-art/`, relancer.
- **Carte d'un monde** : nœuds = particules (sphère de verre, nuage de points
  tournant, orbite + électron), liens = filaments d'énergie (halo, flux,
  photon sur les liens réussis) — `openWorld()` dans `engine.js`, styles
  `.wn` / `.wl*` dans `quantix.css`. États : lock / open / cur / done.

## 5. Pièges qui ont coûté cher (ne pas refaire)

- **Un aperçu n'est pas le jeu** : l'utilisateur a mis en ligne R32 en
  croyant y trouver le nouveau design, qui n'existait que dans les aperçus.
  Toujours dire explicitement ce qui est dans le moteur et ce qui ne l'est pas.
- **Vérifier visuellement** : Playwright + Chromium fonctionnent ici.
  `page.goto('file:///…/index.html')`, puis `page.evaluate("goto('game');loadLevel(i)")`,
  puis `page.screenshot(...)`.

- `node -e` : jamais de variable `L`, `S`, `T` (collision avec le moteur,
  handbook §9.1) — utiliser `LV`, `ST`, `X.S`.
- `pkill -f motif` tue aussi la commande qui le contient.
- Un aperçu à physique approximative ment : copier `collide()` du moteur.
- Une solution de référence « qui gagne » ne prouve pas que le noyau est
  atteignable : toujours vérifier `gotStar`.
