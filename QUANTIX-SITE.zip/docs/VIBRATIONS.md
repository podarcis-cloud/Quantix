# QUANTIX — Vibrations (proposition R230, 16 octobre 2026)

*Statut : proposition jouable dans le Banc de la fin, pas encore dans le jeu.*

## Moteurs (`assets/js/haptics.js`, global `QHAP`)
| Appareil | Moyen | Intensités |
|---|---|---|
| Application native (Capacitor Haptics) | `Haptics.impact` | légère / moyenne / lourde réelles |
| Android | `navigator.vibrate` (durées 9 / 20 / 38 ms) | par la durée |
| iPhone, iOS 18+ (Safari, WebKit) | interrupteur caché `<input type=checkbox switch>` | une seule (tic système) ; relief par le rythme, « lourd » = deux tics serrés |

Non vérifié : que le tic iPhone part sans geste de l'utilisateur (pendant le film). Les boutons d'essai, eux, sont des gestes.

## Le pool (19 motifs) — [délai ms, force 1·2·3]
frôlement, petit rebond, rebond, impact lourd (choc + écho), double rebond (lourd, moyen, léger : 0 / 300 / 490 ms),
roulement, propulsion (s'emballe), portail, collision, crépitement, annihilation, battement, aspiration (de plus en plus
serré), naissance, cliquet, givre, houle, tension (charge qui monte), envol.

## Le scénario de la fin (`VIBSC` dans `hero.js`, temps local de chaque acte)
Principes : un motif par geste physique fort ; jamais deux chocs lourds collés ; des silences pour que les impacts comptent ;
les mondes doux (Glacier, vol libre) ne vibrent presque pas ; la fin monte en tension jusqu'à l'aspiration.

| Acte | Partition |
|---|---|
| La coupe | battement → impact lourd (l'onde part) |
| Quantique | portail (dédoublement) · portail (tunnel) |
| Filaments | rebond (la corde claque) · petit rebond · propulsion |
| Faille | portail · portail · impact lourd à la réception |
| Magnétisme | tic, tic, rebond, rebond (l'accélérateur s'emballe) · tension · collision |
| Gravité | impact lourd (la chute) · rebond |
| Mécanique | cliquet · cliquet · impact lourd (violette) · tension · propulsion (éjection) · double rebond (blanche) |
| Soufflerie | houle (l'air monte) · portail (cyclone) · envol |
| Glacier | givre × 3, très léger |
| Chaîne | petit rebond · propulsion · rebond · envol |
| Fonderie | rebond (sol) · tic (plafond) · rebond · tic · double rebond (dernière plaque) |
| Atelier | tic · crépitement × 3 (le trait s'électrise) · tension · annihilation (impact) · crépitement (sable) · propulsion (saut) · silence du vol · tension · aspiration (siphon) |
| Plongée | aspiration · naissance (l'atome) |
| Danse | battement à chaque changement de figure |

## Pour le jeu (à décider)
Option « Vibrations » dans les Paramètres (textes FR/EN dans `i18n.js`, mémorisée dans la sauvegarde), `haptics.js`
chargé dans `index.html`, puis une partition courte pour les niveaux : petit rebond, rebond, impact lourd, portail,
annihilation (trait refusé par une zone interdite), naissance (réussite). Pas de vibration sur l'échec (charte).
