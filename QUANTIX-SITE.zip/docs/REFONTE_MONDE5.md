# Refonte du monde 5 « Soufflerie » — lot 1 (25 oct. 2026)

Méthode : fiches Opus (`FICHES_MONDE5.md`), géométrie et preuves au banc (`tools/refonte/m5.js`, `BASE=48 WD=5`). Aperçu seul (artefact « refonte ») ; le jeu principal garde les niveaux d'origine du monde 5.

| N | Titre | Raisonnement | P_ligne | P_hasard | Note |
|---|---|---|---|---|---|
| 49 | Le souffle | Déposer dans le courant | 83 | 4,5 | colonne + hotte ; un peu facile au hasard |
| 50 | La couche | Traverser vite (de plus haut) | 95 | 0,7 | couche de vent ; marches fixes = leurre |
| 51 | L'ascenseur | S'attarder dans la colonne (machine : chute à vitesses) | 88 | 4,9 | colonne large 120 u (50 u trop fragile) |
| 52 | Ramer | Ruban contre un vent long | 93 | 0,25 | |
| 54 | La cascade inversée | Boomerang puis couloir à rubans 2/10/7/0 | 93 | 4,3 | entonnoir de retour ; spécial |
| 60 | Le cyclone | Arracher par la tangente + machine à rubans courbes | 75–80 | 3,9 | lame courte ; spécial |
| 53, 55, 56, 59 | — | demandent les extensions moteur E3 (ombre), E5 (vanne), E1 (vent qui change) | | | non faits : anciens niveaux conservés |
| 57, 58 | — | faisables au moteur actuel | | | non faits : anciens niveaux conservés |

## Leçons de construction
- Un vent uniforme n'arrête pas une balle rapide : la différence « rapide / lent » vient du temps passé dans le vent (50). Une balle qui sort d'une pente a une grande vitesse horizontale : les marches ne la ralentissent pas, il faut des butées.
- Une zone se lit par son coin gauche : `cup:[x gauche, y bas, largeur]`, hauteur 48.
- Les entonnoirs de retour (54) rendent le trait tolérant mais montent P_hasard : il faut réduire la zone dessinable (nd) et l'encre.
- Les rubans à vitesse courbes (`curves` avec `v`, R301) servent aux machines (54, 60).

## État
- **Vérifié** : 6 niveaux réussis dans le moteur réel ; sans trait ils échouent ; rendu contrôlé en capture (49, 51, 54, 60).
- **Non testé** : iPhone réel ; 53, 55, 56, 57, 58, 59 non refaits ; machines 54 et 60 plus courtes que dans les fiches (≈ 3 s) ; P_hasard au-dessus des cibles pour 49, 51, 54, 60.
