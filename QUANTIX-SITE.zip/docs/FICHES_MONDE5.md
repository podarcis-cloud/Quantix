# QUANTIX — Monde 5 « Soufflerie » : 12 fiches de conception (niveaux 49–60)

25 oct. 2026 · concepteur d'énigmes · **aucune géométrie** : idées, raisonnements, leurres, rôles. L'ingénieur construit et prouve au banc.
Refonte de fond : remplace les 12 niveaux actuels (`levels.js`, `wd:5`). Ne modifie rien d'autre.

## 0. Résumé du monde

**Phrase du monde : « L'invisible pousse. »** Le vent est une matière : on y **dépose** la balle, on le **traverse**, on s'y
**attarde**, on lui **résiste**, on lui **fait de l'ombre**, on l'**allume**, on **lit** deux vents qui se croisent, on
**attend** qu'il tourne, on en **arrache** la balle.

**Courbe (Ki → Ketsu)**
- Ki (49–51) : le vent porte (49), il ne retient que les lents (50), il ne soulève que ce qui reste (51, révélation de la machine type « ascenseur d'air puis glissade »).
- Shō (52–54) : contre un vent long, l'élan meurt et seul un ruban avance (52) ; un trait debout fait un abri (53, l'ombre) ; le vent renvoie ce qu'on lui lance (54, boomerang, puis la **cascade inversée**).
- Ten (55–57) : le vent devient l'ennemi de tout le parcours et l'abri doit se poser loin (55) ; le vent dort et c'est la balle qui l'allume (56) ; deux vents croisés font un troisième vent (57, **machine-énigme**).
- Ketsu (58–60) : refuser le chemin que le vent propose (58, deux actes) ; le vent tourne, il faut tenir la balle en attendant (59) ; le tourbillon garde la balle pour toujours, il faut l'en arracher (60, **le cyclone**, grande machine).

**Éléments introduits, dans l'ordre** : colonne (49) · rideau horizontal (50) · colonne étroite (51) · vent de face long + ruban (52) · ombre du trait, E3 (53) · bande de retour (54) · bouche lointaine (55) · vanne, E5 (56) · croisement de deux vents (57) · deux relais (58) · vent qui tourne, E1 (59) · tourbillon (60).

**Cible de P_hasard (traits au hasard)** : 49–51 ≤ 3 % · 52–54 ≤ 1,5 % · 55–57 ≤ 1 % · 58–60 ≤ 0,5 %. P_ligne (bruit de doigt σ = 3) ≥ 85 % partout.

**Ce que la refonte garde des niveaux actuels** : l'idée du 49 (déposer dans la colonne), celle du 52 « Colonne étroite » (devenue 51), la cascade inversée (54) et le cyclone (60, modèle validé par Simon), tous deux agrandis en machines. **Retirés** : « Vent de face » et « Contre-courant » (viser à côté pour compenser la dérive : c'est de la précision, pas une idée) ; « Vent descendant » et « La tempête » (« le vent raccourcit la pente », « une pente peut monter » : c'est la vérité du monde 7, voir §1.3) ; « Deux colonnes », « Vent et lame », « La rafale », « Le tunnel » (sans référence, contournables : AUDIT_R209 et scan 132).

---

## 1. Cadre commun (à lire avant les fiches)

### 1.1 Ce que le vent fait dans le moteur actuel (`engine.js`, `fields()` et `qpField()`)
1. **Une zone de vent est un rectangle** `[x, y, l, h, ax, ay, caché]` qui **ajoute une accélération constante** tant que le
   centre de la balle est dedans. Toute direction est possible ; les zones qui se chevauchent **s'additionnent**. La pesanteur
   vaut 0,4 : une colonne à −0,6 pousse vers le haut avec 0,2 net ; à −0,8, avec 0,4.
2. **L'effet dépend du temps passé dans la zone, pas de la vitesse.** Une balle rapide traverse une zone étroite presque sans
   déviation ; une balle lente ou arrêtée est emportée. Étalonnage : une colonne soulève de 500 à 700 u ; un vent latéral de
   0,1 décale de ≈ 24 u sur 200 u de chute (cahier §7). C'est le premier levier propre au vent (50, 51, 52).
3. **Un vent uniforme ne freine ni ne piège : il rend ce qu'il prend.** Une balle lancée contre lui revient à la même vitesse
   (le **boomerang**, 54) ; une balle dans une colonne bornée **danse** sans fin à son sommet (prison silencieuse) ; une balle
   poussée contre un mur y reste **plaquée** (prison silencieuse). Ces trois comportements servent de pièges lisibles.
4. **Aujourd'hui le vent traverse les murs** : aucun trait n'arrête l'air. L'ombre de vent (« derrière un mur, l'air se tait »)
   est l'extension **E3** ; c'est la signature du monde, voir §6.
5. **Le tourbillon est natif** : le cyclone actuel combine une piste circulaire et quatre bandes de vent cachées tangentes
   (haut →, droite ↓, bas ←, gauche ↑). `updraft` et `vortex` ne sont que des dessins.
6. **Le ruban réglé (`v`) pousse au plus de 0,62 par pas** : il bat tout vent plus faible. Un ruban ordinaire plafonne à 7,2 (monde 3).
7. **Gagner = être dans la zone à moins de 2,2 pendant 17 trames.** Une balle plaquée par le vent a une vitesse nulle : un vent
   qui couvre la zone peut faire gagner sans idée (raccourci générique R-b ci-dessous). **Règle : la zone est toujours hors du
   vent visible.**
8. Le vent agit aussi sur les cordes (particules) : non utilisé ici, la corde appartient au monde 10.

### 1.2 Raccourcis génériques (à chercher dans chaque niveau, en plus de ceux de chaque fiche)
- **R-a** ligne droite balle → zone, dans chaque matière permise.
- **R-b** plaquer la balle dans la zone par un vent (fermé par la règle 7).
- **R-c** la danse au sommet d'une colonne qui tombe dans la zone (même règle : aucune colonne ne finit dans la zone).
- **R-d** la **voûte** : un trait-plafond posé dans un vent montant fait remonter la balle le long de son dessous (le vent joue la
  pesanteur à l'envers). C'est le raccourci universel des niveaux à colonne : à fermer partout par l'encre ou des nd placés au-dessus
  des colonnes. **Jamais la solution d'un niveau de ce monde** (c'est la vérité du monde 7).
- **R-e** tir au hasard (P_hasard).
- **R-f (si E3)** l'**abri accidentel** : tout trait fait de l'ombre ; vérifier que les traits d'un niveau n'ouvrent pas un abri
  imprévu (en particulier le pont du 50 et le berceau du 51).

### 1.3 Règle de non-redondance avec le monde 7 (Gravité)
Un vent uniforme équivaut à une pesanteur inclinée. Tout raisonnement du type « le bas change » (voûte, pente qui monte, rampe à
l'envers, équilibre sur une pente) est **réservé au monde 7**. Le monde 5 n'utilise que ce que la gravité ne sait pas faire :
**le temps d'exposition** (zones étroites ou longues), **la somme de deux vents**, **l'ombre** (E3), **le vent qui change avec le
temps** (E1), **le vent qu'on allume** (E5), **la poussée constante contre l'élan** (ruban contre vent), **le renvoi** (boomerang,
danse, plaquage) et **le tourbillon**.

### 1.4 Langage visuel requis
- Chevrons animés dans le sens du vent (existants, R252). **E0** : vitesse et densité des chevrons proportionnelles à la force,
  pour que « vent fort » et « vent faible » se lisent sans mots (indispensable au 57).
- Toute zone à source a une **bouche** dessinée (grille) sur son bord amont : le vent vient de quelque part (indispensable au 55).
- Si E3 : derrière un trait, les chevrons **s'éteignent** et une ombre translucide dessine l'abri. Sans ce retour, 53 et 55 sont illisibles.
- Rubans de vitesse (monde 3) : ambre 0 · turquoise 2 · violet 7 · blanc-cyan 10, chevrons allumés quand ils poussent.
- Machines : vents cachés (`caché` = 1) dans un tube dessiné (`updraft`), toujours sous nd. Courbes lissées (Catmull-Rom),
  pentes douces, détours d'harmonie (REFONTE_MONDE3, « Esthétique des trajectoires »).

### 1.5 Hypothèses nouvelles (à ajouter au registre, Bible IX.2)
H27 « pour monter, il faut construire une montée » · H28 « le vent pousse pareil tout ce qui le traverse » · H29 « il suffit
d'entrer dans le courant » · H30 « assez d'élan au départ suffit à tout traverser » · H31 « l'air traverse tout ; un trait ne
change rien au vent » · H32 « on va vers ce qu'on vise » · H33 « le fond d'un puits est un échec » · H34 « de deux vents, seul
le plus fort compte » · H35 « le chemin que le vent propose est le bon » · H36 « le vent reste le même du début à la fin » ·
H37 « pour arrêter ce qui tourne, il faut lui barrer la route ». Du registre existant : H14 (55), H18 (58).

### 1.6 Décision D1 (à prendre AVANT de construire)
**E3 (ombre de vent) s'applique-t-elle à tous les vents visibles du monde ?** Recommandation : **oui** (cohérence : un monde où
le mur arrête l'air au 53 mais pas au 50 serait faux). Les vents cachés des machines n'ont pas d'ombre (on ne peut pas y tracer :
nd). Chaque fiche dit ce que l'ombre change chez elle. Si E3 est refusée, voir les rechanges (§7).

---

## 49 · Le souffle
- **Temps** : Ki 1, Simple. Raison d'être : montrer sans mots que l'air porte, et que le trait n'a pas à bâtir la montée.
- **Type** : DÉPOSER (confier la balle au courant).
- **Vérité** : une colonne d'air soulève tout ce qui y entre ; le trait ne fait que l'y conduire.
- **Phrase** : « Ne bâtis pas la montée : pousse la balle dans le souffle. »
- **Hypothèse** : H27 (pour monter, il faut construire une montée).
- **Leurre** : une rampe ou un escalier vers le plateau haut : la jauge d'encre se vide à mi-hauteur, ou la rampe est trop raide et la balle cale puis redescend.
- **Scénario** : sans trait, la balle tombe sur une pente qui l'éloigne de la colonne et roule aux pointes ; il trace une rampe vers le plateau, trop courte ; il remarque la colonne qui « chante » à côté (chevrons montants) ; un petit déflecteur renvoie la balle dans la fenêtre de la colonne ; elle monte, la hotte la verse sur le plateau.
- **Éléments** : chute sur une pente fixe qui descend **à l'opposé** de la colonne (PIÉGER : le « rien faire » est fatal et lisible ; oblige un geste à contre-pente) ; pointes au bout de la pente (PIÉGER) ; colonne visible (≈ 60 u, −0,8) adossée à une falaise, entrée par une fenêtre basse ≥ 44 u (PORTER) ; falaise (FERMER l'accès au plateau par le bas) ; hotte courbe fixe au sommet de la colonne (PORTER : convertit la montée en glissade vers la zone, première image de la machine type en miniature) ; zone sur le plateau, adossée à un mur (PORTER : arrivée lente).
- **Raccourcis** : rampe vers le plateau (fermé : hauteur du plateau > ce que l'encre permet, encre = 1,3 × déflecteur) ; tremplin qui lance la balle par-dessus la falaise (fermé : plafond fixe au-dessus de la falaise, nd sur le ciel du plateau) ; voûte R-d (fermé : nd sur la moitié haute de la colonne, sous la hotte) ; entrer dans la colonne par le haut (impossible : hotte).
- **Contraintes** : palette S ; encre serrée (un trait court) ; nd au-dessus de la falaise, sur la hotte et la moitié haute de la colonne ; 1 zone de vent visible ; hotte = `curves` ; aucun ruban v2. Déflecteur tolérant : toute inclinaison de 20 à 60° sous la chute renvoie vers la fenêtre. Si E3 : le déflecteur est hors colonne, sans effet sur l'air.
- **Unique** : seul niveau où le vent fait tout et le trait presque rien ; tout le reste du monde le discute.
- **Variante dure** : deux colonnes, deux hottes ; l'une verse sur le plateau, l'autre sur les pointes ; seule la forme de la hotte dit laquelle choisir.

## 50 · La couche
- **Temps** : Ki 2, Simple. Raison d'être : le vent agit avec le temps ; la vitesse est un poids.
- **Type** : TRAVERSER VITE (garder la hauteur pour traverser).
- **Vérité** : le vent pousse en proportion du temps passé dedans ; une balle rapide traverse une couche d'air presque droit.
- **Phrase** : « Lâche-la de haut : rapide, elle traverse la couche sans dériver. »
- **Hypothèse** : H28 (le vent pousse pareil tout ce qui le traverse).
- **Leurre** : « poser » la balle doucement : une descente qui amène la balle près du puits avant de la lâcher (le geste précautionneux de tout joueur). Lâchée bas, elle tombe lentement dans la couche, dérive et s'empale sur la crête de pointes au bord du puits.
- **Scénario** : la balle descend les deux marches fixes vers le puits, tombe dans la couche et dérive aux pointes ; il trace une descente plus douce, plus près, c'est pire ; il comprend que la couche « pèse » sur ce qui s'attarde ; il trace un pont **haut**, plat, depuis le départ jusqu'au-dessus du puits : la balle tombe de toute la hauteur, traverse la couche en un éclair et entre dans le puits.
- **Éléments** : départ haut (PORTER : la hauteur est la vitesse disponible) ; deux marches fixes qui descendent vers le puits (PIÉGER : elles invitent à perdre la hauteur, c'est le leurre joué au premier lancer) ; **couche horizontale** de vent latéral fort (≈ 60 u d'épaisseur, ≈ 0,8, vers les pointes) sur toute la largeur, à mi-hauteur (PIÉGER le lent) ; crête de pointes au bord du puits, côté sous le vent (PIÉGER : rend la dérive fatale et lisible) ; puits-zone profond (≈ 90 u), adossé, sous la couche (PORTER : arrêt d'une balle rapide).
- **Raccourcis** : paravent ou tube à travers la couche (fermé : nd sur toute la couche + 30 u de marge ; c'est aussi ce qui rend E3 sans effet ici) ; déviation en vol sous la couche (fermé : même nd, puits juste sous la couche) ; pente raide qui « plonge » (même idée : vitesse à la traversée, acceptable) ; pont bas (c'est le leurre) ; R-e : un pont long, haut et finissant au-dessus du puits est rare au hasard.
- **Contraintes** : palette S ; encre moyenne (un pont haut ≈ 1,25 × référence, insuffisante pour un pont + une marche) ; nd sur la couche et autour du puits ; 1 zone visible ; aucun v2. Tolérance : tout pont dont le bout est au-dessus du puits (± 40 u) et plus haut qu'un seuil large (≈ la moitié de la hauteur départ-couche) réussit.
- **Unique** : seul niveau où la bonne réponse est « de plus haut, plus vite » ; il prépare 51 et 52, qui le renversent.
- **Variante dure** : deux couches de sens opposés ; une balle lente dérive dans la première et revient dans la seconde, mais trop tard ; seule une balle rapide les traverse toutes les deux.

## 51 · L'ascenseur
- **Temps** : Ki 3, **Relais** (révélation de la machine type : ascenseur d'air puis glissade). Raison d'être : seconde face du 50, et la machine du monde.
- **Type** : S'ATTARDER (arrêter la balle dans le courant).
- **Vérité** : une colonne étroite ne soulève que ce qui y reste : il faut y arrêter la balle, pas l'y jeter.
- **Phrase** : « Arrête la balle dans la colonne : immobile, elle monte. »
- **Hypothèse** : H29 (il suffit d'entrer dans le courant ; renverse la leçon du 49).
- **Leurre** : le réflexe du 49 et du 50 réunis : envoyer la balle **vite** dans la colonne. Elle la traverse en un éclair, à peine relevée, et file dans le vide de l'autre côté.
- **Scénario** : sans trait, la balle dévale la longue rampe fixe, traverse la colonne et tombe ; il la jette plus haut dans la colonne, même chose ; il comprend que c'est la vitesse qui la fait traverser ; il dresse une butée verticale **dans** la colonne : la balle s'y arrête, l'air la hisse le long de la butée jusqu'au récepteur.
- **Éléments** : longue rampe fixe (PORTER la vitesse, et PIÉGER : c'est elle qui fait traverser) ; colonne étroite (≈ 50 u, −0,8) (PORTER) ; vide au-delà (PIÉGER : la traversée se voit) ; récepteur en haut de la colonne, bouche tournée **vers le bas**, coiffé (FERMER tout tir en cloche : on ne l'atteint qu'en montant dans la colonne) ; machine.
- **Raccourcis** : tremplin vers le récepteur (fermé : bouche vers le bas, coiffe) ; arrêter la balle avant la colonne (échec lisible : elle reste posée) ; voûte R-d (fermé : nd dans la colonne au-dessus de la hauteur de la rampe) ; berceau horizontal dans la colonne (sans E3 : réussit, même idée, acceptable ; **avec E3 : échoue**, l'air s'éteint au-dessus du berceau, premier aperçu de l'ombre, lisible grâce aux chevrons éteints) ; R-e : encre courte (≈ 60 u), un trait au hasard tombe rarement dans la bande de 50 u à la bonne hauteur et assez debout.
- **Machine (révélation + récompense, ≈ 4 s)** : récepteur → tube vitré (vent caché −1,0) qui hisse la balle en passant deux **paliers d'ombre** (écrans fixes : dans leur ombre l'air se tait, la balle retombe sur un palier, roule, rentre dans le vent et remonte ; en natif, ombres faites en découpant les zones) → coude courbe au sommet → **glissade** : lacet violet (7), vague blanc-cyan (10) où la balle bondit d'une bosse à l'autre, ralenti turquoise (2) qui la pose dans la zone. Révélation : « au-dessus d'un mur, l'air se tait » (servira au 53 et au 55).
- **Contraintes** : palette S ; encre serrée (un trait de 50–70 u) ; nd sur la rampe, la moitié haute de la colonne, le récepteur et la machine ; 1 zone visible + zones cachées ; rubans v2 dans la glissade. Butée tolérante : toute butée ±25° de la verticale dont le pied est dans la colonne.
- **Unique** : seul niveau où l'on arrête la balle pour qu'elle monte.
- **Variante dure** : la balle traverse la colonne **en vol** ; il faut un crochet suspendu qui la cueille dans l'air (avec E3, un crochet sans fond, sinon il éteint la colonne).

## 52 · Ramer
- **Temps** : Shō 4, Simple. Raison d'être : combiner avec le monde 3 (le ruban) ; renverser le 50.
- **Type** : MOTORISER (une poussée constante contre une force constante).
- **Vérité** : un vent long use tout élan ; seul un ruban, qui pousse sans fin, avance contre lui.
- **Phrase** : « Contre le vent, l'élan s'épuise : pose un ruban, il pousse toujours. »
- **Hypothèse** : H30 (assez d'élan au départ suffit à tout traverser).
- **Leurre** : la plongée du 50 (palette S sélectionnée par défaut) : la balle part vite sur la longue passerelle balayée de face, ralentit, s'arrête aux deux tiers et repart en arrière, de plus en plus vite, jusqu'aux pointes du départ.
- **Scénario** : il plonge, elle revient ; il plonge de plus haut, le plafond l'en empêche et elle revient encore ; il se souvient du ruban (outil A offert) ; il le pose sur la passerelle, vers la zone : chevrons allumés, la balle avance au pas contre le vent et entre dans la niche.
- **Éléments** : passerelle fixe longue et plate (PORTER : support du ruban) ; vent de face modéré (≈ 0,3) sur toute sa longueur (PIÉGER l'élan) ; pointes derrière le départ (PIÉGER : le retour est fatal et lisible) ; plafond bas au-dessus du départ (FERMER la plongée assez haute) ; zone dans une niche **abritée** au bout, adossée (PORTER : arrivée hors du vent) ; bouche du vent au-dessus de la niche, sous nd (FERMER « couper la source », voir 55).
- **Raccourcis** : plonger plus haut (fermé : plafond ; longueur du vent > portée de la meilleure plongée, v²/2a) ; un ruban court au début (fermé : au-delà du ruban, la balle sortie à 7,2 s'arrête en ≈ 85 u ; le vent est bien plus long, encre = 1,2 × passerelle) ; deux rubans à la suite (sans gain, plafond 7,2) ; paravent (si E3 : un écran face à un vent horizontal est forcément sur le chemin de la balle, il la bloque ; couper la bouche est impossible, nd) ; G1 (ruban montant posé en l'air) : sans objet, la niche est au niveau de la passerelle.
- **Contraintes** : palette S + A, **S par défaut** ; encre calculée (un ruban couvrant ≈ 85 % de la passerelle, pas plus) ; nd sur la bouche, le plafond et la niche ; 1 zone visible ; aucun v2 fixe.
- **Unique** : seul niveau où le vent est plus fort que toute vitesse et plus faible qu'un ruban.
- **Variante dure** : la passerelle monte doucement ; seul un ruban blanc-cyan fixe (10) au premier tiers donne assez ; le joueur doit **prolonger** ce ruban fixe plutôt que le recouvrir.

## 53 · Le paravent  *(E3)*
- **Temps** : Shō 5, Simple, première impasse sérieuse. Raison d'être : introduire l'ombre de vent comme outil.
- **Type** : ABRITER (faire un calme).
- **Vérité** : un trait debout face au vent fait un abri : derrière lui, l'air se tait.
- **Phrase** : « Dresse un mur face au vent : derrière lui, la balle roule en paix. »
- **Hypothèse** : H31 (l'air traverse tout ; un trait ne change rien au vent).
- **Leurre A** : la vitesse (réflexe du 50) : la balle descend plus vite la gouttière vers le bassin, y entre, puis le vent la repousse hors du bassin, côté départ, jusqu'aux pointes. **Leurre B** : un toit au-dessus de la gouttière : le vent passe dessous, rien ne change (lisible : chevrons intacts sous le toit).
- **Scénario** : la balle descend la gouttière fixe, le vent de face la renvoie aux pointes ; il donne de la vitesse, elle atteint le bassin puis en ressort ; il couvre la gouttière d'un toit, rien ; il dresse, à côté du bassin côté vent, un mur haut : les chevrons s'éteignent derrière lui, la balle descend dans le calme et s'arrête dans le bassin.
- **Éléments** : gouttière fixe du départ au bassin, à contre-vent (PORTER le chemin, PIÉGER : le vent la remonte) ; vent horizontal fort (≈ 0,6) venant d'une bouche visible au-delà du bassin (PIÉGER) ; pointes derrière le départ (PIÉGER : rendent le renvoi fatal) ; bassin-zone à rebords bas (FERMER « elle y restera seule ») ; bande traçable étroite entre le bassin et la bouche (PORTER : c'est là que l'abri se pose, et H16 : le seul endroit permis est un indice).
- **Raccourcis** : mur derrière le bassin pour y plaquer la balle (fermé : nd sur le bassin et ses rebords ; un mur côté départ couperait la gouttière) ; tremplin qui saute dans le bassin (fermé : nd sur la gouttière) ; couper la bouche (même idée, acceptable, c'est un abri plus loin) ; R-b (zone hors vent : fermé par l'abri lui-même, c'est l'idée).
- **Contraintes** : palette S ; encre serrée (un mur de la hauteur du chemin, ≈ 1,2 ×) ; nd partout sauf la bande d'abri ; 1 zone visible avec bouche ; **E3 requise** + rendu d'ombre. Tolérance : tout trait dans la bande, à ±30° de la verticale et assez haut pour couvrir gouttière + bassin.
- **Unique** : premier trait du jeu que la balle ne touche pas et qui change tout.
- **Variante dure** : la bande d'abri est à mi-chemin ; un seul mur ne couvre pas tout ; il faut l'incliner pour que son ombre couvre à la fois la fin de la gouttière et le bassin.

## 54 · La cascade inversée
- **Temps** : Shō 6, **Relais, NIVEAU SPÉCIAL** (machine-récompense). Raison d'être : le vent renvoie ce qu'on lui lance ; puis le grand spectacle de mi-monde.
- **Type** : LANCER À CONTRE-VENT (le boomerang).
- **Vérité** : un vent constant renvoie ce qu'on lui lance ; plus la balle reste en l'air, plus il la ramène.
- **Phrase** : « Lance la balle loin et haut, contre le vent : il te la ramène. »
- **Hypothèse** : H32 (on va vers ce qu'on vise).
- **Leurre** : viser le récepteur, qui est **sous** la corniche de départ, dans une alcôve : tout chemin direct est barré par la corniche ; laisser tomber la balle au bord : la bande la ramène vers la falaise, mais trop bas, sur les pointes sous l'alcôve.
- **Scénario** : sans trait, la balle tombe du bord, revient trop bas et s'empale ; il cherche un chemin vers l'alcôve, la corniche et les nd l'en empêchent ; il voit que la bande ramène tout vers la falaise et que « trop bas » vient d'une chute trop courte ; il trace un tremplin qui lance la balle **vers le haut et le large** : elle s'éloigne, ralentit, revient en courbe et entre dans l'alcôve.
- **Éléments** : corniche de départ en surplomb (PORTER le lancer, FERMER l'accès direct) ; alcôve-récepteur sous la corniche (but) ; bande de vent horizontale vers la falaise, sous la corniche (PORTER le retour) ; pointes sous l'alcôve (PIÉGER : rendent le « trop court » lisible) ; dessous de corniche en pente douce vers l'alcôve (PORTER : un retour trop haut glisse quand même dedans : tolérance) ; la bande couvre tout le large (FERMER le lancer qui échapperait au vent : tout ce qui part revient) ; machine.
- **Raccourcis** : toboggan de la corniche vers l'alcôve (fermé : nd sous la corniche et devant l'alcôve) ; paravent pour tomber droit (fermé : nd sur la bande ; et tomber droit mène aux pointes) ; R-e : seuls les traits montants au bord de la corniche réussissent.
- **Machine « La cascade inversée » (≈ 5,5 s, accélérable)** : la balle, captée dans l'alcôve, ressort au pied d'une grande colonne vitrée (vent caché fort) dont les **plafonds** alternent de gauche à droite, comme des marches renversées ; l'air la plaque sous chaque plafond et elle le parcourt jusqu'à son bout haut, puis remonte au suivant : l'eau descend les marches, la balle les monte. **Chorégraphie** : 1er plafond turquoise (2) : départ lent, on comprend que « ça monte » ; 2e violet (7) ; 3e et 4e blanc-cyan (10) : accélération, le zigzag se resserre ; **apogée** : au sommet, un grand arc (demi-looping lissé) qui la fait jaillir hors de la colonne ; **glissade** extérieure : vague blanc-cyan (10) en deux bosses, demi-tour en épingle violet (7), long ralenti turquoise (2) qui la pose dans la zone en bas. Les rubans de plafond effacent la vitesse d'entrée : déterminisme (les plafonds sont des rubans courbes plaqués par le vent : `curves` avec `v`). La voûte n'est ici que spectacle, jamais l'énigme (§1.3).
- **Contraintes** : palette S ; encre serrée (un tremplin) ; nd sous la corniche, sur la bande, sur la colonne et la glissade ; 1 zone visible + vents cachés ; **rubans v2 courbes requis** (plafonds + glissade). Tolérance du tremplin : de 20 à 60° vers le haut, longueur libre.
- **Unique** : seul niveau où l'on lance la balle à l'opposé de son but ; la plus grande machine avant la finale.
- **Variante dure** : la bande s'arrête à mi-largeur ; lancée trop loin, la balle sort du vent et ne revient plus : il faut un lancer moins long mais plus haut.

## 55 · L'ombre longue  *(E3)*
- **Temps** : Ten 7, Simple. **Retournement** : le vent n'est plus un obstacle local, il attaque tout le parcours ; l'abri près de la balle (53) devient le piège.
- **Type** : ABRITER DE LOIN (l'ombre porte jusqu'au bout du vent).
- **Vérité** : l'ombre d'un mur court jusqu'au bout du vent : on l'abrite de loin, là où il ne gêne pas.
- **Phrase** : « Pose l'abri près de la bouche, loin du chemin : son ombre couvre tout. »
- **Hypothèse** : H14 (ce qui est loin ne compte pas).
- **Leurre** : le paravent du 53 posé contre le chemin : le chemin est un lacet de rampes fixes qui traverse le vent sur toute sa hauteur ; tout écran assez haut posé près du lacet **coupe le lacet**, la balle bute dessus ; un écran court n'abrite qu'un virage et la balle est plaquée au suivant.
- **Scénario** : la balle descend le lacet, le vent latéral la plaque contre un mur de pointes au deuxième virage ; il pose un paravent près du virage, la balle bute dessus ; il en pose un plus court, elle passe ce virage et meurt au suivant ; il regarde d'où vient l'air (la bouche, loin, de l'autre côté de l'écran) ; il pose un seul grand mur près de la bouche, dans le vide : l'ombre couvre tout le lacet, la balle descend dans le calme.
- **Éléments** : lacet de rampes fixes courbes (PORTER le chemin, FERMER le paravent proche : il n'y a pas de place pour un écran sans couper le lacet) ; vent latéral fort sur toute la hauteur du lacet, sortant d'une **bouche visible** à l'autre bout de l'écran (PIÉGER) ; parois à pointes côté sous le vent, à chaque virage (PIÉGER : rendent l'exposition fatale) ; grand espace vide traçable entre le lacet et la bouche (PORTER) ; zone au bas du lacet, adossée (PORTER).
- **Raccourcis** : tube autour du lacet (fermé : encre) ; boucher la bouche avec un trait posé dessus (même idée, acceptable) ; sauter le lacet par un trait direct vers la zone (fermé : nd sur l'espace devant la zone et au-dessus du lacet) ; R-e : un mur au hasard assez long, assez debout et dans l'espace vide : ≤ 1 %.
- **Contraintes** : palette S ; encre serrée (un mur de la hauteur du vent, ≈ 1,2 ×) ; nd sur le lacet et ses abords (40 u) et devant la zone ; 1 zone visible avec bouche ; **E3 requise** ; aucun v2.
- **Unique** : seul niveau où l'on agit à l'autre bout de l'écran, sans que la balle ne passe jamais près du trait.
- **Variante dure** : deux bouches perpendiculaires (une latérale, une descendante) ; un seul trait en équerre, posé dans l'angle mort, doit faire les deux ombres.

## 56 · La vanne  *(E5)*
- **Temps** : Ten 8, Simple. Raison d'être : le vent peut dormir ; la balle elle-même l'allume.
- **Type** : DÉCLENCHER SON RETOUR (aller d'abord au piège apparent).
- **Vérité** : le vent dort tant que la balle n'a pas touché sa vanne ; ton premier passage allume celui qui te ramènera.
- **Phrase** : « Jette la balle au fond du puits : la vanne y réveille le vent. »
- **Hypothèse** : H33 (le fond d'un puits est un échec).
- **Leurre** : conduire la balle droit à la colonne qui mène à la zone : la colonne dort (grille immobile, pas de chevrons) ; la balle reste posée à son pied, sans menace et sans issue.
- **Scénario** : il conduit la balle à la colonne, rien ; il voit le fil de lumière qui relie la grille à une plaque au fond d'un puits, de l'autre côté ; il hésite (un puits, c'est perdre) ; il y envoie la balle : la plaque s'allume, la colonne et un souffle horizontal au fond du puits se réveillent ; le souffle ramène la balle par un tunnel bas jusqu'au pied de la colonne, qui la hisse à la zone.
- **Éléments** : colonne dormante qui mène à la zone (PORTER, et PIÉGER : le leurre est joué par le niveau lui-même au premier lancer, la balle y glisse sans trait) ; puits avec plaque-vanne (PORTER) ; fil de lumière plaque → grille (lecture) ; souffle dormant au fond du puits, vers un tunnel bas qui rejoint la colonne (PORTER le retour) ; zone en haut, adossée (PORTER).
- **Raccourcis** : remonter du puits par un trait (fermé : nd dans le puits et le tunnel) ; atteindre la zone sans la colonne (fermé : hauteur et nd au-dessus de la zone) ; passer sur la plaque sans tomber au fond (impossible : la plaque est au fond, c'est l'idée) ; R-e : la balle ne va au puits qu'avec un déflecteur orienté à l'opposé de la pente naturelle : ≤ 1 %.
- **Contraintes** : palette S ; encre serrée (un déflecteur) ; nd dans le puits, le tunnel, la colonne ; **E5 requise** (vanne à verrou + rendu grille dormante/éveillée + fil) ; si E3, les vents de ce niveau sont enfermés (tunnel, tube) : pas d'ombre utile.
- **Unique** : seul niveau où le vent n'existe pas au départ et où l'échec apparent (le fond du puits) est la clé.
- **Variante dure** : deux vannes ; la première allume un vent qui renvoie la balle vers la seconde ; l'ordre se lit aux fils.

## 57 · Le carrefour
- **Temps** : Ten 9, **Machine-énigme** (ZJ1 → récepteur → machine → ZJ2 préparée d'avance). Raison d'être : lire deux vents ensemble.
- **Type** : LIRE LA SOMME (anticiper une trajectoire sous deux vents croisés).
- **Vérité** : deux vents qui se croisent font un troisième, oblique ; la balle suit leur somme, pas le plus fort.
- **Phrase** : « Là où les vents se croisent, ils s'additionnent : attends-la où leur somme l'envoie. »
- **Hypothèse** : H34 (de deux vents, seul le plus fort compte).
- **Leurre** : poser le receveur là où le **vent fort seul** emmènerait la balle (ou dans l'axe du bec, comme sans vent) : la balle passe dans le carré de croisement, oblique, et tombe ailleurs, sur les pointes.
- **Scénario** : il réussit la ZJ1 (un déflecteur vers le récepteur) ; il voit le bec de la machine et les deux bandes croisées (chevrons de forces lisibles, E0) ; il pose le receveur sous le vent fort ; la machine tire, la balle traverse le croisement et part en diagonale ; il comprend que les deux vents agissent ensemble ; il pose le receveur dans la fenêtre calme où la diagonale la mène.
- **Éléments** : ZJ1 simple (PORTER : amener au récepteur, raison de jouer d'abord) ; machine : ascenseur en spirale de rubans courbes (7 puis 10) jusqu'à un **bec** qui lâche la balle toujours pareil (PORTER, déterminisme) ; bande horizontale et bande verticale qui se croisent (PIÉGER la lecture simple, PORTER la bonne) ; fenêtres calmes entre les bandes, seules zones traçables de la ZJ2 (FERMER « attendre partout ») ; pointes au sol hors de la gouttière (PIÉGER) ; gouttière fixe vers la zone (PORTER : le receveur n'a qu'à y verser la balle).
- **Raccourcis** : tracer dans les bandes (fermé : nd ; et sous E3 un trait dans le vent changerait le champ) ; essai-erreur (un lancer montre la trajectoire : accepté, c'est la limite connue d'une machine-énigme ; la fenêtre juste n'est pas sur le chemin vu au premier tir si le leurre est posé, parce qu'il l'intercepte plus tôt : le joueur doit **retirer** son receveur et raisonner) ; R-e : une seule fenêtre mène à la gouttière.
- **Machine (≈ 3,5 s)** : récepteur → spirale montante (violet 7 lent, puis blanc-cyan 10 dans le dernier tour : accélération) → bec : la balle **suspendue** une demi-seconde au sommet d'un petit arc (apogée) puis lâchée dans le carrefour ; trajectoire en S (vent seul, somme, vent seul) : c'est le spectacle et l'énigme à la fois.
- **Contraintes** : palette S ; encre : ZJ1 + un receveur (≈ 1,3 ×) ; nd sur les bandes, la machine, l'axe du bec ; 2 zones de vent visibles qui se chevauchent ; **E0 requise** (force lisible) ; rubans v2 dans la spirale.
- **Unique** : seul niveau où deux vents agissent au même endroit et où la lecture précède le geste.
- **Variante dure** : trois bandes ; la balle traverse deux croisements de sommes différentes ; une seule fenêtre est atteinte.

## 58 · Les deux bouches
- **Temps** : Ketsu 10, **Deux actes** (ZJ1 → deux récepteurs → deux machines → ZJ2 → zone). Raison d'être : refuser le chemin que le vent offre.
- **Type** : CHOISIR SON RELAIS (lire la suite avant de jouer).
- **Vérité** : le vent offre toujours un chemin ; on choisit son relais en lisant où chaque machine dépose la balle.
- **Phrase** : « Le vent t'offre la bouche facile : lis où elle mène, prends l'autre. »
- **Hypothèses** : H35 (le chemin que le vent propose est le bon) et H18 (le relais le plus proche est le bon).
- **Leurre** : laisser la bande porter la balle à la **bouche A**, sous le vent, sans effort : la machine A la dépose dans un puits à colonne où elle **danse** sans fin (prison silencieuse, visible dès le départ).
- **Scénario** : sans trait, la balle file dans la bouche A, la machine l'emporte, elle danse dans le puits ; il comprend que la bouche facile mène au puits ; il regarde l'autre machine : la bouche B, au vent, dépose la balle près d'une colonne étroite et de la zone ; pour l'atteindre, il faut traverser la bande **vite** (50) ; il trace une plongée vers B **et**, avant de lâcher, la butée de l'acte 2 dans la colonne (51).
- **Éléments** : bande latérale qui pousse vers A (PORTER le leurre) ; bouche A sous le vent (PIÉGER : la facilité) ; machine A → puits dansant (PIÉGER, lisible, sans mort) ; bouche B au vent (but de l'acte 1) ; machine B : tube pneumatique en S (FERMER : montre l'espace de l'acte 2 pendant le trajet, fonction « transition ») ; acte 2 : colonne étroite, zone au-dessus (PORTER) ; encre partagée entre les deux actes (FERMER : pas d'encre pour un pont dans l'acte 2).
- **Raccourcis** : atteindre l'espace de l'acte 2 sans machine (fermé : parois, nd) ; tracer l'acte 2 après la machine (impossible : tracé avant le lâcher, comme toute machine-énigme, §3.5) ; un paravent devant B (si E3 : fermé par nd sur la bande) ; une butée verticale qui sert aussi d'acte 1 (non : deux lieux séparés).
- **Machines** : A (≈ 2 s) : glissade courte et douce, violet → turquoise, puis chute lente dans le puits, la danse commence (pas de mort : c'est une impasse lisible) ; B (≈ 3 s) : tube pneumatique (tunnel courbe dont la paroi extérieure est un ruban blanc-cyan 10), une boucle en S au-dessus de l'acte 2, sortie turquoise (2) au bord de la colonne.
- **Contraintes** : palette S ; encre calculée (plongée + butée, ≈ 1,2 ×, insuffisante pour un pont dans l'acte 2) ; nd sur les machines, le puits, la bande au voisinage de B ; 1 bande + 1 colonne visibles + vents cachés ; rubans v2 dans les machines.
- **Unique** : seul niveau où le premier choix est une destination, pas un geste.
- **Variante dure** : la bouche B n'est atteignable que par le boomerang du 54 (lancer contre la bande), et l'acte 2 demande l'abri du 53.

## 59 · La girouette  *(E1)*
- **Temps** : Ketsu 11, Simple, **moment unique**. Raison d'être : le seul niveau où l'air change avec le temps.
- **Type** : PATIENTER (tenir la balle jusqu'au bon souffle).
- **Vérité** : le vent tourne : tiens la balle contre un mur, et attends le souffle qui la porte.
- **Phrase** : « Tiens la balle contre un mur et laisse le vent tourner. »
- **Hypothèse** : H36 (le vent reste le même du début à la fin).
- **Leurre** : précipiter la balle vers le pied de la falaise (sous la corniche-zone) : elle y arrive pendant le long souffle latéral, qui l'emporte aux pointes ; la courte bouffée montante ne vient que plus tard, sur une place vide.
- **Scénario** : il envoie la balle sous la corniche, le vent latéral la jette aux pointes ; il remarque la girouette et les chevrons qui, toutes les cinq secondes, se redressent un instant vers le haut ; il comprend qu'il faut être là au bon moment, sans pouvoir viser l'instant ; il dresse un mur debout sous la corniche, côté pointes : la balle y est plaquée pendant le souffle latéral, puis la bouffée montante la hisse le long du mur jusqu'à la corniche.
- **Éléments** : vent cyclique : long souffle latéral (≈ 4 s, vers les pointes) puis bouffée montante courte (≈ 0,8 s), annoncée 0,5 s avant par la girouette (PORTER et PIÉGER à la fois) ; pointes sous le vent (PIÉGER : le mauvais moment est fatal et lisible) ; corniche-zone en haut, adossée, hors du vent (PORTER) ; hotte courbe au-dessus de la corniche (PORTER : verse la balle montante sur la corniche) ; sol plat sous la corniche (PORTER le mur).
- **Raccourcis** : arriver pile pendant la bouffée (fermé : bouffée courte, chemin naturel qui arrive pendant le souffle latéral ; probabilité au hasard ≤ 0,5 %) ; berceau horizontal (sans E3 : même idée, tenir puis lâcher, acceptable ; avec E3 : le fond du berceau éteint la bouffée, échec lisible, c'est pourquoi le mur doit être debout : un mur vertical ne fait pas d'ombre vers le haut) ; voûte R-d pendant la bouffée (fermé : nd au-dessus de la hauteur du mur) ; R-e : un mur au hasard sous la corniche et assez debout : ≤ 0,5 %.
- **Contraintes** : palette S ; encre serrée (un mur court) ; nd sur la corniche, au-dessus de 1/2 hauteur, autour des pointes ; 1 zone visible **cyclique** ; **E1 requise** (phases + transition douce + girouette + annonce). La bouffée se répète : jamais de minuteur, la balle tenue attend sans risque.
- **Unique** : seul niveau où le temps change l'air ; la patience y est la solution, et le temps est offert, jamais compté.
- **Variante dure** : trois phases (latéral, montant, latéral inverse) ; le mur doit avoir un retour en crochet pour tenir la balle dans les deux souffles latéraux.

## 60 · Le cyclone
- **Temps** : Ketsu 12, **Finale, NIVEAU SPÉCIAL** (ZJ → récepteur → grande machine → zone). **Rappel renversé du 49** : au 49 le vent emmène la balle au but ; ici il la garde pour toujours, il faut l'en arracher.
- **Type** : ARRACHER (sortir du courant par la tangente).
- **Vérité** : on n'arrête pas un tourbillon : on lui prend la balle d'un trait tangent à sa course.
- **Phrase** : « Ne barre pas le cyclone : glisse une lame le long de sa course. »
- **Hypothèse** : H37 (pour arrêter ce qui tourne, il faut lui barrer la route).
- **Leurre** : un mur en travers de l'anneau : la balle le heurte, rebondit en arrière, les quatre souffles la freinent puis la relancent dans le sens d'origine ; elle retourne contre le mur et tourne de l'autre côté de lui, prisonnière d'un demi-anneau.
- **Scénario** : la balle tombe dans le cyclone et tourne sans fin (le tip du jeu actuel le dit déjà) ; il barre l'anneau, elle rebondit et se fait reprendre ; il essaie un mur plus long, même prison ; il comprend que la vitesse ne se combat pas, elle se détourne ; il trace une lame courte, presque tangente, à l'endroit où l'anneau s'ouvre vers le récepteur : la balle la prend comme un aiguillage et sort en glissant.
- **Éléments** : départ au-dessus du cyclone (PORTER : la chute amène dans l'anneau) ; anneau courbe + quatre bandes tangentes cachées (dessin `vortex`) (PIÉGER : la prison, PORTER : la vitesse qui servira à sortir) ; brèche de l'anneau vers un grand récepteur en entonnoir (PORTER la sortie) ; tout le reste de l'anneau sans issue (FERMER les sorties au hasard) ; grande machine (PORTER, spectacle, résumé du monde).
- **Raccourcis** : empêcher la balle d'entrer dans le cyclone (fermé : chute directe, nd au-dessus de l'anneau) ; une lame non tangente (fait rebondir, échec lisible ; tolérance ± 25° sur un quart d'anneau) ; R-e : un trait au hasard qui coupe l'anneau dans le bon quart et dans le bon angle : ≤ 0,5 % ; voûte R-d dans les bandes cachées (fermé : nd sur tout le cyclone sauf le quart de sortie).
- **Grande machine (≈ 6 s, accélérable) : chorégraphie** : récepteur (ralenti turquoise 2, la balle « respire ») → **tube pneumatique** en spirale montante (ruban blanc-cyan 10 sur la paroi extérieure) : accélération, deux tours serrés ; **apogée** : la balle jaillit du tube dans une colonne où elle **danse trois fois** (rappel du 49 et de la prison du 58), un souffle latéral caché la prend au troisième rebond ; **trois parachutes** : chute lente à travers trois coussins d'air de plus en plus bas, chaque coussin freine sans arrêter (ralentis successifs, effet cascade) ; **glissade finale** en vague : blanc-cyan 10, violet 7, demi-tour en épingle, turquoise 2, ambre 0 juste avant la zone : la balle finit à l'arrêt, au milieu de la zone dégagée. Dernière image : premier décor du monde 6 (Mécanique). Déterminisme : chaque étage commence par un ruban qui efface la vitesse d'entrée.
- **Contraintes** : palette S ; encre très serrée (une lame ≈ 60 u) ; nd sur tout le cyclone sauf le quart de sortie, sur le récepteur et la machine ; vents cachés seulement (aucun vent visible hors dessin du cyclone) ; **rubans v2 courbes requis** ; si E3 : les vents cachés n'ont pas d'ombre, la lame n'éteint rien.
- **Unique** : seul niveau où la balle ne peut pas perdre et ne peut pas gagner sans l'idée ; seule machine qui montre tous les vents du monde (colonne, danse, coussins, tourbillon) et les quatre couleurs.
- **Variante dure** : deux cyclones imbriqués tournant en sens contraires ; la lame du premier doit verser la balle dans le second **dans son sens**, puis une seconde lame l'en sort.

---

## Auto-critique (une ligne par niveau, honnête)
- **49** : risque de P_hasard élevé (beaucoup de traits renvoient vers la colonne) ; la fenêtre basse et la pente à l'opposé le réduisent. Faible en eurêka : c'est son rôle.
- **50** : le leurre (« poser doucement ») suppose un geste prudent ; un joueur qui trace d'emblée un pont haut réussit au premier essai. La couche doit être bien lisible comme danger.
- **51** : très proche du 52 actuel (« Colonne étroite ») ; le contraste avec 49–50 fait l'intérêt. Risque physique : la butée doit guider la montée sans que la balle reste collée (frottement de contact .995).
- **52** : dépend du rapport ruban/vent (0,62 contre 0,3) et de l'arrivée à 7 dans une niche courte ; à mesurer.
- **53** : l'eurêka repose entièrement sur le rendu de l'ombre ; sans chevrons éteints, c'est un mur posé au hasard. Parent proche du 55 (même outil) : les deux se distinguent par le **lieu** (près / loin), à juger par Simon.
- **54** : la tolérance du boomerang est à prouver ; le dessous de corniche en pente doit absorber les retours trop hauts. La voûte de la cascade frôle le monde 7, assumée comme spectacle seulement.
- **55** : le plus fort du monde si E3 est lisible ; risque : un joueur qui a compris le 53 pose l'abri loin d'emblée (pas d'impasse). Le lacet doit rendre le paravent proche vraiment tentant.
- **56** : énigme « interrupteur », genre connu ; elle tient par H33 (le puits fait peur). Dépend d'E5.
- **57** : comme toute machine-énigme, résoluble par observation en deux lancers ; la fenêtre unique et l'interception du leurre le retardent un peu, pas plus.
- **58** : réutilise 50 et 51 (c'est la règle des deux actes) ; l'idée neuve, le choix du relais, ne vaut que si le puits dansant est visible avant le premier lancer.
- **59** : le plus original ; dépend d'E1 et de l'annonce visuelle de la bouffée. Risque de lecture « minuteur » : la répétition sans fin et la balle tenue sans danger doivent le démentir.
- **60** : le cœur (la lame) est validé par Simon ; la tolérance actuelle de la lame est trop fine (21 u dans `optsol`) : il faut un quart d'anneau de sortie et ± 25°.
- **Écarts au gabarit** : la Machine-énigme est au 57 (position 9) et non au 56, à la demande de Simon ; 56 est donc Simple. Proportion : 7 Simples (49, 50, 52, 53, 55, 56, 59 ; cible 5–6, un de trop, accepté parce que 59 est un moment unique), 2 Relais (51, 54), 1 Machine-énigme (57), 1 Deux actes (58), 1 Finale (60).

## Tableau récapitulatif
| N | Titre | Type de raisonnement | Hypothèse | Vent utilisé | Spécial / machine | Risque de construction |
|---|---|---|---|---|---|---|
| 49 | Le souffle | Déposer | H27 | colonne + hotte | — | faible |
| 50 | La couche | Traverser vite | H28 | couche latérale | — | faible |
| 51 | L'ascenseur | S'attarder | H29 | colonne étroite | Relais (révélation : ascenseur + glissade) | moyen (butée, montée) |
| 52 | Ramer | Motoriser | H30 | vent de face long + ruban | — | faible à moyen |
| 53 | Le paravent | Abriter | H31 | vent latéral + ombre | — | **E3** + rendu |
| 54 | La cascade inversée | Lancer à contre-vent | H32 | bande de retour + colonne cachée | **SPÉCIAL** : machine cascade | moyen (tolérance boomerang, plafonds-rubans) |
| 55 | L'ombre longue | Abriter de loin | H14 | vent latéral à bouche + ombre | — | **E3** + rendu |
| 56 | La vanne | Déclencher son retour | H33 | vents dormants (colonne, souffle) | — | **E5** |
| 57 | Le carrefour | Lire la somme | H34 | deux bandes croisées | **Machine-énigme** | moyen (E0, lisibilité) |
| 58 | Les deux bouches | Choisir son relais | H35 / H18 | bande + colonne + danse | Deux actes, 2 machines | moyen (2 machines) |
| 59 | La girouette | Patienter | H36 | vent cyclique | moment unique | **E1** |
| 60 | Le cyclone | Arracher | H37 | tourbillon (4 bandes cachées) | **SPÉCIAL** : Finale, grande machine | moyen à fort (machine longue, tolérance de lame) |

Hors du schéma « une rampe vers la zone » : tous ; aucun type de raisonnement ne se répète, ni avec les fiches des mondes 1, 3 et 7.

## Extensions moteur (de la plus petite à la plus lourde)
- **E0 · Lisibilité du vent (rendu seul, très petite)** : vitesse et densité des chevrons proportionnelles à la force ; bouche (grille) dessinée sur le bord amont d'une zone (`src:1`). Requise : 57 ; utile partout (53, 55).
- **E1 · Vent cyclique (petite)** : `cyc:[[ax,ay,durée],…]` ; force en fonction de `S.t` depuis le lâcher (déterministe, retour arrière sans état) ; transition douce ≈ 12 trames ; rendu : chevrons qui tournent, girouette, annonce 0,5 s avant chaque changement. Requise : 59.
- **E5 · Vanne (petite à moyenne)** : zone dormante `on:[x,y,l,h]` qui s'allume (verrou) quand la balle entre dans le rectangle de déclenchement ; état remis à zéro au lâcher (comme `S.coilOn`) ; rendu grille immobile / éveillée et fil de lumière plaque → bouche. À vérifier : affichage pendant le retour arrière (`S.rec`). Requise : 56.
- **E3 · Ombre de vent (moyenne, la signature du monde)** : pour chaque zone visible, rayon tiré du centre de la balle **à contre-vent** jusqu'au bord amont de la zone ; s'il coupe un segment (murs, traits, pièces mobiles, portes fermées ; pas les cordes), la zone n'agit pas. Murs du niveau marqués `grille` transparents au vent ; vents cachés des machines sans ombre. Coût : zones × segments × sous-pas (faible). Rendu : chevrons masqués dans l'ombre + voile d'ombre translucide (la partie la plus lourde). Requise : 53, 55 ; change 51 et 59 (déjà prévus) ; **revérifier 49, 50, 52, 54, 57 sous E3** (raccourci R-f).
- **Non requises (pour mémoire)** : tourbillon de champ (force tangentielle + rappel radial) : inutile, le cyclone natif suffit ; **vent dévié par les murs** (écoulement qui longe un trait) : lourd, peu lisible, à ne pas faire ; vent sur des voiles (cordes) : réservé au monde 10.

## Ordre de construction recommandé (les plus sûrs d'abord)
0. **Décision D1** (E3 globale ou non) avant tout : elle fixe les nd de 49, 50, 52, 54, 57.
1. **49, 50, 52** : natifs, une zone, physique connue.
2. **51** : natif ; prouver la montée le long de la butée ; machine courte (révélation).
3. **60** : natif, cœur déjà validé ; élargir la tolérance de la lame d'abord, la grande machine ensuite.
4. **54** : natif ; prouver la tolérance du boomerang avant de construire la cascade (plafonds en rubans courbes plaqués par le vent).
5. **57** (après E0) puis **58** : machines déterministes, lecture.
6. **59** (après E1).
7. **56** (après E5).
8. **53, 55** (après E3 et son rendu), puis rejouer 49–60 sous E3.

## Faisabilité : rechanges si une extension est refusée
- **Sans E3 (53, 55)** : 53 → « La danse » (natif) : la balle danse au sommet d'une colonne sans pouvoir en sortir ; il faut l'y faire entrer de biais, par un déflecteur oblique au pied, pour que sa danse la dépose sur la corniche (vérité : le vent garde la direction qu'on lui confie, il n'en crée pas). 55 → « Les vents contraires » (natif) : deux bandes opposées s'annulent dans leur chevauchement ; le seul passage vers la zone est cette bande calme, qu'il faut trouver et viser (vérité : deux vents contraires font un calme). Attention : proche du 57 (somme) ; à départager.
- **Sans E5 (56)** : « Le puits qui ramène » : même puits, même H33, mais le souffle du fond est toujours allumé (l'idée « se jeter au fond » demeure, l'interrupteur disparaît).
- **Sans E1 (59)** : pas de rechange fidèle (le temps est l'idée) ; remplacer par « La danse » si elle n'est pas déjà prise au 53.
- **Risques physiques à mesurer d'abord** : montée le long d'une butée (51) ; ruban contre vent de face et arrêt dans la niche (52) ; tolérance du boomerang (54) ; plafonds-rubans plaqués (54) ; sortie par la lame sur un quart d'anneau (60).
