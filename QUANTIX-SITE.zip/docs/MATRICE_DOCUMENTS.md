# QUANTIX — Matrice de cohérence des documents (R262, 22 octobre 2026)

*Inventaire fait le 22 oct. sur `docs/` du zip R261 (65 entrées) et le Projet claude.ai (52 documents). Sert de trace de la
refonte ; ne pas relire au démarrage d'une session.*

## Problèmes constatés

| # | Problème | Effet |
|---|---|---|
| P1 | Les instructions imposaient de lire en entier `REPRISE-SESSION.md` (141 Ko), `PASSATION_R232` (9,5 Ko), `CHARTE_EXIGENCES` (12,8 Ko) et `LEXIQUE` (9,3 Ko) | ≈ 45 000 jetons relus avant chaque tâche |
| P2 | Quatre « prompts » concurrents : `PROJET-PROMPT.md` (R115), `PROJET-PROMPT-R36-archive.md`, `INSTRUCTIONS_PROJET.md` (R232), `CONSIGNES_SIMON.md` (R122) | consignes contradictoires selon le fichier ouvert |
| P3 | `REPRISE-SESSION.md` empilait 13 blocs « ÉTAT AU Rxxx » (R249 → R260) au‑dessus des sections utiles, puis un journal de 120 Ko | l'état courant noyé dans l'historique |
| P4 | Phrase d'ouverture de `REPRISE-SESSION` §1 : « tampon R232 » alors que l'état était R260 ; `REPRISE.md` (ancien) et `archive_REPRISE-SESSION-R121.md` portaient aussi le nom « reprise » | risque de travailler sur un mauvais zip |
| P5 | `METHODE.md` §4 interdit « calcul en arrière‑plan », les instructions R232 interdisent « calcul parallèle » ; `METHODE` §2 demande « 15 minutes de lecture » | règles d'économie floues, lecture longue imposée |
| P6 | Règles dispersées : charte (A–J), méthode (§3–§6), instructions (règles techniques), passation (§1), reprise (§7 pièges) — en partie recopiées | duplications qui divergent |
| P7 | Une vingtaine de documents périmés (R29 → R116) restaient dans le Projet sans marque d'archive | la recherche du Projet les remonte |
| P8 | Aucune règle de communication pendant un long travail | session de 25 min sans message (22 oct.) |

## Matrice

Actions : **NOUVEAU**, **REFONDU**, **GARDÉ** (référence, inchangé), **FUSIONNÉ** (contenu repris ailleurs, original archivé),
**ARCHIVÉ** (déplacé dans `docs/archive/`, retiré du Projet).

| Fichier | Rôle avant | Action | Où va le contenu |
|---|---|---|---|
| `INSTRUCTIONS_PROJET.md` | prompt R232 | **REFONDU** | prompt maître court |
| — | — | **NOUVEAU** `ETAT.md` | source de vérité unique : version, prochain lot, décisions, mondes, liens |
| — | — | **NOUVEAU** `REGLES.md` | charte A–J + méthode + passation §1 + règles techniques |
| — | — | **NOUVEAU** `TECHNIQUE.md` | fichiers, systèmes, commandes, pièges, architecture Quantone et fin |
| — | — | **NOUVEAU** `JOURNAL.md` | historique R122 → R261, blocs ÉTAT anciens |
| `INDEX_DOCUMENTS.md` | index | FUSIONNÉ → **NOUVEAU** `INDEX.md` | index par sujet |
| `REPRISE-SESSION.md` | état + journal | FUSIONNÉ | `ETAT.md`, `TECHNIQUE.md`, `JOURNAL.md` |
| `CHARTE_EXIGENCES.md` | exigences | FUSIONNÉ | `REGLES.md` §A–§J |
| `METHODE.md` | méthode | FUSIONNÉ | `REGLES.md` §K–§M |
| `PASSATION_R232.md` | passation | FUSIONNÉ | `REGLES.md` §L (règles), `TECHNIQUE.md` (fin, Quantone, vibrations) |
| `LEXIQUE.md` | vocabulaire | GARDÉ | — |
| `A_VERIFIER.md` | liste de Simon | GARDÉ | — |
| `AUDIT_R209.md` | état des lieux | GARDÉ (référence datée) | — |
| `NARRATION.md`, `MONDE11_MOTEUR.md`, `TEXTURE_MAGNETISME.md`, `VIBRATIONS.md`, `SON_MONDES.md`, `SOUND_DESIGN_PROTOCOL.md`, `MENU_EDITION.md` (généré), `HANDBOOK.md`, `CAHIER_DES_CHARGES_GENERATION.md`, `ANNEXE_DESIGN_JONCTIONS.md`, `QUANTUM_VISUAL_NARRATIVE.md`, `PISTES_TRAVERSABLES.md`, `DIDACTICIEL_DESIGN.md`, `BIBLE_ENIGMES.md`, `ENIGME_PROTOCOL.md`, `DIFFICULTY_PROTOCOL.md`, `ENGAGEMENT-ET-MONETISATION.md`, `MONDE1_FICHES.md`, `MONDE7_FICHES.md` | références par sujet | GARDÉ | — |
| `PROJET-PROMPT.md`, `PROJET-PROMPT-R36-archive.md`, `CONSIGNES_SIMON.md`, `REPRISE.md`, `archive_REPRISE-SESSION-R121.md`, `TACHES.md` | anciens prompts et reprises | ARCHIVÉ | remplacés |
| `AUDIT-R29.md`, `AUDIT_R52.md`, `AUDIT_METHODE.md`, `ANALYSE_R116.md`, `ETAT_REFONTE_NIVEAUX.md`, `TRIAGE_R73.md`, `FINITION.md`, `FINITION_R91.md`, `BYPASS-RAPPORT.md`, `bypass-mondes-2-5.txt`, `REDUNDANCY_ANALYSIS.md`, `AUDIT_CONTOURNEMENTS.md`, `AUDIT_DIDACTICIEL.md`, `AUDIT_INTERFACE.md`, `AUDIT_ESPACE_JEU.md` | audits et mesures datés | ARCHIVÉ | conclusions dans `AUDIT_R209.md` |
| `CAHIER_DES_CHARGES_R39.md`, `CAHIER_DES_CHARGES_NIVEAUX.md`, `REPONSES_R38.md`, `MASTER_LEVEL_DESIGN_PROTOCOL.md`, `LEVEL_DESIGN_CANVAS.md`, `SCENARIO_PROTOCOL.md`, `DRAMATURGY_FRAMEWORK.md`, `PLAYTEST_PROTOCOL.md`, `PROTOCOLE.md`, `REFERENCE_DESIGN_ENIGMES.md`, `WORLD_IDENTITY_FRAMEWORK.md` | anciens protocoles R30–R97 | ARCHIVÉ | bibliothèque ; l'actif est dans `REGLES.md` et `BIBLE_ENIGMES.md` |
| Projet seulement : `FINALE_R213.md`, `FINALE_FIL.md`, `AUDIT_HEROS_FIN.md`, `FIN_DEUX_PLANS.md`, `redundancy.js` | travail de la fin (validée R233) | ARCHIVÉ | copie dans `docs/archive/` |
