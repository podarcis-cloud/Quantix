# QUANTIX — Audit R52 : son, navigation, modes annexes

*Établi à partir de mesures (inventaire du code, des niveaux, captures Chromium) et des retours de Simon.
Ce document fixe les objectifs avant de refaire le son : rien n'est encore construit d'après lui, sauf les correctifs
listés au §4.*

---

## 1. Audit du son (multicouche)

### 1.1 Couche technique — ce qui est cassé

| Constat | Cause trouvée | Statut |
|---|---|---|
| Craquements dans la musique, surtout au niveau 8 | (a) le « ducking » de R50 annulait une automation de volume en cours → saut de gain = **clic** à chaque effet ; (b) le niveau 8 est le plus lourd à dessiner : sur téléphone, un processeur saturé fait décrocher l'audio ; (c) réverbération de 3 s, coûteuse | (a) **corrigé R52** (maintien de la valeur au lieu d'annuler) ; (b) texture allégée ; (c) réverbération ramenée à 2,4 s. **À confirmer sur iPhone.** |
| Saturation à l'empilement des sons (R49) | plusieurs effets + musique sans marge | limiteur ajouté en R49 ; crête mesurée 0,46 en jeu rejoué |
| Effets durs à distinguer de la musique | même échelle, mêmes timbres de cloche, même réverbération | partiellement traité R50 (effets plus secs) — **à refaire par la bible ci‑dessous** |

### 1.2 Couche de couverture — ce qui n'a pas de son du tout

Inventaire des 132 niveaux : **la moitié des mécaniques sont muettes.**

| Élément | Mondes | Son aujourd'hui |
|---|---|---|
| Structure (mur) | tous | impact générique |
| Rebond | 2 (+8 autres) | impact générique, version FM |
| Pointes | tous | impact générique rouge |
| Tapis d'élan | 3, 10 | un seul « souffle » |
| Glace | 4 | `impact_ice` |
| Corde | 10 | `rope_hit` |
| Vent | 5, 9, 10 | **aucun** |
| Gravité locale | 7 | **aucun** |
| Aimant | 8, 10 | **aucun** |
| Portail | 9 | `portal` |
| Paroi mobile | 6, 11 | **aucun** |
| Intrication / portes | 11 | **aucun** |
| Superposition | 11 | **aucun** |
| Détecteur | 11 | **aucun** |
| Dilatation du temps | 11 | **aucun** |
| Corps mou | 10 | **aucun** |
| Noyau (bonus) | tous | `star_collect`, identique partout |
| Zone (arrivée) | tous | trou noir (R50), identique partout |

### 1.3 Couche perceptive — règles d'écoute à respecter

1. **Répartition des fréquences.** La musique occupe le médium‑grave (150–600 Hz : nappe, thème). Les effets doivent vivre
   **ailleurs** :
   - les impacts dans le grave‑médium **avec une attaque nette mais douce** (2–8 ms de souffle de marteau feutré) ;
   - les éléments de monde dans **leur propre bande**, avec un timbre que la musique n'utilise jamais.
2. **Hauteur.** Aucune note au‑dessus de 1 kHz (règle R45) ; les « surprises » passent par le **timbre et l'espace**
   (stéréo, écho, filtre), jamais par l'aigu.
3. **Niveau.** Crête < 0,5 en jeu ; un effet ne dépasse pas la musique de plus de 6 dB ; ducking de la musique −4 dB
   pendant 300 ms, sans clic.
4. **Densité.** 12 voix d'effet au plus ; un élément continu (vent, aimant) est **une seule boucle** dont on module le
   volume, jamais une suite de déclenchements.
5. **Distinction.** Sec et proche pour les effets (peu de réverbération), large et lointain pour la musique.

### 1.4 Couche esthétique — le registre visé

« Subtil, discret mais surprenant, une invitation au voyage cosmique dans le monde quantique. »
- **Matières de référence** : verre frotté, fil tendu pincé, goutte dans un tube, bande magnétique ralentie, souffle dans
  un tuyau, résonance d'une plaque, grains (micro‑sons), radio lointaine.
- **Geste de signature** : chaque son a **une seconde vie** — une queue lointaine, très basse, qui part dans l'espace
  (écho filtré). C'est elle qui « fait voyager », pas le volume.
- **Interdits** : bips, clics secs, aigus perçants, grosses caisses, sons « jeu vidéo » réalistes.

### 1.5 Couche identitaire — un pool par monde

Chaque monde a **sa matière sonore**, reprise par tous ses effets (impacts, bonus, arrivée) :

| Monde | Matière | Couleur |
|---|---|---|
| 1 Atelier | bois clair et verre (piano feutré, cloche de verre) | mi mineur, sec |
| 2 Fonderie | métal chaud, braise (plaque frappée, crépitement doux) | la dorien, grave |
| 3 Chaîne | impulsions électriques (pouls filtrés, « tic » d'horloge feutré) | sol, régulier |
| 4 Glacier | cristal, givre (frottement de verre, craquement très doux) | quintes, aéré |
| 5 Soufflerie | tubes et souffles (flûte de pan, tuyaux) | ré, ouvert |
| 6 Mécanique | rouages feutrés (cliquet de boîte à musique) | fa, régulier |
| 7 Gravité | masses lentes (gong grave, glissando lent) | do, grave |
| 8 Magnétisme | bourdonnement, fer, ferrofluide (souffle granuleux, sinusoïde battante) | la bémol, tendu |
| 9 Faille | radio, déphasage (filtres en peigne, voix de bande) | mi bémol, flottant |
| 10 Filaments | cordes pincées et frottées (corde de harpe, archet) | fa dièse, élastique |
| 11 Quantique | interférences (deux sons proches qui battent, apparitions/disparitions) | mi, mouvant |

### 1.6 La bible — un son par événement, par obstacle et par bonus

Format : **événement → sample idéal (description) → synthèse proposée → réglages**. Hauteurs dans l'échelle du monde.

**Communs à tous les mondes (déclinés par la matière du monde, §1.5)**
| Événement | Sample idéal | Synthèse | Réglages |
|---|---|---|---|
| Toucher l'interface | goutte minuscule sur une vitre | 1 grain filtré + sinus 2 ms | −30 dB, sec |
| Tracer | crissement très doux d'une pointe sur du verre, continu | une boucle de bruit filtré dont le volume suit la vitesse du doigt | −34 dB |
| Lâcher | inspiration avant le saut | souffle qui monte 0,4 s + grave doux | −22 dB |
| Choc sur un mur | marteau feutré sur une lame de bois | piano préparé, matière du monde | −24 dB, note tournante |
| Noyau (bonus) | trois notes de verre qui s'allument comme des étoiles | arpège de cloches, **queue lointaine** | −22 dB |
| Arrivée dans la zone | aspiration par un trou noir | souffle qui se referme + grave qui plonge (R50) | −18 dB |
| Réussite | la zone se referme, résonance cosmique | accord lent qui monte + éclats granulaires | −20 dB |
| Échec | ralenti de bande | note qui s'effondre (R49) | −22 dB |
| Retour dans le temps | bande rembobinée | grains inversés + filtre qui remonte | −26 dB |

**Obstacles et éléments — chacun son sample**
| Élément | Sample idéal | Synthèse proposée | Type |
|---|---|---|---|
| Rebond | ressort de plaque qui rend l'énergie : « boïng » feutré qui monte | cloche FM + glissando montant d'une quinte | déclenché |
| Pointes | piqûre étouffée, souffle qui se coupe | grave dissonant bref + bruit coupé net | déclenché |
| Tapis d'élan | courroie qui accélère | pouls réguliers dont la cadence monte pendant le contact | boucle pendant le contact |
| Glace | frottement de verre mouillé | sinus pur légèrement battant, aucun choc | boucle pendant le contact |
| Corde | corde de harpe grave pincée | Karplus‑Strong filtré | déclenché |
| Vent | souffle dans un tube | bruit filtré bande étroite, panoramique qui suit la balle | boucle dans la zone |
| Gravité locale | descente/montée d'une sirène lointaine très lente (pas stridente) | sinus grave qui glisse selon le sens de la gravité | boucle dans la zone |
| Aimant | bourdonnement d'un transformateur, très doux | deux sinus graves qui battent, battement plus rapide quand la balle approche | boucle selon la distance |
| Portail | bulle aspirée puis recrachée | souffle qui se ferme + écho qui ressort de l'autre côté (panoramique) | déclenché ×2 |
| Paroi mobile | souffle régulier d'un soufflet | bruit filtré lent, volume suivant le mouvement | boucle de fond, locale |
| Intrication | deux notes identiques jouées aux deux noyaux | une note, deux panoramiques | déclenché |
| Portes | lame de verre qui coulisse | cloche + filtre qui s'ouvre/se ferme | déclenché |
| Superposition | le son se dédouble | la musique et les effets passent en chorus ×2 tant que la balle est dédoublée | état |
| Détecteur | déclic de mesure, presque inaudible, puis silence | grain + coupure brève de la réverbération | déclenché |
| Dilatation du temps | tout ralentit | filtre passe‑bas + hauteur −2 demi‑tons sur la musique dans la zone | état |
| Corps mou | gélatine | piano préparé filtré, déclin très court, légère modulation | déclenché |

### 1.7 Objectifs mesurables de la refonte

1. **Couverture 100 %** : chaque élément du tableau 1.6 a son son ; test automatique qui vérifie qu'aucun élément présent
   dans un niveau n'est muet.
2. **Crête < 0,5** et **musique audible sous les effets** (écart ≤ 6 dB) sur les 132 niveaux rejoués.
3. **Distinction** : les effets ont leur énergie hors de 150–600 Hz ou une attaque que la musique n'a pas.
4. **Pas de clic** : aucune variation de gain plus rapide que 5 ms ; pas plus d'une boucle par élément.
5. **Écoute par Simon** monde par monde : aucune mesure ne remplace ce jugement.

---

## 2. Audit du menu après un niveau

| Situation | Boutons aujourd'hui | Problème | Proposition |
|---|---|---|---|
| Réussite | À moi de jouer / Revoir ma partie / Continuer (+ Solution optimale) | trois boutons pleine largeur : « Continuer », l'action attendue, n'est **pas** en premier | **Continuer** en grand ; « Revoir ma partie » et « Rejouer pour la maîtrise » en petits boutons côte à côte |
| Échec | Repartir du début / Revenir dans le temps / Revoir ma partie / Voir la solution optimale | quatre boutons : le panneau dépasse l'écran sur petit téléphone ; « Voir la solution » dès le 1er échec enlève la découverte | **Revenir dans le temps** (la mécanique propre au jeu) en premier ; « Repartir » à côté ; « Voir la solution » seulement après 3 échecs |
| Après « Continuer » | carte du monde 2,6 s puis niveau suivant | bien, mais on ne peut pas l'interrompre | un toucher passe directement au niveau |
| Retour accueil | — | **bug trouvé** : `goto('home')` laisse ouvert un voile d'un autre écran (Atelier de particule resté par‑dessus l'accueil) | fermer tous les voiles à chaque changement d'écran |

## 3. Audit des modes non aboutis

| Mode | État constaté (captures R52) | Ce qui manque | Proposition |
|---|---|---|---|
| **Quantum Drop** (demande de Simon : « Quantix Drop ») | défi du jour = **un niveau existant** (ex. n° 23) + une contrainte (« Le noyau ») | aucune nouveauté, nom incohérent, pas de série ni de partage | renommer **Quantix Drop** ; niveau du jour **généré** (combinaison de 2 mécaniques déjà vues), série de jours, partage d'un code de résultat |
| **Zen Lab** | bac à sable avec toutes les matières, gravité et temps réglables | aucun objectif, rien n'est gardé, pas de lien avec Quantone | sauvegarde de créations ; **éditeur de niveau** (placer départ et zone) ; partage par code ; la musique vient de Quantone |
| **Atelier de particule** | peinture d'un motif sur une sphère **lisse et cyan** | la sphère ne ressemble pas à la particule du jeu (nuage de points) | peindre directement **le nuage de points** ; couleurs de la charte ; aperçu en mouvement |
| **Accueil** | ligne de diagnostic audio visible (« voie échantillons activée · session non supportée ») | texte technique montré au joueur | à cacher (garder pour les tests via un réglage) |

---

## 4. Ce qui est fait en R52 (vérifié)

- Craquements : ducking sans saut de gain ; réverbération 2,4 s ; texture du monde 8 allégée (grille 60 × 80, recalcul une
  image sur trois).
- Loupe de la ligne droite : plus d'étiquettes (angle, énergie, consignes) dans la loupe ; elles restent sur le terrain.
- Écran de résultat : emblème **animé** au rendu du jeu — la particule (même nuage de points que la balle) est aspirée en
  spirale dans l'anneau vert de la zone ; à l'échec elle se défait en éclats rouges.
- Monde 8 : ferrofluide refait d'après la nouvelle vidéo (cellules près de la goutte, filaments étirés derrière elle,
  gouttelettes, relief par ombre et liseré, poussière abondante émise le long des parois, goutte qui dérive vite).

## 5. Ordre de réalisation proposé

1. Son : réaliser la bible §1.6 monde par monde (commencer par les communs + mondes 1 à 4), avec le test de couverture.
2. Menu après niveau (§2) : rapide, améliore toute la partie.
3. Quantix Drop (§3), puis Zen Lab, puis Atelier de particule.
4. Reprendre la refonte des niveaux (annexe R51 de `DIFFICULTY_PROTOCOL.md`).

---

## 6. Réalisation de la bible sonore (R54)

| Objectif (§1.7) | Résultat mesuré |
|---|---|
| Couverture 100 % | **Oui** : aucun élément muet sur les 132 niveaux (`tools/e2e-son.py`) |
| Crête < 0,5 avec musique | **Oui** : 0,24 à 0,27 dans les 11 mondes, tous les effets empilés |
| Une boucle par élément continu | **Oui** : vent, gravité, aimant, parois mobiles, glace, tracé — volume modulé à chaque instant (60 ms) ; elles se taisent hors partie |
| Pas de clic | ducking avec maintien de valeur (R52) ; variations de gain lissées (constantes 50 à 300 ms) |
| Distinction effets / musique | effets secs (réverbération × 0,45) + « seconde vie » sur un bus d'écho lointain filtré à 650 Hz ; musique en retrait −4 dB à chaque effet |
| Écoute de Simon | **à faire** — extrait `quantix-bible-sonore-11-mondes.wav` (hors du site) |

Code : `assets/js/sound.js`, bloc « BIBLE SONORE (R54) » — table `MAT` (matière de chaque monde), `struck` (choc d'objet
de la matière), `SFX` (événements), `impact` (chocs par matériau), `loopTick` (boucles), `musChain` (filtre de dilatation
et double désaccordé de la superposition), `tail` (seconde vie). Événements quantiques renommés dans `engine.js` :
`ent_link`, `gate`, `sup_split`, `det_measure`, `collapse`.
Corrigé en chemin : la corde (Karplus‑Strong) devenait instable (crête 2,2) — remplacée par un pincement sûr ; après un
rendu hors ligne, le moteur sonore gardait des liens vers le contexte de rendu (erreurs « autre contexte ») — restauré.
