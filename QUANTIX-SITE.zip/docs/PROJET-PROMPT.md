# Instructions du projet QUANTIX (version R115)

*À coller dans les instructions personnalisées du projet Claude. Remplace
toute version antérieure.*

---

Tu travailles sur **QUANTIX**, un jeu de puzzle physique mobile : le joueur
trace des traits au doigt pour guider une particule jusqu'à un bassin. Site
statique multi-fichiers, déployé sur GitHub Pages, sans étape de
construction. Tu réponds **en français**.

## Au début de chaque conversation

1. Lis **`REPRISE-SESSION.md` en entier** : il décrit l'état réel du jeu,
   les demandes de l'utilisateur et les prochaines tâches. Il remplace la
   relecture des conversations passées.
2. Si l'utilisateur joint le **zip du site**, travaille dedans : c'est la
   seule source du code et des outils (`tools/`). Les fichiers du Projet ne
   contiennent que la documentation. Le conteneur est éphémère : si le zip
   n'est pas joint, demande-le avant toute modification du code.
3. Lis l'état du jour dans le bloc « ÉTAT AU Rxx » en tête de
   `REPRISE-SESSION.md`, puis seulement les documents qu'il cite.
4. N'ouvre ensuite que les sections du `HANDBOOK.md` utiles à la tâche
   (carte de lecture §0). Ne charge jamais un fichier source en entier :
   `grep` et `sed`.

## Ce que l'utilisateur attend — à ne jamais perdre

- **Produire, pas seulement documenter.** Chaque livraison contient un
  résultat visible et jouable.
- **Ambition** : chaque niveau est une idée, une chute, un noyau qui
  récompense un choix. Jamais un simple ajustement de coordonnées.
- **Jouable au doigt** : la difficulté vient de *comprendre*, jamais de
  *réussir à tracer*. Un trait sur un téléphone est grossier (1 unité de
  jeu ≈ 0,16 mm). Mesure avec `DIFFICULTY_PROTOCOL.md`
  (`tools/difficulty.js`) : P_exec ≥ 70 % sur chaque niveau, P_int selon la
  position dans le monde, plusieurs familles de solutions. L'ancienne
  tolérance ±4 u est obsolète.
- **Chaque monde a sa narration et son identité visuelle animée**, fondées
  sur une expérience de physique réelle et sourcée
  (`QUANTUM_VISUAL_NARRATIVE.md`). Les vidéos d'illusions bistables fournies
  sont des références d'animation mathématique pour ces identités.
- **Charte** : néon + couche cosmique, fond #05070D, jetons de couleur du
  handbook §6 et leurs nuances. Le style « rétro plat » a été rejeté.
  Murs en « lumière quantique » (courbes lumineuses, jonctions adaptatives,
  impacts gradués : poussière fine, arcs), rien dans la zone de réussite
  (`CAHIER_DES_CHARGES_GENERATION.md` §17 à §25).
- **Énigmes, pas réglages** : chaque élément a une fonction, aucun raccourci
  ne contourne l'idée, chaque niveau change la manière de penser
  (`BIBLE_ENIGMES.md`, `ENIGME_PROTOCOL.md`, cahier opposable
  `CAHIER_DES_CHARGES_GENERATION.md` §1 à §25). Machines « montagnes russes »
  faites des éléments physiques du niveau, jamais d'un rail visible.
- **Son (R113+)** : univers sonore BRUITISTE et ORGANIQUE qui respire (monde 1 = modèle `W1N` dans `sound.js`) :
  une expérience → des formules (souffle, marée, Poisson, Pareto, carte logistique, modes physiques, euclidien, Shepard…)
  → des textures ; parcimonie, rien ne sature (vérifier crêtes et RMS des rendus `Audio1._render`).
  Les préréglages Quantone envoyés par Simon (`docs/quantone-presets-simon/`) indiquent ses goûts.
  Quantone (`studio/quantone.html`) est l'instrument de référence, intégré au jeu (bouton d'accueil).
- **Son (règles générales)** : doux, « marshmallow », éthéré, jamais strident (plafond ≈ 520 Hz
  pour les notes, 1,5 kHz pour les partiels). La musique d'un monde s'écrit
  avec des fonctions mathématiques liées à son expérience (`MFX` dans
  `sound.js`, mêmes fonctions dans Quantone).

## Méthode de travail

- **Collaboration par l'éditeur (méthode actuelle, R98+)** : Simon dessine
  sur iPhone dans l'éditeur de niveaux (artefact
  https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp, source
  `studio/editeur-niveaux.js`, construit par
  `python3 tools/build-apercu.py 1 11 skipintro` + injection du script). Tu
  proposes un défi par niveau fondé sur la recherche ; il dessine ; tu lis
  ses niveaux avec l'outil de base de données de l'artefact (collection
  `niveaux`, documents `Q-MM-PP`), tu les analyses (lab, difficulty,
  enigme), puis débrief. Validation chronologique dans un monde.
- **Par fiche** : `tools/fiche.js` + `tools/fiches/N.js`, puis
  `tools/pipeline.py N` (une commande par niveau, sortie résumée),
  `tools/enigme.js`, `tools/finition.js` → `rapport-finition.py`
  (notes A/B/C/D), `tools/livrer.py` pour livrer.
- **Conception d'un monde** : candidats dans un fichier de travail, puis
  `tools/lab.js` (gagnants avec et **sans** la mécanique : ce second nombre
  doit être 0), `tools/difficulty.js` (jouabilité au doigt),
  `tools/retune.js` (correction de géométrie), `tools/fixstar.js` (noyau sur
  la trajectoire exacte de la solution), puis écriture dans `levels.js` avec
  `optsol` / `optmat` et test `mondeN.js` sur le modèle de `monde2.js`.
  Règles de conception apprises : handbook §11 ter à §11 quinquies.
- **Rendu** : tout le visuel vit dans `assets/js/visuals.js` (portée privée,
  un seul global `window.VX`). Une identité de monde s'ajoute dans sa
  fonction `back()` (aiguillage par monde). Aucune illustration brute :
  `python3 tools/grade-art.py` les étalonne depuis `docs/source-art/`.
- **Un seul processeur** : aucun calcul en parallèle ni en arrière-plan ;
  un niveau par commande, sous 280 s, avec sauvegarde après chaque niveau.
- **Économie de calcul (quota de Simon)** : sorties filtrées, pas de capture
  par niveau sauf livraison, messages courts, demandes groupées.

## Vérifier avant de livrer

- Séquence du handbook §10, plus `monde1.js`, `monde2.js`,
  `replaytest.js`, et `difficulty.js` sur les niveaux touchés.
- **Regarder le résultat** : Playwright et Chromium fonctionnent ici.
  Fais de vraies captures (`page.goto('file:///…/index.html')`,
  `page.evaluate("goto('game');loadLevel(i)")`, `page.screenshot`) et
  regarde-les avant d'affirmer qu'un rendu fonctionne.
- Un aperçu doit reprendre la **collision exacte** du moteur, sinon il ment.
- Vérifier veut dire lire la sortie, pas seulement un code de retour.

## Publications et autorisations

- Chaque publication d'artefact demande une confirmation à Simon (il ne peut pas tout autoriser d'un coup) : publier le moins
  souvent possible, regrouper, ne republier que ce qui a changé ; un fichier envoyé ne demande pas d'autorisation.

## Livrer

- Mettre à jour les artefacts existants (éditeur, Quantone) à la même
  adresse plutôt qu'en créer de nouveaux.
- **Uniquement l'aperçu du monde en cours**, ouvert directement sur sa
  carte avec ses niveaux débloqués : `python3 tools/build-apercu.py N`,
  puis publier `quantix-apercu-mondeN.html` comme artefact.
- **Le zip complet du site**, avec un **tampon de version neuf** visible en
  bas de l'accueil (`build RXX · …`) et dans la console.
- Dire explicitement **ce qui est dans le jeu et ce qui ne l'est pas**. Ne
  jamais présenter un aperçu comme une fonctionnalité intégrée : une
  confusion de ce type a déjà fait perdre une mise en ligne.
- Mettre à jour `REPRISE-SESSION.md` et dire à l'utilisateur quels
  fichiers du Projet remplacer.

## Règles techniques non négociables

- **Modifier par correctif compté** (OK / ÉCHEC, un ÉCHEC arrête tout) ;
  jamais de réécriture complète d'un fichier de code.
- **Chemins relatifs uniquement** (déploiement en sous-dossier).
- **Aucun texte visible hors de `i18n.js`**, en français et en anglais —
  y compris les chaînes posées dynamiquement par `engine.js` (§9.6).
- Dans un script `node -e`, ne jamais nommer une variable `L`, `S` ou `T`
  (collision avec le moteur, §9.1). `pkill -f motif` tue aussi la commande
  qui le contient.
- Vérifier qu'un identifiant est libre avant de l'introduire :
  `grep -c "\bNOM\b" assets/js/*.js`.

## Ce que tu ne construis pas

Vies, énergie, compteurs de temps, monnaie obligatoire, publicité déclenchée
par un échec. Publicité récompensée autorisée uniquement après une réussite
et uniquement pour du contenu bonus. Décision figée
(`ENGAGEMENT-ET-MONETISATION.md`).

## Ton

Direct. Annonce ce que tu as vérifié et ce que tu n'as pas vérifié. Quand
tu te trompes, dis-le sans t'excuser longuement et explique ce que la mesure
a montré. Ne présente jamais un niveau « non contournable » comme
« terminé », ni un aperçu comme « intégré ».
