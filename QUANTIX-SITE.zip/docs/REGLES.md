# QUANTIX — Règles (exigences, méthode, passation, économie)

*Document unique des règles (R262). Fusion de `CHARTE_EXIGENCES.md` (§A–§J), `METHODE.md` (§K) et `PASSATION_R232.md` §1
(§L) ; §M (économie et communication) est nouveau. À lire avant de modifier du code, un niveau ou un rendu ; inutile pour une
question simple. **Une règle nouvelle remplace une ligne existante** (on note la date), elle ne s'empile pas.*

**Lecture** : ✅ en vigueur ; ⛔ refus définitif ; ⚠ en vigueur mais encore violé dans le code (voir `AUDIT_R209.md`).

---

## A. Le projet et la manière de travailler

| # | Exigence | Depuis |
|---|---|---|
| A1 | ✅ **Produire, pas seulement documenter** : chaque livraison contient un résultat visible et jouable | historique |
| A2 | ✅ **Ambition** : chaque niveau est une idée, une chute, un noyau qui récompense un choix — jamais un simple ajustement de coordonnées | historique |
| A3 | ✅ Simon juge **à l'œil, sur iPhone**, à partir d'un aperçu jouable ; les outils servent à ne rien casser, pas à décider si c'est bon | R122 |
| A4 | ✅ Simon travaille **uniquement sur iPhone** : tous les outils doivent être utilisables au doigt sur iPhone | R98 |
| A5 | ✅ **Valider dans l'ordre**, monde par monde, du premier au dernier niveau | R98 |
| A6 | ✅ Refonte des mondes 7 à 11 « **progressivement mais sûrement** », un monde à la fois, **sans allers-retours** | R201 |
| A7 | ✅ **Ne pas abandonner une idée** après un long travail : la retravailler en élargissant la palette (moteur, élément, géométrie, combinaison) | 12 oct. |
| A8 | ✅ **Économie de calcul** (crédits de Simon) : voir §M, qui fait foi | R115 → R262 |
| A9 | ✅ **Vérifier avant d'affirmer** : vraies captures Playwright regardées ; collisions exactes du moteur dans tout aperçu ; « vérifier veut dire lire la sortie » | historique |
| A10 | ✅ **Dire ce qui est dans le jeu et ce qui ne l'est pas**, ce qui a été vérifié et ce qui ne l'a pas été ; ne jamais présenter un aperçu comme intégré | historique |
| A11 | ✅ **Remonter l'erreur exacte** avant de formuler une hypothèse | historique |
| A12 | ✅ Claude refond les niveaux en autonomie selon le protocole et les livre en préréglages dans l'éditeur + aperçu ; Simon modifie ensuite, finitions ensemble | 11 oct. |
| A13 | ✅ Ne jamais écraser un document que Simon a enregistré dans l'éditeur ; écrire une variante `Q-MM-PP-claude` et le signaler | R98 |
| A14 | ✅ Une remarque sur un monde **ne s'étend jamais** aux autres sans le dire | R153 |
| A15 | ✅ Tout nouveau rendu passe d'abord par le **banc des rendus** (artefact séparé) avant d'entrer dans le jeu | R166 |
| A16 | ✅ Communication **directe** ; quand on se trompe, le dire sans longues excuses et expliquer ce que la mesure a montré | historique |

## B. Direction artistique et charte graphique

| # | Exigence | Depuis |
|---|---|---|
| B1 | ✅ **Néon + couche cosmique**, fond **#05070D**, jetons de couleur du `HANDBOOK.md` §6 et leurs nuances seulement | historique |
| B2 | ⛔ Style « **rétro plat** » rejeté | historique |
| B3 | ✅ Visuels **éthérés, légers, cosmiques, nébuleux** ; transparences par **couches animées successives** (voiles de particules, vortex, trous noirs, cordes, fentes de Young) ; références : vidéos de nuages de points animés (illusions bistables) | historique |
| B4 | ✅ **Murs en « lumière quantique »** : courbes lumineuses, jonctions adaptatives, impacts gradués (poussière fine, arcs) | historique |
| B5 | ✅ **Rien dans la zone de réussite** (aucun élément, aucun motif de décor) — opposable | historique ⚠ (#21, #34) |
| B6 | ✅ **Chaque monde a son identité visuelle animée**, fondée sur une expérience de physique réelle et sourcée ; pas un nouveau noyau par monde | historique |
| B7 | ✅ Design **professionnel et subtil**, cohérent, issu de recherche, parti pris tranché codé selon des règles strictes (pas de valeurs en dur), animations subtiles au service de la mise en scène | historique |
| B8 | ✅ **Plein écran** : contours en couleur unie ou dégradé comme l'accueil, **jamais une image floue agrandie** ; titre du niveau discret | R192 |
| B9 | ✅ Le **terrain de jeu ne change jamais** de format ni d'emplacement | R141 |
| B10 | ✅ **Aucune zone invisible** : toute interdiction de tracer est visible | R122 ⚠ (6 niveaux `mz`) |
| B11 | ✅ Zone interdite = **fluctuations du vide** (paires matière/antimatière, trait qui se délite en poussière ronde et fine) ; la zone refuse le TRAIT, pas la particule | R165–R199 |
| B12 | ✅ Le Magnétisme a son **ferrofluide vivant** ; les autres mondes gardent leurs voiles 3D et hélices | R153–R173 |
| B13 | ✅ La **Mécanique décorative** (trains d'engrenages, bielle, échappement, came) est un modèle de soin du décor | R153, R206 |
| B14 | ✅ Le **cyclone** (Soufflerie 12) est le modèle : un concept fort ET une esthétique singulière dédiée ; éviter la redondance (cercles, échelles de plafonds) | 10 oct. |
| B15 | ⛔ **Kitsch** (guirlandes, constellation en collier, « Félicitations » en dur) | R201 |
| B16 | ✅ Illustrations étalonnées (`grade-art.py`), jamais brutes ; ni sur-assombries ni sur-compressées | historique |

## C. Niveaux et énigmes

| # | Exigence | Depuis |
|---|---|---|
| C1 | ✅ **Énigmes, pas réglages** : chaque élément a une fonction, chaque niveau change la manière de penser | historique |
| C2 | ✅ **Aucun raccourci** ne contourne l'idée : 0 gagnant sans la mécanique, 0 trait « nu » | R158 ⚠ (33 niveaux) |
| C3 | ✅ La difficulté vient de **comprendre**, jamais de réussir à tracer ; jouabilité mesurée au modèle éditeur (P_exec ≥ 70 %) ; la réussite facile au doigt n'est pas indispensable si l'éditeur de ligne le permet | R117, 11 oct. |
| C4 | ✅ Chaque niveau renforcé **gagne un mouvement, une particularité, de l'élégance**, comme les 6 et 12 | R159 |
| C5 | ✅ Plusieurs familles de solutions quand c'est possible | R117 |
| C6 | ✅ Le **noyau** récompense un choix (pas un détour gratuit) | historique |
| C7 | ✅ Un niveau ancien qui ne tient pas se **refait** à partir d'une idée ; on ne le règle pas au pixel | R122 |

## D. Machines (niveaux 6 et 12 de chaque monde)

| # | Exigence | Depuis |
|---|---|---|
| D1 | ✅ Machines « **montagnes russes** » faites des éléments physiques du niveau, **jamais d'un rail visible** | historique |
| D2 | ✅ Chaque machine contient **un bonus de son monde** (ex. un rebond en Fonderie) et une **trajectoire longue et amusante** à regarder | 10 oct. |
| D3 | ✅ Courbes **calculées** (`rail.js`), composition élégante et harmonieuse, entrée fluide (trémie + goulotte) | R122 |
| D4 | ✅ Les machines « doivent faire machine » (pas une harpe décorative) | R146 |

## E. Interface, didacticiel, textes

| # | Exigence | Depuis |
|---|---|---|
| E1 | ✅ **Aucun texte visible hors de `i18n.js`**, FR et EN, y compris les chaînes posées par `engine.js` | R24 ⚠ (13 chaînes) |
| E2 | ✅ **Peu de texte** : l'animation dit l'issue ; mots courts et conceptuels sur le thème quantique ; options cliquables qui ont l'air cliquables (pas de chevrons de sous-menu) ; gros travail typographique | R192 |
| E3 | ✅ Ton **pragmatique, énigmatique, concis** : une règle, un verbe, ≤ 80 signes, pas de lyrisme (remplace « tonalité dramaturgique » du 9 oct.) | R201 |
| E4 | ✅ Fiches du didacticiel **en surimpression**, holographiques (proposition A : émetteur, rails, déroulement, verre sombre translucide flouté), animations conservées, décor à l'encre cyan | R196–R198 |
| E5 | ✅ Fiches : une notion à la fois ; à l'arrivée dans un niveau seulement ; jamais sur un niveau déjà réussi ; deux au plus | R202 |
| E6 | ✅ **Éditeur de lignes soigné** : gomme, ligne droite entre deux points, déplacement, rotation et échelle dans le même outil (comme Quantone), aimant | historique → R261 |
| E7 | ✅ **Bilan** sans titre ni phrases : en-tête animé par issue, tuiles icône + mot, vocabulaire quantique (État initial, Bifurquer, Trajectoire, Géodésique, Poursuivre) | R192 |
| E8 | ✅ Bilan final = **le parcours entier** (étoiles, matière/énergie, temps, essais, données de jeu) | R208 |
| E9 | ✅ **Les liens des outils** (`ETAT.md` §7) sont donnés en clair à la fin de chaque réponse ; le Menu édition est supprimé (22 oct.) | R192 → R264 |
| E10 | ✅ Zen Lab, Quantum Drop, atelier de particule **retirés du menu** jusqu'à redéfinition | R115 |

## F. Son

| # | Exigence | Depuis |
|---|---|---|
| F1 | ✅ Univers sonore **bruitiste et organique qui respire** : une expérience → des formules → des textures ; parcimonie ; rien ne sature (vérifier crêtes et RMS) | R113 |
| F2 | ✅ Doux, « **marshmallow** », éthéré, **jamais strident** : notes ≤ 520 Hz, partiels ≤ 1,5 kHz | historique |
| F3 | ✅ Souffle qui respire **jusqu'au silence**, pulsation dès le niveau 1, rien d'oppressant | R118 |
| F4 | ✅ Nappes plus **mélodiques**, un thème simple avec variantes par monde ; bruitages **texturés et vaporeux** (pas secs ni industriels), cohérents avec la musique | historique |
| F5 | ✅ **Quantone** est l'instrument de référence ; les préréglages de Simon indiquent ses goûts (fa♯ lydien ; Glacier en quintes) | R114 |

## G. Narration et fin

| # | Exigence | Depuis |
|---|---|---|
| G1 | ✅ Narration **C** : paire intriquée, séparation, traversée, retrouvailles (`NARRATION.md`) | R203 |
| G2 | ✅ Fin = **vraie scène cinématique au niveau du héros** : poursuite de retour, même principe que le héros mais **autres actions et autres éléments** | R203–R204 |
| G3 | ✅ La **compagne** a l'aspect de la branche de superposition du jeu ; elle fait le retour avec la particule | R204 |
| G4 | ✅ **Un seul mouvement** à deux (canon, valse) plutôt que la symétrie ; transitions soignées ; caméra non linéaire (rythme, cadrage, direction) mais **sobre** (un seul basculement, en Gravité, sans tourbillon) | R205–R207 |
| G5 | ✅ Fin : les particules plongent dans le trou noir → la sphère → **QUANTIX** apparaît délicatement | R207 |
| G6 | ✅ Le texte final est **à creuser** ; pas de crédits pour l'instant ; un lien Ko-fi est souhaité (adresse à fournir) | R202 |

## H. Technique

| # | Exigence | Depuis |
|---|---|---|
| H1 | ✅ Site **statique multi-fichiers**, scripts classiques (pas de modules), GitHub Pages, **chemins relatifs** | historique |
| H2 | ✅ Monde de référence **360 × 480 unités** | historique |
| H3 | ✅ **Correctifs comptés** (OK / ÉCHEC, un ÉCHEC arrête tout) ; jamais de réécriture complète d'un fichier de code | historique |
| H4 | ✅ Dans `node -e`, jamais de variable `L`, `S`, `T` ; vérifier qu'un identifiant est libre avant de l'introduire | historique |
| H5 | ✅ **Tampon de version** neuf visible en bas de l'accueil et dans la console à chaque livraison | historique |
| H6 | ✅ Tout le visuel dans `visuals.js` (un seul global `window.VX`) ; héros et épilogue dans `hero.js` (`QHERO`) | historique, R188 |

## I. Livraison

| # | Exigence | Depuis |
|---|---|---|
| I1 | ✅ Le **zip complet du site** à chaque lot | historique |
| I2 | ✅ Un **aperçu jouable** à la même adresse, ouvert sur ce qu'il faut juger, **tous les mondes et niveaux débloqués** | 11 oct. |
| I3 | ✅ Mettre à jour les artefacts existants **à la même adresse** ; publier le moins souvent possible (chaque publication demande une autorisation) | R115 |
| I4 | ✅ Mettre à jour `ETAT.md` (et `JOURNAL.md`) et dire quels fichiers du Projet ont été remplacés | historique → R262 |

## J. Refus définitifs

| # | Refus | Pourquoi |
|---|---|---|
| J1 | ⛔ Vies, énergie payante, minuteurs, monnaie obligatoire | monétisent la frustration, détruisent l'autonomie (Ryan, Rigby, Przybylski) |
| J2 | ⛔ Publicité déclenchée par un échec ; interstitielles ; lecture automatique | idem |
| J3 | ✅ Publicité récompensée seulement **après une réussite** et pour du **bonus** (recommandation R209 : ne pas en mettre du tout) | décision figée |
| J4 | ⛔ Le canon Replit / React (abandonné) | historique |

## K. Méthode d'un lot

Un lot = **un monde** (refonte de niveaux) **ou une fonction** (rendu, son, interface). Il s'annonce en une phrase.

**Un niveau**
1. **Fiche** (trois lignes, `tools/fiches/N.js` ou dans le message) : *le joueur croit… / il découvre… / le geste* ; plus
   l'expérience évoquée, la mécanique indispensable, le leurre, la place dans le monde.
2. **Construction** : géométrie dans `levels.js` (correctifs comptés), courbes `tools/rail.js`, machines `tools/forge.json` ;
   si Simon a dessiné dans l'éditeur, partir de son dessin (base `niveaux`, document `Q-MM-PP`).
3. **Preuve** : `python3 tools/preuve.py N` (référence gagne, à vide échoue, zone propre, pas de zone invisible, mécanique
   indispensable, pas de trait « nu ») ; puis `node tools/difficulty.js N` (P_exec ≥ 70 % au modèle éditeur) ; et
   `node tools/scan132.js N` (encre de départ, encre minimale d'une ligne gagnante, contournements, murs jamais touchés).
4. **Encre** : le quota découle du scénario du niveau et de la meilleure solution connue (référence ET balayage) ; la
   solution de référence (« Géodésique ») doit être traçable au doigt et la plus économe connue. **Règle validée par Simon le 24 oct. (R297)** : `Q = k × encre(référence) + c` ; profils *défi d'encre* (k 1,2 ; c 10), *standard* (1,6 ; 20), *découverte* (2 ; 40) ; jamais < 1,15 × la référence. Les niveaux « défi d'encre » se définissent d'après les données des bêta-testeurs (événements), pas a priori. Détail et mesures : `CALIBRAGE_ENCRE.md`.
5. **Capture regardée** (Playwright), puis `node tools/mondeN.js` en fin de monde et `replaytest.js`.

**« Fini »** = fiche + `preuve.py` à OK + P_exec ≥ 70 % + capture regardée + validé par Simon sur iPhone.

**Un rendu** : Banc des rendus d'abord (`python3 tools/build-galerie.py`), validation de Simon, puis intégration
(`visuals.js` / `hero.js` / `quantix.css`, bloc daté en fin de fichier). **Tout rendu modifié est couvert par une capture
automatique comparée** (règle R262 après la régression du Magnétisme : un test de fonds par monde est à créer).

**Un son** : méthode W1N (`SON_MONDES.md`) ; mesurer crête, RMS, part de silence ; rendus d'écoute envoyés en fichier.

**Tests avant livraison** : audit, strict, tutotest, render, replaytest, savetest, maptest, `mondeN` des mondes touchés ;
e2e (didacticiel, éditeur, échelle, Quantone) si l'interface change. Seulement ceux qui concernent ce qui a changé.

**Livrer** : tampon neuf (`index.html` `#buildTag` + console `engine.js` + `?v=Rnnn`), zip complet envoyé, aperçu
republié seulement si Simon doit juger un rendu ou un niveau (avec son accord), `ETAT.md` réécrit, une ligne dans
`JOURNAL.md`, documents envoyés au Projet ; dire lesquels ont changé. Liens en fin de réponse (voir `ETAT.md` §7).

## L. Passation entre conversations

1. **Une seule conversation travaille à la fois.** Celle qui livre le dernier zip est la référence ; vérifier le tampon
   contre `ETAT.md` avant de toucher au code ; s'il est plus ancien, demander le dernier zip.
2. **Le zip (ou le dépôt GitHub) est la seule source du code.** Les fichiers d'une autre conversation n'existent pas ici
   tant que le zip n'est pas joint.
3. **Les artefacts sont partagés** : lire avant de republier, fusionner, publier à la même adresse ; jamais d'adresse
   nouvelle pour un outil existant.
4. **Fin de lot** : zip envoyé, `ETAT.md` + `JOURNAL.md` envoyés au Projet, `TECHNIQUE.md` mis à jour si l'architecture ou un
   outil change.

## M. Économie de crédits et communication (fait foi, R262)

1. **Lecture sélective** : au démarrage, `ETAT.md` seulement (+ `LEXIQUE.md` si un mot est flou). Les autres documents
   selon la tâche (`INDEX.md`). Jamais de lecture intégrale d'un long document ; sections par `grep`/`sed`.
2. **Plan court d'abord** (≤ 7 étapes, livrables, risques) pour tout lot de plus de quelques appels d'outils.
3. **Un message à Simon au moins toutes les 5 à 8 actions** et à chaque résultat : jamais un long travail silencieux.
4. **Calcul long** (> 2 min) : l'annoncer avant ; une commande < 280 s ; pas deux calculs lourds en même temps ; un calcul
   d'arrière‑plan est permis s'il est annoncé et ne bloque pas les réponses.
5. **Deux échecs similaires → arrêt** : diagnostiquer, changer de méthode ou montrer l'état et deux options.
6. **Avant une étape coûteuse** (scan complet, refonte d'un monde, recherche web longue, publication), demander
   l'accord de Simon en disant le bénéfice attendu.
7. **Un lot par demande** quand Simon en envoie plusieurs : livrer le premier, proposer l'ordre des suivants.
8. **Preuves** : séparer fait / vérifié / non testé / supposé ; ne jamais inventer un test réussi.
9. **Sorties filtrées** (`tail`, `grep`), messages courts, pas de journal de raisonnement.
10. **Ne pas republier** un artefact sans nécessité ; un fichier envoyé ne coûte pas d'autorisation.
