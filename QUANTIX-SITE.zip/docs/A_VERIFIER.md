# QUANTIX — À vérifier par Simon (tenu à jour à chaque lot)

*Créé le 17 octobre 2026 (R241). Chaque ligne : où, quoi regarder, statut. Simon coche « vu » ou écrit sa remarque ;
la conversation suivante lit ce fichier et traite les remarques. Convention : « Monde X – niveau Y (Nom) ».*

Tout se joue dans l'**Aperçu** (https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC), sauf mention contraire.
« Voir la solution » (bouton Géodésique après un échec) montre la solution de référence.

## Monde 7 – Gravité (refondu R233)

| Niveau | L'idée | À regarder | Statut |
|---|---|---|---|
| Monde 7 – niveau 5 (Le saut lunaire) | pesanteur très faible : un petit élan suffit à un grand saut | le saut paraît-il « lunaire » ? | à vérifier |
| Monde 7 – niveau 7 (Le plafond) | dans la zone, la pesanteur tire vers le haut | lisibilité de la zone inversée | à vérifier |
| Monde 7 – niveau 8 (Le jet) | colonne qui projette vers le haut | machine du monde : assez spectaculaire ? | à vérifier |
| Monde 7 – niveau 9 (La frontière) | franchir la limite entre deux pesanteurs | on comprend où est la frontière ? | à vérifier |
| Monde 7 – niveau 10 (La plume) | deux traits ; jet + champ faible | difficulté (deux traits) | à vérifier |
| Monde 7 – niveau 11 (Le miroir) | pesanteur inversée sous une ligne | la trajectoire « miroir » se lit-elle ? | à vérifier |

## Monde 8 – Magnétisme (refondu R238–R239)

| Niveau | L'idée | À regarder | Statut |
|---|---|---|---|
| Monde 8 – niveau 5 (Le ricochet) | le champ renvoie la particule vers le haut ; arriver à plat pour ricocher | le ricochet est-il beau ? trop facile ? | à vérifier |
| Monde 8 – niveau 6 (Le canon de Gauss) | zone non traçable devenue visible (colonne de gauche) | la zone grise gêne-t-elle ? | à vérifier |
| Monde 8 – niveau 8 (Le coussin) | aimants répulsifs sous une pente : lévitation | respiration voulue (Simon) | vu (respiration) |
| Monde 8 – niveau 10 (L'accélérateur) | aimants en fer à cheval qui poussent vers l'avant (R239) | l'effet magnétique se comprend-il maintenant ? | à vérifier |
| Monde 8 – niveau 12 (Le spectromètre) | zone invisible retirée | rien ne doit avoir changé au jeu | à vérifier |

## Monde 9 – Faille (refondu R241)

| Niveau | L'idée | À regarder | Statut |
|---|---|---|---|
| Monde 9 – niveau 1 (Le portail) | bassin enfermé ; rouler jusqu'au cercle bleu | bonne entrée dans le monde ? | à vérifier |
| Monde 9 – niveau 5 (Le bord du monde) | couture des bords : sortir à droite, rentrer à gauche | **la bande verte au bord est-elle assez visible ?** | à vérifier |
| Monde 9 – niveau 8 (Le trou de serrure) | traverser une faille en plein vol | trop proche du niveau 1 ? | à vérifier |
| Monde 9 – niveau 9 (Aller-retour) | synthèse bord + faille au sol | passage facile : acceptable ? | à vérifier |
| Monde 9 – niveau 11 (Le pli) | bord puis faille juste après la couture | passage facile : acceptable ? | à vérifier |

## Monde 11 – Quantique (en cours, R242)

| Niveau | L'idée | À regarder | Statut |
|---|---|---|---|
| Monde 11 – niveau 3 (Deux possibles) | la particule se dédouble ; rattraper la copie de droite | voit-on les deux copies ? | à vérifier |
| Monde 11 – niveau 4 (La mesure) | le détecteur rend réelle la copie qui le touche ; détourner la gauche | la règle se devine-t-elle ? | à vérifier |
| Monde 11 – niveau 6 (L'interféromètre) — habit « banc d'optique » au Banc des rendus (R247) : garder / ajuster / pousser ? | | | à valider |
| Monde 11 – niveau 6 (L'interféromètre) | vrai Mach-Zehnder : ensemble les versions sortent à gauche ; boucher un tube change la sortie de l'autre | **le recombineur se voit-il ?** la machine est-elle assez spectaculaire ? | à vérifier |
| Monde 11 – niveau 2 (Opposition) | paire opposée devenue réelle (même solution qu'avant) | rien ne doit avoir changé au jeu | à vérifier |
| Monde 11 – niveau 11 (Machine quantique) | une copie ouvre la porte, l'autre la franchit | assez « machine » avant la finale ? | à vérifier |
| Monde 11 – niveau 8 (Mesure tardive) | un trait mène la copie de droite dans le détecteur : elle devient réelle et la porte du bassin, juste devant elle, s'ouvre | le lien détecteur → porte se comprend-il ? | à vérifier (R244) |
| Monde 11 – niveau 10 (Le choix) | la copie de gauche se fait mesurer et se retrouve piégée ; détourner celle de droite sur le détecteur central | le lien « un détecteur → deux portes » se lit-il ? | à vérifier (R244) |
| Monde 11 – niveau 5 (Le temps ralenti) | la chute directe arrive trop tôt sur la lame ; un petit trait envoie la particule dans le couloir doré, la lame s'est retirée quand elle arrive | la lame (ligne rouge) se lit-elle comme un danger qui se retire ? | à vérifier (R245) |
| Monde 11 – niveau 7 (Intrication double) | le noyau sur la chute referme le passage ; passer d'abord par le passage, puis toucher l'autre noyau | l'ordre des contacts se comprend-il ? | à vérifier (R245) |
| Monde 11 – niveau 9 (Les jumeaux) | refait après ton retour : retenir la copie de gauche (trait le long du poteau) ; réunies, elles sont lancées le long de l'arc pointillé vers le bassin perché ; l'anneau du recombineur montre l'attente | la force est-elle lisible maintenant ? geste reproductible ? | à vérifier (R248) |
| Monde 6 – tous niveaux à barre mobile (scan R245) | piège « trait plat qui attend la barre » : l'énigme de rythme est-elle contournable ? | à mesurer à l'outil | à faire |
| Lisibilité (scan R249) | recombineur redessiné ; portes ouvertes visibles (jambages + seuil) ; vent, gravité, colonne d'air, champ uniforme plus marqués | tout élément jouable se voit-il d'un coup d'œil sur iPhone ? | à vérifier (R249) |
| Squelettes (scan R248 : 0 paire) | Monde 11 – niveau 4 (La mesure) refait ; Monde 9 – niveau 11 (Le pli) en miroir | l'entrée se distingue-t-elle assez ? | à vérifier (R248) |
| Didacticiel | nouvelle fiche « Recombineur » (Explications) | le dessin animé est-il clair ? | à vérifier |

## Monde 10 – Filaments (en attente)

| Niveau | Problème | Statut |
|---|---|---|
| Monde 10 – niveaux 2, 9, 10, 11 | pas de solution de référence, gagnables sans corde ; deux essais échoués (voir `REPRISE-SESSION.md` §2) | décision de Simon |

## Hors niveaux

| Où | Quoi | Statut |
|---|---|---|
| Accueil | icône Quantone sonore (particule + trois ondes, R240) ; trop « Wi‑Fi » ? | à vérifier |
| Fin (« Les retrouvailles ») | bande son, bruitages d'impacts ; la violette reste sur la plateforme (Mécanique, R237) | à vérifier |
| Fin | vibrations : impossibles sur iPhone depuis le web (API absente) | connu |

## Décisions en attente

- Quantone en deux volets (Boucle / Morceau) : une boucle = tout le dessin ? 4 pistes ? automation d'abord sur la boucle ?
  (`REPRISE-SESSION.md` §2).

## R250 — Quantone (à l'oreille / sur iPhone)
- Corde, Écume, Onde : timbre et volume au regard des autres instruments (niveaux mesurés : Corde 0,05→ réglé, Écume 0,07, Onde 0,14, Sampler 0,18).
- Sampler : import d'un fichier depuis l'iPhone, enregistrement au micro (iPhone / interface USB), glisser les repères au doigt, tranches, boucle tenue.
- Fonctions 11–20 : écouter chacune sur Mélodie et Synthé ; la goutte et le chirp (hauteur qui monte), la pédale tanh (saturation par mesure).
- Micro dans l'artefact Quantone : probablement bloqué par l'hôte ; dans le jeu, `allow="microphone"` posé.

## R251 — Quantone (à l'oreille / au doigt)
- Volume instrument : 0 = muet, 300 % assez fort ? (loi linéaire).
- Boîte à rythmes : niveau suffisant ? glisser le doigt sur les pas sur iPhone (ne doit pas faire défiler la page) ; 16 motifs justes ?
- Accords et Voix : timbre, volume ; la voix à formants sonne-t-elle comme un chœur ?

## R253
- X‑Y : regarder sur iPhone la fluidité (animation continue, 60 i/s) et la lisibilité du trait ; dire si le sable doit être plus/moins dense.
- Boîte à rythmes : lancer ▶ sans trait, avec un effet actif, puis exporter .wav ; confirmer que le comportement « trait Rythmes = largeur d'ouverture de la boîte » convient.
