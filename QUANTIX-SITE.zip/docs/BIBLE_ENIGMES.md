# QUANTIX — LA BIBLE DU DESIGN D'ÉNIGMES

*Version 2 (R78). Remplace `REFERENCE_DESIGN_ENIGMES.md` (v1). Document de référence pour toute conception de niveau, de
monde et d'enchaînement. Chaque idée attribuée à un auteur renvoie à une source numérotée [S‑n] (Partie X). Ce qui est
l'interprétation pour Quantix est marqué ▸.*

**Sommaire** — I. Ce qu'est une énigme · II. Ce qui se passe dans la tête · III. Anatomie d'une énigme · IV. Méthodes de
conception · V. Le cas des jeux de physique et de dessin · VI. Échelle du monde et du jeu · VII. Outils et automatisation ·
VIII. Corpus de jeux · IX. Application à Quantix (le protocole) · X. Sources

---

## I. CE QU'EST UNE ÉNIGME

**I.1 Définitions.**
- Scott Kim : une énigme est un problème amusant à résoudre et qui a une bonne réponse ; il peut y en avoir plus d'une. [S‑1]
- Jesse Schell (*The Art of Game Design*, chap. « Game Mechanics Support Puzzles ») : une énigme est un jeu doté d'une
  **stratégie dominante** ; le but est de la découvrir. Une énigme résolue cesse d'être amusante. [S‑2]
- ▸ Pour Quantix : la « stratégie dominante » d'un niveau est son **idée** ; le joueur ne cherche pas un tracé, il cherche
  une idée. Une fois trouvée, le niveau doit être fini : pas de répétition mécanique.

**I.2 L'énigme dit une vérité du système.**
- Blow et ten Bosch : explorer un système (« si X arrive, quelles conséquences ? ») pour trouver ses idées centrales, et
  préférer les systèmes qui expriment ces vérités le plus proprement, à l'opposé des techniques « combinatoires ». [S‑3]
- Blow décrit *Braid* : chaque énigme se résout d'une manière précise, et c'est en la résolvant que l'idée est communiquée,
  sans mots ; *The Witness* pousse ce principe aussi loin que possible. [S‑4]
- Le créateur de *Pipe Push Paradise*, conseillé par Alan Hazelden : la difficulté est périphérique ; toute énigme digne de ce
  nom illustre une vérité du système ; on doit pouvoir formuler l'idée de chaque énigme, sinon elle n'est pas spéciale. [S‑5]
- Patrick Traynor (*Patrick's Parabox*) : le but du système n'est pas de faire de belles énigmes, le but des énigmes est de
  **montrer le système** ; il visait une difficulté abordable, pour montrer et non pour coincer. [S‑6]
- Mouvement « thinky games » : des énigmes « honnêtes », là pour communiquer des idées, pas pour allonger la durée ni masquer
  une mécanique faible. [S‑7]

**I.3 Les principes de Schell.** Rendre le but clair ; facile de commencer ; donner un sentiment de progrès ; un sentiment de
**solvabilité** ; plusieurs énigmes à la fois ; et finalement « donner la réponse ». [S‑2]

---

## II. CE QUI SE PASSE DANS LA TÊTE DU JOUEUR

**II.1 L'insight (« Aha ! ») — psychologie cognitive.** L'insight passe par l'**impasse** puis la **restructuration** de la
représentation du problème ; atteindre l'impasse augmente la probabilité d'un « Aha ». La restructuration se fait en
**relâchant des contraintes que l'on s'est imposées**. [S‑8] Knoblich, Ohlsson et al. décrivent deux mécanismes :
**relâcher une contrainte** sur la solution et **décomposer un bloc perceptif** ; surmonter l'impasse est un cas particulier
du besoin général de passer outre l'expérience passée face à une situation nouvelle. [S‑9] La difficulté d'un problème
d'insight dépend surtout du **degré de changement de représentation** exigé, bien plus que des heuristiques. [S‑10] Dans le
problème des neuf points, l'espace de recherche initial peut être si vaste qu'on n'atteint même pas l'impasse. [S‑11]
- ▸ Un niveau ne produit un « Aha » que s'il **arrête** d'abord le joueur. Concevoir un niveau, c'est choisir **quelle
  contrainte implicite** il devra relâcher (Partie IX.2).
- ▸ L'espace de recherche doit être **assez petit** pour que l'impasse arrive vite : trop de possibilités = errance, pas
  d'impasse. C'est l'argument scientifique de la sobriété.

**II.2 Eurêka n'est pas fiero.** Elyot Grant distingue deux axes : l'**eurêka** (compréhension soudaine) et le **fiero**
(plaisir de vaincre une difficulté). Le « speedy thing goes in, speedy thing comes out » de *Portal* est faible en fiero mais
fort en eurêka ; une énigme rendue difficile pour flatter le joueur ne produit que du fiero. [S‑12]
- ▸ Quantix vise l'**eurêka**. La difficulté d'exécution (P_ligne bas) ne produit qu'un faux fiero, frustrant.

**II.3 L'échec.** Jesper Juul : les joueurs préfèrent les jeux où ils se sentent **responsables** de l'échec ; il décrit un
cycle échec‑amélioration. [S‑13] L'échec se lit sur des axes (interne/externe, stable/instable…) qui disent s'il paraît
juste et si l'on se sent capable de progresser. [S‑14]
- ▸ Chaque échec dans Quantix doit être **lisible** (on voit pourquoi) et **attribuable au joueur** (« j'ai mal pensé »),
  jamais au hasard de la physique. C'est le rôle du leurre.

**II.4 Mémoire de travail, bruit, flow (Brett Taylor, *Linelight*).** Un débutant consomme plus de mémoire de travail
qu'un expert ; le **flow** demande une difficulté entre l'anxiété et l'ennui. Le **bruit** = tout ce qui occupe la mémoire
sans contribuer à la solution ; il est le plus souvent nuisible, mais peut servir à **masquer** une solution évidente ou à
empêcher une résolution par accident ; les fausses pistes sont du bruit utilisé pour orienter la première hypothèse. [S‑15]

**II.5 La confiance.** Taylor : si le joueur suppose qu'aucune adresse n'est requise et qu'on trahit cette confiance une
fois, il soupçonnera chaque énigme ; « la perception du joueur est la seule réalité ». [S‑15]
- ▸ Contrat de Quantix : **« comprendre, jamais réussir à tracer »**. Un seul niveau qui exige de la précision casse ce contrat
  pour tout le jeu.

---

## III. ANATOMIE D'UNE ÉNIGME

**III.1 Le modèle GMTK (Mark Brown).** [S‑15]
1. **Les mécaniques** : leurs règles et limites forment la base ; le **but doit être clair** : la difficulté porte sur
   *comment* y arriver, pas sur *ce qu'il faut faire*.
2. **Le piège** (« catch ») : une **contradiction logique**, deux choses en conflit direct.
3. **La révélation** : souvent, une solution simple et évidente semble exister ; on l'essaie, elle échoue, et il faut
   abandonner cette hypothèse pour reconstruire son modèle mental. Ce leurre sert aussi de **point de départ** pour comprendre
   les règles.
4. **La présentation** : seulement les éléments nécessaires ; tout le reste distrait ou égare.
5. **La courbe** : monter progressivement, en s'appuyant sur ce qui est su.

**III.2 Les onze propriétés d'une bonne énigme (Jonas Tyroller).** Actions aux conséquences prévisibles ; règles simples ;
défi souvent de trouver une **séquence** d'actions ; toute l'information nécessaire est visible ; aussi complexe et aussi
grande que nécessaire, pas plus ; belle ; **joue avec les attentes** ; **enseigne quelque chose de nouveau sur le système** ;
nombreuses itérations ; beaucoup testée par d'autres. [S‑15]

**III.3 Les sept leçons de Brett Taylor.** [S‑15]
1. **Simplifier** : décrire la solution, puis retirer tout ce qu'on n'a pas mentionné ; le bruit s'ajoute ensuite,
   intentionnellement et prudemment.
2. **Couper les niveaux inutiles** : chaque niveau a une raison — enseigner une mécanique, renforcer un savoir‑faire, un
   moment unique et identifiable, une respiration du rythme.
3. **Vous êtes le joueur expert** : finir son niveau « avec les pieds » ; connaître la solution sans pouvoir l'exécuter est
   détestable.
4. **Séparer action et énigme** (pour les énigmes à solution unique).
5. **Des solutions sans ambiguïté** : signaux d'alarme « C'était ça ? », « J'ai réussi ? », un joueur qui tente des actions
   impossibles ; une énigme se résout en pensant avant d'agir ; ce qui n'est pas la solution doit le paraître.
6. **La confiance** (II.5).
7. **Exhaustivité contre plaisir** : montrer « une de chaque chose possible » n'est pas forcément amusant.
- **Les « phrases de solution »** : décrire la solution en une phrase et chercher l'énigme la plus simple qui l'impose ; chaque
  phrase est comme le secret d'un tour de magie : connue, l'énigme est triviale ; inconnue, c'est de la magie.

**III.4 La « double prise » (double take).** Des énigmes qui trompent d'abord, en rendant facile une mauvaise hypothèse. [S‑15]
Exemple de GMTK dans *Lara Croft GO* : une dalle qui casse au second passage est d'abord montrée comme le moyen de vaincre un
ennemi, puis devient la **mauvaise** solution dans la seconde partie. [S‑15]

---

## IV. MÉTHODES DE CONCEPTION

**IV.1 À rebours depuis la solution (Arvi Teikari, *Baba Is You*).** Partir d'une interaction intéressante, donc de la
solution, puis remonter en posant des restrictions ; la solution peut être simple, l'énigme vient de ce qu'elle est cachée
derrière une suite de problèmes. [S‑16] Une bonne part de la conception consiste à **empêcher** plutôt qu'à permettre. [S‑15]

**IV.2 Fermer les solutions imprévues (Valve, *Portal*).** Une énigme devait enseigner le lien cube‑bouton ; une solution
astucieuse la contournait ; jugée comme un **échec**, elle a été bloquée par une vitre. Des testeurs longeaient des rails
jusqu'à la sortie ; une énigme qui introduisait trop de concepts à la fois a été déplacée. [S‑17] Les testeurs supposaient que
les portails orange étaient des sorties : une énigme a été créée pour **forcer** à entrer dans un orange. [S‑17]
- ▸ Chaque raccourci trouvé donne **deux** choses : une restriction (fermer) et, parfois, **un autre niveau** (IV.3, « transformer
  les solutions alternatives »).

**IV.3 La boîte à idées de Patrick Traynor** (stratégies collectées auprès de concepteurs du genre) [S‑18], avec leur traduction ▸ :

| Stratégie | Description (Traynor) | ▸ Traduction Quantix |
|---|---|---|
| Trouver une interaction et la forcer | construire l'énigme autour d'un coup requis | « la particule doit rebondir sur le bout du mur » |
| Faire se rencontrer les mécaniques | que se passe‑t‑il quand A rencontre B ? | glace + tapis ; vent + aimant ; corde + gravité |
| Énumérer toutes les paires | tableau des paires de mécaniques | matrice 11 × 11 des éléments de Quantix |
| Énumérer des séquences d'actions | forcer A puis B, B puis A, AAB… | tracer avant / pendant la chute, dans un ordre imposé |
| Essayer les extrêmes | dispositions extrêmes | presque tout l'écran en zone interdite ; énergie pour 30 u |
| Géométrie intéressante | niveau étroit, symétrique, sans murs | niveau sans sol ; niveau en miroir où l'idée s'inverse |
| Créer un niveau impossible, puis le rendre possible | ou trouver une faille et la camoufler | partir d'une zone inaccessible et chercher la faille physique |
| Partir d'un niveau possible et le rendre impossible, puis annuler la dernière modification | — | la forme la plus tendue d'une idée |
| Enseigner ce qu'on veut faire apprendre | une règle, un cas limite, une technique | ex. « le trait tracé pendant la chute existe » |
| Trouver une déduction et la forcer | la déduction est la clé de voûte | « l'énergie ne suffit que pour un trait : il n'y a qu'un endroit » |
| Chaîne de conception « vers l'avant » | poser des objets pour créer une suite de déductions que le joueur suivra | niveaux de fin de monde |
| Invariant | géométrique, topologique, de séquence | « la particule repasse toujours par ce point » |
| Phénomènes émergents | parité, boucles, réversibilité | boucle sur un tapis ; pendule ; aller‑retour |
| Gadgets | tunnel à sens unique, verrou, compteur | sas à sens unique fait de deux traits ; « interrupteur » glace/structure |
| Partir d'un thème | narratif ou géométrique | l'expérience de physique réelle du monde |
| Viser une émotion | fort, claustrophobe, surpris | vertige, lenteur, apesanteur |
| Faire une blague | objet utile devenu gênant et inversement ; énigme qui a l'air dure mais est facile | les pointes qui sauvent ; le tapis qui condamne |
| Guetter les « presque » | un plan de testeur qui échoue de peu → un niveau où il réussit | **tes tests** sont la meilleure source |
| Transformer les solutions alternatives en niveaux | le raccourci bloqué devient un niveau où il est forcé | chaque raccourci de `enigme.js` est un candidat |
| Partir des niveaux d'autres jeux / traduire | adapter, sans plagier | traduire une énigme de *Portal* ou de *Baba Is You* en physique |
| Couper deux niveaux en deux | concevoir l'intermédiaire | combler un trou de la courbe |
| Générateurs et solveurs | générer puis réviser | notre forge **comme carrière de matériaux**, jamais comme auteur |

Traynor ajoute : beaucoup d'idées n'aboutissent pas ; explorer les **variantes** pendant l'itération (plus facile, plus dure,
un retournement) — une idée peut donner plusieurs niveaux. [S‑18]

**IV.4 Exercices d'Eric Zimmerman (*The Rules We Break*)** : une énigme a une réponse qu'on conçoit **puis cache** ; penser au
« Aha » ; épuiser les possibilités d'éléments simples avant d'en ajouter. [S‑19]

---

## V. LE CAS DES JEUX DE PHYSIQUE ET DE DESSIN

**V.1 Deux philosophies.**
- **Ouverte** : Petri Purho a volontairement écarté les restrictions habituelles (ressources limitées, une ou deux solutions)
  pour *Crayon Physics Deluxe* ; le jeu ne vise pas une solution précise mais des solutions créatives. [S‑20][S‑21] Un critique
  note que l'illusion d'absence de limites a ses bornes : des stratégies rigides et grossières finissent par fonctionner. [S‑22]
- **Plusieurs solutions revendiquées** : *Brain It On!* et *Shatterbrain* annoncent plusieurs façons de résoudre chaque
  énigme et invitent à chercher « la meilleure ». [S‑23][S‑24]
- **Optimisation** : Zachtronics livre des énigmes ouvertes, puis montre des statistiques d'efficacité comparées par
  histogrammes. [S‑25][S‑26]
- ▸ **Position de Quantix** : *fermée pour réussir, ouverte pour exceller* — une idée obligatoire, une réalisation libre au doigt,
  une maîtrise (noyau, énergie) ouverte et comparable.

**V.2 Le problème du brute force et de la victoire accidentelle.** Dans *Ruin* (puzzle de physique), le concepteur vise
explicitement le problème de beaucoup de jeux de physique : le joueur peut « forcer » une énigme et la résoudre autrement
que prévu ; il règle le nombre de bombes et de clics pour l'éviter. [S‑27]
- ▸ C'est exactement le défaut de la Chaîne (ligne directe avec l'accélérateur). L'**énergie** et les **matières offertes** sont
  nos « bombes et clics » : elles se règlent pour fermer le brute force.

**V.3 Déterminisme.** Les créateurs de *Contraption Maker* ont dû ajouter un contrôle automatique de déterminisme, car un
même départ ne donnait pas toujours la même suite sur toutes les plateformes. [S‑28]
- ▸ Une énigme physique n'est juste que si **la même idée donne toujours le même résultat**. À vérifier sur téléphone (pas
  seulement dans le moteur de test).

**V.4 Solutions émergentes.** Emily Short : les solutions imprévues naissent quand des attributs communs à beaucoup d'objets et
des processus combinables existent, et que le nombre d'énigmes dépasse ce que l'auteur peut anticiper ; elles compliquent la
maîtrise du récit. [S‑29]
- ▸ La physique de Quantix est émergente **par nature** : la recherche active de raccourcis (IX.4) n'est pas optionnelle.

**V.5 Les « boîtes » de *Cut the Rope*.** Niveaux par 25 dans une boîte au thème propre, chacune introduisant une mécanique ;
le joueur sait qu'il aura le temps de la maîtriser ; la difficulté vient du nombre d'interactions, du timing, de la dextérité. [S‑30]
- ▸ Garder le contrat de la boîte (un monde = une mécanique), **retirer** la dextérité et le timing serré.

---

## VI. ÉCHELLE DU MONDE ET DU JEU

**VI.1 Kishōtenketsu (Nintendo).** Koichi Hayashida : décider d'un concept central pour chaque niveau et le porter jusqu'au
bout ; introduction, développement, **retournement**, conclusion, structure transmise par Miyamoto. [S‑31] Mark Brown :
une mécanique enseignée, développée, retournée puis abandonnée en cinq minutes. [S‑32]

**VI.2 La langue de *The Witness*.** Chaque rangée de panneaux introduit **une** idée, puis la tord de panneau en panneau ;
« ces énigmes m'apprennent une langue, une grammaire » écrit un journaliste. [S‑33] Blow : chaque énigme porte un petit
morceau de l'idée, comme des phrases dans un autre mode de communication. [S‑34] Les premières versions paraissaient
« répétitives » quand on enchaînait les énigmes sans pause. [S‑35]

**VI.3 Le monde 1 de *Patrick's Parabox*.** Combiner des concepts déjà vus est une excellente source d'idées ; laisser au
joueur **d'autres énigmes ouvertes** pour que son inconscient travaille sur celle qui le bloque ; le concepteur porte la
« malédiction de l'expert ». [S‑36]

**VI.4 *Portal* : un long entraînement.** Les auteurs décrivent le jeu comme un exercice de formation prolongé ; malgré
l'objectif d'apprentissage en couches, certains concepts ont été introduits trop vite. [S‑17]

**VI.5 Progression par caractéristiques de solution.** La recherche sur *Refraction* (Butler, Smith et al.) conçoit des
progressions en analysant les **caractéristiques des solutions** et en respectant l'ordre d'introduction des concepts, avec des
outils de conception mixte homme‑machine. [S‑37][S‑38]

▸ **Gabarit de monde Quantix (12 niveaux)** :

| Pos. | Temps | Fonction (Taylor : raison d'être) |
|---|---|---|
| 1 | Ki | **Enseigner** la vérité du monde, sans mots, par la seule solution possible |
| 2–3 | Ki | renforcer ; première hypothèse fausse (facile) |
| 4–6 | Shō | combiner avec les mondes précédents ; premières impasses |
| 7 | Ten | **retournement** : la mécanique se retourne contre le joueur |
| 8–9 | Ten | la vérité révèle une seconde face (inversion, détour) |
| 10–11 | Ketsu | deux idées du monde ensemble ; un « moment unique » |
| 12 | Ketsu | rappel du niveau 1, renversé |

Plus, à l'échelle du jeu : **plusieurs niveaux accessibles en même temps** (VI.3), pour ne jamais bloquer le joueur sur un seul.

---

## VII. OUTILS ET AUTOMATISATION

**VII.1 La recherche l'a formalisé.** Adam Smith et ses collègues emploient le terme **« solution raccourci »** pour toute
manière de jouer que le concepteur ne veut pas voir réussir, et étendent la programmation par ensembles‑réponses (ASP) pour
**contraindre les solutions indésirables** et imposer qu'un niveau se résolve **de certaines manières**. [S‑39][S‑40] Leur
générateur produit des énigmes avec des **contraintes dures sur les solutions**. [S‑41] Ils ont aussi conçu des outils
**mixtes** où le concepteur pose des contraintes et la machine vérifie et propose. [S‑38]
- ▸ `enigme.js` est une version empirique de cette idée (recherche de raccourcis par simulation). Évolution à prévoir :
  exprimer chaque niveau comme **« toute solution doit … »** (toucher X, passer par Y, dans l'ordre Z) et chercher activement
  un contre‑exemple.

**VII.2 Ce que la machine ne fait pas.** Taylor : générer donne des énigmes en nombre infini mais peu nouvelles et
prévisibles ; l'artisanat donne des énigmes finies, variées, nouvelles. [S‑15] ▸ Confirmé par notre forge.

---

## VIII. CORPUS DE JEUX À ÉTUDIER

| Jeu | Pourquoi | Leçon pour Quantix |
|---|---|---|
| *Braid* | énigmes qui communiquent une idée sans mots [S‑4] | une mécanique explorée jusqu'au bout |
| *The Witness* | une langue apprise panneau par panneau [S‑33] | un monde = une grammaire |
| *Baba Is You* | conception à rebours [S‑16] | partir de la solution |
| *Stephen's Sausage Roll* | dépouillement radical, influence majeure du genre [S‑7] | rien que l'idée |
| *Sokobond*, *Cosmic Express*, *A Monster's Expedition* | verbaliser l'idée [S‑5] ; risque de niveaux qui se ressemblent [critiques] | variété obligatoire |
| *Patrick's Parabox* | montrer le système, difficulté abordable [S‑6] | l'élégance avant la difficulté |
| *Linelight* | bruit, phrases de solution [S‑15] | budget de bruit |
| *Portal* | apprentissage en couches, fermeture des raccourcis [S‑17] | la vitre de *Portal* |
| *Lara Croft GO* | double prise [S‑15] | un élément montré utile, puis piège |
| *Super Mario 3D Land/World* | kishōtenketsu [S‑31] | structure de monde |
| *Cut the Rope* | boîtes thématiques [S‑30] | un monde, une mécanique |
| *Crayon Physics Deluxe* | dessin + physique, liberté [S‑20] | le geste comme langage |
| *Brain It On!*, *Shatterbrain* | plusieurs solutions, « la meilleure » [S‑23][S‑24] | couche de maîtrise |
| *Ruin* | contrer le brute force en physique [S‑27] | doser énergie et matières |
| *Contraption Maker* | déterminisme [S‑28] | vérifier sur appareil |
| *SpaceChem*, *Opus Magnum* | ouverture + optimisation [S‑25] | histogrammes de maîtrise |
| *Refraction* | contraintes formelles sur les solutions [S‑39] | « toute solution doit … » |
| *Snakebird*, *Antichamber*, *Fez*, *Monument Valley*, *Outer Wilds*, *Return of the Obra Dinn*, *World of Goo*, *Poly Bridge*, *The Incredible Machine* | à étudier (non sourcés ici) | impasse dure, perception, savoir comme clé, construction |

---

## IX. APPLICATION À QUANTIX — LE PROTOCOLE

### IX.1 Les dix commandements (synthèse)
1. **Une idée, formulable en une phrase** (Hazelden, Taylor). Sinon, pas de niveau.
2. **Une vérité du système** à montrer (Blow, ten Bosch, Traynor).
3. **Une hypothèse du joueur à faire tomber** — le « catch » (Brown) — par une **impasse** (psychologie de l'insight).
4. **Un leurre** qui échoue lisiblement et dont le joueur se sent responsable (Juul).
5. **Rien d'autre que le nécessaire** ; le bruit seulement s'il est voulu (Taylor).
6. **Aucun raccourci** : la vitre de *Portal* pour chacun ; puis le raccourci devient peut‑être un autre niveau (Traynor).
7. **Jamais de précision** : ce qui est compris doit réussir (Taylor, « avec les pieds »).
8. **Le but est clair** : la difficulté porte sur le comment (Brown, Schell).
9. **Chaque niveau a une raison d'être** dans son monde (Taylor) et un temps du kishōtenketsu (Hayashida).
10. **Le test du joueur décide** (Valve).

### IX.2 Le moteur créatif : hypothèses implicites du joueur de Quantix ▸
*(À confirmer par tes tests : lesquelles portes‑tu réellement ?)*

| # | Hypothèse | Niveau qui la fait tomber |
|---|---|---|
| H1 | un trait est un sol | trait‑mur, trait‑plafond, déflecteur en vol |
| H2 | on trace avant de lâcher | il faut tracer pendant la chute |
| H3 | le plus court est le mieux | le détour est la seule voie |
| H4 | les pointes sont à fuir | rebondir juste à côté d'elles |
| H5 | la mécanique du monde aide | elle gêne ici |
| H6 | plus d'énergie, plus de choix | l'énergie ne permet qu'un trait, au seul endroit |
| H7 | la particule doit rester à l'écran | elle sort par le haut et revient |
| H8 | il faut viser la zone | il faut viser un mur |
| H9 | le décor est inerte | un mur fixe est la moitié de la construction |
| H10 | un trait = un geste | deux traits dont l'ordre compte |
| H11 | le sens du tracé n'importe pas | le tapis tracé à l'envers |
| H12 | monter exige une aide visible | une chute plus haute donne l'élan |
| H13 | le noyau est sur le chemin | il est sur le leurre : le prendre exige une seconde idée |
| H14 | ce qui est loin ne compte pas | l'élément décisif est à l'autre bout |
| H15 | un élément = une fonction | le même mur sert deux fois (aller, retour) |
| H16 | la zone interdite est un obstacle | elle est un **indice** : elle désigne où ne pas chercher, donc où chercher |

### IX.3 La fiche de niveau (v2) — obligatoire
```
Référence · Titre fr/en · Monde, position, temps (Ki/Shō/Ten/Ketsu), raison d'être (Taylor)
Vérité du système montrée :
Phrase de solution (≤ 15 mots) :
Hypothèse du joueur qui tombe (H‑xx) :
Leurre (ce qu'il essaiera d'abord) et pourquoi il échoue — visiblement :
Scénario de résolution attendu : « il essaie A, échoue parce que B, comprend C »
Stratégie de création utilisée (Traynor, IV.3) :
Éléments et rôle de chacun (PORTER / FERMER tel raccourci / PIÉGER / BRUIT voulu) :
Raccourcis identifiés et la « vitre » qui ferme chacun :
Énergie et matières offertes (et ce qu'elles ouvriraient) :
Mesures (banc, fiche.js, enigme.js) :
Variantes possibles (plus facile / plus dure / retournement) :
Test de Simon : premier essai, impasse ?, « Aha » ?, autre chemin trouvé ?
```

### IX.4 Les portes de validation (v2)
| Porte | Question | Outil |
|---|---|---|
| P1 | La phrase de solution tient en une ligne et dit une vérité du système ? | relecture |
| P2 | L'hypothèse qui tombe est‑elle différente de celles du monde ? | registre |
| P3 | Le leurre échoue‑t‑il **lisiblement** ? | simulation + capture |
| P4 | Toute solution utilise‑t‑elle l'idée ? (0 raccourci) | `enigme.js` |
| P5 | Chaque élément a‑t‑il un rôle ? (0 inutile) | `enigme.js` |
| P6 | Jouable « avec les pieds » ? (tolérance, aucune précision) | `fiche.js` |
| P7 | Espace de recherche assez petit pour une impasse rapide ? | revue des éléments |
| P8 | Le scénario « A → échec B → C » se réalise‑t‑il chez le joueur ? | **ton test** |

### IX.5 Anti‑modèles (constatés dans Quantix)
Solution = première idée (« Le tapis ») · élément décoratif (« Le relais 2 », pointes au fond d'un vide qui tue déjà) ·
matière offerte qui ouvre tout (accélérateur de la Chaîne) · niveaux jumeaux · difficulté par imprécision · génération
combinatoire sans intention · échec non lisible (la particule cale sans qu'on comprenne pourquoi).

### IX.6 Ce qu'il reste à faire pour que cette bible soit complète
1. Visionner et résumer les conférences primaires : Taylor (*Puzzle Game Magic Secrets*, *Puzzle Vocabulary Toolbox*),
   Grant (*30 Puzzle Design Lessons*), Menzel (GDC 2016), Barth (GDC 2019), Traynor (GDC 2024), Rix et Voinov (GDC).
2. Décortiquer dix niveaux de référence (hypothèse qui tombe, leurre, phrase de solution).
3. Valider H1–H16 par tes tests.
4. Matrice des paires de mécaniques de Quantix (11 × 11) — source de niveaux.
5. Réécrire le cahier des charges en conséquence, puis refaire un monde témoin.

---

## X. SOURCES

[S‑1] Scott Kim, TED « The art of puzzles » (définition) — digitalcast.jp/v/13650 ; rosetta.to/person/scott-kim
[S‑2] Jesse Schell, *The Art of Game Design* : principes des énigmes (supports de cours UW CSE481d, docswell « Game Mechanics Support Puzzles »)
[S‑3] Marc ten Bosch, « Designing to Reveal the Nature of the Universe » — marctenbosch.com/news/?p=181
[S‑4] Jonathan Blow, entretien *Edge* (2016) — pressreader.com/australia/edge/20160210
[S‑5] Xbox Wire, *Pipe Push Paradise* — news.xbox.com/en-us/2019/02/11/pipe-push-paradise-xbox-one
[S‑6] Patrick Traynor, « System‑Centric Puzzle Design », diapositives GDC 2024 — media.gdcvault.com/gdc2024/…/Traynor_Patrick_SystemCentricPuzzle.pdf
[S‑7] Thinky Games, dix ans de *Stephen's Sausage Roll* ; CESCG 2023 « Designing Thinky Games »
[S‑8] Frontiers in Human Neuroscience (2018), sommeil et problèmes d'insight
[S‑9] Knoblich, Ohlsson, Haider, Rhenius (1999), *JEP:LMC* — research.ceu.edu
[S‑10] Öllinger, Jones, Knoblich, problèmes d'allumettes à deux mouvements — irep.ntu.ac.uk/id/eprint/25198
[S‑11] Öllinger, Jones, Knoblich (2014), problème des neuf points — irep.ntu.ac.uk/id/eprint/13600
[S‑12] « Eureka is not Fiero », d'après Elyot Grant — diplograph.net/notes/games/puzzle-design/eureka-is-not-fiero
[S‑13] Big Think, sur Jesper Juul, *The Art of Failure*
[S‑14] Liz England, critique de *The Art of Failure* — lizengland.com
[S‑15] Juha‑Matti Santala, « Puzzle game design » (notes sur GMTK, Brett Taylor, Jonas Tyroller, double take, troll levels) — notes.hamatti.org/gaming/puzzle-game-design
[S‑16] Transcription GMTK « How Baba Is You Works » — amara.org
[S‑17] Commentaire des développeurs de *Portal* — theportalwiki.com/wiki/Portal_developer_commentary
[S‑18] Patrick Traynor, « Puzzle Level Idea Strategies » — cwpat.me/misc/puzzle-level-idea-strategies
[S‑19] Exercices d'après Eric Zimmerman, *The Rules We Break* — mycours.es/egd/?p=1033
[S‑20] NBC News, entretien avec Petri Purho
[S‑21] TIGSource, entretien avec Petri Purho (Level)
[S‑22] Technologizer, critique de *Crayon Physics Deluxe*
[S‑23] App Store, *Shatterbrain* (Orbital Nine)
[S‑24] ModDB, *Brain It On!*
[S‑25] Wikipédia, Zachtronics
[S‑26] GDC Vault, « Open‑Ended Puzzle Design at Zachtronics » (2019)
[S‑27] Game Developer, « Ruin — A Study in Physics‑Based Level Design »
[S‑28] SiliconANGLE, sur *Contraption Maker* et le déterminisme
[S‑29] Emily Short, « Emergent Puzzle Solutions » — emshort.blog/2008/02/13/emergent-puzzle-solutions
[S‑30] Mechanics of Magic, analyse de *Cut the Rope*
[S‑31] Game Developer, « The secret to Mario level design » (Hayashida)
[S‑32] MCV, « Nintendo's level design secrets in four steps » (GMTK)
[S‑33] Kotaku, « Two hours with Jonathan Blow's The Witness »
[S‑34] TechRadar, entretien avec Jonathan Blow
[S‑35] Game Developer, « Bearing Witness »
[S‑36] Siddarth R. G., « Tutorial Design of Patrick's Parabox »
[S‑37] Butler et al., « A Mixed‑Initiative Tool for Designing Level Progressions in Games » — grail.cs.washington.edu
[S‑38] Idem (outils mixtes, contraintes de cohérence)
[S‑39] Smith et al., « Quantifying over Play: Constraining Undesirable Solutions in Puzzle Design » — grail.cs.washington.edu
[S‑40] Smith et al., « A Case Study of Expressively Constrainable Level Design Automation Tools for a Puzzle Game »
[S‑41] E. Butler, *Infinite Refraction* (générateur à contraintes dures sur les solutions) — github.com/edbutler/infinite-refraction
[S‑42] Game Developer, « Is your game juicy enough? » — Jonasson & Purho, GDC Europe 2012
[S‑43] Game Developer, « Indies, resist the urge to juice it or lose it » — Folmer Kelly
[S‑44] Andy Matuschak, notes sur *The Incredible Machine* — notes.andymatuschak.org
[S‑45] Giant Bomb, concept « Rube Goldberg Puzzler »

---

## XI. MACHINES ET SPECTACLE (ajout R79)

Le **jus** désigne ce qui rend une interaction satisfaisante : des choses qui bougent, rebondissent, font de petits sons ;
« un maximum de retour pour un minimum d'action » (Jonasson et Purho) [S‑42]. Folmer Kelly met en garde : le jus pour le
jus peut coûter l'immersion [S‑43]. Dans *The Incredible Machine*, le nombre limité de pièces sert surtout à **borner la
complexité** et rendre le niveau soluble, et les niveaux introduisent les pièces une à une [S‑44] ; le genre des énigmes
« Rube Goldberg » consiste à déclencher une chaîne de réactions pour un but simple [S‑45].
▸ Application : les **buts intermédiaires et machines** (montagnes russes de la particule) sont spécifiés dans
`CAHIER_DES_CHARGES_GENERATION.md` §2–3 : relais, machine déterministe sur rail guidé, chorégraphie, fonctions dramatiques.
