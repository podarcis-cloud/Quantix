# QUANTIX — ÉTAT (source de vérité unique)

**Version de référence : R266 — 23 octobre 2026.** Tampon du code : `build R271`. Vérifier avant tout travail de code : `grep -o 'build R[0-9]*' index.html` doit afficher **R270** ; sinon ce
n'est pas le dernier zip → le demander à Simon.

**Au démarrage, lire aussi `DEMARRAGE.md` (1 page)** : où décompresser le zip, quoi ne pas relire, comment traiter un
défaut vu sur iPhone. Il résume les erreurs des sessions R262–R263.

*Ce document remplace le haut de l'ancien `REPRISE-SESSION.md`. Il reste court (< 8 Ko) : on le réécrit à chaque lot, on
ne l'empile pas. L'historique va dans `JOURNAL.md`.*

---

## 1. Ce qui est dans le jeu (déployable)

Accueil Visière + héros ; Constellation et pages de monde ; 132 niveaux (11 mondes × 12) ; plein cadre ; didacticiel
holographique ; bilan animé ; fin « Les retrouvailles » (`fin5`) et bilan du parcours ; Quantone intégré ; FR/EN ;
sauvegarde locale. **Caché** : Zen Lab, Quantum Drop, atelier de particule (D5). **Inactif** : bouton Ko-fi.

## 2. Derniers lots (détail : `JOURNAL.md`)

- **R272–R274** : banc des rendus : aspiration par le trou noir. R273 : trois propositions (A vortex, B toile, C fil). R274 : Simon retient la toile avec poussière plus réaliste et anneaux de C ; deux variantes B2 (grains + filaments) et B3 (nappe de poussière), cœur blanc texturé et flash petit. À choisir par Simon ; pas dans le jeu.
- **R275** : banc des rendus : naissance de la particule en début de niveau (A éjection lointaine + onde de changement de plan + puits décoratif ; B sortie en profondeur au bassin). À choisir ; pas dans le jeu.
- **R276** : banc : fin (B2 retenue) avec la vraie particule du jeu (`VX.ball`) et explosion verte de la zone (rayons effilés, étincelles, ondes) ; anneaux rose→vert ; naissance avec la vraie particule. À valider.
- **R277** : banc : naissance refaite, plus dynamique et plus discrète : niveau en fondu progressif, trou à la suite de la fin ; A fronde (orbite amortie, étirement, clac), B chute (gravité du jeu, rebonds). À choisir ; pas dans le jeu.
- **R278** : banc : naissance sur un vrai niveau (n° 41 « La combe gelée », capture du jeu `studio/captures/naissance_niveau41.jpg`) ; particule = `VX.ball(c,x,y,ang,10.5)` sans teinte (les versions précédentes la teintaient en cyan : faux). A fronde, B ressort. Piège : le jeu dessine un cercle pointillé de capture autour du départ ; la capture se fait avec `VX.ball` neutralisé et les éléments DOM masqués.
- **R285** : sons d’entrée/sortie ×3 à ×4 et plus aigus (le grave sous 150 Hz ne sort pas d’un haut-parleur de téléphone). Toujours à régler à l’oreille.
- **R286** : sons de transition ×0,75. Captation « parcours joueur bêta » : runlog garde la trajectoire de la bille (`bp`) + hook `QRUNS.onrun` ; l’Aperçu (bâti avec `capture`, publié avec capacité `db`) écrit chaque essai dans la collection `parcours_beta` ; import des JSON mail par Claude. Voir `PARCOURS_BETA.md`. Vérifié : écriture simulée (stub db) OK ; non testé : vraie base (vide tant que Simon n’a pas joué), sons à l’oreille.
- **R287** : parcours bêta enrichis des outils d’édition (`tl`) ; `tools/parcours-rapport.py` compare les tracés des joueurs à la géodésique (`optsol`) ; protocole de révision écrit dans `PARCOURS_BETA.md`. Premier constat (67 essais, Simon, N1–24) : encre ≤45 % utilisée sur la plupart des réussites dès N13 ; N15 et N24 réussis avec bien moins d’encre que la référence (⚠ contournement ou référence non optimale) ; N18–22 échouent 3× en `out` au premier essai. Non testé : tl en conditions réelles (testé par stub).
- **R288** : mesure des outils corrigée (crochet interne `EDT.hook` dans editor.js : le mode d’outil n’était jamais capté en R287). 2ᵉ passage de Simon reçu (110 essais, N1–48, pid e370…) : 0 usage de gomme/déplacer/échelle (modes), échecs surtout `out` (45/59) ; l’encre utilisée varie de ±30 pts entre deux passages du même joueur (N1 80→53 %, N6 85→52 %) → calibrer sur le minimum de plusieurs joueurs. À vérifier au prochain passage : comptage `add` (seulement ~10 essais avec `tl` en R287, cause non élucidée).
- **R289** : lot L1 de `AUDIT_DONNEES.md` — `assets/js/events.js` : journal d’événements (session, niveaux, vues, taps, traits, outils, lâchers, contacts, issues, abandons, sortie de session, erreurs), file locale persistante, envoi par lots (`QEV.sink` / `QEV.endpoint`), crochets multiples `EDT.hook`. Aperçu → collection `evenements_beta`. Décisions de Simon : backend **Cloudflare Worker**, **pays grossier seulement** (pas d’âge). Reste L2 (Worker + consentement + page « données collectées »), L3 (rapports funnel/décrochage/logique). Vérifié : test e2e headless avec stub db ; non testé : appareil réel, volume, mail d’export des événements, `QEV.endpoint`.
- **R290** : lot L2 — `worker/` (ingest.js Cloudflare Worker + D1, schema.sql, LISEZMOI.md pas à pas iPhone) ; consentement invité dès la fin du 1er essai (réussi ou non) ; envoi réseau seulement après Oui ; panneau Paramètres « Ce que collecte Quantix » (voir/effacer) ; textes FR/EN. `ENDPOINT` de events.js **vide** : à renseigner quand Simon aura déployé le Worker (étapes LISEZMOI 1–6). Lecture par Claude : Simon ouvre `/export?key=…` et envoie le fichier (le bac à sable de Claude n’atteint pas workers.dev), import dans la base du Projet. Vérifié : e2e headless (invite, rien avant Oui, 1 envoi après Oui, panneau), Worker testé sur base simulée (doublon, origine, forme, taille, clé). Non testé : vrai Cloudflare, iPhone, CORS réel. Aperçu non republié.
- **Collecte en ligne — déploiement (24 oct.)** : site de jeu = https://podarcis-cloud.github.io/Quantix/ (Origin à autoriser : `https://podarcis-cloud.github.io`, SANS chemin). Worker Cloudflare déployé : `https://quantix-events.mydopeoff.workers.dev` (compte Cloudflare de Simon), base D1 `quantix-events` (tables batches, players), liaison `DB` faite, variables `ALLOWED_ORIGIN` et `ADMIN_KEY` (secret, jamais consigné ici) posées. Reste : vérifier `/stats?key=…`, vérifier la valeur de `ALLOWED_ORIGIN`, puis renseigner `ENDPOINT` dans `assets/js/events.js` (R291).
- **R291** : `ENDPOINT` de events.js = `https://quantix-events.mydopeoff.workers.dev/` (collecte en ligne branchée). Vérifié : `/stats` répond (0 joueur) ; non testé : un vrai envoi depuis le site GitHub Pages (dépend de la valeur de `ALLOWED_ORIGIN`, doit être `https://podarcis-cloud.github.io`). Test à faire par Simon : jouer 1 niveau sur le site, répondre Oui, puis rouvrir `/stats`.
- **R284** : sons d’entrée et de sortie (sound.js : absorb_pull, absorb_burst, birth_open, birth_shot, birth_pass, birth_land), déclenchés par transitions.js et calés sur l’animation ; avec l’aspiration, `level_success` et la vibration partent à l’éclat (≈2,4 s) au lieu de la réussite. Testé : aucun son en erreur, ordre et délais corrects ; NON écouté (aucune écoute possible ici), niveaux à régler à l’oreille sur iPhone.
- **R283** : cause trouvée : l’entrée était sautée dès que l’outil sélection/échelle (`EDT.active()`) restait actif d’un niveau à l’autre ; condition retirée.
- **R282** : l’entrée attend que le niveau soit visible (aucun voile `.veil.on` : carte du monde, pause, bilan) avant de démarrer ; sinon elle se jouait sous la carte entre deux niveaux.
- **R281** : grille de fond retirée de l’entrée et de la sortie (le reste inchangé).
- **R280** : INTÉGRATION dans le jeu (validée par Simon, sans zoom) : `assets/js/transitions.js` (`window.QFX`) ; sortie = aspiration B2 sur l’arrivée réelle (démarre à la réussite, bilan retardé à 3,0 s au lieu de 0,42 s ; dernier niveau : finCine à 3,3 s) ; entrée = fronde A à chaque `loadLevel` (3,5 s, « Lâcher la balle » la termine). Dernier niveau : pas d’aspiration (cohérence avec le final). Sautées : mouvement réduit (`RM`/`OPT.rm`), mode zen, démo solution, niveaux `QP.soft`, éditeur actif. `resetBall` annule tout (jeton `S.absTok`, `S.absHide` cache la bille après l’aspiration). Crochets engine.js : `QFX.draw(c)` à la place de `drawBall`, `QFX.birthStart` dans loadLevel, `QFX.absorbStart` dans `level.complete`. Version allégée auto : `QFX.light` (non branché sur la cadence). Testé (Chromium, niveau 20) : images entrée/sortie, bilan à 3 s, reset, mouvement réduit, aucune erreur de page. NON testé : iPhone, fluidité, sons dédiés, niveaux 93/95 (trop lourds en headless), mode démo.
- R279 (banc) : fin sur zone réelle n° 93, entrée A.
- **R271** : réponse d'envoi mémorisée sous une nouvelle clé (`quantix.runs.consent2`) : les sauvegardes qui avaient un ancien « non » (build R268) revoient l'invite une fois.
- **R270** : mail des parties refait : objet = niveau(x) concerné(s) et résultat ; corps = joueur, statistiques, détail par niveau, JSON complet ; tentative de pièce jointe `.json` (selon l'offre Web3Forms), repli en texte. Les mails reçus par Simon sont collés dans la conversation (pas d'accès direct à sa boîte).
- **R269** : invite d'envoi refaite (retour de Simon : peu claire, polluait le bilan) : fenêtre à part, une seule fois, à la 1re sortie du bilan ; ensuite une ligne discrète « Envoyer cette partie » sous les boutons ; le bilan n'est plus modifié avant le Oui.
- **R268** : clé Web3Forms de Simon posée dans `runlog.js` (`SHARE_KEY`) : envoi actif ; non testé avec le vrai service (réseau de la session bloqué).
- **R267** : envoi anonyme des parties par e-mail (Web3Forms) dans `runlog.js` : choix unique Oui/Non au 1er niveau réussi (jamais pré-coché), case « Envoyer cette partie » ensuite, réglage dans Paramètres ; **inactif tant que `SHARE_KEY` est vide**. Chantier 6, étape 2.
- **R266** : journal local des essais (`assets/js/runlog.js`, clé `quantix.runs.v1`) + Paramètres « Mes parties » (Exporter / Effacer) ; rien n'est envoyé. Chantier 6, étape 1.
- **R265** : nettoyage exécuté (`NETTOYAGE.md` §5) : 34 documents retirés du Projet (copies en `docs/archive/` du zip), 15 mis à jour ; artefact Menu édition supprimé le 23 oct.
- **R264** : inventaire et nettoyage préparés (`NETTOYAGE.md`, à exécuter dans une conversation neuve) ; Menu édition supprimé.
- **R263** : régression du fond Magnétisme non reproduite (niveaux chargés directement) ; `DEMARRAGE.md` créé.
- **R261** : encre — règle « sans trait posé, la jauge est pleine » (`paintEnergy`, compteur `S.inkFix`) ; jauge visible
  aussi sous 600 px de haut (elle disparaissait sur petits iPhone) ; Échelle fusionnée dans Déplacer (poignée ⤢ + pincement,
  bouton Échelle retiré) ; Quantone : chaque trait garde boîte à rythmes, kit, fonction et boucle propres.
- **R260** : Quantone — barre de lecture fixe, mini‑diagramme de charge, gamme/grille sous le champ, format `.qx`.
- **R259** : jeu suspendu sous Quantone (tous les contextes audio), ouverture `.json`, garde‑fous audio.

## 3. Chantiers ouverts — dans l'ordre (demandes de Simon du 22 oct.)

| # | Chantier | État | Prochaine action |
|---|---|---|---|
| 1 | **Erreurs fatales** (encre vide au départ, niveau impossible) | correctif défensif R261 ; cause exacte non reproduite | Simon : dire le niveau et l'écran si ça revient ; scan 132 (n° 2) |
| 2 | **Scan des 132 niveaux** (`tools/scan132.js N`) : encre de départ, référence, encre minimale d'une ligne gagnante, contournements, murs jamais touchés | outil prêt (`tools/scan132.js`, ≈ 30 s par niveau) ; les résultats du 22 oct. sont perdus (bloc‑notes) | relancer avec l'accord de Simon, résultats dans `tools/` ; rapport par monde |
| 3 | **Calibrage de l'encre** au scénario de chaque niveau ; **géodésique** (solution de référence) la plus économe ET traçable au doigt | à faire | règle à écrire après le scan |
| 4 | **Redondance** : Chaîne (monde 3) puis Soufflerie (monde 5, refonte de fond : jouabilité, décor, originalité) | à faire | matrice des 12 niveaux par monde |
| 5 | **Méthode de génération** non reproductiviste (logique propre au monde et au niveau, public cible, recherche documentée) ; futur monde « mécanique des fluides » | à faire | document de méthode, après 2–4 |
| 6 | **Collecte des parties des bêta‑testeurs** | étapes 1–2 faites (R266–R268) ; envoi actif, jamais testé avec le vrai service | Simon : sur iPhone, répondre Oui, finir un niveau, vérifier le mail sur mydopeoff@gmail.com ; puis analyser les fichiers reçus |
| 7 | **Régression Magnétisme** : le fond texturé n'est animé qu'au niveau 1 | R263 : **non reproduite** — `tools/probe_ferro.py` (Chromium sans GPU) mesure le fond animé aux niveaux 85 et 86 chargés directement ; aucun code touché | Simon : dire comment il passe au niveau 2 (Suivant / Constellation), sur quel appareil, et si le fond est figé ou absent ; sinon essai long (40 s) + gestion de la perte de contexte WebGL ; puis test des fonds par monde |
| 8 | **Décor Gravité** : points animés liés à la direction et à la force de la gravité, tailles/opacités variées, noyés dans la poussière (vidéo de référence de Simon) | demandé le 22 oct. | banc des rendus d'abord |
| 9 | Monde 11 (niveaux 5, 7–10 à refaire ; dédoublements multiples), monde 10 (2, 9, 10, 11 sans référence), mondes 5–6 | en attente | après 1–4 |
| 10 | Quantone : volets Boucle / Morceau (proposition R241) | en attente | décision de Simon |
| 11 | **Charte graphique complète** (`CHARTE_GRAPHIQUE.md`, à construire) : fusion des sources listées dans `NETTOYAGE.md` §3 | à faire, quand Simon la convoque | consolider sans perdre une exigence |
| 12 | **Méthode de génération des niveaux** (`METHODE_NIVEAUX.md`, à construire) : charte des niveaux mise à jour avec les demandes du 22 oct. | à faire, quand Simon la convoque | idem, sources dans `NETTOYAGE.md` §3 |

## 4. Décisions attendues de Simon

| # | Décision | Recommandation |
|---|---|---|
| D1 | Périmètre de la première version publique | « Chapitre 1 » (mondes 1–4 + héros + fin provisoire) |
| D2 | Nom (« Quantix » probablement pris comme marque) | vérifier EUIPO, BOIP, magasins |
| D3 | Modèle de la première version | gratuit + Ko‑fi ; plus tard démo + achat unique |
| D4 | Connecter le dépôt GitHub à la session | oui (fin des zips, tests automatiques) |
| D5 | Zen Lab, Quantum Drop, atelier de particule | retirer du code jusqu'à redéfinition |
| D6–D8 | Origine de la compagne, sens du noyau, Ko‑fi et crédits | voir `AUDIT_R209.md` §19 |
| D9 | Mot de la ressource de tracé | « énergie » partout |
| D10 | Ordre de refonte | voir §3 ci‑dessus (priorité aux erreurs fatales) |
| D11 | Collecte bêta : périmètre (export volontaire seul, ou envoi vers un service) | export volontaire d'abord |

## 5. Monde par monde (résumé ; détail par niveau : `AUDIT_R209.md` annexe B, à régénérer par le scan)

| Monde | Niveaux | Réf. | Contournables connus | Remarques |
|---|---|---|---|---|
| 1 Atelier | 1–12 | 12/12 | — | niv. 1 et 9 gagnables trop court |
| 2 Fonderie | 13–24 | 11/12 | — | #19 sans référence ; #21 zone occupée |
| 3 Chaîne | 25–36 | 12/12 | — | **redondances signalées par Simon** ; #34 zone occupée |
| 4 Glacier | 37–48 | 12/12 | — | #48 à 63–70 % |
| 5 Soufflerie | 49–60 | 7/12 | 50 53 55 56 58 | **refonte de fond demandée** |
| 6 Mécanique | 61–72 | 6/12 | 61 62 63 64 67 69 | |
| 7 Gravité | 73–84 | 12/12 | — | à juger (`A_VERIFIER.md`) ; décor à refaire (§3 n° 8) |
| 8 Magnétisme | 85–96 | 12/12 | — | régression du fond (§3 n° 7) |
| 9 Faille | 97–108 | 12/12 | — | à juger |
| 10 Filaments | 109–120 | 8/12 | 118 119 | 117 à refaire |
| 11 Quantique | 121–132 | 8/12 | 125 127 128 129 130 | 5, 7–10 à refaire ; ne pas toucher au niveau 12 sans accord |

## 6. Ce qui n'a jamais été vérifié

Performances sur iPhone réel (héros, épilogue, monde 8) ; avis de joueurs extérieurs ; micro de Quantone sur iPhone ;
import Dictaphone `.m4a` ; écoute des nouvelles voix de la boîte à rythmes.

## 7. Liens (à redonner en fin de réponse, Aperçu en premier)

Aperçu https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC ·
Éditeur de niveaux https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp · Banc des rendus https://claude.ai/artifact/YLLD3eGHDLFWP3k44nfMxW ·
Quantone https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By · Banc de la fin https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b

*Les artefacts en ligne ne sont pas republiés à chaque lot : Aperçu et Quantone peuvent montrer une version plus ancienne
que le zip. Le dire à Simon.*
