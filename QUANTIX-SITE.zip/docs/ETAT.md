# QUANTIX — ÉTAT (source de vérité unique)

**Version de référence : R266 — 23 octobre 2026.** Tampon du code : `build R302`. Vérifier avant tout travail de code : `grep -o 'build R[0-9]*' index.html` doit afficher **R302** ; sinon ce
n'est pas le dernier zip → le demander à Simon.

**Au démarrage, lire aussi `DEMARRAGE.md` (1 page)** : où décompresser le zip, quoi ne pas relire, comment traiter un
défaut vu sur iPhone. Il résume les erreurs des sessions R262–R263.

*Ce document remplace le haut de l'ancien `REPRISE-SESSION.md`. Il reste court (< 8 Ko) : on le réécrit à chaque lot, on
ne l'empile pas. L'historique va dans `JOURNAL.md`.*

---

## 1. Ce qui est dans le jeu (déployable)

Accueil Visière + héros ; Constellation et pages de monde ; 132 niveaux (11 mondes × 12) ; plein cadre ; didacticiel
holographique ; bilan animé ; fin « Les retrouvailles » (`fin5`) et bilan du parcours ; Quantone intégré ; FR/EN ;
sauvegarde locale. **Caché** : Zen Lab, Quantum Drop, atelier de particule (D5). **Inactif** : bouton Ko-fi.

## 2. Derniers lots (détail : `JOURNAL.md`)

- **R272–R274** : banc des rendus : aspiration par le trou noir. R273 : trois propositions (A vortex, B toile, C fil). R274 : Simon retient la toile avec poussière plus réaliste et anneaux de C ; deux variantes B2 (grains + filaments) et B3 (nappe de poussière), cœur blanc texturé et flash petit. À choisir par Simon ; pas dans le jeu.
- **R275** : banc des rendus : naissance de la particule en début de niveau (A éjection lointaine + onde de changement de plan + puits décoratif ; B sortie en profondeur au bassin). À choisir ; pas dans le jeu.
- **R276** : banc : fin (B2 retenue) avec la vraie particule du jeu (`VX.ball`) et explosion verte de la zone (rayons effilés, étincelles, ondes) ; anneaux rose→vert ; naissance avec la vraie particule. À valider.
- **R277** : banc : naissance refaite, plus dynamique et plus discrète : niveau en fondu progressif, trou à la suite de la fin ; A fronde (orbite amortie, étirement, clac), B chute (gravité du jeu, rebonds). À choisir ; pas dans le jeu.
- **R278** : banc : naissance sur un vrai niveau (n° 41 « La combe gelée », capture du jeu `studio/captures/naissance_niveau41.jpg`) ; particule = `VX.ball(c,x,y,ang,10.5)` sans teinte (les versions précédentes la teintaient en cyan : faux). A fronde, B ressort. Piège : le jeu dessine un cercle pointillé de capture autour du départ ; la capture se fait avec `VX.ball` neutralisé et les éléments DOM masqués.
- **R285** : sons d’entrée/sortie ×3 à ×4 et plus aigus (le grave sous 150 Hz ne sort pas d’un haut-parleur de téléphone). Toujours à régler à l’oreille.
- **R286** : sons de transition ×0,75. Captation « parcours joueur bêta » : runlog garde la trajectoire de la bille (`bp`) + hook `QRUNS.onrun` ; l’Aperçu (bâti avec `capture`, publié avec capacité `db`) écrit chaque essai dans la collection `parcours_beta` ; import des JSON mail par Claude. Voir `PARCOURS_BETA.md`. Vérifié : écriture simulée (stub db) OK ; non testé : vraie base (vide tant que Simon n’a pas joué), sons à l’oreille.
- **R287** : parcours bêta enrichis des outils d’édition (`tl`) ; `tools/parcours-rapport.py` compare les tracés des joueurs à la géodésique (`optsol`) ; protocole de révision écrit dans `PARCOURS_BETA.md`. Premier constat (67 essais, Simon, N1–24) : encre ≤45 % utilisée sur la plupart des réussites dès N13 ; N15 et N24 réussis avec bien moins d’encre que la référence (⚠ contournement ou référence non optimale) ; N18–22 échouent 3× en `out` au premier essai. Non testé : tl en conditions réelles (testé par stub).
- **R288** : mesure des outils corrigée (crochet interne `EDT.hook` dans editor.js : le mode d’outil n’était jamais capté en R287). 2ᵉ passage de Simon reçu (110 essais, N1–48, pid e370…) : 0 usage de gomme/déplacer/échelle (modes), échecs surtout `out` (45/59) ; l’encre utilisée varie de ±30 pts entre deux passages du même joueur (N1 80→53 %, N6 85→52 %) → calibrer sur le minimum de plusieurs joueurs. À vérifier au prochain passage : comptage `add` (seulement ~10 essais avec `tl` en R287, cause non élucidée).
- **R289** : lot L1 de `AUDIT_DONNEES.md` — `assets/js/events.js` : journal d’événements (session, niveaux, vues, taps, traits, outils, lâchers, contacts, issues, abandons, sortie de session, erreurs), file locale persistante, envoi par lots (`QEV.sink` / `QEV.endpoint`), crochets multiples `EDT.hook`. Aperçu → collection `evenements_beta`. Décisions de Simon : backend **Cloudflare Worker**, **pays grossier seulement** (pas d’âge). Reste L2 (Worker + consentement + page « données collectées »), L3 (rapports funnel/décrochage/logique). Vérifié : test e2e headless avec stub db ; non testé : appareil réel, volume, mail d’export des événements, `QEV.endpoint`.
- **R290** : lot L2 — `worker/` (ingest.js Cloudflare Worker + D1, schema.sql, LISEZMOI.md pas à pas iPhone) ; consentement invité dès la fin du 1er essai (réussi ou non) ; envoi réseau seulement après Oui ; panneau Paramètres « Ce que collecte Quantix » (voir/effacer) ; textes FR/EN. `ENDPOINT` de events.js **vide** : à renseigner quand Simon aura déployé le Worker (étapes LISEZMOI 1–6). Lecture par Claude : Simon ouvre `/export?key=…` et envoie le fichier (le bac à sable de Claude n’atteint pas workers.dev), import dans la base du Projet. Vérifié : e2e headless (invite, rien avant Oui, 1 envoi après Oui, panneau), Worker testé sur base simulée (doublon, origine, forme, taille, clé). Non testé : vrai Cloudflare, iPhone, CORS réel. Aperçu non republié.
- **Collecte en ligne — déploiement (24 oct.)** : site de jeu = https://podarcis-cloud.github.io/Quantix/ (Origin à autoriser : `https://podarcis-cloud.github.io`, SANS chemin). Worker Cloudflare déployé : `https://quantix-events.mydopeoff.workers.dev` (compte Cloudflare de Simon), base D1 `quantix-events` (tables batches, players), liaison `DB` faite, variables `ALLOWED_ORIGIN` et `ADMIN_KEY` (secret, jamais consigné ici) posées. Reste : vérifier `/stats?key=…`, vérifier la valeur de `ALLOWED_ORIGIN`, puis renseigner `ENDPOINT` dans `assets/js/events.js` (R291).
- **R291** : `ENDPOINT` de events.js = `https://quantix-events.mydopeoff.workers.dev/` (collecte en ligne branchée). Vérifié : `/stats` répond (0 joueur) ; non testé : un vrai envoi depuis le site GitHub Pages (dépend de la valeur de `ALLOWED_ORIGIN`, doit être `https://podarcis-cloud.github.io`). Test à faire par Simon : jouer 1 niveau sur le site, répondre Oui, puis rouvrir `/stats`.
- **R292** : diagnostic d’envoi — le panneau « Ce que collecte Quantix » affiche « Dernier envoi : OK/ERREUR code message ». Envoi renforcé : lot borné à 48 Ko, plus de `keepalive` (limite 64 Ko), reprise 4 s après l’ouverture, retry 5 s→2 min. Contexte : Simon a joué (app installée, Firefox privé/non privé), `/stats` restait à 0 ; `ALLOWED_ORIGIN` corrigée en `https://podarcis-cloud.github.io` (la valeur contenait `/Quantix/` puis `/` final). Vérifié : e2e avec faux serveur 403 puis 200 (erreur affichée, file vidée). À lire chez Simon : le message du panneau après avoir joué 1 niveau.
- **Stratégie données (24 oct.)** : `docs/STRATEGIE_DONNEES.md` — leçons (N21/N22 = problème de découverte, pas de précision ; test distance-au-but), coût mesuré (≈ 60 Ko/session, D1 gratuit ≈ 30 000 joueurs), 6 branchements classés (fiche de santé, rejeu contrefactuel, extraction de solutions, courbe de difficulté, aide adaptative, collecte). Aucun niveau encore corrigé à partir des événements. En attente du choix de Simon.
- **4 joueurs, 59 niveaux (export 24 oct. 15:53)** : points durs = N21 « Le grand retour » (29 échecs/32 essais, 2 joueurs, sorties en bas à droite) et N22 « Double rebond » (28/30) : les deux joueurs n'ont jamais trouvé la solution prévue (référence 1 trait ↑ au N21) et passent par 3-4 traits ; N18 (10 essais), N20 (7), N53 (2 abandons). Outils : déplacer 325 fois, échelle 60, gomme 36, annuler 32 ⇒ on règle plus qu'on ne redessine. Rapport complet : `tools/rapport-evenements.py --export`.
- **Zones interdites : Nervures animées (24 oct., banc des rendus v33)** : Simon retient « Nervures », texture à animer vraiment (v35 : « sobre ajustée » = voile ÷2,5 + contraste du décor renforcé, demandé par Simon ; v34 : animation 4× plus vive, Simon la trouvait immobile en v33 : Δ moyen d'image entre 72 trames passé de ≈ 0,5 à 3,4), zones nuancées. Fait dans `studio/galerie-zones.html` : bruit 3D périodique (x, y, temps) précalculé en 10 images-clés fondues en continu (boucle 36 s), carte de densité (plages denses / calmes), activité plus vive près des bords exposés (carte de distance), 2 échelles de veines en parallaxe sur une brume rose ; rendu d'origine `VX.nd` conservé par-dessus ; 2 intensités (sobre, riche). Coût mesuré (Chromium sans GPU) ≈ 7–8 ms/trame ; précalcul ≈ 2 s à l'ouverture → pour le jeu : cuire les 10 images-clés en sprites (WebP) plutôt que les calculer sur iPhone. Rien dans le jeu. Non testé : iPhone. Simon choisit sobre/riche avant intégration.
- **Encre resserrée (R297, 24 oct.)** : règle à 3 profils validée par Simon ; 7 niveaux resserrés dans `levels.js` : 60→90, 90→120, 97→110, 103→100, 113→260, 121→360, 122→120. Vérifié : `scan132.js` sur les 7 (référence gagne, à vide échoue, encre de départ conforme) + chargement headless sans erreur. Non testé : jeu sur iPhone. Les 18 niveaux trop serrés restent inchangés (Simon n'a pas confirmé l'élargissement). Les niveaux « défi d'encre » seront définis par les événements bêta (section « encre observée » à ajouter au rapport).
- **Calibrage de l'encre (24 oct., R297 — sans changement de code)** : quota actuel = 1,05 à 6,7 × la référence (médiane ≈ 1,4). 18 niveaux < 1,15 × (trop serrés pour un doigt, ex. 8, 11, 20, 33, 35, 52, 72, 77, 79, 80…), 7 > 3,5 × (encre sans enjeu : 60, 90, 97, 103…), 46 gagnables par une ligne < 30 % de la référence (encre qui ne protège rien, signal de contournement), 41 références non économes (ligne droite < 80 %), 16 sans référence. Propositions chiffrées dans CALIBRAGE_ENCRE.md, à valider avant toute modification des niveaux.
- **Scan 132 (24 oct., R296)** : 128/132 mesurés. Signaux : 25 niveaux où la référence gagne sans la mécanique (contournement possible : 3, 6, 12, 18, 32–38…), 16 sans référence (19, 53, 55–58, 61–64, 67, 69, 110, 117…), 14 références hors noyau (81–83, 88, 97, 101, 107, 124–131), 9 niveaux où des lignes droites gagnent trop souvent (46, 48, 86, 87, 123–126, 129), 6 encres très généreuses (60, 90, 103, 113, 121, 122), 1 très serrée (20), 75 avec au moins un mur jamais touché (à trier : décor ou vrai mur muet). Rien n'est corrigé : le rapport sert de base au calibrage de l'encre (n° 3) et à la géodésique.
- **Animations par défaut (R296, 24 oct.)** : régression constatée sur l'iPhone de Simon = `RM` initialisé depuis `prefers-reduced-motion` (iOS) → naissance/aspiration du trou noir coupées (preuve : bilan à +0,42 s au lieu de +3 s dans l'export R294). Désormais `RM=false` d'office ; seul l'interrupteur « Animations réduites » du jeu compte (compromis accessibilité à garder en tête, cf. D-accessibilité). « Relancer » grisé pendant l'aspiration (réactivé à l'ouverture du bilan ou au reset). Testé headless (reduced_motion émulé : animation OK, bouton grisé puis réactivé). Non testé sur iPhone.
- **Géométrie finale (R295, 24 oct.)** : 1er export réel (Simon, niv. 61-63 : 3 réussis, encre 8-19 % utilisée, réglage par « déplacer »). Journal corrigé : `la.g` (traits tels que lancés), `mov` dx/dy ; rapport : distance au tracé de référence. À republier ; parties R294 sans `g`.
- **Export des événements (R294, 24 oct.)** : `admin.html` (clé tapée, jamais stockée) → fichier/copie ; bouton d'export in-app ; journal riche validé en headless (traits, undo/gomme, modes, essais, contacts). Le `&dl=1` du Worker devient facultatif. Non testé : partage iOS réel, parties réelles sur iPhone.
- **Rapport événements (R293, 24 oct.)** : `tools/rapport-evenements.py` écrit (voir PARCOURS_BETA.md). Testé sur anciens essais + export réel (5 événements). Safari n'a pas de bouton télécharger sur `/export` : `&dl=1` ajouté à `worker/ingest.js` (non déployé ; copier-coller du texte suffit tant que c'est petit). Reste : journal riche non testé (attendre parties R289+).
- **Collecte en ligne OPÉRATIONNELLE (24 oct., 12:50)** : cause du blocage = `ALLOWED_ORIGIN` enregistrée mais non déployée (bouton Deploy ≠ Save version). `/stats` : 1 joueur (BE), 5 sessions, 2 lots, 5 événements ; panneau « Dernier envoi : OK ». Les événements gardés sur les autres appareils de Simon (app installée, Firefox) partiront à leur prochaine ouverture. Lecture : Simon enregistre `/export?key=…` (clé jamais consignée) et l’envoie à Claude ; sandbox Claude sans accès à workers.dev. Prochain lot : rapports (décrochage par niveau, niveau moyen terminé, logique de résolution, outils) + import export→base.
- **R284** : sons d’entrée et de sortie (sound.js : absorb_pull, absorb_burst, birth_open, birth_shot, birth_pass, birth_land), déclenchés par transitions.js et calés sur l’animation ; avec l’aspiration, `level_success` et la vibration partent à l’éclat (≈2,4 s) au lieu de la réussite. Testé : aucun son en erreur, ordre et délais corrects ; NON écouté (aucune écoute possible ici), niveaux à régler à l’oreille sur iPhone.
- **R283** : cause trouvée : l’entrée était sautée dès que l’outil sélection/échelle (`EDT.active()`) restait actif d’un niveau à l’autre ; condition retirée.
- **R282** : l’entrée attend que le niveau soit visible (aucun voile `.veil.on` : carte du monde, pause, bilan) avant de démarrer ; sinon elle se jouait sous la carte entre deux niveaux.
- **R281** : grille de fond retirée de l’entrée et de la sortie (le reste inchangé).
- **R280** : INTÉGRATION dans le jeu (validée par Simon, sans zoom) : `assets/js/transitions.js` (`window.QFX`) ; sortie = aspiration B2 sur l’arrivée réelle (démarre à la réussite, bilan retardé à 3,0 s au lieu de 0,42 s ; dernier niveau : finCine à 3,3 s) ; entrée = fronde A à chaque `loadLevel` (3,5 s, « Lâcher la balle » la termine). Dernier niveau : pas d’aspiration (cohérence avec le final). Sautées : mouvement réduit (`RM`/`OPT.rm`), mode zen, démo solution, niveaux `QP.soft`, éditeur actif. `resetBall` annule tout (jeton `S.absTok`, `S.absHide` cache la bille après l’aspiration). Crochets engine.js : `QFX.draw(c)` à la place de `drawBall`, `QFX.birthStart` dans loadLevel, `QFX.absorbStart` dans `level.complete`. Version allégée auto : `QFX.light` (non branché sur la cadence). Testé (Chromium, niveau 20) : images entrée/sortie, bilan à 3 s, reset, mouvement réduit, aucune erreur de page. NON testé : iPhone, fluidité, sons dédiés, niveaux 93/95 (trop lourds en headless), mode démo.
- R279 (banc) : fin sur zone réelle n° 93, entrée A.
- **R271** : réponse d'envoi mémorisée sous une nouvelle clé (`quantix.runs.consent2`) : les sauvegardes qui avaient un ancien « non » (build R268) revoient l'invite une fois.
- **R270** : mail des parties refait : objet = niveau(x) concerné(s) et résultat ; corps = joueur, statistiques, détail par niveau, JSON complet ; tentative de pièce jointe `.json` (selon l'offre Web3Forms), repli en texte. Les mails reçus par Simon sont collés dans la conversation (pas d'accès direct à sa boîte).
- **R269** : invite d'envoi refaite (retour de Simon : peu claire, polluait le bilan) : fenêtre à part, une seule fois, à la 1re sortie du bilan ; ensuite une ligne discrète « Envoyer cette partie » sous les boutons ; le bilan n'est plus modifié avant le Oui.
- **R268** : clé Web3Forms de Simon posée dans `runlog.js` (`SHARE_KEY`) : envoi actif ; non testé avec le vrai service (réseau de la session bloqué).
- **R267** : envoi anonyme des parties par e-mail (Web3Forms) dans `runlog.js` : choix unique Oui/Non au 1er niveau réussi (jamais pré-coché), case « Envoyer cette partie » ensuite, réglage dans Paramètres ; **inactif tant que `SHARE_KEY` est vide**. Chantier 6, étape 2.
- **R266** : journal local des essais (`assets/js/runlog.js`, clé `quantix.runs.v1`) + Paramètres « Mes parties » (Exporter / Effacer) ; rien n'est envoyé. Chantier 6, étape 1.
- **R265** : nettoyage exécuté (`NETTOYAGE.md` §5) : 34 documents retirés du Projet (copies en `docs/archive/` du zip), 15 mis à jour ; artefact Menu édition supprimé le 23 oct.
- **R264** : inventaire et nettoyage préparés (`NETTOYAGE.md`, à exécuter dans une conversation neuve) ; Menu édition supprimé.
- **R263** : régression du fond Magnétisme non reproduite (niveaux chargés directement) ; `DEMARRAGE.md` créé.
- **R261** : encre — règle « sans trait posé, la jauge est pleine » (`paintEnergy`, compteur `S.inkFix`) ; jauge visible
  aussi sous 600 px de haut (elle disparaissait sur petits iPhone) ; Échelle fusionnée dans Déplacer (poignée ⤢ + pincement,
  bouton Échelle retiré) ; Quantone : chaque trait garde boîte à rythmes, kit, fonction et boucle propres.
- **R260** : Quantone — barre de lecture fixe, mini‑diagramme de charge, gamme/grille sous le champ, format `.qx`.
- **R259** : jeu suspendu sous Quantone (tous les contextes audio), ouverture `.json`, garde‑fous audio.

## 3. Chantiers ouverts — dans l'ordre (demandes de Simon du 22 oct.)

| # | Chantier | État | Prochaine action |
|---|---|---|---|
| 1 | **Erreurs fatales** (encre vide au départ, niveau impossible) | correctif défensif R261 ; cause exacte non reproduite | Simon : dire le niveau et l'écran si ça revient ; scan 132 (n° 2) |
| 2 | **Scan des 132 niveaux** (`tools/scan132.js N`) : encre de départ, référence, encre minimale d'une ligne gagnante, contournements, murs jamais touchés | **128/132 mesurés** (R296, 24 oct.) ; rapport `docs/SCAN132_RAPPORT.md` (`tools/scan-rapport.py`) ; 4 niveaux trop lourds (30, 114, 120, 132 : > 10 min chacun) | lire le rapport ; scan des 4 lourds à faire par un autre moyen (allègement du balayage) |
| 3 | **Calibrage de l'encre** au scénario de chaque niveau ; **géodésique** (solution de référence) la plus économe ET traçable au doigt | règle + photographie faites (R297) : `docs/CALIBRAGE_ENCRE.md` (`tools/calibrage-encre.py`) ; **rien appliqué** | Simon : valider la règle (3 profils), désigner les niveaux « défi d'encre », accepter ou non les 18 resserrements→élargissements et 7 assouplissements |
| 4 | **Redondance** : Chaîne (monde 3) puis Soufflerie (monde 5, refonte de fond : jouabilité, décor, originalité) | à faire | matrice des 12 niveaux par monde |
| 5 | **Méthode de génération** non reproductiviste (logique propre au monde et au niveau, public cible, recherche documentée) ; futur monde « mécanique des fluides » | à faire | document de méthode, après 2–4 |
| 6 | **Collecte des parties des bêta‑testeurs** | étapes 1–2 faites (R266–R268) ; envoi actif, jamais testé avec le vrai service | Simon : sur iPhone, répondre Oui, finir un niveau, vérifier le mail sur mydopeoff@gmail.com ; puis analyser les fichiers reçus |
| 7 | **Régression Magnétisme** : le fond texturé n'est animé qu'au niveau 1 | R263 : **non reproduite** — `tools/probe_ferro.py` (Chromium sans GPU) mesure le fond animé aux niveaux 85 et 86 chargés directement ; aucun code touché | Simon : dire comment il passe au niveau 2 (Suivant / Constellation), sur quel appareil, et si le fond est figé ou absent ; sinon essai long (40 s) + gestion de la perte de contexte WebGL ; puis test des fonds par monde |
| 8 | **Décor Gravité** : points animés liés à la direction et à la force de la gravité, tailles/opacités variées, noyés dans la poussière (vidéo de référence de Simon) | demandé le 22 oct. | banc des rendus d'abord |
| 9 | Monde 11 (niveaux 5, 7–10 à refaire ; dédoublements multiples), monde 10 (2, 9, 10, 11 sans référence), mondes 5–6 | en attente | après 1–4 |
| 10 | Quantone : volets Boucle / Morceau (proposition R241) | en attente | décision de Simon |
| 11 | **Charte graphique complète** (`CHARTE_GRAPHIQUE.md`, à construire) : fusion des sources listées dans `NETTOYAGE.md` §3 | à faire, quand Simon la convoque | consolider sans perdre une exigence |
| 12 | **Méthode de génération des niveaux** (`METHODE_NIVEAUX.md`, à construire) : charte des niveaux mise à jour avec les demandes du 22 oct. | à faire, quand Simon la convoque | idem, sources dans `NETTOYAGE.md` §3 |

## 4. Décisions attendues de Simon

| # | Décision | Recommandation |
|---|---|---|
| D1 | Périmètre de la première version publique | « Chapitre 1 » (mondes 1–4 + héros + fin provisoire) |
| D2 | Nom (« Quantix » probablement pris comme marque) | vérifier EUIPO, BOIP, magasins |
| D3 | Modèle de la première version | gratuit + Ko‑fi ; plus tard démo + achat unique |
| D4 | Connecter le dépôt GitHub à la session | oui (fin des zips, tests automatiques) |
| D5 | Zen Lab, Quantum Drop, atelier de particule | retirer du code jusqu'à redéfinition |
| D6–D8 | Origine de la compagne, sens du noyau, Ko‑fi et crédits | voir `AUDIT_R209.md` §19 |
| D9 | Mot de la ressource de tracé | « énergie » partout |
| D10 | Ordre de refonte | voir §3 ci‑dessus (priorité aux erreurs fatales) |
| D11 | Collecte bêta : périmètre (export volontaire seul, ou envoi vers un service) | export volontaire d'abord |

## 5. Monde par monde (résumé ; détail par niveau : `AUDIT_R209.md` annexe B, à régénérer par le scan)

| Monde | Niveaux | Réf. | Contournables connus | Remarques |
|---|---|---|---|---|
| 1 Atelier | 1–12 | 12/12 | — | niv. 1 et 9 gagnables trop court |
| 2 Fonderie | 13–24 | 11/12 | — | #19 sans référence ; #21 zone occupée |
| 3 Chaîne | 25–36 | 12/12 | — | **redondances signalées par Simon** ; #34 zone occupée |
| 4 Glacier | 37–48 | 12/12 | — | #48 à 63–70 % |
| 5 Soufflerie | 49–60 | 7/12 | 50 53 55 56 58 | **refonte de fond demandée** |
| 6 Mécanique | 61–72 | 6/12 | 61 62 63 64 67 69 | |
| 7 Gravité | 73–84 | 12/12 | — | à juger (`A_VERIFIER.md`) ; décor à refaire (§3 n° 8) |
| 8 Magnétisme | 85–96 | 12/12 | — | régression du fond (§3 n° 7) |
| 9 Faille | 97–108 | 12/12 | — | à juger |
| 10 Filaments | 109–120 | 8/12 | 118 119 | 117 à refaire |
| 11 Quantique | 121–132 | 8/12 | 125 127 128 129 130 | 5, 7–10 à refaire ; ne pas toucher au niveau 12 sans accord |

## 6. Ce qui n'a jamais été vérifié

Performances sur iPhone réel (héros, épilogue, monde 8) ; avis de joueurs extérieurs ; micro de Quantone sur iPhone ;
import Dictaphone `.m4a` ; écoute des nouvelles voix de la boîte à rythmes.

## 7. Liens (à redonner en fin de réponse, Aperçu en premier)

Aperçu https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC ·
Éditeur de niveaux https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp · Banc des rendus https://claude.ai/artifact/YLLD3eGHDLFWP3k44nfMxW ·
Quantone https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By · Banc de la fin https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b

*Les artefacts en ligne ne sont pas republiés à chaque lot : Aperçu et Quantone peuvent montrer une version plus ancienne
que le zip. Le dire à Simon.*

- Banc v37 (zones interdites) : 3e variante « rouge subtile, rapide » (v37 : veines/brume rouges, animation ×1,9, opacité globale ≈80 %, brume quasi nulle, respiration d'opacité ±28 %). Choix de Simon en attente avant intégration au jeu (sprites WebP précalculés).

- **R298 · Nervures sous les zones interdites (dans le jeu)** : variante « rouge subtile, rapide » validée par Simon. Atlas `assets/img/nervures.webp` (10 images-clés teintées, 635 Ko, cuit depuis le banc) ; `visuals.js` : `nvDraw` (couche contraste en demi-résolution rafraîchie toutes les 15 trames, nervures rafraîchies 1 trame sur 2, masque calculé une fois par niveau). Coupée si `OPT.rm`, si l'image ne charge pas, ou si coût moyen > 12 ms/trame sur 90 trames. Mesuré : ≈12 ms/trame en Chromium logiciel (sans GPU, écran 2×). Vérifié : rendu + mouvement, rejeu 12/12. NON testé : iPhone réel (fluidité, batterie), autres niveaux à zones.

- **Rejeu contrefactuel (outil, jeu inchangé R298)** : `tools/replay-reel.js` ; fidélité 87 % (201/231) ; N21 : élargir le bassin ou supprimer la zone ne change rien → l'idée n'est pas trouvée (voir STRATEGIE_DONNEES.md). Prochain : fiche de santé automatique par niveau ; décision de Simon sur le N21 (indice visuel ou nouvelle référence).

- **Audit de conception (outil + rapport, jeu inchangé R298)** : `docs/AUDIT_CONCEPTION.md` (outils `tools/audit-conception.js`, `audit-contact.js`, `audit-meta.js`, `audit-conception.py`, données `docs/audit-*.json`). 132 niveaux, 656 éléments : 208 indispensables, 30 filtres, 187 jamais approchés, 167 redondants. Doublons de niveaux listés. Suite décidée par Simon : (1) 3 modes de difficulté sélectionnables dans Paramètres (à spécifier à partir de l'audit) ; (2) réflexion sur l'enjeu/les vies : la règle « jamais de vies » reste en vigueur, seulement une réflexion sur un engagement plus dur optionnel en mode difficile. Objectif posé par Simon : juger et régler la difficulté, apporter un nouveau type de réflexion par niveau, corriger obstacles et composition — PAS rendre les solutions faciles à trouver.

- **Spécification des 3 modes + enjeu** : `docs/MODES_DIFFICULTE.md` (rien de codé). Modes Découverte/Standard/Défi par transformation automatique (encre, bassin, indice, solution, noyau), garde-fous (solvabilité ×3 modes, P_hasard, P_ligne), règles de composition issues de l'audit, réflexion sur l'enjeu (série, médaille intacte, essais comptés, cœurs = nécessiterait de rouvrir la règle). En attente de Simon : noms des modes, médaille par mode, premier chantier.

- **Refonte simulée du monde 3 « Chaîne »** (jeu principal inchangé R298) : `docs/REFONTE_MONDE3.md` ; aperçus jouables « refonte » https://claude.ai/artifact/5gzqcibWj9ENUsyiJFvRho et « actuel » https://claude.ai/artifact/JY4DmhVthduGoCZFt13Tge. 4 niveaux remplacés (26 Dans le bon sens, 27 Le canon, 32 Le boomerang, 35 Le bon ruban), 1 nettoyé (25), 7 conservés. Validée au moteur, jamais jouée : en attente du retour de Simon pour intégrer (`tools/refonte/levels-monde3-refonte.js`).

- **R302 · Monde 5 Soufflerie lot 1 INTÉGRÉ au jeu + bouton « Rejouer pour le noyau »** : niveaux 49, 50, 51, 52, 54, 57 (« Le carrefour », remplace « La rafale »), 60 refaits (voir `REFONTE_MONDE5.md`). 50 : seule la bande haute est dessinable (évitement fermé). 57 : sans trait la balle échoue ; hasard ~8–10 % (cible ≤1 %, à resserrer). Bouton rRetry sur l'écran de résultat quand le noyau n'est pas pris (relance le niveau). Restent 53, 55, 56, 58, 59 (anciennes versions ; extensions moteur E3/E5/E1, décision D1). **À FAIRE plus tard : monde secret « mécanique des fluides »** (déblocage quand tous les noyaux sont pris ; nouveau moteur physique, décor ; conception à venir). Non testé : rendu iPhone réel du bouton.
- **R301 · Refonte monde 3 (v6) INTÉGRÉE au jeu, validée par Simon le 25 oct.** : 6 = montagnes russes à vitesses variées, 8 = « Rendre l'élan », 10 = « L'îlot lent » (aucun trait unique ne gagne), 11 = « Après ton passage » (tracé pendant la course ; `optat` dans le moteur pour la démo), 12 = ancienne machine allongée (rubans 10/2/7/0). Vérifié : 12 niveaux réussis dans le moteur ; sans trait échoue partout. Non testé : iPhone, non-régression 132 rejouée (ajout inerte). Non-régression 132 : seuls les niveaux 27–36 changent (122 identiques). Zip envoyé. R301b : 11 plus tolérant (fenêtre de tracé), 6 en rubans courbes (`curves` + `v` dans le moteur) ; principe d'esthétique des trajectoires consigné dans `REFONTE_MONDE3.md`.
- **R300 · Code couleur de vitesse des rubans (moteur + refonte monde 3 v4)** : ambre/turquoise/violet/blanc-cyan selon la vitesse cible, légende en jeu, `optmats` (matière par trait de la solution). Non-régression 132 niveaux identique. Refonte v4 du monde 3 (11 niveaux redessinés d'après `FICHES_MONDE3.md`) publiée en aperçu seulement — voir `REFONTE_MONDE3.md`. Zip non envoyé. À faire : jeu de Simon sur l'aperçu, fiche 35 « Après ton passage », revoir 32.
- **R299 · Ruban v2 (moteur) + refonte monde 3 v2** : un ruban fixe peut avoir une vitesse cible (`R_(x1,y1,x2,y2,v)` dans levels.js ; 0 = frein ; accélère en dessous, freine au-dessus ; dessin : chevrons serrés = rapide, barres ambrées = frein). Sans `R_` : comportement identique (vérifié : empreinte des 132 niveaux identique avant/après, `tools/regress-ref.js`). Aperçu refonte mis à jour (v3) : + niveau 31 « Le ruban qui freine » (remplace « Tapis et lames »). Idée « montée lente » (ruban lent qui remonte une pente) : sans solution à un trait trouvée, abandonnée pour l'instant. Le jeu principal (levels.js) n'intègre PAS la refonte ; zip non envoyé (demande de Simon : seulement l'aperçu). Fiche didacticiel du ruban lent/frein : à faire si intégré.
