# QUANTIX — ÉTAT (source de vérité unique)

**Version de référence : R266 — 23 octobre 2026.** Tampon du code : `build R269`. Vérifier avant tout travail de code : `grep -o 'build R[0-9]*' index.html` doit afficher **R269** ; sinon ce
n'est pas le dernier zip → le demander à Simon.

**Au démarrage, lire aussi `DEMARRAGE.md` (1 page)** : où décompresser le zip, quoi ne pas relire, comment traiter un
défaut vu sur iPhone. Il résume les erreurs des sessions R262–R263.

*Ce document remplace le haut de l'ancien `REPRISE-SESSION.md`. Il reste court (< 8 Ko) : on le réécrit à chaque lot, on
ne l'empile pas. L'historique va dans `JOURNAL.md`.*

---

## 1. Ce qui est dans le jeu (déployable)

Accueil Visière + héros ; Constellation et pages de monde ; 132 niveaux (11 mondes × 12) ; plein cadre ; didacticiel
holographique ; bilan animé ; fin « Les retrouvailles » (`fin5`) et bilan du parcours ; Quantone intégré ; FR/EN ;
sauvegarde locale. **Caché** : Zen Lab, Quantum Drop, atelier de particule (D5). **Inactif** : bouton Ko-fi.

## 2. Derniers lots (détail : `JOURNAL.md`)

- **R269** : invite d'envoi refaite (retour de Simon : peu claire, polluait le bilan) : fenêtre à part, une seule fois, à la 1re sortie du bilan ; ensuite une ligne discrète « Envoyer cette partie » sous les boutons ; le bilan n'est plus modifié avant le Oui.
- **R268** : clé Web3Forms de Simon posée dans `runlog.js` (`SHARE_KEY`) : envoi actif ; non testé avec le vrai service (réseau de la session bloqué).
- **R267** : envoi anonyme des parties par e-mail (Web3Forms) dans `runlog.js` : choix unique Oui/Non au 1er niveau réussi (jamais pré-coché), case « Envoyer cette partie » ensuite, réglage dans Paramètres ; **inactif tant que `SHARE_KEY` est vide**. Chantier 6, étape 2.
- **R266** : journal local des essais (`assets/js/runlog.js`, clé `quantix.runs.v1`) + Paramètres « Mes parties » (Exporter / Effacer) ; rien n'est envoyé. Chantier 6, étape 1.
- **R265** : nettoyage exécuté (`NETTOYAGE.md` §5) : 34 documents retirés du Projet (copies en `docs/archive/` du zip), 15 mis à jour ; artefact Menu édition supprimé le 23 oct.
- **R264** : inventaire et nettoyage préparés (`NETTOYAGE.md`, à exécuter dans une conversation neuve) ; Menu édition supprimé.
- **R263** : régression du fond Magnétisme non reproduite (niveaux chargés directement) ; `DEMARRAGE.md` créé.
- **R261** : encre — règle « sans trait posé, la jauge est pleine » (`paintEnergy`, compteur `S.inkFix`) ; jauge visible
  aussi sous 600 px de haut (elle disparaissait sur petits iPhone) ; Échelle fusionnée dans Déplacer (poignée ⤢ + pincement,
  bouton Échelle retiré) ; Quantone : chaque trait garde boîte à rythmes, kit, fonction et boucle propres.
- **R260** : Quantone — barre de lecture fixe, mini‑diagramme de charge, gamme/grille sous le champ, format `.qx`.
- **R259** : jeu suspendu sous Quantone (tous les contextes audio), ouverture `.json`, garde‑fous audio.

## 3. Chantiers ouverts — dans l'ordre (demandes de Simon du 22 oct.)

| # | Chantier | État | Prochaine action |
|---|---|---|---|
| 1 | **Erreurs fatales** (encre vide au départ, niveau impossible) | correctif défensif R261 ; cause exacte non reproduite | Simon : dire le niveau et l'écran si ça revient ; scan 132 (n° 2) |
| 2 | **Scan des 132 niveaux** (`tools/scan132.js N`) : encre de départ, référence, encre minimale d'une ligne gagnante, contournements, murs jamais touchés | outil prêt (`tools/scan132.js`, ≈ 30 s par niveau) ; les résultats du 22 oct. sont perdus (bloc‑notes) | relancer avec l'accord de Simon, résultats dans `tools/` ; rapport par monde |
| 3 | **Calibrage de l'encre** au scénario de chaque niveau ; **géodésique** (solution de référence) la plus économe ET traçable au doigt | à faire | règle à écrire après le scan |
| 4 | **Redondance** : Chaîne (monde 3) puis Soufflerie (monde 5, refonte de fond : jouabilité, décor, originalité) | à faire | matrice des 12 niveaux par monde |
| 5 | **Méthode de génération** non reproductiviste (logique propre au monde et au niveau, public cible, recherche documentée) ; futur monde « mécanique des fluides » | à faire | document de méthode, après 2–4 |
| 6 | **Collecte des parties des bêta‑testeurs** | étapes 1–2 faites (R266–R268) ; envoi actif, jamais testé avec le vrai service | Simon : sur iPhone, répondre Oui, finir un niveau, vérifier le mail sur mydopeoff@gmail.com ; puis analyser les fichiers reçus |
| 7 | **Régression Magnétisme** : le fond texturé n'est animé qu'au niveau 1 | R263 : **non reproduite** — `tools/probe_ferro.py` (Chromium sans GPU) mesure le fond animé aux niveaux 85 et 86 chargés directement ; aucun code touché | Simon : dire comment il passe au niveau 2 (Suivant / Constellation), sur quel appareil, et si le fond est figé ou absent ; sinon essai long (40 s) + gestion de la perte de contexte WebGL ; puis test des fonds par monde |
| 8 | **Décor Gravité** : points animés liés à la direction et à la force de la gravité, tailles/opacités variées, noyés dans la poussière (vidéo de référence de Simon) | demandé le 22 oct. | banc des rendus d'abord |
| 9 | Monde 11 (niveaux 5, 7–10 à refaire ; dédoublements multiples), monde 10 (2, 9, 10, 11 sans référence), mondes 5–6 | en attente | après 1–4 |
| 10 | Quantone : volets Boucle / Morceau (proposition R241) | en attente | décision de Simon |
| 11 | **Charte graphique complète** (`CHARTE_GRAPHIQUE.md`, à construire) : fusion des sources listées dans `NETTOYAGE.md` §3 | à faire, quand Simon la convoque | consolider sans perdre une exigence |
| 12 | **Méthode de génération des niveaux** (`METHODE_NIVEAUX.md`, à construire) : charte des niveaux mise à jour avec les demandes du 22 oct. | à faire, quand Simon la convoque | idem, sources dans `NETTOYAGE.md` §3 |

## 4. Décisions attendues de Simon

| # | Décision | Recommandation |
|---|---|---|
| D1 | Périmètre de la première version publique | « Chapitre 1 » (mondes 1–4 + héros + fin provisoire) |
| D2 | Nom (« Quantix » probablement pris comme marque) | vérifier EUIPO, BOIP, magasins |
| D3 | Modèle de la première version | gratuit + Ko‑fi ; plus tard démo + achat unique |
| D4 | Connecter le dépôt GitHub à la session | oui (fin des zips, tests automatiques) |
| D5 | Zen Lab, Quantum Drop, atelier de particule | retirer du code jusqu'à redéfinition |
| D6–D8 | Origine de la compagne, sens du noyau, Ko‑fi et crédits | voir `AUDIT_R209.md` §19 |
| D9 | Mot de la ressource de tracé | « énergie » partout |
| D10 | Ordre de refonte | voir §3 ci‑dessus (priorité aux erreurs fatales) |
| D11 | Collecte bêta : périmètre (export volontaire seul, ou envoi vers un service) | export volontaire d'abord |

## 5. Monde par monde (résumé ; détail par niveau : `AUDIT_R209.md` annexe B, à régénérer par le scan)

| Monde | Niveaux | Réf. | Contournables connus | Remarques |
|---|---|---|---|---|
| 1 Atelier | 1–12 | 12/12 | — | niv. 1 et 9 gagnables trop court |
| 2 Fonderie | 13–24 | 11/12 | — | #19 sans référence ; #21 zone occupée |
| 3 Chaîne | 25–36 | 12/12 | — | **redondances signalées par Simon** ; #34 zone occupée |
| 4 Glacier | 37–48 | 12/12 | — | #48 à 63–70 % |
| 5 Soufflerie | 49–60 | 7/12 | 50 53 55 56 58 | **refonte de fond demandée** |
| 6 Mécanique | 61–72 | 6/12 | 61 62 63 64 67 69 | |
| 7 Gravité | 73–84 | 12/12 | — | à juger (`A_VERIFIER.md`) ; décor à refaire (§3 n° 8) |
| 8 Magnétisme | 85–96 | 12/12 | — | régression du fond (§3 n° 7) |
| 9 Faille | 97–108 | 12/12 | — | à juger |
| 10 Filaments | 109–120 | 8/12 | 118 119 | 117 à refaire |
| 11 Quantique | 121–132 | 8/12 | 125 127 128 129 130 | 5, 7–10 à refaire ; ne pas toucher au niveau 12 sans accord |

## 6. Ce qui n'a jamais été vérifié

Performances sur iPhone réel (héros, épilogue, monde 8) ; avis de joueurs extérieurs ; micro de Quantone sur iPhone ;
import Dictaphone `.m4a` ; écoute des nouvelles voix de la boîte à rythmes.

## 7. Liens (à redonner en fin de réponse, Aperçu en premier)

Aperçu https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC ·
Éditeur de niveaux https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp · Banc des rendus https://claude.ai/artifact/YLLD3eGHDLFWP3k44nfMxW ·
Quantone https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By · Banc de la fin https://claude.ai/artifact/SW1xvEzZkMsCq562tCKH3b

*Les artefacts en ligne ne sont pas republiés à chaque lot : Aperçu et Quantone peuvent montrer une version plus ancienne
que le zip. Le dire à Simon.*
