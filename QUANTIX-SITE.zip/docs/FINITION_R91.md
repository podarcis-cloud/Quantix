# QUANTIX — Compte rendu du degré de finition des 132 niveaux (R91)

*Mesuré le 3 octobre 2026 avec `tools/finition.js` (et les audits `enigme.js` déjà faits). Aucun niveau n'a encore passé ton test (porte P10) : le meilleur état possible est donc « candidat ».*

## Échelle

| Note | Signification |
|---|---|
| **A — fini (candidat)** | conçu au protocole complet (fiche, hypothèse, leurre), contrôle énigme ✓, aucun raccourci mesuré, zone dégagée — attend ton test |
| **B — solide** | solution enregistrée qui marche, pas de trait court gagnant, pas de ligne directe, zone dégagée, contrôle énigme ✓ ou fiche — mais pas encore repassé au protocole complet |
| **C — jouable mais faible** | se joue, mais au moins un défaut mesuré : trait trop court qui gagne, ligne directe, mécanique inutile, raccourci, mur dans la zone |
| **D — brut** | aucune solution enregistrée ni vérifiée (ancien niveau jamais retravaillé) — à refaire |

## Bilan

| Note | Niveaux | Part |
|---|---|---|
| A · fini (candidat, attend ton test) | 3 | 2 % |
| B · solide | 10 | 8 % |
| C · jouable mais faible | 37 | 28 % |
| D · brut, à refaire | 82 | 62 % |

## Par monde

| Monde | A | B | C | D |
|---|---|---|---|---|
| 1 Atelier | 1 | 2 | 9 | 0 |
| 2 Fonderie | 0 | 2 | 9 | 1 |
| 3 Chaîne | 1 | 0 | 11 | 0 |
| 4 Glacier | 1 | 5 | 4 | 2 |
| 5 Soufflerie | 0 | 1 | 2 | 9 |
| 6 Mécanique | 0 | 0 | 0 | 12 |
| 7 Gravité | 0 | 0 | 2 | 10 |
| 8 Magnétisme | 0 | 0 | 0 | 12 |
| 9 Faille | 0 | 0 | 0 | 12 |
| 10 Filaments | 0 | 0 | 0 | 12 |
| 11 Quantique | 0 | 0 | 0 | 12 |

## Détail niveau par niveau

### Monde 1 — Atelier

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 1 | Le premier trait | **C** | 9 u | un trait de 9 u suffit; contrôle énigme ✗ |
| 2 | Le pont | **C** | 8 u | un trait de 8 u suffit |
| 3 | Le demi-tour | **B** | 111 u | — |
| 4 | Le relais | **B** | — | aucun trait unique trouvé |
| 5 | La douceur | **C** | 17 u | un trait de 17 u suffit |
| 6 | Le fil | **C** | 138 u | contrôle énigme ✗ |
| 7 | Économie | **C** | 15 u | un trait de 15 u suffit |
| 8 | La portée | **C** | 121 u | contrôle énigme ✗ |
| 9 | Le détour | **C** | 97 u | un trait de 97 u suffit; contrôle énigme ✗ |
| 10 | Le plafond | **A** | — | aucun trait unique trouvé |
| 11 | Le relais | **C** | — | aucun trait unique trouvé; mur dans la zone |
| 12 | L’établi | **C** | — | aucun trait unique trouvé; contrôle énigme ✗ |

### Monde 2 — Fonderie

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 13 | Le trampoline | **C** | 28 u | un trait de 28 u suffit; contrôle énigme ✗ |
| 14 | Le ricochet | **B** | 51 u | — |
| 15 | La montée | **B** | — | aucun trait unique trouvé |
| 16 | La hauteur juste | **C** | 50 u | un trait de 50 u suffit; contrôle énigme ✗ |
| 17 | Sol brûlant | **C** | 39 u | un trait de 39 u suffit; contrôle énigme ✗ |
| 18 | Ta plaque | **C** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 19 | Le four | **D** | 47 u | un trait de 47 u suffit; aucune solution enregistrée |
| 20 | Le tremplin | **C** | 87 u | — |
| 21 | Le grand retour | **C** | 164 u | mur dans la zone |
| 22 | Double rebond | **C** | 17 u | un trait de 17 u suffit |
| 23 | L’élan d’abord | **C** | 62 u | un trait de 62 u suffit |
| 24 | La fonte | **C** | 182 u | — |

### Monde 3 — Chaîne

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 25 | Le tapis | **A** | — | aucun trait unique trouvé |
| 26 | Sens inverse | **C** | 35 u | un trait de 35 u suffit; contrôle énigme ✗ |
| 27 | Tapis et butée | **C** | 21 u | un trait de 21 u suffit; contrôle énigme ✗ |
| 28 | Le plafond bas | **C** | 19 u | un trait de 19 u suffit; contrôle énigme ✗ |
| 29 | Ton élan | **C** | 70 u | un trait de 70 u suffit; ligne directe gagnante (7); contrôle énigme ✗ |
| 30 | Saut de chaîne | **C** | 106 u | contrôle énigme ✗ |
| 31 | Tapis et lames | **C** | 55 u | un trait de 55 u suffit; contrôle énigme ✗ |
| 32 | Deux tapis | **C** | 114 u | contrôle énigme ✗ |
| 33 | Chaîne montante | **C** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 34 | Relais d’élan | **C** | 176 u | ligne directe gagnante (2); mur dans la zone; contrôle énigme ✗ |
| 35 | Le tri des tapis | **C** | — | aucun trait unique trouvé; ligne directe gagnante (4); contrôle énigme ✗ |
| 36 | La chaîne complète | **C** | 75 u | un trait de 75 u suffit; contrôle énigme ✗ |

### Monde 4 — Glacier

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 37 | Le lac | **A** | 53 u | — |
| 38 | Trop vite | **C** | 77 u | contrôle énigme ✗ |
| 39 | Le saut | **B** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 40 | Le demi‑tour | **B** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 41 | Glace interdite | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée |
| 42 | La butée | **C** | 36 u | un trait de 36 u suffit |
| 43 | Deux étages | **C** | 40 u | un trait de 40 u suffit |
| 44 | La patinoire | **B** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 45 | Le passage gardé | **B** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 46 | Verglas | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée |
| 47 | La crevasse double | **B** | — | aucun trait unique trouvé; contrôle énigme ✗ |
| 48 | Le sérac | **C** | — | aucun trait unique trouvé; contrôle énigme ✗ |

### Monde 5 — Soufflerie

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 49 | Le souffle | **C** | 110 u | contrôle énigme ✗ |
| 50 | Vent de face | **C** | — | aucun trait unique trouvé; mécanique inutile; contrôle énigme ✗ |
| 51 | Vent descendant | **B** | 137 u | — |
| 52 | Colonne étroite | **D** | 196 u | aucune solution enregistrée |
| 53 | Deux colonnes | **D** | 135 u | aucune solution enregistrée |
| 54 | Vent et plafond | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée |
| 55 | Vent et lame | **D** | 106 u | aucune solution enregistrée |
| 56 | Contre-courant | **D** | — | aucun trait unique trouvé; aucune solution enregistrée |
| 57 | La rafale | **D** | 140 u | aucune solution enregistrée |
| 58 | Le tunnel | **D** | 42 u | un trait de 42 u suffit; aucune solution enregistrée |
| 59 | La tempête | **D** | 44 u | un trait de 44 u suffit; aucune solution enregistrée |
| 60 | La veine | **D** | 149 u | aucune solution enregistrée |

### Monde 6 — Mécanique

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 61 | Le piston | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée |
| 62 | La navette | **D** | 110 u | aucune solution enregistrée |
| 63 | Piston bas | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée |
| 64 | Deux pistons | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée |
| 65 | Le pendule | **D** | 28 u | un trait de 28 u suffit; aucune solution enregistrée |
| 66 | Va-et-vient | **D** | 15 u | un trait de 15 u suffit; aucune solution enregistrée |
| 67 | Métronome | **D** | 33 u | un trait de 33 u suffit; aucune solution enregistrée |
| 68 | L’engrenage | **D** | 160 u | aucune solution enregistrée |
| 69 | Cadence double | **D** | 82 u | un trait de 82 u suffit; aucune solution enregistrée |
| 70 | L’horloge | **D** | 35 u | un trait de 35 u suffit; aucune solution enregistrée |
| 71 | Atelier mobile | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée |
| 72 | Le régulateur | **D** | — | aucun trait unique trouvé; aucune solution enregistrée |

### Monde 7 — Gravité

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 73 | Gravité faible | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée |
| 74 | Gravité lourde | **C** | 96 u | — |
| 75 | Gravité inversée | **C** | 101 u | — |
| 76 | Champ latéral | **D** | 90 u | aucune solution enregistrée |
| 77 | Deux champs | **D** | 14 u | un trait de 14 u suffit; aucune solution enregistrée |
| 78 | Champ et mur | **D** | 22 u | un trait de 22 u suffit; aucune solution enregistrée |
| 79 | Ascension | **D** | 10 u | un trait de 10 u suffit; aucune solution enregistrée |
| 80 | Champ et lame | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée |
| 81 | Bascule | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée |
| 82 | Apesanteur | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée |
| 83 | Le puits | **D** | 60 u | un trait de 60 u suffit; aucune solution enregistrée |
| 84 | Le pèse-matière | **D** | 96 u | un trait de 96 u suffit; aucune solution enregistrée |

### Monde 8 — Magnétisme

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 85 | L’aimant | **D** | 48 u | aucune solution enregistrée |
| 86 | Aimant fort | **D** | 84 u | aucune solution enregistrée |
| 87 | Aimant haut | **D** | 44 u | aucune solution enregistrée |
| 88 | Deux aimants | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée |
| 89 | Aimant et mur | **D** | 47 u | un trait de 47 u suffit; aucune solution enregistrée |
| 90 | Le couloir | **D** | 78 u | un trait de 78 u suffit; aucune solution enregistrée |
| 91 | Aimant et lame | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée |
| 92 | Slalom | **D** | 30 u | un trait de 30 u suffit; aucune solution enregistrée |
| 93 | Orbite | **D** | 104 u | un trait de 104 u suffit; aucune solution enregistrée |
| 94 | Champ magnétique | **D** | 22 u | un trait de 22 u suffit; aucune solution enregistrée |
| 95 | La capture | **D** | 20 u | un trait de 20 u suffit; aucune solution enregistrée |
| 96 | Le solénoïde | **D** | 202 u | aucune solution enregistrée |

### Monde 9 — Faille

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 97 | Le portail | **D** | 40 u | aucune solution enregistrée |
| 98 | Portail court | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée |
| 99 | Portail montant | **D** | 18 u | un trait de 18 u suffit; aucune solution enregistrée |
| 100 | Portail et mur | **D** | 35 u | un trait de 35 u suffit; aucune solution enregistrée |
| 101 | Deux failles | **D** | 39 u | un trait de 39 u suffit; aucune solution enregistrée |
| 102 | Portail et vent | **D** | 8 u | un trait de 8 u suffit; réussit sans trait; aucune solution enregistrée |
| 103 | Portail et lame | **D** | 39 u | un trait de 39 u suffit; aucune solution enregistrée |
| 104 | Boucle | **D** | 173 u | aucune solution enregistrée |
| 105 | Aller-retour | **D** | 8 u | un trait de 8 u suffit; réussit sans trait; aucune solution enregistrée |
| 106 | Faille interdite | **D** | 38 u | un trait de 38 u suffit; aucune solution enregistrée |
| 107 | Le pli | **D** | 38 u | un trait de 38 u suffit; aucune solution enregistrée |
| 108 | La singularité | **D** | — | aucun trait unique trouvé; aucune solution enregistrée |

### Monde 10 — Filaments

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 109 | La corde | **D** | 42 u | aucune solution enregistrée |
| 110 | Corde tendue | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée |
| 111 | Le hamac | **D** | 131 u | aucune solution enregistrée |
| 112 | Corde et plaque | **D** | 133 u | aucune solution enregistrée |
| 113 | La balle molle | **D** | 118 u | aucune solution enregistrée |
| 114 | Molle et mince | **D** | — | aucun trait unique trouvé; aucune solution enregistrée |
| 115 | Molle et pente | **D** | 8 u | un trait de 8 u suffit; ligne directe gagnante (2); réussit sans trait; aucune solution enregistrée |
| 116 | Molle et lame | **D** | 186 u | aucune solution enregistrée |
| 117 | Deux cordes | **D** | 125 u | aucune solution enregistrée |
| 118 | Le filet | **D** | 138 u | aucune solution enregistrée |
| 119 | Corde et colonne | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée |
| 120 | Opus | **D** | 77 u | un trait de 77 u suffit; aucune solution enregistrée |

### Monde 11 — Quantique

| # | Niveau | Note | Plus petit trait gagnant | Défauts mesurés |
|---|---|---|---|---|
| 121 | Le lien | **D** | — | aucun trait unique trouvé; aucune solution enregistrée |
| 122 | Opposition | **D** | 8 u | un trait de 8 u suffit; aucune solution enregistrée |
| 123 | La mesure | **D** | 11 u | un trait de 11 u suffit; aucune solution enregistrée |
| 124 | Deux possibles | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée |
| 125 | Le temps ralenti | **D** | 11 u | un trait de 11 u suffit; aucune solution enregistrée |
| 126 | Lien et porte | **D** | 12 u | un trait de 12 u suffit; aucune solution enregistrée |
| 127 | Intrication double | **D** | 13 u | un trait de 13 u suffit; aucune solution enregistrée |
| 128 | Mesure tardive | **D** | 29 u | un trait de 29 u suffit; aucune solution enregistrée |
| 129 | Temps et rebond | **D** | 17 u | un trait de 17 u suffit; aucune solution enregistrée |
| 130 | Le choix | **D** | 28 u | un trait de 28 u suffit; aucune solution enregistrée |
| 131 | Machine quantique | **D** | 50 u | un trait de 50 u suffit; aucune solution enregistrée |
| 132 | Quantix | **D** | 27 u | un trait de 27 u suffit; aucune solution enregistrée |

## Ce que mesure chaque colonne

- **Plus petit trait gagnant** : sur 1 200 traits droits au hasard, le plus court qui réussit. Sous 40 u (positions 1–3), 80 u (4–8) ou 120 u (9–12), le niveau est trivial.
- **Ligne directe** : tracés de la particule vers la zone, dans chaque matière offerte (jusqu'à 12 variantes) ; une seule qui gagne = raccourci évident.
- **Mécanique inutile** : pour les mondes à champ, la solution de référence réussit encore quand on retire le champ.
- **Mur dans la zone** : un élément entre dans l'intérieur du bassin (`zonepropre.js`).
- **Contrôle énigme ✗** : audits `enigme.js` (R74–R89) : raccourci ou élément inutile trouvé.

**Limites** : le tirage au hasard peut manquer un raccourci (le plus petit trait est une borne haute) ; les mondes 6 à 11 n'ont pas de solution enregistrée, donc ni contrôle d'énigme ni test de mécanique ; aucun niveau n'a été testé par toi.