# Audit de conception des niveaux (R298, 25 oct. 2026)

Méthode : pour chaque niveau, on retire un élément à la fois (zone interdite, mur, mécanique entière) et on regarde (a) si la solution de référence réussit encore, (b) si des lignes droites tirées au hasard (400, appariées) réussissent davantage. **Limites** : test à un seul trait aléatoire + la référence ; un élément « sans effet » peut pourtant guider le regard, servir le scénario ou gêner des solutions à plusieurs traits. À confirmer à l'œil avant de supprimer.

## Constats (à lire d'abord)
1. **Beaucoup d'obstacles ne servent à rien** : sur 656 éléments, 187 ne sont jamais approchés par la balle (référence + 150 tracés au hasard) et 167 sont approchés sans rien changer. Seuls 208 sont indispensables à la référence et 30 filtrent des raccourcis. Le problème s'aggrave avec les mondes : monde 9 = 60 éléments sans effet, monde 11 = 91.
2. **Les mondes 1 à 4 réutilisent les mêmes trois mécaniques** (courbes, flux, zone interdite) ; la variété vient de la géométrie, pas de nouvelles idées. Le monde 10 (11 mécaniques) et le monde 11 (10) en empilent beaucoup, sans que chaque niveau en exige plus d'une.
3. **Doublons nets** : N68≈N71, N99≈N106, N2≈N37, N86≈N95, N25≈N39, N112≈N113 (voir §3).
4. **16 niveaux n'ont pas de solution de référence** (`optsol`) : impossible de les auditer finement.
5. **Limite** : mesure par un seul trait et la référence ; un obstacle « sans effet » peut guider le regard ou gêner des solutions à plusieurs traits. Ne rien supprimer sans regarder le niveau.

## 1. Utilité des éléments (132 niveaux, 656 éléments)

- indispensable : 208
- filtre : 30
- sert l'étoile : 11
- sans effet : 407
- non testé : 0

Parmi les « sans effet » (407) : **jamais approchés par la balle : 187** (obstacles morts ou purement décoratifs) · approchés mais redondants : 167 · mécaniques sans effet mesurable : 53

Niveaux dont la référence est ABSENTE ou échoue à l'état actuel : N19, N53, N55, N56, N57, N58, N61, N62, N63, N64, N67, N69, N110, N117, N118, N119

## 2. Par monde : variété, éléments inutiles, redondance

| Monde | Mécaniques distinctes | Types de réflexion | Éléments sans effet | Paires quasi identiques |
|---|---|---|---|---|
| 1 | 4 (curves, flow, mz, nd) | forces 7, zone interdite 6, rebond simple 2, quantique 2, multi-traits 2 | 22 | 0 |
| 2 | 3 (curves, flow, nd) | rebond simple 4, zone interdite 4, forces 3, multi-traits 2 | 16 | 0 |
| 3 | 3 (curves, flow, nd) | zone interdite 5, rebond simple 4, forces 2, multi-traits 2 | 24 | 0 |
| 4 | 3 (curves, flow, nd) | zone interdite 6, forces 4, rebond simple 3, multi-traits 2 | 24 | 0 |
| 5 | 6 (curves, flow, nd, updraft, vortex, wind) | forces 12, zone interdite 3, multi-traits 1 | 21 | 1 |
| 6 | 5 (curves, flow, mov, nd, pend) | mobile 11, zone interdite 7, forces 3, corps/cordes 2 | 37 | 1 |
| 7 | 5 (curves, flow, grav, nd, well) | forces 12, zone interdite 1, multi-traits 1 | 20 | 1 |
| 8 | 9 (bf, coil, curves, flow, kick, mag, nd, rails, spectro) | zone interdite 10, forces 9, corps/cordes 5, mobile 3, transport 1 | 44 | 1 |
| 9 | 5 (curves, flow, nd, port, wrap) | transport 12, zone interdite 10, forces 2 | 60 | 6 |
| 10 | 11 (curves, elastic, flow, fork, mag, nd, sling, softball, strE, strings, wind) | corps/cordes 8, zone interdite 5, forces 4, mobile 2, multi-traits 2 | 48 | 2 |
| 11 | 10 (bf, curves, det, ent, gate, mov, nd, rec, sup, tdil) | zone interdite 10, quantique 9, transport 7, mobile 1, forces 1 | 91 | 2 |

## 3. Redondance : niveaux quasi identiques (signature ≥ 0,85)

Même ensemble de mécaniques + même forme de solution de référence (nombre de traits, matière, angle, longueur). Le joueur refait la même réflexion.

- N68 « L’engrenage » ≈ N71 « Atelier mobile » (0.99)  — même monde
- N99 « Le geyser » ≈ N106 « La couture » (0.97)  — même monde
- N2 « Le pont » ≈ N37 « Le lac » (0.97)
- N86 « La feuille d’or » ≈ N95 « La capture » (0.94)  — même monde
- N25 « Le tapis » ≈ N39 « Le saut » (0.92)
- N112 « La balle molle » ≈ N113 « Molle et mince » (0.91)  — même monde
- N5 « Le demi-tour » ≈ N26 « Sens inverse » (0.89)
- N17 « Sol brûlant » ≈ N39 « Le saut » (0.88)
- N49 « Le souffle » ≈ N50 « Vent de face » (0.88)  — même monde
- N17 « Sol brûlant » ≈ N25 « Le tapis » (0.87)
- N127 « Intrication double » ≈ N131 « Machine quantique » (0.87)  — même monde
- N80 « Le jet » ≈ N81 « La frontière » (0.86)  — même monde
- N128 « Mesure tardive » ≈ N130 « Le choix » (0.85)  — même monde
- N109 « Corde tendue » ≈ N111 « Corde et plaque » (0.85)  — même monde
- N105 « Aller-retour » ≈ N107 « Le pli » (0.85)  — même monde
- N104 « Le trou de serrure » ≈ N106 « La couture » (0.85)  — même monde
- N101 « Le bord du monde » ≈ N105 « Aller-retour » (0.85)  — même monde
- N99 « Le geyser » ≈ N104 « Le trou de serrure » (0.85)  — même monde
- N98 « À travers le mur » ≈ N100 « Portail et mur » (0.85)  — même monde
- N7 « Économie » ≈ N15 « La montée » (0.85)

## 4. Apport de nouveauté par niveau

Mécaniques à leur première apparition : N1 curves; N3 mz+flow; N4 nd; N49 wind; N54 updraft; N60 vortex; N61 mov; N65 pend; N73 grav; N78 well; N85 mag; N87 bf; N90 rails+coil; N91 kick; N96 spectro; N97 port; N101 wrap; N109 elastic; N112 softball; N114 strings+strE+fork; N120 sling; N121 ent+gate; N123 sup; N124 det; N125 tdil; N126 rec

Niveaux sans mécanique nouvelle ET très proches d'un niveau antérieur (≥ 0,80) : 29 — N11, N15, N25, N26, N28, N31, N34, N35, N37, N38, N39, N42, N43, N46, N50, N71, N80, N81, N84, N95, N100, N104, N105, N106, N107, N111, N113, N130, N131

## 5. Éléments sans effet à examiner (obstacles probablement décoratifs ou mal placés)

**Jamais approchés** (la référence et 150 tracés au hasard ne passent jamais à moins de 12 u) : candidats à supprimer, déplacer ou à justifier visuellement.

- N2 « Le pont » : mur #2 mat 0 [150,0,150,112]
- N7 « Économie » : mur #2 mat 0 [137,282,250,380]
- N9 « Le détour » : zone interdite #3 [150,56,150,46] ; mur #3 mat 0 [68,236,70,452]
- N10 « Le plafond » : mur #1 mat 2 [166,122,356,122]
- N16 « La hauteur juste » : mur #2 mat 2 [150,150,360,150]
- N19 « Le four » : mur #2 mat 1 [180,300,300,300]
- N21 « Le grand retour » : mur #2 mat 1 [145,226,248,262] ; mur #3 mat 0 [133,189,235,62]
- N24 « La fonte » : mur #3 mat 0 [54,40,178,40] ; mur #4 mat 0 [54,40,54,112]
- N25 « Le tapis » : mur #3 mat 0 [260,306,260,476]
- N26 « Sens inverse » : mur #1 mat 0 [250,290,340,290]
- N28 « Le plafond bas » : mur #3 mat 2 [130,228,240,228]
- N31 « Tapis et lames » : mur #1 mat 0 [20,268,130,290]
- N32 « Deux tapis » : mur #1 mat 0 [15,290,90,290] ; mur #2 mat 3 [90,290,130,290]
- N33 « Chaîne montante » : mur #2 mat 3 [255,288,195,232]
- N34 « Relais d’élan » : mur #1 mat 3 [66,128,240,178] ; mur #2 mat 3 [297,223,356,274]
- N35 « Le tri des tapis » : mur #1 mat 3 [300,268,356,306] ; mur #2 mat 3 [95,368,188,476] ; mur #3 mat 0 [259,249,356,264] ; mur #4 mat 3 [219,339,356,372] ; mur #5 mat 3 [172,192,216,260]
- N37 « Le lac » : mur #3 mat 4 [260,240,262,250]
- N38 « Trop vite » : mur #2 mat 4 [150,190,185,186]
- N41 « La combe gelée » : mur #1 mat 2 [0,476,360,476] ; mur #2 mat 0 [262,80,360,80]
- N43 « Deux étages » : mur #2 mat 4 [47,155,119,87]
- N45 « Le passage gardé » : mur #3 mat 0 [262,238,262,476]
- N46 « Verglas » : mur #1 mat 2 [0,476,360,476] ; mur #2 mat 0 [280,88,360,88] ; mur #3 mat 0 [280,88,280,126]
- N47 « La crevasse double » : mur #3 mat 4 [230,150,296,150] ; mur #8 mat 4 [150,326,40,340]
- N49 « Le souffle » : mur #1 mat 0 [140,316,44,344]
- N50 « Vent de face » : mur #3 mat 0 [262,330,262,476]
- N54 « La cascade inversée » : mur #1 mat 0 [300,476,360,476]
- N61 « Le piston » : mur #1 mat 0 [0,168,148,168]
- N65 « Le pendule » : zone interdite #1 [0,0,360,120]
- N66 « L’escalier mécanique » : mur #1 mat 2 [0,476,40,476]
- N68 « L’engrenage » : mur #2 mat 0 [30,200,30,476] ; mur #4 mat 0 [90,330,118,333] ; mur #5 mat 0 [170,362,170,476]
- N71 « Atelier mobile » : mur #2 mat 0 [30,200,30,476] ; mur #5 mat 0 [358,140,358,242]
- N79 « Le plafond » : mur #3 mat 2 [0,472,360,472]
- N80 « Le jet » : mur #2 mat 0 [150,170,150,472] ; mur #3 mat 0 [150,472,210,472] ; mur #4 mat 0 [210,170,210,472] ; mur #5 mat 2 [210,472,360,472] ; mur #6 mat 2 [100,22,260,22]
- N81 « La frontière » : mur #1 mat 2 [0,472,360,472]
- N82 « La plume » : mur #1 mat 0 [20,200,20,472] ; mur #2 mat 0 [20,472,80,472] ; mur #3 mat 0 [80,200,80,472] ; mur #4 mat 2 [0,22,170,22] ; mur #6 mat 0 [170,22,170,116] ; mur #7 mat 2 [80,472,360,472]
- N83 « Le miroir » : mur #1 mat 2 [0,472,360,472]
- N89 « Le ricochet » : mur #1 mat 2 [0,476,270,476] ; mur #2 mat 0 [0,0,0,476]
- N90 « Le canon de Gauss » : mur #1 mat 2 [0,476,360,476] ; mur #2 mat 0 [96,416,176,416]
- N92 « Le coussin » : mur #1 mat 2 [0,476,280,476] ; mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #6 mat 2 [280,350,360,350]
- N94 « L’accélérateur » : mur #1 mat 2 [0,476,360,476] ; mur #2 mat 0 [0,0,0,476] ; mur #5 mat 2 [200,300,200,476] ; mur #6 mat 2 [300,381,300,476]
- N96 « Le spectromètre » : mur #1 mat 2 [0,476,360,476] ; mur #2 mat 0 [0,100,0,450] ; mur #3 mat 0 [360,100,360,372] ; mur #4 mat 0 [150,330,316,330] ; mur #5 mat 0 [148,100,148,330] ; mur #6 mat 0 [320,334,320,362] ; mur #8 mat 0 [91,350,91,404]
- N97 « Le portail » : mur #1 mat 0 [0,440,200,440] ; mur #2 mat 2 [200,440,200,476] ; mur #5 mat 0 [240,120,360,120]
- N98 « À travers le mur » : mur #1 mat 0 [180,0,180,480]
- N99 « Le geyser » : mur #2 mat 0 [228,250,228,420] ; mur #3 mat 0 [272,250,272,420]
- N101 « Le bord du monde » : mur #3 mat 0 [0,0,0,330] ; mur #4 mat 0 [0,400,0,476] ; mur #6 mat 0 [360,400,360,476] ; mur #7 mat 0 [0,476,180,476]
- N102 « L’élan transmis » : mur #1 mat 0 [10,110,10,470] ; mur #2 mat 0 [130,110,130,318] ; mur #4 mat 0 [10,470,130,470]
- N103 « La sarbacane » : mur #1 mat 0 [226,0,226,112] ; mur #3 mat 2 [96,150,226,112] ; mur #4 mat 2 [96,232,226,184]
- N104 « Le trou de serrure » : mur #2 mat 0 [240,330,240,476] ; mur #3 mat 0 [240,330,360,330] ; mur #4 mat 0 [0,0,0,476] ; mur #5 mat 0 [360,0,360,476]
- N105 « Aller-retour » : mur #3 mat 0 [0,0,0,300] ; mur #4 mat 0 [0,370,0,440] ; mur #6 mat 0 [360,370,360,476] ; mur #8 mat 0 [170,400,170,440] ; mur #9 mat 0 [256,380,256,476]
- N106 « La couture » : mur #3 mat 0 [220,330,360,330] ; mur #4 mat 0 [220,330,220,476] ; mur #5 mat 0 [214,372,214,440]
- N107 « Le pli » : mur #3 mat 0 [360,0,360,300] ; mur #4 mat 2 [360,370,360,476] ; mur #5 mat 0 [0,0,0,300] ; mur #7 mat 0 [104,380,104,476]
- N108 « L’univers torique » : mur #1 mat 0 [0,396,110,396]
- N109 « Corde tendue » : mur #1 mat 0 [200,320,200,452] ; mur #4 mat 0 [2,120,2,476]
- N111 « Corde et plaque » : zone interdite #2 [0,0,110,480] ; zone interdite #3 [250,150,110,330] ; mur #4 mat 0 [110,120,250,60]
- N112 « La balle molle » : mur #2 mat 0 [201,240,360,240] ; mur #3 mat 0 [150,170,175,238]
- N113 « Molle et mince » : mur #3 mat 2 [0,360,140,360]
- N114 « Le lance-pierre » : mur #2 mat 0 [356,120,356,190]
- N115 « Molle et lame » : mur #2 mat 0 [201,220,360,220] ; mur #3 mat 0 [150,150,175,218] ; mur #5 mat 2 [110,390,250,390]
- N116 « Deux cordes » : zone interdite #2 [0,0,20,480] ; zone interdite #3 [250,115,110,365] ; mur #3 mat 0 [20,140,125,200] ; mur #6 mat 0 [125,110,250,45]
- N118 « Corde et colonne » : mur #1 mat 2 [0,456,160,456] ; mur #2 mat 3 [40,300,150,300]
- N119 « Opus » : mur #1 mat 2 [0,456,150,456] ; mur #2 mat 3 [40,320,160,320] ; mur #3 mat 1 [200,420,330,420]
- N120 « Le relais des frondes » : mur #2 mat 0 [0,120,0,300]
- N122 « Opposition » : mur #1 mat 0 [0,278,46,284] ; mur #2 mat 0 [176,300,214,306] ; mur #3 mat 0 [344,300,360,300]
- N123 « Deux possibles » : zone interdite #2 [270,0,90,220] ; mur #3 mat 0 [0,0,0,476] ; mur #4 mat 0 [360,0,360,476]
- N124 « La mesure » : mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [10,408,96,408]
- N125 « Le temps ralenti » : mur #1 mat 2 [0,476,192,476] ; mur #3 mat 0 [0,0,0,476] ; mur #4 mat 0 [360,0,360,476] ; mur #5 mat 0 [192,430,192,476] ; mur #6 mat 0 [286,430,286,476] ; mur #7 mat 0 [180,165,180,295]
- N126 « L’interféromètre » : mur #2 mat 2 [286,476,360,476] ; mur #6 mat 0 [127,239,127,295] ; mur #7 mat 0 [127,295,182,375] ; mur #8 mat 0 [233,239,233,295] ; mur #9 mat 0 [233,295,178,375] ; mur #14 mat 0 [180,200,233,239] ; mur #15 mat 0 [0,0,0,476] ; mur #16 mat 0 [360,0,360,476]
- N127 « Intrication double » : mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [100,370,100,476] ; mur #5 mat 0 [180,60,180,110] ; mur #6 mat 0 [180,214,180,340] ; mur #7 mat 0 [178,218,40,250]
- N128 « Mesure tardive » : mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [140,320,262,320] ; mur #5 mat 0 [262,320,262,404] ; mur #6 mat 0 [262,404,360,404] ; mur #7 mat 0 [250,250,360,250]
- N129 « Les jumeaux » : mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [280,254,360,254] ; mur #5 mat 0 [100,130,100,300] ; mur #6 mat 0 [260,130,260,300]
- N130 « Le choix » : mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [140,300,220,300] ; mur #5 mat 0 [140,250,140,300] ; mur #6 mat 0 [220,250,220,300] ; mur #7 mat 0 [10,250,45,340] ; mur #8 mat 0 [125,250,95,340]
- N131 « Machine quantique » : zone interdite #2 [0,0,150,170] ; mur #2 mat 0 [0,0,0,476] ; mur #3 mat 0 [360,0,360,476] ; mur #4 mat 0 [280,400,280,476]
- N132 « Quantix » : mur #1 mat 2 [0,476,140,476] ; mur #2 mat 2 [220,476,360,476]

**Approchés mais sans effet / mécaniques sans effet** : à regarder au cas par cas.

- N1 « Le premier trait » : mur #3 mat 2 [25,297,160,297] [approché mais redondant]
- N3 « Le colimaçon » : mécanique « mz » [méca sans effet] ; mécanique « curves » [méca sans effet] ; mécanique « flow » [méca sans effet]
- N4 « Le relais » : zone interdite #1 [140,0,220,255] [approché mais redondant] ; zone interdite #2 [0,240,212,240] [approché mais redondant] ; zone interdite #3 [0,0,140,62] [approché mais redondant]
- N5 « Le demi-tour » : zone interdite #1 [0,0,206,240] [approché mais redondant]
- N6 « Les collines » : zone interdite #1 [140,0,70,66] [approché mais redondant] ; zone interdite #2 [210,0,46,54] [approché mais redondant] ; mécanique « mz » [méca sans effet] ; mécanique « flow » [méca sans effet]
- N9 « Le détour » : zone interdite #1 [0,201,260,279] [approché mais redondant] ; zone interdite #2 [0,0,360,56] [approché mais redondant]
- N10 « Le plafond » : zone interdite #1 [150,268,210,208] [approché mais redondant]
- N11 « Le relais » : zone interdite #1 [233,268,89,86] [approché mais redondant]
- N12 « La cellule » : mécanique « flow » [méca sans effet]
- N13 « Le trampoline » : mécanique « flow » [méca sans effet]
- N16 « La hauteur juste » : zone interdite #1 [80,240,60,240] [approché mais redondant]
- N17 « Sol brûlant » : mur #1 mat 2 [0,470,360,470] [approché mais redondant]
- N18 « Ta plaque » : mécanique « flow » [méca sans effet]
- N19 « Le four » : zone interdite #1 [150,0,30,456] [approché mais redondant] ; zone interdite #2 [300,0,60,456] [approché mais redondant] ; mur #1 mat 2 [0,456,150,456] [approché mais redondant]
- N21 « Le grand retour » : zone interdite #1 [80,169,112,126] [approché mais redondant]
- N24 « La fonte » : zone interdite #1 [60,380,200,52] [approché mais redondant] ; mécanique « flow » [méca sans effet]
- N26 « Sens inverse » : zone interdite #1 [110,0,70,480] [approché mais redondant]
- N28 « Le plafond bas » : zone interdite #1 [130,0,122,480] [approché mais redondant]
- N30 « Saut de chaîne » : mécanique « curves » [méca sans effet] ; mécanique « flow » [méca sans effet]
- N31 « Tapis et lames » : zone interdite #1 [130,0,120,480] [approché mais redondant] ; mur #2 mat 2 [130,470,250,470] [approché mais redondant]
- N32 « Deux tapis » : zone interdite #1 [130,0,60,480] [approché mais redondant] ; zone interdite #2 [232,0,58,480] [approché mais redondant]
- N36 « La chaîne complète » : zone interdite #1 [0,300,262,180] [approché mais redondant] ; mécanique « flow » [méca sans effet]
- N37 « Le lac » : mur #4 mat 2 [150,170,260,170] [approché mais redondant]
- N38 « Trop vite » : mur #3 mat 2 [356,200,356,476] [approché mais redondant]
- N41 « La combe gelée » : zone interdite #1 [0,170,360,310] [approché mais redondant] ; zone interdite #2 [250,0,110,170] [approché mais redondant]
- N42 « La piste glacée » : mécanique « flow » [méca sans effet]
- N43 « Deux étages » : zone interdite #1 [26,173,115,202] [approché mais redondant]
- N45 « Le passage gardé » : zone interdite #1 [150,0,110,480] [approché mais redondant]
- N46 « Verglas » : zone interdite #1 [0,170,360,310] [approché mais redondant] ; zone interdite #2 [270,0,90,170] [approché mais redondant]
- N47 « La crevasse double » : zone interdite #1 [124,162,112,133] [approché mais redondant] ; zone interdite #2 [144,340,122,144] [approché mais redondant] ; mur #6 mat 2 [128,196,232,196] [approché mais redondant]
- N48 « Le pendule de glace » : mécanique « flow » [méca sans effet]
- N50 « Vent de face » : mur #2 mat 2 [110,470,262,470] [approché mais redondant] ; mécanique « wind » [méca sans effet]
- N52 « Colonne étroite » : zone interdite #1 [232,0,128,480] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N53 « Deux colonnes » : mécanique « wind » [méca sans effet]
- N54 « La cascade inversée » : mécanique « flow » [méca sans effet] ; mécanique « updraft » [méca sans effet]
- N55 « Vent et lame » : mur #1 mat 2 [0,400,150,400] [approché mais redondant] ; mécanique « wind » [méca sans effet]
- N56 « Contre-courant » : mécanique « wind » [méca sans effet]
- N57 « La rafale » : zone interdite #1 [210,130,90,160] [approché mais redondant] ; mécanique « wind » [méca sans effet]
- N58 « Le tunnel » : mécanique « wind » [méca sans effet]
- N59 « La tempête » : zone interdite #1 [260,0,100,330] [approché mais redondant] ; zone interdite #2 [0,100,150,100] [approché mais redondant] ; mur #2 mat 2 [0,476,360,476] [approché mais redondant]
- N60 « Le cyclone » : mécanique « flow » [méca sans effet] ; mécanique « vortex » [méca sans effet]
- N61 « Le piston » : zone interdite #1 [160,60,60,100] [approché mais redondant] ; mécanique « mov » [méca sans effet]
- N62 « La navette » : mécanique « mov » [méca sans effet]
- N63 « Piston bas » : zone interdite #1 [120,0,60,240] [approché mais redondant] ; mécanique « mov » [méca sans effet]
- N64 « Deux pistons » : mécanique « mov » [méca sans effet]
- N65 « Le pendule » : zone interdite #2 [170,120,190,360] [approché mais redondant] ; zone interdite #3 [0,282,170,198] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N66 « L’escalier mécanique » : mécanique « flow » [méca sans effet]
- N67 « Métronome » : zone interdite #1 [215,120,100,150] [approché mais redondant] ; zone interdite #2 [60,280,60,160] [approché mais redondant] ; zone interdite #3 [140,60,60,60] [approché mais redondant] ; mécanique « mov » [méca sans effet]
- N68 « L’engrenage » : zone interdite #1 [30,200,60,276] [approché mais redondant] ; zone interdite #2 [170,200,60,276] [approché mais redondant] ; zone interdite #3 [232,170,128,45] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N69 « Cadence double » : mur #1 mat 2 [0,380,120,380] [approché mais redondant] ; mécanique « mov » [méca sans effet]
- N70 « L’horloge » : zone interdite #1 [0,300,360,180] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N71 « Atelier mobile » : zone interdite #1 [30,200,60,276] [approché mais redondant] ; zone interdite #2 [276,190,84,52] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N72 « L’échappement » : mur #1 mat 2 [0,476,300,476] [approché mais redondant] ; mécanique « mov » [méca sans effet] ; mécanique « flow » [méca sans effet] ; mécanique « pend » [méca sans effet]
- N75 « Le manège inversé » : mur #1 mat 2 [70,104,232,104] [approché mais redondant]
- N76 « Le champ de travers » : zone interdite #1 [262,290,98,190] [approché mais redondant]
- N77 « Le saut lunaire » : mur #2 mat 2 [100,472,266,472] [approché mais redondant]
- N78 « La fronde » : mécanique « curves » [méca sans effet] ; mécanique « flow » [méca sans effet]
- N80 « Le jet » : mur #1 mat 2 [0,472,150,472] [approché mais redondant]
- N85 « La lentille » : zone interdite #1 [0,0,360,110] [approché mais redondant] ; zone interdite #3 [290,110,70,370] [approché mais redondant] ; zone interdite #4 [70,350,220,130] [approché mais redondant]
- N86 « La feuille d’or » : zone interdite #1 [150,0,210,480] [approché mais redondant] ; zone interdite #2 [0,150,150,330] [approché mais redondant]
- N87 « La dérive » : zone interdite #1 [220,0,140,480] [approché mais redondant] ; zone interdite #2 [0,292,220,188] [approché mais redondant]
- N88 « Le dipôle » : zone interdite #1 [150,0,210,480] [approché mais redondant] ; zone interdite #2 [0,150,150,330] [approché mais redondant] ; mur #3 mat 2 [0,476,170,476] [approché mais redondant]
- N89 « Le ricochet » : zone interdite #1 [0,400,270,80] [approché mais redondant]
- N90 « Le canon de Gauss » : zone interdite #1 [0,0,46,420] [approché mais redondant] ; mécanique « flow » [méca sans effet]
- N91 « Le cyclotron » : zone interdite #1 [0,0,360,60] [approché mais redondant] ; zone interdite #2 [148,40,64,230] [approché mais redondant]
- N92 « Le coussin » : mur #4 mat 2 [0,230,280,440] [approché mais redondant] ; mur #5 mat 2 [70,193,280,350] [approché mais redondant]
- N93 « Orbite » : zone interdite #1 [162,159,102,60] [approché mais redondant] ; mur #2 mat 2 [0,476,360,476] [approché mais redondant]
- N94 « L’accélérateur » : zone interdite #1 [60,240,300,240] [approché mais redondant]
- N95 « La capture » : zone interdite #1 [209,258,95,60] [approché mais redondant] ; mur #1 mat 0 [72,422,122,424] [approché mais redondant] ; mur #2 mat 2 [0,476,360,476] [approché mais redondant]
- N96 « Le spectromètre » : mécanique « flow » [méca sans effet] ; mécanique « spectro » [méca sans effet]
- N97 « Le portail » : zone interdite #1 [240,120,120,120] [approché mais redondant] ; mur #3 mat 2 [200,476,360,476] [approché mais redondant]
- N98 « À travers le mur » : zone interdite #1 [174,0,186,480] [approché mais redondant] ; mur #2 mat 2 [0,476,180,476] [approché mais redondant]
- N99 « Le geyser » : zone interdite #1 [200,180,160,300] [approché mais redondant] ; zone interdite #2 [0,300,360,180] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N100 « Portail et mur » : zone interdite #1 [0,164,360,316] [approché mais redondant]
- N101 « Le bord du monde » : zone interdite #1 [0,0,186,480] [approché mais redondant] ; mur #2 mat 2 [180,476,360,476] [approché mais redondant]
- N102 « L’élan transmis » : mécanique « flow » [méca sans effet]
- N103 « La sarbacane » : zone interdite #1 [0,0,232,480] [approché mais redondant] ; zone interdite #2 [232,110,128,70] [approché mais redondant] ; mur #5 mat 2 [226,476,360,476] [approché mais redondant]
- N104 « Le trou de serrure » : zone interdite #1 [240,330,120,150] [approché mais redondant] ; mur #1 mat 2 [0,476,240,476] [approché mais redondant]
- N105 « Aller-retour » : zone interdite #1 [0,0,186,480] [approché mais redondant] ; zone interdite #2 [256,380,104,100] [approché mais redondant] ; mur #1 mat 2 [180,0,180,476] [approché mais redondant] ; mur #2 mat 2 [180,476,256,476] [approché mais redondant]
- N106 « La couture » : zone interdite #1 [140,0,220,480] [approché mais redondant] ; zone interdite #2 [0,150,140,330] [approché mais redondant]
- N107 « Le pli » : zone interdite #1 [174,0,186,480] [approché mais redondant] ; zone interdite #2 [0,380,104,100] [approché mais redondant] ; mur #1 mat 2 [180,0,180,476] [approché mais redondant] ; mur #2 mat 2 [104,476,360,476] [approché mais redondant]
- N108 « L’univers torique » : mur #2 mat 2 [150,476,360,476] [approché mais redondant]
- N109 « Corde tendue » : zone interdite #2 [190,330,170,150] [approché mais redondant] ; mur #2 mat 2 [0,476,200,476] [approché mais redondant]
- N110 « Le hamac » : zone interdite #1 [140,130,90,130] [approché mais redondant] ; mur #1 mat 2 [60,452,300,452] [approché mais redondant]
- N111 « Corde et plaque » : zone interdite #1 [252,90,108,60] [approché mais redondant] ; zone interdite #4 [110,0,140,200] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N112 « La balle molle » : mur #1 mat 0 [0,240,175,240] [approché mais redondant]
- N113 « Molle et mince » : mur #1 mat 0 [0,200,146,200] [approché mais redondant]
- N114 « Le lance-pierre » : mur #1 mat 2 [0,476,360,476] [approché mais redondant] ; mécanique « flow » [méca sans effet] ; mécanique « fork » [méca sans effet]
- N115 « Molle et lame » : mur #1 mat 0 [0,220,175,220] [approché mais redondant]
- N116 « Deux cordes » : zone interdite #1 [252,55,108,60] [approché mais redondant] ; zone interdite #4 [113,190,24,290] [approché mais redondant] ; zone interdite #5 [20,0,230,200] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N117 « Le filet » : zone interdite #1 [120,240,110,120] [approché mais redondant] ; mur #1 mat 2 [40,452,320,452] [approché mais redondant]
- N118 « Corde et colonne » : mécanique « wind » [méca sans effet]
- N119 « Opus » : mécanique « wind » [méca sans effet] ; mécanique « mag » [méca sans effet]
- N120 « Le relais des frondes » : mur #1 mat 2 [0,476,360,476] [approché mais redondant] ; mécanique « curves » [méca sans effet] ; mécanique « flow » [méca sans effet] ; mécanique « fork » [méca sans effet]
- N122 « Opposition » : zone interdite #1 [0,292,360,188] [approché mais redondant] ; mur #4 mat 2 [0,476,200,476] [approché mais redondant]
- N123 « Deux possibles » : zone interdite #3 [270,400,90,80] [approché mais redondant] ; mur #1 mat 2 [0,476,196,476] [approché mais redondant] ; mur #2 mat 2 [270,476,360,476] [approché mais redondant]
- N124 « La mesure » : zone interdite #2 [0,140,310,340] [approché mais redondant] ; zone interdite #3 [250,290,110,190] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant] ; mécanique « det » [méca sans effet]
- N125 « Le temps ralenti » : zone interdite #1 [0,0,360,70] [approché mais redondant] ; zone interdite #2 [0,70,222,85] [approché mais redondant] ; zone interdite #3 [252,70,108,85] [approché mais redondant] ; zone interdite #4 [0,155,360,325] [approché mais redondant] ; mur #2 mat 2 [286,476,360,476] [approché mais redondant] ; mécanique « mov » [méca sans effet]
- N126 « L’interféromètre » : zone interdite #1 [0,0,360,156] [approché mais redondant] ; mur #1 mat 2 [0,476,184,476] [approché mais redondant]
- N127 « Intrication double » : zone interdite #1 [0,0,360,60] [approché mais redondant] ; zone interdite #2 [0,250,180,230] [approché mais redondant] ; mur #1 mat 2 [100,476,360,476] [approché mais redondant] ; mécanique « gate » [méca sans effet]
- N128 « Mesure tardive » : zone interdite #1 [0,0,140,170] [approché mais redondant] ; zone interdite #2 [140,320,220,160] [approché mais redondant] ; zone interdite #3 [250,250,110,160] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N129 « Les jumeaux » : zone interdite #1 [0,0,360,130] [approché mais redondant] ; zone interdite #2 [0,130,104,170] [approché mais redondant] ; zone interdite #3 [150,130,210,90] [approché mais redondant] ; zone interdite #4 [176,220,184,80] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant]
- N130 « Le choix » : zone interdite #1 [0,0,360,170] [approché mais redondant] ; zone interdite #2 [0,240,130,110] [approché mais redondant] ; zone interdite #3 [140,250,80,60] [approché mais redondant] ; mur #1 mat 2 [0,476,360,476] [approché mais redondant] ; mécanique « gate » [méca sans effet]
- N131 « Machine quantique » : zone interdite #1 [150,0,210,480] [approché mais redondant] ; zone interdite #3 [0,420,150,60] [approché mais redondant] ; mur #1 mat 2 [0,476,290,476] [approché mais redondant]
- N132 « Quantix » : mécanique « tdil » [méca sans effet]

## 6. Niveaux à retravailler en priorité

- N130 « Le choix » (monde 11) — 7 obstacle(s) jamais approché(s), redondant
- N126 « L’interféromètre » (monde 11) — 8 obstacle(s) jamais approché(s)
- N106 « La couture » (monde 9) — 3 obstacle(s) jamais approché(s), redondant, doublon
- N105 « Aller-retour » (monde 9) — 5 obstacle(s) jamais approché(s), redondant
- N96 « Le spectromètre » (monde 8) — 7 obstacle(s) jamais approché(s)
- N80 « Le jet » (monde 7) — 5 obstacle(s) jamais approché(s), redondant
- N35 « Le tri des tapis » (monde 3) — 5 obstacle(s) jamais approché(s), redondant
- N131 « Machine quantique » (monde 11) — 4 obstacle(s) jamais approché(s), redondant
- N128 « Mesure tardive » (monde 11) — 6 obstacle(s) jamais approché(s)
- N125 « Le temps ralenti » (monde 11) — 6 obstacle(s) jamais approché(s)
- N107 « Le pli » (monde 9) — 4 obstacle(s) jamais approché(s), redondant
- N104 « Le trou de serrure » (monde 9) — 4 obstacle(s) jamais approché(s), redondant
- N82 « La plume » (monde 7) — 6 obstacle(s) jamais approché(s)
- N71 « Atelier mobile » (monde 6) — 2 obstacle(s) jamais approché(s), redondant, doublon
- N129 « Les jumeaux » (monde 11) — 5 obstacle(s) jamais approché(s)
- N127 « Intrication double » (monde 11) — 5 obstacle(s) jamais approché(s)
- N119 « Opus » (monde 10) — 3 obstacle(s) jamais approché(s), référence manquante/échoue
- N113 « Molle et mince » (monde 10) — 1 obstacle(s) jamais approché(s), redondant, doublon
- N111 « Corde et plaque » (monde 10) — 3 obstacle(s) jamais approché(s), redondant
- N68 « L’engrenage » (monde 6) — 3 obstacle(s) jamais approché(s), doublon
- N46 « Verglas » (monde 4) — 3 obstacle(s) jamais approché(s), redondant
- N37 « Le lac » (monde 4) — 1 obstacle(s) jamais approché(s), redondant, doublon
- N25 « Le tapis » (monde 3) — 1 obstacle(s) jamais approché(s), redondant, doublon
- N118 « Corde et colonne » (monde 10) — 2 obstacle(s) jamais approché(s), référence manquante/échoue
- N116 « Deux cordes » (monde 10) — 4 obstacle(s) jamais approché(s)
- N112 « La balle molle » (monde 10) — 2 obstacle(s) jamais approché(s), doublon
- N101 « Le bord du monde » (monde 9) — 4 obstacle(s) jamais approché(s)
- N99 « Le geyser » (monde 9) — 2 obstacle(s) jamais approché(s), doublon
- N95 « La capture » (monde 8) — redondant, doublon
- N94 « L’accélérateur » (monde 8) — 4 obstacle(s) jamais approché(s)
