# QUANTIX — Tri des niveaux restants et stratégie (R73)

*Demande de Simon : « avance de manière optimale, il reste 6 mondes complets non traités ». Avant de concevoir quoi que ce soit,
j'ai mesuré l'état réel de tous les niveaux non refaits, avec un outil de tri automatique (`tools/triage.js`, ~2,5 s par niveau).*

## 1. Critères du tri (les mêmes que pour les niveaux refaits)

Un niveau est **GARDÉ** s'il existe une solution à un trait qui : est assez longue pour sa position (40 / 80 / 120 u),
réussit à la ligne droite (≥ 85 %), **échoue quand on retire la mécanique du monde**, et si aucun trait plus court ne gagne.
Sinon : **TRIVIAL** (un petit trait suffit), **DÉCOR** (la mécanique ne sert pas), **FRAGILE**, **MULTI** (pas de solution à
un trait), **RÉUSSIT SEUL**.

## 2. Résultat

| Monde | Niveaux triés | Gardés | Triviaux | Décor | Autres |
|---|---|---|---|---|---|
| 4 Glacier (restes) | 41, 42, 43, 46 | 0 | 4 (10 à 21 u) | — | — |
| 5 Soufflerie (51–60) | 10 | **1** (51) | 6 | 1 (60) | 2 fragiles |
| 6 Mécanique (61–72) | 12 | 0 | 10 (8 à 35 u) | 1 (68) | 1 multi (72) |
| 7 Gravité (73–84) | 12 | **2** (74, 75) | 10 | — | — |
| 8 Magnétisme (85–96) | 12 | 0 | 12 (8 à 59 u) | — | — |
| 9 Faille (97–108) | 12 | 0 | 9 | 1 (104) | 2 réussissent seuls (102, 105) |
| 10 Filaments (109–120) | 12 | 0 | 6 | 4 (111, 113, 116, 121*) | 1 multi (114), 1 réussit seul (115), 1 fragile |
| 11 Quantique (121–132) | 12 | 0 | 11 | 1 (121) | — |

**Constat : sur 76 niveaux non refaits, 3 sont bons tels quels (51, 74, 75 — installés en R73 avec solution, noyau et
encre serrée). 73 sont à reconcevoir.** La grande majorité se gagne avec un trait de 8 à 35 unités.

## 3. Ce que cela impose

Au rythme d'une fiche construite à la main (une à deux par série, avec des échecs), 73 niveaux prendraient des dizaines de
séries. Il faut changer d'échelle **sans revenir aux niveaux sans histoire de la forge**.

**Proposition : une bibliothèque de gabarits scénarisés.** Les fiches réussies montrent que les bons niveaux reposent sur
quelques **situations dramatiques** robustes (la particule roule sur le trait, sans rebond chaotique) :

| Gabarit | Histoire | Prouvé par |
|---|---|---|
| Pont | un vide fatal à franchir | 37, 47 |
| Saut | trop large pour un pont : il faut un tremplin | 39, 45 |
| Demi‑tour | la zone est derrière : un lacet | 40 |
| Boucliers | une suite de virages gardés par des pointes | 44 |
| Rattrapage | trop vite : la rattraper en vol plus bas | 38 |
| Rampe au sommet | la zone est perchée : une rampe | 48 |
| Rampe dans le champ | amener la particule DANS la force qui l'aide | 49 |
| Pont contre le champ | une force contraire : donner assez de pente | 50 |

Chaque monde **réécrit ces situations avec sa mécanique** (le champ fait partie de l'obstacle ou de la solution) :
- *Mécanique* (parois mobiles) : le pont doit être posé là où la paroi ne passe pas ; le saut doit être pris au bon moment.
- *Gravité* : rampe dans une zone de gravité inversée (elle « tombe » vers le haut) ; pont contre une gravité latérale.
- *Magnétisme* : l'aimant détourne de la zone (champ‑obstacle) ; ou il est le seul à pouvoir la tirer au‑dessus d'un vide.
- *Faille* (portails) : le pont mène au portail d'entrée ; la sortie la projette — il faut un rattrapage.
- *Filaments* (corde, corps mou) : la corde remplace le pont (elle plie : il faut la tendre plus haut).
- *Quantique* : deux versions de la particule, une seule zone ; le détecteur au bon endroit.

Chaque gabarit devient une **fiche paramétrée commune** ; `fiche.js` décline les variantes et vérifie tout (y compris « échoue
sans la mécanique »). Je n'écris plus la géométrie de chaque niveau à la main : j'écris l'histoire, je choisis le gabarit et la
mécanique, l'outil fait le reste, et je regarde chaque niveau avant de l'installer.

**Estimation honnête** : la mise au point d'un gabarit par mécanique prend une à deux séries ; ensuite, plusieurs niveaux par
série deviennent possibles. Le risque : des niveaux d'un même gabarit qui se ressemblent — on varie la mise en scène (sens,
hauteurs, enchaînements de deux gabarits en fin de monde).
