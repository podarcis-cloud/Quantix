# QUANTIX — rapport de contournement

*Mesuré avec `tools/bypass.js` sur les 132 niveaux, build R29 — mise à jour du
rapport initial qui ne couvrait que les mondes 2 à 5. `tools/bypass.js` était
alors la seule mesure disponible ; `tools/solver.js`, `tools/deep.js`,
`tools/strict.js`, `tools/qprobe.js` et `tools/savetest.js` étaient cassés
(restes de l'ancien build en fichier unique, référençant `testq.js`,
`test6.js` ou `quantix-RNN.html`, inexistants depuis le passage au site
statique). Les cinq ont été migrés vers le harnais commun `tools/load.js` et
revérifiés par exécution réelle, pas seulement `node --check`.*

## Méthode

Inchangée : un niveau est **scénarisé** si sa mécanique signature est
indispensable. Le détecteur la désactive, puis relance la recherche de
solution avec les mêmes tracés candidats. S'il reste résolvable sans elle,
elle est décorative.

## Résultat — les 132 niveaux, pas seulement les mondes 2 à 5

**97 niveaux sur 112 testés restent contournables, contre 106 avant cette session — le monde 2 est passé à 0/10.** Les 20 niveaux
restants (essentiellement le monde 1) n'ont pas de mécanique signature à
tester par construction — ce n'est pas un trou de mesure.

| Monde | Testés | Contournables |
|---|---|---|
| 02 Fonderie — rebond | 10 | 9 |
| 03 Chaîne — élan | 11 | 10 |
| 04 Glacier — glace | 12 | 11 |
| 05 Soufflerie — vent | 11 | 10 |
| 06 Mécanique — barres mobiles | 12 | 11 |
| 07 Gravité — champs | 12 | 12 |
| 08 Magnétisme — aimants | 12 | 12 |
| 09 Faille — portails | 12 | 12 |
| 10 Filaments — corde, corps mou | 8 | 6 |
| 11 Quantique — superposition, intrication, dilatation | 12 | 12 |

**Même les niveaux quantiques sont décoratifs.** Les 12 niveaux du monde 11
— superposition, intrication, effondrement par mesure, dilatation temporelle,
jusqu'à la synthèse finale « Quantix » qui cumule cinq mécaniques — se
résolvent tous sans leur mécanique signature. C'est la partie la plus grave
du problème : le cœur conceptuel du jeu (« de la physique classique aux
phénomènes quantiques ») n'est prouvé nécessaire à aucun niveau.

Six niveaux résistent au test dans un sens ou l'autre (non prouvés, pas
validés) : **#24 La fonte, #36 La ligne, #41 Glace interdite, #57 La rafale,
#72 Le régulateur, #114 Molle et mince.**

## Un cran plus grave, découvert avec `tools/deep.js` (réparé)

`deep.js` fait une recherche plus large, avec choix de matière, sur les
niveaux que `solver.js` ne prouve pas résolubles. Résultat sur les 16 niveaux
ciblés : **15 se résolvent avec de la matière structure pure (0), sans
toucher à leur mécanique ni à une matière spéciale** — y compris les six
« non prouvés » ci-dessus (#24, #36, #41, #57, #114) et des niveaux déjà
listés comme contournables (#15, #26, #27, #32, #34, #38, #42, #44, #105,
#111). Un simple toboggan de structure suffit.

**Seul #72 Le régulateur (monde 6) résiste** — non résolu après 708 tracés
candidats. C'est, à ce stade de la mesure, le seul niveau du jeu dont on n'a
pas trouvé de solution qui contourne sa mécanique.

## Ce que ça veut dire

Le diagnostic du rapport initial était juste mais sous-évalué : ce n'est pas
« beaucoup de niveaux sont contournables », c'est **la quasi-totalité du
jeu**. Un joueur qui ignore systématiquement rebond, élan, glace, vent,
barres mobiles, gravité, aimants, portails, corde, corps mou et tout
l'appareil quantique, et qui trace juste une pente vers la zone, gagne dans
19 cas sur 20.

## Monde 2 (Fonderie) — rescénarisé et vérifié

Les 10 niveaux à mécanique du monde 2 (#13, 14, 16, 17, 19, 20, 21, 22, 23,
24) ne sont plus contournables — `bypass.js 2` donne 0/10. Méthode
appliquée : un couloir étroit de non-tracé (`nd`) autour du point de départ,
fermé sur toute la largeur jusqu'à la hauteur de la plaque de rebond ; le vol
balistique de la particule après rebond n'est jamais gêné par `nd` (qui ne
bloque que le tracé du joueur), donc la mécanique reste la seule voie.

**Chacun des 10 a été reconfirmé solvable par simulation directe**, pas
seulement par `solver.js` : sa recherche de candidats, plus simple que la
correction ne l'exige parfois (ex. #14, #20 demandaient un tracé à trois
segments avec un angle précis), ne retrouve plus que 3 niveaux sur 12 pour
ce monde. C'est attendu, documenté handbook §4 (« un niveau non prouvé n'est
pas forcément injouable ») — mais ça veut dire que **la baisse du chiffre
« PROUVÉS SOLVABLES » de solver.js (117 → 110) n'est pas une régression**,
c'est la recherche heuristique qui perd en couverture à mesure que les
niveaux perdent leurs raccourcis. Prochaine amélioration utile de l'outil :
enrichir `candidates()` de `solver.js` avec des tracés à couloir étroit,
dans l'esprit de ce qui a été utilisé ici à la main.

## Le remède — inchangé, mais l'échelle a changé

1. **Fermer les échappatoires par la géométrie** (murs permanents, `nd`).
2. **Faire de la mécanique le seul apport d'énergie ou de direction.**
3. **Resserrer le budget de matière** — la fonte de `deep.js` montre qu'un
   budget large autorise presque toujours le toboggan de structure pure.
4. **Relancer `bypass.js` puis `solver.js` après chaque lot corrigé.**
5. **Prendre #72 Le régulateur comme référence** de ce à quoi ressemble un
   niveau qui résiste déjà — étudier pourquoi avant de rescénariser les
   autres.

## Cible

Zéro niveau contournable sur les 132, `solver.js` à 132/132.

## Reste à mesurer

Rien en couverture : les 132 niveaux sont désormais couverts par `bypass.js`
et par `solver.js`. La prochaine mesure utile est le **suivi de régression**
après chaque lot de rescénarisation — pas une extension du périmètre.
