# QUANTIX — Démarrage d'une session : les erreurs à ne pas refaire

*Écrit le 22 oct. 2026 après analyse des deux premières sessions sous les nouvelles instructions (R262–R263). À lire avec
`ETAT.md`, une seule fois au démarrage. Court exprès.*

## 1. Avant la première action

1. **Pas de zip joint → une seule phrase** : « Joins `QUANTIX-SITE.zip` (dernière carte de la conversation précédente). »
   Ne rien chercher d'autre (session du 22 oct. 02:28 : arrêt correct, mais à faire en une phrase, sans Glob).
2. **Décompresser dans le dossier de travail**, pas dans le bloc‑notes :
   `mkdir -p /home/claude/site && unzip -q -o <zip> -d /home/claude/site`.
   L'outil Projet (`project_write` avec `local_path`) **refuse les fichiers hors de `/home/claude`** : la session R263 a
   perdu trois appels à cause de ça.
3. **Lire `docs/ETAT.md` du zip, une fois.** Ne pas relire `ETAT.md` dans le Projet ensuite (doublon), et **ne jamais
   ouvrir `JOURNAL.md` en entier** (126 Ko) : pour y ajouter une ligne, `echo "- **Rnnn** …" >> docs/JOURNAL.md`, puis
   `project_write` avec `local_path`.

## 2. Un défaut vu par Simon sur iPhone (régression, « ça ne marche plus »)

- **D'abord demander le parcours exact**, avant tout calcul : quel niveau, comment il y est arrivé (Suivant, Constellation,
  rechargement), appareil, et ce qu'il voit (figé, absent, saccadé). Une question coûte moins qu'un test.
- **Reproduire le même parcours**, pas un raccourci : la session R263 a chargé les niveaux directement (`loadLevel`) alors
  que le défaut survient peut‑être en passant au niveau suivant → test vert, défaut non trouvé, crédits dépensés.
- **Le monde 8 (WebGL) est très lent sans carte graphique** : un seul essai court, jamais de boucle d'attente
  (`sleep`, `until … do sleep`), jamais deux lancements du même test. Si un test dépasse 2 min : arrêter et dire à Simon.
- Outils déjà prêts : `tools/visibles.py` (avec `DPR=1`), `tools/probe_ferro.py` (mouvement du fond Magnétisme, R263).

## 3. Ce que la session R263 a établi (ne pas refaire)

- Fond Magnétisme (`ferro4`, `visuals.js`) : **animé** aux niveaux 85 et 86 chargés directement, sous Chromium sans GPU ;
  rien dans `ferro4` ne dépend du numéro de niveau.
- Restent à tester : passage par « Suivant » ou la Constellation, durée > 40 s, iPhone ; piste : aucune gestion de la
  perte du contexte WebGL (`webglcontextlost`).

## 4. Règles de coût vérifiées par l'expérience

- Un message à Simon avant tout calcul de plus de 2 min, avec le choix « je lance / tu me donnes d'abord X ».
- Pas de modèle Opus pour ce projet sauf demande de Simon : Sonnet suffit.
- Une conversation qui devient longue coûte plus cher à chaque action : au bout d'un lot livré, proposer à Simon de
  repartir dans une conversation neuve avec le dernier zip.
- Le dernier zip est toujours une **carte de fichier** dans la conversation précédente : le rappeler à Simon en fin de
  lot (« pour la suite, joins le zip `QUANTIX-SITE.zip` de cette conversation »).
