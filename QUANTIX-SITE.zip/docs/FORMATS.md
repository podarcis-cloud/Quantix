# FORMATS — Quantone / Morceau (R331)

| Format | Rôle | Contenu | Ouvre dans |
|---|---|---|---|
| `.qx` | **Format unique d'une boucle** | JSON `{q:'quantix-qx', preset, samples[]}` : dessin, réglages, boîte à rythme (réglages par voix), automations, samples (PCM 16 bits base64) | Quantone, Morceau (bloc), bande son du jeu (via rendu) |
| `.qxp` | **Morceau** (timeline) | JSON `{q:'quantone-morceau', bpm, tracks[], clips[], master, blocks[]}` ; blocs `.qx` embarqués, audio importé embarqué (fichier d'origine en base64) | Morceau |
| `.wav` | Export audio | Quantone : 2 boucles (dans un .zip pour la visionneuse) ; Morceau : rendu stéréo 44,1 kHz 16 bits | partout |
| `.json` | Préréglage seul (ancien format, sans samples) | `preset` | Quantone (lecture conservée) |
| mp3 / wav / m4a… | Import | Morceau : piste audio ; Quantone : sample de la boîte à rythme / sampler | — |
| localStorage `quantone.mine` | Préréglages gardés | liste de presets | Quantone, Morceau (« Mes préréglages ») |
| localStorage `quantone.motifs` | Motifs de boîte à rythme perso (`{n,len,rows[14][16],px?}`) | menu Motif › « Mes motifs » | Quantone |
| localStorage `qx.handoff` / `qx.open` | Passerelle : Quantone → Morceau (nouveau bloc) / Morceau → Quantone (édition) | un `.qx` en JSON, effacé après lecture | — |
| IndexedDB `morceau` | Reprise automatique du dernier morceau | même structure que `.qxp` (audio en binaire) | Morceau |

Règle : **un seul fichier à manipuler, le `.qx`**. Un bloc de la timeline EST un `.qx` (rendu une fois, boucle de `loopLen` secondes, mise en boucle sans couture). Pour modifier un bloc : « Éditer ▸ Quantone », puis « Morceau ▸ » renvoie la nouvelle version comme nouveau bloc.
