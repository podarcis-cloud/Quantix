# Trois modes de difficulté + enjeu (spécification, 25 oct. 2026 — rien n'est codé)

Objectif posé par Simon : **juger et régler la difficulté**, amener du challenge, un type de réflexion nouveau à chaque niveau, corriger obstacles et composition. Pas de rendre les solutions faciles à trouver.
Appuis : `CALIBRAGE_ENCRE.md` (3 profils d'encre validés), `DIFFICULTY_PROTOCOL.md` (P_hasard par position), `AUDIT_CONCEPTION.md` (obstacles inutiles, doublons), `BIBLE_ENIGMES.md` (eurêka ≠ fiero ; l'échec doit être lisible et attribuable au joueur).

## 1. Principe
Les niveaux restent écrits UNE fois (= mode **Standard**). Les autres modes sont des **transformations automatiques et validées** appliquées au chargement : `applyMode(niveau, mode)`. Aucun niveau n'est dupliqué, aucune solution n'est réécrite. Choix dans Paramètres, modifiable à tout moment, jamais payant.

## 2. Les leviers (déjà existants dans le jeu)
| Levier | Effet sur la difficulté | Réglé par |
|---|---|---|
| Encre | quantité de gestes possibles ; « défi d'encre » = l'économie fait partie du puzzle | profil k, c (CALIBRAGE_ENCRE) |
| Bassin (largeur de la coupe) | précision exigée | `cup[2]` |
| Zones interdites (`nd`) | ferme des familles de solutions | `hardtune.js` (ND=1) |
| Noyau (étoile) | objectif secondaire | position / visibilité |
| Indice (`tip`) et « Voir la solution optimale » | aide à la compréhension | affichage conditionnel |
| Matières autorisées (`pal`) | moyens | retrait d'une matière de confort |

## 3. Proposition de modes (noms provisoires)
| | **Découverte** | **Standard** (actuel) | **Défi** |
|---|---|---|---|
| Idée | comprendre sans pression | le jeu tel que conçu | maîtriser, optimiser |
| Encre | profil découverte (k 2,0 ; c 40) | profil standard (k 1,6 ; c 20) | profil défi (k 1,2 ; c 10) |
| Bassin | ×1,25 (plafonné) | ×1 | ×0,85 (plancher : P_ligne ≥ 85 %) |
| Zones interdites | inchangées | inchangées | + zone de « raccourci » si P_hasard > cible (hardtune) |
| Indice | toujours visible | après 3 échecs | masqué (consultable, compté) |
| Solution optimale | disponible dès 3 échecs | disponible après 6 échecs | seulement après réussite (pour comparer) |
| Noyau | repère discret | repère actuel | pas de repère : à deviner |
| Récompense | progression | progression + étoiles | « médaille » du niveau (réussi sans solution, encre ≤ réf ×1,2) |
Niveaux sans référence (16) : encre ×1,25 / ×1 / ×0,85 de la valeur actuelle, en attendant leur référence.

## 4. Garde-fous (obligatoires avant de livrer un mode)
1. **Solvabilité** : pour les 132 niveaux × 3 modes, la solution de référence réussit encore (test moteur automatique).
2. **P_hasard** par position et par mode : Découverte ≤ 2× la cible du protocole, Défi ≤ cible (sinon zone ajoutée).
3. **P_ligne ≥ 85 %** en Défi (la difficulté vient de comprendre, pas de la précision du doigt — règle C3).
4. Progression unique : les étoiles/déblocages ne dépendent pas du mode ; seule la **médaille** est par mode (3 pastilles par niveau).
5. Jamais de minuteur, de paiement ni de publicité après échec. Changement de mode sans perte de progression.

## 5. Composition des niveaux (règles issues de l'audit)
1. **Une idée nouvelle par niveau** : chaque niveau déclare la contrainte que le joueur doit relâcher (BIBLE II.1). Taxonomie de travail : *rebond / pente / lancer plus haut qu'on ne croit / passer par l'opposé / ordre des traits / économie d'encre / mécanique externe (vent, aimant, portail…) / lecture d'un état (quantique)*.
2. **Tout élément se justifie** : indispensable à la référence OU filtre de raccourci OU repère scénario assumé. Les 187 obstacles « jamais approchés » sont retirés ou justifiés.
3. **Pas de doublon** : signature ≥ 0,85 avec un niveau antérieur = à redessiner (6 paires aujourd'hui).
4. **Une seule mécanique nouvelle à la fois** ; les mondes 10 et 11 (10-11 mécaniques) à rééquilibrer.
5. **Une référence par niveau** (16 manquantes) et solution *trouvable* ≠ solution la plus économe : garder les deux si elles diffèrent.

## 6. Enjeu et « vies » — réflexion (la règle « jamais de vies » reste en vigueur)
Constat : sans coût à l'échec, le joueur de Quantix « essaie n'importe quoi » (40 % des essais après échec rejouent les mêmes traits retouchés). Il faut un enjeu **qui ne punit pas** et qui reste choisi par le joueur.
Options, de la plus douce à la plus dure :
- **A · Série** : compteur de réussites au premier essai ; aucune pénalité, juste un ruban qui se brise.
- **B · Médaille intacte** (mode Défi) : un monde terminé avec ≤ X échecs → médaille « intacte ». Rien n'est bloqué ; on peut rejouer.
- **C · Essais comptés** (Défi, option) : N essais par niveau (ex. 5 à 7) ; au-delà, le niveau est « marqué » (pas de médaille), jamais bloqué, rejouable sans limite.
- **D · Défi du jour** : un seul essai, sans enjeu persistant (cf. Quantum Drop).
- **E · Cœurs** (le plus dur) : réserve de cœurs sur un monde du mode Défi, volontaire. **Exige que Simon rouvre la règle « jamais de vies »** ; garde-fous : jamais payant, jamais de minuteur, jamais de pub, restauration gratuite à l'entrée du monde suivant, désactivable.
Recommandation : **A + B** d'abord (aucun conflit avec les règles), **C** en option du mode Défi, **E** seulement si les bêta-testeurs la réclament. À mesurer par les événements : taux de rejeu après échec, abandon, essais médians.

## 7. Chantiers pour livrer (un lot chacun)
1. Corriger l'audit : retirer/justifier les obstacles morts (mondes 9, 11 d'abord), redessiner les 6 doublons.
2. Moteur : `applyMode`, réglage dans Paramètres, sauvegarde, médailles (UI) + garde-fous automatisés.
3. Mesure sur beta : comparer P(réussite au 1ᵉʳ essai) par mode.
4. Enjeu (A + B), puis décision sur C/E.

## Questions pour Simon
1. Noms des modes (Découverte / Standard / Défi ?) et médaille par mode ou étoiles séparées ?
2. Par quoi commencer : nettoyage des obstacles (chantier 1) ou moteur des modes (chantier 2) ?
