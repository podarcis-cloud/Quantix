# QUANTIX — identité des mondes et audit mécanique

*Un monde n'est pas un changement de décor. Un joueur doit pouvoir
reconnaître le monde où il se trouve par son gameplay, pas seulement par
son illustration. Ce document fixe, pour chacun des onze mondes, son
identité voulue — et audite, dans le code réel du moteur (pas dans
l'impression laissée en jouant), ce que sa mécanique signature peut
effectivement produire. Les deux ne sont pas encore alignés partout ; ce
document sert à mesurer l'écart, monde par monde, avant la refonte.*

---

## Méthode de l'audit

Pour chaque mécanique, deux choses distinctes sont vérifiées :

1. **Ce que le code permet** — lu directement dans `assets/js/engine.js`,
   pas supposé. Une mécanique peut être puissante dans le moteur et
   pourtant inerte dans tous les niveaux qui l'utilisent, si aucun niveau
   n'exploite sa propriété distinctive.
2. **Ce que les niveaux actuels en exigent** — à vérifier niveau par
   niveau lors de la refonte (§9 de `MASTER_LEVEL_DESIGN_PROTOCOL.md`), pas
   supposé non plus. Ce document ne prétend pas avoir déjà fait cette
   seconde vérification pour tous les niveaux — seul le monde 2 et une
   partie du monde 3 l'ont été à ce jour (voir `BYPASS-RAPPORT.md`).

---

## Monde 1 — Atelier

- **Thème** : le geste fondateur — tracer un mur, rien d'autre.
- **Mécanique centrale** : aucune. C'est voulu — c'est le seul monde dont
  l'identité *est* l'absence de mécanique spéciale.
- **Identité sonore** : `WD[0]` — fondamentale 53, mode éolien, 60 bpm,
  onde sinusoïdale, la plus douce et la plus lente-à-densifier du jeu
  (`dens:.22`).
- **Émotion dominante voulue** : compétence immédiate.
- **Relation avec le monde suivant** : prépare la Fonderie en établissant
  que la seule variable, jusqu'ici, était la géométrie — le monde 2 y
  ajoute l'énergie.
- **Risque identifié** : sans mécanique, la seule source de différenciation
  entre les 12 niveaux est la géométrie pure. C'est le monde le plus
  exposé au risque de redondance — à vérifier en priorité (§7 du protocole
  maître) lors du traitement niveau par niveau.

## Monde 2 — Fonderie (rebond)

- **Thème** : l'énergie qu'on reçoit en plus de celle qu'on donne.
- **Mécanique centrale** : `BOUNCEM`, restitution `PADE=1.52` (plus de
  vitesse en sortie qu'en entrée, sur la composante normale à la surface).
- **Audit code** : mécanique confirmée puissante et fiable — un rebond
  franc restitue nettement plus d'énergie verticale qu'il n'en reçoit.
  Contrainte découverte pendant la correction (`BYPASS-RAPPORT.md`) :
  aucun levier ne permet de doser la vitesse par la surface elle-même —
  seule la position de la plaque et de la zone d'arrivée règle le
  résultat.
- **État** : rescénarisé et vérifié, 0/10 contournable (voir
  `BYPASS-RAPPORT.md`). Premier monde à avoir traversé la méthode
  complète — sert de référence de calibrage pour les suivants.

## Monde 3 — Chaîne (élan)

- **Thème** : l'élan qui s'accumule et se transmet, un geste qui en
  déclenche un autre.
- **Mécanique centrale** : `BOOSTM`, accélération `BOOSTF=.62` par
  sous-pas de contact tant que la vitesse le long de la surface reste sous
  `7.2`.
- **Audit code** : découverte importante pendant la mesure — la vitesse de
  sortie sature en une vingtaine d'unités de contact et reste quasi
  constante (~7,2 à 7,8) quelle que soit la longueur du tapis. La
  mécanique n'est donc pas un curseur (« plus long = plus vite », ce que
  suggérait le texte d'aide d'origine), c'est un **interrupteur** : on
  touche, on part à vitesse quasi fixe. La conception doit placer les
  zones d'arrivée sur la trajectoire balistique réelle qui en résulte, pas
  sur une estimation visuelle. Détail complet et méthode de calcul dans
  `docs/REPRISE.md` et l'historique de cette session.
- **État** : en cours de refonte niveau par niveau (#25 traité et vérifié ;
  #26 en cours au moment de la rédaction de ce document).

## Monde 4 — Glacier (glace)

- **Thème** : la vitesse qu'on ne peut plus reprendre une fois lancée.
- **Mécanique centrale** : `ICEM`, `matPhys` renvoie `[e=.12, f=1]` contre
  `[e=.34, f=.995]` pour une surface ordinaire.
- **Audit code** : l'écart de restitution (`.12` contre `.34`) est réel
  mais modeste. L'écart de frottement tangentiel est en revanche **très
  important et largement invisible en l'état** : `f=1` sur glace signifie
  une conservation *parfaite* de la vitesse tangentielle à chaque contact,
  contre `f=.995` sur une surface ordinaire — un facteur qui semble proche
  de 1 mais qui, appliqué à 300 sous-pas par seconde au repos sur la
  surface, fait perdre à une surface ordinaire environ 78 % de sa vitesse
  tangentielle en une seconde de contact soutenu, contre **une perte
  nulle sur glace**. C'est une différence mécanique majeure — glisser sur
  la glace ne ralentit jamais, glisser sur autre chose ralentit très vite.
- **Diagnostic préliminaire** : si les niveaux du monde 4 se résolvent
  aujourd'hui sans jamais faire reposer la solution sur un glissement
  *soutenu* (plusieurs dizaines d'unités de contact continu), cette
  propriété reste invisible malgré son ampleur réelle dans le moteur. À
  vérifier niveau par niveau — c'est une conjecture fondée sur le code,
  pas encore une mesure comme pour le monde 3.
- **Piste de conception** : un niveau qui *exige* un long glissement sans
  perte de vitesse — impossible à reproduire avec de la structure
  ordinaire, quelle que soit la pente dessinée — serait la première preuve
  mécanique que la glace est indispensable, au même sens que
  `bypass.js` le prouve pour le rebond et l'élan.

## Monde 5 — Soufflerie (vent)

- **Thème** : une force constante, invisible, qui ne dépend pas du contact.
- **Mécanique centrale** : `wind`, force constante `(fx,fy)` appliquée à
  chaque sous-pas tant que la particule est dans la zone — indépendante de
  toute collision.
- **Audit code** : c'est la seule mécanique de champ qui agit **en vol**,
  sans nécessiter un contact avec une surface — donc, en principe, la
  seule capable de courber une trajectoire de manière continue plutôt que
  ponctuelle (à la différence du rebond ou de l'élan, qui n'agissent qu'au
  contact). C'est un levier de conception distinct des mondes 2 et 3, pas
  encore exploité comme tel à ce jour.

## Monde 6 — Mécanique (barres mobiles)

- **Thème** : le timing plutôt que la trajectoire.
- **Mécanique centrale** : `mov`, segments oscillants (`amp`, `spd`,
  direction `ax,ay`).
- **Audit code** : seule mécanique du jeu dont la géométrie **change dans
  le temps** — la seule, donc, où la solution peut dépendre du moment où
  le joueur lâche la balle, pas seulement de l'endroit où il trace. Aucun
  autre monde ne peut produire ce type de décision. Non encore vérifié si
  les niveaux actuels exploitent réellement cette fenêtre temporelle ou
  si une barre à l'arrêt suffirait tout autant.

## Monde 7 — Gravité (champs)

- **Thème** : la direction du bas elle-même remise en question.
- **Mécanique centrale** : `grav`, zone où `g` est remplacé et une
  poussée horizontale `z[4]` est ajoutée.
- **Audit code** : la gravité locale peut être **inversée, latéralisée, ou
  simplement amplifiée/réduite** — un potentiel de conception nettement
  plus large que « la balle tombe plus vite ici ». Le signalement du
  demandeur (« la gravité pourrait apporter une vraie contrainte si elle
  était bien exploitée ») est cohérent avec ce que le code permet : rien
  dans le moteur ne limite la gravité locale à une simple variation
  d'intensité verticale — la sous-exploitation, si elle est confirmée
  niveau par niveau, est un choix de conception passé, pas une limite du
  moteur.

## Monde 8 — Magnétisme (attracteurs)

- **Thème** : une force qui grandit à mesure qu'on s'approche.
- **Mécanique centrale** : `mag`, attraction en `1/d` bornée par un rayon,
  nulle sous 7 unités de distance (évite la singularité).
- **Audit code** : contrairement au vent (force constante) et à la
  gravité locale (force fixe dans une zone), l'aimant produit une force
  **qui varie continûment avec la position** — le seul champ du jeu dont
  l'effet dépend de la trajectoire exacte plutôt que d'un simple passage
  en zone. Potentiel de conception pour des trajectoires courbes fines,
  non confirmé niveau par niveau à ce jour.

## Monde 9 — Faille (portails)

- **Thème** : la discontinuité maîtrisée.
- **Mécanique centrale** : `port`, téléportation au contact (rayon 16),
  cooldown de 14 ticks.
- **Audit code** : élément important — **la vitesse (direction et
  magnitude) est intégralement conservée à travers un portail**, seule la
  position change. C'est cohérent avec l'intuition du demandeur
  (« conservation ou modification de vitesse » comme axe d'exploration) et
  ouvre des possibilités déjà partiellement con nues : chaîne de portails,
  sortie orientée différemment de l'entrée pour rediriger une trajectoire
  sans rien lui faire perdre en énergie. C'est, avec le monde 11, la
  mécanique dont le potentiel narratif est le plus net et le moins
  discutable dans le code lui-même.

## Monde 10 — Filaments (corde, corps mou)

- **Thème** : la déformation comme solution, pas comme contrainte.
- **Mécanique centrale** : `ROPE` (corde tracée par le joueur, solveur QP)
  et `softball` (la particule elle-même devient un corps mou, rayon de
  repos `12.5`).
- **Audit code — anomalie confirmée** : le niveau #114 « Molle et mince »
  exige un passage de 22 unités pour un corps mou dont le diamètre de
  repos est 25 — impossible à franchir par la compression élastique
  disponible dans le solveur (constantes de liaison `.9/.45/.30`,
  contrainte d'aire `.8`). Reproduit et confirmé par simulation directe
  (voir l'historique de cette session). **Ce monde ne peut pas être traité
  par la seule méthode géométrique (`nd`)** : la taille même de la
  particule molle est une variable de conception à ce jour figée en dur
  dans `qpBuild()`, jamais exposée au niveau. Piste de refonte : faire du
  rayon du corps mou (ou de la forme éditée dans l'atelier de particule,
  aujourd'hui inerte hors Zen Lab — voir §9) une variable *par niveau*,
  ce qui transformerait « Filaments » du monde le plus anecdotique en
  celui où la personnalisation de la balle devient une vraie mécanique.

## Monde 11 — Quantique (superposition, intrication, mesure, dilatation)

- **Thème** : plusieurs possibles à la fois, jusqu'à ce qu'on regarde.
- **Mécanique centrale** : `sup` (dédoublement de branche), `det`
  (effondrement par mesure), `ent` (intrication de paires, portes liées),
  `tdil` (dilatation temporelle locale).
- **Audit mesuré (pas seulement code)** : c'est le résultat le plus grave
  de l'audit R29 — les 12 niveaux de ce monde, y compris la synthèse finale
  « Quantix » qui cumule cinq mécaniques, se résolvent tous **sans leur
  mécanique signature** (`bypass.js`, monde 11 : 12/12 contournables).
  C'est le monde qui donne son nom au jeu, et c'est celui dont l'identité
  ludique est aujourd'hui la plus vide du jeu. Priorité de conception
  déjà actée dans `BYPASS-RAPPORT.md` — à traiter avec un soin
  particulier au principe du protocole maître §4 (enseigner sans texte,
  une idée à la fois) puisque c'est ici que se joue la promesse centrale
  du jeu.

---

## Synthèse — ce qui est confirmé contre ce qui reste à vérifier

| Monde | Impact mécanique confirmé par le code | Statut de vérification par niveau |
|---|---|---|
| 1 Atelier | Sans objet (pas de mécanique) | — |
| 2 Fonderie | Fort, fiable | ✅ vérifié, 0/10 contournable |
| 3 Chaîne | Fort mais mal compris jusqu'ici (interrupteur, pas curseur) | 🔶 en cours |
| 4 Glacier | Potentiellement fort (frottement quasi nul), non exploité en l'état probable | ⬜ non vérifié |
| 5 Soufflerie | Distinct (seule force en vol continu) | ⬜ non vérifié |
| 6 Mécanique | Distinct (seule variable temporelle) | ⬜ non vérifié |
| 7 Gravité | Fort potentiel, sous-exploitation probable | ⬜ non vérifié |
| 8 Magnétisme | Distinct (seul champ à gradient continu) | ⬜ non vérifié |
| 9 Faille | Fort, vitesse conservée — potentiel net | ⬜ non vérifié |
| 10 Filaments | Anomalie confirmée (#114 cassé), variable de taille figée | 🔴 niveau cassé confirmé |
| 11 Quantique | Fort sur le papier, **nul en pratique mesurée** | 🔴 12/12 contournable, mesuré |

*« Confirmé par le code » décrit ce que le moteur permet, pas ce que les
niveaux actuels en font. Seuls les mondes 2, 3, 10 et 11 ont fait l'objet
d'une vérification allant au-delà de la lecture de code à ce jour — les
sept autres restent des hypothèses de conception fondées sur le
comportement du moteur, à confirmer ou infirmer niveau par niveau selon la
méthode du protocole maître.*
