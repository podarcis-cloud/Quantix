# QUANTIX — Protocole de scénarisation des niveaux (R61)

*Retour de Simon après avoir joué le Glacier (R60) : « les niveaux sont beaucoup trop simples ; je n'utilise que 10 % de la
matière ; le défi de chaque niveau n'est pas identifié ; il faut scénariser les parcours : le tracé évoque une histoire, avec
une difficulté identifiée à surmonter. »*

## 1. Diagnostic mesuré

Outil : `node tools/tighten.js N…` avec `DRY=1` — cherche le **plus petit trait gagnant** parmi 4 000 lignes au hasard.

| Constat | Mesure |
|---|---|
| Niveaux du Glacier forgés | 37 et 38 se gagnent avec un trait de **10 unités** (un petit bout de butée) |
| Mondes 1 à 3 | 16 niveaux se gagnent avec moins de 25 u : 1, 2, 5, 7, 13, 14, 15, 16, 17, 19, 25, 26, 27, 28, 32, 33 |
| Fins de monde « à deux traits » | 22, 35 et 36 se gagnent aussi d'un seul trait |

**Pourquoi les outils ne l'ont pas vu** : `P_hasard` tire des lignes de longueur quelconque ; un petit trait précis, que
la ligne droite et la loupe rendent facile, est rare au hasard mais évident pour un joueur. Et la forge invente des
géométries sans histoire : elle garantit des chiffres, pas un défi.

## 2. La nouvelle méthode : le scénario d'abord

Un niveau commence par une **fiche scénario**, écrite avant toute géométrie :

| Rubrique | Contenu |
|---|---|
| Histoire | une phrase : ce qui arrive à la particule si l'on ne fait rien |
| Obstacle | la difficulté à surmonter, nommée (un gouffre, une vitesse, un mur, un piège) |
| Geste | ce que le joueur doit construire — **une vraie construction**, pas une retouche |
| Leurre | la solution qui semble évidente et qui échoue |
| Chute | le moment où le joueur comprend |
| Énergie | 1,2 à 1,3 × le coût de la solution la moins chère : l'énergie devient une contrainte |

La géométrie est ensuite dessinée **pour servir la fiche**, puis vérifiée. La forge ne sert plus qu'à vérifier et régler.

**Critères (tous obligatoires)**
1. **Coût minimal** : aucun trait plus court que le seuil ne réussit — positions 1–3 : 40 u, 4–8 : 80 u, 9–12 : 120 u
   (ou deux traits). Intégré à `forge.js` (rejet « trivial »).
2. **Énergie serrée** : encre = 1,2 à 1,3 × la solution la moins chère (`tighten.js`).
3. **Leurre** : la solution évidente doit échouer — vérifiée par une simulation dédiée.
4. `P_hasard` et `P_ligne` comme avant (annexe R51).
5. **Chaque élément du décor joue un rôle dans l'histoire** — sinon il est retiré.
6. Le test de Simon : défi identifié en moins de 10 s de regard ?

## 3. Fiches scénario du Glacier (monde 4 — « la vitesse qu'on ne peut plus reprendre »)

| # | Titre | Histoire | Obstacle | Geste attendu | Leurre |
|---|---|---|---|---|---|
| 37 | Le lac | La particule glisse sur un lac gelé jusqu'au bord, puis tombe dans le vide | un trou au milieu du lac | **un pont** au‑dessus du trou | une butée : elle arrête, mais avant la zone |
| 38 | Trop vite | Elle file sur la glace et survole la zone | sa vitesse | **un long plan qui la freine en montant** (rampe ascendante) | un mur : elle rebondit et repart |
| 39 | Le saut | La glace s'arrête au bord d'une crevasse large | la crevasse | **un tremplin** au bout de la glace | un pont trop court (énergie juste insuffisante) |
| 40 | Le retour de glace | La pente la renvoie toujours du mauvais côté | le sens de la pente | **un demi‑tour** : courbe en U | un mur droit : elle rebondit dans le vide |
| 41 | Le toboggan | Une longue descente de glace en zigzag | elle prend trop de vitesse à chaque virage | **ralentir** par des montées intermédiaires | couper le zigzag : elle sort du terrain |
| 42 | La butée haute | La zone est au sommet d'une rampe de glace | elle redescend toujours | **une butée au sommet** au bon moment de la montée | la butée en bas |
| 43 | Deux étages | Un étage de glace au‑dessus d'un autre | la chute la projette trop loin | **une goulotte** qui guide la chute vers l'étage du bas | un trait sous elle : elle repart |
| 44 | La patinoire | Une surface de glace avec des pointes en îlots | slalom sans frein | **deux déflecteurs** | un seul long mur |
| 45 | Le passage gardé | Une zone interdite garde le chemin direct | on ne peut pas tracer où il faudrait | **dévier en amont**, avant la zone | tracer au bord de la zone |
| 46 | Le pendule | Glace en creux : elle oscille sans fin | elle ne s'arrête jamais | **une marche** pour la sortir du creux au bon côté | une butée au fond |
| 47 | La crevasse double | Deux crevasses à la suite | l'énergie ne suffit pas pour deux ponts | **un tremplin qui saute les deux** (deux traits) | deux ponts |
| 48 | Le sérac | Final : tout le monde | vitesse + crevasse + zone haute | **tremplin + rampe de freinage** (deux traits coordonnés) | un seul long trait |

## 4. Suite

1. Construire les fiches 37 à 48 une par une (géométrie dessinée à la main pour la fiche), vérifier par les critères §2.
2. Repasser les 16 niveaux triviaux des mondes 1 à 3 avec une fiche scénario chacun.
3. Simon teste le défi : identifiable en moins de 10 s ?


## 5. Outils (R64)

- **`tools/fiche.js N`** construit un niveau à partir de sa fiche `tools/fiches/N.js` : géométrie paramétrée (`gen`), **boîtes
  du geste** (`boxes` : où et comment se construit chaque trait voulu — l'outil cherche la meilleure réalisation), leurre,
  grille de variantes. Il vérifie tous les critères (§2) et écrit la variante retenue dans `forge.json` (clé `N_fiche`).
  Options : `V=1` détail par variante, `SHOW=1` montre la réalisation trouvée, `NS=` nombre d'essais.
- **`/tmp/fview.py N 'P' [solution]`** (à copier dans `tools/` si besoin) dessine la fiche avec la trajectoire sans trait (rouge)
  et avec la solution (jaune) : indispensable pour régler une fiche à l'œil.
- Leçon de la fiche 44 : une solution « trop fragile » vient presque toujours d'un **manque de marge** dans le décor (îlot trop
  près du bout de la descente, chute qui frôle le bord de l'étage suivant) — on élargit le décor, pas la tolérance.

## 6. État du Glacier

| # | Niveau | Fait |
|---|---|---|
| 37 | Le lac | fiche, R61 |
| 44 | La patinoire | fiche, R64 — slalom à deux boucliers (P_hasard à un trait 0 %, P_ligne 100 %) |
| 48 | Le sérac | fiche, R63 |
| 38, 39, 42, 43, 45 | forgés (R59) | **à refaire par fiche** (le 38 se gagne avec 10 u) |
| 47 | La crevasse double | fiche, R65 — deux ponts ; pointes au fond des crevasses et zones interdites dessous (rattraper la chute est impossible) ; P_hasard à un trait 0 %, P_ligne 97 % |
| 39 | Le saut | fiche, R66 — crevasse trop large pour un pont (l'énergie ne suffit pas), il faut un tremplin ; P_hasard 0,08 %, P_ligne 90 %, encre 111 |
| 38 | Trop vite | fiche, R67 — un tremplin de glace la lance trop loin ; le haut du vol est en zone interdite, il faut la rattraper plus bas avec un plan incliné qui la renvoie vers la zone ; P_hasard 0,16 %, **P_ligne 80 %** (sous la cible de 85 % : accepté parce que Déplacer permet d'ajuster après un essai ; à surveiller en test joueur), encre 118 |
| 40 | Le demi‑tour | fiche, R68 — la pente l'emporte vers une paroi de pointes, la zone est derrière : un long lacet la ramène ; P_hasard 0,04 %, P_ligne 100 %, encre 355 |
| 45 | Le passage gardé | fiche, R68 — une zone interdite garde le vide central : un tremplin avant pour la faire sauter par‑dessus ; P_hasard 0,04 %, P_ligne 87 %, encre 74 |
| 41, 42, 43, 46 | à refaire | 46 : nouvelle histoire « La cuvette » (voir leçon R68) |

**Leçons de la fiche 47** : (1) un obstacle n'en est un que si l'échec est **fatal** — une crevasse sans pointes au fond laissait
la particule retomber sur l'étage du dessous et continuer ; (2) toute façon de **contourner le geste voulu** doit être fermée par
le décor (ici : zone interdite sous chaque crevasse, plafond de pointes bas) ; (3) une fente plus étroite que la particule la
coince (paroi trop proche du bout du lac).

**Leçons des fiches 38–39 (R66)** : (1) un **leurre trop cher** pour l'énergie disponible ne peut pas être tracé — `fiche.js` le compte
désormais comme un échec du leurre, ce qui permet les niveaux « le pont ne suffit pas, il faut sauter » ; (2) **38 « Trop vite »
non abouti** : un virage brusque (descente puis montée, plus de ~70°) fait perdre presque toute la vitesse au choc — une rampe
droite ne peut pas convertir la vitesse en hauteur. Il faudra soit une rampe courbe (trait libre), soit une autre histoire.

**Leçons de la fiche 38 (R67)** : (1) tout virage de plus de ~30° entre deux surfaces fait perdre la vitesse au choc : les tremplins
doivent prolonger la pente en douceur ; (2) **tension robustesse / trivialité** — élargir le bassin rend la solution tolérante mais
ouvre des solutions de 10 à 30 u ; la zone interdite sur la partie haute du vol force le geste à se faire là où il demande une vraie
construction.

**Leçon de la fiche 46 « Le pendule » (R68, non aboutie)** : un creux de glace en V tue la vitesse au fond (angle trop vif) ;
arrondi en parabole (segments de 17 u), il devient un vrai pendule — mais chaque jointure de segment coûte un peu d'énergie :
la particule ne remonte plus qu'aux deux tiers du bord. Elle ne peut donc **jamais** sortir du creux par le haut, et une
passerelle posée hors du creux est inaccessible (le bord du creux est entre les deux). L'histoire « sortir du pendule » est
incompatible avec la physique du jeu sans source d'énergie (plaque de rebond, tapis). Pistes : (a) donner au pendule une plaque
de rebond au fond (hors palette du Glacier) ; (b) changer d'histoire — « la cuvette » : la zone est dans le creux, mais un îlot de
pointes en garde le fond et il faut la faire s'arrêter sur le flanc.


## 7. Extension au monde 5 — Soufflerie (R69)

**Mesures sur les 12 niveaux actuels** (`tighten.js`, `DRY=1`, puis test « sans vent ») :
- plus petit trait gagnant : 49 → 117 u, 50 → **35 u**, 51 → 78 u, 52 → 140 u, 53 → 189 u, 54 → **14 u**, 55 → 82 u, 56 → 106 u,
  57 → 155 u, 58 → **17 u**, 59 → 67 u, 60 → 223 u ;
- **constat principal** : pour 51, 53, 57 et 60, la solution la moins chère **réussit aussi sans le vent**. Le vent est un décor,
  pas une mécanique. Le monde 5 est donc entièrement à reconcevoir, fiche par fiche.

**Règle propre au vent** : une solution n'est valide que si elle **échoue quand on retire le vent** (test à ajouter à `fiche.js`
pour les mondes à champ : vent, gravité, aimant).

**Fiches scénario (thème : une force invisible qui agit en vol, sans contact)**

| # | Titre | Histoire | Geste attendu | Leurre |
|---|---|---|---|---|
| 49 | Le souffle | une colonne d'air montant soulève la particule au‑dessus d'un mur ; il faut l'y amener | une rampe qui la dépose DANS la colonne | la lancer par‑dessus le mur (trop haut) |
| 50 | Vent de travers | un vent latéral la dévie de la zone pendant sa chute | un mur‑écran qui la protège du vent sur la fin | un mur sous elle |
| 51 | Vent descendant | une rafale vers le bas l'écrase avant la zone | un toit qui coupe la rafale au bon endroit | un pont (le vent l'en décolle pas, elle s'y écrase) |
| 52 | La cheminée | colonne étroite : elle monte, mais ressort du mauvais côté | un déflecteur en sortie de cheminée | rampe à l'entrée |
| 53 | Deux colonnes | deux colonnes : la première la monte, la seconde la porte | une passerelle entre les deux | une seule colonne |
| 54 | Le plafond | sous un plafond de pointes, la colonne la plaque en haut | couper la colonne avec un toit protecteur | descendre la zone |
| 55 | La lame d'air | un vent latéral fort la pousse vers des pointes | l'amener à traverser la lame vite (tremplin) | traverser lentement |
| 56 | Contre‑courant | la zone est en amont du vent | un abri qui la laisse remonter le courant | lui faire face |
| 57 | La rafale | la colonne la projette trop haut, vers des pointes | un plafond protecteur | réduire l'entrée |
| 58 | Le tunnel | un vent descendant puis un montant | deux ponts (deux traits) | un seul trait |
| 59 | La tempête | colonnes contraires | rebond + vent (deux traits) | — |
| 60 | La veine | le vent est la seule voie : elle traverse le niveau portée par l'air | trois appuis (fin de monde) | — |

## 8. Glacier — 41 « Le virage » (R69, non abouti)

Un seul bouclier à poser est **toujours court** (10 à 80 u) : le niveau reste trivial même avec un îlot plus grand et une zone
interdite près de l'îlot. Le virage seul n'est pas un défi : il ne prend son sens qu'enchaîné (« La patinoire », 44). Le 41 doit
porter une autre idée.


## 9. Soufflerie — premières fiches (R70)

- `fiche.js` vérifie désormais que la solution **échoue sans le vent** (et sans gravité locale, sans aimant pour les mondes 7–8).
- **49 « Le souffle »** fait : un mur trop haut ; devant lui une colonne d'air qui monte en poussant légèrement vers la droite ;
  la pente emporte la particule de l'autre côté ; il faut une rampe qui la ramène au pied de la colonne. Sans vent : échoue.
  P_hasard 0,24 %, P_ligne 100 %, encre 232. Note : la particule sort brièvement par le haut de l'écran pendant sa montée.
- Leçons : (1) une colonne d'air purement verticale soulève sans faire avancer — sans composante latérale, la particule retombe
  du même côté et tourne en boucle ; (2) encore une fente plus étroite que la particule (plateforme trop près de la paroi).

- **50 « Vent de face »** (R71, nouvelle histoire) : un vent contraire au‑dessus d'une fosse ; un pont en pente douce suffirait
  sans vent mais cale avec ; il faut un pont assez pentu. P_hasard 0,16 %, P_ligne 100 %, encre 265.
- **Champ‑obstacle** dans `fiche.js` (`obstacle:true`) : quand le champ gêne au lieu d'aider (vent contraire, comme la glace), on
  exige que le **leurre réussisse sans le champ et échoue avec** — c'est la preuve que le champ change le problème.
- Abandonné pour 50 : « tremplin dans un vent de travers » — le rebond contre une paroi puis sur le trait est chaotique
  (P_ligne ≤ 0,4 quelles que soient les marges).

- **51 « Vent descendant » (R72, non abouti)** : « sauter une crevasse sous un vent qui rabat ». Dix‑sept variantes : soit la
  solution est trop fragile (P_ligne 0,43 à 0,83 — le saut sous vent est très sensible à l'angle du tremplin), soit un trait de
  9 à 39 u suffit. Famille « saut + vent » abandonnée. Piste : utiliser le vent descendant comme **aide** (il plaque la particule
  sur une rampe de glace et l'empêche de décoller au‑dessus d'un trou), pas comme obstacle au saut.
- `fiche.js` : `leurreBoxes` — l'outil **cherche lui‑même un leurre** (un geste du même type qui réussit sans le champ et échoue
  avec), au lieu d'un leurre écrit à la main.
- **52 « La cheminée » (R72, non abouti)** : dans un conduit d'air étroit, la particule monte, dépasse le haut du conduit,
  retombe, et cogne les parois : le mouvement devient **chaotique** (trajectoires différentes à chaque rebond), si bien que tantôt
  elle tombe seule dans la zone, tantôt un trait de 26 à 39 u suffit. Leçon : éviter les colonnes d'air **entre deux parois** ; une
  colonne libre (sans parois, comme au 49) donne un mouvement prévisible.
