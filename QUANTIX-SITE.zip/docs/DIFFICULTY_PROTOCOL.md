# QUANTIX — protocole de difficulté et de faisabilité au doigt

*Né d'un retour de test sur téléphone : « la marge d'erreur à main levée est
franchement trop faible, et certains niveaux ne permettent pas de solution
alternative à la solution parfaite ». Ce protocole remplace la tolérance
±4 u utilisée jusqu'ici (monde1.js, monde2.js, optimal.js), qui supposait une
précision de 0,6 mm : aucun doigt n'en est capable.*

Outil : `tools/difficulty.js` (vrai moteur). `OUT=difficulty.json node difficulty.js 1 2 3 …`

---

## 1. Échelle : combien mesure une unité de jeu ?

Le terrain fait 360 × 480 u et occupe ~360 pt de large sur un téléphone :
**1 u ≈ 1 pt ≈ 0,16 mm**. Toute tolérance doit être raisonnée en millimètres
de doigt, pas en unités.

## 2. Modèle du joueur — deux erreurs distinctes

Fondement : le modèle « à double distribution gaussienne » du toucher au doigt
(Bi, Li & Zhai, *FFitts law*, CHI 2013) — l'erreur de pointage est la somme
d'une imprécision **absolue** propre au doigt (indépendante de l'effort) et
d'une imprécision **relative** liée à la vitesse du geste. Valeurs retenues
ci-dessous : calibrage de départ, **à confirmer par des tests réels** (voir §6).

| | Exécution (le joueur sait quoi tracer) | Intention (il vise « à peu près ») |
|---|---|---|
| Décalage global du trait | σ = 6 u (≈ 1 mm) | σ = 18 u (≈ 3 mm) |
| Extrémités | σ = 9 u (≈ 1,5 mm, précision absolue du doigt) | σ = 12 u |
| Rotation | σ = 4° | σ = 10° |
| Longueur | ×(1 ± 10 %) | ×(1 ± 20 %) |
| Ondulation (main levée) | 1–3 u | 1–3 u |

Le tracé bruité respecte les règles du moteur : points refusés dans les zones
interdites, trait tronqué quand l'encre manque.

## 3. Les quatre mesures

1. **P_exec** — réussite en reproduisant la solution optimale connue, avec
   l'erreur d'exécution. *Question : une fois compris, le niveau est-il juste ?*
2. **P_int** — réussite avec l'erreur d'intention, sur la meilleure famille de
   solutions (ou la solution optimale). *Question : le niveau pardonne-t-il
   un geste approximatif ?*
3. **P_noyau** — part des exécutions qui prennent le noyau.
4. **Familles** — groupes distincts de solutions (milieux à ≥ 45 u ou angles à
   ≥ 25° d'écart, ≥ 3 membres). *Question : existe-t-il des alternatives à la
   solution parfaite ?* (Niveaux à plusieurs traits : non mesurable au
   balayage à un trait — noté « — ».)

**Échantillons** : 60 essais par mesure pour un verdict (marge ≈ ±12 % à
95 %) ; 24–30 pour un tri rapide (marge ≈ ±18 %).

## 4. Cibles (courbe de difficulté d'un monde de 12 niveaux)

| Position | P_exec | P_int | P_noyau | Familles |
|---|---|---|---|---|
| 1–2 (introduction) | ≥ 70 % | ≥ 60 % | ≥ 35 % | ≥ 2 |
| 3–5 (variations) | ≥ 70 % | ≥ 50 % | ≥ 35 % | ≥ 3 |
| 6–8 (combinaisons) | ≥ 70 % | ≥ 40 % | ≥ 25 % | ≥ 3 |
| 9–10 (complication) | ≥ 70 % | ≥ 35 % | ≥ 25 % | ≥ 3 |
| 11 (renversement) | ≥ 70 % | ≥ 30 % | ≥ 25 % | ≥ 3 |
| 12 (synthèse) | ≥ 70 % | ≥ 25 % | ≥ 25 % | ≥ 2 |

**P_exec ≥ 70 % partout** : la difficulté doit venir de *comprendre*, jamais
de *réussir à tracer* (protocole maître §2). Seul P_int monte avec la
progression.

## 5. Résultats sur les mondes 1 et 2 refondus (tri rapide, N = 24–30)

| 1 | Le premier trait | 1 | ❌ 37 % | ❌ 27 % (cible 60) | ❌ 3 % | ✅ 8 |
| 2 | Le pont | 2 | ❌ 53 % | ❌ 30 % (cible 60) | ❌ 33 % | ✅ 16 |
| 3 | Le demi-tour | 3 | ❌ 50 % | ❌ 33 % (cible 50) | ✅ 43 % | ✅ 26 |
| 4 | Le relais | 4 | ✅ 90 % | ❌ 27 % (cible 50) | ✅ 53 % | — 0 |
| 5 | La douceur | 5 | ❌ 67 % | ✅ 63 % (cible 50) | ✅ 57 % | ✅ 34 |
| 6 | Le fil | 6 | ❌ 7 % | ❌ 13 % (cible 40) | ❌ 7 % | — 0 |
| 7 | Économie | 7 | ❌ 43 % | ✅ 46 % (cible 40) | ✅ 30 % | ✅ 12 |
| 8 | La portée | 8 | ❌ 53 % | ❌ 30 % (cible 40) | ❌ 23 % | ❌ 2 |
| 9 | Le leurre | 9 | ❌ 57 % | ✅ 46 % (cible 35) | ❌ 20 % | ✅ 6 |
| 10 | Le col | 10 | ❌ 53 % | ❌ 30 % (cible 35) | ❌ 20 % | ❌ 2 |
| 11 | Le plafond | 11 | ❌ 13 % | ❌ 0 % (cible 30) | ❌ 0 % | — 0 |
| 12 | L’établi | 12 | ❌ 3 % | ❌ 0 % (cible 25) | ❌ 0 % | — 0 |
| 13 | Le trampoline | 1 | ❌ 13 % | ❌ 17 % (cible 60) | ❌ 10 % | ✅ 36 |
| 14 | Le ricochet | 2 | ❌ 7 % | ❌ 7 % (cible 60) | ❌ 0 % | ✅ 2 |
| 15 | La montée | 3 | ❌ 0 % | ❌ 0 % (cible 50) | ❌ 0 % | — 0 |
| 16 | La hauteur juste | 4 | ❌ 63 % | ❌ 38 % (cible 50) | ✅ 63 % | ✅ 10 |
| 17 | Sol brûlant | 5 | ❌ 33 % | ❌ 17 % (cible 50) | ❌ 30 % | ✅ 15 |
| 18 | Ta plaque | 6 | ❌ 17 % | ❌ 3 % (cible 40) | ❌ 3 % | — 0 |
| 19 | Le four | 7 | ❌ 17 % | ❌ 13 % (cible 40) | ❌ 0 % | ✅ 8 |
| 20 | Garder la hauteur | 8 | ❌ 13 % | ❌ 4 % (cible 40) | ❌ 13 % | ✅ 15 |
| 21 | Le leurre ardent | 9 | ❌ 67 % | ✅ 50 % (cible 35) | ✅ 43 % | ✅ 42 |
| 22 | Rebond serré | 10 | ❌ 0 % | ❌ 7 % (cible 35) | ❌ 0 % | ✅ 4 |
| 23 | Descendre pour monter | 11 | ❌ 17 % | ❌ 21 % (cible 30) | ❌ 13 % | ✅ 37 |
| 24 | La fonte | 12 | ❌ 3 % | ❌ 0 % (cible 25) | ❌ 3 % | — 0 |

**Verdict : 0 niveau(x) sur 24 atteignent à la fois P_exec et P_int.**
Le retour de test est confirmé par la mesure : une fois la solution connue,
la plupart des niveaux ne se réussissent au doigt qu'une fois sur trois à une
fois sur dix ; plusieurs sont pratiquement injouables (0–7 %).

### Ce que la mesure a exclu

**Une aide « tracé redressé » ne résout rien.** Supprimer l'ondulation de la
main levée (tracé redressé en segment exact) ne change pas les taux au-delà
de la marge statistique (ex. #1 : 30 % → 23 %, #23 : 28 % → 35 %). Le
problème n'est pas le tremblement : c'est **l'étroitesse du couloir de
positions gagnantes**. Il se corrige dans la géométrie des niveaux, pas dans
le moteur.

## 6. Méthode de correction (à appliquer niveau par niveau)

1. Mesurer (`difficulty.js`) → repérer ce qui échoue : P_exec, P_int, familles.
2. Élargir le couloir gagnant **sans toucher à l'idée** : bassin plus large
   ou plus proche de la trajectoire naturelle, obstacle déplacé de quelques
   dizaines d'unités, pente fixe qui guide davantage, noyau rapproché de la
   trajectoire de la famille principale, encre plus généreuse (≥ 2 × la
   solution + 40 u).
3. Re-vérifier que la mécanique reste indispensable (`lab.js`, 0 gagnant
   sans elle) — élargir peut ouvrir un contournement.
4. Remesurer avec N = 60 jusqu'à atteindre les cibles §4.
5. **Mettre à jour la solution optimale** : choisir désormais la solution
   qui maximise **P_exec** (et non plus la tolérance ±4 u), puis `optsol`.
6. **Test réel** : noter sur téléphone, pour 3–4 niveaux, le nombre d'essais
   avant réussite — il doit rester proche de 1 / P_int. Si les joueurs
   réussissent nettement mieux ou moins bien, recalibrer les σ du §2.

## 7. Sources

- Bi X., Li Y., Zhai S. (2013). *FFitts law: modeling finger touch with
  Fitts' law.* CHI '13, 1363–1372. DOI 10.1145/2470654.2466180 — modèle à
  double distribution (précision absolue + relative) du toucher au doigt.
- Bi X., Zhai S. (2013). *Bayesian touch: a statistical criterion of target
  selection with finger touch.* UIST '13.
- Valeurs σ du §2 : calibrage initial raisonné à partir de ce modèle et de
  l'échelle §1 — **non mesurées sur des joueurs de Quantix**, à valider §6.6.


---

## 8. Correction R34 — mesures après correction (dans le jeu tel qu'écrit)

Outil : `tools/retune.js` (déplace/élargit le bassin, encre ×1–2,6, allonge les
plaques ; l'idée, le décor et les zones interdites ne changent pas). Règle
d'application : une géométrie n'est écrite que si **P_exec gagne ≥ 10 points**
et si les contraintes tiennent (monde 2 : 0 solution sans plaque ; relais et
synthèse : un trait seul ne gagne pas). Noyaux replacés **sur la trajectoire
exacte** de la solution optimale (`tools/fixstar.js`), pris par ~50 % des
exécutions au doigt quand c'est possible.

| # | Niveau | P_exec avant → après | P_int avant → après | P_noyau | Familles |
|---|---|---|---|---|---|
| 1 | Le premier trait | 37 → **77 %** ✅ | 27 → 47 % (cible 60) ❌ | 43 % | 26 |
| 2 | Le pont | 53 → **70 %** ✅ | 30 → 53 % (cible 60) ❌ | 67 % | 21 |
| 3 | Le demi-tour | 50 → **53 %** ❌ | 33 → 38 % (cible 50) ❌ | 47 % | 33 |
| 4 | Le relais | 90 → **90 %** ✅ | 27 → 27 % (cible 50) ❌ | 53 % | 0 |
| 5 | La douceur | 67 → **87 %** ✅ | 63 → 67 % (cible 50) ✅ | 57 % | 43 |
| 6 | Le fil | 7 → **70 %** ✅ | 13 → 37 % (cible 40) ❌ | 60 % | 7 |
| 7 | Économie | 43 → **73 %** ✅ | 46 → 54 % (cible 40) ✅ | 53 % | 20 |
| 8 | La portée | 53 → **40 %** ❌ | 30 → 46 % (cible 40) ✅ | 40 % | 6 |
| 9 | Le leurre | 57 → **73 %** ✅ | 46 → 54 % (cible 35) ✅ | 40 % | 8 |
| 10 | Le col | 53 → **53 %** ❌ | 30 → 30 % (cible 35) ❌ | 20 % | 2 |
| 11 | Le plafond | 13 → **43 %** ❌ | 0 → 23 % (cible 30) ❌ | 30 % | 1 |
| 12 | L’établi | 3 → **3 %** ❌ | 0 → 0 % (cible 25) ❌ | 0 % | 0 |
| 13 | Le trampoline | 13 → **70 %** ✅ | 17 → 67 % (cible 60) ✅ | 33 % | 121 |
| 14 | Le ricochet | 7 → **77 %** ✅ | 7 → 50 % (cible 60) ❌ | 50 % | 7 |
| 15 | La montée | 0 → **20 %** ❌ | 0 → 13 % (cible 50) ❌ | 20 % | 2 |
| 16 | La hauteur juste | 63 → **63 %** ❌ | 38 → 38 % (cible 50) ❌ | 63 % | 10 |
| 17 | Sol brûlant | 33 → **33 %** ❌ | 17 → 17 % (cible 50) ❌ | 30 % | 15 |
| 18 | Ta plaque | 17 → **17 %** ❌ | 3 → 3 % (cible 40) ❌ | 3 % | 0 |
| 20 | Garder la hauteur | 13 → **40 %** ❌ | 4 → 30 % (cible 40) ❌ | 37 % | 51 |
| 21 | Le leurre ardent | 67 → **67 %** ❌ | 50 → 50 % (cible 35) ✅ | 43 % | 42 |
| 22 | Rebond serré | 0 → **52 %** ❌ | 7 → 32 % (cible 35) ❌ | 25 % | 28 |
| 23 | Descendre pour monter | 17 → **53 %** ❌ | 21 → 60 % (cible 30) ✅ | 28 % | 63 |
| 24 | La fonte | 3 → **33 %** ❌ | 0 → 12 % (cible 25) ❌ | 20 % | 5 |

**Bilan** : P_exec ≥ 70 % sur **9/23** niveaux (0/23 avant) ; les deux
cibles atteintes sur **4/23**. #19 Le four (ancien niveau) non mesuré.

**Restent à reconcevoir** (la géométrie seule ne suffit pas) : L'établi (#12,
trois traits enchaînés), La montée (#15), Ta plaque (#18), Sol brûlant (#17),
La hauteur juste (#16), Le four (#19). Piste : **géométrie convergente**
(entonnoir fixe qui ramène les gestes approximatifs sur la même trajectoire),
plutôt qu'une précision exigée.

**Noyaux trop faciles** (≥ 90 % des exécutions) : Le pont, La portée,
La montée, Le demi-tour, Économie — aucun point de leur trajectoire exacte
n'est pris par 40–80 % des gestes. À revoir avec la géométrie de ces niveaux.

**Marge de mesure** : 30 essais par mesure (≈ ±18 %) ; les écarts entre la
recherche (60 essais) et la remesure viennent de ce bruit (ex. La portée
65 % → 40 %). Un verdict ferme demande 60 essais.
