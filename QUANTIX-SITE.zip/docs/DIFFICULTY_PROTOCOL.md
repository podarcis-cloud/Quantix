# QUANTIX — protocole de difficulté et de faisabilité au doigt

*Né d'un retour de test sur téléphone : « la marge d'erreur à main levée est
franchement trop faible, et certains niveaux ne permettent pas de solution
alternative à la solution parfaite ». Ce protocole remplace la tolérance
±4 u utilisée jusqu'ici (monde1.js, monde2.js, optimal.js), qui supposait une
précision de 0,6 mm : aucun doigt n'en est capable.*

Outil : `tools/difficulty.js` (vrai moteur). `OUT=difficulty.json node difficulty.js 1 2 3 …`

---

## 1. Échelle : combien mesure une unité de jeu ?

Le terrain fait 360 × 480 u et occupe ~360 pt de large sur un téléphone :
**1 u ≈ 1 pt ≈ 0,16 mm**. Toute tolérance doit être raisonnée en millimètres
de doigt, pas en unités.

## 2. Modèle du joueur — deux erreurs distinctes

Fondement : le modèle « à double distribution gaussienne » du toucher au doigt
(Bi, Li & Zhai, *FFitts law*, CHI 2013) — l'erreur de pointage est la somme
d'une imprécision **absolue** propre au doigt (indépendante de l'effort) et
d'une imprécision **relative** liée à la vitesse du geste. Valeurs retenues
ci-dessous : calibrage de départ, **à confirmer par des tests réels** (voir §6).

| | Exécution (le joueur sait quoi tracer) | Intention (il vise « à peu près ») |
|---|---|---|
| Décalage global du trait | σ = 6 u (≈ 1 mm) | σ = 18 u (≈ 3 mm) |
| Extrémités | σ = 9 u (≈ 1,5 mm, précision absolue du doigt) | σ = 12 u |
| Rotation | σ = 4° | σ = 10° |
| Longueur | ×(1 ± 10 %) | ×(1 ± 20 %) |
| Ondulation (main levée) | 1–3 u | 1–3 u |

Le tracé bruité respecte les règles du moteur : points refusés dans les zones
interdites, trait tronqué quand l'encre manque.

## 3. Les quatre mesures

1. **P_exec** — réussite en reproduisant la solution optimale connue, avec
   l'erreur d'exécution. *Question : une fois compris, le niveau est-il juste ?*
2. **P_int** — réussite avec l'erreur d'intention, sur la meilleure famille de
   solutions (ou la solution optimale). *Question : le niveau pardonne-t-il
   un geste approximatif ?*
3. **P_noyau** — part des exécutions qui prennent le noyau.
4. **Familles** — groupes distincts de solutions (milieux à ≥ 45 u ou angles à
   ≥ 25° d'écart, ≥ 3 membres). *Question : existe-t-il des alternatives à la
   solution parfaite ?* (Niveaux à plusieurs traits : non mesurable au
   balayage à un trait — noté « — ».)

**Échantillons** : 60 essais par mesure pour un verdict (marge ≈ ±12 % à
95 %) ; 24–30 pour un tri rapide (marge ≈ ±18 %).

## 4. Cibles (courbe de difficulté d'un monde de 12 niveaux)

| Position | P_exec | P_int | P_noyau | Familles |
|---|---|---|---|---|
| 1–2 (introduction) | ≥ 70 % | ≥ 60 % | ≥ 35 % | ≥ 2 |
| 3–5 (variations) | ≥ 70 % | ≥ 50 % | ≥ 35 % | ≥ 3 |
| 6–8 (combinaisons) | ≥ 70 % | ≥ 40 % | ≥ 25 % | ≥ 3 |
| 9–10 (complication) | ≥ 70 % | ≥ 35 % | ≥ 25 % | ≥ 3 |
| 11 (renversement) | ≥ 70 % | ≥ 30 % | ≥ 25 % | ≥ 3 |
| 12 (synthèse) | ≥ 70 % | ≥ 25 % | ≥ 25 % | ≥ 2 |

**P_exec ≥ 70 % partout** : la difficulté doit venir de *comprendre*, jamais
de *réussir à tracer* (protocole maître §2). Seul P_int monte avec la
progression.

## 5. Résultats sur les mondes 1 et 2 refondus (tri rapide, N = 24–30)

| 1 | Le premier trait | 1 | ❌ 37 % | ❌ 27 % (cible 60) | ❌ 3 % | ✅ 8 |
| 2 | Le pont | 2 | ❌ 53 % | ❌ 30 % (cible 60) | ❌ 33 % | ✅ 16 |
| 3 | Le demi-tour | 3 | ❌ 50 % | ❌ 33 % (cible 50) | ✅ 43 % | ✅ 26 |
| 4 | Le relais | 4 | ✅ 90 % | ❌ 27 % (cible 50) | ✅ 53 % | — 0 |
| 5 | La douceur | 5 | ❌ 67 % | ✅ 63 % (cible 50) | ✅ 57 % | ✅ 34 |
| 6 | Le fil | 6 | ❌ 7 % | ❌ 13 % (cible 40) | ❌ 7 % | — 0 |
| 7 | Économie | 7 | ❌ 43 % | ✅ 46 % (cible 40) | ✅ 30 % | ✅ 12 |
| 8 | La portée | 8 | ❌ 53 % | ❌ 30 % (cible 40) | ❌ 23 % | ❌ 2 |
| 9 | Le leurre | 9 | ❌ 57 % | ✅ 46 % (cible 35) | ❌ 20 % | ✅ 6 |
| 10 | Le col | 10 | ❌ 53 % | ❌ 30 % (cible 35) | ❌ 20 % | ❌ 2 |
| 11 | Le plafond | 11 | ❌ 13 % | ❌ 0 % (cible 30) | ❌ 0 % | — 0 |
| 12 | L’établi | 12 | ❌ 3 % | ❌ 0 % (cible 25) | ❌ 0 % | — 0 |
| 13 | Le trampoline | 1 | ❌ 13 % | ❌ 17 % (cible 60) | ❌ 10 % | ✅ 36 |
| 14 | Le ricochet | 2 | ❌ 7 % | ❌ 7 % (cible 60) | ❌ 0 % | ✅ 2 |
| 15 | La montée | 3 | ❌ 0 % | ❌ 0 % (cible 50) | ❌ 0 % | — 0 |
| 16 | La hauteur juste | 4 | ❌ 63 % | ❌ 38 % (cible 50) | ✅ 63 % | ✅ 10 |
| 17 | Sol brûlant | 5 | ❌ 33 % | ❌ 17 % (cible 50) | ❌ 30 % | ✅ 15 |
| 18 | Ta plaque | 6 | ❌ 17 % | ❌ 3 % (cible 40) | ❌ 3 % | — 0 |
| 19 | Le four | 7 | ❌ 17 % | ❌ 13 % (cible 40) | ❌ 0 % | ✅ 8 |
| 20 | Garder la hauteur | 8 | ❌ 13 % | ❌ 4 % (cible 40) | ❌ 13 % | ✅ 15 |
| 21 | Le leurre ardent | 9 | ❌ 67 % | ✅ 50 % (cible 35) | ✅ 43 % | ✅ 42 |
| 22 | Rebond serré | 10 | ❌ 0 % | ❌ 7 % (cible 35) | ❌ 0 % | ✅ 4 |
| 23 | Descendre pour monter | 11 | ❌ 17 % | ❌ 21 % (cible 30) | ❌ 13 % | ✅ 37 |
| 24 | La fonte | 12 | ❌ 3 % | ❌ 0 % (cible 25) | ❌ 3 % | — 0 |

**Verdict : 0 niveau(x) sur 24 atteignent à la fois P_exec et P_int.**
Le retour de test est confirmé par la mesure : une fois la solution connue,
la plupart des niveaux ne se réussissent au doigt qu'une fois sur trois à une
fois sur dix ; plusieurs sont pratiquement injouables (0–7 %).

### Ce que la mesure a exclu

**Une aide « tracé redressé » ne résout rien.** Supprimer l'ondulation de la
main levée (tracé redressé en segment exact) ne change pas les taux au-delà
de la marge statistique (ex. #1 : 30 % → 23 %, #23 : 28 % → 35 %). Le
problème n'est pas le tremblement : c'est **l'étroitesse du couloir de
positions gagnantes**. Il se corrige dans la géométrie des niveaux, pas dans
le moteur.

## 6. Méthode de correction (à appliquer niveau par niveau)

1. Mesurer (`difficulty.js`) → repérer ce qui échoue : P_exec, P_int, familles.
2. Élargir le couloir gagnant **sans toucher à l'idée** : bassin plus large
   ou plus proche de la trajectoire naturelle, obstacle déplacé de quelques
   dizaines d'unités, pente fixe qui guide davantage, noyau rapproché de la
   trajectoire de la famille principale, encre plus généreuse (≥ 2 × la
   solution + 40 u).
3. Re-vérifier que la mécanique reste indispensable (`lab.js`, 0 gagnant
   sans elle) — élargir peut ouvrir un contournement.
4. Remesurer avec N = 60 jusqu'à atteindre les cibles §4.
5. **Mettre à jour la solution optimale** : choisir désormais la solution
   qui maximise **P_exec** (et non plus la tolérance ±4 u), puis `optsol`.
6. **Test réel** : noter sur téléphone, pour 3–4 niveaux, le nombre d'essais
   avant réussite — il doit rester proche de 1 / P_int. Si les joueurs
   réussissent nettement mieux ou moins bien, recalibrer les σ du §2.

## 7. Sources

- Bi X., Li Y., Zhai S. (2013). *FFitts law: modeling finger touch with
  Fitts' law.* CHI '13, 1363–1372. DOI 10.1145/2470654.2466180 — modèle à
  double distribution (précision absolue + relative) du toucher au doigt.
- Bi X., Zhai S. (2013). *Bayesian touch: a statistical criterion of target
  selection with finger touch.* UIST '13.
- Valeurs σ du §2 : calibrage initial raisonné à partir de ce modèle et de
  l'échelle §1 — **non mesurées sur des joueurs de Quantix**, à valider §6.6.


---

## 8. Correction R34 — mesures après correction (dans le jeu tel qu'écrit)

Outil : `tools/retune.js` (déplace/élargit le bassin, encre ×1–2,6, allonge les
plaques ; l'idée, le décor et les zones interdites ne changent pas). Règle
d'application : une géométrie n'est écrite que si **P_exec gagne ≥ 10 points**
et si les contraintes tiennent (monde 2 : 0 solution sans plaque ; relais et
synthèse : un trait seul ne gagne pas). Noyaux replacés **sur la trajectoire
exacte** de la solution optimale (`tools/fixstar.js`), pris par ~50 % des
exécutions au doigt quand c'est possible.

| # | Niveau | P_exec avant → après | P_int avant → après | P_noyau | Familles |
|---|---|---|---|---|---|
| 1 | Le premier trait | 37 → **77 %** ✅ | 27 → 47 % (cible 60) ❌ | 43 % | 26 |
| 2 | Le pont | 53 → **70 %** ✅ | 30 → 53 % (cible 60) ❌ | 67 % | 21 |
| 3 | Le demi-tour | 50 → **53 %** ❌ | 33 → 38 % (cible 50) ❌ | 47 % | 33 |
| 4 | Le relais | 90 → **90 %** ✅ | 27 → 27 % (cible 50) ❌ | 53 % | 0 |
| 5 | La douceur | 67 → **87 %** ✅ | 63 → 67 % (cible 50) ✅ | 57 % | 43 |
| 6 | Le fil | 7 → **70 %** ✅ | 13 → 37 % (cible 40) ❌ | 60 % | 7 |
| 7 | Économie | 43 → **73 %** ✅ | 46 → 54 % (cible 40) ✅ | 53 % | 20 |
| 8 | La portée | 53 → **40 %** ❌ | 30 → 46 % (cible 40) ✅ | 40 % | 6 |
| 9 | Le leurre | 57 → **73 %** ✅ | 46 → 54 % (cible 35) ✅ | 40 % | 8 |
| 10 | Le col | 53 → **53 %** ❌ | 30 → 30 % (cible 35) ❌ | 20 % | 2 |
| 11 | Le plafond | 13 → **43 %** ❌ | 0 → 23 % (cible 30) ❌ | 30 % | 1 |
| 12 | L’établi | 3 → **3 %** ❌ | 0 → 0 % (cible 25) ❌ | 0 % | 0 |
| 13 | Le trampoline | 13 → **70 %** ✅ | 17 → 67 % (cible 60) ✅ | 33 % | 121 |
| 14 | Le ricochet | 7 → **77 %** ✅ | 7 → 50 % (cible 60) ❌ | 50 % | 7 |
| 15 | La montée | 0 → **20 %** ❌ | 0 → 13 % (cible 50) ❌ | 20 % | 2 |
| 16 | La hauteur juste | 63 → **63 %** ❌ | 38 → 38 % (cible 50) ❌ | 63 % | 10 |
| 17 | Sol brûlant | 33 → **33 %** ❌ | 17 → 17 % (cible 50) ❌ | 30 % | 15 |
| 18 | Ta plaque | 17 → **17 %** ❌ | 3 → 3 % (cible 40) ❌ | 3 % | 0 |
| 20 | Garder la hauteur | 13 → **40 %** ❌ | 4 → 30 % (cible 40) ❌ | 37 % | 51 |
| 21 | Le leurre ardent | 67 → **67 %** ❌ | 50 → 50 % (cible 35) ✅ | 43 % | 42 |
| 22 | Rebond serré | 0 → **52 %** ❌ | 7 → 32 % (cible 35) ❌ | 25 % | 28 |
| 23 | Descendre pour monter | 17 → **53 %** ❌ | 21 → 60 % (cible 30) ✅ | 28 % | 63 |
| 24 | La fonte | 3 → **33 %** ❌ | 0 → 12 % (cible 25) ❌ | 20 % | 5 |

**Bilan** : P_exec ≥ 70 % sur **9/23** niveaux (0/23 avant) ; les deux
cibles atteintes sur **4/23**. #19 Le four (ancien niveau) non mesuré.

**Restent à reconcevoir** (la géométrie seule ne suffit pas) : L'établi (#12,
trois traits enchaînés), La montée (#15), Ta plaque (#18), Sol brûlant (#17),
La hauteur juste (#16), Le four (#19). Piste : **géométrie convergente**
(entonnoir fixe qui ramène les gestes approximatifs sur la même trajectoire),
plutôt qu'une précision exigée.

**Noyaux trop faciles** (≥ 90 % des exécutions) : Le pont, La portée,
La montée, Le demi-tour, Économie — aucun point de leur trajectoire exacte
n'est pris par 40–80 % des gestes. À revoir avec la géométrie de ces niveaux.

**Marge de mesure** : 30 essais par mesure (≈ ±18 %) ; les écarts entre la
recherche (60 essais) et la remesure viennent de ce bruit (ex. La portée
65 % → 40 %). Un verdict ferme demande 60 essais.

## Annexe R51 — la difficulté à l'ère de l'éditeur de lignes

**Constat (Simon, R50)** : avec la ligne droite, les niveaux sont trop faciles. La mesure le confirme : sur certains niveaux,
**une ligne droite tirée au hasard réussit une fois sur dix**. Avec Annuler et Déplacer gratuits, il suffit d'essayer.

**Ce qui change dans la méthode**
1. `P_exec` (tolérance du tracé au doigt) n'est plus le critère central : la ligne droite, l'accroche et Déplacer rendent la
   précision gratuite. On garde seulement **P_ligne ≥ 85 %** : la solution, tracée à la ligne droite avec ±3 u d'erreur par
   extrémité, doit réussir — comprendre doit suffire.
2. Nouveau critère principal : **P_hasard**, la part des lignes droites aléatoires (départ, angle, longueur, matière) qui
   résolvent le niveau. Cibles par position dans le monde :
   positions 1–2 ≤ 4 % · 3–5 ≤ 1,5 % · 6–9 ≤ 0,5 % · 10–12 ≤ 0,2 %.
3. Sous 0,2 %, un trait unique ne suffit plus à créer de la difficulté : les fins de monde doivent **demander deux traits
   qui coopèrent** (P_hasard à un trait = 0), ou un ordre d'action (tracer pendant la chute).
4. Outils : `node tools/hasard.js N…` (mesure, 1 à 4 s par niveau) ; `OUT=hard.json PT=40 node tools/hardtune.js N…`
   (resserre bassin et encre, garde 0 contournement, une solution réussie à la ligne, un noyau sur sa trajectoire) ;
   `SRC=hard.json python3 tools/w3apply.py N…` (écrit dans `levels.js`) ; puis `monde1/2/3.js`.
5. Piège corrigé : `lab.run` réécrit le niveau en mémoire ; tout script de recherche doit travailler sur une **copie figée**
   du niveau (sinon l'encre et le bassin se réduisent à chaque essai).

**Mesures R51 (3 000 lignes par niveau ; P_ligne sur 60 essais)**

| # | Niveau | Pos. | P_hasard | Cible | Conforme | P_ligne |
|---|---|---|---|---|---|---|
| 1 | Le premier trait | 1 | 2.97 % | ≤ 4.0 % | oui | 100 % |
| 2 | Le pont | 2 | 5.07 % | ≤ 4.0 % | non | 100 % |
| 3 | Le demi-tour | 3 | 7.23 % | ≤ 1.5 % | non | 87 % |
| 4 | Le relais | 4 | 0.00 % | ≤ 1.5 % | oui (multi‑traits) | 100 % |
| 5 | La douceur | 5 | 7.90 % | ≤ 1.5 % | non | 100 % |
| 6 | Le fil | 6 | 1.30 % | ≤ 0.5 % | non | 98 % |
| 7 | Économie | 7 | 1.83 % | ≤ 0.5 % | non | 98 % |
| 8 | La portée | 8 | 1.37 % | ≤ 0.5 % | non | 73 % |
| 9 | Le leurre | 9 | 10.10 % | ≤ 0.5 % | non | 100 % |
| 10 | Le col | 10 | 1.27 % | ≤ 0.2 % | non | 100 % |
| 11 | Le plafond | 11 | 0.60 % | ≤ 0.2 % | non | 72 % |
| 12 | L’établi | 12 | 0.00 % | ≤ 0.2 % | oui (multi‑traits) | 32 % |
| 13 | Le trampoline | 1 | 11.30 % | ≤ 4.0 % | non | 100 % |
| 14 | Le ricochet | 2 | 0.20 % | ≤ 4.0 % | oui | 90 % |
| 15 | La montée | 3 | 0.27 % | ≤ 1.5 % | oui | 58 % |
| 16 | La hauteur juste | 4 | 0.97 % | ≤ 1.5 % | oui | 98 % |
| 17 | Sol brûlant | 5 | 0.63 % | ≤ 1.5 % | oui | 88 % |
| 18 | Ta plaque | 6 | 0.03 % | ≤ 0.5 % | oui | 50 % |
| 19 | Le four | 7 | 0.20 % | ≤ 0.5 % | oui | — |
| 20 | Garder la hauteur | 8 | 3.43 % | ≤ 0.5 % | non | 45 % |
| 21 | Le leurre ardent | 9 | 2.47 % | ≤ 0.5 % | non | 100 % |
| 22 | Rebond serré | 10 | 3.50 % | ≤ 0.2 % | non | 93 % |
| 23 | Descendre pour monter | 11 | 6.17 % | ≤ 0.2 % | non | 28 % |
| 24 | La fonte | 12 | 0.07 % | ≤ 0.2 % | oui | 57 % |
| 25 | Le tapis | 1 | 2.10 % | ≤ 4.0 % | oui | 100 % |
| 26 | Sens inverse | 2 | 2.17 % | ≤ 4.0 % | oui | 87 % |
| 27 | Tapis et butée | 3 | 1.13 % | ≤ 1.5 % | oui | 98 % |
| 28 | Le plafond bas | 4 | 1.50 % | ≤ 1.5 % | oui | 92 % |
| 29 | Ton élan | 5 | 0.50 % | ≤ 1.5 % | oui | 100 % |
| 30 | Saut de chaîne | 6 | 0.23 % | ≤ 0.5 % | oui | 100 % |
| 31 | Tapis et lames | 7 | 0.23 % | ≤ 0.5 % | oui | 95 % |
| 32 | Deux tapis | 8 | 0.13 % | ≤ 0.5 % | oui | 92 % |
| 33 | Chaîne montante | 9 | 0.23 % | ≤ 0.5 % | oui | 100 % |
| 34 | Cadence | 10 | 0.33 % | ≤ 0.2 % | non | 100 % |
| 35 | Le triage | 11 | 2.27 % | ≤ 0.2 % | non | 100 % |
| 36 | La ligne | 12 | 0.37 % | ≤ 0.2 % | non | 100 % |

**À reprendre** : #2, #3, #5, #6, #7, #8, #9, #10, #11, #13, #20, #21, #22, #23, #34, #35, #36.
Niveaux 28, 30 et 33 resserrés en R51 par `hardtune.js`. Pour 34, 35 et 36, resserrer ne suffit pas (aucune variante
conforme) : il faut les **redessiner à deux traits**.


## Annexe R55 — état après resserrage

Resserrés en R55 (vérifiés à 3 000 puis 4 000 lignes, mondes 1 et 2 toujours 12/12 et 11/11) : 2, 3, 5, 6, 7, 8, 13.
Nouveau levier dans `hardtune.js` (`ND=1`) : une **zone interdite** posée là où se tracent la plupart des solutions faciles,
sans toucher la meilleure solution, le départ ni le bassin (utilisé au niveau 5).
Garde‑fou ajouté : une variante n'est acceptée qu'après une **remesure à 3 000 lignes** (la mesure à 1 200 était trop bruitée).

| # | Niveau | P_hasard | Cible | Conforme |
|---|---|---|---|---|
| 1 | Le premier trait | 2.97 % | ≤ 4.0 % | oui |
| 2 | Le pont | 1.73 % | ≤ 4.0 % | oui |
| 3 | Le demi-tour | 0.70 % | ≤ 1.5 % | oui |
| 4 | Le relais | 0.00 % | ≤ 1.5 % | oui |
| 5 | La douceur | 1.00 % | ≤ 1.5 % | oui |
| 6 | Le fil | 0.53 % | ≤ 0.5 % | non |
| 7 | Économie | 0.53 % | ≤ 0.5 % | non |
| 8 | La portée | 0.13 % | ≤ 0.5 % | oui |
| 9 | Le leurre | 9.97 % | ≤ 0.5 % | non |
| 10 | Le col | 1.20 % | ≤ 0.2 % | non |
| 11 | Le plafond | 0.63 % | ≤ 0.2 % | non |
| 12 | L’établi | 0.00 % | ≤ 0.2 % | oui |
| 13 | Le trampoline | 2.63 % | ≤ 4.0 % | oui |
| 14 | Le ricochet | 0.10 % | ≤ 4.0 % | oui |
| 15 | La montée | 0.30 % | ≤ 1.5 % | oui |
| 16 | La hauteur juste | 1.23 % | ≤ 1.5 % | oui |
| 17 | Sol brûlant | 0.53 % | ≤ 1.5 % | oui |
| 18 | Ta plaque | 0.03 % | ≤ 0.5 % | oui |
| 19 | Le four | 0.17 % | ≤ 0.5 % | oui |
| 20 | Garder la hauteur | 3.40 % | ≤ 0.5 % | non |
| 21 | Le leurre ardent | 3.17 % | ≤ 0.5 % | non |
| 22 | Rebond serré | 2.83 % | ≤ 0.2 % | non |
| 23 | Descendre pour monter | 6.23 % | ≤ 0.2 % | non |
| 24 | La fonte | 0.17 % | ≤ 0.2 % | oui |
| 25 | Le tapis | 1.73 % | ≤ 4.0 % | oui |
| 26 | Sens inverse | 2.23 % | ≤ 4.0 % | oui |
| 27 | Tapis et butée | 1.17 % | ≤ 1.5 % | oui |
| 28 | Le plafond bas | 1.37 % | ≤ 1.5 % | oui |
| 29 | Ton élan | 0.37 % | ≤ 1.5 % | oui |
| 30 | Saut de chaîne | 0.10 % | ≤ 0.5 % | oui |
| 31 | Tapis et lames | 0.23 % | ≤ 0.5 % | oui |
| 32 | Deux tapis | 0.07 % | ≤ 0.5 % | oui |
| 33 | Chaîne montante | 0.17 % | ≤ 0.5 % | oui |
| 34 | Cadence | 0.33 % | ≤ 0.2 % | non |
| 35 | Le triage | 1.93 % | ≤ 0.2 % | non |
| 36 | La ligne | 0.73 % | ≤ 0.2 % | non |

**Conformes : 24 / 36.** Restent : #6, #7, #9, #10, #11, #20, #21, #22, #23, #34, #35, #36 — pour eux, ni le bassin, ni l'encre, ni une zone interdite ne suffisent :
il faut les **redessiner** (fins de monde à deux traits, cf. annexe R51).


## Annexe R56 — la forge de niveaux

`tools/forge.js` génère des niveaux et ne garde que ceux qui passent **tous** les critères en une passe (échec sans trait,
P_hasard dans la cible — ou deux traits nécessaires —, mécanique indispensable : la solution échoue si la mécanique devient
structure, murs inutiles élagués, P_ligne ≥ 0,85, noyau sur la trajectoire, confirmation à 3 000 / 6 000 tirages).
Générateurs propres aux mondes 2–3 (principe d'énergie : bassin plus haut que le départ, plaque/tapis sous la balle) et au
monde 4 (glace : bassin lointain et plus bas). `tools/slotwrite.py plan.json` installe un niveau forgé (nom et conseil fr/en).
Usage : `KEYSEED=1 OUT=forge.json SECS=120 SEED=… node forge.js N [2]` — un niveau par commande, 10 s à 2 min.
**Limite** : la forge garantit la conformité, pas une idée forte ; le nom et le conseil sont écrits ensuite, à la main,
et l'avis de joueur reste nécessaire.

Installés en R56 : 9, 10, 11, 20, 21, 22, 23, 34, 35, 36 (10, 11, 22, 23, 34, 35, 36 à deux traits).
Bilan R56 (2 500 lignes, un trait) : **33 / 36 conformes** ; à revoir : #4, #11, #18.


## Annexe R59 — Glacier et réglages de la forge

- **Glace = obstacle, pas aide** : on ne peut plus freiner. Le test de contournement (mécanique ramenée à de la structure) ne
  s'applique pas ; à la place, la solution retenue doit **glisser au moins 25 images sur la glace**.
- **Plancher de difficulté** par position (`MINT`) : 1 % aux positions 1–2, 0,4 % aux 3–5, 0,1 % aux 6–9 — un début de monde
  ne doit pas être plus dur qu'une fin.
- Installés : 37 Le glissement, 38 La descente, 39 Le retour, 42 La butée, 43 Deux étages, 45 Le passage gardé
  (P_hasard 4,1 / 3,3 / 0,63 / 0,27 / 0,33 / 0,43 %). `tools/monde4.js` : 6/6.
- **Limite constatée** : le générateur de glace produit des niveaux trop semblables (étagère de glace en haut, butée à poser).
  Pour 40, 41, 44 et 46–48 il faut **varier les gabarits** (glace montante qui fait sauter, zigzag de glace, pointes au‑delà
  du bassin, deux traits) avant de forger.
