# QUANTIX — Reprise de session (R155, 11 octobre 2026)

*Une page, réécrite à chaque lot (jamais empilée). La méthode est dans `METHODE.md` ; le pourquoi dans `AUDIT_METHODE.md`.
L'ancienne reprise (11 600 mots, R38 → R121) est archivée sous `archive/REPRISE-SESSION-R121.md`.*

## Où en est le jeu (zip QUANTIX-R121)

- **Monde 1 — Atelier** : 12 niveaux jouables. Machines refaites aux courbes calculées : **3 Le colimaçon** (lacets à trois
  crochets) et **6 Les collines** (vague, décollage, dosseret). Faibles : 1 (gagné par un tout petit mur), 9, 11, 12 (finale
  sans machine).
- **Monde 2 — Fonderie** : 12 niveaux. **18 Ta plaque** a sa machine « creuset » (trémie à bras courbes, goulotte, plaque de
  relance). Vérifications bloquantes non passées : **19** (pas de solution de référence), **21** (élément dans la zone).
  Finale 24 sans machine (essai de machine au départ abandonné, voir archive).
- **Mondes 3 à 11** : niveaux anciens, non revus.
- **Didacticiel** : système de fiches en surimpression ; la consigne du niveau 1 se pose sur la barre du haut.
- **Son** : W1N corrigé (respire jusqu'au silence, pulsation dès le niveau 1) ; trop présent à partir du niveau 8 (à alléger).
- **Mesure de jouabilité** : modèle « éditeur » partout depuis R121 (`DOIGT=1` rétablit l'ancien).

## Depuis R122 (10 oct.)

- Outils de tracé toujours visibles hors introduction (R122). Éditeur republié avec les niveaux actuels (clé `QED2:`).
- **Fonderie 6 « Ta plaque »** : serpentin dessiné par Simon, mis au propre (tube lissé, bonus rebond au virage droit), départ
  décalé à x = 40 — validé par Simon (R125).
- **Fonderie 12 « La fonte »** : esquisse de Simon rendue fonctionnelle (R126) : plaque du sol → tube en arche par dessous →
  plaque de relance → second tube → bassin perché en haut à gauche, abrité par un toit. Constance 89 %, ≈ 8 s, jouabilité
  indicative 37 %. Outils : scratchpad `m/tubes.js`, `m/m24d.js`, `m/g24.js` ; `tools/fiches/machines/fonte24.json`.
- **Chaîne 6 « Saut de chaîne »** (R128) : machine de sauts — tapis + tremplins + crochets tapissés qui cueillent le vol,
  trois sauts en zigzag ; le joueur pose le DERNIER maillon : un tapis dans le bon sens remonte la particule à la zone (structure
  et tapis à l'envers ne marchent pas). Constat physique : pas de looping possible en 2D, le tapis ne soulève pas à la verticale.
  Scratchpad `m/jump.js` → `tools/fiches/machines/chaine30.json`.
- **Chaîne 12 « La chaîne complète »** (R129) : VRAI LOOPING. Le joueur trace le maillon qui monte (tapis, sens imposé) ;
  la particule boucle tête en bas et traverse sa propre piste d'entrée grâce aux **pistes traversables** (moteur : champs
  `pass` et `pz` des courbes, `engine.js` curveExpand + collide). Proposition d'intégration : `docs/PISTES_TRAVERSABLES.md`.

- **R130 — repères de la paroi tunnel (W3N12 seulement, pour validation)** : la partie traversable d'une piste est
  marquée en bleu glacé #A9BCEB (gaine lumineuse, deux brins entrelacés qui ondulent = imbrication de la matière, bornes
  aux deux bouts ; les atomes s'écartent et un anneau s'élargit quand la particule passe). Fiche de didacticiel « Paroi
  tunnel » (FR/EN, démo : bille lente portée / bille rapide qui traverse). Poussière d'étoile (`lv.flow`, `VX.flow`) qui
  dérive du départ vers l'entrée de la machine. Noyau déplacé au sommet de la boucle (il masquait le croisement).
  Code : `visuals.js` tunnel/flow, `engine.js` (dessin), `tuto.js` (carte), `i18n.js`. **À étendre aux autres machines
  seulement après accord de Simon.**
- **R131 — poussière des machines (toutes)** : `lv.flow` = trajectoire de la solution dans la machine (+ courte amorce
  vers l'entrée), calculée par `node tools/flow.js 3 6 18 24 30 36` (à relancer si une machine change). `VX.flow` : grains à
  vitesses variées, les plus rapides laissent un fil, certains décrochent dans les virages serrés et filent tout droit.
  Fiche raccourcie : « Piste poreuse — lente, roule dessus ; rapide, passe au travers ». La piste poreuse n'existe qu'en 36.
  Aperçu : mondes 1 à 3 débloqués.
- **R132 — Atelier 12 « Le portail »** (remplace « L'établi ») : un mur poreux vertical coupe le terrain. Le joueur trace une
  rampe ; trop douce, la particule bute (vx < 4,5) ; assez raide, elle traverse et entre dans la machine « aiguille » : un tube
  qui coud la membrane trois fois (droite → gauche → droite) puis la traverse une dernière fois jusqu'au bassin abrité.
  Géométrie : scratchpad `m/p12.js` → `tools/fiches/machines/portail12.json`, `forge.json` clé `12_portail`. La fiche
  « Matière poreuse » apparaît ici pour la première fois. Mur entièrement poreux : dessiné seulement en gaine bleu pâle.
  Poussière plus dense (jusqu'à 280 grains, tailles et transparences variées, quelques halos).
- **R133** — Atelier 12 affiné : membrane courbe, parois du tube qui s'effacent dans la matière poreuse (ni nœud ni capuchon
  au contact, `visuals.js` jointsBuild), abri courbe du bassin, capot courbe à droite, zones interdites resserrées.
  **Glacier 6 « La piste glacée »** (remplace « La butée ») : tube de glace avec un vrai looping (croisement poreux `pz`,
  sans nœud), sortie lancée à pleine vitesse ; le joueur pose la butée derrière le bassin. Scratchpad `m/p42.js` →
  `tools/fiches/machines/luge42.json`, forge `42_luge`.
- **R134** — **Glacier 12 « Le pendule de glace »** (remplace « Le sérac ») : vasque de glace sans frottement, la particule
  s'y balance sans fin ; au fond, une fenêtre de glace poreuse (`pass` 6, `pz`) ne laisse passer qu'une chute franche ; dessous,
  entonnoir et tube de glace jusqu'au bassin. Plusieurs familles de solutions (≈ 3 % des traits au hasard gagnent : tremplins sur
  les flancs, déflecteurs). Scratchpad `m/p48e.js`, `g48.js` (recherche rapide) → `machines/pendule48.json`, forge `48_pendule`.
  Bouton retour du niveau → carte du monde (`engine.js` gBack). Aperçu : tous les mondes et niveaux ouverts
  (`build-apercu.py 4 11 skipintro`).
- **R135** — Outils **Échelle** et **Aimant** : dans le jeu (dock : `editor.js` mode `scale`, interrupteur `mag` mémorisé
  `QX_mag` ; l'encre suit la longueur, annulation prise en charge) et dans l'éditeur de niveaux (poignée carrée sous la forme,
  bouton ⊕, `QED_mag`). Éditeur republié.
- **R136** — retour du niveau → page illustrée du monde (`openWorld`). **R137 — Atelier 12 « La cellule »** (remplace « Le
  portail ») : cellule ronde de structure (r 88) percée d'un pore poreux (`pz`, `pass` 3.2) en bas à droite, bassin-noyau à
  l'intérieur, orbite concentrique (r 130) autour. La particule tombe dans l'orbite et oscille ; le joueur barre l'orbite juste
  après le pore : elle rebondit et traverse. Aucun raccourci depuis le haut (recherche). Scratchpad `m/c12.js` →
  `machines/cellule12.json`, forge `12_cellule`. 
- **R138 — Soufflerie 6 « La cascade inversée »** (remplace « Vent et plafond ») : une colonne d'air (vent −1,3) entre deux
  parois de verre ; cinq plafonds en zigzag que la particule remonte comme l'eau descend un escalier ; en haut, une crosse la
  rejette à gauche vers le bassin. Le joueur la fait entrer par le bas (rampe sous la paroi droite). ≈ 6,5 s. Scratchpad
  `m/w54.js`, `run54c.sh` → `machines/cascade54.json`, forge `54_cascade`.
- **R139 — Soufflerie 12 « Le cyclone »** (remplace « La veine ») : tambour de structure (r 90) parcouru par un tourbillon
  (quatre champs tangents, invisibles : 7ᵉ valeur = 1) dessiné en spirale (`lv.vortex`, `VX.vortex`) ; la particule y tourne
  sans fin au‑dessus d'une fente ; le joueur glisse une lame qui l'arrache vers l'entonnoir et le bassin. Scratchpad `m/v60.js`
  → `machines/cyclone60.json`, forge `60_cyclone`. Essai d'entrée tangentielle en spirale abandonné (trajectoire chaotique).
- **R140** — Soufflerie 6 recomposée (vase de verre courbe, plafonds détachés des parois — plus de nœuds —, colonne d'air
  dessinée en filets montants `lv.updraft`/`VX.updraft`, champ de vent caché). **Mécanique 6 « L'escalier mécanique »** :
  quatre marches mobiles dorées en contretemps (`mov` avec `ph` phase, `v` vitesse transmise à la balle, `ck` bielle à
  coulisse dessinée `VX.yoke`) alternent avec des paliers fixes : la particule monte seule ; le joueur la pose sur la
  première marche. **Mécanique 12 « L'échappement »** : boîtier d'horloge en arche, balancier et ancre (`lv.pend`,
  `VX.pendulum`), palettes coulissantes (`pl`) qui libèrent un palier par battement ; le joueur jette un pont au‑dessus du
  fond mortel. Moteur : `moverSeg` (phase, vitesse) et `collide` (vitesse relative) — sans effet sur les anciens niveaux
  (options absentes). Zones nettoyées : 48 (bout du tube retiré, lèvre à droite du bassin), 60 (entonnoir raccourci).
  Scratchpad `m/s66.js`, `m/e72.js` → `machines/escalier66.json`, `echappement72.json`.
- **Leçon (Simon, 10 oct.)** : le cyclone est le modèle — un concept fort ET une esthétique singulière qui sert le jeu
  (dessin dédié de la mécanique : tourbillon, filets d'air, bielles, balancier). À systématiser. Éviter la redondance des
  cercles et des échelles de plafonds.
- **R141 — Didacticiel harmonisé** : les fiches d'éléments physiques (zone interdite, pointes, rebond, élan, poreux, glace,
  vent, gravité, aimant, portail, paroi mobile) ne sont plus chorégraphiées à la main : chaque scène est décrite en données
  (`tools/tuto-scenes-src.js`, repère 232 × 104), simulée par le vrai moteur (`node tools/tutoscenes.js` → `assets/js/
  tuto-scenes.js`, `window.TSC`) et rejouée par un lecteur unique (`tuto.js` `scene()`) : le doigt trace, la bille part, elle
  suit la trajectoire calculée, pause. Même rendu que le jeu (murs, courbes, filets d'air, poreux). Restent dessinées à la main :
  outils (gestes), puces de matière, éléments quantiques (intrication, superposition, détecteur, dilatation) et bille molle.
  Pour ajouter/modifier une fiche : éditer la source, relancer le générateur.
- **R142 — Gravité 6 « La fronde »** : une planète (`lv.well=[x,y,m,r]`, attraction m/d² dans `engine.js` fields, noyau de
  structure) au milieu ; la toile de l'espace se creuse autour (`VX.well`, grille déformée violette + niveaux d'énergie).
  Le joueur vise à côté de la planète, sa gravité courbe la fin de la trajectoire vers le bassin (≈ 1 % des traits au hasard).
  **Gravité 12 « Relativité »** (Escher) : zones à leur propre bas (`grav` 7ᵉ valeur = 1, `VX.gzone` : lignes d'horizon
  perpendiculaires à la pesanteur locale + fil à plomb) ; la particule roule vers la droite, le joueur trace sur la paroi de
  droite une pente qui « descend » vers le haut, elle file au plafond, une crosse la rend au bassin central. Pas de poussière
  d'indice sur ces deux niveaux (elle révélerait la solution). Scratchpad `m/g78.js`, `m/r84.js`.
- **R143 — Magnétisme 6 « Les états de bord »** : champ magnétique uniforme (`lv.bf=[x,y,w,h,B,vide?]`, force de Lorentz :
  la vitesse tourne sans changer de valeur ; `VX.bfield` : trame ⊙/⊗ qui respire). Avec la pesanteur, la particule fait des
  cycloïdes qui dérivent de côté ; le joueur dresse un bord : elle le longe en sautillant (orbites rasantes, les « états de bord »
  de l'effet Hall quantique) jusqu'au bassin. **Magnétisme 12 « Le cyclotron »** : deux « D » sous vide (`bf` 6ᵉ valeur = 1)
  et une fente accélératrice (`lv.kick`, poussée dans le sens de la course, `VX.kickgap`) ; la particule part de la source au
  centre et s'enroule en spirale de plus en plus large ; le joueur place le déflecteur d'extraction vers le bassin
  (≈ 0,7 % des traits au hasard). ≈ 13 s. Scratchpad `m/b90.js`, `m/c96.js`.
- **R144** — Gravité 6 : planète plus grosse (noyau r 34) et poussière. Gravité 12 refaite d'après le croquis de Simon :
  plafond en arc gracieux plus bas, zone du haut agrandie (x 120–360, y 0–140), colonne de droite élargie → bien plus
  facile (15 pentes sur 18 gagnent) ; zones « Relativité » plus visibles (teinte, bas local éclairé, contour pointillé).
  **Faille 6 « L'élan transmis »** : failles orientées (`port` 5ᵉ/6ᵉ valeurs : angle de sortie, 1 = absolu) ; ce qui tombe
  dans la faille du fond ressort à l'horizontale aussi vite ; le joueur choisit la hauteur de plongée (un trait dans le puits).
  Bouches dessinées en « corral quantique » (`VX.rift` : anneau d'atomes, onde stationnaire, chevrons de sortie).
  **Faille 12 « L'univers torique »** : bords gauche et droit recousus (`lv.wrap=[y0,y1]`, coutures `VX.seam`, éclair aux deux
  bords) ; la particule descend une hélice de quatre tours qui traverse la couture ; le joueur la fait sortir à droite pour
  qu'elle entre à gauche dans le bassin abrité. `slotwrite.py` écrit désormais `port` et `wrap`.
- **R145 — Filaments (monde 10) réordonné** à la demande de Simon : anciens 2–6 → 1–5, anciens 8–12 → 7–11 ; les anciens 1 et
  7 sont remplacés par deux machines aux **cordes élastiques** (`lv.elastic` : rebond des cordes du joueur, 0,86 ≈ 65 % de la
  hauteur ; `lv.strings=[[x1,y1,x2,y2]]` : cordes tendues du décor, `lv.strE` ; dessin `VX.harp`). **Filaments 6 « La harpe »** :
  trois cordes, il en manque une ; le joueur la tend au bon endroit (9 placements sur 16 gagnent). **Filaments 12 « La toile
  élastique »** (renommée : « Le trampoline » existe déjà au monde 2) : la particule tombe sur une corde tendue presque à plat ;
  le joueur tend la seconde corde qui la relance jusqu'au bassin perché. Colonne non traçable à gauche (`nd` x < 110) : sans
  elle, une corde sous la chute gagnait sans la corde du décor (raccourci). Sans la corde du décor : 0 gagnant sur 5 730 traits ;
  14 familles ; P_exec 63 % (sous les 70 % visés), noyau pris 52 %. Le bouton Fermer de la constellation ramène à l'accueil.
- **R146 — Filaments 6 et 12 refaits en vraies machines** (Simon : la harpe et la toile « ne font pas machine »).
  Moteur : cordes du décor **entraînées** (`strings` : `[x1,y1,x2,y2, amp, vitesse, phase, bout(0 les deux), wv, dx, dy]` ;
  `wv` > 0 = fronde : tension lente pendant la fraction `wv` du cycle puis détente brusque ; `dx,dy` = axe de traction) ;
  vitesse d'entraînement transmise à la balle au contact ; `lv.sling={z:[x,y,w,h],amp,spd,ph,wv,d:[dx,dy],e}` : une corde du
  joueur dont les deux bouts sont dans la zone devient l'élastique d'une fronde. Visuels : `VX.harp` (la corde frappée vibre sur
  le mode dont le ventre est au point d'impact, nœuds marqués), `VX.fork` (`lv.fork` : diapason de Melde, élastiques qui
  rougissent à la tension, onde de choc à la détente ; `player:1` = fronde vide en pointillé).
  **Filaments 6 « Le lance-pierre »** : la bille roule dans la poche, le diapason tire, l'arc retombe sur la rampe et revient
  dans la poche — boucle perpétuelle stable (période 140 images) ; le joueur coupe la boucle avec une corde pour l'envoyer dans le
  bassin de gauche. Fronde immobile : 0 gagnant sur 1 460 ; famille de référence 97 % au doigt.
  **Filaments 12 « Le relais des frondes »** : deux diapasons se passent la bille en zigzag montant ; le joueur tend la
  troisième fronde (zone `sling`) : il faut une POCHE (trait en V) — 0 bande droite gagnante sur 415, 0 trait hors fronde sur
  2 965, 0 poche inerte ; ≈ 8 s ; jouabilité au doigt 50–83 % selon la poche (référence ≈ 77 %).
- **R147** — Outil Échelle : le rond central déplace la ligne, plus de poignée de rotation (textes fr/en mis à jour).
  **Texture de fond** (tous les mondes sauf la Chaîne) : plus aucune sphère (globes et coquilles de points retirés) ; trois
  nappes de fils de soie très fins dont les angles diffèrent → moiré qui glisse, trois familles de transparence, grain d'étoiles
  (`vlSilk`, `vlSilkDraw`, `vlGrainDraw` dans `visuals.js`) ; hélices deux fois plus petites et plus fines.
  **Magnétisme 6 « Le canon de Gauss »** : nouvel élément `lv.coil=[[x,y,ax,ay,portée,force,(vide)]]` (bobine qui tire la
  particule vers son centre le long de l'axe puis se coupe, `VX.coil` : spires, lignes de champ, flèche quand elle s'allume).
  Quatre bobines lancent la particule dans un J, puis dans le champ magnétique (`bf`) où elle sautille en cycloïdes jusqu'au mur
  gauche et retombe dans le canon : boucle perpétuelle autour du bassin ; le joueur la fait tomber au cœur. Zone de machine
  invisible (`mz`) sur la descente de gauche (sinon une rampe directe gagnait). Bobines coupées : 0 gagnant sur 7 350 ;
  au doigt 87–100 %.
  **Magnétisme 12 « Le spectromètre »** (Aston 1919) : trois colonnes au‑dessus du canon (5, 4 ou 3 bobines à franchir) ;
  la vitesse fixe le rayon du demi‑cercle dans la chambre sous vide (collimateur vertical, champ au‑dessus d'une bande de
  pesanteur pour que la particule se pose) ; orbites de référence en pointillé et raies sur la plaque (`lv.spectro`,
  `VX.spectro`). Défaut : colonne de droite → trop lent. Bobines coupées : 0 gagnant ; référence 60 % au doigt (sous 70 %).
- **R148** — Texture de fond étendue à TOUS les mondes (la Chaîne aussi) : cinq nappes de fils (maille 4 à 24 u, cinq
  opacités) + grain dense + **mycélium de lumière** (`myBuild`/`myDraw` : réseau de capillaires qui pousse depuis les bords,
  dessiné une fois dans un calque ; des éclats partent des racines, se divisent aux fourches et laissent une traînée qui
  s'éteint). **Magnétisme 6** : looping après trois bobines (rail guidé `look:'track'` dessiné comme une courbe, capture
  seulement si la vitesse ≥ `vmin` = 10 → bobines coupées : 0 gagnant sur 10 506) ; bassin déplacé [96,372,92] ; 241 traits
  gagnants sur 3 480 ; référence 100 % au doigt ; noyau au sommet du J (le rail ne ramasse pas le noyau).
- **R149** — Texture du Magnétisme refaite d'après la vidéo de ferrofluide de Simon (`ferro2`) : plus de goutte/bulle ;
  cinq plages qui dérivent, de tailles et de finesses différentes (cellules fines, moyennes, grandes) ; rendu en veines
  connectées (champ f2−f1 sur grille 96×128, graines rangées par cases, image lissée) + contours fins ; éclats rares qui
  suivent les parois (`fvSparks`), un sur cinq finit en rouge/orangé/pourpre (`WARM`). Mycélium de tous les mondes : plus fin
  (traits 0,42 u, alpha divisé par deux), plus régulier, éclats rares (≈ 1 toutes les 1,5 s, 6 au plus), plus doux, un sur
  cinq vire au chaud.
- **R150** — Simon préfère la texture discrète des niveaux 6 et 12 du Magnétisme : labyrinthe atténué partout (veines 0,2,
  contours 0,38/0,42). Éclats rendus perceptibles (mycélium : ≈ 1 toutes les 0,6 s, 9 au plus ; parois : 8 au plus, plus
  lumineux). Zones de champ magnétique (`VX.bfield`) lisibles : voile rose qui respire, bande de lumière qui balaie, liseré
  en pointillé, coins marqués, symboles ⊙/⊗ plus nets.
- **R151** — Magnétisme : labyrinthe plus présent (veines 0,34, contours 0,6) ; plus aucune bille qui flotte (gouttelettes
  et poussière du ferrofluide retirées) ; mycélium coupé dans ce monde. **Flux d'énergie** (`fvFlow`) : une impulsion naît
  sur une veine (crête du champ f2−f1), suit la crête de case en case, se ramifie aux carrefours, laisse une traînée lissée ;
  une sur cinq glisse vers rouge/orangé/pourpre. Même rendu sur les 12 niveaux du monde (vérifié en planche).
- **R152** — Captures de Simon : le niveau 4 (sans mur) montrait des cellules très marquées, le 12 (beaucoup de murs) presque
  rien, car `ffClear` effaçait la texture à 46 u de chaque mur. Désormais : effacement seulement à 6–28 u des pièces et jamais
  sous 35 % ; contours atténués (0,4 / 0,36). Planche 1, 4, 6, 12 : même densité.
- **R153 — RÉGRESSION CORRIGÉE.** En R147–R148 j'avais appliqué à tout le jeu une demande qui visait le Magnétisme : voiles en
  volume de chaque monde remplacés par une nappe de fils, hélices réduites, réseau capillaire partout. Rétabli : voiles 3D,
  hélices et hélice fantôme comme en R146 ; réseau capillaire retiré (le Magnétisme garde ferrofluide + flux + soie). Ajouts :
  nouvelles formes de voiles par monde (galaxie spirale, nœud de trèfle, réseau cristallin, solénoïde : Soufflerie disk/cyl,
  Mécanique lattice/torus, Gravité disk, Faille et Filaments knot, Quantique lattice/tetra) ; chaque niveau compose ses voiles
  autrement (position, taille, ordre, sens). **Mécanique décorative** (monde 6, `D.mech`, `mechDeco`) : trains d'engrenages
  engrenés, bielle‑manivelle sur glissière, échappement à ancre, came et poussoir, posés hors des pièces de jeu, 4 par niveau.
  **Leçon : une remarque sur un monde ne s'étend jamais aux autres sans le dire.**
- **R154** — Bruit de vent persistant (musique) : les bruits continus du monde 1 (chœur d'air, grondement, frottement de
  `W1N`) gardaient leur dernier volume quand on quittait le niveau (menu, constellation, autre monde). `W1N.hush()` les
  ramène à 0 dans l'état menu et hors du monde 1 ; `W1N.bar` ne joue rien en menu ; constellation et page du monde passent
  la musique en état menu. Ligne de diagnostic du son retirée de l'accueil.
- **R155** — Tracés du joueur en rebond (1) et accélérateur (3) dessinés avec `VX.curve` comme les pièces du niveau (fin, lumineux) au lieu des planches épaisses `plate`/`boostPad`.
- **Reste** : fiches des outils Échelle et Aimant ; scènes simulées pour les éléments quantiques ; machines du monde 3
  (Chaîne 3 et 9 proposés) ; mondes 7 à 11.
- **À faire (demandé par Simon)** : (1) didacticiels harmonisés, non codés en dur ; (2) deux machines manquantes du monde 3
  à base de matière poreuse (niveaux à confirmer avec Simon).
- Connu, non traité : zone de réussite non propre aux niveaux 21 et 34.

## Aperçu

Adresse unique : https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC. Il montre le monde travaillé en dernier ; éditeur : https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp. Pour juger
les machines 3 et 6, republier le monde 1 (`python3 tools/build-apercu.py 1`).

## Outils utiles

`tools/rail.js` (courbes harmonieuses), scratchpad de conception des machines recopié dans `tools/fiches/machines/*.json`,
`tools/courts.js N` (traits courts gagnants), `tools/monde1.js`, `monde2.js`, `replaytest.js`, `zonepropre.js`,
`difficulty.js`, `enigme.js`, `constance.js` (`EX/EY/EY2/ER`).

## Décisions attendues de Simon

1. Périmètre de la première version publiée (proposition : mondes 1 à 4, une machine par monde, la finale).
2. Connecter le dépôt GitHub du site (fin des zips et des tampons) ?

## Prochain lot proposé

Republier l'aperçu du monde 1 pour que Simon juge les machines 3 et 6 ; selon son avis, faire la **finale 12 du monde 1** comme
machine (même méthode que 3 et 6), puis la finale 24.
