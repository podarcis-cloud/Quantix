# QUANTIX — REPRISE DE SESSION (à lire EN PREMIER, puis s'arrêter là)

*Ce fichier remplace la relecture de la conversation précédente, devenue trop
longue et trop coûteuse. Il suffit à reprendre le travail. Version : **R32**.*

## Phrase d'ouverture à coller dans une conversation neuve

> Reprends Quantix. Lis `docs/REPRISE-SESSION.md` en entier, puis seulement
> les sections du handbook qu'il indique. Tâche : **[une seule tâche de la
> liste §4]**. Applique la méthode §3. Livre un aperçu jouable publié, puis
> le zip.

## 1. Où en est le jeu (vérifié par les tests, pas déclaré)

| Élément | État | Preuve |
|---|---|---|
| Monde 1 · Atelier | **Refondu, 12/12** | `node tools/monde1.js` |
| Monde 2 · Fonderie | **Refondu 11/12** — #19 est l'ANCIEN « Le four » (R29), à reconcevoir | `node tools/monde2.js` → 11/11 ; `bypass.js 2` → 0/11 |
| Mondes 3 à 11 | Anciens niveaux (R29), à refondre | — |
| Solution optimale (bouton) | Mondes 1 et 2 : chaque niveau refondu a son `optsol` (+ `optmat` si matière rebond), noyau compris | `node tools/replaytest.js` |
| Revoir ma partie | Fonctionne (relit `S.rec`, sans physique) | `replaytest.js` |
| Rebond sans fin | Arrêt à **20 s** de vol → « Rebond sans fin » + bouton **Continuer** (+20 s) | testé R32 |
| Décor cosmique / Fonderie | **Aperçus seulement**, pas dans le moteur | `docs/apercus/*.html` |

**Aperçus publiés** (claude.ai) : Atelier 12/12 et Fonderie 10 niveaux —
sources dans `docs/apercus/` ; code des décors dans `tools/apercu/`.

## 2. Ce que l'utilisateur veut (ne pas le perdre)

- **Refonte niveau par niveau**, ambitieuse, jamais un simple correctif :
  chaque niveau = une idée, une chute, un noyau qui récompense un choix.
- **Chaque monde a sa narration et son identité visuelle animée forte** —
  fondée sur une expérience de physique réelle (`docs/QUANTUM_VISUAL_NARRATIVE.md`).
  Les vidéos d'illusions bistables (nuages de points en rotation) sont des
  **références d'animation mathématique** pour ces identités de monde — pas
  une demande de nouveau noyau par monde.
- **Toujours un aperçu jouable** du travail en cours, qui soit fidèle au jeu.
- Style de décor retenu : **néon + couche cosmique** (hélices ADN, poussière
  d'étoiles, voile de nébuleuses), décliné par monde (Fonderie = chambre à
  bulles). Le style « rétro plat » a été **rejeté**.
- Réponses en **français**. Ne pas se contenter de documenter : produire.

## 3. Méthode qui marche (outils dans `tools/`)

1. Concevoir des candidats dans un fichier `wNcand.js` (format de `levels.js`).
2. `lab.js` : pour chaque candidat — échec sans trait, gagnants AVEC la
   mécanique, gagnants SANS elle (doit être 0). Script modèle : `w2redo.js`.
3. `w2finish.js` (généraliser en `wNfinish.js`) : noyau placé où passent
   15–35 % des solutions, solution avec noyau la plus tolérante au doigt
   (±4 px, seuil ≥ 50 %). **Un niveau par commande** (`OUT=wN_k.json
   STEP=14 DA=.34 NT=30 timeout 285 node …`) — la machine n'a **qu'un
   processeur**, rien en parallèle, rien en arrière-plan (ne survit pas).
4. Vérifier que les gagnants utilisent **vraiment** chaque élément prévu
   (rendre l'élément inerte, compter ceux qui échouent).
5. Écrire dans `levels.js` (+ `optsol`/`optmat`) et `i18n.js` (EN), puis
   un test `mondeN.js` sur le modèle de `monde2.js`.
6. Aperçu : partir de `docs/apercus/monde2-fonderie.html` (collision
   **identique** au moteur : contact à R+4 murs, R+3,2 traits, pointes
   mortelles). Remplacer le décor par celui du monde. Vérifier que chaque
   solution y gagne avec le noyau avant de publier.
7. Séquence handbook §10 + `monde1.js` `monde2.js` `replaytest.js`, tampon
   de version neuf, zip.

**Règles de conception apprises** : handbook §11 ter (monde 1) et
§11 quinquies (monde 2 — principe d'énergie : bassin plus haut que le
départ ⇒ rebond indispensable ; la plaque ne projette vers le haut que
frappée **en vol** ; éviter les demi-tours avec rebond et les rebonds entre
deux parois).

## 4. Prochaines tâches, dans l'ordre

1. **Monde 2 #19** (rôle « combinaison ») — 9 concepts rejetés, listés au
   handbook §11 quinquies. Piste non essayée : combiner avec *Le col* ou
   *Le leurre* du monde 1, en gardant une arrivée **en vol** sur la plaque.
2. **Monde 2 : réduire la redondance** (`redundancy.js 2` → 8 paires) —
   varier la position du départ et de la plaque entre niveaux proches.
3. **Monde 3 · Chaîne (élan)** — narration « anneau d'accélération ».
   Principe à vérifier d'abord : le tapis d'élan est un *interrupteur* de
   vitesse (~7,4 constant), pas un curseur.
4. Intégrer au moteur le décor animé par monde (aujourd'hui aperçus seuls).
5. Mondes 4 à 11, puis #114 (monde 10, infranchissable) et monde 11
   (12/12 contournable) — priorités connues.

## 5. Pièges qui ont coûté cher (ne pas refaire)

- `node -e` : jamais de variable `L`, `S`, `T` (collision avec le moteur,
  handbook §9.1) — utiliser `LV`, `ST`, `X.S`.
- `pkill -f motif` tue aussi la commande qui le contient.
- Un aperçu à physique approximative ment : copier `collide()` du moteur.
- Une solution de référence « qui gagne » ne prouve pas que le noyau est
  atteignable : toujours vérifier `gotStar`.
