# QUANTIX — Reprise de session (R208, 13 octobre 2026)

*Une page, réécrite à chaque lot (jamais empilée). La méthode est dans `METHODE.md` ; le pourquoi dans `AUDIT_METHODE.md`.
L'ancienne reprise (11 600 mots, R38 → R121) est archivée sous `archive/REPRISE-SESSION-R121.md`.*

## Où en est le jeu (zip QUANTIX-R121)

- **Monde 1 — Atelier** : 12 niveaux jouables. Machines refaites aux courbes calculées : **3 Le colimaçon** (lacets à trois
  crochets) et **6 Les collines** (vague, décollage, dosseret). Faibles : 1 (gagné par un tout petit mur), 9, 11, 12 (finale
  sans machine).
- **Monde 2 — Fonderie** : 12 niveaux. **18 Ta plaque** a sa machine « creuset » (trémie à bras courbes, goulotte, plaque de
  relance). Vérifications bloquantes non passées : **19** (pas de solution de référence), **21** (élément dans la zone).
  Finale 24 sans machine (essai de machine au départ abandonné, voir archive).
- **Mondes 3 à 11** : niveaux anciens, non revus.
- **Didacticiel** : système de fiches en surimpression ; la consigne du niveau 1 se pose sur la barre du haut.
- **Son** : W1N corrigé (respire jusqu'au silence, pulsation dès le niveau 1) ; trop présent à partir du niveau 8 (à alléger).
- **Mesure de jouabilité** : modèle « éditeur » partout depuis R121 (`DOIGT=1` rétablit l'ancien).

## Depuis R122 (10 oct.)

- Outils de tracé toujours visibles hors introduction (R122). Éditeur republié avec les niveaux actuels (clé `QED2:`).
- **Fonderie 6 « Ta plaque »** : serpentin dessiné par Simon, mis au propre (tube lissé, bonus rebond au virage droit), départ
  décalé à x = 40 — validé par Simon (R125).
- **Fonderie 12 « La fonte »** : esquisse de Simon rendue fonctionnelle (R126) : plaque du sol → tube en arche par dessous →
  plaque de relance → second tube → bassin perché en haut à gauche, abrité par un toit. Constance 89 %, ≈ 8 s, jouabilité
  indicative 37 %. Outils : scratchpad `m/tubes.js`, `m/m24d.js`, `m/g24.js` ; `tools/fiches/machines/fonte24.json`.
- **Chaîne 6 « Saut de chaîne »** (R128) : machine de sauts — tapis + tremplins + crochets tapissés qui cueillent le vol,
  trois sauts en zigzag ; le joueur pose le DERNIER maillon : un tapis dans le bon sens remonte la particule à la zone (structure
  et tapis à l'envers ne marchent pas). Constat physique : pas de looping possible en 2D, le tapis ne soulève pas à la verticale.
  Scratchpad `m/jump.js` → `tools/fiches/machines/chaine30.json`.
- **Chaîne 12 « La chaîne complète »** (R129) : VRAI LOOPING. Le joueur trace le maillon qui monte (tapis, sens imposé) ;
  la particule boucle tête en bas et traverse sa propre piste d'entrée grâce aux **pistes traversables** (moteur : champs
  `pass` et `pz` des courbes, `engine.js` curveExpand + collide). Proposition d'intégration : `docs/PISTES_TRAVERSABLES.md`.

- **R130 — repères de la paroi tunnel (W3N12 seulement, pour validation)** : la partie traversable d'une piste est
  marquée en bleu glacé #A9BCEB (gaine lumineuse, deux brins entrelacés qui ondulent = imbrication de la matière, bornes
  aux deux bouts ; les atomes s'écartent et un anneau s'élargit quand la particule passe). Fiche de didacticiel « Paroi
  tunnel » (FR/EN, démo : bille lente portée / bille rapide qui traverse). Poussière d'étoile (`lv.flow`, `VX.flow`) qui
  dérive du départ vers l'entrée de la machine. Noyau déplacé au sommet de la boucle (il masquait le croisement).
  Code : `visuals.js` tunnel/flow, `engine.js` (dessin), `tuto.js` (carte), `i18n.js`. **À étendre aux autres machines
  seulement après accord de Simon.**
- **R131 — poussière des machines (toutes)** : `lv.flow` = trajectoire de la solution dans la machine (+ courte amorce
  vers l'entrée), calculée par `node tools/flow.js 3 6 18 24 30 36` (à relancer si une machine change). `VX.flow` : grains à
  vitesses variées, les plus rapides laissent un fil, certains décrochent dans les virages serrés et filent tout droit.
  Fiche raccourcie : « Piste poreuse — lente, roule dessus ; rapide, passe au travers ». La piste poreuse n'existe qu'en 36.
  Aperçu : mondes 1 à 3 débloqués.
- **R132 — Atelier 12 « Le portail »** (remplace « L'établi ») : un mur poreux vertical coupe le terrain. Le joueur trace une
  rampe ; trop douce, la particule bute (vx < 4,5) ; assez raide, elle traverse et entre dans la machine « aiguille » : un tube
  qui coud la membrane trois fois (droite → gauche → droite) puis la traverse une dernière fois jusqu'au bassin abrité.
  Géométrie : scratchpad `m/p12.js` → `tools/fiches/machines/portail12.json`, `forge.json` clé `12_portail`. La fiche
  « Matière poreuse » apparaît ici pour la première fois. Mur entièrement poreux : dessiné seulement en gaine bleu pâle.
  Poussière plus dense (jusqu'à 280 grains, tailles et transparences variées, quelques halos).
- **R133** — Atelier 12 affiné : membrane courbe, parois du tube qui s'effacent dans la matière poreuse (ni nœud ni capuchon
  au contact, `visuals.js` jointsBuild), abri courbe du bassin, capot courbe à droite, zones interdites resserrées.
  **Glacier 6 « La piste glacée »** (remplace « La butée ») : tube de glace avec un vrai looping (croisement poreux `pz`,
  sans nœud), sortie lancée à pleine vitesse ; le joueur pose la butée derrière le bassin. Scratchpad `m/p42.js` →
  `tools/fiches/machines/luge42.json`, forge `42_luge`.
- **R134** — **Glacier 12 « Le pendule de glace »** (remplace « Le sérac ») : vasque de glace sans frottement, la particule
  s'y balance sans fin ; au fond, une fenêtre de glace poreuse (`pass` 6, `pz`) ne laisse passer qu'une chute franche ; dessous,
  entonnoir et tube de glace jusqu'au bassin. Plusieurs familles de solutions (≈ 3 % des traits au hasard gagnent : tremplins sur
  les flancs, déflecteurs). Scratchpad `m/p48e.js`, `g48.js` (recherche rapide) → `machines/pendule48.json`, forge `48_pendule`.
  Bouton retour du niveau → carte du monde (`engine.js` gBack). Aperçu : tous les mondes et niveaux ouverts
  (`build-apercu.py 4 11 skipintro`).
- **R135** — Outils **Échelle** et **Aimant** : dans le jeu (dock : `editor.js` mode `scale`, interrupteur `mag` mémorisé
  `QX_mag` ; l'encre suit la longueur, annulation prise en charge) et dans l'éditeur de niveaux (poignée carrée sous la forme,
  bouton ⊕, `QED_mag`). Éditeur republié.
- **R136** — retour du niveau → page illustrée du monde (`openWorld`). **R137 — Atelier 12 « La cellule »** (remplace « Le
  portail ») : cellule ronde de structure (r 88) percée d'un pore poreux (`pz`, `pass` 3.2) en bas à droite, bassin-noyau à
  l'intérieur, orbite concentrique (r 130) autour. La particule tombe dans l'orbite et oscille ; le joueur barre l'orbite juste
  après le pore : elle rebondit et traverse. Aucun raccourci depuis le haut (recherche). Scratchpad `m/c12.js` →
  `machines/cellule12.json`, forge `12_cellule`. 
- **R138 — Soufflerie 6 « La cascade inversée »** (remplace « Vent et plafond ») : une colonne d'air (vent −1,3) entre deux
  parois de verre ; cinq plafonds en zigzag que la particule remonte comme l'eau descend un escalier ; en haut, une crosse la
  rejette à gauche vers le bassin. Le joueur la fait entrer par le bas (rampe sous la paroi droite). ≈ 6,5 s. Scratchpad
  `m/w54.js`, `run54c.sh` → `machines/cascade54.json`, forge `54_cascade`.
- **R139 — Soufflerie 12 « Le cyclone »** (remplace « La veine ») : tambour de structure (r 90) parcouru par un tourbillon
  (quatre champs tangents, invisibles : 7ᵉ valeur = 1) dessiné en spirale (`lv.vortex`, `VX.vortex`) ; la particule y tourne
  sans fin au‑dessus d'une fente ; le joueur glisse une lame qui l'arrache vers l'entonnoir et le bassin. Scratchpad `m/v60.js`
  → `machines/cyclone60.json`, forge `60_cyclone`. Essai d'entrée tangentielle en spirale abandonné (trajectoire chaotique).
- **R140** — Soufflerie 6 recomposée (vase de verre courbe, plafonds détachés des parois — plus de nœuds —, colonne d'air
  dessinée en filets montants `lv.updraft`/`VX.updraft`, champ de vent caché). **Mécanique 6 « L'escalier mécanique »** :
  quatre marches mobiles dorées en contretemps (`mov` avec `ph` phase, `v` vitesse transmise à la balle, `ck` bielle à
  coulisse dessinée `VX.yoke`) alternent avec des paliers fixes : la particule monte seule ; le joueur la pose sur la
  première marche. **Mécanique 12 « L'échappement »** : boîtier d'horloge en arche, balancier et ancre (`lv.pend`,
  `VX.pendulum`), palettes coulissantes (`pl`) qui libèrent un palier par battement ; le joueur jette un pont au‑dessus du
  fond mortel. Moteur : `moverSeg` (phase, vitesse) et `collide` (vitesse relative) — sans effet sur les anciens niveaux
  (options absentes). Zones nettoyées : 48 (bout du tube retiré, lèvre à droite du bassin), 60 (entonnoir raccourci).
  Scratchpad `m/s66.js`, `m/e72.js` → `machines/escalier66.json`, `echappement72.json`.
- **Leçon (Simon, 10 oct.)** : le cyclone est le modèle — un concept fort ET une esthétique singulière qui sert le jeu
  (dessin dédié de la mécanique : tourbillon, filets d'air, bielles, balancier). À systématiser. Éviter la redondance des
  cercles et des échelles de plafonds.
- **R141 — Didacticiel harmonisé** : les fiches d'éléments physiques (zone interdite, pointes, rebond, élan, poreux, glace,
  vent, gravité, aimant, portail, paroi mobile) ne sont plus chorégraphiées à la main : chaque scène est décrite en données
  (`tools/tuto-scenes-src.js`, repère 232 × 104), simulée par le vrai moteur (`node tools/tutoscenes.js` → `assets/js/
  tuto-scenes.js`, `window.TSC`) et rejouée par un lecteur unique (`tuto.js` `scene()`) : le doigt trace, la bille part, elle
  suit la trajectoire calculée, pause. Même rendu que le jeu (murs, courbes, filets d'air, poreux). Restent dessinées à la main :
  outils (gestes), puces de matière, éléments quantiques (intrication, superposition, détecteur, dilatation) et bille molle.
  Pour ajouter/modifier une fiche : éditer la source, relancer le générateur.
- **R142 — Gravité 6 « La fronde »** : une planète (`lv.well=[x,y,m,r]`, attraction m/d² dans `engine.js` fields, noyau de
  structure) au milieu ; la toile de l'espace se creuse autour (`VX.well`, grille déformée violette + niveaux d'énergie).
  Le joueur vise à côté de la planète, sa gravité courbe la fin de la trajectoire vers le bassin (≈ 1 % des traits au hasard).
  **Gravité 12 « Relativité »** (Escher) : zones à leur propre bas (`grav` 7ᵉ valeur = 1, `VX.gzone` : lignes d'horizon
  perpendiculaires à la pesanteur locale + fil à plomb) ; la particule roule vers la droite, le joueur trace sur la paroi de
  droite une pente qui « descend » vers le haut, elle file au plafond, une crosse la rend au bassin central. Pas de poussière
  d'indice sur ces deux niveaux (elle révélerait la solution). Scratchpad `m/g78.js`, `m/r84.js`.
- **R143 — Magnétisme 6 « Les états de bord »** : champ magnétique uniforme (`lv.bf=[x,y,w,h,B,vide?]`, force de Lorentz :
  la vitesse tourne sans changer de valeur ; `VX.bfield` : trame ⊙/⊗ qui respire). Avec la pesanteur, la particule fait des
  cycloïdes qui dérivent de côté ; le joueur dresse un bord : elle le longe en sautillant (orbites rasantes, les « états de bord »
  de l'effet Hall quantique) jusqu'au bassin. **Magnétisme 12 « Le cyclotron »** : deux « D » sous vide (`bf` 6ᵉ valeur = 1)
  et une fente accélératrice (`lv.kick`, poussée dans le sens de la course, `VX.kickgap`) ; la particule part de la source au
  centre et s'enroule en spirale de plus en plus large ; le joueur place le déflecteur d'extraction vers le bassin
  (≈ 0,7 % des traits au hasard). ≈ 13 s. Scratchpad `m/b90.js`, `m/c96.js`.
- **R144** — Gravité 6 : planète plus grosse (noyau r 34) et poussière. Gravité 12 refaite d'après le croquis de Simon :
  plafond en arc gracieux plus bas, zone du haut agrandie (x 120–360, y 0–140), colonne de droite élargie → bien plus
  facile (15 pentes sur 18 gagnent) ; zones « Relativité » plus visibles (teinte, bas local éclairé, contour pointillé).
  **Faille 6 « L'élan transmis »** : failles orientées (`port` 5ᵉ/6ᵉ valeurs : angle de sortie, 1 = absolu) ; ce qui tombe
  dans la faille du fond ressort à l'horizontale aussi vite ; le joueur choisit la hauteur de plongée (un trait dans le puits).
  Bouches dessinées en « corral quantique » (`VX.rift` : anneau d'atomes, onde stationnaire, chevrons de sortie).
  **Faille 12 « L'univers torique »** : bords gauche et droit recousus (`lv.wrap=[y0,y1]`, coutures `VX.seam`, éclair aux deux
  bords) ; la particule descend une hélice de quatre tours qui traverse la couture ; le joueur la fait sortir à droite pour
  qu'elle entre à gauche dans le bassin abrité. `slotwrite.py` écrit désormais `port` et `wrap`.
- **R145 — Filaments (monde 10) réordonné** à la demande de Simon : anciens 2–6 → 1–5, anciens 8–12 → 7–11 ; les anciens 1 et
  7 sont remplacés par deux machines aux **cordes élastiques** (`lv.elastic` : rebond des cordes du joueur, 0,86 ≈ 65 % de la
  hauteur ; `lv.strings=[[x1,y1,x2,y2]]` : cordes tendues du décor, `lv.strE` ; dessin `VX.harp`). **Filaments 6 « La harpe »** :
  trois cordes, il en manque une ; le joueur la tend au bon endroit (9 placements sur 16 gagnent). **Filaments 12 « La toile
  élastique »** (renommée : « Le trampoline » existe déjà au monde 2) : la particule tombe sur une corde tendue presque à plat ;
  le joueur tend la seconde corde qui la relance jusqu'au bassin perché. Colonne non traçable à gauche (`nd` x < 110) : sans
  elle, une corde sous la chute gagnait sans la corde du décor (raccourci). Sans la corde du décor : 0 gagnant sur 5 730 traits ;
  14 familles ; P_exec 63 % (sous les 70 % visés), noyau pris 52 %. Le bouton Fermer de la constellation ramène à l'accueil.
- **R146 — Filaments 6 et 12 refaits en vraies machines** (Simon : la harpe et la toile « ne font pas machine »).
  Moteur : cordes du décor **entraînées** (`strings` : `[x1,y1,x2,y2, amp, vitesse, phase, bout(0 les deux), wv, dx, dy]` ;
  `wv` > 0 = fronde : tension lente pendant la fraction `wv` du cycle puis détente brusque ; `dx,dy` = axe de traction) ;
  vitesse d'entraînement transmise à la balle au contact ; `lv.sling={z:[x,y,w,h],amp,spd,ph,wv,d:[dx,dy],e}` : une corde du
  joueur dont les deux bouts sont dans la zone devient l'élastique d'une fronde. Visuels : `VX.harp` (la corde frappée vibre sur
  le mode dont le ventre est au point d'impact, nœuds marqués), `VX.fork` (`lv.fork` : diapason de Melde, élastiques qui
  rougissent à la tension, onde de choc à la détente ; `player:1` = fronde vide en pointillé).
  **Filaments 6 « Le lance-pierre »** : la bille roule dans la poche, le diapason tire, l'arc retombe sur la rampe et revient
  dans la poche — boucle perpétuelle stable (période 140 images) ; le joueur coupe la boucle avec une corde pour l'envoyer dans le
  bassin de gauche. Fronde immobile : 0 gagnant sur 1 460 ; famille de référence 97 % au doigt.
  **Filaments 12 « Le relais des frondes »** : deux diapasons se passent la bille en zigzag montant ; le joueur tend la
  troisième fronde (zone `sling`) : il faut une POCHE (trait en V) — 0 bande droite gagnante sur 415, 0 trait hors fronde sur
  2 965, 0 poche inerte ; ≈ 8 s ; jouabilité au doigt 50–83 % selon la poche (référence ≈ 77 %).
- **R147** — Outil Échelle : le rond central déplace la ligne, plus de poignée de rotation (textes fr/en mis à jour).
  **Texture de fond** (tous les mondes sauf la Chaîne) : plus aucune sphère (globes et coquilles de points retirés) ; trois
  nappes de fils de soie très fins dont les angles diffèrent → moiré qui glisse, trois familles de transparence, grain d'étoiles
  (`vlSilk`, `vlSilkDraw`, `vlGrainDraw` dans `visuals.js`) ; hélices deux fois plus petites et plus fines.
  **Magnétisme 6 « Le canon de Gauss »** : nouvel élément `lv.coil=[[x,y,ax,ay,portée,force,(vide)]]` (bobine qui tire la
  particule vers son centre le long de l'axe puis se coupe, `VX.coil` : spires, lignes de champ, flèche quand elle s'allume).
  Quatre bobines lancent la particule dans un J, puis dans le champ magnétique (`bf`) où elle sautille en cycloïdes jusqu'au mur
  gauche et retombe dans le canon : boucle perpétuelle autour du bassin ; le joueur la fait tomber au cœur. Zone de machine
  invisible (`mz`) sur la descente de gauche (sinon une rampe directe gagnait). Bobines coupées : 0 gagnant sur 7 350 ;
  au doigt 87–100 %.
  **Magnétisme 12 « Le spectromètre »** (Aston 1919) : trois colonnes au‑dessus du canon (5, 4 ou 3 bobines à franchir) ;
  la vitesse fixe le rayon du demi‑cercle dans la chambre sous vide (collimateur vertical, champ au‑dessus d'une bande de
  pesanteur pour que la particule se pose) ; orbites de référence en pointillé et raies sur la plaque (`lv.spectro`,
  `VX.spectro`). Défaut : colonne de droite → trop lent. Bobines coupées : 0 gagnant ; référence 60 % au doigt (sous 70 %).
- **R148** — Texture de fond étendue à TOUS les mondes (la Chaîne aussi) : cinq nappes de fils (maille 4 à 24 u, cinq
  opacités) + grain dense + **mycélium de lumière** (`myBuild`/`myDraw` : réseau de capillaires qui pousse depuis les bords,
  dessiné une fois dans un calque ; des éclats partent des racines, se divisent aux fourches et laissent une traînée qui
  s'éteint). **Magnétisme 6** : looping après trois bobines (rail guidé `look:'track'` dessiné comme une courbe, capture
  seulement si la vitesse ≥ `vmin` = 10 → bobines coupées : 0 gagnant sur 10 506) ; bassin déplacé [96,372,92] ; 241 traits
  gagnants sur 3 480 ; référence 100 % au doigt ; noyau au sommet du J (le rail ne ramasse pas le noyau).
- **R149** — Texture du Magnétisme refaite d'après la vidéo de ferrofluide de Simon (`ferro2`) : plus de goutte/bulle ;
  cinq plages qui dérivent, de tailles et de finesses différentes (cellules fines, moyennes, grandes) ; rendu en veines
  connectées (champ f2−f1 sur grille 96×128, graines rangées par cases, image lissée) + contours fins ; éclats rares qui
  suivent les parois (`fvSparks`), un sur cinq finit en rouge/orangé/pourpre (`WARM`). Mycélium de tous les mondes : plus fin
  (traits 0,42 u, alpha divisé par deux), plus régulier, éclats rares (≈ 1 toutes les 1,5 s, 6 au plus), plus doux, un sur
  cinq vire au chaud.
- **R150** — Simon préfère la texture discrète des niveaux 6 et 12 du Magnétisme : labyrinthe atténué partout (veines 0,2,
  contours 0,38/0,42). Éclats rendus perceptibles (mycélium : ≈ 1 toutes les 0,6 s, 9 au plus ; parois : 8 au plus, plus
  lumineux). Zones de champ magnétique (`VX.bfield`) lisibles : voile rose qui respire, bande de lumière qui balaie, liseré
  en pointillé, coins marqués, symboles ⊙/⊗ plus nets.
- **R151** — Magnétisme : labyrinthe plus présent (veines 0,34, contours 0,6) ; plus aucune bille qui flotte (gouttelettes
  et poussière du ferrofluide retirées) ; mycélium coupé dans ce monde. **Flux d'énergie** (`fvFlow`) : une impulsion naît
  sur une veine (crête du champ f2−f1), suit la crête de case en case, se ramifie aux carrefours, laisse une traînée lissée ;
  une sur cinq glisse vers rouge/orangé/pourpre. Même rendu sur les 12 niveaux du monde (vérifié en planche).
- **R152** — Captures de Simon : le niveau 4 (sans mur) montrait des cellules très marquées, le 12 (beaucoup de murs) presque
  rien, car `ffClear` effaçait la texture à 46 u de chaque mur. Désormais : effacement seulement à 6–28 u des pièces et jamais
  sous 35 % ; contours atténués (0,4 / 0,36). Planche 1, 4, 6, 12 : même densité.
- **R153 — RÉGRESSION CORRIGÉE.** En R147–R148 j'avais appliqué à tout le jeu une demande qui visait le Magnétisme : voiles en
  volume de chaque monde remplacés par une nappe de fils, hélices réduites, réseau capillaire partout. Rétabli : voiles 3D,
  hélices et hélice fantôme comme en R146 ; réseau capillaire retiré (le Magnétisme garde ferrofluide + flux + soie). Ajouts :
  nouvelles formes de voiles par monde (galaxie spirale, nœud de trèfle, réseau cristallin, solénoïde : Soufflerie disk/cyl,
  Mécanique lattice/torus, Gravité disk, Faille et Filaments knot, Quantique lattice/tetra) ; chaque niveau compose ses voiles
  autrement (position, taille, ordre, sens). **Mécanique décorative** (monde 6, `D.mech`, `mechDeco`) : trains d'engrenages
  engrenés, bielle‑manivelle sur glissière, échappement à ancre, came et poussoir, posés hors des pièces de jeu, 4 par niveau.
  **Leçon : une remarque sur un monde ne s'étend jamais aux autres sans le dire.**
- **R154** — Bruit de vent persistant (musique) : les bruits continus du monde 1 (chœur d'air, grondement, frottement de
  `W1N`) gardaient leur dernier volume quand on quittait le niveau (menu, constellation, autre monde). `W1N.hush()` les
  ramène à 0 dans l'état menu et hors du monde 1 ; `W1N.bar` ne joue rien en menu ; constellation et page du monde passent
  la musique en état menu. Ligne de diagnostic du son retirée de l'accueil.
- **R155** — Tracés du joueur en rebond (1) et accélérateur (3) dessinés avec `VX.curve` comme les pièces du niveau (fin, lumineux) au lieu des planches épaisses `plate`/`boostPad`.
- **R156 — Monde 11 Quantique, apothéose (en cours)** :
  - Éléments quantiques redessinés (`visuals.js` : `VX.qent/qgate/qsup/qdet/qtdil`, couleurs par paire `QCOL`) :
    qubit = sphère de Bloch + flèche de spin ; lien en double hélice entre les deux qubits d'une paire (signe = / ≠), fils
    pointillés vers les portes qu'elle commande ; porte fermée = barrière de champ, ouverte = fantôme pointillé ; séparateur =
    losange + franges ; détecteur = diaphragme, armé seulement quand une branche existe, fil vers la paire `d[3]` ; dilatation
    = cadran d'horloge.
  - Moteur : la branche MESURÉE devient la particule réelle ; `det[3]` = rang de la paire basculée par la mesure ; champ `bf`
    7e valeur `'atom'` (halo, orbites, noyau).
  - **126 « L'interféromètre »** : deux chemins qui basculent chacun la paire → la porte reste fermée ; il faut boucher un
    chemin. Sans trait : échec ; solution : réussite + noyau.
  - **132 « Quantix » (finale du jeu)** : particule en orbite fermée dans un « atome » magnétique, séparateur → deux orbites,
    la mesure rend la branche réelle et ouvre la porte intriquée ; le joueur éjecte la particule par un trait de rebond →
    entonnoir, ralenti, porte, bassin. Sans trait : orbite sans fin ; solution : réussite (≈ image 137) + noyau ; 19 % des
    traits de rebond essayés gagnent. Hélices de décor retirées sur ce niveau.
  - **Fin du jeu** : `VX.finale` — onde depuis le bassin, 11 fusées aux couleurs des 11 mondes, constellation des mondes,
    « Félicitations » + sous-titre (i18n `finTitle`, `finSub`, `completeSub`), panneau de résultat retardé de 7,6 s.
  - **Constat** : les solutions de référence de 122–125 et 127–131 échouent (déjà vrai en R155) → ces niveaux sont à refondre.
- **R157 — Magnétisme 1, 2, 7 refaits de zéro** (Simon : 1–4 et 7 « beaucoup trop similaires ») :
  - **85 « La lentille »** (attracteur) : on dévie la particule dans un grand champ qui la recourbe jusqu'au bassin.
    Éditeur 92 %, doigt 60 %, 0 gagnant sans l'aimant. Zone de tracé limitée (`mz`) au champ.
  - **86 « La feuille d'or »** (Rutherford) : nouveau **répulseur** (`mag` à force négative, rendu cyan, grains et ondes qui
    partent du cœur, `engine.js`). Bassin sous un toit : on pousse doucement la particule au bout du toit, le noyau la renvoie
    dessous. Éditeur ≈ 80 % (68–87 % selon le tirage), 0 gagnant sans le noyau.
  - **91 « Le cyclotron »** (Lawrence 1931) : tube d'injection en glace traversable (`curves` m:4, pass:3), champ en vide,
    fente accélératrice (`kick`, inutilisée jusqu'ici) → spirale qui grandit jusqu'au rayon final ; le joueur pose le
    **déflecteur d'extraction**. Sans trait : orbite sans fin (échec à 20 s). Solution ≈ 15 s ; éditeur 82 %, doigt 72 %.
  - **Non faits : 87 et 88 (niveaux 3 et 4)** — essais abandonnés (demi-tour dans le champ, ricochet, dérive g×B, dipôle) :
    trop fragiles ou contournables. Pistes : dérive en boucles (spectaculaire), dipôle attracteur + répulseur.
  - Les niveaux 89, 92–95 suivent encore l'ancien gabarit (aimant au centre, bassin en bas à droite) — non demandés.
  - Prototypes : scratchpad `mg/` (`mg.js` banc, `tune.js`, `fam.js`, `dr.py`).
- **R158 — Contournements** (Simon : « trop facile d'éviter la difficulté », photos Quantique 2 et Filaments 7) :
  - Détecteur `tools/contournements.js` → `docs/AUDIT_CONTOURNEMENTS.md` : **88/132 niveaux** se gagnent d'un trait sans toucher
    aucun élément. Liste classée, à traiter par lots.
  - Corrigés : **122 Opposition** (plancher plein, portes = seuls passages, une seule bascule ; deux = refermé), **112 La balle
    molle** (étagère pleine + entonnoir sur la fente), **115 Molle et lame** (fente puis pointes : 2e trait de rattrapage),
    **100 Portail et mur** (plafond plein, l'élan traverse la faille). Éditeur 70–100 %, 0 victoire nue.
  - **Balle molle** : la compression dans une fente n'avait jamais fonctionné (liens de flexion trop raides) → souplesse par niveau
    (`softball:0.15`, `engine.js`) ; rendu en nuage de points étiré selon la déformation (`VX.softball`).
  - Reporté : 65 Le pendule (ni toit ni barre ne changent l'issue → refonte), puis le reste de la liste.
- **R159 — Contournements, lot 2 (Faille)** — consigne Simon : chaque niveau renforcé gagne un mouvement, une particularité,
  de l'élégance, comme les 6 et 12 :
  - **98 « À travers le mur »** (ex-Portail court) : mur plein, la faille le perce, la parabole se prolonge de l'autre côté.
    Éditeur 83 %, doigt 55 %.
  - **99 « Le geyser »** (ex-Portail montant) : la particule tombe seule dans la faille (rotation 180°) et jaillit plus haut que
    son départ ; le joueur pose le déflecteur qui envoie le jet dans la loge perchée. Éditeur 100 %, doigt 88 %.
  - **103 « La sarbacane »** (ex-Portail et lame) : faille à 90°, une chute droite devient un tir horizontal à travers une
    galerie de lames inclinée vers la chambre du bassin ; on la fait longer le mur pour qu'elle tombe droit. Éditeur 93 %.
  - Tous : 0 victoire nue, 0 gagnant sans la faille. Reportés : 105 Aller-retour, 106 Faille interdite, 65 Le pendule…
- **R160 — lot 3** : **106 « La couture »** (ex-Faille interdite) : faille du centre → réapparition au fond d'une poche
  fermée → roule dans la 2e faille → loge du bassin. Éditeur 85 %, 0 victoire nue.
  - **Essais abandonnés** (limites du moteur à connaître) : (a) « Le bac » pour 70 L'horloge — une barre mobile en diagonale
    porte bien la balle si elle tombe dessus, mais l'embarquement est trop rare (0–4 gagnants), et une barre qui MONTE à travers
    un plancher ne soulève pas la balle (elle passe au travers) ; (b) `pend` (pendule) n'est qu'un DÉCOR, sans physique →
    pas de « marteau » possible pour 65 Le pendule sans écrire une mécanique. Reste à faire : 65, 70, 105 Aller-retour.
- **R161 — Pendule actif + lot 4** :
  - **Moteur** : `pend=[px,py,L,spd,amp,ph,actif,rayon,restitution]` ; `pend[6]=1` → la masse frappe la particule et lui transmet
    sa vitesse (`pendHit` dans `stepBranch`, même calcul que le dessin) ; masse dessinée pleine (`VX.pendulum`). Plusieurs
    pendules possibles. Sans `pend[6]` : décor inchangé (L'échappement).
  - **65 « Le pendule »** : amener la particule au creux de l'arc ; le marteau la frappe, elle grimpe un tremplin jusqu'à un
    bassin plus haut que le départ. Éditeur 87 %, 0 gagnant sans le marteau.
  - **41 « La combe gelée »** (ex-Glace interdite) : un val de glace (la glace ne freine pas) ; posée en douceur sur le rebord,
    la particule remonte jusqu'au bassin perché ; un impact brutal fait perdre l'énergie. Éditeur 97 %, 0 gagnant en piste
    ordinaire.
  - **Détecteur corrigé** : seuil de contact R+5 (au lieu de R+3, plus petit que la distance d'une balle qui roule) →
    **51 niveaux** restent contournables, pas 88. `docs/AUDIT_CONTOURNEMENTS.md` réécrit.
  - Abandonnés (limites, voir l'audit) : Corde tendue en trampoline, Verglas en double val, L'horloge en bac.
- **CONSIGNE DE MÉTHODE (Simon, 12 oct.)** : ne plus abandonner une idée après un long travail. Quand une idée ne tient pas,
  la RETRAVAILLER jusqu'à satisfaction en élargissant la palette (modifier le moteur, ajouter un élément, changer la géométrie,
  combiner des mécaniques) plutôt que de passer à une autre : chaque abandon gaspille le calcul déjà dépensé. Idées en suspens à
  reprendre ainsi : Corde tendue (trampoline), Verglas (double val), L'horloge (bac), Magnétisme 3 et 4, Faille 9 ; Glacier 5
  (combe gelée) jugé beaucoup trop facile.
- **R162 — idées reprises jusqu'au bout (consigne Simon)** :
  - **Moteur** : (1) glace sans perte — sur une courbe de glace (non traversable), un contact rasant (< ~20°) réoriente la
    vitesse sans la diminuer ; un choc franc reste amorti ; (2) adhérence des pièces mobiles `m.grip` (0–1) : la balle suit la
    plateforme (bac porteur) ; (3) cordes réglables par niveau `ropeIter` (raideur) et `ropeDamp`.
  - **41 La combe gelée** durcie : départ au centre, loge du bassin fermée (fente au ras du rebord), bassin à la limite de
    l'énergie : une longue rampe (qui freine) échoue, un court tremplin (vol libre puis glace) réussit. Éditeur 97 %, doigt 72 %,
    intention 38 % (au lieu de 70 %).
  - **46 Verglas** : deux vals de glace et une crête ; marche descendante à l'entrée de la loge ; lèvre de glace allongée.
    Éditeur 93 %, doigt 52 %, 0 gagnant en piste ordinaire.
  - **70 L'horloge** : la particule part posée sur le bac (barre mobile `grip` 0,6) qui fait la navette au-dessus du vide ; le
    joueur pose un butoir au-delà de la portée de la barre, qui se dérobe et lâche la particule dans le bassin. Éditeur 100 %,
    doigt 90 %.
  - **109 Corde tendue** : trampoline — corde du joueur raide (`ropeIter` 10) et sur-élastique (1,25), mur à franchir, murs de
    fond. Éditeur 68–76 %, doigt 80 %.
  - **48 Le pendule de glace** (régression causée par la glace sans perte, réparée et améliorée) : départ posé sur la courbe,
    zone poreuse ±80, seuil 4,5. Éditeur 63–70 % (35 % avant R162) — encore un peu sous 70 %.
  - Détecteur : échantillonnage à chaque image + seuil R+9 (plaques orange plus épaisses) → la Fonderie n'est plus faussement
    signalée.
- **R163 — zones de Pauli + Magnétisme 3 et 4** :
  - **Rendu des zones interdites (idée : principe d'exclusion de Pauli)** : une zone interdite est une région déjà pleine —
    chaque place y est occupée par une paire d'états (spin haut / spin bas), rien d'autre ne peut s'y loger. Rendu
    (`visuals.js` `nd()`) : voile rose-rouge très léger, réseau hexagonal de paires de points liés qui tournent en sens
    opposés, onde lumineuse lente, liseré et deux pulsations qui ne courent que sur les bords exposés (jamais entre deux
    zones accolées) ; un trait refusé (`S.ndHit`, `engine.js`) envoie une onde de refus et un anneau au point touché.
    15 niveaux passent de la zone invisible `mz` à la zone visible `nd` (L'horloge, La lentille, La feuille d'or, La dérive,
    Le cyclotron, À travers le mur, Le geyser, Portail et mur, La sarbacane, La couture, Opposition, Le pendule, La combe
    gelée, Verglas, Corde tendue) — les 132 solutions de référence réussissent toujours.
  - **87 La dérive** (Magnétisme 3) : éditeur 72 %, doigt 80 %, 0 gagnant sans champ.
  - **88 Le dipôle** (Magnétisme 4, remplace « Deux aimants ») : la particule tombe sur un toit plat que le répulseur cyan
    fait rouler À RECULONS, chute dans l'attracteur rose qui l'enroule en crochet jusqu'au bassin. Trop vite → elle est
    capturée en orbite sans fin. Balayage : 169 gagnants avec les deux aimants, 0 avec le répulseur seul, 0 avec
    l'attracteur seul, 0 sans aimant. Solution de référence : éditeur 93 %, doigt 47 %. Noyau (198,428) au creux d'un
    crochet serré : réservé aux lâchers très doux (≈ 25 % des solutions, éditeur 35–65 %), la solution de référence ne le
    prend pas.
  - Magnétisme 1, 2, 3, 4 et 7 sont désormais tous refaits (demande de Simon sur la redondance).
- **R164 — spins agrandis + Soufflerie 4** :
  - Zones de Pauli : motifs agrandis pour l'écran de téléphone (maille 15 → 22, points 1,15 → 1,8, écart de la paire ×1,6),
    demande de Simon.
  - **52 Colonne étroite** refaite (était contournable : 28 gagnants « nus » sur 35). La particule part plus BAS que le bassin :
    sans le courant, aucune énergie ne permet d'y monter (contournement impossible par construction : 0 gagnant sans vent).
    Le courant est mince : une particule qui le traverse en roulant n'est presque pas soulevée. Idée : poser une BUTÉE dans la
    colonne pour que la particule s'y attarde ; elle monte alors contre la butée jusqu'au plafond incliné qui la verse dans
    le bassin. Un seul trait droit : 11 gagnants sur 17 430 (fragile) ; rampe + butée : 60/60 perturbés. Éditeur 100 %,
    doigt 82 % ; noyau (210,286) au ras de la butée dans la colonne : éditeur 97 %, doigt 63 %. Un trait libre en « J »
    est une deuxième famille.
  - **93 Orbite** (Magnétisme 9) — essais NON aboutis, consignés pour reprendre : (1) fronde vers un bassin perché : impossible,
    l'énergie ne suffit pas ; (2) capture puis sortie par un trait : la capture vient du plafond de vitesse VMAX (dissipatif),
    la particule capturée n'a plus l'énergie de ressortir ; (3) zone de tracé réservée à l'intérieur de l'orbite (aucun
    contournement possible sans aimant) : 81 gagnants mais jouabilité 30–45 % (régime chaotique : aimant 1,5 → tout gagne,
    1,8 → tout est capturé) ; (4) coup de pouce rebond / élan dans l'orbite : la sortie part dans toutes les directions.
    Piste suivante : apesanteur locale (`grav` qui annule la pesanteur) pour de vraies orbites conservatives, ou un
    entonnoir de sortie.
  - Note : la solution de référence du Dipôle (88) ne prend pas son noyau (choix délibéré, voir R163) ; à revoir si le
    test du monde 8 l'exige.
- **R165 — ESSAI de rendu « fluctuations quantiques du vide » pour les zones interdites** (document de Simon) :
  - `visuals.js` : `nd()` aiguille selon `ND_MODE` ('vide' par défaut ; 'pauli' rétablit R163/R164, fonction `ndPauli`).
    Rendu `ndVac` : voile rose très léger ; paires matière (rose-rouge) / antimatière (blanc rosé) qui naissent au hasard
    par cellule (Poisson éclairci, sans état), s'écartent puis se rejoignent en accélérant et s'annihilent dans un
    micro-éclair ; plus la paire est énergique, plus elle s'écarte et moins elle vit (ΔE·Δt ≥ ħ/2). Frontière vibrante
    (somme de sinus) et lueur intérieure tracées seulement là où la zone touche l'espace libre (test point par point —
    corrige aussi les côtés à moitié exposés) et jamais sur le cadre. Trait refusé : une antiparticule jaillit, rejoint la
    pointe du trait, deux photons partent dos à dos (e⁺e⁻ → 2γ) avec une onde de choc.
  - Fiche du didacticiel `td_nd` réécrite (FR/EN) : le vide bouillonne, ton trait n'y survit pas.
  - **Écart avec le document** : dans Quantix, la zone interdite refuse le TRAIT ; la particule la traverse librement
    (plusieurs niveaux en dépendent : Le dipôle, L'horloge, La lentille…). La rendre mortelle changerait la règle de 15
    niveaux ; l'annihilation est donc appliquée au trait refusé. La mort de la particule existe déjà (matière « danger »).
- **R166 — zones du vide retravaillées + banc des rendus** (consignes Simon : la zone reste interdite au tracé seulement) :
  - Paires : petits éclairs brisés de deux couleurs opposées (rose-rouge matière, cyan antimatière) qui errent par des routes
    imprévisibles (angle et vacillement tirés par paire), avec une traînée, avant de se rejoindre en un point qui a dérivé et
    de se déliter en poussière d'étoile (9 grains, trois teintes). `visuals.js` `ndVac`.
  - Trait tenté dans la zone (`engine.js` : `S.ndg`, `S.ndgCur`, pointeur) : il s'affiche ~0,25 s en tremblant, blanchit,
    puis se délite en sable cosmique qui tombe et disparaît (~1,2 s) — `VX.ndDust`. Sortir de la zone reprend un trait normal.
    L'encre n'est pas consommée.
  - **Nouvel artefact « banc des rendus »** : tout rendu passe par lui avant validation. Source `studio/galerie-rendus.tpl.html`,
    construit par `python3 tools/build-galerie.py` (inline `visuals.js`) → `quantix-galerie-rendus.html`. Les deux rendus de
    zone (vide, Pauli) y tournent avec un trait de démonstration toutes les 5 s, et on peut y tracer.
  - Dans le jeu (zip) : le rendu du vide et le trait qui se délite sont ACTIFS (`ND_MODE='vide'`), mais marqués à valider ;
    `ND_MODE='pauli'` rétablit l'ancien.
- **R167** : rendu « fluctuations du vide » et trait qui se délite **validés par Simon** et gardés dans le jeu (`ND_MODE='vide'`).
- **R168** : (1) BOGUE corrigé — en R166 l'appel `VX.ndDust` avait été inséré entre le `if` du rendu des zones et son `else`,
  si bien que l'ancien hachurage de secours s'affichait aussi dans le jeu (signalé par Simon) ; (2) paires du vide en
  « comètes » : tête brillante, queue brisée qui suit la route réellement parcourue et s'efface vers l'arrière, lueur légère
  dans la traînée, longueur propre à chaque particule (0,7–1,6 ×).
  - Niveaux en cours d'étude (non intégrés) : 117 Le filet (corde-filet qui cueille une chute rapide vers un socle sans
    rebords : 24 gagnants corde contre 9 structure dans l'essai f2 ; à durcir), 68 L'engrenage (barre porteuse + plaque :
    pas encore de version qui tient). Audit relancé : les niveaux 13, 17, 20 ne sont plus contournables ; restent surtout
    117, 129, 68, 111, 63, 67, 101, 116, 123, 71, 95, 97, 130, 59, 104, 124.
- **R169 — texture du Magnétisme, À VALIDER (pas active dans le jeu)** : les « bords » que Simon voit sont les contours des
  cellules du ferrofluide (`ferro2` : ombre portée + trait coloré + liseré clair, et la bande nette des veines). Interrupteur
  `VX.ffSoft(doux, sansSoie)` (`FF_SOFT`, `FF_NOSILK`, défaut false) : en doux, aucun contour, veines seulement floutées
  (3,5 px et 11 px) ; « sans soie » retire aussi les fils fins (`vlSilkDraw`, monde 8 seulement). Banc des rendus : bouton
  Doux / Doux sans soie / Actuel, et six niveaux (1, 2, 3, 4, 6, 12) avec le vrai fond du monde. Pour activer : mettre
  `FF_SOFT=true` (et `FF_NOSILK` selon le choix de Simon).
- **R170 — texture du Magnétisme REFAITE DE ZÉRO, À VALIDER (pas active)** : demandes et références consignées dans
  `docs/TEXTURE_MAGNETISME.md`. Nouveau rendu `ferro3` (veines de lumière calculées à 1 u, aucun contour, halo sans filtre,
  deux états fondus, impulsions sur les crêtes, sans fils de soie dans ce monde). Interrupteur `F3_ON` (faux) ; banc des rendus :
  Nouveau / Actuel sur six niveaux. L'essai R169 (`FF_SOFT`) est abandonné (jugé pixelisé).
- **R171 — texture du Magnétisme : SIMULATION Gray‑Scott en WebGL 2 (`ferro4`), À VALIDER (pas active)** : voir
  `docs/TEXTURE_MAGNETISME.md` §5. Interrupteur `F3_ON` (faux) ; banc des rendus : Nouveau / Actuel.
- **R172 — ferrofluide vivant VALIDÉ et ACTIF dans le jeu** : attiré par les aimants et bobines du niveau selon leur force,
  couronne autour des répulseurs, gouttelettes de tailles variées en bordure (`docs/TEXTURE_MAGNETISME.md` §6).
- **R173** : ferrofluide sur tout le fond à trois échelles, opacités/luminosités variables, vitesse aléatoire accélérée près
  des aimants (`TEXTURE_MAGNETISME.md` §7). **Bogue** : avec l'outil Droite (éditeur), un trait vers une zone interdite était
  seulement coupé (cadre rouge) — maintenant la partie entrée dans la zone s'y montre puis se délite (`editor.js` : `ghostLine`,
  geste `gline`, `deny` → `S.ndHit`). Effet renforcé (halo, maintien 0,33 s, grains plus gros).
- **R174** : comètes de la zone interdite plus rares (≈ 1/3 de moins), plus fines, taille (0,5–1,25) et opacité (0,25–1) propres à
  chaque paire, éclair d'annihilation adouci, poussière qui s'effondre sur elle-même en tournant (zone morte).
- **R175** : comètes un peu plus présentes (opacité +40 %, un peu plus nombreuses) ; lueur large laissée derrière leur passage,
  qui s'éteint plus lentement que les particules (`glw`) ; à la rencontre, choc électrique délicat (4 arcs brisés qui crépitent
  + anneau fin) avant l'effondrement de la poussière.
- **R176 — raccourcis fermés (outil `tools/ndfix.js N`)** : énumère les traits gagnants (grille du détecteur + 1 800 traits
  au hasard), sépare ceux qui ne touchent aucun élément (« nus ») et cherche 1 ou 2 zones interdites (60–240 u) qui les
  suppriment en gardant les solutions qui passent par la mécanique, jamais sur le départ, le bassin ni la chute initiale.
  Appliqué : 61 Le piston, 63 Piston bas, 97 Le portail, 104 Boucle, 124 Deux possibles, 129 Temps et rebond, 130 Le choix,
  16 La hauteur juste → **0 raccourci** au détecteur ; 67 Métronome, 101 Deux failles, 123 La mesure → **1** restant.
  Ces niveaux n'ont toujours pas de solution de référence (`optsol`) sauf le 16. Sauvegarde : scratchpad `levels.r175.js`.
  Les huit à reconcevoir : sept faits en R177, reste 117 Le filet.
- **R177 — sept niveaux reconçus de zéro** (la mécanique est la seule source d'énergie ou le seul chemin ; 0 gagnant sans
  elle ; solution de référence + noyau ; nom et conseil fr/en ; P_exec mesuré au modèle éditeur) :
  - **59 La tempête** (Soufflerie) : la tempête souffle à gauche plus fort que la pesanteur, le « bas » penche de côté :
    une pente qui MONTE vers la gauche devient une descente. Bassin plus haut que le départ. P_exec 100 %, 1 famille.
  - **68 L'engrenage** (Mécanique) : deux ascenseurs ; le premier ne monte pas assez haut, il faut redescendre vers le
    second au bon moment (pont entre les deux puits). P_exec 77 %, 1 famille, noyau non discriminant.
  - **71 Atelier mobile** : ascenseur puis navette oblique (`mov` avec `grip` 0,15) ; on pose un quai là où la navette
    passe prendre la particule. P_exec 90 %.
  - **93 Orbite** (Magnétisme) : répulseur = ressort (seule énergie), attracteur sous le bassin flottant ; seule, la
    particule se balance sous l'aimant pour toujours ; un mur dans sa course la fait boucler et retomber par-dessus.
    P_exec 100 %, 17 familles.
  - **95 La capture** : même couple ressort/attracteur, autre pensée : lancée trop haut elle est capturée en orbite ;
    un plafond posé sur le ressort la fait passer DESSOUS, l'aimant la hisse dans le bassin. Noyau sur le passage bas
    (48 % des gagnants). P_exec 90 %.
  - **111 Corde et plaque** (Filaments, palette corde seule, `elastic` 1,3, `ropeIter` 10) : la corde rend plus qu'elle ne
    reçoit, rebond après rebond la particule monte dans le puits ; la plaque du haut la renvoie au bassin. Structure : 0.
    P_exec 87 %.
  - **116 Deux cordes** : deux puits, deux pompes en relais ; une seule corde ne suffit jamais (0 gagnant à un trait,
    bande interdite sur la cloison). P_exec 77 %.
  - Mesures : `allsol` 132/132, `difficulty.js` ci-dessus, détecteur de raccourcis 0 « nu » sur les sept, monde1/2,
    replaytest, tutotest, audit, maptest, strict, qprobe OK. Captures regardées (La tempête, plateaux des autres
    derrière les fiches du didacticiel).
  - **117 Le filet : PAS refait.** Essais : corde molle qui retient sur une pente (la structure fait aussi bien avec un coin),
    filet qui attrape une balle rapide (structure : 427 gagnants contre 1 003), périscope à deux cordes élastiques
    (P_exec ≈ 5 %, chaotique). Piste à proposer à Simon dans l'éditeur.
  - Constats moteur utiles : la corde par défaut renvoie 20 % (amortit, plie) ; `elastic` > 1 pompe l'énergie ;
    `ropeIter` 10 rend la corde prévisible ; une chaîne de deux rebonds élastiques précis est injouable au doigt ;
    un attracteur seul ne peut pas faire monter (champ conservatif) : il faut un répulseur pour l'énergie.
  - Scratchpad : `mg/t*.json` (tempête), `e6`, `a15`, `oA`, `cA`, `k2`, `r2` ; outils `abl.js`, `ablm.js`, `arcg.js`,
    `grid2.js` (2e trait, 1er fixé), `rgen.js`/`rgen2.js`/`rgen3.js` (recherche aléatoire de conceptions), `best.js`
    (P_exec des gagnants), `stp.js` (noyau qui partage les gagnants), `pert3.js`. Entrées ajoutées à `tools/forge.json`.
- **R178 — didacticiel holographique, 3 propositions dans le banc des rendus (rien dans le jeu)** : A Projection (fente de
  lumière au-dessus des outils, faisceau, lame qui se déroule sous un balayage), B Visière (aucune surface, voile radial,
  lentille ronde à anneaux d'interférence, rail gradué), C Lame (verre fin en biais, bord irisé tournant, trois plans en
  profondeur). Chacune : fiche « Zone interdite » + consigne « Dévier » + repère, sur captures réelles (`studio/captures/`).
  Source `studio/galerie-holo.html`, injectée par `tools/build-galerie.py` (`__HOLO__`). En attente du choix de Simon.
- **R179 — Simon retient C** avec la surface de A, plus transparente (30 %). Apparition = déploiement mécanique (1,9 s) :
  pivot → rail cranté → montants qui se dressent → trois lames de verre qui se relèvent → équerres verrouillées + bord irisé
  → contenu ; repli inverse 1,2 s ; durées × `--sp` (bouton « Ralenti ×4 »). Toujours dans le banc seulement, pas en jeu.
- **R180 — essai « Mât »** (classe `.dep2`, par défaut dans le banc ; bouton pour revenir au « Rail ») : origine en bas au
  centre de l'écran → tige qui traverse la barre d'outils → mât jusqu'en haut de la fiche → deux volets de verre qui
  pivotent autour du mât vers les côtés, rails et montants suivent → verrous, bord irisé, contenu (1,9 s). Repli inverse.
- **R181 — essai « Tiroirs »** (`.dep3`, par défaut) : consigne de Simon, RIEN ne passe sur l'éditeur de ligne (origine juste
  au-dessus des outils ; la tige du Mât est supprimée aussi). Mât qui monte lentement-vite-lentement, graduations cran par
  cran ; puis 4 rangées de tiroirs sortent de part et d'autre, de bas en haut, easing (.72,0,.18,1) = départ doux,
  accélération, atterrissage en douceur ; arête lumineuse + poignée par façade, cote « ◂ 339 u ▸ » qui compte l'ouverture,
  grains qui s'échappent du mât. 2,8 s ; fermeture 2 s (tiroirs du haut vers le bas, puis le mât redescend).
- **R182 — essai « Tiroirs verticaux »** (`.dep4`, par défaut) : fente qui s'ouvre au-dessus des outils, puis 4 tiroirs
  qui montent l'un après l'autre en sortant de derrière celui du dessous (même courbe partout : départ doux, accélération,
  atterrissage doux) ; arête + poignée + glissières par façade, jointures fines au repos, cote de hauteur réelle (« ▴ N u »,
  mesurée en JS), montants qui suivent. 3 s. FERMETURE = miroir exact ×0,85 : texte (bas → haut), verrous, tiroirs (le dernier
  sorti rentre le premier), montants et cote, fente, origine. Bogue corrigé : `--n` doit être posé sur `.hc`/`.hk`
  (sinon les calc du bord irisé et du texte sont invalides et ces pièces apparaissent d'emblée).
- **R183** — Simon : les déploiements mécaniques sont trop compliqués, pas assez fluides (mis de côté, gardés dans le banc).
  Retour à **B Visière**, avec la démonstration dans une grande fenêtre (pleine largeur × 156 px au lieu de la lentille de
  96 px) : sans bordure, bords dissous dans le voile, franges d'interférence fines, 4 repères d'angle ; apparition = mise au
  point (flou → net) + franges qui se resserrent + repères qui se posent, puis titre condensé (1,1 s). À valider.
- **R184** — Visière : vignette réduite (76 % × 116 px) ; ouverture en un seul geste (ligne de lumière au centre → la fiche
  s'ouvre vers le haut et le bas, courbe expo) ; fermeture = même geste inversé ; vignetage des bords de l'écran
  (`.hvig`, via `:has(.hc.in)`), plus léger pour une consigne. À valider.
- **R185 — audit du didacticiel** (`docs/AUDIT_DIDACTICIEL.md`) + solution « Visière adaptative » dans le banc (4 niveaux
  témoins, calcul en direct) : projecteur sur l'élément, contour tracé, position/format calculés, voile ajusté au fond, outils
  regroupés. Source `studio/galerie-audit.html` (injectée avec `__HOLO__`), captures `studio/captures/h*.jpg`. Pas dans le jeu.
- **R186 — DIDACTICIEL VISIÈRE ADAPTATIVE DANS LE JEU** (validée par Simon) : `tuto.js` (fiche « Tes outils » au lieu de 4,
  `vsPlace` position/format calculés sur la vraie géométrie, `vsVeil` voile d'après les pixels de `#cv`, `vsSpot` projecteur
  dans `#tshield`, `vsOutline` contour tracé `#tout`, ouverture depuis une ligne `.tvl`, fermeture `vsClose`, attente 0,7 s,
  `frStart` neutralisé, anneaux de cible remplacés), CSS bloc R186 en fin de `quantix.css`, i18n `tt_tools`, `td_tools`,
  `cat_tools`, `ts_*` FR/EN, `index.html` (`.tvl`). Tests mis à jour : tutotest (fiche outils), e2e-didacticiel (2 fiches,
  24 entrées d'explications : le 23 était périmé depuis la paroi tunnel) → 38/38. Captures regardées (niveaux 2, 3, 49, 1).
  Non regardé : monde 8 (WebGL trop lent sans GPU).
- **R187 — audit de l'interface** (`docs/AUDIT_INTERFACE.md`) + maquette d'accueil Visière avec héros animé, pause,
  paramètres, barres d'outils harmonisées (banc des rendus). Pas dans le jeu.
- **R188 — accueil Visière + héros « L'odyssée » (DANS LE JEU)** : `assets/js/hero.js` (nouveau, global `QHERO`) : boucle
  de ≈ 20 s, la particule jaillit d'un vortex et traverse les 11 mondes (trait qui se trace, plaques de rebond sur lave,
  looping, pont de glace + tremplin, colonne d'air + cyclone, escalier mécanique qui monte, gravité renversée avec roulis de
  caméra, fronde magnétique, faille + portails, corde-tremplin + harpe, dédoublement + détecteur), tombe dans le bassin qui
  s'ouvre en vortex et reboucle. Fonds : `assets/img/hero/h01–h11.jpg` (540 px, tirés de `assets/img/worlds`). Branché dans
  `engine.js hStep` (l'ancienne simulation reste en secours si `QHERO` manque). Accueil : héros plein cadre (64 % de
  hauteur), marque en haut, nom du monde traversé sous la devise, bouton « Continuer » à sous-ligne (monde · n / 12 · nom,
  `#hContSub`), lignes Constellation / Quantone / Paramètres, statistiques ; ouverture animée (CSS, bloc R188 en fin de
  `quantix.css`). i18n `continueQ`. `build-apercu.py` : `hero` embarqué + option `home` (aperçu ouvert sur l'accueil).
  Vérifié : audit, strict, tutotest, monde1/2, replaytest, maptest, qprobe, savetest, e2e-didacticiel 38/38, e2e-editeur
  25/25, e2e-son 7/7 ; captures 390×844, 375×667, 1280×800, anglais. Non fait : passage du héros au banc des rendus,
  harmonisation pause/paramètres/codex/Quantone/barres (maquettes seulement).
- **R189 — odyssée retouchée (retour de Simon)** : vortex d'arrivée refait en disque d'accrétion texturé (`vortexQ` : 340 grains
  aux couleurs des onze mondes en arcs elliptiques, horizon sombre, anneau de photons, arc de lentille, bras en pointillés,
  arcs électriques ; il se referme au départ). Chocs : bibliothèque d'impacts du jeu exportée (`VX.impact` / `VX.impacts`
  dans `visuals.js`), doublée sur les chocs forts, éclair local + onde double, écrasement de la particule, secousse et arrêt
  sur image de 60 ms. Fonds plus sombres (opacité .6, vignette renforcée). Décors du jeu ajoutés : poussière d'étoile
  (`VX.flow`, Atelier), chambre à bulles (Fonderie), puits d'espace-temps (`VX.well`, Gravité), corral de la faille
  (`VX.rift`), lame de superposition + détecteur (`VX.qsup`, `VX.qdet`), ciel étoilé à l'arrivée.
- **R190 — odyssée fluide** : départs/arrivées de segments jamais à vitesse nulle (`ease` adouci), plus d'éclair blanc ni
  d'arrêt sur image, secousses réduites ; la boucle passe par l'horizon (le vortex s'élargit, l'image plonge dans le noir,
  le départ en émerge). **Audit de l'espace de jeu** (`docs/AUDIT_ESPACE_JEU.md`) : la toile est limitée par la LARGEUR sur
  tous les téléphones récents ; prototype « Plein cadre » (`studio/proto-plein-cadre.css/.js`, injecté seulement par
  `build-apercu.py … plein`) : reflet flou du rendu jusqu'aux bords, coins repères, titre sur une ligne, étoiles retirées,
  fil d'énergie dans l'écran, outils en icônes en Visière. **Pas dans le site** : en attente de validation.
- **R191 — dans le site** : panneaux Visière (bloc R191 de `quantix.css`, aucune balise changée) pour bilan, pause, paramètres,
  explications, constellation, atelier : voile en vignette, verre sombre, repères de coin, ligne de lumière, poussière qui
  dérive, titre qui s'allume, lignes à chevron au lieu des pilules secondaires, bouton principal en lumière, ouverture en
  cascade. Bulle « Zone interdite » retirée du tracé à la droite (`editor.js`). Astuce du bas cachée ; elle apparaît en
  hologramme après 3 lâchers sans réussite ou 45 s (`HINT`, `hintCheck` dans la boucle — pas de minuterie, sinon les tests
  node ne s'arrêtent plus). Prototype plein cadre : marge de zone sûre du haut retirée (l'aperçu dans l'application Claude en
  déclarait une fausse). Tests : audit, strict, tutotest, monde1, replaytest, e2e-didacticiel 38/38, e2e-editeur 25/25.
  À voir : les textes d'aide de la relecture et de la solution passent aussi par l'astuce, donc cachés pour l'instant.
- **R192 — dans le site** : bilan sans titre ni phrases : en-tête animé par issue (`VX.resAnim` dans visuals.js : win/complete
  spirale + colonne + satellites d'or, sol géodésique, out paquet d'ondes hors cadre, spike annihilation, stuck puits de
  potentiel amorti, long lemniscate + cadran) ; critères en trois médaillons, mesures en deux chiffres (i18n `r_matter`,
  `r_time`) ; actions en tuiles icône + mot : État initial, Bifurquer, Trajectoire, Géodésique, Poursuivre (i18n FR/EN
  changés) ; pause en tuiles. Astuce holographique dans l'en-tête à la place du titre (12 s, toucher le titre la rappelle).
  Prototype plein cadre : contours en dégradé comme l'accueil, titre discret. **MENU édition** :
  https://claude.ai/artifact/63wuCq6jdpwN6i7PWmyNkk (`python3 tools/build-menu.py` → `studio/menu-edition.html`, style
  `tools/menu-style.css`, docs `docs/menu-docs.json`) — à donner à CHAQUE tour, republier seulement s'il change.
- **R193 — dans le site** : animation de victoire renforcée (hélice lumineuse, éclosion, 16 rayons, triple onde, gerbe de
  90 éclats, couronne d'orbites, constellation des trois critères reliés). Livré : zip du site seul (demande de Simon).
- **R194 — dans le site** : PLEIN CADRE intégré (bloc R194 de quantix.css, `pfLayout` dans engine.js ; l'option `plein` de
  build-apercu est désactivée). Astuces retirées (`hintShow` neutralisé, `.tip` caché). Didacticiel apaisé : niveau 1 sans
  fiche, consigne seule dès l'ouverture (étape 0 « Les bases » qui cède au premier trait ou après 8 s), jamais sur l'en-tête,
  ni sur la particule ou le noyau ; pointes nommées sur le terrain et marquées vues en fin d'intro ; une notion par niveau
  (« Tes outils » attend un niveau sans élément nouveau) ; 1,8 s avant une fiche ; zone interdite en un seul contour
  (`ndEdges`, bords exposés) ; voile des fiches en flou + assombrissement d'arrière-plan (la ligne nette au bord du voile venait
  du dégradé : supprimé). Énergie relevée pour que la solution de référence soit traçable : #34 → 420, #72 → 300,
  #84 → 270, #116 → 320 (aucun raccourci « nu » au scan). Quantone : barre Écouter collante (toujours visible), un trait
  sélectionné change d'instrument en touchant une puce (annulable), consigne de Dupliquer complétée. Tests : audit, strict,
  tutotest, monde1/2, replaytest, maptest, savetest, e2e-didacticiel 38/38, e2e-editeur 25/25, e2e-quantone 12/12,
  e2e-quantone-editeur 9/9. Non republié : l'artefact Quantone séparé (le Quantone du jeu et de l'aperçu est à jour).
- **R195 — dans le site** : fiches du didacticiel en verre OPAQUE (bloc R195 de quantix.css : panneau sombre plein, voile
  supprimé, repères de coin gardés). Plus de partie guidée au niveau 1 : fiches « Les bases » puis « Pointes » (onLoad, et
  `mark('basics')` pose l'intro faite). Zones interdites retirées des niveaux 2 et 3 (le 1 n'en avait pas) → « Tes outils »
  au niveau 2, « Zone interdite » au niveau 4. Mesure : #2 Le pont a désormais 33 traits droits gagnants dont 1 « nu »
  (contourne l'idée) ; #3 23 gagnants, 0 nu. Tests adaptés (tutotest, e2e-didacticiel 32/32, e2e-editeur 25/25 sur le
  niveau 5). Banc des rendus : section R195 (`studio/galerie-r195.html`, captures `studio/captures/r195_*.jpg`).
- **R196 — dans le site** : fiche holographique = proposition A du banc (bloc R196 de quantix.css + éléments `.hd` dans
  #tcard : émetteur, faisceau, poussière, rails, ligne de lecture, filament, relevé `#thud` ; pied `.hfoot` onde + bouton).
  Verre translucide sombre et flouté. Déploiement : émetteur → rails → panneau déroulé (clip-path) → coins → texte ; fermeture
  inverse ; `htop` (vsPlace) met le projecteur du côté du bord. Niveau 2 « Le pont » : pilier [150,0,150,112] (0 trait « nu »,
  P_exec 100 %), conseil FR/EN mis à jour. Fiche « Zone interdite » au niveau 4 « Le relais » (premier niveau où les zones
  dessinent tout le couloir). Banc : section R196 avec animation WebP capturée dans le jeu (`studio/captures/r196_*`).
- **R197 — dans le site** : vignettes des fiches au rendu fin de la proposition A (tuto.js : `neon`, `wall`, `zone`, `cup`,
  `dball` redessinés en traits fins, sol en perspective qui défile dans `demoLoop`, courbes des scènes en traits fins) ; plus
  de quadrillage plat CSS. Banc republié (animation et captures refaites).
- **R198** : décor des fiches toujours à l'encre cyan (`--hk:#4DD7FF`), la couleur de l'élément reste sur la pastille et les
  mots-clés. Éditeur de niveaux reconstruit avec les niveaux actuels (aperçu `1 11 skipintro` + `studio/editeur-niveaux.js`
  injecté avant `</body>`, titre « Quantix Éditeur », capacités db + downloads conservées) et republié. Menu édition : liens
  en `target="_top"` (ouverture dans la visionneuse Claude, à confirmer sur iPhone) ; les liens sont aussi redonnés dans chaque réponse.
- **R199** : délitement du trait dans la zone interdite en grains ronds et fins (visuals.js `ndDust` : plus de carrés), trait
  instable plus fin. Fiche « Zone interdite » : démonstration propre `ndDemo` (tuto.js, d'après la proposition A) — le trait
  entre, tremble, se délite en sable ; paires qui s'annihilent ; la particule contourne.
- **R200** : Constellation sans défilement (carte 2:3 dimensionnée sur la hauteur disponible, « Fermer » collant). Rappel : le
  PLEIN CADRE est actif dans le site depuis R194 (bloc R194 de quantix.css + `pfLayout`).
- **R201** : (1) vortex du héros allégé (340 → 210 grains, bras 46 → 30 segments). (2) MENU édition : `target=_top` ne
  s'ouvrait pas dans l'app iPhone → lien simple + adresse visible + bouton « Copier » ; toujours donner les liens en clair.
  (3) **Audit de ton** : didacticiel (ti_*, td_*), sous-titres de carte, aide de la frise et 6 conseils du monde 1 réécrits
  courts et énigmatiques (une règle, un verbe), FR et EN. Règle : ≤ 80 signes, pas de lyrisme, la physique dite en une image.
  (4) **Fin du jeu** : `VX.finale` refaite sans texte — « Naissance » : onze comètes aux couleurs des mondes s'enroulent dans le
  bassin, le point se charge puis se contracte, la particule naît au centre d'un disque d'émission qui glisse au milieu de
  l'écran, le ciel s'allume, la constellation des onze mondes se trace ; l'interface du niveau s'efface (`#app.fin`). À
  500 images, **générique holographique** `#vFin` (même langage que la fiche A) : « Elle est réelle. », crédits, bouton
  Ko-fi (`var KOFI=''` dans engine.js : vide = bouton masqué), « Bilan » ouvre le panneau de résultat. (5) Dette réglée : plus
  de français en dur pour la maîtrise (oneShot / usedRewind[s]).
- **R201 b — audit externe (GPT) vérifié** : `render.js` affichait OK malgré « VX is not defined » (le banc Node ne
  rendait pas `window.VX` global) → corrigé dans `load.js`, et le banc échoue désormais sur toute erreur de rendu.
  `bypass.js` : 33 / 97 contournables, tous dans les mondes 5 à 11 (50 53 55 56 58 · 61 62 63 64 67 69 · 77 79 80 81 82 83 ·
  89 92 94 · 104 107 · 118 119 · 121 123 124 125 126 127 128 130 131) — c'est la liste de travail de la refonte 7→11, puis 5–6.
  Faux positifs : images `hero/h01–h11` (chemin construit dans hero.js) ; `user-scalable=no` voulu (le pincement gênerait le tracé).
  Tableau de suivi encore calculé sur `difficulty_R116.json` : à recalculer monde par monde pendant la refonte.
- **R202 · fin du jeu refaite en scène cinématique** (R201 jugée kitsch par Simon : guirlande, matières pauvres). Prélude de
  1,5 s dans le niveau (`VX.finale` : le niveau s'assombrit, le bassin se charge), puis **`QHERO.epilogue`** (hero.js) en plein
  écran sur `#finCv` : le bassin d'arrivée émerge du noir → la particule remonte l'odyssée À REBOURS (8 s, les décors se
  défont) → le vortex de départ se rouvre et l'avale → puits harmonique fait d'une paroi du jeu : période fixe, énergie qui
  décroît, un photon aux couleurs d'un monde à chaque niveau quitté (n = 10 → 0) → état fondamental (point zéro, nuage |ψ₀|²).
  Le texte vient quand l'état fondamental est atteint : « ÉTAT FONDAMENTAL · n = 0 / Équilibre. / Toute l'énergie est rendue.
  Il ne reste que le frémissement du vide. » **Crédits retirés** (Simon : texte final à creuser plus tard). Ko-fi : code prêt,
  bouton masqué (`KOFI` vide). Aperçu de la fin : `build-apercu.py 1 11 skipintro fin`.
- **R202 · règles des fiches du didacticiel** (bug : après la fin du jeu, toutes les fiches du monde Quantique s'affichaient —
  la fiche « en attente » du dernier niveau survivait à la réussite). Règles écrites en tête de `onLoad` (tuto.js) : (1) une
  fiche ne s'ouvre qu'à l'arrivée dans un niveau, avant le premier lâcher ; (2) seulement les notions de CE niveau jamais
  expliquées ; (3) niveau déjà réussi : aucune fiche ; (4) deux fiches au plus par arrivée ; (5) la fiche en attente est
  abandonnée au lâcher, à la réussite, à l'échec ou en quittant. Mémoire = sauvegarde du jeu (même stockage que la
  progression) : effacer les données du site ou changer d'aperçu (chaque version d'artefact a sa propre mémoire) = tout
  réexpliquer.
- **R203 · NARRATION décidée (choix C, `docs/NARRATION.md`)** : paire intriquée née à l'horizon (le vortex du héros), la
  nôtre s'échappe ; la fin = retrouvailles, puis fentes de Young où chaque niveau réussi devient un point (Tonomura).
  **Épilogue refait** (`QHERO.epilogue`, remplace R202 « puits ») : poursuite de RETOUR (11 → 1, ×1,15) avec une figure par
  monde absente du héros (tunnel, corps mou, univers recousu, cyclotron, assistance gravitationnelle, pendule, allée de
  Kármán, bosses de glace, anneau de stockage, chambre à bulles, ricochets) + fil d'intrication vers l'origine ; horizon :
  la jumelle émerge, spirale avec ondes, nuage bistable ; plaque de détection : un point puis un point par niveau réussi
  (couleur du monde, `opts.solved` depuis `S.best`), franges révélées. Texte : « INTRICATION · UN SEUL ÉTAT / Réunies. /
  Chaque point est une de tes expériences. » ≈ 25 s. L'aperçu `fin` marque tous les niveaux réussis.
- **R204 · fin refaite d'après Simon** : la compagne (aspect de la branche de superposition) naît au monde Quantique du
  retour et fait toute la poursuite (harmonie ↔ séparation, caméra qui recule pour le couple) ; Glacier = demi-lune avec
  caméra qui se balance/zoome ; fusion à l'horizon puis **danse dans une sphère** (3D, sans texte, bouton Bilan seul).
  Écran des fentes supprimé. Détail dans `docs/NARRATION.md`. ≈ 18 s de poursuite + 2,6 s de fusion + danse (bouton à 7 s).
- **R205 · fin moins linéaire** : rythme variable (ralentis/accélérations), cadrages variés, Gravité avec tour de caméra complet, accélérateur linéaire, paire en V, double hélice, danse à quatre figures (`docs/NARRATION.md` § R205).
- **R206 · fin « un seul mouvement »** : compagne en canon/valse au lieu des miroirs, un seul basculement (Gravité), transitions de fin continues, décors mécaniques et hélices du jeu réutilisés (`VX.mech`, `VX.helix`, `VX.torusCells` exportés de visuals.js). Détail : `docs/NARRATION.md` § R206.
- **R207** : Gravité = basculement aller-retour (plus de tourbillon) ; les particules plongent dans le trou noir, puis la sphère ; titre QUANTIX qui apparaît en haut pendant la danse (`fin_title`). Zip livré pour déploiement ; aperçu non republié.
- **R208 · bilan du parcours** : journal `JR` (engine.js, sauvegardé avec la progression, clé `jr`) : temps de jeu (écran de jeu visible, hors Zen), lâchers, échecs, réussites, traits, matière engagée dans les réussites (unités d'encre), reprises. Bilan final (`#vResult.jfinal`) : grille de 9 mesures — étoiles x/396, expériences x/132, parfaites (3 étoiles), matière tracée, temps, lâchers, échecs, traits, reprises. Libellés i18n `jr_*`. Les parties antérieures à R208 partent de zéro pour ces compteurs (étoiles et expériences, elles, viennent de la sauvegarde existante).
- **Reste** : fiches des outils Échelle et Aimant ; scènes simulées pour les éléments quantiques ; machines du monde 3
  (Chaîne 3 et 9 proposés) ; mondes 7 à 11.
- **À faire (demandé par Simon)** : (1) didacticiels harmonisés, non codés en dur ; (2) deux machines manquantes du monde 3
  à base de matière poreuse (niveaux à confirmer avec Simon).
- Connu, non traité : zone de réussite non propre aux niveaux 21 et 34.

## Aperçu

MENU édition (tous les outils, à donner à chaque tour) : https://claude.ai/artifact/63wuCq6jdpwN6i7PWmyNkk

Banc des rendus à valider : https://claude.ai/artifact/YLLD3eGHDLFWP3k44nfMxW (`python3 tools/build-galerie.py`, republier à la même adresse).

Adresse unique : https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC. R188 : ouvert sur l'accueil, tout débloqué (`build-apercu.py 1 11 home`) ; éditeur : https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp. Pour juger
les machines 3 et 6, republier le monde 1 (`python3 tools/build-apercu.py 1`).

## Outils utiles

`tools/rail.js` (courbes harmonieuses), scratchpad de conception des machines recopié dans `tools/fiches/machines/*.json`,
`tools/courts.js N` (traits courts gagnants), `tools/monde1.js`, `monde2.js`, `replaytest.js`, `zonepropre.js`,
`difficulty.js`, `enigme.js`, `constance.js` (`EX/EY/EY2/ER`).

## Décisions attendues de Simon

0. **Adresse Ko-fi** et libellés des crédits (nom affiché, autres contributeurs) pour le générique.
1. Périmètre de la première version publiée (proposition : mondes 1 à 4, une machine par monde, la finale).
2. Connecter le dépôt GitHub du site (fin des zips et des tampons) ?

## Prochain lot proposé

**Demande de Simon (R201)** : refonte des niveaux des mondes 7 à 11, « progressivement mais sûrement », un monde à la fois,
sans allers-retours. Commencer par le monde 7.


Faille 9 « Aller-retour » (aucune idée qui tienne encore) ; Le pendule de glace à porter à 70 % ; suite de la liste
de `AUDIT_CONTOURNEMENTS.md` (Le filet, Temps et rebond, L'engrenage, Corde et plaque, Orbite, Piston bas, Métronome,
Colonne étroite, Deux failles…). Puis : avis de Simon sur 126, 132 et la fin du jeu ; puis refonte des niveaux 121–125 et 127–131 du monde Quantique avec
les éléments clarifiés (un élément nouveau ou une combinaison nouvelle par niveau, progression vers 126 et 132).
