# QUANTIX — La narration (choix C, R203 ; fin revue R204)

> **Statut R209 : référence (histoire décidée R203–R207 ; proposition R209 dans AUDIT_R209.md §13).** Voir `INDEX_DOCUMENTS.md`.


*Décidé avec Simon le 13 octobre 2026. Complète `QUANTUM_VISUAL_NARRATIVE.md`, dont le fil (« la particule remonte
l'histoire de la physique ») reste le décor ; ce document donne **le but**. Aucun texte visible ne raconte l'histoire :
elle se lit dans les images (héros, fin) et, plus tard, dans quelques mots concis.*

## L'histoire en trois temps

1. **La séparation (le héros, à l'accueil).** Au bord d'un horizon, le vide crée une paire de particules intriquées.
   L'une s'échappe : c'est la nôtre. Sa jumelle reste de l'autre côté. Le vortex du héros *est* cet horizon.
   — Interprétation artistique du rayonnement de Hawking (paires créées à l'horizon, partenaires intriqués).
2. **La traversée (les onze mondes).** La particule traverse les salles d'expérience. Le lien ne se rompt jamais :
   intrication = corrélation sans contact (mesures d'Aspect, 1982 ; prix Nobel 2022).
3. **Les retrouvailles (la fin du jeu).** Elle repart vers l'origine par un autre chemin, à travers les mêmes mondes
   mais d'autres expériences ; le fil qui la relie à sa jumelle s'éclaire à mesure qu'elle approche. À l'horizon, la
   jumelle émerge ; elles spiralent l'une vers l'autre et ne font plus qu'un seul état. Cet état unique traverse deux
   fentes et frappe un écran : **un point**. Puis chaque expérience réussie par le joueur s'y rallume en point, et la
   figure d'interférence apparaît (Tonomura, 1989 : franges construites électron par électron).

## La poursuite de retour (épilogue, `QHERO.epilogue`)

Même principe que le héros (scènes de 360 × 480 côte à côte, caméra qui suit, illustrations des mondes), dans l'autre
sens, avec une figure par monde **absente du héros** :

| Monde | Héros (aller) | Retour |
|---|---|---|
| Arrivée | bassin, vortex | la particule se soulève du bassin |
| Quantique | dédoublement, détecteur | **effet tunnel** à travers une barrière (paquet d'onde, reflet partiel) |
| Filaments | corde-tremplin, harpe | **corps mou** qui se comprime pour passer une fente plus étroite que lui |
| Faille | portails | **univers recousu** : sort par le bas, rentre par le haut |
| Magnétisme | fronde autour de l'aimant | **cyclotron** : spirale qui grandit, extraction tangente |
| Gravité | plafond porteur | **assistance gravitationnelle** autour d'une planète |
| Mécanique | marches qui montent | **pendule** qui la frappe et la relance |
| Soufflerie | colonne d'air, cyclone | **allée de tourbillons** derrière un cylindre (Kármán) |
| Glacier | pont qui gèle | **bosses de glace** franchies sans frottement |
| Chaîne | looping, tapis | **anneau de stockage** en perspective, lumière synchrotron tangente |
| Fonderie | plaques, lave | **chambre à bulles** : trace en spirale, plaque chaude qui la relance |
| Atelier | trait tracé | **ricochets** sur des traits qui s'allument, jusqu'à l'horizon d'origine |

## R204 — la compagne et la danse (décision de Simon)

- La compagne a l'aspect de la **branche de superposition du jeu** (balle teintée violette, 94 %, opacité 0,72, traîne de
  points violets, frange pointillée entre les deux). Elle **naît au monde Quantique** du retour (dédoublement dans une zone
  de superposition) et fait tout le retour avec la particule.
- Dynamique propre, tantôt **harmonieuse** (miroirs, contre-phase, patineuses), tantôt **séparée** pour franchir un autre
  obstacle ou le même autrement ; la caméra recule pour les garder toutes deux. Par monde : Quantique (l'une traverse le temps
  dilaté, l'autre la barrière par effet tunnel) · Filaments (deux fentes, une chacune) · Faille (elles se croisent par les
  coutures) · Magnétisme (charges opposées, spirales en miroir) · Gravité (l'une dessus, l'autre dessous la planète) ·
  Mécanique (l'une frappée par le pendule, l'autre le survole) · Soufflerie (contre-phase dans l'allée de tourbillons) ·
  Glacier (demi-lune de glace, deux patineuses, caméra qui se balance et zoome aux croisements, sortie en coup de fouet) ·
  Chaîne (faisceaux contrarotatifs, collisions) · Fonderie (création de paire, spirales opposées) · Atelier (ricochets à deux
  étages).
- **Fin** : à l'horizon d'origine elles tournent l'une autour de l'autre et se refondent ; **leur réunion crée une sphère**
  dans laquelle elles dansent sur des grands cercles qui précessent (rotations à trois dimensions, profondeur rendue par la
  taille et l'éclat, axe pointillé qui les relie par le centre). **Aucun texte** ; un seul bouton « Bilan » apparaît.
- L'écran des fentes (R203) est abandonné.

## R205 — moins linéaire (retours de Simon)

- **Rythme** : le temps de la poursuite n'est plus constant — ralentis aux moments forts (dédoublement, deux fentes, choc du
  pendule, création de paire, rencontre à l'Atelier), accélérations (sortie du Glacier, fin de l'accélérateur).
- **Cadrage** : plan large d'ouverture, gros plans (dédoublement, pendule en contre-plongée), plans larges (coutures de la
  Faille, sortie du Glacier), à-coup de recul à chaque changement de monde, roulis et cadrages décentrés.
- **Gravité** : elles orbitent la planète en sens contraires et la caméra fait **un tour complet** avec elles, en plan large.
- **Chaîne** : plus de boucle — **accélérateur linéaire** en diagonale montante, neuf cavités qui s'allument à leur passage,
  elles s'y tressent et accélèrent (traits de vitesse, caméra qui recule et pivote).
- **Fonderie** : plus de spirale (redite du cyclotron) — **création de paire en V** : traces de bulles courbées en sens
  opposés, l'une rebondit sur une plaque incandescente.
- **Atelier** : **double hélice** — elles en sont les deux brins, le trait du joueur se trace devant elles, des barreaux
  restent derrière ; profondeur rendue par la taille.
- **Danse** : quatre figures enchaînées (antipodes sur grands cercles qui précessent → poursuite sur la même orbite →
  orbites croisées → loxodromies d'un pôle à l'autre).

## R206 — un seul mouvement (retours de Simon)

- **Plus de symétrie** : le couple bouge comme un seul geste. La compagne suit en canon (Faille, Magnétisme dans le même
  paquet du cyclotron, Gravité sur la même orbite, Glacier en patineuse derrière), tourne autour de la particule comme une
  danseuse (Mécanique, Soufflerie), ou se sépare seulement quand l'obstacle le justifie (Quantique, Filaments, paire en V
  de la Fonderie). Sa position est toujours lissée : aucun saut entre deux mondes.
- **Caméra** : un seul grand basculement, réservé à la Gravité (tour complet) ; ailleurs, plus de roulis (balancement
  à peine perceptible au Glacier). Recul et gros plans conservés, mouvements de caméra plus doux, secousses divisées par deux.
- **Transitions de fin** : l'accélérateur sort dans le sens de la Fonderie (sommet du V dans l'axe), Fonderie et Atelier
  plus longs, ralentis plus doux ; l'origine s'ouvre déjà pendant la montée en hélice, la fusion enchaîne sans coupure
  et sans écran noir jusqu'à la danse.
- **Décors du jeu réutilisés** (`VX.mech`, `VX.helix`, `VX.torusCells`) : trains d'engrenages, échappement à ancre,
  bielle-manivelle et came du monde Mécanique ; hélices de l'Atelier ; cellules du tore de la Chaîne ; poussière en
  parallaxe sur tout le retour.

## R207 — trou noir et titre

- Gravité : la caméra **bascule** (jusqu'à ≈ 110°) au plus fort de l'orbite puis revient — plus de tour complet.
- Fin : les deux particules décrivent le disque du trou noir d'origine et **y plongent** ; il se referme ; la sphère naît.
- Pendant la danse, **QUANTIX** apparaît délicatement en haut, lettre après lettre (i18n `fin_title`), un fin trait violet
  dessous. Bouton « Bilan » seul, plus tard.

## R209 — proposition de clarification (à valider par Simon, `AUDIT_R209.md` §13)

- **Une seule origine de la compagne** : née à l'horizon avec la particule (le héros doit montrer 2 s de séparation au
  début de sa boucle) ; perdue de vue ; **retrouvée** au monde Quantique (où elle devient une mécanique : mouvements
  anti-corrélés, portes qui demandent une mesure commune), puis l'épilogue.
- **Le noyau** devient un fragment de l'état commun : le ramasser fait apparaître un instant l'écho violet de la jumelle.
- **Une phrase par monde** (titre de salle, ton concis et énigmatique), par exemple : Atelier « Le trait est matière. » ·
  Fonderie « Ce qui frappe rend plus. » · Chaîne « L'élan se transmet. » · Glacier « Rien ne freine. » · Soufflerie
  « L'invisible pousse. » · Mécanique « Tout bat la mesure. » · Gravité « Le bas change. » · Magnétisme « Attirer sans
  toucher. » · Faille « L'espace se recoud. » · Filaments « La corde répond. » · Quantique « Deux chemins à la fois. »
- Titre de travail : « Quantix — l'autre moitié ».

## R214 — option A : la grammaire du héros (décision de Simon, 16 octobre 2026)

**Pourquoi** (diagnostic de la régression R210–R213) : la fin des bancs fin2→fin5 éparpillait la lumière (4 à 8 petits
éléments par plan, 3–4 couleurs, deux particules qui forçaient la caméra à reculer, schémas plutôt qu'objets), dans un
moteur à part, corrigé par ajouts sur des images fixes, sans jamais être comparé au héros. Simon choisit l'option A.

**Règles (mesurables, à vérifier sur chaque plan)** : un seul grand élément par monde ; la couleur du monde et le blanc ;
la caméra du héros (serrée sur la particule du joueur, 40 u d'avance dans le sens du mouvement, zoom 1 → 1,12 aux
poussées) ; la traînée du héros (26 points) ; les fonds du héros (opacité 0,6, vignette) ; aucun ralenti ; un seul
basculement léger (Gravité, ≈ 20°) ; arrêt sur image de 90 ms aux chocs forts. **La compagne est une invitée** : elle
n'entre dans le cadre qu'à quatre moments et en ressort par un bord.

| Monde | Le grand élément | Le geste | La compagne |
|---|---|---|---|
| Arrivée | le bassin | il se charge et la relance | — |
| Quantique | une barrière de lumière | effet tunnel : l'onde se partage | **naît** : la part réfléchie repart en arrière |
| Filaments | une corde tendue | elle tombe dessus ; l'impulsion transverse la porte, se réfléchit inversée au nœud | — |
| Faille | deux bouches (bas, haut) | elle plonge en bas, ressort en haut | sort de la bouche du haut juste avant elle |
| Magnétisme | le cyclotron (deux dés) | spirale à fréquence constante, poussée à chaque intervalle, extraction tangente | — |
| Gravité | une planète à anneau | survol hyperbolique (2ᵉ loi de Kepler), caméra qui penche | — |
| Mécanique | le pendule armé | elle roule sur la corniche, il la frappe | — |
| Soufflerie | un cylindre dans le vent | elle slalome dans l'allée de Kármán | — |
| Glacier | deux bosses de glace | glisse sans frottement | la rattrape, la saute, file devant |
| Chaîne | l'accélérateur linéaire | sept cavités s'allument, accélération | — |
| Fonderie | la plaque incandescente | choc, la plaque rougeoie | — |
| Atelier | deux traits qui se rejoignent | le trait du joueur mène à l'horizon d'origine | descend l'autre trait ; elles se rejoignent |

Puis fusion dans le trou noir et danse dans la sphère (R207, inchangées). Code : `hero.js` bloc R214 (`ZA`, `decoA`,
`epChaseA`), actif seulement si `window.QFIN_A` : **le jeu garde R207 tant que Simon n'a pas validé**. Banc :
`python3 tools/build-banc-finA.py` → `studio/banc-finA.html` (héros et fin côte à côte, à la même seconde ; bouton
« Jeu actuel (R207) »). Retour = 18,3 s ; total ≈ 30 s.

## R215 — retour à la base R213 (décision de Simon, 16 octobre 2026)

R214 (option A) est rejetée : rendu jugé pauvre, éléments inventés (planète, dés du cyclotron, bob du pendule…) qui ne
sont pas ceux du jeu. Gardés : **la vague** (Filaments). Repris de la nouvelle discussion (banc R213) : escaliers qui
montent et propulsent, magnétron avec rotation de caméra, cyclone de glace, et le reste de fin5. **Règle ajoutée** : la fin
ne dessine que la charte du jeu — fond animé du monde (`VX.back`), murs du jeu (`VX.curve`), éléments du jeu (`VX.gzone`…),
aucun objet inventé.

## Texte final (provisoire, non affiché depuis R204)

« INTRICATION · UN SEUL ÉTAT » — « Réunies. » — « Chaque point est une de tes expériences. »

## Sources

- Hawking S. W. (1974). *Black hole explosions?* Nature 248, 30–31.
- Aspect A., Grangier P., Roger G. (1982). *Experimental realization of Einstein-Podolsky-Rosen-Bohm Gedankenexperiment.*
  Physical Review Letters 49, 91.
- Tonomura A. et al. (1989). *Demonstration of single-electron buildup of an interference pattern.* Am. J. Phys. 57, 117.
- von Kármán (allée de tourbillons), Lawrence (cyclotron, 1931) : culture générale, à sourcer avant tout texte visible.

## Pistes ouvertes

- Héros : montrer la jumelle qui reste derrière l'horizon au départ (aujourd'hui absente).
- Monde 11 : la jumelle comme mécanique (déplacements anti-corrélés) — à étudier pendant la refonte.
