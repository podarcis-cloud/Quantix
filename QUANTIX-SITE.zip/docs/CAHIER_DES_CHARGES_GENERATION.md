# QUANTIX — CAHIER DES CHARGES DE LA GÉNÉRATION DE NIVEAUX

> **Statut R209 : référence pour §17–§25 (langue visuelle) ; le reste est historique.** Voir `INDEX_DOCUMENTS.md`.


*Version 3 (R79). Document opposable. Il remplace `CAHIER_DES_CHARGES_NIVEAUX.md` (v1) et s'appuie sur `BIBLE_ENIGMES.md`
(le savoir, sources [S‑n]). Hiérarchie : **la Bible explique pourquoi, ce cahier dit ce qu'on fait et comment on le vérifie.**
Ajout de cette version, demandé par Simon : les **buts intermédiaires** et les **machines** — des séquences où le décor
prend la particule en charge dans un mouvement spectaculaire, avant de la rendre au joueur ou de l'amener à l'arrivée.*

---

## 1. La promesse de Quantix

Chaque niveau offre **deux plaisirs** qui se répondent :
1. **Comprendre** — une énigme unique, référencée, dont l'idée renverse une hypothèse du joueur (Bible II, III).
2. **Contempler** — la physique du monde mise en scène : quand le joueur a compris, le monde lui **répond** par un mouvement
   beau et surprenant.

Le premier est une conquête, le second une récompense. Martin Jonasson et Petri Purho appellent « jus » ce qui rend une
interaction satisfaisante : maximum de retour pour un minimum d'action [S‑42]. Folmer Kelly met en garde contre le jus pour
le jus, qui peut briser l'immersion ; chaque matière doit sentir ce qu'elle est [S‑43]. **Règle : le spectacle doit toujours
dire la physique du monde, jamais la décorer.**

---

## 2. Architecture d'un niveau : les actes

Un niveau est une suite d'**actes**. Quatre briques :

| Brique | Code | Définition | Qui agit |
|---|---|---|---|
| **Zone jouable** | ZJ | partie du niveau où le joueur trace ; elle porte une énigme | le joueur |
| **Relais** | RL | but intermédiaire : un **récepteur** visible où la particule doit entrer | le joueur l'atteint |
| **Machine** | MA | séquence automatique déclenchée par le relais : le décor emporte la particule (manège) | le niveau |
| **Arrivée** | AR | la plateforme de fin | — |

### Formes autorisées
| Forme | Schéma | Usage |
|---|---|---|
| **Simple** | ZJ → AR | énigme pure ; la majorité des niveaux de début de monde |
| **Relais** | ZJ → RL → MA → AR | l'énigme est d'atteindre le relais ; la machine conclut en spectacle |
| **Deux actes** | ZJ1 → RL → MA → ZJ2 → AR | la machine dépose la particule dans une seconde zone jouable : **deuxième énigme**, souvent conditionnée par la première |
| **Finale** | ZJ → RL → MA longue → AR | fin de monde : la grande machine qui résume la physique du monde |
| **Machine‑énigme** | ZJ (lire la machine) → RL → MA → … | la machine est **visible et prévisible** ; l'énigme consiste à anticiper où elle va projeter la particule (« lire le manège ») |

**Règle de proportion (par monde de 12)** : 5 à 6 Simples, 3 à 4 Relais, 1 à 2 Deux actes, 1 Finale (position 12). Au
moins **une** Machine‑énigme par monde à partir du monde 3.

---

## 3. La machine — cahier technique

### 3.1 Fonctions dramatiques (au moins une, écrite dans la fiche)
- **Récompense** : la réussite de l'énigme déclenche un mouvement ample (montagnes russes, cascade de rebonds, toboggan).
- **Transition** : emmener la particule vers un second acte, en **montrant** pendant le trajet l'espace de la seconde énigme.
- **Révélation** : la machine montre une propriété du monde que le joueur utilisera ensuite (ex. le tapis lance à 40 u de haut).
- **Respiration** : une pause dans le rythme du monde (Taylor : « une respiration du rythme » est une raison d'être [S‑15]).
- **Signature** : la finale de monde est la machine qui le résume.

### 3.2 Règles absolues
1. **Déterminisme** : la machine produit **toujours** la même trajectoire et la même sortie, quelles que soient la vitesse et
   l'angle d'entrée dans le relais. Une machine qui dépend de l'entrée est une ZJ déguisée. *Moyen* : le **rail guidé**
   (§3.4) ; à défaut, une machine physique vérifiée sur 200 entrées perturbées sans écart de sortie.
2. **Non‑traçable** : aucune matière ne peut être posée sur le trajet de la machine (zone interdite automatique), sinon elle
   devient un raccourci ou un moyen de casser le spectacle.
3. **Pas de raccourci par la machine** : la machine n'est accessible **que** par son relais (rail fermé, entrée unique).
4. **Lisibilité** : la machine est **visible dès le départ** (elle est la promesse du niveau) ; le relais est clairement
   identifiable comme but (forme et couleur dédiées, distinctes de l'arrivée).
5. **Durée** : 1,5 à 6 s. Au‑delà, le joueur attend ; en deçà, il ne voit rien.
6. **Pas d'échec dans la machine** : une machine ne tue jamais la particule. L'échec appartient aux zones jouables.
7. **Rejouabilité** : un toucher **accélère** la machine (×3) dès qu'elle a déjà été vue une fois dans ce niveau.
8. **Énergie** : la machine ne consomme pas d'énergie du joueur ; la particule ressort avec une vitesse **définie par la
   machine**, pas par l'entrée.

### 3.3 Esthétique et chorégraphie
- **Courbe de vitesse** : lente à l'entrée (on comprend que « ça part »), accélération, **apogée** (sommet d'une boucle,
  saut, chute libre), décélération lisible à la sortie.
- **Lignes** : courbes continues (pas d'angles), boucles, spirales, montées‑descentes ; pensées pour l'écran vertical d'un
  téléphone.
- **Son** : la machine joue une **phrase musicale** accordée sur l'échelle du monde (un arpège qui monte avec la vitesse) ;
  le relais a son propre son d'entrée (Audit son, §1.6).
- **Lumière** : le rail s'allume au passage ; traînée de la particule ; la sortie déclenche un éclat discret.
- **Identité de monde** (machine type) :

| Monde | Machine type |
|---|---|
| 1 Atelier | rail de bois clair, spirale descendante |
| 2 Fonderie | cascade de plaques de rebond en escalier |
| 3 Chaîne | boucle complète portée par les tapis (looping) |
| 4 Glacier | toboggan de glace en lacets |
| 5 Soufflerie | ascenseur d'air puis glissade |
| 6 Mécanique | ascenseur à piston, roue à godets |
| 7 Gravité | looping où la gravité s'inverse à l'apogée |
| 8 Magnétisme | orbite autour d'un aimant puis libération |
| 9 Faille | portails en série (téléportations rythmées) |
| 10 Filaments | catapulte de corde |
| 11 Quantique | dédoublement : deux trajectoires qui se recombinent |

### 3.4 Éléments techniques nouveaux (à implémenter dans le moteur)
| Élément | Description | Paramètres |
|---|---|---|
| **Récepteur** (relais) | entonnoir visible ; la particule qui y entre est captée (sa vitesse est annulée) | position, largeur d'ouverture, orientation |
| **Rail guidé** | trajectoire en courbe (suite de points lissée) que la particule suit à une vitesse imposée, sans physique libre | points, profil de vitesse, sortie (position, vitesse, angle) |
| **Lanceur** | fin de rail qui rend la particule à la physique avec une vitesse précise | vitesse, angle |
| **Zone interdite automatique** | générée autour du rail et du récepteur | marge |
| **Accélération de revoir** | toucher pendant une machine déjà vue | facteur |

*Le rail guidé garantit le déterminisme (§3.2‑1) quelle que soit la physique ; il est rendu comme un objet physique du monde
(bois, verre, tapis…), pas comme une ligne abstraite.*

### 3.5 La machine dans l'énigme
- **Machine‑énigme** : la sortie du lanceur est **visible avant de jouer** (une flèche fantôme, ou une démonstration au
  chargement) ; la seconde zone jouable demande de **préparer** l'arrivée de la particule (pont, butée, déflecteur) **avant**
  de la lâcher. Le joueur trace donc les deux actes d'un coup, en lisant la machine.
- **Deux actes conditionnés** : l'idée de ZJ1 (ex. « arriver lentement ») change l'entrée du relais… mais pas la sortie
  (déterminisme). Pour conditionner ZJ2, on utilise **deux relais** : selon celui atteint, la machine dépose la particule à des
  endroits différents (choisir son relais = choisir son second acte).
- **Interdit** : une machine qui résout à la place du joueur (le relais ne doit pas être plus facile à atteindre que
  l'arrivée elle‑même sans machine — sinon le niveau est trivial).

---

## 4. L'énigme — règles (synthèse de la Bible)

1. **Phrase de solution** ≤ 15 mots, qui dit une vérité du système [S‑5][S‑15].
2. **Hypothèse du joueur qui tombe** (H‑xx, Bible IX.2), différente de celles du reste du monde.
3. **Leurre** : la première idée probable, qui échoue **lisiblement**, et dont le joueur se sent responsable [S‑13].
4. **Scénario de résolution** : « il essaie A, échoue parce que B, comprend C ».
5. **Rôle de chaque élément** : PORTER, FERMER (raccourci nommé), PIÉGER, BRUIT voulu [S‑15].
6. **Aucun raccourci** (recherche active, la « vitre » de *Portal* [S‑17]).
7. **Jamais de précision** : jouable « avec les pieds » [S‑15].
8. **Espace de recherche petit** : l'impasse doit arriver vite [S‑11].
9. **But clair** : la difficulté porte sur le comment [S‑15].
10. **Eurêka, pas fiero** [S‑12].

---

## 5. Référentiels

### 5.1 Types de raisonnement (R‑01 à R‑20)
Repris de la v1 (Découvrir, Ponter, Sauter, Inverser, Rattraper, Doser, Relayer, Protéger, Éviter, Détourner, Boucler,
Orienter, Économiser, Contre‑pied, Synchroniser, Tracer en vol, Utiliser le danger, Choisir, Combiner, Synthèse) — **plus** :
| Code | Type | Ce que le joueur doit comprendre |
|---|---|---|
| R‑21 | **Lire la machine** | anticiper où la machine va projeter la particule et préparer l'arrivée |
| R‑22 | **Choisir son relais** | deux relais, deux machines, deux destins : un seul mène à l'arrivée |

### 5.2 Hypothèses du joueur (H1 à H16) — Bible IX.2
Ajouts liés aux machines :
| # | Hypothèse | Niveau qui la fait tomber |
|---|---|---|
| H17 | « la machine me sauve » | elle me dépose au‑dessus du vide : c'est à moi de préparer la suite |
| H18 | « le relais est le but » | il y a deux relais ; le plus proche mène à l'impasse |

### 5.3 Stratégies de création — Bible IV.3 (22 stratégies de Traynor, traduites)

---

## 6. Gabarit de monde (12 niveaux) et enchaînement

| Pos. | Temps | Forme conseillée | Rôle |
|---|---|---|---|
| 1 | Ki | Simple | enseigner la vérité du monde sans mots |
| 2 | Ki | Simple | renforcer |
| 3 | Ki | **Relais** | première machine : **révélation** de la machine type du monde |
| 4 | Shō | Simple | combiner avec les mondes précédents |
| 5 | Shō | Simple | première impasse sérieuse |
| 6 | Shō | **Relais** | machine‑récompense |
| 7 | Ten | Simple | retournement : la mécanique gêne |
| 8 | Ten | **Machine‑énigme** | lire la machine (R‑21) |
| 9 | Ten | Simple | seconde face de la vérité |
| 10 | Ketsu | **Deux actes** | deux idées du monde, reliées par la machine |
| 11 | Ketsu | Simple ou Relais | moment unique |
| 12 | Ketsu | **Finale** | la grande machine du monde ; rappel renversé du niveau 1 |

**Enchaînement des mondes** : la finale d'un monde **dépose** la particule dans le décor du monde suivant (dernière image
du monde N = première du monde N+1) ; le niveau 1 du monde N+1 reprend une hypothèse déjà tombée et montre qu'avec la
nouvelle vérité elle revient autrement.

---

## 7. Étalonnage des mécaniques (mesuré, `tools/banc.js`)

| Mécanique | Mesure | Règle de conception |
|---|---|---|
| Changement de pente jointif | 99–107 % de vitesse conservée de 10° à 90° | les arrêts viennent de bouts qui dépassent et de fentes < 30 u |
| Tapis | ≈ 40 u de hauteur gagnée, quelle que soit sa longueur | interrupteur, pas amplificateur |
| Rebond | 150–200 % de la hauteur de chute | crée de l'énergie : ne jamais l'offrir sans fermer les raccourcis |
| Saut depuis la glace | 96 u de portée après 60 u de descente (137 u après 120 u) | dimensionner les vides |
| Colonne d'air | soulève de 500 à 700 u | il faut une composante latérale pour en sortir |
| Vent latéral | ≈ 24 u par 0,1 de force sur 200 u de chute | un vent de 0,2 fait manquer une zone de 60 u |
| **À mesurer** | gravité locale, aimant, portails, parois mobiles, corde, effets quantiques, **rail guidé** | avant de concevoir leurs mondes |

---

## 8. Jouabilité mobile et accessibilité
- Tolérance : la solution tracée à la ligne droite avec ±3 u aux extrémités réussit ≥ 85 %.
- Aucune fente < 30 u ; aucun élément décisif < 20 u ; zones de toucher ≥ 44 pt.
- L'énigme se lit en 10 s ; la machine se voit dès le départ.
- Énergie : 1,2 à 1,3 × la solution de référence.
- Aucune information portée par la couleur seule (forme + couleur).
- Machines accélérables ; aucune machine > 6 s.

---

## 9. Pipeline de génération

| Étape | Livrable | Responsable | Outil |
|---|---|---|---|
| 0. Étalonner la mécanique du monde | table de mesures | moi | `banc.js` |
| 1. Écrire les 12 fiches du monde (phrases, hypothèses, formes, machines) | registre du monde | moi | — |
| 2. **Valider les fiches** | accord ou corrections | **Simon** | — |
| 3. Concevoir chaque énigme à rebours (solution → restrictions) | géométrie minimale | moi | `fiche.js`, `fview.py` |
| 4. Chercher les raccourcis, poser une « vitre » par raccourci | rôles FERMER | moi | `enigme.js` |
| 5. Construire la machine (rail, récepteur, lanceur) et sa chorégraphie | machine déterministe | moi | moteur + `banc.js` |
| 6. Habiller : son, lumière, identité du monde | rendu | moi | `visuals.js`, `sound.js` |
| 7. Contrôles P1–P10 | rapport | moi | outils |
| 8. Banc d'essai (aperçu) | lien de test | moi | `build-apercu.py` + panneau |
| 9. **Test** : premier essai, impasse, « Aha », autre chemin | notes | **Simon** | — |
| 10. Itérer ; transformer chaque raccourci trouvé en variante possible | — | moi | — |
| 11. Intégrer au jeu, tampon de version | zip | moi | — |

---

## 10. Portes de validation

| Porte | Question | Preuve |
|---|---|---|
| P1 | Phrase de solution claire, vérité du système | fiche |
| P2 | Hypothèse différente du reste du monde | registre |
| P3 | Leurre qui échoue lisiblement | simulation + capture |
| P4 | 0 raccourci | `enigme.js` |
| P5 | 0 élément inutile | `enigme.js` |
| P6 | Jouable « avec les pieds » | `fiche.js` (P_ligne) |
| P7 | Impasse rapide (espace de recherche petit) | revue |
| P8 | **Machine** : déterministe (200 entrées perturbées → sortie identique), non traçable, non raccourci, ≤ 6 s | banc machine |
| P9 | **Forme et proportion** respectées dans le monde (§2, §6) | registre |
| P10 | Le scénario « A → B → C » se réalise chez le joueur | **test de Simon** |

**Définition de « fait »** : P1 à P10 validées. Avant P10 : « candidat ».

---

## 11. Fiche de niveau (v3)

```
Référence : Q-MM-PP · Titre fr/en · Temps (Ki/Shō/Ten/Ketsu) · Raison d'être
Forme : Simple | Relais | Deux actes | Finale | Machine-énigme
Vérité du système :
Phrase de solution (≤ 15 mots) :
Type de raisonnement (R-xx) · Hypothèse qui tombe (H-xx) · Stratégie de création (Traynor)
Leurre et raison visible de son échec :
Scénario : « il essaie A, échoue parce que B, comprend C »
Éléments et rôles (PORTER / FERMER : raccourci nommé / PIÉGER / BRUIT voulu) :
Raccourcis et leur vitre :
Énergie et matières offertes :
MACHINE (si forme ≠ Simple)
  Fonction dramatique : récompense | transition | révélation | respiration | signature
  Tracé (rail, points) · durée · profil de vitesse · apogée · sortie (position, vitesse, angle)
  Son (phrase musicale) · lumière · identité du monde
  Contrôle de déterminisme (200 entrées) :
Mesures (banc, fiche.js, enigme.js) :
Variantes (plus facile / plus dure / retournement) :
Test de Simon :
```

---

## 12. Anti‑modèles
Solution = première idée · élément décoratif · matière offerte qui ouvre tout · niveaux jumeaux · difficulté par
imprécision · génération combinatoire sans intention · échec illisible · **machine qui dépend de l'entrée** · **machine qui
résout à la place du joueur** · **machine trop longue** · **spectacle sans rapport avec la physique du monde** (jus pour le
jus [S‑43]).

---

## 13. Plan de mise en œuvre technique (machines)
1. Moteur : élément `rail` (points lissés, vitesse imposée, capture/libération), `recepteur`, `lanceur`, zone interdite
   automatique, accélération au toucher. Format dans `levels.js` : `rails:[{pts:[…],v:[…],out:[x,y,vx,vy]}]`,
   `relais:[[x,y,w,dir]]`.
2. Rendu : rail matérialisé selon le monde, allumage au passage, traînée, éclat de sortie.
3. Son : phrase par monde, déclenchée au relais, accordée à la vitesse.
4. Outils : `banc.js` — test de déterminisme des machines ; `enigme.js` — le rail et ses abords sont exclus des tracés et
   l'entrée du rail ne doit être atteignable que par le relais.
5. Prototype : un niveau **Relais** dans le monde 1 et une **Finale** dans le monde 3, présentés au banc d'essai avant toute
   généralisation.

---

## 14. Sources ajoutées (les autres : Bible, partie X)
[S‑42] Game Developer, « Is your game juicy enough? » — Jonasson & Purho, GDC Europe 2012
[S‑43] Game Developer, « Indies, resist the urge to juice it or lose it » — Folmer Kelly, GDC Europe 2014
[S‑44] Andy Matuschak, notes sur *The Incredible Machine* (contraintes et progressions comme échafaudage cognitif)
[S‑45] Giant Bomb, concept « Rube Goldberg Puzzler » (corpus : *Armadillo Run*, *Contraption Maker*, *Crazy Machines*, *Marble Madness*…)


## 15. État de la mise en œuvre (R80)
- **Fait dans le moteur** : rail guidé (`lv.rails = [{in:[x,y], r, pts:[[x,y]…], v:[départ, milieu, fin], out:[vx,vy]}]`),
  courbe lissée (Catmull‑Rom), vitesse imposée, capture par le relais, lanceur, zone non traçable de 20 u autour du rail
  (jeu, éditeur et outils), rendu (tube lumineux, traverses, allumage au passage, relais doré pulsant), sons `rail_in` /
  `rail_out`. Fonctions : `railBuild`, `railStep`, `railCatch`, `drawRails` (`engine.js`).
- **Vérifié** : déterminisme — 200 solutions différentes entrent dans le relais, **une seule** trajectoire après la sortie ;
  trajet complet dans le jeu réel (relais → rail → zone → réussite) ; toute la non‑régression passe.
- **Prototype** « Le relais » (fiche `tools/fiches/9.js`) : présent **uniquement dans le banc d'essai**. Limite connue : de
  petits déflecteurs (15 à 40 u) font rebondir la particule dans le relais — l'énigme d'accès est encore trop simple ; le
  prototype sert à juger la machine, pas l'énigme.
- **Pas encore fait** : accélération au toucher (§3.2‑7), phrase musicale accordée à la vitesse, identité visuelle par monde,
  relais doubles (R‑22), outil `banc.js` de test machine intégré.


## 16. Révision R81 — la machine est PHYSIQUE (décision de Simon)
« L'idée n'est pas d'ajouter un rail visible, mais d'utiliser les éléments physiques du niveau pour créer un trajet
impressionnant de type montagnes russes. » En conséquence :
- **Le rail guidé n'est plus utilisé** dans les niveaux (le code reste dans le moteur, inactif). §3.4 est remplacé par :
  une machine est **composée des éléments du monde** (murs, glace, tapis, rebonds, vent…), sans objet dédié.
- **Comment garantir un trajet toujours identique sans rail** : par des **normaliseurs** — des éléments qui effacent les
  différences d'entrée : l'**entonnoir** (relais) qui calme la particule ; le **tapis**, qui ramène toujours la vitesse à la
  même valeur ; la **paroi de retournement** ; la cuvette. Mesure exigée (P8) : sur 200 entrées différentes, ≥ 98 % arrivent
  au bout de la machine, et l'écart de position à la sortie ≤ 10 u.
- **Zone de machine** (`mz` dans `levels.js`) : rectangles **non traçables mais invisibles** — la machine reste un décor
  physique, sans hachures (jeu, éditeur et outils).
- **Prototype « La grande descente »** (fiche `tools/fiches/9.js`, banc d'essai uniquement) : entonnoir → quatre tapis en
  lacets entre deux parois → tremplin au‑dessus des pointes → zone. Mesure : **197 entrées sur 200 (99 %)** arrivent ;
  écart au tremplin 6 u. Énigme d'accès encore trop simple (un trait de 81 à 120 u suffit) — à travailler.
- `tools/build-banc.py` reconstruit le banc d'essai (aperçu + panneau + prototype).


## 17. Éléments courbes et composition graphique (R82)

**Élément courbe** (`lv.curves = [{pts:[[x,y]…], m:matière}]`) : une courbe lissée devient pour la physique une suite de
segments jointifs de ~9 u, et pour l'œil **une seule pièce continue** (`VX.curve`) qui parle le même langage que les éléments
droits : bande de profondeur 12 u, surface lumineuse, treillis pour la structure, cellules animées pour le tapis, reflet pour
la glace ; aucune jointure visible. Matières courbes : structure (0), rebond (1), tapis (3), glace (4).

**Règles physiques des courbes (apprises sur le prototype)**
1. Un virage se prend **par l'intérieur** (côté creux) : la particule doit arriver contre la face concave, jamais rouler
   sur le dessus d'un arc (elle s'envole).
2. Le haut de chaque virage **se recourbe** au‑dessus de l'arrivée (lèvre) pour contenir la particule rapide.
3. Toute piste qui reçoit la particule d'une chute doit avoir une **butée galbée** à son extrémité opposée au sens du tapis.
4. Mesure obligatoire (P8) : ≥ 98 % d'arrivées sur 200 entrées différentes ; noter la durée médiane.

**Composition graphique (cohérence avec le jeu)**
- **Lecture en diagonale** : départ en haut d'un côté, arrivée en bas de l'autre ; la machine relie les deux par un
  mouvement ample (vague, lacets, spirale).
- **Respiration** : la zone jouable garde un espace dégagé (le tiers haut de l'écran) ; la machine n'empiète pas sur le
  geste du joueur.
- **Rythme** : alterner droites (tapis) et courbes (virages) ; répéter un motif (lacets) avec une variation finale
  (toboggan, saut).
- **Hiérarchie** : la zone d'arrivée et le relais sont les éléments les plus lumineux ; la machine est en retrait (matières
  sombres, surfaces fines), elle s'anime quand la particule passe.
- **Une seule langue visuelle** : mêmes matières, mêmes épaisseurs, mêmes reflets pour les pièces droites et courbes.

**Prototype « La grande descente » v3** (banc d'essai uniquement) : entonnoir galbé → butée galbée → trois tapis en lacets
reliés par trois virages en demi‑lune → toboggan de glace → tremplin → zone. Mesure : **196 arrivées sur 200 (98 %)** ;
durée médiane du trajet complet 427 images (≈ 7 s), 90 % sous 738 images (≈ 12 s) — **trop long au‑delà du médian**,
à resserrer (§3.2‑5 : machine ≤ 6 s).
Correctif annexe : les outils simulent désormais **1 200 images**, comme le jeu (900 auparavant).


## 18. Composition d'or et machines de monde (R83)

Demande de Simon : « composition hyper importante — symétries, nombre d'or, équilibre, zones qui respirent, ne pas
surcharger, créer des sauts ou des combinaisons. »

**Grille de composition (écran 360 × 480)**
- Axe de symétrie : x = 180. Lignes d'or : x ≈ 137,5 et 222,5 ; y ≈ 183 et 297 (480/φ et 480 − 480/φ). Tiers : y = 160, 320.
- Les éléments **porteurs** (pistes, virages) s'alignent sur les lignes d'or ; les **pôles** (entonnoir, zone) sur l'axe.
- **Respiration** : une bande dégagée au moins (ici le haut, pour le geste ; et le centre bas, scène du saut final).
- **Sobriété** : deux pistes, deux virages, un saut — pas davantage pour une machine de niveau ordinaire.
- **Miroir** : les virages droit et gauche sont exactement symétriques (le gabarit les calcule l'un de l'autre).
- **Saut** : chaque machine se termine par un **tremplin** suivi d'un vol au‑dessus d'un vide (pointes), cueilli par un
  **dosseret galbé** qui dépose la particule dans la zone.

**Gabarit `tools/fiches/lacets.js`** : entonnoir sur l'axe → butée galbée → piste haute (ligne d'or 183) → virage droit
avec lèvre → piste basse (ligne d'or 297) → virage gauche en miroir → glissade → tremplin → saut → dosseret → zone sur l'axe.
La matière des pistes et des virages suit le monde.

**Trois prototypes (banc d'essai uniquement)**, mesurés avec `tools/constance.js` (200 entrées différentes) :

| Monde | Matière | Arrivées | Durée médiane | Dans le jeu |
|---|---|---|---|---|
| 1 Atelier | poutres, pistes inclinées (pente 18) | 197/200 (99 %) | 434 images | réussi en 6,2 s |
| 3 Chaîne | tapis à plat, virages en poutre | 197/200 (99 %) | 396 images | réussi en 5,5 s |
| 4 Glacier | glace partout (pente 10) | 197/200 (99 %) | 455 images | réussi en 6,5 s |

**Leçons** : (1) la lèvre d'un virage trop basse coince la particule contre la piste (garder ≥ 40 u) ; (2) un saut final
sans dosseret est trop sensible à la vitesse : le dosseret rend la fin constante ; (3) la version en miroir complet du
Glacier tombait à 84 % — à étudier avant d'utiliser des niveaux inversés.

**Limites** : les trois prototypes partagent la même composition (seule la matière change) ; l'énigme d'accès (une rampe
vers l'entonnoir) est triviale. Prochaine étape : composer **des machines différentes par monde** (identité §3.3) sur la
même grille d'or, et une vraie énigme d'accès.


## 19. Trois histoires, trois machines (R84) — retour de Simon : « le même scénario trois fois ; les murs arrondis ne sont pas satisfaisants »

**Règle ajoutée** : dans un même lot, **jamais deux prototypes sur le même gabarit**. Chaque niveau a sa propre histoire
d'accès, sa propre machine et sa propre composition.

**Pièces courbes redessinées** (`VX.curve`) : construites à abscisse curviligne constante — treillis de Warren régulier (un
triangle tous les 13 u), profondeur toujours du même côté (opposé à la face de roulement), dégradé de la surface vers la
profondeur comme la poutre droite, rail lumineux et liseré clair, embouts arrondis ; glace : bloc translucide avec un reflet
qui court ; tapis : cellules régulières.

**Les trois prototypes (banc d'essai uniquement)**

| Monde | Titre | Accès (énigme) | Machine | Composition | Constance | Jeu |
|---|---|---|---|---|---|---|
| 1 Atelier | Les collines | un **pont** au‑dessus d'un gouffre | piste de poutres en **vague** : descente concave, vallée, **décollage** au sommet de la colline, dosseret galbé, zone | une grande ondulation en S de l'entonnoir (haut gauche) à la zone (bas droite) | 200/200 | 4,2 s |
| 3 Chaîne | L'ascenseur | **laisser tomber** puis jeter la particule sur le tapis (déflecteur au pied ; la colonne de chute est non traçable) | **escalator** : tapis incliné à 40° qui la remonte et la lance sur un balcon | V ouvert : la chute verticale répond à la diagonale du tapis ; le balcon sur la ligne d'or basse | 200/200 | 2,0 s |
| 4 Glacier | Le grand tremplin | une **rampe** jusqu'à l'entonnoir de la piste d'élan | rampe de glace raide → tremplin → **long vol** au‑dessus du vide central → grande réception galbée → zone | deux « C » qui se répondent ; le centre vide est la scène du vol | 193/200 (97 %) | 6,0 s |

**Ce que la physique a appris (à respecter)** : une courbe roulée **par‑dessus** ne doit jamais se courber vers le bas (la
particule s'envole) — descentes **concaves** (raide puis douce) ; une piste qui se courbe vers le bas ne se prend que **par
l'intérieur** ; un **entonnoir** fixe le point de chute et rend la suite constante ; un **tapis incliné** est un escalator ;
une zone **fermée des deux côtés** pour recevoir une particule qui arrive en glissant.


## 20. Finition des pièces courbes (R85)

`VX.curve` dessine désormais une pièce de piste en sept couches : ombre portée floutée ; suspentes fines vers le haut tous
les ~90 u (comme les poutres droites) ; corps en dégradé et membrure basse ; traverses perpendiculaires, treillis de Warren
régulier et rivets aux nœuds ; rail de roulement en **tube** (ombre, teinte, reflet) ; **lampes** tous les 18 u qui
s'allument à l'approche de la particule, plus une lueur lente qui parcourt la piste au repos ; **platines d'about**
boulonnées. Glace : bloc translucide, strates de givre, scintillements, sans treillis. Tapis : galets qui tournent.
Vérifié en capture haute définition (×3) dans le jeu.


## 21. Bibliothèque de connecteurs et unification des murs (R86)

**Une seule langue visuelle** : les poutres droites (structure) et la glace droite sont désormais dessinées par la même
fonction que les pièces courbes (`VX.curve`) — même tube de roulement, même treillis, mêmes rivets, mêmes lampes. Les
poutres du bassin gardent leur liseré vert.

**Connecteurs** (`joints` dans `visuals.js`), choisis automatiquement pour chaque extrémité de pièce :

| Connecteur | Situation | Dessin |
|---|---|---|
| Embout | extrémité libre | capuchon rond dans l'axe, boulon |
| Platine | extrémité contre un bord de l'écran | plaque murale plaquée au bord, deux boulons |
| Manchon | deux pièces dans le prolongement (< 25°) | bague, deux anneaux, boulon |
| Gousset | deux pièces ou plus en angle | hexagone sur la bissectrice (taille selon le nombre de pièces), boulon central + un boulon par pièce, ombre portée |
| Collier | extrémité appuyée sur le corps d'une autre pièce | demi‑collier, deux boulons |

Même métal (dégradé acier, liseré clair), teinté par la matière (glace, tapis, rebond). Les anciennes jonctions
hexagonales plates sont retirées. **Ce changement touche tous les niveaux du jeu.**


## 22. Jonction adaptative universelle (R87) — remplace les connecteurs du §21

Retour de Simon : « connecteurs trop anecdotiques ; quand deux murs se croisent, ils se chevauchent simplement ». Désormais
**toute rencontre** devient un **nœud** décrit par ses **bras** (une direction par pièce qui en part ; une pièce qui
traverse donne deux bras opposés) :
- bouts qui se touchent : angle (L), Y, étoile ; bout posé sur le corps d'une autre pièce : **T** ; corps contre corps :
  **croisement X** (intersection calculée segment par segment, courbes comprises) ;
- **dessin adaptatif** : chaque bras reçoit un manchon (bague, deux anneaux, boulon) ; le cœur est l'**enveloppe convexe**
  des manchons — une plaque qui épouse exactement la géométrie de la rencontre, quel que soit le nombre de bras et leurs
  angles (ombre portée, dégradé acier, liseré, gorge intérieure) ; moyeu boulonné au centre ; cordon de soudure pour un
  croisement ;
- bouts libres : **embout** (capuchon, bague, boulon) ; bouts contre un bord : **platine murale** ;
- teinte selon la matière dominante ; calcul une fois par niveau (cache `lv._jn`), parois mobiles exclues.

**Planche des jonctions** (banc d'essai) : angle, croix, X, T, T sur courbe, Y à trois bras, croisement poutre × glace,
croisement glace × glace, platines aux bords — vérifiée en capture haute définition.


## 23. Langue « lumière quantique » et zone de réussite dégagée (R88)

Retour de Simon : « pour un résultat professionnel et coller à l'univers quantique onirique cosmique » ; « je n'aime pas que
des éléments se trouvent au sein même de la zone de réussite, ça fait brouillon ».

**Murs (droits, courbes, glace, bassin)** : plus d'acier — de la **lumière tenue** : rail de photons (halo, teinte de la
matière, cœur blanc), âme translucide qui s'éteint en profondeur, réseau fin en constellation dont les nœuds scintillent,
photons qui circulent le long du rail et s'éveillent à l'approche de la particule, suspentes et pylônes en fils de lumière.
Le bassin parle la même langue, teinté de la couleur de la zone.

**Jonctions** : la plaque d'acier devient une **lentille** (verre sombre au cœur teinté, liseré lumineux) ; le moyeu devient un
**petit atome** (noyau blanc, halo, deux orbites elliptiques, un électron qui tourne) ; bouts libres : **perle de lumière** ;
bords d'écran : **ancrage lumineux** à deux points.

**Zone de réussite dégagée — règle opposable**
1. Aucun élément de niveau (mur, courbe, tapis, pointes…) n'entre dans l'intérieur du bassin. Contrôle : `tools/zonepropre.js`
   (132 niveaux ou fiches).
2. Aucun motif de décor (voiles, anneau, hélices) n'est dessiné autour du bassin : masque automatique dans `back()`.

**État** : prototypes corrigés (Les collines, Le grand tremplin) ; **4 niveaux du jeu ont encore un élément dans la zone**
(10 « Deux appuis », 11 « Le relais », 21 « Le grand retour », 34 « Relais d'élan ») — à reprendre avec leur refonte.


## 24. Détails animés et première refonte au protocole complet (R89)

**Petites animations** (toutes les pièces, droites et courbes, dont désormais les plaques de rebond et les tapis droits) :
halo qui respire ; poussières de lumière qui se détachent du rail et montent ; photons qui circulent et s'éveillent près de
la particule ; plaques de rebond : ondes qui battent sur la face (plus fortes à l'approche) ; tapis : anneaux de champ qui
défilent, éclair quand il pousse ; jonctions : une onde lumineuse s'échappe régulièrement du cœur‑atome ; perles qui pulsent.

**Q‑01‑10 « Le plafond »** (remplace « Deux appuis », qui avait un mur dans la zone) — Ketsu, R‑14 Contre‑pied, hypothèse H1
« un trait est un sol ». La grande courbe lance la particule vers un plafond de pointes ; tout le dessous du vol est
interdit ; la zone est sur un balcon. Idée : poser une tôle SOUS les pointes, qui renvoie la particule dans la zone.
Contrôles : `fiche.js` CONFORME (P_ligne 90 %, P_hasard 0 %, encre 131) ; `enigme.js` ÉNIGME ✓ (0 raccourci) ;
`zonepropre.js` zone dégagée ; monde 1 12/12 ; réussi dans le jeu.
`slotwrite.py` écrit désormais `curves` et `mz`. Limite connue : `enigme.js` ne compte pas encore les pièces courbes dans
l'idée ni dans la recherche d'éléments inutiles.
Restent avec un mur dans la zone : 11, 21, 34.


## 25. Animations de choc (R90)

Bibliothèque `impactFx` / `drawImpacts` (`visuals.js`), branchée sur les événements du moteur `ball.impact` et
`ball.bounce` (point de contact, normale, vitesse normale v, matière). Quatre paliers, de plus en plus déployés :

| Palier | v | Animation |
|---|---|---|
| Effleurement | < 1,6 | trois grains de lumière |
| Léger | 1,6–3 | gerbe de poussière lumineuse très fine le long de la surface (traînées), micro‑éclat |
| Moyen | 3–5 | gerbe dense + 1 à 2 arcs électriques qui crépitent (ligne brisée re‑tirée à chaque image, ramification) + anneau de choc |
| Fort | > 5 | gerbe longue + 3 à 4 arcs + onde de choc + éclat en étoile |

Couleur : matière touchée (rebond ambre, tapis violet, glace givre, sinon cyan) mêlée de blanc. Durées 0,3 à 1 s.
Vérifié par capture de quatre chocs déclenchés à 60, 130 et 260 ms.

**Refonte du niveau 11 « La moitié »** (H9 : la poutre fixe n'est que la moitié d'une vallée) : fiche écrite
(`tools/fiches/11.js`), solvable, mais **non conforme** — des traits de 41 à 113 u réussissent aussi (trop d'énergie au bas de
la vallée). Leçons : une vallée formée d'un décor fixe et d'un trait du joueur **coince la particule** si les deux se
rejoignent en angle (même jointifs) — il faut un palier fixe d'où part le trait ; un bassin ouvert à gauche (`'R'`) est
nécessaire quand la particule arrive par la gauche à hauteur de bord. Le niveau 11 actuel reste en place.
