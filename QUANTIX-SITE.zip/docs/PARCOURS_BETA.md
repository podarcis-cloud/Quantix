# PARCOURS JOUEUR BÊTA (base de données) — R286

**Où** : base de l'artefact Aperçu (https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC), collection `parcours_beta`. Lecture par Claude : outil `ArtifactData` (ToolSearch `select:ArtifactData`), `action list|query`, `url` = l'Aperçu, `out_dir` pour sauver en fichiers JSON puis analyser.

**Alimentation**
1. Auto : quand Simon joue sur l'Aperçu (bâti avec `python3 tools/build-apercu.py N U capture`, script `studio/apercu-capture.js`), chaque essai terminé est écrit (1 document / essai). Refus = clé `quantix.runs.consent2`='no'. Essais locaux non envoyés repris au chargement (suivi `quantix.db.sent`). Si la base est absente, l'essai reste local.
2. Import : les JSON reçus par mail (format `quantix-runs` v1 : `{id,build,lang,w,h,dpr,runs:[…]}`) que Simon fournit → Claude les écrit dans la même collection par `ArtifactData batch` (≤50/lot), avec `src:'mail'`, même schéma et même id (déduplication).

**Id document** : `<pid>_<niveau 1-based>_<n° essai>_<chiffres de la date ISO minute>`.

**Champs** : i (index niveau), lvl, nom, monde, n, t, td (ms de dessin), ink, mx, s (tracés ≤28 pts : {m matière, l longueur, p [x,y,…]}), r ('ok'/raison d'échec/'abandon'), f (frames), star, ink2, s2, **bp** (trajectoire de la bille ≤90 pts [x,y]), **tl** (dès R287 : outils d'édition utilisés avant le lâcher — `o` opérations {add,del,mov,scl,clr,und}, `m` suite des modes choisis draw/line/erase/move/scale), pid, build, lang, sw, sh, dpr, src ('apercu'|'mail'), at.

**Usage** : calibrer l'encre par niveau (ink/mx sur les réussites), repérer échecs fatals, vérifier la faisabilité au doigt des solutions, nourrir le générateur. Aucune donnée personnelle (pas d'e-mail, id aléatoire).
**Limite** : la base n'est alimentée que par un joueur connecté à Claude (Simon) sur l'Aperçu ; le site GitHub Pages reste en envoi mail.

## Protocole de révision des niveaux (R287)
**Matière première par niveau** : géométrie = `assets/js/levels.js` (murs, zones, matières, encre) ; solution de référence « géodésique » = `optsol`/`optmat` du même fichier ; essais réels = collection `parcours_beta`.
**Outil** : `python3 tools/parcours-rapport.py DOSSIER [niveaux]` sur un export `ArtifactData list … out_dir=DOSSIER` (mails : les importer d'abord dans la collection). Sortie : issues par essai, encre réussite vs max vs référence, causes d'échec, usage des outils, écart de tracé à la géodésique (px), signaux ⚠.
**Règles de lecture**
1. Encre : max cible ≈ 1,3–1,5 × encre des réussites ; < 45 % d'utilisation = trop généreux ; ≥ 95 % = trop serré.
2. ⚠ « encre << réf » ou « famille différente de la réf » = contournement possible ou référence non optimale → vérifier le tracé (`s`, `bp`) en rejouant dans le moteur, puis soit corriger le niveau (fermer le contournement), soit mettre à jour `optsol`.
3. ≥ 3 échecs de même cause (`out`, etc.) ou abandon répété → revue du niveau (lisibilité, mécanisme non annoncé).
4. Outils (`tl`) : fréquences de gomme/déplacer/échelle/annuler par niveau ; un outil jamais utilisé là où il est attendu, ou massivement utilisé, signale un défaut de conception ou de didactique.
5. Familles de solutions : regrouper les réussites par (départ ±30 px, pente ±20°, matière) dès ≥ 3 joueurs ; une famille dominante hors de `optsol` = lacune ou meilleure idée.
6. Limite : 1 joueur expert = borne basse d'encre, pas difficulté pour un débutant ; ne rien décider définitivement avec < 3 joueurs.

## Journal d'événements (R289) — collection `evenements_beta`
Source : `assets/js/events.js` (jeu en ligne ET Aperçu). 1 document = 1 lot ≤150 événements : `{st:{pid,build,lang,w,h,dpr,ori,n…}, src, at, n, ev:[…]}` ; id `pid_sid_premierK`.
Événement : `{s session, k n°, t ms depuis début de session, y type, l niveau (1-based), d données}`.
Types : **ss** session (build, n° de session, gap en h depuis la précédente, écran, langue, pwa) · **se** fin (why hide/pagehide, act s actives, dur s, mode, essais) · **sr** retour au premier plan ·
**lv** entrée niveau · **vw** vue ouverte/fermée (id) · **ck** tap sur élément à id · **tm** mode d'outil · **sk** trait (matière, longueur, points ≤40, durée de geste, rang, encre restante, tp = ms depuis arrivée) ·
**ed** édition (o = del/mov/scl/clr/und, n, a→b longueurs, ink) · **la** lâcher (n° essai, tp, encre, nb traits, matières) · **ct** contact [x,y,vitesse,matière,frame] (≤60/essai) ·
**bx** événement physique (étoile, portail, boost, rail, quantique…) · **rs** issue (r ok/out/spike/stuck/long, frames, x,y de fin, encre, étoile, bp trajectoire ≤90 pts, ms) · **ab** abandon · **er** erreur script.
Lecture : `ArtifactData list collection=evenements_beta out_dir=…` ; rejouer = regrouper par (pid,s) et trier par k. Hors Aperçu, les événements restent dans la file locale (`quantix.ev.q`, 6000 max) tant qu'aucun `QEV.endpoint` n'est défini (L2 : Cloudflare Worker, décidé).
Tests R289 (Aperçu, stub db) : session, niveau, modes d'outil, trait, lâcher, 7 contacts, issue, masquage, sortie → tous écrits ; file vidée après envoi.

## Rapport sur les événements (R293)
`python3 tools/rapport-evenements.py [--export FICHIER.json] [--events DOSSIER_evenements_beta] [--runs DOSSIER_parcours_beta] [--out rapport.md]`
Sections : joueurs/sessions/retour/pays ; progression (niveaux terminés, dernier niveau vu = décrochage) + tableau par niveau (joueurs, terminé, échecs, 1er essai, essais médians, abandons) ; signaux qualité (encre généreuse/serrée, encre << référence, difficulté, échecs récurrents, lecture longue) ; zones de sortie (case 60 px) ; familles de solutions vs `optsol` ; changement d'un essai à l'autre ; outils. Moins de 3 joueurs → avertissement.
Récupération des données serveur : ouvrir `…workers.dev/export?key=…&dl=1` (R293 : télécharge un fichier ; nécessite de redéployer le Worker) ou, tant que c'est petit, copier-coller le texte dans le chat.
Testé : anciens essais (177, 2 joueurs) et export réel (5 événements). Non testé : journal d'événements riche (aucune partie R289+ complète reçue).

## Export des événements (R294)
- **`admin.html`** (à la racine du site, noindex) : tu tapes la clé admin (non enregistrée) → « Récupérer » lit `/stats` puis `/export` par pages de 200 lots → « Enregistrer / partager le fichier » (feuille de partage iOS ou téléchargement) ou « Copier le texte ». Aucun changement du Worker requis (CORS déjà ouvert à `ALLOWED_ORIGIN`). Ouvrir depuis le site publié (pas depuis un fichier local). Le fichier obtenu s'envoie à Claude : `rapport-evenements.py --export fichier.json`.
- **App** : panneau « Ce que collecte Quantix » → « Exporter les événements gardés ici » (fichier/partage des événements encore en attente sur l'appareil).
- Testé (headless, faux serveur) : admin.html (clé refusée, pagination, téléchargement), export in-app. Non testé : partage iOS réel.
- **Journal riche validé** (niv. 20, 2 essais) : sk ×4, ed und/del, tm erase/draw, la, rs (long puis out), ct ×35, tout reçu dans les lots ; `rapport-evenements.py` lit l'export et sort outils, essais, niveau.

## Géométrie finale (R295)
Premier export réel (R294, niv. 61-63) : l'événement `sk` garde le trait tel que dessiné, or le joueur le déplace presque à chaque essai (outil déplacer). Corrigé : `la` porte maintenant `g:[{m,l,p}]` = traits **tels que lancés** (matière, longueur, ≤24 points x,y à plat, ≤12 traits) ; `ed` `mov` porte `dx,dy` (déplacement du 1er point) et `i` (indice du trait) ; `scl` garde `a`,`b` (longueurs). Le rapport utilise `g` quand il existe (sinon `sk`, approximatif) et ajoute « distance moyenne tracé final ↔ solution de référence » (px).
Testé : partie headless (mov dx 33, dy 22 ; `g` aux coordonnées déplacées) + export synthétique (distance 7 px pour un décalage de 8). Données antérieures à R295 : sans `g`.
