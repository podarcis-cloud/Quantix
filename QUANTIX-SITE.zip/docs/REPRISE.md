# QUANTIX — reprise

*Lis ce fichier en entier avant toute chose. Il remplace la conversation précédente.*

---

## 1. Ce qu'est le projet

Un jeu de puzzle physique. Le joueur trace des murs au doigt pour guider une particule jusqu'à une zone d'arrivée. La progression le fait passer de la physique classique aux phénomènes quantiques.

Signature : **Dessine. Expérimente. Maîtrise.**
Accroche : **Une particule. Mille possibilités.**

Livrable : **un site statique à chemins relatifs**, déployé sur GitHub Pages. Le fichier unique est abandonné depuis R28 : il plafonnait la qualité des illustrations.

---

## 2. État exact à R22

### Fait et vérifié

- **132 expériences, 11 mondes.** 119 prouvées résolvables par simulation automatique. Le niveau 121 « Le lien » est le seul non prouvé : soit très exigeant, soit injouable, il faut y jouer.
- **Moteur** à horloge fixe 60 Hz avec accumulateur et échelle de temps. Cinq sous-pas par tick.
- **Solveur à contraintes** transposé de QuarkPhysics : cordes ancrées, balle molle à préservation d'aire.
- **Mécaniques** : structure, rebond, élan, glace, piques, zones interdites, vent, gravité variable, aimants, portails, barres mobiles, cordes, corps mous. Quantique : intrication à portes en phase, superposition à deux branches, détecteur de mesure, dilatation temporelle.
- **Reprise temporelle** : frise de rembobinage, état complet du solveur enregistré à chaque frame.
- **Sauvegarde** `quantix.save.v1` : étoiles, records de matière, déblocage, langue, réglages. Testée sur quota plein, JSON corrompu, schéma inconnu, stockage inaccessible.
- **Bilingue FR/EN complet** : 132 noms, 132 conseils, 11 mondes, 42 éléments statiques. Aucune clé orpheline.
- **Zen Lab** : sans échec, matière illimitée, gravité et temps réglables.
- **Quantum Drop** : une expérience par jour, graine déterministe sur la date, quatre contraintes en rotation.
- **Direction artistique** relevée sur les moodboards : palette, Space Grotesk et Inter, gélules, étoiles dorées, visuels découpés embarqués.
- **Audio** : 17 effets et 10 pistes génératives, deux voies de lecture.

### Non fait

Les 8 leviers d'engagement (voir `ENGAGEMENT-ET-MONETISATION.md`), le vocabulaire quantique des libellés, le tutoriel gestuel, l'éditeur de niveaux, la découpe gratuit/payant, aucun test hors simulateur.

---

## 3. Décisions figées — ne pas rouvrir

| Sujet | Décision |
|---|---|
| Canon | Le site statique multi-fichiers. Fichier unique et dépôt Replit abandonnés. |
| Monde de référence | 360 × 480 unités. Les 132 niveaux en dépendent. |
| Palette | Celle du moodboard, handbook §6. Aucune couleur hors liste. |
| Typographie | Space Grotesk titres, Inter texte. |
| Vies, énergie, timers | Refusés. Monétisent la frustration, subvertissent l'autonomie. |
| Publicité | Récompensée seulement, après une **réussite**, pour du contenu bonus. |
| Textes | Aucune chaîne visible hors de `i18n.js`. |
| Physique | Les constantes du handbook §2 ne bougent pas sans rejouer `solver.js`. |

---

## 4. Le problème audio — ne pas refaire l'enquête

Le son **fonctionne** dans Safari, et dans la vue web intégrée quand le mode silencieux de l'iPhone est désactivé. Il ne fonctionne pas dans la vue web intégrée avec le mode silencieux activé.

Chaîne établie par mesure, onze tours :

1. Le contexte Web Audio s'ouvre, les 17 effets atteignent la sortie avec des gains de 0,045 à 0,36.
2. `navigator.audioSession.type='playback'` est accepté.
3. Sur iOS, Web Audio sort sur la voie sonnerie ; il faut un élément `<audio>` en lecture continue pour basculer sur la voie média.
4. Cet élément échoue en `MEDIA_ERR_SRC_NOT_SUPPORTED` successivement en WAV 8 bits, WAV 16 bits, `data:` URI, URL de Blob, puis MP3.

**Vérification décisive jamais faite** : ouvrir le fichier dans Safari, mode silencieux activé. Si le son sort, le code est correct et la limitation vient de la vue intégrée.

**Si ça ne suffit pas** : passer en dossier, héberger les MP3 à côté du HTML et les charger par URL relative. Les 17 fichiers sont déjà encodés.

---

## 5. Prochaine tâche

`TACHES.md` est ordonné par dépendance. Le premier point non fait est le **vocabulaire Quantix**, qui se traite entièrement dans `i18n.js` — un seul fichier à relire. Puis le tutoriel gestuel.

Les 8 leviers d'engagement s'insèrent ensuite, dans l'ordre de leur §6.

---

## 6. Les quatre erreurs qui ont coûté le plus, et leur remède

**Des correctifs annoncés sans vérification.** Des scripts de remplacement visaient un texte absent et échouaient en silence. → Tout script compte ses remplacements et affiche OK ou ÉCHEC. Un ÉCHEC arrête le travail.

**Des tests qui ne couvraient pas le code.** Le test de chargement s'arrêtait à l'accueil pendant qu'un bug vivait dans le rendu du jeu. Il y est resté trois tours. → Un test doit exécuter la fonction qu'il prétend couvrir.

**Des republications sous le même nom.** L'aperçu servait l'ancienne version, deux fois. → Numéro neuf, tampon visible, `console.log` au démarrage.

**Des hypothèses avant instrumentation.** Onze tours sur l'audio à supposer au lieu de mesurer. Chaque déblocage est venu d'un message d'erreur affiché. → Instrumenter d'abord, corriger ensuite.

Une cinquième, plus insidieuse : **trois collisions de noms** dans une IIFE unique — `S.ghost`, `th`, `T`. → `grep -c "\bNOM\b" build/*.js` avant d'introduire un identifiant.

---

## 7. Formule d'ouverture recommandée

> Reprends Quantix. Lis `REPRISE.md`, puis le handbook §0 pour choisir tes sections. Tâche unique : **…**. Applique le protocole : correctifs comptés, vérification avant livraison, numéro de build neuf. Ne touche à rien d'autre.
