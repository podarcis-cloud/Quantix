# QUANTIX — reprise

*Lis ce fichier en entier avant toute chose. Il remplace la conversation précédente.*

---

## 1. Ce qu'est le projet

Jeu de puzzle physique. Le joueur trace des murs au doigt pour guider une
particule jusqu'à une zone d'arrivée. La progression le mène de la physique
classique aux phénomènes quantiques.

**Une particule. Mille possibilités.** — *Dessine. Expérimente. Maîtrise.*

Livrable : **un site statique à chemins relatifs**, déployé sur GitHub Pages.
Déjà en ligne sur `podarcis-cloud.github.io`.

---

## 2. État à R29

### Ce qui a changé depuis R28 (audit de reprise, non documenté avant ce jour)

Le tampon de version et le `console.log` de démarrage étaient déjà à **R29**
dans le code reçu, sans que ce fichier n'ait été mis à jour pour en rendre
compte — l'écart n'est documenté nulle part ailleurs. Cette reprise corrige
ça et ajoute ce qu'un audit complet a trouvé :

- **La moitié de l'outillage de vérification était cassée.** `solver.js`,
  `strict.js`, `qprobe.js`, `savetest.js`, `deep.js` et `maptest.js`
  référençaient `testq.js`, `test6.js`, `harness.js` ou `quantix-RNN.html` —
  restes de l'ancien build en fichier unique, inexistants depuis le passage
  au site statique. **Réparés et revérifiés par exécution réelle** (pas
  `node --check` seul) : tous passent maintenant. `scenetest.js`, qui faisait
  doublon cassé de `render.js`, a été supprimé.
- **Le problème de contournement est bien plus grave que mesuré.**
  `BYPASS-RAPPORT.md` ne couvrait que les mondes 2 à 5 (41/45). Le balayage
  complet des 132 niveaux donne **106 niveaux sur 112 testés contournables
  (95 %)**, mondes 6 à 11 compris — **y compris les 12 niveaux quantiques du
  monde 11**, jamais mesurés jusqu'ici. `deep.js`, réparé, montre que 15 des
  16 niveaux les plus résistants tombent à un simple toboggan de structure
  pure, sans aucune matière spéciale. Seul **#72 Le régulateur** résiste.
  Voir `BYPASS-RAPPORT.md`, entièrement réécrit.
- **Le bilingue n'était pas complet malgré le ✅ de `TACHES.md`.** L'écran de
  résultat (succès, échec, critères, bouton « suivant »/« recommencer »),
  Zen Lab, Quantum Drop et les titres Pause/Paramètres écrivaient du français
  en dur dans `engine.js` et `index.html`, en ignorant `i18n.js` — alors que
  les clés `DICT.en` correspondantes existaient déjà, inutilisées. Corrigé :
  9 remplacements dans `engine.js`, 2 dans `index.html`, 2 clés ajoutées à
  `i18n.js` (`retryLevel`, `failMastery`). Vérifié en simulant un succès et
  un échec en FR et en EN via `tools/load.js` — texte affiché confirmé
  correct dans les deux langues, pas seulement absence d'erreur.
- **`auWarn` (avertissement audio en vue web intégrée) est du code mort.**
  L'élément existe dans `index.html`, `display:none`, texte français en dur
  sans `data-t`, et **rien dans `engine.js` ne le rend jamais visible**.
  Soit une fonctionnalité commencée puis abandonnée, soit perdue en cours de
  route. Non corrigé — activer ça correctement demande de savoir sur quel
  état exact d'`Audio1` se déclencher, et §5 dit de ne pas refaire l'enquête
  audio sans mesure sur appareil réel.
- **Les instructions de ce Projet Claude, côté plateforme, sont périmées.**
  Elles décrivent encore le build R22 en fichier unique. `docs/PROJET-PROMPT.md`
  (ce dossier) est à jour et doit remplacer ce qui est collé dans les
  instructions personnalisées du Projet — **action à faire par toi, pas par
  moi.**
- **La règle « aucune couleur hors des jetons du handbook §6 » ne correspond
  pas à la réalité du code.** Plus de 80 couleurs hexadécimales distinctes
  vivent dans `quantix.css`, `engine.js` et `index.html`, contre 11 jetons
  documentés. Ce sont presque certainement des teintes et nuances dérivées
  du moodboard (dégradés, halos, transparences), pas une dérive de charte —
  mais la règle telle qu'écrite est invérifiable en l'état. À trancher :
  soit documenter la palette étendue réelle, soit auditer chaque couleur
  contre le moodboard.

### Acquis et vérifié (inchangé depuis R28, reconfirmé)

- **132 expériences, 11 mondes**, 117 prouvées résolvables par `solver.js`
  (119 annoncé précédemment — écart mineur, heuristique de recherche, pas
  une régression connue).
- **11 illustrations de monde** en qualité pleine, 900 px, chargées à la
  demande. Confirmé par `tools/audit.js` et `tools/maptest.js`.
- **Cartes de monde en constellation**, décor flouté, audio (11 ambiances,
  17 effets MP3), atelier sonore caché, atelier de particule, sauvegarde
  `quantix.save.v1`, Zen Lab, Quantum Drop : fonctionnels, testés par
  `render.js`, `maptest.js`, `savetest.js`, `qprobe.js`.
- **Bilingue FR/EN** : symétrie parfaite `DICT.fr`/`DICT.en` (104 clés
  chacun) et couverture complète des `data-t` — vrai maintenant que les
  9+2 correctifs ci-dessus sont passés.

### Le problème numéro un — mesuré, et le monde 2 est corrigé

**97 niveaux sur 132 restent contournables** (106 au début de cette reprise ;
le monde 2 — 10 niveaux à mécanique — est passé à 0/10, vérifié par
`bypass.js` et reconfirmé solvable par simulation directe niveau par
niveau). Méthode qui a marché : un couloir étroit de non-tracé (`nd`) autour
du départ, fermé sur toute la largeur jusqu'à hauteur de la mécanique — le
vol de la particule après rebond n'est jamais gêné par `nd`. Détail dans
`BYPASS-RAPPORT.md`. Toujours la priorité absolue pour les 9 mondes
restants.

### Non fait

Rescénarisation des 132 niveaux, tutoriel gestuel, historique personnel,
transitions, éditeur de niveaux, découpe gratuit/payant, aucun test sur
Android ni sur navigateur de bureau, décision sur la palette étendue,
décision sur `auWarn`.

---

## 3. Décisions figées — ne pas rouvrir

| Sujet | Décision |
|---|---|
| Canon | Site statique multi-fichiers. Fichier unique et Replit abandonnés. |
| Chemins | Relatifs uniquement. Un `/` initial casse le déploiement en sous-dossier. |
| Scripts | Classiques, pas modules ES : le jeu s'ouvre sans serveur. |
| Monde de référence | 360 × 480 unités. Les 132 niveaux en dépendent. |
| Palette et typo | Moodboard, handbook §6 — étendue réelle à documenter, voir §2. |
| Vies, énergie, timers | Refusés. Monétisent la frustration, subvertissent l'autonomie. |
| Publicité | Récompensée seulement, après une **réussite**, contenu bonus. |
| Textes | Aucune chaîne visible hors de `i18n.js`. |
| Huit leviers d'engagement | Actés dans `ENGAGEMENT-ET-MONETISATION.md`, pas rediscutés. |

---

## 4. Décision en attente

L'affiche de constellation porte du **texte incrusté**, contraire au protocole
visuel, et trois libellés contredisent la liste canonique : elle annonce
**W01 ORIGINE, W02 NÉBULEUSE, W03 PLANÉTAIRE** là où le jeu a **Atelier,
Fonderie, Chaîne**. Les mondes 4 à 11 correspondent.

Deux issues : régénérer l'affiche sans texte, ou renommer les trois premiers
mondes dans `i18n.js` et la table musicale.

---

## 5. Le problème audio — ne pas refaire l'enquête

Le son **fonctionne** dans Safari, et dans la vue web intégrée quand le mode
silencieux de l'iPhone est désactivé. Chaîne établie par mesure sur onze tours :
contexte ouvert, `navigator.audioSession.type='playback'` accepté, mais la
bascule vers la voie média exige un élément `<audio>` en lecture continue, qui
échouait en `MEDIA_ERR_SRC_NOT_SUPPORTED` en WAV, en `data:` et en Blob.

Depuis R28 les sons sont de **vrais fichiers MP3** servis par le site. C'est la
configuration qui n'a jamais été testée et qui a le plus de chances de régler le
mode silencieux. **À vérifier en priorité.**

Élément trouvé en R29 : `auWarn`, l'avertissement visuel prévu pour ce cas,
ne se déclenche jamais (voir §2). À raccorder quand la vérification sur
appareil aura confirmé l'état exact à détecter — pas avant, pour ne pas
réintroduire une hypothèse non instrumentée.

---

## 5 quater. Monde 2 en cours (après R31)

Aperçu publié : 10 niveaux sur 12 finalisés (noyau + solution optimale +
tolérance ≥ 50 %), tous impossibles sans la plaque. Données : `tools/w2cand.js`
(candidats), `tools/w2final.json` + `tools/w2f_*.json` (noyaux, solutions).
**Manquent** : #19 (rôle « combinaison ») et #20 (« enchaînement ») — sept
concepts testés et rejetés (voir handbook §11 quinquies). **Pas encore écrit
dans levels.js** : le monde 2 du jeu est toujours l'ancien (R29).

## 5 ter. État R31

- **Chaque niveau du monde 1 a sa solution optimale** (champ `optsol`),
  qui décroche le noyau — y compris #9 Le leurre (vérifié : 21 % des
  solutions gagnantes prennent le noyau) et #11 Le plafond (6 % : noyau
  « expert », gardé volontairement).
- **Dans le jeu** : « Revoir ma partie » et « Voir la solution optimale »
  sur l'écran de résultat. `node tools/replaytest.js` : 12/12 + relecture OK.
- **Direction artistique en cours** (aperçu, pas encore dans le moteur) :
  décor cosmique composé par niveau + noyau en nuage de points bistable.
  Narration et identité des 11 mondes : `docs/QUANTUM_VISUAL_NARRATIVE.md`.

## 5 bis. État R30 — le monde 1 est refondu (à lire en premier)

Les 12 niveaux du monde 1 ont été entièrement reconçus — pas corrigés :
nouveaux noms, nouvelle géométrie, un geste appris par niveau, un arc
dramatique (introduction → variations → danger → fausse piste → renversement
→ synthèse). Détail niveau par niveau : `LEVEL_DESIGN_CANVAS.md` §11.
Vérification : `node tools/monde1.js` (12/12) et `node tools/redundancy.js 1`
(0 paire). Règles apprises : handbook §11 ter.

**Prochaine tâche : monde 2 (Fonderie), niveau par niveau, même méthode** —
`design.js` pour chaque candidat, `starfind.js` pour le noyau,
`tolerance.js` pour la robustesse, puis un `monde2.js` sur le modèle de
`monde1.js`. Le monde 2 est déjà non contournable (R29) mais n'a jamais reçu
de conception : ses 12 niveaux restent des variations d'une plaque de rebond.

**À faire par l'utilisateur** : tester le monde 1 sur téléphone réel —
c'est un test réel qui a révélé le budget d'encre injouable du niveau 1.

## 6. Prochaines tâches, dans l'ordre

**Changement de méthode acté** : la fermeture géométrique des raccourcis
(couloir `nd`) ne définit plus un niveau « terminé ». Depuis
`docs/MASTER_LEVEL_DESIGN_PROTOCOL.md`, chaque niveau se retravaille en
entier, un par un, du premier au dernier, avec sa fiche
(`docs/LEVEL_DESIGN_CANVAS.md`). Le monde 2 (0/10 contournable) et le
début du monde 3 restent des acquis techniques valides mais n'ont pas
encore reçu ce traitement complet.

1. **Niveau #1 « La rampe », monde 1 — fait et vérifié.** Fiche complète
   dans `LEVEL_DESIGN_CANVAS.md` §5, avec preuve par simulation directe à
   chaque porte qui s'y prêtait (solutions avec et sans noyau, séquence
   sonore instrumentée, vérification de redondance contre les 11 autres
   niveaux du monde). Aucune modification de données n'a été nécessaire —
   le niveau existant remplissait déjà son intention. Découverte au
   passage : `redundancy.js` place #1 en paire suspecte avec #2, #5, #7,
   #8, #10 — examiné pour #8 (faux positif, un `nd` que l'outil ne voit
   pas) ; **pour #2, #5, #7, #10, la vérification est reportée à leur
   propre tour**, pas faite par anticipation.
2. **Niveau #2 « Le seuil », monde 1 — fait et vérifié.** Défaut réel
   trouvé et corrigé : une diagonale directe passait déjà sous la cloison
   sans détour conscient — la cloison ne remplissait aucune fonction.
   Corrigé par un couloir `nd:[[136,0,224,260]]` (pas en allongeant la
   cloison — risque de collage identifié, une balle qui frôle un mur
   vertical glisse à peine, `FRIC=.995`). Découverte générale à retenir
   pour tous les niveaux suivants : la victoire exige de **rester** dans
   la zone 16 frames, pas seulement d'y entrer — une approche trop raide
   rebondit hors de la zone avant que ça compte. Fiche complète dans
   `LEVEL_DESIGN_CANVAS.md` §6.
3. **Niveau #3 « La corniche », monde 1 — prochain.** Point d'attention :
   devrait varier l'orientation ou la forme de l'obstacle par rapport à
   #2 (cloison verticale), pas la répéter à l'identique.
4. Poursuivre le monde 1 dans l'ordre (#4 à #12), puis les mondes suivants
   dans l'ordre numérique — sauf réévaluation explicite de priorité.
   Le monde 11 (Quantique, 12/12 contournable) et le niveau #114 (monde
   10, structurellement infranchissable — voir
   `WORLD_IDENTITY_FRAMEWORK.md`) restent des priorités connues à ne pas
   perdre de vue quand leur tour viendra.
4. Tutoriel gestuel — vraisemblablement absorbé par le traitement complet
   du niveau #1 et des tout premiers niveaux du monde 1, à confirmer une
   fois plusieurs niveaux d'introduction traités.
5. Historique personnel par niveau.
6. Transitions et états pressés.
7. Vérification Android et navigateur de bureau, mode silencieux iOS.
8. Éditeur de niveaux et partage par lien.

Le détecteur de redondance (`tools/redundancy.js`) et l'audit sonore
(`docs/SOUND_DESIGN_PROTOCOL.md`) sont maintenant des outils permanents à
relancer à chaque niveau retravaillé, pas une mesure ponctuelle.
8. Trancher `auWarn` et la palette étendue (§2).
9. Recoller `docs/PROJET-PROMPT.md` dans les instructions du Projet Claude.

Les huit leviers d'engagement sont dans `ENGAGEMENT-ET-MONETISATION.md` et
s'insèrent après le point 3.

---

## 7. Les erreurs qui ont coûté le plus

**Un script de correction qui meurt avant d'écrire.** → Vérifier la présence
de chaque changement dans le fichier, par `grep`, pas dans la sortie du
script.

**Des correctifs annoncés sans vérification.** → Tout script compte ses
remplacements et un ÉCHEC arrête le travail.

**Des tests qui ne couvrent pas le code.** → Un test doit exécuter la
fonction qu'il prétend couvrir.

**Des republications sous le même nom.** → Numéro neuf, tampon visible,
`console.log` au démarrage.

**Des hypothèses avant instrumentation.** → Instrumenter d'abord, corriger
ensuite.

**Trois collisions de noms** — `S.ghost`, `th`, `T`. → `grep -c "\bNOM\b"
assets/js/*.js` avant d'introduire un identifiant. Vérifié en R29 : aucune
collision de déclaration top-level entre les quatre fichiers actuellement.

**Nouvelle, R29 : un outil cassé qui continue d'être cité comme fiable.**
Cinq outils sur dix référençaient des fichiers disparus depuis la migration
vers le site statique, et personne ne s'en était aperçu parce que
`docs/PROJET-PROMPT.md` (à jour) cite la bonne séquence (`audit.js`,
`render.js`, `solver.js`, `bypass.js`) — mais les instructions collées dans
le Projet Claude, périmées, citaient l'ancienne. → **Après toute migration
d'architecture, relancer chaque outil du dossier `tools/` une fois, pas
seulement ceux que la doc courante mentionne.**

---

## 8. Formule d'ouverture recommandée

> Reprends Quantix. Lis `docs/REPRISE.md`, puis le handbook §0 pour choisir tes
> sections. Tâche unique : **…**. Applique le protocole : correctifs comptés et
> vérifiés dans le fichier, séquence de vérification avant livraison, tampon de
> version neuf. Ne touche à rien d'autre.
