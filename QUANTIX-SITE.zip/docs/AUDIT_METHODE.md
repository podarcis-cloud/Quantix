# QUANTIX — Audit de fonctionnement (10 octobre 2026)

*Regard extérieur sur la façon dont le projet est mené, pas sur le jeu lui‑même. Objectif : comprendre pourquoi le travail
coûte cher et aboutit peu, et en tirer une méthode courte (`METHODE.md`).*

---

## 1. Les faits

| Mesure | Valeur |
|---|---|
| Documents de règles dans le Projet | 28 (≈ 60 000 mots) |
| Lecture « obligatoire » avant de concevoir un monde (CONSIGNES §3) | 9 documents, ≈ 30 000 mots |
| `REPRISE-SESSION.md` (censé « remplacer la relecture ») | 11 600 mots, 7 blocs « ÉTAT AU Rxx » empilés |
| Scripts dans `tools/` | 103 (dont une trentaine à usage unique : `w2*`, `w3*`, `hard*.json`, `tight*.json`…) |
| Critères pour qu'un niveau soit « PRÊT » | 10 (énigme, coût, sans‑trait, doigt, noyau, référence, zone, machine, test, capture) |
| Versions livrées | R38 → R121 (plus de 80 tampons) |
| Niveaux « PRÊTS » au sens des critères | 2 / 132 en R116 → 13 / 132 en R121 |
| Dernières sessions (R119 → R121) | ≈ 40 % du quota hebdomadaire de Simon ; résultats visibles : 2 machines (niveaux 3 et 6), 1 creuset (18), corrections ponctuelles |

Ce qui a **vraiment** abouti, d'après Simon : le niveau 1 dessiné par lui dans l'éditeur, les machines 3 et 6 une fois redessinées
avec des courbes calculées, les corrections précises qu'il a signalées sur capture (didacticiel, mur dans la zone).

## 2. Ce qui empêche le projet d'avancer

### 2.1 Les règles s'empilent et ne sont jamais retirées
Chaque déception a produit un nouveau document ou un nouveau critère (« ne plus jamais… »), sans en retirer un autre. Résultat :
des exigences contradictoires que plus personne ne peut satisfaire en même temps.
- « Jouable au doigt » (P_exec ≥ 70 % au doigt) contre « le joueur utilise l'éditeur de ligne » : tranché seulement en R121.
- « Aucun trait court ne gagne » contre des idées dont la solution EST un petit trait (16, 23 : le trait court gagnant est la
  solution voulue, tracée plus court).
- « Autonomie totale, ne pas demander » contre « tout est jugé par Simon à l'œil ».
- « Une machine aux positions 3, 6, 8, 10, 12 » contre « constance ≥ 98 % en ≤ 6 s » sur des mondes à rebonds chaotiques.

### 2.2 La mesure a remplacé le jugement
Les outils (`difficulty`, `enigme`, `fiche`, `constance`, `etat`…) devaient éviter les erreurs ; ils sont devenus le travail.
La plupart des appels de la refonte servaient à faire passer une case, pas à améliorer ce que Simon voit. Deux preuves :
- les machines 3 et 6 passaient les mesures en R118 ; Simon les a jugées « tracées par un enfant » ;
- le niveau 24 a consommé une session entière de recherches automatiques pour revenir à l'ancien.
Une case rouge déclenche une boucle de calcul ; rien n'arrête la boucle tant qu'il reste une case rouge.

### 2.3 Réparer l'existant plutôt que concevoir
Beaucoup de niveaux anciens reposent sur des rebonds chaotiques ou des réglages au pixel. Les « réparer » en déplaçant un bassin
ou en ajoutant une zone interdite ne crée pas d'idée et échoue souvent (monde 2 : 27 % → 27 %). Concevoir neuf à partir d'une
idée claire coûte moins cher qu'un sauvetage.

### 2.4 Le jugement de Simon arrive trop tard
Claude juge avec des chiffres ; Simon juge avec ses yeux, sur iPhone. Entre les deux : des heures de calcul. Une mauvaise
direction (géométrie laide, aperçu du mauvais monde) n'est découverte qu'à la livraison. L'aperçu R121 a même remplacé celui du
monde 1 sans le dire clairement : Simon n'a plus rien pu vérifier.

### 2.5 Le mandat est trop grand pour la méthode
« Refondre 132 niveaux en autonomie, protocole complet, son compris » est un travail de studio. Avec un quota hebdomadaire, une
conversation par session et un conteneur éphémère, il ne peut pas tenir. Chaque réduction de périmètre a été ajoutée comme une
section de plus (§9 « Priorité quota »), sans simplifier le reste.

### 2.6 Le coût de chaque session est gonflé par l'outillage de session
- Une conversation très longue : chaque action relit tout l'historique (et la compaction perd des détails).
- Une reprise de 11 600 mots relue à chaque début de session.
- Un zip de 9,6 Mo à joindre et réenvoyer, des tampons de version à chaque livraison.
- Chaque publication d'artefact demande une autorisation : on publie rarement, donc Simon voit tard.

## 3. Ce qui marche et qu'il faut garder

- Le jeu lui‑même : moteur, rendu « lumière quantique », didacticiel en surimpression, éditeur de niveaux sur iPhone, Quantone.
- **Simon dessine une idée dans l'éditeur, Claude la met au propre** (niveau 1).
- **Les courbes calculées** (`tools/rail.js` : virages à courbure douce, lèvres posées sur la trajectoire, trémie + goulotte
  qui normalise l'entrée d'une machine). C'est ce qui a rendu les machines belles et constantes.
- Les vérifications simples qui évitent les régressions : test du monde, relecture des solutions, zone dégagée, capture regardée.
- Le moteur sonore W1N comme base.

## 4. Décisions (appliquées dans `METHODE.md`)

1. **Une seule règle de méthode, courte** (`METHODE.md`, deux pages au plus). Toute nouvelle règle **remplace** une ligne
   existante ; on n'ajoute plus de document de règles.
2. **Deux niveaux de critères** : bloquants (le niveau marche, rien de cassé) et indicatifs (jouabilité, coût, noyau, constance).
   Les indicatifs informent le jugement de Simon, ils ne déclenchent plus de boucles de calcul.
3. **Le juge est Simon, à l'œil.** Chaque lot de travail se termine par un aperçu qu'il ouvre sur son iPhone, avec une phrase
   qui dit quel monde et quels niveaux regarder.
4. **Petits lots, deux essais.** Un lot = 1 à 3 niveaux, ou une fonctionnalité. Deux essais au plus par problème, puis on montre
   où on en est et on demande.
5. **Concevoir plutôt que réparer.** Un ancien niveau qui ne tient pas est refait à partir d'une idée en trois lignes, pas réglé.
6. **Sessions courtes.** Une conversation par lot ; la reprise est réécrite (une page), jamais empilée.
7. **Le reste de la documentation devient une bibliothèque** : utile pour s'inspirer (énigmes, charte, son, narration), jamais
   une liste de cases à cocher.

## 5. Questions ouvertes pour Simon

- **Périmètre de la première version publiée** : par exemple les mondes 1 à 4 (48 niveaux), avec une machine par monde (la
  finale), plutôt que 132 niveaux et cinq machines par monde.
- **Le dépôt GitHub du site** : s'il est connecté à Claude, chaque session clone le site et enregistre ses changements
  (historique, retour arrière). Plus de zip à joindre ni de tampons de version.
