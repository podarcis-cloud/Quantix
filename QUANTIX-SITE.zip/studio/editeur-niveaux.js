/* QUANTIX — ÉDITEUR DE NIVEAUX v2 (R99). Édition sur une toile dédiée ; « Tester » charge le niveau dans le VRAI jeu, dans
   le monde du défi, avec toute son interface (bouton Lâcher compris) ; « ✎ Éditeur » revient.
   Fichiers : Q-MM-PP_monde-niv###.json (ex. Q-07-05_gravite-niv077.json) ; sauvegarde locale automatique par défi. */
(function(){
var W=['Atelier','Fonderie','Chaîne','Glacier','Soufflerie','Mécanique','Gravité','Magnétisme','Faille','Filaments','Quantique'];
var SLUG=['atelier','fonderie','chaine','glacier','soufflerie','mecanique','gravite','magnetisme','faille','filaments','quantique'];
var VERITE=['le trait de lumière est la seule construction','la plaque de rebond rend plus qu\'elle ne reçoit','le tapis donne l\'élan (≈ 40 u de hauteur, pas plus)','sur la glace, rien ne freine','une force sans contact agit en plein vol','des parois bougent : le moment compte','le haut n\'est plus le haut','l\'aimant attire ou détourne, à distance','les portails déplacent sans changer la vitesse','la corde et le corps mou plient','plusieurs versions, une seule réalité mesurée'];
var MATS_W=['Structure','Structure, Rebond','Structure, Tapis','Structure, Glace','Structure + champs de vent','Structure (parois mobiles : à décrire dans la note)','Structure + champs de gravité','Structure (aimant : à décrire dans la note)','Structure (portails : à décrire dans la note)','Structure (corde : à décrire dans la note)','Structure (effets quantiques : à décrire dans la note)'];
var TY={'R-01':'Découvrir','R-02':'Ponter','R-03':'Sauter','R-04':'Inverser','R-05':'Rattraper','R-06':'Doser','R-07':'Relayer','R-08':'Protéger','R-09':'Éviter','R-10':'Détourner','R-11':'Boucler','R-12':'Orienter','R-13':'Économiser','R-14':'Contre-pied','R-15':'Synchroniser','R-16':'Tracer en vol','R-17':'Utiliser le danger','R-18':'Choisir','R-19':'Combiner','R-20':'Synthèse','R-21':'Lire la machine'};
var PLAN=[['R-01','R-02','R-04','R-07','R-06','R-10','R-13','R-05','R-09','R-14','R-08','R-20'],['R-01','R-04','R-03','R-06','R-17','R-12','R-07','R-09','R-10','R-11','R-19','R-20'],
['R-01','R-04','R-06','R-07','R-12','R-09','R-10','R-11','R-13','R-14','R-16','R-20'],['R-02','R-05','R-03','R-04','R-06','R-13','R-10','R-08','R-14','R-09','R-07','R-20'],
['R-01','R-17','R-19','R-12','R-07','R-09','R-06','R-10','R-08','R-16','R-14','R-20'],['R-01','R-15','R-02','R-17','R-10','R-09','R-16','R-07','R-11','R-14','R-19','R-20'],
['R-01','R-06','R-01','R-04','R-02','R-06','R-09','R-21','R-12','R-19','R-14','R-20'],['R-01','R-09','R-06','R-11','R-07','R-08','R-12','R-10','R-13','R-17','R-14','R-20'],
['R-01','R-12','R-05','R-11','R-10','R-04','R-07','R-06','R-09','R-13','R-14','R-20'],['R-02','R-06','R-17','R-07','R-08','R-10','R-12','R-13','R-09','R-19','R-14','R-20'],
['R-18','R-01','R-15','R-06','R-19','R-12','R-10','R-09','R-13','R-14','R-11','R-20']];
var HYP={'R-01':'« cet élément est un décor »','R-02':'« un vide se saute »','R-03':'« un vide se franchit par un pont »','R-04':'« le plus court chemin mène à la zone »','R-05':'« il faut la ralentir avant »','R-06':'« plus vite, c\'est mieux »','R-07':'« un trait = un geste »','R-08':'« un seul obstacle à la fois »','R-09':'« l\'élément visible est l\'aide »','R-10':'« le chemin direct existe »','R-11':'« on ne repasse jamais au même endroit »','R-12':'« le sens du trait n\'importe pas »','R-13':'« plus d\'énergie, plus de choix »','R-14':'« il faut viser la zone »','R-15':'« on trace avant, une fois pour toutes »','R-16':'« on trace avant de lâcher »','R-17':'« le danger est à fuir »','R-18':'« il n\'y a qu\'une particule »','R-19':'« les mécaniques agissent séparément »','R-20':'(fin de monde) deux idées du monde, enchaînées','R-21':'« la machine me sauve »'};
var TEMPS=['Ki','Ki','Ki','Shō','Shō','Shō','Ten','Ten','Ten','Ketsu','Ketsu','Ketsu'];
var FORME=['Simple','Simple','Relais (première machine du monde)','Simple','Simple','Relais (machine-récompense)','Simple','Machine-énigme (lire la machine)','Simple','Deux actes (deux énigmes reliées par la machine)','Simple','Finale (grande machine du monde)'];
function card(w,p){var t=PLAN[w][p];return {code:'Q-'+('0'+(w+1)).slice(-2)+'-'+('0'+(p+1)).slice(-2),n:w*12+p+1,monde:W[w],slug:SLUG[w],pos:p+1,temps:TEMPS[p],forme:FORME[p],type:t+' '+TY[t],hyp:HYP[t],verite:VERITE[w],mats:MATS_W[w]};}
function fname(c){return c.code+'_'+c.slug+'-niv'+('00'+c.n).slice(-3)+'.json';}
var cv,cx,K=1,TOOL='droite',MAT=0,FK='nd',D,CUR,sel=null,drag=null,hist=[],look=null,mode='edit';
var MAT_L=[['Structure',0,'#77d7ff','▬'],['Glace',4,'#d6f3ff','❄'],['Accélérateur',3,'#a678ff','»'],['Rebond',1,'#ff9a52','◉'],['Pointes',2,'#ff5252','▲'],['Paroi mobile verticale (monte et descend)',6,'#c8ff6b','↕'],['Paroi mobile horizontale (va et vient)',7,'#c8ff6b','↔']];
var LASTTR=null;
var redo=[],SIM=null;
var FIELDS=[['Zone interdite','nd','rgba(200,210,230,.25)','⊘'],['Vent vers le haut','w_up','rgba(120,200,255,.22)','⇡'],['Vent vers la droite','w_r','rgba(120,200,255,.22)','⇢'],['Vent vers la gauche','w_l','rgba(120,200,255,.22)','⇠'],['Gravité inversée','g_inv','rgba(150,235,90,.22)','⇅'],['Gravité faible','g_low','rgba(150,235,90,.16)','◌'],['Gravité lourde','g_hi','rgba(255,170,90,.2)','⬇'],['Dilatation du temps','tdil','rgba(180,140,255,.2)','⌛']];
/* R105 — palettes PAR MONDE (seuls les éléments du monde du défi sont proposés) ; fin de monde (positions 10–12, Ketsu) :
   + les éléments des deux mondes précédents (synthèse) ; monde Quantique : presque tout (« le monde qui réunit tout »). */
var OBJ={mag:['Aimant','🧲','pt'],port:['Portail (entrée → sortie)','◐','seg'],gate:['Porte quantique','⊟','seg'],ent:['Intrication (deux points liés)','∞','seg'],sup:['Superposition (séparateur)','⋔','seg'],det:['Détecteur','◎','pt']};
var WP=[{d:[0,2],f:['nd'],o:[],p:[0]},{d:[0,2,1],f:['nd'],o:[],p:[0,1]},{d:[0,2,3],f:['nd'],o:[],p:[0,3]},{d:[0,2,4],f:['nd'],o:[],p:[0]},
 {d:[0,2],f:['nd','w_up','w_r','w_l'],o:[],p:[0]},{d:[0,2,6,7],f:['nd'],o:[],p:[0]},{d:[0,2],f:['nd','g_inv','g_low','g_hi'],o:[],p:[0]},{d:[0,2],f:['nd'],o:['mag'],p:[0]},
 {d:[0,2],f:['nd'],o:['port'],p:[0]},{d:[0,2],f:['nd'],o:[],p:[0,5],soft:1},{d:[0,2,1,3,4],f:['nd','w_up','w_r','w_l','g_inv','g_low','g_hi','tdil'],o:['mag','port','gate','ent','sup','det'],p:[0,1,3]}];
function pal(c){var w=c.n?Math.floor((c.n-1)/12):0,P=JSON.parse(JSON.stringify(WP[w]));if(c.pos>=10&&w<10)for(var k=1;k<=2;k++)if(w-k>=0){var Q=WP[w-k];['d','f','o','p'].forEach(function(t){Q[t].forEach(function(x){if(P[t].indexOf(x)<0)P[t].push(x);});});}return P;}
var PM=[['Structure',0,'#77d7ff','▬',1],['Rebond',1,'#ff9a52','◉',1.9],['Accélérateur',3,'#a678ff','»',1.7],['Corde',5,'#ffd27a','〰',1]],PMAT=0,SHOWREF=true,REFTR=null,REFOK=null;
function blank(){return {ball:[60,40],cup:[135,456,90],w:[],curves:[],fields:[],obj:[],tests:[],ref:[],ink:300,note:''};}
function norm(d){d.obj=d.obj||[];d.tests=d.tests||[];d.ref=d.ref||[];d.ink=d.ink||300;d.fields=d.fields||[];
 d.w=d.w.filter(function(w){if(w[4]===9){d.ref.push([[w[0],w[1]],[w[2],w[3]]]);return false;}return true;});
 d.curves=d.curves.filter(function(c){if(c.m===9){d.ref.push(pts(c));return false;}return true;});return d;}
function key(c){return 'QED2:'+c.code;}   /* R123 : nouvelle clé, chaque défi s'ouvre sur le niveau actuel du jeu (les anciens brouillons restent sous « QED: ») */
var ORIG=null;   /* R104 : chaque défi s'ouvre sur la VERSION ACTUELLE du niveau (copie prise au démarrage, avant tout essai) */
function snapLevels(){ORIG=LEVELS.map(function(L){return JSON.parse(JSON.stringify({w:L.w,curves:L.curves,ball:L.ball,cup:L.cup,nd:L.nd,wind:L.wind,grav:L.grav,mov:L.mov,optsol:L.optsol,optmat:L.optmat,ink:L.ink,mag:L.mag,port:L.port,gate:L.gate,ent:L.ent,sup:L.sup,det:L.det,tdil:L.tdil,softball:L.softball,rails:L.rails,n:L.n}));});}
function fromLevel(c){var L=ORIG&&ORIG[c.n-1];if(!L)return blank();var d={ball:(L.ball||[60,40]).slice(),cup:L.cup?[L.cup[0],L.cup[1],L.cup[2],L.cup[3]||'B']:[135,456,90,'B'],w:[],curves:[],fields:[],note:''};
 (L.w||[]).forEach(function(w){d.w.push([w[0],w[1],w[2],w[3],w[4]]);});
 (L.curves||[]).forEach(function(cv){d.curves.push({pts:cv.pts.map(function(q){return [Math.round(q[0]),Math.round(q[1])];}),m:cv.m||0});});
 (L.nd||[]).forEach(function(r){d.fields.push([r[0],r[1],r[2],r[3],'nd']);});
 (L.wind||[]).forEach(function(r){d.fields.push([r[0],r[1],r[2],r[3],r[5]<0?'w_up':r[4]>0?'w_r':'w_l']);});
 (L.grav||[]).forEach(function(r){d.fields.push([r[0],r[1],r[2],r[3],r[5]<0?'g_inv':r[5]<.3?'g_low':'g_hi']);});
 (L.mov||[]).forEach(function(m){d.w.push([m.seg[0],m.seg[1],m.seg[2],m.seg[3],m.ay?6:7]);});
 d.obj=[];d.tests=[];d.ref=(L.optsol||[]).map(function(sp){return sp.map(function(q){return q.slice();});});d.ink=L.ink||300;d.refmat=L.optmat||0;
 ['mag','det'].forEach(function(k){(L[k]||[]).forEach(function(v){d.obj.push({k:k,v:v.slice()});});});['port','gate','ent','sup'].forEach(function(k){(L[k]||[]).forEach(function(v){d.obj.push({k:k,v:v.slice()});});});
 (L.tdil||[]).forEach(function(r){d.fields.push([r[0],r[1],r[2],r[3],'tdil']);});d.soft=!!L.softball;
 var miss=[];if(L.rails&&L.rails.length)miss.push('rail');
 d.note='Version actuelle du jeu : « '+L.n+' »'+(L.optsol?' (✦ = solution enregistrée)':'')+(miss.length?' — éléments non affichés : '+miss.join(', '):'');return d;}
function load(c){try{var s=localStorage.getItem(key(c));if(s)return norm(JSON.parse(s));}catch(e){}return norm(fromLevel(c));}
var DB=null,DL=null,dbT=null;
/* R103 : sauvegarde dans la base de l'artefact (le stockage local est refusé par la visionneuse) — Claude lit ces niveaux
   directement (collection « niveaux », un document par défi, champ json) ; fichier proposé via la capacité « downloads ». */
function store(){try{localStorage.setItem(key(CUR),JSON.stringify(D));}catch(e){}refSim();inkUI();
 if(DB){clearTimeout(dbT);var c=CUR,d=JSON.stringify(payload());dbT=setTimeout(function(){DB.doc('niveaux/'+c.code).set({json:d,code:c.code,fichier:fname(c),date:new Date().toISOString()}).then(listSaved).catch(function(e){document.getElementById('qeSaved').textContent='Sauvegarde en ligne refusée : '+(e&&e.code||e);});},700);}
 else listSaved();}
function push(){hist.push(JSON.stringify(D));if(hist.length>80)hist.shift();redo=[];}
function pts(c){return c.ctl?bez(c.a,c.ctl,c.b):c.pts;}
function cen(o){var q=o.length?o:pts(o),x=0,y=0;q.forEach(function(v){x+=v[0];y+=v[1];});return [x/q.length,y/q.length];}
function rot(q,c,a){var dx=q[0]-c[0],dy=q[1]-c[1];return [Math.round(c[0]+dx*Math.cos(a)-dy*Math.sin(a)),Math.round(c[1]+dx*Math.sin(a)+dy*Math.cos(a))];}
function bez(a,c,b){var o=[];for(var i=0;i<=8;i++){var t=i/8,u=1-t;o.push([Math.round(u*u*a[0]+2*u*t*c[0]+t*t*b[0]),Math.round(u*u*a[1]+2*u*t*c[1]+t*t*b[1])]);}return o;}
var GX=[180,137.5,222.5],GY=[183.4,296.6],MAGON=true;try{MAGON=localStorage.getItem('QED_mag')!=='0';}catch(e){}   /* R135 : aimant activable */
function snap(p,ex){if(!MAGON)return {p:[Math.round(p[0]),Math.round(p[1])],k:''};var best=null,d=11;function tr(q,k){if(k===ex)return;var dd=Math.hypot(q[0]-p[0],q[1]-p[1]);if(dd<d){d=dd;best=[q[0],q[1]];}}
 D.w.forEach(function(w,i){tr([w[0],w[1]],'w'+i+'a');tr([w[2],w[3]],'w'+i+'b');});D.curves.forEach(function(c,i){var q=pts(c);tr(q[0],'c'+i+'a');tr(q[q.length-1],'c'+i+'b');});
 if(best)return {p:best,k:'bout'};var g={p:[Math.round(p[0]/5)*5,Math.round(p[1]/5)*5],k:''};
 GX.forEach(function(x){if(Math.abs(p[0]-x)<5){g.p[0]=Math.round(x);g.gx=x;}});GY.forEach(function(y){if(Math.abs(p[1]-y)<5){g.p[1]=Math.round(y);g.gy=y;}});return g;}
function mag(E,self){if(!MAGON)return [0,0,null];var best=null,d=13;function chk(q,id){if(id===self)return;E.forEach(function(e){var dd=Math.hypot(q[0]-e[0],q[1]-e[1]);if(dd<d){d=dd;best=[q[0]-e[0],q[1]-e[1],[q[0],q[1]]];}});}
 D.w.forEach(function(w,i){chk([w[0],w[1]],'w'+i);chk([w[2],w[3]],'w'+i);});D.curves.forEach(function(c,i){var q=pts(c);chk(q[0],'c'+i);chk(q[q.length-1],'c'+i);});return best||[0,0,null];}
function dseg(p,a,b){var ax=b[0]-a[0],ay=b[1]-a[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((p[0]-a[0])*ax+(p[1]-a[1])*ay)/l)):0;return Math.hypot(p[0]-a[0]-u*ax,p[1]-a[1]-u*ay);}
function pick(p){var r=null,d;function H(q,o,R){var dd=Math.hypot(q[0]-p[0],q[1]-p[1]);if(dd<(R||14)&&(!r||dd<d)){d=dd;r=o;}}
 if(sel){if(sel.t==='w'){var w=D.w[sel.i];H([w[0],w[1]],{t:'w',i:sel.i,h:'a'});H([w[2],w[3]],{t:'w',i:sel.i,h:'b'});}
  if(sel.t==='c'){var c=D.curves[sel.i];if(c.ctl){H(c.a,{t:'c',i:sel.i,h:'a'});H(c.b,{t:'c',i:sel.i,h:'b'});H(c.ctl,{t:'c',i:sel.i,h:'ctl'});}}
  if(sel.t==='w'||sel.t==='c'){var ce=sel.t==='w'?cen([[D.w[sel.i][0],D.w[sel.i][1]],[D.w[sel.i][2],D.w[sel.i][3]]]):cen(D.curves[sel.i]);H([ce[0],ce[1]-34],{t:sel.t,i:sel.i,h:'rot',c:ce},16);H([ce[0],ce[1]+34],{t:sel.t,i:sel.i,h:'scl',c:ce},16);}
  if(sel.t==='f'){var f=D.fields[sel.i];H([f[0]+f[2],f[1]+f[3]],{t:'f',i:sel.i,h:'size'});}
  if(sel.t==='cup')H([D.cup[0]+D.cup[2],D.cup[1]-56],{t:'cup',h:'size'});
  if(sel.t==='e'&&D.tests[sel.i]){var te=D.tests[sel.i].pts;H(te[0],{t:'e',i:sel.i,h:'a'});H(te[te.length-1],{t:'e',i:sel.i,h:'b'});var cee=cen(te);H([cee[0],cee[1]+34],{t:'e',i:sel.i,h:'scl',c:cee},16);H([cee[0],cee[1]-34],{t:'e',i:sel.i,h:'rot',c:cee},16);}}
 if(r)return r;H(D.ball,{t:'ball'},16);if(r)return r;
 var c2=D.cup;if(p[0]>c2[0]&&p[0]<c2[0]+c2[2]&&p[1]>c2[1]-56&&p[1]<c2[1]+4)return {t:'cup'};
 D.w.forEach(function(w,i){var dd=dseg(p,[w[0],w[1]],[w[2],w[3]]);if(dd<10&&(!r||dd<d)){d=dd;r={t:'w',i:i};}});
 D.curves.forEach(function(c,i){var Q=pts(c);for(var k=1;k<Q.length;k++){var dd=dseg(p,Q[k-1],Q[k]);if(dd<10&&(!r||dd<d)){d=dd;r={t:'c',i:i};}}});
 D.tests.forEach(function(t,i){for(var k=1;k<t.pts.length;k++){var dd=dseg(p,t.pts[k-1],t.pts[k]);if(dd<12&&(!r||dd<d)){d=dd;r={t:'e',i:i};}}});
 if(r)return r;(D.obj||[]).forEach(function(o,i){var v=o.v;if(OBJ[o.k][2]==='pt'){H([v[0],v[1]],{t:'o',i:i},16);if(sel&&sel.t==='o'&&sel.i===i)H([v[0]+v[2],v[1]],{t:'o',i:i,h:'r'});}else{if(sel&&sel.t==='o'&&sel.i===i){H([v[0],v[1]],{t:'o',i:i,h:'a'});H([v[2],v[3]],{t:'o',i:i,h:'b'});}var dd=dseg(p,[v[0],v[1]],[v[2],v[3]]);if(dd<10&&!r)r={t:'o',i:i};}});
 if(r)return r;D.fields.forEach(function(f,i){if(!r&&p[0]>f[0]&&p[0]<f[0]+f[2]&&p[1]>f[1]&&p[1]<f[1]+f[3])r={t:'f',i:i};});return r;}
function P(e){var r=cv.getBoundingClientRect();return [(e.clientX-r.left)/r.width*360,(e.clientY-r.top)/r.height*480];}
function down(e){if(mode!=='edit')return;e.preventDefault();try{cv.setPointerCapture(e.pointerId);}catch(x){}var p=P(e),s=snap(p);look=s;
 if(TOOL==='sel'){var h=pick(p);if(h){if(h.t==='ball'||h.t==='cup')sel={t:h.t};else if(!h.h)sel={t:h.t,i:h.i};push();drag={h:h,p0:p,o:JSON.parse(JSON.stringify(D))};}else sel=null;}
 else if(TOOL==='gomme'){var g=pick(p);if(g&&(g.t==='w'||g.t==='c'||g.t==='f'||g.t==='e')){push();if(g.t==='e')D.tests.splice(g.i,1);if(g.t==='w')D.w.splice(g.i,1);if(g.t==='c')D.curves.splice(g.i,1);if(g.t==='f')D.fields.splice(g.i,1);sel=null;store();}}
 else if(TOOL==='courbe'&&sel&&sel.t==='c'&&(function(){var hh=pick(p);if(hh&&hh.t==='c'&&hh.h&&hh.h!=='rot'){push();drag={h:hh,p0:p,o:JSON.parse(JSON.stringify(D))};return true;}return false;})()){}
 else if(TOOL==='obj'&&OBJ[OK][2]==='pt'){push();D.obj.push({k:OK,v:OK==='mag'?[s.p[0],s.p[1],80,.34]:[s.p[0],s.p[1],34]});sel={t:'o',i:D.obj.length-1};store();}
 else if(TOOL==='essai')drag={make:'essai',pl:[s.p]};
 else if(TOOL==='essaiD')drag={make:'essaiD',a:s.p,b:s.p};
 else if(TOOL==='main')drag={make:'main',pl:[s.p]};
 else drag={make:TOOL==='obj'?'obj':TOOL,a:s.p,b:s.p};ui2();draw();}
function move(e){if(mode!=='edit'||!drag)return;e.preventDefault();var p=P(e),h=drag.h;
 if(drag.make==='main'||drag.make==='essai'){var l=drag.pl[drag.pl.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])>=7)drag.pl.push([Math.round(p[0]),Math.round(p[1])]);look={p:p,k:''};draw();return;}
 if(drag.make){var s=snap(p);drag.b=s.p;look=s;draw();return;}
 if(h.h==='rot'){var a0=Math.atan2(drag.p0[1]-h.c[1],drag.p0[0]-h.c[0]),a1=Math.atan2(p[1]-h.c[1],p[0]-h.c[0]),A=MAGON?Math.round((a1-a0)/(Math.PI/36))*(Math.PI/36):Math.round((a1-a0)/(Math.PI/180))*(Math.PI/180);
  if(h.t==='e'){D.tests[h.i].pts=drag.o.tests[h.i].pts.map(function(q){var r9=rot(q,h.c,A);return [Math.round(r9[0]),Math.round(r9[1])];});}
  else if(h.t==='w'){var w0=drag.o.w[h.i],q1=rot([w0[0],w0[1]],h.c,A),q2=rot([w0[2],w0[3]],h.c,A);D.w[h.i]=[q1[0],q1[1],q2[0],q2[1],w0[4]];}
  else{var c0=drag.o.curves[h.i],n0=D.curves[h.i];if(c0.ctl){n0.a=rot(c0.a,h.c,A);n0.b=rot(c0.b,h.c,A);n0.ctl=rot(c0.ctl,h.c,A);}else n0.pts=c0.pts.map(function(q){return rot(q,h.c,A);});}
  look={p:p,k:'',deg:Math.round(A*180/Math.PI)};draw();return;}
 if(h.h==='scl'){var fs=Math.hypot(p[0]-h.c[0],p[1]-h.c[1])/Math.max(8,Math.hypot(drag.p0[0]-h.c[0],drag.p0[1]-h.c[1]));fs=Math.max(.2,Math.min(5,fs));if(MAGON){var fr=Math.round(fs*4)/4;if(Math.abs(fs-fr)<.05)fs=fr;}
  var sc=function(q){return [Math.round(h.c[0]+(q[0]-h.c[0])*fs),Math.round(h.c[1]+(q[1]-h.c[1])*fs)];};   /* R135 : échelle autour du centre */
  if(h.t==='e')D.tests[h.i].pts=drag.o.tests[h.i].pts.map(sc);
  else if(h.t==='w'){var w5=drag.o.w[h.i],e1=sc([w5[0],w5[1]]),e2=sc([w5[2],w5[3]]);D.w[h.i]=[e1[0],e1[1],e2[0],e2[1],w5[4]];}
  else{var c5=drag.o.curves[h.i],n5=D.curves[h.i];if(c5.ctl){n5.a=sc(c5.a);n5.b=sc(c5.b);n5.ctl=sc(c5.ctl);}else n5.pts=c5.pts.map(sc);}
  look={p:p,k:'×'+fs.toFixed(2)};draw();return;}
 var dx=Math.round(p[0]-drag.p0[0]),dy=Math.round(p[1]-drag.p0[1]),o=drag.o;look=null;
 if(h.t==='ball'){D.ball=[o.ball[0]+dx,o.ball[1]+dy];look={p:D.ball,k:''};}
 else if(h.t==='cup'&&h.h==='size'){D.cup[2]=Math.max(40,o.cup[2]+dx);}
 else if(h.t==='cup'){D.cup=[o.cup[0]+dx,o.cup[1]+dy,o.cup[2],o.cup[3]||'B'];look={p:[D.cup[0]+D.cup[2]/2,D.cup[1]],k:''};}
 else if(h.t==='w'){var w=o.w[h.i];if(h.h==='a'){var s1=snap([w[0]+dx,w[1]+dy],'w'+h.i+'a');D.w[h.i][0]=s1.p[0];D.w[h.i][1]=s1.p[1];look=s1;}else if(h.h==='b'){var s2=snap([w[2]+dx,w[3]+dy],'w'+h.i+'b');D.w[h.i][2]=s2.p[0];D.w[h.i][3]=s2.p[1];look=s2;}
  else{var m1=mag([[w[0]+dx,w[1]+dy],[w[2]+dx,w[3]+dy]],'w'+h.i);dx+=m1[0];dy+=m1[1];D.w[h.i]=[w[0]+dx,w[1]+dy,w[2]+dx,w[3]+dy,w[4]];if(m1[2])look={p:m1[2],k:'bout'};}}
 else if(h.t==='c'&&!o.curves[h.i].ctl){var c9=o.curves[h.i],e9=[c9.pts[0],c9.pts[c9.pts.length-1]].map(function(q){return [q[0]+dx,q[1]+dy];}),m9=mag(e9,'c'+h.i);dx+=m9[0];dy+=m9[1];D.curves[h.i].pts=c9.pts.map(function(q){return [q[0]+dx,q[1]+dy];});if(m9[2])look={p:m9[2],k:'bout'};}
 else if(h.t==='c'){var c=o.curves[h.i],n=D.curves[h.i];if(h.h){if(h.h==='ctl'){n.ctl=[c.ctl[0]+dx,c.ctl[1]+dy];look={p:n.ctl,k:''};}else{var s3=snap([c[h.h][0]+dx,c[h.h][1]+dy],'c'+h.i+h.h);n[h.h]=s3.p;look=s3;}}
  else{var m8=mag([[c.a[0]+dx,c.a[1]+dy],[c.b[0]+dx,c.b[1]+dy]],'c'+h.i);dx+=m8[0];dy+=m8[1];['a','b','ctl'].forEach(function(k){n[k]=[c[k][0]+dx,c[k][1]+dy];});if(m8[2])look={p:m8[2],k:'bout'};}}
 else if(h.t==='o'){var v=o.obj[h.i].v,n2=D.obj[h.i].v;if(h.h==='r')n2[2]=Math.max(12,Math.round(Math.hypot(v[0]+v[2]+dx-v[0],dy)));else if(h.h==='a'){n2[0]=v[0]+dx;n2[1]=v[1]+dy;}else if(h.h==='b'){n2[2]=v[2]+dx;n2[3]=v[3]+dy;}else{n2[0]=v[0]+dx;n2[1]=v[1]+dy;if(OBJ[D.obj[h.i].k][2]==='seg'){n2[2]=v[2]+dx;n2[3]=v[3]+dy;}}}
 else if(h.t==='e'){var te0=o.tests[h.i].pts,tn0=D.tests[h.i].pts,nL=te0.length-1;if(h.h==='a'||h.h==='b'){var ix=h.h==='a'?0:nL,s5=snap([te0[ix][0]+dx,te0[ix][1]+dy]);tn0[ix]=s5.p;look=s5;if(nL>1){/* main levée : on étire le tracé entier */var oA=te0[ix],ddx=s5.p[0]-oA[0],ddy=s5.p[1]-oA[1];D.tests[h.i].pts=te0.map(function(q,j){var wgt=h.h==='a'?1-j/nL:j/nL;return [Math.round(q[0]+ddx*wgt),Math.round(q[1]+ddy*wgt)];});}}else D.tests[h.i].pts=te0.map(function(q){return [q[0]+dx,q[1]+dy];});}
 else if(h.t==='f'){var f=o.fields[h.i];if(h.h==='size'){D.fields[h.i][2]=Math.max(20,f[2]+dx);D.fields[h.i][3]=Math.max(20,f[3]+dy);}else{D.fields[h.i][0]=f[0]+dx;D.fields[h.i][1]=f[1]+dy;}}
 draw();}
function up(e){if(mode!=='edit')return;if(drag&&drag.make==='essaiD'){if(Math.hypot(drag.b[0]-drag.a[0],drag.b[1]-drag.a[1])>8){push();D.tests.push({pts:[drag.a,drag.b],m:PMAT});}drag=null;look=null;store();ui2();draw();return;}if(drag&&drag.make==='essai'){if(drag.pl.length>1){push();D.tests.push({pts:drag.pl,m:PMAT});}drag=null;look=null;store();ui2();draw();return;}
 if(drag&&drag.make==='obj'){var a3=drag.a,b3=drag.b;if(Math.hypot(b3[0]-a3[0],b3[1]-a3[1])>8){push();var v3=[a3[0],a3[1],b3[0],b3[1]];if(OK==='gate')v3=v3.concat([0,0]);if(OK==='ent')v3=v3.concat(['same',0]);if(OK==='sup')v3=v3.concat([.5]);D.obj.push({k:OK,v:v3});sel={t:'o',i:D.obj.length-1};}drag=null;look=null;store();ui2();draw();return;}
 if(drag&&drag.make==='main'){if(drag.pl.length>1){push();var mt=MAT>=10?0:MAT;D.curves.push({pts:drag.pl,m:mt===2?0:mt});sel={t:'c',i:D.curves.length-1};}drag=null;look=null;store();ui2();draw();return;}
 if(drag&&drag.make){var a=drag.a,b=drag.b,L=Math.hypot(b[0]-a[0],b[1]-a[1]);
  if(L>8){push();if(drag.make==='droite'){D.w.push([a[0],a[1],b[0],b[1],MAT]);sel={t:'w',i:D.w.length-1};}
   else if(drag.make==='courbe'){var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,nx=-(b[1]-a[1])/L,ny=(b[0]-a[0])/L;D.curves.push({a:a,b:b,ctl:[Math.round(mx+nx*L*.3),Math.round(my+ny*L*.3)],m:MAT===2?0:MAT});sel={t:'c',i:D.curves.length-1};}
   else{D.fields.push([Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1]),FK]);sel={t:'f',i:D.fields.length-1};}}}
 drag=null;look=null;store();ui2();draw();}
function draw(){var c=cx;c.setTransform(K,0,0,K,0,0);c.fillStyle='#05070D';c.fillRect(0,0,360,480);
 c.strokeStyle='rgba(120,150,190,.08)';c.lineWidth=1;for(var x=0;x<=360;x+=20){c.beginPath();c.moveTo(x,0);c.lineTo(x,480);c.stroke();}for(var y=0;y<=480;y+=20){c.beginPath();c.moveTo(0,y);c.lineTo(360,y);c.stroke();}
 c.setLineDash([4,6]);c.strokeStyle='rgba(255,216,90,.22)';GX.forEach(function(x){c.beginPath();c.moveTo(x,0);c.lineTo(x,480);c.stroke();});GY.forEach(function(y){c.beginPath();c.moveTo(0,y);c.lineTo(360,y);c.stroke();});c.setLineDash([]);
 D.fields.forEach(function(f,i){var F=FIELDS.filter(function(q){return q[1]===f[4];})[0]||FIELDS[0];c.fillStyle=F[2];c.fillRect(f[0],f[1],f[2],f[3]);c.strokeStyle=sel&&sel.t==='f'&&sel.i===i?'#FFD85A':'rgba(255,255,255,.3)';c.lineWidth=1;c.strokeRect(f[0],f[1],f[2],f[3]);
  c.fillStyle='rgba(255,255,255,.7)';c.font='10px sans-serif';c.fillText(F[0],f[0]+4,f[1]+12);});
 var cp=D.cup;c.fillStyle='rgba(155,235,75,.15)';c.fillRect(cp[0],cp[1]-48,cp[2],48);c.strokeStyle=sel&&sel.t==='cup'?'#FFD85A':'#9BEB4B';c.lineWidth=3;c.beginPath();c.moveTo(cp[0],cp[1]-(cp[3]==='R'?0:56));c.lineTo(cp[0],cp[1]);c.lineTo(cp[0]+cp[2],cp[1]);c.lineTo(cp[0]+cp[2],cp[1]-(cp[3]==='L'?0:56));c.stroke();
 function col(m){return (MAT_L.filter(function(q){return q[1]===m;})[0]||MAT_L[0])[2];}
 function hs(q){c.fillStyle='#05070D';c.strokeStyle='#FFD85A';c.lineWidth=2;c.beginPath();c.rect(q[0]-7,q[1]-7,14,14);c.fill();c.stroke();c.beginPath();c.moveTo(q[0]-4,q[1]+4);c.lineTo(q[0]+4,q[1]-4);c.moveTo(q[0]+1,q[1]-4);c.lineTo(q[0]+4,q[1]-4);c.lineTo(q[0]+4,q[1]-1);c.stroke();}   /* poignée d'échelle */
 function hd(q,round){c.fillStyle='#FFD85A';c.strokeStyle='#05070D';c.lineWidth=2;c.beginPath();if(round)c.arc(q[0],q[1],7,0,6.3);else c.rect(q[0]-6,q[1]-6,12,12);c.fill();c.stroke();}
 c.lineCap='round';
 D.w.forEach(function(w,i){var on=sel&&sel.t==='w'&&sel.i===i;c.strokeStyle=col(w[4]);c.lineWidth=on?6:4;c.setLineDash(w[4]===9?[7,5]:[]);c.beginPath();c.moveTo(w[0],w[1]);c.lineTo(w[2],w[3]);c.stroke();if(w[4]===6||w[4]===7){c.save();c.globalAlpha=.25;c.setLineDash([3,5]);c.lineWidth=2;var ox=w[4]===7?50:0,oy=w[4]===6?50:0;c.beginPath();c.moveTo(w[0]-ox,w[1]-oy);c.lineTo(w[2]-ox,w[3]-oy);c.moveTo(w[0]+ox,w[1]+oy);c.lineTo(w[2]+ox,w[3]+oy);c.stroke();c.restore();}if(on){hd([w[0],w[1]]);hd([w[2],w[3]]);hd([(w[0]+w[2])/2,(w[1]+w[3])/2-34],1);hs([(w[0]+w[2])/2,(w[1]+w[3])/2+34]);}});
 c.setLineDash([]);D.curves.forEach(function(cu,i){var on=sel&&sel.t==='c'&&sel.i===i,Q=pts(cu);c.strokeStyle=col(cu.m);c.lineWidth=on?6:4;c.setLineDash(cu.m===9?[7,5]:[]);c.beginPath();c.moveTo(Q[0][0],Q[0][1]);Q.forEach(function(q){c.lineTo(q[0],q[1]);});c.stroke();
  if(on&&!cu.ctl){var ce2=cen(cu);hd([ce2[0],ce2[1]-34],1);hs([ce2[0],ce2[1]+34]);}
  if(on&&cu.ctl){var ce3=cen(cu);hd([ce3[0],ce3[1]-34],1);hs([ce3[0],ce3[1]+34]);c.strokeStyle='rgba(255,216,90,.6)';c.lineWidth=1;c.beginPath();c.moveTo(cu.a[0],cu.a[1]);c.lineTo(cu.ctl[0],cu.ctl[1]);c.lineTo(cu.b[0],cu.b[1]);c.stroke();hd(cu.a);hd(cu.b);hd(cu.ctl,1);}});
 if(sel&&sel.t==='f'){var f=D.fields[sel.i];hd([f[0]+f[2],f[1]+f[3]]);}
 if(sel&&sel.t==='cup')hd([D.cup[0]+D.cup[2],D.cup[1]-56]);
 if(sel&&sel.t==='e'&&D.tests[sel.i]){var tq=D.tests[sel.i].pts,tc=cen(tq);hd(tq[0]);hd(tq[tq.length-1]);hd([tc[0],tc[1]-34],1);hs([tc[0],tc[1]+34]);}
 c.setLineDash([]);if(!SIM&&LASTTR&&LASTTR.length){c.strokeStyle='rgba(255,216,90,.35)';c.lineWidth=1.5;c.setLineDash([3,4]);c.beginPath();LASTTR.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();c.setLineDash([]);}
 if(SIM&&SIM.tr.length){c.strokeStyle='rgba(255,216,90,.7)';c.lineWidth=2;c.beginPath();SIM.tr.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();}
 (D.obj||[]).forEach(function(o,i){var v=o.v,on=sel&&sel.t==='o'&&sel.i===i,ic=OBJ[o.k][1];c.font='15px sans-serif';c.textAlign='center';c.textBaseline='middle';
  if(OBJ[o.k][2]==='pt'){c.strokeStyle=on?'#FFD85A':'rgba(255,255,255,.4)';c.setLineDash([4,4]);c.lineWidth=1;c.beginPath();c.arc(v[0],v[1],v[2],0,6.3);c.stroke();c.setLineDash([]);c.fillStyle='#fff';c.fillText(ic,v[0],v[1]);if(on)hd([v[0]+v[2],v[1]],1);}
  else{c.strokeStyle=on?'#FFD85A':'#e7c6ff';c.lineWidth=o.k==='gate'?5:2;c.setLineDash(o.k==='gate'?[]:[5,4]);c.beginPath();c.moveTo(v[0],v[1]);c.lineTo(v[2],v[3]);c.stroke();c.setLineDash([]);c.fillStyle='#fff';c.fillText(ic,v[0],v[1]-10);c.fillText(o.k==='port'?'◑':ic,v[2],v[3]-10);if(on){hd([v[0],v[1]]);hd([v[2],v[3]]);}}});
 c.textAlign='start';c.textBaseline='alphabetic';
 if(SHOWREF&&D.ref.length){c.save();c.globalAlpha=.22;c.strokeStyle='#ffffff';c.lineWidth=7;c.setLineDash([10,6]);D.ref.forEach(function(sp){c.beginPath();sp.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();});c.setLineDash([]);
  if(REFTR){c.globalAlpha=.4;c.strokeStyle=REFOK?'#9BEB4B':'#ff6b6b';c.lineWidth=1.5;c.setLineDash([2,4]);c.beginPath();REFTR.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();c.setLineDash([]);}c.restore();}
 D.tests.forEach(function(t,i){var onT=sel&&sel.t==='e'&&sel.i===i;c.strokeStyle=onT?'#FFD85A':'#4DFFC3';c.setLineDash(t.m?[2,3]:[]);c.lineWidth=4;c.shadowColor='#4DFFC3';c.shadowBlur=6;c.beginPath();t.pts.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();c.shadowBlur=0;c.setLineDash([]);});
 var BP=SIM&&SIM.tr.length?SIM.tr[SIM.tr.length-1]:D.ball;c.fillStyle='#dff6ff';c.beginPath();c.arc(BP[0],BP[1],10.5,0,6.3);c.fill();c.globalAlpha=SIM?.3:1;c.beginPath();c.arc(D.ball[0],D.ball[1],10.5,0,6.3);c.fill();c.globalAlpha=1;if(sel&&sel.t==='ball'){c.strokeStyle='#FFD85A';c.lineWidth=2;c.stroke();}
 if(drag&&drag.make==='main'){c.strokeStyle=col(MAT);c.lineWidth=3;c.beginPath();drag.pl.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();}
 else if(drag&&drag.make==='essai'){c.strokeStyle='#4DFFC3';c.lineWidth=3;c.beginPath();drag.pl.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();}
 else if(drag&&drag.make){var a=drag.a,b=drag.b;c.strokeStyle=drag.make==='champ'?'#fff':drag.make==='essaiD'?'#4DFFC3':col(MAT);c.lineWidth=3;c.beginPath();if(drag.make==='champ')c.rect(Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1]));else{c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);}c.stroke();
  c.fillStyle='#fff';c.font='11px sans-serif';c.fillText(Math.round(Math.hypot(b[0]-a[0],b[1]-a[1]))+' u',b[0]+8,b[1]-8);}
 var lz=document.getElementById('qeLoupe'),xy=document.getElementById('qeXY');
 if(look){var q=look.p;c.strokeStyle=look.k==='bout'?'#9BEB4B':'#fff';c.lineWidth=1;c.beginPath();c.arc(q[0],q[1],7,0,6.3);c.moveTo(q[0]-13,q[1]);c.lineTo(q[0]+13,q[1]);c.moveTo(q[0],q[1]-13);c.lineTo(q[0],q[1]+13);c.stroke();
  c.strokeStyle='rgba(255,216,90,.95)';if(look.gx!=null){c.beginPath();c.moveTo(look.gx,0);c.lineTo(look.gx,480);c.stroke();}if(look.gy!=null){c.beginPath();c.moveTo(0,look.gy);c.lineTo(360,look.gy);c.stroke();}
  var lc=lz.getContext('2d');lz.style.display='block';lc.clearRect(0,0,110,110);lc.save();lc.beginPath();lc.arc(55,55,53,0,6.3);lc.clip();
  lc.drawImage(cv,(q[0]-18)*K,(q[1]-18)*K,36*K,36*K,0,0,110,110);lc.restore();lc.strokeStyle='#FFD85A';lc.lineWidth=2;lc.beginPath();lc.arc(55,55,53,0,6.3);lc.stroke();
  xy.textContent=(look.deg!=null?'rotation '+look.deg+'°   ':'')+Math.round(q[0])+' , '+Math.round(q[1])+(look.k==='bout'?'  ● accroché à un bout':'');}
 else if(SIM){lz.style.display='none';}
 else{lz.style.display='none';xy.textContent={sel:'Touche un élément (particule et zone comprises) puis glisse ; poignée ronde au‑dessus = rotation, carrée dessous = échelle ; ⊕ = aimant',gomme:'Touche un élément pour l’effacer',main:'Trace librement',droite:'Glisse du début à la fin',courbe:'Glisse du début à la fin, puis tire la poignée ronde',champ:'Glisse pour dessiner la zone'}[TOOL]||'';}}
function install(){var slot=CUR.n-1,L=LEVELS[slot];L.w=D.w.filter(function(w){return w[4]!==9&&w[4]!==6&&w[4]!==7;}).map(function(w){return w.slice();});L.curves=D.curves.filter(function(c){return c.m!==9;}).map(function(c){return {pts:pts(c),m:c.m};});
 L.ball=D.ball.slice();L.cup=[D.cup[0],D.cup[1],D.cup[2],D.cup[3]||'B'];L.nd=[];L.wind=[];L.grav=[];
 D.fields.forEach(function(f){var r=[f[0],f[1],f[2],f[3]];if(f[4]==='nd')L.nd.push(r);else if(f[4]==='w_up')L.wind.push(r.concat([0,-.6]));else if(f[4]==='w_r')L.wind.push(r.concat([.3,0]));else if(f[4]==='w_l')L.wind.push(r.concat([-.3,0]));
  else if(f[4]==='g_inv')L.grav.push(r.concat([0,-.45]));else if(f[4]==='g_low')L.grav.push(r.concat([0,.12]));else if(f[4]==='g_hi')L.grav.push(r.concat([0,.9]));});
 ['mz','rails','mag','port','mov','star','optsol','gate','ent','sup','det','tdil'].forEach(function(k){L[k]=null;});['mag','port','gate','ent','sup','det'].forEach(function(k){var a=D.obj.filter(function(o){return o.k===k;}).map(function(o){return o.v.slice();});if(a.length)L[k]=a;});
 var td=D.fields.filter(function(f){return f[4]==='tdil';}).map(function(f){return [f[0],f[1],f[2],f[3],.38];});if(td.length)L.tdil=td;L.softball=D.soft||undefined;L.mov=D.w.filter(function(w){return w[4]===6||w[4]===7;}).map(function(w){return {seg:[w[0],w[1],w[2],w[3]],amp:50,spd:.022,ax:w[4]===7?1:0,ay:w[4]===6?1:0};});if(!L.mov.length)L.mov=null;L.ink=D.ink;L.pal='S'+(pal(CUR).p.indexOf(1)>=0?'B':'')+(pal(CUR).p.indexOf(3)>=0?'A':'')+(pal(CUR).p.indexOf(5)>=0?'C':'');L.n=CUR.code+' (essai)';L.tip=CUR.type;L._cv=null;L._jn=null;L._rb=null;
 L.walls=L.w.slice();var cp=L.cup;L.walls.push([cp[0],cp[1],cp[0]+cp[2],cp[1],0]);if(cp[3]!=='L')L.walls.push([cp[0]+cp[2],cp[1],cp[0]+cp[2],cp[1]-56,0]);if(cp[3]!=='R')L.walls.push([cp[0],cp[1],cp[0],cp[1]-56,0]);L.zone=[cp[0],cp[1]-48,cp[2],48];
 try{S.unlocked=131;TUTO.load({v:1,i:1,s:TUTO._tools.concat(['nd','spike','bounce','palB','boost','palA','ice','wind','grav'])},0);}catch(e){}goto('game');loadLevel(slot);
 return D.tests.map(function(t){return {pts:t.pts,len:plen(t.pts),birth:0,mat:t.m};});}
function plen(P){var l=0;for(var i=1;i<P.length;i++)l+=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);return l;}
function used(){var u=0;D.tests.forEach(function(t){u+=plen(t.pts)*(PM.filter(function(m){return m[1]===t.m;})[0]||PM[0])[4];});return Math.round(u);}
/* la solution de référence est rejouée instantanément après chaque modification : sa trajectoire suit le décor en temps réel */
function refSim(){REFTR=null;REFOK=null;if(!D.ref.length||mode!=='edit'||SIM)return;try{install();S.strokes=D.ref.map(function(sp){return {pts:sp,len:plen(sp),birth:0,mat:D.refmat||0};});S.ink=9999;document.getElementById('bPlay').click();var tr=[];
  for(var k=0;k<1200&&S.mode==='run';k++){physics();if(k%2===0)tr.push([Math.round(S.ball.x),Math.round(S.ball.y)]);}REFOK=S.mode==='success';REFTR=tr;loadLevel(CUR.n-1);}catch(e){}}
function toGame(){var st=install();mode='game';document.getElementById('qeRoot').style.display='none';document.getElementById('qeBack').style.display='block';S.strokes=st;}
/* test intégré : le moteur du jeu tourne derrière l'éditeur ; on montre la particule et sa traînée sur la toile d'édition */
function sim(){var b=document.getElementById('qeRun');if(SIM){LASTTR=SIM.tr;SIM=null;b.textContent='▶';try{loadLevel(CUR.n-1);}catch(e){}draw();return;}
 if(used()>D.ink){document.getElementById('qeXY').textContent='⚠ Les essais dépassent l’encre du niveau ('+used()+' / '+D.ink+')';return;}
 LASTTR=null;var st=install();S.strokes=st;S.ink=D.ink;SIM={tr:[],t:0};b.textContent='■';try{document.getElementById('bPlay').click();}catch(e){}
 (function step(){if(!SIM)return;SIM.t++;try{SIM.tr.push([Math.round(S.ball.x),Math.round(S.ball.y)]);}catch(e){}
  draw();var m=S.mode;document.getElementById('qeXY').textContent=m==='success'?'✔ RÉUSSITE — la particule est dans la zone':m==='fail'||m==='dead'?'✕ ÉCHEC':'… la particule roule ('+Math.round(SIM.t/60*10)/10+' s)';
  if(m==='run'||SIM.t<20)requestAnimationFrame(step);else{b.textContent='↺';SIM.done=1;LASTTR=SIM.tr;}})();}
function toEdit(){mode='edit';SIM=null;try{document.querySelectorAll('.veil.on').forEach(function(v){v.classList.remove('on');});}catch(e){}document.getElementById('qeRoot').style.display='block';document.getElementById('qeBack').style.display='none';fit();draw();}
function payload(){return {fichier:fname(CUR),defi:CUR,ball:D.ball,cup:D.cup,w:D.w,curves:D.curves,fields:D.fields,obj:D.obj,soft:D.soft,ink:D.ink,essais:D.tests,ref:D.ref,note:D.note,date:new Date().toISOString()};}
function download(){var s=JSON.stringify(payload());var t=document.getElementById('qeOut');t.value=s;t.style.display='block';
 if(DL){DL.save({filename:fname(CUR),data:s}).catch(function(){});return;}
 try{var f=new File([s],fname(CUR),{type:'application/json'});if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:fname(CUR)}).catch(function(){});return;}}catch(e){}
 try{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([s],{type:'application/json'}));a.download=fname(CUR);document.body.appendChild(a);a.click();a.remove();}catch(e){}}
function listSaved(){if(DB){DB.collection('niveaux').get().then(function(q){var o=q.docs.map(function(d){var v=d.data();return v&&v.code;}).filter(Boolean).sort();document.getElementById('qeSaved').textContent=o.length?'Enregistrés (en ligne, lisibles par Claude) : '+o.join(' · '):'Aucun niveau enregistré';}).catch(function(){});return;}
 var o=[];try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&k.indexOf('QED:')===0)o.push(k.slice(4));}}catch(e){}o.sort();document.getElementById('qeSaved').textContent=o.length?'Enregistrés sur cet appareil : '+o.join(' · '):'Aucun niveau enregistré';}
function fit(){var st=document.getElementById('qeStage'),top=st.getBoundingClientRect().top+document.getElementById('qeRoot').scrollTop,w=Math.min(st.clientWidth||360,(window.innerHeight-top-196)*.75);   /* toile + barre d'outils tiennent dans l'écran */   /* toile pleine largeur : la précision prime, la page défile */cv.style.width=w+'px';cv.style.height=(w*4/3)+'px';K=cv.width/360;}
function setCard(){var c=CUR;document.getElementById('qeCard').innerHTML='<div><b>'+c.code+' · '+c.type+'</b> — '+c.forme+'</div><div>'+c.monde+' · niveau '+c.n+' · '+c.temps+'<br><b>Type</b> : '+c.type+' · <b>Idée reçue à faire tomber</b> : '+c.hyp+'<br><b>Vérité du monde</b> : '+c.verite+' · <b>Éléments</b> : '+c.mats+'<br><i>Le joueur essaie d\'abord une idée évidente qui échoue, puis comprend. Aucun élément décoratif. Lisible en 10 s. Rien dans la zone.</i><br><span style="color:#8A97A6">Fichier : '+fname(c)+'</span></div>';
 D=load(c);hist=[];sel=null;if(window.__mkMats)__mkMats();refSim();inkUI();if(DB)DB.doc('niveaux/'+c.code).get().then(function(sn){if(sn.exists&&CUR===c){try{var o=JSON.parse(sn.data().json);D=norm(o.ball?o:fromLevel(c));document.getElementById('qeNote').value=D.note||'';refSim();draw();}catch(e){}}}).catch(function(){});document.getElementById('qeNote').value=D.note||'';ui2();draw();}
function applyMat(m,f){if(!sel)return false;push();if(sel.t==='w'&&m!=null)D.w[sel.i][4]=m;else if(sel.t==='c'&&m!=null)D.curves[sel.i].m=m===2?0:m;else if(sel.t==='f'&&f)D.fields[sel.i][4]=f;else{hist.pop();return false;}store();draw();return true;}
var OK='mag';
function SCALE(){var m=0;(ORIG||[]).forEach(function(L){if(L.ink>m)m=L.ink;});return Math.max(m||600,D?D.ink:0);}
function inkUI(){var u=used(),r=document.getElementById('qeInkBar');if(!r)return;var SC=SCALE();document.getElementById('qeInkS').textContent=SC;var pm=Math.min(100,100*D.ink/SC);document.getElementById('qeInkOff').style.width=pm+'%';document.getElementById('qeInkMax').style.left=pm+'%';var U=document.getElementById('qeInkUse');U.style.width=Math.min(100,100*u/SC)+'%';U.style.background=u>D.ink?'linear-gradient(90deg,#FF7A7A,#ff6b6b)':'';
 document.getElementById('qeInkT').textContent='consommée '+u+' · max '+D.ink+(D.ref.length?' · réf. '+Math.round(D.ref.reduce(function(a,sp){return a+plen(sp);},0)*((PM.filter(function(m){return m[1]===(D.refmat||0);})[0]||PM[0])[4]))+(REFOK===false?' ✕':REFOK?' ✔':''):'');}
function ui2(){[].forEach.call(document.querySelectorAll('#qeTools button'),function(x){x.className=x.id==='qeMag'?(MAGON?'on':''):(x.dataset.t===TOOL?'on':'');});[].forEach.call(document.querySelectorAll('#qePM button'),function(x){x.className=(x.dataset.pd?TOOL==='essaiD':(TOOL==='essai'&&+x.dataset.pm===PMAT))?'on':'';});[].forEach.call(document.querySelectorAll('#qeMats button[data-o]'),function(x){x.className=TOOL==='obj'&&x.dataset.o===OK?'on':'';});
 [].forEach.call(document.querySelectorAll('#qeMats button'),function(x){x.className=+x.dataset.m===MAT?'on':'';});
 [].forEach.call(document.querySelectorAll('#qeFk button'),function(x){x.className=x.dataset.f===FK?'on':'';});
 [].forEach.call(document.querySelectorAll('#qeMats button,#qeFk button'),function(x){x.style.opacity=(TOOL==='champ'?x.dataset.f!==undefined:x.dataset.m!==undefined)||TOOL==='sel'||TOOL==='gomme'?1:.35;});
 var tn={essaiD:'Essai en ligne droite — comme le joueur (retouche ╱ pour quitter)',essai:'Essai main levée — comme le joueur (retouche pour quitter)',obj:'Objet : '+(OBJ[OK]||[''])[0]+((OBJ[OK]||[])[2]==='seg'?' — glisse de l’entrée à la sortie':' — touche pour poser'),main:'Main levée',droite:'Ligne droite',courbe:'Courbe',champ:'Zone',gomme:'Gomme',sel:'Choisir / déplacer / tourner — touche une matière pour l’appliquer à l’objet choisi'}[TOOL],mn=(MAT_L.filter(function(m){return m[1]===MAT;})[0]||MAT_L[0])[0],fn=(FIELDS.filter(function(f){return f[1]===FK;})[0]||FIELDS[0])[0];
 document.getElementById('qeTip').textContent=tn+(TOOL==='sel'||TOOL==='gomme'?'':' · '+(TOOL==='champ'?fn:TOOL==='essai'||TOOL==='obj'?'':mn));return;
 var sp=document.getElementById('qeSel');if(!sel){sp.innerHTML='';return;}
 var lab={w:'Mur',c:'Courbe',f:'Champ',ball:'Particule',cup:'Zone',e:'Trait d’essai',o:'Objet'}[sel.t];var h='<span>'+lab+' :</span>';
 if(sel.t==='w'||sel.t==='c')h+=MAT_L.map(function(m){return '<button data-sm="'+m[1]+'" style="color:'+m[2]+'">'+m[0]+'</button>';}).join('');
 if(sel.t==='e')h+=PM.map(function(m){return '<button data-se="'+m[1]+'" style="color:'+m[2]+'">'+m[0]+'</button>';}).join('');
 if(sel.t==='f')h+=FIELDS.map(function(f){return '<button data-sf="'+f[1]+'">'+f[0]+'</button>';}).join('');
 if(sel.t==='cup')h+='<button data-cw="-10">Plus étroite</button><button data-cw="10">Plus large</button>';
 if(sel.t!=='ball'&&sel.t!=='cup')h+='<button data-del="1" style="color:#ff6b6b">Supprimer</button>';sp.innerHTML=h;
 [].forEach.call(sp.querySelectorAll('button'),function(b){b.onclick=function(){push();var d=b.dataset;
  if(d.sm!==undefined){var m=+d.sm;if(sel.t==='w')D.w[sel.i][4]=m;else D.curves[sel.i].m=m===2?0:m;}
  if(d.se!==undefined)D.tests[sel.i].m=+d.se;if(d.sf)D.fields[sel.i][4]=d.sf;if(d.cw)D.cup[2]=Math.max(40,D.cup[2]+(+d.cw));
  if(d.del){if(sel.t==='w')D.w.splice(sel.i,1);if(sel.t==='c')D.curves.splice(sel.i,1);if(sel.t==='f')D.fields.splice(sel.i,1);if(sel.t==='e')D.tests.splice(sel.i,1);if(sel.t==='o')D.obj.splice(sel.i,1);sel=null;}
  store();ui2();draw();};});}
function build(){snapLevels();var css=document.createElement('style');css.textContent=
 '#qeRoot{position:fixed;inset:0;z-index:100000;background:#05070D;overflow-y:auto;-webkit-overflow-scrolling:touch;color:#EAF6FF;font:13px -apple-system,sans-serif;padding:calc(env(safe-area-inset-top,0px) + 4px) 6px calc(env(safe-area-inset-bottom,0px) + 24px)}'+
 '#qeRoot button{background:#121a26;color:#EAF6FF;border:1px solid #2a3a4e;border-radius:9px;padding:9px 10px;font:600 12px -apple-system,sans-serif;margin:2px}#qeRoot button.on{border-color:#FFD85A;color:#FFD85A;background:#1e1a08}'+
 '#qeRoot select,#qeRoot input{background:#0b111b;color:#EAF6FF;border:1px solid #2a3a4e;border-radius:8px;padding:8px;font:14px -apple-system,sans-serif;width:100%;box-sizing:border-box}#qeRoot textarea{width:100%;box-sizing:border-box;background:#0b111b;color:#8A97A6;border:1px solid #2a3a4e;border-radius:8px}'+
 '.qeLab{font:700 10px -apple-system,sans-serif;letter-spacing:.12em;color:#8A97A6;margin:6px 2px 0}.qeRow{display:flex;flex-wrap:wrap;gap:2px;margin:4px 0}.qeRow>*{flex:1 0 auto}#qeCard{background:#0b111b;border:1px solid #23324a;border-radius:10px;padding:8px;line-height:1.45;margin:4px 0;font-size:12px}'+
 '#qeStage{position:relative;display:flex;flex-direction:column;align-items:center}#qeBar button{min-width:0;height:40px;padding:0 6px!important;font-size:19px!important;line-height:1}#qeBar .qeRow{flex-wrap:nowrap;overflow-x:auto}#qeBar .qeRow>*{flex:1 1 0;min-width:0;margin:1px!important}#qeRun{border-color:#9BEB4B!important;color:#9BEB4B!important}#qeInk{flex:1 1 auto!important;position:relative;height:40px;margin:2px 4px;touch-action:none;cursor:ew-resize}#qeInkL{position:absolute;left:0;top:2px;font:600 9px -apple-system,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:#8A97A6}#qeInkT{position:absolute;right:0;top:1px;font:600 10px -apple-system,sans-serif;color:#EAF6FF}#qeInkBar{position:absolute;left:0;right:0;top:19px;height:5px;border-radius:999px;background:#16202C}#qeInkOff{position:absolute;left:0;top:0;height:5px;width:0;border-radius:999px;background:#FFD85A;opacity:.45}#qeInkUse{position:absolute;left:0;top:0;height:5px;width:0;border-radius:999px;background:linear-gradient(90deg,#4DD9FF,#4DFFC3);box-shadow:0 0 8px rgba(77,255,195,.7)}#qeInkMax{position:absolute;top:-4px;width:3px;height:13px;margin-left:-1.5px;border-radius:2px;background:#FFD85A;box-shadow:0 0 6px #FFD85A}#qeInk0,#qeInkS{position:absolute;top:28px;font:600 9px -apple-system,sans-serif;color:#5d6b7c}#qeInk0{left:0}#qeInkS{right:0}#qeTip{font-size:10.5px;color:#8A97A6;text-align:center;height:14px;overflow:hidden;white-space:nowrap}.qeSec{margin-top:14px;border-top:1px solid #1d2a3c;padding-top:6px}#qeCv{touch-action:none;border:1px solid #23324a;border-radius:10px}#qeLoupe{position:absolute;left:6px;top:6px;width:110px;height:110px;border-radius:55px;display:none;pointer-events:none}'+
 '#qeXY{font-size:11px;color:#8A97A6;text-align:center;margin:3px 0;height:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#qeSel{display:flex;flex-wrap:nowrap;overflow-x:auto;align-items:center;gap:2px;height:46px}#qeSel span{color:#FFD85A;font-weight:600;margin:0 6px}'+
 '#qeBack{position:fixed;right:10px;top:calc(env(safe-area-inset-top,0px) + 54px);z-index:100001;display:none;background:#FFD85A;color:#05070D;border:0;border-radius:999px;padding:11px 15px;font:700 14px -apple-system,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.5)}#qeOut{display:none;height:70px;font:10px monospace}';
 document.head.appendChild(css);var R=document.createElement('div');R.id='qeRoot';
 R.innerHTML='<div id="qeStage"><canvas id="qeCv" width="720" height="960"></canvas><canvas id="qeLoupe" width="110" height="110"></canvas><div id="qeXY"></div></div>'+
 '<div id="qeBar"><div class="qeRow" id="qeTools"><button data-t="main" title="Main levée">✎</button><button data-t="droite" title="Ligne droite">╱</button><button data-t="courbe" title="Courbe">◠</button><button data-t="champ" title="Zone (interdite, vent, gravité)">▭</button><button data-t="gomme" title="Gomme">⌫</button><button data-t="sel" title="Choisir, déplacer, tourner, agrandir (poignée carrée sous la forme)">✥</button><button id="qeMag" title="Aimant : bouts, grille et angles">⊕</button>'+
 '<button data-t="essai" title="Essai : tracer comme le joueur" style="color:#4DFFC3">✦</button><button id="qeD" title="Dupliquer l’objet choisi">⧉</button><button id="qeU" title="Annuler">↶</button><button id="qeR" title="Refaire">↷</button><button id="qeRun" title="Lâcher la particule (test)" class="run">▶</button></div>'+
 '<div class="qeRow" id="qeMats"></div><div class="qeRow" id="qeTest"><span id="qePM" style="display:flex;gap:2px;flex:0 0 auto"></span><button id="qeEye" title="Afficher / masquer la solution de référence">👁</button><button id="qeClr" title="Effacer les essais">✦⌫</button></div>'+
 '<div class="qeRow"><div id="qeInk"><span id="qeInkL">ÉNERGIE</span><div id="qeInkBar"><div id="qeInkOff"></div><div id="qeInkUse"></div><div id="qeInkMax"></div></div><span id="qeInk0">0</span><span id="qeInkS"></span><span id="qeInkT"></span></div></div><div id="qeTip"></div></div>'+
 '<div class="qeSec"><div class="qeLab">DÉFI</div><div class="qeRow"><select id="qeW"></select><select id="qeP"></select></div><div id="qeCard"></div>'+
 '<input id="qeNote" placeholder="Note : idée · leurre · « il essaie A, échoue car B, comprend C »"><div id="qeSel"></div></div>'+
 '<div class="qeSec"><div class="qeLab">FICHIERS</div><div class="qeRow"><button id="qeS">💾 Enregistrer / partager</button><button id="qeI">📂 Ouvrir</button><button id="qeT">🎮 Essayer dans le jeu</button><button id="qeG">↺ Version du jeu</button><button id="qeC">✕ Vider</button></div><input type="file" id="qeF" accept=".json,application/json" style="display:none">'+
 '<div id="qeSaved" style="font-size:11px;color:#8A97A6;margin:4px 0"></div><textarea id="qeOut" readonly></textarea></div>';
 document.body.appendChild(R);var back=document.createElement('button');back.id='qeBack';back.textContent='✎ Retour à l’éditeur';back.onclick=toEdit;document.body.appendChild(back);
 cv=document.getElementById('qeCv');cx=cv.getContext('2d');
 var sw=document.getElementById('qeW'),sp=document.getElementById('qeP');W.forEach(function(n,i){var o=document.createElement('option');o.value=i;o.textContent='Monde '+(i+1)+' · '+n;sw.appendChild(o);});
 function fillP(){sp.innerHTML='';for(var p=0;p<12;p++){var c=card(+sw.value,p),o=document.createElement('option');o.value=p;o.textContent=c.code+' · '+TY[PLAN[+sw.value][p]]+([2,5,7,9,11].indexOf(p)>=0?' · machine':'');sp.appendChild(o);}}
 sw.onchange=function(){fillP();CUR=card(+sw.value,0);setCard();};sp.onchange=function(){CUR=card(+sw.value,+sp.value);setCard();};
 window.__mkMats=function(){var MM=document.getElementById('qeMats');MM.innerHTML='';var P=pal(CUR);
 MAT_L.filter(function(m){return P.d.indexOf(m[1])>=0;}).forEach(function(m){var b=document.createElement('button');b.textContent=m[3];b.title=m[0];b.style.color=m[2];b.dataset.m=m[1];b.onclick=function(){MAT=m[1];if(TOOL==='sel'&&applyMat(m[1],null)){ui2();return;}if(TOOL==='champ'||TOOL==='sel'||TOOL==='gomme')TOOL='droite';ui2();draw();};MM.appendChild(b);});
 FIELDS.filter(function(f){return P.f.indexOf(f[1])>=0;}).forEach(function(f){var b=document.createElement('button');b.textContent=f[3];b.title=f[0];b.dataset.f=f[1];b.onclick=function(){FK=f[1];if(TOOL==='sel'&&applyMat(null,f[1])){ui2();return;}TOOL='champ';ui2();draw();};MM.appendChild(b);});
 P.o.forEach(function(k){var b=document.createElement('button');b.textContent=OBJ[k][1];b.title=OBJ[k][0];b.dataset.o=k;b.onclick=function(){OK=k;TOOL='obj';ui2();draw();};MM.appendChild(b);});
 if(WP[Math.floor((CUR.n-1)/12)].soft){var b2=document.createElement('button');b2.textContent=D.soft?'● mou':'○ mou';b2.title='Particule en corps mou';b2.onclick=function(){push();D.soft=!D.soft;b2.textContent=D.soft?'● mou':'○ mou';store();};MM.appendChild(b2);}
 var PMb=document.getElementById('qePM');PMb.innerHTML='';PM.filter(function(m){return P.p.indexOf(m[1])>=0;}).forEach(function(m){var b=document.createElement('button');b.textContent=m[3];b.title='Essai en '+m[0];b.style.color=m[2];b.dataset.pm=m[1];b.onclick=function(){if(sel&&sel.t==='e'&&(TOOL==='sel')){push();D.tests[sel.i].m=m[1];PMAT=m[1];store();ui2();draw();return;}if((TOOL==='essai'||TOOL==='essaiD')&&PMAT===m[1]){TOOL='sel';ui2();draw();return;}PMAT=m[1];TOOL='essai';ui2();draw();};PMb.appendChild(b);});
 var bD=document.createElement('button');bD.textContent='╱';bD.title='Essai en ligne droite (comme le joueur)';bD.style.color='#4DFFC3';bD.dataset.pd='1';bD.onclick=function(){TOOL=TOOL==='essaiD'?'sel':'essaiD';ui2();draw();};PMb.appendChild(bD);
 if(P.p.indexOf(PMAT)<0)PMAT=0;ui2();};
 document.getElementById('qeMag').onclick=function(){MAGON=!MAGON;try{localStorage.setItem('QED_mag',MAGON?'1':'0');}catch(e){}ui2();draw();};
 [].forEach.call(document.querySelectorAll('#qeTools button[data-t]'),function(b){b.onclick=function(){TOOL=(TOOL===b.dataset.t&&b.dataset.t!=='sel')?'sel':b.dataset.t;ui2();draw();};});
 document.getElementById('qeU').onclick=function(){if(hist.length){redo.push(JSON.stringify(D));D=JSON.parse(hist.pop());sel=null;store();ui2();draw();}};
 document.getElementById('qeR').onclick=function(){if(redo.length){hist.push(JSON.stringify(D));D=JSON.parse(redo.pop());sel=null;store();ui2();draw();}};
 document.getElementById('qeRun').onclick=sim;
 document.getElementById('qeEye').onclick=function(e){e.preventDefault();SHOWREF=!SHOWREF;this.textContent=SHOWREF?'👁':'🚫';this.style.opacity=SHOWREF?1:.5;draw();};
 document.getElementById('qeClr').onclick=function(){if(D.tests.length){push();D.tests=[];store();draw();}};
 (function(){var G=document.getElementById('qeInk'),on=false;function setI(e){var r=document.getElementById('qeInkBar').getBoundingClientRect();var x=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));D.ink=Math.max(5,Math.round(x*SCALE()/5)*5);inkUI();}G.addEventListener('pointerdown',function(e){on=true;try{G.setPointerCapture(e.pointerId);}catch(x){}setI(e);e.preventDefault();});G.addEventListener('pointermove',function(e){if(on)setI(e);});G.addEventListener('pointerup',function(){if(on){on=false;store();}});G.addEventListener('pointercancel',function(){on=false;});})();
 document.getElementById('qeD').onclick=function(){if(!sel||sel.t==='ball'||sel.t==='cup')return;push();var o;
  if(sel.t==='w'){o=D.w[sel.i].slice();o[0]+=16;o[1]+=16;o[2]+=16;o[3]+=16;D.w.push(o);sel={t:'w',i:D.w.length-1};}
  else if(sel.t==='c'){o=JSON.parse(JSON.stringify(D.curves[sel.i]));if(o.ctl)['a','b','ctl'].forEach(function(k){o[k]=[o[k][0]+16,o[k][1]+16];});else o.pts=o.pts.map(function(q){return [q[0]+16,q[1]+16];});D.curves.push(o);sel={t:'c',i:D.curves.length-1};}
  else if(sel.t==='e'){o={pts:D.tests[sel.i].pts.map(function(q){return [q[0]+16,q[1]+16];}),m:D.tests[sel.i].m};D.tests.push(o);sel={t:'e',i:D.tests.length-1};}
  else{o=D.fields[sel.i].slice();o[0]+=16;o[1]+=16;D.fields.push(o);sel={t:'f',i:D.fields.length-1};}TOOL='sel';store();ui2();draw();};
 document.getElementById('qeT').onclick=toGame;document.getElementById('qeS').onclick=function(){store();download();};
 document.getElementById('qeI').onclick=function(){document.getElementById('qeF').click();};
 document.getElementById('qeF').onchange=function(e){var f=e.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(){try{var o=JSON.parse(r.result);push();D={ball:o.ball,cup:o.cup,w:o.w||[],curves:o.curves||[],fields:o.fields||[],note:o.note||''};store();draw();}catch(x){alert('Fichier illisible');}};r.readAsText(f);};
 document.getElementById('qeC').onclick=function(){if(confirm('Tout effacer pour ce défi ?')){push();D=blank();store();sel=null;ui2();draw();}};
 document.getElementById('qeG').onclick=function(){if(confirm('Revenir à la version actuelle du niveau dans le jeu ?')){push();D=fromLevel(CUR);document.getElementById('qeNote').value=D.note;sel=null;store();ui2();draw();}};
 document.getElementById('qeNote').oninput=function(){D.note=this.value;store();};
 cv.addEventListener('pointerdown',down);cv.addEventListener('pointermove',move);cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
 if(typeof claude!=='undefined'&&claude.use){claude.use('db').then(function(d){DB=d;if(DB){listSaved();setCard();}}).catch(function(){});claude.use('downloads').then(function(d){DL=d;}).catch(function(){});}
 window.addEventListener('resize',function(){fit();draw();});fillP();CUR=card(0,0);setCard();fit();ui2();draw();listSaved();}
window.QE={card:card,fname:fname};setTimeout(build,700);
})();
