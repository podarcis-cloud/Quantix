/* QFXE — moteur d'effets de Quantone (R366). Partagé par Quantone et, au lot suivant, par les pistes de Track.
   Un effet = {id, fam, fr, en, cost 1–3, P:[[clé, fr, en, min, max, défaut]…], make(c,T) → {in,out,set(v),stop()}}.
   Une chaîne = jusqu'à 4 effets ; un effet « off » n'est JAMAIS construit (zéro calcul). Que des nœuds Web Audio natifs :
   fonctionne aussi dans un OfflineAudioContext (export, blocs Track). Les effets lourds (autotune, décaleur…) viendront de FX_bank. */
(function(){
'use strict';
var MAXFX=4,DEFS={},ORDER=[];
var FAM={dyn:['Dynamique & ton','Dynamics & tone'],col:['Couleur','Color'],mod:['Modulation','Modulation'],spc:['Espace','Space']};
function def(id,fam,fr,en,cost,P,make,nomix){DEFS[id]={id:id,fam:fam,fr:fr,en:en,cost:cost,P:P,make:make,mix:!nomix};ORDER.push(id);}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function sm(p,v,c){ /* changement lissé d'un AudioParam (pas de clic) */
  try{p.setTargetAtTime(v,c.currentTime,.03);}catch(e){try{p.value=v;}catch(e2){}}}
function bq(c,type,f,q,g){var b=c.createBiquadFilter();b.type=type;b.frequency.value=f;if(q!=null)b.Q.value=q;if(g!=null)b.gain.value=g;return b;}
function lfo(c,type,f){var o=c.createOscillator();o.type=type;o.frequency.value=f;o.start();return o;}
function noiseBuf(c){if(c._qfxN)return c._qfxN;var n=Math.floor(c.sampleRate*2),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0),i;for(i=0;i<n;i++)d[i]=Math.random()*2-1;return (c._qfxN=b);}
var CV={};
function curve(kind,q){var k=kind+q;if(CV[k])return CV[k];var n=1024,a=new Float32Array(n),i,x,K;
  for(i=0;i<n;i++){x=i/(n-1)*2-1;
    if(kind==='s'){K=1+q/20*12;a[i]=Math.tanh(K*x)/Math.tanh(K);}                       /* saturation douce */
    else if(kind==='f'){K=1+q/20*7;a[i]=Math.sin(K*x*1.5707963);}                          /* repli d'onde */
    else{var L=Math.pow(2,q);a[i]=Math.round(x*L)/L;}}                                       /* bits */
  return (CV[k]=a);}
function irFor(c,sec){var key=Math.round(sec*10),M=c._qfxIR||(c._qfxIR={});if(M[key])return M[key];
  var sr=c.sampleRate,n=Math.max(1000,Math.floor(sr*key/10)),b=c.createBuffer(2,n,sr),ch,i,d,lp;
  for(ch=0;ch<2;ch++){d=b.getChannelData(ch);lp=0;for(i=0;i<n;i++){var t=i/n;lp+=((Math.random()*2-1)-lp)*(.55-.35*t);d[i]=lp*Math.pow(1-t,2.4)*(i<sr*.004?i/(sr*.004):1)*1.6;}}
  return (M[key]=b);}
function mixc(a,b,m){return a+(b-a)*m;}

/* ── Dynamique & ton ── */
def('eq3','dyn','Égaliseur 3 bandes','3‑band EQ',1,[['a','Graves','Low',-12,12,0],['c','Médiums','Mid',-12,12,0],['b','Aigus','High',-12,12,0]],function(c){
  var l=bq(c,'lowshelf',150,null,0),m=bq(c,'peaking',1000,.8,0),h=bq(c,'highshelf',5500,null,0);l.connect(m);m.connect(h);
  return {in:l,out:h,set:function(v){sm(l.gain,v.a,c);sm(m.gain,v.c,c);sm(h.gain,v.b,c);},stop:function(){}};},1);
def('comp','dyn','Compresseur','Compressor',1,[['a','Seuil','Threshold',-40,-4,-22],['b','Gain','Makeup',0,12,4]],function(c){
  var k=c.createDynamicsCompressor(),g=c.createGain();k.ratio.value=4;k.attack.value=.006;k.release.value=.16;k.knee.value=12;k.connect(g);
  return {in:k,out:g,set:function(v){sm(k.threshold,v.a,c);sm(g.gain,Math.pow(10,v.b/20),c);},stop:function(){}};},1);
def('wah','dyn','Filtre auto (wah)','Auto‑filter',2,[['a','Vitesse','Rate',.1,8,1.2],['b','Profondeur','Depth',0,1,.7]],function(c){
  var f=bq(c,'bandpass',900,4.5),o=lfo(c,'sine',1),g=c.createGain();o.connect(g);g.connect(f.frequency);f.frequency.value=900;
  return {in:f,out:f,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b*800,c);},stop:function(){try{o.stop();}catch(e){}}};});

/* ── Couleur ── */
def('sat','col','Saturation douce','Soft saturation',1,[['a','Drive','Drive',0,1,.4],['b','Ton','Tone',0,1,.7]],function(c){
  var w=c.createWaveShaper(),lp=bq(c,'lowpass',9000,.5);w.curve=curve('s',8);w.connect(lp);
  return {in:w,out:lp,set:function(v){w.curve=curve('s',Math.round(v.a*20));sm(lp.frequency,mixc(1500,14000,v.b),c);},stop:function(){}};});
def('fold','col','Repli d’onde','Wave folder',1,[['a','Intensité','Amount',0,1,.4],['b','Sortie','Output',0,1,.7]],function(c){
  var w=c.createWaveShaper(),g=c.createGain();w.curve=curve('f',8);w.connect(g);
  return {in:w,out:g,set:function(v){w.curve=curve('f',Math.round(v.a*20));sm(g.gain,v.b,c);},stop:function(){}};});
def('crush','col','Bits (lo‑fi numérique)','Bit crusher',1,[['a','Bits','Bits',3,12,6],['b','Éclat','Bright',0,1,.8]],function(c){
  var w=c.createWaveShaper(),lp=bq(c,'lowpass',9000,.5);w.curve=curve('b',6);w.connect(lp);
  return {in:w,out:lp,set:function(v){w.curve=curve('b',Math.round(v.a)||6);sm(lp.frequency,mixc(1200,16000,v.b),c);},stop:function(){}};});
def('lofi','col','Cassette','Cassette',2,[['a','Usure','Wear',0,1,.5],['b','Souffle','Hiss',0,1,.3]],function(c){
  var i=c.createGain(),lp=bq(c,'lowpass',4200,.6),hp=bq(c,'highpass',90,.5),dl=c.createDelay(.05),o=lfo(c,'sine',.55),og=c.createGain(),o2=lfo(c,'triangle',6.3),og2=c.createGain(),o3=c.createGain(),
    ns=c.createBufferSource(),ng=c.createGain(),out=c.createGain();
  dl.delayTime.value=.006;o.connect(og);og.connect(dl.delayTime);o2.connect(og2);og2.connect(dl.delayTime);i.connect(hp);hp.connect(lp);lp.connect(dl);dl.connect(out);
  ns.buffer=noiseBuf(c);ns.loop=true;ns.connect(ng);ng.connect(out);ns.start();
  return {in:i,out:out,set:function(v){sm(lp.frequency,mixc(7000,1800,v.a),c);sm(og.gain,.0004+v.a*.0016,c);sm(og2.gain,.00005+v.a*.0004,c);sm(ng.gain,v.b*.02,c);},stop:function(){try{o.stop();o2.stop();ns.stop();}catch(e){}}};},1);
def('ring','col','Modulation en anneau','Ring modulator',1,[['a','Fréquence','Frequency',0,1,.45],['b','Éclat','Bright',0,1,.6]],function(c){
  var g=c.createGain(),o=lfo(c,'sine',200),lp=bq(c,'lowpass',9000,.5);g.gain.value=0;o.connect(g.gain);g.connect(lp);
  return {in:g,out:lp,set:function(v){sm(o.frequency,40*Math.pow(60,v.a),c);sm(lp.frequency,mixc(1500,14000,v.b),c);},stop:function(){try{o.stop();}catch(e){}}};});

/* ── Modulation ── */
def('chorus','mod','Chorus','Chorus',2,[['a','Vitesse','Rate',.1,4,.8],['b','Profondeur','Depth',0,1,.5]],function(c){
  var i=c.createGain(),out=c.createGain(),d1=c.createDelay(.06),d2=c.createDelay(.06),o1=lfo(c,'sine',.8),o2=lfo(c,'sine',.93),g1=c.createGain(),g2=c.createGain(),w=c.createGain();
  d1.delayTime.value=.017;d2.delayTime.value=.024;o1.connect(g1);g1.connect(d1.delayTime);o2.connect(g2);g2.connect(d2.delayTime);i.connect(d1);i.connect(d2);d1.connect(w);d2.connect(w);w.gain.value=.7;w.connect(out);
  return {in:i,out:out,set:function(v){sm(o1.frequency,v.a,c);sm(o2.frequency,v.a*1.17,c);sm(g1.gain,v.b*.006,c);sm(g2.gain,v.b*.007,c);},stop:function(){try{o1.stop();o2.stop();}catch(e){}}};});
def('flanger','mod','Flanger','Flanger',2,[['a','Vitesse','Rate',.05,2,.3],['b','Résonance','Feedback',0,.9,.5]],function(c){
  var i=c.createGain(),out=c.createGain(),d=c.createDelay(.02),fb=c.createGain(),o=lfo(c,'sine',.3),g=c.createGain();
  d.delayTime.value=.004;g.gain.value=.0026;o.connect(g);g.connect(d.delayTime);i.connect(d);d.connect(out);d.connect(fb);fb.connect(d);
  return {in:i,out:out,set:function(v){sm(o.frequency,v.a,c);sm(fb.gain,v.b*.85,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('phaser','mod','Phaser','Phaser',2,[['a','Vitesse','Rate',.1,3,.5],['b','Profondeur','Depth',0,1,.6]],function(c){
  var i=c.createGain(),out=c.createGain(),o=lfo(c,'sine',.5),g=c.createGain(),ap=[],k,prev=i;
  o.connect(g);for(k=0;k<4;k++){var f=bq(c,'allpass',500+k*350,.7);g.connect(f.frequency);prev.connect(f);prev=f;ap.push(f);}
  prev.connect(out);
  return {in:i,out:out,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b*700,c);},stop:function(){try{o.stop();}catch(e){}}};});
def('trem','mod','Trémolo','Tremolo',1,[['a','Vitesse','Rate',.5,14,5],['b','Profondeur','Depth',0,1,.6]],function(c){
  var g=c.createGain(),o=lfo(c,'sine',5),og=c.createGain();og.gain.value=.3;g.gain.value=.7;o.connect(og);og.connect(g.gain);
  return {in:g,out:g,set:function(v){sm(o.frequency,v.a,c);sm(og.gain,v.b*.5,c);sm(g.gain,1-v.b*.5,c);},stop:function(){try{o.stop();}catch(e){}}};},1);
def('pan','mod','Auto‑pan','Auto‑pan',1,[['a','Vitesse','Rate',.1,6,.6],['b','Largeur','Width',0,1,.7]],function(c){
  if(!c.createStereoPanner){var p0=c.createGain();return {in:p0,out:p0,set:function(){},stop:function(){}};}
  var p=c.createStereoPanner(),o=lfo(c,'sine',.6),g=c.createGain();o.connect(g);g.connect(p.pan);
  return {in:p,out:p,set:function(v){sm(o.frequency,v.a,c);sm(g.gain,v.b,c);},stop:function(){try{o.stop();}catch(e){}}};},1);

/* ── Espace ── */
def('ping','spc','Délai ping‑pong','Ping‑pong delay',2,[['a','Temps (tempo)','Time (tempo)',0,1,.35],['b','Répétitions','Repeats',0,.85,.4]],function(c,T){
  var i=c.createGain(),dL=c.createDelay(2),dR=c.createDelay(2),f1=c.createGain(),f2=c.createGain(),lp=bq(c,'lowpass',3800,.5),mg=c.createChannelMerger(2),out=c.createGain();
  i.connect(dL);dL.connect(lp);lp.connect(f1);f1.connect(dR);dR.connect(f2);f2.connect(dL);dL.connect(mg,0,0);dR.connect(mg,0,1);mg.connect(out);
  return {in:i,out:out,set:function(v){var t=Math.min(1.8,60/Math.max(30,T&&T.tempo||90)*(.25+.75*v.a));sm(dL.delayTime,t,c);sm(dR.delayTime,t,c);sm(f1.gain,v.b,c);sm(f2.gain,v.b,c);},stop:function(){}};});
def('plate','spc','Réverbération plaque','Plate reverb',3,[['a','Taille','Size',0,1,.5],['b','Amorti','Damping',0,1,.5]],function(c){
  var cv=c.createConvolver(),lp=bq(c,'lowpass',8000,.5),cur=-1;cv.connect(lp);
  return {in:cv,out:lp,set:function(v){var s=Math.round((.4+v.a*2)*10)/10;if(s!==cur){cur=s;cv.buffer=irFor(c,s);}sm(lp.frequency,mixc(14000,1800,v.b),c);},stop:function(){}};});

/* ── Chaînes prêtes ── */
var CHAINS={
  cassette:{fr:'Cassette chaude',en:'Warm cassette',list:[{t:'lofi',a:.6,b:.35,m:1},{t:'sat',a:.3,b:.5,m:.6},{t:'chorus',a:.4,b:.3,m:.3}]},
  espace:{fr:'Espace profond',en:'Deep space',list:[{t:'ping',a:.5,b:.45,m:.3},{t:'plate',a:.75,b:.6,m:.45}]},
  robot:{fr:'Robot',en:'Robot',list:[{t:'ring',a:.35,b:.5,m:.55},{t:'crush',a:6,b:.7,m:1},{t:'comp',a:-24,b:5,m:1}]},
  psyche:{fr:'Psychédélique',en:'Psychedelic',list:[{t:'phaser',a:.4,b:.8,m:.6},{t:'ping',a:.4,b:.5,m:.35},{t:'plate',a:.6,b:.4,m:.35}]},
  chaud:{fr:'Chaleur analogique',en:'Analog warmth',list:[{t:'eq3',a:3,c:-1,b:-2,m:1},{t:'sat',a:.35,b:.55,m:1},{t:'comp',a:-20,b:3,m:1}]}};

/* ── chaîne ── */
function norm(x){var d=DEFS[x.t],v={m:x.m==null?(d.mix?.5:1):x.m},k;d.P.forEach(function(p){v[p[0]]=x[p[0]]==null?p[5]:clamp(+x[p[0]],p[3],p[4]);});return v;}
function live(list){var o=[];(list||[]).forEach(function(x){if(x&&x.on!==0&&DEFS[x.t]&&o.length<MAXFX)o.push(x);});return o;}
function sig(list){return live(list).map(function(x){return x.t;}).join('|');}
function wrap(c,d,u,v){
  if(!d.mix)return {in:u.in,out:u.out,m:null};
  var i=c.createGain(),o=c.createGain(),dr=c.createGain(),wt=c.createGain();i.connect(dr);dr.connect(o);i.connect(u.in);u.out.connect(wt);wt.connect(o);
  return {in:i,out:o,dr:dr,wt:wt};}
function apply(c,U,list){var L=live(list);if(L.length!==U.length)return false;
  L.forEach(function(x,k){var u=U[k],v=norm(x);u.u.set(v);if(u.w.dr){sm(u.w.dr.gain,1-v.m,c);sm(u.w.wt.gain,v.m,c);}});return true;}
function chain(c,list,T){
  var L=live(list),ci=c.createGain(),co=c.createGain(),U=[],prev=ci,n0=0;
  L.forEach(function(x){var d=DEFS[x.t],u=d.make(c,T||{}),w=wrap(c,d,u),v=norm(x);u.set(v);if(w.dr){w.dr.gain.value=1-v.m;w.wt.gain.value=v.m;}prev.connect(w.in);prev=w.out;U.push({d:d,u:u,w:w,x:x});});
  prev.connect(co);
  return {in:ci,out:co,units:U,sig:sig(list),cost:L.reduce(function(a,x){return a+DEFS[x.t].cost;},0),
    set:function(l){return apply(c,U,l);},
    kill:function(){U.forEach(function(q){try{q.u.stop();}catch(e){}});try{ci.disconnect();}catch(e){}U.forEach(function(q){try{q.w.in.disconnect();q.w.out.disconnect();}catch(e){}});try{co.disconnect();}catch(e){}}};}
function cost(list){return live(list).reduce(function(a,x){return a+DEFS[x.t].cost;},0);}
window.QFXE={defs:DEFS,order:ORDER,fam:FAM,chains:CHAINS,max:MAXFX,chain:chain,sig:sig,cost:cost,live:live,norm:norm,
  fresh:function(t){var d=DEFS[t];if(!d)return null;var x={t:t,on:1,m:d.mix?.5:1};d.P.forEach(function(p){x[p[0]]=p[5];});return x;},
  clean:function(list){var o=[];(Array.isArray(list)?list:[]).forEach(function(x){if(x&&DEFS[x.t]&&o.length<MAXFX)o.push(JSON.parse(JSON.stringify(x)));});return o;}};
})();
