/* R286 — captation des parcours dans l'aperçu publié (artefact) : chaque essai joué (tracés, trajectoire de la particule, encre,
   issue, durée de dessin) est écrit dans la base de l'artefact, collection « parcours_beta » (1 document par essai).
   Seulement dans l'aperçu (capacité `db`) ; rien dans le site GitHub Pages (là : envoi par e-mail, avec consentement).
   Respecte le refus du joueur (consent2 = 'no'). Les essais non encore enregistrés sont repris au chargement. */
(function(){
 'use strict';
 if(typeof claude==='undefined'||!claude||typeof claude.use!=='function'||!window.QRUNS)return;
 var COL='parcours_beta',SENT='quantix.db.sent',sent={},q=[],busy=false,dbp=null;
 try{sent=JSON.parse(localStorage.getItem(SENT)||'{}')||{};}catch(e){}
 function saveSent(){try{localStorage.setItem(SENT,JSON.stringify(sent));}catch(e){}}
 function refused(){try{return localStorage.getItem('quantix.runs.consent2')==='no';}catch(e){return false;}}
 function ident(r,pid){return pid+'_'+(r.i+1)+'_'+r.n+'_'+String(r.t||'').replace(/\D/g,'');}
 function mk(r,st){
  var L=(typeof LEVELS!=='undefined'&&LEVELS[r.i])||{},d={};
  for(var k in r)d[k]=r[k];
  d.pid=st.id;d.build=st.build;d.lang=st.lang;d.sw=st.w;d.sh=st.h;d.dpr=st.dpr;d.src='apercu';
  d.lvl=r.i+1;d.nom=L.n||'';d.monde=L.wd||0;d.at=new Date().toISOString();
  return d;}
 function push(r,st){
  if(refused()||!r)return;var id=ident(r,st.id);if(sent[id]||q.some(function(x){return x.id===id;}))return;
  q.push({id:id,doc:mk(r,st)});pump();}
 function pump(){
  if(busy||!q.length)return;busy=true;
  if(!dbp)dbp=claude.use('db');
  Promise.resolve(dbp).then(function(db){
   if(!db){busy=false;return;}   /* base absente (hors connexion, droits) : l'essai reste local et sera repris au prochain chargement */
   (function next(){
    if(!q.length){busy=false;return;}
    var it=q[0];
    db.doc(COL+'/'+it.id).set(it.doc).then(function(){sent[it.id]=1;saveSent();q.shift();next();})
     .catch(function(){busy=false;setTimeout(pump,20000);});})();
  }).catch(function(){busy=false;});}
 var prev=window.QRUNS.onrun;
 window.QRUNS.onrun=function(r,st){try{if(prev)prev(r,st);}catch(e){}push(r,st);};
 setTimeout(function(){try{var st=window.QRUNS.get();(st.runs||[]).forEach(function(r){push(r,st);});}catch(e){}},2500);   /* reprise des essais antérieurs */
 /* R289 : journal d'événements complet (session, traits, outils, contacts, vues…) → collection « evenements_beta », un document par lot */
 if(window.QEV){window.QEV.sink=function(batch,st){
  return Promise.resolve(dbp||(dbp=claude.use('db'))).then(function(db){
   if(!db||!batch.length)return Promise.reject(new Error('db'));
   var f=batch[0],id=st.pid+'_'+f.s+'_'+f.k;
   return db.doc('evenements_beta/'+id).set({st:st,src:'apercu',at:new Date().toISOString(),n:batch.length,ev:batch});});};
  setTimeout(function(){try{window.QEV.flush();}catch(e){}},3000);}
 window.QDB={pending:function(){return q.length;},sent:function(){return Object.keys(sent).length;}};
})();
