/* QUANTONE — formats de fichier (R403) : .qpt (un pattern) et .qxp v2 (une track).
   Partagé par Pattern (quantone.html) et Track (morceau.html).
   - Écrit : .qpt, .qxp v2. Lit pour toujours : .qpt, .qx, .json (préréglage), .qxp v1 et v2.
   - Les échantillons de la banque intégrée sont désignés par référence (`ref:"pool:p13-1"`) au lieu d'être copiés.
     On ne remplace un PCM par une référence que si le son correspond vraiment (durée, niveau, corrélation ≥ 0,99).
   - `au` (son rendu du pattern) est facultatif. */
(function(){
'use strict';
var BASE=(function(){try{return new URL('../assets/audio/pool/',document.currentScript.src).href;}catch(e){return '../assets/audio/pool/';}})();
/* noms des sons intégrés (copie de POOLN de quantone.html ; e2e-qpt vérifie qu'ils sont identiques) */
var POOLN={1:['Rabot','Scie','Marteau','Ponçage','Copeaux','Serre-joint','Planche','Clous'],2:['Conduits','Gloussements','Érosion','Bouche','Coulée','Daxo grave','Daxo aigu','Claquements'],3:['Chaîne','Tapis','Cliquet','Rouleaux','Paquets','Courroie','Pistons','Bouche'],4:['Glace','Verre','Gouttes','Glisse','Neige','Gel','Carillon','Éclats'],5:['Souffle grave','Sifflement','Turbine','Volets','Tourbillon','Tuyau','Lèvres','Sable'],6:['Échappement','Ressort','Peigne','Rochet','Engrenage','Verre','Souffle fin','Tic-tacs'],7:['Chute','Rebond','Orbite','Doppler','Sub','Cloche grave','Poussière','Attraction'],
 8:['Frappe forge','Tôle','Claquement acier','Vis','Chaîne longue','Enclume','Clic acier','Raclement'],9:['Pas de verre','Éclat','Cliquetis','Ping aigu','Carillon','Bouteille','Tic cristal','Éclats pluie'],10:['Bûche','Planche','Claquoirs','Grattement','Sciure','Marimba','Bloc','Scie rauque'],11:['Grosse peau','Caisse peau','Mains','Doigts','Balai','Conga','Rim peau','Voix de gorge'],12:['Kick poussière','Caisse lo‑fi','Clap lo‑fi','Craquements','Souffle bande','Tom étouffé','Pop','Sillon'],13:['Goutte grave','Éclaboussure','Glace craque','Plic aigu','Glace tourbillon','Bulle','Glaçon','Ruisseau'],14:['Piston','Vapeur','Pistons rapides','Valve','Vapeur longue','Tuyau','Relais','Moteur'],15:['Kick numérique','Snare bruitée','Clap haché','Bruit 1 bit','FM sifflante','Blip FM','Clic carré','Bégaiement'],16:['Carton','Papier déchiré','Papier froissé','Grain','Sable versé','Boîte','Clic carton','Froissement'],17:['Sub profond','Laser','Scintillement','Tic stellaire','Souffle spatial','Radar','Zap','Nappe dérive']};
var FR=function(){try{var l=localStorage.getItem('qx.lang');if(l==='en'||l==='fr')return l==='fr';}catch(e){}return (navigator.language||'fr').slice(0,2)==='fr';};

/* ── utilitaires ── */
function hash(s){var h=5381,i;s=String(s);for(i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return (h>>>0).toString(36);}
function b64u8(u){var s='',i;for(i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s);}
function u8b64(s){var r=atob(s),u=new Uint8Array(r.length),i;for(i=0;i<r.length;i++)u[i]=r.charCodeAt(i);return u;}
function i16ToB64(a){return b64u8(new Uint8Array(a.buffer,a.byteOffset,a.byteLength));}
function b64ToI16(s){var u=u8b64(s);return new Int16Array(u.buffer,0,u.length>>1);}
function f32ToI16(d){var o=new Int16Array(d.length),i,v;for(i=0;i<d.length;i++){v=d[i];if(v!==v)v=0;v=Math.max(-1,Math.min(1,v));o[i]=v<0?Math.round(v*32768):Math.round(v*32767);}return o;}
function i16ToF32(a){var o=new Float32Array(a.length),i;for(i=0;i<a.length;i++)o[i]=a[i]/32768;return o;}
function clone(o){return o==null?o:JSON.parse(JSON.stringify(o));}
/* son rendu (it.au : Int16 l/r) ⇄ objet de fichier (base64) */
function auEnc(a){if(!a||!a.l)return null;return {sr:a.sr,len:a.len,codec:'pcm16',src:a.src||null,l:i16ToB64(a.l),r:i16ToB64(a.r||a.l)};}
function auDec(o){if(!o||!o.l)return null;try{var l=b64ToI16(o.l);return {sr:o.sr,len:o.len,src:o.src||'fichier',l:l,r:o.r?b64ToI16(o.r):l};}catch(e){return null;}}

/* ── sons intégrés ── */
function poolIds(name,slot){var o=[],w,k;for(w in POOLN)for(k=0;k<8;k++)if(POOLN[w][k]===name){var id='p'+w+'-'+(k+1);if(k+1===slot)o.unshift(id);else o.push(id);}return o;}
function poolUrl(id){var w=window,i;try{for(i=0;i<5&&w;i++){if(w.QXA&&w.QXA['pool/'+id])return w.QXA['pool/'+id];if(w.parent===w)break;w=w.parent;}}catch(e){}return BASE+id+'.mp3';}
var DEC={};
/* décodage au taux d'échantillonnage demandé (un OfflineAudioContext rééchantillonne au décodage) : même canal 0 que Pattern */
function poolPcm(id,sr){var k=id+'@'+sr;if(DEC[k])return DEC[k];
 DEC[k]=fetch(poolUrl(id)).then(function(r){if(!r.ok)throw new Error(r.status);return r.arrayBuffer();}).then(function(ab){
  var C=window.OfflineAudioContext||window.webkitOfflineAudioContext,c;try{c=new C(1,1,sr);}catch(e){c=new C(1,1,44100);}
  return new Promise(function(res,rej){var p=c.decodeAudioData(ab,res,rej);if(p&&p.then)p.then(res,rej);});}).then(function(b){var d=b.getChannelData(0),o=new Float32Array(d.length);o.set(d);return {d:o,sr:b.sampleRate};});
 DEC[k].catch(function(){delete DEC[k];});return DEC[k];}
/* le PCM stocké est-il ce son intégré ? Les décodeurs MP3 diffèrent par le silence de début et de fin (Safari garde ~18 ms) :
   on accepte un écart de longueur ≤ 0,1 s, une énergie totale à ±0,5 dB et une corrélation ≥ 0,99 après alignement (≤ 50 ms). */
function onset(a){for(var i=0;i<a.length;i++)if(Math.abs(a[i])>1e-3)return i;return 0;}
function same(a,b,sr){var na=a.length,nb=b.length;if(!na||!nb||Math.abs(na-nb)>.1*sr)return false;
 var D=16,ma=Math.floor(na/D),mb=Math.floor(nb/D),A=new Float32Array(ma),B=new Float32Array(mb),i,j,s;
 for(i=0;i<ma;i++){s=0;for(j=0;j<D;j++)s+=a[i*D+j];A[i]=s;}for(i=0;i<mb;i++){s=0;for(j=0;j<D;j++)s+=b[i*D+j];B[i]=s;}
 function corr(X,Y,lag){var sx=0,sy=0,sxy=0,n=Math.min(X.length,Y.length-lag),i0=Math.max(0,-lag),k,x,y;for(k=i0;k<n;k++){x=X[k];y=Y[k+lag];sxy+=x*y;sx+=x*x;sy+=y*y;}return sx>0&&sy>0?sxy/Math.sqrt(sx*sy):0;}
 var best=-2,bl=0,l,r,L=Math.ceil(.05*sr/D);for(l=-L;l<=L;l++){r=corr(A,B,l);if(r>best){best=r;bl=l;}}
 if(best<.9)return false;best=-2;for(l=bl*D-D;l<=bl*D+D;l++){r=corr(a,b,l);if(r>best)best=r;}
 var ea=0,eb=0;for(i=0;i<na;i++)ea+=a[i]*a[i];for(i=0;i<nb;i++)eb+=b[i]*b[i];
 return best>=.99&&Math.abs(10*Math.log10((ea+1e-12)/(eb+1e-12)))<=.5;}
/* recale un son intégré décodé sur l'original (les décodeurs ajoutent plus ou moins de silence au début) :
   empreinte = 128 moyennes de 32 échantillons du début de l'original ; on cherche le décalage (±50 ms) qui la retrouve, puis on garde n échantillons */
var FD=32,FN=128;
function fpOf(a){var o=[],i,j,s;for(i=0;i<FN;i++){s=0;for(j=0;j<FD;j++)s+=a[i*FD+j]||0;o.push(Math.round(s/FD*2e3));}return o;}
function fit(d,fp,n,sr){if(!(n>0))return d;var sh=0;
 if(fp&&fp.length){var L=Math.ceil(.05*sr/FD),M=FN+2*L+2,C=new Float32Array(M),i,j,s,best=-2,l,k;for(i=0;i<M;i++){s=0;for(j=0;j<FD;j++)s+=d[i*FD+j]||0;C[i]=s/FD*2e3;}
  for(l=-L;l<=L;l++){var sx=0,sy=0,sxy=0;for(k=0;k<fp.length;k++){if(k+l<0||k+l>=M)continue;sxy+=fp[k]*C[k+l];sx+=fp[k]*fp[k];sy+=C[k+l]*C[k+l];}var r=sx>0&&sy>0?sxy/Math.sqrt(sx*sy):-1;if(r>best){best=r;sh=l*FD;}}}
 var o=new Float32Array(n);for(var q=0;q<n;q++){var p=q+sh;if(p>=0&&p<d.length)o[q]=d[p];}return o;}
var VER={};   /* empreinte → référence déjà vérifiée */
function refFor(s){if(!s||!s.pcm)return Promise.resolve(null);var h=hash(s.pcm);if(VER[h]!==undefined)return Promise.resolve(VER[h]);
 var a=i16ToF32(b64ToI16(s.pcm)),sr=s.sr||44100,geo={fp:fpOf(a),n:a.length};
 if(s.src&&/^pool:/.test(s.src)){VER[h]={ref:s.src,fp:geo.fp,n:geo.n};return Promise.resolve(VER[h]);}   /* choisi dans la banque et pas retouché */
 var ids=poolIds(s.name,s.slot),i=0;if(!ids.length){VER[h]=null;return Promise.resolve(null);}
 function next(){if(i>=ids.length){VER[h]=null;return null;}var id=ids[i++];return poolPcm(id,sr).then(function(p){if(p.sr===sr&&same(a,p.d,sr)){VER[h]={ref:'pool:'+id,fp:geo.fp,n:geo.n};return VER[h];}return next();},function(){return next();});}
 return Promise.resolve().then(next);}

/* ── reconnaissance ── */
function kind(J){if(!J||typeof J!=='object')return null;
 if(J.q==='quantone-pattern')return 'qpt';if(J.q==='quantix-qx'&&J.preset)return 'qx';
 if(J.q==='quantone-morceau')return J.v>=2?'qxp2':'qxp1';
 if(J.quantone||Array.isArray(J.strokes)||(J.k&&typeof J.k==='object'))return 'preset';return null;}

/* ── .qpt ── */
/* qx (format interne, PCM) → .qpt ; un échantillon dont l'origine est connue (src « pool: ») est référencé tout de suite */
function fromQx(qx,meta,au){meta=meta||{};var inf=clone(qx.info)||{};if(au&&au.len)inf.len=au.len;
 var o={q:'quantone-pattern',v:1,app:'Quantone',build:window.QBUILD||undefined,id:meta.id||undefined,name:meta.name||undefined,proj:meta.proj||undefined,col:meta.col||undefined,cr:meta.cr||undefined,ver:meta.ver||undefined,
  info:inf,pat:clone(qx.preset),samples:(qx.samples||[]).map(function(s){var r={slot:s.slot,name:s.name,sr:s.sr,pcm:s.pcm,h:s.pcm?hash(s.pcm):undefined};if(s.src)r.src=s.src;return r;}),seed:null};
 if(au)o.au=au.l?auEnc(au):au;return o;}
/* remplace les PCM qui sont des sons intégrés par leur référence */
function slim(qpt){var o=clone(qpt);return Promise.all((o.samples||[]).map(function(s){if(!s.pcm){delete s.src;return null;}return refFor(s).then(function(R){delete s.src;if(R){s.ref=R.ref;s.n=R.n;s.fp=R.fp;delete s.pcm;}});})).then(function(){return o;});}
/* .qpt (ou qx / préréglage) → qx interne ; les références sont rechargées. `missing` = sons introuvables (hors ligne) */
function toQx(J){var k=kind(J),missing=[];
 if(k==='qx'){var q=clone(J);return Promise.resolve({qx:q,meta:{},au:null,missing:missing});}
 if(k==='preset'){var p=clone(J);return Promise.resolve({qx:{q:'quantix-qx',v:1,app:'Quantone',info:{world:p.world||0,tempo:p.k&&p.k.tempo?Math.round(p.k.tempo):undefined,strokes:(p.strokes||[]).length,samples:0},preset:p,samples:[]},meta:{},au:null,missing:missing});}
 if(k!=='qpt')return Promise.reject(new Error(FR()?'fichier non reconnu':'unknown file'));
 return Promise.all((J.samples||[]).map(function(s){
  if(s.pcm)return {slot:s.slot,name:s.name,sr:s.sr||44100,pcm:s.pcm};
  if(s.ref&&/^pool:/.test(s.ref)){var sr=s.sr||44100;return poolPcm(s.ref.slice(5),sr).then(function(p){var d=p.sr===sr?fit(p.d,s.fp,s.n,sr):p.d;return {slot:s.slot,name:s.name,sr:p.sr,pcm:i16ToB64(f32ToI16(d)),src:s.ref};},function(){missing.push(s.name||s.ref);return null;});}
  return null;})).then(function(S){
  var qx={q:'quantix-qx',v:1,app:'Quantone',info:clone(J.info)||{},preset:clone(J.pat),samples:S.filter(Boolean)};
  return {qx:qx,meta:{id:J.id,name:J.name,proj:J.proj,col:J.col,cr:J.cr,ver:J.ver},au:auDec(J.au),missing:missing};});}

/* ── .qxp ── */
/* v1 (blocs « qx » complets) → v2 : blocs « pat » allégés, échantillons perso mutualisés ; opt.au = {idBloc: son} */
function packQxp(v1,opt){opt=opt||{};var o={q:'quantone-morceau',v:2,app:'Quantone',name:opt.name||v1.name||undefined,bpm:v1.bpm,tracks:v1.tracks,clips:v1.clips,master:v1.master,loop:v1.loop,blocks:[],samples:{}};var AU={},nAu=0;
 return Promise.all((v1.blocks||[]).map(function(b){
  if(b.kind!=='qx')return Promise.resolve(clone(b));
  return slim(fromQx(b.qx||{},{})).then(function(q){delete q.au;delete q.id;delete q.name;delete q.app;delete q.build;
   (q.samples||[]).forEach(function(s){var h=s.h;if(!h)return;var e={sr:s.sr};if(s.pcm)e.pcm=s.pcm;else if(s.ref){e.ref=s.ref;e.n=s.n;e.fp=s.fp;}else return;o.samples[h]=e;['pcm','ref','n','fp','sr','h'].forEach(function(k){delete s[k];});s.sid=h;});   /* table partagée : un même son n'est écrit qu'une fois */
   var a=opt.au&&opt.au[b.id];if(a){AU[b.id]=a.l?auEnc(a):a;nAu++;}
   return {id:b.id,kind:'pat',name:b.name,len:b.len,loop:b.loop,lib:b.lib||null,libVer:b.libVer||0,col:b.col||null,pat:q};});})).then(function(B){o.blocks=B;if(nAu)o.au=AU;return o;});}
/* v2 → v1 (format interne de Track) ; chaque bloc peut porter son son (b.au, Int16) */
function unpackQxp(v2){var missing=[];if(kind(v2)==='qxp1')return Promise.resolve({p:v2,missing:missing});
 var S=v2.samples||{},A=v2.au||{};
 return Promise.all((v2.blocks||[]).map(function(b){
  if(b.kind!=='pat')return Promise.resolve(clone(b));
  var q=clone(b.pat)||{};q.q='quantone-pattern';(q.samples||[]).forEach(function(s){var e=s.sid&&S[s.sid];if(e){['sr','pcm','ref','n','fp'].forEach(function(k){if(e[k]!=null)s[k]=e[k];});s.h=s.sid;delete s.sid;}});
  return toQx(q).then(function(r){missing=missing.concat(r.missing);var o={id:b.id,kind:'qx',name:b.name,len:b.len,loop:b.loop,lib:b.lib||null,libVer:b.libVer||0,col:b.col||null,qx:r.qx};var a=auDec(A[b.id]);if(a)o.au=a;return o;});})).then(function(B){
  return {p:{q:'quantone-morceau',v:1,name:v2.name,bpm:v2.bpm,tracks:v2.tracks,clips:v2.clips,master:v2.master,loop:v2.loop,blocks:B},missing:missing};});}

/* lecture de n'importe quel fichier QUANTONE (objet JSON déjà analysé) */
function read(J){var k=kind(J);
 if(k==='qxp1'||k==='qxp2')return unpackQxp(J).then(function(r){return {type:'track',p:r.p,missing:r.missing,src:k};});
 return toQx(J).then(function(r){r.type='pattern';r.src=k;return r;});}
function parse(text){return JSON.parse(String(text).replace(/^﻿/,''));}
function missingMsg(m){if(!m||!m.length)return '';var fr=FR();return (fr?'Sons intégrés introuvables (hors ligne ?) : ':'Built-in sounds not found (offline?): ')+m.slice(0,4).join(', ')+(m.length>4?'…':'')+(fr?' — ces voix restent muettes.':' — these voices stay silent.');}
function fileName(name,ext){var s=String(name||'').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Za-z0-9 _-]+/g,'').trim().replace(/\s+/g,'-').slice(0,40);
 if(!s){var d=new Date();s=(ext==='qxp'?'track-':'pattern-')+d.getFullYear()+('0'+(d.getMonth()+1)).slice(-2)+('0'+d.getDate()).slice(-2)+'-'+('0'+d.getHours()).slice(-2)+('0'+d.getMinutes()).slice(-2);}return s+'.'+ext;}

/* ── import unique des anciens préréglages (localStorage « quantone.mine ») dans la bibliothèque ──
   Idempotent : identifiant dérivé du contenu, drapeau « qx.mineMigr ». La clé d'origine n'est jamais effacée. */
function migrateMine(cb){cb=cb||function(){};var L;try{if(localStorage.getItem('qx.mineMigr')==='1')return cb(0);L=JSON.parse(localStorage.getItem('quantone.mine')||'[]');}catch(e){return cb(0);}
 if(!Array.isArray(L)||!L.length){try{localStorage.setItem('qx.mineMigr','1');}catch(e){}return cb(0);}
 var COLS=['#72D6D2','#EE9AA8','#A99AEE','#EBC27A','#8ED9A0','#7FB4F0','#D58CE0','#F0AC8A'];
 try{var r=indexedDB.open('qxlib',1);r.onupgradeneeded=function(){r.result.createObjectStore('items',{keyPath:'id'});};r.onerror=function(){cb(0);};
  r.onsuccess=function(){var db=r.result,n=0,tx;try{tx=db.transaction('items','readwrite');}catch(e){return cb(0);}var os=tx.objectStore('items'),now=Date.now();
   L.forEach(function(p,i){if(!p||typeof p!=='object')return;var id='mig'+hash(JSON.stringify(p)),g=os.get(id);g.onsuccess=function(){if(g.result)return;var d=p.date?Date.parse(p.date):0,dt=d?new Date(d):null;
     var nm=(FR()?'Préréglage ':'Preset ')+(i+1)+(dt?' · '+('0'+dt.getDate()).slice(-2)+'/'+('0'+(dt.getMonth()+1)).slice(-2)+' '+('0'+dt.getHours()).slice(-2)+':'+('0'+dt.getMinutes()).slice(-2):'');
     os.put({id:id,proj:'Anciens préréglages',name:nm,col:COLS[i%COLS.length],ver:now,cr:d||now-(L.length-i),mig:1,
      qx:{q:'quantix-qx',v:1,app:'Quantone',info:{world:p.world||0,tempo:p.k&&p.k.tempo?Math.round(p.k.tempo):undefined,strokes:(p.strokes||[]).length,samples:0},preset:p,samples:[]}});n++;};});
   tx.oncomplete=function(){try{localStorage.setItem('qx.mineMigr','1');}catch(e){}cb(n);};tx.onerror=function(){cb(0);};};}catch(e){cb(0);}}

window.QPT={POOLN:POOLN,hash:hash,kind:kind,fromQx:fromQx,slim:slim,toQx:toQx,packQxp:packQxp,unpackQxp:unpackQxp,read:read,parse:parse,auEnc:auEnc,auDec:auDec,
 poolPcm:poolPcm,refFor:refFor,missingMsg:missingMsg,fileName:fileName,migrateMine:migrateMine,
 ACCEPT:'.qpt,.qx,.qxp,.json,application/json',size:function(o){return new Blob([JSON.stringify(o)]).size;}};
})();
