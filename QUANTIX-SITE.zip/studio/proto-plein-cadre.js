/* PROTOTYPE R190 « Plein cadre » — aperçu seulement. Reflet flou du rendu réel jusqu'aux bords, énergie et coins posés sur
   l'écran de jeu, hauteur du pied mesurée. Aucun changement du moteur : la toile garde sa taille, ses coordonnées, sa collision. */
(function(){var g=document.getElementById('game'),cv=document.getElementById('cv'),ft=g.querySelector('footer'),en=g.querySelector('.energy');
 var bl=document.createElement('canvas');bl.id='gbleed';g.insertBefore(bl,g.firstChild);var bx=bl.getContext('2d');
 var co=['tl','tr','bl','br'].map(function(k){var e=document.createElement('i');e.className='pcorner '+k;g.appendChild(e);return e;});
 var n=0;function step(){requestAnimationFrame(step);if(document.getElementById('app').dataset.screen!=='game')return;
  var gr=g.getBoundingClientRect(),r=cv.getBoundingClientRect(),fh=Math.round(ft.getBoundingClientRect().height);
  if(g.style.getPropertyValue('--pfh')!==fh+'px')g.style.setProperty('--pfh',fh+'px');
  var x=r.left-gr.left,y=r.top-gr.top;
  co[0].style.cssText='left:'+(x-5)+'px;top:'+(y-5)+'px';co[1].style.cssText='left:'+(x+r.width-5)+'px;top:'+(y-5)+'px';
  co[2].style.cssText='left:'+(x-5)+'px;top:'+(y+r.height-5)+'px';co[3].style.cssText='left:'+(x+r.width-5)+'px;top:'+(y+r.height-5)+'px';
  en.style.left=(x+14)+'px';en.style.width=(r.width-28)+'px';en.style.top=(y+8)+'px';
  return;var k=6,W=Math.ceil(gr.width/k),H=Math.ceil(gr.height/k);if(bl.width!==W||bl.height!==H){bl.width=W;bl.height=H;}
  try{bx.fillStyle='#05070D';bx.fillRect(0,0,W,H);var cx=(x+r.width/2)/k,cy=(y+r.height/2)/k,sw=r.width/k,sh=r.height/k;
   bx.drawImage(cv,cx-sw*1.5,cy-sh*1.25,sw*3,sh*2.5);bx.drawImage(cv,x/k,y/k,sw,sh);}catch(e){}}
 step();})();
