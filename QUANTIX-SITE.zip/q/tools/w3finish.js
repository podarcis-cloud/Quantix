/* w3finish.js — finalise un niveau du monde 3 : balayage fin, noyau (15–35 % des solutions), solution avec noyau la plus
   tolérante au doigt (±4 u sur chaque point). Écrit w3final.json.  OUT=... STEP=10 DA=.3 SECS=170 NT=30 node w3finish.js <k> */
const W3=require('./w3lab.js'),LAB=require('./lab.js'),C=require('./w3cand.js'),fs=require('fs');
const f=process.env.OUT||'w3final.json',out=fs.existsSync(f)?JSON.parse(fs.readFileSync(f)):{};
function tol(idx,c,w){let ok=0,n=0;for(let pi=0;pi<w.pts.length;pi++)for(const dx of [-4,0,4])for(const dy of [-4,0,4]){
  const pts=w.pts.map((q,i)=>i===pi?[q[0]+dx,q[1]+dy]:q);n++;if(W3.run(0,c,[{pts,mat:w.mat}]).ok)ok++;}return ok/n;}
for(const k of process.argv.slice(2)){const c=C[k],idx=24+ +k;
 const o=W3.sweep(idx,c,{grid:{step:+(process.env.STEP||10),da:+(process.env.DA||.3),lens:[25,40,60,85,115,150,190]},secs:+(process.env.SECS||170)});
 const st=LAB.star({wins:o.wins},[0,20,360,470]);let best=null,tried=0;
 if(st){const c2=Object.assign({},c,{star:[st.x,st.y]});
  const cand=o.wins.filter(w=>w.tr.some(q=>Math.hypot(q[0]-st.x,q[1]-st.y)<20.5)).slice(0,+(process.env.NT||30));
  for(const w of cand){tried++;const r=W3.run(idx,c2,[{pts:w.pts,mat:w.mat}]);if(!r.ok||!r.star)continue;const t=tol(idx,c2,w);
   if(!best||t>best.t)best={pts:w.pts,mat:w.mat,t};}}
 out[k]={n:c.n,gagnants:o.avec,sans:o.sans,coupe:o.coupe,star:st&&[st.x,st.y],starPct:st&&st.f,sol:best&&[best.pts],mat:best&&best.mat,tol:best&&Math.round(best.t*100)};
 fs.writeFileSync(f,JSON.stringify(out,null,1));
 console.log(`#${25+ +k} ${c.n.padEnd(16)} gagnants ${o.avec} (sans mécanique ${o.sans}) | noyau ${st?JSON.stringify([st.x,st.y])+' ('+Math.round(st.f*100)+' %)':'AUCUNE POSITION'} | solution avec noyau : ${best?'tolérance '+Math.round(best.t*100)+' % mat '+best.mat+' '+JSON.stringify(best.pts):'AUCUNE'} ${o.coupe?'[balayage coupé]':''}`);}
