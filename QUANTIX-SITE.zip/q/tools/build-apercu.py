"""build-apercu.py N [U] — aperçu jouable autonome ouvert sur la carte du monde N
(tous ses niveaux débloqués, rien n'est sauvegardé de plus). Sortie : /mnt/user-data/outputs/quantix-apercu-mondeN.html
Règle (demande utilisateur) : ne livrer que l'aperçu du monde en cours, pas tout le jeu."""
import base64,re,sys,os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));W=int(sys.argv[1]);U=int(sys.argv[2]) if len(sys.argv)>2 and sys.argv[2].isdigit() else W;SKIP='skipintro' in sys.argv  # skipintro : didacticiel d'ouverture considéré comme fait (outils d'édition proposés)  # U : débloquer les mondes jusqu'à U (ex. didacticiel : 1 3)
def uri(p):
    m={'jpg':'image/jpeg','png':'image/png','mp3':'audio/mpeg'}[p.rsplit('.',1)[1]]
    return 'data:%s;base64,%s'%(m,base64.b64encode(open(os.path.join(ROOT,p),'rb').read()).decode())
h=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
css=open(os.path.join(ROOT,'assets/css/quantix.css'),encoding='utf-8').read().replace('url(../img/ui/hero.jpg)','url('+uri('assets/img/ui/hero.jpg')+')')
h=h.replace('<link rel="manifest" href="manifest.webmanifest">\n','').replace('<link rel="apple-touch-icon" href="assets/img/ui/icon-192.png">','')
h=h.replace('<link rel="icon" href="assets/img/ui/icon-192.png" sizes="192x192">','<link rel="icon" href="%s" sizes="192x192">'%uri('assets/img/ui/icon-192.png'))
h=h.replace('<link rel="stylesheet" href="assets/css/quantix.css">','<style>\n'+css+'\n</style>')
for f in ['worldart','i18n','levels','visuals','tuto','editor','engine','sound']:
    js=open(os.path.join(ROOT,'assets/js/%s.js'%f),encoding='utf-8').read()
    for m in sorted(set(re.findall(r"assets/[A-Za-z0-9_./-]+\.(?:jpg|png|mp3)",js))):js=js.replace(m,uri(m))
    tag='<script src="assets/js/%s.js"></script>'%f;assert tag in h,f;h=h.replace(tag,'<script>\n'+js+'\n</script>')
# skipintro : si le joueur n'a pas encore d'état de didacticiel, il est traité comme ayant fini les mondes précédents :
# intro faite, fiches d'outils vues (sauf monde 1), éléments des niveaux précédents vus. Seules les règles NOUVELLES du monde s'affichent.
SKIPJS="if(!TUTO._intro()){var f0=worldRange(%d)[0],s0=[];if(f0>0){s0=TUTO._tools.slice();for(var j0=0;j0<f0;j0++)s0=s0.concat(TUTO._elemsOf(LEVELS[j0]));}TUTO.load({v:1,i:1,s:s0},0);if(typeof persist==='function')persist();}"%W
boot=('<script>/* APERÇU monde %d : ouverture directe sur sa carte, niveaux du monde débloqués */\n'
      'setTimeout(function(){try{%svar r=worldRange(%d);S.unlocked=Math.max(S.unlocked,worldRange(%d).slice(-1)[0]);openWorld(%d);}catch(e){console.log(e);}},450);</script>\n</body>')%(W,SKIPJS if SKIP else '',W,U,W)
h=h.replace('</body>',boot,1)
h=re.sub(r'<meta name="viewport" content="[^"]*">','<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">',h,count=1)
out='/mnt/user-data/outputs/quantix-apercu-monde%d.html'%W;open(out,'w',encoding='utf-8').write(h);print(out,'%.1f Mo'%(len(h.encode())/1e6))
