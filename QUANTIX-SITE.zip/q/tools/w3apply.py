"""w3apply.py N… — écrit dans levels.js les résultats de w3retune.json (bassin, encre, noyau, optsol, optmat) des niveaux donnés.
Correctif compté : chaque champ doit être trouvé une seule fois dans l'entrée du niveau, sinon ÉCHEC et arrêt."""
import json,re,sys
R='/home/claude/q/'
d=json.load(open(R+'tools/w3retune.json'))
p=R+'assets/js/levels.js';s=open(p,encoding='utf-8').read()
def arr(a):return '['+','.join(str(v) for v in a)+']'
for num in sys.argv[1:]:
    r=d[num];i=s.index("n:'%s'"%r['n']);j=s.index("tip:",i);seg=s[i:j]
    sol='['+','.join('['+','.join(arr(q) for q in st)+']' for st in r['optsol'])+']'
    reps=[(r"optsol:\[.*?\]\]\],","optsol:%s,"%sol),(r"optmat:\d+","optmat:%d"%r['optmat']),(r"ink:\d+","ink:%d"%r['ink']),
          (r"cup:\[[^\]]*\]","cup:[%d,%d,%d,'%s']"%tuple(r['cup'])),(r"star:\[[^\]]*\]","star:%s"%arr(r['star']))]
    for pat,new in reps:
        if len(re.findall(pat,seg))!=1:print('ÉCHEC',num,pat);sys.exit(1)
        seg=re.sub(pat,new,seg,count=1)
    s=s[:i]+seg+s[j:];print('OK #%s %s : exec %d%% int %d%% noyau %d%%'%(num,r['n'],r['P_exec']*100,r['P_int']*100,r['P_noyau']*100))
open(p,'w',encoding='utf-8').write(s)
