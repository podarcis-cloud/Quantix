/* w3tune.js — balaye des variantes d'un candidat et classe par nombre de gagnants (sans mécanique doit rester 0).
   node w3tune.js <nom> — les familles de variantes sont définies ci-dessous. */
const W3=require('./w3lab.js'),C=require('./w3cand.js');
const fam={
 butee:()=>{const o=[];for(const cx of [222,236,250])for(const wx of [312,322,334])for(const cy of [290,310])o.push({n:`cup ${cx},${cy} butée x${wx}`,idx:26,c:Object.assign({},C[2],{cup:[cx,cy,wx-cx-2,'R'],w:[[20,290,120,290,0],[120,290,180,232,3],[wx,150,wx,cy,0]]})});return o;},
 relais:()=>{const o=[];for(const g of [70,85,100])for(const dy of [20,32])for(const cy of [340,380]){
   const x1=120,e1=x1+40; // tapis 1 : de 120 à 160 ; fosse g ; tapis 2 ; fosse ; cup
   const b1=[120,290,165,290,3],b2=[165+g,290+dy,165+g+45,290+dy,3],cx=165+g+45+g;
   o.push({n:`relais g${g} dy${dy} cy${cy}`,idx:31,c:{n:'Deux tapis',ink:300,ball:[60,236],cup:[Math.min(cx,262),cy,90,'R'],nd:[[165,0,g,480]],w:[[20,290,120,290,0],b1,b2]}});}return o;}
,
 triage:()=>{const o=[];for(const [ex,ey] of [[215,250],[225,240],[230,232]])for(const cx of [282,296])for(const cy of [225,250]){
   o.push({n:`belt→${ex},${ey} cup ${cx},${cy}`,idx:34,c:{n:'Le triage',ink:300,pal:'SA',ball:[120,236],cup:[cx,cy,Math.min(66,356-cx),'R'],nd:[[20,0,30,480],[205,0,80,480]].slice(1),w:[[70,290,170,290,0],[170,290,ex,ey,3],[70,290,40,290,3],[20,470,60,470,2]]}});}return o;},
 ligne:()=>{const o=[];for(const cx of [250,270])for(const cy of [110,140,170,200])o.push({n:`cup ${cx},${cy}`,idx:35,c:Object.assign({},C[11],{cup:[cx,cy,90,'R']})});return o;},
 c33:()=>{const o=[];for(const cx of [10,30,50])for(const cy of [130,160,190])o.push({n:`cup ${cx},${cy}`,idx:32,c:Object.assign({},C[8],{cup:[cx,cy,80,'L']})});return o;},
 ligne2:()=>{const o=[];for(const cx of [236,244,252])for(const cy of [176,184,192])o.push({n:`cup ${cx},${cy}`,idx:35,c:Object.assign({},C[11],{cup:[cx,cy,Math.min(90,356-cx),'R']})});return o;},
 c26:()=>{const o=[];for(const cy of [300,320,340])for(const g of [[110,70],[100,86]])o.push({n:`cup y${cy} fosse ${g}`,idx:25,c:Object.assign({},C[1],{cup:[20,cy,90,'L'],nd:[[g[0],0,g[1],480]]})});return o;},
 c30:()=>{const o=[];for(const cx of [250,270,290])for(const cy of [140,165,190])o.push({n:`cup ${cx},${cy}`,idx:29,c:Object.assign({},C[5],{cup:[cx,cy,Math.min(80,356-cx),'R']})});return o;}
};
const name=process.argv[2],F=fam[name]();const step=+(process.env.STEP||20),secs=+(process.env.SECS||9);
const res=[];const t0=Date.now();
for(const v of F){if(Date.now()-t0>250000)break;const o=W3.sweep(v.idx,v.c,{grid:{step,da:.5,lens:[30,60,100,150]},secs});res.push([v.n,o.avec,o.sans,o.sansTrait[0]]);}
res.sort((a,b)=>b[1]-a[1]);res.slice(0,8).forEach(r=>console.log(r.join(' | ')));console.log('variantes évaluées',res.length,'/',F.length);
