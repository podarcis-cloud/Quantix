/* tutotest.js — non-régression du didacticiel (R37).
   - chaque entrée du catalogue a titre + texte en FR et EN ;
   - chaque démo se dessine sans exception sur toute sa boucle ;
   - le repérage de cible existe pour l'élément dans son premier niveau ;
   - état : neuf → intro en attente ; vétéran (seen=N) → intro faite, éléments déjà traversés marqués vus ;
   - aller-retour de sauvegarde, et saveState() contient bien le bloc « tuto » ;
   - tableau « où chaque élément apparaît pour la première fois » (position dans le monde). */
require('./load.js');
const X=globalThis.__X,TU=globalThis.TUTO;
let bad=0;function ok(c,m){console.log((c?'  OK  ':'  ÉCHEC ')+m);if(!c)bad++;}
const noop=new Proxy(function(){},{get:(t,k)=>k==='canvas'?{}:(k==='measureText'?()=>({width:40}):(/create(Radial|Linear)Gradient/.test(k)?()=>({addColorStop(){}}):noop)),apply:()=>noop,set:()=>true});
ok(!!TU,'TUTO exposé');
const ids=TU._cat.map(c=>c.id);
ids.forEach(id=>{for(const lg of ['fr','en'])if(!X.DICT[lg]['tt_'+id]||!X.DICT[lg]['td_'+id])ok(false,'clé manquante '+lg+' '+id);});
ok(true,ids.length+' entrées du catalogue, titres et textes présents en fr et en');
['tutoNew','tutoOk','tutoNext','tutoSkip','tutoHelp','tutoCodex','tutoCodexD','tutoOpen','tutoCodexSub','tutoLocked','ti_see','ti_ball','ti_goal','ti_core','ti_draw','ti_release','ti_adjust'].forEach(k=>{
  ok(X.DICT.fr[k]&&X.DICT.en[k],'clé '+k);});
let thrown=0;
ids.forEach(id=>{for(let t=0;t<300;t+=7){try{TU._demo(noop,id,t);}catch(e){thrown++;console.log('   démo',id,'t='+t,e.message);}}});
ok(thrown===0,'toutes les démos se dessinent sur leur boucle complète');
const first={};
X.LEVELS.forEach((lv,i)=>TU._elemsOf(lv).forEach(id=>{if(!(id in first))first[id]=i;}));
ids.filter(i=>i!=='basics'&&TU._tools.indexOf(i)<0).forEach(id=>{
  const i=first[id];const sh=(i===undefined)?null:TU._focus(id,X.LEVELS[i]);
  const chip=id.indexOf('pal')===0; /* puce de la palette : ciblée dans le DOM, pas sur le terrain */
  ok(i!==undefined&&(chip||sh.length>0),'élément atteignable et repérable : '+id+(i===undefined?'':' (niveau '+(i+1)+')'));});
console.log('\n  Première apparition (niveau global → monde, position) :');
Object.keys(first).sort((a,b)=>first[a]-first[b]).forEach(id=>{const i=first[id],w=X.LEVELS[i].wd;
  console.log('   '+id.padEnd(7)+' #'+String(i+1).padEnd(4)+'monde '+w+' · position '+(i-X.worldRange(w)[0]+1)+' / 12');});
/* outils d'édition : fiche + démo + mode de l'éditeur correspondant */
ok(TU._tools.length===4&&TU._tools.every(t=>ids.indexOf(t)>=0),'les 4 outils ont une entrée de catalogue');
/* marques d'emphase *mot* : toujours en nombre pair, jamais vides */
let badStar=0;for(const lg of ['fr','en'])Object.keys(X.DICT[lg]).filter(k=>/^(ti_|td_)/.test(k)).forEach(k=>{
  const v=X.DICT[lg][k],n=(v.match(/\*/g)||[]).length;if(n%2||/\*\s*\*/.test(v)){badStar++;console.log('   emphase incorrecte',lg,k);}});
ok(badStar===0,'marques d’emphase équilibrées dans tous les textes du didacticiel');
/* pas de HTML ni de crochets oubliés dans les textes */
let badTxt=0;for(const lg of ['fr','en'])Object.keys(X.DICT[lg]).filter(k=>/^(ti_|tt_|td_)/.test(k)).forEach(k=>{if(/[<>{}]/.test(X.DICT[lg][k])){badTxt++;console.log('   caractère suspect',lg,k);}});
ok(badTxt===0,'aucun HTML ni accolade dans les textes du didacticiel');
/* états */
TU.load(null,0);ok(TU._intro()===false&&Object.keys(TU._seen()).length===0,'partie neuve : intro à faire, rien de vu');
TU.load(null,6);
ok(TU._intro()===true&&!!TU._seen().nd&&!TU._seen().bounce,'vétéran (niveau 6 atteint) : intro faite, zone interdite vue, rebond pas encore');
TU.load({v:1,i:1,s:['nd','wind']},0);const s=TU.state();
ok(s.i===1&&s.s.join()==='nd,wind','aller-retour état → sauvegarde → état');
TU.load({v:1,i:1,s:[]},0);X.S.zen=false;TU.onLoad(1);
const pd=TU._pend();ok(pd&&pd.kind==='cards'&&pd.ids.slice(0,4).join()==='tdraw,tline,terase,tmove','après l’intro : les 4 fiches d’outils précèdent les éléments du niveau');
TU.load({v:1,i:1,s:['tdraw','tline','terase','tmove']},0);TU.onLoad(1);const pd2=TU._pend();
ok(!pd2||pd2.ids.indexOf('tdraw')<0,'outils déjà vus : plus proposés');
TU.load(null,0);
X.S.li=0;TU.onLoad(0);
const sv=X.saveState();ok('tuto' in sv,'saveState contient le bloc tuto');
console.log(bad?'\ndidacticiel : '+bad+' ÉCHEC':'\ndidacticiel : OK');process.exit(bad?1:0);
