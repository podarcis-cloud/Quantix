# e2e-didacticiel.py — parcours complet du didacticiel dans Chromium (Playwright), taille téléphone.
# Usage : python3 tools/e2e-didacticiel.py   (depuis la racine du site)
import os,sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
URL='file://'+ROOT+'/index.html'
res=[];errs=[]
def chk(c,m):
    res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
def w2s(pg,x,y):
    r=pg.evaluate("(function(){var r=cv.getBoundingClientRect();return [r.left,r.top,r.width]})()");s=r[2]/360.0;return r[0]+x*s,r[1]+y*s
def on(pg,i):return pg.evaluate("document.getElementById('%s').classList.contains('on')"%i)
def txt(pg,i):return pg.evaluate("document.getElementById('%s').textContent"%i)
def fits(pg,i):
    return pg.evaluate("(function(){var r=document.getElementById('%s').getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1})()"%i)
with sync_playwright() as p:
    b=p.chromium.launch()
    for (vw,vh,tag) in ((390,780,'390x780'),(360,640,'360x640')):
        ctx=b.new_context(viewport={'width':vw,'height':vh},device_scale_factor=2);pg=ctx.new_page()
        pg.on('pageerror',lambda e: errs.append('PAGEERR '+str(e)))
        pg.on('console',lambda m: errs.append(m.text) if m.type=='error' and '403' not in m.text and 'ERR_' not in m.text else None)
        pg.goto(URL);pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(500)
        print('── '+tag)
        # 1. première partie guidée
        pg.evaluate("goto('game');loadLevel(0)");pg.wait_for_timeout(1300)
        chk(on(pg,'tcoach'),'premier lancement : bandeau de mission visible')
        chk(not on(pg,'dock'),'premier lancement : les outils d’édition ne sont pas encore proposés')
        chk(fits(pg,'tcoach'),'bandeau entièrement dans l’écran')
        pg.click('#tcoachOk');pg.wait_for_timeout(400)
        chk('trait' in txt(pg,'tcoachT'),'étape 2 : consigne de tracer un trait')
        a=w2s(pg,60,180);c2=w2s(pg,29,165)
        pg.mouse.move(*a);pg.mouse.down();pg.mouse.move(*c2,steps=8);pg.mouse.up();pg.wait_for_timeout(600)
        chk('lâche' in txt(pg,'tcoachT').lower(),'étape 3 : le vrai trait déclenche « lâche »')
        chk(pg.evaluate("document.getElementById('bPlay').classList.contains('tpulse')"),'le bouton Lâcher pulse')
        pg.click('#bPlay');pg.wait_for_timeout(5500)
        chk('Raté' in txt(pg,'tcoachT') or on(pg,'vResult') or pg.evaluate("S.mode")=='draw','échec : le jeu reprend la main sans planter')
        # 2. après l'intro : fiches d'outils puis d'éléments, au niveau 2
        pg.evaluate("TUTO.load({v:1,i:1,s:[]},0);loadLevel(1)");pg.wait_for_timeout(1300)
        chk(on(pg,'dock'),'après l’intro : le dock d’outils apparaît')
        titles=[]
        for k in range(8):
            if not on(pg,'tcard'):break
            titles.append(txt(pg,'tt'))
            if k==0:
                chk(txt(pg,'tk').startswith('NOUVEAU'),'première fiche : kicker « NOUVEAU · … »')
                chk(fits(pg,'tcard'),'fiche entièrement dans l’écran')
            pg.click('#tok');pg.wait_for_timeout(450)
        print('   fiches vues :',titles)
        chk(titles[:4]==['Trait libre','Ligne droite','Gomme','Déplacer et pivoter'] and 'Zone interdite' in titles,'ordre : les 4 outils, puis les éléments du niveau')
        st=pg.evaluate("TUTO.state()");chk(all(k in st['s'] for k in ('tdraw','tline','terase','tmove','nd')),'fiches marquées comme vues')
        # persistance
        pg.evaluate("saveState()");pg.reload();pg.wait_for_timeout(500)
        pg.evaluate("goto('game');S.unlocked=131;loadLevel(1)");pg.wait_for_timeout(1200)
        chk(not on(pg,'tcard'),'après rechargement : les fiches ne se rouvrent pas')
        # 3. aide du niveau
        pg.click('#gPause');pg.wait_for_timeout(300);pg.click('#pHelp');pg.wait_for_timeout(500)
        chk(on(pg,'tcard') and not txt(pg,'tk').startswith('NOUVEAU'),'aide du niveau : fiche en révision (sans « NOUVEAU »)')
        pg.click('#tok');pg.wait_for_timeout(300)
        # 4. explications depuis l'accueil
        pg.evaluate("goto('home')");pg.wait_for_timeout(250)
        pg.click('#hSet');pg.wait_for_timeout(300);pg.click('#sCodex');pg.wait_for_timeout(400)
        n=pg.evaluate("document.querySelectorAll('#cxList .cx').length");hh=pg.evaluate("document.querySelectorAll('#cxList .cxh').length")
        chk(n==23 and hh==2,'explications : %d entrées, %d rubriques'%(n,hh))
        pg.click('#cxList .cx[data-id=tmove]');pg.wait_for_timeout(500)
        chk(on(pg,'tcard') and txt(pg,'tt')=='Déplacer et pivoter','entrée « Déplacer et pivoter » : la fiche s’ouvre')
        pg.click('#tok');pg.wait_for_timeout(300)
        chk(not on(pg,'tcard') and on(pg,'vCodex'),'fermer la fiche ramène aux explications')
        pg.click('#cxClose')
        # 5. anglais
        pg.evaluate("LANG='en';applyLang();goto('game');loadLevel(1)");pg.wait_for_timeout(400)
        pg.evaluate("TUTO.load({v:1,i:1,s:[]},0);loadLevel(1)");pg.wait_for_timeout(1200)
        chk(txt(pg,'tt')=='Freehand line','anglais : titre de la première fiche')
        pg.screenshot(path='/tmp/e2e_en_%s.png'%tag)
        pg.evaluate("LANG='fr';applyLang()")
        ctx.close()
    b.close()
print('erreurs de page :',errs)
print('RÉSULTAT',sum(res),'/',len(res))
sys.exit(0 if all(res) and not errs else 1)
