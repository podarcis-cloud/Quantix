/* difficulty.js — difficulté et faisabilité d'un niveau pour un tracé AU DOIGT, grossier.
   Usage : OUT=diff.json node difficulty.js 1 2 13 …   (numéros de niveau 1–132)

   Modèle (voir docs/DIFFICULTY_PROTOCOL.md) :
   - 1 unité de jeu ≈ 0,16 mm sur téléphone (terrain de 360 u ≈ 360 pt).
   - EXÉCUTION : le joueur sait quoi tracer. Chaque trait subit : décalage global
     σ=6 u, extrémités σ=9 u (≈1,5 mm, précision absolue du doigt — Bi, Li & Zhai,
     CHI 2013), rotation σ=4°, longueur ×(1±10 %), ondulation perpendiculaire
     d'amplitude 1–3 u. Tracé tronqué si l'encre manque (comme le moteur).
   - INTENTION : le joueur vise « à peu près » sans connaître la solution exacte.
     Décalage σ=18 u, extrémités σ=12 u, rotation σ=10°, longueur ×(1±20 %).
   - FAMILLES : balayage de traits droits ; deux gagnants sont de la même famille si
     leurs milieux sont à < 45 u et leurs angles à < 25°. Famille retenue si ≥ 3 membres.
   Mesures : P_exec et P_int (réussite), P_noyau (exécution), nombre de familles.
   Physique : le vrai moteur (tools/lab.js → load.js). */
const LAB=require('./lab.js'),X=LAB.X,fs=require('fs');
let seed=1;function rng(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
function gauss(){let u=0,v=0;while(!u)u=rng();while(!v)v=rng();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
const EXEC={t:6,e:9,r:4,l:.10,w:[1,3]},INT={t:18,e:12,r:10,l:.20,w:[1,3]};
/* tracé humain : bruit de placement + resampling + ondulation basse fréquence */
function human(pts,M){const n=pts.length,cx=pts.reduce((a,p)=>a+p[0],0)/n,cy=pts.reduce((a,p)=>a+p[1],0)/n;
 const tx=gauss()*M.t,ty=gauss()*M.t,rot=gauss()*M.r*Math.PI/180,sc=1+gauss()*M.l,c=Math.cos(rot),s=Math.sin(rot);
 let q=pts.map(p=>{const dx=(p[0]-cx)*sc,dy=(p[1]-cy)*sc;return [cx+dx*c-dy*s+tx,cy+dx*s+dy*c+ty];});
 q=q.map((p,i)=>(i===0||i===n-1)?[p[0]+gauss()*M.e,p[1]+gauss()*M.e]:p);
 const out=[];for(let i=1;i<q.length;i++){const a=q[i-1],b=q[i],m=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/6));
  for(let k=(i===1?0:1);k<=m;k++)out.push([a[0]+(b[0]-a[0])*k/m,a[1]+(b[1]-a[1])*k/m]);}
 const A=M.w[0]+rng()*(M.w[1]-M.w[0]),f=1+rng(),ph=rng()*6.28,L=plen(out)||1;let acc=0;
 for(let i=0;i<out.length;i++){if(i)acc+=Math.hypot(out[i][0]-out[i-1][0],out[i][1]-out[i-1][1]);
  const a=out[Math.max(0,i-1)],b=out[Math.min(out.length-1,i+1)],dl=Math.hypot(b[0]-a[0],b[1]-a[1])||1,nx=-(b[1]-a[1])/dl,ny=(b[0]-a[0])/dl,o=A*Math.sin(2*Math.PI*f*acc/L+ph);
  out[i]=[out[i][0]+nx*o,out[i][1]+ny*o];}
 return out;}
/* un geste complet (plusieurs traits), respect de l'encre et des zones interdites (le moteur refuse ces points) */
function gesture(LVg,sol,M,mat){let ink=LVg.ink;const cost=({0:1,1:1.9,3:1.7})[mat||0]||1,res=[];
 for(const p of sol){const h=human(p,M),kept=[h[0]];
  for(let i=1;i<h.length;i++){const d=Math.hypot(h[i][0]-kept[kept.length-1][0],h[i][1]-kept[kept.length-1][1]);
   const x=h[i][0],y=h[i][1],bad=x<0||x>360||y<0||y>480||(LVg.nd||[]).some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]);
   if(bad)continue;if(ink-d*cost<0)break;ink-=d*cost;kept.push(h[i]);}
  if(kept.length>1)res.push({pts:kept,mat:mat||0});}
 return res;}
function P(idx,LVg,sol,M,mat,N){let w=0,st=0;for(let k=0;k<N;k++){const g=gesture(LVg,sol,M,mat);X.loadLevel(idx);
  for(const s of g)X.S.strokes.push({pts:s.pts,len:plen(s.pts),birth:0,mat:s.mat});X.qpBuild();X.S.mode='run';
  for(let f=0;f<1300&&X.S.mode==='run';f++)X.physics();if(X.S.mode==='success'){w++;if(X.S.gotStar)st++;}}return {win:w/N,star:st/N};}
function families(idx,LVg){const wins=[],mat=(LVg.optmat!==undefined)?LVg.optmat:((LVg.pal||'S').includes('B')&&!(LVg.walls||[]).some(w=>w[4]===1)?1:0);
 for(let x=0;x<=360;x+=20)for(let y=20;y<=470;y+=20)for(let a=0;a<3.1416*2;a+=.45)for(const Ln of [35,70,110,160,220]){
  if(Ln*(({0:1,1:1.9,3:1.7})[mat]||1)>LVg.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(a)*Ln),Math.round(y+Math.sin(a)*Ln)]];
  if(!LAB.D.drawable(LVg,p))continue;X.loadLevel(idx);X.S.strokes.push({pts:p,len:Ln,birth:0,mat});X.qpBuild();X.S.mode='run';
  for(let f=0;f<1300&&X.S.mode==='run';f++)X.physics();if(X.S.mode==='success')wins.push(p);}
 const fam=[];for(const p of wins){const mx=(p[0][0]+p[1][0])/2,my=(p[0][1]+p[1][1])/2,an=((Math.atan2(p[1][1]-p[0][1],p[1][0]-p[0][0])%Math.PI)+Math.PI)%Math.PI;
  let f=fam.find(F=>Math.hypot(F.mx-mx,F.my-my)<45&&Math.min(Math.abs(F.an-an),Math.PI-Math.abs(F.an-an))<25*Math.PI/180);
  if(!f){f={mx,my,an,m:[]};fam.push(f);}f.m.push(p);}
 return {wins:wins.length,fam:fam.filter(F=>F.m.length>=3).sort((a,b)=>b.m.length-a.m.length),mat};}
module.exports={P,gesture,human,families,EXEC,INT,X,LAB,setSeed:v=>{seed=v;}};
if(require.main===module){
const file=process.env.OUT||'difficulty.json',out=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):{};
for(const a of process.argv.slice(2)){const idx=+a-1,LVg=X.LEVELS[idx];seed=idx*7919+1;
 const F=families(idx,LVg);const res={n:LVg.n,wd:LVg.wd,familles:F.fam.length,gagnantsBalayage:F.wins};
 // meilleure famille : P_int sur les 3 plus grandes (médoïde = membre le plus central)
 let best=null;for(const f of F.fam.slice(0,3)){const med=f.m.reduce((b,p)=>{const d=f.m.reduce((s,q)=>s+Math.hypot(p[0][0]-q[0][0],p[0][1]-q[0][1])+Math.hypot(p[1][0]-q[1][0],p[1][1]-q[1][1]),0);return !b||d<b.d?{p,d}:b;},null).p;
  const pi=P(idx,LVg,[med],INT,F.mat,24);if(!best||pi.win>best.pint)best={sol:[med],pint:pi.win};}
 // référence : la solution optimale enregistrée (plusieurs traits possibles)
 const ref=LVg.optsol||(best&&best.sol);const mat=LVg.optmat||F.mat;
 if(ref){const pe=P(idx,LVg,ref,EXEC,mat,30),pr=P(idx,LVg,ref,INT,mat,30);res.P_exec=+pe.win.toFixed(2);res.P_noyau=+pe.star.toFixed(2);res.P_int_ref=+pr.win.toFixed(2);}
 res.P_int_famille=best?+best.pint.toFixed(2):0;res.P_int=Math.max(res.P_int_ref||0,res.P_int_famille);
 out[a]=res;fs.writeFileSync(file,JSON.stringify(out,null,1));
 console.log(`#${a} ${LVg.n.padEnd(22)} familles ${String(res.familles).padStart(2)} | P_exec ${Math.round((res.P_exec||0)*100)}% | P_int ${Math.round(res.P_int*100)}% | P_noyau ${Math.round((res.P_noyau||0)*100)}%`);}
}
