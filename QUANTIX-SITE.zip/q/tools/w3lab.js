/* w3lab.js — banc d'essai du monde 3 (élan). Comme lab.js, mais les matières du joueur suivent `pal` :
   B → rebond (×1,9), A → élan (×1,7). « Sans mécanique » = tapis fixes ET tapis du joueur ramenés à de la structure.
   Balayage à 1 segment, borné en temps. Usage : node w3lab.js <clé> [step] [da] [secondes]  (clés de w3cand.js, ou old:<n> = niveau du jeu) */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js');
const MECA=[1,3,4];const COST={0:1,1:1.9,3:1.7};
function strip(c){return Object.assign({},c,{w:(c.w||[]).map(s=>[s[0],s[1],s[2],s[3],MECA.includes(s[4])?0:s[4]])});}
function run(idx,c,strokes){return LAB.run(idx,c,strokes);}
function sweep(idx,c,opt){opt=opt||{};
 const g=Object.assign({x0:0,x1:360,y0:20,y1:470,step:14,da:.4,lens:[30,55,85,120,160]},opt.grid||{});
 const mats=[0].concat((c.pal||'S').includes('A')?[3]:[]).concat((c.pal||'S').includes('B')?[1]:[]);
 const cs=strip(c),out={sansTrait:run(idx,c,[]).ok?'RÉUSSIT SEUL':'échoue',essais:0,avec:0,sans:0,wins:[],exSans:[]};
 const t0=Date.now(),tmax=(opt.secs||200)*1000;let cut=false;
 outer:for(let x=g.x0;x<=g.x1;x+=g.step)for(let y=g.y0;y<=g.y1;y+=g.step)for(let a=0;a<6.283;a+=g.da)for(const L of g.lens)for(const m of mats){
  if(Date.now()-t0>tmax){cut=true;break outer;}
  if(L*COST[m]>c.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(a)*L),Math.round(y+Math.sin(a)*L)]];
  if(!D.drawable(c,p))continue;out.essais++;
  const r=run(idx,c,[{pts:p,mat:m}]);if(r.ok){out.avec++;out.wins.push({pts:p,mat:m,star:r.star,tr:r.tr});}
  const rs=run(idx,cs,[{pts:p,mat:0}]);if(rs.ok){out.sans++;if(out.exSans.length<3)out.exSans.push(p);}}
 out.coupe=cut;out.ms=Date.now()-t0;return out;}
module.exports={sweep,strip,run,COST};
if(require.main===module){
 const k=process.argv[2],step=+(process.argv[3]||14),da=+(process.argv[4]||.4),secs=+(process.argv[5]||200);
 let c,idx;
 if(k.startsWith('old:')){idx=+k.slice(4)-1;const L=X.LEVELS[idx];c={n:L.n,ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w};}
 else{const C=require('./w3cand.js');idx=24+ +k;c=C[k];}
 const o=sweep(idx,c,{grid:{step,da},secs});
 console.log(k,(c.n||''),'| sans trait :',o.sansTrait,'| essais',o.essais,'| gagnants AVEC',o.avec,'| gagnants SANS mécanique',o.sans,o.coupe?'(coupé par le temps)':'','|',Math.round(o.ms/1000)+' s');
 if(o.exSans.length)console.log('  ex. sans mécanique :',JSON.stringify(o.exSans));
 if(o.wins.length)console.log('  ex. avec :',JSON.stringify(o.wins.slice(0,2).map(w=>[w.pts,w.mat])));}
