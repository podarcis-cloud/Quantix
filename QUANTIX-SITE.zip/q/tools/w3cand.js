/* Candidats du monde 3 (Chaîne — élan) — format levels.js. Matières : 0 structure, 2 pointes, 3 tapis d'élan.
   Principe d'énergie (à respecter) : le tapis fait passer la vitesse à ≈ 7,2 le long de sa surface, mais une balle qui roule ne
   remonte jamais au-dessus de son départ. Un bassin plus haut que le départ (jusqu'à ≈ 65 u au-dessus du tapis) ne s'atteint donc
   que par le tapis. Départ bas ⇒ le tapis apporte de l'énergie ; départ haut ⇒ la balle dépasse déjà 7,2 et le tapis ne sert plus. */
module.exports={
 0:{n:'Le tapis',ink:300,ball:[60,240],cup:[250,230,80,'R'],w:[[20,290,120,290,0],[120,290,190,220,3]]},
 1:{n:'Sens inverse',ink:300,ball:[300,236],cup:[20,300,90,'L'],nd:[[110,0,70,480]],w:[[250,290,340,290,0],[250,290,180,290,3]]},
 2:{n:'Tapis et butée',ink:300,ball:[50,236],cup:[222,310,98,'R'],w:[[20,290,120,290,0],[120,290,180,232,3],[322,150,322,310,0]]},
 3:{n:'Le plafond bas',ink:300,ball:[50,236],cup:[262,340,80,'R'],nd:[[130,0,110,480]],w:[[20,290,120,290,0],[120,290,175,290,3],[130,250,240,250,2]]},
 4:{n:'Ton élan',ink:320,pal:'SA',ball:[50,236],cup:[250,215,90,'R'],w:[[20,268,150,290,0]]},
 5:{n:'Saut de chaîne',ink:320,pal:'SA',ball:[50,236],cup:[250,190,80,'R'],w:[[20,268,105,288,0],[105,288,165,232,3]]},
 6:{n:'Tapis et lames',ink:320,pal:'SA',ball:[50,236],cup:[262,290,80,'R'],nd:[[130,0,120,480]],w:[[20,268,130,290,0],[130,470,250,470,2]]},
 7:{n:'Deux tapis',ink:300,pal:'SA',ball:[40,236],cup:[290,372,66,'R'],nd:[[130,0,60,480],[232,0,58,480]],w:[[15,290,90,290,0],[90,290,130,290,3],[190,322,232,322,3]]},
 8:{n:'Chaîne montante',ink:320,pal:'SA',ball:[310,236],cup:[10,190,80,'L'],w:[[340,268,255,288,0],[255,288,195,232,3]]},
 9:{n:'Cadence',ink:320,pal:'SA',ball:[50,236],cup:[262,190,90,'R'],w:[[20,268,105,288,0],[105,288,165,232,3],[190,110,300,110,2]]},
 10:{n:'Le triage',ink:300,pal:'SA',ball:[120,236],cup:[282,225,66,'R'],nd:[[205,0,80,480]],w:[[70,290,170,290,0],[170,290,230,232,3],[70,290,40,290,3],[20,470,60,470,2]]},
 11:{n:'La ligne',ink:340,pal:'SA',ball:[50,236],cup:[236,192,90,'R'],nd:[[0,0,30,300]],w:[[20,268,105,288,0],[105,288,165,232,3],[190,470,340,470,2]]}
};
