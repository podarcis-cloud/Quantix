/* w3probe.js — explore des variantes d'un candidat : node w3probe.js  (édite VARIANTS ci-dessous) */
const W3=require('./w3lab.js');
function evalC(idx,c,step,da,secs){const o=W3.sweep(idx,c,{grid:{step:step||14,da:da||.4},secs:secs||40});return o;}
module.exports={evalC};
if(require.main===module){
 const base={ink:300,ball:[60,240],w:[[20,290,120,290,0],[120,290,190,220,3]]};
 const rows=[];
 for(const cx of [230,250,270,290])for(const cy of [200,230,260])for(const ang of [[190,220],[186,232],[180,214]]){
  const c=Object.assign({},base,{n:'t',cup:[cx,cy,80,'R'],w:[[20,290,120,290,0],[120,290,ang[0],ang[1],3]]});
  const o=evalC(24,c,16,.5,20);
  rows.push([cx,cy,ang.join(','),o.sansTrait[0],o.avec,o.sans]);}
 rows.filter(r=>r[4]>0).forEach(r=>console.log(r.join('  ')));
 console.log('total variantes',rows.length,'avec gagnants',rows.filter(r=>r[4]>0).length,'dont 0 sans mécanique',rows.filter(r=>r[4]>0&&r[5]===0).length);}
