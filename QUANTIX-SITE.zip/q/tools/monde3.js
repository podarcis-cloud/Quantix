/* monde3.js — non-régression du monde 3 refondu (R38).
   Pour chaque niveau muni d'une solution optimale (optsol, matière optmat) :
   - sans trait : ne doit pas réussir ;
   - bouton « Voir la solution optimale » : réussit AVEC le noyau, progression intacte ;
   - même solution, tapis fixes et matière élan ramenés à de la structure : doit échouer
     (le tapis est indispensable — principe d'énergie, handbook §11 sexies). */
require('./load.js');
const X=globalThis.__X,{store}=require('./load.js');const ST=X.S;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
let bad=0,n=0;
for(let i=24;i<36;i++){const LVi=X.LEVELS[i];if(!LVi.optsol){console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'(ancien niveau conservé — à reconcevoir)');continue;}n++;
 X.loadLevel(i);X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();const seul=ST.mode==='success';
 X.loadLevel(i);const before=JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);ST.mode='fail';
 store['rSolution'].onclick.call(store['rSolution'],{});for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();
 const win=ST.mode==='success',star=ST.gotStar,intact=before===JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);
 const saved=LVi.walls.map(w=>w[4]);LVi.walls.forEach(w=>{if(w[4]===3)w[4]=0;});
 X.loadLevel(i);LVi.walls.forEach(w=>{if(w[4]===3)w[4]=0;});
 for(const p of LVi.optsol)ST.strokes.push({pts:p,len:plen(p),birth:0,mat:0});X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();
 const sansMeca=ST.mode==='success';LVi.walls.forEach((w,k)=>w[4]=saved[k]);
 const ok=!seul&&win&&star&&intact&&!sansMeca;if(!ok)bad++;
 console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'seul:',seul?'RÉUSSIT(!)':'non','| solution:',win?'réussit':'ÉCHOUE','| noyau',star?'oui':'NON','| progression',intact?'intacte':'TOUCHÉE','| sans tapis:',sansMeca?'RÉUSSIT(!)':'échoue',ok?' OK':' <<<');}
console.log(bad?bad+' problème(s)':'monde 3 : '+n+'/'+n+' OK');process.exitCode=bad?1:0;
