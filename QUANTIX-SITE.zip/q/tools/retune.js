/* retune.js — corrige la géométrie d'un niveau vers les cibles de docs/DIFFICULTY_PROTOCOL.md.
   Usage : OUT=retune.json node retune.js 1 2 …
   Leviers (l'idée du niveau n'est jamais modifiée) : bassin déplacé (±45 u) et élargi
   (jusqu'à +70 u), encre ×1 à ×1,8. Décor, zones interdites, départ : inchangés.
   Contraintes : sans trait → échec ; niveaux à plusieurs traits → aucun trait seul ne gagne ;
   monde 2 → bassin plus haut que le départ (principe d'énergie) + 0 gagnant sans plaque
   (balayage complet, vérifié sur la géométrie retenue).
   Geste de référence : famille la plus pardonnante (niveaux à un trait) ou optsol (plusieurs traits).
   Sortie : géométrie, noyau replacé (≈ 50 % des exécutions le prennent), optsol = geste le plus
   exécutable, mesures finales N = 60. */
const DF=require('./difficulty.js'),LAB=DF.LAB,X=DF.X,D=LAB.D,fs=require('fs');
const POS=n=>((n-1)%12)+1,TGT=p=>p<=2?.60:p<=5?.50:p<=8?.40:p<=10?.35:p===11?.30:.25;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function h(n){const x=Math.sin(n*12.9898)*43758.5453;return x-Math.floor(x);}
function cand(base,g){const c=JSON.parse(JSON.stringify(base));const w=Math.min(360-8,c.cup[2]+g.dw);
 let x=Math.round(c.cup[0]+g.dx-(w-c.cup[2])/2);x=Math.max(2,Math.min(358-w,x));c.cup=[x,Math.min(462,Math.round(c.cup[1]+g.dy)),Math.round(w),c.cup[3]];
 c.ink=Math.round(base.ink*g.k);
 if(g.ps&&g.ps!==1)c.w=c.w.map(w=>{if(w[4]!==1)return w;const mx=(w[0]+w[2])/2,my=(w[1]+w[3])/2,f=g.ps;   // plaques allongées autour de leur centre
  const q=[mx+(w[0]-mx)*f,my+(w[1]-my)*f,mx+(w[2]-mx)*f,my+(w[3]-my)*f].map(v=>Math.round(v));
  q[0]=Math.max(0,Math.min(360,q[0]));q[2]=Math.max(0,Math.min(360,q[2]));return [q[0],q[1],q[2],q[3],1];});
 return c;}
function runG(idx,strokes){X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:plen(s.pts),birth:0,mat:s.mat||0});
 X.qpBuild();X.S.mode='run';const tr=[];for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',tr};}
function evalC(idx,c,multi,N){D.install(idx,c);const LVc=X.LEVELS[idx];
 if(runG(idx,[]).ok)return null;
 let gest,mat=c.optmat||0,fam=0;
 if(multi){gest=c.optsol;}
 else{const F=DF.families(idx,LVc);fam=F.fam.length;mat=F.mat;if(!F.fam.length)return {score:0,fam:0};
  let best=null;for(const f of F.fam.slice(0,4)){const med=f.m.reduce((b,p)=>{const d=f.m.reduce((s,q)=>s+Math.hypot(p[0][0]-q[0][0],p[0][1]-q[0][1])+Math.hypot(p[1][0]-q[1][0],p[1][1]-q[1][1]),0);return !b||d<b.d?{p,d}:b;},null).p;
   DF.setSeed(idx*31+7);const pi=DF.P(idx,LVc,[med],DF.INT,mat,N).win;if(!best||pi>best.pi)best={g:[med],pi};}
  if(c.optsol&&c.optsol.length===1){DF.setSeed(idx*31+7);const po=DF.P(idx,LVc,c.optsol,DF.INT,c.optmat||0,N).win;if(po>=best.pi){best={g:c.optsol,pi:po};mat=c.optmat||0;}}
  gest=best.g;}
 DF.setSeed(idx*53+11);const pe=DF.P(idx,LVc,gest,DF.EXEC,mat,N).win;DF.setSeed(idx*97+5);const pi=DF.P(idx,LVc,gest,DF.INT,mat,N).win;
 return {pe,pi,fam,gest,mat};}
function score(r,p,multi){if(!r||!r.pe&&r.pe!==0)return -1;const fT=p<=2?2:3;
 return Math.min(r.pe/.7,1)*.5+Math.min(r.pi/TGT(p),1)*.4+(multi?.1:Math.min(r.fam/fT,1)*.1);}
function stripOK(idx,c){const cs=LAB.strip(c);let n=0;   // 0 gagnant sans plaque (balayage à 1 trait)
 for(let x=0;x<=360;x+=22)for(let y=20;y<=470;y+=22)for(let a=0;a<6.283;a+=.5)for(const L of [40,90,150,220]){
  if(L>c.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(a)*L),Math.round(y+Math.sin(a)*L)]];if(!D.drawable(c,p))continue;
  if(LAB.run(idx,cs,[{pts:p,mat:0}]).ok){n++;if(n>0)return false;}}return true;}
function placeStar(idx,c,gest,mat){D.install(idx,Object.assign({},c,{star:null}));const LVc=X.LEVELS[idx],trs=[];
 DF.setSeed(idx*17+3);for(let k=0;k<40;k++){const g=DF.gesture(LVc,gest,DF.EXEC,mat);const r=runG(idx,g);if(r.ok)trs.push(r.tr);}
 if(trs.length<5)return null;const z=LVc.zone;let best=null;
 for(let sx=10;sx<=350;sx+=6)for(let sy=20;sy<=470;sy+=6){
  if(Math.hypot(sx-c.ball[0],sy-c.ball[1])<45)continue;if(sx>z[0]-12&&sx<z[0]+z[2]+12&&sy>z[1]-20&&sy<z[1]+z[3]+10)continue;
  let hN=0;for(const t of trs)if(t.some(q=>Math.hypot(q[0]-sx,q[1]-sy)<20.5))hN++;const f=hN/trs.length;
  if(f>=.45&&f<=.7&&(!best||Math.abs(f-.55)<Math.abs(best.f-.55)))best={x:sx,y:sy,f};}
 return best?[best.x,best.y]:null;}
const file=process.env.OUT||'retune.json',out=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):{};
for(const a of process.argv.slice(2)){const num=+a,idx=num-1,L0=X.LEVELS[idx],p=POS(num),t0=Date.now();
 const base={ball:L0.ball,cup:L0.cup,ink:L0.ink,star:L0.star,w:L0.w||[],nd:L0.nd||[],pal:L0.pal,optsol:L0.optsol,optmat:L0.optmat||0};
 const multi=!!(L0.optsol&&L0.optsol.length>1),energy=(L0.wd===2||L0.wd===3)&&base.cup[1]<base.ball[1];
 const gens=[{dx:0,dy:0,dw:0,k:1}];const NG=+(process.env.NG||34),SP=+(process.env.SP||1);for(let i=0;i<NG;i++)gens.push({dx:Math.round((h(num*100+i)-.5)*90*SP),dy:Math.round((h(num*200+i)-.5)*60*SP),dw:Math.round(h(num*300+i)*70*SP),k:1+h(num*400+i)*.8*SP,ps:1+h(num*500+i)*.7*SP});
 let best=null;
 for(const g of gens){if(Date.now()-t0>(+(process.env.TMAX||150))*1000)break;const c=cand(base,g);if(energy&&c.cup[1]>=c.ball[1]-15)continue;
  const r=evalC(idx,c,multi,16);const sc=score(r,p,multi);if(sc>(best?best.sc:-1))best={c,r,sc,g};}
 // vérifications finales sur la géométrie retenue
 let c=best.c;const r=best.r;D.install(idx,c);
 const single=multi?(()=>{const F=DF.families(idx,X.LEVELS[idx]);return F.wins;})():0;
 const noPlate=(L0.wd===2||L0.wd===3)?stripOK(idx,c):true;
 const star=placeStar(idx,c,r.gest,r.mat)||base.star;c.star=star;D.install(idx,c);
 DF.setSeed(idx*7+1);const fe=DF.P(idx,X.LEVELS[idx],r.gest,DF.EXEC,r.mat,60);DF.setSeed(idx*9+2);const fi=DF.P(idx,X.LEVELS[idx],r.gest,DF.INT,r.mat,60);
 const res={n:L0.n,pos:p,cup:c.cup,ink:c.ink,w:c.w,star,optsol:r.gest,optmat:r.mat,P_exec:+fe.win.toFixed(2),P_int:+fi.win.toFixed(2),P_noyau:+fe.star.toFixed(2),
  familles:r.fam,cible_int:TGT(p),unTraitSuffit:multi?single>0:null,sansPlaqueImpossible:noPlate,avant:{cup:L0.cup,ink:L0.ink}};
 const ok=res.P_exec>=.7&&res.P_int>=TGT(p)&&noPlate&&!res.unTraitSuffit;res.conforme=ok;
 out[a]=res;fs.writeFileSync(file,JSON.stringify(out,null,1));
 // restaurer le niveau d'origine en mémoire (l'écriture dans levels.js se fait à part)
 D.install(idx,Object.assign({},base));
 console.log(`#${num} ${L0.n.padEnd(22)} exec ${Math.round(res.P_exec*100)}% int ${Math.round(res.P_int*100)}%(≥${Math.round(TGT(p)*100)}) noyau ${Math.round(res.P_noyau*100)}% fam ${res.familles} | bassin ${JSON.stringify(L0.cup)}→${JSON.stringify(c.cup)} encre ${L0.ink}→${c.ink}${(L0.wd===2||L0.wd===3)?' | sans plaque impossible: '+noPlate:''}${multi?' | un trait suffit: '+res.unTraitSuffit:''} ${ok?'✅':'❌'} (${Math.round((Date.now()-t0)/1000)} s)`);}
