# e2e-editeur.py — éditeur de lignes à la souris dans Chromium. Usage : python3 tools/e2e-editeur.py
import os,sys
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
from playwright.sync_api import sync_playwright
errs=[];res=[]
def chk(c,m):
    res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
def w2s(pg,x,y):
    r=pg.evaluate("(function(){var r=cv.getBoundingClientRect();return [r.left,r.top,r.width]})()")
    s=r[2]/360.0;return r[0]+x*s, r[1]+y*s
def drag(pg,a,b,steps=8):
    x1,y1=w2s(pg,*a);x2,y2=w2s(pg,*b)
    pg.mouse.move(x1,y1);pg.mouse.down();pg.mouse.move(x2,y2,steps=steps);pg.mouse.up();pg.wait_for_timeout(120)
def tap(pg,p):
    x,y=w2s(pg,*p);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.up();pg.wait_for_timeout(120)
def n(pg):return pg.evaluate("S.strokes.length")
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':390,'height':780},device_scale_factor=2)
    pg.on('pageerror',lambda e: errs.append('PAGEERR '+str(e)))
    pg.on('console',lambda m: errs.append(m.text) if m.type=='error' and '403' not in m.text else None)
    pg.goto('file://'+ROOT+'/index.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(500)
    pg.evaluate("TUTO.load({v:1,i:1,s:['tdraw','tline','terase','tmove','nd','spike','bounce','palB']},0);S.unlocked=131;goto('game');loadLevel(0);S.ink=S.inkMax=900;paintEnergy()");pg.wait_for_timeout(700)
    chk(pg.evaluate("document.getElementById('dock').classList.contains('on')"),'dock visible après l’intro')
    pg.screenshot(path='/tmp/ed_dock.png')
    # --- ligne droite : glisser
    pg.click('.dk[data-m=line]');pg.wait_for_timeout(200)
    chk(pg.evaluate("EDT.mode()")=='line','outil ligne actif')
    ink0=pg.evaluate("S.ink")
    drag(pg,(40,320),(150,320.5))
    chk(n(pg)==1,'ligne droite par glisser : 1 trait')
    pts=pg.evaluate("S.strokes[0].pts")
    chk(len(pts)==2 and abs(pts[0][1]-pts[1][1])<0.01,'ligne parfaitement horizontale (accroche 0°) : %s'%pts)
    cost=pg.evaluate("S.strokes[0].len");chk(abs((ink0-pg.evaluate("S.ink"))-cost)<0.01 and cost>90,'énergie débitée = coût (%.1f)'%cost)
    # --- deux touchers
    tap(pg,(200,360));chk(pg.evaluate("EDT._anchor()")is not None,'premier toucher : ancre posée')
    pg.screenshot(path='/tmp/ed_anchor.png')
    drag(pg,(300,400),(300,400),steps=1)  # second toucher = point B
    chk(n(pg)==2,'deux touchers : ligne créée (%d traits)'%n(pg))
    # accroche extrémité : partir près de l'extrémité (150,150)
    drag(pg,(154,323),(150,420))
    p2=pg.evaluate("S.strokes[2].pts");chk(abs(p2[0][0]-pts[1][0])<0.01 and abs(p2[0][1]-pts[1][1])<0.01,'départ accroché à l’extrémité existante %s'%p2[0])
    # zone interdite (niveau 2 : nd) : partir dans la zone = refus
    before=n(pg)
    pg.evaluate("loadLevel(1)");pg.wait_for_timeout(500);pg.evaluate("EDT.set('line',true)")
    nd=pg.evaluate("L().nd");zx=nd[0][0]+nd[0][2]/2;zy=nd[0][1]+nd[0][3]/2
    drag(pg,(zx,zy),(zx+20,zy+20))
    chk(n(pg)==0,'départ dans une zone interdite : refusé')
    drag(pg,(200,300),(60,300))
    q=pg.evaluate("S.strokes[0]&&S.strokes[0].pts");print('   ligne vers zone interdite s’arrête à',q)
    chk(q and q[1][0]>=139,'la ligne s’arrête au bord de la zone interdite')
    pg.evaluate("loadLevel(0);S.ink=S.inkMax=900;paintEnergy()");pg.wait_for_timeout(400)
    # refaire les 3 lignes
    pg.evaluate("EDT.set('line',true)")
    drag(pg,(40,320),(150,320.5));tap(pg,(200,360));drag(pg,(300,400),(300,400),steps=1);drag(pg,(154,323),(150,420))
    # --- gomme
    pg.click('.dk[data-m=erase]');pg.wait_for_timeout(200)
    ink1=pg.evaluate("S.ink");L0=pg.evaluate("S.strokes[0].len")
    tap(pg,(95,320))
    chk(n(pg)==before-1 and abs(pg.evaluate("S.ink")-(ink1+L0))<0.01,'gomme : ligne effacée, énergie rendue')
    pg.click('#bUndo');pg.wait_for_timeout(200)
    chk(n(pg)==before and abs(pg.evaluate("S.ink")-ink1)<0.01,'annuler : ligne rétablie, énergie reprise')
    # glisser sur 2 lignes
    x1,y1=w2s(pg,100,300);x2,y2=w2s(pg,100,336);x3,y3=w2s(pg,175,336)
    pg.mouse.move(x1,y1);pg.mouse.down();pg.mouse.move(x2,y2,steps=8);pg.mouse.move(x3,y3,steps=12)
    na=pg.evaluate("EDT._armed().length");chk(na==2,'glisser sur deux lignes : %d armées'%na)
    pg.screenshot(path='/tmp/ed_erase.png');pg.mouse.up();pg.wait_for_timeout(150)
    chk(n(pg)==before-2,'effacement multiple : %d restante(s)'%n(pg))
    pg.click('#bUndo');pg.wait_for_timeout(150)
    chk(n(pg)==before,'annuler un effacement multiple : tout revient en une fois')
    # --- déplacer
    pg.click('.dk[data-m=move]');pg.wait_for_timeout(200)
    a0=pg.evaluate("S.strokes[0].pts")
    drag(pg,(95,320),(95,290))
    a1=pg.evaluate("S.strokes[0].pts")
    chk(abs((a1[0][1]-a0[0][1])+30)<3 and abs(a1[0][0]-a0[0][0])<3,'déplacer : translation ≈ (0,-30) %s'%[round(a1[0][1]-a0[0][1],1)])
    chk(abs((a1[1][0]-a1[0][0])-(a0[1][0]-a0[0][0]))<0.01,'longueur inchangée par le déplacement')
    pg.screenshot(path='/tmp/ed_move.png')
    # rotation par la poignée
    hp=pg.evaluate("(function(){var s=EDT._sel();var c=EDT._center(s.s.pts);var a=s.hAng;return [c[0]+Math.cos(a)*60,c[1]+Math.sin(a)*60,c[0],c[1]]})()")
    drag(pg,(hp[0],hp[1]),(hp[2]+60,hp[3]),steps=12)
    a2=pg.evaluate("S.strokes[0].pts")
    import math
    ang=math.degrees(math.atan2(a2[1][1]-a2[0][1],a2[1][0]-a2[0][0]))
    print('   angle après rotation:',round(ang,1))
    chk(abs(abs(ang)-90)<1.5 or abs(abs(ang)-90)<6,'rotation par la poignée ≈ 90° (accroche 15°)')
    L_before=math.hypot(a0[1][0]-a0[0][0],a0[1][1]-a0[0][1]);L_after=math.hypot(a2[1][0]-a2[0][0],a2[1][1]-a2[0][1])
    chk(abs(L_before-L_after)<0.01,'longueur inchangée par la rotation')
    pg.screenshot(path='/tmp/ed_rot.png')
    # annuler rotation puis déplacement
    pg.click('#bUndo');pg.wait_for_timeout(150)
    a3=pg.evaluate("S.strokes[0].pts");chk(abs(a3[0][0]-a1[0][0])<0.01 and abs(a3[1][1]-a1[1][1])<0.01,'annuler : rotation défaite')
    pg.click('#bUndo');pg.wait_for_timeout(150)
    a4=pg.evaluate("S.strokes[0].pts");chk(abs(a4[0][1]-a0[0][1])<0.01,'annuler : déplacement défait')
    # blocage zone interdite en déplacement
    pg.evaluate("loadLevel(1)");pg.wait_for_timeout(400);pg.evaluate("EDT.set('line',true)");drag(pg,(150,300),(250,300));pg.evaluate("EDT.set('move',true)")
    tap(pg,(200,300));drag(pg,(200,300),(zx,300),steps=20)
    okp=pg.evaluate("EDT._ptsValid(S.strokes[0].pts)")
    pg.evaluate("loadLevel(0);S.ink=S.inkMax=900;paintEnergy();EDT.set('line',true)");pg.wait_for_timeout(300);drag(pg,(40,320),(150,320.5));tap(pg,(200,360));drag(pg,(300,400),(300,400),steps=1);drag(pg,(154,323),(150,420));chk(okp,'déplacer vers une zone interdite : la ligne reste valide (bute)')
    # tout effacer + annuler
    ink_all=pg.evaluate("S.ink");cnt=n(pg)
    pg.click('#bClear');pg.wait_for_timeout(200)
    chk(n(pg)==0 and not pg.evaluate("document.getElementById('bUndo').disabled"),'tout effacer : Annuler reste actif')
    pg.click('#bUndo');pg.wait_for_timeout(200)
    chk(n(pg)==cnt and abs(pg.evaluate("S.ink")-ink_all)<0.01,'annuler « tout effacer » : %d traits rétablis'%n(pg))
    # lâcher : retour auto en Trait
    pg.click('#bPlay');pg.wait_for_timeout(600)
    chk(pg.evaluate("EDT.mode()")=='draw','lancement : retour automatique à l’outil Trait')
    pg.wait_for_timeout(3500)
    b.close()
print('erreurs:',errs)
print('RÉSULTAT',sum(res),'/',len(res))
sys.exit(0 if all(res) and not errs else 1)
