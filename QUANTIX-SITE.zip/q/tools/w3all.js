/* w3all.js — balaye plusieurs candidats : node w3all.js 0 1 2 [step] [da] [secondes par niveau] (variables STEP, DA, SECS) */
const W3=require('./w3lab.js'),C=require('./w3cand.js');
const step=+(process.env.STEP||18),da=+(process.env.DA||.5),secs=+(process.env.SECS||24);
for(const k of process.argv.slice(2)){const c=C[k];const o=W3.sweep(24+ +k,c,{grid:{step,da,lens:[30,60,100,150]},secs});
 console.log(('#'+(25+ +k)).padEnd(4),c.n.padEnd(16),'| sans trait',o.sansTrait.padEnd(6),'| essais',String(o.essais).padEnd(6),'| AVEC',String(o.avec).padEnd(5),'| SANS mécanique',String(o.sans).padEnd(4),o.coupe?'(coupé)':'',Math.round(o.ms/1000)+'s');}
