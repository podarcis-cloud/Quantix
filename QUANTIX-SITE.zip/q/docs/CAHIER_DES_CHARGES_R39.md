# QUANTIX — cahier des charges R39 (demandes de Simon, session R38)

*Ce document range les demandes reçues, ce qui a été fait en R38 (vérifié) et ce qui reste. Il ne déclare rien
« terminé » sans preuve. Une ligne « À juger par toi » veut dire que je ne peux pas l'évaluer depuis le bac à sable.*

## 1. Tâches et état

| # | Demande | État R38 | Reste à faire |
|---|---|---|---|
| A | Éditeur de ligne : ligne droite, gomme, déplacer/pivoter, design soigné | **Fait et testé** (25 contrôles souris Chromium) | Test au doigt sur vrai téléphone ; remesurer la jouabilité (§5) |
| B | Design du didacticiel (police, cohérence, à la hauteur) | **Refondu** : bandeau MISSION, carte en verre, démos au rendu du jeu | Juger la typographie sur appareil (§4) |
| C | Phrases du didacticiel sensées | **Réécrites** (28 textes fr + en) | Test avec de vrais joueurs (PLAYTEST_PROTOCOL) |
| D | Tonalité dramaturgique et éditoriale quantique | **Première passe appliquée** (§3) | Fil narratif entre mondes (épigraphes), textes d'accueil de monde |
| E | Monde 4 : visuel fidèle au gameplay | **Décor posé** : franges de deux sources, tourbillons, globe de fils, condensat qui respire | Juger le mouvement sur appareil ; **niveaux du monde 4 à refondre** (anciens R29) |
| F | Voiles de particules en couches transparentes (tous mondes) | **Fait pour les mondes 1 à 4** : `veils()` dans `visuals.js` | Mondes 5 à 11 (paramètres de forme à définir) ; densité à régler sur appareil réel |
| G | Carte d'un monde : lignes et ronds plus légers, éthérés | **Fait** (`engine.js` + CSS « carte éthérée ») | Carte des mondes (constellation), cellules `.cell` : même traitement |
| H | Musique mélodique, un thème simple avec variantes par monde | **Non commencé** — analyse des vidéos faite (§6) | Tout le chantier son |
| I | Bruitages moins secs, texturés, cohérents avec la musique | **Non commencé** | Voir §6 |
| J | Corriger les 3 premiers mondes pour coller à la description | **Décor** : voiles ajoutés aux mondes 1 à 3 ; carte alléger | **Monde 3 (Chaîne) : niveaux jamais refondus** ; ordre de travail à décider (§7) |

## 2. Audit multicouche du didacticiel

**Couche 1 — usage.** Le didacticiel doit amener au premier geste réussi vite, sans mur de texte. Contrôlé : un
seul geste demandé par étape, le bandeau attend le vrai geste, « Passer » toujours présent, fiche après le
niveau 1 seulement (les outils d'édition ne sont pas dévoilés avant), taille des textes (≤ 31 mots pour le
plus long, mesuré). Défaut relevé : le bandeau long réduit le terrain de quelques pour cent au premier niveau.

**Couche 2 — exactitude.** Chaque phrase a été confrontée au moteur : rebond = restitution supérieure à 1
(« plus vite qu'il n'est arrivé »), tapis = poussée dans le sens du tracé jusqu'à une vitesse limite, aimant =
attraction croissante avec la proximité, portail = la vitesse est conservée, superposition = il suffit qu'une
version atteigne la zone, dilatation = plus lent (échelles 0,38 / 0,42 / 0,45 dans les niveaux). Une phrase
de l'ancien texte (« détecteur ») était fausse : corrigée.

**Couche 3 — éditoriale.** Trois tonalités comparées :
- *A. Manuel technique* (l'ancienne) : exact, mais neutre ; n'entre pas dans l'univers.
- *B. Carnet de laboratoire* (**retenue**) : une phrase d'émerveillement sobre, puis une phrase d'usage précise.
  Vocabulaire réel (mesure, superposition, onde) ; jamais de promesse que le moteur ne tient pas.
- *C. Oracle poétique* : plus lyrique, mais masque la consigne. Écartée pour un jeu tactile où l'on lit 3 secondes.

**Couche 4 — dramaturgie.** Fil retenu : *le joueur est l'observateur*. Ouverture : « tant qu'on ne la regarde
pas, une particule n'est qu'une promesse » → la zone la rend réelle. Fiches : superposition = « deux chemins à
la fois » ; détecteur = « observer, c'est perturber ». Ces deux idées viennent du texte fourni sur les fentes de
Young (dualité onde-corpuscule, mesure qui réduit l'onde à une particule).

**Couche 5 — risques.** Dérive « quantique-mystique » (la science réelle doit rester le socle : citer les
sources dans les écrans de monde) ; pathos trop appuyé (une seule image par fiche) ; longueur (limite 30 mots) ;
traduction anglaise (jeux de mots évités, sens gardé).

**Ce qui reste ouvert.** (1) Épigraphes d'accueil de monde tirées des expériences réelles (Young 1801, neutron
unique Vienne 2022 — ce dernier figure dans le document fourni). (2) Ton des messages de réussite et d'échec.
(3) Un vrai test de lecture avec 5 personnes : mesurer si la première phrase aide ou gêne.

## 3. Règles d'écriture retenues (à respecter pour tout nouveau texte)

1. Deux phrases maximum par fiche : une image sobre, puis l'usage exact.
2. Le mot clé de l'usage est entouré de `*étoiles*` (mis en valeur à l'affichage).
3. Aucune affirmation sur la physique du jeu sans l'avoir vérifiée dans le moteur.
4. Aucun terme de la science dit « à moitié » : mesure, superposition, onde, interférence gardent leur sens réel.
5. Pas de trait d'union qui coupe la ligne : utiliser le trait d'union insécable (U+2011) dans « glisse‑la », etc.

## 4. Typographie

Système retenu : **Space Grotesk** (titres, déjà la police d'affichage du jeu), **Inter** (corps),
**JetBrains Mono** (kickers, étiquettes, dock : ton « instrument de laboratoire »). *Non vérifié visuellement :* le
bac à sable n'a pas de réseau, mes captures utilisent la police de secours. **À juger par toi sur ton appareil.**
Si la police mono ne convient pas, une seule ligne à changer (`--mono` dans `quantix.css`).

## 5. Éditeur de lignes — effets de jeu à mesurer

« Déplacer » est **gratuit** (la longueur ne change pas) : cela facilite la précision, ce qui va dans le sens du
principe « la difficulté vient de comprendre, pas de réussir à tracer ». Mais `difficulty.js` mesurait un tracé
en un seul jet : **la jouabilité au doigt n'a pas été remesurée** avec l'éditeur. À faire : repasser P_exec en
comptant un ajustement gratuit, et décider si certains niveaux doivent devenir plus exigeants.

## 6. Son — ce que les vidéos de référence montrent (mesuré, pas ressenti)

Analyse spectrale des trois fichiers (les deux vidéos de 12 s portent la même piste) :

| Mesure | Résultat |
|---|---|
| Note dominante | **Mi** (32 à 36 % de l'énergie), puis La (17–18 %), Do (12–14 %), Si (9–11 %) → Mi mineur / La mineur add9, couleur Do majeur 7 |
| Répartition d'énergie | 250 Hz–1 kHz : **58 à 60 %** ; 60–250 Hz : 15–19 % ; 1–4 kHz : 19–24 % ; au‑dessus de 4 kHz : **3 %** |
| Centre de gravité spectral | 790 à 920 Hz (chaud, voilé, sans brillance) |
| Pulsation | aucune franche (autocorrélation ≤ 0,36) : nappes continues, pas de rythme |
| Durées | boucles de 12 s et 30 s |

**Cahier des charges son (à réaliser) :**
- *Thème* : 4 à 5 notes dans la pentatonique de Mi mineur (Mi Sol La Si Ré), joué par un timbre cloche/verre, décay 3 s.
- *Nappes* : deux oscillateurs légèrement désaccordés + sous‑grave, filtre passe‑bas 900–1800 Hz qui respire,
  réverbération longue (impulsion générée, 3 à 4 s), chorus lent.
- *Variantes par monde* : même motif, autre mode et autre registre (Atelier = Mi mineur pentatonique ; Fonderie =
  La dorien plus chaud et plus lent ; Glacier = quintes ouvertes, timbre plus cristallin, sans grave).
- *Bruitages* : chaque événement = bruit filtré + note de l'échelle du monde, attaque 8–20 ms, réverbération
  en envoi, aucun clic sec. La hauteur d'un impact suit l'échelle : les effets deviennent des notes du thème.
- *Critère mesurable* : rendre un extrait hors ligne et repasser la même analyse : centre de gravité < 1,2 kHz,
  énergie > 4 kHz < 5 %. **Les critères mesurables ne remplacent pas l'écoute : tu devras écouter et trancher.**

## 7. Ordre de travail proposé

1. Valider sur ton appareil : éditeur, didacticiel, carte, décor du monde 4 (ce que livre R38).
2. **Son** (H, I) : chantier indépendant des niveaux ; le plus visible dans l'expérience après le décor.
3. **Monde 3 (Chaîne)** : niveaux jamais refondus. Ils précèdent le monde 4 dans la progression.
4. **Monde 4 (Glacier)** : refondre les 12 niveaux autour du glissement soutenu (voir `WORLD_IDENTITY_FRAMEWORK.md`).
5. Voiles pour les mondes 5 à 11 ; carte des mondes et cellules `.cell` au même style que la carte d'un monde.
