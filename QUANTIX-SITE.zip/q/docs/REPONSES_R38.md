# QUANTIX — réponses de Simon au questionnaire R38 (consignées au fil de l'eau)

| # | Sujet | Réponse | Suite à donner |
|---|---|---|---|
| 1 | Éditeur de lignes (dock, poignées) | **Clair et agréable** | Rien à changer |
| 2 | Ligne droite et accroches | **Bien** | Rien à changer |
| 3 | Typographie du didacticiel | **Cohérente avec l'éditeur et avec le reste du jeu, tout en signalant qu'il s'agit d'un didacticiel** (compromis à trouver : taille, police, graisse, italique, couleur) | Voir « Cahier typographique » ci-dessous |
| 4 | Design des cartes et du bandeau de mission | **Manque de caractère** | Donner une identité propre : motif, couleur de catégorie plus présente, animation d'entrée plus marquée (à proposer, à valider) |
| 5 | Ton des textes | **Pas assez, va plus loin** | Renforcer la voix quantique : images plus fortes, vocabulaire réel (mesure, superposition, onde), tout en gardant la consigne exacte |
| 6 | Carte d'un monde (fils et orbes) | **Trop discret maintenant** | Remonter l'intensité, entre l'ancienne version (lourde) et la version R38 (trop effacée) : halos et fils plus lumineux, orbes moins transparents |
| 7 | Décor du monde 4 | **Sur la bonne voie**, mais : ne pas trop charger, respecter la cohérence dynamique et la composition ; ne pas répéter le même élément trop de fois, sinon jouer sur les échelles de taille | Varier les échelles (tourbillons de tailles différentes, moins nombreux), alléger, vérifier la composition sur plusieurs niveaux |
| 8 | Voiles des mondes 1 à 3 | **Bien pour le moment**, mais **les grilles d'interdiction sont trop légères** | Renforcer les zones interdites (hachures, contour, teinte) dans tous les mondes |
| 9 | Direction du thème musical | **Pas de réponse : le son ne fonctionne pas dans l'aperçu**, pas encore mis en ligne | Bug à instruire : audio muet dans l'aperçu publié. Décision musicale reportée à l'écoute |
| 10 | Bruitages | Les bruitages sont **inchangés** dans l'aperçu (normal : rien n'a été modifié) et restent **trop secs**. Visé : beaucoup moins secs, très agréables mais **bien en place**, un peu de réverbération et d'éclat sur certains sons, un rendu « marshmallow » plutôt que des tacs et des bips secs. **Une recherche plus poussée est demandée** pour trouver ce qui convient à un jeu à l'univers vaporeux et éthéré | Chantier son : phase de recherche d'abord (références, palette de timbres, essais comparés à écouter), puis réalisation |
| 11 | Ordre de la suite | **Monde 3, puis monde 4, puis son** | Prochaine tâche : refonte des 12 niveaux du monde 3 (Chaîne, élan), puis monde 4 (Glacier), puis son |
| 12 | Fluidité sur téléphone | **Fluide** | Marge disponible pour les voiles ; garder le budget (13 ms/scène sans GPU) |
| 13 | « Déplacer » gratuit | **À décider selon les niveaux** | Prévoir un réglage par niveau (par exemple `move:0` pour l'interdire, ou un coût) dans `levels.js`, lu par l'éditeur ; le défaut reste gratuit. Remesurer la jouabilité au doigt (`difficulty.js`) au fil des refontes |

## Cahier typographique du didacticiel (issu de la réponse 3)

Principe : **mêmes familles que le jeu, un signal propre au didacticiel par la couleur et l'italique, pas par une police étrangère.**
- Le dock de l'éditeur utilise déjà la police mono en petites capitales espacées : les kickers du didacticiel (« NOUVEAU · OUTIL », « MISSION ») font donc écho à l'éditeur.
- Titres : Space Grotesk, comme les titres du jeu.
- Phrase d'ambiance (première phrase, ton quantique) : **italique**, gris‑bleu plus doux.
- Phrase d'usage (consigne) : droite, plus claire, mot clé en blanc gras avec soulignement lumineux.
- Couleur du signal « didacticiel » : la couleur de la catégorie (cyan outil, rouge danger, violet…) déjà portée par les kickers et les coins de cadre.
- **À valider sur appareil** (pas de police chargée dans le bac à sable).

## Bug consigné — son muet dans l'aperçu publié (signalé à la question 9)

*Précision à confirmer avec Simon : la réponse 10 juge les bruitages « inchangés », donc audibles. Le silence signalé en 9 concerne peut-être seulement la musique de fond, ou le nouveau thème qui n'existe pas encore. À vérifier avant d'y consacrer du temps.*

- **Vérifié en local (Chromium)** : les 18 sons sont bien embarqués dans le fichier d'aperçu et la lecture d'un effet réussit (durée lue : 0,13 s).
- **Non reproduit** dans le bac à sable : le problème est donc propre à l'environnement où l'aperçu est publié.
- **Hypothèses, non vérifiées** : (1) la page publiée refuse les sons créés en mémoire (`blob:`) ; (2) le cadre de l'aperçu n'autorise pas la lecture audio ; (3) le son ne démarre qu'après un premier toucher et rien ne le signale.
- **Piste** : ajouter dans l'aperçu une ligne de diagnostic visible (état audio, dernière erreur) pour savoir laquelle des trois tient ; charger les sons directement depuis leur donnée intégrée au lieu de `blob:` ; tester le zip une fois mis en ligne.

## Synthèse des décisions (13 réponses)

**Validé, rien à changer** : éditeur de lignes (1), ligne droite et accroches (2), voiles des mondes 1 à 3 (8, sauf zones interdites), fluidité sur téléphone (12).

**À corriger ou renforcer**
- Didacticiel : plus de caractère graphique (4), ton plus fort (5), typographie cohérente avec l'éditeur et le jeu, signal « didacticiel » par couleur et italique (3).
- Carte d'un monde : remonter l'intensité (6).
- Zones interdites : trop légères dans tous les mondes (8).
- Monde 4 : varier les échelles, ne pas répéter ni surcharger (7).
- Éditeur : « Déplacer » réglable par niveau (13).

**Ordre de travail** (11) : monde 3, puis monde 4, puis son. Le son commence par une phase de recherche (10).

**À clarifier** : quel son est muet dans l'aperçu (9 / 10).
