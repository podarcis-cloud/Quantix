# QUANTIX — REPRISE DE SESSION (à lire EN PREMIER, puis s'arrêter là)

*Ce fichier remplace la relecture de la conversation précédente, devenue trop
longue et trop coûteuse. Il suffit à reprendre le travail. Version : **R40**.*

## 0 ter. R40 — son éthéré (`assets/js/sound.js`)

- **Intégré** : remplace la musique et les bruitages d'Audio1 (API inchangée), chargé après `engine.js`. Plus aucun échantillon mp3 joué (les fichiers restent dans `assets/audio/`, inutilisés). Synthèse pure : pas de `blob:` (piste pour le son muet signalé dans l'aperçu publié — **non vérifié** dans l'environnement de publication).
- **Musique** : thème de 5 notes (pentatonique de mi mineur, comme les vidéos de référence) en voix de verre, varié par 5 motifs ; nappe à 6 voix désaccordées + grave doux, filtre qui respire ; une couleur par monde (Atelier mi mineur, Fonderie la dorien, Chaîne sol pentatonique majeur, Glacier quintes ouvertes cristallines ; 5 à 11 déclinés). Couches mixées selon l'état (menu, dessin, chute, tension, réussite, échec).
- **Bruitages** : voix « guimauve » (triangle filtré, attaque 11 à 25 ms), verre, souffle filtré ; tous accordés sur l'échelle du monde et envoyés dans la même réverbération générée (3,6 s). Impacts limités à un toutes les 60 ms.
- **Mesuré (rendu hors ligne, scène de 36 s)** : centre spectral 561 Hz (anciens bruitages : 2 600 à 2 900 Hz ; référence vidéo : 928 Hz) ; énergie > 4 kHz 0,5 % (anciens : 24 à 29 % ; référence 3 %) ; 63 % de l'énergie entre 250 Hz et 1 kHz (référence 58 %). Extrait audio : `docs/quantix-son-demo-R40.wav`.
- **Non vérifié** : l'écoute (impossible ici) — c'est Simon qui juge. Réglages dans `sound.js` : tableau `WORLDS` (tonalité, filtre, tempo, brillance), `MOTIF`, `MIX`, fonctions `SFX`.

## 0 bis. R39 — monde 3 refondu (lire aussi `docs/REPONSES_R38.md`)

| Élément | État | Preuve |
|---|---|---|
| Monde 3 · Chaîne : 12 niveaux neufs | **Intégré** (`levels.js`, candidats `tools/w3cand.js`) | `node tools/monde3.js` → 12/12 ; balayage : 0 gagnant sans tapis sur les 12 |
| Jouabilité au doigt monde 3 | **Conformes** : 25 (92 % / 60 %), 28 (98 / 72), 29 (98 / 75). **Pas conformes** : 26 (63 %), 27 (63 %), 30 (~23 %), 31 à 36 non remesurés | `difficulty.js`, `retune.js` (étendu au monde 3), `tools/w3retune.json` |
| Retours de Simon (questionnaire) | Appliqués : zones interdites renforcées, carte plus lumineuse, tourbillons du monde 4 à échelles variées, didacticiel (phrase d'ambiance en italique, filet lumineux, ton plus fort) | captures, `e2e-didacticiel.py` 36/36 |

**Didacticiel dans les aperçus (R39, correctif)** : `build-apercu.py N … skipintro` traite désormais le joueur comme ayant fini les mondes précédents (intro faite, fiches d'outils vues, éléments des niveaux précédents vus) ; seules les règles nouvelles du monde s'affichent, et l'état n'est plus remis à zéro à chaque ouverture. Dans le jeu, une fiche vue ne revient jamais (vérifié : niveau 2 → outils + zone interdite ; 13 → rebond seul ; 25 → tapis seul ; 26 → rien).
**Règle apprise (monde 3)** : une balle qui démarre au repos sur un sol plat rend le niveau injouable au doigt (un trait décalé la laisse immobile) ; démarrer plus haut (y ≈ 196) donne de l'élan et de la tolérance, mais ouvre des contournements, à fermer en élargissant la zone interdite (pas en réduisant l'encre, sans effet).
**Suite** : régler 26, 27, puis 30 à 36 (`OUT=w3retune.json TMAX=… NG=… SP=… node retune.js N`, vérifier le contournement avec `node w3lab.js old:N`, écrire avec `python3 w3apply.py N`, relancer `monde3.js`). Puis monde 4, puis son (phase de recherche).

## 0. R38 — ce qui a changé (lire avec `docs/CAHIER_DES_CHARGES_R39.md`)

| Élément | État | Preuve |
|---|---|---|
| **Éditeur de lignes** (droite, gomme, déplacer/pivoter, historique unifié) | **Intégré** : `assets/js/editor.js`, dock `#dock` | `python3 tools/e2e-editeur.py` → 25/25 (souris, Chromium) |
| **Didacticiel refondu** (design, tonalité « carnet de laboratoire », 4 fiches d'outils) | **Intégré** | `node tools/tutotest.js` ; `python3 tools/e2e-didacticiel.py` → 36/36 |
| **Voiles de points** (3 couches translucides, mondes 1 à 4) | **Intégré** : `veils()` dans `visuals.js` | captures Chromium ; 13 ms/scène sans GPU |
| **Monde 4 : décor** (franges de Young, tourbillons, globe de fils, condensat) | **Décor seulement — les 12 niveaux du monde 4 sont encore les anciens (R29)** | captures |
| **Carte d'un monde éthérée** | **Intégré** | captures |
| Son (musique mélodique, bruitages texturés) | **Non commencé** ; analyse des vidéos faite | `CAHIER_DES_CHARGES_R39.md` §6 |
| Jouabilité au doigt avec l'éditeur | **Non remesurée** | §5 du cahier des charges |
| **Monde 3 (Chaîne)** | Niveaux jamais refondus ; précède le monde 4 | — |

**Limites de vérification** : captures avec police de secours (pas de réseau) ; aucun test sur téléphone réel ;
aucune écoute possible ; démos de fiches illustratives, pas la physique du moteur.
`python3 tools/build-apercu.py N [U] [skipintro]` : `skipintro` considère le didacticiel d'ouverture comme fait
(nécessaire pour voir le dock dans un aperçu qui n'ouvre pas sur le niveau 1).

## Phrase d'ouverture à coller dans une conversation neuve

> Reprends Quantix. Lis `docs/REPRISE-SESSION.md` en entier, puis seulement
> les sections du handbook qu'il indique. Tâche : **[une seule tâche de la
> liste §4]**. Applique la méthode §3. Livre un aperçu jouable publié, puis
> le zip.

## 1. Où en est le jeu (vérifié par les tests, pas déclaré)

| Élément | État | Preuve |
|---|---|---|
| Monde 1 · Atelier | **Refondu, 12/12** | `node tools/monde1.js` |
| Monde 2 · Fonderie | **Refondu 11/12** — #19 est l'ANCIEN « Le four » (R29), à reconcevoir | `node tools/monde2.js` → 11/11 ; `bypass.js 2` → 0/11 |
| Mondes 3 à 11 | Anciens niveaux (R29), à refondre | — |
| Solution optimale (bouton) | Mondes 1 et 2 : chaque niveau refondu a son `optsol` (+ `optmat` si matière rebond), noyau compris | `node tools/replaytest.js` |
| Revoir ma partie | Fonctionne (relit `S.rec`, sans physique) | `replaytest.js` |
| Rebond sans fin | Arrêt à **20 s** de vol → « Rebond sans fin » + bouton **Continuer** (+20 s) | testé R32 |
| **Nouveau rendu (R33)** | **Intégré au jeu** : `assets/js/visuals.js` (portée privée, un seul global `window.VX`). Structures en treillis, plaques incandescentes, pointes cristallines, cuve, zones interdites, ruban d'énergie, noyau et **balle en nuage de points bistable**, **accueil animé**. Décor : monde 1 = cosmos + hélices ADN composées par niveau ; monde 2 = chambre à bulles ; **monde 3 = anneau de stockage (cavités RF, lumière synchrotron de la balle) — R35** ; **mondes 4–11 = cosmos aux couleurs du monde (provisoire, à doter de leur identité propre)** | captures Chromium réelles (Playwright disponible : `/tmp/shot.py` à recréer, voir §5) ; appels comptés dans le moteur |

| **Didacticiel (R37)** | **Intégré au jeu** : première partie guidée dans le niveau 1 ; fiche d'élément à la première rencontre (détection sur les données du niveau, 18 éléments, tous mondes) ; « Aide du niveau » (pause) ; « Explications » (paramètres). Voir handbook §13 | `node tools/tutotest.js` ; parcours Chromium réel (échec, persistance, aide, explications, anglais, 360×640) |

**Aperçus publiés** (claude.ai) : Atelier 12/12 et Fonderie 10 niveaux —
sources dans `docs/apercus/` ; code des décors dans `tools/apercu/`.

## 2. Ce que l'utilisateur veut (ne pas le perdre)

- **Refonte niveau par niveau**, ambitieuse, jamais un simple correctif :
  chaque niveau = une idée, une chute, un noyau qui récompense un choix.
- **Chaque monde a sa narration et son identité visuelle animée forte** —
  fondée sur une expérience de physique réelle (`docs/QUANTUM_VISUAL_NARRATIVE.md`).
  Les vidéos d'illusions bistables (nuages de points en rotation) sont des
  **références d'animation mathématique** pour ces identités de monde — pas
  une demande de nouveau noyau par monde.
- **Toujours un aperçu jouable** du travail en cours, qui soit fidèle au jeu.
- Style de décor retenu : **néon + couche cosmique** (hélices ADN, poussière
  d'étoiles, voile de nébuleuses), décliné par monde (Fonderie = chambre à
  bulles). Le style « rétro plat » a été **rejeté**.
- Réponses en **français**. Ne pas se contenter de documenter : produire.

## 3. Méthode qui marche (outils dans `tools/`)

1. Concevoir des candidats dans un fichier `wNcand.js` (format de `levels.js`).
2. `lab.js` : pour chaque candidat — échec sans trait, gagnants AVEC la
   mécanique, gagnants SANS elle (doit être 0). Script modèle : `w2redo.js`.
3. `w2finish.js` (généraliser en `wNfinish.js`) : noyau placé où passent
   15–35 % des solutions, solution avec noyau la plus tolérante au doigt
   (±4 px, seuil ≥ 50 %). **Un niveau par commande** (`OUT=wN_k.json
   STEP=14 DA=.34 NT=30 timeout 285 node …`) — la machine n'a **qu'un
   processeur**, rien en parallèle, rien en arrière-plan (ne survit pas).
4. Vérifier que les gagnants utilisent **vraiment** chaque élément prévu
   (rendre l'élément inerte, compter ceux qui échouent).
5. Écrire dans `levels.js` (+ `optsol`/`optmat`) et `i18n.js` (EN), puis
   un test `mondeN.js` sur le modèle de `monde2.js`.
6. Aperçu : partir de `docs/apercus/monde2-fonderie.html` (collision
   **identique** au moteur : contact à R+4 murs, R+3,2 traits, pointes
   mortelles). Remplacer le décor par celui du monde. Vérifier que chaque
   solution y gagne avec le noyau avant de publier.
7. Séquence handbook §10 + `monde1.js` `monde2.js` `replaytest.js`, tampon
   de version neuf, zip.

**Règles de conception apprises** : handbook §11 ter (monde 1) et
§11 quinquies (monde 2 — principe d'énergie : bassin plus haut que le
départ ⇒ rebond indispensable ; la plaque ne projette vers le haut que
frappée **en vol** ; éviter les demi-tours avec rebond et les rebonds entre
deux parois).

## 4. Prochaines tâches, dans l'ordre

**Didacticiel — reste à faire** : (a) test sur de vrais joueurs débutants, sur téléphone ; (b) lorsqu'un monde est refondu, vérifier que chaque élément nouveau arrive **seul** en position 1 ou 2 (relevés au handbook §13) ; (c) les démos de fiche sont illustratives, pas la physique du moteur : à remplacer si l'écart gêne ; (d) l'étape « Voir la solution optimale » et le score en étoiles ne sont pas expliqués hors de l'écran de résultat.

0. **EN COURS (R34) : jouabilité au doigt** — correction appliquée à 16 niveaux,
   bilan au §8 de `docs/DIFFICULTY_PROTOCOL.md`. Reste : reconcevoir #12, #15,
   #16, #17, #18, #19 (géométrie convergente) ; revoir les noyaux trop faciles.
   Outils : `retune.js` (correction), `fixstar.js` (noyau sur la trajectoire
   exacte), `difficulty.js` (mesure). Historique de la tâche :
   **rendre les mondes 1 et 2 jouables au doigt** — test réel :
   difficulté excessive, marge d'erreur trop faible, pas d'alternative à la
   solution parfaite. Mesuré (`docs/DIFFICULTY_PROTOCOL.md`,
   `node tools/difficulty.js N`) : quasiment aucun niveau n'atteint
   P_exec ≥ 70 %. Corriger la **géométrie** niveau par niveau (§6 du
   protocole) — une aide « tracé redressé » a été mesurée inutile.
   L'ancienne tolérance ±4 u (0,6 mm) est **obsolète**.

1. **Monde 2 #19** (rôle « combinaison ») — 9 concepts rejetés, listés au
   handbook §11 quinquies. Piste non essayée : combiner avec *Le col* ou
   *Le leurre* du monde 1, en gardant une arrivée **en vol** sur la plaque.
2. **Monde 2 : réduire la redondance** (`redundancy.js 2` → 8 paires) —
   varier la position du départ et de la plaque entre niveaux proches.
3. **Monde 3 · Chaîne (élan)** — narration « anneau d'accélération ».
   Principe à vérifier d'abord : le tapis d'élan est un *interrupteur* de
   vitesse (~7,4 constant), pas un curseur.
4. Doter chaque monde 3–11 de son identité animée propre dans `visuals.js`
   (fonction `back()` : aiguillage par `D.wd`), d'après `QUANTUM_VISUAL_NARRATIVE.md`.
5. Mondes 4 à 11, puis #114 (monde 10, infranchissable) et monde 11
   (12/12 contournable) — priorités connues.

## 4 bis. Règles de livraison et de charte (demandes utilisateur, R36)

- **Ne livrer que l'aperçu du monde en cours**, ouvert directement sur sa
  carte avec ses niveaux débloqués : `python3 tools/build-apercu.py N`
  → `quantix-apercu-mondeN.html` (publier comme artefact). Plus de version
  « jeu complet » à chaque livraison : l'utilisateur devait rejouer tous les
  niveaux pour atteindre le monde travaillé. Le zip reste le livrable du site.
- **Illustrations** : jamais utilisées brutes (trop saturées, trop claires pour
  la charte néon sur fond #05070D). `python3 tools/grade-art.py` les étalonne
  (saturation ×0,48, luminosité ×0,70, virage nuit → couleur du monde → cyan
  pâle, vignettage) depuis les **originaux conservés** dans `docs/source-art/`.
  Toute nouvelle illustration : la déposer dans `docs/source-art/`, relancer.
- **Carte d'un monde** : nœuds = particules (sphère de verre, nuage de points
  tournant, orbite + électron), liens = filaments d'énergie (halo, flux,
  photon sur les liens réussis) — `openWorld()` dans `engine.js`, styles
  `.wn` / `.wl*` dans `quantix.css`. États : lock / open / cur / done.

## 5. Pièges qui ont coûté cher (ne pas refaire)

- **Un aperçu n'est pas le jeu** : l'utilisateur a mis en ligne R32 en
  croyant y trouver le nouveau design, qui n'existait que dans les aperçus.
  Toujours dire explicitement ce qui est dans le moteur et ce qui ne l'est pas.
- **Vérifier visuellement** : Playwright + Chromium fonctionnent ici.
  `page.goto('file:///…/index.html')`, puis `page.evaluate("goto('game');loadLevel(i)")`,
  puis `page.screenshot(...)`.

- `node -e` : jamais de variable `L`, `S`, `T` (collision avec le moteur,
  handbook §9.1) — utiliser `LV`, `ST`, `X.S`.
- `pkill -f motif` tue aussi la commande qui le contient.
- Un aperçu à physique approximative ment : copier `collide()` du moteur.
- Une solution de référence « qui gagne » ne prouve pas que le noyau est
  atteignable : toujours vérifier `gotStar`.
