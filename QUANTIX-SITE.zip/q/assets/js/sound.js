/* ══ SON ÉTHÉRÉ ══ (R40)
   Remplace la musique et les bruitages d'Audio1 (engine.js) par une synthèse douce, sans échantillon :
   - un THÈME de cinq notes (pentatonique de mi mineur, comme les bandes son de référence), joué par une voix
     de verre (sinus + partiel à 2,76), repris et varié par monde ;
   - des NAPPES : accord à trois voix désaccordées, filtre passe-bas qui respire, grave très doux ;
   - des BRUITAGES « guimauve » : attaque lente (10 à 25 ms), hauteur prise dans l'échelle du monde,
     souffle filtré pour les glissements, envoi dans une réverbération longue générée (≈ 3,5 s).
   Musique et bruitages partagent la même échelle et la même réverbération : ils se répondent.
   L'API d'Audio1 est conservée (unlock, playSfx, playImpact, playMusicState, setWorld, set*Vol…).
   Chargé APRÈS engine.js. Aucun texte visible. */
(function(){
if(typeof Audio1==='undefined')return;
var A0={};for(var k in Audio1)A0[k]=Audio1[k];

/* ── mondes : même motif, autre couleur ── */
var PENTA=[0,3,5,7,10];                       /* mi sol la si ré — degrés de la pentatonique mineure */
var WORLDS=[
 {root:52,scale:[0,3,5,7,10],cut:1200,tempo:17,bright:.55,chords:[[0,7,14],[-4,3,11],[3,10,14],[-2,5,12]]},   /* 1 Atelier : mi mineur */
 {root:57,scale:[0,2,3,7,9],cut:950,tempo:20,bright:.45,chords:[[0,7,15],[-2,5,14],[3,10,15],[-5,2,10]]},     /* 2 Fonderie : la dorien, plus chaud */
 {root:55,scale:[0,2,4,7,9],cut:1300,tempo:15,bright:.6,chords:[[0,7,16],[-3,4,12],[5,9,16],[2,7,14]]},       /* 3 Chaîne : sol majeur pentatonique, élan */
 {root:64,scale:[0,2,7,9,14],cut:1700,tempo:22,bright:.8,chords:[[0,7,14],[5,12,19],[-5,2,9],[0,7,19]]},       /* 4 Glacier : quintes ouvertes, cristallin */
 {root:50,scale:[0,3,5,7,10],cut:1100,tempo:18,bright:.5,chords:[[0,7,14],[-4,3,10],[5,10,15],[-2,5,12]]},
 {root:53,scale:[0,2,5,7,9],cut:1000,tempo:16,bright:.5,chords:[[0,7,14],[-3,4,12],[2,9,14],[-5,2,9]]},
 {root:48,scale:[0,3,5,7,10],cut:1000,tempo:20,bright:.45,chords:[[0,7,15],[-4,3,10],[3,10,15],[-2,5,12]]},
 {root:56,scale:[0,2,4,7,9],cut:1300,tempo:18,bright:.6,chords:[[0,7,16],[-3,4,12],[5,9,16],[2,7,14]]},
 {root:51,scale:[0,3,5,7,10],cut:1150,tempo:19,bright:.55,chords:[[0,7,14],[-4,3,11],[3,10,14],[-2,5,12]]},
 {root:54,scale:[0,2,3,7,9],cut:1050,tempo:21,bright:.5,chords:[[0,7,15],[-2,5,14],[3,10,15],[-5,2,10]]},
 {root:52,scale:[0,2,7,9,14],cut:1500,tempo:24,bright:.7,chords:[[0,7,14],[5,12,19],[-5,2,9],[0,7,19]]}];
/* motif (degrés d'échelle) et ses variantes : l'ordre des phrases fait le chant */
var MOTIF=[[0,2,4,3,1],[0,2,4,5,4],[4,3,2,1,0],[2,4,5,7,4],[0,1,2,4,2]];
var ST={menu:0,draw:1,run:2,tension:3,success:4,failure:5};

var ac=null,master,comp,rev,revIn,mus,sfx,dry,wi=0,st=1,started=false,chordI=0,next=0,timer=0,phrase=0,padV=[],padF=null,lastImp=0;
var vol={mus:(typeof OPT!=='undefined'&&OPT.mus!==false)?(OPT.musVol!==undefined?OPT.musVol:.5):0,
         sfx:(typeof OPT!=='undefined'&&OPT.sfx!==false)?(OPT.sfxVol!==undefined?OPT.sfxVol:1):0};
var noiseBuf=null;

function mtof(n){return 440*Math.pow(2,(n-69)/12);}
function W(){return WORLDS[wi]||WORLDS[0];}
function note(d,oct){var w=W(),s=w.scale,n=s.length,i=((d%n)+n)%n;return mtof(w.root+s[i]+12*(Math.floor(d/n)+(oct||0)));}

/* réverbération : réponse impulsionnelle générée (bruit stéréo, décroissance exponentielle, aigus amortis) */
function impulse(c,sec,decay){
 var n=Math.floor(c.sampleRate*sec),b=c.createBuffer(2,n,c.sampleRate),ch,i,d,lp;
 for(ch=0;ch<2;ch++){d=b.getChannelData(ch);lp=0;
  for(i=0;i<n;i++){var t=i/n,x=(Math.random()*2-1)*Math.pow(1-t,decay);lp+= (x-lp)*(.18+.5*(1-t));d[i]=lp;}}
 return b;}
function graph(c){
 ac=c;master=c.createGain();master.gain.value=1.25;
 comp=c.createDynamicsCompressor();comp.threshold.value=-20;comp.knee.value=18;comp.ratio.value=3;comp.attack.value=.02;comp.release.value=.3;
 master.connect(comp);comp.connect(c.destination);
 rev=c.createConvolver();rev.buffer=impulse(c,3.6,2.4);
 var rlp=c.createBiquadFilter();rlp.type='lowpass';rlp.frequency.value=3200;
 revIn=c.createGain();revIn.gain.value=1;revIn.connect(rlp);rlp.connect(rev);
 var rOut=c.createGain();rOut.gain.value=.55;rev.connect(rOut);rOut.connect(master);
 mus=c.createGain();mus.gain.value=vol.mus;dry=c.createGain();dry.gain.value=1;
 sfx=c.createGain();sfx.gain.value=vol.sfx;
 mus.connect(master);sfx.connect(master);
 var n=Math.floor(c.sampleRate*2),nb=c.createBuffer(1,n,c.sampleRate),nd=nb.getChannelData(0),i,pk=0;
 for(i=0;i<n;i++){var w=Math.random()*2-1;pk=.97*pk+.03*w;nd[i]=pk*6;}   /* bruit « rose-ish », pas de sifflement */
 noiseBuf=nb;}
function send(node,bus,wet){node.connect(bus);var s=ac.createGain();s.gain.value=wet;node.connect(s);s.connect(revIn);}

/* ── voix ── */
function glass(bus,f,t,dur,g,wet){ /* verre / cloche douce : fondamentale + partiel inharmonique discret */
 var o=ac.createOscillator(),o2=ac.createOscillator(),e=ac.createGain(),e2=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain();
 o.type='sine';o2.type='sine';o.frequency.value=f;o2.frequency.value=f*2.756;
 lp.type='lowpass';lp.frequency.value=Math.min(5200,f*4.5);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.018);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 e2.gain.setValueAtTime(.0001,t);e2.gain.linearRampToValueAtTime(g*.16*W().bright,t+.012);e2.gain.exponentialRampToValueAtTime(.0001,t+dur*.35);
 o.connect(e);o2.connect(e2);e.connect(lp);e2.connect(lp);lp.connect(out);send(out,bus,wet===undefined?.5:wet);
 o.start(t);o2.start(t);o.stop(t+dur+.05);o2.stop(t+dur+.05);}
function mallow(bus,f,t,dur,g,wet,glide){ /* « guimauve » : triangle filtré, attaque lente, léger glissement de hauteur */
 var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain();
 o.type='triangle';o.frequency.setValueAtTime(f*(glide||1),t);o.frequency.exponentialRampToValueAtTime(f,t+Math.min(.08,dur*.5));
 lp.type='lowpass';lp.frequency.setValueAtTime(f*3.2,t);lp.frequency.exponentialRampToValueAtTime(Math.max(120,f*1.3),t+dur);lp.Q.value=.3;
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.022);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 o.connect(lp);lp.connect(e);e.connect(out);send(out,bus,wet===undefined?.4:wet);o.start(t);o.stop(t+dur+.05);}
function breath(bus,t,dur,f0,f1,g,wet,q){ /* souffle filtré qui glisse de f0 à f1 */
 var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain(),out=ac.createGain();
 s.buffer=noiseBuf;s.loop=true;bp.type='bandpass';bp.Q.value=q||1.4;
 bp.frequency.setValueAtTime(f0,t);bp.frequency.exponentialRampToValueAtTime(f1,t+dur);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+dur*.35);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 s.connect(bp);bp.connect(e);e.connect(out);send(out,bus,wet===undefined?.5:wet);s.start(t,Math.random()*1.5);s.stop(t+dur+.05);}

/* ── musique ── */
var MIX=[ /* nappe, thème, pulsation, grave — par état de jeu */
 [1,.9,0,.6],[1,.7,0,.6],[.9,.5,.55,.7],[.7,.3,.8,.8],[1,1,.3,.6],[.6,.2,0,.4]];
var lay={};
function buildMusic(){
 var names=['pad','theme','pulse','sub'],i;
 names.forEach(function(n){lay[n]=ac.createGain();lay[n].gain.value=0;lay[n].connect(mus);});
 padF=ac.createBiquadFilter();padF.type='lowpass';padF.frequency.value=W().cut*1.7;padF.Q.value=.5;padF.connect(lay.pad);
 var lfo=ac.createOscillator(),lg=ac.createGain();lfo.frequency.value=.05;lg.gain.value=W().cut*.35;lfo.connect(lg);lg.connect(padF.frequency);lfo.start();
 var ps=ac.createGain();ps.gain.value=.5;padF.connect(ps);ps.connect(revIn);
 padV=[];
 for(i=0;i<6;i++){var o=ac.createOscillator(),g=ac.createGain();o.type=i%2?'sine':'triangle';o.detune.value=(i%2?1:-1)*(4+i*1.5);
  g.gain.value=i%2?.04:.03;o.connect(g);g.connect(padF);o.start();padV.push(o);}
 var sub=ac.createOscillator(),sg=ac.createGain();sub.type='sine';sg.gain.value=.035;sub.connect(sg);sg.connect(lay.sub);sub.start();padV.push(sub);
 setChord(0,ac.currentTime);mixTo(1.5);
 next=ac.currentTime+.3;timer=setInterval(tick,90);}
function setChord(ci,t){
 var w=W(),ch=w.chords[ci%w.chords.length],i;
 for(i=0;i<6;i++){var f=mtof(w.root+ch[i%3]+(i>=3?12:0));padV[i].frequency.setTargetAtTime(f,t,.9);}
 padV[6].frequency.setTargetAtTime(mtof(w.root-12+ch[0]),t,1.2);}
function mixTo(tc){var m=MIX[st]||MIX[1];['pad','theme','pulse','sub'].forEach(function(n,i){lay[n].gain.setTargetAtTime(m[i],ac.currentTime,tc||1.2);});}
function tick(){
 if(!ac)return;var w=W(),bar=60/w.tempo*2;   /* une « mesure » lente : 5 à 7 s */
 while(next<ac.currentTime+.4){
  var t=next;
  setChord(chordI,t);
  /* thème : une phrase toutes les deux mesures, avec un souffle de silence entre les phrases */
  if(chordI%2===0){var m=MOTIF[phrase%MOTIF.length],k,step=bar/6;
   for(k=0;k<m.length;k++)if(!(phrase%3===2&&k===m.length-1))glass(lay.theme,note(m[k],2),t+.2+k*step*(k===m.length-1?1.4:1),2.8,.06,.62);
   phrase++;}
  /* pulsation douce (pendant la chute) : notes détachées de l'accord */
  var n=4;for(var j=0;j<n;j++)if(Math.random()<.7)mallow(lay.pulse,note([0,2,4,2][j],1),t+j*bar/n,.5,.035,.5);
  chordI++;next+=bar;}}
function stopMusic(){clearInterval(timer);timer=0;try{padV.forEach(function(o){o.stop(ac.currentTime+.8);});}catch(e){}
 ['pad','theme','pulse','sub'].forEach(function(n){if(lay[n])lay[n].gain.setTargetAtTime(0,ac.currentTime,.25);});}

/* ── bruitages : tous accordés sur l'échelle du monde ── */
function now(){return ac.currentTime+.005;}
var SFX={
 ui_tap:function(t,v){glass(sfx,note(4,2),t,.35,.05*v,.35);},
 ui_confirm:function(t,v){glass(sfx,note(2,2),t,.6,.06*v,.45);glass(sfx,note(4,2),t+.07,.8,.05*v,.5);},
 draw_material:function(t,v){breath(sfx,t,.22,700,1400,.05*v,.3,2);},
 rope_set:function(t,v){mallow(sfx,note(0,1),t,.7,.08*v,.45,1.03);},
 ball_launch:function(t,v){breath(sfx,t,.7,300,1200,.06*v,.55,1.1);mallow(sfx,note(0,0),t+.05,1.1,.09*v,.5);},
 boost_whoosh:function(t,v){breath(sfx,t,.55,500,2600,.07*v,.6,1.6);glass(sfx,note(4,2),t+.18,.9,.03*v,.7);},
 portal:function(t,v){glass(sfx,note(0,2),t,1.4,.05*v,.7);glass(sfx,note(2,2),t+.09,1.4,.045*v,.7);glass(sfx,note(4,2),t+.18,1.6,.04*v,.75);breath(sfx,t,.9,2400,600,.04*v,.7,1);},
 star_collect:function(t,v){[0,2,4,5].forEach(function(d,i){glass(sfx,note(d,2),t+i*.075,1.6,.055*v,.6);});},
 goal_enter:function(t,v){glass(sfx,note(0,1),t,2.2,.06*v,.65);glass(sfx,note(4,1),t+.05,2.2,.045*v,.65);},
 level_success:function(t,v){[0,2,4,5,7,9].forEach(function(d,i){glass(sfx,note(d,1),t+i*.11,2.6,.06*v,.65);});mallow(sfx,note(0,-1),t,2.4,.07*v,.6);},
 level_fail:function(t,v){mallow(sfx,note(2,0),t,1.2,.07*v,.6,1.02);mallow(sfx,note(0,0),t+.28,1.8,.07*v,.65,1.02);breath(sfx,t,1.2,900,250,.03*v,.6,1);},
 rewind:function(t,v){breath(sfx,t,.6,2200,400,.06*v,.55,1.3);glass(sfx,note(4,1),t+.1,.8,.03*v,.6);},
 rope_hit:function(t,v){mallow(sfx,note(1,1),t,.6,.06*v,.45,1.04);},
 impact_ice:function(t,v){glass(sfx,note(4,2),t,.9,.05*v,.6);},
 spike_hit:function(t,v){mallow(sfx,note(0,-1),t,.9,.12*v,.5,1.15);breath(sfx,t,.35,1400,300,.05*v,.4,1.2);}};
function impact(mat,i,t){
 /* plus c'est fort, plus la note est grave et ronde ; aucun clic : attaque lente même au plus fort */
 var d=Math.round((1-i)*4);
 if(mat===1){mallow(sfx,note(d+2,1),t,.55+i*.4,.05+.08*i,.5,.94);glass(sfx,note(d+4,2),t+.02,.7,.02+.03*i,.6);}
 else if(mat===2)SFX.spike_hit(t,.6+.4*i);
 else if(mat===4)glass(sfx,note(d+3,2),t,.8+i*.5,.03+.05*i,.6);
 else mallow(sfx,note(d,0),t,.35+i*.35,.04+.08*i,.35,1.02);}

/* ── remplacement de l'API ── */
function ensure(){
 if(ac)return ac;
 var C=window.AudioContext||window.webkitAudioContext;if(!C)return null;
 try{graph(new C());}catch(e){ac=null;return null;}
 return ac;}
Audio1.unlock=function(){
 try{A0.setMusicVol(0);}catch(e){}           /* l'ancienne musique reste muette */
 try{A0.unlock();}catch(e){}                 /* iOS : session audio et boucle silencieuse */
 var c=ensure();if(!c)return;
 if(c.state==='suspended'){try{var r=c.resume();if(r&&r.catch)r.catch(function(){});}catch(e){}}
 if(!started){started=true;buildMusic();}};
Audio1.playSfx=function(n,v){if(!ac||vol.sfx<=0)return;var f=SFX[n]||SFX.ui_tap;f(now(),v===undefined?1:Math.max(.3,Math.min(1,v)));};
Audio1.playImpact=function(mat,vel){if(!ac||vol.sfx<=0)return;var i=Math.min(1,vel/9);if(i<.1)return;
 var t=ac.currentTime;if(t-lastImp<.06)return;lastImp=t;impact(mat,i,t+.005);};
Audio1.playMusicState=function(s){if(ST[s]===undefined)return;st=ST[s];if(ac&&lay.pad)mixTo(s==='tension'?.5:1.1);};
Audio1.setWorld=function(i){if(!WORLDS[i])i=0;if(i===wi)return;wi=i;
 if(ac&&padF){padF.frequency.setTargetAtTime(W().cut*1.7,ac.currentTime,1.5);chordI=0;phrase=0;setChord(0,ac.currentTime);}};
Audio1.setMusicVol=function(v){vol.mus=v;if(mus)mus.gain.setTargetAtTime(v,ac.currentTime,.1);try{A0.setMusicVol(0);}catch(e){}};
Audio1.setSfxVol=function(v){vol.sfx=v;if(sfx)sfx.gain.setTargetAtTime(v,ac.currentTime,.05);};
Audio1.setMusic=function(on){Audio1.setMusicVol(on?(vol.mus||.5):0);};
Audio1.setSfx=function(on){Audio1.setSfxVol(on?(vol.sfx||1):0);};
Audio1.test=function(){Audio1.playSfx('ui_confirm');};
Audio1.state=function(){return ac?ac.state:'inactif';};
Audio1.sampReady=function(){return true;};Audio1.sampErr=function(){return '';};
Audio1.world=function(){return wi;};
/* rendu hors ligne pour les tests (spectre mesurable sans écouter) */
Audio1._render=function(sec,scene,cb){
 var C=window.OfflineAudioContext||window.webkitOfflineAudioContext;if(!C){cb(null);return;}
 var keep={ac:ac,started:started,timer:timer};var c=new C(2,Math.floor(44100*sec),44100);
 graph(c);vol.mus=vol.mus||.5;vol.sfx=vol.sfx||1;mus.gain.value=vol.mus;sfx.gain.value=vol.sfx;
 buildMusic();clearInterval(timer);next=.3;
 while(next<sec)(function(){var save=c.currentTime;tickAt(sec);})();
 scene(c);
 c.startRendering().then(function(b){ac=keep.ac;started=keep.started;cb(b);});};
function tickAt(horizon){var w=W(),bar=60/w.tempo*2;while(next<horizon){var t=next;setChord(chordI,t);
 if(chordI%2===0){var m=MOTIF[phrase%MOTIF.length],k,step=bar/6;for(k=0;k<m.length;k++)glass(lay.theme,note(m[k],2),t+.2+k*step,2.8,.06,.62);phrase++;}
 for(var j=0;j<4;j++)mallow(lay.pulse,note([0,2,4,2][j],1),t+j*bar/4,.5,.035,.5);chordI++;next+=bar;}}
Audio1._sfxAt=function(n,t,v){(SFX[n]||SFX.ui_tap)(t,v||1);};
Audio1._impactAt=function(m,i,t){impact(m,i,t);};
Audio1._state=function(s){st=ST[s];var m=MIX[st];['pad','theme','pulse','sub'].forEach(function(n,i){lay[n].gain.value=m[i];});};
})();
