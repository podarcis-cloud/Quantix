/* ══ DIDACTICIEL ══ (R37, refonte R38)
   1. Première partie guidée dans le niveau 1 : le joueur fait les gestes lui-même.
   2. Fiche d'élément à la première rencontre : le jeu compare les éléments du niveau
      chargé à la liste « déjà vus » de la sauvegarde. Aucun code par monde.
   3. « Aide du niveau » (pause) et « Explications » (paramètres) pour tout revoir.
   Tout le texte visible vit dans i18n.js (clés ti_*, tt_*, td_*, tuto*).
   Chargé AVANT engine.js ; n'utilise les globaux du moteur (S, LEVELS, W, TR…) qu'à l'exécution. */
var TUTO=(function(){
 var st={intro:false,seen:{}},pend=null,mode=null,T0=0;
 var ci=0,cids=[],fromCodex=false,isRev=false,step=0,failed=false,dId=null,dT=0,dOn=false,dCtx=null,dDir=[1,0],dGm=0;
 var DW=232,DH=104;

 function $$(id){return document.getElementById(id);}
 function vx(){return (typeof window!=='undefined'&&window.VX)||null;}
 function hasArr(a){return !!(a&&a.length);}
 function matIn(lv,m){var w=lv.w||[],i;for(i=0;i<w.length;i++)if(w[i][4]===m)return true;return false;}
 function palHas(lv,ch){return (lv.pal||'S').indexOf(ch)>=0;}

 /* ── catalogue : l'ordre est l'ordre d'enseignement quand plusieurs éléments arrivent ensemble.
    cat : base | tool | mat | elem (libellé de la fiche). Les outils n'ont pas de niveau : ils sont
    proposés une fois, au premier niveau après le didacticiel d'ouverture. ── */
 var TOOLS=['tdraw','tline','terase','tmove'];
 var TOOLMODE={tdraw:'draw',tline:'line',terase:'erase',tmove:'move'};
 function no(){return false;}
 var CAT=[
  {id:'basics',cat:'base',col:'#4DD7FF',has:no},
  {id:'tdraw', cat:'tool',col:'#4DD7FF',has:no},
  {id:'tline', cat:'tool',col:'#4DD7FF',has:no},
  {id:'terase',cat:'tool',col:'#FF5252',has:no},
  {id:'tmove', cat:'tool',col:'#A878FF',has:no},
  {id:'nd',    cat:'elem',col:'#FF5252',has:function(lv){return hasArr(lv.nd);}},
  {id:'spike', cat:'elem',col:'#FF5252',has:function(lv){return matIn(lv,2);}},
  {id:'bounce',cat:'elem',col:'#FFAA3C',has:function(lv){return matIn(lv,1);}},
  {id:'palB',  cat:'mat', col:'#FFAA3C',has:function(lv){return palHas(lv,'B');}},
  {id:'boost', cat:'elem',col:'#A878FF',has:function(lv){return matIn(lv,3);}},
  {id:'palA',  cat:'mat', col:'#A878FF',has:function(lv){return palHas(lv,'A');}},
  {id:'ice',   cat:'elem',col:'#BFEAF7',has:function(lv){return matIn(lv,4);}},
  {id:'palC',  cat:'mat', col:'#E8B98A',has:function(lv){return palHas(lv,'C');}},
  {id:'wind',  cat:'elem',col:'#A8C8E8',has:function(lv){return hasArr(lv.wind);}},
  {id:'grav',  cat:'elem',col:'#A878FF',has:function(lv){return hasArr(lv.grav);}},
  {id:'mag',   cat:'elem',col:'#FF4D8D',has:function(lv){return hasArr(lv.mag);}},
  {id:'port',  cat:'elem',col:'#4DD7FF',has:function(lv){return hasArr(lv.port);}},
  {id:'mov',   cat:'elem',col:'#43D5F5',has:function(lv){return hasArr(lv.mov);}},
  {id:'ent',   cat:'elem',col:'#FFD85A',has:function(lv){return hasArr(lv.ent)||hasArr(lv.gate);}},
  {id:'sup',   cat:'elem',col:'#A878FF',has:function(lv){return hasArr(lv.sup);}},
  {id:'det',   cat:'elem',col:'#FFD85A',has:function(lv){return hasArr(lv.det);}},
  {id:'tdil',  cat:'elem',col:'#4DD7FF',has:function(lv){return hasArr(lv.tdil);}},
  {id:'soft',  cat:'elem',col:'#43D5F5',has:function(lv){return !!lv.softball;}}
 ];
 function entry(id){for(var i=0;i<CAT.length;i++)if(CAT[i].id===id)return CAT[i];return CAT[0];}
 function colOf(id){return entry(id).col;}
 function elemsOf(lv){var o=[],i;if(!lv)return o;for(i=0;i<CAT.length;i++)if(CAT[i].has(lv))o.push(CAT[i].id);return o;}

 /* ── état persistant ── */
 function state(){return {v:1,i:st.intro?1:0,s:Object.keys(st.seen)};}
 function load(d,seenLv){
  st={intro:false,seen:{}};
  var j,k,e;
  if(d&&d.v===1){st.intro=!!d.i;for(k=0;k<(d.s||[]).length;k++)st.seen[d.s[k]]=1;}
  else if(seenLv>0){ /* joueur d'avant le didacticiel : ce qu'il a déjà traversé n'est pas réexpliqué */
   st.intro=true;
   for(j=0;j<seenLv&&j<LEVELS.length;j++){e=elemsOf(LEVELS[j]);for(k=0;k<e.length;k++)st.seen[e[k]]=1;}
  }
 }
 function reset(){st={intro:false,seen:{}};pend=null;hide();}
 function save(){try{if(typeof persist==='function')persist();}catch(e){}}

 /* ── déclenchement ── */
 function onLoad(i){
  pend=null;
  if(mode&&!fromCodex)hide();
  if(typeof S==='undefined'||S.zen)return;
  if(!st.intro&&i===0){pend={li:0,kind:'intro'};return;}
  var ids=[],k;
  if(st.intro)for(k=0;k<TOOLS.length;k++)if(!st.seen[TOOLS[k]])ids.push(TOOLS[k]);
  ids=ids.concat(elemsOf(LEVELS[i]).filter(function(id){return !st.seen[id];}));
  if(ids.length)pend={li:i,kind:'cards',ids:ids};
 }
 function busy(){return !!(document.querySelector&&document.querySelector('.veil.on'));}
 function tick(){
  T0++;
  var scr=$$('app').dataset.screen;
  if(scr!=='game'){if(mode&&!fromCodex)hide();return;}
  if(mode==='intro'){tickIntro();return;}
  if(mode==='card'){pulseTarget();return;}
  if(!pend||pend.li!==S.li||S.zen||S.mode!=='draw'||busy())return;
  if(pend.kind==='intro')startIntro();
  else{var ids=pend.ids;pend=null;openCards(ids,false,false);}
 }

 /* ── première partie guidée ── */
 function rich(el,txt){ /* « *mot* » → mot mis en valeur ; la 1re phrase, quand il y en a plusieurs, est la phrase d'ambiance (italique). Nœuds seulement, jamais de HTML brut. */
  while(el.firstChild)el.removeChild(el.firstChild);
  var s0=String(txt),cut=s0.search(/[.:!?] (?=[A-ZÀ-ÖØ-Þ*])/),wrap=el;
  if(cut>0&&cut<s0.length-12){
   var amb=document.createElement('span');amb.className='amb';el.appendChild(amb);
   var head=s0.slice(0,cut+1);s0=s0.slice(cut+2);
   var hp=head.split('*'),hi,hn;for(hi=0;hi<hp.length;hi++){if(!hp[hi])continue;if(hi%2){hn=document.createElement('em');hn.textContent=hp[hi];amb.appendChild(hn);}else amb.appendChild(document.createTextNode(hp[hi]));}
   el.appendChild(document.createElement('br'));}
  var parts=String(s0).split('*'),i,n;
  for(i=0;i<parts.length;i++){
   if(!parts[i])continue;
   if(i%2){n=document.createElement('em');n.textContent=parts[i];el.appendChild(n);}
   else el.appendChild(document.createTextNode(parts[i]));}
 }
 function startIntro(){mode='intro';step=0;failed=false;coach('ti_see',true,0);}
 function coach(key,withNext,pip){
  rich($$('tcoachT'),TR(key));
  $$('tcoachOk').style.display=withNext?'':'none';
  var ps=$$('tcPips').children,i;
  for(i=0;i<ps.length;i++)ps[i].classList.toggle('on',i<=pip);
  $$('tcoach').classList.add('on');
 }
 function toStep(n){
  step=n;
  if(n===1)coach('ti_draw',false,1);
  else if(n===2)coach('ti_release',false,2);
  else if(n===6)coach('ti_adjust',false,3);
  else $$('tcoach').classList.remove('on');
 }
 function tickIntro(){
  if(S.li!==0||S.zen){hide();return;}
  if(S.mode==='success'){finishIntro();return;}
  var bp=$$('bPlay');
  if(bp)bp.classList.toggle('tpulse',step===2);
  if(step===0)return;
  if(step===1){if(S.mode!=='draw'){toStep(3);return;}if(S.strokes.length&&!S.cur)toStep(2);}
  else if(step===2){if(S.mode!=='draw'){toStep(3);return;}if(!S.strokes.length)toStep(1);}
  else if(step===3){if(S.mode==='fail')failed=true;else if(S.mode==='draw'&&failed)toStep(6);}
  else if(step===6){if(S.mode!=='draw')toStep(3);}
 }
 function finishIntro(){st.intro=true;pend=null;save();hide();}

 /* ── fiches d'élément ── */
 function openCards(ids,codex,review){
  cids=ids.slice();ci=0;fromCodex=!!codex;isRev=!!(review||codex);mode='card';showCard();
 }
 function focusOf(id,lv){
  var o=[],i,a;
  function rect(r){o.push({t:'r',x:r[0],y:r[1],w:r[2],h:r[3]});}
  function circ(x,y,r){o.push({t:'c',x:x,y:y,r:r});}
  function seg(x1,y1,x2,y2){o.push({t:'s',x1:x1,y1:y1,x2:x2,y2:y2});}
  var m={spike:2,bounce:1,boost:3,ice:4};
  if(id==='nd'||id==='wind'||id==='grav'||id==='sup'||id==='tdil'){a=lv[id]||[];for(i=0;i<a.length;i++)rect(a[i]);}
  else if(m[id]!==undefined){a=lv.w||[];for(i=0;i<a.length;i++)if(a[i][4]===m[id])seg(a[i][0],a[i][1],a[i][2],a[i][3]);}
  else if(id==='mag'){a=lv.mag||[];for(i=0;i<a.length;i++)circ(a[i][0],a[i][1],Math.min(a[i][2],60));}
  else if(id==='port'){a=lv.port||[];for(i=0;i<a.length;i++){circ(a[i][0],a[i][1],20);circ(a[i][2],a[i][3],20);}}
  else if(id==='mov'){a=lv.mov||[];for(i=0;i<a.length;i++)seg(a[i].seg[0],a[i].seg[1],a[i].seg[2],a[i].seg[3]);}
  else if(id==='ent'){a=lv.ent||[];for(i=0;i<a.length;i++){circ(a[i][0],a[i][1],22);circ(a[i][2],a[i][3],22);}
   a=lv.gate||[];for(i=0;i<a.length;i++)seg(a[i][0],a[i][1],a[i][2],a[i][3]);}
  else if(id==='det'){a=lv.det||[];for(i=0;i<a.length;i++)circ(a[i][0],a[i][1],a[i][2]);}
  else if(id==='soft')circ(lv.ball[0],lv.ball[1],24);
  return o;
 }
 function avgY(sh){var i,s=0,n=0;for(i=0;i<sh.length;i++){var q=sh[i];s+=(q.t==='r')?q.y+q.h/2:(q.t==='s'?(q.y1+q.y2)/2:q.y);n++;}return n?s/n:0;}
 function showCard(){
  var id=cids[ci],card=$$('tcard'),e=entry(id),pos='bot',k,d;
  if(!fromCodex){
   if(e.cat==='tool'||e.cat==='mat')pos='top';     /* la palette et le dock sont en bas : on les laisse visibles */
   else{var y=avgY(focusOf(id,LEVELS[S.li]));if(y>H*.5)pos='top';}}
  card.classList.remove('top','bot','swp');void card.offsetWidth;
  card.classList.add('on',pos,'swp');
  card.style.setProperty('--tc',e.col);
  $$('tshield').classList.add('on');
  $$('tk').textContent=(isRev?'':TR('tutoNew')+' · ')+TR('cat_'+e.cat);
  var dots=$$('tdots');while(dots.firstChild)dots.removeChild(dots.firstChild);
  if(cids.length>1)for(k=0;k<cids.length;k++){d=document.createElement('i');if(k===ci)d.className='on';dots.appendChild(d);}
  $$('tt').textContent=TR('tt_'+id);
  rich($$('tb'),TR('td_'+id));
  $$('tok').textContent=(ci<cids.length-1)?TR('tutoNext'):TR('tutoOk');
  $$('tskip').style.display=(ci<cids.length-1)?'':'none';
  dId=id;dT=0;dDir=[1,0];dGm=0;
  if(!fromCodex){var lv2=LEVELS[S.li],z;
   if(id==='wind'&&lv2.wind&&lv2.wind[0]){z=lv2.wind[0];var n=Math.hypot(z[4],z[5])||1;dDir=[z[4]/n,z[5]/n];}
   if(id==='grav'&&lv2.grav&&lv2.grav[0]){z=lv2.grav[0];dGm=(z[5]<0)?0:(Math.abs(z[5])<G?1:2);}}
  if(!dOn){dOn=true;requestAnimationFrame(demoLoop);}
 }
 function nextCard(){
  if(!fromCodex)st.seen[cids[ci]]=1;
  if(ci<cids.length-1){ci++;showCard();return;}
  if(!fromCodex)save();
  hide();
 }
 function skipCards(){
  var k;if(!fromCodex){for(k=ci;k<cids.length;k++)st.seen[cids[k]]=1;save();}
  hide();
 }
 function hide(){
  mode=null;fromCodex=false;isRev=false;dOn=false;
  var a=['tcard','tshield','tcoach'],i,e;
  for(i=0;i<a.length;i++){e=$$(a[i]);if(e)e.classList.remove('on');}
  e=$$('bPlay');if(e)e.classList.remove('tpulse');
  clearPulse();
 }
 function clearPulse(){
  var i,cs=document.querySelectorAll?document.querySelectorAll('#palRow .chip, #dock .dk'):[];
  for(i=0;i<cs.length;i++)cs[i].classList.remove('tpulse');
  var a=['palRow','dock'],e;for(i=0;i<a.length;i++){e=$$(a[i]);if(e)e.classList.remove('tlift');}
 }
 function pulseTarget(){ /* fait ressortir, au-dessus du voile, la puce ou l'outil dont parle la fiche */
  if(fromCodex)return;
  var id=cids[ci],e=entry(id),i,cs;
  if(e.cat==='mat'){
   var want=(id==='palB')?BOUNCEM:(id==='palA')?BOOSTM:ROPE;
   $$('palRow').classList.add('tlift');
   cs=document.querySelectorAll('#palRow .chip');
   for(i=0;i<cs.length;i++)cs[i].classList.toggle('tpulse',+cs[i].dataset.m===want);
  }else if(e.cat==='tool'){
   $$('dock').classList.add('tlift');
   cs=document.querySelectorAll('#dock .dk');
   for(i=0;i<cs.length;i++)cs[i].classList.toggle('tpulse',cs[i].getAttribute('data-m')===TOOLMODE[id]);
  }else clearPulse();
 }

 /* ── aide du niveau et explications ── */
 function help(){
  if(typeof S==='undefined')return;
  var ids=S.zen?[]:elemsOf(LEVELS[S.li]);
  if(!ids.length)ids=['basics'];
  openCards(ids,false,true);
 }
 function codexOpen(){
  var box=$$('cxList'),i,c,h='';
  function row(c){
   var ok=(c.id==='basics'||c.cat==='tool')||!!st.seen[c.id];
   return '<button class="cx'+(ok?'':' lock')+'" data-id="'+c.id+'" style="--tc:'+c.col+'"'+(ok?'':' disabled')+
    '><i></i><span>'+(ok?TR('tt_'+c.id):TR('tutoLocked'))+'</span></button>';}
  h+=row(CAT[0]);
  h+='<p class="cxh">'+TR('cx_h_tools')+'</p>';
  for(i=0;i<CAT.length;i++)if(CAT[i].cat==='tool')h+=row(CAT[i]);
  h+='<p class="cxh">'+TR('cx_h_elems')+'</p>';
  for(i=0;i<CAT.length;i++){c=CAT[i];if(c.cat==='elem'||c.cat==='mat')h+=row(c);}
  box.innerHTML=h;
  var bs=box.querySelectorAll('.cx');
  for(i=0;i<bs.length;i++)bs[i].onclick=function(){openCards([this.getAttribute('data-id')],true,true);};
  $$('vCodex').classList.add('on');
 }

 /* ── dessin sur le terrain (coordonnées du jeu) ── */
 function rr(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
 function pulse(){return (typeof OPT!=='undefined'&&OPT.rm)?.5:.5+.5*Math.sin(T0*.09);}
 function cl(v,a,b){return v<a?a:(v>b?b:v);}
 function ringShapes(c,sh,col){
  var p=pulse(),i,q;
  c.save();c.strokeStyle=col;c.fillStyle=col;c.lineWidth=2;c.lineCap='round';
  for(i=0;i<sh.length;i++){
   q=sh[i];c.globalAlpha=.4+.5*p;c.setLineDash([7,5]);
   if(q.t==='r'){rr(c,q.x-3-p*3,q.y-3-p*3,q.w+6+p*6,q.h+6+p*6,8);c.stroke();c.globalAlpha=.07;c.setLineDash([]);c.fill();}
   else if(q.t==='c'){c.beginPath();c.arc(q.x,q.y,q.r+4+p*5,0,6.2832);c.stroke();}
   else{c.setLineDash([]);c.globalAlpha=.16+.16*p;c.lineWidth=16;c.beginPath();c.moveTo(q.x1,q.y1);c.lineTo(q.x2,q.y2);c.stroke();}
  }
  c.restore();
 }
 function tag(c,x,y,tx,ty,txt,col){ /* étiquette + trait de repère vers la cible */
  c.save();
  c.font='600 10px "JetBrains Mono",ui-monospace,Menlo,Consolas,monospace';
  try{c.letterSpacing='1.3px';}catch(e){}
  var s=txt.toUpperCase(),w=c.measureText(s).width+20;
  x=cl(x,w/2+4,W-w/2-4);y=cl(y,14,H-14);
  c.strokeStyle=col;c.fillStyle=col;c.lineWidth=1.2;c.globalAlpha=.8;
  c.beginPath();c.moveTo(x,y);c.lineTo(tx,ty);c.stroke();
  c.beginPath();c.arc(tx,ty,2.6,0,6.2832);c.fill();
  c.globalAlpha=1;
  c.fillStyle='rgba(5,9,15,.95)';rr(c,x-w/2,y-10,w,20,10);c.fill();
  c.strokeStyle=col;c.lineWidth=1.2;c.stroke();
  c.fillStyle='#EAF6FF';c.textAlign='center';c.textBaseline='middle';c.fillText(s,x+.7,y+.5);
  c.restore();
 }
 function toward(cx,cy,r,x,y){var d=Math.hypot(x-cx,y-cy)||1;return [cx+(x-cx)/d*r,cy+(y-cy)/d*r];}
 function partial(pts,u){ /* polyligne tronquée à la fraction u de sa longueur */
  var tot=0,seg=[],i,d,out=[[pts[0][0],pts[0][1]]],x=pts[0][0],y=pts[0][1],f;
  for(i=1;i<pts.length;i++){seg.push(Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]));tot+=seg[i-1];}
  d=cl(u,0,1)*tot;
  for(i=1;i<pts.length;i++){
   if(d>=seg[i-1]){out.push([pts[i][0],pts[i][1]]);d-=seg[i-1];x=pts[i][0];y=pts[i][1];}
   else{f=seg[i-1]?d/seg[i-1]:0;x=pts[i-1][0]+(pts[i][0]-pts[i-1][0])*f;y=pts[i-1][1]+(pts[i][1]-pts[i-1][1])*f;out.push([x,y]);break;}}
  return {pts:out,x:x,y:y};
 }
 function drawIntro(c){
  var lv=LEVELS[0];
  if(step===0){
   var b=lv.ball,cp=lv.cup,s=lv.star,cx=cp[0]+cp[2]/2,cy=cp[1]-22,e;
   ringShapes(c,[{t:'c',x:b[0],y:b[1],r:R+6},{t:'r',x:cp[0]-2,y:cp[1]-46,w:cp[2]+4,h:50}],'#4DD7FF');
   e=toward(b[0],b[1],R+10,b[0]+70,b[1]-26);tag(c,b[0]+72,b[1]-26,e[0],e[1],TR('ti_ball'),'#4DD7FF');
   e=toward(cx,cy,30,cx,cy-72);tag(c,cx,cy-72,e[0],e[1],TR('ti_goal'),'#9BE84B');
   if(s){ringShapes(c,[{t:'c',x:s[0],y:s[1],r:14}],'#FFD85A');
    e=toward(s[0],s[1],20,s[0]+62,s[1]-34);tag(c,s[0]+62,s[1]-34,e[0],e[1],TR('ti_core'),'#FFD85A');}
  }else if(step===1&&!S.cur){
   var pts=(lv.optsol&&lv.optsol[0])||[[lv.ball[0],lv.ball[1]+90],[lv.ball[0]-30,lv.ball[1]+70]];
   var k=T0%210,u=k/130,pr=partial(pts,u>1?1:u);
   c.save();
   if(pr.pts.length>1){c.globalAlpha=.9;if(!(vx()&&vx().stroke(c,pr.pts,0,1))){c.strokeStyle='#4DD7FF';c.lineWidth=4;c.lineCap='round';c.beginPath();c.moveTo(pr.pts[0][0],pr.pts[0][1]);c.lineTo(pr.x,pr.y);c.stroke();}}
   c.globalAlpha=1;dfinger(c,pr.x,pr.y,k<14?k/14:0);
   c.restore();
  }
 }
 function draw(c){
  if(mode==='intro')drawIntro(c);
  else if(mode==='card'&&!fromCodex)ringShapes(c,focusOf(cids[ci],LEVELS[S.li]),colOf(cids[ci]));
 }

 /* ── mini-démos : le rendu est celui du jeu (VX.stroke, drawBall, drawSeg) ; les mouvements sont illustratifs,
    ce n'est pas la physique du moteur ── */
 function c01(u){return u<0?0:(u>1?1:u);}
 function lerp(a,b,u){return a+(b-a)*u;}
 function ease(u){u=c01(u);return u*u*(3-2*u);}
 function hexA(hex,a){return a>=1?hex:hex+('0'+Math.round(c01(a)*255).toString(16)).slice(-2);}
 function press(p,p0){var d=p-p0;return (d>=0&&d<.05)?d/.05:0;}
 function dball(c,x,y,tint,a,s){
  var sv=S.squash;S.squash=null;
  c.save();if(a!==undefined)c.globalAlpha=a;
  if(s){c.translate(x,y);c.scale(s[0],s[1]);x=0;y=0;}
  try{drawBall(c,x,y,T0*.03,7.5,tint);}catch(e){}
  c.restore();S.squash=sv;
 }
 function glow(c,x,y,r,col,a){var g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,hexA(col,a));g.addColorStop(1,hexA(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();}
 function trailOf(c,fn,p,n,dp,col){
  var i,q;
  for(i=n;i>=1;i--){q=fn(c01(p-i*dp));c.globalAlpha=(1-i/(n+1))*.4;c.fillStyle=col;c.beginPath();c.arc(q[0],q[1],7.5*(.3+.4*(1-i/(n+1))),0,6.2832);c.fill();}
  c.globalAlpha=1;
 }
 function neon(c,pts,mat){
  if(pts.length<2)return;
  if(vx()&&vx().stroke(c,pts,mat||0,1))return;
  var i;c.save();c.strokeStyle=T.matter;c.lineWidth=4;c.beginPath();c.moveTo(pts[0][0],pts[0][1]);
  for(i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.stroke();c.restore();
 }
 function wall(c,mat,x1,y1,x2,y2){
  if(vx()&&vx().stroke(c,[[x1,y1],[x2,y2]],mat,1))return;
  drawSeg(c,[x1,y1,x2,y2,mat],true,1);
 }
 function zone(c,x,y,w,h,col){
  var g=c.createLinearGradient(x,y,x,y+h);g.addColorStop(0,hexA(col,.16));g.addColorStop(1,hexA(col,.05));
  c.fillStyle=g;c.fillRect(x,y,w,h);
  c.save();c.strokeStyle=col;c.globalAlpha=.7;c.lineWidth=1.2;c.setLineDash([4,4]);c.lineDashOffset=-T0*.3;c.strokeRect(x+.5,y+.5,w-1,h-1);c.restore();
 }
 function cup(c,x,y,w){
  var g=c.createLinearGradient(0,y-24,0,y);g.addColorStop(0,'rgba(155,235,75,0)');g.addColorStop(1,'rgba(155,235,75,.3)');
  c.fillStyle=g;c.fillRect(x,y-24,w,24);
  c.save();c.strokeStyle='#9BEB4B';c.lineWidth=2.6;c.shadowColor='#9BEB4B';c.shadowBlur=10;
  c.beginPath();c.moveTo(x,y-20);c.lineTo(x,y);c.lineTo(x+w,y);c.lineTo(x+w,y-20);c.stroke();c.restore();
 }
 function chip(c,x,y,w,txt,col,on){
  c.save();rr(c,x,y,w,20,10);c.fillStyle=on?hexA(col,.16):'rgba(255,255,255,.03)';c.fill();
  c.strokeStyle=on?col:'rgba(255,255,255,.18)';c.lineWidth=1.2;if(on){c.shadowColor=col;c.shadowBlur=8;}c.stroke();c.shadowBlur=0;
  c.font='600 8.5px "JetBrains Mono",ui-monospace,Menlo,monospace';c.fillStyle=on?col:'#8A97A6';c.textAlign='center';c.textBaseline='middle';
  c.fillText(String(txt).toUpperCase(),x+w/2,y+10.5);c.restore();
 }
 function dpill(c,x,y,txt,col){
  c.save();c.font='600 9px "JetBrains Mono",ui-monospace,Menlo,monospace';
  var w=(c.measureText(txt).width||30)+12;
  c.fillStyle='rgba(5,9,15,.95)';rr(c,x-w/2,y-8,w,16,8);c.fill();c.strokeStyle=col;c.lineWidth=1;c.stroke();
  c.fillStyle='#EAF6FF';c.textAlign='center';c.textBaseline='middle';c.fillText(txt,x,y+.5);c.restore();
 }
 function dfinger(c,x,y,pr){ /* doigt fantôme ; pr = 0..1 : onde au moment de l'appui */
  var r=11,g;c.save();
  if(pr>0){c.globalAlpha=(1-pr)*.55;c.strokeStyle='#fff';c.lineWidth=1.5;c.beginPath();c.arc(x,y,r+pr*17,0,6.2832);c.stroke();}
  c.globalAlpha=1;g=c.createRadialGradient(x,y,0,x,y,r*1.6);
  g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(.6,'rgba(255,255,255,.16)');g.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=g;c.beginPath();c.arc(x,y,r*1.6,0,6.2832);c.fill();
  c.strokeStyle='rgba(255,255,255,.92)';c.lineWidth=1.4;c.beginPath();c.arc(x,y,r*.6,0,6.2832);c.stroke();
  c.restore();
 }
 function dsel(c,pts,hAng){ /* cadre de sélection et poignées, comme dans l'éditeur */
  var cx=(pts[0][0]+pts[1][0])/2,cy=(pts[0][1]+pts[1][1])/2,col=T.matter;
  var x0=Math.min(pts[0][0],pts[1][0])-9,y0=Math.min(pts[0][1],pts[1][1])-9,x1=Math.max(pts[0][0],pts[1][0])+9,y1=Math.max(pts[0][1],pts[1][1])+9;
  var hx=cx+Math.cos(hAng)*34,hy=cy+Math.sin(hAng)*34;
  c.save();c.strokeStyle=col;c.globalAlpha=.75;c.lineWidth=1;c.setLineDash([4,4]);rr(c,x0,y0,x1-x0,y1-y0,6);c.stroke();
  c.beginPath();c.moveTo(cx,cy);c.lineTo(hx,hy);c.globalAlpha=.5;c.stroke();c.setLineDash([]);c.globalAlpha=1;
  c.fillStyle='rgba(5,9,15,.96)';c.strokeStyle=col;c.lineWidth=1.4;c.shadowColor=col;c.shadowBlur=8;
  c.beginPath();c.arc(hx,hy,9,0,6.2832);c.fill();c.stroke();
  c.beginPath();c.arc(cx,cy,8,0,6.2832);c.fill();c.stroke();c.shadowBlur=0;
  c.strokeStyle='#EAFBFF';c.lineWidth=1.3;c.beginPath();c.arc(hx,hy,3.8,-.4,4.3);c.stroke();
  c.beginPath();c.moveTo(cx-4,cy);c.lineTo(cx+4,cy);c.moveTo(cx,cy-4);c.lineTo(cx,cy+4);c.stroke();
  c.restore();
 }
 function rot(pts,c0,a,dx,dy){var co=Math.cos(a),si=Math.sin(a),o=[],i,x,y;
  for(i=0;i<pts.length;i++){x=pts[i][0]-c0[0];y=pts[i][1]-c0[1];o.push([c0[0]+x*co-y*si+dx,c0[1]+x*si+y*co+dy]);}return o;}

 function demo(c,id,t){
  var p=(t%300)/300,i,q,x,y,u,pr,path,col=colOf(id),pk=.5+.5*Math.sin(t*.16);
  c.lineJoin='round';c.lineCap='round';
  switch(id){
  case 'basics':{
   var L0=[[44,30],[112,54]];
   cup(c,146,92,66);
   if(p<.3){pr=partial(L0,ease(p/.26));neon(c,pr.pts);if(p<.27)dfinger(c,pr.x,pr.y,press(p,0));}
   else{neon(c,L0);path=[[64,2],[78,36],[112,47],[134,60],[176,84]];
    q=c01((p-.34)/.56);pr=partial(path,q*.55+q*q*.45);dball(c,pr.x,pr.y);}
   break;}
  case 'tdraw':{
   var wave=[];for(i=0;i<=18;i++){u=i/18;wave.push([22+u*188,58+Math.sin(u*Math.PI*1.7)*20-u*10]);}
   if(p<.48){pr=partial(wave,ease(p/.44));neon(c,pr.pts);if(p<.46)dfinger(c,pr.x,pr.y,press(p,0));}
   else{neon(c,wave);pr=partial(wave,c01((p-.52)/.4));dball(c,pr.x,pr.y-9);}
   break;}
  case 'tline':{
   var A=[28,26],B=[190,72],E=[[190,72],[214,94]];
   neon(c,E);
   if(p<.5){q=ease(p/.44);var cx2=lerp(A[0],B[0],q),cy2=lerp(A[1],B[1],q);
    neon(c,[A,[cx2,cy2]]);if(p<.47)dfinger(c,cx2,cy2,press(p,0));
    dpill(c,(A[0]+cx2)/2,(A[1]+cy2)/2-14,'−12 %','#4DD7FF');
    if(q>.85){c.save();c.strokeStyle='#EAFBFF';c.lineWidth=1.6;c.beginPath();c.arc(B[0],B[1],7,0,6.2832);c.stroke();
     c.strokeStyle=T.matter;c.globalAlpha=.6;c.beginPath();c.arc(B[0],B[1],10+pk*3,0,6.2832);c.stroke();c.restore();}}
   else{neon(c,[A,B]);pr=partial([A,B],c01((p-.56)/.38));dball(c,pr.x,pr.y-8.5);}
   break;}
  case 'terase':{
   var L1=[[26,76],[104,50]],L2=[[124,38],[206,78]],mid=[165,58];
   neon(c,L1);
   if(p<.3){neon(c,L2);dfinger(c,lerp(200,mid[0],ease(p/.2)),lerp(96,mid[1],ease(p/.2)),press(p,.2));}
   else if(p<.5){neon(c,L2);c.save();c.lineCap='round';c.strokeStyle='rgba(255,82,82,.28)';c.lineWidth=13;c.beginPath();c.moveTo(L2[0][0],L2[0][1]);c.lineTo(L2[1][0],L2[1][1]);c.stroke();
    c.setLineDash([4,5]);c.lineDashOffset=-t*.6;c.strokeStyle=T.danger;c.lineWidth=2;c.stroke();c.restore();dfinger(c,mid[0],mid[1],0);}
   else if(p<.8){u=(p-.5)/.3;c.globalAlpha=1-u;neon(c,L2);c.globalAlpha=1;
    for(i=0;i<9;i++){x=lerp(L2[0][0],L2[1][0],i/8);y=lerp(L2[0][1],L2[1][1],i/8);
     c.globalAlpha=(1-u)*.8;c.fillStyle=T.danger;c.beginPath();c.arc(x+(i%3-1)*10*u,y-u*(8+(i%4)*5),1.8,0,6.2832);c.fill();}
    c.globalAlpha=1;dpill(c,mid[0],mid[1]-16-u*10,'+18 %',T.goal);}
   break;}
  case 'tmove':{
   var A0=[52,74],B0=[108,74],C0=[80,74],pts,hA=-Math.PI/2,th=0,dxy=[0,0],fx,fy,txt=null;
   if(p<.32){q=ease(p/.28);dxy=[64*q,-28*q];pts=rot([A0,B0],C0,0,dxy[0],dxy[1]);fx=C0[0]+dxy[0];fy=C0[1]+dxy[1];}
   else{dxy=[64,-28];q=ease((p-.4)/.36);th=-q*Math.PI*.22;pts=rot([A0,B0],C0,th,dxy[0],dxy[1]);hA=-Math.PI/2+th;
    fx=C0[0]+dxy[0]+Math.cos(hA)*34;fy=C0[1]+dxy[1]+Math.sin(hA)*34;if(p>.4&&p<.78)txt=Math.round(th*180/Math.PI)+'°';}
   neon(c,pts);dsel(c,pts,hA);
   if(p<.3)dfinger(c,fx,fy,press(p,0));else if(p<.8)dfinger(c,fx,fy,press(p,.38));
   if(txt)dpill(c,C0[0]+dxy[0],C0[1]+dxy[1]-40,txt,'#4DD7FF');
   break;}
  case 'nd':{
   if(vx()&&vx().nd)vx().nd(c,{nd:[[126,4,74,96]]});
   c.save();c.strokeStyle=T.danger;c.globalAlpha=.6;c.lineWidth=1.2;c.setLineDash([4,4]);c.strokeRect(126.5,4.5,73,95);c.restore();
   q=ease(p/.62);x=lerp(22,168,q);var xe=Math.min(x,124),ye=60+(xe-22)*.06;
   neon(c,[[22,60],[xe,ye]]);if(p<.7)dfinger(c,x,60+(x-22)*.06,press(p,0));
   if(x>124){c.save();c.strokeStyle=T.danger;c.lineWidth=2.2;c.globalAlpha=.6+.4*pk;
    c.beginPath();c.moveTo(121,ye-5);c.lineTo(131,ye+5);c.moveTo(131,ye-5);c.lineTo(121,ye+5);c.stroke();c.restore();}
   break;}
  case 'spike':{
   wall(c,2,46,92,186,92);
   q=c01(p/.5);
   if(p<.5)dball(c,116,lerp(6,78,q*q));
   else{u=(p-.5)/.4;c.save();c.strokeStyle=T.danger;c.globalAlpha=Math.max(0,1-u);c.lineWidth=2;c.beginPath();c.arc(116,82,6+u*26,0,6.2832);c.stroke();c.restore();
    if(u<.35)dball(c,116,78,undefined,1-u/.35);}
   break;}
  case 'bounce':{
   c.save();c.strokeStyle='rgba(255,255,255,.25)';c.setLineDash([3,4]);c.lineWidth=1;c.beginPath();c.moveTo(70,30);c.lineTo(162,30);c.stroke();c.restore();
   wall(c,1,56,94,176,94);
   if(p<.34)y=lerp(30,80,Math.pow(p/.34,2));
   else if(p<.86){u=(p-.34)/.52;y=80-72*(1-Math.pow(2*u-1,2));}
   else y=80;
   dball(c,116,y);
   break;}
  case 'boost':{
   wall(c,3,14,90,218,90);
   var fb=function(v){return [lerp(14,214,Math.pow(v,1.7)),81];};q=c01(p/.9);pr=fb(q);
   trailOf(c,fb,q,7,.028,'#A878FF');dball(c,pr[0],pr[1]);
   break;}
  case 'ice':{
   wall(c,4,14,58,218,88);
   var fi=function(v){var xx=lerp(20,210,Math.pow(v,1.35));return [xx,58+(xx-14)*.147-9];};q=c01(p/.9);pr=fi(q);
   trailOf(c,fi,q,8,.03,'#BFEAF7');dball(c,pr[0],pr[1]);
   break;}
  case 'palB':case 'palA':case 'palC':{
   var mat=(id==='palB')?1:(id==='palA')?3:5,nmk=(id==='palB')?'mat_bounce':(id==='palA')?'mat_boost':'mat_rope',cc=(id==='palB')?'#FFAA3C':(id==='palA')?'#A878FF':'#E8B98A';
   var on=p>.26;
   chip(c,16,80,64,TR('mat_structure'),'#43D5F5',!on);chip(c,88,80,64,TR(nmk),cc,on);
   if(p<.26){u=ease(p/.22);dfinger(c,lerp(150,120,u),lerp(40,90,u),press(p,.2));}
   else if(p<.7){pr=partial([[46,22],[188,42]],ease((p-.3)/.36));
    if(mat===5){c.save();c.strokeStyle=cc;c.lineWidth=3;c.shadowColor=cc;c.shadowBlur=8;c.beginPath();c.moveTo(46,22);
     c.quadraticCurveTo((46+pr.x)/2,(22+pr.y)/2+14*c01((p-.3)/.2),pr.x,pr.y);c.stroke();c.restore();}
    else if(pr.pts.length>1)neon(c,pr.pts,mat);
    if(p<.68)dfinger(c,pr.x,pr.y,press(p,.3));}
   else{if(mat===5){c.save();c.strokeStyle=cc;c.lineWidth=3;c.shadowColor=cc;c.shadowBlur=8;c.beginPath();c.moveTo(46,22);c.quadraticCurveTo(117,44,188,42);c.stroke();c.restore();}
    else neon(c,[[46,22],[188,42]],mat);}
   break;}
  case 'wind':{
   zone(c,20,12,192,80,'#A8C8E8');
   var wx=dDir[0],wy=dDir[1];
   for(i=0;i<12;i++){var sx=30+((i*53)%170),sy=20+((i*29)%64),s2=(t*.9+i*17)%70,a2=Math.sin(s2/70*Math.PI);
    c.save();c.strokeStyle='#A8C8E8';c.globalAlpha=.55*a2;c.lineWidth=1.4;c.beginPath();
    c.moveTo(sx+wx*s2,sy+wy*s2);c.lineTo(sx+wx*(s2+16),sy+wy*(s2+16));c.stroke();c.restore();}
   dball(c,lerp(70,162,ease(p))*(Math.abs(wx)>.3?1:0)+(Math.abs(wx)>.3?0:116)+wx*0,lerp(52,52,0)+wy*(ease(p)-.5)*60);
   break;}
  case 'grav':{
   zone(c,60,8,112,88,'#A878FF');
   var sg=(dGm===0)?-1:1;
   for(i=0;i<3;i++){y=(t*.5+i*30)%90;var yy=(sg>0)?8+y:96-y;c.save();c.strokeStyle='#A878FF';c.globalAlpha=.4;c.lineWidth=1.6;
    for(var k2=0;k2<3;k2++){var xx=82+k2*34;c.beginPath();c.moveTo(xx-6,yy-3*sg);c.lineTo(xx,yy+3*sg);c.lineTo(xx+6,yy-3*sg);c.stroke();}c.restore();}
   if(dGm===0)y=lerp(92,12,ease(p));else if(dGm===1)y=10+80*p*.8;else y=10+80*Math.pow(p,2.6);
   dball(c,116,y);
   break;}
  case 'mag':{
   glow(c,116,52,44,'#FF4D8D',.3);
   for(i=0;i<3;i++){u=((t*.012+i/3)%1);c.save();c.strokeStyle='#FF4D8D';c.globalAlpha=(u)*.5;c.lineWidth=1.3;c.beginPath();c.arc(116,52,46*(1-u)+6,0,6.2832);c.stroke();c.restore();}
   c.fillStyle='#FF4D8D';c.beginPath();c.arc(116,52,5,0,6.2832);c.fill();
   q=ease(p/.85);x=lerp(20,110,q)+Math.sin(q*3)*0;y=lerp(14,49,q*q)+(1-q)*20*Math.sin(q*Math.PI);
   dball(c,x,y);
   break;}
  case 'port':{
   glow(c,46,52,26,'#4DD7FF',.35);glow(c,188,52,26,'#9BEB4B',.35);
   c.save();c.lineWidth=2.6;c.strokeStyle='#4DD7FF';c.beginPath();c.ellipse(46,52,8,20,0,0,6.2832);c.stroke();
   c.strokeStyle='#9BEB4B';c.beginPath();c.ellipse(188,52,8,20,0,0,6.2832);c.stroke();c.restore();
   if(p<.4)dball(c,lerp(4,44,ease(p/.4)),52);
   else{u=(p-.4)/.45;if(u<1)dball(c,lerp(190,232,ease(u)),52);
    if(p<.5){c.save();c.strokeStyle='#9BEB4B';c.globalAlpha=1-(p-.4)/.1;c.lineWidth=2;c.beginPath();c.arc(188,52,8+(p-.4)*220,0,6.2832);c.stroke();c.restore();}}
   break;}
  case 'mov':{
   y=52+Math.sin(t*.05)*28;
   c.save();c.strokeStyle='rgba(255,255,255,.2)';c.setLineDash([3,4]);c.lineWidth=1;
   c.beginPath();c.moveTo(86,24);c.lineTo(146,24);c.moveTo(86,80);c.lineTo(146,80);c.stroke();c.restore();
   wall(c,0,86,y,146,y);
   c.save();c.strokeStyle='#43D5F5';c.globalAlpha=.6;c.lineWidth=1.6;
   c.beginPath();c.moveTo(166,40);c.lineTo(166,66);c.moveTo(161,45);c.lineTo(166,39);c.lineTo(171,45);c.moveTo(161,61);c.lineTo(166,67);c.lineTo(171,61);c.stroke();c.restore();
   break;}
  case 'ent':{
   var open=p>.26;
   c.save();c.strokeStyle='#FFD85A';c.globalAlpha=.4;c.lineWidth=1.2;c.setLineDash([3,5]);c.beginPath();c.moveTo(40,52);c.quadraticCurveTo(116,100,192,52);c.stroke();c.restore();
   if(vx()&&vx().core){vx().core(c,{star:[40,52],wd:1});vx().core(c,{star:[192,52],wd:1});}
   if(!open)wall(c,0,116,20,116,84);
   else{c.save();c.strokeStyle='#FFD85A';c.globalAlpha=.3;c.setLineDash([3,4]);c.beginPath();c.moveTo(116,20);c.lineTo(116,84);c.stroke();c.restore();}
   if(p>.24&&p<.4){c.save();c.strokeStyle='#FFD85A';c.globalAlpha=1-(p-.24)/.16;c.lineWidth=2;c.beginPath();c.arc(40,52,10+(p-.24)*160,0,6.2832);c.stroke();c.restore();}
   dball(c,lerp(6,226,ease(p/.95)*.85+p*.15),52);
   break;}
  case 'sup':{
   zone(c,70,8,52,88,'#A878FF');
   x=lerp(10,222,ease(p/.92));
   var sp=c01((x-70)/50)*17;
   dball(c,x,52+sp*(x>122?1:.4)*0+(x>70?-sp:0));
   if(x>70)dball(c,x,52+sp,'#A878FF',.62);
   break;}
  case 'det':{
   c.save();c.strokeStyle='#FFD85A';c.lineWidth=1.6;c.globalAlpha=.75;c.setLineDash([4,4]);c.lineDashOffset=-t*.3;c.beginPath();c.arc(140,52,22,0,6.2832);c.stroke();c.restore();
   glow(c,140,52,26,'#FFD85A',.18);
   x=lerp(30,214,ease(p/.9));
   dball(c,x,52);
   if(x<128)dball(c,x,52+16,'#A878FF',.6);
   else if(x<160){u=(x-128)/32;dball(c,x,52+16,'#A878FF',.6*(1-u));}
   if(x>128&&x<150){c.save();c.strokeStyle='#FFD85A';c.globalAlpha=1-(x-128)/22;c.lineWidth=2;c.beginPath();c.arc(x,52,10+(x-128),0,6.2832);c.stroke();c.restore();}
   break;}
  case 'tdil':{
   zone(c,72,10,88,84,'#4DD7FF');
   var ft=function(v){var xx=(v<.3)?lerp(8,72,v/.3):(v<.75)?lerp(72,160,(v-.3)/.45):lerp(160,226,(v-.75)/.25);return [xx,52];};
   q=c01(p/.95);pr=ft(q);trailOf(c,ft,q,10,.016,'#4DD7FF');dball(c,pr[0],pr[1]);
   c.save();c.translate(116,26);c.strokeStyle='#4DD7FF';c.globalAlpha=.7;c.lineWidth=1.4;c.beginPath();c.arc(0,0,9,0,6.2832);c.stroke();
   c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(t*.02)*6,Math.sin(t*.02)*6);c.moveTo(0,0);c.lineTo(0,-5);c.stroke();c.restore();
   break;}
  case 'soft':{
   wall(c,0,40,94,192,94);
   var yy2,sq=0;
   if(p<.4){yy2=lerp(14,84,Math.pow(p/.4,2));}
   else if(p<.55){u=(p-.4)/.15;sq=Math.sin(u*Math.PI)*.38;yy2=84+sq*7;}
   else{u=(p-.55)/.4;yy2=84-60*(1-Math.pow(2*u-1,2))*.7;}
   dball(c,116,yy2,undefined,1,[1+sq,1-sq]);
   break;}
  default:
   dball(c,116,52);
  }
 }
 function demoLoop(){
  if(!dOn)return;
  var cv2=$$('tdemo');
  if(cv2){
   if(!dCtx||dCtx.canvas!==cv2)dCtx=cv2.getContext('2d');
   var cw=cv2.clientWidth||300,chh=cv2.clientHeight||Math.round(cw*DH/DW),dpr=Math.min(2,window.devicePixelRatio||1);
   if(cv2.width!==Math.round(cw*dpr)||cv2.height!==Math.round(chh*dpr)){cv2.width=Math.round(cw*dpr);cv2.height=Math.round(chh*dpr);}
   var k=cv2.width/DW,ty=(cv2.height-DH*k)/2;
   dCtx.setTransform(k,0,0,k,0,ty);dCtx.clearRect(0,-ty/k,DW,cv2.height/k);
   demo(dCtx,dId,dT);
  }
  dT+=(typeof OPT!=='undefined'&&OPT.rm)?0:1;
  requestAnimationFrame(demoLoop);
 }

 /* ── branchement des boutons (le HTML est statique dans index.html) ── */
 function init(){
  if(typeof document==='undefined'||!$$('tcard'))return;
  $$('tok').onclick=function(){nextCard();};
  $$('tskip').onclick=function(){skipCards();};
  $$('tcoachOk').onclick=function(){if(mode==='intro'&&step===0)toStep(1);};
  $$('tcoachSkip').onclick=function(){if(mode==='intro')finishIntro();};
  var ph=$$('pHelp');if(ph)ph.onclick=function(){$$('vPause').classList.remove('on');help();};
  var sc=$$('sCodex');if(sc)sc.onclick=function(){$$('vSet').classList.remove('on');codexOpen();};
  var cc=$$('cxClose');if(cc)cc.onclick=function(){$$('vCodex').classList.remove('on');};
 }
 init();

 return {editorReady:function(){return st.intro;},state:state,load:load,reset:reset,onLoad:onLoad,tick:tick,draw:draw,help:help,codex:codexOpen,
         _cat:CAT,_elemsOf:elemsOf,_seen:function(){return st.seen;},_intro:function(){return st.intro;},
         _demo:demo,_focus:focusOf,_tools:TOOLS,_pend:function(){return pend;}};
})();
if(typeof window!=='undefined')window.TUTO=TUTO;
