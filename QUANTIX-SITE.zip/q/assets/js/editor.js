/* ══ ÉDITEUR DE LIGNES ══ (R38)
   Quatre outils sur la même surface de tracé :
     draw  — trait libre (code d'origine du moteur, inchangé)
     line  — ligne droite : glisser d'un point à l'autre, ou toucher deux points successifs ;
             accroche aux extrémités des autres traits et aux angles de 45°
     erase — gomme : toucher (ou glisser sur) une ligne l'efface et rend son énergie
     move  — déplacer / pivoter : sélectionner une ligne, la glisser, tourner avec la poignée
             ou à deux doigts ; ne coûte aucune énergie (la longueur ne change pas)
   Historique unifié pour « Annuler » : ajout, effacement, déplacement, « tout effacer ».
   Le moteur appelle EDT via des crochets gardés par window.EDT. Tout le texte visible : i18n.js (ed_*). */
var EDT=(function(){
 var mode='draw',hist=[],P={},g=null,anchor=null,sel=null,armed=[],pill=null,snap=null,guide=null;
 var hint=null,flashNd=0,T0=0,clrPending=null;
 var SNAP=13,ANG=.045,ERASE_TOL=22,PICK_TOL=24,ROT_HIT=28,ORBIT=60,MIN_LINE=10;
 hist.ref=null;

 function $$(id){return document.getElementById(id);}
 function clamp(v,a,b){return v<a?a:(v>b?b:v);}
 function cp(pts){var o=[],i;for(i=0;i<pts.length;i++)o.push([pts[i][0],pts[i][1]]);return o;}
 function rm(){return typeof OPT!=='undefined'&&OPT.rm;}
 function accent(){try{if(!S.zen&&WORLDS[L().wd-1])return WORLDS[L().wd-1].c;}catch(e){}return T.matter;}
 function buzz(n){try{Audio1.buzz(n);}catch(e){}}
 function sfx(n,v){try{Audio1.playSfx(n,v);}catch(e){}}
 function ready(){return !!S.zen||!window.TUTO||TUTO.editorReady();}

 /* ── géométrie ── */
 function segDist(px,py,x1,y1,x2,y2){
  var dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy,t=l2?clamp(((px-x1)*dx+(py-y1)*dy)/l2,0,1):0;
  return Math.hypot(px-(x1+t*dx),py-(y1+t*dy));}
 function polyDist(p,pts){
  var d=1e9,i;if(pts.length===1)return Math.hypot(p[0]-pts[0][0],p[1]-pts[0][1]);
  for(i=1;i<pts.length;i++)d=Math.min(d,segDist(p[0],p[1],pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1]));return d;}
 function nearest(p,tol){
  var best=null,bd=tol,i,d;
  for(i=S.strokes.length-1;i>=0;i--){d=polyDist(p,S.strokes[i].pts);if(d<=bd){bd=d;best=S.strokes[i];}}
  return best;}
 function center(pts){ /* centre géométrique de la ligne (pondéré par la longueur) : invariant par rotation */
  var sx=0,sy=0,sl=0,i,l;
  for(i=1;i<pts.length;i++){l=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);
   sx+=l*(pts[i][0]+pts[i-1][0])/2;sy+=l*(pts[i][1]+pts[i-1][1])/2;sl+=l;}
  return sl?[sx/sl,sy/sl]:[pts[0][0],pts[0][1]];}
 function bbox(pts,pad){
  var x0=1e9,y0=1e9,x1=-1e9,y1=-1e9,i;
  for(i=0;i<pts.length;i++){x0=Math.min(x0,pts[i][0]);y0=Math.min(y0,pts[i][1]);x1=Math.max(x1,pts[i][0]);y1=Math.max(y1,pts[i][1]);}
  return {x:x0-pad,y:y0-pad,w:x1-x0+2*pad,h:y1-y0+2*pad};}
 function endpoints(){
  var o=[],i,s;for(i=0;i<S.strokes.length;i++){s=S.strokes[i].pts;o.push(s[0]);o.push(s[s.length-1]);}
  if(g&&g.k==='move'&&sel){/* ne pas s'accrocher à soi-même */}
  return o;}
 function ptsValid(pts){
  var i,k,n,x,y,x1,y1,x2,y2,l;
  for(i=0;i<pts.length;i++){if(pts[i][0]<2||pts[i][0]>W-2||pts[i][1]<2||pts[i][1]>H-2)return false;}
  for(i=0;i<pts.length;i++){
   if(inRects(L().nd,pts[i][0],pts[i][1]))return false;
   if(i){x1=pts[i-1][0];y1=pts[i-1][1];x2=pts[i][0];y2=pts[i][1];l=Math.hypot(x2-x1,y2-y1);n=Math.ceil(l/4);
    for(k=1;k<n;k++){x=x1+(x2-x1)*k/n;y=y1+(y2-y1)*k/n;if(inRects(L().nd,x,y))return false;}}}
  return true;}
 function chordAngle(pts){var a=pts[0],b=pts[pts.length-1];return Math.atan2(b[1]-a[1],b[0]-a[0]);}
 function deg(a){var d=Math.round(a*180/Math.PI);while(d>90)d-=180;while(d<=-90)d+=180;return d;}

 /* ── historique ── */
 function refSync(){if(hist.ref!==S.strokes){hist.length=0;hist.ref=S.strokes;}}
 function rec(op){refSync();hist.push(op);if(hist.length>80)hist.shift();sync();}
 function canUndo(){return hist.ref===S.strokes&&hist.length>0;}
 function sync(){var b=$$('bUndo');if(b)b.disabled=!(S.strokes.length||canUndo());}
 function pushClear(){clrPending=S.strokes.length?{t:'clr',list:S.strokes.slice(),ink:S.ink}:null;}
 function afterClear(keep){
  hist.length=0;hist.ref=S.strokes;sel=null;anchor=null;armed=[];g=null;
  if(keep&&clrPending)hist.push(clrPending);
  clrPending=null;sync();}
 function needReset(){if(S.mode==='run'||S.mode==='fail')resetBall();}
 function undo(){
  refSync();
  var op,i,it;
  while(hist.length){
   op=hist.pop();
   if(op.t==='add'){
    i=S.strokes.indexOf(op.s);if(i<0)continue;
    S.strokes.splice(i,1);S.ink=Math.min(S.inkMax,S.ink+op.s.len);
    var pts=op.s.pts,k;
    for(k=0;k<pts.length;k+=2)spawn(pts[k][0],pts[k][1],(W-24-pts[k][0])*.012,(14-pts[k][1])*.012,36,1.6,T.matter);
   }else if(op.t==='del'){
    for(i=0;i<op.items.length;i++){it=op.items[i];S.strokes.splice(Math.min(it.idx,S.strokes.length),0,it.s);S.ink=Math.max(0,S.ink-it.s.len);}
    for(i=0;i<op.items.length;i++)ringAlong(op.items[i].s.pts,T.matter);
   }else if(op.t==='mov'){
    if(S.strokes.indexOf(op.s)<0)continue;
    op.s.pts=cp(op.before);ringAlong(op.s.pts,T.matter);
   }else if(op.t==='clr'){
    S.strokes.push.apply(S.strokes,op.list);S.ink=op.ink;
    for(i=0;i<op.list.length;i++)ringAlong(op.list[i].pts,T.matter);
   }else continue;
   sel=null;armed=[];paintEnergy();qpBuild();sfx('ui_tap');sync();needReset();return true;
  }
  sync();return false;}
 function ringAlong(pts,col){var a=pts[0],b=pts[pts.length-1];ring((a[0]+b[0])/2,(a[1]+b[1])/2,34,col,2);}

 /* ── outils : sélection, indice, dock ── */
 function active(){return mode!=='draw';}
 function setMode(m,silent){
  if(m===mode)return;
  cancel();mode=m;sel=null;anchor=null;armed=[];snap=null;guide=null;pill=null;ptr=null;
  paintDock();
  var pr=$$('palRow');if(pr)pr.classList.toggle('dim',m==='erase'||m==='move');
  var key=(m==='erase'&&!S.strokes.length)?'ed_h_erase0':(m==='move'&&!S.strokes.length)?'ed_h_move0':'ed_h_'+m;
  if(!silent){hint={txt:TR(key),t:T0};sfx('ui_tap');buzz(6);}else hint=null;
  if(window.TUTO&&TUTO.onTool)TUTO.onTool(m);}
 function cancel(){g=null;P={};}
 function paintDock(){
  var d=$$('dock');if(!d)return;
  var bs=d.querySelectorAll('.dk'),i,idx=0,ms=['draw','line','erase','move'];
  for(i=0;i<bs.length;i++){var on=bs[i].getAttribute('data-m')===mode;bs[i].classList.toggle('on',on);
   bs[i].setAttribute('aria-pressed',on?'true':'false');if(on)idx=i;}
  d.style.setProperty('--i',idx);}
 function showDock(on){
  var d=$$('dock');if(!d)return;
  var was=d.classList.contains('on');d.classList.toggle('on',!!on);
  if(was!==!!on)try{resize();}catch(e){}}
 function onLoad(){
  mode='draw';cancel();sel=null;anchor=null;armed=[];snap=null;guide=null;pill=null;hint=null;
  hist.length=0;hist.ref=S.strokes;paintDock();
  var pr=$$('palRow');if(pr)pr.classList.remove('dim');
  showDock(ready());sync();}
 function init(){
  var d=$$('dock');if(!d)return;
  var ic={draw:'pen',line:'line',erase:'rub',move:'move'},bs=d.querySelectorAll('.dk'),i;
  for(i=0;i<bs.length;i++){
   bs[i].querySelector('.dki').innerHTML=ico(ic[bs[i].getAttribute('data-m')],20);
   bs[i].onclick=function(){setMode(this.getAttribute('data-m'));};}
  paintDock();sync();}

 /* ── feedback ── */
 function nope(){
  var e=document.querySelector('.energy');if(!e)return;
  e.classList.remove('nope');void e.offsetWidth;e.classList.add('nope');buzz([8,30,8]);}
 function deny(p){ring(p[0],p[1],26,T.danger,2.4);burst(p[0],p[1],6,T.danger,1.8);flashNd=T0;buzz([10,40,10]);sfx('ui_tap',.4);}

 /* ── ligne droite ── */
 function lineConstrain(A,p){
  var q=[clamp(p[0],2,W-2),clamp(p[1],2,H-2)],info={kind:null},best=null,bd=SNAP,ends=endpoints(),i,e;
  for(i=0;i<ends.length;i++){e=ends[i];
   var d=Math.hypot(e[0]-q[0],e[1]-q[1]);
   if(d<bd&&Math.hypot(e[0]-A[0],e[1]-A[1])>MIN_LINE){bd=d;best=e;}}
  if(best){q=[best[0],best[1]];info={kind:'pt',x:best[0],y:best[1]};}
  else{
   var dx=q[0]-A[0],dy=q[1]-A[1],len=Math.hypot(dx,dy);
   if(len>26){var a=Math.atan2(dy,dx),st=Math.PI/4,t=Math.round(a/st)*st;
    if(Math.abs(a-t)<ANG){q=[A[0]+Math.cos(t)*len,A[1]+Math.sin(t)*len];info={kind:'ang',a:t};}}}
  var dx2=q[0]-A[0],dy2=q[1]-A[1],L2=Math.hypot(dx2,dy2),n=Math.max(1,Math.ceil(L2/3)),k;
  for(k=1;k<=n;k++){
   var x=A[0]+dx2*k/n,y=A[1]+dy2*k/n;
   if(inRects(L().nd,x,y)){var kk=Math.max(0,k-1);q=[A[0]+dx2*kk/n,A[1]+dy2*kk/n];info={kind:'nd',x:x,y:y};break;}}
  var ln=Math.hypot(q[0]-A[0],q[1]-A[1]),cost=S.zen?0:ln*COST[S.tool];
  if(!S.zen&&cost>S.ink){var f=S.ink/cost;q=[A[0]+(q[0]-A[0])*f,A[1]+(q[1]-A[1])*f];cost=S.ink;if(info.kind!=='nd')info={kind:'ink'};}
  return {B:q,cost:cost,info:info,len:Math.hypot(q[0]-A[0],q[1]-A[1])};}
 function snapStart(p){
  var q=[clamp(p[0],2,W-2),clamp(p[1],2,H-2)],ends=endpoints(),best=null,bd=SNAP,i,d;
  for(i=0;i<ends.length;i++){d=Math.hypot(ends[i][0]-q[0],ends[i][1]-q[1]);if(d<bd){bd=d;best=ends[i];}}
  return best?[best[0],best[1]]:q;}
 function lineDown(p,e){
  if(inRects(L().nd,p[0],p[1])){deny(p);return;}
  if(!S.zen&&S.ink<=2){nope();return;}
  var A=anchor?anchor:snapStart(p);
  g={k:'line',id:e.pointerId,A:A,fromAnchor:!!anchor,B:A,cost:0,moved:false,len:0};
  ptr=p;lineUpdate(p);}
 function lineUpdate(p){
  if(!g||g.k!=='line')return;
  var r=lineConstrain(g.A,p);
  g.B=r.B;g.cost=r.cost;g.len=r.len;g.moved=r.len>=MIN_LINE;
  snap=(r.info.kind==='pt')?r.info:null;
  guide=(r.info.kind==='ang')?{x:g.A[0],y:g.A[1],a:r.info.a}:null;
  if(r.info.kind!==g.lastKind){g.lastKind=r.info.kind;if(r.info.kind==='pt'||r.info.kind==='ang')buzz(5);if(r.info.kind==='nd')deny(g.B);}
  if(g.moved){
   var pc=S.inkMax?Math.round(g.cost/S.inkMax*100):0;
   var t=deg(chordAngle([g.A,g.B]))+'°'+(S.zen?'':'  ·  −'+pc+' %');
   if(r.info.kind==='ink')t=TR('ed_short');else if(r.info.kind==='nd')t=TR('ed_nd');
   pill={x:(g.A[0]+g.B[0])/2,y:(g.A[1]+g.B[1])/2,txt:t,col:(r.info.kind==='ink'||r.info.kind==='nd')?T.bounce:null};
  }else pill=null;}
 function commitLine(A,B,cost){
  var s={pts:[[A[0],A[1]],[B[0],B[1]]],len:cost,birth:S.tick,mat:S.tool};
  S.strokes.push(s);if(!S.zen)S.ink=Math.max(0,S.ink-cost);
  paintEnergy();rec({t:'add',s:s});if(S.tool===ROPE)qpBuild();
  sfx(S.tool===ROPE?'rope_set':'ui_tap');buzz(8);
  var n=Math.max(2,Math.round(Math.hypot(B[0]-A[0],B[1]-A[1])/26)),i;
  for(i=0;i<=n;i++)spawn(A[0]+(B[0]-A[0])*i/n,A[1]+(B[1]-A[1])*i/n,(Math.random()-.5)*.5,(Math.random()-.5)*.5,18,1.2,matCol(S.tool));}
 function lineUp(){
  if(!g||g.k!=='line')return;
  var A=g.A,B=g.B;
  if(g.moved){commitLine(A,B,g.cost);anchor=null;}
  else if(g.fromAnchor){anchor=null;sfx('ui_tap',.4);}   /* re-toucher l'ancre l'annule */
  else{anchor=A;sfx('ui_tap');buzz(6);}
  g=null;snap=null;guide=null;pill=null;ptr=null;}

 /* ── gomme ── */
 function eraseProbe(p){
  var s=nearest(p,ERASE_TOL);
  if(s&&armed.indexOf(s)<0){armed.push(s);buzz(5);sfx('ui_tap',.35);}
  var tot=0,i;for(i=0;i<armed.length;i++)tot+=armed[i].len;
  pill=armed.length&&!S.zen?{x:p[0],y:p[1]-30,txt:'+'+Math.round(tot/S.inkMax*100)+' %',col:T.goal}:null;}
 function eraseDown(p,e){g={k:'erase',id:e.pointerId,p:p};armed=[];eraseProbe(p);}
 function eraseUp(){
  if(armed.length){
   var items=[],ink=0,i,idx;
   for(i=0;i<armed.length;i++){idx=S.strokes.indexOf(armed[i]);if(idx>=0)items.push({s:armed[i],idx:idx});}
   items.sort(function(a,b){return a.idx-b.idx;});
   for(i=items.length-1;i>=0;i--){S.strokes.splice(items[i].idx,1);ink+=items[i].s.len;}
   if(!S.zen)S.ink=Math.min(S.inkMax,S.ink+ink);
   for(i=0;i<items.length;i++){
    var pts=items[i].s.pts,k;
    for(k=0;k<pts.length;k+=2)spawn(pts[k][0],pts[k][1],(Math.random()-.5)*1.4,(Math.random()-.5)*1.4-.3,30,1.5,T.danger);}
   if(items.length){rec({t:'del',items:items});paintEnergy();qpBuild();sfx('impact_ice',.5);buzz(12);needReset();}
  }
  armed=[];pill=null;g=null;}

 /* ── déplacer / pivoter ── */
 function handleAng(cen){return (cen[1]-ORBIT<20)?Math.PI/2:-Math.PI/2;}
 function handlePos(){
  var c=center(sel.s.pts),a=sel.hAng;
  return [clamp(c[0]+Math.cos(a)*ORBIT,16,W-16),clamp(c[1]+Math.sin(a)*ORBIT,16,H-16)];}
 function select(s){sel={s:s,hAng:handleAng(center(s.pts))};}
 function moveDown(p,e){
  var n=Object.keys(P).length;
  if(sel){
   var hp=handlePos();
   if(Math.hypot(p[0]-hp[0],p[1]-hp[1])<=ROT_HIT){
    needReset();var c=center(sel.s.pts);
    g={k:'rot',id:e.pointerId,c:c,th0:Math.atan2(p[1]-c[1],p[0]-c[0]),orig:cp(sel.s.pts),before:cp(sel.s.pts),moved:false,last:cp(sel.s.pts)};
    return;}
   if(polyDist(p,sel.s.pts)<=PICK_TOL||Math.hypot(p[0]-center(sel.s.pts)[0],p[1]-center(sel.s.pts)[1])<=20){
    needReset();g={k:'move',id:e.pointerId,p0:p,orig:cp(sel.s.pts),before:cp(sel.s.pts),moved:false,last:cp(sel.s.pts)};ptr=p;return;}}
  var s=nearest(p,PICK_TOL);
  if(s){select(s);sfx('ui_tap',.5);buzz(5);needReset();
   g={k:'move',id:e.pointerId,p0:p,orig:cp(s.pts),before:cp(s.pts),moved:false,last:cp(s.pts)};ptr=p;}
  else{sel=null;g=null;}}
 function startPinch(){
  var ids=Object.keys(P);if(ids.length<2||!sel)return;
  var a=P[ids[0]],b=P[ids[1]],before=(g&&g.before)?g.before:cp(sel.s.pts);
  needReset();
  g={k:'pinch',ids:[ids[0],ids[1]],m0:[(a[0]+b[0])/2,(a[1]+b[1])/2],a0:Math.atan2(b[1]-a[1],b[0]-a[0]),
     orig:cp(sel.s.pts),c0:center(sel.s.pts),before:before,moved:false,last:cp(sel.s.pts)};
  ptr=null;}
 function applyPose(pts){
  var s=sel.s;
  if(!ptsValid(pts)){flashNd=T0;return false;}
  s.pts=pts;g.last=cp(pts);g.moved=true;
  if(s.mat===ROPE)qpBuild();
  return true;}
 function xform(orig,c,ang,dx,dy){
  var co=Math.cos(ang),si=Math.sin(ang),o=[],i,x,y;
  for(i=0;i<orig.length;i++){x=orig[i][0]-c[0];y=orig[i][1]-c[1];o.push([c[0]+x*co-y*si+dx,c[1]+x*si+y*co+dy]);}
  return o;}
 function moveMove(e){
  var p=P[e.pointerId];if(!g||!sel)return;
  if(g.k==='move'&&e.pointerId===g.id){
   var dx=p[0]-g.p0[0],dy=p[1]-g.p0[1];
   if(!g.moved&&Math.hypot(dx,dy)<3)return;
   /* garder la ligne dans le terrain : on rabote le déplacement */
   var bb=bbox(g.orig,0);
   dx=clamp(dx,3-bb.x,W-3-(bb.x+bb.w));dy=clamp(dy,3-bb.y,H-3-(bb.y+bb.h));
   applyPose(xform(g.orig,[0,0],0,dx,dy));ptr=p;
  }else if(g.k==='rot'&&e.pointerId===g.id){
   var th=Math.atan2(p[1]-g.c[1],p[0]-g.c[0]),d=th-g.th0;
   while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;
   var a0=chordAngle(g.orig),tot=a0+d,step=Math.PI/12,t=Math.round(tot/step)*step;
   guide=null;
   if(Math.abs(tot-t)<.05){d=t-a0;guide={x:g.c[0],y:g.c[1],a:t};if(g.snapA!==t){g.snapA=t;buzz(5);}}else g.snapA=null;
   if(applyPose(xform(g.orig,g.c,d,0,0))){sel.hAng=th;
    pill={x:g.c[0],y:g.c[1]-ORBIT-26<8?g.c[1]+ORBIT+26:g.c[1]-ORBIT-26,txt:deg(chordAngle(sel.s.pts))+'°',col:null};}
  }else if(g.k==='pinch'){
   var a=P[g.ids[0]],b=P[g.ids[1]];if(!a||!b)return;
   var m=[(a[0]+b[0])/2,(a[1]+b[1])/2],ang=Math.atan2(b[1]-a[1],b[0]-a[0])-g.a0;
   while(ang>Math.PI)ang-=2*Math.PI;while(ang<-Math.PI)ang+=2*Math.PI;
   var a1=chordAngle(g.orig),tt=a1+ang,st=Math.PI/12,r=Math.round(tt/st)*st;
   guide=null;
   if(Math.abs(tt-r)<.05){ang=r-a1;guide={x:g.c0[0]+(m[0]-g.m0[0]),y:g.c0[1]+(m[1]-g.m0[1]),a:r};}
   var pts=xform(g.orig,g.c0,ang,m[0]-g.m0[0],m[1]-g.m0[1]);
   if(applyPose(pts))pill={x:m[0],y:m[1]-40<8?m[1]+40:m[1]-40,txt:deg(chordAngle(sel.s.pts))+'°',col:null};}}
 function moveUp(e){
  if(!g)return;
  if(g.k==='pinch'&&(String(e.pointerId)!==g.ids[0]&&String(e.pointerId)!==g.ids[1]))return;
  if((g.k==='move'||g.k==='rot')&&e.pointerId!==g.id)return;
  if(g.moved&&sel){
   rec({t:'mov',s:sel.s,before:g.before,after:cp(sel.s.pts)});
   ringAlong(sel.s.pts,accent());sfx('ui_tap');buzz(8);
   if(sel.s.mat===ROPE)qpBuild();}
  var wasPinch=g.k==='pinch';
  g=wasPinch?{k:'none'}:null;guide=null;pill=null;ptr=null;
  if(sel&&!wasPinch)sel.hAng=sel.hAng;}

 /* ── entrées (appelées par le moteur) ── */
 function pos(e){var p=pt(e);return [clamp(p[0],0,W),clamp(p[1],0,H)];}
 function down(e){
  if(S.mode==='success'||S.mode==='fail')return;
  if(e.pointerType==='mouse'&&e.button!==0)return;
  var p=pos(e);e.preventDefault();
  var had=Object.keys(P).length;
  P[e.pointerId]=p;
  try{cv.setPointerCapture(e.pointerId);}catch(x){}
  if(mode==='move'){
   if(had>=1){if(!sel){var s=nearest(p,PICK_TOL*2);if(s)select(s);}if(sel)startPinch();return;}
   moveDown(p,e);return;}
  if(had>=1)return;              /* un seul doigt pour les autres outils */
  if(mode==='line')lineDown(p,e);
  else if(mode==='erase')eraseDown(p,e);}
 function move(e){
  if(!P[e.pointerId])return;
  e.preventDefault();var p=pos(e);P[e.pointerId]=p;
  if(!g)return;
  if(mode==='line'&&g.k==='line'&&e.pointerId===g.id){ptr=p;lineUpdate(p);}
  else if(mode==='erase'&&g.k==='erase'&&e.pointerId===g.id)eraseProbe(p);
  else if(mode==='move')moveMove(e);}
 function up(e,cancelled){
  if(!P[e.pointerId])return;
  delete P[e.pointerId];
  try{cv.releasePointerCapture(e.pointerId);}catch(x){}
  if(cancelled){if(g){if(g.k==='move'||g.k==='rot'||g.k==='pinch'){if(sel)sel.s.pts=cp(g.before);if(sel&&sel.s.mat===ROPE)qpBuild();}}g=null;armed=[];pill=null;guide=null;snap=null;ptr=null;return;}
  if(!g)return;
  if(mode==='line')lineUp();
  else if(mode==='erase'&&e.pointerId===g.id)eraseUp();
  else if(mode==='move')moveUp(e);
  if(!Object.keys(P).length&&g&&g.k==='none')g=null;}

 /* ── rendu (dans le repère du jeu, appelé à la fin de scene()) ── */
 function rr(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
 function poly(c,pts){var i;c.beginPath();for(i=0;i<pts.length;i++){if(i)c.lineTo(pts[i][0],pts[i][1]);else c.moveTo(pts[i][0],pts[i][1]);}}
 function label(c,x,y,txt,col,alpha){
  c.save();c.globalAlpha=alpha===undefined?1:alpha;
  c.font='600 11.5px "Space Grotesk",Inter,system-ui,sans-serif';
  var w=c.measureText(txt).width+18;x=clamp(x,w/2+4,W-w/2-4);y=clamp(y,14,H-14);
  c.fillStyle='rgba(5,9,15,.92)';rr(c,x-w/2,y-11,w,22,11);c.fill();
  c.strokeStyle=col||accent();c.lineWidth=1.2;c.stroke();
  c.fillStyle=col||'#F1F4F6';c.textAlign='center';c.textBaseline='middle';c.fillText(txt,x,y+.5);c.restore();}
 function pulse(){return rm()?.5:.5+.5*Math.sin(T0*.12);}
 function drawSnapMarks(c,col){
  var ends=endpoints(),i,p=pulse();
  c.save();c.fillStyle=col;
  for(i=0;i<ends.length;i++){c.globalAlpha=.35+.25*p;c.beginPath();c.arc(ends[i][0],ends[i][1],3.4,0,6.2832);c.fill();}
  c.restore();}
 function drawArrowHead(c,x,y,dx,dy,s){
  c.beginPath();c.moveTo(x+dx*s,y+dy*s);c.lineTo(x-dy*s*.7-dx*s*.2,y+dx*s*.7-dy*s*.2);c.lineTo(x+dy*s*.7-dx*s*.2,y-dx*s*.7-dy*s*.2);c.closePath();c.fill();}
 function drawSel(c){
  var s=sel.s,pts=s.pts,col=accent(),cen=center(pts),bb=bbox(pts,14),p=pulse();
  c.save();c.lineCap='round';c.lineJoin='round';
  var bad=(T0-flashNd)<14;
  c.strokeStyle=bad?'rgba(255,82,82,.32)':'rgba(255,255,255,.14)';c.lineWidth=18;poly(c,pts);c.stroke();
  c.setLineDash([5,5]);c.lineDashOffset=rm()?0:-T0*.4;c.strokeStyle=bad?T.danger:col;c.globalAlpha=.75;c.lineWidth=1.2;
  rr(c,bb.x,bb.y,bb.w,bb.h,8);c.stroke();c.setLineDash([]);c.globalAlpha=1;
  /* repères d'angle du cadre */
  c.strokeStyle=bad?T.danger:col;c.lineWidth=2.2;var k=7,cx=[bb.x,bb.x+bb.w],cy=[bb.y,bb.y+bb.h],i,j;
  for(i=0;i<2;i++)for(j=0;j<2;j++){var sx=i?-1:1,sy=j?-1:1;
   c.beginPath();c.moveTo(cx[i],cy[j]+sy*k);c.lineTo(cx[i],cy[j]);c.lineTo(cx[i]+sx*k,cy[j]);c.stroke();}
  /* poignée de rotation */
  var hp=handlePos(),rotating=g&&(g.k==='rot');
  c.globalAlpha=.5;c.setLineDash([2,4]);c.strokeStyle=col;c.lineWidth=1.2;c.beginPath();c.moveTo(cen[0],cen[1]);c.lineTo(hp[0],hp[1]);c.stroke();
  if(rotating){c.beginPath();c.arc(cen[0],cen[1],ORBIT,0,6.2832);c.stroke();}
  c.setLineDash([]);c.globalAlpha=1;
  c.fillStyle='rgba(5,9,15,.94)';c.strokeStyle=col;c.lineWidth=1.8;
  c.shadowColor=col;c.shadowBlur=rotating?16:8+p*6;
  c.beginPath();c.arc(hp[0],hp[1],13,0,6.2832);c.fill();c.stroke();c.shadowBlur=0;
  c.strokeStyle='#EAFBFF';c.lineWidth=1.8;c.beginPath();c.arc(hp[0],hp[1],5.6,-Math.PI*.15,Math.PI*1.35);c.stroke();
  c.fillStyle='#EAFBFF';var ea=Math.PI*1.35,ex=hp[0]+Math.cos(ea)*5.6,ey=hp[1]+Math.sin(ea)*5.6;
  drawArrowHead(c,ex,ey,-Math.sin(ea),Math.cos(ea),4);
  /* poignée centrale */
  c.fillStyle='rgba(5,9,15,.94)';c.strokeStyle=col;c.lineWidth=1.8;c.shadowColor=col;c.shadowBlur=g&&g.k==='move'?16:8;
  c.beginPath();c.arc(cen[0],cen[1],12,0,6.2832);c.fill();c.stroke();c.shadowBlur=0;
  c.strokeStyle='#EAFBFF';c.lineWidth=1.5;c.fillStyle='#EAFBFF';
  c.beginPath();c.moveTo(cen[0]-5,cen[1]);c.lineTo(cen[0]+5,cen[1]);c.moveTo(cen[0],cen[1]-5);c.lineTo(cen[0],cen[1]+5);c.stroke();
  drawArrowHead(c,cen[0]+6,cen[1],1,0,2.6);drawArrowHead(c,cen[0]-6,cen[1],-1,0,2.6);
  drawArrowHead(c,cen[0],cen[1]+6,0,1,2.6);drawArrowHead(c,cen[0],cen[1]-6,0,-1,2.6);
  c.restore();}
 function drawNdFlash(c){
  var a=1-(T0-flashNd)/14,nd=L().nd,i;if(!nd||a<=0)return;
  c.save();c.strokeStyle=T.danger;c.lineWidth=2;c.globalAlpha=a*.8;
  for(i=0;i<nd.length;i++){rr(c,nd[i][0],nd[i][1],nd[i][2],nd[i][3],6);c.stroke();}
  c.restore();}
 function draw(c){
  T0++;
  if(mode!=='draw'&&(S.mode==='run'||S.mode==='replay')){setMode('draw',true);}
  if(mode==='draw'&&!hint)return;
  var col=accent(),i,p;
  c.save();
  if(mode==='line'){
   drawSnapMarks(c,col);
   if(guide){c.strokeStyle=col;c.globalAlpha=.4;c.lineWidth=1;c.setLineDash([6,6]);c.beginPath();
    c.moveTo(guide.x-Math.cos(guide.a)*170,guide.y-Math.sin(guide.a)*170);c.lineTo(guide.x+Math.cos(guide.a)*170,guide.y+Math.sin(guide.a)*170);c.stroke();c.setLineDash([]);c.globalAlpha=1;}
   var A=anchor||(g&&g.k==='line'?g.A:null);
   if(g&&g.k==='line'&&g.moved){
    var seg=[g.A,g.B];
    if(!(window.VX&&VX.stroke(c,seg,S.tool,1)))drawSeg(c,[g.A[0],g.A[1],g.B[0],g.B[1],S.tool],false,1);}
   if(A){p=pulse();c.strokeStyle=col;c.lineWidth=1.8;c.globalAlpha=.9;c.beginPath();c.arc(A[0],A[1],7+p*3,0,6.2832);c.stroke();
    c.fillStyle='#EAFBFF';c.globalAlpha=1;c.beginPath();c.arc(A[0],A[1],3.2,0,6.2832);c.fill();}
   if(snap){c.strokeStyle='#EAFBFF';c.lineWidth=1.8;c.beginPath();c.arc(snap.x,snap.y,9,0,6.2832);c.stroke();
    c.strokeStyle=col;c.globalAlpha=.6;c.beginPath();c.arc(snap.x,snap.y,13+pulse()*2,0,6.2832);c.stroke();c.globalAlpha=1;}
  }else if(mode==='erase'){
   for(i=0;i<armed.length;i++){
    c.lineCap='round';c.lineJoin='round';
    c.strokeStyle='rgba(255,82,82,.26)';c.lineWidth=16;poly(c,armed[i].pts);c.stroke();
    c.setLineDash([4,5]);c.lineDashOffset=rm()?0:-T0*.6;c.strokeStyle=T.danger;c.lineWidth=2.4;poly(c,armed[i].pts);c.stroke();c.setLineDash([]);}
   if(g&&g.k==='erase'){var q=P[g.id]||g.p;c.strokeStyle=T.danger;c.globalAlpha=.55;c.lineWidth=1.2;c.setLineDash([3,4]);
    c.beginPath();c.arc(q[0],q[1],ERASE_TOL,0,6.2832);c.stroke();c.setLineDash([]);c.globalAlpha=1;}
  }else if(mode==='move'){
   if(sel&&S.strokes.indexOf(sel.s)<0)sel=null;
   if(sel)drawSel(c);
   else if(S.strokes.length&&!g){ /* invitation : petites cibles sur chaque ligne */
    for(i=0;i<S.strokes.length;i++){var ce=center(S.strokes[i].pts);
     c.strokeStyle=col;c.globalAlpha=.35+.35*pulse();c.lineWidth=1.4;c.beginPath();c.arc(ce[0],ce[1],9+pulse()*2,0,6.2832);c.stroke();}
    c.globalAlpha=1;}
  }
  if(mode==='move'||mode==='line')drawNdFlash(c);
  if(pill)label(c,pill.x,pill.y,pill.txt,pill.col);
  if(hint){var age=T0-hint.t;
   if(age>170)hint=null;
   else{var a=age<10?age/10:(age>140?(170-age)/30:1);label(c,W/2,22,hint.txt,col,a);}}
  c.restore();}

 return {init:init,active:active,down:down,move:move,up:up,draw:draw,undo:undo,rec:rec,sync:sync,canUndo:canUndo,
   pushClear:pushClear,afterClear:afterClear,onLoad:onLoad,set:setMode,mode:function(){return mode;},showDock:showDock,
   /* pour les tests */
   _sel:function(){return sel;},_hist:function(){return hist;},_armed:function(){return armed;},_anchor:function(){return anchor;},
   _nearest:nearest,_ptsValid:ptsValid,_center:center};
})();
if(typeof window!=='undefined')window.EDT=EDT;
