/* ============================================================
   visuals.js — rendu R33 (direction validée sur les aperçus)
   Portée privée : un seul nom global exposé, VX (évite toute collision
   avec les identifiants courts d'engine.js — handbook §9.1).
   Règle : la surface visible d'un mur est EXACTEMENT sa ligne de collision ;
   toute la structure décorative est dessinée derrière.
   Couleurs : jetons du handbook §6 et leurs nuances uniquement.
   ============================================================ */
(function(){
'use strict';
var VW=360,VH=480;
var C={matter:[77,215,255],boost:[166,120,255],reward:[255,216,90],goal:[155,235,75],danger:[255,82,82],
       bounce:[255,170,60],white:[234,246,255],pink:[242,160,200],ember:[176,72,28]};
function rgba(c,a){return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';}
function mix(a,b,s){return [a[0]+(b[0]-a[0])*s|0,a[1]+(b[1]-a[1])*s|0,a[2]+(b[2]-a[2])*s|0];}
function rnd(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function now(){return (typeof S!=='undefined'&&S.tick)||0;}
var PAL_W={1:[C.matter,C.boost],2:[C.bounce,C.ember,C.danger,C.reward],3:[C.boost,C.matter],4:[C.white,C.matter],
  5:[C.white,C.boost],6:[C.reward,C.matter],7:[C.goal,C.matter],8:[C.boost,C.matter],9:[C.matter,C.boost],
  10:[C.pink,C.boost],11:[C.boost,C.matter,C.reward]};

/* ---------- géométrie d'un segment : normale « derrière » la surface ---------- */
function geom(s){var dx=s[2]-s[0],dy=s[3]-s[1],len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,nx=-uy,ny=ux;
 if(Math.abs(ny)<.2){nx=s[0]<VW/2?-1:1;ny=0;}else if(ny<0){nx=-nx;ny=-ny;}
 return {len:len,ux:ux,uy:uy,nx:nx,ny:ny};}

/* ============================ DÉCOR PAR NIVEAU ============================ */
var D={key:-1,neb:[],hel:[],ghost:null,dust:[],tracks:[],bubbles:[],embers:[],pal:[C.matter,C.boost],wd:1,busOn:false,
 ring:null,rays:[],flash:[],pv:null};
function veil(seed,pal,keys){var cv=document.createElement('canvas');cv.width=VW;cv.height=VH;var g=cv.getContext('2d');
 g.globalCompositeOperation='lighter';
 function blob(x,y,r,col,a){var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,a));gr.addColorStop(.55,rgba(col,a*.35));gr.addColorStop(1,rgba(col,0));g.fillStyle=gr;g.fillRect(0,0,VW,VH);}
 var i;for(i=0;i<keys.length;i++)blob(keys[i][0],keys[i][1],keys[i][2],keys[i][3],keys[i][4]);
 for(i=0;i<8;i++)blob(rnd(seed+i)*VW,rnd(seed+i*3.1)*VH,60+rnd(seed+i*7.7)*140,pal[i%pal.length],.04+rnd(seed+i*1.9)*.07);
 for(i=0;i<22;i++){var x=rnd(seed*2+i)*VW,y=rnd(seed*3+i)*VH,r=20+rnd(seed*5+i)*50,col=pal[i%pal.length];
  var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,.05));gr.addColorStop(1,rgba(col,0));
  g.save();g.translate(x,y);g.rotate(rnd(i)*3);g.scale(2.7,.35);g.translate(-x,-y);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r);g.restore();}
 return cv;}

function compose(lv){
 var seed=(lv.idx||0)*17+3,wd=lv.wd||1,pal=PAL_W[wd]||PAL_W[1],i,k,s;D.wd=wd;D.pal=pal;D.key=lv.idx;
 var z=lv.zone||[0,0,1,1];
 var sx=0,sy=0;for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];var dx=s[2]-s[0],dy=s[3]-s[1],a=Math.atan2(dy,dx)*2,l=Math.hypot(dx,dy);sx+=Math.cos(a)*l;sy+=Math.sin(a)*l;}
 var dom=(sx||sy)?Math.atan2(sy,sx)/2:Math.PI/2;
 var occ=[];for(i=0;i<lv.walls.length;i++){s=lv.walls[i];var n=Math.ceil(Math.hypot(s[2]-s[0],s[3]-s[1])/8);for(k=0;k<=n;k++)occ.push([s[0]+(s[2]-s[0])*k/n,s[1]+(s[3]-s[1])*k/n]);}
 for(var x=z[0];x<=z[0]+z[2];x+=10)for(var y=z[1];y<=z[1]+z[3];y+=12)occ.push([x,y]);
 if(lv.star)occ.push(lv.star);for(y=lv.ball[1]-10;y<lv.ball[1]+140;y+=10)occ.push([lv.ball[0],y]);
 function far(x,y){var m=1e9;for(var j=0;j<occ.length;j++){var d=(occ[j][0]-x)*(occ[j][0]-x)+(occ[j][1]-y)*(occ[j][1]-y);if(d<m)m=d;}return Math.sqrt(m);}
 D.hel=[];
 if(wd!==2&&wd!==4)for(var h=0;h<3;h++){var best=null;
  for(k=0;k<300;k++){var cx=20+rnd(seed+h*991+k)*320,cy=50+rnd(seed+h*577+k*1.3)*410;
   var ang=dom+[0,0,.3,-.3,Math.PI/2][Math.floor(rnd(seed+k*2.2)*5)],len=110+rnd(seed+k*3.7)*150;
   var x0=cx-Math.cos(ang)*len/2,y0=cy-Math.sin(ang)*len/2,x1=cx+Math.cos(ang)*len/2,y1=cy+Math.sin(ang)*len/2,clear=1e9;
   for(var q=0;q<=10;q++){var px=x0+(x1-x0)*q/10,py=y0+(y1-y0)*q/10;if(px<-40||px>VW+40||py<-40||py>VH+40){clear=0;break;}clear=Math.min(clear,far(px,py));}
   if(clear<30)continue;var sc=len*Math.min(clear,60);if(!best||sc>best.sc)best={x0:x0,y0:y0,x1:x1,y1:y1,sc:sc,clear:clear};}
  if(!best)break;
  D.hel.push({x0:best.x0,y0:best.y0,x1:best.x1,y1:best.y1,amp:Math.min(12,best.clear-16),turns:1.4+Math.hypot(best.x1-best.x0,best.y1-best.y0)/90,
   sp:(h%2?-1:1)*(.022+rnd(seed+h)*.014),a:pal[h%pal.length],b:pal[(h+1)%pal.length],al:.55-h*.1});
  for(q=0;q<=10;q++)occ.push([best.x0+(best.x1-best.x0)*q/10,best.y0+(best.y1-best.y0)*q/10]);}
 D.ghost=(wd!==2&&wd!==4)?{x0:180-Math.cos(dom)*260,y0:240-Math.sin(dom)*260,x1:180+Math.cos(dom)*260,y1:240+Math.sin(dom)*260}:null;
 var keys=[[lv.ball[0],lv.ball[1],110,pal[0],.13],[z[0]+z[2]/2,z[1]+24,120,C.goal,.10]];
 if(wd===2)for(i=0;i<lv.walls.length;i++){s=lv.walls[i];if(s[4]===1)keys.push([(s[0]+s[2])/2,(s[1]+s[3])/2+10,90,C.bounce,.16]);}
 D.neb=[veil(seed,pal,keys),veil(seed+31,pal.slice().reverse(),[])];
 D.dust=[];for(i=0;i<(wd===2?90:150);i++){var zz=.25+rnd(seed+i*2.3)*.75;
  D.dust.push({x:rnd(seed+i)*VW,y:rnd(seed+i*1.7)*VH,z:zz,ph:rnd(i*4.1)*6.28,vx:Math.cos(dom)*(.06+rnd(seed+i*6.1)*.12),vy:(wd===2?-.3-zz*.5:(Math.abs(Math.sin(dom))+.15)*.06),
   col:wd===2?(zz>.7?C.reward:C.bounce):[C.white,C.white,C.white].concat(pal)[i%(3+pal.length)]});}
 D.ring=null;D.rays=[];D.flash=[];D.pv=null;
 if(wd===3){/* anneau de stockage : 2 lignes droites + 2 arcs, aimants de courbure, cavité RF, lignes de lumière tangentes */
  var rx=172,ry=112,cx0=180,cy0=250,rr=ry,sl=rx-rr,mags=[],k2;
  for(k2=0;k2<6;k2++){var side=k2<3?1:-1,ang2=(k2%3-1)*.75;mags.push({side:side,ang:ang2});}
  D.ring={cx:cx0,cy:cy0,r:rr,sl:sl,mags:mags,bunches:[0,.25,.5,.75],cav:.08};
  D.hel=[];D.ghost=null;}
 D.tracks=[];D.bubbles=[];if(wd===2)for(i=0;i<50;i++)D.bubbles.push({x:rnd(seed+i)*VW,y:rnd(seed+i*2.2)*VH,r:.6+rnd(seed+i*3.3)*1.8,sp:.15+rnd(seed+i*4.4)*.35,ph:rnd(i)*6.28});
}
function spawnTrack(x,y,ang,sp,strong){D.tracks.push({pts:[[x,y]],x:x,y:y,a:ang,v:sp,q:Math.random()<.5?-1:1,k:.018+Math.random()*.03,age:0,life:strong?260:190,col:strong?C.reward:(Math.random()<.5?C.bounce:C.white)});}

function ringAt(R,u){var L1=2*R.sl,La=Math.PI*R.r,P=2*L1+2*La,d=((u%1)+1)%1*P,x,y,tx,ty;
 if(d<L1){x=R.cx-R.sl+d;y=R.cy-R.r;tx=1;ty=0;}
 else if(d<L1+La){var a=-Math.PI/2+(d-L1)/R.r;x=R.cx+R.sl+Math.cos(a)*R.r;y=R.cy+Math.sin(a)*R.r;tx=-Math.sin(a);ty=Math.cos(a);}
 else if(d<2*L1+La){x=R.cx+R.sl-(d-L1-La);y=R.cy+R.r;tx=-1;ty=0;}
 else{var a2=Math.PI/2+(d-2*L1-La)/R.r;x=R.cx-R.sl+Math.cos(a2)*R.r;y=R.cy+Math.sin(a2)*R.r;tx=-Math.sin(a2);ty=Math.cos(a2);}
 return {x:x,y:y,tx:tx,ty:ty};}
function magAt(R,m){var a=m.ang;if(m.side>0)return {x:R.cx+R.sl+Math.cos(a)*R.r,y:R.cy+Math.sin(a)*R.r,tx:-Math.sin(a),ty:Math.cos(a)};
 return {x:R.cx-R.sl-Math.cos(a)*R.r,y:R.cy-Math.sin(a)*R.r,tx:Math.sin(a),ty:-Math.cos(a)};}
function drawRing(c){var R=D.ring,t=now(),i,k;c.save();c.globalCompositeOperation='lighter';
 // tube de l'anneau
 c.strokeStyle=rgba(C.boost,.08);c.lineWidth=7;c.beginPath();for(k=0;k<=120;k++){var q=ringAt(R,k/120);if(k)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.stroke();
 c.strokeStyle=rgba(C.boost,.2);c.lineWidth=1;c.stroke();
 // lignes de lumière tangentes (éventail synchrotron) depuis chaque aimant de courbure, parcourues d'impulsions
 for(i=0;i<R.mags.length;i++){var m=magAt(R,R.mags[i]),L=260;
  var gr=c.createLinearGradient(m.x,m.y,m.x+m.tx*L,m.y+m.ty*L);gr.addColorStop(0,rgba(C.matter,.22));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=1.2;c.beginPath();c.moveTo(m.x,m.y);c.lineTo(m.x+m.tx*L,m.y+m.ty*L);c.stroke();
  var pp=((t*1.6+i*37)%L);c.fillStyle=rgba(C.white,.55*(1-pp/L));c.fillRect(m.x+m.tx*pp-1.5,m.y+m.ty*pp-1.5,3,3);
  c.save();c.translate(m.x,m.y);c.rotate(Math.atan2(m.ty,m.tx));c.fillStyle=rgba(C.boost,.3);c.fillRect(-7,-4,14,8);c.strokeStyle=rgba(C.white,.2);c.lineWidth=.8;c.strokeRect(-7,-4,14,8);c.restore();}
 // cavité RF de l'anneau (chaîne de bulbes sur la ligne droite du haut)
 for(k=0;k<5;k++){var cq=ringAt(R,R.cav+k*.012);c.strokeStyle=rgba(C.reward,.35);c.lineWidth=1;c.beginPath();c.ellipse(cq.x,cq.y,4.5,6.5,0,0,6.2832);c.stroke();}
 // paquets de particules : vitesse FIXE (la cavité maintient l'énergie), flash au passage de la cavité
 for(i=0;i<R.bunches.length;i++){var u=(R.bunches[i]+t*.0022)%1,b=ringAt(R,u),inCav=u>R.cav-.01&&u<R.cav+.07;
  for(k=0;k<7;k++){var bk=ringAt(R,u-k*.004);c.fillStyle=rgba(k?C.boost:C.white,(inCav?.9:.5)*(1-k/7));c.beginPath();c.arc(bk.x,bk.y,k?1.4:2.2,0,6.2832);c.fill();}
  if(inCav){var g3=c.createRadialGradient(b.x,b.y,0,b.x,b.y,12);g3.addColorStop(0,rgba(C.reward,.5));g3.addColorStop(1,rgba(C.reward,0));c.fillStyle=g3;c.fillRect(b.x-12,b.y-12,24,24);}}
 c.restore();}
/* lumière synchrotron de la balle : quand elle tourne vite, un rayon part en tangente */
function synchro(c){var b=(typeof S!=='undefined'&&S.ball)?S.ball:null,t=now(),i;if(!b)return;
 var sp=Math.hypot(b.vx,b.vy),ang=Math.atan2(b.vy,b.vx);
 if(D.pv&&sp>3.5&&typeof S!=='undefined'&&S.mode==='run'){var da=Math.abs(((ang-D.pv.a+Math.PI*3)%(Math.PI*2))-Math.PI);
  if(da*sp>.22&&D.rays.length<18)D.rays.push({x:b.x,y:b.y,a:D.pv.a,l:55+sp*11,life:1,w:Math.max(1.6,Math.min(3.5,da*sp*1.4))});}
 D.pv={a:ang};
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.rays.length;i++){var r=D.rays[i],ex=r.x+Math.cos(r.a)*r.l,ey=r.y+Math.sin(r.a)*r.l,gr=c.createLinearGradient(r.x,r.y,ex,ey);
  gr.addColorStop(0,rgba(C.white,.95*r.life));gr.addColorStop(.3,rgba(C.boost,.6*r.life));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=r.w;c.lineCap='round';c.beginPath();c.moveTo(r.x,r.y);c.lineTo(ex,ey);c.stroke();r.life-=.03;}
 D.rays=D.rays.filter(function(q){return q.life>0;});
 for(i=0;i<D.flash.length;i++)D.flash[i].life-=.05;D.flash=D.flash.filter(function(q){return q.life>0;});
 c.restore();}
function helix(c,x0,y0,x1,y1,amp,turns,sp,cA,cB,al,N){
 var t=now(),dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len,pts=[],i;N=N||56;
 for(i=0;i<=N;i++){var s=i/N,ang=s*turns*6.2832+t*sp,bx=x0+dx*s,by=y0+dy*s,o=Math.sin(ang)*amp;
  pts.push({s:s,ang:ang,a:[bx+nx*o,by+ny*o],b:[bx-nx*o,by-ny*o],da:Math.cos(ang),db:-Math.cos(ang)});}
 function fade(s){return Math.min(1,s*6,(1-s)*6);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<=N;i+=3){var p=pts[i],f=(.35+.65*Math.abs(Math.sin(p.ang)))*fade(p.s);c.strokeStyle=rgba(mix(cA,cB,p.s),al*.45*f);c.lineWidth=1;
  c.beginPath();c.moveTo(p.a[0],p.a[1]);c.lineTo(p.b[0],p.b[1]);c.stroke();}
 var keys=['a','b'];for(var kk=0;kk<2;kk++){var key=keys[kk],dk=key==='a'?'da':'db';
  for(i=1;i<=N;i++){p=pts[i];var q=pts[i-1],d=(p[dk]+1)/2,col=mix(cA,cB,p.s),ff=fade(p.s);
   c.strokeStyle=rgba(col,al*(.08+.18*d)*ff);c.lineWidth=4+d*4;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();
   c.strokeStyle=rgba(col,al*(.25+.75*d)*ff);c.lineWidth=.8+d*1.6;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();}}
 c.restore();}

/* ============================ VOILES DE POINTS (R38) ============================
   Plusieurs couches translucides de nuages de points en rotation 3D, superposées : la transparence
   cumulée donne la profondeur (références : vidéos d'illusions bistables). Une volumétrie par monde ;
   le monde 4 y ajoute les franges de deux sources (fentes de Young), un réseau de tourbillons et un
   condensat qui se contracte en pic. Tout est calculé point par point, sans image. */
var VL={wd:-1,layers:[]};
function vlShape(kind,n,seed){
 var out=[],i,x,y,z,r,a,th,ph,q,GA=2.39996323;
 if(kind==='globe'){ /* six grands cercles d'orientations différentes : un globe fait de fils de points */
  var m=Math.round(n/6),ci,cj,u,ax,ay,az,px,py,pz,ca,sa;
  for(ci=0;ci<6;ci++){ax=ci*1.0472;ay=(ci%3)*.9+.3;
   for(cj=0;cj<m;cj++){u=cj/m*6.2832;px=Math.cos(u);py=Math.sin(u);pz=0;
    ca=Math.cos(ax);sa=Math.sin(ax);var y2=py*ca-pz*sa,z2=py*sa+pz*ca;
    ca=Math.cos(ay);sa=Math.sin(ay);out.push([px*ca+z2*sa,y2,-px*sa+z2*ca]);}}
  out.ring=m;return out;}
 for(i=0;i<n;i++){
  if(kind==='torus'){th=rnd(seed+i*1.7)*6.2832;ph=rnd(seed+i*2.9+5)*6.2832;
   x=(1+.34*Math.cos(ph))*Math.cos(th);y=(1+.34*Math.cos(ph))*Math.sin(th);z=.34*Math.sin(ph);out.push([x*.72,y*.72,z*.72]);continue;}
  z=1-2*(i+.5)/n;r=Math.sqrt(1-z*z);a=i*GA;x=Math.cos(a)*r;y=Math.sin(a)*r;
  if(kind==='tetra'){q=1+1.5*x*y*z;x*=q;y*=q;z*=q;}
  else if(kind==='shell2'){q=(i%2)?1:.62;x*=q;y*=q;z*=q;}
  out.push([x,y,z]);}
 return out;}
function vlBuild(wd){
 var L=VL.layers=[],pal=PAL_W[wd]||PAL_W[1],A=pal[0],B=pal[1]||pal[0];
 var kinds={1:['globe','globe','shell2'],2:['tetra','tetra','tetra'],3:['torus','torus','torus'],4:['globe','shell2','globe']}[wd]||['globe','shell2','globe'];
 var defs=[[.76,.28,190,.30,.0026,300],[.16,.72,74,.40,-.0046,420],[.60,.90,34,.5,.0067,240]];
 for(var i=0;i<defs.length;i++){var d=defs[i];
  L.push({pts:vlShape(kinds[i],d[5],wd*31+i*7),cx:d[0]*VW,cy:d[1]*VH,R:d[2],a:d[3],sp:d[4],ph:i*1.7,c1:i%2?B:A,c2:i%2?A:B,tilt:.5+i*.35});}
 VL.wd=wd;}
function vlDrawLayer(c,l,t,sc,alphaMul){
 var ry=t*l.sp+l.ph,rx=l.tilt+Math.sin(t*.0021+l.ph)*.25,cy_=Math.cos(ry),sy=Math.sin(ry),cx_=Math.cos(rx),sx=Math.sin(rx),i,p,x,y,z,x1,z1,y1,z2,pr,al,s;
 if(l.pts.ring){ /* fils : chaque grand cercle est tracé en trait fin, face avant plus lumineuse que la face arrière */
  var m=l.pts.ring,rg,k,q,pp,xx,yy,zz,px_,py_,fr,last;
  c.lineWidth=.8;c.lineJoin='round';
  for(var ps=0;ps<2;ps++){
   c.strokeStyle=rgba(ps?l.c1:l.c2,1);c.globalAlpha=Math.min(1,l.a*alphaMul*(ps?1.5:.8));c.beginPath();
   for(rg=0;rg<6;rg++){last=false;
    for(k=0;k<=m;k++){q=l.pts[rg*m+(k%m)];xx=q[0]*sc;yy=q[1]*sc;zz=q[2]*sc;
     x1=xx*cy_+zz*sy;z1=-xx*sy+zz*cy_;y1=yy*cx_-z1*sx;z2=yy*sx+z1*cx_;
     fr=(z2>0)===(ps===1);
     if(fr){pr=1/(1-z2*.22);px_=l.cx+x1*l.R*pr;py_=l.cy+y1*l.R*pr;if(last)c.lineTo(px_,py_);else c.moveTo(px_,py_);last=true;}else last=false;}}
   c.stroke();}
  return;}
 for(var pass=0;pass<2;pass++){
  c.fillStyle=rgba(pass?l.c1:l.c2,1);
  for(i=0;i<l.pts.length;i++){
   p=l.pts[i];x=p[0]*sc;y=p[1]*sc;z=p[2]*sc;
   x1=x*cy_+z*sy;z1=-x*sy+z*cy_;y1=y*cx_-z1*sx;z2=y*sx+z1*cx_;
   if((z2>0)!==(pass===1))continue;
   pr=1/(1-z2*.22);al=l.a*alphaMul*(.35+.65*(z2+1.3)/2.3);
   s=(1.15+.85*pr)*(z2>0?1.2:.9);
   c.globalAlpha=al;c.fillRect(l.cx+x1*l.R*pr-s/2,l.cy+y1*l.R*pr-s/2,s,s);}}
}
function vlYoung(c,t){
 var src=[[VW*.28,VH*.06],[VW*.72,VH*.06]],k,j,r,al;
 c.save();c.lineWidth=.9;c.setLineDash([1.2,5.5]);
 for(j=0;j<2;j++){
  c.strokeStyle=rgba(j?C.matter:C.white,1);
  for(k=0;k<15;k++){r=(k*17+t*.32)%255;al=(1-r/255)*.42*Math.min(1,r/14);
   if(al<=.004)continue;c.globalAlpha=al;c.beginPath();c.arc(src[j][0],src[j][1],r,.15,Math.PI-.15);c.stroke();}}
 c.restore();}
function vlVortices(c,t){
 var cs=[[.30,.42,1.5],[.66,.32,.7],[.80,.62,1.05],[.18,.80,.6],[.56,.88,.85]],i,k,a,rr,n=16;
 c.save();
 for(i=0;i<cs.length;i++){
  var x0=cs[i][0]*VW,y0=cs[i][1]*VH,dir=(i%2)?-1:1,sp=t*.011*dir/(cs[i][2]*.8)+i,sz=cs[i][2];
  for(k=0;k<n*3;k++){
   var arm=k%3,u=(k/3|0)/n;a=sp+arm*2.0944+u*3.6*dir;rr=(3+u*22)*sz;
   c.globalAlpha=.4*(1-u*.8);c.fillStyle=rgba(u<.5?C.white:C.matter,1);
   c.fillRect(x0+Math.cos(a)*rr-.6,y0+Math.sin(a)*rr*.86-.6,1.5,1.5);}}
 c.restore();}
function vlCondensate(c,t){
 var ph=.5+.5*Math.sin(t*.0105),x=VW*.80,y=VH*.14,g;
 c.save();
 g=c.createRadialGradient(x,y,0,x,y,44+22*(1-ph));
 g.addColorStop(0,rgba(C.white,.05+.34*ph));g.addColorStop(.35,rgba(C.matter,.05+.13*ph));g.addColorStop(1,rgba(C.matter,0));
 c.fillStyle=g;c.fillRect(x-70,y-70,140,140);
 for(var k=0;k<46;k++){var a=k*2.39996+t*.004,r=(6+ (k*7)%44)*(1-.5*ph*(1-k/60));
  c.globalAlpha=.16+.3*ph*(1-k/60);c.fillStyle=rgba(C.white,1);c.fillRect(x+Math.cos(a)*r-.5,y+Math.sin(a)*r*.8-.5,1.2,1.2);}
 c.restore();}
function veils(c){
 if(VL.wd!==D.wd)vlBuild(D.wd);
 var t=now(),i,cond=(D.wd===4),mul=cond?1.15:1;
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<VL.layers.length;i++){
  var sc=1;if(cond&&i===0)sc=1-.16*(.5+.5*Math.sin(t*.0105));   /* le condensat respire : le nuage se resserre */
  vlDrawLayer(c,VL.layers[i],t,sc,mul);}
 if(cond){vlYoung(c,t);vlVortices(c,t);vlCondensate(c,t);}
 c.globalAlpha=1;c.restore();}

function back(c,lv){
 if(!D.busOn&&typeof BUS!=='undefined'){D.busOn=true;
  BUS.on('ball.bounce',function(e){if(D.wd===2&&e.v>1.5)spawnTrack(e.x,e.y,Math.atan2(-e.ny,-e.nx)+Math.PI,3+e.v*.15,true);});
  BUS.on('ball.boost',function(e){D.flash.push({x:e.x,y:e.y,life:1});});}
 if(D.key!==lv.idx)compose(lv);
 var t=now(),i,b=(typeof S!=='undefined'&&S.ball)?S.ball:{x:-99,y:-99};
 c.save();c.globalCompositeOperation='screen';
 c.globalAlpha=.8+.18*Math.sin(t*.012);c.drawImage(D.neb[0],Math.sin(t*.0022)*12-8,Math.cos(t*.0017)*9-6,VW+16,VH+12);
 c.globalAlpha=.5+.2*Math.sin(t*.009+1.3);c.drawImage(D.neb[1],-Math.sin(t*.0015)*16-12,Math.sin(t*.0021)*11-10,VW+24,VH+20);c.restore();
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.dust.length;i++){var d=D.dust[i];d.x+=d.vx*d.z;d.y+=d.vy*d.z;
  var dx=d.x-b.x,dy=d.y-b.y,dd=dx*dx+dy*dy;if(dd<1600&&dd>1){var r=Math.sqrt(dd),f=(1-r/40)*.9*d.z;d.x+=dx/r*f;d.y+=dy/r*f;}
  if(d.y<-4)d.y=VH+4;if(d.y>VH+4)d.y=-4;if(d.x<-4)d.x=VW+4;if(d.x>VW+4)d.x=-4;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),a=(.12+.5*d.z)*tw,sz=.5+d.z*1.3;c.fillStyle=rgba(d.col,a);c.fillRect(d.x-sz/2,d.y-sz/2,sz,sz);}
 c.restore();
 veils(c);
 if(D.wd===3){drawRing(c);synchro(c);}
 else if(D.wd===2){
  if(t%70===0){var side=Math.floor(rnd(t)*3),x=side===0?-5:side===1?VW+5:rnd(t*1.7)*VW,y=side===2?VH+5:VH*.3+rnd(t*2.3)*VH*.6;
   spawnTrack(x,y,Math.atan2(VH*.5-y,VW*.5-x)+(rnd(t*3)-.5),2.2+rnd(t*4)*1.6,false);}
  c.save();c.globalCompositeOperation='lighter';
  for(i=0;i<D.tracks.length;i++){var tr=D.tracks[i];tr.age++;
   if(tr.v>.25){tr.a+=tr.q*tr.k*(3/tr.v);tr.v*=.985;tr.x+=Math.cos(tr.a)*tr.v;tr.y+=Math.sin(tr.a)*tr.v;if(tr.age%2===0)tr.pts.push([tr.x,tr.y]);if(tr.pts.length>140)tr.pts.shift();}
   var fd=Math.min(1,(tr.life-tr.age)/60)*Math.min(1,tr.age/6);
   for(var k=0;k<tr.pts.length;k++){c.fillStyle=rgba(tr.col,fd*(.25+.65*k/tr.pts.length)*.8);c.beginPath();c.arc(tr.pts[k][0],tr.pts[k][1],.7+(k%3===0?.6:0),0,6.2832);c.fill();}}
  D.tracks=D.tracks.filter(function(q){return q.age<q.life;});
  for(i=0;i<D.bubbles.length;i++){var bb=D.bubbles[i];bb.y-=bb.sp;bb.x+=Math.sin(t*.04+bb.ph)*.25;if(bb.y<-5){bb.y=VH+5;bb.x=rnd(t+bb.ph*99)*VW;}
   c.strokeStyle=rgba(C.white,.2);c.lineWidth=.7;c.beginPath();c.arc(bb.x,bb.y,bb.r,0,6.2832);c.stroke();}
  c.restore();
 }else{
  if(D.ghost)helix(c,D.ghost.x0,D.ghost.y0,D.ghost.x1,D.ghost.y1,30,2,.011,D.pal[0],D.pal[D.pal.length-1],.14,80);
  for(i=0;i<D.hel.length;i++){var h=D.hel[i];helix(c,h.x0,h.y0,h.x1,h.y1,h.amp,h.turns,h.sp,h.a,h.b,h.al);}
 }
}

/* ============================ ZONES INTERDITES ============================ */
function nd(c,lv){var t=now();for(var i=0;i<lv.nd.length;i++){var r=lv.nd[i];
 c.save();c.beginPath();c.rect(r[0],r[1],r[2],r[3]);c.clip();var br=.5+.5*Math.sin(t*.03+i);var gz=c.createLinearGradient(r[0],r[1],r[0]+r[2],r[1]+r[3]);gz.addColorStop(0,'rgba(150,166,184,.20)');gz.addColorStop(1,'rgba(110,124,142,.13)');c.fillStyle=gz;c.fillRect(r[0],r[1],r[2],r[3]);
 c.strokeStyle='rgba(206,224,238,'+(.38+.10*br).toFixed(3)+')';c.lineWidth=1.8;var o=(t*.35)%14;c.beginPath();
 for(var k=-520;k<520;k+=14){c.moveTo(r[0]+k+o,r[1]);c.lineTo(r[0]+k+o+520,r[1]+520);}c.stroke();c.restore();
 c.save();c.strokeStyle='rgba(206,224,238,.5)';c.lineWidth=1.2;c.setLineDash([2,5]);c.strokeRect(r[0]+2.5,r[1]+2.5,r[2]-5,r[3]-5);c.setLineDash([]);c.restore();
 c.save();c.strokeStyle='rgba(214,230,242,.9)';c.lineWidth=2;var cc=12,cs=[[r[0],r[1],1,1],[r[0]+r[2],r[1],-1,1],[r[0],r[1]+r[3],1,-1],[r[0]+r[2],r[1]+r[3],-1,-1]];
 for(k=0;k<4;k++){var q=cs[k];if(q[0]<=0||q[0]>=VW||q[1]<=0||q[1]>=VH)continue;c.beginPath();c.moveTo(q[0]+q[2]*cc,q[1]);c.lineTo(q[0],q[1]);c.lineTo(q[0],q[1]+q[3]*cc);c.stroke();}
 c.restore();}}

/* ============================ STRUCTURES ============================ */
function beam(c,s,accent){var g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,'#3A5068');gr.addColorStop(1,'#18222E');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.strokeStyle='rgba(169,200,232,.95)';c.lineWidth=1.4;c.beginPath();var ns=Math.max(2,Math.round(g.len/13));
 for(var i=0;i<=ns;i++){q=i/ns*g.len;var off=(i%2?Dp-2.5:2.5),x=A[0]+g.ux*q+g.nx*off,y=A[1]+g.uy*q+g.ny*off;if(i)c.lineTo(x,y);else c.moveTo(x,y);}c.stroke();
 c.strokeStyle='rgba(191,212,228,.8)';c.beginPath();c.moveTo(A2[0]-g.nx*1.5,A2[1]-g.ny*1.5);c.lineTo(B2[0]-g.nx*1.5,B2[1]-g.ny*1.5);c.stroke();
 c.fillStyle='#9FB3C4';for(q=10;q<g.len-6;q+=34){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.5,A[1]+g.uy*q+g.ny*Dp*.5,1.5,0,6.2832);c.fill();}
 c.lineCap='round';c.strokeStyle=accent||'#A9C3D6';c.lineWidth=3.4;c.shadowColor=accent||'rgba(169,195,214,.6)';c.shadowBlur=accent?10:5;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle='rgba(241,244,246,.75)';c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function plate(c,s){var t=now(),g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],heat=.6+.4*Math.sin(t*.05+s[0]*.02),q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,rgba(C.bounce,.9));gr.addColorStop(.35,'#6A2C12');gr.addColorStop(1,'#1A0C08');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.save();c.clip();c.strokeStyle=rgba(C.bounce,.28*heat);c.lineWidth=2;
 for(q=((t*.4)%14)-14;q<g.len+14;q+=14){var x=A[0]+g.ux*q,y=A[1]+g.uy*q;c.beginPath();c.moveTo(x,y);c.lineTo(x+g.nx*Dp+g.ux*5,y+g.ny*Dp+g.uy*5);c.stroke();}c.restore();
 c.fillStyle=rgba(C.reward,.9);for(q=10;q<g.len-6;q+=30){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.6,A[1]+g.uy*q+g.ny*Dp*.6,1.6,0,6.2832);c.fill();}
 c.lineCap='round';c.shadowColor=rgba(C.bounce,1);c.shadowBlur=10+8*heat;c.strokeStyle=rgba(C.bounce,1);c.lineWidth=3.6;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.85);c.lineWidth=1.1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function boostPad(c,s){var t=now(),g=geom(s),A=[s[0],s[1]],dx=s[2]-s[0],dy=s[3]-s[1],len=g.len,ux=dx/len,uy=dy/len,Dp=11,i;
 var fl=0;for(i=0;i<D.flash.length;i++){var f=D.flash[i],pr=((f.x-A[0])*ux+(f.y-A[1])*uy);var pd=Math.abs((f.x-A[0])*g.nx+(f.y-A[1])*g.ny);if(pr>-15&&pr<len+15&&pd<25)fl=Math.max(fl,f.life);}
 c.save();
 // longeron sombre derrière la surface
 var gr=c.createLinearGradient(A[0],A[1],A[0]+g.nx*Dp,A[1]+g.ny*Dp);gr.addColorStop(0,'#3B2A5E');gr.addColorStop(1,'#140E22');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.lineTo(s[2]+g.nx*Dp,s[3]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 // chaîne de cellules (cavité RF) : une onde les parcourt dans le sens de la poussée
 var nc=Math.max(2,Math.floor(len/11)),step=len/nc,ang=Math.atan2(uy,ux);
 for(i=0;i<nc;i++){var q=(i+.5)*step,x=A[0]+ux*q+g.nx*Dp*.5,y=A[1]+uy*q+g.ny*Dp*.5,wave=.5+.5*Math.sin(i*.9-t*.22),e=Math.max(wave*.8,fl);
  c.save();c.translate(x,y);c.rotate(ang);
  var g2=c.createRadialGradient(0,0,0,0,0,6);g2.addColorStop(0,rgba(C.white,.25+.55*e));g2.addColorStop(.5,rgba(C.boost,.35+.5*e));g2.addColorStop(1,rgba(C.boost,.05));
  c.fillStyle=g2;c.beginPath();c.ellipse(0,0,step*.46,5,0,0,6.2832);c.fill();
  c.strokeStyle=rgba(C.boost,.6+.4*e);c.lineWidth=.9;c.stroke();
  c.strokeStyle=rgba(C.white,.35+.5*e);c.lineWidth=1;c.beginPath();c.moveTo(-1.5,-2.2);c.lineTo(1.5,0);c.lineTo(-1.5,2.2);c.stroke();   // chevron = sens de la poussée
  c.restore();}
 // surface de roulement exactement sur la ligne de collision
 c.lineCap='round';c.shadowColor=rgba(C.boost,1);c.shadowBlur=10+14*fl;c.strokeStyle=rgba(C.boost,1);c.lineWidth=3.4;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.8);c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(s[2]-g.nx,s[3]-g.ny);c.stroke();
 c.restore();}
function spikes(c,s){var g=geom(s),Dp=7,A=[s[0],s[1]],B=[s[2],s[3]],i=0;
 c.save();c.fillStyle='#1B0F14';c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B[0]+g.nx*Dp,B[1]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 c.strokeStyle='rgba(255,82,82,.35)';c.lineWidth=1;c.stroke();c.shadowColor='#FF5252';c.shadowBlur=8;
 for(var q=4;q<g.len-3;q+=8.5,i++){var hh=7+rnd(i+s[0])*7,w=3+rnd(i*3+s[1])*1.6,x=A[0]+g.ux*q,y=A[1]+g.uy*q,tx=x-g.nx*hh,ty=y-g.ny*hh;
  var gr=c.createLinearGradient(x,y,tx,ty);gr.addColorStop(0,'#5A1418');gr.addColorStop(1,'#FF7A7A');
  c.fillStyle=gr;c.beginPath();c.moveTo(x-g.ux*w,y-g.uy*w);c.lineTo(tx,ty);c.lineTo(x+g.ux*w,y+g.uy*w);c.closePath();c.fill();}
 c.restore();}

function isCupWall(lv,s){if(!lv.cup)return false;var x=lv.cup[0],y=lv.cup[1],w=lv.cup[2];
 return (s[1]===y&&s[3]===y&&s[0]===x&&s[2]===x+w)||((s[0]===x||s[0]===x+w)&&s[1]===y&&s[2]===s[0]&&s[3]===y-56);}

function cupGlow(c,lv){var z=lv.zone,t=now(),pul=.5+.5*Math.sin(t*.05);if(!z)return;
 c.save();var gr=c.createLinearGradient(0,z[1],0,z[1]+z[3]);gr.addColorStop(0,'rgba(155,235,75,0)');gr.addColorStop(1,'rgba(155,235,75,'+(.16+.08*pul)+')');
 c.fillStyle=gr;c.fillRect(z[0],z[1],z[2],z[3]);c.strokeStyle='rgba(200,255,141,.55)';c.lineWidth=1.4;c.beginPath();
 for(var x=z[0]+2;x<=z[0]+z[2]-2;x+=3){var y=z[1]+z[3]-9+Math.sin(x*.12+t*.08)*1.6;if(x===z[0]+2)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();
 for(var i=0;i<5;i++){var px=z[0]+8+rnd(i)*(z[2]-16),py=z[1]+z[3]-((t*.4+rnd(i+9)*60)%44);c.fillStyle='rgba(155,235,75,.5)';c.beginPath();c.arc(px,py,1.2,0,6.2832);c.fill();}
 c.restore();}

function supports(c,lv){var deg={},i,s,k,p,j;
 for(i=0;i<lv.walls.length;i++){s=lv.walls[i];var e=[[s[0],s[1]],[s[2],s[3]]];for(j=0;j<2;j++){k=Math.round(e[j][0])+','+Math.round(e[j][1]);deg[k]=(deg[k]||0)+1;}}
 for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];if(s[4]!==0)continue;var g=geom(s),ends=[[s[0],s[1]],[s[2],s[3]]];
  for(j=0;j<2;j++){p=ends[j];if(p[0]<8||p[0]>VW-8)continue;k=Math.round(p[0])+','+Math.round(p[1]);
   if(p[1]<300){c.strokeStyle='rgba(138,151,166,.22)';c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]-2);c.lineTo(p[0],0);c.stroke();
    c.fillStyle='#8A97A6';c.beginPath();c.arc(p[0],p[1]-3,2,0,6.2832);c.fill();}
   else if(p[1]<455&&deg[k]<2){var x0=p[0]-4,y0=p[1]+g.ny*10;c.fillStyle='rgba(36,48,64,.85)';c.fillRect(x0,y0,8,VH-y0);
    c.strokeStyle='rgba(169,200,232,.85)';c.lineWidth=1;c.beginPath();for(var y=y0,n=0;y<VH;y+=10,n++){c.moveTo(n%2?x0:x0+8,y);c.lineTo(n%2?x0+8:x0,y+10);}c.stroke();}}}
 for(k in deg){if(deg[k]<2)continue;var xy=k.split(',').map(Number);c.fillStyle='#1A2533';c.strokeStyle='#A9C3D6';c.lineWidth=1.4;c.beginPath();
  for(i=0;i<6;i++){var a=i*Math.PI/3+Math.PI/6;c.lineTo(xy[0]+Math.cos(a)*7,xy[1]+Math.sin(a)*7);}c.closePath();c.fill();c.stroke();}}

/* murs fixes : renvoie la liste des segments que le rendu d'origine doit encore dessiner (élan, glace…) */
function fixed(c,segs,lv){var rest=[],i,s;cupGlow(c,lv);supports(c,lv);
 for(i=0;i<segs.length;i++){s=segs[i];
  if(s[4]===2)spikes(c,s);else if(s[4]===1)plate(c,s);else if(s[4]===3)boostPad(c,s);else if(s[4]===0)beam(c,s,isCupWall(lv,s)?'#9BEB4B':null);else rest.push(s);}
 return rest;}

/* trait du joueur : ruban d'énergie (structure) ou plaque (rebond). Renvoie false si non géré. */
function stroke(c,pts,mat,k){if(mat===3){for(var j3=1;j3<pts.length;j3++)boostPad(c,[pts[j3-1][0],pts[j3-1][1],pts[j3][0],pts[j3][1],3]);return true;}
 if(mat===1){for(var i=1;i<pts.length;i++)plate(c,[pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1],1]);return true;}
 if(mat!==0)return false;var t=now();c.save();c.globalAlpha=k===undefined?1:k;c.lineCap='round';c.lineJoin='round';
 function path(){c.beginPath();for(var j=0;j<pts.length;j++){if(j)c.lineTo(pts[j][0],pts[j][1]);else c.moveTo(pts[j][0],pts[j][1]);}}
 c.shadowColor='#4DD7FF';c.shadowBlur=18;c.strokeStyle='rgba(77,215,255,.9)';c.lineWidth=5.5;path();c.stroke();
 c.shadowBlur=0;c.strokeStyle='#E8FBFF';c.lineWidth=1.6;path();c.stroke();
 c.setLineDash([3,11]);c.lineDashOffset=-t*.9;c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=2.6;path();c.stroke();c.setLineDash([]);
 c.restore();return true;}

/* ============================ NUAGES DE POINTS ============================ */
/* Références : illusions bistables (nuages de points en rotation 3D, sans indice
   de profondeur — le sens de rotation est ambigu : métaphore de la superposition). */
var SPH=[],CAP=[],RING=[],i;
for(i=0;i<150;i++){var yy=1-2*(i+.5)/150,rr=Math.sqrt(1-yy*yy),aa=i*2.39996;SPH.push([Math.cos(aa)*rr,yy,Math.sin(aa)*rr]);}
for(i=0;i<170;i++){var u=i/170,a2=i*2.39996,y2=u*2-1,cap=.55,x2,z2;
 if(Math.abs(y2)<cap){x2=Math.cos(a2);z2=Math.sin(a2);}else{var kq=(Math.abs(y2)-cap)/(1-cap),hq=Math.sqrt(Math.max(0,1-kq*kq));x2=Math.cos(a2)*hq;z2=Math.sin(a2)*hq;y2=(y2<0?-1:1)*(cap+kq*.55);}
 CAP.push([x2*.62,y2,z2*.62]);}
for(i=0;i<80;i++){var a3=i/80*6.2832;RING.push([Math.cos(a3),0,Math.sin(a3)]);}
function rot(p,ax,ay,az){var x=p[0],y=p[1],z=p[2],c1=Math.cos(ay),s1=Math.sin(ay),t;t=x*c1+z*s1;z=-x*s1+z*c1;x=t;
 c1=Math.cos(ax);s1=Math.sin(ax);t=y*c1-z*s1;z=y*s1+z*c1;y=t;if(az){c1=Math.cos(az);s1=Math.sin(az);t=x*c1-y*s1;y=x*s1+y*c1;x=t;}return [x,y,z];}
function cloud(c,pts,R,ax,ay,az,colf,sz){for(var j=0;j<pts.length;j++){var q=rot(pts[j],ax,ay,az);c.fillStyle=colf(pts[j]);c.fillRect(q[0]*R-sz/2,q[1]*R-sz/2,sz,sz);}}
function sphereCol(p){var f=(p[1]+1)/2;return rgba(f>.5?mix(C.pink,C.boost,(1-f)*2):mix(C.boost,C.matter,(.5-f)*2),.9);}

/* noyau : sphère bistable + anneau (Fonderie : capsule orange-or) */
function core(c,lv){var t=now(),st=lv.star,fo=(lv.wd===2);c.save();c.translate(st[0],st[1]);c.globalCompositeOperation='lighter';
 var gr=c.createRadialGradient(0,0,0,0,0,24);gr.addColorStop(0,rgba(fo?C.bounce:C.boost,.24));gr.addColorStop(.6,rgba(fo?C.danger:C.matter,.06));gr.addColorStop(1,'rgba(0,0,0,0)');
 c.fillStyle=gr;c.fillRect(-24,-24,48,48);
 if(fo)cloud(c,CAP,12,.25,t*.02,.7+Math.sin(t*.006)*.25,function(p){return rgba(mix(C.bounce,C.reward,(p[1]+1)/2),.85);},1.4);
 else cloud(c,SPH,10.5,.35,t*.021,0,sphereCol,1.4);
 var ax2=1.15+Math.sin(t*.004)*.2,ay2=-t*.017;
 cloud(c,RING,17.5,ax2,ay2,fo?.7:0,function(p){return rgba(fo?C.danger:mix(C.reward,C.goal,(p[0]+1)/2),.75);},1.2);
 if(lv.wd===3){for(var bb=0;bb<3;bb++){var ph3=t*.09+bb*2.094,q3=rot([Math.cos(ph3),0,Math.sin(ph3)],ax2,ay2,0);
   var g4=c.createRadialGradient(q3[0]*17.5,q3[1]*17.5,0,q3[0]*17.5,q3[1]*17.5,5);g4.addColorStop(0,rgba(C.white,.95));g4.addColorStop(1,rgba(C.boost,0));c.fillStyle=g4;c.fillRect(q3[0]*17.5-5,q3[1]*17.5-5,10,10);}}
 else if((t%140)>5){var ph=t*.05,q=rot([Math.cos(ph),0,Math.sin(ph)],ax2,ay2,fo?.7:0),ex=q[0]*17.5,ey=q[1]*17.5;
  gr=c.createRadialGradient(ex,ey,0,ex,ey,6);gr.addColorStop(0,rgba(C.white,.95));gr.addColorStop(.4,rgba(fo?C.bounce:C.matter,.6));gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(ex-6,ey-6,12,12);}
 c.restore();}

/* balle : particule en nuage de points (sphère bistable), cœur lumineux, contour net pour rester lisible */
function ball(c,x,y,ang,r,tint){var t=now();c.save();c.translate(x,y);
 var tc=tint?hex(tint):null;
 var gr=c.createRadialGradient(0,0,0,0,0,r*2.1);gr.addColorStop(0,rgba(tc||C.matter,.35));gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(-r*2.1,-r*2.1,r*4.2,r*4.2);
 gr=c.createRadialGradient(-r*.25,-r*.3,0,0,0,r);gr.addColorStop(0,'rgba(255,255,255,.55)');gr.addColorStop(.5,rgba(tc||C.boost,.28));gr.addColorStop(1,rgba(tc||C.matter,.12));
 c.fillStyle=gr;c.beginPath();c.arc(0,0,r,0,6.2832);c.fill();
 c.globalCompositeOperation='lighter';
 cloud(c,SPH,r*.96,.45,(ang||0)+t*.01,0,tc?function(){return rgba(tc,.9);}:sphereCol,1.25);
 c.globalCompositeOperation='source-over';c.strokeStyle=rgba(tc||C.white,.7);c.lineWidth=1;c.beginPath();c.arc(0,0,r,0,6.2832);c.stroke();
 c.restore();}
function hex(h){if(typeof h!=='string'||h.charAt(0)!=='#')return C.boost;return [parseInt(h.substr(1,2),16),parseInt(h.substr(3,2),16),parseInt(h.substr(5,2),16)];}

/* ============================ ACCUEIL ============================ */
var HD=null;
function hero(c,w,h){var t=now();
 if(!HD||HD.w!==w||HD.h!==h){HD={w:w,h:h,dust:[]};for(var j=0;j<90;j++)HD.dust.push({x:rnd(j)*w,y:rnd(j*1.7)*h,z:.3+rnd(j*2.3)*.7,ph:rnd(j*4.1)*6.28,col:[C.white,C.white,C.matter,C.boost][j%4]});}
 c.fillStyle='#070B14';c.fillRect(0,0,w,h);
 c.save();c.globalCompositeOperation='lighter';
 var b1=[[w*.2,h*.5,w*.55,C.boost,.16],[w*.78,h*.45,w*.45,C.matter,.14],[w*.55,h*.9,w*.4,C.reward,.06]];
 for(var i=0;i<b1.length;i++){var q=b1[i],x=q[0]+Math.sin(t*.004+i)*10,gr=c.createRadialGradient(x,q[1],0,x,q[1],q[2]);
  gr.addColorStop(0,rgba(q[3],q[4]*(.85+.15*Math.sin(t*.01+i))));gr.addColorStop(1,rgba(q[3],0));c.fillStyle=gr;c.fillRect(0,0,w,h);}
 for(i=0;i<HD.dust.length;i++){var d=HD.dust[i];d.x+=.08*d.z;d.y-=.03*d.z;if(d.x>w+3)d.x=-3;if(d.y<-3)d.y=h+3;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),s=.5+d.z*1.2;c.fillStyle=rgba(d.col,(.15+.5*d.z)*tw);c.fillRect(d.x,d.y,s,s);}
 c.restore();
 helix(c,-10,h*.78,w*.62,h*.18,11,3.2,.028,C.matter,C.boost,.55,70);
 var cx=w*.8,cy=h*.5,R=Math.min(h*.36,w*.16);
 c.save();c.translate(cx,cy);c.globalCompositeOperation='lighter';
 var g2=c.createRadialGradient(0,0,0,0,0,R*1.6);g2.addColorStop(0,rgba(C.boost,.22));g2.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g2;c.fillRect(-R*1.6,-R*1.6,R*3.2,R*3.2);
 cloud(c,SPH,R,.35,t*.012,0,sphereCol,1.6);
 cloud(c,RING,R*1.45,1.2+Math.sin(t*.003)*.15,-t*.009,0,function(p){return rgba(mix(C.reward,C.goal,(p[0]+1)/2),.7);},1.4);
 c.restore();}
function heroWall(c,q){stroke(c,[[q[0],q[1]],[q[2],q[3]]],0,1);}

window.VX={back:back,nd:nd,fixed:fixed,stroke:stroke,core:core,ball:ball,hero:hero,heroWall:heroWall};
})();
