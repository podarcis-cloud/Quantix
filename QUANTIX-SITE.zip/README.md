# QUANTIX

Jeu de puzzle physique. On trace des murs au doigt pour guider une particule
jusqu'à la zone d'arrivée. 132 expériences, 11 mondes, de la physique classique
aux phénomènes quantiques.

**Dessine. Expérimente. Maîtrise.**

## Lancer en local

Aucune construction, aucune dépendance. Ouvre `index.html` dans un navigateur.
Les scripts sont des scripts classiques, pas des modules : le double-clic suffit,
sans serveur local.

Pour servir en HTTP malgré tout :

```sh
python3 -m http.server 8000
```

## Mettre en ligne sur GitHub Pages

1. Crée un dépôt et pousse ce dossier à la racine.
2. Dans **Settings → Pages**, choisis **Source : GitHub Actions**.
3. Pousse sur `main`. Le workflow `.github/workflows/deploy.yml` publie le site.

Le site s'ouvrira sur `https://<compte>.github.io/<dépôt>/`.

Tous les chemins sont **relatifs** : le site fonctionne aussi bien à la racine
d'un domaine que dans un sous-dossier. Ne jamais introduire de chemin commençant
par `/`, il casserait le déploiement en sous-dossier.

Le fichier `.nojekyll` désactive le traitement Jekyll, qui ignorerait certains
fichiers.

## Arborescence

```
index.html                 structure seule, aucun script en ligne
manifest.webmanifest       installation sur l'écran d'accueil
assets/
  css/quantix.css          tous les styles et les jetons de couleur
  js/worldart.js           chemins des illustrations + fiches de monde
  js/i18n.js               dictionnaire FR/EN, 132 noms, 132 conseils
  js/levels.js             les 132 expériences et les 11 mondes
  js/engine.js             audio, physique, solveur, rendu, interface
  img/worlds/              une illustration par monde, chargée à la demande
  img/ui/                  bandeau d'accueil et icônes
  audio/sfx/               17 effets en MP3
  audio/silent.mp3         boucle silencieuse, contournement iOS
tools/                     harnais de test node, hors production
docs/                      handbook, protocole, reprise, tâches
```

**L'ordre de chargement des scripts est imposé** : les données avant le moteur.
`worldart.js`, `i18n.js`, `levels.js`, puis `engine.js`.

## Vérifier avant de publier

```sh
cd tools
node audit.js     # base64 résiduel, chemins morts, assets orphelins, démarrage
node render.js    # 12 frames de rendu, niveau de référence, 11 cartes de monde
```

`audit.js` sort en erreur si quelque chose manque : il peut servir tel quel dans
une étape de vérification avant déploiement.
