# e2e-son.py — bible sonore (R54) : couverture des éléments, boucles vivantes, niveaux de crête par monde. Chromium.
import os,sys,json,base64
import numpy as np
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));URL='file://'+ROOT+'/index.html'
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_context().new_page()
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(URL);pg.wait_for_timeout(700)
    # 1. couverture : chaque élément présent dans un niveau a un son
    miss=pg.evaluate("""(function(){var cov=Audio1._covers(),m=[];LEVELS.forEach(function(l,i){
      (l.w||[]).forEach(function(s){if(!cov['mat'+s[4]])m.push((i+1)+':mat'+s[4]);});
      ['wind','grav','mag','mov','port','ent','gate','sup','det','tdil'].forEach(function(k){if(l[k]&&l[k].length&&!cov[k])m.push((i+1)+':'+k);});
      if(l.softball&&!cov.soft)m.push((i+1)+':soft');});return m;})()""")
    chk(len(miss)==0,'couverture : aucun élément muet sur les 132 niveaux'+(' — manquants : '+','.join(miss[:10]) if miss else ''))
    # 2. boucles vivantes : vent (monde 5), aimant (monde 8), dilatation (monde 11)
    pg.mouse.click(10,10);pg.evaluate("Audio1.unlock()");pg.wait_for_timeout(300)
    def first(k):return pg.evaluate("(function(){for(var i=0;i<LEVELS.length;i++)if(LEVELS[i]['%s']&&LEVELS[i]['%s'].length)return i;return -1})()"%(k,k))
    for k,probe in (('wind','wind'),('mag','mag'),('tdil','musF'),('grav','grav')):
        i=first(k);pg.evaluate("S.unlocked=131;goto('game');loadLevel(%d);S.mode='run';"%i)
        z=pg.evaluate("LEVELS[%d]['%s'][0]"%(i,k))
        cx,cy=(z[0]+z[2]/2,z[1]+z[3]/2) if k in ('wind','tdil','grav') else (z[0]+4,z[1]+4)
        for _ in range(12):pg.evaluate("S.mode='run';S.ball.x=%f;S.ball.y=%f;S.ball.vx=1;S.ball.vy=0"%(cx,cy));pg.wait_for_timeout(60)
        lp=pg.evaluate("Audio1._loops()");v=lp.get(probe)
        ok=(v is not None and (v<2000 if probe=='musF' else v>.003))
        chk(ok,'boucle « %s » active dans la zone (niveau %d) : %s'%(k,i+1,v))
    pg.evaluate("S.mode='draw'");pg.wait_for_timeout(500)
    chk(all(v<.004 for n,v in pg.evaluate("Audio1._loops()").items() if n in('wind','mag','grav')),'hors partie : les boucles se taisent')
    # 3. crête par monde : toutes les familles d'effets empilées sur fond de musique
    peaks=[]
    for w in range(11):
        pk=pg.evaluate("""(w)=>new Promise(res=>{Audio1._render(14,function(c){Audio1._world(w);var t=1;
          [0,1,2,3,4,5].forEach(function(m,j){Audio1._impactAt(m,.9,t+j*.3);});
          ['star_collect','portal','ent_link','gate','sup_split','det_measure','collapse','boost_whoosh','ball_launch'].forEach(function(n,j){Audio1._sfxAt(n,t+2+j*.6,1);});
          Audio1._sfxAt('goal_enter',9,1);Audio1._sfxAt('level_success',10,1);Audio1._impactAt(0,1,10.1);Audio1._impactAt(1,1,10.2);
        },function(buf){var L=buf.getChannelData(0),R=buf.getChannelData(1),p=0;for(var i=0;i<L.length;i++)p=Math.max(p,Math.abs(L[i]),Math.abs(R[i]));res(p);},w);})""",w)
        peaks.append(round(pk,3))
    chk(max(peaks)<.5,'crête < 0,5 dans les 11 mondes : '+' '.join(str(x) for x in peaks))
    b.close()
print('erreurs',errs);print('RÉSULTAT',sum(res),'/',len(res));sys.exit(0 if all(res) and not errs else 1)
