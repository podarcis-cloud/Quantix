# Fermeture magnétique du trait à main levée (R385)
from playwright.sync_api import sync_playwright
import math
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(1000)
    pg.evaluate("QUANTONE.state.strokes=[]");pg.evaluate("(()=>{const t=document.querySelector('.dk[data-m=\"draw\"]');t&&t.click()})()")
    bb=pg.locator('#cv').bounding_box();cx=bb['x']+bb['width']/2;cy=bb['y']+bb['height']/2;R=min(bb['width'],bb['height'])*.28
    def pt(a,r=R):return cx+r*math.cos(a),cy+r*math.sin(a)
    def circle(upto_deg,end_r=R,release=True,away=False):
        x,y=pt(0);pg.mouse.move(x,y);pg.mouse.down()
        for d in range(4,int(upto_deg)+1,4):
            x,y=pt(math.radians(d));pg.mouse.move(x,y)
        x,y=pt(math.radians(upto_deg+3),end_r);pg.mouse.move(x,y)
        return x,y
    # 1) approche à ~14° du départ : le magnétisme s'active, lâcher ferme exactement
    circle(352)
    st=pg.evaluate("({mag:document.getElementById('cv')&&0})")
    mag=pg.evaluate("(()=>{const P=QUANTONE.ed;return P.pill?P.pill.t:null})()")
    chk(mag and 'ferm' in mag.lower() or mag and 'close' in mag.lower(),'près du départ : message « %s »'%mag)
    pg.mouse.up();pg.wait_for_timeout(100)
    S=pg.evaluate("QUANTONE.state.strokes.map(s=>({n:s.pts.length,a:s.pts[0],b:s.pts[s.pts.length-1]}))")
    chk(len(S)==1 and S[0]['a'][0]==S[0]['b'][0] and S[0]['a'][1]==S[0]['b'][1],'lâcher : forme fermée exactement (début = fin)')
    # 2) loin du départ : pas de fermeture
    pg.evaluate("QUANTONE.state.strokes=[]")
    circle(250);pg.mouse.up();pg.wait_for_timeout(100)
    S=pg.evaluate("QUANTONE.state.strokes.map(s=>({a:s.pts[0],b:s.pts[s.pts.length-1]}))")
    chk(len(S)==1 and (abs(S[0]['a'][0]-S[0]['b'][0])+abs(S[0]['a'][1]-S[0]['b'][1]))>.3,'trait ouvert : aucune fermeture forcée')
    # 3) approche puis on s'éloigne : le trait continue, pas de message, pas d'accroche
    pg.evaluate("QUANTONE.state.strokes=[]")
    circle(346);x,y=pt(math.radians(340),R*1.6);pg.mouse.move(x,y);pg.mouse.move(x+30,y+30)
    chk(pg.evaluate("QUANTONE.ed.pill===null"),'on s\'éloigne : le message disparaît')
    pg.mouse.up();pg.wait_for_timeout(100)
    S=pg.evaluate("QUANTONE.state.strokes.map(s=>({a:s.pts[0],b:s.pts[s.pts.length-1]}))")
    chk(len(S)==1 and (abs(S[0]['a'][0]-S[0]['b'][0])+abs(S[0]['a'][1]-S[0]['b'][1]))>.1,'le trait continue (non fermé)')
    # 4) petit trait court près de son départ : pas de magnétisme
    pg.evaluate("QUANTONE.state.strokes=[]")
    x,y=pt(0);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+8,y+6);pg.mouse.move(x+3,y+2)
    chk(pg.evaluate("QUANTONE.ed.pill===null"),'trait court : pas de magnétisme parasite')
    pg.mouse.up()
    chk(not er,'aucune erreur JS '+str(er[:2]))
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
