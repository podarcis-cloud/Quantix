# e2e-echelle.py — R261 : Échelle fusionnée dans Déplacer (poignée ⤢), encre et annulation.
import os
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':780},device_scale_factor=2)
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('file://'+ROOT+'/index.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(500)
    pg.evaluate("TUTO.load({v:1,i:1,s:['tdraw','tline','terase','tmove','nd','spike','bounce','palB']},0);S.unlocked=131;goto('game');loadLevel(0);S.ink=S.inkMax=900;paintEnergy()");pg.wait_for_timeout(600)
    chk(pg.evaluate("!document.querySelector('.dk[data-m=scale]')"),'plus de bouton Échelle séparé dans le dock')
    def w2s(x,y):
        r=pg.evaluate("(function(){var r=cv.getBoundingClientRect();return [r.left,r.top,r.width]})()");s=r[2]/360.0;return r[0]+x*s,r[1]+y*s
    pg.click('.dk[data-m=line]');a=w2s(100,300);c=w2s(200,300)
    pg.mouse.move(*a);pg.mouse.down();pg.mouse.move(*c,steps=8);pg.mouse.up();pg.wait_for_timeout(150)
    L0=pg.evaluate("S.strokes[0].len");ink0=pg.evaluate("S.ink")
    pg.click('.dk[data-m=move]');m=w2s(150,300);pg.mouse.click(*m);pg.wait_for_timeout(150)
    sp=pg.evaluate("EDT._sclPos?EDT._sclPos():null")
    # la poignée est au coin du cadre : on la cherche à l'écran par les coins candidats
    pts=pg.evaluate("S.strokes[0].pts")
    xs=[q[0] for q in pts];ys=[q[1] for q in pts]
    cands=[(max(xs)+14,max(ys)+14),(min(xs)-14,max(ys)+14),(max(xs)+14,min(ys)-14),(min(xs)-14,min(ys)-14)]
    ok=False
    for cx,cy in cands:
        s0=w2s(cx,cy);s1=w2s(cx+50,cy+10)
        pg.mouse.move(*s0);pg.mouse.down();pg.mouse.move(*s1,steps=8);pg.mouse.up();pg.wait_for_timeout(150)
        L1=pg.evaluate("S.strokes[0].len")
        if L1>L0*1.15: ok=True;break
    chk(ok,'la poignée ⤢ agrandit le trait (%.0f → %.0f)'%(L0,L1))
    ink1=pg.evaluate("S.ink");chk(abs((ink0-ink1)-(L1-L0))<2,'l’encre suit la longueur (−%.0f)'%(ink0-ink1))
    pg.click('#bUndo');pg.wait_for_timeout(150)
    chk(abs(pg.evaluate("S.strokes[0].len")-L0)<1 and abs(pg.evaluate("S.ink")-ink0)<1,'Annuler rend la taille et l’encre')
    pg.screenshot(path='/tmp/ech.png')
    chk(not errs,'aucune erreur '+str(errs[:2]))
print('RÉSULTAT',sum(res),'/',len(res))
