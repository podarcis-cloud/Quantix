# Banque FX (R378) : chargement de FX_bank.zip, effets AudioWorklet en rendu hors ligne, interface
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
RENDER="""async (args)=>{const [list,srcFreq,sec,pre]=args;const c=new OfflineAudioContext(2,Math.ceil(44100*sec),44100);
 const o=c.createOscillator();o.frequency.value=srcFreq;const g=c.createGain();g.gain.value=.5;o.connect(g);o.start();
 const ch=QFXE.chain(c,list,{tempo:90});g.connect(ch.in);ch.out.connect(c.destination);if(pre)pre(c,ch);
 const b=await c.startRendering();return Array.from(b.getChannelData(0));}"""
FREQ="""(a)=>{let z=0,p=a[0];for(let i=1;i<a.length;i++){if(p<0&&a[i]>=0)z++;p=a[i];}return z/(a.length/44100);}"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    S=pg.evaluate("({s:QFXE.bank.state,v:QFXE.bank.ver,n:QFXE.bank.n,d:!!QFXE.defs.pitch&&!!QFXE.defs.tune,c:!!QFXE.chains.b_voixpop})")
    chk(S['s']=='ok' and S['n']==11 and S['d'] and S['c'],'FX_bank.zip chargée : 11 effets + chaînes (%s)'%S)
    # décaleur de hauteur +12 demi-tons : 440 Hz → 880 Hz
    f=pg.evaluate("async()=>{const a=await ("+RENDER+")([[{t:'pitch',a:12,b:0,m:1,on:1}],440,1.5]);return ("+FREQ+")(a.slice(22050))}")
    chk(abs(f-880)<25,'décaleur +12 : 440 Hz → %.0f Hz (rendu hors ligne)'%f)
    f=pg.evaluate("async()=>{const a=await ("+RENDER+")([[{t:'pitch',a:-12,b:0,m:1,on:1}],440,1.5]);return ("+FREQ+")(a.slice(22050))}")
    chk(abs(f-220)<15,'décaleur −12 : 440 Hz → %.0f Hz'%f)
    # autotune : 450 Hz (39 cents trop haut) → 440 Hz, gamme chromatique, vitesse max
    f=pg.evaluate("async()=>{const a=await ("+RENDER+")([[{t:'tune',a:1,b:0,c:0,m:1,on:1}],450,2.5]);return ("+FREQ+")(a.slice(66150))}")
    chk(abs(f-440)<4,'autotune : 450 Hz → %.1f Hz (note la plus proche, A4)'%f)
    f0=pg.evaluate("async()=>{const a=await ("+RENDER+")([[{t:'tune',a:1,b:0,c:0,m:0,on:1}],450,2.5]);return ("+FREQ+")(a.slice(66150))}")
    chk(abs(f0-450)<4,'autotune mix 0 : le son direct reste à 450 Hz (%.1f)'%f0)
    # bitcrusher 2 bits : peu de niveaux distincts
    n=pg.evaluate("async()=>{const a=await ("+RENDER+")([[{t:'crush2',a:2,b:0,m:1,on:1}],220,1]);return new Set(a.slice(4410).map(v=>Math.round(v*1000))).size}")
    chk(n<=6,'bitcrusher 2 bits : %d niveaux distincts'%n)
    # gel granulaire : après le gel, du son continue alors que l’entrée est coupée
    r=pg.evaluate("""async()=>{const c=new OfflineAudioContext(2,44100*2,44100),o=c.createOscillator();o.frequency.value=300;const g=c.createGain();g.gain.value=.5;g.gain.setValueAtTime(0,1);o.connect(g);o.start();
      const ch=QFXE.chain(c,[{t:'freeze',a:0,b:.2,m:1,on:1}],{});g.connect(ch.in);ch.out.connect(c.destination);
      await new Promise(r=>setTimeout(r,300));const n=ch.units[0].u;let tries=0;while(!n.node&&tries++<40)await new Promise(r=>setTimeout(r,50));
      n.node.parameters.get('hold').setValueAtTime(1,.8);const b=await c.startRendering();const d=b.getChannelData(0);let e=0;for(let i=66150;i<88200;i++)e+=d[i]*d[i];return [e/22050,!!n.node]}""")
    chk(r[1] and r[0]>0.005,'gel granulaire : le son se maintient après coupure de l’entrée (énergie %.4f)'%r[0])
    # interface : liste des effets et chaîne prête
    pg.evaluate("QFX3.open(0)");pg.wait_for_timeout(400)
    ops=pg.evaluate("[...document.querySelectorAll('#ifxAdd option')].map(o=>o.value)")
    chk('pitch' in ops and 'tune' in ops and 'c:b_voixpop' in ops,'« Ajouter un effet » propose les effets et chaînes de la banque')
    pg.evaluate("(()=>{const s=document.getElementById('ifxAdd');s.value='tune';s.dispatchEvent(new Event('change',{bubbles:true}))})()");pg.wait_for_timeout(500)
    chk(pg.locator('#ifxBox .fxc').count()==1 and pg.locator('#ifxBox .fxc input[type=range]').count()>=3,'carte Autotune avec ses curseurs (vitesse, gamme, tonique)')
    k=pg.evaluate("QAUTO.key(document.querySelector('#ifxBox .fxc input[data-k]'))")
    chk(k and k[0].startswith('ifx:0:0:'),'curseurs de la banque automatisables (règle Q1) %s'%k)
    # morceau ancien avec effet de banque absente : pas d’erreur
    pg.evaluate("(()=>{QUANTONE.state.inst[0].fx=[{t:'inconnu_xyz',on:1}]; QFX3.open(0)})()");pg.wait_for_timeout(300)
    chk(pg.locator('#ifxBox .fxc').count()>=1,'effet inconnu : carte neutre, pas de plantage')
    chk(not er,'aucune erreur page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
