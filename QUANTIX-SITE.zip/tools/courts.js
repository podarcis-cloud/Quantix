/* courts.js N [nd-json] — R121 : liste les traits courts (sous le seuil de la position) qui gagnent le niveau installé,
   éventuellement avec des zones interdites ajoutées (pour essayer une fermeture avant de l'écrire). */
const D=require('./design.js'),LAB=require('./lab.js');const num=+process.argv[2],idx=num-1,pos=idx%12+1,MINL=pos<=3?40:pos<=8?80:120;
const lv=D.X.LEVELS[idx],add=JSON.parse(process.argv[3]||'[]');
const c=JSON.parse(JSON.stringify({w:lv.w,curves:lv.curves,nd:(lv.nd||[]).concat(add),cup:lv.cup,ball:lv.ball,mz:lv.mz,ink:lv.ink,pal:lv.pal,star:lv.star}));
if(!c.nd.length)delete c.nd;
let seed=num*97;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const mats=[0].concat((c.pal||'S').includes('B')?[1]:[]);const out=[];let t=0;
while(t<6000&&out.length<8){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,l=8+rnd()*(MINL-8),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];
 if(!D.drawable(c,p))continue;t++;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok)out.push([Math.round(l),m,p]);}
const sol=LAB.run(idx,c,lv.optsol.map(p=>({pts:p,mat:lv.optmat||0}))).ok;
console.log('#'+num,lv.n,'seuil',MINL,'| solution',sol?'ok':'ÉCHOUE','| courts gagnants',out.length,JSON.stringify(out));
