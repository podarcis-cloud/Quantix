/* audit-meta.js — signature de chaque niveau (mécaniques, forme de la solution de référence) → JSON sur stdout. */
require('./load.js');const X=globalThis.__X,KEYS=['nd','wind','grav','mag','port','mov','ent','gate','sup','det','tdil','rails','mz','curves','flow','vortex','updraft','pend','well','bf','kick','wrap','strings','elastic','strE','sling','fork','coil','spectro','rec','softball'];
const out=X.LEVELS.map((L,i)=>{const m=KEYS.filter(k=>L[k]!==undefined&&L[k]!==null&&!(Array.isArray(L[k])&&!L[k].length));
 const o=L.optsol||null;let len=0,ang=null,ns=0;if(o){ns=o.length;o.forEach(p=>{for(let q=1;q<p.length;q++)len+=Math.hypot(p[q][0]-p[q-1][0],p[q][1]-p[q-1][1]);});const p=o[0];ang=Math.round(Math.atan2(p[p.length-1][1]-p[0][1],p[p.length-1][0]-p[0][0])*180/Math.PI);}
 return {i:i+1,n:L.n,wd:L.wd,ink:L.ink,mech:m,walls:(L.w||[]).length,cupSide:L.cup[3],ns,mat:L.optmat||0,len:Math.round(len),ang,tip:L.tip||'',pal:L.pal};});
process.stdout.write('@@'+JSON.stringify(out));
