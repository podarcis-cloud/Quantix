"""build-banc-fin.py — Banc de la fin (avec annotation) : reprend la page publiée de la nouvelle discussion
(studio/banc-fin.html) et y remplace seulement visuals.js et hero.js par ceux du site. Sortie : studio/banc-fin.html.
Usage : python3 tools/build-banc-fin.py [source.html] [Rnnn]"""
import os,re,sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src=sys.argv[1] if len(sys.argv)>1 else os.path.join(ROOT,'studio/banc-fin.html')
tag=sys.argv[2] if len(sys.argv)>2 else ''
s=open(src,encoding='utf8').read()
vis=open(os.path.join(ROOT,'assets/js/visuals.js'),encoding='utf8').read();hero=open(os.path.join(ROOT,'assets/js/hero.js'),encoding='utf8').read()
parts=re.split(r'(<script>|</script>)',s);n=0
for i,p in enumerate(parts):
    if i>0 and parts[i-1]=='<script>':
        if 'visuals.js — rendu R33' in p:parts[i]=vis;n+=1
        elif 'var QHERO=(function' in p:img=p[:p.index('\n')+1];assert img.startswith('window.QHERO_IMG=');parts[i]=img+hero;n+=1
assert n==2,n
# R229 : vibrations (haptics.js) + panneau d'essai du pool
hap=open(os.path.join(ROOT,'assets/js/haptics.js'),encoding='utf8').read()
hi=[i for i,p in enumerate(parts) if i>0 and parts[i-1]=='<script>' and 'haptics.js — vibrations' in p]
if hi:parts[hi[0]]=hap
else:
    k=[i for i,p in enumerate(parts) if i>0 and parts[i-1]=='<script>' and p.startswith('window.QHERO_IMG=')][0]
    parts[k-1:k-1]=['<script>',hap,'</script>\n']
out=''.join(parts)
PANEL='''<div class="panel" id="hapPanel"><div class="lbl" style="margin-bottom:6px">Vibrations · proposition (<span id="hapEng"></span>)</div>
 <label class="sw"><input type="checkbox" id="hapOn" checked>Vibrer pendant le film (scénario R230)</label>
 <div class="row" style="margin-top:8px"><label class="sw"><input type="checkbox" switch id="hapSw">Test iPhone : bascule cet interrupteur toi-même</label><span class="note" id="hapUA"></span></div>
 <div class="row" id="hapRows" style="margin-top:8px"></div>
 <div class="note" style="margin-top:6px">Touche un motif pour le sentir. Sur iPhone, une seule intensité (le tic système) : le relief vient du rythme. Les vraies intensités légère / moyenne / lourde demandent l'application native.</div></div>
<script>window.addEventListener('load',function(){var N={frole:'Frôlement',tic:'Petit rebond',rebond:'Rebond',lourd:'Impact lourd',double:'Double rebond',roule:'Roulement',propulse:'Propulsion',portail:'Portail',collision:'Collision',crepite:'Crépitement',annihile:'Annihilation',coeur:'Battement',aspire:'Aspiration',naissance:'Naissance',cliquet:'Cliquet',givre:'Givre',houle:'Houle',tension:'Tension',envol:'Envol'};
 var R=document.getElementById('hapRows'),on=document.getElementById('hapOn');document.getElementById('hapEng').textContent=QHAP.engine();var mv=navigator.userAgent.match(/OS (\\d+)_(\\d+)/);document.getElementById('hapUA').textContent=(mv?'iOS '+mv[1]+'.'+mv[2]:'')+(/Safari\\//.test(navigator.userAgent)?' · Safari':' · intégré à une app');
 Object.keys(QHAP.pool).forEach(function(k){var b=document.createElement('button');b.type='button';b.textContent=N[k]||k;b.onclick=function(){var w=QHAP.on;QHAP.set(true);QHAP.play(k);if(!w)setTimeout(function(){QHAP.set(on.checked);},1600);};R.appendChild(b);});
 on.onchange=function(){QHAP.set(on.checked);};QHAP.set(on.checked);var ip=document.getElementById('bPlay');if(ip)ip.addEventListener('click',function(){if(on.checked)QHAP.play('tic');});});</script>
'''
if 'id="hapPanel"' not in out:
    m='<div class="panel" id="capList"'
    assert out.count(m)==1
    out=out.replace(m,PANEL+m)
# R234 : bande son de la fin (fin-sound.js) — script après hero.js, case « Son », lecture synchronisée sur l'horloge du banc
snd=open(os.path.join(ROOT,'assets/js/fin-sound.js'),encoding='utf8').read()
parts=re.split(r'(<script>|</script>)',out)
si=[i for i,p in enumerate(parts) if i>0 and parts[i-1]=='<script>' and 'fin-sound.js — R234' in p]
if si:parts[si[0]]=snd
else:
    k=[i for i,p in enumerate(parts) if i>0 and parts[i-1]=='<script>' and p.startswith('window.QHERO_IMG=')][0]
    parts[k+2:k+2]=['<script>',snd,'</script>\n']
out=''.join(parts)
SPANEL='''<div class="panel" id="sndPanel"><label class="sw"><input type="checkbox" id="sndOn" checked>Son de la fin (R234) — à ×1 seulement ; iPhone : mode silencieux désactivé</label></div>
<script>window.addEventListener('load',function(){var c=document.getElementById('sndOn'),u=function(){if(c.checked)QFINS.unlock();};c.onchange=function(){QFINS.set(c.checked);u();};
 ['bPlay','bRe','bM1','bM01','bP01','bP1'].forEach(function(id){var b=document.getElementById(id);if(b)b.addEventListener('click',u);});document.addEventListener('pointerdown',u,{once:true});});</script>
'''
if 'id="sndPanel"' not in out:
    m='<div class="panel" id="hapPanel"'
    assert out.count(m)==1
    out=out.replace(m,SPANEL+m)
HK=" if(ts-lastRead>90){lastRead=ts;readout();}"
if 'R234 : bande son */' not in out:
    assert out.count(HK)==1
    out=out.replace(HK," if(window.QFINS)QFINS.sync(t,playing&&!drag&&mode==='new',speed);   /* R234 : bande son */\n"+HK)
if tag:out=re.sub(r'Nouvelle fin \(R\d+\)','Nouvelle fin ('+tag+')',out);out=re.sub(r'<small>R\d+ · ','<small>'+tag+' · ',out)
open(os.path.join(ROOT,'studio/banc-fin.html'),'w',encoding='utf8').write(out);print('studio/banc-fin.html',len(out))
