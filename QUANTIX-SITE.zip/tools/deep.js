global.window={matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener:()=>{},ResizeObserver:null};
global.navigator={};const store={};
function fake(id){const o={id,style:{setProperty(){}},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(sel){/*QSA_REAL*/return (sel==='i')?[{className:''},{className:''},{className:''}]:[];},getBoundingClientRect(){return{left:0,top:0}},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>k==='createRadialGradient'?()=>({addColorStop(){}}):()=>{}})},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.document={getElementById:id=>store[id]||(store[id]=fake(id)),addEventListener(){},documentElement:fake('r')};
global.requestAnimationFrame=()=>{};
require('./test6.js');
const {S,LEVELS,physics,loadLevel,qpBuild,COST}=global.__X;
const TARGETS=[14,23,25,26,31,33,35,37,40,41,43,56,71,104,110,113];
const inND=(L,x,y)=>L.nd?L.nd.some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]):false;
function polyOK(L,p){for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i];
 const n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/9));
 for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;
  if(x<-2||x>362||y<-2||y>478)return false;if(inND(L,x,y))return false;}}return true;}
const plen=p=>{let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;};
function attempt(idx,pts,mat){loadLevel(idx);
 if(pts){S.strokes.push({pts,len:plen(pts),birth:0,mat:mat||0});S.ink-=plen(pts)*COST[mat||0];}
 qpBuild();S.mode='run';
 for(let f=0;f<1100;f++){physics();if(S.mode!=='run')break;}return S.mode;}
let out=[];
for(const idx of TARGETS){
 const L=LEVELS[idx],bx=L.ball[0],by=L.ball[1],z=L.zone;
 const cx=z[0]+z[2]/2,dir=cx>bx?1:-1,rim=dir>0?z[0]:z[0]+z[2];
 const mats=[0]; if(L.pal.indexOf('B')>=0)mats.push(1); if(L.pal.indexOf("A")>=0)mats.push(3); if(L.pal.indexOf("C")>=0)mats.push(5);
 let found=null,tried=0;
 const starts=[[bx-dir*28,by+36],[bx-dir*22,by+28],[bx-dir*40,by+56],[bx-dir*14,by+22]];
 const ends=[];
 for(const dx of [-10,10,30,60]) for(const dy of [-70,-46,-28,-14])
   ends.push([rim+dir*dx, z[1]+z[3]+dy]);
 outer:
 for(const m of mats) for(const s of starts) for(const e of ends){
   const cands=[[s,e]];
   for(const fx of [.3,.5,.7]) for(const wy of [120,190,260,330,400])
     cands.push([s,[bx+(e[0]-bx)*fx,wy],e]);
   for(const fx of [.35,.65]) for(const wy of [170,300])
     cands.push([s,[bx+(e[0]-bx)*fx,wy],[bx+(e[0]-bx)*(fx+.2),wy+90],e]);
   for(const c of cands){
     if(!polyOK(L,c))continue; if(plen(c)*COST[m]>L.ink)continue;
     tried++; if(attempt(idx,c,m)==='success'){found={c,m};break outer;}
   }
 }
 out.push({idx,n:L.n,wd:L.wd,found,tried});
 console.log(('#'+(idx+1)+' M'+L.wd+' '+L.n).padEnd(32)+
  (found?('RÉSOLU (matière '+found.m+') '+found.c.map(p=>p.map(Math.round).join(',')).join('→')):
         ('non résolu après '+tried+' tracés')));
}
console.log('\nrésolus :',out.filter(o=>o.found).length,'/',TARGETS.length);
