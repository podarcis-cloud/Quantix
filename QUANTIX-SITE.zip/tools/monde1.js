/* monde1.js — non-régression du monde 1 (R34, géométrie corrigée pour le doigt).
   Pour chaque niveau : sans trait → pas de réussite ; bouton « Voir la solution optimale »
   → réussit AVEC le noyau, progression intacte. La jouabilité au doigt se mesure à part :
   node difficulty.js 1 … 12 (docs/DIFFICULTY_PROTOCOL.md). */
require('./load.js');
const X=globalThis.__X,{store}=require('./load.js');const ST=X.S;let bad=0;
for(let i=0;i<12;i++){const LVi=X.LEVELS[i];
 X.loadLevel(i);X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();const seul=ST.mode==='success';
 X.loadLevel(i);const before=JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);ST.mode='fail';
 store['rSolution'].onclick.call(store['rSolution'],{});for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();
 const win=ST.mode==='success',star=ST.gotStar,intact=before===JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);
 const ok=!seul&&win&&star&&intact;if(!ok)bad++;
 console.log(String(i+1).padStart(2),LVi.n.padEnd(17),'seul:',seul?'RÉUSSIT(!)':'non','| solution:',win?'réussit':'ÉCHOUE','| noyau',star?'oui':'NON','| progression',intact?'intacte':'TOUCHÉE',ok?' OK':' <<<');}
console.log(bad?bad+' problème(s)':'monde 1 : 12/12 OK');process.exitCode=bad?1:0;
