/* monde1.js — non-régression du monde 1 refondu (R30).
   Pour chaque niveau : sans tracé -> doit échouer ; solution de référence -> doit réussir,
   dessinable (hors zones nd) et dans le budget d'encre. Données lues dans levels.js réel. */
require('./load.js');
const X=globalThis.__X;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function inND(LVz,x,y){return (LVz.nd||[]).some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]);}
function drawable(LVz,p){for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i],n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/6));
 for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;if(x<0||x>360||y<0||y>480||inND(LVz,x,y))return false;}}return true;}
function run(i,strokes){X.loadLevel(i);for(const p of strokes)X.S.strokes.push({pts:p,len:plen(p),birth:0,mat:0});
 X.qpBuild();X.S.mode='run';for(let f=0;f<900&&X.S.mode==='run';f++)X.physics();return {ok:X.S.mode==='success',star:X.S.gotStar};}
const REF={
 0:[[[34,90],[95,124]]],
 1:[[[148,192],[242,238]]],
 2:[[[300,200],[200,330]]],
 3:[[[18,110],[130,170]],[[330,280],[220,400]]],
 4:[[[280,240],[270,430]]],
 5:[[[10,360],[268,440]]],
 6:[[[70,236],[39,211]]],
 7:null, // cherché ci-dessous : tremplin droit
 8:[[[34,54],[82,40]]],
 9:null, // cherché ci-dessous : rampe naturelle
 10:[[[150,106],[206,163]]],
 11:[[[30,58],[58,62]],[[192,160],[262,182]],[[345,205],[155,445]]]
};
function find(i,box){const L=X.LEVELS[i];for(let sx=box[0];sx<=box[1];sx+=4)for(let sy=box[2];sy<=box[3];sy+=6)for(let ex=box[4];ex<=box[5];ex+=6)for(let ey=box[6];ey<=box[7];ey+=8){
 const p=[[sx,sy],[ex,ey]];if(!drawable(L,p)||plen(p)>L.ink)continue;if(run(i,[p]).ok)return [p];}return null;}
const TOL=require('./tolerance.js');
function findRobust(i,box){const LVx=X.LEVELS[i];let best=null;
 for(let sx=box[0];sx<=box[1];sx+=8)for(let sy=box[2];sy<=box[3];sy+=12)for(let ex=box[4];ex<=box[5];ex+=12)for(let ey=box[6];ey<=box[7];ey+=16){
  const p=[[sx,sy],[ex,ey]];if(!drawable(LVx,p)||plen(p)>LVx.ink||!run(i,[p]).ok)continue;const t=TOL(i,[p],4);if(!best||t>best.t)best={p,t};if(t===1)return [best.p];}
 return best?[best.p]:null;}
REF[7]=findRobust(7,[6,40,60,110,90,126,150,300]);
REF[9]=findRobust(9,[6,40,60,110,110,182,100,250]);
let bad=0;
for(let i=0;i<12;i++){const LVi=X.LEVELS[i],s=REF[i];
 const seul=run(i,[]).ok;const ink=s?s.reduce((a,p)=>a+plen(p),0):0;const dess=s&&s.every(p=>drawable(LVi,p));const r=s?run(i,s):{ok:false};
 const tol=s&&r.ok?require('./tolerance.js')(i,s,4):0;const ok=!seul&&r.ok&&dess&&ink<=LVi.ink&&tol>=.5;if(!ok)bad++;
 console.log(String(i+1).padStart(2),LVi.n.padEnd(17),'seul:',seul?'RÉUSSIT (!)':'échoue','| réf:',r.ok?'réussit':'ÉCHOUE','| encre',Math.round(ink)+'/'+LVi.ink,'| dessinable',dess?'oui':'NON','| tolérance ±4px',Math.round(100*tol)+'%',ok?'  OK':'  <<< PROBLÈME');}
console.log(bad?bad+' problème(s)':'monde 1 : 12/12 OK');
process.exitCode=bad?1:0;
