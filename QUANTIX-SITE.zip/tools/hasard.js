/* hasard.js — difficulté À L'ÈRE DE L'ÉDITEUR (R51).
   Avec la ligne droite (et Déplacer, gratuit), la précision du geste ne coûte plus rien : un niveau n'est difficile que si
   peu de traits le résolvent. On mesure donc :
   - P_hasard : part des LIGNES DROITES tirées au hasard dans l'espace traçable (point de départ, angle, longueur, matière)
     qui résolvent le niveau. C'est la probabilité de réussir « en essayant n'importe quoi ». Plus elle est basse, plus il faut
     comprendre.
   - P_ligne  : réussite de la solution optimale tracée à la ligne droite avec une erreur de doigt sur chaque extrémité
     (σ = 3 u, l'accroche et la loupe aident) — doit rester ≥ 90 % : comprendre doit suffire.
   Usage : node hasard.js 25 26 …   (N=tirages, 3000 par défaut)  ·  OUT=fichier.json pour garder les résultats */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const COST={0:1,1:1.9,3:1.7,5:1};
let seed=7;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
function gauss(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
function matsOf(L){const p=L.pal||'S',m=[0];if(p.includes('B'))m.push(1);if(p.includes('A'))m.push(3);if(p.includes('C'))m.push(5);return m;}
function cand(L){return {n:L.n,ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w,
 wind:L.wind,grav:L.grav,mag:L.mag,port:L.port,mov:L.mov,ent:L.ent,gate:L.gate,sup:L.sup,det:L.det,tdil:L.tdil,softball:L.softball};}
function measure(idx,N){
 const L=X.LEVELS[idx],c=cand(L),mats=matsOf(L);let ok=0,tries=0,guard=0;
 while(tries<N&&guard<N*20){guard++;
  const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);if(maxL<15)continue;
  const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];
  if(!D.drawable(c,p))continue;tries++;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok)ok++;}
 let pl=null;
 if(L.optsol&&L.optsol.length){let s=0;const T=60;
  for(let k=0;k<T;k++){const strokes=L.optsol.map(st=>({pts:[st[0],st[st.length-1]].map(q=>[q[0]+gauss()*3,q[1]+gauss()*3]),mat:L.optmat||0}));
   if(LAB.run(idx,c,strokes).ok)s++;}pl=s/T;}
 return {n:L.n,P_hasard:ok/Math.max(1,tries),tirages:tries,P_ligne:pl};}
module.exports={measure};
if(require.main===module){const N=+(process.env.N||3000),out=process.env.OUT,res=out&&fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{};
 for(const a of process.argv.slice(2)){const t0=Date.now(),r=measure(+a-1,N);res[a]=r;
  console.log(`#${a} ${r.n.padEnd(22)} P_hasard ${(r.P_hasard*100).toFixed(2).padStart(6)} %  (${r.tirages} lignes)  P_ligne ${r.P_ligne===null?'—':Math.round(r.P_ligne*100)+' %'}  ${Math.round((Date.now()-t0)/1000)} s`);
  if(out)fs.writeFileSync(out,JSON.stringify(res,null,1));}}
