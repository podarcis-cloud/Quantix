/* constance.js — P8 du cahier : une machine doit mener au bout quelle que soit l'entrée. On lance 200 entrées différentes
   (traits de départ tirés dans les « boîtes » de la fiche) et on compte celles qui, une fois dans la machine, arrivent.
   Usage : node constance.js <fiche> <niveau> '<paramètres>'                                                 */
const D=require('./design.js'),LAB=require('./lab.js'),F=require('./fiches/'+process.argv[2]+'.js'),slot=+process.argv[3]-1,P=JSON.parse(process.argv[4]);
const c=F.gen(P);c.ink=999;let seed=11;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
const B=F.boxes(P)[0],FA={};let SH=0;let enter=0,win=0,tries=0;const fr=[];
while(enter<200&&tries<40000){tries++;const x=B.x[0]+rnd()*(B.x[1]-B.x[0]),y=B.y[0]+rnd()*(B.y[1]-B.y[0]),a=B.a[0]+rnd()*(B.a[1]-B.a[0]),l=B.l[0]+rnd()*(B.l[1]-B.l[0]),
 p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];if(!D.drawable(c,p))continue;
 const r=LAB.run(slot,c,[{pts:p,mat:F.mat||0}]);if(!r.tr.some(q=>q[1]>(+process.env.EY||140)&&q[1]<(+process.env.EY2||9999)&&Math.abs(q[0]-(+process.env.EX||180))<(+process.env.ER||30)))continue;enter++;if(r.ok){win++;fr.push(r.tr.length);}else{if(process.env.V&&!SH){SH=1;console.log('exemple',JSON.stringify(p),JSON.stringify(r.tr.filter((_,i)=>i%8===0).map(q=>q.map(Math.round))));}const q=r.tr[r.tr.length-1],k=Math.round(q[0]/30)*30+','+Math.round(q[1]/30)*30;FA[k]=(FA[k]||0)+1;}}
fr.sort((a,b)=>a-b);
if(process.env.V)console.log('lieux d’échec',JSON.stringify(FA));
console.log(`${process.argv[2]} ${JSON.stringify(P)} : ${win}/${enter} arrivées (${Math.round(100*win/Math.max(1,enter))} %) · durée médiane ${fr[fr.length>>1]} images, 90 % sous ${fr[Math.floor(fr.length*.9)]}`);
