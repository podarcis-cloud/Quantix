# Curseur onde de temps + poussière (R351) — serveur local 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1000)
    pg.evaluate("(()=>{const st=QUANTONE.state,w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));st.strokes=[{layer:0,pts:w(40,(t,i)=>[.1+.5*t,.5+.2*Math.sin(t*6.28),i*30])},{layer:2,pts:w(30,(t,i)=>[.3+.5*t,.65+.1*Math.sin(t*5+1),i*30])},{layer:4,pts:w(40,(t,i)=>[.02+.96*t,.885+.04*Math.sin(t*12.6+.4),i*4.5])}];})()")
    chk(pg.evaluate("!!window.QPULSE"),'module présent')
    pg.click('#bPlay');pg.wait_for_timeout(2500)
    mx=0
    for k in range(10):
        mx=max(mx,pg.evaluate("QPULSE.dust()"));pg.wait_for_timeout(150)
    chk(mx>0,'poussière émise par les notes (max %d)'%mx)
    pg.screenshot(path='/tmp/pouls-q.png')
    chk(mx<400,'poussière bornée')
    pg.click('#bPlay');pg.wait_for_timeout(800)
    pg.click('#bPlay');pg.wait_for_timeout(1200)
    chk(pg.evaluate("document.getElementById('bPlay').textContent")!='Listen','relance OK')
    lv=pg.evaluate("QUANTONE.level()");chk(lv>=0,'moteur répond')
print('RÉSULTAT',sum(res),'/',len(res),errs[:2])
