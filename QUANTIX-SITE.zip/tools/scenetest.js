const fs=require('fs'),re=/id="([A-Za-z0-9_-]+)"/g;
const html=fs.readFileSync('quantix-R27.html','utf8');
const IDS=new Set(); let m; while((m=re.exec(html)))IDS.add(m[1]);
const store={};
function ctx2d(){
  const grad={addColorStop(){}};
  const o={canvas:{width:720,height:960},
    fillStyle:'',strokeStyle:'',lineWidth:1,globalAlpha:1,font:'',lineCap:'',lineJoin:'',
    shadowColor:'',shadowBlur:0,textAlign:'',
    createRadialGradient(){return grad;},createLinearGradient(){return grad;},
    clearRect(){},fillRect(){},strokeRect(){},beginPath(){},moveTo(){},lineTo(){},
    arc(){},quadraticCurveTo(){},closePath(){},fill(){},stroke(){},save(){},restore(){},
    translate(){},scale(){},rotate(){},setTransform(){},clip(){},rect(){},
    setLineDash(){},fillText(){},measureText(){return{width:10};},drawImage(){}};
  return o;
}
function fake(id){const c=ctx2d();const o={id,style:{setProperty(){}},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(sel){/*QSA_REAL*/return (sel==='i')?[{className:''},{className:''},{className:''}]:[];},getBoundingClientRect(){return{left:0,top:0,width:360,height:480};},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return c;},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.window={matchMedia:()=>({matches:false}),devicePixelRatio:2,addEventListener(){},ResizeObserver:null};
global.navigator={};
global.document={getElementById:id=>IDS.has(id)?(store[id]||(store[id]=fake(id))):null,
 addEventListener(){},documentElement:fake('root')};
let frames=[];
global.Audio=function(src){return {src:src,preload:'',volume:1,currentTime:0,
 setAttribute(){},pause(){},play(){return Promise.resolve();}};};
global.Image=function(){return {set src(v){this._src=v;this._ok=false;},get src(){return this._src;}};};
global.requestAnimationFrame=f=>{frames.push(f);};
require('./testq.js');
const X=global.__X;
console.log('chargement : ok');
// passer en écran de jeu et faire tourner la boucle
store['app'].dataset.screen='game';
let err=null,n=0;
try{
  for(let i=0;i<12;i++){ const q=frames; frames=[]; q.forEach(f=>{n++;f(16.7*i);}); }
}catch(e){err=e;}
console.log(err?('ERREUR DANS LA BOUCLE : '+err.message+'\n'+err.stack.split('\n')[1].trim()):'boucle de rendu : '+n+' frames, aucune erreur');
if(!err){
  // et pendant une simulation, avec tracé
  X.loadLevel(0);
  X.S.strokes.push({pts:[[24,80],[250,430]],len:200,birth:0,mat:0});
  X.qpBuild(); X.S.mode='run';
  try{ for(let i=0;i<40;i++){const q=frames;frames=[];q.forEach(f=>f(16.7*i));} }
  catch(e){err=e;console.log('ERREUR EN SIMULATION : '+e.message+'\n'+e.stack.split('\n')[1].trim());}
  if(!err)console.log('simulation avec tracé : aucune erreur');
}
