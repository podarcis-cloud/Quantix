/* forge.js — FORGE DE NIVEAUX (R56) : génère des niveaux candidats et ne garde que ceux qui passent tous les critères
   de la méthode R51 en une seule passe, sans intervention :
     1. la balle échoue sans trait ;
     2. P_hasard (1 trait) dans la cible de la position — ou, en mode deux traits, P_hasard à 1 trait ≈ 0 et
        P_hasard à 2 traits dans la cible ;
     3. 0 réussite au hasard quand la mécanique du monde est ramenée à de la structure (mondes ≥ 2) ;
     4. une solution que l'on réussit à la ligne droite (P_ligne ≥ 0,85) ;
     5. un noyau traversé par 15 à 35 % des solutions, pris par la solution retenue.
   Usage : OUT=forge.json SECS=200 node forge.js <n° de niveau> [2]   (2 = niveau à deux traits)
   Le résultat (géométrie, solution, noyau, mesures) est écrit dans OUT ; slotwrite.py l'installe dans levels.js. */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const COST={0:1,1:1.9,3:1.7,4:1};
const TGT=p=>p<=2?.04:p<=5?.015:p<=9?.005:.002;
const MINT=p=>p<=2?.01:p<=5?.004:p<=9?.001:0;   /* plancher : un début de monde ne doit pas être plus dur qu'une fin */
let seed=+(process.env.SEED||Date.now()%100000);const seed0=seed;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
const ri=(a,b)=>a+Math.floor(rnd()*(b-a+1)),rf=(a,b)=>a+rnd()*(b-a);
function gauss(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
const MATS={1:[0,0,0,2],2:[1,1,0,2],3:[3,3,0,2],4:[4,4,0,2],5:[0,0,2,1],6:[0,0,2,1],7:[0,0,2],8:[0,0,2,1],9:[0,0,2],10:[0,2,5],11:[0,0,2]};
function gen(wd,pos){
 const c={n:'forge',ink:ri(180,380),ball:[ri(30,330),ri(30,110)],w:[],nd:[]};
 const side=['R','L','B'][ri(0,2)],cw=ri(64,110),cx=ri(10,350-cw),cy=ri(220,460);c.cup=[cx,cy,cw,side];
 const nw=ri(2,4),mats=MATS[wd]||[0];
 for(let k=0;k<nw;k++){const x=ri(10,330),y=ri(120,440),L=ri(60,200),a=rf(-1.05,1.05)*(rnd()<.5?1:-1),m=mats[ri(0,mats.length-1)];
  const x2=Math.round(Math.max(4,Math.min(356,x+Math.cos(a)*L))),y2=Math.round(Math.max(30,Math.min(476,y+Math.sin(a)*L)));
  c.w.push([x,y,x2,y2,m]);}
 if(wd===4){ /* glace : rien ne freine — la balle va loin. Bassin lointain et plus bas, une pente de glace sous la balle ;
     sur de la structure, la balle s'arrête avant : la glace est indispensable */
  const bx=ri(30,110),by=ri(60,170),flip=rnd()<.5;c.ball=[flip?360-bx:bx,by];
  const cw2=ri(60,96),cy2=Math.min(462,by+ri(70,170)),cx2=flip?ri(8,120):ri(230,352-cw2);c.cup=[cx2,cy2,cw2,flip?'L':'R'];
  const px=c.ball[0]+(flip?20:-20),py=by+ri(25,50),pl=ri(170,280),pa=(flip?Math.PI-rf(.03,.14):rf(.03,.14));   /* pente douce : sur de la structure la balle s'arrête, sur la glace elle file */
  c.w.unshift([px,py,Math.round(Math.max(4,Math.min(356,px+Math.cos(pa)*pl))),Math.round(Math.max(30,Math.min(476,py+Math.sin(pa)*pl))),4]);}
 else if(wd===2||wd===3){ /* principe d'énergie (handbook §11 quinquies) : bassin plus haut que le départ, une plaque de la mécanique
     sous la balle — seule la mécanique peut apporter l'énergie qui manque */
  const by=ri(170,320),bx=ri(40,320);c.ball=[bx,by];
  const cy2=Math.max(120,by-ri(20,110)),cw2=ri(64,100),cx2=bx<180?ri(200,350-cw2):ri(10,160-cw2+60);c.cup=[Math.max(4,Math.min(356-cw2,cx2)),cy2,cw2,cx2>bx?'R':'L'];
  const m=wd===2?1:(wd===3?3:4),py=Math.min(470,by+ri(50,130)),px=Math.max(10,Math.min(300,bx+ri(-90,40))),pl=ri(60,140),pa=rf(-.35,.35)+(wd===3?(cx2>bx?-.5:.5):0);
  c.w.unshift([px,py,Math.round(Math.max(4,Math.min(356,px+Math.cos(pa)*pl))),Math.round(Math.max(30,Math.min(476,py+Math.sin(pa)*pl))),m]);}
 if(rnd()<.5){const w=ri(60,140),h=ri(80,240);c.nd.push([ri(0,360-w),ri(0,480-h),w,h]);}
 if(wd===2&&pos>=6&&rnd()<.5)c.pal='SB';if(wd===3&&pos>=5&&rnd()<.5)c.pal='SA';
 if(!c.nd.length)delete c.nd;return c;}
function matsOf(c){const p=c.pal||'S',m=[0];if(p.includes('B'))m.push(1);if(p.includes('A'))m.push(3);return m;}
function line(c,mats){const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,c.ink/(COST[m]||1));if(maxL<15)return null;
 const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15);return {pts:[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]],mat:m};}
function sample(idx,c,N,k,keep){const mats=matsOf(c),wins=[];let ok=0,tries=0,guard=0;
 while(tries<N&&guard<N*30){guard++;const ss=[];let inkU=0,bad=false;
  for(let j=0;j<k;j++){const s=line(c,mats);if(!s||!D.drawable(c,s.pts)){bad=true;break;}inkU+=Math.hypot(s.pts[1][0]-s.pts[0][0],s.pts[1][1]-s.pts[0][1])*(COST[s.mat]||1);ss.push(s);}
  if(bad||inkU>c.ink)continue;tries++;const r=LAB.run(idx,c,ss);if(r.ok){ok++;if(keep&&wins.length<keep)wins.push({ss,tr:r.tr});}}
 return {p:ok/Math.max(1,tries),wins};}
function pLigne(idx,c,ss,T){let s=0;for(let k=0;k<T;k++){const n=ss.map(x=>({pts:x.pts.map(q=>[q[0]+gauss()*3,q[1]+gauss()*3]),mat:x.mat}));if(LAB.run(idx,c,n).ok)s++;}return s/T;}
const num=+process.argv[2],two=process.argv[3]==='2',idx=num-1,L0=JSON.parse(JSON.stringify(X.LEVELS[idx])),wd=L0.wd,pos=idx%12+1,tgt=TGT(pos);
const out=process.env.OUT||'forge.json',res=fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{},t0=Date.now(),tmax=(+process.env.SECS||200)*1000;
/* R61 — critère du COÛT MINIMAL : aucun trait plus court que MINLEN ne doit réussir (sinon un petit bout de trait bien placé
   suffit : le niveau n'a pas de défi). Seuil par position : 1–3 → 40 u, 4–8 → 80 u, 9–12 → 120 u. */
const MINLEN=p=>p<=3?40:p<=8?80:120;
function trivial(idx,c){const mats=matsOf(c);let n=0;for(let k=0;k<1500;k++){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=8+rnd()*(MINLEN(pos)-8);
  const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];if(!D.drawable(c,p))continue;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok)return true;}return false;}
let tried=0,stage={vide:0,cible:0,contournement:0,ligne:0,noyau:0,trivial:0},found=null;
while(Date.now()-t0<tmax&&!found){tried++;const c=gen(wd,pos);
 if(LAB.run(idx,c,[]).ok){stage.vide++;continue;}
 const s1=sample(idx,c,two?500:700,1,two?0:60);
 if(two){if(s1.p>tgt*.5){stage.cible++;continue;}}else if(s1.p<MINT(pos)*.6||s1.p===0||s1.p>tgt*1.6){stage.cible++;continue;}
 let s=s1;if(two){s=sample(idx,c,2500,2,40);if(s.p===0||s.p>tgt*1.6){stage.cible++;continue;}}
 if(wd>=2&&wd!==4&&sample(idx,LAB.strip(c),600,1,0).p>0){stage.contournement++;continue;}   /* glace : c'est un obstacle (on ne freine plus), pas une aide — pas de test de contournement */
 let sol=null;for(const w of s.wins.slice(0,25)){if(new Set(w.ss.map(x=>x.mat)).size>1)continue;   /* optsol n'a qu'une matière */
  const pl=pLigne(idx,c,w.ss,16);if(!sol||pl>sol.pl)sol={ss:w.ss,pl,tr:w.tr};if(sol.pl>=.95)break;}
 if(!sol||sol.pl<.85){stage.ligne++;continue;}
 /* la mécanique doit servir : la solution retenue échoue quand on la remplace par de la structure */
 if(wd>=2&&wd!==4&&LAB.run(idx,LAB.strip(c),sol.ss.map(x=>({pts:x.pts,mat:0}))).ok){stage.contournement++;continue;}
 /* élagage : on retire les murs qu'aucune solution ne touche (décor inutile), puis on revérifie */
 const near=(tr,w)=>tr.some(q=>{const ax=w[2]-w[0],ay=w[3]-w[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((q[0]-w[0])*ax+(q[1]-w[1])*ay)/l)):0;return Math.hypot(q[0]-w[0]-u*ax,q[1]-w[1]-u*ay)<15;});
 const used=c.w.filter(w=>s.wins.some(x=>near(x.tr,w)));
 if(used.length&&used.length<c.w.length){const c2=Object.assign({},c,{w:used});
  if(!LAB.run(idx,c2,[]).ok&&LAB.run(idx,c2,sol.ss).ok)c.w=used;}
 if(wd>=2&&!c.w.some(w=>[1,3,4].includes(w[4]))&&!(c.pal||'S').match(/[AB]/)){stage.contournement++;continue;}
 /* glace : la solution doit vraiment glisser sur la glace (au moins 25 images au contact) */
 if(wd===4){const ice=c.w.filter(w=>w[4]===4);let cnt=0;for(const q of sol.tr)if(ice.some(w=>near([q],w)))cnt++;if(cnt<25){stage.contournement++;continue;}}
 const st=LAB.star({wins:s.wins.map(w=>({tr:w.tr}))},[0,20,360,470]);if(!st){stage.noyau++;continue;}
 c.star=[st.x,st.y];let r=LAB.run(idx,c,sol.ss);
 if(!r.ok||!r.star){const q=sol.tr[Math.floor(sol.tr.length*.45)];c.star=[Math.round(q[0]),Math.round(q[1])];r=LAB.run(idx,c,sol.ss);if(!r.ok||!r.star){stage.noyau++;continue;}}
 if(trivial(idx,c)){stage.trivial++;continue;}
 /* confirmation à grande échelle */
 const pf=sample(idx,c,two?6000:3000,two?2:1,0).p,p1=two?sample(idx,c,2000,1,0).p:null;
 if(pf===0||pf>tgt||(!two&&pf<MINT(pos))||(two&&p1>tgt*.5)){stage.cible++;continue;}
 found={c,optsol:sol.ss.map(x=>x.pts),optmat:sol.ss[0].mat,P_hasard:pf,P_hasard_1trait:p1,P_ligne:sol.pl,deux_traits:two};}
console.log(`#${num} (monde ${wd}, position ${pos}${two?', deux traits':''}) cible ≤ ${(tgt*100).toFixed(1)} % — ${tried} candidats en ${Math.round((Date.now()-t0)/1000)} s — rejets ${JSON.stringify(stage)}`);
if(found){res[process.env.KEYSEED?num+"_"+seed0:num]=found;fs.writeFileSync(out,JSON.stringify(res,null,1));
 console.log(`   TROUVÉ : P_hasard ${(found.P_hasard*100).toFixed(2)} %${two?' (1 trait : '+(found.P_hasard_1trait*100).toFixed(2)+' %)':''} · P_ligne ${Math.round(found.P_ligne*100)} % · balle ${JSON.stringify(found.c.ball)} · bassin ${JSON.stringify(found.c.cup)} · ${found.c.w.length} murs · encre ${found.c.ink}`);}
else console.log('   rien de conforme dans le temps imparti');
