/* lab.js — banc d'essai d'un MONDE entier (candidats au format levels.js).
   Pour chaque candidat :
   - sans trait : doit échouer ;
   - balayage de traits à 1 segment (matière structure, et rebond si pal contient 'B') :
     gagnants AVEC la mécanique, et gagnants SANS elle (plaques fixes ET matière
     rebond du joueur ramenées à de la structure) — ce second nombre doit être 0,
     sinon la mécanique est contournable ;
   - exemples de solutions.
   Usage : const LAB=require('./lab.js'); LAB.report(idx, cand, {grid}) */
const D=require('./design.js');const X=D.X;
const MECA=[1,3,4];                       // rebond, élan, glace : matières « mécanique »
function strip(c){return Object.assign({},c,{w:(c.w||[]).map(s=>[s[0],s[1],s[2],s[3],MECA.includes(s[4])?0:s[4]])});}
function run(idx,c,strokes){                // strokes : [{pts,mat}]
  D.install(idx,c);X.loadLevel(idx);
  for(const s of strokes)X.S.strokes.push({pts:s.pts,len:D.plen(s.pts),birth:0,mat:s.mat||0});
  X.qpBuild();X.S.mode='run';const tr=[];
  for(let f=0;f<900&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}
  return {ok:X.S.mode==='success',star:X.S.gotStar,end:[Math.round(X.S.ball.x),Math.round(X.S.ball.y)],tr};}
const COST={0:1,1:1.9};
function report(idx,c,opt){opt=opt||{};
  const g=Object.assign({x0:0,x1:360,y0:20,y1:470,step:12,da:.35,lens:[25,45,70,100,140,190]},opt.grid||{});
  const mats=(c.pal||'S').includes('B')?[0,1]:[0];
  const out={sansTrait:run(idx,c,[]).ok?'RÉUSSIT SEUL':'échoue',avec:0,sans:0,ex:[],exSans:[],wins:[]};
  const cs=strip(c);
  for(let x=g.x0;x<=g.x1;x+=g.step)for(let y=g.y0;y<=g.y1;y+=g.step)for(let a=0;a<6.283;a+=g.da)for(const L of g.lens)for(const m of mats){
    if(L*COST[m]>c.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(a)*L),Math.round(y+Math.sin(a)*L)]];
    if(!D.drawable(c,p))continue;
    const r=run(idx,c,[{pts:p,mat:m}]);if(r.ok){out.avec++;out.wins.push({pts:p,mat:m,tr:r.tr,star:r.star});if(out.ex.length<3)out.ex.push([p,m]);}
    const rs=run(idx,cs,[{pts:p,mat:0}]);if(rs.ok){out.sans++;if(out.exSans.length<3)out.exSans.push(p);}}
  return out;}
/* noyau : point traversé par 15–35 % des solutions gagnantes */
function star(out,zone){let best=null;const z=zone||[0,0,360,480];
  for(let sx=z[0];sx<=z[2];sx+=6)for(let sy=z[1];sy<=z[3];sy+=6){let h=0;
    for(const w of out.wins)if(w.tr.some(q=>Math.hypot(q[0]-sx,q[1]-sy)<20.5))h++;
    const f=h/out.wins.length;if(f>=.15&&f<=.35&&(!best||Math.abs(f-.25)<Math.abs(best.f-.25)))best={x:sx,y:sy,f:+f.toFixed(2)};}
  return best;}
module.exports={report,star,run,strip,D,X};
