/* ================= COUCHE COSMIQUE v2 — composée pour chaque niveau =================
   Couleurs : jetons du handbook §6 uniquement (matière, élan, noyau, arrivée, danger). */
const CM=[77,215,255],CV=[166,120,255],CG=[255,216,90],CL=[155,235,75],CD=[255,82,82],CW=[234,246,255];
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${a})`;
const PAL={1:[CM,CV],2:[CV,CG],6:[CD,CV],9:[CG,CD],12:[CM,CV,CG]};   // l'humeur de chaque parcours
let DEC={neb:[],helices:[],dust:[],dir:[0,1],pal:[CM,CV]},collapse=0;

/* --- voile : lueurs sur les lieux clés + nébuleuse teintée du niveau --- */
function makeVeil(seed,pal,keys){const c=document.createElement("canvas");c.width=720;c.height=960;const g=c.getContext("2d");g.scale(2,2);
 g.globalCompositeOperation="lighter";
 const blob=(x,y,r,col,a)=>{const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,a));gr.addColorStop(.55,rgba(col,a*.35));gr.addColorStop(1,rgba(col,0));g.fillStyle=gr;g.fillRect(0,0,W,H);};
 for(const k of keys)blob(k.x,k.y,k.r,k.col,k.a);
 for(let i=0;i<8;i++)blob(rand(seed+i)*W,rand(seed+i*3.1)*H,60+rand(seed+i*7.7)*140,pal[i%pal.length],.04+rand(seed+i*1.9)*.07);
 for(let i=0;i<24;i++){const x=rand(seed*2+i)*W,y=rand(seed*3+i)*H,r=20+rand(seed*5+i)*50,col=pal[i%pal.length];
  const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,.05));gr.addColorStop(1,rgba(col,0));
  g.save();g.translate(x,y);g.rotate(Math.atan2(DEC.dir[1],DEC.dir[0])+(rand(i)-.5)*.8);g.scale(2.8,.35);g.translate(-x,-y);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r);g.restore();}
 return c;}

/* --- composition : où poser les hélices sans jamais gêner le jeu --- */
function composeDecor(){
 const seed=cur*17+3,pal=PAL[cur]||[CM,CV];DEC.pal=pal;
 // angle dominant des structures du niveau (pondéré par la longueur), sinon vertical
 let sx=0,sy=0;for(const s of L.w){const dx=s[2]-s[0],dy=s[3]-s[1],a=Math.atan2(dy,dx)*2;const l=Math.hypot(dx,dy);sx+=Math.cos(a)*l;sy+=Math.sin(a)*l;}
 const dom=(sx||sy)?Math.atan2(sy,sx)/2:Math.PI/2;DEC.dir=[Math.cos(dom),Math.abs(Math.sin(dom))+.15];
 // points occupés : structures, bassin, noyau, départ et colonne de chute de la balle
 const occ=[];for(const s of walls){const n=Math.ceil(Math.hypot(s[2]-s[0],s[3]-s[1])/8);for(let k=0;k<=n;k++)occ.push([s[0]+(s[2]-s[0])*k/n,s[1]+(s[3]-s[1])*k/n]);}
 for(let x=ZONE[0];x<=ZONE[0]+ZONE[2];x+=10)for(let y=ZONE[1];y<=ZONE[1]+ZONE[3];y+=12)occ.push([x,y]);
 occ.push(L.star);for(let y=L.ball[1]-10;y<L.ball[1]+140;y+=10)occ.push([L.ball[0],y]);
 const far=(x,y)=>{let m=1e9;for(const p of occ){const d=(p[0]-x)**2+(p[1]-y)**2;if(d<m)m=d;}return Math.sqrt(m);};
 DEC.helices=[];
 for(let h=0;h<3;h++){let best=null;
  for(let k=0;k<420;k++){const cxp=20+rand(seed+h*991+k)*320,cyp=50+rand(seed+h*577+k*1.3)*410;
   const ang=dom+[0,0,.3,-.3,Math.PI/2][Math.floor(rand(seed+k*2.2)*5)],len=110+rand(seed+k*3.7)*150;
   const x0=cxp-Math.cos(ang)*len/2,y0=cyp-Math.sin(ang)*len/2,x1=cxp+Math.cos(ang)*len/2,y1=cyp+Math.sin(ang)*len/2;
   let clear=1e9;for(let q=0;q<=12;q++){const x=x0+(x1-x0)*q/12,y=y0+(y1-y0)*q/12;if(x<-40||x>400||y<-40||y>520){clear=0;break;}clear=Math.min(clear,far(x,y));}
   if(clear<30)continue;const sc=len*Math.min(clear,60);if(!best||sc>best.sc)best={x0,y0,x1,y1,sc,clear};}
  if(!best)break;
  const cA=pal[h%pal.length],cB=pal[(h+1)%pal.length];
  DEC.helices.push({x0:best.x0,y0:best.y0,x1:best.x1,y1:best.y1,amp:Math.min(12,best.clear-16),turns:1.4+Math.hypot(best.x1-best.x0,best.y1-best.y0)/90,
   speed:(h%2?-1:1)*(.022+rand(seed+h)*.014),cA,cB,alpha:.72-h*.12});
  const n=12;for(let q=0;q<=n;q++)occ.push([best.x0+(best.x1-best.x0)*q/n,best.y0+(best.y1-best.y0)*q/n]);}
 // hélice fantôme dans l'axe du niveau, très discrète, en travers du fond
 DEC.ghost={x0:180-Math.cos(dom)*260,y0:240-Math.sin(dom)*260,x1:180+Math.cos(dom)*260,y1:240+Math.sin(dom)*260};
 // voile : naissance au départ, promesse au bassin
 const keys=[{x:L.ball[0],y:L.ball[1],r:110,col:pal[0],a:.14},{x:ZONE[0]+ZONE[2]/2,y:ZONE[1]+24,r:120,col:CL,a:.11}];
 DEC.neb=[makeVeil(seed,pal,keys),makeVeil(seed+31,pal.slice().reverse(),[])];
 // poussière qui dérive dans le sens du parcours
 DEC.dust=[];for(let i=0;i<170;i++){const z=.25+rand(seed+i*2.3)*.75,sp=.06+rand(seed+i*6.1)*.12;
  DEC.dust.push({x:rand(seed+i)*W,y:rand(seed+i*1.7)*H,z,ph:rand(i*4.1)*6.28,vx:DEC.dir[0]*sp,vy:DEC.dir[1]*sp*.6,col:[CW,CW,CW,...pal][i%(3+pal.length)]});}
 collapse=0;}

function cosmicBack(){cx.save();cx.globalCompositeOperation="screen";
 cx.globalAlpha=.8+.18*Math.sin(t*.012);cx.drawImage(DEC.neb[0],Math.sin(t*.0022)*12-8,Math.cos(t*.0017)*9-6,W+16,H+12);
 cx.globalAlpha=.5+.2*Math.sin(t*.009+1.3);cx.drawImage(DEC.neb[1],-Math.sin(t*.0015)*16-12,Math.sin(t*.0021)*11-10,W+24,H+20);cx.restore();}

function stardust(){cx.save();cx.globalCompositeOperation="lighter";
 for(const d of DEC.dust){d.x+=d.vx*d.z;d.y+=d.vy*d.z;
  const dx=d.x-ball.x,dy=d.y-ball.y,dd=dx*dx+dy*dy;if(dd<1600&&dd>1){const r=Math.sqrt(dd),f=(1-r/40)*.9*d.z;d.x+=dx/r*f;d.y+=dy/r*f;}
  if(d.y<-4)d.y=H+4;if(d.y>H+4)d.y=-4;if(d.x<-4)d.x=W+4;if(d.x>W+4)d.x=-4;
  const tw=.45+.55*Math.sin(t*.06*d.z+d.ph),a=(.12+.5*d.z)*tw,s=.5+d.z*1.3;cx.fillStyle=rgba(d.col,a);cx.fillRect(d.x-s/2,d.y-s/2,s,s);
  if(d.z>.93&&tw>.8){cx.strokeStyle=rgba(d.col,a*.6);cx.lineWidth=.6;cx.beginPath();cx.moveTo(d.x-4,d.y);cx.lineTo(d.x+4,d.y);cx.moveTo(d.x,d.y-4);cx.lineTo(d.x,d.y+4);cx.stroke();}}
 cx.restore();}

function helix(x0,y0,x1,y1,amp,turns,speed,cA,cB,alpha,N){N=N||64;
 const dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy),ux=dx/len,uy=dy/len,nx=-uy,ny=ux;const pts=[];
 for(let i=0;i<=N;i++){const s=i/N,ang=s*turns*6.2832+t*speed,bx=x0+dx*s,by=y0+dy*s,o1=Math.sin(ang)*amp,o2=-o1;
  pts.push({s,ang,a:[bx+nx*o1,by+ny*o1],b:[bx+nx*o2,by+ny*o2],da:Math.cos(ang),db:-Math.cos(ang)});}
 const mix=s=>[cA[0]+(cB[0]-cA[0])*s|0,cA[1]+(cB[1]-cA[1])*s|0,cA[2]+(cB[2]-cA[2])*s|0];
 const fade=s=>Math.min(1,s*6,(1-s)*6);   // extrémités qui se dissolvent dans le voile
 cx.save();cx.globalCompositeOperation="lighter";cx.lineCap="round";
 for(let i=0;i<=N;i+=3){const p=pts[i],f=(.35+.65*Math.abs(Math.sin(p.ang)))*fade(p.s);
  const gr=cx.createLinearGradient(p.a[0],p.a[1],p.b[0],p.b[1]);gr.addColorStop(0,rgba(mix(p.s),alpha*.55*f));gr.addColorStop(.5,rgba(mix(p.s),alpha*.12*f));gr.addColorStop(1,rgba(mix(1-p.s),alpha*.55*f));
  cx.strokeStyle=gr;cx.lineWidth=1.1;cx.beginPath();cx.moveTo(p.a[0],p.a[1]);cx.lineTo(p.b[0],p.b[1]);cx.stroke();}
 for(const k of ["a","b"]){const dk=k==="a"?"da":"db";for(let i=1;i<=N;i++){const p=pts[i],q=pts[i-1],d=(p[dk]+1)/2,c=mix(p.s),f=fade(p.s);
  cx.strokeStyle=rgba(c,alpha*(.08+.18*d)*f);cx.lineWidth=4+d*4;cx.beginPath();cx.moveTo(q[k][0],q[k][1]);cx.lineTo(p[k][0],p[k][1]);cx.stroke();
  cx.strokeStyle=rgba(c,alpha*(.25+.75*d)*f);cx.lineWidth=.8+d*1.6;cx.beginPath();cx.moveTo(q[k][0],q[k][1]);cx.lineTo(p[k][0],p[k][1]);cx.stroke();}}
 for(let i=0;i<=N;i+=3){const p=pts[i];for(const k of ["a","b"]){const d=(k==="a"?p.da:p.db)*fade(p.s);if(d<.2)continue;const c=mix(p.s);
  const gr=cx.createRadialGradient(p[k][0],p[k][1],0,p[k][0],p[k][1],5);gr.addColorStop(0,rgba(CW,alpha*.9*d));gr.addColorStop(.35,rgba(c,alpha*.6*d));gr.addColorStop(1,rgba(c,0));
  cx.fillStyle=gr;cx.fillRect(p[k][0]-5,p[k][1]-5,10,10);}}
 cx.restore();}

let shoot=null;
function shootingStar(){if(!shoot&&t%60===0&&rand(t/60+cur)>.9)shoot={x:rand(t)*W*.8,y:rand(t*1.3)*H*.35,life:1,vx:3.6,vy:1.4};
 if(!shoot)return;shoot.x+=shoot.vx;shoot.y+=shoot.vy;shoot.life-=.02;
 const tx=shoot.x-shoot.vx*14,ty=shoot.y-shoot.vy*14,gr=cx.createLinearGradient(tx,ty,shoot.x,shoot.y);gr.addColorStop(0,rgba(CW,0));gr.addColorStop(1,rgba(CW,.8*shoot.life));
 cx.save();cx.globalCompositeOperation="lighter";cx.strokeStyle=gr;cx.lineWidth=1.6;cx.lineCap="round";cx.beginPath();cx.moveTo(tx,ty);cx.lineTo(shoot.x,shoot.y);cx.stroke();cx.restore();
 if(shoot.life<=0||shoot.x>W+20)shoot=null;}

function cosmicMid(){stardust();const g=DEC.ghost;helix(g.x0,g.y0,g.x1,g.y1,30,2,.011,DEC.pal[0],DEC.pal[DEC.pal.length-1],.14,90);
 for(const h of DEC.helices)helix(h.x0,h.y0,h.x1,h.y1,h.amp,h.turns,h.speed,h.cA,h.cB,h.alpha);shootingStar();}

/* ================= NOYAU QUANTIQUE — nuage de points bistable =================
   Référence : illusions bistables (nuages de points en rotation 3D, sans indice de
   profondeur : le sens de rotation est ambigu → métaphore de la superposition).
   Sphère de Fibonacci (dégradé rose → violet → cyan, comme la référence) ceinte d'un
   anneau de points or → vert. Rayon visuel ~18 u (capture réelle : R+10 = 20,5 u).
   Capture : le nuage s'effondre en un point (la mesure fige l'état), puis éclate. */
const QS=[],QT=[];
for(let i=0;i<150;i++){const y=1-2*(i+.5)/150,r=Math.sqrt(1-y*y),a=i*2.39996;QS.push([Math.cos(a)*r,y,Math.sin(a)*r]);}
for(let i=0;i<90;i++){const a=i/90*6.2832,b=(i*7%90)/90*6.2832;QT.push([(1+.16*Math.cos(b))*Math.cos(a),.16*Math.sin(b),(1+.16*Math.cos(b))*Math.sin(a)]);}
const QPK=[242,160,200];   // rose (nuance du danger adoucie vers le violet)
function rot(p,ax,ay){let [x,y,z]=p;let c=Math.cos(ay),s=Math.sin(ay);[x,z]=[x*c+z*s,-x*s+z*c];c=Math.cos(ax);s=Math.sin(ax);[y,z]=[y*c-z*s,y*s+z*c];return [x,y,z];}
function drawQuantum(){const st=L.star;
 if(gotStar){if(collapse<1){collapse+=.045;const k=1-collapse;cx.save();cx.globalCompositeOperation="lighter";
   cx.strokeStyle=rgba(CM,k);cx.lineWidth=1.6;cx.beginPath();cx.arc(st[0],st[1],3+collapse*42,0,6.28);cx.stroke();
   cx.strokeStyle=rgba(CV,k*.7);cx.beginPath();cx.arc(st[0],st[1],2+collapse*26,0,6.28);cx.stroke();cx.restore();}return;}
 cx.save();cx.translate(st[0],st[1]);cx.globalCompositeOperation="lighter";
 // halo de probabilité
 let gr=cx.createRadialGradient(0,0,0,0,0,24);gr.addColorStop(0,rgba(CV,.22));gr.addColorStop(.6,rgba(CM,.06));gr.addColorStop(1,rgba(CM,0));cx.fillStyle=gr;cx.fillRect(-24,-24,48,48);
 // sphère : projection orthographique, taille et opacité UNIFORMES (aucun indice de profondeur → bistable)
 const Rs=10.5,ay=t*.021,ax=.35;
 for(const p of QS){const q=rot(p,ax,ay),f=(p[1]+1)/2;
  const c=f>.5?[QPK[0]+(CV[0]-QPK[0])*(1-f)*2|0,QPK[1]+(CV[1]-QPK[1])*(1-f)*2|0,QPK[2]+(CV[2]-QPK[2])*(1-f)*2|0]
              :[CV[0]+(CM[0]-CV[0])*(.5-f)*2|0,CV[1]+(CM[1]-CV[1])*(.5-f)*2|0,CV[2]+(CM[2]-CV[2])*(.5-f)*2|0];
  cx.fillStyle=rgba(c,.85);cx.fillRect(q[0]*Rs-.7,q[1]*Rs-.7,1.4,1.4);}
 // anneau (orbite) : autre axe, sens opposé
 const Rt=17.5,ay2=-t*.017,ax2=1.15+Math.sin(t*.004)*.2;
 for(let i=0;i<QT.length;i++){const q=rot(QT[i],ax2,ay2),f=i/QT.length;
  const c=[CG[0]+(CL[0]-CG[0])*f|0,CG[1]+(CL[1]-CG[1])*f|0,CG[2]+(CL[2]-CG[2])*f|0];
  cx.fillStyle=rgba(c,.8);cx.fillRect(q[0]*Rt-.65,q[1]*Rt-.65,1.3,1.3);}
 // électron sur l'anneau, avec saut quantique occasionnel
 const jump=Math.floor(t/140),flick=(t%140)<5;
 if(!flick){const ph=t*.05+rand(jump*9)*6.28,q=rot([Math.cos(ph),0,Math.sin(ph)],ax2,ay2),ex=q[0]*Rt,ey=q[1]*Rt;
  gr=cx.createRadialGradient(ex,ey,0,ex,ey,6);gr.addColorStop(0,rgba(CW,.95));gr.addColorStop(.4,rgba(CM,.6));gr.addColorStop(1,rgba(CM,0));cx.fillStyle=gr;cx.fillRect(ex-6,ey-6,12,12);}
 cx.restore();}
