import json,re,glob,base64
p=open('/home/claude/preview/structures4.html',encoding='utf-8').read();n=0
def rep(a,b,cnt=1):
    global p,n
    if a not in p: print('ÉCHEC',a[:80]); raise SystemExit(1)
    p=p.replace(a,b,cnt);n+=1
cand={}
src=open('/home/claude/work/tools/w2cand.js',encoding='utf-8').read()
for m in re.finditer(r"(\d+):\{n:'([^']*)',(.*?)\},?\n",src):
    cand[m.group(1)]=m.group(3)
fin=json.load(open('/home/claude/work/tools/w2final.json'))
for f in glob.glob('/home/claude/work/tools/w2f_*.json'):fin.update(json.load(open(f)))
names=re.findall(r"(\d+):\{n:'([^']*)'",src);names=dict(names)
lv=[];keep=[]
for k in sorted(fin,key=int):
    v=fin[k]
    if not v.get('sol') or not v.get('star') or (v.get('tol') or 0)<50:continue
    body=cand[k]
    body=re.sub(r"cup:\[([^\]]*)'(\w)'\]",lambda m:'cup:['+m.group(1)+'"'+m.group(2)+'"]',body).replace("pal:'SB'",'pal:"SB"')
    lv.append(' %d:{n:"%s",%s,star:%s,nd:[],sol:%s,solMat:%d},'%(int(k)+1,names[k],body,json.dumps(v['star']),json.dumps(v['sol'],separators=(',',':')),v.get('mat') or 0))
    keep.append(int(k)+1)
i=p.index('const LV={');j=p.index('};',i)
p=p[:i]+'const LV={\n'+'\n'.join(lv)+'\n'+p[j:]
# décor : remplacer la couche cosmique par la Fonderie
i=p.index('/* ================= COUCHE COSMIQUE v2');j=p.index('function draw(){')
p=p[:i]+open('/tmp/fonderie.js',encoding='utf-8').read()+'\n'+p[j:]
# physique : restitution par matière + trace de chambre à bulles à chaque rebond
rep('function collide(b,ws){let hit=0,spike=false;','function collide(b,ws){let hit=0,spike=false,bounce=0;')
rep('if(vn<0){b.vx-=(1+REST)*vn*nx;b.vy-=(1+REST)*vn*ny;const tx=-ny,ty=nx,vt=(b.vx*tx+b.vy*ty)*FRIC,nv=b.vx*nx+b.vy*ny;',
    'if(vn<0){const E=s[4]===1?1.52:REST,F=s[4]===1?1:FRIC;b.vx-=(1+E)*vn*nx;b.vy-=(1+E)*vn*ny;const tx=-ny,ty=nx,vt=(b.vx*tx+b.vy*ty)*F,nv=b.vx*nx+b.vy*ny;if(s[4]===1&&-vn>bounce)bounce=-vn;')
rep(' return {hit,spike};}',' return {hit,spike,bounce};}')
rep('const r=collide(ball,ws);if(r.spike){','const r=collide(ball,ws);if(r.bounce>1.5&&t-lastBounce>8){lastBounce=t;spawnTrack(ball.x,ball.y,Math.atan2(ball.vy,ball.vx),3+r.bounce*.15,true);burst(ball.x,ball.y,10,"#FFAA3C",2);}if(r.spike){')
rep('for(const p of strokes)for(let i=1;i<p.length;i++)ws.push([p[i-1][0],p[i-1][1],p[i][0],p[i][1],S_]);',
    'for(const p of strokes)for(let i=1;i<p.length;i++)ws.push([p[i-1][0],p[i-1][1],p[i][0],p[i][1],p.mat||S_]);')
# matière du joueur (niveau « Ta plaque ») : bouton acier / rebond, coût ×1,9
rep('function used(){return strokes.reduce((s,p)=>s+plen(p),0)+(drawing?plen(drawing):0);}',
    'let tool=0;function used(){return strokes.reduce((s,p)=>s+plen(p)*(p.mat===1?1.9:1),0)+(drawing?plen(drawing)*(tool===1?1.9:1):0);}')
rep('stage.addEventListener("pointerup",()=>{if(drawing&&drawing.length>1)strokes.push(drawing);drawing=null;});',
    'stage.addEventListener("pointerup",()=>{if(drawing&&drawing.length>1){drawing.mat=tool;strokes.push(drawing);}drawing=null;});')
rep('if(used()+d>L.ink){','if(used()+d*(tool===1?1.9:1)>L.ink){')
rep('<button id="sol">Solution</button>','<button id="sol">Solution</button>\n<button id="mat" style="display:none">Acier</button>')
rep('document.getElementById("sol").onclick=()=>{mode="draw";reset();strokes=L.sol.map(p=>p.map(q=>q.slice()));',
    'const matB=document.getElementById("mat");matB.onclick=()=>{tool=1-tool;matB.textContent=tool?"Rebond ×1,9":"Acier";matB.classList.toggle("on",tool===1);};\ndocument.getElementById("sol").onclick=()=>{mode="draw";reset();strokes=L.sol.map(p=>{const a=p.map(q=>q.slice());a.mat=L.solMat||0;return a;});')
rep('composeDecor();}','composeDecor();matB.style.display=(L.pal||"S").includes("B")?"":"none";tool=0;matB.textContent="Acier";matB.classList.remove("on");}')
# rendu : plaques incandescentes, traits « rebond » du joueur
rep('  for(const s of L.w){if(s[4]===X_)drawSpikes(s);else drawBeam(s);}','  for(const s of L.w){if(s[4]===X_)drawSpikes(s);else if(s[4]===1)drawPlate(s);else drawBeam(s);}')
rep('  for(const p of strokes.concat(drawing?[drawing]:[]))drawRibbon(p);',
    '  for(const p of strokes.concat(drawing?[drawing]:[])){if((p===drawing?tool:p.mat)===1){for(let i=1;i<p.length;i++)drawPlate([p[i-1][0],p[i-1][1],p[i][0],p[i][1],1]);}else drawRibbon(p);}')
rep('for(const s of L.w)oldSeg(s,s[4]===X_?"#FF5252":"#8FB3C9",true);','for(const s of L.w)oldSeg(s,s[4]===X_?"#FF5252":s[4]===1?"#FFAA3C":"#8FB3C9",true);')
rep('<header><h1 id="title">L’établi</h1><span class="num" id="num">Atelier · 12</span></header>','<header><h1 id="title">Fonderie</h1><span class="num" id="num">Fonderie · 13</span></header>')
p=re.sub(r'document\.getElementById\("num"\)\.textContent="Atelier · "\+String\(n\)\.padStart\(2,"0"\);','document.getElementById("num").textContent="Fonderie · "+n;',p)
p=re.sub(r'<p class="hint">.*?</p>','<p class="hint">Monde 2 · <b>La chambre à bulles</b>. Chaque rebond laisse une trace de particule qui s’enroule en spirale ; braises et bulles montent de la fournaise. Le bassin est toujours plus haut que le départ : seul l’orange rend plus d’énergie qu’il n’en reçoit. « Solution » = solution optimale, noyau compris.</p>',p,count=1,flags=re.S)
p=p.replace('load(12);loop();','load(%d);loop();'%keep[0])
p=p.replace('__BG__',base64.b64encode(open('/home/claude/work/assets/img/worlds/w02-fonderie.jpg','rb').read()).decode())
open('/home/claude/preview/fonderie.html','w',encoding='utf-8').write(p)
open('/tmp/fo.js','w',encoding='utf-8').write(re.search(r'<script>(.*)</script>',p,re.S).group(1))
print('remplacements',n,'| niveaux dans l’aperçu :',keep)
