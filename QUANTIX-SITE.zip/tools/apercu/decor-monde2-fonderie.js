/* ================= MONDE 2 · FONDERIE — « La chambre à bulles » =================
   Chambre à bulles : les particules chargées laissent des traces de bulles qui
   s'enroulent en spirales sous un champ magnétique [à sourcer — voir
   QUANTUM_VISUAL_NARRATIVE.md]. Ici, chaque rebond de la balle fait naître une trace.
   Couleurs : jetons rebond #FFAA3C, danger #FF5252, noyau #FFD85A et leurs nuances. */
const CB=[255,170,60],CD=[255,82,82],CG=[255,216,90],CW=[255,240,220],CE=[176,72,28],CM=[77,215,255];
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${a})`;
let DEC={neb:[],tracks:[],bubbles:[],embers:[]},collapse=0,lastBounce=0;

function makeVeil(seed,pal,keys){const c=document.createElement("canvas");c.width=720;c.height=960;const g=c.getContext("2d");g.scale(2,2);
 g.globalCompositeOperation="lighter";
 const blob=(x,y,r,col,a)=>{const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,a));gr.addColorStop(.55,rgba(col,a*.35));gr.addColorStop(1,rgba(col,0));g.fillStyle=gr;g.fillRect(0,0,W,H);};
 for(const k of keys)blob(k.x,k.y,k.r,k.col,k.a);
 for(let i=0;i<8;i++)blob(rand(seed+i)*W,H*.35+rand(seed+i*3.1)*H*.7,70+rand(seed+i*7.7)*140,pal[i%pal.length],.035+rand(seed+i*1.9)*.06);
 return c;}

/* composition par niveau : lueur de fournaise sous les plaques, promesse au bassin */
function composeDecor(){const seed=cur*29+5,pal=[CB,CE,CD,CG];
 const keys=[{x:ZONE[0]+ZONE[2]/2,y:ZONE[1]+24,r:110,col:CG,a:.10}];
 for(const s of L.w)if(s[4]===1)keys.push({x:(s[0]+s[2])/2,y:(s[1]+s[3])/2+10,r:90,col:CB,a:.16});
 DEC.neb=[makeVeil(seed,pal,keys),makeVeil(seed+13,[CE,CB],[])];
 DEC.tracks=[];DEC.bubbles=[];DEC.embers=[];
 for(let i=0;i<60;i++)DEC.bubbles.push({x:rand(seed+i)*W,y:rand(seed+i*2.2)*H,r:.6+rand(seed+i*3.3)*1.8,sp:.15+rand(seed+i*4.4)*.35,ph:rand(i)*6.28});
 for(let i=0;i<90;i++)DEC.embers.push({x:rand(seed+i*5.5)*W,y:rand(seed+i*6.6)*H,z:.3+rand(seed+i*7.7)*.7,ph:rand(i*8.8)*6.28});
 collapse=0;}

/* une trace de chambre à bulles : particule chargée qui s'enroule en perdant de l'énergie */
function spawnTrack(x,y,ang,sp,strong){DEC.tracks.push({pts:[[x,y]],x,y,a:ang,v:sp,q:Math.random()<.5?-1:1,
 k:.018+Math.random()*.03,age:0,life:strong?260:190,col:strong?CG:(Math.random()<.5?CB:CW)});}
function stepTracks(){
 if(t%70===0){const side=Math.floor(rand(t)*3);const x=side===0?-5:side===1?W+5:rand(t*1.7)*W,y=side===2?H+5:H*.3+rand(t*2.3)*H*.6;
  spawnTrack(x,y,Math.atan2(H*.5-y,W*.5-x)+(rand(t*3)-.5),2.2+rand(t*4)*1.6,false);}
 for(const tr of DEC.tracks){tr.age++;if(tr.v>.25){tr.a+=tr.q*tr.k*(3/tr.v);tr.v*=.985;tr.x+=Math.cos(tr.a)*tr.v;tr.y+=Math.sin(tr.a)*tr.v;
   if(tr.age%2===0)tr.pts.push([tr.x,tr.y]);if(tr.pts.length>140)tr.pts.shift();}}
 DEC.tracks=DEC.tracks.filter(tr=>tr.age<tr.life);}
function drawTracks(){cx.save();cx.globalCompositeOperation="lighter";
 for(const tr of DEC.tracks){const fade=Math.min(1,(tr.life-tr.age)/60)*Math.min(1,tr.age/6);
  for(let i=0;i<tr.pts.length;i++){const p=tr.pts[i],a=fade*(.25+.65*i/tr.pts.length);cx.fillStyle=rgba(tr.col,a*.8);
   const r=.7+(i%3===0?.6:0);cx.beginPath();cx.arc(p[0],p[1],r,0,6.28);cx.fill();}
  if(tr.pts.length){const h=tr.pts[tr.pts.length-1],gr=cx.createRadialGradient(h[0],h[1],0,h[0],h[1],5);
   gr.addColorStop(0,rgba(CW,.8*fade));gr.addColorStop(1,rgba(tr.col,0));cx.fillStyle=gr;cx.fillRect(h[0]-5,h[1]-5,10,10);}}
 cx.restore();}

function cosmicBack(){cx.save();cx.globalCompositeOperation="screen";
 cx.globalAlpha=.85+.12*Math.sin(t*.02);cx.drawImage(DEC.neb[0],Math.sin(t*.003)*8-4,Math.cos(t*.0025)*6-3,W+8,H+6);
 cx.globalAlpha=.45+.2*Math.sin(t*.013+1);cx.drawImage(DEC.neb[1],-Math.sin(t*.002)*12-8,0,W+16,H);cx.restore();}

function cosmicMid(){stepTracks();drawTracks();
 cx.save();cx.globalCompositeOperation="lighter";
 for(const b of DEC.bubbles){b.y-=b.sp;b.x+=Math.sin(t*.04+b.ph)*.25;if(b.y<-5){b.y=H+5;b.x=rand(t+b.ph*99)*W;}
  cx.strokeStyle=rgba(CW,.22);cx.lineWidth=.7;cx.beginPath();cx.arc(b.x,b.y,b.r,0,6.28);cx.stroke();}
 for(const e of DEC.embers){e.y-=.25+e.z*.5;e.x+=Math.sin(t*.03+e.ph)*.35*e.z;
  const dx=e.x-ball.x,dy=e.y-ball.y,dd=dx*dx+dy*dy;if(dd<1600&&dd>1){const r=Math.sqrt(dd),f=(1-r/40)*1.1*e.z;e.x+=dx/r*f;e.y+=dy/r*f;}
  if(e.y<-4){e.y=H+4;e.x=rand(t+e.ph*77)*W;}
  const tw=.5+.5*Math.sin(t*.09*e.z+e.ph),s=.6+e.z*1.4;cx.fillStyle=rgba(e.z>.7?CG:CB,(.2+.55*e.z)*tw);cx.fillRect(e.x-s/2,e.y-s/2,s,s);}
 cx.restore();}

/* plaque de rebond : fonte au cœur incandescent — surface EXACTEMENT sur la ligne de collision */
function drawPlate(s){const g=geom(s),D=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*D,A[1]+g.ny*D],B2=[B[0]+g.nx*D,B[1]+g.ny*D];
 const heat=.6+.4*Math.sin(t*.05+s[0]*.02);cx.save();
 cx.shadowColor="rgba(0,0,0,.55)";cx.shadowBlur=10;cx.shadowOffsetY=3;
 const gr=cx.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,rgba(CB,.9));gr.addColorStop(.35,"#6A2C12");gr.addColorStop(1,"#1A0C08");
 cx.fillStyle=gr;cx.beginPath();cx.moveTo(A[0],A[1]);cx.lineTo(B[0],B[1]);cx.lineTo(B2[0],B2[1]);cx.lineTo(A2[0],A2[1]);cx.closePath();cx.fill();cx.shadowColor="transparent";
 cx.save();cx.clip();cx.strokeStyle=rgba(CB,.28*heat);cx.lineWidth=2;
 for(let q=((t*.4)%14)-14;q<g.len+14;q+=14){const x=A[0]+g.ux*q,y=A[1]+g.uy*q;cx.beginPath();cx.moveTo(x,y);cx.lineTo(x+g.nx*D+g.ux*5,y+g.ny*D+g.uy*5);cx.stroke();}
 cx.restore();
 cx.fillStyle=rgba(CG,.9);for(let q=10;q<g.len-6;q+=30){cx.beginPath();cx.arc(A[0]+g.ux*q+g.nx*D*.6,A[1]+g.uy*q+g.ny*D*.6,1.6,0,6.28);cx.fill();}
 cx.lineCap="round";cx.shadowColor=rgba(CB,1);cx.shadowBlur=10+8*heat;cx.strokeStyle=rgba(CB,1);cx.lineWidth=3.6;
 cx.beginPath();cx.moveTo(A[0],A[1]);cx.lineTo(B[0],B[1]);cx.stroke();cx.shadowBlur=0;
 cx.strokeStyle=rgba(CW,.85);cx.lineWidth=1.1;cx.beginPath();cx.moveTo(A[0]-g.nx,A[1]-g.ny);cx.lineTo(B[0]-g.nx,B[1]-g.ny);cx.stroke();
 cx.restore();}

/* noyau : capsule de points bistable (référence vidéo 1), orange → or, anneau de braise */
const QS=[],QT=[];
for(let i=0;i<170;i++){const u=i/170,a=i*2.39996;let y=u*2-1;const cap=.55;let x,z,r=1;
 if(Math.abs(y)<cap){x=Math.cos(a);z=Math.sin(a);}else{const k=(Math.abs(y)-cap)/(1-cap),h=Math.sqrt(Math.max(0,1-k*k));x=Math.cos(a)*h;z=Math.sin(a)*h;y=Math.sign(y)*(cap+k*.55);}
 QS.push([x*.62,y,z*.62]);}
for(let i=0;i<80;i++){const a=i/80*6.2832;QT.push([Math.cos(a),0,Math.sin(a)]);}
function rot3(p,ax,ay,az){let [x,y,z]=p,c,s;c=Math.cos(ay);s=Math.sin(ay);[x,z]=[x*c+z*s,-x*s+z*c];c=Math.cos(ax);s=Math.sin(ax);[y,z]=[y*c-z*s,y*s+z*c];c=Math.cos(az);s=Math.sin(az);[x,y]=[x*c-y*s,x*s+y*c];return [x,y,z];}
function drawQuantum(){const st=L.star;
 if(gotStar){if(collapse<1){collapse+=.045;const k=1-collapse;cx.save();cx.globalCompositeOperation="lighter";
   cx.strokeStyle=rgba(CG,k);cx.lineWidth=1.6;cx.beginPath();cx.arc(st[0],st[1],3+collapse*42,0,6.28);cx.stroke();
   cx.strokeStyle=rgba(CB,k*.7);cx.beginPath();cx.arc(st[0],st[1],2+collapse*26,0,6.28);cx.stroke();cx.restore();}return;}
 cx.save();cx.translate(st[0],st[1]);cx.globalCompositeOperation="lighter";
 let gr=cx.createRadialGradient(0,0,0,0,0,24);gr.addColorStop(0,rgba(CB,.24));gr.addColorStop(.6,rgba(CD,.06));gr.addColorStop(1,rgba(CD,0));cx.fillStyle=gr;cx.fillRect(-24,-24,48,48);
 const Rs=12,ay=t*.02,az=.7+Math.sin(t*.006)*.25;
 for(const p of QS){const q=rot3(p,.25,ay,az),f=(p[1]+1)/2,c=[CB[0]+(CG[0]-CB[0])*f|0,CB[1]+(CG[1]-CB[1])*f|0,CB[2]+(CG[2]-CB[2])*f|0];
  cx.fillStyle=rgba(c,.85);cx.fillRect(q[0]*Rs-.7,q[1]*Rs-.7,1.4,1.4);}
 const Rt=18,ay2=-t*.018;
 for(let i=0;i<QT.length;i++){const q=rot3(QT[i],1.25,ay2,az);cx.fillStyle=rgba(i%2?CD:CB,.7);cx.fillRect(q[0]*Rt-.6,q[1]*Rt-.6,1.2,1.2);}
 const ph=t*.05,q=rot3([Math.cos(ph),0,Math.sin(ph)],1.25,ay2,az);
 if((t%150)>5){gr=cx.createRadialGradient(q[0]*Rt,q[1]*Rt,0,q[0]*Rt,q[1]*Rt,6);gr.addColorStop(0,rgba(CW,.95));gr.addColorStop(1,rgba(CB,0));cx.fillStyle=gr;cx.fillRect(q[0]*Rt-6,q[1]*Rt-6,12,12);}
 cx.restore();}
