/* DOM strict : getElementById renvoie null si l'id n'existe pas dans le HTML,
   exactement comme le navigateur. On y ajoute les écrans et panneaux réels. */
require('./load.js');
const {store}=require('./load.js');
console.log('chargement : aucune erreur');
const $=id=>store[id];
const clicks=['hCont','hLev','hZen','hDrop','hSet','bPlay','bClear','bUndo','bSlow','gPause','gBack',
 'mapBack','lvClose','setClose','pResume','pRestart','pLevels','pSet','pHome','rNext','rScrub','auTest'];
/* hDrop injecte 'dropGo' par innerHTML : le faux DOM ne parse pas les id créés
   ainsi (§9.5 du handbook), donc son clic déclenchera une erreur ici même s'il
   fonctionne en vrai navigateur. Attendu, pas un bug du jeu. */
let bad=[];
for(const id of clicks){
  const el=$(id);
  if(!el||!el.onclick){bad.push(id+' (pas de gestionnaire)');continue;}
  try{el.onclick.call(el,{});}catch(e){bad.push(id+' → '+e.message+(id==='hDrop'?' [attendu, cf. §9.5]':''));}
}
console.log(bad.length?('gestionnaires en échec :\n  '+bad.join('\n  ')):'tous les boutons : aucune exception');
