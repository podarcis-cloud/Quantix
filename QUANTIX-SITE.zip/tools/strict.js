/* DOM strict : getElementById renvoie null si l'id n'existe pas dans le HTML,
   exactement comme le navigateur. On y ajoute les écrans et panneaux réels. */
const fs=require('fs'),re=/id="([A-Za-z0-9_-]+)"/g;
const html=fs.readFileSync('quantix-R27.html','utf8');
const IDS=new Set(); let m; while((m=re.exec(html)))IDS.add(m[1]);
const store={};
function fake(id){const o={id,style:{setProperty(){}},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(sel){/*QSA_REAL*/return (sel==='i')?[{className:''},{className:''},{className:''}]:[];},getBoundingClientRect(){return{left:0,top:0}},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>k==='createRadialGradient'||k==='createLinearGradient'?()=>({addColorStop(){}}):()=>{}})},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.window={matchMedia:()=>({matches:false}),devicePixelRatio:2,addEventListener(){},ResizeObserver:null};
global.navigator={};
global.document={getElementById:id=>IDS.has(id)?(store[id]||(store[id]=fake(id))):null,
 addEventListener(){},documentElement:fake('root')};
global.Audio=function(src){return {src:src,preload:'',volume:1,currentTime:0,
 setAttribute(){},pause(){},play(){return Promise.resolve();}};};
global.Image=function(){return {set src(v){this._src=v;this._ok=false;},get src(){return this._src;}};};
global.requestAnimationFrame=()=>{};
let err=null;
try{require('./testq.js');}catch(e){err=e;}
console.log(err?('ERREUR AU CHARGEMENT : '+err.message):'chargement : aucune erreur');
if(err)process.exit(1);
const $=id=>store[id];
const clicks=['hCont','hLev','hZen','hDrop','hSet','bPlay','bClear','bUndo','bSlow','gPause','gBack',
 'mapBack','lvClose','setClose','pResume','pRestart','pLevels','pSet','pHome','rNext','rAgain','rScrub','auTest'];
let bad=[];
for(const id of clicks){
  const el=$(id);
  if(!el||!el.onclick){bad.push(id+' (pas de gestionnaire)');continue;}
  try{el.onclick.call(el,{});}catch(e){bad.push(id+' → '+e.message);}
}
console.log(bad.length?('gestionnaires en échec :\n  '+bad.join('\n  ')):'tous les boutons : aucune exception');
