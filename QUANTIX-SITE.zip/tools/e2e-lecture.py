# R400 : la lueur de lecture parcourt le trait seulement là où passe le curseur réel (plus de boules sur les extrémités)
from playwright.sync_api import sync_playwright
import math
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
JS="""()=>{const c=document.querySelector('#field canvas');const g=c.getContext('2d'),W=c.width,H=c.height,d=g.getImageData(0,0,W,H).data;let n=0,sx=0,mn=1e9,mx=-1;
 for(let y=Math.floor(H*.15);y<H*.9;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4;if(d[i]>225&&d[i+1]>225&&d[i+2]>225){n++;sx+=x;if(x<mn)mn=x;if(x>mx)mx=x;}}
 return {n:n,mx:n?sx/n/W:-1,sp:n?(mx-mn)/W:0}}"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    bx=pg.locator('#field canvas').first.bounding_box();x0,y0,w,h=bx['x'],bx['y'],bx['width'],bx['height']
    pg.mouse.move(x0+w*.08,y0+h*.5);pg.mouse.down()
    for i in range(1,41):pg.mouse.move(x0+w*(.08+.8*i/40),y0+h*(.5-.2*math.sin(i/40*6.28)),steps=1)
    pg.mouse.up();pg.wait_for_timeout(300)
    arret=pg.evaluate(JS);chk(arret['n']<30,'à l’arrêt : aucune lueur blanche sur le trait (%d px)'%arret['n'])
    pg.click('#bPlay');M=[]
    pg.wait_for_timeout(500)
    for k in range(6):
        pg.wait_for_timeout(350);M.append(pg.evaluate(JS))
    print(M)
    chk(sum(1 for m in M if m['n']>25)>=3,'en lecture : une lueur est visible')
    chk(all(m['sp']<.2 for m in M if m['n']>25),'la lueur est localisée (pas de boules aux extrémités)')
    xs=[round(m['mx'],2) for m in M if m['n']>25];chk(len(set(xs))>=3,'la lueur avance avec le temps %s'%xs)
    chk(not er,'aucune erreur %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
