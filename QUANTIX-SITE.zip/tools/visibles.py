"""R249 · visibles.py — scan de lisibilité des éléments jouables.
Pour chaque niveau du monde W : image du niveau (édition) avec l'élément, puis sans lui ; l'écart moyen dans la boîte de
l'élément, moins le bruit d'animation (deux images « avec »), dit s'il se voit. Usage : python3 tools/visibles.py W
Sortie : une ligne JSON par élément dans tools/visibles.jsonl (remplace celles du monde W) + vignettes des faibles."""
import asyncio,sys,json,os
from playwright.async_api import async_playwright
from PIL import Image,ImageChops,ImageStat
W=int(sys.argv[1]);R=os.path.dirname(os.path.abspath(__file__));OUT=R+'/visibles.jsonl';VIG='/tmp/visibles';os.makedirs(VIG,exist_ok=True)
APER='/mnt/user-data/outputs/quantix-apercu-monde11.html'
JS_LIST="""(n)=>{const l=LEVELS[n],E=[];const rect=a=>[a[0],a[1],a[2],a[3]],circ=(x,y,r)=>[x-r,y-r,2*r,2*r],seg=(a,p)=>[Math.min(a[0],a[2])-p,Math.min(a[1],a[3])-p,Math.abs(a[2]-a[0])+2*p,Math.abs(a[3]-a[1])+2*p];
 const A=(k,f)=>{if(Array.isArray(l[k]))l[k].forEach((e,i)=>{try{const b=f(e);if(b&&b.every(v=>isFinite(v)))E.push({k,i,b});}catch(_){}});};
 ['sup','tdil','wind','grav','bf','kick'].forEach(k=>A(k,rect));A('det',e=>circ(e[0],e[1],Math.max(e[2],14)));A('rec',e=>circ(e[0],e[1],e[2]+8));A('mag',e=>circ(e[0],e[1],Math.min(e[2],60)));
 A('well',e=>circ(e[0],e[1],e[3]||30));if(Array.isArray(l.ent))l.ent.forEach((e,i)=>{E.push({k:'ent',i,b:circ(e[0],e[1],20)});E.push({k:'ent',i,b:circ(e[2],e[3],20)});});
 A('gate',e=>seg(e,10));A('port',e=>seg(e,22));A('strings',e=>seg(e,12));A('coil',e=>circ(e[0],e[1],22));A('mov',e=>{const s=e.seg,p=12+(e.amp||0);return [Math.min(s[0],s[2])-(e.ax?p:12),Math.min(s[1],s[3])-(e.ay?p:12),Math.abs(s[2]-s[0])+2*(e.ax?p:12),Math.abs(s[3]-s[1])+2*(e.ay?p:12)];});
 if(l.updraft)E.push({k:'updraft',i:-1,b:rect(l.updraft)});if(l.vortex)E.push({k:'vortex',i:-1,b:circ(l.vortex[0],l.vortex[1],l.vortex[2])});
 if(l.pend)E.push({k:'pend',i:-1,b:circ(l.pend[0],l.pend[1],24)});if(l.spectro)E.push({k:'spectro',i:-1,b:circ(l.spectro.x,l.spectro.y,40)});
 try{if(l.fork&&l.fork.tips)E.push({k:'fork',i:-1,b:[Math.min(l.fork.tips[0][0],l.fork.base[0])-15,l.fork.tips[0][1]-15,Math.abs(l.fork.tips[1][0]-l.fork.tips[0][0])+30,l.fork.base[1]-l.fork.tips[0][1]+30]});
 }catch(_){}
 try{if(l.sling&&l.sling.z)E.push({k:'sling',i:-1,b:rect(l.sling.z)});}catch(_){}
 return E.map(e=>({k:e.k,i:e.i,b:e.b.map(Math.round)}));}"""
async def main():
  async with async_playwright() as p:
    br=await p.chromium.launch();pg=await br.new_page(viewport={'width':390,'height':844},device_scale_factor=int(os.environ.get('DPR','2')));pg.set_default_timeout(90000)
    await pg.route('**/fonts.g*/**',lambda r:r.abort())
    await pg.goto('file://'+APER);await pg.wait_for_timeout(1500)
    await pg.add_style_tag(content='#tcard,.tvl,#tshield,.hvig{display:none!important}')
    idx=await pg.evaluate(f"LEVELS.map((l,i)=>l.wd==={W}?i:-1).filter(i=>i>=0)")
    rows=[]
    async def shot(n,f):
      await pg.evaluate(f"show(vWorld,false);S.zen=false;goto('game');loadLevel({n});");await pg.wait_for_timeout(450)
      await pg.screenshot(path=f);return Image.open(f).convert('RGB')
    LO,HI=(int(sys.argv[2]),int(sys.argv[3])) if len(sys.argv)>3 else (1,12)
    for j,n in enumerate(idx):
      if not (LO<=j+1<=HI): continue
      print('niveau',j+1,flush=True);E=await pg.evaluate(JS_LIST,n)
      if not E: continue
      geo=await pg.evaluate("(()=>{const r=cv.getBoundingClientRect();return [r.left,r.top,r.width/360];})()")
      A=await shot(n,VIG+'/a.png');A2=await shot(n,VIG+'/a2.png')
      for e in E:
        key=e['k'];i=e['i']
        await pg.evaluate(f"(()=>{{window.__sv=JSON.stringify(LEVELS[{n}]['{key}']);const v=LEVELS[{n}]['{key}'];if({i}>=0)v.splice({i},1);else LEVELS[{n}]['{key}']=null;}})()")
        try: B=await shot(n,VIG+'/b.png')
        except Exception as ex:
          print('  bloqué sans %s #%d (niveau %d) : %s'%(key,i,j+1,str(ex)[:60]),flush=True);rows.append({'monde':W,'niveau':j+1,'idx':n,'k':key,'i':i,'vis':-1,'bruit':-1,'score':99,'err':1})
          await pg.reload();await pg.wait_for_timeout(1500);await pg.add_style_tag(content='#tcard,.tvl,#tshield,.hvig{display:none!important}');A=await shot(n,VIG+'/a.png');continue
        await pg.evaluate(f"LEVELS[{n}]['{key}']=JSON.parse(window.__sv)")
        x,y,w,h=e['b'];L0,T0,s=geo;D=int(os.environ.get('DPR','2'));box=(int((L0+max(0,x)*s)*D),int((T0+max(0,y)*s)*D),int((L0+min(360,x+w)*s)*D),int((T0+min(480,y+h)*s)*D))
        if box[2]-box[0]<4 or box[3]-box[1]<4: continue
        ca,ca2,cb=A.crop(box),A2.crop(box),B.crop(box)
        ca.thumbnail((240,240));ca2.thumbnail((240,240));cb.thumbnail((240,240))
        vis=sum(ImageStat.Stat(ImageChops.difference(ca,cb)).mean)/3;noi=sum(ImageStat.Stat(ImageChops.difference(ca,ca2)).mean)/3
        r={'monde':W,'niveau':j+1,'idx':n,'k':key,'i':i,'vis':round(vis,1),'bruit':round(noi,1),'score':round(vis-noi,1)}
        rows.append(r)
        if vis-noi<6: Image.fromarray(__import__('numpy').hstack([__import__('numpy').array(ca),__import__('numpy').array(cb)])).save(f"{VIG}/w{W}n{j+1}_{key}{i}.png")
    await br.close()
  old=[l for l in open(OUT).read().splitlines() if not (json.loads(l)['monde']==W and LO<=json.loads(l)['niveau']<=HI)] if os.path.exists(OUT) else []
  open(OUT,'w').write('\n'.join(old+[json.dumps(r,ensure_ascii=False) for r in rows])+'\n')
  for r in rows: print('Monde %d – niveau %d  %-8s #%d  visibilité %5.1f  bruit %4.1f  %s'%(r['monde'],r['niveau'],r['k'],r['i'],r['vis'],r['bruit'],'FAIBLE' if r['score']<6 else 'ok'))
asyncio.run(main())
