# Bibliothèque de boucles dans Quantone (R380) : bouton à droite de Fichier, projet en cours par défaut
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
SEED="""async()=>{const q=QXIO.build();const mk=(id,name,proj,v)=>({id,name,col:'#72D6D2',proj,ver:v,cr:v,qx:q});
 const db=await new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>r(o.result);});
 const tx=db.transaction('items','readwrite'),os=tx.objectStore('items');os.clear();
 [mk('a1','Pulse A','Projet Alpha',3),mk('a2','Basse A','Projet Alpha',2),mk('b1','Nappe B','Projet Beta',1)].forEach(x=>os.put(x));
 await new Promise(r=>tx.oncomplete=r);localStorage.setItem('qx.proj','Projet Alpha');return true}"""
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(900)
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=[{layer:0,pts:Array.from({length:20},(_,i)=>[.1+i*.04,.4,i*30])}]})()")
    pg.evaluate(SEED);pg.reload();pg.wait_for_timeout(1000)
    chk(pg.locator('#qLibMgr').count()==1,'bouton Bibliothèque présent')
    bx=pg.locator('#qLibMgr').bounding_box();fx=pg.locator('#qFileBtn').bounding_box();lx=pg.locator('#qLibBtn').bounding_box()
    chk(bx['x']>fx['x']+fx['width'] and bx['x']>lx['x'],'il est à droite de Fichier')
    pg.click('#qLibMgr');pg.wait_for_timeout(400)
    rows=pg.locator('#qLibPanel .lr').count()
    chk(rows==2,'par défaut : seulement les boucles du projet en cours (%d lignes)'%rows)
    chk(pg.locator('#qLibPanel canvas').count()==2,'miniature du dessin par boucle')
    pg.click('#qLibPanel [data-p="*"]');pg.wait_for_timeout(200)
    chk(pg.locator('#qLibPanel .lr').count()==3,'« Tous les projets » : 3 boucles')
    pg.click('#qLibPanel [data-p="Projet Beta"]');pg.wait_for_timeout(200)
    chk(pg.locator('#qLibPanel .lr').count()==1,'chip projet Beta : 1 boucle')
    pg.click('#qLibPanel [data-p="Projet Alpha"]');pg.fill('#qLibQ','basse');pg.wait_for_timeout(200)
    chk(pg.locator('#qLibPanel .lr').count()==1,'recherche « basse » : 1 boucle')
    pg.fill('#qLibQ','');pg.wait_for_timeout(200)
    names=pg.evaluate("[...document.querySelectorAll('#qLibPanel .lr .ln b')].map(e=>e.textContent)")
    pg.click('#qLibPanel [data-s="nm"]');pg.wait_for_timeout(150)
    n2=pg.evaluate("[...document.querySelectorAll('#qLibPanel .lr .ln b')].map(e=>e.textContent)")
    chk(names==['Pulse A','Basse A'] and n2==['Basse A','Pulse A'],'tri récent puis par nom %s %s'%(names,n2))
    # dupliquer
    pg.click('#qLibPanel .lr[data-id="a1"] [data-a="dup"]');pg.wait_for_timeout(300)
    chk(pg.locator('#qLibPanel .lr').count()==3,'dupliquer ajoute une copie')
    # supprimer en deux touchers
    pg.click('#qLibPanel .lr[data-id="a2"] [data-a="del"]');pg.wait_for_timeout(100)
    chk(pg.locator('#qLibPanel .lr').count()==3,'un seul toucher ne supprime pas')
    pg.click('#qLibPanel .lr[data-id="a2"] [data-a="del"]');pg.wait_for_timeout(300)
    chk(pg.locator('#qLibPanel .lr').count()==2,'deuxième toucher : supprimée')
    # renommer
    pg.click('#qLibPanel .lr[data-id="a1"] [data-a="ren"]');pg.wait_for_timeout(150)
    pg.fill('#qLibPanel input[data-a="nm"]','Pulse renommée');pg.keyboard.press('Enter');pg.wait_for_timeout(300)
    chk('Pulse renommée' in pg.evaluate("[...document.querySelectorAll('#qLibPanel .lr .ln b')].map(e=>e.textContent)"),'renommer')
    # ouvrir dans Quantone
    pg.evaluate("QUANTONE.state.strokes=[]");pg.click('#qLibPanel .lr[data-id="a1"] [data-a="open"]');pg.wait_for_timeout(400)
    chk(pg.evaluate("QUANTONE.state.strokes.length")>=1 and pg.evaluate("QLIBAPI.id()")=='a1','Ouvrir : la boucle est chargée et devient la boucle en cours')
    chk(not pg.evaluate("QLIBMGR.state().open"),'le panneau se referme après ouverture')
    # Fichier referme le panneau
    pg.click('#qLibMgr');pg.click('#qFileBtn');pg.wait_for_timeout(200)
    chk(not pg.evaluate("QLIBMGR.state().open"),'Fichier referme la bibliothèque')
    # Track : liste des patterns limitée au projet en cours
    pg.evaluate(SEED)
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1500)
    o=pg.evaluate("[...document.querySelectorAll('#patSel option')].map(x=>x.textContent)")
    chk('Pulse A' in o and 'Basse A' in o and 'Nappe B' not in o,'Track : seulement le projet en cours (%s)'%o)
    chk(not any('Voir tous' in x for x in o),'Track : plus d\'option « Voir tous les projets » (projet en cours uniquement)')
    chk(not er,'aucune erreur page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
