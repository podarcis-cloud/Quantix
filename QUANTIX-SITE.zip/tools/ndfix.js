/* ndfix.js N — ferme les raccourcis d'un niveau par des zones interdites (R176).
   1. énumère les traits droits gagnants (même grille que contournements.js) en notant s'ils touchent un élément du niveau ;
   2. cherche jusqu'à 2 rectangles nd qui suppriment tous les gagnants « nus » en gardant le plus de gagnants qui passent
      par la mécanique (≥ 12) ; jamais sur le départ, le bassin, ni à moins de 14 u de la trajectoire de chute initiale.
   Sortie : nd proposé (JSON) + comptes. N = numéro de niveau (1..132). */
require('./load.js');const X=globalThis.__X;const R=10.5;
const src=require('fs').readFileSync(__dirname+'/contournements.js','utf8');
eval(src.slice(src.indexOf('function plen'),src.indexOf('const a=+process.argv[2]')));   /* plen, dseg, shapes, touches, inZ, ok */
const num=+process.argv[2],i=num-1,lv=X.LEVELS[i];X.loadLevel(i);const sh=shapes(lv);
const mat=(lv.optmat!=null)?lv.optmat:((lv.pal||'S').charAt(0)==='B'?1:((lv.pal||'S').charAt(0)==='A'?3:0));const cost={0:1,1:1.9,3:1.7,5:1.4}[mat]||1;
const W=[];const t0=Date.now();
function run(p){X.loadLevel(i);X.S.strokes.push({pts:p,len:plen(p),birth:0,mat});try{X.qpBuild()}catch(e){}X.S.mode='run';const tr=[];
 for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',tr};}
X.loadLevel(i);X.S.mode='run';const fall=[];for(let f=0;f<300&&X.S.mode==='run';f++){X.physics();fall.push([X.S.ball.x,X.S.ball.y]);}
for(let x=6;x<=354;x+=24)for(let y=12;y<=470;y+=24)for(let an=0;an<3.14;an+=.3)for(const Ln of [60,110,170,240,320]){
 if(Ln*cost>lv.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(an)*Ln),Math.round(y+Math.sin(an)*Ln)]];if(!ok(lv,p))continue;
 const r=run(p);if(r.ok)W.push({p,nu:!touches(sh,r.tr)});}
let sd=num*7919+13;const rr=()=>{sd=(sd*16807)%2147483647;return sd/2147483647;};
for(let q=0;q<1800&&Date.now()-t0<150000;q++){const x=rr()*360,y=rr()*470,an=rr()*6.283,Ln=40+rr()*280;if(Ln*cost>lv.ink)continue;
 const p=[[x|0,y|0],[Math.round(x+Math.cos(an)*Ln),Math.round(y+Math.sin(an)*Ln)]];if(!ok(lv,p))continue;const r=run(p);if(r.ok)W.push({p,nu:!touches(sh,r.tr)});}
const nus=W.filter(w=>w.nu),mech=W.filter(w=>!w.nu);
function hits(rc,p){const n=Math.ceil(plen(p)/4);for(let k=0;k<=n;k++){const x=p[0][0]+(p[1][0]-p[0][0])*k/n,y=p[0][1]+(p[1][1]-p[0][1])*k/n;if(inZ(rc,x,y))return true;}return false;}
const cu=lv.cup,cz=[cu[0]-14,cu[1]-70,cu[2]+28,84];
function legal(rc){const b=lv.ball;if(b[0]>rc[0]-14&&b[0]<rc[0]+rc[2]+14&&b[1]>rc[1]-14&&b[1]<rc[1]+rc[3]+14)return false;
 if(rc[0]<cz[0]+cz[2]&&rc[0]+rc[2]>cz[0]&&rc[1]<cz[1]+cz[3]&&rc[1]+rc[3]>cz[1])return false;
 if(fall.some(q=>q[0]>rc[0]-14&&q[0]<rc[0]+rc[2]+14&&q[1]>rc[1]-14&&q[1]<rc[1]+rc[3]+14))return false;return true;}
const C=[];for(let x=0;x<=340;x+=20)for(let y=0;y<=460;y+=20)for(const w of [60,100,160,240])for(const h of [60,100,160,240]){if(x+w>360||y+h>480)continue;const rc=[x,y,w,h];if(legal(rc))C.push(rc);}
function score(set){let n=0,m=0;for(const w of nus)if(set.some(rc=>hits(rc,w.p)))n++;for(const w of mech)if(!set.some(rc=>hits(rc,w.p)))m++;return [n,m];}
let best=null;
for(const a of C){const [n,m]=score([a]);if(m<12)continue;const v=(n===nus.length?1000:0)+n*3+m*.5-a[2]*a[3]/4000;if(!best||v>best.v)best={v,set:[a],n,m};}
if(best&&best.n<nus.length){const base=best.set[0];for(const b of C){const [n,m]=score([base,b]);if(m<12)continue;const v=(n===nus.length?1000:0)+n*3+m*.5-(base[2]*base[3]+b[2]*b[3])/4000;if(v>best.v)best={v,set:[base,b],n,m};}}
console.log(JSON.stringify({num,n:lv.n,gagnants:W.length,nus:nus.length,meca:mech.length,nd_actuel:lv.nd||null,propose:best&&best.set,bloque:best&&best.n,meca_gardes:best&&best.m,s:((Date.now()-t0)/1000|0),ex_meca:mech.slice(0,3).map(w=>w.p)}));
