# Track : appui long sur un bloc → menu, courbe de volume, effets, muet, inverser (R383)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
SETUP="""()=>{const M=MORCEAU,sr=44100,n=sr*2,a=new Float32Array(n);for(let i=0;i<n;i++)a[i]=(i/n)*0.8*Math.sin(i*0.05);
 const b=M.addBlock({name:'Rampe',ch:[a,a],sr:sr,len:2,col:'#4DD7FF'});const P=M.P();
 if(!P.tracks.length)document.getElementById('bAdd').click();
 const c=M.place(b.id,0,0,2);return c.id}"""
RMS="""async()=>{const b=await MORCEAU.exportBuf();const d=b.getChannelData(0),sr=b.sampleRate;
 const f=(a,z)=>{let s=0,k=0;for(let i=Math.floor(a*sr);i<Math.floor(z*sr)&&i<d.length;i++){s+=d[i]*d[i];k++}return Math.sqrt(s/Math.max(1,k))};
 return [f(0,.5),f(.5,1),f(1,1.5),f(1.5,2)]}"""
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(900)
    cid=pg.evaluate(SETUP);pg.wait_for_timeout(300)
    base=pg.evaluate(RMS);chk(base[3]>base[0]*2,'référence : rampe croissante %s'%[round(x,3) for x in base])
    box=pg.locator('.clip').first.bounding_box()
    pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);pg.mouse.down();pg.wait_for_timeout(750)
    chk(pg.locator('#cm.show').count()==1,'appui long : le menu s\'ouvre')
    pg.mouse.up()
    txt=pg.inner_text('#cm');chk('Volume' in txt and 'Effets' in txt and 'Muet' in txt and 'Inverser' in txt,'menu : volume, effets, muet, inverser')
    # court appui : pas de menu
    pg.click('#cm [data-a="x"]');pg.wait_for_timeout(100)
    pg.mouse.move(box['x']+20,box['y']+20);pg.mouse.down();pg.wait_for_timeout(120);pg.mouse.up();pg.wait_for_timeout(150)
    chk(pg.locator('#cm.show').count()==0,'appui court : pas de menu')
    # fondu d'entrée via l'éditeur
    pg.mouse.move(box['x']+box['width']/2,box['y']+30);pg.mouse.down();pg.wait_for_timeout(750);pg.mouse.up()
    pg.click('#cm [data-a="vol"]');pg.wait_for_timeout(200)
    chk(pg.locator('#vcC').count()==1,'éditeur de courbe affiché')
    pg.click('#cm [data-a="fo"]');pg.wait_for_timeout(300)
    vc=pg.evaluate("MORCEAU.P().clips[0].vc");chk(vc and vc[-1][1]==0,'fondu de sortie : dernier point à 0 %s'%vc)
    r=pg.evaluate(RMS);chk(r[3]<base[3]*.6,'rendu : la fin est atténuée %s'%[round(x,3) for x in r])
    # point ajouté au doigt
    cb=pg.locator('#vcC').bounding_box();pg.mouse.click(cb['x']+cb['width']*.5,cb['y']+cb['height']*.9);pg.wait_for_timeout(250)
    n=pg.evaluate("MORCEAU.P().clips[0].vc.length");chk(n>=4,'toucher la courbe ajoute un point (%d points)'%n)
    r2=pg.evaluate(RMS);chk(r2[1]<base[1]*.75,'le creux se retrouve dans le rendu')
    pg.click('#cm [data-a="fl"]');pg.wait_for_timeout(200)
    chk(pg.evaluate("MORCEAU.P().clips[0].vc===undefined"),'« Plat » supprime la courbe')
    pg.click('#cm [data-a="bk"]');pg.wait_for_timeout(150)
    pg.click('#cm [data-a="mute"]');pg.wait_for_timeout(250)
    rm=pg.evaluate(RMS);chk(max(rm)<1e-4,'muet : rendu silencieux')
    pg.click('#cm [data-a="mute"]');pg.wait_for_timeout(200)
    pg.click('#cm [data-a="rev"]');pg.wait_for_timeout(250)
    rr=pg.evaluate(RMS);chk(rr[0]>rr[3]*2 and rr[0]>base[3]*.5,'inverser : la rampe est retournée %s'%[round(x,3) for x in rr])
    pg.click('#cm [data-a="rev"]');pg.wait_for_timeout(200)
    pg.click('#cm [data-a="o+"]');pg.wait_for_timeout(150)
    chk(abs(pg.evaluate("MORCEAU.P().clips[0].rate")-2)<1e-6,'octave + : vitesse ×2')
    pg.click('#cm [data-a="r1"]');pg.wait_for_timeout(150)
    # effets
    pg.click('#cm [data-a="fx"]');pg.wait_for_timeout(200)
    fid=pg.evaluate("QFXE.order.find(i=>QFXE.defs[i].fam==='col')||QFXE.order[0]")
    pg.select_option('#fxSel',fid);pg.wait_for_timeout(300)
    chk(pg.evaluate("(MORCEAU.P().clips[0].fx||[]).length")==1,'effet ajouté au bloc (%s)'%fid)
    rf=pg.evaluate(RMS);diff=sum(abs(a-b) for a,b in zip(rf,base))
    chk(diff>1e-4,'le rendu change avec l\'effet (Δ=%.4f)'%diff)
    pg.click('#cm [data-a="ok"]');pg.wait_for_timeout(200)
    chk('✦' in pg.inner_text('.clip .cn'),'le bloc affiche le repère d\'effet')
    # sauvegarde
    s=pg.evaluate("JSON.stringify(MORCEAU.P().clips[0])");chk('"fx"' in s,'courbe/effets présents dans les données du morceau')
    chk(not er,'aucune erreur JS '+str(er[:2]))
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
