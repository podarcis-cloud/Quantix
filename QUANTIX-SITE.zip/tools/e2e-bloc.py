# Bloc du Morceau = rendu complet de Quantone (R361) — serveur local requis : python3 -m http.server 8765 depuis la racine
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
JS="""async()=>{
 const Q=QUANTONE,st=Q.state;
 QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:100,echo:0,rev:0,breath:0,clar:.45,drone:0,grain:0,swing:0},strokes:[
  {l:0,p:[[.03,.5],[.3,.25],[.55,.7],[.8,.3],[.97,.55],[.55,.85],[.03,.5]]},
  {l:1,p:[[.05,.8],[.5,.6],[.95,.75]]},{l:4,p:[[.05,.3],[.5,.5],[.95,.2]]}]});
 st.inst[0].fn=5;st.inst[0].p.rev=.6;
 const seg=(b,s0,n)=>b.getChannelData(0).slice(s0,s0+n);
 const rms=a=>{let s=0;for(const x of a)s+=x*x;return Math.sqrt(s/a.length);};
 const old=await new Promise(r=>Q.render(r));
 const L=Q.loopLen(),sr=old.sampleRate,oldS=seg(old,Math.round((.05+L)*sr),Math.round(L*sr));
 st.eq={hp:1,lo:6,mid:0,hi:-9,out:0};
 const eq0=JSON.stringify(st.eq);
 let m=null;const blk=await new Promise(r=>Q.renderBlock((b,mt)=>{m=mt;r(b);}));
 const eqAfter=JSON.stringify(st.eq);
 const bS=seg(blk,Math.round(m.start*sr),Math.round(m.len*sr));
 st.eq={hp:1,lo:0,mid:0,hi:0,out:0};QEXPORT.opt.auto=false;QEXPORT.opt.loops=2;
 const ex=await new Promise(r=>QEXPORT.render(r));const Le=(QEXP_last()-.05)/2;
 function QEXP_last(){return QEXPORT.opt.last.sec;}
 const eS=seg(ex,Math.round((.05+Le)*sr),Math.round(Le*sr));
 let n=Math.min(bS.length,eS.length),dmax=0;for(let i=0;i<n;i++)dmax=Math.max(dmax,Math.abs(bS[i]-eS[i]));
 let d2=0;{const k=Math.min(oldS.length,bS.length);for(let i=0;i<k;i++)d2=Math.max(d2,Math.abs(oldS[i]-bS[i]));}
 return {d2,eqKept:eq0===eqAfter,rmsOld:rms(oldS),rmsBlk:rms(bS),rmsEx:rms(eS),dmax,lenBlk:m.len,L};}"""
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    r=pg.evaluate(JS);print(r)
    chk(r['eqKept'],'le master (égaliseur) de l’utilisateur est restauré après le rendu du bloc')
    chk(r['rmsBlk']>1e-3,'bloc non silencieux (rms %.4f)'%r['rmsBlk'])
    chk(r['dmax']<1e-3,'bloc = rendu de l’export sans master (écart max %.6f)'%r['dmax'])
    chk(r['d2']>.05,'l’ancien rendu différait nettement du bloc (écart max %.3f) : fonctions/rythmes manquaient'%r['d2'])
    chk(not errs,'aucune erreur de page %s'%errs[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
