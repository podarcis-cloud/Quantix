# Track suit le tempo de Quantone (R382) : 80 par défaut, adopté si le Track est vide
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(800)
    chk(pg.input_value('#bpm')=='80','Track neuf : BPM 80')
    pg.evaluate("localStorage.setItem('qx.tempo','132')");pg.reload();pg.wait_for_timeout(800)
    chk(pg.input_value('#bpm')=='132','tempo Quantone 132 adopté (Track vide)')
    chk(pg.evaluate("localStorage.getItem('qx.tempo')")is None,'clé consommée')
    chk(not er,'aucune erreur JS '+str(er[:1]))
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
