global.window={matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener:()=>{},ResizeObserver:null};
global.navigator={};const store={};
function fake(id){const o={id,style:{setProperty(){}},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(sel){/*QSA_REAL*/return (sel==='i')?[{className:''},{className:''},{className:''}]:[];},getBoundingClientRect(){return{left:0,top:0}},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>k==='createRadialGradient'?()=>({addColorStop(){}}):()=>{}})},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.document={getElementById:id=>store[id]||(store[id]=fake(id)),addEventListener(){},documentElement:fake('r')};
global.requestAnimationFrame=()=>{};
require('./testq.js');
const {S,LEVELS,WORLDS,physics,loadLevel,qpBuild}=global.__X;
console.log('mondes :',WORLDS.length,'| niveaux :',LEVELS.length);
const idx=n=>LEVELS.findIndex(l=>l.n===n);
function run(name,pts,frames){
  const i=idx(name); loadLevel(i);
  if(pts)S.strokes.push({pts,len:0,birth:0,mat:0});
  qpBuild(); S.mode='run';
  let sawGhost=false,entFlips=0,prev=S.ent.map(e=>e.on),collapsed=false;
  for(let f=0;f<frames;f++){
    physics();
    if(S.branch)sawGhost=true;
    S.ent.forEach((e,k)=>{if(e.on!==prev[k]){entFlips++;prev[k]=e.on;}});
    if(S.collapsed)collapsed=true;
    if(S.mode!=='run')break;
  }
  return {mode:S.mode,sawGhost,entFlips,collapsed};
}
let r=run('Le lien',[[24,80],[300,230]],900);
console.log('« Le lien »        bascules d\'intrication :',r.entFlips,'| issue :',r.mode);
r=run('La mesure',[[22,70],[260,300]],900);
console.log('« La mesure »      dédoublement :',r.sawGhost,'| effondrement :',r.collapsed,'| issue :',r.mode);
r=run('Deux possibles',[[22,70],[250,300]],900);
console.log('« Deux possibles » dédoublement :',r.sawGhost,'| issue :',r.mode);
r=run('Le temps ralenti',[[22,70],[240,330]],900);
console.log('« Le temps ralenti » issue :',r.mode);
// non-régression
loadLevel(0); S.strokes.push({pts:[[24,80],[250,430]],len:0,birth:0,mat:0}); qpBuild(); S.mode='run';
for(let f=0;f<900&&S.mode==='run';f++)physics();
console.log('non-régression niveau 1 :',S.mode);
