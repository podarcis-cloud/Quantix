require('./load.js');
const {S,LEVELS,WORLDS,physics,loadLevel,qpBuild}=globalThis.__X;
console.log('mondes :',WORLDS.length,'| niveaux :',LEVELS.length);
const idx=n=>LEVELS.findIndex(l=>l.n===n);
function run(name,pts,frames){
  const i=idx(name); loadLevel(i);
  if(pts)S.strokes.push({pts,len:0,birth:0,mat:0});
  qpBuild(); S.mode='run';
  let sawGhost=false,entFlips=0,prev=S.ent.map(e=>e.on),collapsed=false;
  for(let f=0;f<frames;f++){
    physics();
    if(S.branch)sawGhost=true;
    S.ent.forEach((e,k)=>{if(e.on!==prev[k]){entFlips++;prev[k]=e.on;}});
    if(S.collapsed)collapsed=true;
    if(S.mode!=='run')break;
  }
  return {mode:S.mode,sawGhost,entFlips,collapsed};
}
let r=run('Le lien',[[24,80],[300,230]],900);
console.log('« Le lien »        bascules d\'intrication :',r.entFlips,'| issue :',r.mode);
r=run('La mesure',[[22,70],[260,300]],900);
console.log('« La mesure »      dédoublement :',r.sawGhost,'| effondrement :',r.collapsed,'| issue :',r.mode);
r=run('Deux possibles',[[22,70],[250,300]],900);
console.log('« Deux possibles » dédoublement :',r.sawGhost,'| issue :',r.mode);
r=run('Le temps ralenti',[[22,70],[240,330]],900);
console.log('« Le temps ralenti » issue :',r.mode);
// non-régression
loadLevel(0); S.strokes.push({pts:[[24,80],[250,430]],len:0,birth:0,mat:0}); qpBuild(); S.mode='run';
for(let f=0;f<900&&S.mode==='run';f++)physics();
console.log('non-régression niveau 1 :',S.mode);
