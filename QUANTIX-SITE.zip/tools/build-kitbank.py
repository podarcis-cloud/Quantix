# Construit KIT_bank.zip (zip SANS compression) : manifest.json + kits.json. Usage : python3 tools/build-kitbank.py [version]
import json,sys,zipfile
V=sys.argv[1] if len(sys.argv)>1 else 'R365'
K=['ktune','kdec','stone','snoise','clap','hdec','perc','tone','vol','rev','dly','grit','room']
R={'ktune':(35,90),'kdec':(.15,1.2),'stone':(800,4000),'snoise':(0,1),'clap':(0,1),'hdec':(0,1),'perc':(0,1),'tone':(1500,16000),'vol':(0,3),'rev':(0,1),'dly':(0,1),'grit':(0,1),'room':(0,1)}
F={'elec':('Électro','Electro'),'hh':('Hip‑hop & lo‑fi','Hip‑hop & lo‑fi'),'hs':('House & techno','House & techno'),'ac':('Acoustique','Acoustic'),'dub':('Dub & reggae','Dub & reggae'),'mo':('Monde','World'),'ci':('Cinéma & ambiance','Cinema & ambient'),'gl':('Glitch & expérimental','Glitch & experimental'),'in':('Industriel & dur','Industrial & hard')}
#      id      fam   fr                    en                 ktune kdec stone snoise clap hdec perc tone  vol  rev  dly  grit room
D=[
('e808','elec','808 profond','Deep 808',                40,1.0,1500,.4,0,.45,0,8000,.8,.1,0,.05,0),
('e909','elec','909 franc','Punchy 909',                54,.4,2400,.85,1,.4,0,14000,.72,.08,0,.1,0),
('e707','elec','707 sec','Dry 707',                     58,.28,2800,.6,1,.2,0,11000,.72,.05,0,.05,0),
('ecm','elec','Boîte vintage','Vintage box',            52,.5,1700,.5,0,.3,1,5500,.78,.12,.05,.25,.1),
('esyn','elec','Synthwave','Synthwave',                 50,.55,2000,.7,1,.55,0,12000,.72,.35,.2,.05,.2),
('eele','elec','Électro clair','Clean electro',         62,.33,3200,.45,1,.25,1,15000,.7,.12,.15,0,0),
('hdus','hh','Poussière','Dust',                        46,.55,1400,.45,0,.35,0,3200,.8,.2,.1,.6,.2),
('hmpc','hh','Sampler 12 bits','12‑bit sampler',        49,.4,1700,.65,1,.3,0,4800,.8,.15,0,.45,.05),
('hvin','hh','Vinyle chaud','Warm vinyl',               44,.6,1300,.4,0,.4,0,2600,.82,.25,.08,.7,.25),
('hbo','hh','Boom bap','Boom bap',                      47,.45,1900,.75,1,.28,0,5200,.82,.1,0,.35,.1),
('hsl','hh','Nuit lente','Slow night',                  42,.8,1500,.35,0,.5,0,3800,.78,.4,.2,.3,.35),
('hlo','hh','Cassette','Cassette',                      48,.5,1500,.5,0,.3,1,2200,.8,.18,.12,.55,.15),
('hou','hs','House classique','Classic house',          53,.38,2300,.8,1,.45,0,13000,.72,.1,0,.1,.05),
('hte','hs','Techno sec','Dry techno',                  50,.32,2600,.55,0,.2,1,10000,.74,.05,0,.2,0),
('hdp','hs','Deep house','Deep house',                  45,.55,1800,.5,1,.4,0,7500,.74,.3,.15,.1,.25),
('hmi','hs','Minimal club','Minimal club',              58,.25,3400,.3,0,.12,1,12500,.7,.1,.25,0,0),
('hac','hs','Acid warehouse','Acid warehouse',          46,.6,2800,.9,1,.5,1,9000,.74,.3,.15,.4,.4),
('hbr','hs','Break détroit','Detroit break',            52,.42,2200,.7,1,.35,1,11000,.72,.15,.1,.15,.1),
('abr','ac','Brosses douces','Soft brushes',            60,.3,1400,.7,0,.2,1,6000,.85,.2,0,0,.5),
('asa','ac','Salle de répétition','Rehearsal room',     56,.38,1800,.75,1,.3,1,9000,.8,.25,0,0,.7),
('ajz','ac','Jazz feutré','Muted jazz',                 58,.35,1500,.6,0,.45,1,5000,.82,.3,0,0,.55),
('abo','ac','Bois & peaux','Wood & skins',              64,.28,1300,.35,0,.15,1,5500,.85,.2,0,.05,.4),
('afo','ac','Folk','Folk',                              57,.33,1600,.5,0,.25,1,7000,.82,.28,0,.05,.45),
('acc','ac','Cuisine sonore','Kitchen kit',             66,.22,2000,.55,1,.18,1,8000,.82,.12,0,.1,.3),
('dro','dub','Roots','Roots',                           44,.85,1700,.35,0,.5,1,4500,.8,.5,.45,.1,.55),
('dst','dub','Steppers','Steppers',                     46,.7,1900,.45,1,.4,1,6500,.78,.42,.4,.1,.4),
('dec','dub','Écho de chambre','Chamber echo',          43,.95,1900,.3,0,.6,1,4200,.78,.55,.55,.05,.65),
('drg','dub','Dancehall','Dancehall',                   50,.5,2400,.6,1,.3,1,10000,.76,.2,.25,.15,.2),
('dli','dub','Ligne de basse','Bass line',              38,1.1,1400,.25,0,.4,0,3500,.82,.35,.3,.1,.4),
('mfo','mo','Afro‑percus','Afro percussion',            62,.35,1800,.4,0,.25,1,9000,.8,.25,.1,.05,.3),
('mla','mo','Latin sec','Dry Latin',                    60,.3,2200,.6,1,.22,1,10000,.78,.18,0,.05,.2),
('mba','mo','Bossa légère','Light bossa',               58,.33,1500,.55,0,.25,1,6500,.8,.28,0,0,.45),
('mor','mo','Orient','Oriental',                        56,.4,2000,.45,0,.35,1,8500,.78,.3,.1,.1,.4),
('mta','mo','Tablas','Tablas',                          68,.25,2600,.3,0,.2,1,9500,.8,.3,.15,.05,.35),
('cci','ci','Grand écran','Big screen',                        36,1.2,1500,.6,1,1,1,7000,.8,.6,.1,.1,.8),
('cam','ci','Ambient doux','Soft ambient',              44,.9,1800,.2,0,.8,1,5000,.7,.7,.4,0,.7),
('ccat','ci','Cathédrale','Cathedral',                  40,1.1,1300,.3,0,.9,1,4000,.74,.85,.3,0,.9),
('cve','ci','Cristal flottant','Floating crystal',            80,.35,4000,.2,0,.8,1,16000,.7,.7,.3,0,.5),
('cfi','ci','Film noir','Film noir',                    41,.9,1400,.45,0,.55,1,3500,.78,.45,.2,.2,.7),
('gtr','gl','Glitch clair','Clean glitch',              70,.15,3800,.3,0,.05,1,15000,.7,.1,.3,.3,0),
('gbi','gl','Octets','Bits',                            66,.2,3400,.4,1,.1,1,6000,.7,.1,.2,.8,0),
('gst','gl','Statique','Static',                        62,.18,3800,.95,0,.08,1,12000,.62,.1,.15,.7,0),
('gmi','gl','Micro‑rebonds','Micro bounces',            74,.15,3000,.35,0,.06,1,14000,.68,.15,.5,.25,0),
('iin','in','Usine','Factory',                          38,.8,3200,1,1,.5,1,9000,.7,.25,.1,.85,.35),
('iha','in','Marteau','Hammer',                         36,.7,3600,.85,1,.45,1,7500,.7,.2,0,.9,.2),
('iru','in','Rouille','Rust',                           42,.65,2800,.9,1,.4,1,4200,.72,.2,.1,.95,.3),
('ibr','in','Béton brut','Raw concrete',                40,.6,3000,.8,1,.35,1,6000,.74,.12,0,.75,.15),
]
kits=[];fam=[]
for d in D:
    i,f,fr,en=d[:4];v=d[4:];assert len(v)==len(K),i
    p={}
    for k,x in zip(K,v):
        lo,hi=R[k];assert lo<=x<=hi,(i,k,x);p[k]=x
    kits.append({'id':i,'fam':f,'fr':fr,'en':en,'p':p})
fams=[{'id':k,'fr':a,'en':b} for k,(a,b) in F.items()]
assert len({k['id'] for k in kits})==len(kits)
man={'bank':'KIT_bank','version':V,'count':len(kits),'min':'R365','files':['kits.json']}
with zipfile.ZipFile('KIT_bank.zip','w',zipfile.ZIP_STORED) as z:
    z.writestr('manifest.json',json.dumps(man,ensure_ascii=False))
    z.writestr('kits.json',json.dumps({'fams':fams,'kits':kits},ensure_ascii=False,separators=(',',':')))
print(len(kits),'kits',V)
