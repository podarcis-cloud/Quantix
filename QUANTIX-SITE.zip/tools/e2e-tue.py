# Fenêtre tuée par iOS (sessionStorage perdu) : l'état de Pattern revient quand même (R393)
from playwright.sync_api import sync_playwright
import math
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844});pg=ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{const t=document.querySelector('.dk[data-m=\"draw\"]');t&&t.click()})()")
    bb=pg.locator('#cv').bounding_box();cx=bb['x']+bb['width']/2;cy=bb['y']+bb['height']/2
    pg.mouse.move(cx-80,cy);pg.mouse.down()
    for i in range(1,12):pg.mouse.move(cx-80+i*14,cy+math.sin(i/2)*30)
    pg.mouse.up();pg.wait_for_timeout(500)
    n0=pg.evaluate("QUANTONE.state.strokes.length")
    pg.evaluate("document.dispatchEvent(new Event('visibilitychange'));dispatchEvent(new Event('pagehide'))");pg.wait_for_timeout(1500)
    chk(n0>=1,'un trait dessiné (%d)'%n0)
    chk(pg.evaluate("+localStorage.getItem('qx.liveAt')||0")>0,'date du dernier état gardée')
    pg.close()
    p2=ctx.new_page();p2.goto('http://localhost:8765/studio/quantone.html');p2.wait_for_timeout(2500)   # nouvel onglet = sessionStorage vide, comme après un kill
    chk(p2.evaluate("sessionStorage.getItem('qx.autoSeen')||'-'")!='x','nouvelle fenêtre')
    n1=p2.evaluate("QUANTONE.state.strokes.length")
    chk(n1==n0,'le trait est restauré après fermeture de la fenêtre (%d)'%n1)
    chk(not er,'aucune erreur JS %s'%er)
    print('RÉSULTAT',sum(res),'/',len(res));b.close()
