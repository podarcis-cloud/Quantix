"""etat.py — état de la refonte des 132 niveaux (R117, CONSIGNES_SIMON.md §2).
Régénère docs/ETAT_REFONTE_NIVEAUX.md (python3 tools/etat.py) ; « --analyse » imprime seulement l'ancien tableau d'ANALYSE_R116 §6.
Sources : levels.js (via le moteur : optsol, mz), tools/difficulty_R116.json (P_exec / P_noyau, modèle par position),
enigme_status.json, fiches/registre.json (fiche ; champ machine.constance pour les machines), finition.json (trait court, ligne
directe, zone), docs/FINITION.md (notes), tools/mondeN.js (test du monde), docs/SON_MONDES.md (son neuf : « ## Monde N … [validé] »)."""
import json,re,os,subprocess,sys
H=os.path.dirname(os.path.abspath(__file__));R=os.path.dirname(H)
F=json.load(open(H+'/finition.json'));D=json.load(open(H+'/difficulty_R116.json'))
E=set(json.load(open(H+'/enigme_status.json'))['ok']);REG=json.load(open(H+'/fiches/registre.json'))
md=open(R+'/docs/FINITION.md',encoding='utf-8').read()
G={int(m.group(1)):m.group(2) for m in re.finditer(r'^\| (\d+) \| [^|]+\| \*\*([ABCD])\*\*',md,re.M)}
js="require('./load.js');const X=globalThis.__X;const o=[];X.LEVELS.forEach((l,i)=>{X.loadLevel(i);X.qpBuild();X.S.mode='run';for(let f=0;f<1300&&X.S.mode==='run';f++)X.physics();o.push({ref:!!l.optsol,mz:!!(l.mz&&l.mz.length),alone:X.S.mode==='success',n:l.n})});console.log('@@'+JSON.stringify(o));"
out=subprocess.run(['node','-e',js],cwd=H,capture_output=True,text=True).stdout
META=json.loads([l for l in out.splitlines() if l.startswith('@@')][0][2:])
SON=open(R+'/docs/SON_MONDES.md',encoding='utf-8').read() if os.path.exists(R+'/docs/SON_MONDES.md') else ''
MACH={3,6,8,10,12}
W=['Atelier','Fonderie','Chaîne','Glacier','Soufflerie','Mécanique','Gravité','Magnétisme','Faille','Filaments','Quantique']
def row(i):
    f=F[str(i)];d=D.get(str(i),{});m=META[i-1];pos=f['pos'];w=f['wd'];reg=REG.get(str(i),{})
    pe=d.get('P_exec');pn=d.get('P_noyau')
    mach=reg.get('machine') if isinstance(reg,dict) and isinstance(reg.get('machine'),dict) else {}
    c={'enig':i in E,'cout':not f.get('trivial') and not f.get('direct') and not m['alone'],'doigt':(pe or 0)>=.7,'noyau':(pn or 0)>0,   # §9 (quota) : P_noyau > 0 suffit, l'optimisation 15–35 % est reportée
       'ref':m['ref'],'zone':f.get('zoneOk',True),'fiche':str(i) in REG,
       'forme':(not m['mz']) or (mach.get('constance') or 0)>=.98,'test':os.path.exists(H+'/monde%d.js'%w),   # R118 (Simon) : au moins un niveau spectaculaire par monde ; une machine présente doit être constante'test':os.path.exists(H+'/monde%d.js'%w),
       'son':bool(re.search(r'^## Monde %d\b.*\[validé\]'%w,SON,re.M))}
    c['pret']=all(c[k] for k in ('enig','cout','doigt','noyau','ref','zone','fiche','forme','test'))
    man=[]
    if m['alone']:man.append('réussit sans trait')
    if not c['doigt']:man.append('aucun trait droit ne gagne' if not pe else 'jouabilité %d %%'%round(pe*100))
    if not c['noyau']:man.append('noyau inatteignable' if not (pn or 0)>0 else 'noyau hors de 15–35 % des solutions')
    if not m['ref']:man.append('pas de solution de référence')
    if f.get('trivial'):man.append('trait de %s u suffit'%f.get('minLen'))
    if f.get('direct'):man.append('ligne directe')
    if not c['zone']:man.append('élément dans la zone')
    if not c['enig']:man.append('énigme non validée')
    if not c['fiche']:man.append('sans fiche')
    if not c['forme']:man.append('machine : constance non mesurée ou < 98 %')
    if not c['test']:man.append('pas de test du monde')
    if isinstance(reg,dict) and reg.get('reporte'):man.append('reporté : '+reg['reporte'])
    return dict(i=i,pos=pos,w=w,n=f['n'],g=G.get(i,'?'),pe=pe,pn=pn,c=c,man=man)
rows=[row(i) for i in range(1,133)]
if '--analyse' in sys.argv:
    for w in range(1,12):
        print('\n### Monde %d — %s\n\n| # | Pos. | Niveau | Note | P_exec | P_noyau | Défauts |\n|---|---|---|---|---|---|---|'%(w,W[w-1]))
        for r in [r for r in rows if r['w']==w]:print('| %d | %d | %s | %s | %s | %s | %s |'%(r['i'],r['pos'],r['n'],r['g'],'—' if r['pe'] is None else '%d %%'%round(r['pe']*100),'—' if r['pn'] is None else '%d %%'%round(r['pn']*100),' ; '.join(r['man']) or '—'))
    sys.exit()
K=[('enig','Énigme ✓'),('cout','Pas de trait court ni ligne directe'),('doigt','Jouable au doigt ≥ 70 %'),('noyau','Noyau atteignable'),('ref','Solution de référence'),('zone','Zone dégagée'),('fiche','Fiche écrite'),('forme','Machine constante (≥ 98 %) quand il y en a une'),('test','Test du monde'),('son','Son neuf du monde'),('pret','PRÊT (toutes les cases sauf son)')]
y=lambda b:'✅' if b else '❌'
o=['# QUANTIX — ÉTAT DE LA REFONTE, NIVEAU PAR NIVEAU','','*Généré par `python3 tools/etat.py` (ne pas modifier à la main). Critères : `CONSIGNES_SIMON.md` §2. Jouabilité : `difficulty.js`, modèle par position (1–6 main levée, 7–12 éditeur admis, R117).*','','## Synthèse','','| Critère | Niveaux qui le remplissent |','|---|---|']
for k,t in K:o.append('| %s | %d / 132 |'%(t,sum(r['c'][k] for r in rows)))
o+=['','**Niveaux PRÊTS** : '+(', '.join('%d « %s »'%(r['i'],r['n']) for r in rows if r['c']['pret']) or 'aucun'),'','| Monde | Prêts | Énigme ✓ | Doigt ≥ 70 % | Réf. | Niveaux spectaculaires (≥ 1) | Test | Son neuf |','|---|---|---|---|---|---|---|---|']
for w in range(1,12):
    R_=[r for r in rows if r['w']==w]
    o.append('| %d %s | %d/12 | %d/12 | %d/12 | %d/12 | %d | %s | %s |'%(w,W[w-1],sum(r['c']['pret'] for r in R_),sum(r['c']['enig'] for r in R_),sum(r['c']['doigt'] for r in R_),sum(r['c']['ref'] for r in R_),sum(1 for r in R_ if META[r['i']-1]['mz'] and r['c']['forme']),'oui' if R_[0]['c']['test'] else 'non','oui' if R_[0]['c']['son'] else 'non'))
o+=['','## Niveau par niveau']
for w in range(1,12):
    o+=['','### Monde %d — %s'%(w,W[w-1]),'','| # | Pos. | Niveau | Note | P_exec | P_noyau | Énig. | Coût | Doigt | Noyau | Réf. | Zone | Fiche | Forme | Test | PRÊT | Ce qui manque |','|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|']
    for r in [r for r in rows if r['w']==w]:
        c=r['c'];o.append('| %d | %d | %s | %s | %s | %s | %s | %s |'%(r['i'],r['pos'],r['n'],r['g'],'—' if r['pe'] is None else '%d %%'%round(r['pe']*100),'—' if r['pn'] is None else '%d %%'%round(r['pn']*100),' | '.join(y(c[k]) for k in ('enig','cout','doigt','noyau','ref','zone','fiche','forme','test','pret')),' ; '.join(r['man']) or '—'))
open(R+'/docs/ETAT_REFONTE_NIVEAUX.md','w',encoding='utf-8').write('\n'.join(o)+'\n')
print('docs/ETAT_REFONTE_NIVEAUX.md :',sum(r['c']['pret'] for r in rows),'PRÊTS ;',' '.join('%s %d'%(k,sum(r['c'][k] for r in rows)) for k,_ in K[:-1]))
