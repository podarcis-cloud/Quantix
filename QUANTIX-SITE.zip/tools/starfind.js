/* starfind.js — place le noyau là où une minorité (cible ~15-35 %) des solutions gagnantes passe.
   Usage : node -e "require('./starfind.js')(idx, candidat, {zone:[x0,y0,x1,y1], grid})" */
const D=require('./design.js');
module.exports=function(idx,c,opt){
  opt=opt||{};const g=Object.assign({x0:0,x1:360,y0:20,y1:470,step:12,da:0.4,lens:[25,45,70,100,140]},opt.grid||{});
  const wins=[];
  for(let x=g.x0;x<=g.x1;x+=g.step)for(let y=g.y0;y<=g.y1;y+=g.step)for(let a=0;a<6.283;a+=g.da)for(const L of g.lens){
    if(L>c.ink)continue;const p=[[x,y],[x+Math.cos(a)*L,y+Math.sin(a)*L]];if(!D.drawable(c,p))continue;
    const r=D.run(idx,Object.assign({},c,{star:null}),[p]);if(r.ok)wins.push(r.trail);}
  const z=opt.zone||[0,0,360,480];const lo=opt.lo||.12,hi=opt.hi||.35,tgt=(lo+hi)/2;let best=null;
  for(let sx=z[0];sx<=z[2];sx+=6)for(let sy=z[1];sy<=z[3];sy+=6){
    let h=0;for(const t of wins)if(t.some(q=>Math.hypot(q[0]-sx,q[1]-sy)<20.5))h++;
    const f=h/wins.length;if(f>=lo&&f<=hi&&(!best||Math.abs(f-tgt)<Math.abs(best.f-tgt)))best={x:sx,y:sy,f:+f.toFixed(2)};}
  return {gagnants:wins.length,noyau:best};
};
