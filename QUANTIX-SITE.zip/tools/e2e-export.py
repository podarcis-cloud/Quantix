# Export audio R352 : nombre de boucles, automations rendues, MP3 — serveur local 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
JS_R="""async (n)=>{QEXPORT.opt.auto=false;QEXPORT.opt.loops=n;
 const b=await new Promise(r=>QEXPORT.render(r));const d=b.getChannelData(0);
 const q=Math.floor(QEXPORT.opt.last.sec*b.sampleRate/4);const rms=(a,z)=>{let s=0;for(let i=a;i<z;i++)s+=d[i]*d[i];return Math.sqrt(s/Math.max(1,z-a));};
 return {len:d.length,sec:d.length/b.sampleRate,r1:rms(0,q),r4:rms(3*q-q/2|0,4*q-q),tot:rms(0,d.length)};}"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("!!window.QEXPORT"),'module export présent')
    pg.evaluate("QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:90,echo:0,rev:0,breath:0,clar:.45,drone:0,grain:0,swing:0},strokes:[{l:0,p:[[.03,.5],[.3,.25],[.55,.7],[.8,.3],[.97,.55],[.55,.85],[.03,.5]]}]})");pg.wait_for_timeout(300)
    pg.click('#qFileBtn');pg.wait_for_timeout(400)
    chk(pg.evaluate("!!document.getElementById('xpBox')"),'sélecteur de boucles/format dans la feuille')
    pg.click('#xpBox [data-l="4"]');chk(pg.evaluate("QEXPORT.opt.loops===4 && !QEXPORT.opt.auto"),'puce 4 boucles prise en compte')
    pg.click('#xpBox [data-l="8"]');chk(pg.evaluate("QEXPORT.opt.loops===8"),'puce 8 boucles (R404 : 1, 2, 4, 8, cycle)')
    pg.click('#xpBox [data-f="mp3"]');chk(pg.evaluate("QEXPORT.opt.fmt==='mp3'"),'format MP3 choisi')
    a=pg.evaluate(JS_R,1);c=pg.evaluate(JS_R,4)
    print('1 boucle %.1fs · 4 boucles %.1fs'%(a['sec'],c['sec']))
    chk(abs((c['sec']-4)/(a['sec']-4)-4)<.25,'durée proportionnelle au nombre de boucles')
    chk(a['tot']>1e-4,'audio non silencieux (rms %.4f)'%a['tot'])
    # automation de volume de sortie : -12 dB -> +6 dB sur 4 boucles
    pg.evaluate("window.__o=QAUTO.AUT['eq:out'];QAUTO.AUT['eq:out']={on:true,mode:'lin',len:4,pts:[[0,0],[.75,1]]}")
    base=pg.evaluate("(()=>{try{return QAUTO.desc('eq:out').get();}catch(e){return -1;}})()")
    d=pg.evaluate(JS_R,4)
    chk(d['r4']>d['r1']*1.8,'automation rendue dans l’audio (début %.4f → fin %.4f)'%(d['r1'],d['r4']))
    after=pg.evaluate("QAUTO.desc('eq:out').get()")
    chk(abs(after-base)<1e-6,'réglage restauré après export (%.3f → %.3f)'%(base,after))
    pg.evaluate("QAUTO.AUT['eq:out'].len=3;")
    pg.click('#xpBox [data-l="a"]');chk(pg.evaluate("QEXPORT.cycle()===3 && QEXPORT.opt.auto"),'cycle complet = 3 boucles')
    pg.evaluate("delete QAUTO.AUT['eq:out'];QEXPORT.opt.auto=false;QEXPORT.opt.loops=2")
    r=pg.evaluate("""async()=>{const b=await new Promise(r=>QEXPORT.render(r));const bl=await new Promise(r=>QEXPORT.mp3(b,r));
      if(!bl)return null;const u=new Uint8Array(await bl.arrayBuffer());return {n:u.length,h:[u[0],u[1],u[2]],dur:b.duration};}""")
    chk(r and r['n']>5000,'MP3 encodé (%s octets)'%(r and r['n']))
    chk(r and (r['h'][0]==0xFF or r['h'][:3]==[0x49,0x44,0x33]),'en-tête MP3 valide')
    ok=pg.evaluate("document.getElementById('xpI').textContent");print(ok)
    chk('MP3' in ok or 'WAV' in ok,'estimation de durée affichée')
    pg.screenshot(path='/tmp/export-q.png')
print('RÉSULTAT',sum(res),'/',len(res),errs[:2])
