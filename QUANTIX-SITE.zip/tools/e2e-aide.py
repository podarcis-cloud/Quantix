# R399 : bouton « ? » (mode d'emploi) identique dans Pattern et Track
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
R="(id=>{const e=document.getElementById(id);if(!e)return null;const b=e.getBoundingClientRect();return [Math.round(b.left),Math.round(b.top),Math.round(b.width),Math.round(b.height)]})"
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pos={}
    for u in ('quantone','morceau'):
        pg.goto('http://localhost:8765/studio/%s.html'%u);pg.wait_for_timeout(1800)
        pos[u]=pg.evaluate("(()=>{const r=%s;return [r('bLang'),r('bHelp')]})()"%R)
        chk(pos[u][1] is not None,'%s : bouton ? présent'%u)
        pg.click('#bHelp');pg.wait_for_timeout(1200)
        chk(pg.locator('#qHelpOv iframe').count()==1 and pg.frame_locator('#qHelpOv iframe').locator('h1').count()>=1,'%s : le manuel s’ouvre'%u)
        pg.click('#qHelpOv button');chk(pg.locator('#qHelpOv').count()==0,'%s : fermeture'%u)
    chk(pos['quantone']==pos['morceau'],'le bouton ? est au même endroit dans Pattern et Track %s'%pos)
    chk(pos['quantone'][1][1]==pos['quantone'][0][1] and pos['quantone'][1][3]==pos['quantone'][0][3],'aligné avec FR/EN')
    chk(not er,'aucune erreur %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
