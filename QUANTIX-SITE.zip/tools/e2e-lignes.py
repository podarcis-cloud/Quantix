# Lignes multi-points et courbes de Bézier (R370) : appui long sur Droite, appui long pour finir
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(600)
    pg.evaluate("QUANTONE.state.strokes.length=0");
    pg.evaluate("document.getElementById('cv').id='cv'")
    def rect():return pg.evaluate("(()=>{const r=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width,r.height]})()")
    def tap(x,y,hold=0):
        l,t,w,h=rect();pg.mouse.move(l+x*w,t+y*h);pg.mouse.down();pg.wait_for_timeout(hold or 60);pg.mouse.up();pg.wait_for_timeout(80)
    def menu(item):
        bx=pg.locator('#qdock .dk[data-m="line"]').bounding_box();pg.mouse.move(bx['x']+bx['width']/2,bx['y']+bx['height']/2);pg.mouse.down();pg.wait_for_timeout(700);pg.mouse.up();pg.wait_for_timeout(200)
        chk(pg.locator('#qpop button').count()==3,'appui long sur Droite : 3 types de ligne')
        pg.locator('#qpop button').nth(item).click();pg.wait_for_timeout(150)
    pg.click('#qdock .dk[data-m="line"]')
    # multi-points
    menu(1)
    chk(pg.evaluate("QUANTONE.ed.mode")=='line','outil ligne actif')
    for x,y in [(.2,.7),(.4,.3),(.6,.7),(.8,.3)]:tap(x,y)
    chk(pg.evaluate("QUANTONE.state.strokes.length")==0,'tant que la ligne n’est pas finie, rien n’est ajouté')
    chk(pg.evaluate("QUANTONE.ed.path.length")==4,'4 sommets posés')
    tap(.9,.9,hold=800)
    s=pg.evaluate("QUANTONE.state.strokes.map(s=>s.pts)")
    chk(len(s)==1 and len(s[0])>20,'appui long : la ligne est créée (%d pts)'%(len(s[0]) if s else 0))
    chk(s and abs(s[0][0][0]-.2)<.04 and abs(s[0][-1][0]-.8)<.04,'elle passe du premier au dernier sommet')
    pg.evaluate("QUANTONE.undo()");chk(pg.evaluate("QUANTONE.state.strokes.length")==0,'annuler retire la ligne')
    # bézier
    menu(2)
    for x,y in [(.15,.8),(.4,.2),(.7,.8),(.9,.3)]:tap(x,y)
    pg.evaluate("QUANTONE.undo()");chk(pg.evaluate("QUANTONE.ed.path.length")==3,'annuler pendant le tracé retire le dernier sommet')
    tap(.9,.3);tap(.5,.5,hold=800)
    s=pg.evaluate("QUANTONE.state.strokes.map(s=>s.pts)")
    chk(len(s)==1,'courbe de Bézier créée')
    if s:
        pts=s[0];ys=[p[1] for p in pts];chk(min(ys)<.35 and max(ys)>.7,'la courbe monte et descend entre les points')
        ts=[p[2] for p in pts];chk(all(ts[i]<ts[i+1] for i in range(len(ts)-1)),'temps croissants (jouable)')
    # un seul sommet + appui long : annulé
    tap(.3,.3);tap(.3,.3,hold=800);chk(pg.evaluate("QUANTONE.state.strokes.length")==1 and not pg.evaluate("QUANTONE.ed.path"),'un seul point : rien créé')
    # retour droite
    menu(0);tap(.2,.5);pg.mouse.move(*[0,0])
    chk(not er,'aucune erreur de page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
