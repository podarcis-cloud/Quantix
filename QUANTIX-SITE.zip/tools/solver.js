global.window={matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener:()=>{},ResizeObserver:null};
global.navigator={};
const store={};
function fake(id){const o={id,style:{setProperty(){}},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(sel){/*QSA_REAL*/return (sel==='i')?[{className:''},{className:''},{className:''}]:[];},getBoundingClientRect(){return{left:0,top:0}},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>k==='createRadialGradient'?()=>({addColorStop(){}}):()=>{}})},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.document={getElementById:id=>store[id]||(store[id]=fake(id)),addEventListener(){},documentElement:fake('r')};
global.requestAnimationFrame=()=>{};
require('./testq.js');
const {S,LEVELS,WORLDS,physics,loadLevel,qpBuild,COST,worldRange}=global.__X;

const inND=(L,x,y)=>L.nd?L.nd.some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]):false;
function polyOK(L,pts){
  for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i];
    const n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/9));
    for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;
      if(x<-2||x>362||y<-2||y>478)return false; if(inND(L,x,y))return false;}}
  return true;
}
const plen=p=>{let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;};

function attempt(idx,pts,cap){
  loadLevel(idx);
  if(pts){S.strokes.push({pts,len:plen(pts),birth:0,mat:0});S.ink-=plen(pts);}
  qpBuild();S.mode='run';
  for(let f=0;f<cap;f++){physics();if(S.mode!=='run')break;}
  return S.mode;
}
function candidates(L){
  const bx=L.ball[0],by=L.ball[1],z=L.zone;
  const cx=z[0]+z[2]/2, dir=cx>bx?1:-1;
  const starts=[[bx-dir*28,by+36],[bx-dir*20,by+26],[bx-dir*38,by+52]];
  const rim = dir>0 ? z[0] : z[0]+z[2];
  const ends=[[rim-dir*6,z[1]+z[3]-56],[rim+dir*12,z[1]+z[3]-36],[rim+dir*z[2]*.3,z[1]+z[3]-24]];
  // points d'intérêt : colonnes d'air, plaques, tapis, portails, aimants
  const feats=[];
  (L.wind||[]).forEach(w=>feats.push([w[0]+w[2]/2,w[1]+w[3]-12]));
  (L.grav||[]).forEach(g=>feats.push([g[0]+g[2]/2,g[1]+10]));
  (L.port||[]).forEach(p=>feats.push([p[0],p[1]-6]));
  (L.w||[]).forEach(w=>{if(w[4]===1||w[4]===3||w[4]===4)feats.push([(w[0]+w[2])/2,(w[1]+w[3])/2-18]);});
  (L.mag||[]).forEach(m=>feats.push([m[0],m[1]-m[2]-8]));
  (L.ent||[]).forEach(e=>{feats.push([e[0],e[1]-14]);feats.push([e[2],e[3]-14]);});
  (L.det||[]).forEach(d=>feats.push([d[0],d[1]-d[2]-6]));
  const out=[];
  for(const s of starts) for(const e of ends) out.push([s,e]);
  for(const e of ends) for(const fx of [.4,.62]) for(const wy of [150,240,330,410])
    out.push([starts[0],[bx+(e[0]-bx)*fx,wy],e]);
  for(const f of feats){ for(const s of starts) out.push([s,f]);
    for(const e of ends) out.push([starts[0],f,e]);
    for(const wy of [180,300]) out.push([starts[0],[bx+(f[0]-bx)*.55,wy],f]); }
  return out;
}
const res=[];
for(let i=0;i<LEVELS.length;i++){
  const L=LEVELS[i]; let sol=null;
  if(attempt(i,null,240)==='success') sol='sans rien';
  if(!sol) for(const c of candidates(L)){
    if(!polyOK(L,c))continue;
    if(plen(c)*COST[0]>L.ink)continue;
    if(attempt(i,c,1000)==='success'){sol=c.map(p=>p.map(Math.round).join(',')).join('→');break;}
  }
  res.push({i,wd:L.wd,n:L.n,sol});
}
const ok=res.filter(r=>r.sol).length;
console.log('PROUVÉS SOLVABLES : '+ok+' / '+LEVELS.length+'\n');
for(let w=1;w<=11;w++){const rs=res.filter(r=>r.wd===w);
  const o=rs.filter(r=>r.sol).length;
  console.log(('M'+w+' '+WORLDS[w-1].n).padEnd(20)+o+'/12'+(o<12?'   → '+rs.filter(r=>!r.sol).map(r=>'#'+(r.i+1)+' '+r.n).join(', '):''));}
