"""preuve.py N — R209 : la PREUVE d'un niveau en une commande, sortie courte (méthode, INSTRUCTIONS_PROJET §Méthode).
Enchaîne : solution de référence et essai à vide (preuve_ref.js) · zone de réussite propre (zonepropre.js) ·
mécanique indispensable (bypass.js N) · traits droits « nus » (contournements.js N N). Ne modifie rien.
Usage : python3 tools/preuve.py 77   (plusieurs : python3 tools/preuve.py 73 74 75 — un niveau par commande reste conseillé)"""
import subprocess,sys,os,json,re
H=os.path.dirname(os.path.abspath(__file__))
def run(cmd,t=270):
    try:r=subprocess.run(cmd,cwd=H,capture_output=True,text=True,timeout=t);return r.stdout+r.stderr
    except subprocess.TimeoutExpired:return 'DÉLAI DÉPASSÉ'
for N in sys.argv[1:]:
    o=run(['node','preuve_ref.js',N]);j=[l for l in o.splitlines() if l.startswith('{')]
    d=json.loads(j[-1]) if j else {}
    print('#%s %s'%(N,d.get('nom','?')))
    ok=lambda b:'OK' if b else 'ÉCHEC'
    print('  référence      :',d.get('ref'),'| noyau' if d.get('noyau') else '| sans noyau',d.get('duree',''),'—',ok(d.get('ref')=='success'))
    print('  à vide         :',d.get('vide'),'—',ok(d.get('vide')!='success'))
    print('  zone invisible :','oui' if d.get('mz') else 'non','—',ok(not d.get('mz')))
    z=run(['node','zonepropre.js',N]);zl=[l for l in z.splitlines() if l.startswith('#')]
    print('  zone propre    :',(zl[0][:90] if zl else 'propre'),'—',ok(not zl))
    b=run(['node','bypass.js','n='+N]);bl=[l for l in b.splitlines() if re.search(r'#\d+',l)]
    print('  mécanique      :',(bl[-1].strip()[:110] if bl else b.strip().splitlines()[-1][:110] if b.strip() else '?'))
    c=run(['node','contournements.js',N,N]);cl=[l for l in c.splitlines() if 'NUS' in l]
    print('  traits droits  :',(cl[-1].strip()[:110] if cl else c.strip().splitlines()[-1][:110] if c.strip() else '?'))
