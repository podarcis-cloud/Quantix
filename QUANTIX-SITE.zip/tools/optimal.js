/* optimal.js — solution optimale d'un niveau, pour le bouton « Voir la solution » du jeu.
   Optimale = (1) réussit, (2) décroche le noyau, (3) tolérance au doigt maximale
   (extrémités décalées de ±4 px, tools/tolerance.js), (4) à tolérance égale, le moins d'encre.
   Usage : node optimal.js 1 2 3 …   (numéros de niveau, 1 à 12 pour le monde 1)
   Écrit tools/optimal-monde1.json (fusionne avec l'existant). Physique : le vrai moteur. */
require('./load.js');
const X=globalThis.__X, fs=require('fs'), TOL=require('./tolerance.js');
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function inND(LVz,x,y){return (LVz.nd||[]).some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]);}
function drawable(LVz,p){for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i],n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/5));
 for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;if(x<0||x>360||y<0||y>480||inND(LVz,x,y))return false;}}return true;}
function run(i,s){X.loadLevel(i);for(const p of s)X.S.strokes.push({pts:p,len:plen(p),birth:0,mat:0});
 X.qpBuild();X.S.mode='run';for(let f=0;f<900&&X.S.mode==='run';f++)X.physics();return {ok:X.S.mode==='success',star:X.S.gotStar};}
function hash(n){const x=Math.sin(n*12.9898)*43758.5453;return x-Math.floor(x);}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(hash(i+7)*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

/* candidats à un trait : segments droits + polylignes à 3 points (courbes, tremplins) */
function singles(i){const LVi=X.LEVELS[i],c=[];
 for(let x=0;x<=360;x+=10)for(let y=20;y<=470;y+=10){if(inND(LVi,x,y))continue;
  for(let a=0;a<6.283;a+=0.3)for(const Ln of [25,40,60,85,115,150,200,260]){if(Ln>LVi.ink)continue;
   const p=[[x,y],[Math.round(x+Math.cos(a)*Ln),Math.round(y+Math.sin(a)*Ln)]];if(drawable(LVi,p))c.push([p]);}}
 for(let k=0;k<6000;k++){const x=Math.round(hash(k*3+i)*360),y=Math.round(20+hash(k*5+i)*450),a=hash(k*7+i)*6.283,b=a+(hash(k*11+i)-.5)*2.2,
   l1=20+hash(k*13+i)*110,l2=15+hash(k*17+i)*90;
  const m=[Math.round(x+Math.cos(a)*l1),Math.round(y+Math.sin(a)*l1)],e=[Math.round(m[0]+Math.cos(b)*l2),Math.round(m[1]+Math.sin(b)*l2)],p=[[x,y],m,e];
  if(plen(p)<=LVi.ink&&drawable(LVi,p))c.push([p]);}
 return shuffle(c);}

/* candidats à plusieurs traits (relais, synthèse) */
const MULTI={
 3:()=>{const A=[],B=[],c=[];for(const sx of [10,20,30])for(const sy of [80,100,120])for(const ex of [100,125,138])for(const ey of [150,190,230])A.push([[sx,sy],[ex,ey]]);
  for(const sx of [290,320,350])for(const sy of [262,290,320])for(const ex of [216,235])for(const ey of [360,400,440])B.push([[sx,sy],[ex,ey]]);
  for(const a of A)for(const b of B)c.push([a,b]);return shuffle(c);},
 11:()=>{const As=[[[30,58],[58,62]],[[20,70],[56,66]],[[40,55],[60,60]]],Cs=[[[345,205],[155,445]],[[340,210],[150,450]],[[350,200],[160,440]]],c=[];
  for(let mx=195;mx<=240;mx+=5)for(let my=158;my<=212;my+=6)for(let ex=mx+8;ex<=262;ex+=8)for(let ey=145;ey<=210;ey+=8)
   for(const a of As)for(const cc of Cs)c.push([a,[[190,160],[mx,my],[ex,ey]],cc]);return shuffle(c);}
};

function optimal(num){const i=num-1,LVi=X.LEVELS[i],cand=MULTI[i]?MULTI[i]():singles(i);
 const hits=[];let tried=0;
 for(const s of cand){if(!s.every(p=>drawable(LVi,p)))continue;if(s.reduce((a,p)=>a+plen(p),0)>LVi.ink)continue;
  tried++;const r=run(i,s);if(r.ok&&r.star)hits.push(s);if(hits.length>=80||tried>40000)break;}
 if(!hits.length)return {niveau:num,nom:LVi.n,trouve:false,essais:tried};
 hits.sort((a,b)=>a.reduce((s,p)=>s+plen(p),0)-b.reduce((s,p)=>s+plen(p),0));
 let best=null;for(const s of hits.slice(0,30)){const t=TOL(i,s,4);const ink=s.reduce((a,p)=>a+plen(p),0);
  if(!best||t>best.tol+1e-9||(Math.abs(t-best.tol)<1e-9&&ink<best.encre))best={s,tol:t,encre:ink};}
 return {niveau:num,nom:LVi.n,trouve:true,essais:tried,gagnantsAvecNoyau:hits.length,
  solution:best.s,encre:Math.round(best.encre),encreMax:LVi.ink,tolerance:Math.round(100*best.tol)};}

const file=__dirname+'/optimal-monde1.json';
const out=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{};
for(const a of process.argv.slice(2)){const r=optimal(+a);out[a]=r;fs.writeFileSync(file,JSON.stringify(out,null,1));
 console.log(r.trouve?`#${a} ${r.nom.padEnd(17)} noyau OK | encre ${r.encre}/${r.encreMax} | tolérance ${r.tolerance}% | ${r.gagnantsAvecNoyau} solutions à noyau parmi ${r.essais} essais`
  :`#${a} ${r.nom} — AUCUNE solution avec noyau trouvée (${r.essais} essais)`);}
