# e2e-quantone-traits.py — R261 : chaque trait garde ses propres réglages (boîte à rythmes, kit, fonction, boucle), sans toucher aux autres.
import os
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_context(viewport={'width':390,'height':844}).new_page()
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','studio','quantone.html')));pg.wait_for_timeout(700)
    pg.evaluate("""(function(){var S=QUANTONE.state;S.strokes.length=0;
      S.strokes.push({layer:4,pts:[[.02,.5],[.45,.52]]},{layer:4,pts:[[.55,.5],[.98,.52]]},{layer:0,pts:[[.1,.3],[.9,.6]]},{layer:0,pts:[[.1,.7],[.9,.2]]});
      QFX3.open(4);})()""");pg.wait_for_timeout(300)
    pg.select_option('#dmMo',pg.evaluate("[].map.call(document.querySelectorAll('#dmMo option'),function(o){return o.value}).filter(Boolean)[1]"));pg.wait_for_timeout(150)
    pg.evaluate("QFX3.target=QUANTONE.state.strokes[0];QFX3.open(4)");pg.wait_for_timeout(300)
    g0=pg.evaluate("JSON.stringify(QUANTONE.state.dm.rows.map(function(r){return r.on}))")
    pg.click('#inOne');pg.wait_for_timeout(200)
    chk(pg.evaluate("!!QFX3.target.ip"),'« Ce trait seulement » donne au trait ses propres réglages')
    chk(any(k in pg.evaluate("document.getElementById('dmSum').textContent") for k in ['ce trait','stroke’s own']),'la boîte indique qu’elle est celle du trait')
    opts=pg.evaluate("[].map.call(document.querySelectorAll('#dmMo option'),function(o){return o.value}).filter(Boolean)")
    pg.select_option('#dmMo',opts[5]);pg.wait_for_timeout(200)
    g1=pg.evaluate("JSON.stringify(QUANTONE.state.dm.rows.map(function(r){return r.on}))")
    chk(g0==g1,'changer le motif du trait ne touche pas la boîte générale')
    own=pg.evaluate("JSON.stringify(QFX3.target.ip.dm.rows.map(function(r){return r.on}))")
    chk(own!=g1,'le trait a bien son propre motif')
    r=pg.evaluate("""(function(){var ev=QFX3.score().filter(function(e){return e.kind===4});var t=QFX3.target.ip,a=0,b=0,c=0;
      ev.forEach(function(e){if(e.ip===t)a++;else if(!e.ip)b++;else c++;});return [ev.length,a,b,c];})()""")
    chk(r[1]>0 and r[2]>0,'la partition joue la boîte du trait dans sa fenêtre et la boîte générale ailleurs %s'%r)
    # kit propre au trait
    kits=pg.evaluate("[].map.call(document.querySelectorAll('#dmKit option'),function(o){return o.value})")
    k0=pg.evaluate("QUANTONE.state.inst?null:null")
    g_kit=pg.evaluate("QFX3.inst[4].preset");pg.select_option('#dmKit',[k for k in kits if k!=g_kit][0]);pg.wait_for_timeout(200)
    chk(pg.evaluate("QFX3.inst[4].preset")==g_kit and pg.evaluate("QFX3.target.ip.preset")!=g_kit,'le kit du trait change, pas celui de l’instrument')
    # fonction propre à un trait de mélodie
    pg.evaluate("(function(){var S=QUANTONE.state;QFX3.target=S.strokes[2];QFX3.open(0);})()");pg.wait_for_timeout(200)
    pg.click('#inOne');pg.wait_for_timeout(200)
    pg.select_option('[data-ifn]','3');pg.wait_for_timeout(150)
    chk(pg.evaluate("QFX3.inst[0].fn|0")==0 and pg.evaluate("QFX3.target.ip.fn")==3,'la fonction 3 ne s’applique qu’à ce trait')
    pg.select_option('[data-ilp]',pg.evaluate("[].map.call(document.querySelectorAll('[data-ilp] option'),function(o){return o.value}).filter(function(v){return v!=='g'})[0]"))
    chk(pg.evaluate("QFX3.inst[0].lp||'g'")=='g' and pg.evaluate("QFX3.target.ip.lp")!='g','la boucle aussi ne vaut que pour ce trait')
    # sauvegarde et rechargement
    rr=pg.evaluate("(function(){var p=JSON.parse(JSON.stringify(QFX3.preset()));QFX3.load(p);var S=QUANTONE.state;return [!!(S.strokes[0].ip&&S.strokes[0].ip.dm),S.strokes[2].ip&&S.strokes[2].ip.fn]})()")
    chk(rr[0] and rr[1]==3,'le préréglage garde la boîte et la fonction de chaque trait %s'%rr)
    pg.click('#bPlay');pg.wait_for_timeout(1500);chk(pg.evaluate("QUANTONE.level()")>.0005,'la lecture sonne')
    chk(not errs,'aucune erreur '+str(errs[:2]))
print('RÉSULTAT',sum(res),'/',len(res))
