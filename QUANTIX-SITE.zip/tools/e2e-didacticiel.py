# e2e-didacticiel.py — parcours complet du didacticiel dans Chromium (Playwright), taille téléphone.
# Usage : python3 tools/e2e-didacticiel.py   (depuis la racine du site)
import os,sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
URL='file://'+ROOT+'/index.html'
res=[];errs=[]
def chk(c,m):
    res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
def w2s(pg,x,y):
    r=pg.evaluate("(function(){var r=cv.getBoundingClientRect();return [r.left,r.top,r.width]})()");s=r[2]/360.0;return r[0]+x*s,r[1]+y*s
def on(pg,i):return pg.evaluate("document.getElementById('%s').classList.contains('on')"%i)
def txt(pg,i):return pg.evaluate("document.getElementById('%s').textContent"%i)
def fits(pg,i):
    return pg.evaluate("(function(){var r=document.getElementById('%s').getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1})()"%i)
with sync_playwright() as p:
    b=p.chromium.launch()
    for (vw,vh,tag) in ((390,780,'390x780'),(360,640,'360x640')):
        ctx=b.new_context(viewport={'width':vw,'height':vh},device_scale_factor=2);pg=ctx.new_page()
        pg.on('pageerror',lambda e: errs.append('PAGEERR '+str(e)))
        pg.on('console',lambda m: errs.append(m.text) if m.type=='error' and '403' not in m.text and 'ERR_' not in m.text else None)
        pg.goto(URL);pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(500)
        print('── '+tag)
        # 1. ouverture (R195) : des fiches comme les autres, plus de partie guidée
        pg.evaluate("goto('game');loadLevel(0)");pg.wait_for_timeout(2600)
        chk(on(pg,'tcard') and txt(pg,'tt')=='Les bases','premier lancement : fiche « Les bases » (R195)')
        chk(fits(pg,'tcard'),'fiche d’ouverture entièrement dans l’écran')
        chk(not on(pg,'tcoach'),'plus de consigne interactive (R195)')
        pg.click('#tok');pg.wait_for_timeout(600)
        chk(on(pg,'tcard') and txt(pg,'tt')=='Pointes','puis la fiche « Pointes » (élément du niveau 1)')
        pg.click('#tok');pg.wait_for_timeout(600)
        chk(not on(pg,'tcard') and pg.evaluate("TUTO._intro()"),'ouverture terminée, la partie est libre')
        # 2. après l'intro : fiches d'outils puis d'éléments, au niveau 2
        pg.evaluate("TUTO.load({v:1,i:1,s:[]},0);loadLevel(1)");pg.wait_for_timeout(2400)
        chk(on(pg,'dock'),'après l’intro : le dock d’outils apparaît')
        titles=[]
        for k in range(8):
            if not on(pg,'tcard'):break
            titles.append(txt(pg,'tt'))
            if k==0:
                chk(txt(pg,'tk').startswith('NOUVEAU'),'première fiche : kicker « NOUVEAU · … »')
                chk(fits(pg,'tcard'),'fiche entièrement dans l’écran')
            pg.click('#tok');pg.wait_for_timeout(450)
        print('   fiches vues :',titles)
        chk(titles==['Tes outils'],'niveau 2 : la fiche « Tes outils » (R195)')
        st=pg.evaluate("TUTO.state()");chk('tdraw' in st['s'],'fiche marquée comme vue')
        # persistance
        pg.evaluate("saveState()");pg.reload();pg.wait_for_timeout(500)
        pg.evaluate("goto('game');S.unlocked=131;loadLevel(1)");pg.wait_for_timeout(1200)
        chk(not on(pg,'tcard'),'après rechargement : les fiches ne se rouvrent pas')
        # 3. aide du niveau
        pg.click('#gPause');pg.wait_for_timeout(300);pg.click('#pHelp');pg.wait_for_timeout(500)
        chk(on(pg,'tcard') and not txt(pg,'tk').startswith('NOUVEAU'),'aide du niveau : fiche en révision (sans « NOUVEAU »)')
        pg.click('#tok');pg.wait_for_timeout(300)
        # 4. explications depuis l'accueil
        pg.evaluate("goto('home')");pg.wait_for_timeout(250)
        pg.click('#hSet');pg.wait_for_timeout(300);pg.click('#sCodex');pg.wait_for_timeout(400)
        n=pg.evaluate("document.querySelectorAll('#cxList .cx').length");hh=pg.evaluate("document.querySelectorAll('#cxList .cxh').length")
        chk(n==25 and hh==2,   # R243 : 1 bases + 4 outils + 20 éléments/matières (+ recombineur)
            'explications : %d entrées, %d rubriques'%(n,hh))
        pg.click('#cxList .cx[data-id=tmove]');pg.wait_for_timeout(500)
        chk(on(pg,'tcard') and txt(pg,'tt')=='Déplacer et pivoter','entrée « Déplacer et pivoter » : la fiche s’ouvre')
        pg.click('#tok');pg.wait_for_timeout(300)
        chk(not on(pg,'tcard') and on(pg,'vCodex'),'fermer la fiche ramène aux explications')
        pg.click('#cxClose')
        # 5. anglais
        pg.evaluate("LANG='en';applyLang();goto('game');loadLevel(1)");pg.wait_for_timeout(400)
        pg.evaluate("TUTO.load({v:1,i:1,s:[]},0);loadLevel(1)");pg.wait_for_timeout(2400)
        chk(txt(pg,'tt')=='Your tools','anglais : titre de la première fiche')
        pg.screenshot(path='/tmp/e2e_en_%s.png'%tag)
        pg.evaluate("LANG='fr';applyLang()")
        ctx.close()
    b.close()
print('erreurs de page :',errs)
print('RÉSULTAT',sum(res),'/',len(res))
sys.exit(0 if all(res) and not errs else 1)
