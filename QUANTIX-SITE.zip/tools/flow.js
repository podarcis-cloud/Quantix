/* flow.js (R131) — poussière d'étoile des machines : calcule lv.flow = la trajectoire de la solution optimale DANS la machine
   (du premier au dernier contact avec une courbe), précédée d'une courte amorce qui montre l'entrée. Écrit dans levels.js.
   Usage : node flow.js 3 6 18 … */
const X=require('./difficulty.js').X,fs=require('fs');
let src=fs.readFileSync('../assets/js/levels.js','utf8');
for(const a of process.argv.slice(2)){const idx=+a-1,LV=X.LEVELS[idx];X.loadLevel(idx);
 for(const p of LV.optsol)X.S.strokes.push({pts:p,len:1,birth:0,mat:LV.optmat||0});X.qpBuild();X.S.mode='run';
 const cv=X.S.lv?X.S.lv._cv:(X.LEVELS[idx]._cv||[]);const tr=[],near=[];
 function dseg(px,py,x1,y1,x2,y2){const dx=x2-x1,dy=y2-y1,l=dx*dx+dy*dy||1;let u=((px-x1)*dx+(py-y1)*dy)/l;u=Math.max(0,Math.min(1,u));return Math.hypot(px-x1-u*dx,py-y1-u*dy);}
 for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();const bx=X.S.ball.x,by=X.S.ball.y;tr.push([bx,by]);
  let n=false;for(const c of (cv||[]))for(let i=1;i<c.pts.length&&!n;i++)if(dseg(bx,by,c.pts[i-1][0],c.pts[i-1][1],c.pts[i][0],c.pts[i][1])<20)n=true;near.push(n);}
 const ok=X.S.mode==='success',i0=near.indexOf(true),i1=near.lastIndexOf(true);
 let j0=i0,j1=i1;if(j0<0){j0=0;j1=0;for(let i=1;i<tr.length;i++)if(tr[i][1]<tr[j1][1])j1=i;if(j1<10)j1=tr.length-1;}   /* machine sans courbe : du départ au point le plus haut */
 const pts=[];for(let i=Math.max(0,j0-22);i<=Math.min(tr.length-1,j1+4);i+=3)pts.push([Math.round(tr[i][0]),Math.round(tr[i][1])]);
 const stt=[...src.matchAll(/^\{wd:/gm)].map(x=>x.index);const m=[src.slice(stt[idx],stt[idx+1]||src.length)];   /* R311 : par rang, pas par nom (deux niveaux peuvent porter le même titre) */
 if(!m){console.log('#'+a,'ÉCHEC entrée');process.exit(1);}
 let e=m[0].replace(/flow:\[\[[\d,\[\]-]*\]\],/,'');e=e.replace(/\n tip:'/,'flow:'+JSON.stringify(pts)+',\n tip:\'');
 if(e===m[0]){console.log('#'+a,'ÉCHEC insertion');process.exit(1);}src=src.replace(m[0],e);
 console.log('#'+a,LV.n.padEnd(22),ok?'solution OK':'SOLUTION EN ÉCHEC','| images',j0,'→',j1,'| points',pts.length);}
fs.writeFileSync('../assets/js/levels.js',src);
