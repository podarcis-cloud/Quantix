# R388 : Track ne capture plus, état de Pattern conservé, Nouvelle pattern / Nouveau projet, glissement
import sys
from playwright.sync_api import sync_playwright
Q='http://localhost:8765/studio/quantone.html';M='http://localhost:8765/studio/morceau.html';ok=0;n=0
def T(name,c):
    global ok,n;n+=1;ok+=bool(c);print(('OK   ' if c else 'FAIL ')+name)
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':780},has_touch=True,is_mobile=True);pg=c.new_page();er=[]
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto(Q);pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.echo=.42;q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q)})()")
    def items():
        return pg.evaluate("new Promise(r=>{var q=indexedDB.open('qxlib',1);q.onupgradeneeded=()=>q.result.createObjectStore('items',{keyPath:'id'});q.onsuccess=()=>{var g=q.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.length)}})")
    n0=items()
    pg.evaluate("document.getElementById('qFloat').click()");pg.wait_for_timeout(1500)
    T('Track ▸ ouvre Track',pg.url.endswith('morceau.html'))
    T('aucune capture créée par Track ▸',items()==n0)
    T('Track s\'ouvre à vide',pg.evaluate("MORCEAU.P().clips.length")==0)
    pg.evaluate("document.getElementById('bQt').click()");pg.wait_for_timeout(2200)
    T('retour sur Pattern',pg.url.endswith('quantone.html'))
    s=pg.evaluate("QXIO.build().preset");T('Pattern restitué à l\'identique (trait, réglage)',len(s['strokes'])==1 and abs(s['k']['echo']-.42)<.01)
    # glissement
    pg.evaluate("window.scrollTo(0,0)")
    def swipe(x1,y1,x2,y2):
        cdp=c.new_cdp_session(pg);cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x1,'y':y1}]});
        for i in range(1,7):cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x1+(x2-x1)*i/6,'y':y1+(y2-y1)*i/6}]})
        cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    cvb=pg.locator('#cv').bounding_box()
    swipe(300,cvb['y']+100,60,cvb['y']+100);pg.wait_for_timeout(800)
    T('glissement sur le dessin : sans effet',pg.url.endswith('quantone.html'))
    ns=pg.evaluate("QXIO.build().preset.strokes.length")
    swipe(300,22,60,22);pg.wait_for_timeout(2000)
    T('glissement dans la barre du haut → Track',pg.url.endswith('morceau.html'))
    swipe(60,100,330,100);pg.wait_for_timeout(2000)
    T('glissement → retour Pattern',pg.url.endswith('quantone.html'))
    s=pg.evaluate("QXIO.build().preset");T('Pattern toujours intacte %s %s'%(len(s['strokes']),s['k']['echo']),len(s['strokes'])==ns and abs(s['k']['echo']-.42)<.01)
    # nouvelle pattern
    pg.evaluate("localStorage.setItem('qx.proj','Alpha')")
    pg.evaluate("document.getElementById('qFileBtn').click()");pg.wait_for_timeout(300)
    bt=pg.locator('#bNew');bt.click();bt.click();pg.wait_for_timeout(2500)
    T('Nouvelle pattern : Pattern vide, projet conservé',pg.evaluate("QXIO.build().preset.strokes.length")==0 and pg.evaluate("localStorage.getItem('qx.proj')")=='Alpha')
    pg.evaluate("document.getElementById('qFileBtn').click()");pg.wait_for_timeout(300)
    bt=pg.locator('#bNewP');bt.click();bt.click();pg.wait_for_timeout(2500)
    T('Nouveau projet : projet effacé',not pg.evaluate("localStorage.getItem('qx.proj')"))
    T('aucune erreur de page',not er)
    if er:print(er[:3])
    b.close()
print('RÉSULTAT %d / %d'%(ok,n));sys.exit(0 if ok==n else 1)
