/* scan-encre.js — R261 : pour chaque niveau, encre de départ, coût de la solution de référence, victoire de celle‑ci. */
require('./load.js');const X=globalThis.__X,{store}=require('./load.js'),S=X.S;
const COST={0:1,1:1.9,3:1.7,5:1.4};const out=[];
function len(p){let l=0;for(let k=1;k<p.length;k++)l+=Math.hypot(p[k][0]-p[k-1][0],p[k][1]-p[k-1][1]);return l;}
for(let i=0;i<X.LEVELS.length;i++){
 X.loadLevel(i);const lv=X.LEVELS[i];const r={i:i+1,n:lv.n,ink:S.ink,max:S.inkMax};
 r.okInk=isFinite(S.ink)&&S.ink>2&&S.ink===S.inkMax;
 if(lv.optsol){r.ns=lv.optsol.length;r.cost=Math.round(lv.optsol.reduce((a,p)=>a+len(p),0)*(COST[lv.optmat||0]||1));r.pct=Math.round(r.cost/S.inkMax*100);
  S.mode='fail';try{store['rSolution'].onclick.call(store['rSolution'],{});for(let f=0;f<1500&&S.mode==='run';f++)X.physics();r.win=S.mode==='success';r.star=!!S.gotStar;}catch(e){r.err=String(e).slice(0,80);}}
 out.push(r);}
require('fs').writeFileSync(process.argv[2]||'/dev/stdout',JSON.stringify(out));
