/* zonepropre.js — R88 : aucun élément (mur, courbe, pointes, tapis…) ne doit entrer dans la zone de réussite.
   Intérieur du bassin = [x+4, y−52, w−8, 50]. Usage : node zonepropre.js [fiche@niveau '{param}'] …  (sans argument : les 132 niveaux) */
const X=require('./design.js').X;
function inside(c,segs){const [x,y,w]=c.cup,r=[x+4,y-52,w-8,50],bad=[];
 const hit=(a,b)=>{for(let k=0;k<=20;k++){const px=a[0]+(b[0]-a[0])*k/20,py=a[1]+(b[1]-a[1])*k/20;if(px>r[0]&&px<r[0]+r[2]&&py>r[1]&&py<r[1]+r[3])return true;}return false;};
 segs.forEach((s,i)=>{if(hit([s[0],s[1]],[s[2],s[3]]))bad.push(s);});return bad;}
function segsOf(c){const o=(c.w||[]).slice();(c.curves||[]).forEach(cv=>{for(let i=1;i<cv.pts.length;i++)o.push([cv.pts[i-1][0],cv.pts[i-1][1],cv.pts[i][0],cv.pts[i][1],cv.m||0]);});return o;}
const args=process.argv.slice(2);
if(!args.length){let n=0;for(let i=0;i<X.LEVELS.length;i++){const L=X.LEVELS[i],b=inside(L,segsOf(L));if(b.length){n++;console.log('#'+(i+1),L.n,'—',b.length,'élément(s) dans la zone :',JSON.stringify(b.slice(0,3)));}}console.log('niveaux concernés :',n,'/',X.LEVELS.length);}
else for(let k=0;k<args.length;k+=2){const [mod]=args[k].split('@'),F=require('./fiches/'+mod+'.js'),c=F.gen(JSON.parse(args[k+1])),b=inside(c,segsOf(c));console.log(mod,b.length?'✗ '+b.length+' élément(s) dans la zone : '+JSON.stringify(b.slice(0,3)):'✓ zone dégagée');}
