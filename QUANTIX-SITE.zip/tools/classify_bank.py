"""classify_bank.py — noms (onomatopée), genre et durée pour chaque son de la banque.
Usage : python3 classify_bank.py <dossier assets/bank>  (lit bank.json + packs, ajoute nm / g / k aux entrées). Heuristique : à juger à l'oreille."""
import json,sys,numpy as np
SR=32000
ONO={ # famille -> noms du plus sombre au plus clair
 'grave':['Boum','Doum','Toum','Poum','Bom'],'sub':['Woumm','Bwoom','Vwoum','Oumm'],'tic':['Toc','Tic','Tac','Tip','Tick'],
 'bois':['Tonk','Toc','Plonk','Tok','Tack'],'metal':['Clong','Clang','Cling','Ding','Tling'],'aigu':['Tchik','Tsik','Ting','Tsss','Pssit'],
 'bruit':['Fshh','Chhh','Shhh'],'texture':['Wouuu','Brrrr','Frrrr','Ssshhh'],'effet':['Zwoup','Vwip','Bzzz','Whoosh'],
 'glitch':['Krrt','Bzzt','Gzzt','Zip','Trrk','Bip'],'break':['Boum-tchak','Rata','Tchak','Clap','Schlak'],'fm':['Dwong','Bwee','Zwoup','Dwiing','Wowow'],
 'ferraille':['Clonk','Clank','Krang','Cling-clang','Tchang'],'grain':['Prrt','Crrr','Frrt','Tttrr','Trrr'],'inverse':['Whoum','Shwoup','Ssswip','Vouiip','Whiip'],
 'impact':['Boom','Bam','Blam','Pam','Krash'],'visqueux':['Bloup','Squelch','Wouaou','Filet','Glou'],'grouillant':['Grouille','Fourmille','Crépite','Grésille'],
 'organique':['Plop','Flop','Gout','Souffle','Ouuu','Poul']}
ONO_K={'bloup':'Bloup','squelch':'Squelch','filet':'Filet','wobble':'Wouaou','swarm':'Grouillement','crackle':'Crépite','wetclick':'Plop','drop':'Goutte','breath':'Souffle','vowel':'Ouuu','slap':'Flop','pulse':'Poul'}
GEN={ # famille -> genres selon timbre (sombre, médian, clair)
 'grave':['Techno','Hip-hop','House'],'sub':['Dub','Hip-hop','Dub'],'tic':['Minimal','Techno','IDM'],'bois':['Organique','Minimal','IDM'],
 'metal':['Industriel','Ambient','Ambient'],'aigu':['Techno','House','Ambient'],'bruit':['Industriel','Ambient','Techno'],'texture':['Ambient','Cinéma','Ambient'],
 'effet':['Cinéma','Électro','Cinéma'],'glitch':['Glitch','IDM','Glitch'],'break':['Breakbeat','Jungle','Breakbeat'],'fm':['Électro','IDM','Électro'],
 'ferraille':['Industriel','Industriel','Cinéma'],'grain':['IDM','Glitch','Ambient'],'inverse':['Cinéma','Transition','Transition'],'impact':['Cinéma','Trap','Cinéma'],
 'visqueux':['Visqueux','Organique','Visqueux'],'grouillant':['Organique','Visqueux','Organique'],'organique':['Organique','Organique','Visqueux']}
def feats(x):
    n=len(x);seg=x[:min(n,int(.3*SR))]*np.hanning(min(n,int(.3*SR))*2)[:min(n,int(.3*SR))][::1]if False else x[:min(n,int(.3*SR))]
    S=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),4096 if len(seg)>2048 else 2048))+1e-9;f=np.fft.rfftfreq(4096 if len(seg)>2048 else 2048,1/SR)
    return float((S*f).sum()/S.sum())
def main(d):
    c=json.load(open(d+'/bank.json'));P={}
    for g,f in c['packs'].items():P[g]=np.fromfile(d+'/'+f['file'],'<i2').astype(np.float32)/32768
    by={}
    for it in c['items']:
        x=P[it['p']][it['off']//2:it['off']//2+it['n']];it['_c']=feats(x);by.setdefault(it['fam'],[]).append(it)
    used={}
    for fam,L in by.items():
        L.sort(key=lambda i:i['_c']);names=ONO.get(fam,['Son']);gens=GEN.get(fam,['Électro']*3)
        for r,it in enumerate(L):
            q=r/max(1,len(L)-1);nm=ONO_K.get(it.get('k')) if it.get('k') else names[min(len(names)-1,int(q*len(names)))]
            g=gens[0 if q<.33 else (1 if q<.67 else 2)]
            if it['ms']>900 and fam in('texture','bruit','effet','inverse','metal'):g='Ambient' if g!='Cinéma' else g
            used[nm]=used.get(nm,0)+1;it['nm']=nm;it['g']=g
    tot={};
    for it in c['items']:tot[it['nm']]=tot.get(it['nm'],0)+1
    seen={}
    for it in c['items']:
        if tot[it['nm']]>1:seen[it['nm']]=seen.get(it['nm'],0)+1;it['nm']='%s %d'%(it['nm'],seen[it['nm']])
        it.pop('_c',None)
    json.dump(c,open(d+'/bank.json','w'),separators=(',',':'),ensure_ascii=False)
    import collections;print(collections.Counter(i['g'] for i in c['items']));print([i['nm'] for i in c['items'][::60]])
if __name__=='__main__':main(sys.argv[1])
