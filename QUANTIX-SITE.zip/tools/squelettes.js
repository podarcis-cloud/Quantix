/* R244 : piège « même squelette » — repère les niveaux d'un même monde dont l'entrée graphique se ressemble trop
   (départ, bassin, séparateur quantique, murs communs). Usage : node tools/squelettes.js [monde] */
require('./load.js');const LV=globalThis.__X.LEVELS;const only=+process.argv[2]||0;
const d=(a,b)=>a&&b?Math.hypot(a[0]-b[0],a[1]-b[1]):999;
const bord=w=>(w[0]===w[2]&&(w[0]===0||w[0]===360))||(w[1]===w[3]&&(w[1]===0||w[1]>=476));   /* bords du cadre : communs à tous, ignorés */
const ws=l=>new Set((l.w||[]).filter(w=>!bord(w)).map(w=>w.slice(0,4).map(v=>Math.round(v/10)).join(',')));
let n=0;for(let i=0;i<LV.length;i++)for(let j=i+1;j<LV.length;j++){const a=LV[i],b=LV[j];if(a.wd!==b.wd||(only&&a.wd!==only))continue;
 const bd=d(a.ball,b.ball),cd=d(a.cup,b.cup),sd=d(a.sup&&a.sup[0],b.sup&&b.sup[0]);const A=ws(a),B=ws(b);let com=0;A.forEach(k=>{if(B.has(k))com++;});
 const fr=(A.size+B.size)?2*com/(A.size+B.size):0;let s=(bd<25)+(cd<25)+(sd<25)+(fr>.5);
 if(s>=3){n++;console.log('Monde '+a.wd+' – niveaux '+(i-LV.findIndex(l=>l.wd===a.wd)+1)+' ('+a.n+') et '+(j-LV.findIndex(l=>l.wd===a.wd)+1)+' ('+b.n+') : départ '+Math.round(bd)+' · bassin '+Math.round(cd)+' · séparateur '+(sd<999?Math.round(sd):'—')+' · murs communs '+Math.round(fr*100)+' %');}}
console.log(n+' paire(s) trop proches');
