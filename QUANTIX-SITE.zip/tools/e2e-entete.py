# En-tête commun Pattern/Track (R391) : lignes 1 et 2 superposables
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
J="""(()=>{const o={};for(const [k,s] of Object.entries({mk:'header #tName,#mk',lang:'#bLang',close:'#qClose,#bClose',sec:'#qSec',svg:'#qSec svg',qt:'#qSec .qt',file:'#qFileBtn,#bFile',sw:'#qFloat,#bQt',tools:'#qTools,#tools'})){const e=document.querySelector(s);if(!e){o[k]=null;continue}const b=e.getBoundingClientRect();o[k]=[Math.round(b.left),Math.round(b.top),Math.round(b.right),Math.round(b.bottom)]}o.font=getComputedStyle(document.querySelector('#qSec .qt')).fontFamily+'|'+getComputedStyle(document.querySelector('header #tName,#mk')).fontFamily;return o})()"""
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.evaluate("localStorage.clear();localStorage.setItem('qx.lang','fr')");pg.reload();pg.wait_for_timeout(3500)
    pg.evaluate("scrollTo(0,0)");Q=pg.evaluate(J)
    pg.evaluate("document.getElementById('bLang').click()");pg.wait_for_timeout(200)
    chk(pg.evaluate("localStorage.getItem('qx.lang')") in('fr','en'),'langue mémorisée (partagée avec Track)')
    pg.evaluate("localStorage.setItem('qx.lang','fr')")
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1800)
    T=pg.evaluate(J)
    for k in ['mk','lang','close','svg','qt','sw']:
        chk(Q[k] and T[k] and all(abs(Q[k][i]-T[k][i])<=1 for i in range(4)),'ligne 1/2 alignée : '+k+' %s / %s'%(Q[k],T[k]))
    chk(abs(Q['file'][1]-T['file'][1])<=1 and abs(Q['file'][2]-T['file'][2])<=1,'Fichier : même hauteur, bord droit identique')
    chk(abs(Q['tools'][1]-T['tools'][1])<=1 and abs(Q['tools'][3]-T['tools'][3])<=1,'ligne 3 : outils à la même hauteur')
    chk(Q['font']==T['font'],'même police des titres')
    chk(not er,'aucune erreur JS %s'%er)
    print('RÉSULTAT',sum(res),'/',len(res));b.close()
