/* diag.js — R116 : pourquoi un geste échoue au doigt.
   node diag.js N fiche '{P}' '[[[x,y],[x,y]]]'  → 30 gestes humains (modèle EXEC de difficulty.js), issue de chacun :
   réussite, ou position finale de la particule (arrondie à 20 u) et cause probable. */
const DIF=require('./difficulty.js'),X=DIF.X,LAB=DIF.LAB;
const n=+process.argv[2],idx=n-1,inst=process.argv[3]==='-';   /* « - » : le niveau tel qu'installé, avec sa solution de référence */
const F=inst?{mat:X.LEVELS[idx].optmat||0}:require('./fiches/'+process.argv[3]+'.js');
const sol=inst?X.LEVELS[idx].optsol:JSON.parse(process.argv[5]);
if(!inst){const c=F.gen(JSON.parse(process.argv[4]));c.ink=+(process.env.INK||400);LAB.run(idx,c,[]);}if(inst&&process.env.INKX)X.LEVELS[idx].ink=Math.round(X.LEVELS[idx].ink*+process.env.INKX);DIF.setSeed(11);
const out={};let win=0;
for(let k=0;k<30;k++){const g=DIF.gesture(X.LEVELS[idx],sol,DIF.modelFor(idx),F.mat||0);X.loadLevel(idx);for(const s of g)X.S.strokes.push({pts:s.pts,len:1,birth:0,mat:s.mat});
 X.qpBuild();X.S.mode='run';let f=0;for(;f<1300&&X.S.mode==='run';f++)X.physics();
 if(X.S.mode==='success'){win++;continue;}
 const b=X.S.ball,key=(X.S.mode==='fail'?(b.y>470?'chute':'mort'):'arrêt')+'@'+Math.round(b.x/20)*20+','+Math.round(b.y/20)*20;out[key]=(out[key]||0)+1;}
console.log('réussites',win,'/ 30 ;',Object.entries(out).sort((a,b)=>b[1]-a[1]).map(e=>e[0]+'×'+e[1]).join('  '));
