"""rapport-finition.py — R92 : compte rendu de finition des 132 niveaux, à partir des mesures (finition.json),
du registre des fiches (fiches/registre.json) et des résultats du contrôle d'énigme (enigme_status.json).
A = fiche au registre + énigme ✓ + mesures propres ; B = mesures propres + (énigme ✓ ou fiche) ; C = jouable avec défauts ; D = brut."""
import json,os
H=os.path.dirname(os.path.abspath(__file__))
d=json.load(open(H+'/finition.json'));reg=json.load(open(H+'/fiches/registre.json'));E=json.load(open(H+'/enigme_status.json'))
fiche={int(k) for k in reg if k.isdigit()};OK=set(E['ok']);KO=set(E['ko'])-OK
mondes=['Atelier','Fonderie','Chaîne','Glacier','Soufflerie','Mécanique','Gravité','Magnétisme','Faille','Filaments','Quantique']
rows=[];cnt={'A':0,'B':0,'C':0,'D':0}
for k in range(1,133):
    r=d[str(k)];notes=[];triv=r['trivial'] if r['minLen'] is not None else False
    if triv:notes.append('un trait de %s u suffit'%r['minLen'])
    if r['direct']:notes.append('ligne directe gagnante (%d)'%r['direct'])
    if r.get('fieldNeeded') is False:notes.append('mécanique inutile')
    if not r['zoneOk']:notes.append('mur dans la zone')
    if r['alone']:notes.append('réussit sans trait')
    if r['sol'] and not r['solOk']:notes.append('solution enregistrée en échec')
    if not r['sol']:notes.append('aucune solution enregistrée')
    if k in KO:notes.append('contrôle énigme ✗')
    if k not in fiche:notes.append('pas de fiche')
    clean=r['solOk'] and not triv and not r['direct'] and r['zoneOk'] and r.get('fieldNeeded') is not False and not r['alone'] and k not in KO
    g='A' if clean and k in fiche and k in OK else 'B' if clean and (k in OK or k in fiche) else 'C' if r['solOk'] else 'D'
    cnt[g]+=1;rows.append((k,r['n'],g,r['minLen'],'; '.join(notes) or '—'))
md=['# QUANTIX — Compte rendu de finition des 132 niveaux','','*Généré par `tools/rapport-finition.py` à partir des mesures. Aucun niveau n\'a encore passé ton test : A = « candidat ».*','',
'| Note | Niveaux |','|---|---|']+['| %s | %d |'%(g,cnt[g]) for g in 'ABCD']+['','| Monde | A | B | C | D |','|---|---|---|---|---|']
for w in range(11):
    sub=[r for r in rows if (r[0]-1)//12==w];md.append('| %d %s | %s |'%(w+1,mondes[w],' | '.join(str(sum(1 for r in sub if r[2]==g)) for g in 'ABCD')))
md+=['','**A** : '+', '.join('%d %s'%(r[0],r[1]) for r in rows if r[2]=='A'),'','**B** : '+', '.join('%d %s'%(r[0],r[1]) for r in rows if r[2]=='B'),'']
for w in range(11):
    md+=['### Monde %d — %s'%(w+1,mondes[w]),'','| # | Niveau | Note | Plus petit trait gagnant | Ce qui manque |','|---|---|---|---|---|']
    for r in rows:
        if (r[0]-1)//12==w:md.append('| %d | %s | **%s** | %s | %s |'%(r[0],r[1],r[2],('%s u'%r[3]) if r[3] is not None else '—',r[4]))
    md.append('')
open(H+'/../docs/FINITION.md','w',encoding='utf-8').write('\n'.join(md));print(cnt)
print('A :',[r[0] for r in rows if r[2]=='A']);print('B :',[r[0] for r in rows if r[2]=='B'])
