/* noyau2.js — R118 : cherche un point (hors machine, dans la zone donnée) traversé par 15–35 % des solutions gagnantes, puis la
   solution passant par ce point la plus jouable au doigt. Affiche ; ÉCRIRE=1 écrit star + optsol dans levels.js. */
const DIF=require('./difficulty.js'),X=DIF.X,fs=require('fs');
const n=+process.argv[2],idx=n-1,LV=X.LEVELS[idx],Z=process.argv[3]?process.argv[3].split(',').map(Number):[0,0,360,480];
function run(strokes){X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:1,birth:0,mat:s.mat||0});X.qpBuild();X.S.mode='run';const tr=[];
 for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',tr};}
LV.star=null;const F=DIF.families(idx,LV);const W=[];for(const f of F.fam)for(const p of f.m){const r=run([{pts:p,mat:F.mat}]);if(r.ok)W.push({p,tr:r.tr});}
const inMz=(x,y)=>(LV.mz||[]).some(m=>x>m[0]&&x<m[0]+m[2]&&y>m[1]&&y<m[1]+m[3]);const C=[];
for(let x=Z[0];x<=Z[2];x+=8)for(let y=Z[1];y<=Z[3];y+=8){if(inMz(x,y))continue;const hit=W.filter(w=>w.tr.some(r=>Math.hypot(r[0]-x,r[1]-y)<20.5));const f=hit.length/Math.max(1,W.length);if(f>=.15&&f<=.35)C.push({x,y,f,hit});}
C.sort((a,b)=>Math.abs(a.f-.25)-Math.abs(b.f-.25));let best=null;
for(const c of C.slice(0,10)){LV.star=[c.x,c.y];for(const w of c.hit.slice(0,6)){DIF.setSeed(7);const r=DIF.P(idx,LV,[w.p],DIF.modelFor(idx),F.mat,20);if(!best||r.star>best.ps)best={star:[c.x,c.y],f:c.f,sol:w.p,ps:r.star,pw:r.win};}}
console.log('#'+n,'gagnants',W.length,'| candidats',C.length,best?'| noyau '+JSON.stringify(best.star)+' ('+Math.round(best.f*100)+' % des solutions) | sol '+JSON.stringify(best.sol)+' | au doigt : gagne '+Math.round(best.pw*100)+' %, noyau '+Math.round(best.ps*100)+' %':'| aucun point à 15–35 %');
