/* scan132.js N — R261 : radiographie d'un niveau, pour le scan des 132 niveaux (une commande = un niveau).
   Mesure, avec le vrai moteur :
   - encre de départ (finie, > 2, égale au quota) ; sans trait : doit échouer ;
   - solution de référence (optsol) : gagne ? noyau ? encre (% du quota), durée de chute, dessinable ?
   - balayage de LIGNES DROITES (centre sur une grille de 20, 8 angles sur 180° — 16 sur 360° pour l'élan —,
     7 longueurs, chaque matière de la palette) : gagnants, P_hasard, ENCRE MINIMALE d'un gagnant, familles ;
   - contournement : chaque gagnant est rejoué dans le niveau privé de sa mécanique (champs retirés, matières
     mécaniques des murs ramenées à la structure) ; s'il gagne encore, il ignore la mécanique ;
   - obstacles muets : murs dont aucun gagnant (ni la référence) ne passe à moins de 16 px.
   Sortie : une ligne JSON (stdout). */
require('./load.js');
const X=globalThis.__X,D=require('./design.js');
const N=+process.argv[2],idx=N-1,LV=X.LEVELS[idx];
const COST={0:1,1:1.9,3:1.7,5:1.4},PM={S:0,B:1,C:3,A:5};
const FIELDS=['wind','grav','mag','port','mov','ent','gate','sup','det','tdil','rails','flow','vortex','updraft','pend','well','bf','kick','wrap','strings','elastic','strE','sling','fork','coil','spectro','rec','softball'];
const MECA=[1,3,4];
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function run(strokes,keepTrail){X.loadLevel(idx);const S=X.S;
 for(const s of strokes)S.strokes.push({pts:s.pts.map(q=>[q[0],q[1]]),len:plen(s.pts),birth:0,mat:s.mat||0});
 X.qpBuild();S.mode='run';const tr=[];let f=0;
 for(;f<1200&&S.mode==='run';f++){X.physics();if(keepTrail&&f%3===0)tr.push([S.ball.x,S.ball.y]);}
 return {ok:S.mode==='success',star:!!S.gotStar,f,tr};}
/* état d'origine, pour pouvoir retirer puis remettre la mécanique */
const SAVE={};for(const k of FIELDS.concat(['w']))SAVE[k]=LV[k];
function strip(on){for(const k of FIELDS){if(on){if(LV[k]!=null)LV[k]=Array.isArray(LV[k])?[]:null;}else LV[k]=SAVE[k];}
 LV.w=on?(SAVE.w||[]).map(s=>[s[0],s[1],s[2],s[3],MECA.includes(s[4])?0:s[4]].concat(s.slice(5))):SAVE.w;
 LV._rb=null;LV._cv=null;
 /* les murs calculés à partir de w (coupe comprise) */
 const SOLID=0;LV.walls=(LV.w||[]).slice();const c=LV.cup;if(c){const [x,y,w,s]=c;LV.walls.push([x,y,x+w,y,SOLID]);if(s==='R'||s==='B')LV.walls.push([x+w,y,x+w,y-56,SOLID]);if(s==='L'||s==='B')LV.walls.push([x,y,x,y-56,SOLID]);}}
const hasMeca=FIELDS.some(k=>LV[k]&&(!Array.isArray(LV[k])||LV[k].length))||(LV.w||[]).some(s=>MECA.includes(s[4]));
X.loadLevel(idx);
const out={n:N,nom:LV.n,wd:LV.wd,ink:LV.ink,pal:LV.pal,ball:LV.ball,cup:LV.cup,
 kinds:FIELDS.filter(k=>LV[k]&&(!Array.isArray(LV[k])||LV[k].length)).map(k=>k+':'+(Array.isArray(LV[k])?LV[k].length:1)),
 murs:(LV.w||[]).length,mursMeca:(LV.w||[]).filter(s=>MECA.includes(s[4])).length,nd:(LV.nd||[]).length,mz:!!LV.mz,
 encreDepart:X.S.ink,encreOK:isFinite(X.S.ink)&&X.S.ink>2&&X.S.ink===X.S.inkMax};
out.vide=run([]).ok?'GAGNE SEUL':'échoue';
let refTr=[];
if(LV.optsol){const st=LV.optsol.map(p=>({pts:p,mat:LV.optmat||0}));const r=run(st,true);refTr=r.tr;
 const c=Math.round(LV.optsol.reduce((a,p)=>a+plen(p),0)*(COST[LV.optmat||0]||1));
 out.ref={gagne:r.ok,noyau:r.star,encre:c,pct:Math.round(c/LV.ink*100),traits:LV.optsol.length,points:LV.optsol.reduce((a,p)=>a+p.length,0),chute:+(r.f/60).toFixed(1),
  dessinable:LV.optsol.every(p=>D.drawable(LV,p))};
 if(hasMeca){strip(true);out.ref.sansMeca=run(st).ok;strip(false);}}
else out.ref=null;
/* balayage */
const mats=[...new Set((LV.pal||'S').split('').map(ch=>PM[ch]).filter(m=>m!=null))];if(!mats.length)mats.push(0);
const LENS=[20,35,55,80,110,150,200,260];let tested=0;const wins=[];
for(let cx=10;cx<=350;cx+=20)for(let cy=20;cy<=470;cy+=20)for(const m of mats){const na=m===5?16:8,span=m===5?2*Math.PI:Math.PI;
 for(let ai=0;ai<na;ai++){const a=span*ai/na;for(const L of LENS){const cost=L*(COST[m]||1);if(cost>LV.ink)continue;
  const dx=Math.cos(a)*L/2,dy=Math.sin(a)*L/2,p=[[Math.round(cx-dx),Math.round(cy-dy)],[Math.round(cx+dx),Math.round(cy+dy)]];
  if(!D.drawable(LV,p))continue;tested++;const r=run([{pts:p,mat:m}],true);
  if(r.ok)wins.push({p,m,cost:Math.round(cost),star:r.star,f:r.f,tr:r.tr});}}}
out.essais=tested;out.gagnants=wins.length;out.P_hasard=tested?+(wins.length/tested).toFixed(4):0;
if(wins.length){wins.sort((a,b)=>a.cost-b.cost);const w0=wins[0];out.min={encre:w0.cost,pct:Math.round(w0.cost/LV.ink*100),trait:w0.p,mat:w0.m,noyau:w0.star,chute:+(w0.f/60).toFixed(1)};
 const ws=wins.filter(w=>w.star);if(ws.length){ws.sort((a,b)=>a.cost-b.cost);out.minNoyau={encre:ws[0].cost,pct:Math.round(ws[0].cost/LV.ink*100),trait:ws[0].p};}
 out.noyauPct=Math.round(100*ws.length/wins.length);
 /* familles : où et comment le trait est posé (cellules de 60 px du milieu × 4 orientations) */
 const fam=new Set(wins.map(w=>{const a=Math.atan2(w.p[1][1]-w.p[0][1],w.p[1][0]-w.p[0][0]);return Math.floor((w.p[0][0]+w.p[1][0])/120)+','+Math.floor((w.p[0][1]+w.p[1][1])/120)+','+(((Math.round(a/(Math.PI/4))%4)+4)%4);}));
 out.familles=fam.size;
 /* contournement */
 if(hasMeca){strip(true);let by=0;const ex=[];for(const w of wins){if(run([{pts:w.p,mat:w.m}]).ok){by++;if(ex.length<2)ex.push(w.p);}}strip(false);out.contournants=by;out.contournPct=Math.round(100*by/wins.length);out.exContourne=ex;}
}
/* murs muets : aucun gagnant ni la référence ne passe près */
const trs=wins.map(w=>w.tr).concat(refTr.length?[refTr]:[]);
function dseg(x,y,s){const ax=s[2]-s[0],ay=s[3]-s[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((x-s[0])*ax+(y-s[1])*ay)/l)):0;return Math.hypot(x-s[0]-u*ax,y-s[1]-u*ay);}
if(trs.length){out.mursMuets=(LV.w||[]).map((s,k)=>({k,s})).filter(o=>!trs.some(tr=>tr.some(q=>dseg(q[0],q[1],o.s)<16))).map(o=>o.k);}
console.log(JSON.stringify(out));
