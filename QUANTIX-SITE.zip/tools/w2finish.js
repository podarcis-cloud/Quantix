/* Finalise un niveau du monde 2 : balayage fin, noyau (15–35 % des solutions), solution avec noyau
   la plus tolérante au doigt (±4 px). Écrit w2final.json. */
const LAB=require('./lab.js'),C=require('./w2cand.js'),fs=require('fs');
const f=process.env.OUT||'w2final.json',out=fs.existsSync(f)?JSON.parse(fs.readFileSync(f)):{};
function tol(idx,c,s){let ok=0,n=0;for(let pi=0;pi<s.pts.length;pi++)for(const dx of [-4,0,4])for(const dy of [-4,0,4]){
  const pts=s.pts.map((q,i)=>i===pi?[q[0]+dx,q[1]+dy]:q);n++;if(LAB.run(idx,c,[{pts,mat:s.mat}]).ok)ok++;}return ok/n;}
for(const k of process.argv.slice(2)){const c=C[k];
 const o=LAB.report(+k,c,{grid:{step:+(process.env.STEP||10),da:+(process.env.DA||.28),lens:[25,40,60,85,115,150,190]}});
 const st=LAB.star(o,[0,20,360,470]);let best=null;
 if(st){const c2=Object.assign({},c,{star:[st.x,st.y]});
  const cand=o.wins.filter(w=>w.tr.some(q=>Math.hypot(q[0]-st.x,q[1]-st.y)<20.5)).slice(0,+(process.env.NT||25));
  for(const w of cand){const r=LAB.run(+k,c2,[{pts:w.pts,mat:w.mat}]);if(!r.ok||!r.star)continue;const t=tol(+k,c2,w);
   if(!best||t>best.t)best={pts:w.pts,mat:w.mat,t};}}
 out[k]={n:c.n,gagnants:o.avec,star:st&&[st.x,st.y],starPct:st&&st.f,sol:best&&[best.pts],mat:best&&best.mat,tol:best&&Math.round(best.t*100)};
 fs.writeFileSync(f,JSON.stringify(out,null,1));
 console.log(`#${+k+1} ${c.n.padEnd(17)} gagnants ${o.avec} | noyau ${st?JSON.stringify([st.x,st.y])+' ('+Math.round(st.f*100)+' %)':'AUCUNE POSITION'} | solution avec noyau : ${best?'tolérance '+Math.round(best.t*100)+' %':'AUCUNE'}`);}
