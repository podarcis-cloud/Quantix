# Wave du lecteur R398 : nuée rouge + houle Cuivre (qwave.js), repli, repliage
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    chk(pg.evaluate("typeof window.QWV")=='object','moteur qwave.js chargé')
    N="(()=>{const c=document.getElementById('qWave');const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=0;i<d.length;i+=4)if(d[i]>60||d[i+1]>50)n++;return n})()"
    pg.wait_for_timeout(1500);idle=pg.evaluate(N)
    pg.click('#bPlay');pg.wait_for_timeout(3500);play=pg.evaluate(N)
    chk(play>1500,'en lecture la wave se dessine (%d px vifs)'%play)
    chk(pg.evaluate("typeof window.QWV")=='object','pas de repli après erreur')
    ms=pg.evaluate("(()=>new Promise(r=>{let n=0,t0=performance.now();const f=()=>{n++;if(n<50)requestAnimationFrame(f);else r((performance.now()-t0)/50)};f()}))()")
    chk(ms<40,'fluidité %.1f ms/image'%ms)
    pg.click('#qFold');pg.wait_for_timeout(700);h=pg.evaluate("document.querySelector('.qwv').getBoundingClientRect().height")
    chk(h<60,'wave repliée (%d px)'%h)
    pg.click('#qFold');pg.wait_for_timeout(700);pg.click('#bPlay');pg.wait_for_timeout(600)
    chk(pg.evaluate("document.querySelector('.qwv').getBoundingClientRect().height")>70,'wave dépliée')
    chk(not er,'aucune erreur de page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
