"""build_bio.py — pack-bio.bin : sons visqueux / organiques / grouillants (synthèse numpy, 32 kHz, mono Int16).
Usage : python3 build_bio.py <dossier assets/bank>  → écrit pack-bio.bin et ajoute les entrées à bank.json (idempotent)."""
import numpy as np, json, sys, os
from scipy.signal import lfilter, sosfilt, butter
SR=32000
def rng(s):return np.random.default_rng(s)
def t_(d):return np.arange(int(d*SR))/SR
def bq_bp(f,q):
    w=2*np.pi*min(f,SR*.45)/SR;a=np.sin(w)/(2*q);b=np.array([a,0,-a]);aa=np.array([1+a,-2*np.cos(w),1-a]);return b/aa[0],aa/aa[0]
def bq_lp(f,q):
    w=2*np.pi*min(f,SR*.45)/SR;a=np.sin(w)/(2*q);c=np.cos(w);b=np.array([(1-c)/2,1-c,(1-c)/2]);aa=np.array([1+a,-2*c,1-a]);return b/aa[0],aa/aa[0]
def sweep_filter(x,fcurve,q,kind='bp'):
    out=np.zeros_like(x);zi=np.zeros(2);B=64
    for i in range(0,len(x),B):
        f=fcurve[min(i,len(fcurve)-1)];b,a=(bq_bp if kind=='bp' else bq_lp)(f,q)
        y,zi=lfilter(b,a,x[i:i+B],zi=zi);out[i:i+B]=y
    return out
def smooth_noise(r,n,rate):
    k=max(2,int(n*rate/SR)+2);v=r.standard_normal(k);return np.interp(np.arange(n)/n*(k-1),np.arange(k),v)
def env_exp(n,tau):return np.exp(-np.arange(n)/SR/tau)
def fin(x,peak=.85):
    x=np.asarray(x,float);x=x-np.mean(x);m=np.max(np.abs(x))+1e-9;x=x/m*peak;n=len(x);a=int(.003*SR);b=int(.01*SR)
    x[:a]*=np.linspace(0,1,a);x[-b:]*=np.linspace(1,0,b);return x
def bloup(r,v):  # bulle visqueuse
    d=.12+.5*r.random();t=t_(d);f0=90+r.random()*220;k=3+r.random()*7;f=f0*(1+k*t/d*(.4+r.random()*.6))
    ph=2*np.pi*np.cumsum(f)/SR;x=np.sin(ph)*env_exp(len(t),d*.35)+.35*np.sin(ph*.5)*env_exp(len(t),d*.5);return x
def squelch(r,v): # slime : bruit filtré balayé + modulation irrégulière
    d=.35+.9*r.random();n=int(d*SR);x=r.standard_normal(n);fc=250+1800*np.abs(smooth_noise(r,n,6+r.random()*8))
    y=sweep_filter(x,fc,6+r.random()*6);am=np.clip(.5+.6*smooth_noise(r,n,9),0,None)**2;return y*am*np.hanning(n)**.5
def wobble(r,v):  # basse gélatineuse
    d=.8+r.random()*.9;n=int(d*SR);t=np.arange(n)/SR;f=45+r.random()*35;ph=2*np.pi*np.cumsum(f*(1+.18*np.sin(2*np.pi*(2+r.random()*3)*t)))/SR
    x=np.sin(ph)+.5*np.sin(2*ph+1)+.25*np.sin(3*ph);fc=120+380*(.5+.5*np.sin(2*np.pi*(1.5+r.random()*2.5)*t));return sweep_filter(x,fc,3+r.random()*3,'lp')*np.minimum(1,t*30)*env_exp(n,d*.7)
def swarm(r,v):  # grouillement : micro-clics en essaim
    d=.7+r.random()*1.1;n=int(d*SR);out=np.zeros(n);dens=np.clip(.55+.5*smooth_noise(r,n,3),.05,None)
    pos=0
    while pos<n:
        pos+=int(SR/(60+260*dens[min(pos,n-1)])*(.3+r.random()*1.4))
        if pos>=n-300:break
        L=int(.004*SR*(.4+r.random()*2));tt=np.arange(L)/SR;f=1800+r.random()*4200
        out[pos:pos+L]+=(.2+.8*r.random())*np.sin(2*np.pi*f*tt*(1-.4*tt/(L/SR)))*np.exp(-tt/(.0012+.0015*r.random()))
    low=sweep_filter(r.standard_normal(n),np.full(n,500+600*r.random()),2,'lp')*.12*np.abs(smooth_noise(r,n,10))
    return (out+low)*np.sin(np.pi*np.arange(n)/n)**.4
def wetclick(r,v):  # pop humide
    d=.05+.12*r.random();t=t_(d);f=300+r.random()*900;ph=2*np.pi*np.cumsum(f*(1+2.5*np.exp(-t/.012)))/SR
    return np.sin(ph)*env_exp(len(t),.02+.03*r.random())+.15*r.standard_normal(len(t))*env_exp(len(t),.004)
def drop(r,v): # goutte + écho mouillé
    t=t_(.1);f=500+r.random()*1100;ph=2*np.pi*np.cumsum(f*(1+1.4*t/.1))/SR;g=np.sin(ph)*env_exp(len(t),.025);n=int((.5+.5*r.random())*SR);o=np.zeros(n);o[:len(g)]+=g
    for k,(dl,a) in enumerate([(.11,.4),(.19,.22),(.31,.12)]):
        s=int(dl*SR)+int(r.random()*300);
        if s+len(g)<n:o[s:s+len(g)]+=a*g*(1.0+.1*k)
    return o
def breath(r,v):  # souffle organique
    d=.7+r.random()*.9;n=int(d*SR);x=r.standard_normal(n);fc=900+1500*(.5+.5*np.sin(2*np.pi*np.arange(n)/n*(.7+r.random()*.6)+r.random()*6))
    return sweep_filter(x,fc,1.6+r.random()*2)*np.sin(np.pi*np.arange(n)/n)**1.5
def vowel(r,v):  # voyelle chantée "ouu/aah"
    F=[[300,870,2240],[400,800,2600],[350,600,2400],[550,1100,2500]][int(r.integers(0,4))];d=.9+r.random()*.9;n=int(d*SR);t=np.arange(n)/SR
    f0=70+r.random()*90;vib=1+.015*np.sin(2*np.pi*(4.5+r.random())*t)*np.minimum(1,t*2);ph=2*np.pi*np.cumsum(f0*vib)/SR
    src=sum(np.sin(k*ph)/k for k in range(1,28));y=sum(a*sweep_filter(src,np.full(n,f*(1+.05*np.sin(2*np.pi*.7*t))),9) for a,f in zip([1,.6,.3],F))
    return y*np.sin(np.pi*t/d)**1.3
def slap(r,v):  # claque de membrane / tentacule
    t=t_(.25+.2*r.random());f=60+r.random()*70;ph=2*np.pi*np.cumsum(f*(1+1.6*np.exp(-t/.05)))/SR
    nz=sweep_filter(r.standard_normal(len(t)),np.full(len(t),400+r.random()*700),2.5)*env_exp(len(t),.03);return np.sin(ph)*env_exp(len(t),.09)+.8*nz
def pulse(r,v):  # pouls organique (double battement)
    g=.28+.12*r.random();n=int((.55+.2*r.random())*SR);o=np.zeros(n)
    for dl,a in [(0,1),(g,.65)]:
        t=t_(.2);f=48+r.random()*12;ph=2*np.pi*np.cumsum(f*(1+.8*np.exp(-t/.04)))/SR;k=np.sin(ph)*env_exp(len(t),.07);s=int(dl*SR);o[s:s+len(k)]+=a*k[:max(0,min(len(k),n-s))] if s+len(k)<=n else 0
    return o
def drip_visc(r,v): # filet visqueux qui s'étire
    d=1.0+r.random();n=int(d*SR);t=np.arange(n)/SR;f=160+120*r.random();ph=2*np.pi*np.cumsum(f*np.exp(-t*(.5+r.random()))*(1+.25*np.sin(2*np.pi*6*t)))/SR
    return (np.sin(ph)+.3*np.sin(3*ph))*np.sin(np.pi*t/d)**.6*(.6+.4*np.sin(2*np.pi*3*t))
def crackle(r,v): # craquement de matière vivante
    d=.5+r.random()*.8;n=int(d*SR);x=np.zeros(n);i=0
    while i<n:
        i+=int(r.exponential(.012)*SR)+20
        if i<n-200:x[i:i+200]+=r.standard_normal(200)*np.exp(-np.arange(200)/(20+60*r.random()))*r.random()
    return sweep_filter(x,np.full(n,1200+2500*r.random()),1.2)*np.sin(np.pi*np.arange(n)/n)**.5
TYPES=[('visqueux','bloup',bloup,'Bloup'),('visqueux','squelch',squelch,'Squelch'),('visqueux','filet',drip_visc,'Filet'),('visqueux','wobble',wobble,'Wouaou'),
       ('grouillant','swarm',swarm,'Grouillement'),('grouillant','crackle',crackle,'Crépite'),('organique','wetclick',wetclick,'Plop'),('organique','drop',drop,'Gout'),
       ('organique','breath',breath,'Souffle'),('organique','vowel',vowel,'Ouuu'),('organique','slap',slap,'Flop'),('organique','pulse',pulse,'Poul')]
PER=8
def main(d):
    cat=json.load(open(d+'/bank.json'));cat['items']=[i for i in cat['items'] if i.get('p')!='bio'];cat['packs'].pop('bio',None)
    blobs=[];off=0;items=[];c={}
    for ti,(fam,kind,fn,nm) in enumerate(TYPES):
        for k in range(PER):
            r=rng(1000+ti*97+k);x=fin(fn(r,k));q=np.round(x*32767).astype('<i2');c[fam]=c.get(fam,0)+1
            items.append({'id':'%s-%03d'%(fam[:3],c[fam]),'fam':fam,'k':kind,'d':'long' if len(x)>SR*.6 else ('moyen' if len(x)>SR*.2 else 'court'),'t':'sombre','p':'bio','off':off,'n':int(len(q)),'ms':int(len(q)/SR*1000)});blobs.append(q.tobytes());off+=len(q)*2
    data=b''.join(blobs);open(d+'/pack-bio.bin','wb').write(data)
    cat['packs']['bio']={'file':'pack-bio.bin','bytes':len(data),'count':len(items)};cat['items']+=items;json.dump(cat,open(d+'/bank.json','w'),separators=(',',':'),ensure_ascii=False)
    print(len(items),'sons bio',len(data),'octets')
if __name__=='__main__':main(sys.argv[1])
