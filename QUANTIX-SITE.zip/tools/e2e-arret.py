# Arrêt / relance de Quantone (serveur local requis : python3 -m http.server 8765 depuis la racine)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page();cdp=pg.context.new_cdp_session(pg);errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("QFX3.load({quantone:1,world:0,root:4,scale:'none',k:{tempo:120},strokes:[{l:0,p:[[.05,.3],[.5,.5],[.9,.4]]},{l:2,p:[[.1,.6],[.6,.3]]}]})")
    cdp.send('Emulation.setCPUThrottlingRate',{'rate':6})
    r=pg.evaluate("""async()=>{const o=[],lv=[];for(let i=0;i<8;i++){QUANTONE.play();let pk=0;for(let k=0;k<14;k++){await new Promise(r=>setTimeout(r,60));pk=Math.max(pk,QUANTONE.level());}lv.push(pk);const t=performance.now();QUANTONE.stop();o.push(performance.now()-t);await new Promise(r=>setTimeout(r,i%2?900:100));}return [o,lv]}""")
    chk(max(r[0])<40,'arrêt rapide (CPU ×6), max %.0f ms'%max(r[0]))
    chk(min(r[1])>.005,'8 relances sonnent (pic sur ~0,8 s), min %.3f'%min(r[1]))
    chk(not errs,'aucune erreur %s'%errs)
print('RÉSULTAT',sum(res),'/',len(res))
