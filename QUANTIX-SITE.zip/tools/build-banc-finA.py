"""build-banc-finA.py — banc de la fin (R214) : le héros et la fin côte à côte, à la même seconde, en mouvement.
Sortie : studio/banc-finA.html (autonome : visuals.js et hero.js embarqués deux fois, pour que les deux films ne partagent
ni éclats ni chocs). Outil d'atelier : textes en français, hors du jeu."""
import base64,os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p):return open(os.path.join(ROOT,p),encoding='utf-8').read()
def uri(p):return 'data:image/jpeg;base64,'+base64.b64encode(open(os.path.join(ROOT,p),'rb').read()).decode()
vis=rd('assets/js/visuals.js');hero=rd('assets/js/hero.js')
assert hero.count('var QHERO=')==1 and hero.count('window.QHERO=QHERO')==1
heroH=hero.replace('var QHERO=','var QHEROH=').replace('window.QHERO=QHERO','window.QHEROH=QHEROH')
imgs='window.QHERO_IMG=['+','.join('"'+uri('assets/img/hero/h%02d.jpg'%(k+1))+'"' for k in range(11))+'];'
page=r'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Banc de la fin A</title>
<style>
:root{--bg:#05070D;--panel:#0A0F18;--line:#26334A;--fg:#E8EEF4;--mute:#8896AB;--cyan:#4DD7FF;--violet:#A878FF;color-scheme:dark}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.4 -apple-system,"Avenir Next",system-ui,sans-serif;padding:10px max(16px,env(safe-area-inset-right)) 24px max(16px,env(safe-area-inset-left))}
h1{font-weight:500;font-size:13px;letter-spacing:.14em;text-transform:uppercase;margin:4px 0 10px;color:var(--mute)}
.stages{display:flex;gap:8px;justify-content:center}
.st{flex:1 1 0;max-width:calc(74svh*9/19.5);min-width:0}
.st canvas{display:block;width:100%;aspect-ratio:9/19.5;background:#000;border:1px solid var(--line);border-radius:6px}
.st b{display:block;font-weight:500;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--mute);margin:0 0 4px}
.solo #wH{display:none}.solo .st{max-width:calc(80svh*9/19.5)}
.bar{position:relative;height:44px;margin-top:12px;border:1px solid var(--line);border-radius:4px;background:var(--panel);touch-action:none;cursor:ew-resize;overflow:hidden;display:flex}
.bar i{display:block;height:100%;border-right:1px solid var(--bg);background:rgba(77,215,255,.08);font:10px ui-monospace,Menlo,monospace;color:var(--mute);padding:3px 2px;overflow:hidden;white-space:nowrap;font-style:normal}
.bar i:nth-child(even){background:rgba(168,120,255,.1)}
.bar s{position:absolute;top:0;bottom:0;width:3px;background:#fff;box-shadow:0 0 8px var(--cyan);pointer-events:none;left:0}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px}
button{font:500 13px inherit;font-family:inherit;color:var(--fg);background:var(--panel);border:1px solid var(--line);border-radius:4px;padding:9px 13px;min-height:40px;cursor:pointer}
button.on{border-color:var(--cyan);color:var(--cyan);background:rgba(77,215,255,.1)}
button.go{background:var(--cyan);color:#021018;border-color:var(--cyan);min-width:92px;font-weight:600}
.t{font:12px ui-monospace,Menlo,monospace;color:var(--mute);margin-left:auto}
p{color:var(--mute);font-size:12.5px;max-width:64ch;margin:10px 0 0}
</style></head><body>
<h1>Banc de la fin · héros et retour, à la même seconde</h1>
<div class="stages" id="stages"><div class="st" id="wH"><b>Héros (accueil)</b><canvas id="cH"></canvas></div><div class="st"><b id="lF">Fin · R215</b><canvas id="cF"></canvas></div></div>
<div class="bar" id="bar"><s id="head"></s></div>
<div class="row"><button id="bRe" type="button" aria-label="Revenir au début">⏮</button><button id="bPlay" class="go" type="button">Pause</button>
<button data-sp=".25" type="button">¼</button><button data-sp=".5" type="button">½</button><button data-sp="1" type="button" class="on">×1</button><span class="t" id="tOut">0,0 s</span></div>
<div class="row"><button id="vBoth" type="button" class="on">Côte à côte</button><button id="vSolo" type="button">Fin seule</button>
<button id="mA" type="button" class="on">Nouvelle fin (R215)</button><button id="mOld" type="button">Jeu actuel (R207)</button></div>
<p>R215 : la fin de la nouvelle discussion (escaliers, magnétron, cyclone de glace…) avec la vague, la Gravité sans planète, et sous chaque scène le fond animé du monde, comme dans les niveaux.</p>
<script>var S={t:0,tick:0,ndHit:null,ndg:[],ndgCur:null};var BUS={on:function(){},emit:function(){}};var OPT={rm:false};window.QFIN_A=true;</script>
<script>__VIS__</script><script>window.VX1=window.VX;</script>
<script>__VIS__</script><script>window.VX2=window.VX;</script>
<script>__IMGS__</script>
<script>__HERO__</script>
<script>__HEROH__</script>
<script>
(function(){
var $=function(i){return document.getElementById(i);},F=window.QHERO,H=window.QHEROH,cF=$('cF'),cH=$('cH'),xF=cF.getContext('2d'),xH=cH.getContext('2d');
var NM=['Atelier','Fonderie','Chaîne','Glacier','Soufflerie','Mécanique','Gravité','Magnétisme','Faille','Filaments','Quantique','Arrivée'];
var need=true,t=0,playing=true,speed=1,last=0,solo=false,total=0,acts=[],tiny=document.createElement('canvas'),tinyH=document.createElement('canvas');tiny.width=tinyH.width=90;tiny.height=tinyH.height=195;
function setup(){var bar=$('bar'),segs;Array.prototype.slice.call(bar.querySelectorAll('i')).forEach(function(e){e.remove();});
 if(window.QFIN_A){var f5=F.fin5;acts=f5.acts().map(function(a){return [a.nm,a.t0,a.d];});total=f5.total();segs=acts.slice();segs.push(['Plongée',f5.chaseEnd(),f5.fuseEnd()-f5.chaseEnd()]);segs.push(['Atome',f5.fuseEnd(),total-f5.fuseEnd()]);}
 else{var CE=F.chaseT();acts=[];total=CE+2300+9500;segs=[['Retour R207',0,CE],['Fusion',CE,2300],['Danse',CE+2300,9500]];}
 segs.forEach(function(s){var e=document.createElement('i');e.style.width=(s[2]/total*100)+'%';e.textContent=s[0];e.title=s[0];e.onclick=function(){};bar.insertBefore(e,$('head'));});}
function fit(cv){var r=cv.getBoundingClientRect(),d=Math.min(window.devicePixelRatio||1,2),W=Math.max(2,Math.round(r.width*d)),Hh=Math.max(2,Math.round(r.height*d));if(cv.width!==W||cv.height!==Hh){cv.width=W;cv.height=Hh;}}
function drawF(c,W,Hh,v){S.tick=v/16;S.t=v/16;window.VX=window.VX2;if(window.QFIN_A)F.fin5.render(c,W,Hh,v,{title:'QUANTIX'});else F.epilogue(c,W,Hh,1+v,{title:'QUANTIX'});}
function drawH(c,W,Hh,v){S.tick=v/16;S.t=v/16;window.VX=window.VX1;H.frame(c,W,Hh,1+v,{});}
function seek(v){need=true;t=Math.max(0,Math.min(total,v));F.epReset();H.reset();var a=tiny.getContext('2d'),b=tinyH.getContext('2d');var f0=window.QFIN_A?Math.max(0,t-200):0;for(var k=f0;k<t-16;k+=16)drawF(a,90,195,k);if(!solo)for(k=0;k<t-16;k+=16)drawH(b,90,195,k);}
var bar=$('bar'),drag=false;function pos(e){var r=bar.getBoundingClientRect();return Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*total;}
bar.addEventListener('pointerdown',function(e){drag=true;bar.setPointerCapture(e.pointerId);});bar.addEventListener('pointerup',function(e){if(drag){drag=false;seek(pos(e));}});
function toggle(){playing=!playing;if(playing&&t>=total)seek(0);$('bPlay').textContent=playing?'Pause':'Lecture';}
$('bPlay').onclick=toggle;$('bRe').onclick=function(){seek(0);playing=true;$('bPlay').textContent='Pause';};
Array.prototype.forEach.call(document.querySelectorAll('[data-sp]'),function(b){b.onclick=function(){speed=parseFloat(b.dataset.sp);Array.prototype.forEach.call(document.querySelectorAll('[data-sp]'),function(x){x.classList.toggle('on',x===b);});};});
function view(s){solo=s;$('stages').classList.toggle('solo',s);$('vBoth').classList.toggle('on',!s);$('vSolo').classList.toggle('on',s);seek(t);}
$('vBoth').onclick=function(){view(false);};$('vSolo').onclick=function(){view(true);};
function mode(a){window.QFIN_A=a;$('mA').classList.toggle('on',a);$('mOld').classList.toggle('on',!a);$('lF').textContent=a?'Fin · R215':'Fin · jeu actuel (R207)';setup();seek(0);}
$('mA').onclick=function(){mode(true);};$('mOld').onclick=function(){mode(false);};
document.addEventListener('keydown',function(e){if(e.code==='Space'){e.preventDefault();toggle();}});
function frame(ts){var dt=last?Math.min(48,ts-last):0;last=ts;var w0=cF.width;fit(cF);if(!solo)fit(cH);if(cF.width!==w0)need=true;
 if(playing&&!drag){t+=dt*speed;if(t>=total){t=total;playing=false;$('bPlay').textContent='Lecture';}}
 if(playing||need){need=false;try{drawF(xF,cF.width,cF.height,t);if(!solo)drawH(xH,cH.width,cH.height,t);}catch(e){window.__err=String(e&&e.stack||e);}}
 $('head').style.left=(t/total*100)+'%';$('tOut').textContent=(t/1000).toFixed(1).replace('.',',')+' s';requestAnimationFrame(frame);}
window.__banc={seek:function(v){seek(v);playing=false;},total:function(){return total;},acts:function(){return acts;},solo:view,mode:mode};
setup();requestAnimationFrame(frame);
})();
</script></body></html>'''
page=page.replace('__VIS__',vis).replace('__IMGS__',imgs).replace('__HERO__',hero,1).replace('__HEROH__',heroH,1)
out=os.path.join(ROOT,'studio/banc-finA.html');open(out,'w',encoding='utf-8').write(page);print(out,'%.1f Mo'%(len(page.encode())/1e6))
