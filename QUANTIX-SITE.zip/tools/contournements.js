/* scan.js a b → scan.jsonl : traits droits uniques gagnants ; « nus » = trajectoire qui ne touche aucun élément du niveau */
require('/home/claude/site/q/tools/load.js');const X=globalThis.__X,fs=require('fs');const R=10.5;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function dseg(px,py,s){const ax=s[2]-s[0],ay=s[3]-s[1],l=ax*ax+ay*ay;let u=l?((px-s[0])*ax+(py-s[1])*ay)/l:0;u=Math.max(0,Math.min(1,u));return Math.hypot(px-s[0]-ax*u,py-s[1]-ay*u);}
function shapes(lv){const segs=[],rects=[],circ=[];const cu=lv.cup;
 const cupS=[[cu[0],cu[1],cu[0]+cu[2],cu[1]],[cu[0]+cu[2],cu[1],cu[0]+cu[2],cu[1]-56],[cu[0],cu[1],cu[0],cu[1]-56]];
 const isCup=s=>cupS.some(q=>Math.abs(q[0]-s[0])+Math.abs(q[1]-s[1])+Math.abs(q[2]-s[2])+Math.abs(q[3]-s[3])<1);
 (lv.walls||[]).forEach(s=>{if(!isCup(s))segs.push(s);});
 const A=k=>lv[k]?(Array.isArray(lv[k])&&Array.isArray(lv[k][0])?lv[k]:[lv[k]]):[];
 for(const k of ['wind','grav','bf','kick','tdil','sup'])A(k).forEach(z=>rects.push(z));
 if(lv.updraft)rects.push(lv.updraft);if(lv.sling)rects.push(lv.sling.z);
 A('mag').forEach(m=>circ.push([m[0],m[1],m[2]]));A('vortex').forEach(m=>circ.push([m[0],m[1],m[2]]));A('well').forEach(m=>circ.push([m[0],m[1],m[3]*2]));
 A('det').forEach(m=>circ.push([m[0],m[1],m[2]]));A('coil').forEach(m=>circ.push([m[0],m[1],m[4]]));
 A('port').forEach(p=>{circ.push([p[0],p[1],16]);circ.push([p[2],p[3],16]);});
 A('ent').forEach(e=>{circ.push([e[0],e[1],20]);circ.push([e[2],e[3],20]);});
 if(lv.spectro)circ.push([lv.spectro.x,lv.spectro.y,lv.spectro.rs[0]]);
 if(lv.pend){const p=Array.isArray(lv.pend[0])?lv.pend:[lv.pend];p.forEach(q=>circ.push([q[0],q[1],q[2]+18]));}
 if(lv.fork&&lv.fork.tips)lv.fork.tips.forEach(t=>circ.push([t[0],t[1],14]));
 A('strings').forEach(s=>segs.push(s));A('gate').forEach(g=>segs.push(g));
 (lv.mov||[]).forEach(m=>{const s=m.seg;rects.push([Math.min(s[0],s[2])-Math.abs(m.amp*m.ax),Math.min(s[1],s[3])-Math.abs(m.amp*m.ay),Math.abs(s[2]-s[0])+2*Math.abs(m.amp*m.ax),Math.abs(s[3]-s[1])+2*Math.abs(m.amp*m.ay)]);});
 (lv.rails||[]).forEach(r=>{for(let i=1;i<r.pts.length;i++)segs.push([r.pts[i-1][0],r.pts[i-1][1],r.pts[i][0],r.pts[i][1]]);});
 return {segs,rects,circ};}
function touches(sh,tr){for(let k=0;k<tr.length;k++){const n2=k?Math.max(1,Math.ceil(Math.hypot(tr[k][0]-tr[k-1][0],tr[k][1]-tr[k-1][1])/3)):1;for(let j=1;j<=n2;j++){const x=k?tr[k-1][0]+(tr[k][0]-tr[k-1][0])*j/n2:tr[k][0],y=k?tr[k-1][1]+(tr[k][1]-tr[k-1][1])*j/n2:tr[k][1];
 for(const s of sh.segs)if(dseg(x,y,s)<R+9)return true;
 for(const r of sh.rects)if(x>r[0]-R&&x<r[0]+r[2]+R&&y>r[1]-R&&y<r[1]+r[3]+R)return true;
 for(const c of sh.circ)if(Math.hypot(x-c[0],y-c[1])<c[2]+R)return true;}}return false;}
function inZ(r,x,y){return x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3];}
function ok(lv,p){const n=Math.ceil(plen(p)/6);for(let k=0;k<=n;k++){const x=p[0][0]+(p[1][0]-p[0][0])*k/n,y=p[0][1]+(p[1][1]-p[0][1])*k/n;if(x<0||x>360||y<0||y>480)return false;if((lv.nd||[]).concat(lv.mz||[]).some(r=>inZ(r,x,y)))return false;}return true;}
const a=+process.argv[2],b=+process.argv[3];
for(let num=a;num<=b;num++){const i=num-1,lv=X.LEVELS[i];const t0=Date.now();X.loadLevel(i);const sh=shapes(lv);
 const mat=(lv.optmat!=null)?lv.optmat:((lv.pal||'S').charAt(0)==='B'?1:((lv.pal||'S').charAt(0)==='A'?3:0));const cost={0:1,1:1.9,3:1.7}[mat]||1;
 let n=0,win=0,partial=0;const nus=[];
 for(let x=6;x<=354;x+=24)for(let y=12;y<=470;y+=24)for(let an=0;an<3.14;an+=.3)for(const Ln of [60,110,170,240,320]){
  if(Date.now()-t0>45000){partial=1;continue;}if(Ln*cost>lv.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(an)*Ln),Math.round(y+Math.sin(an)*Ln)]];if(!ok(lv,p))continue;n++;
  X.loadLevel(i);X.S.strokes.push({pts:p,len:Ln,birth:0,mat});try{X.qpBuild()}catch(e){}X.S.mode='run';const tr=[];
  for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}
  if(X.S.mode==='success'){win++;if(!touches(sh,tr))nus.push(p);}}
 const o={num,n:lv.n,wd:lv.wd,essais:n,gagnants:win,nus:nus.length,ex:nus.slice(0,4),s:((Date.now()-t0)/1000|0),partial};
 fs.appendFileSync(process.env.OUT||'contournements.jsonl',JSON.stringify(o)+'\n');console.log(num,lv.n,'gagnants',win,'/',n,'NUS',nus.length,o.s+'s');}
