/* redundancy.js — détecteur de similarité entre niveaux.
   Usage : node redundancy.js [monde]        limite la comparaison à un monde
           node redundancy.js --all          compare aussi entre mondes différents
   Par défaut : compare chaque niveau à tous les niveaux du MÊME monde,
   comme le demande §7 de MASTER_LEVEL_DESIGN_PROTOCOL.md.

   Ce que ça mesure — une similarité géométrique et mécanique OBJECTIVE,
   pas le ressenti :
   - l'ensemble des mécaniques présentes (matières spéciales + champs)
   - l'angle et la distance départ→arrivée, normalisés par le monde de
     référence (360×480), donc comparables entre niveaux
   - le nombre et la disposition grossière des murs (silhouette du niveau)
   - le budget d'encre relatif à la distance à parcourir

   Une paire signalée n'est pas automatiquement un doublon à supprimer —
   c'est une paire à examiner à la main contre §7 du protocole maître :
   « si deux niveaux peuvent raisonnablement être résolus de manière
   identique, ils sont suspects », pas condamnés d'office. */
require('./load.js');
const X = globalThis.__X;
const LV_ALL = X.LEVELS;

function mechSet(lv) {
  const s = new Set();
  (lv.walls || []).forEach(w => {
    if (w[4] === 1) s.add('rebond');
    if (w[4] === 3) s.add('élan');
    if (w[4] === 4) s.add('glace');
    if (w[4] === 2) s.add('piquant');
  });
  if (lv.wind && lv.wind.length) s.add('vent');
  if (lv.grav && lv.grav.length) s.add('gravité');
  if (lv.mag && lv.mag.length) s.add('aimant');
  if (lv.port && lv.port.length) s.add('portail');
  if (lv.mov && lv.mov.length) s.add('mobile');
  if (lv.sup && lv.sup.length) s.add('superposition');
  if (lv.det && lv.det.length) s.add('détecteur');
  if (lv.ent && lv.ent.length) s.add('intrication');
  if (lv.tdil && lv.tdil.length) s.add('dilatation');
  if (lv.softball) s.add('corps-mou');
  if ((lv.pal || 'S').indexOf('C') >= 0) s.add('corde');
  return s;
}

function jaccard(a, b) {
  if (a.size === 0 && b.size === 0) return 1;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  const union = new Set([...a, ...b]).size;
  return union === 0 ? 1 : inter / union;
}

/* Masques sur grille 12×16 (cases de 30 px) : où est le décor, où peut-on tracer.
   Ajout R30 — la v1 ne voyait ni les zones nd ni la forme des murs, et jugeait
   « identiques » des niveaux au geste complètement différent (limite documentée
   dans REDUNDANCY_ANALYSIS.md). */
function wallMask(lv) {
  const m = new Set();
  for (const w of (lv.walls || [])) {
    const n = Math.max(1, Math.ceil(Math.hypot(w[2]-w[0], w[3]-w[1]) / 10));
    for (let k = 0; k <= n; k++) {
      const x = w[0] + (w[2]-w[0])*k/n, y = w[1] + (w[3]-w[1])*k/n;
      m.add(Math.floor(x/30) + ',' + Math.floor(y/30));
    }
  }
  return m;
}
function drawMask(lv) {
  const m = new Set();
  for (let cx = 0; cx < 12; cx++) for (let cy = 0; cy < 16; cy++) {
    const x = cx*30+15, y = cy*30+15;
    const blocked = (lv.nd || []).some(r => x>r[0] && x<r[0]+r[2] && y>r[1] && y<r[1]+r[3]);
    if (!blocked) m.add(cx + ',' + cy);
  }
  return m;
}

function signature(lv) {
  const bx = lv.ball[0], by = lv.ball[1];
  const z = lv.zone;
  const cx = z[0] + z[2] / 2, cy = z[1] + z[3] / 2;
  const dx = cx - bx, dy = cy - by;
  const dist = Math.hypot(dx, dy);
  const angle = Math.atan2(dy, dx); // radians
  const nWalls = (lv.w || []).length;
  const inkPerDist = lv.ink / Math.max(1, dist);
  return { mech: mechSet(lv), dist, angle, nWalls, inkPerDist, dir: dx >= 0 ? 1 : -1,
           walls: wallMask(lv), draw: drawMask(lv) };
}

function angleDiff(a, b) {
  let d = Math.abs(a - b);
  if (d > Math.PI) d = 2 * Math.PI - d;
  return d; // 0..PI
}

function similarity(sa, sb) {
  const mechSim = jaccard(sa.mech, sb.mech);
  if (mechSim < 0.5) return null; // mécaniques trop différentes : pas comparable
  const distSim = 1 - Math.min(1, Math.abs(sa.dist - sb.dist) / 300);
  const angSim = 1 - angleDiff(sa.angle, sb.angle) / Math.PI;
  const wallSim = 1 - Math.min(1, Math.abs(sa.nWalls - sb.nWalls) / 4);
  const inkSim = 1 - Math.min(1, Math.abs(sa.inkPerDist - sb.inkPerDist) / 3);
  // pondération : mécanique et angle comptent le plus (ce qui définit
  // le geste que le joueur doit faire), la silhouette de murs le moins
  const shapeSim = jaccard(sa.walls, sb.walls);   // forme du décor
  const drawSim = jaccard(sa.draw, sb.draw);      // espace où l'on peut tracer
  // v2 : la forme du décor et l'espace traçable pèsent autant que le trajet
  // départ→arrivée — ce sont eux qui dictent le geste du joueur.
  const score = mechSim * 0.2 + angSim * 0.15 + distSim * 0.1 + wallSim * 0.05 + inkSim * 0.05
              + shapeSim * 0.25 + drawSim * 0.2;
  return { score, mechSim, distSim, angSim, wallSim, inkSim, shapeSim, drawSim };
}

const args = process.argv.slice(2);
const all = args.includes('--all');
const worldArg = args.map(Number).find(n => n >= 1 && n <= 11);

const rows = LV_ALL.map((lv, i) => ({ i, lv, sig: signature(lv) }));
const pairs = [];
for (let a = 0; a < rows.length; a++) {
  for (let b = a + 1; b < rows.length; b++) {
    const A = rows[a], B = rows[b];
    if (!all && A.lv.wd !== B.lv.wd) continue;
    if (worldArg && A.lv.wd !== worldArg) continue;
    if (worldArg && B.lv.wd !== worldArg) continue;
    const sim = similarity(A.sig, B.sig);
    if (!sim) continue;
    if (sim.score >= 0.78) pairs.push({ A, B, sim });
  }
}
pairs.sort((p, q) => q.sim.score - p.sim.score);

console.log(`${pairs.length} paire(s) suspecte(s) (score >= 0.78)` +
  (worldArg ? ` — monde ${worldArg} seul` : all ? ' — tous mondes confondus' : ' — par monde'));
console.log('');
for (const { A, B, sim } of pairs) {
  console.log(
    `#${A.i + 1} ${A.lv.n}  ~  #${B.i + 1} ${B.lv.n}` +
    `   score ${sim.score.toFixed(2)}` +
    `  (méc ${sim.mechSim.toFixed(2)}, angle ${sim.angSim.toFixed(2)}, décor ${sim.shapeSim.toFixed(2)}, tracé ${sim.drawSim.toFixed(2)})`
  );
}
if (!pairs.length) console.log('aucune paire au-dessus du seuil.');
