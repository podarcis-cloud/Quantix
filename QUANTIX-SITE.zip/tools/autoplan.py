"""autoplan.py N … — écrit /tmp/claude-…/plan_auto.json (nom et conseil actuels, fr et en) pour slotwrite / valide."""
import re,sys,json
R='/home/claude/site/q/';s=open(R+'assets/js/levels.js').read();t=open(R+'assets/js/i18n.js').read()
ents=[m.start() for m in re.finditer(r'^\{wd:',s,re.M)]
def arr(name):
    a=t.index('var %s=['%name);b=t.index('];',a);return [x[1:-1] for x in re.findall(r"'(?:[^'\\]|\\.)*'",t[a:b])]
EN,ET=arr('LV_EN_N'),arr('LV_EN_T');out={}
for n in sys.argv[1:]:
    i=int(n)-1;e=s[ents[i]:ents[i+1] if i+1<len(ents) else len(s)]
    nm=re.search(r"n:'((?:[^'\\]|\\.)*)'",e).group(1);tp=re.search(r"tip:'((?:[^'\\]|\\.)*)'",e).group(1)
    out[n]={'key':n+'_fiche','n':nm,'tip':tp,'nEn':EN[i],'tipEn':ET[i]}
p='/tmp/claude-0/-home-claude/4c641bd7-bb09-5bbb-96e6-ca4b2af5577b/scratchpad/plan_'+'_'.join(sys.argv[1:])+'.json';json.dump(out,open(p,'w'),ensure_ascii=False);print(p)
