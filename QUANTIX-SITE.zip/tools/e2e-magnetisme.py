# Magnétisme de l'éditeur d'automations (R371)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(800)
    k='k:echo'
    chk(pg.evaluate('(k)=>!!QAUTO.desc(k)',k),'automation disponible (%s)'%k)
    pg.evaluate("(k)=>QAUTO.open(k)",k);pg.wait_for_timeout(300)
    chk(pg.locator('#auMg button').count()==2,'ligne Magnétisme : Pas / Niveaux')
    def clickAt(fx,fy):
        r=pg.evaluate("(()=>{const r=document.getElementById('auC').getBoundingClientRect();return [r.left,r.top,r.width,r.height]})()")
        pg.mouse.click(r[0]+fx*r[2],r[1]+10+fy*(r[3]-20))
        pg.wait_for_timeout(120);return r
    def lastPt():return pg.evaluate("(k)=>{const a=QAUTO.AUT[k];return a.pts.map(p=>p.slice())}",k)
    n0=len(lastPt())
    clickAt(.3333,.3)   # près de 1/3 mais pas sur un pas (N=16 par défaut ?)
    P=lastPt();chk(len(P)==n0+1,'point ajouté sans magnétisme')
    raw=[p for p in P if abs(p[0]-.3333)<.01]
    chk(raw and abs(raw[0][1]-.7)<.03,'sans magnétisme : position libre (y=%.3f)'%(raw[0][1] if raw else -1))
    pg.click('#auMg button[data-g="x"]');pg.click('#auMg button[data-g="y"]')
    chk(pg.evaluate("document.querySelectorAll('#auMg button.on').length")==2,'deux boutons actifs')
    clickAt(.0,.0) if False else None
    N=pg.evaluate("(()=>{return QUANTONE.loopLen&&0})()")
    clickAt(.62,.74)   # y=.74*… -> proche de 0.25 niveau
    P=lastPt();q=[p for p in P if p[0]>.55 and p[0]<.7]
    ys=[round(p[1]*4,3) for p in q]
    chk(q and all(abs(y-round(y))<.02 for y in ys),'avec magnétisme : le niveau tombe sur un quart (%s)'%ys)
    xs=[p[0] for p in q]
    chk(q and any(abs(x*16-round(x*16))<.01 or abs(x*8-round(x*8))<.01 or abs(x*32-round(x*32))<.01 for x in xs),'avec magnétisme : x sur un pas (%s)'%[round(x,4) for x in xs])
    pg.reload();pg.wait_for_timeout(600);pg.evaluate("(k)=>QAUTO.open(k)",k);pg.wait_for_timeout(300)
    chk(pg.evaluate("document.querySelectorAll('#auMg button.on').length")==2,'réglage mémorisé après rechargement')
    chk(not er,'aucune erreur de page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
