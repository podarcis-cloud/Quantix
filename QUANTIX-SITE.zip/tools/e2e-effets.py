# Moteur d'effets (R366) : registre, chaîne, bypass réel, interface, sauvegarde, rendu hors ligne
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1200)
    pg.evaluate("(()=>{const st=QUANTONE.state,w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));st.strokes=[{layer:0,pts:w(40,(t,i)=>[.1+.5*t,.5+.2*Math.sin(t*6.28),i*30])},{layer:2,pts:w(30,(t,i)=>[.3+.5*t,.65+.1*Math.sin(t*5+1),i*30])},{layer:4,pts:w(40,(t,i)=>[.02+.96*t,.885+.04*Math.sin(t*12.6+.4),i*4.5])}];})()")
    chk(pg.evaluate("QFXE.order.length")>=15,'registre : %d effets'%pg.evaluate("QFXE.order.length"))
    # chaque effet se construit dans un contexte hors ligne et laisse passer le signal (sans NaN)
    r=pg.evaluate("""async()=>{const out={};for(const id of QFXE.order){const oc=new OfflineAudioContext(2,22050,44100),ch=QFXE.chain(oc,[QFXE.fresh(id)],{tempo:90}),o=oc.createOscillator(),g=oc.createGain();g.gain.value=.3;o.frequency.value=220;o.type='sawtooth';o.connect(g);g.connect(ch.in);ch.out.connect(oc.destination);o.start();
      const b=await oc.startRendering(),d=b.getChannelData(0);let bad=0,pk=0;for(let i=0;i<d.length;i++){if(!isFinite(d[i]))bad++;pk=Math.max(pk,Math.abs(d[i]));}out[id]=[bad,+pk.toFixed(3)];}return out;}""")
    bad=[k for k,v in r.items() if v[0]>0 or v[1]>3];sil=[k for k,v in r.items() if v[1]<.0005]
    chk(not bad,'aucun effet ne produit de NaN ni de saturation folle %s'%bad)
    chk(not sil,'chaque effet laisse passer du son %s'%sil)
    # intégration instrument
    pg.evaluate("QFX3.open(0)");pg.wait_for_timeout(300)
    chk(pg.evaluate("!!document.querySelector('#ifxBox')"),'section Effets dans l’éditeur')
    pg.evaluate("document.querySelector('#ifxBox').open=true")
    pg.select_option('#ifxAdd','chorus');pg.wait_for_timeout(300)
    pg.select_option('#ifxAdd','plate');pg.wait_for_timeout(300)
    chk(pg.evaluate("QFX3.inst[0].fx.map(x=>x.t).join()")=='chorus,plate','ajout de deux effets : chorus, plate')
    chk(pg.evaluate("document.querySelectorAll('#ifxBox .fxc').length")==2,'deux cartes affichées')
    pg.click('#ifxBox .fxc:nth-child(1) [data-a=dn]');pg.wait_for_timeout(200)
    chk(pg.evaluate("QFX3.inst[0].fx.map(x=>x.t).join()")=='plate,chorus','↓ réordonne')
    for t in ['sat','ping','trem']:
        try:pg.select_option('#ifxAdd',t)
        except Exception as e:pass
        pg.wait_for_timeout(120)
    chk(pg.evaluate("QFX3.inst[0].fx.length")==4,'4 effets maximum (%d)'%pg.evaluate("QFX3.inst[0].fx.length"))
    # la lecture passe par la chaîne
    pg.click('#bPlay');pg.wait_for_timeout(2500)
    chk(pg.evaluate("(()=>{const G=QUANTONE.dbg&&QUANTONE.dbg().G;return 1})()"),'lecture avec 4 effets sans erreur')
    lv=pg.evaluate("QUANTONE.level()");chk(lv>.003,'le son passe (niveau %.3f)'%lv)
    pg.click('#bPlay');pg.wait_for_timeout(300)
    # bypass réel : off retire l'effet du graphe
    pg.evaluate("QFX3.inst[0].fx.forEach(x=>x.on=0)")
    # sauvegarde / rechargement
    J=pg.evaluate("JSON.stringify(QFX3.preset().ifx)");chk(J and 'plate' in J,'sauvegardé dans le pattern (ifx)')
    pg.evaluate("(()=>{const p=QFX3.preset();p.ifx[0].forEach(x=>x.on=1);QFX3.load(p);})()");pg.wait_for_timeout(200)
    chk(pg.evaluate("QFX3.inst[0].fx.length")==4,'rechargé depuis le pattern')
    pg.evaluate("(()=>{const p=QFX3.preset();delete p.ifx;QFX3.load(p);})()")
    chk(pg.evaluate("!QFX3.inst[0].fx")  ,'un ancien pattern sans effets remet la chaîne à zéro')
    # rendu hors ligne complet avec effets
    pg.evaluate("(()=>{const p=QFX3.preset();QFX3.load(p);QFX3.inst[0].fx=QFXE.clean(QFXE.chains.espace.list);})()")
    r2=pg.evaluate("""async()=>{const Q=QUANTONE,st=Q.state;const seg=(b,a,n)=>{const d=b.getChannelData?b.getChannelData(0):b[0];return d.slice(a,a+n)};
      const go=()=>new Promise(r=>Q.renderBlock((b,m)=>r([b,m])));
      QFX3.inst[0].fx=[];const [A,ma]=await go();QFX3.inst[0].fx=QFXE.clean(QFXE.chains.robot.list);const [B,mb]=await go();
      const sr=A.sampleRate,x=seg(A,Math.round(ma.start*sr),Math.round(ma.len*sr)),y=seg(B,Math.round(mb.start*sr),Math.round(mb.len*sr));let d=0,n=Math.min(x.length,y.length);for(let i=0;i<n;i++)d=Math.max(d,Math.abs(x[i]-y[i]));
      return {d:+d.toFixed(3),len:ma.len};}""")
    chk(r2['d']>.02,'rendu de bloc (export/Track) : la chaîne Robot change le rendu (écart %s)'%r2['d'])
    chk(not er,'aucune erreur de page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
