import asyncio,sys,os,json
from playwright.async_api import async_playwright
SITE=sys.argv[1]; LV=[int(x) for x in sys.argv[2].split(',')]
src=open(SITE+'/assets/js/visuals.js',encoding='utf-8').read()
key=" c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(F4.cv,0,0,VW,VH);c.restore();}"
assert src.count(key)==1
src=src.replace(key," c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(F4.cv,0,0,VW,VH);c.restore();"
 "try{var s=window.__snap||(window.__snap=document.createElement('canvas'));s.width=90;s.height=120;s.getContext('2d').drawImage(F4.cv,0,0,90,120);window.__snapN=(window.__snapN||0)+1;window.__F4=F4;}catch(e){window.__snapErr=String(e)}}")
async def main():
  async with async_playwright() as p:
    br=await p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg=await br.new_page(viewport={'width':390,'height':844},device_scale_factor=1);pg.set_default_timeout(120000)
    await pg.route('**/fonts.g*/**',lambda r:r.abort())
    await pg.route('**/visuals.js*',lambda r:r.fulfill(body=src,content_type='application/javascript'))
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('C:'+m.text) if m.type=='error' else None)
    await pg.goto('file://'+SITE+'/index.html');await pg.wait_for_timeout(1500)
    await pg.add_style_tag(content='#tcard,.tvl,#tshield,.hvig{display:none!important}')
    for n in LV:
      await pg.evaluate(f"show(vWorld,false);S.zen=false;goto('game');loadLevel({n});")
      await pg.wait_for_timeout(2500)
      frames=[]
      for k in range(4):
        d=await pg.evaluate("(()=>{const s=window.__snap;if(!s)return null;const x=s.getContext('2d').getImageData(0,0,90,120).data;return Array.from(x)})()")
        n2=await pg.evaluate("window.__snapN||0")
        frames.append((d,n2));await pg.wait_for_timeout(1500)
      def diff(a,b):
        if not a or not b: return None
        return sum(abs(x-y) for x,y in zip(a,b))/len(a)
      lvl=await pg.evaluate(f"({{wd:LEVELS[{n}].wd,key:window.__F4&&window.__F4.key,ok:window.__F4&&window.__F4.ok,mag:(LEVELS[{n}].mag||[]).length,coil:(LEVELS[{n}].coil||[]).length}})")
      print(n,lvl,'calls',[f[1] for f in frames],'diffs',[None if diff(frames[i][0],frames[i+1][0]) is None else round(diff(frames[i][0],frames[i+1][0]),3) for i in range(3)],flush=True)
    print('errs',errs[:5])
    await br.close()
asyncio.run(main())
