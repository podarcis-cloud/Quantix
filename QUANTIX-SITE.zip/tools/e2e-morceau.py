# e2e-morceau.py — R341 : effets créés à la demande (y compris en pleine lecture) et clips programmés au fil de la lecture.
# Lancer depuis la racine du site, avec un serveur local : python3 -m http.server 8765 &  puis  python3 tools/e2e-morceau.py
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
INIT="""window.__c={cv:0,dl:0,sh:0,src:0};(function(){var A=BaseAudioContext.prototype;
 [['createConvolver','cv'],['createDelay','dl'],['createWaveShaper','sh'],['createBufferSource','src']].forEach(function(p){var o=A[p[0]];A[p[0]]=function(){if(!(this instanceof OfflineAudioContext))__c[p[1]]++;return o.apply(this,arguments);};});})();"""
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_context(viewport={'width':390,'height':844}).new_page();pg.add_init_script(INIT)
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1200)
    pg.evaluate("""()=>{var M=MORCEAU,P=M.P(),sr=44100,n=sr*2,L=new Float32Array(n);for(var i=0;i<n;i++)L[i]=.5*Math.sin(2*Math.PI*220*i/sr)*Math.exp(-(i%(sr/4))/(sr*.05));
      var id=M.addBlock({kind:'audio',name:'a',sr:sr,ch:[L,L],len:2,loop:true}).id;
      P.tracks.push({id:'tA',name:'A',col:'#4de',vol:.7,pan:0,mute:0,solo:0,fx:{hp:20,lp:20000,lo:0,hi:0,drv:0,dly:0,dt:.75,fb:.4,rev:0}});
      [0,5,40].forEach(function(s,i){P.clips.push({id:'c'+i,track:'tA',src:id,start:s,len:4,off:0,rate:1,gain:1,loop:true});});M.render();}""")
    # 1) sans effet : aucun convolueur / retard / saturateur
    c0=pg.evaluate("Object.assign({},__c)");pg.evaluate("MORCEAU.play(0)");pg.wait_for_timeout(1500)
    c1=pg.evaluate("Object.assign({},__c)")
    chk(c1['cv']==c0['cv'] and c1['dl']==c0['dl'] and c1['sh']==c0['sh'],'sans effet réglé : aucun convolueur, retard ni saturateur créé (%s)'%{k:c1[k]-c0[k] for k in ('cv','dl','sh')})
    chk(c1['src']-c0['src']==2,'clips à 0 s et 5 s programmés, celui à 40 s attendu (sources créées : %d)'%(c1['src']-c0['src']))
    # 2) activer les effets en pleine lecture
    pg.click('[data-fx="tA"]');pg.wait_for_timeout(200)
    for k,v in (('rev',60),('dly',40),('drv',50)):
        pg.evaluate("(a)=>{var e=document.querySelector('input[data-fk=\"'+a[0]+'\"][data-id=\"tA\"]');e.value=a[1];e.dispatchEvent(new Event('input',{bubbles:true}));}",[k,v]);pg.wait_for_timeout(150)
    c2=pg.evaluate("Object.assign({},__c)");pg.wait_for_timeout(600)
    chk(c2['cv']-c1['cv']==1 and c2['dl']-c1['dl']==1 and c2['sh']-c1['sh']==1,'réverb, écho et saturation créés à l’activation, une seule fois (%s)'%{k:c2[k]-c1[k] for k in ('cv','dl','sh')})
    pg.evaluate("(a)=>{var e=document.querySelector('input[data-fk=\"rev\"][data-id=\"tA\"]');e.value=70;e.dispatchEvent(new Event('input',{bubbles:true}));}",[]);pg.wait_for_timeout(200)
    c3=pg.evaluate("Object.assign({},__c)");chk(c3['cv']==c2['cv'],'régler de nouveau la réverb ne recrée pas de convolueur')
    pg.evaluate("MORCEAU.stop()");pg.wait_for_timeout(300)
    # 3) lecture depuis 20 s : le clip à 40 s entre dans la fenêtre de 24 s
    d0=pg.evaluate("__c.src");pg.evaluate("MORCEAU.play(20)");pg.wait_for_timeout(700);d1=pg.evaluate("__c.src")
    chk(d1-d0==1,'lecture depuis 20 s : le clip à 40 s est programmé (sources créées : %d)'%(d1-d0))
    pg.evaluate("MORCEAU.stop()")
    chk(not errs,'aucune erreur de page %s'%errs[:2]);b.close()
print('\n%d/%d OK'%(sum(res),len(res)))
