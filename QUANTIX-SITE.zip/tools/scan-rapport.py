#!/usr/bin/env python3
"""scan-rapport.py [--out F.md] : fusionne tools/scan132.part*.jsonl et sort le rapport par monde (encre, référence, contournements, murs muets, niveaux non mesurés)."""
import json,glob,collections,sys
R={}
for f in sorted(glob.glob('/home/claude/q2/tools/scan132.part*.jsonl')):
    for l in open(f):
        try:d=json.loads(l);R[d['n']]=d
        except Exception:pass
out=[];P=lambda *a:out.append(' '.join(str(x) for x in a))
P('# Scan des 132 niveaux — rapport par monde');P('')
miss=[n for n in range(1,133) if n not in R];P('Mesurés : %d/132 · non mesurés (trop lourds ?) : %s'%(len(R),miss or 'aucun'));P('')
def flag(d):
    F=[];r=d.get('ref') or {}
    if d.get('encreDepart') is None or not d.get('encreOK'):F.append('ENCRE DE DÉPART ANORMALE')
    if d.get('vide')!='échoue':F.append('gagne SANS trait (%s)'%d.get('vide'))
    if not r:F.append('pas de référence')
    else:
        if not r.get('gagne'):F.append('RÉFÉRENCE NE GAGNE PAS')
        if r.get('gagne') and not r.get('noyau'):F.append('référence hors noyau')
        if r.get('pct') is not None and r['pct']>=95:F.append('référence = %d%% de l\'encre (très serré)'%r['pct'])
        if r.get('pct') is not None and r['pct']<=25:F.append('référence = %d%% de l\'encre (encre très généreuse)'%r['pct'])
        if r.get('dessinable') is False:F.append('référence non dessinable au doigt')
        if r.get('sansMeca'):F.append('la référence gagne sans la mécanique (contournement)')
    g=d.get('gagnants',0);ess=d.get('essais',0)
    if ess and g/ess>0.05:F.append('lignes droites gagnantes fréquentes (%.1f%%)'%(100*g/ess))
    if d.get('P_hasard',0)>0.05:F.append('réussite au hasard %.0f%%'%(100*d['P_hasard']))
    if d.get('mursMuets'):F.append('murs muets : %s'%d['mursMuets'])
    return F
byw=collections.defaultdict(list)
for n,d in sorted(R.items()):byw[d['wd']].append(d)
NF=0
for w in sorted(byw):
    P('## Monde %d'%w);P('')
    for d in byw[w]:
        F=flag(d);r=d.get('ref') or {}
        P('- N%d %s · encre %s · ref %s%% · gagnants droits %s/%s%s'%(d['n'],d['nom'],d.get('encreDepart'),r.get('pct','–'),d.get('gagnants'),d.get('essais'),(' · ⚠ '+' ; '.join(F)) if F else ''))
        NF+=bool(F)
    P('')
P('Niveaux avec signal : %d/%d'%(NF,len(R)))
t='\n'.join(out)
if '--out' in sys.argv:open(sys.argv[sys.argv.index('--out')+1],'w',encoding='utf-8').write(t)
else:print(t)
