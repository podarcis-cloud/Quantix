# Zoom, étendue, tour des formes (R347) — serveur local sur 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=2);pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{const g=document.getElementById('qGO');if(g){g.style.pointerEvents='none';g.querySelectorAll('select').forEach(s=>s.style.pointerEvents='none');}})()")   # R360 : les puces Grille/Étendue occupent le coin haut-gauche du champ
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=st.strokes.filter(s=>s.layer!==4);QDM.get().rows.forEach(r=>{r.on=new Array(16).fill(0);});st.dm.mot='';st.grid=16;st.scale='none';})()")   # R363 : l'état par défaut contient maintenant un trait Rythmes pleine largeur + boîte remplie ; ces tests partent de l'ancien état (2 courbes, boîte vide)
    pg.evaluate("QUANTONE.state.strokes.length=0")
    r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
    def P(x,y):
        r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
        return (r[0]+x*r[2],r[1]+y*r[3])
    def draw(pts):
        x,y=P(*pts[0]);pg.mouse.move(x,y);pg.mouse.down()
        for q in pts[1:]:
            x,y=P(*q);pg.mouse.move(x,y,steps=5)
        pg.mouse.up();pg.wait_for_timeout(80)
    # --- étendue
    def span(oct_):
        pg.evaluate("QUANTONE.state.strokes.length=0");pg.select_option('#sOct',str(oct_))
        pg.click('#qdock [data-m=draw]');draw([(.1,.02),(.2,.5),(.3,.98)])
        n=pg.evaluate("QFX3.score().filter(e=>e.kind===st0).map(e=>e.note)".replace('st0',str(pg.evaluate("QUANTONE.state.layer"))))
        return max(n)-min(n)
    s1,s3=span(1),span(3)
    chk(s1<=12 and s3>=24 and s3>s1*2,'étendue : 1 octave → %d demi-tons, 3 octaves → %d'%(s1,s3))
    pg.select_option('#sOct','2')
    # --- forme fermée : un tour = la grille
    pg.evaluate("QUANTONE.state.strokes.length=0")
    pg.click('#qdock [data-m=form]');x,y=P(.5,.5);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+70,y,steps=6);pg.mouse.up();pg.wait_for_timeout(100)
    L=pg.evaluate("QUANTONE.state.layer");g=pg.evaluate("GL()")
    ev=pg.evaluate("QFX3.score().filter(e=>e.kind===%d)"%L)
    steps=sorted(set(e['step'] for e in ev))
    chk(len(ev)==g and all(e['loop']==g for e in ev) and steps==list(range(g)),'rond : %d notes = grille (%d), boucle %d'%(len(ev),g,ev[0]['loop'] if ev else 0))
    ys=[e['y'] for e in ev];chk(max(ys)-min(ys)>.2,'la hauteur donne la note (écart y %.2f)'%(max(ys)-min(ys)))
    pg.evaluate("QUANTONE.state.strokes[0].turn=.5");ev=pg.evaluate("QFX3.score().filter(e=>e.kind===%d)"%L)
    chk(all(e['loop']==g//2 for e in ev) and len(set(e['step']%(g//2) for e in ev))==g//2,'tour ½ grille : boucle %d, répétée dans la grille'%(g//2))
    pg.evaluate("QUANTONE.state.strokes[0].turn=2");ev=pg.evaluate("QFX3.score().filter(e=>e.kind===%d)"%L)
    chk(len(ev)==min(64,g*2),'tour 2 grilles : %d notes'%len(ev))
    # petite et grande forme : même temps
    pg.evaluate("QUANTONE.state.strokes.length=0")
    for rad in (30,110):
        if not pg.evaluate("document.querySelector('#qdock [data-m=form]').classList.contains('on')"):pg.click('#qdock [data-m=form]')   # R369 : retoucher l'outil actif ouvre le menu des formes
        x,y=P(.5,.5);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+rad,y,steps=6);pg.mouse.up();pg.wait_for_timeout(80)
    ev=pg.evaluate("QFX3.score().filter(e=>e.kind===%d)"%L)
    chk(len(ev)==2*g,'petite et grande forme : %d notes chacune'%g)
    pg.evaluate("QUANTONE.state.strokes.length=0")
    # --- menu de tour
    fb=pg.evaluate("(()=>{const q=document.querySelector('#qdock [data-m=form]').getBoundingClientRect();return [q.left+q.width/2,q.top+q.height/2]})()")
    pg.mouse.move(*fb);pg.mouse.down();pg.wait_for_timeout(650);pg.mouse.up();pg.wait_for_timeout(100)
    chk(pg.evaluate("document.querySelectorAll('#qpop button').length")>=7,'menu Forme : formes + tours')
    pg.click('#qpop button:nth-child(8)');pg.wait_for_timeout(150);chk(pg.evaluate("QTOOLS.fm.turn")==2,'tour réglé à 2 grilles')
    pg.mouse.click(5,300)
    pg.evaluate("QTOOLS.fm.turn=1")
    # --- zoom
    pg.click('#zIn');pg.click('#zIn');z=pg.evaluate("QZOOM.v.z");chk(abs(z-2.25)<.01,'zoom ＋ ＋ : ×%.2f'%z)
    pg.evaluate("QZOOM.set(2,.25,.25)");pg.click('#qdock [data-m=draw]')
    draw([(.2,.2),(.5,.5),(.8,.8)])
    pts=pg.evaluate("QUANTONE.state.strokes[QUANTONE.state.strokes.length-1].pts.map(p=>[p[0],p[1]])")
    chk(abs(pts[0][0]-(.25+.2/2))<.03 and abs(pts[0][1]-(.25+.2/2))<.03 and abs(pts[-1][0]-(.25+.8/2))<.03,'dessin zoomé : coordonnées champ (%.2f,%.2f)→(%.2f,%.2f)'%(pts[0][0],pts[0][1],pts[-1][0],pts[-1][1]))
    ln=pg.evaluate("QZOOM.lines()");chk(0<len(ln)<14 and all(isinstance(l['name'],str) and len(l['name'])>=2 for l in ln),'lignes de notes nommées visibles : %s'%[l['name'] for l in ln][:5])
    pg.evaluate("QZOOM.set(1,0,0)");ln1=pg.evaluate("QZOOM.lines().length");chk(ln1>len(ln),'zoom 1 : toutes les lignes (%d)'%ln1)
    # main
    pg.evaluate("QZOOM.set(3,0,0)");pg.click('#zHand');x,y=P(.5,.5);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x-60,y-60,steps=5);pg.mouse.up()
    chk(pg.evaluate("QZOOM.v.x")>.05 and pg.evaluate("QZOOM.v.y")>.05,'mode main : déplacement de la vue (%.2f,%.2f)'%(pg.evaluate("QZOOM.v.x"),pg.evaluate("QZOOM.v.y")))
    pg.click('#zHand');pg.click('#zRst');chk(pg.evaluate("QZOOM.v.z")==1,'⊡ remet la vue')
    # molette
    pg.mouse.move(*P(.5,.5));pg.mouse.wheel(0,-300);pg.wait_for_timeout(100);chk(pg.evaluate("QZOOM.v.z")>1.1,'molette : zoom ×%.2f'%pg.evaluate("QZOOM.v.z"))
    pg.click('#zRst')
    # pincement (événements synthétiques)
    n0=pg.evaluate("QUANTONE.state.strokes.length")
    pg.evaluate("""(()=>{const c=document.getElementById('cv'),q=c.getBoundingClientRect();
      const mk=(t,id,x,y)=>c.dispatchEvent(new PointerEvent(t,{pointerId:id,pointerType:'touch',clientX:x,clientY:y,bubbles:true,cancelable:true,isPrimary:id===11}));
      const cx=q.left+q.width/2,cy=q.top+q.height/2;
      mk('pointerdown',11,cx-20,cy);mk('pointermove',11,cx-22,cy);mk('pointerdown',12,cx+20,cy);
      for(let i=1;i<=6;i++){mk('pointermove',11,cx-20-i*12,cy);mk('pointermove',12,cx+20+i*12,cy);}
      mk('pointerup',12,cx+90,cy);mk('pointerup',11,cx-90,cy);})()""");pg.wait_for_timeout(200)
    chk(pg.evaluate("QZOOM.v.z")>2,'pincement : zoom ×%.2f'%pg.evaluate("QZOOM.v.z"))
    chk(pg.evaluate("QUANTONE.state.strokes.length")==n0,'le pincement ne laisse aucun trait')
    pg.screenshot(path='/tmp/z_pinch.png')
    # préréglage : étendue et tour mémorisés
    pg.evaluate("QZOOM.set(1,0,0)");pg.select_option('#sOct','3');pg.evaluate("QUANTONE.state.strokes.length=0")
    pg.click('#qdock [data-m=form]');x,y=P(.5,.5);pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+60,y,steps=5);pg.mouse.up()
    pg.evaluate("QUANTONE.state.strokes[0].turn=.5");pr=pg.evaluate("QFX3.preset()")
    chk(pr.get('oct')==3 and pr['strokes'][0].get('tn')==.5,'préréglage garde étendue et tour')
    pg.evaluate("p=>QFX3.load(p)",pr);pg.wait_for_timeout(100)
    chk(pg.evaluate("[document.getElementById('sOct').value,QUANTONE.state.strokes[0].turn]")==['3',.5],'rechargé : étendue 3, tour ½')
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(400)
    fl=pg.evaluate("(()=>{const t=document.getElementById('dmTap'),r=t.parentNode.nextElementSibling;if(!r)return null;const f=r.querySelector('[data-ifn]'),l=r.querySelector('[data-ilp]');const vis=e=>!!e&&e.getBoundingClientRect().height>0;return [vis(f),vis(l)]})()")
    chk(fl==[True,True],'boîte à rythmes : Fonction et Boucle juste sous Tempo %s'%fl)
    chk(not errs,'aucune erreur %s'%errs)
print('RÉSULTAT',sum(res),'/',len(res))
