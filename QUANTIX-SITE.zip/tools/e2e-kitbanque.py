# Kits « Banque » (R386) : vrais sons du pack rythme chargés dans les voix de batterie
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
U='http://localhost:8765/studio/quantone.html'
with sync_playwright() as pw:
    b=pw.chromium.launch();cx=b.new_context(viewport={'width':390,'height':844});er=[]
    pg=cx.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto(U);pg.wait_for_timeout(1200);pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(500)
    og=pg.evaluate("[].map.call(document.querySelectorAll('#dmKit optgroup'),g=>g.label).filter(l=>/Banque ·|Bank ·/.test(l)&&/Techno|Ambient|IDM/.test(l))")
    chk(len(og)>=3,'les kits « Banque · genre » sont dans le menu %s'%og[:3])
    v=pg.evaluate("[].map.call(document.querySelectorAll('#dmKit option'),o=>o.value).filter(x=>/^kx:1[0-9]:/.test(x)).length")
    chk(v>=8*3,'8 genres × 3 variantes (%d options kx)'%v)
    pk=pg.evaluate("new Promise(r=>QBANK.pick(0,0,r))");pk1=pg.evaluate("new Promise(r=>QBANK.pick(0,1,r))")
    fams=[x['fam'] for x in pk]
    chk(len(pk)==8 and len(set(x['id'] for x in pk))==8,'8 sons distincts choisis : %s'%[x['nm'] for x in pk])
    chk(fams[0]=='grave' and fams[1]=='bois' and fams[3] in('aigu','tic'),'rôles respectés : grosse caisse = grave, caisse claire = bois, charleston = aigu (%s)'%fams)
    chk(pk[0]['id']!=pk1[0]['id'] or pk[1]['id']!=pk1[1]['id'],'la variante 2 change des échantillons')
    pg.select_option('#dmKit','kx:10:0');pg.wait_for_timeout(3500)
    r=pg.evaluate("(()=>{const S=QBANK.dbg().SMP,o=[];for(let k=1;k<=8;k++){const s=S[k];let m=0;if(s)for(let i=0;i<s.d.length;i+=7)m=Math.max(m,Math.abs(s.d[i]));o.push([s&&s.name,s&&s.sr,+m.toFixed(2)])}return o})()")
    chk(all(x[0] and x[1]==32000 and x[2]>.05 for x in r),'8 emplacements remplis par des sons réels (32 kHz, signal présent) %s'%[x[0] for x in r])
    chk(pg.evaluate("QDM.get().kx==='kx:10:0'&&QDM.get().rows[0].smp===1&&QDM.get().rows[1].smp===2"),'les voix de batterie pointent sur ces échantillons')
    q=pg.evaluate("QXIO.build()");chk(q['info']['samples']==8,'le motif embarque les 8 échantillons (%d)'%q['info']['samples'])
    pg.close()
    pg=cx.new_page();pg.on('pageerror',lambda e:er.append(str(e)));pg.route('**/pack-rythme.bin',lambda r:r.abort())
    pg.goto(U);pg.wait_for_timeout(1200);pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(500)
    pg.select_option('#dmKit','kx:12:0');pg.wait_for_timeout(2500)
    t=pg.evaluate("(document.getElementById('toast')||{}).textContent||''")
    chk('pack' in t.lower() and 'rythme' in t.lower(),'pack absent : message clair « %s »'%t[:70])
    chk(not er,'aucune erreur JS %s'%er[:1])
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
