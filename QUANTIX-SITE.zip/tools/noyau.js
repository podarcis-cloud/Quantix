/* noyau.js — R118 : place le noyau selon CONSIGNES_SIMON §2 : sur la trajectoire EXACTE de la solution de référence (le bouton
   « solution » le prend), là où passent 15 à 35 % des traits gagnants (balayage à un trait), hors machine.
   Usage : node noyau.js N [zone x0,y0,x1,y1] → écrit star:[x,y] dans levels.js (ÉCRIRE=1) ou l'affiche seulement. */
const DIF=require('./difficulty.js'),X=DIF.X,fs=require('fs');
const n=+process.argv[2],idx=n-1,LV=X.LEVELS[idx],Z=process.argv[3]?process.argv[3].split(',').map(Number):[0,0,360,480];
function run(strokes){X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:1,birth:0,mat:s.mat||0});X.qpBuild();X.S.mode='run';const tr=[];
 for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',tr,star:X.S.gotStar};}
const keep=LV.star;LV.star=null;const mat=LV.optmat||0,ref=run(LV.optsol.map(p=>({pts:p,mat})));
const F=DIF.families(idx,LV);const W=[];for(const f of F.fam)for(const p of f.m){const r=run([{pts:p,mat:F.mat}]);if(r.ok)W.push(r.tr);}
const inMz=(x,y)=>(LV.mz||[]).some(m=>x>m[0]&&x<m[0]+m[2]&&y>m[1]&&y<m[1]+m[3]);
let best=null;for(let k=0;k<ref.tr.length;k+=3){const q=ref.tr[k];if(q[0]<Z[0]||q[0]>Z[2]||q[1]<Z[1]||q[1]>Z[3]||inMz(q[0],q[1]))continue;
 let h=0;for(const t of W)if(t.some(r=>Math.hypot(r[0]-q[0],r[1]-q[1])<20.5))h++;const f=h/Math.max(1,W.length);
 if(f>=.15&&f<=.35&&(!best||Math.abs(f-.25)<Math.abs(best.f-.25)))best={x:Math.round(q[0]),y:Math.round(q[1]),f};
 if(!best||(best.f>.35&&f<best.f))if(!(best&&best.f>=.15&&best.f<=.35))best={x:Math.round(q[0]),y:Math.round(q[1]),f};}
LV.star=[best.x,best.y];const chk=run(LV.optsol.map(p=>({pts:p,mat})));DIF.setSeed(5);const pn=DIF.P(idx,LV,LV.optsol,DIF.modelFor(idx),mat,30).star;
console.log('#'+n,LV.n,'| gagnants balayés',W.length,'| noyau',JSON.stringify(LV.star),'pris par',Math.round(best.f*100),'% des solutions | solution de référence :',chk.star?'le prend':'NE LE PREND PAS','| P_noyau au doigt',Math.round(pn*100),'%');
if(process.env.ECRIRE){const p='../assets/js/levels.js';let s=fs.readFileSync(p,'utf8');const st=[...s.matchAll(/^\{wd:/gm)].map(m=>m.index);const a=st[idx],b=st[idx+1]||s.length;let e=s.slice(a,b);
 if(!/star:\[[-\d.]+,[-\d.]+\]/.test(e)){console.log('pas de champ star');process.exit(1);}e=e.replace(/star:\[[-\d.]+,[-\d.]+\]/,'star:['+LV.star.join(',')+']');fs.writeFileSync(p,s.slice(0,a)+e+s.slice(b));console.log('écrit');}
