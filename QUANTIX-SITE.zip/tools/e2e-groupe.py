# Édition groupée au lasso, aimant, poignées du zoom (R348) — serveur local sur 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=2);pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    pg.evaluate("QUANTONE.state.strokes.length=0")
    r=pg.evaluate("(()=>{const q=document.getElementById('cv').getBoundingClientRect();return [q.left,q.top,q.width,q.height]})()")
    P=lambda x,y:(r[0]+x*r[2],r[1]+y*r[3])
    def draw(pts):
        x,y=P(*pts[0]);pg.mouse.move(x,y);pg.mouse.down()
        for q in pts[1:]:
            x,y=P(*q);pg.mouse.move(x,y,steps=5)
        pg.mouse.up();pg.wait_for_timeout(80)
    # --- aimant
    pg.click('#qdock [data-m=draw]');pg.evaluate("QUANTONE.state.layer=0")
    chk(pg.evaluate("QMAG.on"),'aimant actif par défaut')
    G=pg.evaluate("GL()");R=pg.evaluate("RNG(REG[0])")
    pg.click('#qdock [data-m=point]');pg.mouse.click(*P(.133,.437));pg.wait_for_timeout(80)
    pp=pg.evaluate("QUANTONE.state.strokes[0].pts[0]");ys=(1-pp[1])*R
    chk(abs(ys-round(ys))<1e-3,'point calé sur une ligne de note (y=%.4f)'%pp[1])
    pg.evaluate("QUANTONE.state.strokes.length=0");pg.click('#zMag');chk(not pg.evaluate("QMAG.on"),'aimant désactivable')
    pg.mouse.click(*P(.133,.437));pg.wait_for_timeout(80);pp=pg.evaluate("QUANTONE.state.strokes[0].pts[0]");ys=(1-pp[1])*R
    chk(abs(ys-round(ys))>1e-3,'aimant coupé : y libre (%.4f)'%pp[1])
    pg.click('#zMag');pg.evaluate("QUANTONE.state.strokes.length=0")
    # --- poignées du zoom : taille fixe
    pg.click('#qdock [data-m=draw]');draw([(.3,.4),(.5,.5),(.7,.4)])
    pg.click('#qdock [data-m=move]');pg.mouse.click(*P(.5,.5));pg.wait_for_timeout(100)
    pg.evaluate("QZOOM.set(1,0,0)");o1=pg.evaluate("QZOOM.orb()");pg.evaluate("QZOOM.set(4,.3,.3)");o4=pg.evaluate("QZOOM.orb()")
    chk(abs(o4*4-o1)<1e-6,'poignée : distance écran constante (ORB %.3f → %.3f)'%(o1,o4))
    pg.evaluate("QZOOM.set(1,0,0)")
    # --- main avec l'outil Point
    pg.evaluate("QZOOM.set(3,0,0)");pg.click('#qdock [data-m=point]');pg.click('#zHand')
    n0=pg.evaluate("QUANTONE.state.strokes.length");pg.mouse.move(*P(.5,.5));pg.mouse.down();pg.mouse.move(P(.5,.5)[0]-50,P(.5,.5)[1]-50,steps=5);pg.mouse.up()
    chk(pg.evaluate("QZOOM.v.x")>.04 and pg.evaluate("QUANTONE.state.strokes.length")==n0,'main active avec l’outil Point (x=%.2f)'%pg.evaluate("QZOOM.v.x"))
    pg.click('#zHand');pg.evaluate("QZOOM.set(1,0,0)")
    # --- lasso : édition groupée de trois traits Rythmes
    pg.evaluate("QUANTONE.state.strokes.length=0");pg.evaluate("QUANTONE.state.layer=4")
    pg.click('#qdock [data-m=draw]')
    for y in (.2,.5,.8):draw([(.1,y),(.5,y+.02),(.9,y)])
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(200)
    n=pg.evaluate("QUANTONE.state.strokes.length");chk(n==3,'3 traits Rythmes (%d)'%n)
    # un trait à part, hors sélection
    pg.evaluate("(()=>{const S=QUANTONE.state;S.strokes[2].layer=4})()")
    pg.click('#qdock [data-m=move]');pg.evaluate("QUANTONE.ed.selMode='lasso'")
    draw([(.02,.02),(.98,.02),(.98,.62),(.02,.62),(.02,.02)])
    k=pg.evaluate("QUANTONE.ed.ms.length");chk(k==2,'lasso sur 2 traits (%d)'%k)
    pg.wait_for_timeout(300)
    chk(pg.evaluate("document.getElementById('inEd').style.display!=='none'&&!!document.querySelector('#inEd .iown')"),'le volet « ce trait seulement » est revenu')
    chk('2' in pg.evaluate("(document.querySelector('#inEd .grpN')||{}).textContent||''"),'le volet indique 2 traits')
    # choisir un motif et un kit
    mot=pg.evaluate("[].map.call(document.querySelectorAll('#dmMo option'),o=>o.value).filter(Boolean)[3]")
    pg.select_option('#dmMo',mot);pg.wait_for_timeout(200)
    pg.evaluate("QGRP.sync()")
    S=pg.evaluate("QUANTONE.state.strokes.map(s=>s.ip?JSON.stringify(s.ip.dm&&s.ip.dm.rows?s.ip.dm.rows.map(r=>r.on.join('')):null):null)")
    chk(S[0] and S[0]==S[1],'kit/motif identiques sur les 2 traits choisis')
    chk(S[2]!=S[0],'le 3e trait (hors sélection) est inchangé')
    gen=pg.evaluate("JSON.stringify(QUANTONE.state.dm.rows.map(r=>r.on.join('')))")
    chk(gen!=S[0],'la boîte générale n’est pas touchée')
    chk(not errs,'aucune erreur %s'%errs)
print('RÉSULTAT',sum(res),'/',len(res))
