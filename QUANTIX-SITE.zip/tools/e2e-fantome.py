# R388c : plus de boîte à rythme « fantôme » après restauration (le motif par défaut reste silencieux tant qu'on ne l'a pas voulu)
import sys
from playwright.sync_api import sync_playwright
Q='http://localhost:8765/studio/quantone.html';ok=0;n=0
def T(name,c):
    global ok,n;n+=1;ok+=bool(c);print(('OK   ' if c else 'FAIL ')+name)
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':780},has_touch=True,is_mobile=True);pg=c.new_page();er=[]
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto(Q);pg.wait_for_timeout(1800)
    any_=lambda:pg.evaluate("!!dmAny()")
    T('départ : motif par défaut silencieux',not any_())
    pg.evaluate("(()=>{var q=QXIO.build();window.__q=q;QXIO.open(q)})()");pg.wait_for_timeout(200)
    T('rechargement du préréglage tel quel : toujours silencieux',not any_())
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q)})()");pg.wait_for_timeout(200)
    T('avec un trait mélodique : toujours silencieux',not any_())
    # session : brouillon + rechargement de page
    pg.evaluate("window.dispatchEvent(new Event('pagehide'))");pg.wait_for_timeout(500);pg.reload();pg.wait_for_timeout(2500)
    T('après restauration de session : toujours silencieux',not any_() and pg.evaluate("QXIO.build().preset.strokes.length")>=1)
    # un motif voulu par l'utilisateur (dg=0) reste audible
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.dg=0;q.preset.dm={len:16,rows:q.preset.dm?q.preset.dm.rows:[]};QXIO.open(q)})()");pg.wait_for_timeout(200)
    T('motif voulu par l\'utilisateur : audible',any_())
    T('aucune erreur de page',not er)
    b.close()
print('RÉSULTAT %d / %d'%(ok,n));sys.exit(0 if ok==n else 1)
