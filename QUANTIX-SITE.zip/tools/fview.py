# fview.py N 'P' [solution json] — dessine la fiche (variante P) avec la trajectoire sans trait (rouge) et avec solution (jaune)
import sys,json,subprocess
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw
arg=sys.argv[1];mod,num=(arg.split('@')[0],int(arg.split('@')[1])) if '@' in arg else (arg,int(arg));   # « p3@33 » : fiche p3 jouée dans le niveau 33
P=sys.argv[2];sol=sys.argv[3] if len(sys.argv)>3 else '[]'
js="""const LAB=require('/home/claude/q/tools/lab.js'),F=require('/home/claude/q/tools/fiches/%s.js');const P=%s,c=F.gen(P);c.ink=999;const sol=%s;
const a=LAB.run(%d,c,[]),b=sol.length?LAB.run(%d,c,sol.map(p=>({pts:p,mat:F.mat||0}))):null;
console.log(JSON.stringify({c,a:a.tr.filter((_,i)=>i%%2==0),b:b?b.tr.filter((_,i)=>i%%2==0):null,okb:b&&b.ok}));"""%(mod,P,sol,num-1,num-1)
out=subprocess.run(['node','-e',js],capture_output=True,text=True).stdout.strip().split('\n')[-1];d=json.loads(out);c=d['c']
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_context(viewport={'width':390,'height':780}).new_page()
    pg.goto('file:///home/claude/q/index.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(400)
    pg.evaluate("TUTO.load({v:1,i:1,s:TUTO._tools.concat(['nd','spike','bounce','palB','boost','palA','ice','palC','wind','grav','mag','port','mov','ent','sup','det','tdil','soft'])},0);S.unlocked=131")
    pg.evaluate("""(a)=>{var L=LEVELS[a.i];['w','nd','ball','cup','pal','wind','grav','mag','rails','mz','curves'].forEach(function(f){if(f in a.c)L[f]=a.c[f];else if(f==='nd')L.nd=null;else L[f]=null;});L._rb=null;L._cv=null;L.star=null;
      L.walls=(L.w||[]).slice();var cp=L.cup;L.walls.push([cp[0],cp[1],cp[0]+cp[2],cp[1],0]);if(cp[3]==='R'||cp[3]==='B')L.walls.push([cp[0]+cp[2],cp[1],cp[0]+cp[2],cp[1]-56,0]);if(cp[3]==='L'||cp[3]==='B')L.walls.push([cp[0],cp[1],cp[0],cp[1]-56,0]);L.zone=[cp[0],cp[1]-48,cp[2],48];
      goto('game');loadLevel(a.i);S.strokes=a.s.map(function(p){return {pts:p,len:1,birth:0,mat:0};});}""",{'i':num-1,'c':c,'s':json.loads(sol)})
    pg.wait_for_timeout(500);r=pg.evaluate("(function(){var r=cv.getBoundingClientRect();return [r.left,r.top,r.width]})()")
    pg.screenshot(path='/tmp/fv.png');b.close()
im=Image.open('/tmp/fv.png').convert('RGB');dr=ImageDraw.Draw(im);s=r[2]/360
for key,col in (('a',(255,80,80)),('b',(255,230,90))):
    if d.get(key):dr.line([(r[0]+x*s,r[1]+y*s) for x,y in d[key]],fill=col,width=2)
im.crop((0,int(r[1]),390,int(r[1]+480*s))).save('/tmp/fv_crop.png');print('solution réussit' if d.get('okb') else 'solution : —' if sol=='[]' else 'solution ÉCHOUE')
