#!/usr/bin/env python3
# Construit FX_bank.zip (zip SANS compression) : effects.js, worklets.js, chains.json, ir/*.wav, manifest.json
# Usage : python3 tools/build-fxbank.py [R378] → écrit FX_bank.zip à la racine du site
import zipfile, json, sys, struct, math, random, os
import numpy as np
VER = sys.argv[1] if len(sys.argv) > 1 else 'R378'
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

WORKLETS = r"""
/* worklets.js — FX_bank (R378). Quatre processeurs : qx-pitch, qx-freeze, qx-tune, qx-crush. */
function ringRead(buf, pos){ const N = buf.length; pos = ((pos % N) + N) % N; const i = Math.floor(pos), f = pos - i; return buf[i] * (1 - f) + buf[(i + 1) % N] * f; }
class Shifter {                       /* décaleur à deux lignes à retard modulées, fondu en sin² (somme = 1) */
  constructor(N, win){ this.N = N; this.win = win; this.b = new Float32Array(N); this.w = 0; this.ph = 0; }
  step(x, ratio){
    this.b[this.w] = x;
    this.ph += (1 - ratio) / this.win; if (this.ph >= 1) this.ph -= 1; else if (this.ph < 0) this.ph += 1;
    const p1 = this.ph, p2 = (this.ph + .5) % 1, g1 = Math.sin(Math.PI * p1), g2 = Math.sin(Math.PI * p2);
    const y = g1 * g1 * ringRead(this.b, this.w - 1 - p1 * this.win) + g2 * g2 * ringRead(this.b, this.w - 1 - p2 * this.win);
    this.w = (this.w + 1) % this.N; return y;
  }
}
class QxPitch extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'semi', defaultValue: 0, minValue: -36, maxValue: 36 }]; }
  constructor(){ super(); const win = Math.floor(sampleRate * .07); this.s = [new Shifter(win * 3, win), new Shifter(win * 3, win)]; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const r = Math.pow(2, par.semi[0] / 12), n = y[0].length;
    for (let c = 0; c < y.length; c++){ const xi = x[Math.min(c, x.length - 1)], sh = this.s[c]; for (let i = 0; i < n; i++) y[c][i] = sh.step(xi[i], r); }
    return true;
  }
}
registerProcessor('qx-pitch', QxPitch);

class QxFreeze extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'hold', defaultValue: 0, minValue: 0, maxValue: 1 }, { name: 'size', defaultValue: .2, minValue: .03, maxValue: .6 }]; }
  constructor(){ super(); this.N = Math.floor(sampleRate * .7); this.rb = [new Float32Array(this.N), new Float32Array(this.N)]; this.w = 0; this.fz = [new Float32Array(this.N), new Float32Array(this.N)]; this.L = 1; this.on = false; this.t = 0; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const n = y[0].length, hold = par.hold[0] >= .5, L = Math.max(64, Math.floor(par.size[0] * sampleRate));
    if (hold && !this.on){ this.on = true; this.L = L; this.t = 0; for (let c = 0; c < 2; c++) for (let i = 0; i < L; i++) this.fz[c][i] = this.rb[c][(this.w - L + i + this.N * 2) % this.N]; }
    else if (!hold) this.on = false;
    for (let i = 0; i < n; i++){
      for (let c = 0; c < y.length; c++){
        const xi = x[Math.min(c, x.length - 1)][i]; this.rb[c][this.w] = xi;
        if (this.on){ const p1 = this.t % this.L, p2 = (this.t + this.L / 2) % this.L, a = Math.sin(Math.PI * p1 / this.L), b = Math.sin(Math.PI * p2 / this.L);
          y[c][i] = a * a * this.fz[c][Math.floor(p1)] + b * b * this.fz[c][Math.floor(p2)]; }
        else y[c][i] = xi;
      }
      this.w = (this.w + 1) % this.N; if (this.on) this.t++;
    }
    return true;
  }
}
registerProcessor('qx-freeze', QxFreeze);

const SCALES = [[0,1,2,3,4,5,6,7,8,9,10,11],[0,2,4,5,7,9,11],[0,2,3,5,7,8,10],[0,2,4,7,9],[0,3,5,6,7,10]];  /* chromatique, majeure, mineure, pentatonique, blues */
class QxTune extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'speed', defaultValue: .3, minValue: 0, maxValue: 1 }, { name: 'scale', defaultValue: 1, minValue: 0, maxValue: 4 }, { name: 'root', defaultValue: 0, minValue: 0, maxValue: 11 }]; }
  constructor(){ super(); this.D = 2; this.W = 512; this.A = new Float32Array(2048); this.aw = 0; this.cnt = 0; this.ratio = 1; this.tgt = 1; this.d = new Float32Array(400); const win = Math.floor(sampleRate * .05); this.sh = new Shifter(win * 3, win); this.dec = 0; this.dc = 0; this.f0 = 0; }
  yin(){   /* YIN (de Cheveigné & Kawahara, 2002) sur le signal sous-échantillonné par 2 */
    const W = this.W, A = this.A, N = A.length, sr = sampleRate / this.D, tmax = Math.min(399, Math.floor(sr / 70)), tmin = Math.floor(sr / 1000), d = this.d;
    const base = this.aw - W - tmax; let e = 0;
    for (let k = 0; k < W; k++){ const v = A[(base + tmax + k + N * 2) % N]; e += v * v; }
    if (e / W < 1e-5) return 0;
    d[0] = 1; let run = 0, best = -1;
    for (let t = 1; t <= tmax; t++){ let s = 0; for (let k = 0; k < W; k++){ const a = A[(base + tmax + k + N * 2) % N], b = A[(base + tmax + k - t + N * 2) % N]; s += (a - b) * (a - b); } run += s; d[t] = s * t / (run || 1); }
    for (let t = tmin; t <= tmax; t++){ if (d[t] < .15){ while (t + 1 <= tmax && d[t + 1] < d[t]) t++; best = t; break; } }
    if (best < 0) return 0;
    const x0 = d[best - 1] || d[best], x2 = d[best + 1] || d[best], dn = x0 - 2 * d[best] + x2, off = dn ? .5 * (x0 - x2) / dn : 0;
    return sr / (best + off);
  }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const n = y[0].length, sp = par.speed[0], sc = SCALES[Math.max(0, Math.min(4, Math.round(par.scale[0])))], root = Math.round(par.root[0]);
    for (let i = 0; i < n; i++){
      const m = (x[0][i] + (x[1] ? x[1][i] : x[0][i])) * .5;
      if ((this.dec++ & 1) === 0){ this.A[this.aw] = m; this.aw = (this.aw + 1) % this.A.length; this.cnt++; if (this.cnt >= 256){ this.cnt = 0; const f = this.yin(); this.f0 = f; if (f > 0){
        const midi = 69 + 12 * Math.log2(f / 440); let best = midi, bd = 99;
        for (let o = -1; o <= 10; o++) for (const s of sc){ const mm = o * 12 + ((s + root) % 12); const dd = Math.abs(mm - midi); if (dd < bd){ bd = dd; best = mm; } }
        this.tgt = Math.pow(2, (best - midi) / 12); } else this.tgt = 1; } }
      const k = 1 - Math.exp(-1 / (sampleRate * (.002 + (1 - sp) * (1 - sp) * .25))); this.ratio += (this.tgt - this.ratio) * k;
      const v = this.sh.step(m, this.ratio);
      for (let c = 0; c < y.length; c++) y[c][i] = v;
    }
    return true;
  }
}
registerProcessor('qx-tune', QxTune);

class QxCrush extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return [{ name: 'bits', defaultValue: 8, minValue: 2, maxValue: 16 }, { name: 'hold', defaultValue: 4, minValue: 1, maxValue: 64 }]; }
  constructor(){ super(); this.h = [0, 0]; this.c = 0; }
  process(inp, out, par){
    const x = inp[0], y = out[0]; if (!x || !x.length) return true;
    const L = Math.pow(2, Math.round(par.bits[0]) - 1), H = Math.max(1, Math.round(par.hold[0])), n = y[0].length;
    for (let i = 0; i < n; i++){ if (this.c <= 0){ for (let c = 0; c < y.length; c++) this.h[c] = Math.round(x[Math.min(c, x.length - 1)][i] * L) / L; this.c = H; } this.c--; for (let c = 0; c < y.length; c++) y[c][i] = this.h[c]; }
    return true;
  }
}
registerProcessor('qx-crush', QxCrush);
"""

EFFECTS = r"""
/* effects.js — FX_bank (R378). Exécuté par QFXE.loadBank(avec QFXE, H). Effets de banque : H.wfx = AudioWorklet (dérivation tant que le nœud n'est pas prêt). */
var def = QFXE.def, sm = H.sm, bq = H.bq, lfo = H.lfo, mixc = H.mixc;
def('pitch','cre','Décaleur de hauteur','Pitch shifter',3,[['a','Demi‑tons','Semitones',-12,12,7],['b','Fin (cents)','Fine (cents)',-50,50,0]],function(c){
  var u = H.wfx(c,'qx-pitch');
  u.onset = function(n,v){ n.parameters.get('semi').setTargetAtTime(Math.round(v.a*2)/2 + v.b/100, c.currentTime, .02); };
  return u; });
def('shim','spc','Shimmer','Shimmer',4,[['a','Taille','Size',0,1,.6],['b','Brillance','Bright',0,1,.6]],function(c){
  var i = c.createGain(), o = c.createGain(), cv = H.bankIR(c,'ir/hall.wav',2.4), lp = bq(c,'lowpass',9000,.5), g = c.createGain(), up = H.wfx(c,'qx-pitch');
  up.onset = function(n){ n.parameters.get('semi').value = 12; };
  i.connect(up.in); up.out.connect(cv); cv.connect(lp); lp.connect(g); g.gain.value = 1; g.connect(o);
  return { in:i, out:o, set:function(v){ sm(lp.frequency, mixc(1800,14000,v.b), c); sm(g.gain, .5 + v.a*.9, c); }, stop:function(){ up.stop(); } }; });
def('freeze','cre','Gel granulaire','Granular freeze',3,[['a','Gel (≥ 0,5)','Freeze (≥ 0.5)',0,1,0],['b','Grain (s)','Grain (s)',.05,.5,.2]],function(c){
  var u = H.wfx(c,'qx-freeze');
  u.onset = function(n,v){ n.parameters.get('hold').setValueAtTime(v.a >= .5 ? 1 : 0, c.currentTime); n.parameters.get('size').setTargetAtTime(v.b, c.currentTime, .02); };
  return u; });
def('tune','cre','Autotune','Autotune',4,[['a','Vitesse','Speed',0,1,.3],['b','Gamme (0‑4)','Scale (0‑4)',0,4,1],['c','Tonique (0‑11)','Root (0‑11)',0,11,0]],function(c){
  var u = H.wfx(c,'qx-tune');
  u.onset = function(n,v){ n.parameters.get('speed').setTargetAtTime(v.a, c.currentTime, .02); n.parameters.get('scale').value = Math.round(v.b); n.parameters.get('root').value = Math.round(v.c); };
  return u; });
def('crush2','col','Bitcrusher (échantillonnage)','Bitcrusher (sample rate)',2,[['a','Bits','Bits',2,16,8],['b','Taux','Rate',0,1,.5]],function(c){
  var u = H.wfx(c,'qx-crush');
  u.onset = function(n,v){ n.parameters.get('bits').value = Math.round(v.a); n.parameters.get('hold').value = 1 + Math.round(v.b*31); };
  return u; });
def('vib','mod','Vibrato','Vibrato',1,[['a','Vitesse','Rate',1,10,5],['b','Profondeur','Depth',0,1,.4]],function(c){
  var d = c.createDelay(.05), o = lfo(c,'sine',5), g = c.createGain(); d.delayTime.value = .008; o.connect(g); g.connect(d.delayTime);
  return { in:d, out:d, set:function(v){ sm(o.frequency,v.a,c); sm(g.gain,v.b*.0035,c); }, stop:function(){ try{o.stop();}catch(e){} } }; });
def('tape','spc','Délai cassette','Tape delay',2,[['a','Temps','Time',0,1,.4],['b','Répétitions','Repeats',0,.9,.45]],function(c,T){
  var i = c.createGain(), d = c.createDelay(2), fb = c.createGain(), lp = bq(c,'lowpass',3000,.5), hp = bq(c,'highpass',160,.5), o = lfo(c,'sine',.7), og = c.createGain(), out = c.createGain();
  i.connect(d); d.connect(lp); lp.connect(hp); hp.connect(fb); fb.connect(d); hp.connect(out); o.connect(og); og.connect(d.delayTime); og.gain.value = .0012;
  return { in:i, out:out, set:function(v){ sm(d.delayTime, Math.min(1.8, 60/Math.max(30,(T&&T.tempo)||90)*(.25+1.25*v.a)), c); sm(fb.gain, v.b, c); }, stop:function(){ try{o.stop();}catch(e){} } }; });
function irfx(id,fr,en,file,sec){
  def(id,'spc',fr,en,3,[['a','Amorti','Damping',0,1,.4],['b','Pré‑délai','Pre‑delay',0,.12,.02]],function(c){
    var pd = c.createDelay(.2), cv = H.bankIR(c,file,sec), lp = bq(c,'lowpass',9000,.5); pd.connect(cv); cv.connect(lp);
    return { in:pd, out:lp, set:function(v){ sm(pd.delayTime,v.b,c); sm(lp.frequency,mixc(15000,2000,v.a),c); }, stop:function(){} }; });
}
irfx('spring','Réverbération à ressort','Spring reverb','ir/spring.wav',1.6);
irfx('hall','Réverbération salle (hall)','Hall reverb','ir/hall.wav',2.4);
irfx('room','Petite pièce','Small room','ir/room.wav',.6);
def('vinyl','col','Disque vinyle','Vinyl',1,[['a','Craquements','Crackle',0,1,.4],['b','Usure','Wear',0,1,.4]],function(c){
  var i = c.createGain(), lp = bq(c,'lowpass',9000,.6), out = c.createGain(), ns = c.createBufferSource(), ng = c.createGain(), n = c.sampleRate*3, b = c.createBuffer(1,n,c.sampleRate), x = b.getChannelData(0), k;
  for(k=0;k<n;k++){ x[k] = Math.random() < .0009 ? (Math.random()*2-1) : (Math.random()*2-1)*.012; }
  ns.buffer = b; ns.loop = true; ns.connect(ng); ng.connect(out); ns.start(); i.connect(lp); lp.connect(out);
  return { in:i, out:out, set:function(v){ sm(ng.gain, v.a*.9, c); sm(lp.frequency, mixc(12000,2500,v.b), c); }, stop:function(){ try{ns.stop();}catch(e){} } }; }, 1);
"""

CHAINS = [
 {"id":"voixpop","fr":"Voix pop (autotune)","en":"Pop voice (autotune)","list":[{"t":"tune","a":0.15,"b":1,"c":0,"m":1},{"t":"comp","a":-24,"b":4,"m":1},{"t":"plate","a":0.5,"b":0.5,"m":0.25}]},
 {"id":"shimpad","fr":"Nappe shimmer","en":"Shimmer pad","list":[{"t":"shim","a":0.7,"b":0.6,"m":0.5},{"t":"chorus","a":0.4,"b":0.4,"m":0.3}]},
 {"id":"gelspace","fr":"Gel dans l'espace","en":"Frozen space","list":[{"t":"freeze","a":0,"b":0.25,"m":1},{"t":"hall","a":0.4,"b":0.04,"m":0.4}]},
 {"id":"radio","fr":"Vieille radio","en":"Old radio","list":[{"t":"crush2","a":10,"b":0.6,"m":1},{"t":"eq3","a":-6,"c":4,"b":-8,"m":1},{"t":"vinyl","a":0.5,"b":0.7,"m":1}]},
 {"id":"vinyle","fr":"Vinyle chaud","en":"Warm vinyl","list":[{"t":"vinyl","a":0.5,"b":0.5,"m":1},{"t":"lofi","a":0.4,"b":0.1,"m":0.8},{"t":"spring","a":0.5,"b":0.02,"m":0.2}]}]

def wav(name, sec, sr, decay, bright, spring=False, seed=1):
    rnd = np.random.default_rng(seed); n = int(sr*sec); t = np.arange(n)/sr; out = np.zeros((n,2), np.float32)
    for ch in range(2):
        x = rnd.standard_normal(n)
        lp = np.zeros(n); a = bright; y = 0.0
        for i in range(n):
            y += (x[i]-y)*(a*(1-0.6*i/n)); lp[i] = y
        env = np.exp(-t*decay)
        sig = lp*env
        if spring:    # ressort : écho chirp répété
            for k in range(1, 18):
                d = int(k*0.035*sr + ch*40)
                if d < n: sig[d:] += np.roll(sig, d)[d:]*0.0 + (rnd.standard_normal(n-d)*np.exp(-np.arange(n-d)/sr*40))*(0.55**k)
        sig[:int(sr*0.004)] *= np.linspace(0, 1, int(sr*0.004))
        out[:, ch] = sig
    out /= max(1e-6, np.abs(out).max())*1.15
    pcm = (out*32767).astype('<i2').tobytes()
    hdr = b'RIFF'+struct.pack('<I', 36+len(pcm))+b'WAVEfmt '+struct.pack('<IHHIIHH', 16, 1, 2, sr, sr*4, 4, 16)+b'data'+struct.pack('<I', len(pcm))
    return hdr+pcm

man = {"version": VER, "name": "FX_bank", "effects": ["pitch","shim","freeze","tune","crush2","vib","tape","spring","hall","room","vinyl"], "worklets": ["qx-pitch","qx-freeze","qx-tune","qx-crush"]}
files = {
 'manifest.json': json.dumps(man, ensure_ascii=False).encode(),
 'effects.js': EFFECTS.encode(), 'worklets.js': WORKLETS.encode(), 'chains.json': json.dumps(CHAINS, ensure_ascii=False).encode(),
 'ir/hall.wav': wav('hall', 2.6, 32000, 1.9, 0.5, seed=3),
 'ir/room.wav': wav('room', 0.7, 32000, 7.0, 0.55, seed=4),
 'ir/spring.wav': wav('spring', 1.7, 32000, 2.8, 0.42, spring=True, seed=5)}
out = os.path.join(ROOT, 'FX_bank.zip')
with zipfile.ZipFile(out, 'w', zipfile.ZIP_STORED) as z:
    for k, v in files.items(): z.writestr(k, v)
print('FX_bank.zip', VER, os.path.getsize(out), 'octets', list(files))
