# Bibliothèque de boucles de Track : suppression en deux touchers, sur l'icône comme sur le bouton (R375)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844},has_touch=True);er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(800)
    seed="""new Promise(res=>{const r=indexedDB.open('qxlib',1);r.onupgradeneeded=()=>r.result.createObjectStore('items',{keyPath:'id'});r.onsuccess=()=>{const tx=r.result.transaction('items','readwrite');const st=tx.objectStore('items');['A','B'].forEach((n,i)=>st.put({id:'t'+n,proj:'P1',name:'Test '+n,col:'#4DD7FF',ver:1,cr:i,qx:{q:'quantix-qx',preset:{}}}));tx.oncomplete=()=>res(1);};})"""
    pg.evaluate(seed);pg.reload();pg.wait_for_timeout(900)
    def open_lib():pg.select_option('#patSel','gear');pg.wait_for_timeout(300)
    open_lib();n0=pg.locator('#fx .gm').count();chk(n0>=2,'%d boucles listées'%n0)
    ic=pg.locator('#fx .gm').first.locator('button[data-a="del"] svg').first
    ic.click();pg.wait_for_timeout(200)
    chk(pg.locator('#fx .gm').count()==n0,'premier toucher (sur l’icône) : demande de confirmation, rien n’est supprimé')
    chk(pg.locator('#fx .gm').first.locator('button[data-a="del"]').get_attribute('data-armed')=='1','le bouton passe en rouge')
    pg.locator('#fx .gm').first.locator('button[data-a="del"] svg').first.click();pg.wait_for_timeout(500)
    chk(pg.locator('#fx .gm').count()==n0-1,'second toucher : la boucle est supprimée (%d → %d)'%(n0,pg.locator('#fx .gm').count()))
    pg.reload();pg.wait_for_timeout(900);open_lib()
    chk(pg.locator('#fx .gm').count()==n0-1,'la suppression est mémorisée après rechargement')
    # le premier toucher seul s'annule tout seul
    pg.locator('#fx .gm').first.locator('button[data-a="del"]').click();pg.wait_for_timeout(3300)
    chk(pg.locator('#fx .gm').count()==n0-1 and pg.locator('#fx .gm').first.locator('button[data-a="del"]').get_attribute('data-armed')!='1','sans second toucher, la demande expire')
    chk(not er,'aucune erreur de page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
