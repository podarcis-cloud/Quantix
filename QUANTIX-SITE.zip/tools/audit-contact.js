/* audit-contact.js — complète audit-conception : un obstacle est-il seulement APPROCHÉ (< 12 u) par la balle ?
   Sur la solution de référence + 150 lignes au hasard : distance minimale de la trajectoire à chaque mur / zone. « Jamais approché » = mort ou décoratif. */
const A=require('./audit-conception.js'),D=require('./design.js'),X=D.X,fs=require('fs');
const clone=o=>JSON.parse(JSON.stringify(o)),COST={0:1,1:1.9,3:1.7,5:1};
let seed=5;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
function dSeg(p,a){const ax=a[2]-a[0],ay=a[3]-a[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((p[0]-a[0])*ax+(p[1]-a[1])*ay)/l)):0;return Math.hypot(p[0]-a[0]-u*ax,p[1]-a[1]-u*ay);}
function dRect(p,r){const dx=Math.max(r[0]-p[0],0,p[0]-r[0]-r[2]),dy=Math.max(r[1]-p[1],0,p[1]-r[1]-r[3]);return Math.hypot(dx,dy);}
function traj(i,c,strokes){D.install(i,c);X.loadLevel(i);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:D.plen(s.pts),birth:0,mat:s.mat||0});X.qpBuild();X.S.mode='run';const t=[];
 for(let f=0;f<1200&&X.S.mode==='run';f++){X.physics();if(f%2===0)t.push([X.S.ball.x,X.S.ball.y]);}return t;}
const out={},N=+(process.env.N||150);
for(let i=0;i<X.LEVELS.length;i++){const L=A.ORIG[i],V=A.variants(L),mats=['S','B','A','C'].filter((m,k)=>k===0||(L.pal||'S').includes(m)).map(m=>({S:0,B:1,A:3,C:5}[m]));
 const T=[];if(L.optsol&&L.optsol.length)T.push({t:traj(i,clone(L),L.optsol.map(p=>({pts:p,mat:L.optmat||0}))),ref:1});
 const open=clone(L);open.nd=null;let g=0,n=0;
 while(n<N&&g<N*30){g++;const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);if(maxL<15)continue;const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),
  p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];if(!D.drawable(open,p)||!D.drawable(L,p))continue;n++;T.push({t:traj(i,clone(L),[{pts:p,mat:m}]),ref:0});}
 out[i+1]=V.map(v=>{let dRef=null,near=0,nl=0;
  for(const q of T){let m=1e9;for(const p of q.t){const d=v.k==='mur'?dSeg(p,L.w[v.j]):v.k==='zone'?dRect(p,L.nd[v.j]):1e9;if(d<m)m=d;}
   if(v.k==='méca'){m=null;}
   if(q.ref){dRef=m===null?null:Math.round(m);}else{nl++;if(m!==null&&m<12)near++;}}
  return {lab:v.lab,dRef,nearRnd:nl?+(near/nl).toFixed(3):null};});
 if(i%10===9)console.log(i+1);}
fs.writeFileSync(process.env.OUT||'docs/audit-contact.json',JSON.stringify(out));
