#!/usr/bin/env python3
"""calibrage-encre.py [--out F.md] : à partir du scan (tools/scan132.part*.jsonl), classe l'encre de chaque niveau et propose un quota.
Rapport r = quota / encre de la référence (géodésique actuelle). Bandes : serré < 1,25 ; standard 1,25–2 ; généreux > 2.
Propositions (jamais appliquées ici) : r < 1,15 → trop serré pour un doigt : ref×1,3+10 ; r > 3,5 → l'encre ne compte plus : ref×2+40.
Signaux : « référence non économe » (une ligne droite gagnante coûte < 80 % de la référence) ; « gagnable avec une ligne de N » (< 30 % : l'encre ne protège rien, c'est surtout un signal de contournement)."""
import json,glob,sys,collections
R={}
for f in sorted(glob.glob('/home/claude/q2/tools/scan132.part*.jsonl')):
    for l in open(f):
        try:d=json.loads(l);R[d['n']]=d
        except Exception:pass
r10=lambda v:int(round(v/10.0))*10
out=[];P=lambda *a:out.append(' '.join(str(x) for x in a))
P('# Calibrage de l\'encre (R297)');P('')
P('**Règle proposée.** Le quota découle de la meilleure solution connue : `Q = k × encre(référence) + c`, avec trois profils choisis par niveau — **défi d\'encre** (k=1,2 ; c=10 ; l\'encre fait partie du puzzle), **standard** (k=1,6 ; c=20), **découverte** (k=2 ; c=40, cf. DIFFICULTY_PROTOCOL §6). Garde-fous : la référence doit gagner, être dessinable au doigt et rester la plus économe connue (aucune ligne droite gagnante à moins de 80 % de son coût) ; un quota inférieur à 1,15 × la référence est refusé (un tracé au doigt dépasse toujours un peu). Les chiffres des beta-testeurs (encre utilisée, essais) ajusteront ensuite chaque niveau.')
P('');P('Cette page **ne modifie aucun niveau** : c\'est la photographie et une proposition à valider.');P('')
band=lambda r:'serré' if r<1.25 else 'standard' if r<=2 else 'généreux'
rows=[];BC=collections.Counter();flags=collections.defaultdict(list)
for n,d in sorted(R.items()):
    r=d.get('ref')
    if not r or not r.get('encre'):continue
    Q=d['encreDepart'];e=r['encre'];ra=Q/e;b=band(ra);BC[b]+=1
    mn=(d.get('min') or {}).get('encre');prop=None;why=[]
    if ra<1.15:prop=r10(e*1.3+10);why.append('trop serré (×%.2f)'%ra)
    if ra>3.5:prop=r10(e*2+40);why.append('encre sans enjeu (×%.1f)'%ra)
    if mn is not None and mn<0.3*e:why.append('gagnable avec une ligne de %d (réf %d) : l\'encre ne protège rien'%(mn,e))
    elif mn is not None and mn<0.8*e:why.append('référence non économe (ligne droite à %d vs %d)'%(mn,e))
    if r.get('dessinable') is False:why.append('référence non dessinable')
    if not r.get('gagne'):why.append('référence ne gagne pas')
    rows.append((n,d,Q,e,ra,b,mn,prop,why))
P('Répartition actuelle : '+', '.join('%s %d'%(k,v) for k,v in BC.items())+' (sur %d niveaux avec référence ; %d sans).'%(len(rows),len(R)-len(rows)));P('')
byw=collections.defaultdict(list)
for x in rows:byw[x[1]['wd']].append(x)
for w in sorted(byw):
    P('## Monde %d'%w);P('');P('| N | nom | quota | réf | ×réf | bande | ligne min | proposition |');P('|--|--|--|--|--|--|--|--|')
    for n,d,Q,e,ra,b,mn,prop,why in byw[w]:
        P('| %d | %s | %d | %d | %.2f | %s | %s | %s |'%(n,d['nom'][:20],Q,e,ra,b,mn if mn is not None else '–',(('**'+str(prop)+'** ' if prop else '')+'; '.join(why)) if (prop or why) else ''))
    P('')
sans=[n for n,d in sorted(R.items()) if not (d.get('ref') and d['ref'].get('encre'))]
P('Sans référence (rien à calibrer avant d\'en poser une) : %s'%sans)
t='\n'.join(out)
if '--out' in sys.argv:open(sys.argv[sys.argv.index('--out')+1],'w',encoding='utf-8').write(t)
else:print(t)
