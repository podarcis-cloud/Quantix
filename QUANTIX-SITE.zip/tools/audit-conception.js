/* audit-conception.js — audit de CONCEPTION des niveaux (R298) : utilité de chaque obstacle/mécanique.
   Pour chaque niveau : on retire un élément à la fois (rectangle de zone interdite, mur, ou mécanique entière) et on compare, sur les MÊMES lignes
   droites tirées au hasard (appariées), la part de réussites et le résultat de la solution de référence.
   Verdict par élément : indispensable (la référence échoue sans lui) · sert l'étoile · filtre (les réussites au hasard augmentent ≥ 2 pts) · sans effet.
   Usage : N=400 OUT=docs/audit-conception.json node tools/audit-conception.js [n° de niveau …]   (sans n° : les 132) */
const D=require('./design.js'),X=D.X,fs=require('fs');
const KEYS=['wind','grav','mag','port','mov','ent','gate','sup','det','tdil','rails','mz','curves','flow','vortex','updraft','pend','well','bf','kick','wrap','strings','elastic','strE','sling','fork','coil','spectro','rec','softball'];
const COST={0:1,1:1.9,3:1.7,5:1};
const clone=o=>JSON.parse(JSON.stringify(o));
const ORIG=X.LEVELS.map(L=>{const o={};for(const k of ['w','nd','star','ball','cup','ink','pal','n','optsol','optmat',...KEYS])if(k in L&&L[k]!==undefined)o[k]=clone(L[k]);return o;});
let seed=11;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const matsOf=L=>{const p=L.pal||'S',m=[0];if(p.includes('B'))m.push(1);if(p.includes('A'))m.push(3);if(p.includes('C'))m.push(5);return m;};
function runC(idx,c,strokes){try{D.install(idx,c);X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:D.plen(s.pts),birth:0,mat:s.mat||0});
 X.qpBuild();X.S.mode='run';for(let f=0;f<1200&&X.S.mode==='run';f++)X.physics();return {ok:X.S.mode==='success',star:!!X.S.gotStar};}catch(e){return {err:String(e).slice(0,80)};}}
function variants(L){const V=[];
 (L.nd||[]).forEach((r,j)=>V.push({k:'zone',j,lab:'zone interdite #'+(j+1)+' ['+r.join(',')+']',mk:c=>{c.nd=c.nd.filter((_,i)=>i!==j);if(!c.nd.length)c.nd=null;}}));
 (L.w||[]).forEach((w,j)=>V.push({k:'mur',j,lab:'mur #'+(j+1)+' mat '+w[4]+' ['+w.slice(0,4).join(',')+']',mk:c=>{c.w=c.w.filter((_,i)=>i!==j);}}));
 KEYS.forEach(k=>{if(L[k]!==undefined&&L[k]!==null&&!(Array.isArray(L[k])&&!L[k].length))V.push({k:'méca',j:k,lab:'mécanique « '+k+' »',mk:c=>{c[k]=undefined;}});});
 return V;}
function auditLevel(i,N){const L=ORIG[i],base=()=>clone(L),mats=matsOf(L),out={n:L.n,idx:i+1,elems:[]};
 const refS=L.optsol&&L.optsol.length?L.optsol.map(p=>({pts:p,mat:L.optmat||0})):null;
 const b0=refS?runC(i,base(),refS):null;out.refOk=b0?!!b0.ok:null;out.refStar=b0?!!b0.star:null;
 /* tirages : réservoir de lignes dessinables hors zones (appariées entre variantes) */
 const c0=base(),open=base();open.nd=null;const lines=[];let g=0;
 while(lines.length<N&&g<N*30){g++;const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);if(maxL<15)continue;
  const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];
  if(D.drawable(open,p))lines.push({p,m});}
 const rate=c=>{let ok=0;for(const l of lines){if(!D.drawable(c,l.p))continue;const r=runC(i,c,[{pts:l.p,mat:l.m}]);if(r.ok)ok++;}return ok/Math.max(1,lines.length);};
 out.P0=rate(base());
 for(const v of variants(L)){const c=base();v.mk(c);const r=refS?runC(i,c,refS):null,P=rate(c),d=P-out.P0;
  let verdict;if(r&&r.err)verdict='non testé';else if(r&&!r.ok)verdict='indispensable';else{const f=[];if(r&&out.refStar&&!r.star)f.push("sert l'étoile");if(d>=.02)f.push('filtre');verdict=f.length?f.join(' + '):'sans effet';}
  out.elems.push({k:v.k,lab:v.lab,P:+P.toFixed(4),dP:+d.toFixed(4),refSans:r?(r.ok?'ok':'échec'):null,verdict});}
 runC(i,base(),[]);return out;}
module.exports={ORIG,auditLevel,variants};
if(require.main===module){const N=+(process.env.N||400),OUT=process.env.OUT||'docs/audit-conception.json',res=fs.existsSync(OUT)?JSON.parse(fs.readFileSync(OUT)):{};
 const list=process.argv.slice(2).map(Number),idxs=list.length?list:X.LEVELS.map((_,i)=>i+1);
 for(const n of idxs){if(res[n]&&!list.length)continue;const t0=Date.now();res[n]=auditLevel(n-1,N);fs.writeFileSync(OUT,JSON.stringify(res));
  console.log(n,res[n].n,'P0',(res[n].P0*100).toFixed(1)+'%','éléments',res[n].elems.length,((Date.now()-t0)/1000).toFixed(1)+'s');}}
