# R388 : annuler / refaire dans Track
import sys
from playwright.sync_api import sync_playwright
ok=0;n=0
def T(name,c):
    global ok,n;n+=1;ok+=bool(c);print(('OK   ' if c else 'FAIL ')+name)
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':780},has_touch=True,is_mobile=True);pg=c.new_page();er=[]
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/morceau.html');pg.wait_for_timeout(1800)
    nc=lambda:pg.evaluate("MORCEAU.P().clips.length")
    dis=lambda i:pg.evaluate("document.getElementById('%s').disabled"%i)
    T('annuler et refaire inactifs au départ',dis('bUndo') and dis('bRedo'))
    pg.evaluate("(()=>{const sr=44100,a=new Float32Array(sr*2).map((_,i)=>Math.sin(i/20)*.3);const b=MORCEAU.addBlock({name:'T',ch:[a,a],sr:sr,len:2,col:'#4DD7FF'});MORCEAU.place(b.id||b,0,0,2);})()");pg.wait_for_timeout(300)
    T('pose d\'un bloc : annuler actif',nc()==1 and not dis('bUndo'))
    pg.evaluate("document.getElementById('bUndo').click()");pg.wait_for_timeout(200)
    T('annuler retire le bloc',nc()==0 and not dis('bRedo'))
    pg.evaluate("document.getElementById('bRedo').click()");pg.wait_for_timeout(200)
    T('refaire le remet',nc()==1)
    pg.wait_for_timeout(900)
    pg.evaluate("MORCEAU.P().tracks[0].mute=true;MORCEAU.render();");pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('bUndo').click()");pg.wait_for_timeout(200)
    T('annuler un réglage de piste (mute)',not pg.evaluate("MORCEAU.P().tracks[0].mute") and nc()==1)
    T('aucune erreur de page',not er)
    b.close()
print('RÉSULTAT %d / %d'%(ok,n));sys.exit(0 if ok==n else 1)
