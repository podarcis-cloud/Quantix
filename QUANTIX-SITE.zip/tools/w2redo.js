const LAB=require('./lab.js');
const V={
 fil1:{c:{ink:300,ball:[40,300],cup:[220,250,110,'R'],w:[[0,472,250,472,2],[250,462,345,470,1]],nd:[[0,0,360,320]]},box:[0,250,320,460]},
 fil2:{c:{ink:300,ball:[40,300],cup:[200,240,120,'R'],w:[[0,472,240,472,2],[240,455,340,468,1]],nd:[[0,0,360,315]]},box:[0,250,315,455]}
};
for(const k of process.argv.slice(2)){const v=V[k],c=v.c,b=v.box,cs=LAB.strip(c);let w=0,ws=0,ex=null;
 const mats=(c.pal||'S').includes('B')?[0,1]:[0];const tried=[];
 for(let x=b[0];x<=b[1];x+=10)for(let y=b[2];y<=b[3];y+=10)for(let a=0;a<6.283;a+=.35)for(const L of [30,60,100,150,200])for(const m of mats){
  if(L*(m?1.9:1)>c.ink)continue;const p=[[x,y],[Math.round(x+Math.cos(a)*L),Math.round(y+Math.sin(a)*L)]];if(!LAB.D.drawable(c,p))continue;tried.push([p,m]);}
 if(v.poly)for(let i=0;i<2500;i++){const h=q=>{const s=Math.sin((i+1)*q*12.9898)*43758.5453;return s-Math.floor(s);};
  const p=[[Math.round(250+h(1)*60),Math.round(215+h(2)*40)],[Math.round(120+h(3)*110),Math.round(330+h(4)*90)],null];p[2]=[p[1][0]-Math.round(5+h(5)*30),p[1][1]+Math.round((h(6)-.5)*10)];
  if(LAB.D.drawable(c,p)&&LAB.D.plen(p)<=c.ink)tried.push([p,0]);}
 const t0=Date.now();for(const [p,m] of tried){if(Date.now()-t0>38000)break;if(LAB.run(0,c,[{pts:p,mat:m}]).ok){w++;if(!ex)ex=[p,m];if(LAB.run(0,cs,[{pts:p,mat:0}]).ok)ws++;}}
 console.log(k.padEnd(6),'sans trait:',LAB.run(0,c,[]).ok?'RÉUSSIT':'échoue','| gagnants',w,'/',tried.length,'| sans mécanique',ws,'| ex',JSON.stringify(ex));}
