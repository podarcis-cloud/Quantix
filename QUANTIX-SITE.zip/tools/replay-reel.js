/* replay-reel.js — rejeu des tracés RÉELS (événements la.g) dans le moteur headless.
   Usage : node tools/replay-reel.js EXPORT.json [--lv 21] [--patch '{"nd":[[…]]}'] [--v]
   1) fidélité : le rejeu retrouve-t-il le résultat réel (rs) de chaque essai ?  2) contrefactuel : --patch modifie le niveau (champs de LEVELS[i]) et
   donne le taux de réussite des mêmes tracés sur la variante. Limites : seuls les essais avec géométrie finale (R295+) ; déplacements en cours d'essai non rejoués. */
const fs=require('fs');require('./load.js');const X=globalThis.__X,S=X.S;
const a=process.argv.slice(2),F=a[0],opt=k=>{const i=a.indexOf(k);return i>0?a[i+1]:null;};
const LVF=opt('--lv')?+opt('--lv'):null,PATCH=opt('--patch')?JSON.parse(opt('--patch')):null,V=a.includes('--v');
const j=JSON.parse(fs.readFileSync(F,'utf8')),by={};
j.batches.forEach(b=>b.ev.forEach(e=>{(by[b.sid]=by[b.sid]||[]).push(e);}));
const T=[];   // essais : {l, strokes, real}
Object.values(by).forEach(ev=>{ev.sort((p,q)=>p.k-q.k);let cur=null;ev.forEach(e=>{
  if(e.y==='la'&&e.d&&e.d.g&&e.d.g.length){cur={l:e.l,g:e.d.g,real:null};}
  else if(e.y==='rs'&&cur&&e.l===cur.l){cur.real=e.d.r;T.push(cur);cur=null;}});});
const orig={};function setLevel(l){const i=l-1;if(PATCH){if(!orig[i])orig[i]=JSON.parse(JSON.stringify(X.LEVELS[i]));Object.assign(X.LEVELS[i],JSON.parse(JSON.stringify(PATCH)));}return i;}
function run(t){const i=setLevel(t.l);X.loadLevel(i);
 t.g.forEach(g=>{const p=g.p,pts=[];for(let q=0;q+1<p.length;q+=2)pts.push([p[q],p[q+1]]);S.strokes.push({pts,len:g.l||0,birth:0,mat:g.m||0});});
 X.qpBuild();S.mode='run';for(let f=0;f<1800&&S.mode==='run';f++)X.physics();return S.mode;}
const res={};
T.filter(t=>!LVF||t.l===LVF).forEach(t=>{const m=run(t),ok=m==='success',real=t.real==='win'||t.real==='success'||t.real==='ok';
 const r=res[t.l]=res[t.l]||{n:0,realOk:0,simOk:0,agree:0};r.n++;r.realOk+=real?1:0;r.simOk+=ok?1:0;r.agree+=(real===ok)?1:0;
 if(V)console.log('L'+t.l,'réel',t.real,'→ rejeu',m);});
Object.keys(res).sort((x,y)=>x-y).forEach(l=>{const r=res[l];console.log('N'+l,'essais',r.n,'| réel réussis',r.realOk,'| rejeu réussis',r.simOk,'| accord',r.agree+'/'+r.n);});
