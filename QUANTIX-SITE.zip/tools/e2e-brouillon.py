# Brouillon automatique de Quantone (R346) — serveur local sur 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844});pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    pg.evaluate("QUANTONE.state.strokes.length=0");pg.click('#qdock [data-m=draw]')
    for i in range(3):
        pg.mouse.move(60+i*30,300+i*20);pg.mouse.down();pg.mouse.move(150+i*30,340+i*20,steps=5);pg.mouse.up()
    pg.wait_for_timeout(3500)
    n=pg.evaluate("QFX3.preset().strokes.length");chk(n>=3,'3 traits dessinés (%d)'%n)
    chk(pg.evaluate("!!localStorage.getItem('quantone.auto')"),'brouillon enregistré')
    pg2=ctx.new_page();pg2.on('pageerror',lambda e:errs.append(str(e)))
    pg2.goto('http://localhost:8765/studio/quantone.html');pg2.wait_for_timeout(2000)
    chk(pg2.evaluate("!!document.getElementById('qAutoChip')"),'bouton « Reprendre » proposé au nouveau départ')
    pg2.click('#qAutoChip');pg2.wait_for_timeout(300)
    chk(pg2.evaluate("QFX3.preset().strokes.length")==n,'brouillon repris : %d traits'%pg2.evaluate("QFX3.preset().strokes.length"))
    # Effacer vide aussi la boîte à rythmes (annulable)
    pg2.evaluate("QFX3.open(4)");pg2.wait_for_timeout(300)
    pg2.select_option('#dmMo',pg2.evaluate("[].map.call(document.querySelectorAll('#dmMo option'),o=>o.value).filter(Boolean)[2]"));pg2.wait_for_timeout(200)
    k=lambda:pg2.evaluate("QFX3.score().filter(e=>e.kind===4).length")
    a=k();pg2.click('#bClear');pg2.wait_for_timeout(200);b0=k()
    pg2.click('#bUndo');pg2.wait_for_timeout(200);c=k()
    chk(a>0 and b0==0 and c==a,'Effacer vide la boîte à rythmes (%d → %d), annuler la rend (%d)'%(a,b0,c))
    chk(not errs,'aucune erreur %s'%errs)
print('RÉSULTAT',sum(res),'/',len(res))
