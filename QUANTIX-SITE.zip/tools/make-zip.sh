#!/bin/bash
# Zip de livraison : tout le site SAUF le gros de studio/ (captures, galeries), MAIS avec studio/quantone.html
# (le jeu l'ouvre : sans lui, Quantone affiche « 404 »). À utiliser pour tout envoi de zip.
cd "$(dirname "$0")/.." && rm -f /tmp/Q.zip && zip -qr /tmp/Q.zip . -x "studio/*" -x "*.bak" -x "docs/source-art/*" -x "docs/apercus/*" -x "assets/bank/*.bin" -x "KIT_bank.zip" -x "FX_bank.zip" && zip -q /tmp/Q.zip studio/quantone.html studio/morceau.html studio/proto-plein-cadre.js studio/proto-plein-cadre.css studio/qfx.js studio/qwave.js && cp /tmp/Q.zip /mnt/user-data/outputs/QUANTIX-SITE.zip && unzip -l /tmp/Q.zip | grep -c "studio/quantone.html" && ls -la /mnt/user-data/outputs/QUANTIX-SITE.zip
