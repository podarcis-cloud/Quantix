/* fiche.js — construit un niveau À PARTIR DE SA FICHE SCÉNARIO (R64).
   Une fiche (fichier tools/fiches/NN.js) décrit : la géométrie paramétrée (gen), la solution voulue (sol), le leurre
   (leurre, facultatif), et une grille de paramètres. Pour chaque jeu de paramètres, on vérifie TOUS les critères :
   échec sans trait · la solution voulue réussit · P_ligne ≥ 0,85 · le leurre échoue · aucun trait plus court que le seuil
   ne réussit (coût minimal) · P_hasard ≤ cible · le noyau est placé sur la trajectoire de la solution · encre = 1,3 × coût.
   La meilleure variante est écrite dans forge.json (clé NN_fiche) ; slotwrite.py l'installe.
   Usage : node fiche.js 44                                                                  */
const D=require('./design.js'),LAB=require('./lab.js'),fs=require('fs'),DIF=require('./difficulty.js');   /* R116 : la porte de jouabilité est le modèle du DOIGT (difficulty.js), plus le décalage de ±3 u */
const PEMIN=+(process.env.PEMIN||.70);
function pexec(idx,c,sol,mat,N){LAB.run(idx,c,[]);DIF.setSeed(idx*7919+1);return DIF.P(idx,DIF.X.LEVELS[idx],sol,DIF.modelFor(idx),mat,N||30).win;}
const num=+process.argv[2],idx=num-1,pos=idx%12+1,F=require('./fiches/'+num+'.js');
const TGT=p=>p<=2?.04:p<=5?.015:p<=9?.005:.002,MINLEN=p=>+(process.env.MINL||0)||(p<=3?40:p<=8?80:120);
let seed=num*31;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}function g(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
const len=s=>s.reduce((a,p,i)=>i?a+Math.hypot(p[0]-s[i-1][0],p[1]-s[i-1][1]):0,0);
function check(P){
 const c=F.gen(P),mat=F.mat||0;let sol=F.sol?F.sol(P):null;
 if(!sol&&F.boxes){ /* la fiche décrit OÙ et COMMENT le geste se construit (boîtes) ; on cherche la meilleure réalisation */
  const B=F.boxes(P),wins=[];c.ink=9999;
  for(let k=0;k<+(process.env.NS||2500)&&wins.length<40;k++){const ss=B.map(b=>{const x=b.x[0]+rnd()*(b.x[1]-b.x[0]),y=b.y[0]+rnd()*(b.y[1]-b.y[0]),a=b.a[0]+rnd()*(b.a[1]-b.a[0]),l=b.l[0]+rnd()*(b.l[1]-b.l[0]);
    return [[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];});
   if(ss.some(p=>!D.drawable(c,p)))continue;if(LAB.run(idx,c,ss.map(p=>({pts:p,mat}))).ok)wins.push(ss);}
  let bb=null;for(const ss of wins.slice(0,24)){const k2=pexec(idx,c,ss,mat,12);if(!bb||k2>bb.k)bb={ss,k:k2};if(bb.k>=1)break;}
  if(!bb)return {P,c,why:'aucune réalisation du geste ne réussit'};sol=bb.ss;}
 const cost=sol.reduce((a,s)=>a+len(s),0)*(mat===1?1.9:mat===3?1.7:1);
 c.ink=Math.round(Math.max(cost*1.3,cost+25));const out={P,c,why:''};
 if(LAB.run(idx,c,[]).ok){out.why='réussit sans trait';return out;}
 const r=LAB.run(idx,c,sol.map(p=>({pts:p,mat})));if(!r.ok){out.why='la solution voulue échoue';return out;}
 /* mondes à champ (R70) : la solution doit échouer quand on retire le champ — sinon le vent (ou la gravité, l'aimant) n'est qu'un décor */
 if(F.obstacle){ /* champ‑obstacle (vent contraire…) : le leurre doit réussir SANS le champ et échouer AVEC — preuve que le champ change tout */
  const c0=Object.assign({},c);for(const fld of ['wind','grav','mag'])c0[fld]=[];
  let lr=F.leurre?F.leurre(P):null;
  if(F.leurreBoxes){ /* le leurre est cherché : un geste du même type qui réussit SANS le champ */
   lr=null;const B=F.leurreBoxes(P);for(let k=0;k<3000&&!lr;k++){const ss=B.map(b=>{const x=b.x[0]+rnd()*(b.x[1]-b.x[0]),y=b.y[0]+rnd()*(b.y[1]-b.y[0]),a=b.a[0]+rnd()*(b.a[1]-b.a[0]),l=b.l[0]+rnd()*(b.l[1]-b.l[0]);
     return [[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];});
    if(ss.some(p=>!D.drawable(c0,p)))continue;if(LAB.run(idx,c0,ss.map(p=>({pts:p,mat}))).ok&&!LAB.run(idx,c,ss.map(p=>({pts:p,mat}))).ok)lr=ss;}
   if(!lr){out.why='aucun leurre : rien de ce type ne réussit sans le champ tout en échouant avec';return out;}out.leurre=lr;}
  if(!LAB.run(idx,c0,lr.map(p=>({pts:p,mat}))).ok){out.why='le leurre échoue même sans le champ (le champ ne change rien)';return out;}}
 else for(const fld of ['wind','grav','mag'])if(c[fld]&&c[fld].length){const c0=Object.assign({},c);c0[fld]=[];if(LAB.run(idx,c0,sol.map(p=>({pts:p,mat}))).ok){out.why='réussit aussi sans '+({wind:'le vent',grav:'la gravité locale',mag:"l'aimant"})[fld];return out;}}
 if(F.leurre&&!F.leurreBoxes){const lr=F.leurre(P),lc=lr.reduce((a,s)=>a+len(s),0)*(mat===1?1.9:mat===3?1.7:1);   /* un leurre trop cher pour l'énergie disponible ne peut pas être tracé */
  if(lc<=c.ink&&LAB.run(idx,c,lr.map(p=>({pts:p,mat}))).ok){out.why='le leurre réussit';return out;}}
 let s=0;for(let k=0;k<30;k++)if(LAB.run(idx,c,sol.map(p=>({pts:p.map(q=>[q[0]+g()*3,q[1]+g()*3]),mat}))).ok)s++;
 out.pl=s/30;out.soft=[];if(process.env.PLGATE&&out.pl<+(process.env.PMIN||.85)){   /* R116 : P_ligne n'est plus qu'un indicateur ; la porte est P_exec (doigt) */if(process.env.SOFT)out.soft.push('P_ligne '+Math.round(out.pl*100)+' %');else{out.why='trop fragile au doigt (P_ligne '+out.pl.toFixed(2)+')'+(process.env.SHOW?' '+JSON.stringify(sol):'');return out;}}
 out.pe=pexec(idx,c,sol,mat,30);
 if(out.pe<PEMIN){if(process.env.SOFT)out.soft.push('P_exec '+Math.round(out.pe*100)+' %');else{out.why='injouable au doigt (P_exec '+Math.round(out.pe*100)+' %)';return out;}}
 const mats=[0].concat((c.pal||'S').includes('B')?[1]:[]).concat((c.pal||'S').includes('A')?[3]:[]);
 let tr=0;while(tr<1500){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,l=8+rnd()*(MINLEN(pos)-8),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];
  if(!D.drawable(c,p))continue;tr++;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok){if(process.env.SOFT){out.soft.push('trait court '+Math.round(l)+' u'+(process.env.SHOW?JSON.stringify(p):''));break;}out.why='un trait court ('+Math.round(l)+' u) suffit'+(process.env.SHOW?' '+JSON.stringify(p):'');return out;}}
 let w=0,t=0;while(t<2500){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,l=15+rnd()*Math.min(220,c.ink),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];
  if(!D.drawable(c,p)||l*(m===1?1.9:m===3?1.7:1)>c.ink)continue;t++;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok)w++;}
 out.ph=w/t;if(out.ph>TGT(pos)&&process.env.SOFT)out.soft.push('P_hasard '+(out.ph*100).toFixed(1)+' %');else if(out.ph>TGT(pos)){out.why='trop facile au hasard ('+(out.ph*100).toFixed(2)+' %)';return out;}
 const q=r.tr[Math.floor(r.tr.length*(F.star||.6))];c.star=[Math.round(q[0]),Math.round(q[1])];
 if(!LAB.run(idx,c,sol.map(p=>({pts:p,mat}))).star){out.why='noyau mal placé';return out;}
 out.ok=true;out.sol=sol;out.mat=mat;return out;}
/* R118 — exploration automatique : si la fiche donne F.space = {param:[min,max]} (ou une liste de valeurs), l'outil tire des
   variantes au hasard jusqu'au budget de temps (BUDGET s, 240 par défaut) au lieu d'une grille écrite à la main. */
function sample(sp){const P={};for(const k in sp){const v=sp[k];P[k]=Array.isArray(v)&&v.length===2&&typeof v[0]==='number'&&typeof v[1]==='number'?Math.round(v[0]+rnd()*(v[1]-v[0])):(Array.isArray(v)?v[Math.floor(rnd()*v.length)]:v);}return P;}
const grid=F.space?{[Symbol.iterator]:function*(){for(let k=0;k<400;k++)yield sample(F.space);}}:F.grid();let best=null,n=0;const t0=Date.now();
for(const P of grid){if(Date.now()-t0>(+process.env.BUDGET||240)*1000)break;n++;const o=check(P);
 if(process.env.V)console.log(JSON.stringify(P),o.ok?'CONFORME':o.why);
 if(o.ok&&(!best||o.pe>best.pe||(o.pe===best.pe&&o.pl>best.pl)))best=o;}
console.log(`#${num} fiche « ${F.titre} » — ${n} variantes essayées en ${Math.round((Date.now()-t0)/1000)} s`);
if(best){const f=JSON.parse(fs.readFileSync('forge.json'));f[num+'_fiche']={c:best.c,optsol:best.sol,optmat:best.mat,P:best.P};fs.writeFileSync('forge.json',JSON.stringify(f,null,1));
 console.log(`   ${best.soft&&best.soft.length?'RETENU AVEC RÉSERVES ['+best.soft.join(' ; ')+']':'CONFORME'} : ${JSON.stringify(best.P)} · P_exec ${Math.round(best.pe*100)} % · P_ligne ${Math.round(best.pl*100)} % · P_hasard ${(best.ph*100).toFixed(2)} % · encre ${best.c.ink}`);}
else console.log('   aucune variante conforme — voir V=1 pour le détail');
