from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2).new_page()
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('file://'+__import__('os').path.abspath(__import__('os').path.join(__import__('os').path.dirname(__file__),'..','studio','quantone.html'))+'');pg.wait_for_timeout(700)
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=st.strokes.filter(s=>s.layer!==4);QDM.get().rows.forEach(r=>{r.on=new Array(16).fill(0);});st.dm.mot='';st.grid=16;})()")   # R363 : l'état par défaut contient maintenant un trait Rythmes pleine largeur + boîte remplie ; ces tests partent de l'ancien état (2 courbes, boîte vide)
    r=pg.evaluate("(function(){var r=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width]})()")
    def at(x,y):return (r[0]+x*r[2],r[1]+y*r[2])
    n=lambda:pg.evaluate("QUANTONE.state.strokes.length")
    n0=n()
    pg.click('#qdock .dk[data-m=line]');pg.wait_for_timeout(150)
    pg.mouse.move(*at(.1,.15));pg.mouse.down();pg.mouse.move(*at(.6,.152),steps=10);pg.wait_for_timeout(100);pg.screenshot(path='/tmp/q_line.png');pg.mouse.up()
    s=pg.evaluate("QUANTONE.state.strokes[QUANTONE.state.strokes.length-1].pts")
    chk(n()==n0+1 and abs(s[0][1]-s[-1][1])<1e-6,'ligne droite horizontale (accroche 0°), %d points'%len(s))
    sc=pg.evaluate("QUANTONE.score().length");chk(sc>0,'la ligne produit des notes (%d événements)'%sc)
    # deux touchers
    pg.mouse.click(*at(.2,.3));pg.wait_for_timeout(100);pg.mouse.click(*at(.8,.4));pg.wait_for_timeout(100)
    chk(n()==n0+2,'ligne par deux touchers')
    # gomme
    pg.click('#qdock .dk[data-m=erase]');pg.mouse.click(*at(.35,.15));pg.wait_for_timeout(100)
    chk(n()==n0+1,'gomme : tracé effacé')
    pg.click('#bUndo');chk(n()==n0+2,'annuler : tracé rétabli')
    # déplacer
    pg.click('#qdock .dk[data-m=move]');a0=pg.evaluate("QUANTONE.state.strokes[%d].pts[0]"%(n0))
    pg.mouse.move(*at(.35,.15));pg.mouse.down();pg.mouse.move(*at(.35,.25),steps=8);pg.wait_for_timeout(100);pg.screenshot(path='/tmp/q_move.png');pg.mouse.up()
    a1=pg.evaluate("QUANTONE.state.strokes[%d].pts[0]"%(n0));chk(abs((a1[1]-a0[1])-.1)<.01,'déplacer : translation de 0,1')
    pg.click('#bUndo');a2=pg.evaluate("QUANTONE.state.strokes[%d].pts[0]"%(n0));chk(abs(a2[1]-a0[1])<1e-6,'annuler le déplacement')
    # rotation par la poignée
    pg.mouse.click(*at(.35,.15));hp=pg.evaluate("(function(){var s=QUANTONE.ed.sel;return s?[s.h]:null})()")
    chk(hp is not None,'sélection par toucher')
    h=pg.evaluate("QUANTONE.hPos()");c=pg.evaluate("QUANTONE.cen(QUANTONE.ed.sel.s.pts)")
    pg.mouse.move(*at(h[0],h[1]));pg.mouse.down();pg.mouse.move(*at(c[0]+.16,c[1]),steps=10);pg.mouse.up()
    q=pg.evaluate("QUANTONE.state.strokes[%d].pts"%n0);import math
    ang=abs(math.degrees(math.atan2(q[-1][1]-q[0][1],q[-1][0]-q[0][0])))
    chk(abs(ang-90)<8,'rotation par la poignée ≈ 90° (%.0f°)'%ang)
    # mise à l'échelle par la poignée ⤢
    sp=pg.evaluate("QUANTONE.sPos()");wd=lambda:pg.evaluate("(function(){var s=QUANTONE.state.strokes[%d].pts,m=Math.min.apply(null,s.map(function(q){return q[1]})),M=Math.max.apply(null,s.map(function(q){return q[1]}));return Math.hypot(s[s.length-1][0]-s[0][0],s[s.length-1][1]-s[0][1]);})()"%n0)
    w0=wd();pg.mouse.move(*at(sp[0],sp[1]));pg.mouse.down();cc=pg.evaluate("QUANTONE.cen(QUANTONE.ed.sel.s.pts)");pg.mouse.move(*at(cc[0]+(sp[0]-cc[0])*1.6,cc[1]+(sp[1]-cc[1])*1.6),steps=8);pg.mouse.up()
    w1=wd();chk(w1>w0*1.3,'échelle par la poignée ⤢ : %.2f → %.2f'%(w0,w1))
    pg.click('#bUndo');chk(abs(wd()-w0)<1e-3,'annuler la mise à l’échelle')
    pg.click('#qdock .dk[data-m=draw]');pg.screenshot(path='/tmp/q_all.png',full_page=True)
    b.close()
print('erreurs',errs);print('RÉSULTAT',sum(res),'/',len(res))
