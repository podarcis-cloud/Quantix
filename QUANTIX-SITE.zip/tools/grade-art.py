"""grade-art.py — étalonne les illustrations pour la charte du jeu (fond #05070D, néon).
Originaux intouchés dans docs/source-art/ ; les fichiers d'assets/ sont régénérés depuis eux.
Réglages : saturation ×0,48, luminosité ×0,70 (tons moyens), virage colorimétrique
nuit → couleur du monde → cyan pâle (22 %), vignettage. Relançable à volonté."""
import os,shutil
from PIL import Image,ImageEnhance,ImageOps,ImageChops,ImageDraw,ImageFilter,ImageStat
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC=os.path.join(ROOT,'docs','source-art')
COL={'w01-atelier':'#43D5F5','w02-fonderie':'#FF8A3C','w03-chaine':'#A878FF','w04-glacier':'#8FE3FF','w05-soufflerie':'#A8C8E8',
 'w06-mecanique':'#E0B24C','w07-gravite':'#8C7BFF','w08-magnetisme':'#FF6FB5','w09-faille':'#5CE8A8','w10-filaments':'#E8B98A',
 'w11-quantique':'#A878FF','constellation':'#8C7BFF','hero':'#43D5F5'}
def grade(im,accent):
    im=im.convert('RGB')
    im=ImageEnhance.Color(im).enhance(.48)
    im=ImageEnhance.Brightness(im).enhance(.70)
    im=ImageEnhance.Contrast(im).enhance(1.06)
    tone=ImageOps.colorize(ImageOps.grayscale(im),black='#05070D',mid=accent,white='#DDF4FF',blackpoint=0,midpoint=150,whitepoint=255)
    im=Image.blend(im,tone,.22)
    w,h=im.size;m=Image.new('L',(w,h),0);d=ImageDraw.Draw(m)
    d.ellipse((-w*.18,-h*.10,w*1.18,h*1.10),fill=255);m=m.filter(ImageFilter.GaussianBlur(w*.12))
    dark=Image.new('RGB',(w,h),'#05070D');im=Image.composite(im,Image.blend(im,dark,.55),m)
    return im
for d,names in [('worlds',[n for n in COL if n.startswith('w')]),('ui',['constellation','hero'])]:
    for n in names:
        dst=os.path.join(ROOT,'assets','img',d,n+'.jpg');src=os.path.join(SRC,n+'.jpg')
        if not os.path.exists(src):shutil.copy(dst,src)          # première fois : sauvegarde de l'original
        a=Image.open(src);b=grade(a,COL[n]);b.save(dst,quality=84,optimize=True,progressive=True)
        s0=ImageStat.Stat(a.convert('HSV'));s1=ImageStat.Stat(b.convert('HSV'))
        print('%-16s saturation %3.0f → %3.0f | luminosité %3.0f → %3.0f'%(n,s0.mean[1],s1.mean[1],s0.mean[2],s1.mean[2]))
