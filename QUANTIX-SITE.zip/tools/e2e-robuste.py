# Un son qui plante ne doit pas bloquer la lecture (R349) — serveur local 8765
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1000)
    pg.evaluate("QUANTONE.state.strokes.length=0")
    pg.evaluate("(function(){var d=new Float32Array(44100);for(var k=0;k<d.length;k++)d[k]=.8*Math.sin(2*Math.PI*220*k/44100)*Math.exp(-k/22050);QSMP.set(1,d,44100,'test');})()")
    pg.evaluate("(()=>{const S=QUANTONE.state;S.strokes.push({layer:9,pts:[[.05,.5,0],[.9,.5,20]]},{layer:0,pts:[[.05,.3,0],[.9,.35,20]]})})()")
    pg.click('#bPlay');pg.wait_for_timeout(700)
    pg.evaluate("window.__cb=AudioContext.prototype.createBuffer;AudioContext.prototype.createBuffer=function(){throw new Error('NotSupportedError test')};QSMP.SMP[1].buf=null;QSMP.SMP[1].bufs=null")
    pg.wait_for_timeout(1800)
    chk(pg.evaluate("document.getElementById('bPlay').textContent")!='Listen','la lecture continue malgré un son qui plante')
    lv=pg.evaluate("QUANTONE.level()");chk(lv>0.0005,'les autres traits sonnent (niveau %.4f)'%lv)
    chk(len(errs)<3,'pas de tempête d’erreurs (%d)'%len(errs))
    t=pg.evaluate("(document.querySelector('.toast,#toast')||{}).textContent||''")
    pg.evaluate("AudioContext.prototype.createBuffer=window.__cb;QSMP.set(1,new Float32Array(22050).fill(.3),44100,'ok')")
    pg.click('#bPlay');pg.wait_for_timeout(300);pg.click('#bPlay');pg.wait_for_timeout(900)
    chk(pg.evaluate("document.getElementById('bPlay').textContent")!='Listen','relance après réparation')
    # moteur interrompu : on le refait
    pg.click('#bPlay');pg.wait_for_timeout(300)
    pg.evaluate("Object.defineProperty(AudioContext.prototype,'state',{get(){return 'interrupted'},configurable:true})")
    pg.click('#bPlay');pg.wait_for_timeout(1500)
    print('toast:',t[:100])
    chk(True,'lecture demandée avec moteur « interrompu » (sans blocage de la page)')
    pg.evaluate("delete AudioContext.prototype.state")
print('RÉSULTAT',sum(res),'/',len(res),errs[:2])
