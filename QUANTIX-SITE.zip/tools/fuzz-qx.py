# Fuzz d'un fichier .qx : réglages au hasard (boîte, sampler, pads) pendant la lecture, CPU ralenti (serveur local 8765)
from playwright.sync_api import sync_playwright
import random,sys,json
f=sys.argv[1];seed=int(sys.argv[2]) if len(sys.argv)>2 else 1;slow=float(sys.argv[3]) if len(sys.argv)>3 else 4;random.seed(seed)
d=json.load(open(f));errs=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    c=pg.context.new_cdp_session(pg);c.send('Emulation.setCPUThrottlingRate',{'rate':slow})
    pg.add_init_script("setInterval(function(){[].forEach.call(document.querySelectorAll('details'),function(d){if(!d.open)d.open=true;});},80)")
    pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)[:200]))
    pg.on('console',lambda m:errs.append('CON '+m.text[:200]) if m.type=='error' and 'ERR_' not in m.text and 'fonts' not in m.text else None)
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    pg.evaluate("d=>QXIO.open(d)",d);pg.wait_for_timeout(1200)
    pg.evaluate("QFX3.target=QUANTONE.state.strokes.filter(s=>s.layer===4)[0]||null;QFX3.open(4)");pg.wait_for_timeout(500)
    pg.click('#bPlay');pg.wait_for_timeout(800)
    SEL="#inEd input[type=range],#inEd select,#dmD input[type=range],#dmD select,#dmD button,#dmS input[type=range],#dmS select,#dmS button,#smD input[type=range],#smD select"
    for it in range(300):
        pg.evaluate("""(args)=>{const [seed,SEL]=args;const els=[].filter.call(document.querySelectorAll(SEL),e=>e.offsetParent&&!/Import|Enreg|Record|Banque|Bank|Effacer|Clear/.test(e.textContent+(e.id||'')));if(!els.length)return;const e=els[Math.floor(seed*els.length)%els.length];
          if(e.tagName==='BUTTON'){e.click();return;}
          if(e.tagName==='SELECT'){e.selectedIndex=Math.floor(Math.random()*e.options.length);}else{const mn=+e.min,mx=+e.max;e.value=mn+Math.random()*(mx-mn);}
          e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}""",[random.random(),SEL])
        if random.random()<.06:
            pg.click('#bPlay');pg.wait_for_timeout(50);pg.click('#bPlay')
        pg.wait_for_timeout(random.choice([5,15,30,60]))
    txt=pg.evaluate("document.getElementById('bPlay').textContent")
    print('seed',seed,'erreurs',len(errs),'bouton',txt)
    for e in errs[:6]:print(' ',e)
    pg.evaluate("localStorage.getItem('quantone.err')") 
    print('journal',pg.evaluate("localStorage.getItem('quantone.err')"))
    # relance
    if txt!='Listen':pg.click('#bPlay');pg.wait_for_timeout(400)
    pg.click('#bPlay');pg.wait_for_timeout(1500)
    print('après relance:',pg.evaluate("document.getElementById('bPlay').textContent"),'niveau',round(pg.evaluate("QUANTONE.level()"),4))
