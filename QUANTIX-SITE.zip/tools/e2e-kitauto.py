# Automation de kit : pas de rechargement continu des samples (R350) — serveur local 8765
from playwright.sync_api import sync_playwright
import json
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    n=[0]
    pg.on('request',lambda r:n.__setitem__(0,n[0]+(1 if 'pool' in r.url else 0)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1000)
    o=json.load(open('tools/grosse_break.qx'))
    pg.evaluate("o=>QXIO.open(o)",o);pg.wait_for_timeout(800)
    c=pg.context.new_cdp_session(pg);c.send('Emulation.setCPUThrottlingRate',{'rate':4})
    n[0]=0
    pg.click('#bPlay');pg.wait_for_timeout(20000)
    chk(pg.evaluate("document.getElementById('bPlay').textContent")!='Listen','lecture en cours')
    chk(n[0]<=60,'requêtes pool bornées en 20 s (%d)'%n[0])
    pg.click('#bPlay');pg.wait_for_timeout(400);pg.click('#bPlay');pg.wait_for_timeout(1500)
    chk(pg.evaluate("document.getElementById('bPlay').textContent")!='Listen','relance OK')
print('RÉSULTAT',sum(res),'/',len(res),errs[:2])
