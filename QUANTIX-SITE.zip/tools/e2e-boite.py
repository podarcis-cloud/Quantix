# La boîte à rythmes se tait quand on efface tous les traits Rythmes (R368)
from playwright.sync_api import sync_playwright
res=[];er=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
D="QFX3.score().filter(e=>e.kind===4).length"
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1300)
    pg.evaluate("(()=>{const st=QUANTONE.state,w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));st.strokes=[{layer:0,pts:w(40,(t,i)=>[.1+.5*t,.5+.2*Math.sin(t*6.28),i*30])},{layer:2,pts:w(30,(t,i)=>[.3+.5*t,.65+.1*Math.sin(t*5+1),i*30])},{layer:4,pts:w(40,(t,i)=>[.02+.96*t,.885+.04*Math.sin(t*12.6+.4),i*4.5])}];})()")
    chk(pg.evaluate(D)>20,'départ : la boîte joue avec son trait Rythmes (%d événements)'%pg.evaluate(D))
    pg.click('#bPlay');pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=st.strokes.filter(s=>s.layer!==4);})()")
    pg.evaluate("document.getElementById('bUndo')&&0")
    # effacer pendant la lecture : on passe par changed() comme la gomme
    pg.evaluate("QFX3.load(QFX3.preset())") if False else None
    pg.wait_for_timeout(300)
    n=pg.evaluate(D);chk(n==0,'trait Rythmes effacé : plus aucun événement de batterie (%d)'%n)
    pg.click('#bPlay');pg.wait_for_timeout(300)
    # tout effacer : la lecture refuse (rien à jouer)
    pg.evaluate("QUANTONE.state.strokes=[]");pg.wait_for_timeout(100)
    chk(pg.evaluate("QUANTONE.empty()"),'plus aucun trait : la page est considérée vide (pas de boîte fantôme)')
    # le motif est conservé et revient si on reprogramme un pas
    chk(pg.evaluate("QDM.get().rows.some(r=>r.on.some(Boolean))"),'le motif reste mémorisé dans la boîte')
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(300);pg.click('#dmP button[data-s="3"]');pg.wait_for_timeout(300)
    n=pg.evaluate(D);chk(n>0,'reprogrammer un pas réarme la boîte autonome (%d événements)'%n)
    # un pattern enregistré avec un trait Rythmes garde son lien après rechargement
    pg.reload();pg.wait_for_timeout(1300)
    pg.evaluate("(()=>{const st=QUANTONE.state,w=(n,f)=>Array.from({length:n+1},(_,i)=>f(i/n,i));st.strokes=[{layer:0,pts:w(40,(t,i)=>[.1+.5*t,.5+.2*Math.sin(t*6.28),i*30])},{layer:2,pts:w(30,(t,i)=>[.3+.5*t,.65+.1*Math.sin(t*5+1),i*30])},{layer:4,pts:w(40,(t,i)=>[.02+.96*t,.885+.04*Math.sin(t*12.6+.4),i*4.5])}];})()")
    p=pg.evaluate("QFX3.preset()");pg.evaluate("(p)=>{QFX3.load(p);const st=QUANTONE.state;st.strokes=st.strokes.filter(s=>s.layer!==4);}",p)
    chk(pg.evaluate(D)==0,'après rechargement du pattern, effacer le trait Rythmes coupe la batterie')
    chk(not er,'aucune erreur %s'%er[:1])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
