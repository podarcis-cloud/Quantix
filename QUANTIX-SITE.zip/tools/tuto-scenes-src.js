/* tuto-scenes-src.js (R141) — SCÈNES DES FICHES DU DIDACTICIEL, en données.
   Chaque fiche d'élément physique est une petite expérience jouée par le VRAI moteur : on décrit la scène ici
   (repère de la vignette 232 × 104, bille de rayon 7,5), `node tools/tutoscenes.js` la simule et écrit
   assets/js/tuto-scenes.js (géométrie + trajectoire). Le didacticiel la rejoue toujours de la même façon :
   1) le doigt trace le trait du joueur, 2) on lâche la bille, 3) la bille suit la trajectoire calculée, 4) pause.
   Champs : w [[x1,y1,x2,y2,mat]], cv [{pts,m,pass}], nd [[x,y,w,h]], wind/grav [[x,y,w,h,ax,ay]], mag [[x,y,r,f]],
   port [[ax,ay,bx,by]], mov [{seg,amp,spd,ax,ay,v}], ball [x,y], stroke {pts,mat} (geste du joueur), cup [x,y,w,côté]. */
module.exports={
 nd:   {nd:[[96,0,52,64]],ball:[20,14],stroke:{pts:[[12,30],[90,54],[150,66],[200,74]],mat:0},cup:[176,100,52,'R']},
 spike:{w:[[0,102,232,102,2]],ball:[24,10],stroke:{pts:[[10,28],[120,60]],mat:0},cup:[150,100,70,'R']},
 bounce:{w:[[18,86,78,98,1]],ball:[36,40],stroke:null,cup:[118,100,90,'B'],frames:150},
 boost:{w:[[16,60,120,60,3]],ball:[30,30],stroke:null,cup:[150,100,76,'B']},
 ice:  {w:[[8,30,140,62,4]],ball:[20,14],stroke:null,cup:[164,100,60,'R']},
 tunnel:{cv:[{pts:[[0,60],[116,60],[232,60]],m:0,pass:3.4}],ball:[120,0],stroke:null,cup:[86,100,70,'B']},
 wind: {wind:[[70,0,110,104,0.42,-0.3]],w:[[8,40,62,52,0]],ball:[18,24],stroke:null,cup:[176,100,52,'R'],frames:160},
 grav: {grav:[[84,0,70,104,0,-0.5]],w:[[6,38,84,52,0]],ball:[16,20],stroke:null,cup:[168,100,56,'R'],frames:190},
 mag:  {mag:[[156,80,90,1.0]],ball:[100,6],stroke:null,cup:[96,100,132,'B'],frames:160},
 port: {port:[[70,66,178,18]],w:[[10,40,46,56,0]],ball:[18,20],stroke:null,cup:[160,100,64,'R']},
 mov:  {mov:[{seg:[70,74,140,74],amp:40,spd:0.05,ax:1,ay:0,v:1,ph:-3.57}],w:[[6,50,60,64,0]],ball:[14,36],stroke:null,cup:[176,100,52,'R'],frames:180}
};
