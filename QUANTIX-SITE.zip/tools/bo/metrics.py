import sys,subprocess,numpy as np
def load(f,ss=6,t=40):
    d=np.frombuffer(subprocess.run(['ffmpeg','-loglevel','error','-ss',str(ss),'-t',str(t),'-i',f,'-ac','1','-ar','22050','-f','s16le','-'],capture_output=True).stdout,'<i2').astype(float)/32768;return d
def met(f):
    d=load(f);sr=22050
    F=np.abs(np.fft.rfft(d[:sr*30]*np.hanning(sr*30)))**2;fr=np.fft.rfftfreq(sr*30,1/sr)
    tot=F.sum()+1e-12;hf=F[fr>4000].sum()/tot;mid=F[(fr>500)&(fr<4000)].sum()/tot;lo=F[fr<200].sum()/tot;cen=(F*fr).sum()/tot
    hop=int(.02*sr);e=np.array([np.sqrt((d[i:i+hop]**2).mean()) for i in range(0,len(d)-hop,hop)]);fl=np.maximum(0,np.diff(np.log(e+1e-5)));ons=(fl>.9).sum()/(len(d)/sr)
    rms=20*np.log10(np.sqrt((d**2).mean())+1e-9);crest=20*np.log10(abs(d).max()/(np.sqrt((d**2).mean())+1e-9))
    return dict(rms=round(rms,1),hf4k=round(hf,3),mid=round(mid,2),lo=round(lo,2),cen=int(cen),onsets_s=round(ons,1),crest=round(crest,1))
if __name__=='__main__':
    for f in sys.argv[1:]:print(f.split('/')[-1],met(f))
