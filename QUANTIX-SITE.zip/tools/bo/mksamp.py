import numpy as np,json,base64
from scipy.signal import butter,lfilter,sosfilt
SR=48000;rng=np.random.default_rng(811)
def t(n):return np.arange(int(n*SR))/SR
def env(x,a,d):return np.minimum(1,x/a)*np.exp(-x/d)
def lp(x,f,o=4):return sosfilt(butter(o,min(.95,f/(SR/2)),'low',output='sos'),x)
def hp(x,f,o=2):return sosfilt(butter(o,min(.95,f/(SR/2)),'high',output='sos'),x)
def bp(x,f,q=2,o=2):
    w=f/(SR/2);return sosfilt(butter(o,[max(1e-3,w*(1-1/(2*q))),min(.98,w*(1+1/(2*q)))],'band',output='sos'),x)
def noise(n):return rng.standard_normal(int(n*SR))
def add(y,i,x):
    i=int(i);m=min(len(x),len(y)-i)
    if m>0 and i>=0:y[i:i+m]+=x[:m]
def modal(dur,fs,ds,gs,a=.001):
    x=t(dur);return sum(g*np.sin(2*np.pi*f*x)*env(x,a,d) for f,d,g in zip(fs,ds,gs))
def ks(f,dur,damp=.996,bright=.5):
    n=int(SR/f);buf=rng.uniform(-1,1,n)*1;buf=lp(buf,3500+bright*2000,2) if False else buf;out=np.zeros(int(dur*SR));
    for i in range(len(out)):
        out[i]=buf[i%n];buf[i%n]=damp*.5*(buf[i%n]+buf[(i+1)%n])
    return out
def norm(y,pk=.8):return y/(abs(y).max()+1e-9)*pk
def fit4(y):
    o=np.zeros(int(4*SR));m=min(len(o),len(y));o[:m]=y[:m];k=int(.01*SR);o[:k]*=np.linspace(0,1,k);o[-k:]*=np.linspace(1,0,k);return o
def i16(y):return base64.b64encode((np.clip(y,-1,1)*32767).astype('<i2').tobytes()).decode()
# -------- 1) assagir les mondes 1..7 : passe-bas 5,2 kHz sur les sons à forte énergie aiguë
for W in range(1,8):
    S=json.load(open(f'/tmp/qx/w45/samples{W}.json'));out=[]
    for s in S:
        x=np.frombuffer(base64.b64decode(s['pcm']),'<i2').astype(float)/32768
        F=np.abs(np.fft.rfft(x));fr=np.fft.rfftfreq(len(x),1/s['sr']);hf=(F[fr>5000]**2).sum()/(F**2).sum()
        if hf>.04:x=lp(x,5200 if hf>.2 else 6500,4);x=norm(x,.8)
        s=dict(s);s['pcm']=i16(x);out.append(s)
    json.dump(out,open(f'samples{W}.json','w'))
# -------- 2) nouveaux jeux thématiques : mondes 8..11 (4 s, ≤ 6 kHz)
def W8():
    S=[]
    x=t(4);y=sum(np.sin(2*np.pi*f*x)*g for f,g in((60,1),(120,.5),(180,.3),(240,.15)))*(.5+.5*np.sin(2*np.pi*.5*x));y+=lp(noise(4),400)*.08
    for k in range(8):add(y,k*.5*SR,modal(.25,[60,120],[.08,.05],[.6,.3])*.8)
    S.append(('Bobine',lp(y,1500)))
    y=np.zeros(4*SR.__int__())
    for k in range(4):
        x=t(.9);f1=200+200*(x/.9);f2=800-400*(x/.9);g=np.sin(2*np.pi*np.cumsum(f1)/SR)+np.sin(2*np.pi*np.cumsum(f2)/SR)
        add(y,k*SR,g*np.minimum(1,x/.02)*np.exp(-x/.7)*.5);add(y,(k+.9)*SR,modal(.15,[300,420],[.05,.03],[1,.6]))
    S.append(('Attraction',lp(y,4500)))
    y=np.zeros(4*SR.__int__())
    for k in range(4):
        x=t(.9);f1=400-200*(x/.9);f2=400+400*(x/.9);g=np.sin(2*np.pi*np.cumsum(f1)/SR)+np.sin(2*np.pi*np.cumsum(f2)/SR)
        add(y,(k+.05)*SR,modal(.2,[90],[.05],[1.4]));add(y,(k+.1)*SR,g*np.minimum(1,x/.02)*np.exp(-x/.5)*.4)
    S.append(('Répulsion',lp(y,4500)))
    y=np.zeros(4*SR.__int__())
    for k in range(60):
        r=rng.uniform(0,3.8);add(y,r*SR,bp(noise(.03),rng.uniform(600,2400),3)*env(t(.03),.001,.01)*rng.uniform(.3,1)*8)
    S.append(('Limaille',lp(y,5000)))
    y=np.zeros(4*SR.__int__())
    for k in range(8):add(y,k*.5*SR,modal(.45,[180,270,455],[.18,.1,.05],[1,.5,.2]))
    S.append(('Aimant',y))
    x=t(4);S.append(('Champ',(np.sin(2*np.pi*110*x)+np.sin(2*np.pi*111.5*x)+.6*np.sin(2*np.pi*165*x)+.3*np.sin(2*np.pi*220.7*x))*.3*(.7+.3*np.sin(2*np.pi*.25*x))))
    y=np.zeros(4*SR.__int__())
    for k in range(5):
        x=t(.7);add(y,k*.8*SR,np.sin(2*np.pi*(700+60*np.exp(-x/.1)*np.cos(2*np.pi*9*x))*x)*env(x,.002,.25)*.6)
    S.append(('Aiguille',y))
    y=np.zeros(4*SR.__int__())
    for k in range(8):
        add(y,k*.5*SR,modal(.2,[150,230],[.07,.04],[1,.5]));add(y,(k*.5+.12)*SR,modal(.1,[620,910],[.03,.02],[.5,.3]))
    S.append(('Dipôle',y))
    return S
def W9():
    S=[]
    y=np.zeros(4*SR.__int__())
    for k in range(40):
        r=rng.uniform(0,3.8)*(rng.uniform()**.6);add(y,r*SR,lp(noise(.04),rng.uniform(900,2500))*env(t(.04),.001,.015)*rng.uniform(.4,1)*6)
    S.append(('Fissure',y))
    y=np.zeros(4*SR.__int__())
    for k in range(18):
        r=rng.uniform(0,3.6);f=rng.uniform(200,800);add(y,r*SR,modal(.3,[f,f*1.6,f*2.3],[.06,.04,.025],[1,.5,.3]))
    S.append(('Éboulis',y))
    x=t(4);S.append(('Glissement',lp(noise(4),260,2)*3*(.5+.5*np.sin(2*np.pi*.37*x))))
    y=np.zeros(4*SR.__int__())
    for k in range(4):add(y,k*SR,modal(.9,[42,63],[.4,.25],[1.2,.5]))
    S.append(('Tectonique',y))
    y=np.zeros(4*SR.__int__())
    for k in range(36):
        r=rng.uniform(0,3.8);add(y,r*SR,bp(noise(.05),rng.uniform(800,2800),2)*env(t(.05),.001,.02)*rng.uniform(.3,1)*7)
    S.append(('Gravier',y))
    x=t(4);S.append(('Béance',bp(noise(4),220,14)*6*(.5+.5*np.sin(2*np.pi*.3*x))+bp(noise(4),520,10)*3))
    y=np.zeros(4*SR.__int__())
    for r in (0,.31,.9,1.3,1.4,2.2,3.0):add(y,r*SR,modal(.25,[420,1100,1700],[.03,.02,.012],[1,.6,.3]))
    S.append(('Craquement',y))
    y=np.zeros(4*SR.__int__())
    for r in (0,1.6,2.9):
        h=modal(.5,[300,520],[.1,.07],[1,.6]);add(y,r*SR,h)
    tail=lp(noise(4),900,2)*np.exp(-t(4)/.7)*.06;S.append(('Écho de roche',y+np.convolve(y,tail[:int(.6*SR)],'same')*.3))
    return S
def W10():
    S=[]
    y=np.zeros(4*SR.__int__())
    for k,f in enumerate((82,82,110,82)):add(y,k*SR,ks(f,.95,.9985))
    S.append(('Corde grave',lp(y,2500)))
    y=np.zeros(4*SR.__int__())
    for k in range(4):add(y,k*SR,ks(220+k,.95,.9985)+ks(221.5+k,.95,.9985)*.7)
    S.append(('Fil tendu',lp(y,3500)))
    x=t(4);b=np.zeros(len(x))
    for f in (147,148.2):b+=(2*((f*x)%1)-1)*.5
    S.append(('Archet',bp(b,440,3)*5*(.4+.6*np.sin(np.pi*x/4)**2)))
    y=np.zeros(4*SR.__int__())
    for k,f in enumerate((660,880,660,990)):add(y,k*SR,ks(f,.9,.997)*.6)
    S.append(('Harmonique',lp(y,4500)))
    y=np.zeros(4*SR.__int__())
    for k in range(4):add(y,k*SR,ks(150*2**(k*.12),.95,.9985))
    S.append(('Tension',lp(y,3000)))
    x=t(4);S.append(('Sympathique',sum(np.sin(2*np.pi*f*x)*np.exp(-x/2.5)*g for f,g in((196,1),(196.8,.8),(294,.5),(392.5,.4)))*.4*(0.6+.4*np.sin(2*np.pi*.4*x))))
    y=np.zeros(4*SR.__int__())
    for k,f in enumerate((330,392,294,440,262,349,392,330)):add(y,k*.5*SR,ks(f,.45,.996)*.9)
    S.append(('Pizz',lp(y,4000)))
    y=np.zeros(4*SR.__int__())
    for k in range(14):
        f=[262,294,330,392,440,524,588][rng.integers(0,7)];add(y,rng.uniform(0,3.5)*SR,ks(f,.35,.995)*.6)
    S.append(('Toile',lp(y,4000)))
    return S
def W11():
    S=[]
    x=t(4);S.append(('Sub vide',(np.sin(2*np.pi*55*x)*(.7+.3*np.sin(2*np.pi*.2*x))+.2*np.sin(2*np.pi*110*x))*.6+lp(noise(4),300)*.05))
    x=t(4);S.append(('Superposition',(np.sin(2*np.pi*200*x)+np.sin(2*np.pi*203*x)+.6*np.sin(2*np.pi*301*x)+.4*np.sin(2*np.pi*299*x))*.25))
    y=np.zeros(4*SR.__int__())
    for k in range(3):
        x=t(1.2);add(y,k*1.3*SR,lp(noise(1.2),1800,2)*np.exp(-x/.35)*2+np.pad(modal(.5,[70],[.15],[1.2]),(0,len(x)-int(.5*SR))))
    S.append(('Effondrement',lp(y,2500)))
    y=np.zeros(4*SR.__int__())
    for k in range(5):add(y,k*.8*SR,np.pad(bp(noise(.01),2200,2)*3,(0,int(.6*SR)-int(.01*SR)))+modal(.6,[1200,1810],[.15,.08],[.6,.3]))
    S.append(('Mesure',lp(y,5000)))
    y=np.zeros(4*SR.__int__())
    for k in range(22):
        f=rng.uniform(150,650);add(y,rng.uniform(0,3.7)*SR,np.sin(2*np.pi*f*t(.12))*env(t(.12),.004,.04)*rng.uniform(.2,.8))
    S.append(('Incertitude',y))
    y=np.zeros(4*SR.__int__())
    for k in range(5):
        p=modal(.3,[330,495],[.08,.05],[1,.5]);add(y,k*.8*SR,p);add(y,(k*.8+.37)*SR,p*.8)
    S.append(('Intrication',y))
    x=t(4);f=100+800*(x/4)**2;S.append(('Tunnel',np.sin(2*np.pi*np.cumsum(f)/SR)*.5*(1-np.exp(-x/.3))*(.5+.5*np.sin(2*np.pi*1.5*x))))
    x=t(4);y=lp(noise(4),700,2)*3*(np.sin(np.pi*x/4)**2)
    for k in range(7):add(y,rng.uniform(0,3.8)*SR,np.sin(2*np.pi*rng.uniform(200,500)*t(.15))*env(t(.15),.01,.05)*.4)
    S.append(('Fond diffus',y))
    return S
for W,fn in ((8,W8),(9,W9),(10,W10),(11,W11)):
    S=fn();out=[]
    for k,(nm,y) in enumerate(S):
        y=fit4(np.asarray(y,float));y=hp(y,35,2);y=lp(y,5600,4);y=norm(y,.8)
        out.append({'slot':k+1,'name':nm,'sr':SR,'pcm':i16(y)})
    json.dump(out,open(f'samples{W}.json','w'));print(W,[o['name'] for o in out])
