import json,copy,sys,random,base64,math
import numpy as np
W=int(sys.argv[1]);LVL=sys.argv[2];lv=int(LVL[1:])
rnd=random.Random(W*1009+lv*31)
rw=random.Random(W*77)            # tirages propres au monde (identiques à tous les niveaux)
B=json.load(open('/mnt/user-data/attachments/c1659ac1-3b70-51cf-9350-315d05ece71d/3b3c9f31-quantone-20261018-0256.qx'))
S=json.load(open('/tmp/qx/w46/samples%d.json'%W))
PRE=json.load(open('/tmp/qx/w45/inst.json'))
J=copy.deepcopy(B);P=J['preset']
_T={1:(54,64,76),2:(60,70,80),3:(62,76,90),4:(52,64,78),5:(60,74,92),6:(66,82,104),7:(46,56,70),8:(58,70,88),9:(50,62,80),10:(60,72,94),11:(56,68,90)}[W]
tempo=round(_T[0]+(_T[1]-_T[0])*(lv-1)/5) if lv<=6 else round(_T[1]+(_T[2]-_T[1])*(lv-6)/6)
P['world']=min(W-1,3)
P['scale']={1:'pM',2:'dor',3:'dor',4:'q',5:'pm',6:'pM',7:'dor',8:'dor',9:'q',10:'pM',11:'pm'}[W]
P['root']={1:5,2:9,3:2,4:4,5:2,6:7,7:9,8:4,9:11,10:0,11:2}[W]
P['grid']=64
# ---------- recettes : une cuisine par monde ----------
# order = ordre d'arrivée des voix de la boîte ; len = longueur du motif ; stut = bégaiements (tournent selon le niveau) ; fillfn = relances de caisse claire
R={
1:dict(len=16,order=['perc','kick','hat','snare','ghost','rim'],stut=[28,29,1],fill=[27,26],blen=3,swing=.10,
  pat=dict(kick=[0,10],snare=[12],ghost=[3,7,13],hat=[2,6,10,14],perc=[5,9,15],rim=[4,11]),shift=dict(kick=1,perc=3,ghost=2,hat=0,snare=0,rim=3),
  inst=[(0,'Marimba',dict(vol=.55,dec=.35),37,[4,19,30],[.6,.45,.7]),(1,'Contrebasse',dict(vol=.5,cut=380),32,[0,13,25],[.55,.5,.6]),(6,'Nylon',dict(vol=.5),53,[9,31],[.5,.6])],pool=0),
2:dict(len=16,order=['kick','snare','hat','perc','ghost','tom'],stut=[26,31,29],fill=[31,26],blen=4,swing=.04,
  pat=dict(kick=[0,7,10],snare=[8,14],hat=[2,4,6,10,12],perc=[3,11,15],ghost=[13],tom=[5,9]),shift=dict(kick=0,snare=0,perc=2,hat=1,ghost=3,tom=2),
  inst=[(1,'Sub 808',dict(vol=.6,drop=.4),32,[0,10,21],[.55,.5,.6]),(0,'Kalimba',dict(vol=.5),43,[6,22],[.55,.4]),(5,'Impact',dict(vol=.45,tone=1800,len=.5),59,[14],[.5])],pool=1),
3:dict(len=12,order=['hat','kick','rim','snare','perc','ghost'],stut=[27,13,28],fill=[27,31],blen=2,swing=0,
  pat=dict(kick=[0,4,8],hat=[0,3,6,9,10],rim=[2,6,11],snare=[6],perc=[1,5,11],ghost=[8,10]),shift=dict(kick=0,hat=1,rim=2,snare=0,perc=1,ghost=1),
  inst=[(6,'Acier',dict(vol=.5),36,[3,17,26],[.5,.6,.45]),(1,'Pluck',dict(vol=.45),24,[0,9,15],[.5,.55,.45]),(0,'Kalimba',dict(vol=.45),48,[11,30],[.6,.5])],pool=2),
4:dict(len=12,order=['hat','perc','snare','kick','rim','ghost'],stut=[30,28,29],fill=[30,27],blen=3,swing=.14,
  pat=dict(hat=[2,5,8,11],perc=[4,9],snare=[7],kick=[0],rim=[3,10],ghost=[1,6]),shift=dict(hat=1,perc=2,snare=1,kick=0,rim=2,ghost=3),
  inst=[(0,'Verre',dict(vol=.5,dec=1.2),47,[5,26],[.65,.5]),(8,'Verre mouvant',dict(vol=.35),61,[14],[.5]),(7,'Cristal',dict(vol=.3),71,[30],[.55])],pool=3),
5:dict(len=16,order=['perc','kick','hat','snare','tom','rim'],stut=[29,3,28],fill=[29,27],blen=5,swing=.06,
  pat=dict(perc=[0,3,6,9,12],kick=[0,11],hat=[4,7,15],snare=[10],tom=[2,13],rim=[5,8]),shift=dict(perc=1,kick=2,hat=3,snare=1,tom=2,rim=1),
  inst=[(0,'Flûte',dict(vol=.4,vib=.3),53,[7,29],[.55,.45]),(1,'Ronde',dict(vol=.45,cut=360),40,[0,17],[.5,.55]),(8,'Souffle',dict(vol=.25),67,[20],[.5])],pool=4),
6:dict(len=16,order=['hat','kick','snare','perc','rim','ghost'],stut=[31,4,27],fill=[31,26],blen=3,swing=0,
  pat=dict(hat=[0,2,4,6,8,10,12,14],kick=[0,6,11],snare=[4,12],perc=[1,5,9,13,15],rim=[3,7],ghost=[10,14]),shift=dict(hat=0,kick=1,snare=0,perc=2,rim=1,ghost=1),
  inst=[(0,'Marimba',dict(vol=.5,dec=.25,ratio=5.4),28,[2,13,22],[.6,.5,.55]),(1,'Pluck',dict(vol=.4),56,[0,17],[.5,.6]),(6,'Koto',dict(vol=.45),44,[6,27],[.5,.6])],pool=5),
7:dict(len=16,order=['kick','tom','snare','hat','perc','ghost'],stut=[30,26,28],fill=[30,28],blen=4,swing=.05,
  pat=dict(kick=[0,8],tom=[10,13,15],snare=[12],hat=[4,6,14],perc=[2,11],ghost=[9,15]),shift=dict(kick=0,tom=1,snare=0,hat=2,perc=1,ghost=2),
  inst=[(1,'Sub 808',dict(vol=.6,drop=.7,cut=240),48,[0,19,33],[.5,.45,.6]),(8,'Cloche douce',dict(vol=.4,oct=-1),61,[10,38],[.5,.6]),(7,'Marée',dict(vol=.3),71,[24],[.5])],pool=6),
8:dict(len=16,order=['kick','rim','snare','hat','perc','ghost'],stut=[27,4,28],fill=[27,29],blen=3,swing=.07,
  pat=dict(kick=[0,6],rim=[4,5,12,13],snare=[8,9],hat=[2,3,10,11],perc=[7,15],ghost=[1,14]),shift=dict(kick=1,rim=2,snare=1,hat=2,perc=3,ghost=1),
  inst=[(8,'Anche',dict(vol=.4),37,[3,21],[.55,.5]),(6,'Acier',dict(vol=.45),53,[11,30],[.6,.5]),(1,'Analogique',dict(vol=.4,cut=300),32,[0,14],[.5,.55])],pool=7),
9:dict(len=16,order=['kick','perc','hat','snare','ghost','tom'],stut=[29,31,30],fill=[31,29],blen=6,swing=.03,
  pat=dict(kick=[0],perc=[3],hat=[7,9],snare=[11,12,13,14,15],ghost=[5],tom=[8]),shift=dict(kick=0,perc=4,hat=1,snare=0,ghost=3,tom=2),
  inst=[(5,'Impact',dict(vol=.5,tone=1500,len=1.4),59,[6,40],[.5,.55]),(1,'Sub 808',dict(vol=.55,drop=.5),43,[0,24],[.5,.55]),(0,'Verre',dict(vol=.35,oct=-1),67,[18],[.5])],pool=0),
10:dict(len=16,order=['perc','kick','snare','hat','rim','ghost'],stut=[27,14,28],fill=[27,30],blen=5,swing=.05,
  pat=dict(perc=[0,1,2,4,7,12],kick=[0,8],snare=[6,14],hat=[3,5,8,13],rim=[9,15],ghost=[10,11]),shift=dict(perc=1,kick=0,snare=2,hat=3,rim=1,ghost=1),
  inst=[(6,'Harpe',dict(vol=.55),34,[2,11,20,31],[.6,.5,.7,.45]),(6,'Nylon',dict(vol=.4),47,[8,26],[.4,.55]),(1,'Contrebasse',dict(vol=.45),64,[0,29],[.5,.6])],pool=1),
11:dict(len=16,order=['perc','snare','kick','hat','rim','ghost'],stut=[29,13,26],fill=[29,31],blen=4,swing=.02,
  pat=dict(perc=[2,3,5,7,11,13],snare=[4],kick=[0,9],hat=[6,10,15],rim=[1,12],ghost=[8,14]),shift=dict(perc=1,snare=2,kick=1,hat=3,rim=2,ghost=1),
  inst=[(7,'Écume',dict(vol=.35),43,[5,29],[.5,.45]),(8,'Voyelle',dict(vol=.3),59,[17],[.55]),(1,'Ronde',dict(vol=.4,cut=300),38,[0,19],[.5,.6])],pool=2),
}[W]
P['k'].update(tempo=tempo,echo=.36,rev=.58,breath=.35,clar=.38,drone=.05 if lv==1 else .07,grain=.08,swing=R['swing'])
P['eq']=dict(hp=1,lo=-6,mid=0,hi=-6,out=-2)
P['ef'].update(div=.75,dfb=.38,rsize=3.4,ftype='lowpass',fq=1.0)
def inst(i,name,**kw):
    p=dict(PRE[i][name]);p.update(kw);P['inst'][i]['preset']=name;P['inst'][i]['mod']=True;P['inst'][i]['p']=p
def sampler(slot,**kw):
    p={'slot':slot,'mode':'tranche','root':60,'slices':8,'start':0,'end':1,'fin':.01,'fout':.04,'loop':0,'lps':0,'lpe':1,'back':0,'tune':0,'speed':1,'keep':0,'hp':120,'cut':5200,'res':.5,'bits':16,'drive':0,'comp':.1,'chor':0,'pan':0,'vol':.55,'rev':.5,'dly':.3}
    p.update(kw);return p
strokes=[];_n=[0]
def micro(l,step,loop,y,ip=None):
    x=(step+.35)/loop;st={'l':l,'p':[[round(x,4),round(y,3)],[round(x+.3/loop,4),round(y,3)]]}
    if ip:st['ip']=ip
    return st
CALM=max(0,lv-8)
def smp(slot,loop,steps,ys,vol=.44,fn=0,pan=0,**kw):
    _n[0]+=1
    if CALM:
        vol=vol*(1-.11*CALM)
        if CALM>=2 and len(steps)>1:
            k=max(1,len(steps)-(CALM-1) if len(steps)>2 else 1);steps=steps[:k];ys=ys[:k]
    for i,(s,y) in enumerate(zip(steps,ys)):
        ip={'preset':'Tranches','mod':True,'p':sampler(slot,vol=vol,pan=pan,**kw),'fn':fn,'lp':loop,'_id':'s%d_%d'%(slot,_n[0])}
        strokes.append(micro(9,s,loop,y,ip))
def inote(l,loop,steps,ys,fn=None):
    for s,y in zip(steps,ys):
        st=micro(l,s,loop,y);st['ip']={'preset':P['inst'][l]['preset'],'mod':False,'p':P['inst'][l]['p'],'fn':0,'lp':loop,'_id':'n%d_%d_%d'%(l,loop,s)};strokes.append(st)
# ---------- choix des voix de batterie dans les samples du monde ----------
def decode(s):return np.frombuffer(base64.b64decode(s['pcm']),'<i2').astype(float)/32768
def candidates():
    C=[]
    for si,s in enumerate(S):
        x=decode(s);sr=s['sr'];n=len(x);hop=int(.01*sr)
        e=np.array([np.sqrt((x[i:i+hop]**2).mean()) for i in range(0,n-hop,hop)]);
        if e.max()<1e-4:continue
        pk=[i for i in range(1,len(e)-1) if e[i]>=e[i-1] and e[i]>e[i+1] and e[i]>.25*e.max()]
        last=-99
        for i in pk:
            if i-last<12:continue
            last=i;j=i
            while j<len(e)-1 and e[j]>.2*e[i] and (j-i)<28:j+=1
            a=max(0,(i-1)*hop);b=min(n,max((j+1)*hop,a+int(.07*sr)));seg=x[a:b]
            if len(seg)<hop*3:continue
            F=np.abs(np.fft.rfft(seg*np.hanning(len(seg))));fr=np.fft.rfftfreq(len(seg),1/sr);cen=(F*fr).sum()/(F.sum()+1e-9)
            C.append(dict(slot=s['slot'],a=a/n,b=b/n,cen=cen,str=e[i]/e.max(),dur=(b-a)/sr))
    return C
CAND=candidates()
TARG=dict(kick=140,tom=320,perc=900,ghost=1300,snare=1800,rim=2600,hat=3600)
ROLEPICK={}
def pick(role):
    used={(r['slot'],round(r['a'],3)) for r in ROLEPICK.values()}
    sc=[]
    for c in CAND:
        if (c['slot'],round(c['a'],3)) in used:continue
        d=abs(math.log((c['cen']+30)/TARG[role]))+(.0 if c['str']>.4 else .6)+(.5 if (role=='hat' and c['dur']>.15) else 0)+(.4 if (role=='kick' and c['dur']<.05) else 0)
        sc.append((d,c))
    sc.sort(key=lambda z:z[0])
    return sc[min(len(sc)-1,rw.randint(0,1))][1] if sc else None
for role in ['kick','snare','hat','perc','rim','tom','ghost']:
    c=pick(role)
    if c:ROLEPICK[role]=c
ROWOF=dict(kick=0,snare=1,ghost=2,hat=3,perc=5,rim=6,tom=8)
# ---------- textures (arrivée un à un 1→6, échange 7→12) ----------
Ltab={
1:[(1,61,[5,38],[.3,.7],-.35),(2,53,[19,46],[.55,.3],.3),(3,47,[11,33],[.3,.7],.1),(4,59,[27],[.4],-.2),(5,43,[5,30],[.6,.4],.45),(6,67,[41],[.5],-.1),(7,37,[3,22],[.4,.6],.25),(8,29,[2,9,17],[.5,.3,.7],-.3)],
2:[(1,41,[3,22],[.3,.7],-.4),(2,37,[9,26],[.55,.3],.35),(3,31,[5,19],[.2,.8],.1),(5,59,[27],[.4],-.2),(4,29,[2,14,21],[.6,.3,.8],.5),(6,53,[41],[.5],-.1),(7,47,[15],[.5],.2),(8,23,[4,11,17],[.3,.5,.7],.15)],
3:[(1,32,[3,19],[.3,.7],-.4),(2,24,[5,15],[.55,.3],.35),(3,40,[11,29],[.3,.7],.1),(4,48,[7],[.4],-.2),(5,36,[2,20],[.6,.4],.5),(6,28,[13],[.5],-.1),(7,44,[9,31],[.5,.7],.25),(8,20,[3,10,15],[.4,.6,.3],-.3)],
4:[(1,61,[7,38],[.3,.7],-.4),(2,53,[19,44],[.55,.3],.35),(3,47,[11,33],[.2,.8],.1),(4,59,[27],[.4],-.2),(5,43,[5,30],[.6,.4],.5),(6,64,[41],[.5],-.1),(7,67,[3,50],[.3,.6],.3),(8,29,[2,9,17],[.5,.3,.7],-.3)],
5:[(1,61,[2,30],[.4,.6],-.3),(2,53,[19,47],[.55,.3],.4),(3,47,[11],[.5],.1),(4,41,[5,20,33],[.3,.6,.5],-.4),(5,59,[27],[.4],.2),(6,64,[41,12],[.5,.3],.0),(7,37,[8,22],[.5,.7],.3),(8,31,[3,10,18],[.4,.6,.3],-.2)],
6:[(1,61,[4,36],[.3,.7],-.4),(2,53,[19,44],[.55,.3],.35),(3,47,[11,33],[.2,.8],.2),(4,43,[5,27],[.6,.4],.4),(5,59,[2],[.5],-.2),(6,67,[39,12],[.5,.3],.1),(7,37,[8],[.5],.3),(8,19,[3,10,15],[.4,.6,.3],-.3)],
7:[(1,71,[9,45],[.4,.6],-.3),(2,59,[19],[.5],.3),(3,53,[11,40],[.5,.3],.0),(4,47,[27],[.4],.4),(5,67,[5,33],[.5,.7],-.2),(6,61,[41],[.3],.1),(7,43,[8,22],[.5,.7],.3),(8,37,[3,17],[.4,.6],-.3)],
8:[(1,59,[3,31],[.4,.6],.3),(2,47,[14,40],[.5,.3],-.35),(3,53,[9],[.5],.0),(4,43,[22,6],[.3,.6],.4),(5,67,[17],[.4],-.2),(6,37,[29,10],[.5,.3],.15),(7,61,[5,35],[.5,.7],-.3),(8,31,[2,12,20],[.4,.6,.3],.25)],
9:[(1,71,[12,50],[.4,.6],-.4),(2,57,[25],[.5],.3),(3,49,[7,36],[.3,.7],.1),(4,61,[18],[.4],-.3),(5,43,[4,28],[.6,.4],.45),(6,53,[33],[.5],-.1),(7,67,[9,44],[.5,.7],.2),(8,37,[3,15,26],[.5,.3,.7],-.25)],
10:[(1,47,[6,28],[.3,.7],.35),(2,59,[17,41],[.55,.3],-.3),(3,41,[10],[.5],.1),(4,53,[24,3],[.3,.6],-.4),(5,61,[14],[.4],.25),(6,37,[20,9],[.5,.3],-.15),(7,43,[7,33],[.5,.7],.4),(8,29,[2,11,19],[.4,.6,.3],-.2)],
11:[(1,79,[15,55],[.4,.6],-.3),(2,61,[22],[.5],.3),(3,53,[8,40],[.3,.7],.0),(4,67,[30],[.4],-.4),(5,47,[5,26],[.6,.4],.4),(6,71,[44],[.5],.1),(7,43,[12,34],[.5,.7],-.2),(8,41,[3,19,29],[.4,.6,.3],.3)],
}
L=Ltab[W]
SV=.42                       # volume de base des textures (plus bas qu'avant)
if lv==1:
    for slot,loop,steps,ys,pan in L[:6]:smp(slot,loop,steps[:1 if slot%2 else 2],ys,vol=SV,pan=pan)
    auto={'k:breath':{'on':True,'len':2,'mode':'smo','pts':[[0,.15],[.4,.7],[.7,.25],[.999,.15]]},'ik:2:cut':{'on':True,'len':3,'mode':'smo','pts':[[0,.05],[.5,.4],[.999,.05]]}}
elif lv<=6:
    K=lv
    for slot,loop,steps,ys,pan in L[:min(8,K+3)]:smp(slot,loop,steps[:1] if K<=3 else (steps[:2] if K==4 else steps),ys,vol=SV,pan=pan)
    auto={'k:breath':{'on':True,'len':2,'mode':'smo','pts':[[0,.2],[.4,.7],[.7,.3],[.999,.2]]},'ik:2:cut':{'on':True,'len':3,'mode':'smo','pts':[[0,.08],[.5,.5],[.999,.08]]}}
else:
    JJ=lv-6
    for slot,loop,steps,ys,pan in L:
        if (slot==1 and JJ>=3) or (slot==3 and JJ>=4) or (slot==6 and JJ>=5):continue
        smp(slot,loop,steps,ys,vol=SV,pan=pan)
    auto={'k:breath':{'on':True,'len':R['blen'],'mode':'smo','pts':[[0,.2+.1*JJ/6],[.4,.7],[.7,.3],[.999,.2]]},'ik:2:cut':{'on':True,'len':3,'mode':'smo','pts':[[0,.1],[.5,.5],[.999,.1]]}}
    if JJ>=2:auto['ef:dfb']={'on':True,'len':R['blen']+1,'mode':'smo','pts':[[0,.3],[.5,.6],[.85,.35],[.999,.3]]}
# ---------- notes d'instruments : jeu propre au monde ----------
for k,(i,name,kw,loop,steps,ys) in enumerate(R['inst']):
    inst(i,name,**kw)
    need=[2,4,6][k] if lv<=6 else [2,4,6][k]
    if lv>=need:
        ns=steps if lv<=6 else steps[:max(1,len(steps)-(1 if lv>=10 else 0))]
        inote(i,loop,ns,ys[:len(ns)])
P['ifn']=[0]*12
if lv>=6:P['ifn'][R['inst'][0][0]]=R['stut'][(lv)%len(R['stut'])] if lv>=8 else 0
# ---------- boîte à rythmes : voix prises dans les samples du monde ----------
rows=P['dm']['rows'];LEN=R['len'];P['dm']['len']=LEN
for r_ in rows:r_['on']=[0]*16;r_['mute']=False
def mk(idx):
    r=[0]*16
    for q in idx:
        if q<LEN:r[q]=1
    return r
def hitlist(role,v):
    base=R['pat'][role];sh=R['shift'][role]
    if lv<=6:return base
    out=[(q+sh*(v//2))%LEN for q in base]            # le motif tourne par paliers
    if v>=3:out=out+[(q+3+sh)%LEN for q in base[::2]]    # fantômes
    if lv>=10:out=out[:max(1,len(out)-1-(lv-10))]       # fin de monde : on retire, on n'empile pas
    return sorted(set(out))
act=R['order'][:max(1,lv-2)] if 3<=lv<=6 else (R['order'] if lv>=7 else [])
if lv>=10:act=act[:-1]                                  # une voix de moins en fin de monde
V=max(0,lv-6)
LVLR=dict(kick=.24,snare=.2,ghost=.1,hat=.09,perc=.13,rim=.11,tom=.18)
TUNE=dict(kick=-4,snare=0,ghost=2,hat=0,perc=0,rim=0,tom=-2)
for role in act:
    c=ROLEPICK.get(role)
    if not c:continue
    rr=rows[ROWOF[role]]
    rr.update(on=mk(hitlist(role,V)),smp=c['slot'],sst=round(c['a'],4),sen=round(c['b'],4),rvs=False,tune=TUNE[role]+rw.choice([-1,0,0,1]),dec=1,
              lvl=LVLR[role]*(1-.12*CALM),pan=rw.choice([-.4,-.2,0,.2,.4]) if role not in('kick','snare') else 0,lp=6000 if role!='hat' else 4800,hp=40 if role in('kick','tom') else 180,drv=0.12 if role in('kick','snare') else 0,rv=.1,dl=.08,sw=1,nz=0)
    if role=='snare':
        rr['on'][ (hitlist(role,V) or [0])[0] ]=2
# ---------- relances de caisse claire et cellule rythmique : bégaiements variés ----------
sc=ROLEPICK.get('snare');pc=ROLEPICK.get('perc')
stut=R['stut']
if lv>=5 and sc:
    FL=[32,48,64][ (lv//3)%3 ] if lv<10 else 64                   # relances plus rares en fin de monde
    fn=R['fill'][(lv)%len(R['fill'])]
    steps=[FL-3,FL-2,FL-1] if lv%2 else [FL-4,FL-2,FL-1]
    if lv>=9:steps=steps[1:]
    smp(sc['slot'],FL,steps,[.3,.6,.45][:len(steps)],vol=.34,fn=fn,pan=rw.choice([-.3,.3]),start=round(sc['a'],4),end=round(sc['b'],4),slices=1,cut=4800)
if lv>=6 and pc:
    CL=[10,14,12,18,20,24][W%6]
    fn=stut[(lv+W)%len(stut)]
    stp=[(i*(3+W%3))%CL for i in range(3 if lv<10 else 2)]
    smp(pc['slot'],CL,sorted(set(stp)),[.2,.55,.8][:len(set(stp))],vol=.32,fn=fn,pan=rw.choice([-.35,.35]),start=round(pc['a'],4),end=round(pc['b'],4),slices=2,cut=4800)
# ---------- breaks : coupures de rangs différentes à chaque monde ----------
if lv>=7:
    bl=R['blen']
    lanes={ROWOF['snare']:[[0,1],[.45,1],[.6,0],[.75,1]],ROWOF['kick']:[[0,1],[.7,1],[.78,0],[.9,1]],ROWOF['hat']:[[0,0],[.3,1],[.85,1]],ROWOF['perc']:[[0,1],[.5,0],[.7,1]]}
    keys=list(lanes);rw2=random.Random(W*5+lv)
    for rk in rw2.sample(keys,2):
        pts=[[round(min(.999,p[0]+rw2.uniform(-.08,.08)),3),p[1]] for p in lanes[rk]];pts[0][0]=0
        pts=sorted(pts,key=lambda z:z[0])
        auto['dmu:%d'%rk]={'on':True,'len':bl+rw2.randint(0,2),'mode':'stp','pts':pts}
    if lv>=9:auto['dln']={'on':True,'len':bl+1,'mode':'stp','pts':[[0,1],[.55,.5],[.8,1]]}
P['auto']=auto;P['strokes']=strokes
if CALM:
    for r_ in rows:r_['lvl']=r_.get('lvl',.3)
J['info'].update(world=min(W-1,3),scale=P['scale'],root=P['root'],tempo=tempo,grid=64,strokes=len(strokes),samples=len(S))
J['samples']=S;J['date']='2026-10-28T20:00:00.000Z'
json.dump(J,open('/tmp/qx/w46/q%d-n%d.qx'%(W,lv),'w'))
print(W,lv,'tempo',tempo,'strokes',len(strokes),{r:(c['slot'],round(c['cen'])) for r,c in ROLEPICK.items()})
