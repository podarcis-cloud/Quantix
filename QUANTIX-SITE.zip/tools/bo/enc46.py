import subprocess,re,sys
T={1:-43,2:-41.5,3:-39.5,4:-37,5:-35,6:-33.5,7:-32.5,8:-32,9:-31.5,10:-32,11:-32.5,12:-33.5}
def rms(f):
    r=subprocess.run(['ffmpeg','-ss','6','-t','36','-i',f,'-af','astats=metadata=1:reset=0','-f','null','-'],capture_output=True,text=True).stderr
    m=re.findall(r'RMS level dB: (-?[\d.]+)',r);return float(m[-1])
out='/home/claude/q2/assets/audio/'
for w in range(1,12):
    for l in range(1,13):
        f=f'/tmp/qx/w46/m{w}-n{l}.wav';g=T[l]-rms(f)
        subprocess.run(['ffmpeg','-y','-loglevel','error','-ss','6','-t','36','-i',f,'-af',f'volume={g}dB,alimiter=limit=0.85:level=false','-ac','1','-ar','24000','-b:a','24k',f'{out}w{w}/q{l}.mp3'])
    print(w,'ok',flush=True)
