/* tighten.js — resserre l'ÉNERGIE (R61). Retour de Simon : « je n'utilise que 10 % de la matière ».
   Cause : un petit trait bien placé suffit ; l'énergie ne contraint rien. Méthode : on cherche la solution la MOINS CHÈRE
   parmi 4 000 lignes au hasard, on fixe l'encre à 1,25 × son coût (au moins +20), et on retient comme solution de référence
   la solution réussie à la ligne droite la plus robuste qui tient dans cette encre ; le noyau est replacé sur sa trajectoire
   si besoin. Usage : OUT=tight.json node tighten.js 37 38 …   puis  SRC=tight.json python3 w3apply.py …  */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const COST={0:1,1:1.9,3:1.7,5:1};
let seed=5;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
function gauss(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
const out=process.env.OUT||'tight.json',res=fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{};
for(const a of process.argv.slice(2)){const idx=+a-1,L=JSON.parse(JSON.stringify(X.LEVELS[idx]));
 const c={n:L.n,ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w};
 const mats=[0].concat((L.pal||'S').includes('B')?[1]:[]).concat((L.pal||'S').includes('A')?[3]:[]);
 const wins=[];let tries=0;
 while(tries<4000){const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);const x=rnd()*360,y=rnd()*480,an=rnd()*6.2832,len=10+rnd()*(maxL-10);
  const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(an)*len),Math.round(y+Math.sin(an)*len)]];if(!D.drawable(c,p))continue;tries++;
  const r=LAB.run(idx,c,[{pts:p,mat:m}]);if(r.ok)wins.push({pts:p,mat:m,cost:len*COST[m],star:r.star});}
 if(!wins.length){console.log('#'+a,'aucune solution à un trait trouvée (niveau à plusieurs traits ?) — inchangé');continue;}
 wins.sort((p,q)=>p.cost-q.cost);const minC=wins[0].cost,ink=Math.round(Math.max(minC*1.25,minC+20));
 if(process.env.DRY){console.log('#'+a+' '+L.n.padEnd(22)+' trait gagnant le moins cher : '+Math.round(minC)+' u ('+wins.length+' gagnants)');continue;}
 const c2=Object.assign({},c,{ink});let best=null;
 for(const w of wins.filter(w=>w.cost<=ink*.95).slice(0,30)){let s=0;for(let k=0;k<24;k++){const pp=w.pts.map(q=>[q[0]+gauss()*3,q[1]+gauss()*3]);if(LAB.run(idx,c2,[{pts:pp,mat:w.mat}]).ok)s++;}
  const pl=s/24;if(!best||pl>best.pl)best={w,pl};}
 if(!best||best.pl<.7){console.log('#'+a,L.n,'— la solution la moins chère est trop fragile ; encre inchangée');continue;}
 let r=LAB.run(idx,c2,[{pts:best.w.pts,mat:best.w.mat}]);let star=L.star;
 if(!r.star){const q=r.tr[Math.floor(r.tr.length*.5)];star=[Math.round(q[0]),Math.round(q[1])];c2.star=star;r=LAB.run(idx,c2,[{pts:best.w.pts,mat:best.w.mat}]);if(!r.ok||!r.star){console.log('#'+a,'noyau introuvable — inchangé');continue;}}
 res[a]={n:L.n,cup:L.cup,ink,star,optsol:[best.w.pts],optmat:best.w.mat,P_ligne:best.pl,minCost:Math.round(minC)};fs.writeFileSync(out,JSON.stringify(res,null,1));
 console.log(`#${a} ${L.n.padEnd(20)} solution la moins chère ${Math.round(minC)} → encre ${L.ink} ⇒ ${ink} (${Math.round(100*minC/ink)} % utilisés au minimum) · P_ligne ${Math.round(best.pl*100)} %`);}
