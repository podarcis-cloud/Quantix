# Fuzz du sampler : réglages au hasard pendant la lecture, puis arrêt/relance (serveur local 8765)
from playwright.sync_api import sync_playwright
import random,sys
seed=int(sys.argv[1]) if len(sys.argv)>1 else 1;random.seed(seed)
errs=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844})
    pg.add_init_script("setInterval(function(){[].forEach.call(document.querySelectorAll('details.smS'),function(d){if(!d.open)d.open=true;});},80)")
    pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)))
    pg.on('console',lambda m:errs.append('CON '+m.text) if m.type=='error' and 'ERR_' not in m.text and 'fonts' not in m.text else None)
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1000)
    pg.evaluate("QUANTONE.state.strokes.length=0")
    pg.evaluate("(function(){var d=new Float32Array(44100);for(var k=0;k<d.length;k++)d[k]=.8*Math.sin(2*Math.PI*220*k/44100)*Math.exp(-k/22050);QSMP.set(1,d,44100,'test');})()")
    pg.evaluate("QUANTONE.state.layer=9;QFX3.open(9)");pg.wait_for_timeout(300)
    for y in (.3,.5,.7):
        pg.evaluate("(()=>{const S=QUANTONE.state;S.strokes.push({layer:9,pts:[[.05,%f,0],[.5,%f,10],[.95,%f,20]]})})()"%(y,y+.05,y))
    pg.evaluate("QFX3.open(9)");pg.click('#bPlay');pg.wait_for_timeout(500)
    n=0
    for it in range(260):
        act=random.random()
        if act<.8:
            r=pg.evaluate("""(seed)=>{const els=[].filter.call(document.querySelectorAll('#inEd input[type=range],#inEd select,#smD input[type=range],#smD select,.smS input[type=range],.smS select'),e=>e.offsetParent);if(!els.length)return 0;const e=els[Math.floor(seed*els.length)%els.length];
              if(e.tagName==='SELECT'){const o=e.options;e.selectedIndex=Math.floor(Math.random()*o.length);}else{const mn=+e.min,mx=+e.max;e.value=mn+Math.random()*(mx-mn);}
              e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return 1;}""",random.random())
            n+=r
        elif act<.9:
            pg.evaluate("""(seed)=>{const bs=[].filter.call(document.querySelectorAll('#inEd button,.smS button,.smS .chip'),e=>e.offsetParent&&!/Banque|Import|Enreg|Record|Bank|×/.test(e.textContent));if(!bs.length)return;bs[Math.floor(seed*bs.length)%bs.length].click();}""",random.random())
        elif act<.95:
            pg.click('#bPlay');pg.wait_for_timeout(60);pg.click('#bPlay')
        else:
            pg.evaluate("QUANTONE.state.layer=9;QFX3.open(9)")
        pg.wait_for_timeout(random.choice([10,20,40,80]))
    print('réglages envoyés',n,'erreurs',len(errs))
    for e in errs[:8]:print(' ',e[:200])
    # relance
    st=pg.evaluate("document.getElementById('bPlay').textContent");print('bouton avant:',st)
    if 'Stop' in st or 'Arr' in st:pg.click('#bPlay');pg.wait_for_timeout(300)
    pg.click('#bPlay');pg.wait_for_timeout(1200)
    print('bouton après relance:',pg.evaluate("document.getElementById('bPlay').textContent"),'niveau',pg.evaluate("QUANTONE.level()"))
