/* R116 — vérifie des niveaux dans le vrai moteur : sans trait → échec ; solution de référence → réussite + noyau.
   Usage : node tools/repairs_check.js 72 102 … (place aussi le noyau sur la trajectoire si STARFIX=1 et l'affiche) */
const LAB=require('./lab.js'),X=LAB.X;
for(const a of process.argv.slice(2)){const i=+a-1,LV=X.LEVELS[i];
 X.loadLevel(i);X.qpBuild();X.S.mode='run';for(let f=0;f<1300&&X.S.mode==='run';f++)X.physics();const seul=X.S.mode==='success';
 const run=()=>{X.loadLevel(i);for(const p of LV.optsol||[])X.S.strokes.push({pts:p,len:1,birth:0,mat:LV.optmat||0});X.qpBuild();X.S.mode='run';const tr=[];
  for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',star:X.S.gotStar,tr};};
 let r=run();if(process.env.STARFIX&&r.ok&&!r.star){const q=r.tr[Math.floor(r.tr.length*.55)];LV.star=[Math.round(q[0]),Math.round(q[1])];r=run();console.log('   noyau proposé',JSON.stringify(LV.star));}
 console.log('#'+a,LV.n,'| seul :',seul?'RÉUSSIT (!)':'échoue','| solution :',r.ok?'réussit':'ÉCHOUE','| noyau :',r.star?'oui':'NON');}
