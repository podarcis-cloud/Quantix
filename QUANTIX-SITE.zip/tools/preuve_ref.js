/* preuve_ref.js N — R209 : la solution de référence (optsol/optmat) gagne-t-elle ? et sans aucun trait, le niveau échoue-t-il ?
   Sortie : une ligne JSON. Utilisé par preuve.py. */
require('./load.js');const X=globalThis.__X;const N=+process.argv[2],i=N-1,LV=globalThis.LEVELS,lv=LV[i];
function run(strokes){X.loadLevel(i);var st=X.S;strokes.forEach(function(p){var len=0;for(var k=1;k<p.length;k++)len+=Math.hypot(p[k][0]-p[k-1][0],p[k][1]-p[k-1][1]);
 st.strokes.push({pts:p.map(function(q){return[q[0],q[1]];}),len:len,birth:0,mat:lv.optmat||0});});X.qpBuild();st.mode='run';
 for(var f=0;f<60*40&&st.mode==='run';f++)X.physics();return {mode:st.mode,star:!!st.gotStar,frames:f};}
var out={n:N,nom:lv.n,mz:!!lv.mz};
out.vide=run([]).mode;
if(lv.optsol){var r=run(lv.optsol);out.ref=r.mode;out.noyau=r.star;out.duree=(r.frames/60).toFixed(1)+' s';}else out.ref='absente';
console.log(JSON.stringify(out));
