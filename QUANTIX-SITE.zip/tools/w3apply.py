"""w3apply.py N… — écrit dans levels.js les résultats de w3retune.json (bassin, encre, noyau, optsol, optmat) des niveaux donnés.
Correctif compté : chaque champ doit être trouvé une seule fois dans l'entrée du niveau, sinon ÉCHEC et arrêt."""
import json,re,sys
R='/home/claude/q/'
import os
d=json.load(open(R+'tools/'+os.environ.get('SRC','w3retune.json')))
p=R+'assets/js/levels.js';s=open(p,encoding='utf-8').read()
def arr(a):return '['+','.join(str(v) for v in a)+']'
for num in sys.argv[1:]:
    r=d[num];i=s.index("n:'%s'"%r['n']);j=s.index("tip:",i);seg=s[i:j]
    sol='['+','.join('['+','.join(arr(q) for q in st)+']' for st in r['optsol'])+']'
    reps=[(r"optsol:\[.*?\]\]\],","optsol:%s,"%sol),(r"optmat:\d+","optmat:%d"%r['optmat']),(r"ink:\d+","ink:%d"%r['ink']),
          (r"cup:\[[^\]]*\]","cup:[%d,%d,%d,'%s']"%tuple(r['cup'])),(r"star:\[[^\]]*\]","star:%s"%arr(r['star']))]
    if 'optsol:' not in seg:   # ancien niveau sans solution enregistrée : on insère les champs après le nom
        seg=re.sub(r"(n:'(?:[^'\\]|\\.)*',)",lambda m:m.group(1)+"optsol:[[[0,0],[1,1]]],optmat:0,",seg,count=1)
    if 'star:' not in seg:
        seg=re.sub(r"(cup:\[[^\]]*\],)",lambda m:m.group(1)+"star:[0,0],",seg,count=1)
    for pat,new in reps:
        if len(re.findall(pat,seg))!=1:print('ÉCHEC',num,pat);sys.exit(1)
        seg=re.sub(pat,new,seg,count=1)
    if r.get('nd'):
        ndtxt='nd:['+','.join(arr(x) for x in r['nd'])+'],'
        if re.search(r"nd:\[\[.*?\]\],",seg):seg=re.sub(r"nd:\[\[.*?\]\],",ndtxt,seg,count=1)
        else:seg=seg.replace('\n w:[','\n '+ndtxt+'w:[',1) if '\n w:[' in seg else seg.replace(' w:[',' '+ndtxt+'w:[',1)
    s=s[:i]+seg+s[j:];print('OK #%s %s'%(num,r['n']))
open(p,'w',encoding='utf-8').write(s)
