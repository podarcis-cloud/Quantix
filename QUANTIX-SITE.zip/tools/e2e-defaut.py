# État par défaut de Quantone (R363) — serveur local requis : python3 -m http.server 8765 depuis la racine
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1800)
    r=pg.evaluate("""()=>{const st=QUANTONE.state,ev=QFX3.score();const pent=[0,3,5,7,10].map(x=>(x+st.root)%12);
      const mel=ev.filter(e=>e.kind===0||e.kind===2);const dr=st.strokes.find(s=>s.layer===4);
      const xs=dr?dr.pts.map(p=>p[0]):[0];
      return {scale:st.scale,tempo:st.k.tempo,layers:st.strokes.map(s=>s.layer),inScale:mel.every(e=>pent.includes(((e.note%12)+12)%12)),nMel:mel.length,
       span:Math.max(...xs)-Math.min(...xs),dmAny:dmAny(),mot:st.dm.mot,kit:st.inst[4].preset,grid:st.grid,loop:QUANTONE.loopLen(),
       lastDrum:Math.max(...ev.filter(e=>e.kind===4).map(e=>e.step)),master:[st.k.echo,st.k.rev,st.k.breath,st.k.drone,st.k.grain]};}""")
    print(r)
    chk(r['scale']=='pm','gamme pentatonique par défaut (%s)'%r['scale'])
    chk(r['tempo']==80,'tempo par défaut 80 BPM (%s)'%r['tempo'])
    chk(r['layers']==[0,2,4],'deux courbes (lead, pad) + un trait Rythmes %s'%r['layers'])
    chk(r['inScale'] and r['nMel']>10,'toutes les notes mélodiques sont dans la gamme (%d notes)'%r['nMel'])
    chk(r['span']>.9,'le trait Rythmes occupe toute la largeur (%.2f)'%r['span'])
    chk(r['dmAny'] and r['mot']=='hiphop' and r['kit']=='Brosses','boîte à rythmes avec motif et kit déjà choisis (%s / %s)'%(r['mot'],r['kit']))
    chk(r['grid']==32 and r['lastDrum']>=28,'les rythmes couvrent toute la phrase (grille %s, dernier pas %s)'%(r['grid'],r['lastDrum']))
    chk(all(v==0 for v in r['master']),'master par défaut sans effets %s'%r['master'])
    pg.click('#bPlay');pg.wait_for_timeout(3000);lv=pg.evaluate("QUANTONE.level()");chk(lv>.003,'la lecture sonne (niveau %.3f)'%lv)
    chk(not errs,'aucune erreur de page %s'%errs[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
