# État par défaut de Quantone (R370) : aucun trait, aucune animation ni son d'ouverture — serveur local : python3 -m http.server 8765 depuis la racine
from playwright.sync_api import sync_playwright
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.add_init_script("window.QINTRO_FORCE=1")
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1500)
    r=pg.evaluate("()=>({n:QUANTONE.state.strokes.length,scale:QUANTONE.state.scale,tempo:QUANTONE.state.k.tempo,intro:!!window.QINTRO,lv:QUANTONE.level()})")
    chk(r['n']==0,'aucun trait par défaut (%s)'%r['n'])
    chk(not r['intro'],"pas d'animation d'ouverture")
    chk(r['lv']<.001,"pas de son d'ouverture (niveau %.4f)"%r['lv'])
    chk(r['scale']=='pm' and r['tempo']==80,'gamme et tempo par défaut conservés (%s, %s)'%(r['scale'],r['tempo']))
    pg.mouse.click(5,5);pg.wait_for_timeout(1200);chk(pg.evaluate("QUANTONE.level()")<.001,'toujours silencieux après le premier geste')
    chk(not errs,'aucune erreur de page %s'%errs[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
