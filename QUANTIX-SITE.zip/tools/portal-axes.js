/* portal-axes.js (R311) — axe d'affichage de chaque sortie de portail : vitesse de la particule juste après la téléportation,
   lors de la solution de référence. Écrit un 7e élément (degrés) dans lv.port[i] : [ax,ay,bx,by,angle,flag,axe].
   Usage : node portal-axes.js   (depuis tools/) */
const X=require('./difficulty.js').X,fs=require('fs'),re=/^\{wd:/gm;
let src=fs.readFileSync('../assets/js/levels.js','utf8');
const st=[...src.matchAll(re)].map(m=>m.index),out=[];
for(let idx=0;idx<X.LEVELS.length;idx++){const LV=X.LEVELS[idx];if(!LV.port||!LV.port.length)continue;
 X.loadLevel(idx);const sol=LV.optsol||[];for(const p of sol)X.S.strokes.push({pts:p,len:1,birth:0,mat:LV.optmat||0});X.qpBuild();X.S.mode='run';
 const ax=LV.port.map(()=>null);let prev=null;
 for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();const b=X.S.ball;
  LV.port.forEach((p,i)=>{const d=Math.hypot(b.x-p[2],b.y-p[3]);if(ax[i]===null&&prev&&d<30&&Math.hypot(prev.x-p[0],prev.y-p[1])<30&&Math.hypot(b.x-p[0],b.y-p[1])>8){ax[i]=Math.round(Math.atan2(b.vy,b.vx)*180/Math.PI);}});prev={x:b.x,y:b.y};}
 out.push([idx+1,LV.n,ax.join(',')]);
 const a=st[idx],b2=st[idx+1]||src.length,e=src.slice(a,b2);
 const m=e.match(/port:(\[\[[^\]]*\](?:,\s*\[[^\]]*\])*\])/);if(!m){console.log('#'+(idx+1),'port non trouvé');continue;}
 const arr=JSON.parse(m[1]).map((p,i)=>{p=p.slice(0,6);while(p.length<6)p.push(0);if(ax[i]!==null)p[6]=ax[i];else p.length=Math.min(p.length,6);return p;});
 src=src.slice(0,a)+e.replace(m[1],JSON.stringify(arr))+src.slice(b2);
 /* les indices st ont changé de longueur : recalcul */
 const nst=[...src.matchAll(re)].map(m=>m.index);st.length=0;nst.forEach(v=>st.push(v));}
fs.writeFileSync('../assets/js/levels.js',src);console.log(out.map(o=>o.join(' | ')).join('\n'));
