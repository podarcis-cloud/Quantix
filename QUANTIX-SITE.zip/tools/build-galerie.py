"""build-galerie.py — banc des rendus à valider (artefact séparé du jeu).
Inline visuals.js, les niveaux montrés (galerie-niveaux.js) et le fond du Magnétisme dans studio/galerie-rendus.tpl.html
→ /mnt/user-data/outputs/quantix-galerie-rendus.html"""
import os,re,subprocess,base64
H=os.path.dirname(os.path.abspath(__file__));Q=H+'/..'
t=open(Q+'/studio/galerie-rendus.tpl.html',encoding='utf-8').read()
v=open(Q+'/assets/js/visuals.js',encoding='utf-8').read().replace('</script','<\\/script')
b=re.search(r'build (R\d+)',open(Q+'/index.html',encoding='utf-8').read()).group(1)
lv=subprocess.run(['node','galerie-niveaux.js'],cwd=H,capture_output=True,text=True).stdout.split('@@JSON@@')[1]
w8='data:image/jpeg;base64,'+base64.b64encode(open(Q+'/assets/img/worlds/w08-magnetisme.jpg','rb').read()).decode()
o='/mnt/user-data/outputs/quantix-galerie-rendus.html'
open(o,'w',encoding='utf-8').write(t.replace('__VISUALS__',v).replace('__BUILD__',b).replace('__LV8__',lv.replace('</','<\\/')).replace('__W8__',w8))
print(o,round(os.path.getsize(o)/1e6,2),'Mo')
