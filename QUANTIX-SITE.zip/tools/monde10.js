/* monde10.js — non-régression du monde 10 Filaments (R242).
   Pour chaque niveau : sans trait → ne réussit pas ; « Voir la solution optimale » → réussit, progression intacte ;
   même solution sans cordes : traits en structure (matière 0), bille rigide, frondes et diapasons retirés → échoue (la gravité est indispensable). Le noyau est indiqué, pas exigé. */
require('./load.js');
const X=globalThis.__X,{store}=require('./load.js');const ST=X.S;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function runSol(i){X.loadLevel(i);for(const p of X.LEVELS[i].optsol)ST.strokes.push({pts:p,len:plen(p),birth:0,mat:X.LEVELS[i].optmat||0});X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();return ST.mode==='success';}
function runSol0(i){X.loadLevel(i);X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();return ST.mode==='success';}
let bad=0,n=0;
for(let i=108;i<120;i++){const LVi=X.LEVELS[i];if(!LVi.optsol){console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'(sans solution de référence)');bad++;continue;}n++;
 X.loadLevel(i);X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();const seul=ST.mode==='success';
 X.loadLevel(i);const before=JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);ST.mode='fail';
 store['rSolution'].onclick.call(store['rSolution'],{});for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();
 const win=ST.mode==='success',star=ST.gotStar,intact=before===JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);
 const K=['strings','fork','sling','softball','elastic'],sv=K.map(k=>LVi[k]);K.forEach(k=>LVi[k]=null);const om=LVi.optmat;LVi.optmat=0;const sans0=runSol0(i),sans=!sans0&&runSol(i);LVi.optmat=om;K.forEach((k,j)=>LVi[k]=sv[j]);   /* sans0 : sans champ, la particule réussit seule → le champ est un obstacle toujours actif (78) */
 const ok=!seul&&win&&intact&&!sans;if(!ok)bad++;
 console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'seul:',seul?'RÉUSSIT(!)':'non','| solution:',win?'réussit':'ÉCHOUE','| noyau',star?'oui':'non','| sans corde:',sans0?'obstacle':sans?'RÉUSSIT(!)':'échoue','| progression',intact?'intacte':'TOUCHÉE',ok?'OK':'ÉCHEC');}
console.log(bad?bad+' problème(s)':'monde 10 : '+n+'/'+n+' OK');process.exitCode=bad?1:0;
