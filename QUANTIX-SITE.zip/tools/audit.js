/* Vérifie l'intégrité du site : chemins référencés, absence de base64,
   ordre de chargement, et exécution du moteur. */
const fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..');
let bad=0;
const html=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
const css=fs.readFileSync(path.join(ROOT,'assets/css/quantix.css'),'utf8');
const js=['worldart.js','i18n.js','levels.js','engine.js']
  .map(f=>[f,fs.readFileSync(path.join(ROOT,'assets/js',f),'utf8')]);

// 1 · plus aucune donnée embarquée
for(const [f,s] of js.concat([['index.html',html],['quantix.css',css]])){
  const n=(s.match(/data:(image|audio)\/[a-z]+;base64/g)||[]).length;
  if(n){console.log('  '+f+' contient encore '+n+' asset(s) en base64');bad++;}
}
if(!bad)console.log('  aucun asset embarqué en base64                OK');

// 2 · tous les chemins référencés existent
const refs=new Set();
for(const [,s] of js) for(const m of s.matchAll(/["'](assets\/[^"']+)["']/g)) refs.add(m[1]);
for(const m of html.matchAll(/(?:src|href)="((?:assets|manifest)[^"]*)"/g)) refs.add(m[1]);
for(const m of css.matchAll(/url\(\.\.\/([^)]+)\)/g)) refs.add('assets/'+m[1]);
const mf=fs.readFileSync(path.join(ROOT,'manifest.webmanifest'),'utf8');
for(const m of mf.matchAll(/"src"\s*:\s*"([^"]+)"/g)) refs.add(m[1]);
let miss=[...refs].filter(r=>!fs.existsSync(path.join(ROOT,r)));
console.log(miss.length?('  chemins introuvables : '+miss.join(', ')):
 ('  '+refs.size+' chemins référencés, tous présents        OK'));
bad+=miss.length;

// 3 · fichiers présents mais jamais référencés
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>
  e.isDirectory()?walk(path.join(d,e.name)):[path.relative(ROOT,path.join(d,e.name))]);
const files=walk(path.join(ROOT,'assets')).filter(f=>!f.endsWith('.js')&&!f.endsWith('.css'));
const orphan=files.filter(f=>!refs.has(f));
console.log(orphan.length?('  assets jamais référencés : '+orphan.join(', ')):
 ('  aucun asset orphelin                         OK'));

// 4 · le moteur démarre
try{ require('./load.js'); const X=globalThis.__X;
  console.log('  moteur chargé : '+X.LEVELS.length+' niveaux, '+X.WORLDS.length+' mondes  OK');
}catch(e){console.log('  ERREUR au chargement : '+e.message);bad++;}
process.exit(bad?1:0);
