"""pipeline.py — R97 : UNE commande par niveau (économie de calcul). Enchaîne, en n'affichant qu'un résumé :
fiche.js (recherche + critères) → slotwrite.py (installation fr/en) → enigme.js → finition.js → zonepropre → test du monde → rapport.
Usage : python3 tools/pipeline.py N plan.json [PMIN=.8] [MINL=..]   (plan.json : nom et conseil fr/en, comme slotwrite)"""
import subprocess,sys,os,json,re
H=os.path.dirname(os.path.abspath(__file__));N=sys.argv[1];plan=sys.argv[2]
env=dict(os.environ,NS=os.environ.get('NS','2500'))
for a in sys.argv[3:]:
    k,v=a.split('=');env[k]=v
def run(cmd,t=280):
    r=subprocess.run(cmd,cwd=H,env=env,capture_output=True,text=True,timeout=t);return r.stdout+r.stderr
o=run(['node','fiche.js',N]);m=re.search(r'CONFORME : (.*)',o)
if not m:
    last=[l for l in o.splitlines() if l.startswith('{')][-3:];print('FICHE NON CONFORME —','\n  '.join(['']+last));sys.exit(1)
print('fiche :',m.group(1)[:160])
o=run(['python3','slotwrite.py',plan]);print('installation :','OK' if 'OK #' in o else o[-200:])
o=run(['node','enigme.js',N]);print('énigme :',' '.join([l for l in o.splitlines() if l.startswith('#')])[len(N)+2:][:170])
o=run(['node','finition.js',N],200);print('finition :',' '.join([l for l in o.splitlines() if l.startswith('#')])[len(N)+2:][:150])
w=(int(N)-1)//12+1;o=run(['node','monde%d.js'%w]);print('monde %d :'%w,[l for l in o.splitlines() if 'monde' in l and ':' in l][-1:] or 'ÉCHEC' if 'ÉCHEC' in o else 'OK')
