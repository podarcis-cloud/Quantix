"""slotwrite.py — installe des niveaux forgés (forge.json) dans levels.js, avec nom et conseil fr/en.
Usage : python3 slotwrite.py plan.json   où plan.json = {"9":{"key":"9_66","n":"…","tip":"…","nEn":"…","tipEn":"…"}, …}
Remplace l'entrée entière du niveau (repérée par son rang parmi les lignes « {wd: »), puis les tableaux anglais."""
import json,sys,re
R='/home/claude/q/'
F=json.load(open(R+'tools/forge.json'));plan=json.load(open(sys.argv[1]))
MAT={0:'S_',1:'B_',2:'X_',3:'A_',4:'I_',5:'5'}
def arr(a):return '['+','.join(str(v) for v in a)+']'
p=R+'assets/js/levels.js';s=open(p,encoding='utf-8').read()
starts=[m.start() for m in re.finditer(r'^\{wd:',s,re.M)]
assert len(starts)==132,len(starts)
for num in sorted(plan,key=lambda k:-int(k)):           # de la fin vers le début : les positions restent valides
    q=plan[num];f=F[q['key']];c=f['c'];i=int(num)-1;a=starts[i]
    m=re.compile(r"tip:'(?:[^'\\]|\\.)*'\},?\n").search(s,a);assert m,num
    wd=int(re.match(r'\{wd:(\d+)',s[a:a+8]).group(1))
    sol='['+','.join('['+','.join(arr(x) for x in st)+']' for st in f['optsol'])+']'
    w=','.join('['+','.join(str(v) for v in seg[:4])+','+MAT[seg[4]]+']' for seg in c['w'])
    nd=('nd:['+','.join(arr(r) for r in c['nd'])+'],') if c.get('nd') else ''
    if c.get('rails'):nd+='rails:'+json.dumps(c['rails'],separators=(',',':'))+','
    for fld2 in ('curves','mz','flow','vortex','updraft','mov','pend','well','bf','kick','port','wrap','strings','elastic','strE','sling','fork','coil','spectro','ent','gate','sup','det','tdil'):
        if c.get(fld2):nd+=fld2+':'+json.dumps(c[fld2],separators=(',',':'))+','
    for fld in ('wind','grav','mag'):
        if c.get(fld):nd+=fld+':['+','.join(arr(r) for r in c[fld])+'],'
    pal=("pal:'%s',"%c['pal']) if c.get('pal') else ''
    entry="{wd:%d,n:'%s',optsol:%s,optmat:%d,ink:%d,%sball:%s,cup:[%d,%d,%d,'%s'],star:%s,\n w:[%s],%s\n tip:'%s'},\n"%(wd,q['n'],sol,f['optmat'],c['ink'],pal,arr(c['ball']),c['cup'][0],c['cup'][1],c['cup'][2],c['cup'][3],arr(c['star']),w,nd,q['tip'])
    s=s[:a]+entry+s[m.end():];print('OK #%s %s'%(num,q['n']))
open(p,'w',encoding='utf-8').write(s)
# anglais
ip=R+'assets/js/i18n.js';t=open(ip,encoding='utf-8').read()
def setarr(t,name,num,val):
    a=t.index('var %s=['%name);b=t.index('];',a)
    body=t[a+len('var %s=['%name):b]
    items=re.findall(r"'(?:[^'\\]|\\.)*'",body)
    assert len(items)==132,(name,len(items))
    old=items[int(num)-1];k=body.index(old)
    # remplacer la n-ième occurrence exacte
    cnt=0;pos=0
    for idx,it in enumerate(re.finditer(r"'(?:[^'\\]|\\.)*'",body)):
        if idx==int(num)-1:body=body[:it.start()]+"'"+val+"'"+body[it.end():];break
    return t[:a+len('var %s=['%name)]+body+t[b:]
for num,q in plan.items():
    t=setarr(t,'LV_EN_N',num,q['nEn']);t=setarr(t,'LV_EN_T',num,q['tipEn'])
open(ip,'w',encoding='utf-8').write(t);print('OK anglais')
