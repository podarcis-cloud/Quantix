# Capture directe (R384) : l'enregistrement en bibliothèque capte la sortie réelle ; Track utilise cet audio tel quel
from playwright.sync_api import sync_playwright
import json,time,numpy as np,copy
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
J=json.load(open('/tmp/J.json'));J=copy.deepcopy(J);J['preset']['strokes']=[s for s in J['preset']['strokes'] if s['l']==4]
GET="""async()=>new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.map(i=>({id:i.id,name:i.name,ver:i.ver,auH:i.auH||null,au:i.au?{sr:i.au.sr,len:i.au.len,n:i.au.l.length,l:Array.from(i.au.l.slice(0,i.au.l.length))}:null})))}})"""
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);ctx=b.new_context(viewport={'width':390,'height':844});pg=ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.evaluate("localStorage.setItem('qx.proj','Test')");pg.reload();pg.wait_for_timeout(900)
    pg.evaluate("(J)=>QXIO.open(J)",J);pg.wait_for_timeout(300)
    ref=pg.evaluate("""()=>new Promise(res=>{QUANTONE.renderBlock((b,mt)=>{const d=b.getChannelData(0),sr=b.sampleRate,s0=Math.round(mt.start*sr),n=Math.round(mt.len*sr);res({len:mt.len,d:Array.from(d.subarray(s0,s0+n))})})})""")
    # R404 : Fichier ▸ « Enregistrer ce pattern » (premier enregistrement : nom et projet demandés)
    t=time.time();pg.click('#qFileBtn');pg.wait_for_timeout(300);pg.click('#qfSave');pg.wait_for_timeout(200);pg.fill('#qLibIn','Capture');pg.click('#qLibOk')
    pg.wait_for_function("QPATFILE.edit().id&&!window.QCAPBUSY",timeout=60000);dt=time.time()-t
    items=pg.evaluate(GET);it=items[0] if items else None
    chk(it and it['au'] is not None,'l\'enregistrement stocke un audio avec le motif (%.1f s d\'attente)'%dt)
    chk(abs(it['au']['len']-ref['len'])<.01,'durée = un cycle exact (%.3f s vs %.3f s)'%(it['au']['len'],ref['len']))
    cap=np.array(it['au']['l'],dtype=np.float32)/32767;rf=np.array(ref['d'],dtype=np.float32)
    n=min(len(cap),len(rf));cc=np.fft.irfft(np.fft.rfft(cap[:n],1<<21)*np.conj(np.fft.rfft(rf[:n],1<<21)))
    sr=it['au']['sr'];lag=int(np.argmax(cc));lag=lag if lag<n//2 else lag-(1<<21)
    r=float(cc.max()/np.sqrt((cap[:n]**2).sum()*(rf[:n]**2).sum()))
    env=lambda x:np.sqrt((x[:len(x)//441*441].reshape(-1,441)**2).mean(1));renv=float(np.corrcoef(env(cap[:n]),env(rf[:n]))[0,1]);lv=float(np.sqrt((cap**2).mean()/(rf**2).mean()))
    chk(abs(lag)/sr<.01 and renv>.97,'départ aligné sur le pas 1 (décalage %.1f ms, enveloppes r=%.3f)'%(lag/sr*1000,renv))
    chk(.9<lv<1.1,'même niveau que le rendu de référence (×%.2f)'%lv)
    # pas de recapture si identique
    t=time.time();pg.click('#qFileBtn');pg.wait_for_timeout(300);pg.click('#qfSave');pg.wait_for_timeout(1200);dt2=time.time()-t
    chk(pg.evaluate(GET)[0]['auH']==it['auH'] and pg.evaluate("!document.querySelector('.toast,#toast')||!/Enregistrement du son/.test((document.querySelector('.toast,#toast')||{}).textContent||'')"),'motif inchangé : pas de nouvelle capture')
    # Track
    pg2=ctx.new_page();pg2.on('pageerror',lambda e:er.append(str(e)))
    pg2.goto('http://localhost:8765/studio/morceau.html');pg2.wait_for_timeout(1000)
    ok=pg2.evaluate("""async(id)=>{const M=MORCEAU;const q=document.querySelectorAll('#patSel option');return [...q].map(o=>o.value).join('|')}""",it['id'])
    pg2.evaluate("(id)=>{document.getElementById('patSel').value='lib:'+id;document.getElementById('patSel').dispatchEvent(new Event('change'))}",it['id']);pg2.wait_for_timeout(2500)
    out=pg2.evaluate("(()=>{const P=MORCEAU.P();const b=P.blocks[0];return b?{au:b.au||0,len:b.len,n:b.ch[0].length,h:Array.from(b.ch[0].slice(0,2000))}:null})()")
    chk(out and out['au']==1,'Track : le bloc vient de la capture (pas du rendu approximatif) %s'%ok[:60])
    if out:
        chk(abs(out['len']-it['au']['len'])<1e-6,'même durée dans Track')
        chk(np.allclose(np.array(out['h'][:2000],dtype=np.float32),cap[:2000],atol=2e-4),'mêmes échantillons que la capture')
    chk(not er,'aucune erreur JS '+str(er[:2]))
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
