/* replaytest.js — R31 : « Voir la solution optimale » et « Revoir ma partie ».
   Solution : pour chaque niveau du monde 1, le bouton rSolution doit gagner AVEC le noyau,
   sans toucher à la progression (étoiles, record, déblocage).
   Relecture : après une vraie partie, rReplay doit rejouer S.rec et finir exactement
   là où la balle s'est arrêtée, puis rendre l'écran de résultat. */
require('./load.js');
const X=globalThis.__X,{store}=require('./load.js');const S=X.S;
let bad=0;
for(let i=0;i<12;i++){
 X.loadLevel(i);
 const before=JSON.stringify([S.best[i],S.bestMat[i],S.unlocked]);
 S.mode='fail';store['rSolution'].onclick.call(store['rSolution'],{});
 for(let f=0;f<1200&&S.mode==='run';f++)X.physics();
 const after=JSON.stringify([S.best[i],S.bestMat[i],S.unlocked]);
 const ok=S.mode==='success'&&S.gotStar&&before===after&&!S.demo;
 if(!ok)bad++;
 console.log(String(i+1).padStart(2),X.LEVELS[i].n.padEnd(17),'solution :',S.mode,'| noyau',S.gotStar?'oui':'NON','| progression intacte',before===after?'oui':'NON',ok?'  OK':'  <<<');
}
// relecture d'une vraie partie (niveau 3, un trait)
X.loadLevel(2);S.strokes.push({pts:[[300,200],[200,330]],len:164,birth:0,mat:0});X.qpBuild();S.mode='run';
for(let f=0;f<900&&S.mode==='run';f++)X.physics();
const endMode=S.mode,rec=S.rec.slice(),endPos=[S.ball.x,S.ball.y];
store['rReplay'].onclick.call(store['rReplay'],{});
const start=S.mode;let n=0;while(S.mode==='replay'&&n<5000){globalThis.replayStep();n++;}
const last=rec[rec.length-1],same=Math.abs(S.ball.x-last[0])<1e-9&&Math.abs(S.ball.y-last[1])<1e-9;
const rok=start==='replay'&&S.mode===endMode&&same&&n===rec.length+1;if(!rok)bad++;
console.log('relecture : mode',start,'→',S.mode,'| images relues',n-1,'/',rec.length,'| position finale identique',same?'oui':'NON',rok?'  OK':'  <<<');
console.log(bad?bad+' problème(s)':'solution optimale 12/12 + relecture : OK');process.exitCode=bad?1:0;
