from playwright.sync_api import sync_playwright
import os,wave,struct,math,json
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
wp='/tmp/test-smp.wav'
w=wave.open(wp,'wb');w.setnchannels(1);w.setsampwidth(2);w.setframerate(44100)
w.writeframes(b''.join(struct.pack('<h',int(12000*math.sin(2*math.pi*220*i/44100)*math.exp(-i/22050))) for i in range(44100)));w.close()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
    ctx=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,permissions=['microphone'])
    pg=ctx.new_page();pg.add_init_script("setInterval(function(){[].forEach.call(document.querySelectorAll('details.smS'),function(d){if(!d.open)d.open=true;});},80)")
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.on('console',lambda m: errs.append(m.text) if m.type=='error' and 'fonts' not in m.text and 'ERR_' not in m.text else None)
    pg.goto('file://'+os.path.abspath('studio/quantone.html'));pg.wait_for_timeout(800)
    chk(pg.evaluate("document.querySelectorAll('#layers .lb').length")==12,'12 boutons d’instruments')
    # niveaux sonores de chaque instrument
    pg.evaluate("document.getElementById('bPlay')&&0")
    lv=[]
    for i in range(12):
        if i==9:
            pg.evaluate("(function(){var d=new Float32Array(44100);for(var k=0;k<d.length;k++)d[k]=.8*Math.sin(2*Math.PI*220*k/44100)*Math.exp(-k/22050);QSMP.set(1,d,44100,'test');})()")
        pg.evaluate("QFX3.open(%d)"%i)
        pg.evaluate("QFX3.hear(%d)"%i)
        mx=0
        for k in range(14):
            pg.wait_for_timeout(110);mx=max(mx,pg.evaluate("QUANTONE.level()"))
        lv.append(round(mx,3));pg.wait_for_timeout(500)
    print('niveaux',lv)
    chk(all(x>.004 for x in lv),'les 12 instruments sonnent')
    # éditeur du sampler
    pg.evaluate("QFX3.open(9)");pg.wait_for_timeout(200)
    chk(pg.evaluate("!!document.getElementById('smCv')"),'éditeur du sampler affiché')
    chk(pg.evaluate("document.querySelectorAll('#inEd [data-ik]').length")>=25,'réglages du sampler : %d'%pg.evaluate("document.querySelectorAll('#inEd [data-ik]').length"))
    pg.set_input_files('#smFile',wp);pg.wait_for_timeout(900)
    chk('test-smp' in pg.evaluate("document.getElementById('smSt').textContent") or 'smp' in pg.evaluate("document.getElementById('smSt').textContent").lower(),'import d’un .wav : '+pg.evaluate("document.getElementById('smSt').textContent"))
    n0=pg.evaluate("QSMP.SMP[1].d.length")
    pg.evaluate("(function(){var r=document.querySelector('[data-ik=\"end\"]');r.value=.5;r.dispatchEvent(new Event('input',{bubbles:true}));})()")
    pg.click('#smCut');pg.wait_for_timeout(200)
    n1=pg.evaluate("QSMP.SMP[1].d.length");chk(abs(n1-n0/2)<40,'couper à la zone : %d → %d'%(n0,n1))
    pg.click('#smNorm');pg.wait_for_timeout(100)
    mx=pg.evaluate("Math.max.apply(null,Array.from(QSMP.SMP[1].d).map(Math.abs))");chk(abs(mx-.98)<.01,'normaliser : crête %.3f'%mx)
    a=pg.evaluate("QSMP.SMP[1].d[100]");pg.click('#smRev');pg.wait_for_timeout(100);bb=pg.evaluate("QSMP.SMP[1].d[QSMP.SMP[1].d.length-101]");chk(abs(a-bb)<1e-6,'inverser')
    pg.click('#smUndo');pg.wait_for_timeout(100);cc=pg.evaluate("QSMP.SMP[1].d[100]");chk(abs(cc-a)<1e-6,'annuler')
    # glisser un repère sur la forme d'onde
    bx=pg.evaluate("(function(){var r=document.getElementById('smCv').getBoundingClientRect();return [r.left,r.top,r.width,r.height];})()")
    pg.mouse.move(bx[0]+bx[2]-2,bx[1]+bx[3]/2);pg.mouse.down();pg.mouse.move(bx[0]+bx[2]*.3,bx[1]+bx[3]/2,steps=4);pg.mouse.up()
    e=pg.evaluate("QFX3.inst[9].p.end");chk(abs(e-.3)<.06,'repère fin glissé → %.2f'%e)
    # modes, effets
    for pre in ['Lo‑fi','Rêve','Tranches','Boucle tenue','Sale','Clair']:
        pg.click('#inEd .ipre button[data-pr="%s"]'%pre);pg.wait_for_timeout(250)
    chk(True,'préréglages du sampler sans erreur')
    # automation : menu sur le curseur Vitesse
    r=pg.evaluate("(function(){var el=document.querySelector('#inEd [data-ik=\"speed\"]');return QAUTO.key(el)})()")
    chk(r and 'speed' in str(r),'clé d’automation du curseur Vitesse : %s'%r)
    # micro (fausse entrée)
    pg.evaluate("QSMP.SMP[2]=null");pg.click('#smRec');pg.wait_for_timeout(1500);pg.click('#smRec');pg.wait_for_timeout(1800)
    chk(pg.evaluate("!!QSMP.SMP[1]&&QSMP.SMP[1].d.length>1000"),'enregistrement micro (fausse entrée) : %s'%pg.evaluate("document.getElementById('smSt').textContent"))
    # nouvelles fonctions
    pg.evaluate("QFX3.open(2)")
    ok=True
    for fn in range(11,21):
        pg.evaluate("(function(){QFX3.inst[0].fn=%d;QFX3.inst[2].fn=%d;})()"%(fn,fn))
        pg.evaluate("QFX3.hear(0)");pg.wait_for_timeout(900)
    chk(True,'fonctions 11 à 20 jouées sans erreur')
    pg.evaluate("QFX3.inst[0].fn=0;QFX3.inst[2].fn=0")
    pj=pg.evaluate("JSON.stringify(QFX3.preset().inst.length)");chk(pj=='12','préréglage : 12 instruments')

    # volume : coupure totale et gros gain
    def lev(vol):
        pg.evaluate("QFX3.inst[0].p.vol=%s"%vol);pg.evaluate("QFX3.hear(0)");m=0
        for k in range(12):
            pg.wait_for_timeout(110);m=max(m,pg.evaluate("QUANTONE.level()"))
        pg.wait_for_timeout(700);return m
    pg.wait_for_timeout(3500);l0=lev(0);l1=lev(1);l3=lev(3);print('volume 0 / 1 / 3 ->',round(l0,4),round(l1,3),round(l3,3))
    chk(l0<.005,'volume 0 = muet');chk(l3>l1*1.4,'volume 3 bien plus fort que 1')
    # boîte à rythmes : vide par défaut, motifs, geste multi-cases
    chk(pg.evaluate("!QFX3.preset().dm"),'boîte à rythmes vide par défaut')
    nm=pg.evaluate("document.querySelectorAll('#dmMo optgroup option').length");chk(nm>=45,'%d motifs dans le menu déroulant'%nm)
    chk(pg.evaluate("document.getElementById('dmD').parentNode.id")=='dmHold','boîte rangée hors calque Rythmes');pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(200);chk(pg.evaluate("!!document.getElementById('dmD').closest('#inEd')"),'boîte dans le module unique de l’éditeur Rythmes');chk(pg.evaluate("!!document.querySelector('#inEd .ipre')&&document.querySelector('#inEd .ipre').style.display=='none'"),'un seul menu de kit (préréglages classiques masqués)')
    pg.select_option('#dmMo','house');pg.wait_for_timeout(150)
    pg.select_option('#dmMo','vide');pg.wait_for_timeout(150)
    pg.evaluate("document.querySelector('#dmP').scrollIntoView({block:'center'})");pg.wait_for_timeout(200)
    r=pg.evaluate("(function(){var a=document.querySelector('#dmP [data-s=\"1\"]').getBoundingClientRect(),b=document.querySelector('#dmP [data-s=\"5\"]').getBoundingClientRect();return [a.left+a.width/2,a.top+a.height/2,b.left+b.width/2,b.top+b.height/2];})()")
    pg.mouse.move(r[0],r[1]);pg.mouse.down();pg.mouse.move(r[2],r[3],steps=12);pg.mouse.up();pg.wait_for_timeout(200)
    on=pg.evaluate("QFX3.preset().dm.rows[0].on.slice(0,8).join('')");chk(on=='01111100'[0:8] or on[1:6]=='11111','glisser peint 5 cases d’un geste : '+on)
    # un trait dessiné sur Rythmes ne joue rien
    pg.evaluate("QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:90},strokes:[{l:4,p:[[.1,.2],[.3,.5],[.6,.4],[.9,.7]]}]})")
    chk(pg.evaluate("QFX3.score().length")==0,'trait Rythmes seul : aucune note')
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(200);pg.select_option('#dmMo','house');pg.wait_for_timeout(150)
    full=pg.evaluate("QFX3.score().length");pg.evaluate("QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:90},strokes:[{l:4,p:[[.0,.2],[.5,.5]]}],dm:QFX3.preset().dm})")
    half=pg.evaluate("QFX3.score().length");chk(0<half<full,'un trait Rythmes ouvre la boîte sur sa largeur : %d notes sur %d'%(half,full))
    # sans aucun trait, la boîte joue (lecture réelle, avec et sans effet actif)
    pg.evaluate("(d)=>QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:90},strokes:[],dm:d})",pg.evaluate("QFX3.preset().dm"))
    pg.click('#bPlay');pg.wait_for_timeout(700)
    chk(pg.evaluate("document.getElementById('bPlay').classList.contains('on')"),'sans trait : la boîte joue (lecture lancée)')
    pg.click('#bPlay');pg.wait_for_timeout(200)

    # R258 : module unique, 14 voix, tempo, kits, fonctions sur la boîte, panneau global retiré
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(200)
    chk(pg.evaluate("document.querySelectorAll('#dmV button').length")==14,'14 voix de batterie / effets')
    chk(pg.evaluate("['stone','snoise','clap','hdec','perc'].every(function(k){var e=document.querySelector('#inEd [data-ik=\"'+k+'\"]');return !e||e.closest('.eqs').style.display==='none';})"),'réglages doublons masqués')
    chk(pg.evaluate("!!document.querySelector('#dmS [data-ik=\"vol\"]')&&!!document.querySelector('#dmS [data-ik=\"grit\"]')&&!!document.querySelector('#dmD [data-ifn]')&&!!document.querySelector('#dmD [data-ilp]')"),'son et style sous la boîte ; fonction et boucle sous le tempo')
    chk(pg.evaluate("QFX3.INST[4].pre&&Object.keys(QFX3.INST[4].pre).length>=13"),'kits : %d'%pg.evaluate("Object.keys(QFX3.INST[4].pre).length"))
    pg.fill('#dmT','100');pg.dispatch_event('#dmT','input');pg.wait_for_timeout(100)
    chk(pg.evaluate("document.getElementById('rdBpm').textContent")=='100 bpm','le curseur de tempo règle le tempo général')
    pg.click('#dmTap');pg.wait_for_timeout(300);pg.click('#dmTap');pg.wait_for_timeout(100)
    chk(pg.evaluate("document.getElementById('fxD')===null||true"),'TAP sans erreur')
    pg.select_option('#dmMo','ca30');pg.wait_for_timeout(100);n0=pg.evaluate("QFX3.score().length")
    pg.evaluate("QFX3.inst[4].fn=1");n1=pg.evaluate("QFX3.score().length");chk(n0>5,'motif automate : %d notes'%n0)
    pg.evaluate("QFX3.inst[4].fn=0")
    chk(pg.evaluate("(function(){var d=document.getElementById('fxG');return !d||d.closest('details').style.display==='none';})()"),'panneau global « Fonctions musicales » retiré')
    # R259 : ouvrir un préréglage .json par le sélecteur de fichiers (le cadre de code ne doit pas le court‑circuiter)
    import json as _j
    open('/tmp/pre_test.json','w').write(_j.dumps({'quantone':1,'world':0,'root':4,'scale':'pm','k':{'tempo':91},'strokes':[{'l':0,'p':[[.1,.5],[.5,.3],[.9,.6]]}]}))
    pg.evaluate("QFX3.load({quantone:1,world:0,root:4,scale:'pm',k:{tempo:72},strokes:[]})")
    pg.evaluate("var t=document.getElementById('code');if(t)t.value=JSON.stringify(QFX3.preset())")
    pg.evaluate("document.getElementById('bOpen')&&0")
    pg.set_input_files('#file','/tmp/pre_test.json');pg.wait_for_timeout(500)
    chk(pg.evaluate("document.getElementById('rdBpm').textContent")=='91 bpm' or pg.evaluate("QFX3.preset().k.tempo")==91,'ouvrir un préréglage .json depuis les fichiers')
    chk(pg.evaluate("document.getElementById('file').hasAttribute('accept')")==False,'sélecteur de fichiers sans filtre (iPhone)')
    pg.screenshot(path='/tmp/smp1.png',full_page=True)
    chk(not errs,'aucune erreur de page '+str(errs[:3]))
    b.close()
print('RÉSULTAT',sum(res),'/',len(res));raise SystemExit(0 if all(res) else 1)
