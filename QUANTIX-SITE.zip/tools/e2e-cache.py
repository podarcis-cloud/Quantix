# R388b : Track dans un cadre préchargé ; Pattern jamais déchargé ; bibliothèque rafraîchie à l'ouverture
import sys
from playwright.sync_api import sync_playwright
Q='http://localhost:8765/studio/quantone.html';ok=0;n=0
def T(name,c):
    global ok,n;n+=1;ok+=bool(c);print(('OK   ' if c else 'FAIL ')+name)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);c=b.new_context(viewport={'width':390,'height':780},has_touch=True,is_mobile=True);pg=c.new_page();er=[]
    pg.on('pageerror',lambda e:er.append(str(e)))
    pg.add_init_script("try{if(top===window)localStorage.setItem('qx.frame','1');localStorage.setItem('qx.proj','Alpha')}catch(e){}")
    pg.goto(Q);pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.echo=.42;q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q);window.__mark=7;})()")
    pg.wait_for_timeout(5800)
    T('cadre Track préchargé (caché)',pg.evaluate("(()=>{var f=document.getElementById('qTrackFrame');return !!f&&f.style.display==='none'})()"))
    pg.evaluate("QLIBSAVE('Capture X',function(){},'Alpha')");pg.wait_for_timeout(300)
    T('≡＋ en cours : indicateur actif',pg.evaluate('window.QCAPBUSY===true'))
    pg.evaluate("document.getElementById('qFloat').click()")
    T('Track ▸ patiente pendant la capture',pg.evaluate("[document.getElementById('qTrackFrame').style.display,document.getElementById('qFloat').textContent]")[0]=='none' or not pg.evaluate('window.QCAPBUSY'))
    for i in range(300):
        if pg.evaluate("document.getElementById('qTrackFrame').style.display")=='block':break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(1500)
    T('Track ▸ affiche Track sans quitter la page',pg.url.endswith('quantone.html') and pg.evaluate("document.getElementById('qTrackFrame').style.display")=='block')
    fr=[f for f in pg.frames if 'morceau' in f.url][0]
    opts=fr.evaluate("[...document.querySelectorAll('#patSel option')].map(x=>x.textContent)")
    T('bibliothèque à jour dans Track (%s)'%[o for o in opts if 'Capture' in o],any('Capture X' in o for o in opts))
    T('Track vide',fr.evaluate("MORCEAU.P().clips.length")==0)
    fr.evaluate("window.__m=5;document.getElementById('bQt').click()");pg.wait_for_timeout(600)
    T('retour : cadre caché',pg.evaluate("document.getElementById('qTrackFrame').style.display")=='none')
    s=pg.evaluate("QXIO.build().preset");T('Pattern intacte, page jamais rechargée',pg.evaluate("window.__mark")==7 and len(s['strokes'])==1 and abs(s['k']['echo']-.42)<.01)
    pg.evaluate("document.getElementById('qFloat').click()");pg.wait_for_timeout(600)
    T('Track gardé en cache (même instance)',fr.evaluate("window.__m")==5)
    cdp=c.new_cdp_session(pg)
    cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':60,'y':30}]})
    for i in range(1,7):cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':60+270*i/6,'y':30}]})
    cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});pg.wait_for_timeout(700)
    T('glissement dans Track → retour',pg.evaluate("document.getElementById('qTrackFrame').style.display")=='none')
    pg.evaluate("window.dispatchEvent(new Event('pagehide'))");pg.wait_for_timeout(600)
    pg.reload();pg.wait_for_timeout(2500)
    s=pg.evaluate("QXIO.build().preset");T('page fermée puis rouverte (même onglet) : Pattern retrouvée seule',len(s['strokes'])>=1 and abs(s['k']['echo']-.42)<.01)
    pg.evaluate("document.dispatchEvent(new Event('visibilitychange'))")
    T('aucune erreur de page',not er)
    if er:print(er[:3])
    b.close()
print('RÉSULTAT %d / %d'%(ok,n));sys.exit(0 if ok==n else 1)
