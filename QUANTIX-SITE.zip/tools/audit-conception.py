#!/usr/bin/env python3
"""audit-conception.py — rapport de conception : docs/audit-conception.json (utilité des éléments) + docs/audit-meta.json (signatures)
→ docs/AUDIT_CONCEPTION.md. Usage : python3 tools/audit-conception.py"""
import json,collections,math,os
R='/home/claude/q2/docs/'
A=json.load(open(R+'audit-conception.json'));M=json.load(open(R+'audit-meta.json'))
BY={m['i']:m for m in M}
C=json.load(open(R+'audit-contact.json'))
def cls(k,e):
    if e['k']=='méca':return 'méca sans effet'
    for c in C.get(str(k),[]):
        if c['lab']==e['lab']:
            near=(c['dRef'] is not None and c['dRef']<12) or (c['nearRnd'] or 0)>0
            return 'approché mais redondant' if near else 'jamais approché'
    return 'méca sans effet'
CAT={'zone interdite':['nd'],'forces':['wind','grav','mag','flow','vortex','updraft','well','curves'],'transport':['port','ent','gate','rails','sling','wrap'],
 'quantique':['sup','det','tdil','mz','rec'],'corps/cordes':['elastic','softball','strings','strE','pend','coil','bf'],'mobile':['mov','fork','kick','spectro']}
def cats(m):
    c=[k for k,v in CAT.items() if any(x in m['mech'] for x in v)]
    if m['ns']>=2:c.append('multi-traits')
    return c or ['rebond simple']
def sim(a,b):
    ma,mb=set(a['mech']),set(b['mech']);j=len(ma&mb)/len(ma|mb) if ma|mb else 1
    s=.45*j+(.1 if a['ns']==b['ns'] else 0)+(.1 if a['mat']==b['mat'] else 0)
    if a['ang'] is not None and b['ang'] is not None:
        d=abs((a['ang']-b['ang']+180)%360-180);s+=.15*max(0,1-d/45)
        if a['len'] and b['len']:s+=.2*max(0,1-abs(a['len']-b['len'])/max(a['len'],b['len'])/.4)
    return s
# --- éléments ---
tot=collections.Counter();per={}
for k,v in A.items():
    c=collections.Counter(e['verdict'].split(' + ')[0] if e['verdict'] not in('indispensable','sans effet','non testé') else e['verdict'] for e in v['elems']);per[int(k)]=c;tot.update(c)
useless=[(int(k),e) for k,v in A.items() for e in v['elems'] if e['verdict']=='sans effet']
UC=collections.Counter(cls(k,e) for k,e in useless)
L=[]
P=L.append
P('# Audit de conception des niveaux (R298, 25 oct. 2026)\n')
P('Méthode : pour chaque niveau, on retire un élément à la fois (zone interdite, mur, mécanique entière) et on regarde (a) si la solution de référence réussit encore, (b) si des lignes droites tirées au hasard (400, appariées) réussissent davantage. **Limites** : test à un seul trait aléatoire + la référence ; un élément « sans effet » peut pourtant guider le regard, servir le scénario ou gêner des solutions à plusieurs traits. À confirmer à l\'œil avant de supprimer.\n')
P('## 1. Utilité des éléments (%d niveaux, %d éléments)\n'%(len(A),sum(tot.values())))
for k in ['indispensable','filtre',"sert l'étoile",'sans effet','non testé']:P('- %s : %d'%(k,tot.get(k,0)))
P('\nParmi les « sans effet » (%d) : **jamais approchés par la balle : %d** (obstacles morts ou purement décoratifs) · approchés mais redondants : %d · mécaniques sans effet mesurable : %d\n'%(len(useless),UC['jamais approché'],UC['approché mais redondant'],UC['méca sans effet']))
P('Niveaux dont la référence est ABSENTE ou échoue à l\'état actuel : '+', '.join('N%s'%k for k,v in sorted(A.items(),key=lambda x:int(x[0])) if v['refOk'] is not True)+'\n')
# --- par monde ---
P('## 2. Par monde : variété, éléments inutiles, redondance\n')
P('| Monde | Mécaniques distinctes | Types de réflexion | Éléments sans effet | Paires quasi identiques |')
P('|---|---|---|---|---|')
pairs=[]
ids=sorted(BY)
for i in ids:
    for j in ids:
        if j<=i:continue
        s=sim(BY[i],BY[j])
        if s>=.85 and BY[i]['ns']>0 and BY[j]['ns']>0:pairs.append((s,i,j))
pairs.sort(reverse=True)
for w in sorted({m['wd'] for m in M}):
    lv=[m for m in M if m['wd']==w];mech=sorted({x for m in lv for x in m['mech']});ct=collections.Counter(c for m in lv for c in cats(m))
    u=sum(1 for k,e in useless if BY[k]['wd']==w);pp=sum(1 for s,i,j in pairs if BY[i]['wd']==w and BY[j]['wd']==w)
    P('| %d | %d (%s) | %s | %d | %d |'%(w,len(mech),', '.join(mech),', '.join('%s %d'%x for x in ct.most_common(5)),u,pp))
P('\n## 3. Redondance : niveaux quasi identiques (signature ≥ 0,85)\n')
P('Même ensemble de mécaniques + même forme de solution de référence (nombre de traits, matière, angle, longueur). Le joueur refait la même réflexion.\n')
for s,i,j in pairs[:40]:P('- N%d « %s » ≈ N%d « %s » (%.2f)%s'%(i,BY[i]['n'],j,BY[j]['n'],s,'  — même monde' if BY[i]['wd']==BY[j]['wd'] else ''))
if len(pairs)>40:P('- … %d paires au total'%len(pairs))
# --- nouveauté ---
P('\n## 4. Apport de nouveauté par niveau\n')
seen=set();news=[];flat=[]
for i in ids:
    m=BY[i];new=[x for x in m['mech'] if x not in seen];seen|=set(m['mech'])
    best=max([sim(m,BY[j]) for j in ids if j<i]+[0])
    if new:news.append((i,new))
    if best>=.8 and not new:flat.append((i,best))
P('Mécaniques à leur première apparition : '+'; '.join('N%d %s'%(i,'+'.join(n)) for i,n in news)+'\n')
P('Niveaux sans mécanique nouvelle ET très proches d\'un niveau antérieur (≥ 0,80) : %d — %s\n'%(len(flat),', '.join('N%d'%i for i,_ in flat)))
# --- éléments sans effet ---
P('## 5. Éléments sans effet à examiner (obstacles probablement décoratifs ou mal placés)\n')
cn=collections.defaultdict(list);dead=collections.defaultdict(list)
for k,e in useless:
    c=cls(k,e);cn[k].append(e['lab']+' ['+c+']')
    if c=='jamais approché':dead[k].append(e['lab'])
P('**Jamais approchés** (la référence et 150 tracés au hasard ne passent jamais à moins de 12 u) : candidats à supprimer, déplacer ou à justifier visuellement.\n')
for k in sorted(dead):P('- N%d « %s » : %s'%(k,BY[k]['n'],' ; '.join(dead[k])))
P('\n**Approchés mais sans effet / mécaniques sans effet** : à regarder au cas par cas.\n')
for k in sorted(cn):
    o=[x for x in cn[k] if 'jamais approché' not in x]
    if o:P('- N%d « %s » : %s'%(k,BY[k]['n'],' ; '.join(o)))
# --- priorités ---
P('\n## 6. Niveaux à retravailler en priorité\n')
sc=[]
for i in ids:
    s=0;why=[]
    u=len(dead.get(i,[]))
    if u:s+=u;why.append('%d obstacle(s) jamais approché(s)'%u)
    if i in {a for a in flat and [x for x,_ in flat]}:s+=2;why.append('redondant')
    if any(i in (p[1],p[2]) for p in pairs if p[0]>=.9):s+=2;why.append('doublon')
    v=A.get(str(i))
    if v and v['refOk'] is not True:s+=2;why.append('référence manquante/échoue')
    if s:sc.append((s,i,why))
sc.sort(reverse=True)
for s,i,why in sc[:30]:P('- N%d « %s » (monde %d) — %s'%(i,BY[i]['n'],BY[i]['wd'],', '.join(why)))
open(R+'AUDIT_CONCEPTION.md','w',encoding='utf-8').write('\n'.join(L)+'\n');print('ok',len(L),'lignes')
