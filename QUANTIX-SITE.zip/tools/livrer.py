"""livrer.py — R97 : livraison en une commande. Tampon de version, tests essentiels (sans les suites lourdes),
compte rendu, banc d'essai (aperçu du monde courant + panneau), zip, copie des documents.
Usage : python3 tools/livrer.py R97 "libellé" MONDE"""
import subprocess,sys,os,re
H=os.path.dirname(os.path.abspath(__file__));Q=H+'/..';V,lab,W=sys.argv[1],sys.argv[2],sys.argv[3]
idx=open(Q+'/index.html',encoding='utf-8').read();idx=re.sub(r'build R\d+ · [^<"]*','build %s · %s'%(V,lab),idx,1);open(Q+'/index.html','w',encoding='utf-8').write(idx)
eng=open(Q+'/assets/js/engine.js',encoding='utf-8').read();eng=re.sub(r'QUANTIX build R\d+','QUANTIX build '+V,eng,1);open(Q+'/assets/js/engine.js','w',encoding='utf-8').write(eng)
bad=[]
for t in ['audit','strict','replaytest','tutotest','monde'+W]:
    o=subprocess.run(['node',t+'.js'],cwd=H,capture_output=True,text=True,timeout=250).stdout
    if 'ÉCHEC' in o:bad.append(t)
print('tests :','OK' if not bad else 'ÉCHEC '+','.join(bad))
print(subprocess.run(['python3','rapport-finition.py'],cwd=H,capture_output=True,text=True).stdout.splitlines()[0])
s=open(H+'/banc-panel.html',encoding='utf-8').read();s=re.sub(r'Banc d’essai R\d+','Banc d’essai '+V,s);s=re.sub(r'BANC D’ESSAI · R\d+','BANC D’ESSAI · '+V,s)
open(H+'/banc-panel.html','w',encoding='utf-8').write(s)
subprocess.run(['python3',H+'/build-apercu.py',W,'11','skipintro'],check=True,capture_output=True)
h=open('/mnt/user-data/outputs/quantix-apercu-monde%s.html'%W,encoding='utf-8').read().replace('</body>',s+'</body>',1)
open('/mnt/user-data/outputs/quantix-banc-essai.html','w',encoding='utf-8').write(h)
z='/mnt/user-data/outputs/QUANTIX-%s.zip'%V
subprocess.run('rm -f /mnt/user-data/outputs/QUANTIX-R*.zip; cd /home/claude && zip -qr %s q && cp q/docs/FINITION.md q/docs/REPRISE-SESSION.md q/docs/MONDE7_FICHES.md /mnt/user-data/outputs/'%z,shell=True,check=True)
print('livré :',z)
