"""parcours-rapport.py DOSSIER_JSON [N1 N2…] — rapport sur les parcours bêta (docs exportés de la collection parcours_beta par ArtifactData out_dir).
Par niveau : essais/issues, encre utilisée vs max vs solution de référence (optsol), usage des outils (tl), écart de tracé à la
géodésique (distance moyenne entre polylignes, ratio d'encre, nb de traits, matière), familles de tracés (même pente/zone de départ),
contournements suspects (réussite avec encre << référence, ou trait sans rapport avec la référence)."""
import sys,re,json,glob,math,collections
D=sys.argv[1];only={int(x) for x in sys.argv[2:]}
src=open('/home/claude/q2/assets/js/levels.js',encoding='utf-8').read()
ents=[m.start() for m in re.finditer(r'^\{wd:',src,re.M)];REF={}
for k,a in enumerate(ents):
    e=src[a:ents[k+1] if k+1<len(ents) else len(src)]
    m=re.search(r"optsol:(\[\[\[.*?\]\]\]),optmat:(\d+)",e)
    mi=re.search(r"\bink:(\d+)",e)
    if m:
        try:REF[k+1]={'p':json.loads(m.group(1)),'mat':int(m.group(2)),'ink':int(mi.group(1)) if mi else None}
        except Exception:pass
def plen(p):return sum(math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]) for i in range(1,len(p)))
def pts(s):p=s['p'];return [[p[i],p[i+1]] for i in range(0,len(p)-1,2)]
def samp(p,n=24):
    L=plen(p) or 1;o=[];t=0;i=1;a=p[0]
    for k in range(n):
        d=L*k/(n-1)
        while i<len(p)-1 and t+math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1])<d:t+=math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);i+=1
        q=p[i-1];r=p[i];seg=math.hypot(r[0]-q[0],r[1]-q[1]) or 1;u=min(1,max(0,(d-t)/seg));o.append([q[0]+(r[0]-q[0])*u,q[1]+(r[1]-q[1])*u])
    return o
def dist(A,B):
    """distance moyenne point→polyligne la plus proche (symétrisée), en px"""
    a,b=samp(A),samp(B)
    f=lambda X,Y:sum(min(math.hypot(x[0]-y[0],x[1]-y[1]) for y in Y) for x in X)/len(X)
    return (f(a,b)+f(b,a))/2
R=[json.load(open(f)) for f in glob.glob(D.rstrip('/')+'/*.json')]
by=collections.defaultdict(list)
for d in R:by[d['lvl']].append(d)
print('# Rapport parcours bêta —',len(R),'essais,',len({d['pid'] for d in R}),'joueur(s),',len(by),'niveaux\n')
tools=collections.Counter();modes=collections.Counter()
for d in R:
    for k,v in (d.get('tl') or {}).get('o',{}).items():tools[k]+=v
    for m in (d.get('tl') or {}).get('m',[]):modes[m]+=1
print('Outils (opérations) :',dict(tools) or 'aucune donnée (essais avant R287)','· modes choisis :',dict(modes) or '-','\n')
for l in sorted(by):
    if only and l not in only:continue
    v=sorted(by[l],key=lambda d:(d['at'],d['n']));ok=[d for d in v if d['r']=='ok'];ref=REF.get(l)
    iss=''.join('o' if d['r']=='ok' else 'a' if d['r']=='abandon' else 'x' for d in v)
    fails=collections.Counter(d['r'] for d in v if d['r'] not in('ok','abandon'))
    u=lambda d:d.get('ink2') if d.get('ink2') is not None else d['ink']
    line=f"N{l} {v[0].get('nom','')[:18]:18} {iss:10} max {v[0]['mx']}"
    if ok:
        best=min(ok,key=u);line+=f" · encre réussite {u(best)} ({round(100*u(best)/v[0]['mx'])} %)"
    if ref:line+=f" · réf {round(sum(plen(q) for q in ref['p']))}"
    if fails:line+=f" · échecs {dict(fails)}"
    print(line)
    for d in ok:
        S=d['s'];tl=d.get('tl') or {}
        info=f"   essai {d['n']}: {len(S)} trait(s), mat {sorted({s['m'] for s in S})}, encre {u(d)}"
        if ref:
            rp=ref['p'][0];best=min(((dist(pts(s),rp),s) for s in S),key=lambda z:z[0])
            info+=f" · écart géodésique {best[0]:.0f}px, mat réf {ref['mat']}, traits ×{len(S)}/{len(ref['p'])}"
            if u(d)<0.6*sum(plen(q) for q in ref['p']):info+=" · ⚠ encre << réf (contournement ?)"
            if best[0]>45:info+=" · ⚠ famille différente de la réf"
        if tl:info+=f" · outils {tl.get('o')} {tl.get('m')}"
        print(info)
print('\nFamilles : regrouper les réussites par (zone de départ ±30 px, pente ±20°, matière) quand ≥3 joueurs ont joué un niveau.')
