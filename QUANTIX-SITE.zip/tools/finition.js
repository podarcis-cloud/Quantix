/* finition.js — R91 : état de finition de chaque niveau, mesuré (pas déclaré).
   Pour chaque niveau : solution de référence enregistrée et rejouée ; plus petit trait gagnant (1 200 traits au hasard) ;
   raccourci « ligne directe » (particule → zone, chaque matière offerte) ; mécanique indispensable (mondes à champ) ;
   zone de réussite dégagée. Sortie JSON (OUT) pour le compte rendu.  Usage : OUT=finition.json node finition.js 1 2 … */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const FIELDS=['wind','grav','mag','port','mov','ent','gate','sup','det','tdil'],COST={0:1,1:1.9,3:1.7,5:1},MINLEN=p=>p<=3?40:p<=8?80:120;
let seed=5;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
const out=process.env.OUT||'finition.json',R=fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{};
function zoneBad(L){const [x,y,w]=L.cup,r=[x+4,y-52,w-8,50];const segs=(L.w||[]).slice();(L.curves||[]).forEach(cv=>{for(let i=1;i<cv.pts.length;i++)segs.push([...cv.pts[i-1],...cv.pts[i]]);});
 return segs.some(s=>{for(let k=0;k<=20;k++){const px=s[0]+(s[2]-s[0])*k/20,py=s[1]+(s[3]-s[1])*k/20;if(px>r[0]&&px<r[0]+r[2]&&py>r[1]&&py<r[1]+r[3])return true;}return false;});}
for(const a of process.argv.slice(2)){const idx=+a-1,pos=idx%12+1,L=JSON.parse(JSON.stringify(X.LEVELS[idx]));
 const c={ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w,softball:L.softball,curves:L.curves,mz:L.mz};for(const f of FIELDS)if(L[f])c[f]=L[f];
 const mats=[0].concat((L.pal||'').includes('B')?[1]:[]).concat((L.pal||'').includes('A')?[3]:[]).concat((L.pal||'').includes('C')?[5]:[]);
 const r0={n:L.n,wd:L.wd,pos};
 r0.sol=!!L.optsol;r0.solOk=L.optsol?LAB.run(idx,c,L.optsol.map(p=>({pts:p,mat:L.optmat||0}))).ok:false;
 r0.alone=LAB.run(idx,c,[]).ok;
 let minL=1e9;for(let t=0;t<1200;){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,an=rnd()*6.2832,l=8+rnd()*Math.min(200,L.ink/(COST[m]||1)),
  p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(an)*l),Math.round(y+Math.sin(an)*l)]];if(!D.drawable(c,p))continue;t++;if(l<minL&&LAB.run(idx,c,[{pts:p,mat:m}]).ok)minL=l;}
 r0.minLen=minL<1e9?Math.round(minL):null;r0.trivial=minL<MINLEN(pos);
 let direct=0;for(const m of mats)for(const dy of [14,30])for(const tx of [.2,.5,.8])for(const ty of [-24,-6]){const p=[[L.ball[0],L.ball[1]+dy],[Math.round(L.cup[0]+L.cup[2]*tx),L.cup[1]+ty]];
  if(!D.drawable(c,p))continue;const len=Math.hypot(p[1][0]-p[0][0],p[1][1]-p[0][1])*(COST[m]||1);if(len>c.ink)continue;if(LAB.run(idx,c,[{pts:p,mat:m}]).ok)direct++;}
 r0.direct=direct;
 const hasF=FIELDS.some(f=>c[f]&&c[f].length);if(hasF&&L.optsol){const s=JSON.parse(JSON.stringify(c));FIELDS.forEach(f=>{if(s[f])s[f]=[];});r0.fieldNeeded=!LAB.run(idx,s,L.optsol.map(p=>({pts:p,mat:L.optmat||0}))).ok;}
 r0.zoneOk=!zoneBad(L);
 R[a]=r0;fs.writeFileSync(out,JSON.stringify(R,null,1));
 console.log(`#${a} ${L.n.padEnd(22)} sol:${r0.solOk?'ok':r0.sol?'ÉCHOUE':'—'} min:${r0.minLen} direct:${direct} champ:${r0.fieldNeeded===undefined?'—':r0.fieldNeeded?'oui':'NON'} zone:${r0.zoneOk?'ok':'✗'}`);}
