"""valide.py N plan.json [MACHINE=EX,EY,ER] [ZONE=x0,y0,x1,y1] — R118 : tout ce qui suit fiche.js, en UNE commande et un résumé.
installation (slotwrite) → énigme (+ statut) → finition → jouabilité → constance (si machine) → noyau (noyau2, zone) → test du monde → état."""
import subprocess,sys,os,json,re
H=os.path.dirname(os.path.abspath(__file__));N=sys.argv[1];plan=sys.argv[2];opt=dict(a.split('=',1) for a in sys.argv[3:])
def run(cmd,t=280,env=None):
    e=dict(os.environ);e.update(env or {});r=subprocess.run(cmd,cwd=H,capture_output=True,text=True,timeout=t,env=e);return r.stdout+r.stderr
def line(o,pre='#'):return ' '.join(l for l in o.splitlines() if l.startswith(pre))
out=[]
o=run(['python3','slotwrite.py',plan]);out.append('installation : '+('OK' if 'OK #' in o else o[-150:]))
o=line(run(['node','enigme.js',N]));ok='ÉNIGME ✓' in o;out.append('énigme : '+o.split('  ',1)[-1][:150])
e=json.load(open(H+'/enigme_status.json'));s=set(e['ok']);(s.add if ok else s.discard)(int(N));e['ok']=sorted(s);json.dump(e,open(H+'/enigme_status.json','w'),ensure_ascii=False)
out.append('finition : '+line(run(['node','finition.js',N]))[-60:])
reg=json.load(open(H+'/fiches/registre.json'));fk=json.load(open(H+'/forge.json')).get(N+'_fiche')
if fk:reg.setdefault(N,{})['jeu']=fk['optsol'];json.dump(reg,open(H+'/fiches/registre.json','w'),ensure_ascii=False,indent=1)
if 'MACHINE' in opt and fk:
    ex,ey,er=opt['MACHINE'].split(',');fiche=opt.get('FICHE',N)
    P=json.dumps(json.load(open(H+'/forge.json'))[N+'_fiche'].get('P') or json.loads(opt['P']))
    o=run(['node','constance.js',fiche,N,P],env={'EX':ex,'EY':ey,'ER':er});out.append('machine : '+o.strip().splitlines()[-1][-80:])
    m=re.search(r'\((\d+) %\)',o)
    if m:reg=json.load(open(H+'/fiches/registre.json'));reg.setdefault(N,{}).setdefault('machine',{})
    if m and isinstance(reg[N]['machine'],dict):reg[N]['machine']['constance']=int(m.group(1))/100;json.dump(reg,open(H+'/fiches/registre.json','w'),ensure_ascii=False,indent=1)
z=opt.get('ZONE','0,0,360,480');o=run(['node','noyau2.js',N,z]).strip().splitlines()[-1] if opt.get('NOYAU') else '';out.append('noyau : '+(o[o.find('|')+2:][:170] if o else 'sur la trajectoire de la fiche (§9 : optimisation 15–35 % reportée)'))
m=re.search(r'noyau \[(\d+),(\d+)\] \((\d+) %.*?sol (\[\[-?\d+,-?\d+\](?:,\[-?\d+,-?\d+\])*\])',o)
if m:
    run(['python3','setlv.py',N,'star:[%s,%s]'%(m.group(1),m.group(2)),'optsol:['+m.group(4)+']'])
    reg=json.load(open(H+'/fiches/registre.json'));reg.setdefault(N,{})['noyau']={'f':int(m.group(3))/100,'pos':[int(m.group(1)),int(m.group(2))]};json.dump(reg,open(H+'/fiches/registre.json','w'),ensure_ascii=False,indent=1)
out.append('jouabilité : '+line(run(['node','difficulty.js',N],env={'OUT':'difficulty_R116.json'}))[25:110])
w=(int(N)-1)//12+1;o=run(['node','monde%d.js'%w]);out.append('monde %d : '%w+(o.strip().splitlines()[-1] if o.strip() else '?'))
out.append('état : '+run(['python3','etat.py']).strip().splitlines()[-1][:60])
st=open(H+'/../docs/ETAT_REFONTE_NIVEAUX.md',encoding='utf-8').read();m=re.search(r'^\| %s \|.*$'%N,st,re.M);out.append('ligne : '+(m.group(0)[-160:] if m else '?'))
print('\n'.join(out))
