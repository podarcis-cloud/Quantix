/* Charge le jeu hors navigateur : concatène les quatre scripts dans l'ordre
   de index.html, installe un faux DOM, et expose globalThis.__X.
   Usage : require('./load.js') depuis site/tools/. */
const fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..');
const FILES=['worldart.js','i18n.js','levels.js','visuals.js','tuto.js','editor.js','engine.js'];
const HTML=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
const IDS=new Set([...HTML.matchAll(/id="([A-Za-z0-9_-]+)"/g)].map(m=>m[1]));
const store={};
function fake(id){const o={id,style:{setProperty(){},display:''},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(s){return s==='i'?[{className:''},{className:''},{className:''}]:[];},
 querySelector(){return null;},
 getBoundingClientRect(){return{left:0,top:0,width:300,height:300};},
 firstElementChild:{innerHTML:''},insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>/create(Radial|Linear)Gradient/.test(k)?()=>({addColorStop(){}}):()=>{}});},
 set innerHTML(v){o._html=v;},get innerHTML(){return o._html||'';},
 set textContent(v){o._t=v;},get textContent(){return o._t||'';},
 set width(v){o._w=v;},get width(){return o._w;},
 set height(v){o._h=v;},get height(){return o._h;},
 get clientWidth(){return 360;},get clientHeight(){return 480;}};return o;}
global.window={matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener(){},ResizeObserver:null};
Object.defineProperty(globalThis,'navigator',{configurable:true,writable:true,value:{}});
global.document={getElementById:id=>IDS.has(id)?(store[id]||(store[id]=fake(id))):null,
 addEventListener(){},documentElement:{lang:'fr'},querySelectorAll(){return [];},
 createElement(){return {width:0,height:0,getContext(){return new Proxy({},{get:(t,k)=>/create(Radial|Linear)Gradient/.test(k)?()=>({addColorStop(){}}):()=>{}});},
   toDataURL(){return 'data:image/png;base64,AA';}};}};
global.Image=function(){return {set src(v){this._s=v;},get src(){return this._s;}};};
global.Audio=function(u){return {src:u,preload:'',volume:1,currentTime:0,loop:false,
  setAttribute(){},addEventListener(){},pause(){},play(){return Promise.resolve();}};};
global.localStorage={getItem:()=>null,setItem(){},removeItem(){}};
global.atob=s=>Buffer.from(s,'base64').toString('binary');
global.Blob=function(){};global.URL={createObjectURL:()=>'blob:x'};
global.requestAnimationFrame=f=>{(global.__raf=global.__raf||[]).push(f);};
const src=FILES.map(f=>fs.readFileSync(path.join(ROOT,'assets/js',f),'utf8')).join('\n;\n');
/* R201 : toute erreur de rendu attrapée par la boucle du moteur est mémorisée, pour que les bancs échouent franchement */
const _ce=console.error;console.error=function(){if(String(arguments[0]).indexOf('rendu')===0)(global.__renderErr=global.__renderErr||[]).push(arguments[1]);return _ce.apply(console,arguments);};
(0,eval)(src);
if(global.window.VX&&!global.VX)global.VX=global.window.VX;   /* comme dans le navigateur : window.VX est un global */
module.exports={store,IDS,FILES};
