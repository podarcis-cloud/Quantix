# Automation universelle (R376) : toute commande (curseur, menu, bouton on/off) a une clé d'automation
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
EXEMPT=['qLibPj','ifxAdd','xyX','xyY','smDev','smPW','smPS']   # ajout d'effet, choix de pads XY, entrée micro, pages d'échantillons, projet de bibliothèque
JS="""(EX)=>{const bad=[];document.querySelectorAll('input[type=range],select').forEach(el=>{if(EX.indexOf(el.id)>=0)return;const k=QAUTO.key(el);if(!(k&&k.length&&k[0])){bad.push((el.tagName+'#'+el.id+'['+(el.dataset.k||el.dataset.ik||el.dataset.dk||el.dataset.ef||el.dataset.eq||'')+']'));}});return bad;}"""
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(900)
    pg.evaluate("(()=>{const st=QUANTONE.state;st.strokes=[{layer:0,pts:Array.from({length:20},(_,i)=>[.1+i*.04,.5,i*30])},{layer:4,pts:Array.from({length:20},(_,i)=>[.1+i*.04,.9,i*30])}]})()")
    for name,act in [('base',''),('instrument 0','QFX3.open(0)'),('instrument 9','QFX3.open(9)'),('boîte','QFX3.open(4)')]:
        if act:pg.evaluate(act);pg.wait_for_timeout(400)
        bad=pg.evaluate(JS,EXEMPT);chk(not bad,'%s : toute commande a une clé %s'%(name,bad[:4]))
    pg.evaluate("QFX3.open(0)");pg.wait_for_timeout(300)
    pg.evaluate("(()=>{const s=document.getElementById('ifxAdd');s.value=[...s.options].find(o=>o.value&&o.value.indexOf('c:')!==0&&o.value!=='').value;s.dispatchEvent(new Event('change',{bubbles:true}))})()");pg.wait_for_timeout(300)
    bad=pg.evaluate(JS,EXEMPT);chk(not bad,'après ajout d’un effet : curseurs Fx automatisables %s'%bad[:4])
    k=pg.evaluate("(()=>{const r=document.querySelector('#ifxBox .fxc input[data-k]');return QAUTO.key(r)})()")
    chk(k and k[0].startswith('ifx:0:0:'),'clé Fx = ifx:instrument:rang:paramètre (%s)'%k)
    r=pg.evaluate("""(()=>{const key=%s,d=QAUTO.desc(key);if(!d)return null;const fx=QUANTONE.state.inst[0].fx[0],p=key.split(':')[3];d.set(1);const a=fx[p];d.set(0);const z=fx[p];return [a,z,d.step,typeof d.fmt(.5)]})()"""%repr(k[0]) if k else "null")
    chk(r and r[0]!=r[1],'ifx : set(1)/set(0) change la valeur de l’effet %s'%r)
    ko=pg.evaluate("(()=>QAUTO.key(document.querySelector('#ifxBox .fxc [data-a=on]')))()")
    chk(ko and ko[0]=='ifxon:0:0','bouton on/off de l’effet a une clé (%s)'%ko)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('ifxon:0:0');d.set(0);const a=QUANTONE.state.inst[0].fx[0].on;d.set(1);return [a,QUANTONE.state.inst[0].fx[0].on]})()")
    chk(r[0]==0 and r[1]==1,'ifxon : désactive puis réactive l’effet %s'%r)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('oct');const o=d.get();d.set(1);const a=document.getElementById('sOct').value;d.set(0);return [a,document.getElementById('sOct').value]})()")
    chk(r[0]!=r[1],'oct : le menu d’étendue suit l’automation %s'%r)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('isc:0');d.set(1);const a=QUANTONE.state.inst[0].sc;d.set(0);return [a,QUANTONE.state.inst[0].sc||null]})()")
    chk(r[0] and not r[1],'isc : gamme d’instrument (valeur puis retour au monde) %s'%r)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('isr:0');d.set(0);const a=QUANTONE.state.inst[0].rt;d.set(1);return [a,QUANTONE.state.inst[0].rt]})()")
    chk(r[0]==0 and r[1]==11,'isr : tonique d’instrument 0→11 %s'%r)
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(400)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('dsm:0');if(!d)return null;d.set(1);const a=QUANTONE.state.dm?QUANTONE.state.dm.rows[0].smp:null;d.set(0);return [a,QUANTONE.state.dm.rows[0].smp|0]})()")
    chk(r and r[0]==8 and r[1]==0,'dsm : échantillon de voix 0↔8 %s'%r)
    r=pg.evaluate("(()=>{const d=QAUTO.desc('dk:0:atk');if(!d)return null;d.set(1);const a=QUANTONE.state.dm.rows[0].atk;d.set(0);return [a,QUANTONE.state.dm.rows[0].atk||0]})()")
    chk(r and r[0]>0 and r[1]==0,'atk : attaque de la voix automatisable %s'%r)
    chk(not er,'aucune erreur page %s'%er[:2])
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
