# Ouverture (R364) : animation de dessin, son d'ouverture au premier geste, grésillement des traits repassés, boîte à rythmes compacte, sampler
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.add_init_script("window.QINTRO_FORCE=1")
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(300)
    chk(pg.evaluate("!!window.QINTRO&&window.QINTRO.list.length==3"),"animation d'ouverture armée sur les 3 traits par défaut")
    pg.mouse.click(5,5);pg.wait_for_timeout(1200)
    chk(pg.evaluate("QUANTONE.level()")>.003,"le son d'ouverture sonne après le premier geste")
    pg.wait_for_timeout(3500);chk(pg.evaluate("window.QINTRO")is None,"l'animation se termine d'elle-même")
    pg.evaluate("(()=>{const st=QUANTONE.state,s=st.strokes[0];for(let i=0;i<3;i++)st.strokes.push({layer:0,pts:s.pts.map(p=>[p[0]+(Math.random()-.5)*.006,p[1]+(Math.random()-.5)*.006,p[2]])});})()");pg.wait_for_timeout(400)
    chk(not er,'trait repassé 4 fois : rendu sans erreur %s'%er[:1])
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(300)
    h=pg.evaluate("document.getElementById('dmB').getBoundingClientRect().height")
    chk(h<900,'boîte à rythmes repliée compacte (%d px)'%h)
    chk(pg.evaluate("document.querySelectorAll('#dmB details.dmS').length")==2,'sections repliables Motifs / Son de la voix')
    pg.evaluate("QFX3.open(9)");pg.wait_for_timeout(400)
    t=pg.evaluate("[].map.call(document.querySelectorAll('#inEd details.smS > summary'),s=>s.textContent)")
    chk(t and ('Function' in t[0] or 'Fonction' in t[0]),'sampler : « Fonction et boucle » en premier (%s)'%t[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
