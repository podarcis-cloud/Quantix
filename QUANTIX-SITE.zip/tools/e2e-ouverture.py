# Ouverture (R370 : sans animation) : grésillement des traits repassés, boîte à rythmes compacte, sampler
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(300)
    pg.evaluate("(()=>{const st=QUANTONE.state;for(let i=0;i<4;i++)st.strokes.push({layer:0,pts:[0,1,2,3,4,5].map(k=>[.2+k*.1+(Math.random()-.5)*.006,.5+(Math.random()-.5)*.006,k*30])});})()")
    pg.wait_for_timeout(300);chk(not er,'trait repassé 4 fois : rendu sans erreur %s'%er[:1])
    pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(300)
    h=pg.evaluate("document.getElementById('dmB').getBoundingClientRect().height")
    chk(h<900,'boîte à rythmes repliée compacte (%d px)'%h)
    chk(pg.evaluate("document.querySelectorAll('#dmB details.dmS').length")==2,'sections repliables Motifs / Son de la voix')
    pg.evaluate("QFX3.open(9)");pg.wait_for_timeout(400)
    t=pg.evaluate("[].map.call(document.querySelectorAll('#inEd details.smS > summary'),s=>s.textContent)")
    chk(t and ('Function' in t[0] or 'Fonction' in t[0]),'sampler : « Fonction et boucle » en premier (%s)'%t[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
