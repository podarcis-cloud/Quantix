/* design.js — banc d'essai d'un niveau candidat, avant de l'écrire dans levels.js.
   Usage (dans un script node) :
     const D=require('./design.js');
     const r=D.check(idx, candidat, {sols:[...], idea:(p)=>bool, grid:{...}});
   Le candidat a le même format que levels.js (w, cup, nd, ball, star, ink).
   Rapporte :
   - sans tracé : doit échouer (sinon le niveau se résout seul)
   - solutions prévues : chacune doit réussir (et on note le noyau)
   - balayage : tous les traits à 1 segment (dans l'encre, hors nd) qui gagnent,
     classés « idée » / « hors idée » via le prédicat fourni — un « hors idée »
     non nul signale un contournement à fermer ou une idée mal définie
   - noyau : part des solutions gagnantes qui l'obtiennent
   Physique : le vrai moteur (tools/load.js), jamais une approximation. */
require('./load.js');
const X = globalThis.__X;
const SOLID = 0;

function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}

function install(idx, c){
  const LV = X.LEVELS[idx];
  for (const k of ['w','nd','star','ball','cup','ink','pal','softball']) if (k in c) LV[k]=c[k];
  if (!('nd' in c)) LV.nd = null;
  if (!('star' in c)) LV.star = null;
  LV.walls = (LV.w||[]).slice();
  const [x,y,w,s] = LV.cup;
  LV.walls.push([x,y,x+w,y,SOLID]);
  if (s==='R'||s==='B') LV.walls.push([x+w,y,x+w,y-56,SOLID]);
  if (s==='L'||s==='B') LV.walls.push([x,y,x,y-56,SOLID]);
  LV.zone = [x,y-48,w,48];
}

function inND(c,x,y){return (c.nd||[]).some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]);}
function drawable(c,p){
  for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i],n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/6));
    for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;
      if(x<0||x>360||y<0||y>480||inND(c,x,y))return false;}}
  return true;
}

function run(idx, c, strokes){
  install(idx, c);
  X.loadLevel(idx);
  for (const p of strokes) X.S.strokes.push({pts:p,len:plen(p),birth:0,mat:0});
  X.qpBuild(); X.S.mode='run';
  const trail=[];
  for (let f=0; f<900 && X.S.mode==='run'; f++){ X.physics(); trail.push([X.S.ball.x,X.S.ball.y]); }
  return {ok:X.S.mode==='success', star:X.S.gotStar, end:[Math.round(X.S.ball.x),Math.round(X.S.ball.y)], trail};
}

function check(idx, c, opt){
  opt = opt||{};
  const out = {};
  out.sansTrace = run(idx,c,[]).ok ? 'RÉUSSIT SEUL — À CORRIGER' : 'échoue (bon)';
  out.solutions = (opt.sols||[]).map(s=>{
    const strokes = Array.isArray(s[0][0]) ? s : [s];
    const ink = strokes.reduce((a,p)=>a+plen(p),0);
    const r = run(idx,c,strokes);
    return {ok:r.ok, noyau:r.star, encre:Math.round(ink), fin:r.end,
            dessinable: strokes.every(p=>drawable(c,p))};
  });
  if (opt.sweep !== false){
    const g = Object.assign({x0:0,x1:360,y0:20,y1:470,step:12,da:0.4,lens:[25,45,70,100]}, opt.grid||{});
    let win=0, idea=0, star=0; const hors=[];
    for(let x=g.x0;x<=g.x1;x+=g.step)for(let y=g.y0;y<=g.y1;y+=g.step)for(let a=0;a<6.283;a+=g.da)for(const L of g.lens){
      if (L > c.ink) continue;
      const p=[[x,y],[x+Math.cos(a)*L,y+Math.sin(a)*L]];
      if(!drawable(c,p))continue;
      const r=run(idx,c,[p]); if(!r.ok)continue;
      win++; if(r.star)star++;
      if(!opt.idea || opt.idea(p)) idea++; else if(hors.length<6) hors.push(p.map(q=>q.map(Math.round)));
    }
    out.balayage = {gagnants:win, idee:idea, horsIdee:win-idea, exemplesHors:hors,
                    noyauPct: win? Math.round(100*star/win):0};
  }
  return out;
}

module.exports = {check, run, install, plen, drawable, X};
