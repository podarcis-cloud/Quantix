/* banc.js — BANC D'ÉTALONNAGE DES MÉCANIQUES (R75). Rien n'est laissé au hasard : avant de concevoir une énigme, on connaît
   exactement ce que chaque mécanique permet. Toutes les mesures sont faites dans le vrai moteur. */
const LAB=require('./lab.js');const IDX=24;
function run(c,strokes,frames){const r=LAB.run(IDX,Object.assign({ink:9999,pal:'S',cup:[300,470,50,'B']},c),strokes||[]);return r.tr;}
const out=[];
/* 1. Virage : vitesse conservée selon l'angle entre deux surfaces (pente de 30° puis changement de direction de φ) */
out.push('VIRAGE — part de la vitesse conservée après un changement de pente de φ degrés');
for(const phi of [10,20,30,45,60,90]){const a1=Math.PI/6,a2=a1-phi*Math.PI/180,x0=20,y0=60,L=150,x1=x0+Math.cos(a1)*L,y1=y0+Math.sin(a1)*L,x2=x1+Math.cos(a2)*120,y2=y1+Math.sin(a2)*120;
 const tr=run({ball:[x0+8,y0-14],w:[[x0,y0,x1,y1,0],[x1,y1,x2,y2,0]]});let vb=0,va=0;
 for(let i=1;i<tr.length;i++){const v=Math.hypot(tr[i][0]-tr[i-1][0],tr[i][1]-tr[i-1][1]);if(tr[i][0]<x1-8)vb=Math.max(vb,v);else if(tr[i][0]<x1+30)va=Math.max(va,v);}
 out.push(`  φ = ${String(phi).padStart(2)}° : ${Math.round(100*va/Math.max(vb,1e-6))} %`);}
/* 2. Tapis d'élan : hauteur gagnée sur une rampe de 20° après un tapis plat de longueur Lt, la particule y entrant à faible vitesse */
out.push('TAPIS — hauteur maximale gagnée (au‑dessus du tapis) sur une rampe de 15° qui suit un tapis de longueur Lt (entrée lente : 30 u de pente)');
for(const Lt of [40,80,120,180,240]){const by=300,a=-15*Math.PI/180;const x1=60+Lt;
 const tr=run({ball:[22,by-44],w:[[10,by-30,60,by,0],[60,by,x1,by,3],[x1,by,x1+Math.cos(a)*300,by+Math.sin(a)*300,0]]});   /* petite pente d'entrée : la particule arrive lentement */
 let hmin=1e9;for(const q of tr)if(q[0]>x1)hmin=Math.min(hmin,q[1]);out.push(`  Lt = ${String(Lt).padStart(3)} u : ${Math.round(by-10.5-hmin)} u`);}
/* 3. Plaque de rebond : hauteur de rebond selon la hauteur de chute */
out.push('REBOND — hauteur de remontée (fraction de la hauteur de chute) sur une plaque horizontale');
for(const h of [60,120,200]){const tr=run({ball:[180,400-h],w:[[120,400,240,400,1]]});let first=-1,top=1e9;for(let i=1;i<tr.length;i++){if(first<0&&tr[i][1]<tr[i-1][1])first=i;if(first>0){if(tr[i][1]>tr[i-1][1]&&i>first+1)break;top=Math.min(top,tr[i][1]);}}   /* premier rebond seulement */
 out.push(`  chute ${h} u : remonte de ${Math.round(400-10.5-top)} u (${Math.round(100*(400-10.5-top)/h)} %)`);}
/* 4. Saut horizontal : portée depuis le bout d'une pente de 30° selon la hauteur de départ */
out.push('SAUT — portée horizontale (u) en quittant le bout d’une pente de glace à 0° après une descente de hauteur H');
for(const H of [60,120,180]){const tr=run({ball:[22,200-H-12],w:[[10,200-H,10+H*1.7,200,4],[10+H*1.7,200,10+H*1.7+30,200,4]]});
 const xe=10+H*1.7+30;let land=null;for(const q of tr){if(q[0]>xe&&q[1]>=200+40){land=q[0];break;}}out.push(`  H = ${H} u : ${land?Math.round(land-xe):'—'} u avant d’être 40 u plus bas`);}
/* 5. Vent : colonne montante d'intensité f (largeur 90) — hauteur atteinte depuis l'entrée par le bas */
out.push('VENT — colonne montante (90 u de large) : la particule y entre par le bas ; hauteur de remontée');
for(const f of [-.45,-.55,-.65]){const tr=run({ball:[150,440],w:[[100,456,200,456,0]],wind:[[110,0,90,480,0,f]]});let top=1e9;for(const q of tr)top=Math.min(top,q[1]);out.push(`  force ${f} : monte de ${Math.round(440-top)} u${top<0?' (sort par le haut)':''}`);}
out.push('VENT LATÉRAL — dérive horizontale pendant une chute de 200 u à travers un vent de force fx');
for(const fx of [.1,.2,.3]){const tr=run({ball:[100,40],w:[],wind:[[0,60,360,200,fx,0]]});let x=null;for(const q of tr)if(q[1]>=240){x=q[0];break;}out.push(`  fx = ${fx} : ${x?Math.round(x-100):'—'} u`);}
console.log(out.join('\n'));
