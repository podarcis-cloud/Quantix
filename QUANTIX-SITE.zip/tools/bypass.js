/* ══ DÉTECTEUR DE CONTOURNEMENT ══
   Un niveau est « scénarisé » si sa mécanique signature est indispensable.
   Méthode : on désactive la mécanique, puis on relance la recherche de solution.
   Si le niveau reste résolvable sans elle, elle est décorative — le joueur peut
   la contourner, et le niveau ne raconte rien. */
require('./load.js');
const X=globalThis.__X, {S,LEVELS,physics,loadLevel,qpBuild}=X;
const SOLID=0,BOUNCE=1,SPIKE=2,BOOST=3,ICE=4;
const MATNAME={1:'rebond',3:'élan',4:'glace'};

const inND=(L,x,y)=>L.nd?L.nd.some(r=>x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3]):false;
function polyOK(L,p){for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i];
 const n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/9));
 for(let k=0;k<=n;k++){const x=a[0]+(b[0]-a[0])*k/n,y=a[1]+(b[1]-a[1])*k/n;
  if(x<-2||x>362||y<-2||y>478)return false;if(inND(L,x,y))return false;}}return true;}
const plen=p=>{let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;};
function attempt(i,pts){
  loadLevel(i);
  if(pts){S.strokes.push({pts,len:plen(pts),birth:0,mat:0});S.ink-=plen(pts);}
  qpBuild();S.mode='run';
  for(let f=0;f<900;f++){physics();if(S.mode!=='run')break;}
  return S.mode==='success';
}
function candidates(L){
  const bx=L.ball[0],by=L.ball[1],z=L.zone,cx=z[0]+z[2]/2,dir=cx>bx?1:-1;
  const st=[[bx-dir*28,by+36],[bx-dir*20,by+26],[bx-dir*38,by+52]];
  const rim=dir>0?z[0]:z[0]+z[2];
  const en=[[rim-dir*6,z[1]+z[3]-56],[rim+dir*12,z[1]+z[3]-36],[rim+dir*z[2]*.3,z[1]+z[3]-24]];
  const out=[];
  for(const s of st)for(const e of en)out.push([s,e]);
  for(const e of en)for(const fx of [.4,.62])for(const wy of [150,240,330,410])
    out.push([st[0],[bx+(e[0]-bx)*fx,wy],e]);
  return out;
}
function solvable(i){
  const L=LEVELS[i];
  if(attempt(i,null))return true;
  for(const c of candidates(L)){
    if(!polyOK(L,c))continue;
    if(plen(c)>L.ink)continue;
    if(attempt(i,c))return true;
  }
  return false;
}
/* désactive la mécanique signature ; renvoie une fonction de restauration */
function strip(i){
  const L=LEVELS[i],undo=[];
  const kill=k=>{if(L[k]&&L[k].length){const v=L[k];L[k]=null;undo.push(()=>L[k]=v);return true;}return false;};
  let tag=[];
  for(const k of ['wind','grav','mag','port','mov','sup','det','tdil','ent','gate'])
    if(kill(k))tag.push(k);
  if(L.walls)for(const w of L.walls)
    if(w[4]===BOUNCE||w[4]===BOOST||w[4]===ICE){
      const old=w[4];w[4]=SOLID;undo.push(()=>w[4]=old);
      if(!tag.includes(MATNAME[old]))tag.push(MATNAME[old]);
    }
  if(L.softball){L.softball=false;undo.push(()=>L.softball=true);tag.push('corps mou');}
  return {tag,undo:()=>undo.forEach(f=>f())};
}
const only=process.argv.slice(2).map(Number).filter(Boolean);
const rows=[];
for(let i=0;i<LEVELS.length;i++){
  const L=LEVELS[i];
  if(only.length&&!only.includes(L.wd))continue;
  const {tag,undo}=strip(i);
  if(!tag.length){undo();continue;}
  const withMech=solvable(i);
  undo();
  const {undo:undo2}=strip(i);
  const without=solvable(i);
  undo2();
  rows.push({i,wd:L.wd,n:L.n,tag,withMech,without});
}
let dec=0;
console.log('niveau'.padEnd(26),'mécanique'.padEnd(22),'sans elle');
for(const r of rows){
  const flag=r.without?'RÉSOLU SANS ELLE — décorative':(r.withMech?'indispensable':'— (non prouvé avec)');
  if(r.without)dec++;
  console.log(('#'+(r.i+1)+' '+r.n).padEnd(26),r.tag.join('+').padEnd(22),flag);
}
console.log('\nmécaniques contournables :',dec,'/',rows.length,'niveaux testés');
