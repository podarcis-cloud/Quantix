/* v2.js — monde 9 « Faille », 12 niveaux (index 0..11 = monde 9, niveau 1..12 ; emplacements moteur 96..107).
   Niveaux 1–5, 9, 12 : repris tels quels de final.js. Niveaux 6, 7, 8, 10, 11 : refaits (26 oct. 2026). */
const {ribbon}=require('/home/claude/q2/tools/refonte/rib.js');
const A=require('./final.js').slice();

/* monde 9, niveau 6 — La navette (MACHINE) */
A[5]={n:'La navette',ink:135,pal:'S',ball:[110,80],cup:[130,272,100,'B'],star:[44,360],
 w:[[0,0,0,480,0],[356,0,356,480,0],[0,476,360,476,2],[120,200,240,200,2],[120,200,120,272,0],[240,200,240,272,0],[0,250,60,250,2]],
 curves:[].concat(
  ribbon([[156,166],[190,168],[230,170],[260,172],[276,176]],[2,2,2,2]),
  ribbon([[300,140],[312,200],[318,265],[312,325],[292,382],[252,422],[196,444],[150,450],[120,450]],[10,10,10,10,10,10,10,10]),
  ribbon([[30,440],[29,390],[33,346],[50,312],[80,292],[112,286]],[10,10,10,10,10])),
 nd:[[0,0,360,40]],
 port:[[110,439,42,440,-90,1],[262,331,140,126,208,1],[58,38,180,232,0,1]],
 sol:[[[64,60],[150,150]]],solmat:0,tip:'Ce que la machine emporte, elle le rapporte.'};

/* monde 9, niveau 7 — L'autre ciel (gravité inversée derrière la faille : élément du monde 7) */
A[6]={n:'L’autre ciel',ink:110,pal:'S',ball:[50,40],cup:[182,120,90,''],star:[300,130],
 w:[[0,0,0,480,0],[180,0,180,476,0],[356,0,356,480,0],[0,476,360,476,2],[182,60,272,60,0],[272,30,356,30,2]],
 curves:ribbon([[30,64],[34,150],[56,260],[96,360],[150,428]],[7,7,7,7]),
 grav:[[182,0,178,480,0,-0.4]],
 nd:[[0,0,180,480]],
 port:[[158,434,220,330,75,1]],
 sol:[[[350,150],[276,80]]],solmat:0,tip:'Derrière la faille, on tombe vers le haut.'};

/* monde 9, niveau 8 — Le métronome (deux temps : tir fort, puis tir juste) */
A[7]={n:'Le métronome',ink:85,pal:'S',ball:[20,40],cup:[130,452,80,'B'],star:[150,410],
 w:[[0,0,0,480,0],[40,0,40,476,0],[0,476,360,476,2],[356,0,356,300,0],[356,300,356,480,2],[130,350,216,350,0]],
 curves:ribbon([[246,184],[280,204],[308,224],[330,234],[346,232],[352,222]],[7,7,7,7,7]),
 nd:[[0,0,44,480],[44,340,180,136]],
 port:[[20,436,100,430,-80,1],[334,220,100,430,-80,1]],
 sol:[[[208,156],[280,176]]],solmat:0,tip:'La faille rend la vitesse qu’on lui donne. Le ruban, lui, la règle.'};

/* monde 9, niveau 10 — Le contre-pied (faille tournante 180°, deux portes) */
A[9]={n:'Le contre-pied',ink:110,pal:'S',ball:[200,200],cup:[4,120,90,''],star:[110,50],
 w:[[0,0,0,150,0],[0,150,0,480,2],[356,0,356,480,2],[0,476,360,476,2]],
 curves:[{pts:[[232,236],[200,250],[170,266],[140,286]],m:0}],
 nd:[[0,0,360,30],[110,30,250,170]],
 port:[[40,420,170,160,180],[314,340,170,160,180]],
 sol:[[[194,222],[256,246]]],solmat:0,tip:'Ce qui entre dans la faille en ressort à rebours.'};

/* monde 9, niveau 11 — La reprise (la sortie est le point de départ ; moteur actuel) */
A[10]={n:'La reprise',ink:110,pal:'S',ball:[210,60],cup:[4,62,130,''],star:[140,40],
 w:[[0,0,0,480,0],[356,0,356,480,0],[0,476,360,476,2],[256,290,302,290,2],[302,196,302,290,2]],
 curves:ribbon([[344,140],[346,220],[340,290],[322,336],[296,358],[266,360],[244,346],[228,322]],[7,7,7,7,7,7,7]),
 nd:[[0,0,360,20],[0,20,160,60],[220,286,90,100]],
 port:[[238,308,210,60]],
 sol:[[[200,100],[280,124]]],solmat:0,tip:'La faille te rend ton départ, avec ton élan.'};

module.exports=A;
