const H=require('/home/claude/q2/tools/refonte/harness.js');const base=require('./m6.js')[5];
const goods=[[[[16,74],[120,140]]],[[[24,80],[120,140]]],[[[10,66],[118,140]]],[[[20,84],[120,144]]]];
const naive=[[[[50,100],[120,142]]],[[[40,96],[118,140]]],[[[56,104],[120,146]]]];
const res=[];
for(const by of [90,100,110,120,132])for(let a=188;a<=212;a+=3)for(const rg of [[20,58],[16,50],[24,64]]){
 const L=JSON.parse(JSON.stringify(base));L.port[1]=[262,331,330,by,a,1];L.port[2]=[rg[0],rg[1],180,232,0,1];const c=H.full(L);
 const g=goods.map(s=>H.runT(101,c,s.map(p=>({pts:p,mat:0})),false).ok);const n=naive.map(s=>H.runT(101,c,s.map(p=>({pts:p,mat:0})),false).ok);
 const sc=g.filter(x=>x).length-2*n.filter(x=>x).length;res.push([sc,by,a,rg.join(','),g.map(x=>+x).join(''),n.map(x=>+x).join('')]);}
res.sort((p,q)=>q[0]-p[0]);console.log(res.slice(0,15).map(r=>r.join(' ')).join('\n'));
