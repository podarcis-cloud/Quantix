/* viz.js FICHIER i [strokesJSON] — trajectoire + dessin PNG v2/L{i}.png */
const H=require('/home/claude/q2/tools/refonte/harness.js');const fs=require('fs');
const C=require(require('path').resolve(process.argv[2]));const i=+process.argv[3];const L=C[i];
const st=process.argv[4]?JSON.parse(process.argv[4]):(L.sol||[]).map(p=>({pts:p,mat:L.solmat||0}));
const c=H.full(L);const r=H.runT(96+i,c,st,true);
const curves=(H.X.LEVELS[96+i]._cv||[]).map(q=>({pts:q.pts,v:q.v,m:q.m}));
console.log('ok',r.ok,'mode',r.mode,'star',r.star,'end',r.end,'frames',r.tr.length);
fs.writeFileSync(__dirname+'/v2/L'+i+'.json',JSON.stringify({L,tr:r.tr,curves,st}));
require('child_process').execSync('python3 '+__dirname+'/viz.py '+__dirname+'/v2/L'+i+'.json');
if(process.env.T){const t=r.tr,k0=+process.env.T||8;let s='';for(let k=1;k<t.length;k+=k0){const v=Math.hypot(t[k][0]-t[k-1][0],t[k][1]-t[k-1][1]);s+=`${k}:${t[k][0]},${t[k][1]}@${v.toFixed(1)} `;}console.log(s);}
