const HH=require('/home/claude/q2/tools/refonte/harness.js');const C=require(require('path').resolve(process.argv[2]));const i=+process.argv[3];const L=C[i];
const st=process.argv[6]?JSON.parse(process.argv[6]):(L.sol||[]).map(p=>({pts:p,mat:L.solmat||0}));
const r=HH.runT(96+i,HH.full(L),st,true);console.log(r.tr.slice(+process.argv[4],+process.argv[5]).map(p=>p.join(',')).join(' '));
