const N={};
N[9]={n:'Le contre-pied',ink:110,pal:'S',ball:[200,200],cup:[4,120,90,''],star:[110,50],
 w:[[0,0,0,150,0],[0,150,0,480,2],[356,0,356,480,2],[0,476,360,476,2]],
 curves:[{pts:[[232,236],[200,250],[170,266],[140,286]],m:0}],
 nd:[[0,0,360,30],[110,30,250,170]],
 port:[[40,420,170,160,180],[314,340,170,160,180]],
 sol:[[[194,222],[256,246]]],solmat:0,tip:'Ce qui entre dans la faille en ressort à rebours.'};
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
