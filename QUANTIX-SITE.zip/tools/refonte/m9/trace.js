/* trace.js FICHIER i [strokesJSON] — trajectoire (1 point / 5 trames) */
const H=require('/home/claude/q2/tools/refonte/harness.js');
const C=require(require('path').resolve(process.argv[2]));const i=+process.argv[3];const L=C[i];
const st=process.argv[4]?JSON.parse(process.argv[4]):(L.sol||[]).map(p=>({pts:p,mat:L.solmat||0}));
const r=H.runT(96+i,H.full(L),st,true);console.log('ok',r.ok,'mode',r.mode,'star',r.star,'end',r.end,'frames',r.tr.length);
console.log(r.tr.filter((_,k)=>k%5==0).map(p=>p.join(',')).join(' '));
