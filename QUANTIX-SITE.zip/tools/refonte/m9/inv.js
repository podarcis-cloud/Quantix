/* inv.js — pour un trait, trajectoire (pos+vit) sans failles ; pour chaque point candidat A et chaque B, vol libre de la vitesse inversée → atteint-il la coupe ? */
const H=require('/home/claude/q2/tools/refonte/harness.js');const L=JSON.parse(JSON.stringify(require('./m10.js')[9]));L.port=[];
const S=JSON.parse(process.argv[2]);const c=H.full(L);H.X.S=H.X.S;
const r=H.runT(105,c,S.map(p=>({pts:p,mat:0})),true);const t=r.tr;
function fly(x,y,vx,vy){for(let f=0;f<200;f++){for(let k=0;k<5;k++){vy+=0.08;x+=vx/5;y+=vy/5;}
 if(x<10||x>350||y>480)return null; if(x>8&&x<92&&y>100&&y<110&&vy>0)return [Math.round(x),Math.round(y),f];}return null;}
const out=[];for(let k=20;k<t.length-1;k+=2){const [x,y]=t[k],[x2,y2]=t[k+1];const vx=x2-x,vy=y2-y;if(y<300)continue;
 for(let bx=200;bx<=330;bx+=20)for(let by=180;by<=300;by+=20){const q=fly(bx,by,-vx,-vy);if(q)out.push([x,y,'v',vx,vy,'B',bx,by,'->',q.join(',')]);}}
console.log('Z',out.length);out.filter((_,i)=>i%Math.max(1,Math.floor(out.length/25))==0).forEach(o=>console.log('Z',o.join(' ')));
