const H=require('/home/claude/q2/tools/refonte/harness.js');const L=require('./v2.js')[10];const c=H.full(L);
let s=9;const rnd=()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};let found=0;
for(let n=0;n<6000&&found<4;n++){const x=150+rnd()*110,y=90+rnd()*190,a=rnd()*6.283,len=20+rnd()*60;const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];
 if(!H.D.drawable(c,p))continue;const r=H.runT(106,c,[{pts:p,mat:0}],true);const t=r.tr;
 for(let k=1;k<t.length;k++)if(Math.abs(t[k][0]-210)<3&&Math.abs(t[k][1]-60)<6&&Math.hypot(t[k][0]-t[k-1][0],t[k][1]-t[k-1][1])>40){const v=t[Math.min(k+2,t.length-1)][1]-t[k][1];if(v>0){console.log('Z',JSON.stringify(p),r.mode,'vy',v);found++;}break;}}
