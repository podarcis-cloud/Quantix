const {ribbon}=require('/home/claude/q2/tools/refonte/rib.js');
const N={};
N[4]={n:'Deux quarts de tour',ink:200,pal:'S',ball:[60,40],cup:[150,346,90,"L"],star:[200,420],
 w:[[0,0,0,480,2],[0,452,96,452,0],[96,452,250,452,2],[250,452,360,452,0],[310,270,310,384,0],[350,230,350,452,0]],
 curves:ribbon([[350,250],[330,212],[300,196],[262,200],[234,222],[220,258],[214,294]],[7,7,7,2,2,2]),
 nd:[[0,0,360,330],[0,330,84,150],[300,330,60,150]],
 port:[[60,441,330,402,90]],
 sol:[[[250,428],[86,446]]],solmat:0,tip:'La faille tourne la course d’un quart de tour.'};
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
