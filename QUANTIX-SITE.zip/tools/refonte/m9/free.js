const H=require('/home/claude/q2/tools/refonte/harness.js');const i=+process.argv[3];const L=JSON.parse(JSON.stringify(require(require('path').resolve(process.argv[2]))[i]));
if(process.env.NOCURVE)L.curves=[];const st=process.argv[4]?JSON.parse(process.argv[4]).map(p=>({pts:p,mat:0})):[];
const r=H.runT(96+i,H.full(L),st,true);console.log('X',r.mode,r.tr.filter((_,k)=>k%4==0&&k>=(+process.env.F||0)).map(p=>p.join(',')).join(' '));
