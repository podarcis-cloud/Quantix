const H=require('/home/claude/q2/tools/refonte/harness.js');const base=require('./m10.js')[9];
const goods=[[[[190,224],[250,240]]],[[[186,226],[240,232]]],[[[194,222],[256,246]]],[[[190,220],[262,236]]],[[[180,226],[246,250]]]];
const res=[];
for(let ax=306;ax<=340;ax+=8)for(let ay=340;ay<=440;ay+=20)for(let bx=160;bx<=300;bx+=20)for(let by=120;by<=260;by+=20){
 const L=JSON.parse(JSON.stringify(base));L.port[1]=[ax,ay,bx,by,180];L.port[0][2]=bx;L.port[0][3]=by;const c=H.full(L);
 if(H.runT(105,c,[],false).ok)continue;const g=goods.map(s=>H.runT(105,c,s.map(p=>({pts:p,mat:0})),false).ok);
 res.push([g.filter(x=>x).length,ax,ay,bx,by,g.map(x=>+x).join('')]);}
res.sort((p,q)=>q[0]-p[0]);console.log('Z\n'+res.slice(0,15).map(r=>r.join(' ')).join('\n'));
