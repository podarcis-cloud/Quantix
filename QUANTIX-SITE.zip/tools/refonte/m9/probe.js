/* probe.js FICHIER i 'strokesJSON' f0 f1 — ok/mode + points entre trames f0..f1 */
const H=require('/home/claude/q2/tools/refonte/harness.js');const L=require(require('path').resolve(process.argv[2]))[+process.argv[3]];
const st=JSON.parse(process.argv[4]).map(p=>({pts:p,mat:0}));const r=H.runT(96+ +process.argv[3],H.full(L),st,true);
const f0=+process.argv[5]||0,f1=+process.argv[6]||r.tr.length;console.log('ok',r.ok,r.mode,'star',r.star,'frames',r.tr.length,'|',r.tr.slice(f0,f1).filter((_,k)=>k%4==0).map(p=>p.join(',')).join(' '));
