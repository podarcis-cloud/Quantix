require('/home/claude/q2/tools/load.js');const X=globalThis.__X;const L=X.LEVELS[+process.argv[2]];
console.log('Z',JSON.stringify({n:L.n,w:L.w,ball:L.ball,cup:L.cup,mag:L.mag,nd:L.nd,sol:L.optsol||L.sol,ink:L.ink,bf:L.bf,grav:L.grav}));
