const H=require('/home/claude/q2/tools/refonte/harness.js');const L=require('./v2.js');
const t=(i,s)=>{const r=H.runT(96+i,H.full(L[i]),s.map(p=>({pts:p,mat:0})),true);return r.mode+' '+r.tr.length+' end '+r.end;};
console.log('Z6 naive',t(5,[[[80,110],[150,152]]]),'| flat',t(5,[[[30,100],[150,152]]]));
console.log('Z7 rampe vers poche',t(6,[[[276,80],[350,150]]]),'| sous B',t(6,[[[200,380],[300,400]]]));
console.log('Z10 rien',t(9,[]),'| porte gauche',t(9,[[[214,222],[150,250]]]));
console.log('Z11 par le trou',t(10,[[[206,150],[214,170]]]),'| rien',t(10,[]));
console.log('Z7b pente inverse',t(6,[[[276,150],[350,80]]]));
for(const s of [[[[204,240],[214,262]]],[[[205,230],[220,262]]],[[[204,250],[212,270]]],[[[200,200],[216,240]]]]){const H2=H.runT(106,H.full(L[10]),s.map(p=>({pts:p,mat:0})),true);console.log('Z11b',JSON.stringify(s),H2.mode,H2.tr.filter((_,k)=>k%6==0).slice(0,14).map(p=>p.join(',')).join(' '));}
