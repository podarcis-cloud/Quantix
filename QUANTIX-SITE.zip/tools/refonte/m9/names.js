require('/home/claude/q2/tools/load.js');const X=globalThis.__X;
for(let i=+process.argv[2];i<+process.argv[3];i++){const L=X.LEVELS[i];console.log('Z',i,L.n,(L.curves||[]).map(c=>c.m+(c.v!==undefined?'v'+c.v:'')).join(','),L.pal,(L.tip||'').slice(0,70));}
