/* srch.js FICHIER i 'json-variants' N — pour chaque variante (patch JSON fusionné), P_hasard (N lignes) et meilleur trait gagnant par P_ligne */
const H=require('/home/claude/q2/tools/refonte/harness.js');const i=+process.argv[3];const base=require(require('path').resolve(process.argv[2]))[i];
const V=JSON.parse(process.argv[4]);const N=+process.argv[5]||600;
let s0=5;const rnd=()=>{s0=(s0*16807)%2147483647;return (s0-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
for(const v of V){const L=Object.assign(JSON.parse(JSON.stringify(base)),v);const c=H.full(L);s0=5;let ok=0,n=0,g=0;const wins=[];
 while(n<N&&g<N*30){g++;const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(Math.min(230,L.ink)-15);const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];
  if(!H.D.drawable(c,p))continue;n++;const q=H.runT(96+i,c,[{pts:p,mat:0}],false);if(q.ok){ok++;wins.push({p,star:q.star});}}
 let best=null;for(const w of wins.slice(0,12)){let k=0;for(let t=0;t<20;t++){if(H.runT(96+i,c,[{pts:w.p.map(q=>[q[0]+gs()*3,q[1]+gs()*3]),mat:0}],false).ok)k++;}if(!best||k>best.k)best={k,p:w.p,star:w.star};}
 console.log(JSON.stringify(v).slice(0,80),'P',(ok/n*100).toFixed(2)+'%',ok+'/'+n,'best',best?JSON.stringify(best):'-');}
