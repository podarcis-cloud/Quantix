const {ribbon}=require('/home/claude/q2/tools/refonte/rib.js');
const N={};
N[6]={n:'L’autre ciel',ink:110,pal:'S',ball:[50,40],cup:[182,120,90,''],star:[300,130],
 w:[[0,0,0,480,0],[180,0,180,476,0],[356,0,356,480,0],[0,476,360,476,2],[182,60,272,60,0],[272,30,356,30,2]],
 curves:ribbon([[30,64],[34,150],[56,260],[96,360],[150,428]],[7,7,7,7]),
 grav:[[182,0,178,480,0,-0.4]],
 nd:[[0,0,180,480]],
 port:[[158,434,220,330,75,1]],
 sol:[[[350,150],[276,80]]],solmat:0,tip:'De l’autre côté, le ciel est en bas.'};
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
