const {ribbon}=require('/home/claude/q2/tools/refonte/rib.js');
const N={};
N[10]={n:'La reprise',ink:110,pal:'S',ball:[210,60],cup:[4,62,130,''],star:[140,40],
 w:[[0,0,0,480,0],[356,0,356,480,0],[0,476,360,476,2],[256,290,302,290,2],[302,196,302,290,2]],
 curves:ribbon([[344,140],[346,220],[340,290],[322,336],[296,358],[266,360],[244,346],[228,322]],[7,7,7,7,7,7,7]),
 nd:[[0,0,360,20],[0,20,160,60],[220,286,90,100]],
 port:[[238,308,210,60]],
 sol:[[[200,100],[280,124]]],solmat:0,tip:'La faille te rend ton départ, avec ton élan.'};
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
