const {ribbon}=require('/home/claude/q2/tools/refonte/rib.js');
const N={};
N[7]={n:'Le métronome',ink:110,pal:'S',ball:[20,40],cup:[130,452,80,'B'],star:[150,410],
 w:[[0,0,0,480,0],[40,0,40,476,0],[0,476,360,476,2],[356,0,356,300,0],[356,300,356,480,2],[130,350,216,350,0]],
 curves:ribbon([[246,184],[280,204],[308,224],[330,234],[346,232],[352,222]],[7,7,7,7,7]),
 nd:[[0,0,44,480],[44,340,180,136]],
 port:[[20,436,100,430,-80,1],[334,220,100,430,-80,1]],
 sol:[[[208,156],[280,176]]],solmat:0,tip:'La faille rend la vitesse qu’on lui donne. Le ruban, lui, la règle.'};
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
