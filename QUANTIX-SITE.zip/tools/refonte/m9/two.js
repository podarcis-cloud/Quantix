const HH=require('/home/claude/q2/tools/refonte/harness.js');const C=require(require('path').resolve(process.argv[2]));const i=+process.argv[3];const L=C[i];const c=HH.full(L);
let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const line=(maxL)=>{for(;;){const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15);const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];if(HH.D.drawable(c,p))return {p,len};}};
let ok=0,n=0;const N=+process.argv[4]||800;while(n<N){const a=line(Math.min(230,L.ink-15));const b=line(Math.max(16,Math.min(230,L.ink-a.len)));n++;if(HH.runT(96+i,c,[{pts:a.p,mat:0},{pts:b.p,mat:0}],false).ok)ok++;}
console.log('P_hasard 2 traits',(ok/n*100).toFixed(2)+'%',ok+'/'+n);
