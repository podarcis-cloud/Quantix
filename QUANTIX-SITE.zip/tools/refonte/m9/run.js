/* run.js FICHIER [i…] — évalue des candidats m9 (index 0..11 = 97..108) */
const H=require('/home/claude/q2/tools/refonte/harness.js');
const C=require(require('path').resolve(process.argv[2]));const N=+process.env.N||1500;
const ids=process.argv.slice(3).map(Number);const list=ids.length?ids:C.map((_,i)=>i);
for(const i of list){const L=C[i];if(!L)continue;
 const t0=Date.now();const r=H.evalLevel(96+i,L,N);
 const tr=r.ref.tr;const pick=tr.filter((_,k)=>k%10==0).map(p=>p.join(',')).join(' ');
 console.log(`#${97+i} ${r.n} | sans trait: ${r.sansTrait} | ref ok=${r.ref.ok} noyau=${r.ref.star} mode=${r.ref.mode} encre=${r.ref.encre}/${L.ink} dessinable=${r.ref.dessinable} Pligne=${r.ref.Pligne}% | Phasard=${r.hasard.P}% (${r.hasard.ok}/${r.hasard.tirages}) ${Date.now()-t0}ms`);
 if(process.env.V){console.log(' traj',pick);console.log(' ex',JSON.stringify(r.hasard.ex));console.log(' ',r.elems.join('; '));}
}
