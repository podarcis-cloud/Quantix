const H=require('/home/claude/q2/tools/refonte/harness.js');const i=+process.argv[3];const L=require(require('path').resolve(process.argv[2]))[i];const c=H.full(L);
let seed=11;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
const S=JSON.parse(process.argv[4]);const out={};for(let t=0;t<40;t++){const q=H.runT(96+i,c,S.map(p=>({pts:p.map(v=>[v[0]+gs()*3,v[1]+gs()*3]),mat:0})),true);
 if(!q.ok){const k=q.mode+' end'+q.end.map(v=>Math.round(v/20)*20).join(',');out[k]=(out[k]||0)+1;}}console.log(JSON.stringify(out));
