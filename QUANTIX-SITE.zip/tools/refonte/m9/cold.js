const X=require('/home/claude/q2/tools/design.js').X;
module.exports=Array.from({length:12},(_,i)=>{const L=JSON.parse(JSON.stringify(X.LEVELS[96+i]));delete L.walls;delete L.zone;L.sol=L.optsol;L.solmat=L.optmat;return L;});
