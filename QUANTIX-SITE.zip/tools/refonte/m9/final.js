const X=require('/home/claude/q2/tools/design.js').X;
const old=i=>{const L=JSON.parse(JSON.stringify(X.LEVELS[i]));delete L.walls;delete L.zone;delete L.idx;delete L.eleg;delete L.flow;L.sol=L.optsol;L.solmat=L.optmat;delete L.optsol;delete L.optmat;delete L.wd;return L;};
const pick=(f,i)=>require('./'+f)[i];
const A=[pick('c97.js',0),pick('c98.js',1),pick('c99.js',2),old(100),pick('c101.js',4),pick('c102.js',5),old(103),pick('c104.js',7),pick('c105.js',8),pick('c106.js',9),null,pick('c108.js',11)];
A[3].n='Le bord du monde';A[3].star=[30,410];
A[6].n='À travers';
module.exports=A;
