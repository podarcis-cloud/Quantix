/* pl.js FICHIER i 'strokesJSON'... — P_ligne (σ=3, 60 essais) pour chaque jeu de traits */
const H=require('/home/claude/q2/tools/refonte/harness.js');const i=+process.argv[3];const L=require(require('path').resolve(process.argv[2]))[i];const c=H.full(L);
let seed=11;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
for(const a of process.argv.slice(4)){const S=JSON.parse(a);const base=H.runT(96+i,c,S.map(p=>({pts:p,mat:0})),false);let ok=0,st=0;const T=60;
 for(let t=0;t<T;t++){const q=H.runT(96+i,c,S.map(p=>({pts:p.map(v=>[v[0]+gs()*3,v[1]+gs()*3]),mat:0})),false);if(q.ok)ok++;if(q.star)st++;}
 const len=S.reduce((s,p)=>s+H.D.plen(p),0);console.log(a,'base',base.ok,base.star,'Pl',Math.round(ok/T*100)+'%','len',Math.round(len),'drawable',S.every(p=>H.D.drawable(c,p)));}
