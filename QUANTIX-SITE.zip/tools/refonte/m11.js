/* Niveau 35 : « Après ton passage » (prison d'élan + rampe tracée au retour). */
const R=(x1,y1,x2,y2,v)=>[x1,y1,x2,y2,3,0,0,0,0,0,v];const A_=(a,b,c,d)=>[a,b,c,d,3];
const o={n:'Après ton passage',ink:110,pal:'SA',ball:[40,372],cup:[10,340,70,'L'],star:[50,322],
 nd:[[0,388,170,26],[196,300,160,114],[0,0,360,330]],
 w:[R(10,400,170,400,5),[170,400,200,400,0],R(352,330,200,400,6),[352,330,352,200,0]],
 sol:[[[190,396],[84,340]]],solmat:3,solat:[70],tip:'Laisse-la passer, puis trace la rampe qu’elle prendra au retour.',idee:'Le ruban renvoie la balle : le temps de tracer est offert.'};
module.exports=[o];
if(require.main===module){const H=require('./harness.js');const r=H.runT(34,H.full(o),[],true);console.log(r.mode,r.tr.length,r.end);console.log(r.tr.filter((_,i)=>i%15==0).map(p=>p.map(Math.round).join(',')).join(' '));}
