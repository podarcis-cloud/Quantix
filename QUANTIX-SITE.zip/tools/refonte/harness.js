/* harness.js — banc de conception d'un monde refondu : évalue des candidats (format levels.js) dans le vrai moteur.
   Usage : node tools/refonte/harness.js FICHIER_CANDIDATS.js [n° local …]   — le fichier exporte un tableau de niveaux (idx = emplacement moteur). */
const D=require('../design.js'),X=D.X,fs=require('fs'),path=require('path');
const KEYS=['w','nd','star','wind','grav','mag','port','mov','ent','gate','sup','det','tdil','rails','mz','curves','flow','vortex','updraft','pend','well','bf','kick','wrap','strings','elastic','strE','sling','fork','coil','spectro','rec','softball'];
const COST={0:1,1:1.9,3:1.7,5:1};
function full(c){const o={};KEYS.forEach(k=>{o[k]=undefined;});o.nd=null;o.star=null;return Object.assign(o,JSON.parse(JSON.stringify(c)));}
let seed=3;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const matsOf=L=>{const p=L.pal||'S',m=[];if(p.includes('S'))m.push(0);if(p.includes('B'))m.push(1);if(p.includes('A'))m.push(3);if(p.includes('C'))m.push(5);return m;};
function runT(idx,c,strokes,tr){D.install(idx,c);X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:D.plen(s.pts),birth:0,mat:s.mat||0});X.qpBuild();X.S.mode='run';const t=[];
 for(let f=0;f<1200&&X.S.mode==='run';f++){X.physics();if(tr)t.push([Math.round(X.S.ball.x),Math.round(X.S.ball.y)]);}return {ok:X.S.mode==='success',star:!!X.S.gotStar,mode:X.S.mode,tr:t,end:[Math.round(X.S.ball.x),Math.round(X.S.ball.y)]};}
function refStrokes(c){return (c.sol||[]).map(p=>({pts:p,mat:c.solmat===undefined?0:(Array.isArray(c.solmat)?c.solmat[(c.sol||[]).indexOf(p)]:c.solmat)}));}
function evalLevel(slot,L,N){const c=full(L),res={n:L.n};
 const none=runT(slot,c,[],false);res.sansTrait=none.ok?'RÉUSSIT SEUL':'échoue';
 const rs=refStrokes(L);const r=runT(slot,c,rs,true);res.ref={ok:r.ok,star:r.star,mode:r.mode,encre:Math.round(rs.reduce((a,s)=>a+D.plen(s.pts),0)),dessinable:rs.every(s=>D.drawable(c,s.pts)),tr:r.tr};
 {let okc=0;const T=40;const gs=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());for(let t=0;t<T;t++){const st=rs.map(s=>({pts:s.pts.map(q=>[q[0]+gs()*3,q[1]+gs()*3]),mat:s.mat}));if(runT(slot,c,st,false).ok)okc++;}res.ref.Pligne=Math.round(okc/T*100);}
 const mats=matsOf(L);let tries=0,ok=0,g=0;const fam={};const wins=[];
 while(tries<N&&g<N*30){g++;const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);if(maxL<15)continue;const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),
  p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];if(!D.drawable(c,p))continue;tries++;
  const q=runT(slot,c,[{pts:p,mat:m}],false);if(q.ok){ok++;fam[m]=(fam[m]||0)+1;if(wins.length<12)wins.push({p,m});}}
 res.hasard={tirages:tries,ok,P:+(ok/Math.max(1,tries)*100).toFixed(2),parMatiere:fam,ex:wins.slice(0,6)};
 /* utilité des éléments (référence retirée un à un) */
 res.elems=[];(L.w||[]).forEach((w,j)=>{const c2=full(L);c2.w=c2.w.filter((_,i)=>i!==j);const q=runT(slot,c2,rs,false);res.elems.push('mur'+(j+1)+(q.ok?' sans effet sur la réf':' indispensable'));});
 (L.nd||[]).forEach((w,j)=>{const c2=full(L);c2.nd=c2.nd.filter((_,i)=>i!==j);if(!c2.nd.length)c2.nd=null;const q=runT(slot,c2,rs,false);res.elems.push('zone'+(j+1)+(q.ok?' sans effet sur la réf':' indispensable'));});
 /* filtre : retrait d'un élément, mêmes lignes au hasard (appariées) */
 if(process.env.FILT){const open=full(L);open.nd=null;const lines=[];let gg=0;const NF=+process.env.FILT;
  while(lines.length<NF&&gg<NF*30){gg++;const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,L.ink/COST[m]);if(maxL<15)continue;const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),
   p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];if(D.drawable(open,p))lines.push({p,m});}
  const rate=cc=>{let k=0;for(const l of lines){if(!D.drawable(cc,l.p))continue;if(runT(slot,cc,[{pts:l.p,mat:l.m}],false).ok)k++;}return k;};
  const b=rate(full(L));res.filtre={base:b,sans:[]};
  (L.w||[]).forEach((w,j)=>{const c2=full(L);c2.w=c2.w.filter((_,i)=>i!==j);res.filtre.sans.push(['mur'+(j+1),rate(c2)]);});
  (L.nd||[]).forEach((w,j)=>{const c2=full(L);c2.nd=c2.nd.filter((_,i)=>i!==j);if(!c2.nd.length)c2.nd=null;res.filtre.sans.push(['zone'+(j+1),rate(c2)]);});}
 return res;}
module.exports={evalLevel,full,runT,D,X};
if(require.main===module){const f=path.resolve(process.argv[2]);delete require.cache[f];const LV=require(f),only=process.argv.slice(3).map(Number),N=+(process.env.N||600);
 LV.forEach((L,k)=>{if(!L)return;if(only.length&&!only.includes(k+1))return;const r=evalLevel((+process.env.BASE||24)+k,L,N);const tr=r.ref.tr;delete r.ref.tr;
  console.log((25+k)+' '+r.n,JSON.stringify({filt:r.filtre,sans:r.sansTrait,ref:r.ref,P:r.hasard.P,tir:r.hasard.tirages,mat:r.hasard.parMatiere,elems:r.elems}));
  fs.mkdirSync('/tmp/rf',{recursive:true});fs.writeFileSync('/tmp/rf/L'+(25+k)+'.json',JSON.stringify({L,tr,ex:r.hasard.ex}));});}
