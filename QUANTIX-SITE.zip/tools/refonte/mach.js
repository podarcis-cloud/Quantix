const H=require('./harness.js');const f=process.argv[2];const o=require('../fiches/machines/'+f+'.json');
const L=Object.assign({n:f,ink:200,pal:'S',w:[]},o);
const r=H.runT(24,H.full(L),[],true);console.log(f,r.mode,r.tr.length,'fin',r.end,r.tr.filter((_,i)=>i%40==0).map(p=>p.join(',')).join(' ').slice(0,300));
