/* Refonte du monde 3 « Chaîne » (ruban d'élan) — candidats. Une idée par niveau. */
const NEW=[
/*25 */{n:'Le ruban',ink:102,pal:'S',ball:[24,322],cup:[264,306,88,'R'],star:[274,290],w:[[10,336,60,340,0],[60,340,200,340,3]],sol:[[[194,344],[260,304]]],solmat:0,
 tip:'La zone est plus haute que toi. Une seule chose ici peut te donner cet élan.',idee:"L'élan donne de la vitesse, pas de la hauteur : il faut un tremplin à la sortie."},
/*26 */{n:'Dans le bon sens',ink:150,pal:'A',ball:[255,250],cup:[18,400,80,'L'],star:[50,380],w:[[98,400,150,400,0],[150,400,175,378,0],[175,378,200,400,0],[200,400,318,400,0],[318,400,360,400,2]],
 sol:[[[256,294],[200,328]]],solmat:3,tip:'Le ruban pousse dans le sens où tu le traces : la coupe est à gauche, et il y a une bosse.',idee:"Le sens du tracé est le sens de l'élan."},
/*27 */{n:'Le canon',ink:230,pal:'A',ball:[60,80],cup:[240,410,100,'R'],star:[280,372],w:[[0,470,360,470,0],[185,250,185,470,0]],sol:[[[39,134],[77,55]]],solmat:3,
 tip:'Pas de tremplin ici : un ruban bien incliné sous la balle la lance par-dessus le pilier.',idee:"Un élan libre lance la balle : l'angle du ruban fait la portée."},

/*32 */{n:'Le boomerang',ink:140,pal:'B',ball:[25,300],cup:[20,430,160,'L'],star:[80,410],w:[[10,340,140,340,3],[0,470,360,470,0]],sol:[[[185,296],[197,333]]],solmat:1,
 tip:'Le ruban de gauche la lance. Renvoie-la d’un rebond.',idee:"La vitesse se conserve dans le rebond : l'élan lance, le rebond renvoie."},
/*35 */{n:'Le bon ruban',ink:100,pal:'S',ball:[60,50],cup:[300,290,60,'R'],star:[328,262],nd:[[0,0,215,238]],w:[[20,100,150,150,0],[265,262,205,276,3],[250,350,310,300,3],[0,468,360,468,2]],
 sol:[[[286,247],[232,248]]],solmat:0,tip:'Deux rubans, un seul mène à la coupe. Fais passer la balle au bon endroit.',idee:"Plusieurs rubans, un seul mène à la coupe : on choisit où la balle arrive."},
];

/* assemblage : monde 3 refondu = nouveaux niveaux (26 sens, 27 canon, 32 boomerang) + niveaux conservés de l'existant (nettoyés) */
const B=require('./base3.js');const J=o=>JSON.parse(JSON.stringify(o));
const out=B.map(J);
const n25=out[0];n25.n='Le ruban';n25.w=n25.w.filter((_,i)=>i!==2);
out[1]=NEW[1];out[2]=NEW[2];out[7]=NEW[3];out[10]=NEW[4];out[6]=require('./chaine2.js')[0];
module.exports=out;
