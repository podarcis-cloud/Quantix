const H=require('./harness.js');
const L={n:'g1',ink:400,pal:'A',ball:[60,200],cup:[300,440,80,'R'],w:[[0,470,360,470,0]]};
for(const ang of [15,25,35,45,60]){const a=ang*Math.PI/180,len=140,x0=40,y0=300;
 const st=[{pts:[[x0,y0],[Math.round(x0+len*Math.cos(a)),Math.round(y0-len*Math.sin(a))]],mat:3}];
 const r=H.runT(24,H.full(L),st,true);
 const ys=r.tr.map(p=>p[1]);console.log(ang,'min y',Math.min(...ys),'fin',r.end,'mode',r.mode,'traj',r.tr.filter((_,i)=>i%25==0).map(p=>p.join(',')).join(' '));}
