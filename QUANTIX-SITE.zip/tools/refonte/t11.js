const H=require('./harness.js');const {D,X}=H;
function runL(idx,c,strokes,tr){D.install(idx,c);X.loadLevel(idx);X.qpBuild();X.S.mode='run';const t=[];
 for(let f=0;f<1200&&X.S.mode==='run';f++){for(const s of strokes)if(s.at===f){X.S.strokes.push({pts:s.pts,len:D.plen(s.pts),birth:f,mat:s.mat||0});X.qpBuild();}
  X.physics();if(tr)t.push([Math.round(X.S.ball.x),Math.round(X.S.ball.y)]);}
 return {ok:X.S.mode==='success',mode:X.S.mode,f:t.length,end:[Math.round(X.S.ball.x),Math.round(X.S.ball.y)],tr:t};}
module.exports={runL};
if(require.main===module){const o=require('./'+process.argv[2])[0];const c=H.full(o);
 const sols=JSON.parse(process.argv[3]);const r=runL(+process.argv[4]||34,c,sols,true);console.log(r.mode,r.f,r.end);}
if(require.main===module&&process.argv[5]){const o=require('./'+process.argv[2])[0];const r=runL(34,H.full(o),JSON.parse(process.argv[3]),true);console.log(r.tr.filter((_,i)=>i%6==0).map(p=>p.join(',')).join(' '));}
