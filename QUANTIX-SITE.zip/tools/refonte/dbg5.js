const H=require('./harness.js');const {D,X}=H;const o=require('./'+process.argv[2])[+process.argv[3]];const c=H.full(o);
D.install(48+(+process.argv[3]),c);X.loadLevel(48+(+process.argv[3]));
for(const p of o.sol)X.S.strokes.push({pts:p,len:D.plen(p),birth:0,mat:o.solmat||0});X.qpBuild();X.S.mode='run';
for(let f=0;f<+process.argv[4];f++){X.physics();if(f>+process.argv[5]&&f%2==0)console.log(f,X.S.ball.x.toFixed(1),X.S.ball.y.toFixed(1),X.S.ball.vx.toFixed(2),X.S.ball.vy.toFixed(2));}
const lv=X.LEVELS[48+(+process.argv[3])];const b=X.S.ball;
function ds(w,x,y){const dx=w[2]-w[0],dy=w[3]-w[1],t=Math.max(0,Math.min(1,((x-w[0])*dx+(y-w[1])*dy)/(dx*dx+dy*dy||1)));return Math.hypot(x-(w[0]+t*dx),y-(w[1]+t*dy));}
console.log((lv.walls||[]).map(w=>[ds(w,b.x,b.y),w.slice(0,5).map(Math.round).join(',')]).sort((a,b)=>a[0]-b[0]).slice(0,4).map(a=>a[0].toFixed(1)+' '+a[1]).join(' | '));
