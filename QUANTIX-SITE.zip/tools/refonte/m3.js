/* Monde 3 « Chaîne » — refonte fiches Opus (R300). Entrées : 12 niveaux ; v2 = R(x1,y1,x2,y2,v). */
const R=(x1,y1,x2,y2,v)=>[x1,y1,x2,y2,3,0,0,0,0,0,v];
const base=require('./chaine.js');
const J=o=>JSON.parse(JSON.stringify(o));
const out=base.map(J);
const NEW={};
NEW[27]={n:'Trois couleurs',ink:60,pal:'S',ball:[20,170],cup:[236,400,96,'R'],star:[300,372],
 nd:[[160,240,70,160]],
 w:[[0,470,40,470,0],R(40,250,150,250,10),R(40,310,150,310,7),R(40,370,150,370,2)],
 sol:[[[6,292],[40,308]]],solmat:0,tip:'Chaque couleur est une vitesse. Choisis celle qui porte juste à la coupe.',idee:'La couleur du ruban est sa vitesse : elle décide de la portée.'};
NEW[28]={n:'La chute est un élan',ink:105,pal:'SA',ball:[34,40],cup:[286,300,74,'R'],star:[330,272],
 w:[[0,300,140,300,0],[140,300,172,282,0]],
 sol:[[[67,274],[12,207]]],solmat:0,tip:'Le ruban ne te lance pas assez loin. Regarde d’où tu tombes.',idee:'La chute donne plus d’élan que le ruban.'};
NEW[29]={n:'Le sas',ink:60,pal:'S',ball:[20,14],cup:[290,380,70,'N'],star:[262,358],nd:[[286,0,74,470]],
 w:[[0,70,120,200,0],[120,200,170,200,0],R(205,380,290,380,2)],
 sol:[[[248,208],[236,184]]],solmat:0,tip:'Elle part trop vite : une zone ouverte ne la retiendra pas. Abaisse-la sur le ruban turquoise.',idee:'Un ruban lent efface la vitesse : amène la balle dessus.'};
const A_=(a,b,c,d)=>[a,b,c,d,3];
NEW[30]={n:'Le second souffle',ink:110,pal:'SA',ball:[22,308],cup:[315,262,45,'R'],star:[296,282],
 w:[A_(0,330,100,330),[100,330,215,300,0],[215,300,235,300,0],[275,300,315,262,0]],
 sol:[[[240,293],[286,289]]],solmat:3,tip:'Le ruban du bas s’éteint en montant. Où la balle est-elle lente ?',idee:'Un ruban ne pousse que ce qui est lent : recharge l’élan en haut.'};
NEW[31]={n:'Le courant',ink:150,pal:'S',ball:[24,172],cup:[290,250,70,'R'],star:[318,228],
 nd:[[70,262,200,170]],
 w:[A_(0,200,60,200),[60,200,60,440,0],R(60,440,290,440,10),[290,440,290,250,0],[254,436,290,436,2]],
 sol:[[[160,238],[265,222]]],solmat:0,tip:'Le courant du fond mène aux pointes. Ne le touche pas.',idee:'Un trait posé au-dessus éteint le ruban : ne laisse pas la balle y tomber.'};
NEW[32]={n:'Le ruban-mur',ink:130,pal:'A',ball:[24,358],cup:[200,380,90,'N'],star:[246,352],
 nd:[[0,0,360,300]],
 w:[A_(0,380,120,380),[120,380,200,380,0]],
 sol:[[[296,330],[296,380]]],solmat:3,tip:'Elle arrive trop vite et ressort de la coupe. Un ruban n’est pas qu’un tapis.',idee:'Un ruban dressé est un mur : la poussée ne compte que le long de lui.'};
NEW[33]={n:"L’escalier lent",ink:100,pal:'S',ball:[22,22],cup:[300,230,60,'R'],star:[238,332],
 w:[[0,40,100,104,0],A_(100,104,140,104),[110,452,190,432,0],[110,300,110,452,0],R(190,432,300,230,2),[250,190,360,190,2]],
 sol:[[[240,156],[223,77]]],solmat:0,tip:'Elle part trop vite et finit sur les pointes. Cherche plus bas.',idee:'Un ruban lent porte la balle en montée : descends pour monter.'};
NEW[34]={n:'Le bout utile',ink:195,pal:'SA',ball:[34,368],cup:[270,380,90,'R'],star:[200,350],
 nd:[[0,0,360,330]],
 w:[[0,380,150,380,0],[240,380,270,380,0]],
 sol:[[[24,371],[74,371]],[[150,380],[240,380]]],solmat:[3,0],tip:'Il faut deux gestes et une seule jauge d’encre. Qu’est-ce qui coûte le plus ?',idee:'Un ruban court suffit : garde l’encre pour le pont.'};
NEW[36]={n:"Rendre l’élan",ink:150,pal:'SA',ball:[24,20],cup:[300,230,60,'N'],star:[216,196],nd:[[0,0,200,170]],
 w:[A_(10,400,170,400),[130,230,200,230,0],R(200,227,240,227,10),R(240,227,270,227,7),R(270,227,300,227,2),R(300,227,352,227,0)],
 sol:[[[15,218],[40,242]],[[60,260],[111,237]]],solmat:[0,3],tip:'Même image qu’au début, mais tout est renversé. Ce qui t’aidait te perd.',idee:'L’élan se reçoit, se garde, se rend : rattrape la chute, relève-la, la machine la rend.'};
for(const k in NEW)out[k-25]=NEW[k];
module.exports=out;
