const H=require('./harness.js');
for(const bx of [45,70,100]){
const L={n:'g1',ink:400,pal:'A',ball:[bx,250],cup:[300,440,80,'R'],w:[[0,470,360,470,0]]};
const a=25*Math.PI/180,len=140,x0=40,y0=300;
const st=[{pts:[[x0,y0],[Math.round(x0+len*Math.cos(a)),Math.round(y0-len*Math.sin(a))]],mat:3}];
const r=H.runT(24,H.full(L),st,true);
console.log(bx,r.mode,r.tr.filter((_,i)=>i%6==0).slice(0,20).map(p=>p.join(',')).join(' '));}
