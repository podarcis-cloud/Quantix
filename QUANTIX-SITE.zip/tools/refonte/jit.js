const H=require('./harness.js');const o=require('./'+process.argv[2])[0];const slot=+process.argv[3]||34;const s=+process.argv[4]||3;
let seed=5;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};const g=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
const base=o.sol.map((p,i)=>({pts:p,mat:Array.isArray(o.solmat)?o.solmat[i]:o.solmat}));
for(const only of [-1,0,1]){let ok=0,T=60;for(let t=0;t<T;t++){const st=base.map((b,i)=>(only<0||only===i)?{pts:b.pts.map(q=>[q[0]+g()*s,q[1]+g()*s]),mat:b.mat}:b);if(H.runT(slot,H.full(o),st,false).ok)ok++;}console.log('jitter stroke',only<0?'all':only,ok+'/'+T);}
