const H=require('./harness.js');const m=require('./m12.js')[0];const r=H.runT(24,H.full(m),[],true);console.log('m12',r.mode,r.tr.filter((_,i)=>i%10==0).map(p=>p.join(',')).join(' '));
const o=require('./orig12.js')[0];const r2=H.runT(35,H.full(o),[],true);console.log('orig',r2.mode,r2.tr.filter((_,i)=>i%10==0).map(p=>p.join(',')).join(' '));
console.log(Object.keys(m).join(),Object.keys(o).join());
