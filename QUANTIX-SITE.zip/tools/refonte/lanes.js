const H=require('./harness.js'),path=require('path');const LV=require(path.resolve(process.argv[2])),k=+process.argv[3],L=LV[k-1];
const sts=JSON.parse(process.argv[4]);
for(const st of sts){const r=H.runT(24+k-1,H.full(L),[{pts:st,mat:+(process.env.MAT||0)}],true);
 const hit=r.tr.find(p=>p[1]>=395);
 console.log(JSON.stringify(st),r.mode,'fin',r.end,'à y395:',hit,'traj',r.tr.filter((_,i)=>i%12==0).map(p=>p.join(',')).join(' ').slice(0,260));}
