const H=require('./harness.js');const R=(a,b,c,d,v)=>[a,b,c,d,3,0,0,0,0,0,v];
for(const ang of [30,45,60,70]){for(const v of [2,4]){
 const a=ang*Math.PI/180,len=130,x0=120,y0=460,x1=Math.round(x0+len*Math.cos(a)),y1=Math.round(y0-len*Math.sin(a));
 const L={n:'t',ink:100,pal:'S',ball:[30,300],cup:[300,100,60,'R'],w:[[0,350,110,458,0],[110,458,120,460,0],R(x0,y0,x1,y1,v),[x1,y1-300,x1,y1,0]]};
 const r=H.runT(24,H.full(L),[],true);const miny=Math.min(...r.tr.map(p=>p[1]));
 console.log(ang,'v',v,'top',y1,'minY',miny,'end',r.end,r.tr.filter((_,i)=>i%30==0).map(p=>p.join(',')).join(' ').slice(0,200));}}
