/* emit.js FICHIER_CANDIDATS.js SORTIE_DIR — écrit levels.js refondu : remplace les niveaux 25–36 par les candidats modifiés ; les autres entrées sont reprises telles quelles. */
const fs=require('fs'),path=require('path');const cand=require(path.resolve(process.argv[2]));
const SRC=fs.readFileSync(path.join(__dirname,'../../assets/js/levels.js'),'utf8');
const M={0:'S_',1:'B_',2:'X_',3:'A_',4:'I_'};
const starts=[...SRC.matchAll(/^\{wd:/gm)].map(m=>m.index);
const entry=(c,k)=>{const w=(c.w||[]).map(s=>s.length>5?'R_('+[s[0],s[1],s[2],s[3],s[10]].join(',')+')':'['+s.slice(0,4).join(',')+','+M[s[4]]+']').join(',');
 let t="{wd:"+(process.env.WD||3)+",n:"+JSON.stringify(c.n).replace(/"/g,"'")+(c.sol?",optsol:"+JSON.stringify(c.sol)+",optmat:"+(Array.isArray(c.solmat)?c.solmat[0]:(c.solmat||0))+(Array.isArray(c.solmat)?",optmats:"+JSON.stringify(c.solmat):'')+(c.solat?",optat:"+JSON.stringify(c.solat):''):'')+",ink:"+c.ink+",pal:'"+c.pal+"',ball:"+JSON.stringify(c.ball)+",cup:"+JSON.stringify(c.cup).replace(/"/g,"'")+(c.star?",star:"+JSON.stringify(c.star):'')+",\n w:["+w+"]"+(c.nd?",nd:"+JSON.stringify(c.nd):'')+['curves','flow','mz','vortex','updraft','wind','port','wrap','grav'].filter(k=>c[k]!==undefined).map(k=>","+k+":"+JSON.stringify(c[k])).join('')+(c.tip?",\n tip:"+JSON.stringify(c.tip).replace(/^"|"$/g,"'").replace(/\\"/g,'"')+"},":"},");return t;};
const orig=starts.map((a,i)=>SRC.slice(a,starts[i+1]||SRC.length));
const NEWIDX=(process.env.NEW||'0,1,2,6,7,10').split(',').map(Number);
NEWIDX.forEach(i=>{const old=orig[(+process.env.BASE||24)+i];const tail=old.endsWith('\n')?'\n':'';orig[(+process.env.BASE||24)+i]=entry(cand[i],i)+'\n';});
/* niveaux conservés : nom et texte inchangés ; seule la 1ʳᵉ ligne du monde garde son indentation */
const out=SRC.slice(0,starts[0])+orig.join('');fs.mkdirSync(process.argv[3],{recursive:true});fs.writeFileSync(path.join(process.argv[3],'levels.js'),out);console.log('écrit',process.argv[3]+'/levels.js',out.length);
