const H=require('./harness.js'),X=H.X,D=H.D;const R=(a,b,c,d,v)=>[a,b,c,d,3,0,0,0,0,0,v];
for(const len of [60,100,140]){for(const drop of [100,300]){
 const L={n:'t',ink:100,pal:'S',ball:[100,400-drop],cup:[320,380,60,'R'],w:[R(60,400,60+len,400,2),[60+len,400,360,400,0]]};
 D.install(24,H.full(L));X.loadLevel(24);X.qpBuild();X.S.mode='run';let tr=[];
 for(let f=0;f<400&&X.S.mode==='run';f++){X.physics();tr.push([Math.round(X.S.ball.x),Math.round(X.S.ball.y),Math.hypot(X.S.ball.vx,X.S.ball.vy).toFixed(1)]);}
 console.log('len',len,'drop',drop,X.S.mode,tr.filter((_,i)=>i%40==0).map(p=>p.join(',')).join(' '));}}
