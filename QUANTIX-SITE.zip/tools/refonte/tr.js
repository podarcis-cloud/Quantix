const H=require('./harness.js');const o=require("./"+process.argv[2])[+(process.env.LVL||0)];const sol=o.sol.map((p,i)=>({pts:p,mat:Array.isArray(o.solmat)?o.solmat[i]:o.solmat}));
const r=H.runT(+process.argv[3]||34,H.full(o),sol,true);console.log(r.mode,r.tr.length,r.end);console.log(r.tr.filter((_,i)=>i%(+process.argv[4]||6)==0).map(p=>p.join(',')).join(' '));
