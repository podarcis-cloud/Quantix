/* probe.js FICHIER n° [traits JSON] — trajectoire sans (ou avec) traits : points toutes les 10 trames + fin. */
const H=require('./harness.js'),path=require('path');const LV=require(path.resolve(process.argv[2])),k=+process.argv[3],L=LV[k-1];
const st=process.argv[4]?JSON.parse(process.argv[4]):[];const r=H.runT(24+k-1,H.full(L),st,true);
console.log('mode',r.mode,'fin',r.end,'trames',r.tr.length);console.log(r.tr.filter((_,i)=>i%10===0).map(p=>p.join(',')).join(' '));
