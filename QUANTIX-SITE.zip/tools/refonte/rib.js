/* rib.js — rubans courbes à vitesse : Catmull-Rom dense + découpe en tronçons de même vitesse. */
function cr(P,step){const o=[];for(let i=0;i<P.length-1;i++){const p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)],n=Math.max(2,Math.round(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/step));
 for(let j=0;j<n;j++){const t=j/n,t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),.5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]);}}
 o.push(P[P.length-1]);return o.map(q=>[Math.round(q[0]*10)/10,Math.round(q[1]*10)/10]);}
/* V : sommets ; SP[i] : vitesse du tronçon V[i]→V[i+1] (null = structure m0) ; renvoie des curves {pts,m,v} */
function ribbon(V,SP,step){const dense=cr(V,step||6);const idxOf=v=>dense.findIndex(q=>Math.hypot(q[0]-v[0],q[1]-v[1])<.6);
 const out=[];let a=0;for(let i=0;i<SP.length;i++){if(i+1<SP.length&&SP[i+1]===SP[i])continue;const end=idxOf(V[i+1]);
  const c={pts:dense.slice(a,end+1),m:SP[i]===null?0:3,st:step||6};if(SP[i]!==null)c.v=SP[i];out.push(c);a=end;}return out;}
module.exports={cr,ribbon};
