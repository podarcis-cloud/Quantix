const H=require('./harness.js');const o=require('./m12.js')[0];const c=H.full(o);
let sd=3;const r=()=>{sd=(sd*16807)%2147483647;return (sd-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(r()+1e-12))*Math.cos(6.2832*r());
const res=[];for(let a=0;a<40;a++){const x1=40+r()*50,y1=250+r()*35,x2=120+r()*70,y2=225+r()*45;const p=[[Math.round(x1),Math.round(y1)],[Math.round(x2),Math.round(y2)]];
 if(!H.D.drawable(c,p))continue;if(!H.runT(24,c,[{pts:p,mat:3}],false).ok)continue;let ok=0;for(let t=0;t<30;t++){const q=p.map(a=>[a[0]+gs()*3,a[1]+gs()*3]);if(H.runT(24,c,[{pts:q,mat:3}],false).ok)ok++;}res.push([Math.round(ok/30*100),JSON.stringify(p)]);}
res.sort((a,b)=>b[0]-a[0]);console.log(res.slice(0,6).join('\n'));
