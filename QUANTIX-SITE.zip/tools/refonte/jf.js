const H=require('./harness.js');const o=require('./'+process.argv[2])[+process.argv[3]];const slot=48+(+process.argv[3]);const s=+process.argv[4]||3;
let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};const g=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
const base=o.sol.map((p,i)=>({pts:p,mat:Array.isArray(o.solmat)?o.solmat[i]:o.solmat}));let ok=0;const T=40;
for(let t=0;t<T;t++){const st=base.map(b=>({pts:b.pts.map(q=>[q[0]+g()*s,q[1]+g()*s]),mat:b.mat}));const r=H.runT(slot,H.full(o),st,false);if(r.ok)ok++;else console.log(JSON.stringify(st.map(x=>x.pts.map(q=>q.map(Math.round)))),r.mode,r.end);}
console.log(ok+'/'+T);
