/* Monde 5 « Soufflerie » — refonte (fiches Opus, FICHES_MONDE5.md). Index 0..11 = niveaux 49..60. */
const R=(x1,y1,x2,y2,v)=>[x1,y1,x2,y2,3,0,0,0,0,0,v];const A_=(a,b,c,d)=>[a,b,c,d,3];
const N={};const {ribbon}=require("./rib.js");
N[0]={n:'Le souffle',ink:108,pal:'S',ball:[110,60],cup:[272,172,80,'N'],star:[216,236],
 nd:[[0,0,360,60],[186,100,70,170],[250,60,110,86]],
 w:[[185,424,20,436,0],[185,424,252,424,0],[250,150,250,470,0],[356,60,356,160,0],[250,146,250,150,0],[0,436,20,436,2]],
 curves:[{pts:[[250,146],[270,160],[296,169],[326,169],[352,158]],m:0},{pts:[[190,112],[204,98],[226,90],[250,92],[268,100]],m:0}],
 wind:[[190,100,60,324,0,-0.8],[196,100,66,66,0.45,0]],
 sol:[[[84,318],[172,370]]],solmat:0,tip:'Ne bâtis pas la montée : pousse la balle dans le souffle.',idee:'L’air porte ; le trait ne fait que l’y conduire.'};
N[1]={n:'La couche',ink:210,pal:'S',ball:[30,20],cup:[204,440,96,'N'],star:[210,150],
 nd:[[0,0,360,40],[0,94,360,386]],
 w:[[10,96,130,110,0],[176,150,44,160,0],[178,128,178,152,0],[0,205,120,219,0],[0,170,0,210,0],[30,246,140,256,0],[200,340,200,440,0],[200,440,306,440,0],[306,340,306,440,0],[306,340,330,340,2],[0,440,200,440,2]],
 wind:[[0,260,360,60,1.6,0]],
 sol:[[[14,66],[192,76]]],solmat:0,tip:'Lâche-la de haut : rapide, elle traverse la couche sans dériver.',idee:'Le vent pousse en proportion du temps passé dedans.'};
N[3]={n:'Ramer',ink:330,pal:'SA',ball:[22,100],cup:[312,302,40,'R'],star:[200,262],
 nd:[[0,0,360,90],[96,200,224,66],[304,200,56,100]],
 w:[[0,130,70,296,0],[70,296,96,296,0],[118,300,356,300,0],[96,310,118,310,2],[96,310,96,340,0],[118,310,118,340,0],[96,340,118,340,2],[356,200,356,302,0]],
 wind:[[100,240,200,62,-0.4,0]],
 sol:[[[112,290],[298,290]]],solmat:3,tip:'Contre le vent, l’élan s’épuise : pose un ruban, il pousse toujours.',idee:'Un vent long use tout élan ; seul un ruban avance contre lui.'};
N[2]={n:'L’ascenseur',ink:66,pal:'S',ball:[20,40],cup:[276,238,70,'L'],star:[196,196],
 nd:[[140,0,130,100],[150,100,120,130]],
 w:[[150,312,150,470,0],[140,298,150,298,0],[150,470,270,470,0],[270,330,270,470,0],[270,440,352,440,2],[352,60,352,440,0],[276,238,346,238,0]],
 curves:[{pts:[[6,100],[40,200],[90,278],[140,298]],m:0},{pts:[[150,106],[190,98],[230,96],[262,102]],m:0}].concat(
  ribbon([[262,122],[294,130],[326,144]],[10,10]),ribbon([[340,200],[316,212],[292,222]],[2,2])),
 wind:[[150,100,120,370,0,-0.8],[150,96,140,56,0.5,0]],
 sol:[[[184,296],[231,257]]],solmat:0,tip:'Arrête la balle dans la colonne : immobile, elle monte.',idee:'Une colonne étroite ne soulève que ce qui y reste.'};
const dy=(a,k)=>a.map(p=>Array.isArray(p[0])?dy(p,k):[p[0],p[1]-k]);
N[8]={n:'Le carrefour',ink:62,pal:'S',ball:[26,40],cup:[100,452,90,'L'],star:[250,300],
 nd:[[0,0,360,250],[40,250,300,80],[150,200,60,240],[0,330,196,150]],
 w:[[200,462,360,462,2],[352,350,352,462,0],[100,452,200,452,0],[0,462,100,462,2]],
 curves:ribbon([[8,72],[50,90],[96,104],[140,112],[180,118]],[7,7,2,2]).concat([{pts:[[262,392],[236,414],[206,432],[184,444]],m:0}]),
 wind:[[40,250,300,80,0.5,0],[150,200,60,240,0,-0.3]],
 sol:[[[286,330],[244,372]]],solmat:0,tip:'Là où les vents se croisent, ils s’additionnent : attends-la où leur somme l’envoie.',idee:'Deux vents qui se croisent en font un troisième, oblique.'};
N[5]={n:'La cascade inversée',ink:50,pal:'S',ball:[18,20],cup:[262,436,86,'R'],star:[170,200],
 nd:[[0,128,360,352]],
 curves:ribbon([[6,418],[44,421],[94,425],[154,429],[210,430],[262,428],[300,424],[334,430]],[2,2,10,10,10,7,0]).concat([{pts:[[0,60],[28,96],[66,114],[104,118]],m:0},{pts:[[134,310],[90,350],[70,362],[40,382],[30,388]],m:0}]),
 w:[[0,452,260,452,2],[0,280,0,440,0],[352,380,352,452,0],[52,384,340,384,0]],
 wind:[[0,150,360,290,-0.8,0]],
 sol:[[[174,124],[160,86]]],solmat:0,tip:'Lance la balle loin et haut, contre le vent : il te la ramène.',idee:'Un vent constant renvoie ce qu’on lui lance.'};
{const H=require('./harness.js');const L=H.X.LEVELS[59],K=90,sh=(P)=>P.map(q=>[q[0],q[1]-K]);
 const ring=L.curves.map(c=>({pts:sh(c.pts),m:c.m}));
 const mach=ribbon([[150,336],[186,347],[230,358],[272,368],[312,374]],[2,2,10,10]).concat(ribbon([[344,418],[300,426],[255,433],[215,438],[175,441],[136,446]],[7,7,10,2,2]));
 N[11]={n:'Le cyclone',ink:90,pal:'S',ball:[112,L.ball[1]-K],cup:[120,470,110,'L'],star:[180,L.star[1]-K],
  nd:[[0,0,360,176],[0,176,150,96],[0,274,360,200]],w:[[350,300,350,440,0]],
  curves:ring.concat(mach),
  vortex:[L.vortex[0],L.vortex[1]-K,L.vortex[2],L.vortex[3]],
  wind:L.wind.map(w=>[w[0],w[1]-K,w[2],w[3],w[4],w[5],w[6]]),flow:sh(L.flow),
  sol:[[[177,225],[203,211]]],solmat:0,tip:'Le tourbillon la retient pour toujours. Glisse une lame dans sa course pour l’en arracher.',idee:'On ne barre pas un tourbillon : on lui prend la balle d’un trait tangent.'};}
module.exports=Array.from({length:12},(_,i)=>N[i]||null);
