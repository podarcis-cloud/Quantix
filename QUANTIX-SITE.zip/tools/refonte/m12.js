/* Finale « La grande chaîne » : machine d'origine (looping) allongée — descente rapide, demi-tour, chicane lente, frein. */
const H=require('./harness.js'),X=H.X;const R=(a,b,c,d,v)=>[a,b,c,d,3,0,0,0,0,0,v];
const L=X.LEVELS[35];const o={};for(const k of ['ink','pal','ball','cup','star','w','nd','curves','tip','mz','flow','vortex','updraft'])if(L[k]!==undefined)o[k]=JSON.parse(JSON.stringify(L[k]));
o.n='La grande chaîne';o.sol=[[[51,262],[160,240]]];o.solmat=3;o.ink=230;
o.nd=[[0,296,360,184]];
o.w=o.w.concat([[0,346,290,330,0],R(340,372,82,404,10),R(84,452,150,452,10),R(150,452,210,452,2),R(210,452,262,452,7),R(268,467,344,467,0)]);
o.curves.push({pts:[[100,364],[66,368],[42,390],[32,428],[38,442],[56,450],[82,452]],m:0});
module.exports=[o];
if(require.main===module){const r=H.runT(35,H.full(o),[{pts:o.sol[0],mat:3}],true);console.log(r.mode,r.tr.length,r.end);console.log(r.tr.filter((_,i)=>i%10==0).map(p=>p.join(',')).join(' '));}
