/* Refonte à fond du monde 3 (ruban v2 : vitesse cible R_). Candidats. */
const R=(x1,y1,x2,y2,v)=>[x1,y1,x2,y2,3,0,0,0,0,0,v];
module.exports=[
/*31 */{n:'Le ruban qui freine',ink:200,pal:'S',ball:[75,270],cup:[270,330,80,'R'],star:[290,262],w:[R(50,330,150,330,10),R(150,330,210,330,2),[210,330,230,330,0],[230,420,260,420,2],[0,470,360,470,2]],
 sol:[[[140,332],[234,279]]],solmat:0,tip:'Le ruban de droite est lent : il freine tout ce qui le touche. Ne t’y pose pas.',idee:"Un ruban lent freine : il faut le sauter."},
];
