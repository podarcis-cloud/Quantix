const H=require('./harness.js'),X=H.X;
const L=X.LEVELS[35];const o={};for(const k of ['n','ink','pal','ball','cup','star','w','nd','curves','flow','tip','mz'])if(L[k]!==undefined)o[k]=JSON.parse(JSON.stringify(L[k]));
o.sol=L.optsol;o.solmat=L.optmat;
module.exports=[o];
if(require.main===module){const r=H.runT(35,H.full(o),[{pts:o.sol[0],mat:3}],true);console.log(r.mode,r.tr.length);console.log(r.tr.filter((_,i)=>i%12==0).map(p=>p.join(',')).join(' '));console.log(JSON.stringify(o.curves.map(c=>c.pts.length)),JSON.stringify(o.flow));}
