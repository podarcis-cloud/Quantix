const H=require('./harness.js');const o=require('./'+process.argv[2])[+process.argv[3]];const slot=48+(+process.argv[3]);const c=H.full(o);
let seed=11;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};const g=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
const best=[];for(let a=0;a<+process.argv[4];a++){const x=(+process.env.X0||170)+rnd()*(+process.env.XW||80),y=(+process.env.Y0||190)+rnd()*(+process.env.YW||70),ang=rnd()*6.28,len=20+rnd()*45;const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(ang)*len),Math.round(y+Math.sin(ang)*len)]];
 if(!H.D.drawable(c,p))continue;if(!H.runT(slot,c,[{pts:p,mat:o.solmat||0}],false).ok)continue;let ok=0;for(let t=0;t<16;t++){const q=p.map(z=>[z[0]+g()*3,z[1]+g()*3]);if(H.runT(slot,c,[{pts:q,mat:o.solmat||0}],false).ok)ok++;}best.push([ok,JSON.stringify(p)]);}
best.sort((a,b)=>b[0]-a[0]);console.log(best.slice(0,5).map(b=>b.join(' ')).join('\n'));
