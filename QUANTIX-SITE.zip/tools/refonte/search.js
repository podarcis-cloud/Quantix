/* search.js — cherche des solutions (1 ou 2 traits) d'un candidat SANS solution écrite : node search.js FICHIER n° [N1] [N2] ; affiche les gagnants par matière et la famille. */
const H=require('./harness.js'),D=H.D,path=require('path');
const f=path.resolve(process.argv[2]),LV=require(f),k=+process.argv[3],N1=+(process.argv[4]||4000),N2=+(process.argv[5]||0);
const L=LV[k-1],slot=(+process.env.BASE||24)+k-1,c=H.full(L),COST={0:1,1:1.9,3:1.7,5:1};
let seed=17;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const mats=(L.pal||'S').split('').map(x=>({S:0,B:1,A:3,C:5}[x]));
function line(inkMax){const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,inkMax/COST[m]);if(maxL<15)return null;const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15);
 const p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];return D.drawable(c,p)?{pts:p,mat:m,cost:len*COST[m]}:null;}
const win=[];let n=0;
while(n<N1){const s=line(L.ink);if(!s)continue;n++;const r=H.runT(slot,c,[s],false);if(r.ok)win.push([s]);}
console.log('1 trait :',win.length,'/',N1,'par matière',JSON.stringify(win.reduce((a,w)=>(a[w[0].mat]=(a[w[0].mat]||0)+1,a),{})));
const w2=[];n=0;
while(n<N2){const a=line(L.ink),b=line(L.ink);if(!a||!b||a.cost+b.cost>L.ink)continue;n++;const r=H.runT(slot,c,[a,b],false);if(r.ok)w2.push([a,b]);}
if(N2)console.log('2 traits :',w2.length,'/',N2);
const show=w=>w.map(s=>s.mat+':'+JSON.stringify(s.pts)).join(' + ');
win.sort((a,b)=>a[0].cost-b[0].cost).slice(0,6).forEach(w=>console.log(' ',show(w),Math.round(w[0].cost)));
w2.sort((a,b)=>a[0].cost+a[1].cost-b[0].cost-b[1].cost).slice(0,6).forEach(w=>console.log(' ',show(w),Math.round(w[0].cost+w[1].cost)));

/* robustesse : réussite sous bruit de doigt σ=3 u sur les extrémités (les 40 gagnants les moins chers) */
if(process.env.ROB){const gs=()=>Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());
 const lst=win.concat(w2).sort((a,b)=>a.reduce((s,x)=>s+x.cost,0)-b.reduce((s,x)=>s+x.cost,0)).slice(0,+process.env.ROB);
 const out=lst.map(w=>{let ok=0;const T=24;for(let t=0;t<T;t++){const st=w.map(s=>({pts:s.pts.map(q=>[q[0]+gs()*3,q[1]+gs()*3]),mat:s.mat}));if(H.runT(slot,c,st,false).ok)ok++;}return [Math.round(ok/T*100),show(w),Math.round(w.reduce((s,x)=>s+x.cost,0))];});
 out.sort((a,b)=>b[0]-a[0]).slice(0,8).forEach(o=>console.log('  robuste',o[0]+'%',o[1],o[2]));}
