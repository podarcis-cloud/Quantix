#!/usr/bin/env python3
"""draw.py N… — dessine /tmp/rf/L{N}.json (murs, zone, balle, coupe, solution, trajectoire) → /tmp/rf/L{N}.png (planche si plusieurs)"""
import json,sys
from PIL import Image,ImageDraw
COL={0:(150,200,230),1:(110,230,150),2:(255,80,80),3:(180,120,255),4:(190,235,247)}
def one(n):
    d=json.load(open('/tmp/rf/L%d.json'%n));L=d['L'];S=2
    im=Image.new('RGB',(360*S,480*S),(8,10,18));g=ImageDraw.Draw(im,'RGBA')
    for r in L.get('nd') or []:g.rectangle([r[0]*S,r[1]*S,(r[0]+r[2])*S,(r[1]+r[3])*S],fill=(255,60,80,70),outline=(255,60,80,200))
    for w in L.get('w') or []:g.line([w[0]*S,w[1]*S,w[2]*S,w[3]*S],fill=COL.get(w[4],(200,200,200)),width=5)
    for c in L.get('curves') or []:g.line([(p[0]*S,p[1]*S) for p in c['pts']],fill=COL.get(c.get('m',0)),width=4)
    x,y,w,s=L['cup'];g.line([x*S,y*S,(x+w)*S,y*S],fill=(255,216,90),width=5)
    if s in('R','B'):g.line([(x+w)*S,y*S,(x+w)*S,(y-56)*S],fill=(255,216,90),width=5)
    if s in('L','B'):g.line([x*S,y*S,x*S,(y-56)*S],fill=(255,216,90),width=5)
    if L.get('star'):a,b=L['star'][:2];g.ellipse([(a-5)*S,(b-5)*S,(a+5)*S,(b+5)*S],outline=(255,255,120),width=2)
    t=d.get('tr') or []
    if len(t)>1:g.line([(p[0]*S,p[1]*S) for p in t],fill=(255,255,255,150),width=2)
    for k,p in enumerate(L.get('sol') or []):
        m=(L.get('solmat') if not isinstance(L.get('solmat'),list) else L['solmat'][k]) or 0
        g.line([p[0][0]*S,p[0][1]*S,p[-1][0]*S,p[-1][1]*S],fill=COL.get(m,(255,255,255))+(255,),width=3);g.ellipse([p[0][0]*S-4,p[0][1]*S-4,p[0][0]*S+4,p[0][1]*S+4],fill=(255,255,255))
    bx,by=L['ball'];g.ellipse([(bx-10)*S,(by-10)*S,(bx+10)*S,(by+10)*S],outline=(255,255,255),width=2)
    g.text((6,6),'N%d %s'%(n,L['n']),fill=(255,255,255));return im
ns=[int(a) for a in sys.argv[1:]];ims=[one(n) for n in ns];W=Image.new('RGB',(720*len(ims)//1 if len(ims)<=4 else 720*4,960*((len(ims)+3)//4)))
for k,i in enumerate(ims):W.paste(i,((k%4)*720,(k//4)*960))
W.save('/tmp/rf/board.png');print('ok')
