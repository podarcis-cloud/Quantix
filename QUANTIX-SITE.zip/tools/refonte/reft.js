const H=require('./harness.js'),path=require('path');const LV=require(path.resolve(process.argv[2])),k=+process.argv[3],L=LV[k-1],c=H.full(L);
const cands=JSON.parse(process.argv[4]),mat=+(process.argv[5]||0);let sd=7;const r=()=>{sd=(sd*16807)%2147483647;return (sd-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(r()+1e-12))*Math.cos(6.2832*r());
for(const p of cands){let ok=0;const T=60;for(let t=0;t<T;t++){const q=p.map(a=>[a[0]+gs()*3,a[1]+gs()*3]);if(H.runT(24+k-1,c,[{pts:q,mat}],false).ok)ok++;}console.log(JSON.stringify(p),Math.round(ok/T*100)+'%');}
