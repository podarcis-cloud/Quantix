const H=require('./harness.js');const {runL}=require('./t11.js');const o=require('./'+process.argv[2])[0];const c=H.full(o);
let s='',runs=[],cur=null;for(let at=5;at<=260;at+=3){const r=runL(34,c,[{at,pts:o.sol[0],mat:o.solmat}],false);if(r.ok){if(!cur)cur=[at,at];else cur[1]=at;}else if(cur){runs.push(cur);cur=null;}}
if(cur)runs.push(cur);console.log(runs.map(r=>r.join('-')).join(' | '));
