/* Niveau 34 : « L’îlot lent » — un saut, un îlot qui éteint l'élan, une relance. */
const R=(x1,y1,x2,y2,v)=>[x1,y1,x2,y2,3,0,0,0,0,0,v];const A_=(a,b,c,d)=>[a,b,c,d,3];
const o={n:'L’îlot lent',ink:215,pal:'SA',ball:[26,368],cup:[276,380,84,'R'],star:[176,356],
 nd:[[0,0,360,330],[0,330,92,34],[140,388,72,26]],
 w:[[0,380,90,380,0],R(146,380,206,380,2),[266,380,360,380,0],[360,300,360,380,0]],
 sol:[[[24,371],[88,371]],[[206,380],[266,380]]],solmat:[3,3],tip:'L’îlot au milieu coupe ton élan. Après lui, il faut le rendre.',idee:'Un ruban lent éteint l’élan : saute avant lui, relance après lui.'};
module.exports=[o];
