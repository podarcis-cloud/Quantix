const m=require('./m3.js').map(x=>JSON.parse(JSON.stringify(x)));
const rel=m[11];            /* « Rendre l'élan » passe en 8 */
const out=m.slice();
out[5]=require('./m6.js')[0];
out[7]=rel;
out[9]=require('./m10.js')[0];
out[10]=require('./m11.js')[0];
out[11]=require('./m12.js')[0];
module.exports=out;
