const H=require('./harness.js'),D=H.D;const LV=require('./m3.js'),L=LV[11],c=H.full(L),slot=35;
let seed=5;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};
const R=(a,b)=>a+rnd()*(b-a);const win=[];
for(let n=0;n<14000;n++){
 const x1=R(0,60),y1=R(190,320),a1=R(0.2,0.9),l1=R(25,70);
 const s1=[[Math.round(x1),Math.round(y1)],[Math.round(x1+Math.cos(a1)*l1),Math.round(y1+Math.sin(a1)*l1)]];
 const x2=R(50,190),y2=R(250,390),a2=-R(0.2,0.9),l2=R(25,70);
 const s2=[[Math.round(x2),Math.round(y2)],[Math.round(x2+Math.cos(a2)*l2),Math.round(y2+Math.sin(a2)*l2)]];
 const m1=0,m2=rnd()<.5?0:3;if(!D.drawable(c,s1)||!D.drawable(c,s2))continue;
 const cost=l1+l2*(m2==3?1.7:1);if(cost>210)continue;
 const r=H.runT(slot,c,[{pts:s1,mat:m1},{pts:s2,mat:m2}],false);if(r.ok)win.push([s1,m1,s2,m2,Math.round(cost)]);}
console.log('wins',win.length);win.slice(0,8).forEach(w=>console.log(JSON.stringify(w)));
let sd=9;const r2=()=>{sd=(sd*16807)%2147483647;return (sd-1)/2147483646;};const gs=()=>Math.sqrt(-2*Math.log(r2()+1e-12))*Math.cos(6.2832*r2());
const out=win.map(w=>{let ok=0;for(let t=0;t<20;t++){const j=p=>p.map(q=>[q[0]+gs()*3,q[1]+gs()*3]);if(H.runT(slot,c,[{pts:j(w[0]),mat:w[1]},{pts:j(w[2]),mat:w[3]}],false).ok)ok++;}return [ok*5,w];});
out.sort((a,b)=>b[0]-a[0]).slice(0,5).forEach(o=>console.log('rob',o[0],JSON.stringify(o[1])));
