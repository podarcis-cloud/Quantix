/* Niveau 30 spécial : « Le second souffle » — pont, puis montagnes russes de rubans COURBES (vitesses 10/7/10/7/10/2). */
const A_=(a,b,c,d)=>[a,b,c,d,3];
function cr(P,step){const o=[];for(let i=0;i<P.length-1;i++){const p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)],n=Math.max(2,Math.round(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/step));
 for(let j=0;j<n;j++){const t=j/n,t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),.5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]);}}
 o.push(P[P.length-1]);return o.map(q=>[Math.round(q[0]*10)/10,Math.round(q[1]*10)/10]);}
/* sommets du parcours et vitesse de chaque tronçon */
const V=[[352,366],[316,388],[276,398],[236,392],[202,380],[170,386],[140,404],[104,426],[66,438],[30,442]];
const SP=[10,10,7,7,7,10,10,10,2];
const dense=cr(V,6);const idxOf=v=>dense.findIndex(q=>Math.hypot(q[0]-v[0],q[1]-v[1])<.6);
const curves=[];let a=0;for(let i=0;i<SP.length;i++){const last=i+1<SP.length&&SP[i+1]===SP[i];if(last)continue;
 const end=idxOf(V[i+1]);curves.push({pts:dense.slice(a,end+1),m:3,v:SP[i],st:6});a=end;}
const o={n:'Le second souffle',ink:110,pal:'SA',ball:[22,308],cup:[10,462,96,'L'],star:[300,392],
 nd:[[0,346,360,134]],
 w:[A_(0,330,100,330),[215,300,235,300,0],[275,300,315,262,0],[315,262,322,262,0],[360,236,360,374,0],[140,342,275,352,0],[275,352,275,300,0]],
 curves:[{pts:[[100,330],[140,328],[182,316],[215,300]],m:0}].concat(curves),
 sol:[[[240,293],[286,289]]],solmat:3,tip:'Le ruban du bas s’éteint en montant. Où la balle est-elle lente ? Puis la machine prend le relais.',idee:'Un ruban ne pousse que ce qui est lent : recharge l’élan en haut.'};
module.exports=[o];
