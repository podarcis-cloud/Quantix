/* base3.js — monde 3 actuel au format candidat (sol/solmat) pour mesurer l'existant avec le même banc. */
const H=require('./harness.js'),X=H.X;
module.exports=X.LEVELS.slice(24,36).map(L=>{const o={};for(const k of ['n','ink','pal','ball','cup','star','w','nd','curves','flow','tip'])if(L[k]!==undefined)o[k]=JSON.parse(JSON.stringify(L[k]));
 o.sol=L.optsol;o.solmat=L.optmat||0;return o;});
