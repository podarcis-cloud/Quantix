const H=require('./harness.js');const o=require('./orig12.js')[0];
console.log('orig sans trait',H.runT(35,H.full(o),[],false).mode);
const m=require('./m12.js')[0];console.log('m12 sans trait slot24',H.runT(24,H.full(m),[],true).mode, 'slot35',H.runT(35,H.full(m),[],false).mode);
