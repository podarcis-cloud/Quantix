const H=require('./harness.js');
for(const ang of [25,40,55,70,85]){
 const a=ang*Math.PI/180,len=140,x0=100,y0=400,x1=Math.round(x0+len*Math.cos(a)),y1=Math.round(y0-len*Math.sin(a));
 for(const f of [.3,.6]){const bx=Math.round(x0+f*(x1-x0))-14,by=Math.round(y0+f*(y1-y0))-60;
  const L={n:'g1',ink:400,pal:'A',ball:[bx,by],cup:[300,440,80,'R'],w:[[0,470,360,470,0]]};
  const r=H.runT(24,H.full(L),[{pts:[[x0,y0],[x1,y1]],mat:3}],true);
  const miny=Math.min(...r.tr.map(p=>p[1]));
  console.log(ang,f,'ribbon top y',y1,'ball min y',miny,'end',r.end);}}
