require('./load.js');
const X=globalThis.__X, {store}=require('./load.js');
let timers=[];global.setTimeout=(f,d)=>{timers.push({f,d});return timers.length;};global.clearTimeout=()=>{};
const orph=Object.keys(X.DICT.fr).filter(k=>!(k in X.DICT.en));
console.log('clés FR sans EN :',orph.length?orph:'aucune');
function parse(){
  const h=store['wMap'].innerHTML;
  const nodes=[...h.matchAll(/<g class="wn ([a-z ]+)" id="wn(\d+)" data-i="(\d+)"/g)].map(m=>m[1]);
  const lines=[...h.matchAll(/<line class="wl ([a-z]+)"/g)].map(m=>m[1]);
  const vb=(h.match(/viewBox="([^"]+)"/)||[])[1];
  const img=(h.match(/<image href="([^"]+)"/)||[])[1]||'';
  return {nodes,lines,vb,img,rect:h.indexOf('<rect')>=0};
}
const sym=s=>({done:'●',cur:'◉',open:'○',lock:'·'}[s]||s);
// 1 · partie neuve, monde 1
X.S.unlocked=0;for(let i=0;i<X.S.best.length;i++)X.S.best[i]=0;
X.openWorld(1);let p=parse();
console.log('\nmonde 1, partie neuve   ',p.nodes.map(sym).join(' '),'· lignes validées',p.lines.filter(l=>l==='done').length,'/',p.lines.length);
console.log('  viewBox',p.vb,'· image du monde 1 :',p.img.slice(4000,4080)===X.WART[1].slice(4000,4080));
// 2 · cinq niveaux validés
for(let i=0;i<5;i++)X.S.best[i]=2;X.S.unlocked=5;
X.openWorld(1);p=parse();
console.log('monde 1, 5 validés      ',p.nodes.map(sym).join(' '),'· lignes validées',p.lines.filter(l=>l==='done').length);
// 3 · chaque monde illustré porte sa propre image
for(const w of [2,3]){X.S.unlocked=40;X.openWorld(w);p=parse();
  console.log('monde',w,'· son image :',p.img.slice(4000,4080)===X.WART[w].slice(4000,4080),'· viewBox',p.vb,'·',p.nodes.length,'nœuds');}
// 4 · les 11 mondes portent désormais chacun leur illustration (R28)
X.openWorld(7);p=parse();
console.log('monde 7 · son image :',p.img.slice(4000,4080)===X.WART[7].slice(4000,4080),'·',p.nodes.length,'nœuds générés');
// 5 · enchaînement : après le niveau 5 on revient à la carte puis au niveau 6
for(let i=0;i<X.S.best.length;i++)X.S.best[i]=0;for(let i=0;i<5;i++)X.S.best[i]=2;X.S.unlocked=5;
timers=[];X.advance(4);
const anim=timers.filter(t=>t.d<2000).map(t=>t.d),adv=timers.find(t=>t.d>=2000);
console.log('\naprès le niveau 5 · étapes d’animation à',anim.join(', '),'ms · passage au suivant à',adv&&adv.d,'ms');
store['vWorld'].classList.contains=()=>true;
adv.f();console.log('  niveau chargé ensuite :',X.S.li+1,'(attendu 6)');
// 6 · fin de monde : le niveau 12 mène à la carte du monde 2, sans lancer de niveau
for(let i=0;i<12;i++)X.S.best[i]=2;X.S.unlocked=12;X.S.li=11;
timers=[];X.advance(11);const adv2=timers.find(t=>t.d>=2000);
const before=X.S.li;adv2.f();p=parse();
console.log('fin du monde 1 → carte affichée :',p.img.slice(4000,4080)===X.WART[2].slice(4000,4080)?'monde 2':'AUTRE','· niveau inchangé :',X.S.li===before);
