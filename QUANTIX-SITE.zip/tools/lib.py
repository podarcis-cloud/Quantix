# Outils communs : extraction de tampons audio depuis la page, mesures de fidélité
import base64, json, numpy as np, wave

ENC = """()=>{window.__enc=function(b,s0,n){s0=s0||0;n=n||b.length-s0;var C=b.numberOfChannels,out=[];for(var c=0;c<Math.min(2,C);c++){var d=b.getChannelData?b.getChannelData(c):b[c],u=new Int16Array(n),i,v;for(i=0;i<n;i++){v=d[s0+i]||0;u[i]=v<-1?-32768:v>1?32767:Math.round(v*32767);}var by=new Uint8Array(u.buffer),s='';for(i=0;i<by.length;i+=8192)s+=String.fromCharCode.apply(null,by.subarray(i,i+8192));out.push(btoa(s));}return {sr:b.sampleRate||44100,ch:out};};}"""

def dec(o):
    ch = [np.frombuffer(base64.b64decode(s), dtype=np.int16).astype(np.float32) / 32767 for s in o['ch']]
    if len(ch) == 1: ch = ch * 2
    return np.stack(ch), o['sr']

def readwav(p):
    w = wave.open(p); n = w.getnframes(); c = w.getnchannels(); sr = w.getframerate()
    x = np.frombuffer(w.readframes(n), dtype=np.int16).astype(np.float32).reshape(-1, c).T / 32767
    if c == 1: x = np.vstack([x, x])
    return x, sr

def env(x, sr, win=.05):
    m = x.mean(0) if x.ndim == 2 else x; k = int(sr * win); n = len(m) // k
    return np.sqrt((m[:n * k].reshape(n, k) ** 2).mean(1) + 1e-12)

def spec(x, sr, nfft=4096):
    m = x.mean(0) if x.ndim == 2 else x; n = len(m) // nfft
    S = np.abs(np.fft.rfft(m[:n * nfft].reshape(n, nfft) * np.hanning(nfft), axis=1)).mean(0)
    f = np.fft.rfftfreq(nfft, 1 / sr)
    # bandes de tiers d'octave 40 Hz - 16 kHz
    edges = 40 * 2 ** (np.arange(0, 28) / 3); b = []
    for a, z in zip(edges[:-1], edges[1:]):
        s = (f >= a) & (f < z); b.append(20 * np.log10(S[s].mean() + 1e-9) if s.any() else -180)
    return np.array(b)

def xcorr_lag(a, b, sr, maxlag=.5):
    # décalage (s) de b par rapport à a sur enveloppes fines (5 ms)
    ea, eb = env(a, sr, .005), env(b, sr, .005); n = min(len(ea), len(eb)); ea, eb = ea[:n] - ea[:n].mean(), eb[:n] - eb[:n].mean()
    L = int(maxlag / .005); best = (-2, 0)
    for l in range(-L, L + 1):
        x, y = (ea[max(0, -l):n - max(0, l)], eb[max(0, l):n - max(0, -l)])
        r = np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y) + 1e-12)
        if r > best[0]: best = (r, l)
    return best[1] * .005, float(best[0])

def compare(a, b, sr, label=''):
    n = min(a.shape[1], b.shape[1]); a, b = a[:, :n], b[:, :n]
    ea, eb = env(a, sr), env(b, sr)
    renv = float(np.corrcoef(ea, eb)[0, 1])
    sa, sb = spec(a, sr), spec(b, sr)
    rs = float(np.corrcoef(sa, sb)[0, 1]); dspec = float(np.abs((sa - sa.mean()) - (sb - sb.mean())).max())
    rms = lambda x: float(np.sqrt((x ** 2).mean()) + 1e-12)
    lvl = float(20 * np.log10(rms(b) / rms(a)))
    am, bm = a.mean(0), b.mean(0); rw = float(np.dot(am, bm) / (np.linalg.norm(am) * np.linalg.norm(bm) + 1e-12))
    lag, rl = xcorr_lag(a, b, sr)
    d = dict(label=label, dur=n / sr, r_env=round(renv, 4), r_spec=round(rs, 4), dspec_max_db=round(dspec, 1), level_db=round(lvl, 2), r_wave=round(rw, 4), lag_ms=round(lag * 1000, 1), r_env_aligned=round(rl, 4))
    return d
