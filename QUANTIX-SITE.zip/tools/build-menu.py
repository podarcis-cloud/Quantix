"""build-menu.py — R192 : construit le « MENU édition » (studio/menu-edition.html) et sa version texte (docs/MENU_EDITION.md).
Un seul endroit où convergent les éditeurs, les artefacts, les fichiers du Projet, les outils de calcul (lus dans tools/ :
première ligne d'en-tête + date de modification) et la méthode de travail logique et graphique.
Usage : python3 tools/build-menu.py [Rxxx]   → puis publier studio/menu-edition.html à la même adresse (seulement s'il a changé).
Pour ajouter un lien ou une règle : éditer LIENS / METHODE ci-dessous ; un document du Projet : docs/menu-docs.json."""
import os, re, sys, json, html, datetime
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VER = sys.argv[1] if len(sys.argv) > 1 else ''
if not VER:
    m = re.search(r'build (R\d+)', open(os.path.join(ROOT, 'index.html'), encoding='utf-8').read()); VER = m.group(1) if m else 'R?'

LIENS = [  # (nom, rôle, adresse, statut)
 ('Aperçu du jeu', "Le jeu complet, jouable. Ouvert sur l'accueil, tous les mondes débloqués. Contient les prototypes en attente de validation (signalés).", 'https://claude.ai/artifact/ASrEUAFnV6NoqYmm6zGkeC', 'à jour à chaque livraison'),
 ('Éditeur de niveaux', "Simon dessine les niveaux au doigt ; Claude les lit dans la base (collection niveaux, documents Q-MM-PP).", 'https://claude.ai/artifact/1a3sK3pRaLi1c9LDKJnGrp', 'source studio/editeur-niveaux.js'),
 ('Banc des rendus', "Rendus à valider avant intégration : interface, didacticiel, holographie, mondes.", 'https://claude.ai/artifact/YLLD3eGHDLFWP3k44nfMxW', 'tools/build-galerie.py'),
 ('Quantone · six instruments', "L'instrument de Quantix (version la plus récente). Préréglages de Simon : docs/quantone-presets-simon/.", 'https://claude.ai/artifact/AjzgmbymcAJkwqkWtKH2By', 'source studio/quantone.html'),
 ('Quantone (version d’origine)', "Première version de l'instrument, gardée pour comparaison.", 'https://claude.ai/artifact/CzoWYZZrtEv2nF9q8cjiq5', 'archive'),
 ('Éditeur de particule', "Motif et forme de la particule. Dans le jeu (panneau « Atelier de particule »), bouton d'accueil masqué depuis R115 ; pas d'artefact séparé.", '', 'dans le jeu, masqué'),
 ('Site en ligne', "La version installée (GitHub Pages).", 'https://podarcis-cloud.github.io/', 'racine du compte · chemin exact du dossier à confirmer'),
]

METHODE = [
 ('Chaque tour', [
  "Claude donne le lien de ce menu à chaque réponse ; il ne le republie que si son contenu a changé (chaque publication demande une confirmation).",
  "Au début d'une session : lire REPRISE-SESSION.md en entier, puis seulement les documents qu'il cite.",
  "Dire ce qui est dans le site, ce qui n'est qu'un aperçu ou un prototype, ce qui a été vérifié et ce qui ne l'a pas été.",
 ]),
 ('Logique (code et niveaux)', [
  "Correctifs comptés (OK / ÉCHEC, un ÉCHEC arrête tout), jamais de réécriture complète d'un fichier de code.",
  "Aucun texte visible hors de i18n.js (FR + EN). Chemins relatifs uniquement.",
  "Un niveau : fiche → pipeline.py N → enigme.js → difficulty.js (P_exec ≥ 70 %) → lab.js (sans la mécanique = 0 gagnant) → levels.js.",
  "Un seul processeur : une commande par niveau, sous 280 s, aucune minuterie qui empêche les tests node de s'arrêter.",
  "Avant de livrer : audit, strict, tutotest, monde1, monde2, replaytest, e2e-didacticiel, e2e-editeur ; regarder de vraies captures.",
 ]),
 ('Graphique (charte)', [
  "Fond #05070D, néon + couche cosmique ; jetons : matière #4DD7FF, élan #A678FF, zone #9BEB4B, danger #FF5252, récompense #FFD85A, rebond #FFAA3C.",
  "Typo : Space Grotesk (titres, chiffres légers), Inter (texte), JetBrains Mono (étiquettes en capitales espacées).",
  "Langue Visière : verre sombre translucide, repères de coin, ligne de lumière, poussière qui dérive, ouverture en cascade, rien qui passe sur la barre de tracé.",
  "Murs en lumière quantique, impacts gradués (poussière, arcs, onde), rien dans la zone de réussite.",
  "Peu de texte : l'animation dit l'issue ; mots courts et conceptuels (Bifurquer, Trajectoire, Géodésique, État initial).",
  "Ce qui se touche a l'air touchable : tuiles avec icône et mot, jamais de chevron qui suggère un sous-menu.",
  "Tout rendu passe par le banc des rendus ou un prototype d'aperçu avant d'entrer dans le site.",
 ]),
 ('Livrer', [
  "Tampon neuf (index.html #buildTag + console engine.js), QUANTIX-SITE.zip (index.html à la racine) et QUANTIX-Rxxx.zip (dossier q/).",
  "Aperçu : python3 tools/build-apercu.py 1 11 home [plein] → publier à la même adresse.",
  "Mettre à jour REPRISE-SESSION.md localement et dans le Projet ; dire quels fichiers du Projet remplacer.",
 ]),
]

def head(path):
    try: t = open(path, encoding='utf-8', errors='replace').read(1600)
    except Exception: return ''
    t = re.sub(r'^#!.*\n', '', t)
    m = re.search(r'"""(.*?)(?:"""|$)', t, re.S) or re.search(r'/\*+(.*?)(?:\*/|$)', t, re.S) or re.search(r'((?:^\s*#.*\n)+)', t, re.M)
    s = (m.group(1) if m else t.split('\n')[0])
    s = re.sub(r'^\s*#\s?', '', s, flags=re.M); s = re.sub(r'[═]+', '', s); s = ' '.join(s.split())
    s = re.sub(r'^\S+\.(py|js)\s*[—:-]\s*', '', s)
    return s[:260] + ('…' if len(s) > 260 else '')

GROUPES = [
 ('Livraison et aperçus', ['build-apercu.py','build-galerie.py','build-banc.py','build-menu.py','livrer.py','audit.js','strict.js','load.js']),
 ('Conception des niveaux', ['fiche.js','pipeline.py','valide.py','slotwrite.py','setlv.py','movelevel.py','autoplan.py','design.js','lab.js','forge.js','rail.js','retune.js','hardtune.js','tighten.js','fixstar.js','noyau.js','noyau2.js','starfind.js','optimal.js','flow.js','ndfix.js']),
 ('Mesure et contrôle', ['difficulty.js','enigme.js','diag.js','constance.js','contournements.js','courts.js','bypass.js','tolerance.js','hasard.js','solver.js','finition.js','rapport-finition.py','etat.py','redundancy.js','zonepropre.js','triage.js','banc.js']),
 ('Non-régression', ['monde1.js','monde2.js','monde3.js','monde4.js','monde5.js','replaytest.js','tutotest.js','maptest.js','qprobe.js','savetest.js','repairs_check.js','render.js','e2e-didacticiel.py','e2e-editeur.py','e2e-son.py','e2e-quantone.py','e2e-quantone-editeur.py']),
 ('Didacticiel et rendus', ['tutoscenes.js','tuto-scenes-src.js','galerie-niveaux.js','grade-art.py','fview.py']),
]
tdir = os.path.join(ROOT, 'tools'); files = sorted(f for f in os.listdir(tdir) if f.endswith(('.py', '.js')))
seen = set(f for _, g in GROUPES for f in g); autres = [f for f in files if f not in seen]
if autres: GROUPES.append(('Autres (mondes 2–3, essais)', autres))
def date(f):
    try: return datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(tdir, f))).strftime('%d/%m')
    except Exception: return ''
docs = json.load(open(os.path.join(ROOT, 'docs/menu-docs.json'), encoding='utf-8'))
code = [('index.html','Page unique du jeu, écrans et panneaux'),('assets/js/engine.js','Moteur, physique, écrans, boucle'),('assets/js/visuals.js','Tout le rendu (window.VX) : mondes, murs, impacts, en-têtes du bilan'),
        ('assets/js/levels.js','132 niveaux, 11 mondes'),('assets/js/i18n.js','Tous les textes FR/EN'),('assets/js/tuto.js','Didacticiel (Visière adaptative)'),('assets/js/hero.js','Héros de l’accueil « L’odyssée »'),
        ('assets/js/sound.js','Son (W1N, MFX)'),('assets/js/editor.js','Outils de tracé'),('assets/css/quantix.css','Styles (blocs datés Rxxx en fin de fichier)'),
        ('studio/','Quantone, éditeur de niveaux, banc des rendus, prototypes (plein cadre)'),('tools/','Outils de calcul ci-dessous'),('docs/','Documentation locale (copie des docs du Projet)')]

E = html.escape
def lien(n, r, u, s):
    a = ('<a class="go" href="%s" target="_blank" rel="noopener">Ouvrir</a>' % E(u)) if u else '<span class="go off">Dans le jeu</span>'
    return '<article class="tool"><div><h3>%s</h3><p>%s</p><span class="st">%s</span></div>%s</article>' % (E(n), E(r), E(s), a)

out = ['<title>Quantix · Menu édition</title>', '<meta name="description" content="Outils, artefacts, fichiers et méthode du projet Quantix">',
 '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;500;600&family=Inter:wght@400;500&family=JetBrains+Mono:wght@500;600&display=swap">',
 '<style>' + open(os.path.join(ROOT, 'tools/menu-style.css'), encoding='utf-8').read() + '</style>',
 '<header class="top"><p class="eyebrow">QUANTIX · MENU ÉDITION · %s</p><h1>Tout l’atelier, d’un geste</h1>'
 '<p class="lede">Éditeurs, artefacts, fichiers du Projet, outils de calcul et méthode. Mis à jour le %s.</p>'
 '<nav class="nav"><a href="#outils">Éditeurs</a><a href="#methode">Méthode</a><a href="#calcul">Outils de calcul</a><a href="#fichiers">Fichiers</a></nav></header>'
 % (E(VER), datetime.date.today().strftime('%d/%m/%Y')),
 '<main>', '<section id="outils"><h2>Éditeurs et artefacts</h2><div class="grid">' + ''.join(lien(*l) for l in LIENS) + '</div></section>',
 '<section id="methode"><h2>Méthode de travail</h2><div class="cols">' + ''.join('<div class="blk"><h3>%s</h3><ul>%s</ul></div>' % (E(t), ''.join('<li>%s</li>' % E(x) for x in xs)) for t, xs in METHODE) + '</div></section>',
 '<section id="calcul"><h2>Outils de calcul <small>%d fichiers dans tools/ · date = dernière modification</small></h2>' % len(files)]
for g, fs in GROUPES:
    rows = ''.join('<tr><td class="f">%s</td><td>%s</td><td class="d">%s</td></tr>' % (E(f), E(head(os.path.join(tdir, f))), date(f)) for f in fs if os.path.exists(os.path.join(tdir, f)))
    out.append('<details open><summary>%s</summary><div class="tw"><table>%s</table></div></details>' % (E(g), rows))
out.append('</section><section id="fichiers"><h2>Fichiers</h2><h3 class="sub">Documents du Projet (claude.ai)</h3><div class="tw"><table>' +
  ''.join('<tr><td class="f">%s</td><td>%s</td></tr>' % (E(k), E(v)) for k, v in docs.items()) + '</table></div>'
  '<h3 class="sub">Code du site (zip)</h3><div class="tw"><table>' + ''.join('<tr><td class="f">%s</td><td>%s</td></tr>' % (E(k), E(v)) for k, v in code) + '</table></div></section></main>')
open(os.path.join(ROOT, 'studio/menu-edition.html'), 'w', encoding='utf-8').write('\n'.join(out))
md = ['# Quantix · Menu édition (%s)\n' % VER, 'Artefact : voir REPRISE-SESSION.md, section Aperçu. Construit par `python3 tools/build-menu.py`.\n', '## Éditeurs et artefacts\n']
md += ['- **%s** — %s %s' % (n, r, ('<' + u + '>') if u else '(%s)' % s) for n, r, u, s in LIENS]
for t, xs in METHODE: md += ['\n## %s\n' % t] + ['- ' + x for x in xs]
md += ['\n## Outils de calcul\n'] + ['- `%s` — %s' % (f, head(os.path.join(tdir, f))) for f in files]
open(os.path.join(ROOT, 'docs/MENU_EDITION.md'), 'w', encoding='utf-8').write('\n'.join(md) + '\n')
print('studio/menu-edition.html', os.path.getsize(os.path.join(ROOT, 'studio/menu-edition.html')), 'o ·', len(files), 'outils ·', len(docs), 'documents')
