/* regress-ref.js — empreinte des 132 niveaux : solution de référence (issue, trames, position finale) + sans trait. Usage : node tools/regress-ref.js SORTIE.json  puis diff entre deux états du moteur. */
require('./load.js');const X=globalThis.__X,S=X.S,fs=require('fs');const out=[];
function run(i,strokes){X.loadLevel(i);for(const s of strokes)S.strokes.push({pts:s.pts,len:s.len||0,birth:0,mat:s.mat||0});X.qpBuild();S.mode='run';let f=0;for(;f<1500&&S.mode==='run';f++)X.physics();return [S.mode,f,Math.round(S.ball.x*100)/100,Math.round(S.ball.y*100)/100,!!S.gotStar];}
for(let i=0;i<X.LEVELS.length;i++){const L=X.LEVELS[i];const st=(L.optsol||[]).map(p=>{let len=0;for(let q=1;q<p.length;q++)len+=Math.hypot(p[q][0]-p[q-1][0],p[q][1]-p[q-1][1]);return {pts:p,len,mat:L.optmat||0};});
 out.push({i:i+1,sans:run(i,[]),ref:L.optsol?run(i,st):null});}
fs.writeFileSync(process.argv[2],JSON.stringify(out));console.log('ok',out.length);
