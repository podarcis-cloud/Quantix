const LAB=require('./lab.js'),C=require('./w2cand.js');
const g={step:18,da:.5,lens:[30,60,100,150]};
for(const k of process.argv.slice(2)){const c=C[k];const o=LAB.report(+k,c,{grid:g});
 console.log(`#${+k+1} ${c.n.padEnd(17)} sans trait: ${o.sansTrait} | gagnants AVEC: ${o.avec} | SANS mécanique: ${o.sans}${o.sans?'  <<< contournable '+JSON.stringify(o.exSans[0]):''}${o.avec?'':'  <<< injouable (au balayage simple)'}`);}
