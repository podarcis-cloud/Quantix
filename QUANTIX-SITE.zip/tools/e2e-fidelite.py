# R402 — Fidélité Pattern → bibliothèque → Track (doit ÉCHOUER avant le correctif, PASSER après)
# Usage : python3 e2e-fidelite.py [port] [chemin .qxp]   (défaut 8765, .qxp réel de Simon)
# Référence = export « cycle » de Pattern (bouton Exporter, automation complète = « 8x » de Simon).
# Seuils (justification dans rapport.md) : enveloppe RMS 50 ms r >= 0.98 ; spectre 1/3 d'octave, écart max <= 2 dB
# (niveau normalisé, bandes à moins de 60 dB de la plus forte) ; aucune fenêtre de 1 s plus de 6 dB sous la référence (notes manquantes / silence) ; durée = cycle à 1 ms près.
import sys, os, json, numpy as np
sys.path.insert(0, '/tmp/claude-0/agent-qpt/fidelite')
from lib import ENC, dec, env, spec, compare
from playwright.sync_api import sync_playwright
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
QXP = sys.argv[2] if len(sys.argv) > 2 else '/tmp/claude-0/agent-qpt/fidelite/ref/simon.qxp'
Q = json.load(open(QXP)); BL = {b['name']: b for b in Q['blocks'] if b['kind'] == 'qx'}
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m, flush=True)
SR = 44100
def fid(ref, out, lc, tag):
    a0 = int(3 * SR); n = int(lc * SR)  # 3 s de chauffe : l'export part à froid (pas de queues du cycle précédent)
    R, T = ref[:, a0:n], out[:, a0:n]
    d = compare(R, T, SR, tag); sR, sT = spec(R, SR), spec(T, SR); mk = sR >= sR.max() - 60; ds = np.abs((sT - sT[mk].mean()) - (sR - sR[mk].mean()))[mk]   # bandes à moins de 60 dB de la plus forte (au-delà : bruit de quantification 16 bits)
    eR, eT = 20 * np.log10(env(R, SR, 1.)), 20 * np.log10(env(T, SR, 1.)); worst = float((eT - eR - (np.median(eT - eR))).min())
    chk(d['r_env'] >= .98, '%s : enveloppe 50 ms r=%.4f (>= 0.98)' % (tag, d['r_env']))
    if ds.max() > 2: print('      bandes (écart dB) :', ' '.join('%.1f' % x for x in ((sT - sT[mk].mean()) - (sR - sR[mk].mean()))), '| crêtes réf %.2f sortie %.2f' % (abs(R).max(), abs(T).max()))
    chk(ds.max() <= 2, '%s : spectre, écart max %.1f dB (<= 2)' % (tag, ds.max()))
    chk(worst >= -6, '%s : pas de trou (pire seconde %.1f dB sous la réf., >= -6)' % (tag, worst))
    print('      niveau Track/Pattern %.2f dB (piste 0,8 + master)' % d['level_db'])
GETAU = "(nm)=>new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>{const i=g.result.filter(x=>x.name===nm).pop();r(i?{id:i.id,au:i.au?{sr:i.au.sr,len:i.au.len,src:i.au.src||null}:null}:null)}}})"
with sync_playwright() as pw:
    b = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); ctx = b.new_context(viewport={'width': 390, 'height': 844}); er = []
    pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append(str(e)))
    pg.goto('http://localhost:%d/studio/quantone.html' % PORT); pg.evaluate("localStorage.setItem('qx.proj','Fidélité')"); pg.reload(); pg.wait_for_timeout(1200); pg.evaluate(ENC)
    REFS = {}
    for nm, noauto in (('Mélodie acide', False), ('Boucle acide melo', False), ('Mélodie acide', True)):
        tag = nm + (' (sans automation)' if noauto else '')
        pg.evaluate("(J)=>QXIO.open(J)", BL[nm]['qx']); pg.wait_for_timeout(300)
        if noauto: pg.evaluate("()=>Object.keys(QAUTO.AUT).forEach(k=>QAUTO.AUT[k].on=false)")
        # sans automation : boucle de 3 s, on compare 8 boucles (24 s) ; avec : le cycle complet d'automation
        r = pg.evaluate("(na)=>new Promise(r=>{QEXPORT.opt.auto=!na;QEXPORT.opt.loops=8;QEXPORT.render(b=>r(Object.assign(__enc(b),{last:QEXPORT.opt.last,cyc:QEXPORT.cycle()})))})", noauto)
        REF, _ = dec(r); D = r['last']['sec'] - .05; lc = D / r['last']['loops'] * (1 if noauto else r['last']['loops']); REFS[tag] = (REF[:, int(.05 * SR):], D)
        if nm == 'Boucle acide melo': continue   # sert seulement au mélange du .qxp
        # ajout à la bibliothèque par l'interface (≡+ → Projet / Nom → Ajouter)
        lname = 'Fid ' + tag
        pg.evaluate("document.getElementById('qLibBtn').click()"); pg.wait_for_timeout(200)
        pg.fill('#qLibPj', 'Fidélité'); pg.fill('#qLibIn', lname); pg.evaluate("document.getElementById('qLibOk').click()")
        import time; t0 = time.time()
        while time.time() - t0 < 150:
            pg.wait_for_timeout(500)
            if pg.evaluate(GETAU, lname) and not pg.evaluate("!!window.QCAPBUSY"): break
        print('      ajout en bibliothèque : %.1f s' % (time.time() - t0))
        it = pg.evaluate(GETAU, lname)
        chk(it and it['au'], '%s : la bibliothèque garde un son avec le motif (%s)' % (tag, it and it['au'] and it['au']['src']))
        if it and it['au']: chk(abs(it['au']['len'] - lc) < .001, '%s : durée = cycle complet (%.3f s / %.3f s)' % (tag, it['au']['len'], lc))
        # Track : choisir le pattern, le poser, rendre
        pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('T:' + str(e)))
        pt.goto('http://localhost:%d/studio/morceau.html' % PORT); pt.wait_for_timeout(1200); pt.evaluate(ENC)
        if os.environ.get('NEUTRE'): pt.evaluate('()=>{window.__NEUTRE=1}')
        pt.evaluate("(id)=>{const s=document.getElementById('patSel');s.value='lib:'+id;s.dispatchEvent(new Event('change'))}", it['id'])
        pt.wait_for_function("(id)=>MORCEAU.P().blocks.some(b=>b.lib===id)", arg=it['id'], timeout=120000)
        m = pt.evaluate("()=>document.getElementById('msg').textContent")
        chk('approximatif' not in m, '%s : pas de « rendu approximatif » dans Track' % tag)
        T = pt.evaluate("async(a)=>{const [L,id]=a;const P=MORCEAU.P();P.clips.length=0;const bk=P.blocks.find(b=>b.lib===id);MORCEAU.place(bk.id,0,0,L).loop=true;if(window.__NEUTRE){P.master.comp=0;P.tracks.forEach(k=>k.vol=1);}const b=await MORCEAU.exportBuf();return Object.assign(__enc(b),{au:bk.au||0,len:bk.len})}", [D, it['id']])
        chk(T['au'] == 1, '%s : Track joue le son stocké (pas de re-rendu)' % tag)
        OUT, _ = dec(T); fid(REFS[tag][0], OUT, D, tag); pt.close()
        import os
        if os.environ.get('DUMP'): np.savez_compressed('/tmp/claude-0/agent-qpt/fidelite/ref/dump_%d.npz' % len(res), REF=REFS[tag][0], OUT=OUT)
    # .qxp réel (master sans compression ni écrêtage : le compresseur de Track est un choix de mixage, mesuré à part) : Track l'ouvre sans bibliothèque (re-rendu depuis les motifs), les 2 pistes doivent sonner comme les 2 Patterns mélangés
    pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('T:' + str(e)))
    pt.goto('http://localhost:%d/studio/morceau.html' % PORT); pt.wait_for_timeout(1200); pt.evaluate(ENC)
    if os.environ.get('NEUTRE'): pt.evaluate('()=>{window.__NEUTRE=1}')
    Qn = json.loads(json.dumps(Q))
    for bb in Qn['blocks']: bb['lib'] = None
    T = pt.evaluate("async(o)=>{await MORCEAU.load(o);if(window.__NEUTRE){P.master.comp=0;P.tracks.forEach(k=>k.vol=1);}const b=await MORCEAU.exportBuf();return __enc(b)}", Qn) if pt.evaluate("!!MORCEAU.load") else None
    if T is None:
        T = pt.evaluate("""async(o)=>{MORCEAU.P().clips.length=0;for(const bk of o.blocks){const r=await MORCEAU.renderQx(bk.qx,bk.name);r.id=bk.id;MORCEAU.addBlock(r);}const P=MORCEAU.P();
          o.clips.forEach((c,i)=>{const nb=MORCEAU.place(c.src,i,c.start,c.len);nb.loop=c.loop;});P.master.comp=0;P.tracks.forEach(k=>k.vol=.4);return __enc(await MORCEAU.exportBuf())}""", Qn)
    OUT, _ = dec(T); a, la = REFS['Mélodie acide']; c2, lb = REFS['Boucle acide melo']; n = min(a.shape[1], c2.shape[1]); MIX = .4 * (a[:, :n] + c2[:, :n])   # pistes à 0,4 : la somme reste sous le seuil du compresseur de Track (-4 dB), sinon on mesure l'écrêtage du mélange
    fid(MIX, OUT, min(la, lb), '.qxp de Simon (2 pistes)')
    chk(not er, 'aucune erreur JS ' + str(er[:2]))
    b.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
sys.exit(0 if all(res) else 1)
