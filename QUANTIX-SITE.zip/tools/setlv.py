"""setlv.py N 'star:[x,y]' 'optsol:[[[..]]]' … — R118 : remplace des champs simples (star, optsol, ink, ball, cup) dans l'entrée N de levels.js (compté)."""
import re,sys
p='/home/claude/q/assets/js/levels.js';s=open(p,encoding='utf-8').read()
st=[m.start() for m in re.finditer(r'^\{wd:',s,re.M)];n=int(sys.argv[1]);a=st[n-1];b=st[n] if n<132 else len(s);e=s[a:b]
for kv in sys.argv[2:]:
    k,v=kv.split(':',1)
    pat={'star':r'star:\[[-\d.]+,[-\d.]+\]','ink':r'ink:\d+','ball':r'ball:\[[-\d.]+,[-\d.]+\]','optsol':r'optsol:\[\[\[.*?\]\]\]','cup':r"cup:\[[^\]]*\]"}[k]
    m=re.findall(pat,e)
    if len(m)!=1:print('ÉCHEC',k,len(m));sys.exit(1)
    e=re.sub(pat,lambda _:k+':'+v,e,count=1);print('OK',n,k)
open(p,'w',encoding='utf-8').write(s[:a]+e+s[b:])
