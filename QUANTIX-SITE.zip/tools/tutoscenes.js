/* tutoscenes.js (R141) — simule les scènes de tuto-scenes-src.js avec le vrai moteur et écrit assets/js/tuto-scenes.js.
   Usage : node tools/tutoscenes.js   (depuis la racine du site) */
const path=require('path'),fs=require('fs');process.chdir(path.join(__dirname));
const LAB=require('./lab.js'),X=LAB.X,D=LAB.D,SRC=require('./tuto-scenes-src.js');
const K=1.4,OX=18,OY=170,IDX=0;   // vignette ×1,4 = repère du jeu (bille 7,5 → 10,5), posée au milieu du terrain
const g=(x,y)=>[+(OX+x*K).toFixed(1),+(OY+y*K).toFixed(1)],back=(x,y)=>[+((x-OX)/K).toFixed(1),+((y-OY)/K).toFixed(1)];
const out={};
for(const id in SRC){const s=SRC[id],c={pal:'SBAC',ink:9999,ball:g(...s.ball),star:null,w:(s.w||[]).map(q=>[...g(q[0],q[1]),...g(q[2],q[3]),q[4]]),
  nd:(s.nd||[]).map(r=>[...g(r[0],r[1]),r[2]*K,r[3]*K]),curves:(s.cv||[]).map(q=>({pts:q.pts.map(p=>g(...p)),m:q.m,pass:q.pass?q.pass:0})),
  wind:(s.wind||[]).map(r=>[...g(r[0],r[1]),r[2]*K,r[3]*K,r[4],r[5]]),grav:(s.grav||[]).map(r=>[...g(r[0],r[1]),r[2]*K,r[3]*K,r[4],r[5]]),
  mag:(s.mag||[]).map(m=>[...g(m[0],m[1]),m[2]*K,m[3]]),port:(s.port||[]).map(p=>[...g(p[0],p[1]),...g(p[2],p[3])]),
  mov:(s.mov||[]).map(m=>Object.assign({},m,{seg:[...g(m.seg[0],m.seg[1]),...g(m.seg[2],m.seg[3])],amp:m.amp*K})),
  cup:s.cup?[...g(s.cup[0],s.cup[1]),s.cup[2]*K,s.cup[3]]:[OX,OY+600,10,'L']};
 c.rails=[];c.mz=[];
 D.install(IDX,JSON.parse(JSON.stringify(c)));X.loadLevel(IDX);
 if(s.stroke)X.S.strokes.push({pts:s.stroke.pts.map(p=>g(...p)),len:1,birth:0,mat:s.stroke.mat||0});
 X.qpBuild();X.S.mode='run';const t0=X.S.t,tr=[];const F=s.frames||130;
 for(let f=0;f<F&&(X.S.mode==='run'||X.S.mode==='success');f++){if(X.S.mode==='run')X.physics();tr.push(back(X.S.ball.x,X.S.ball.y));}
 out[id]=Object.assign({},s,{tr,t0,ok:X.S.mode==='success'});
 console.log(id.padEnd(7),X.S.mode.padEnd(8),'images',tr.length,'fin',tr[tr.length-1]);}
fs.writeFileSync('../assets/js/tuto-scenes.js','/* généré par tools/tutoscenes.js depuis tools/tuto-scenes-src.js — ne pas modifier à la main */\nwindow.TSC='+JSON.stringify(out)+';\n');
