/* 52 « La cheminée » — Histoire : la pente amène la particule au pied d'une cheminée d'air ; l'air la monte, mais au sommet
   elle retombe dans le conduit, sans fin. La zone est sur une corniche, à droite du sommet. Geste : un déflecteur en haut de la
   cheminée qui l'envoie sur la corniche. Leurre : un trait au pied de la cheminée. */
module.exports={titre:'La cheminée',star:.75,
 gen:P=>({pal:'S',ball:[24,300],cup:[262,P.cy,90,'R'],wind:[[150,P.top,70,470-P.top,0,-.6]],
   w:[[10,316,168,402,0],[140,470,230,470,0],[230,P.cy,230,476,0],[140,P.top+60,140,330,0]]}),
 boxes:P=>[{x:[150,220],y:[P.top-30,P.top+60],a:[-.9,.9],l:[40,110]}],
 leurre:P=>[[[150,440],[220,440]]],
 grid:()=>{const o=[];for(const top of [90,130])for(const cy of [150,190])o.push({top,cy});return o;}};
