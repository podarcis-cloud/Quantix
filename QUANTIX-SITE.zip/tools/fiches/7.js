/* Q-01-07 « Économie » — R118 · Ten · Simple · R-13 Économiser · H6 « plus d'énergie, plus de choix ».
   Énigme : très peu d'énergie. La grande rampe évidente (du bout de la pente haute jusqu'au bassin) coûte le double de ce qu'on a.
   Idée : le chemin existe déjà — deux pentes fixes qui ne se parlent pas ; un seul trait, au seul endroit où la particule
   change de sens (le bord gauche), raccorde la pente haute à la pente basse, qui fait le reste.
   Leurre : la ligne directe vers le bassin (trop chère : le tracé s'arrête faute d'énergie).
   Rôles : pente haute = PORTER (l'élan vers la gauche) ; pente basse = PORTER (le retour vers le bassin) ; énergie = FERMER. */
module.exports={titre:'Économie',star:.4,
 gen:P=>({pal:'S',ball:[314,40],cup:[224,447,92,'R'],w:[[340,80,P.ex,P.ey,0],[P.lx,P.ly,250,380,0]]}),
 boxes:P=>[{x:[0,30],y:[P.ey+14,P.ey+48],a:[.42,.78],l:[95,145]}],
 leurre:P=>[[[P.ex-4,P.ey+6],[230,430]]],
 space:{ex:[100,130],ey:[188,212],lx:[100,140],ly:[276,300]},
 grid:()=>[]};
