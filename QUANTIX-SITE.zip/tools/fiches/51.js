/* 51 « Vent descendant » — Histoire : pour atteindre la zone, il faut sauter une crevasse ; mais au‑dessus d'elle, un vent
   descendant rabat tout ce qui passe. Geste : un tremplin plus raide, qui la fait passer haut avant que le vent ne la rabatte.
   Leurre : un tremplin doux — il suffirait sans vent ; avec, elle tombe dans la crevasse. */
module.exports={titre:'Vent descendant',star:.65,obstacle:true,
 gen:P=>({pal:'S',ball:[22,60],cup:[P.x+4,P.h,348-P.x,'R'],wind:[[172,0,P.x-172,470,0,P.fy]],
   w:[[10,74,130,250,4],[130,250,170,262,4],[170,470,P.x,470,2],[P.x,P.h,P.x,476,0]]}),
 boxes:P=>[{x:[150,172],y:[252,266],a:[-1.3,-.5],l:[40,100]}],
 leurreBoxes:P=>[{x:[140,172],y:[248,266],a:[-.6,-.05],l:[30,90]}],
 grid:()=>{const o=[];for(const fy of [.04,.055,.07])for(const h of [275,285])o.push({fy,h,x:260});return o;}};
