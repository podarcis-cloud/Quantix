module.exports=require('./auto.js')(21);
