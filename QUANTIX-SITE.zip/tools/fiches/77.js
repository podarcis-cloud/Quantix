/* Q-07-05 « Le saut lunaire » — R97 · Shō · Simple · R-03 Sauter (transformé) · hypothèse : « un vide se franchit par un pont ».
   Histoire : un gouffre bien trop large pour un pont (l'énergie manque) et pour un saut ordinaire ; mais au‑dessus du gouffre,
   la gravité est faible. Idée : un petit tremplin — dans le champ, le vol devient lunaire et porte jusqu'à l'autre bord.
   Leurre : le pont (trop cher). Rôles : champ = PORTER ; gouffre = PIÉGER ; balcon = PORTER. */
module.exports={titre:'Le saut lunaire',star:.6,
 gen:P=>({pal:'S',ball:[22,60],cup:[P.x+4,P.h,350-P.x,'R'],grav:[[150,40,P.x-150,440,0,P.g]],
  w:[[10,74,120,220,4],[120,220,150,228,4],[P.x,P.h,P.x,P.h+70,0]]}),
 boxes:P=>[{x:[132,152],y:[220,232],a:[-1.1,-.3],l:[30,90]}],
 leurre:P=>[[[148,230],[P.x+2,P.h+2]]],
 grid:()=>{const o=[];for(const x of [290,300])for(const g of [.08,.12])for(const h of [230,260])o.push({x,g,h});return o;}};
