/* Prototype Chaîne « L'ascenseur » (R84).
   Histoire : la particule tombe tout droit le long du bord, vers des pointes ; la zone est sur un balcon, à mi‑hauteur, de
   l'autre côté. Rien ne peut être construit dans la colonne de chute (zone interdite) : seule la base est libre.
   Idée (H12) : laisser tomber, puis jeter la particule sur le tapis incliné — un escalator qui la remonte et la lance sur le
   balcon. Machine : tapis montant (mesuré : il porte la particule jusqu'en haut), envol, réception dans la zone.
   Composition : la chute verticale à gauche et la longue diagonale du tapis forment un V ouvert ; le balcon ferme la
   composition à droite, sur la ligne d'or basse (y ≈ 297). */
module.exports={titre:'L’ascenseur',star:.5,
 gen:P=>({pal:'S',ball:[34,40],cup:[262,P.cy,90,'R'],mz:[[0,60,74,330],[74,60,286,350]],   /* la colonne de chute est non traçable mais sans hachures : la composition reste nette */
  w:[[64,468,P.ex,468-Math.round((P.ex-64)*Math.tan(P.a*Math.PI/180)),3],[258,P.cy,258,476,0],[0,476,60,476,2]]}),
 boxes:P=>[{x:[4,30],y:[420,450],a:[.3,.8],l:[50,90]}],
 grid:()=>[{a:40,ex:200,cy:350}]};
