/* Q-01-10 « Le plafond » — R89 · Ketsu · type R-14 Contre-pied · hypothèse H1 « un trait est un sol ».
   Énigme : le tremplin lance la particule très haut, droit vers un plafond de pointes ; la zone est sur un balcon, à droite.
   Leurre : construire une rampe ou un pont vers le balcon — tout le dessous du vol est interdit, et la particule passe au‑dessus.
   Idée : le trait n'est pas un sol mais un PLAFOND — une tôle sous les pointes qui renvoie la particule dans la zone.
   Scénario : il veut construire en bas (refusé), voit la particule s'écraser au plafond, comprend qu'il faut la renvoyer d'en haut.
   Rôles : piste + tremplin = PORTER ; plafond de pointes = PIÉGER ; zone interdite sous le vol = FERMER (K1 rampe vers le
   balcon) ; balcon = PORTER. Composition : grande courbe de lancement à gauche, parabole qui monte vers la droite, balcon
   sous le plafond ; le bas droit reste vide. */
module.exports={titre:'Le plafond',star:.5,
 gen:P=>({pal:'S',ball:[26,40],cup:[256,P.cy,96,'B'],nd:[[150,P.cy+30,210,446-P.cy]],
  curves:[{pts:[[12,56],[30,120],[52,200],[80,250],[112,262],[140,240],[P.kx,P.ky]],m:0}],
  w:[[166,P.ce,356,P.ce,2]]}),
 boxes:P=>[{x:[166,240],y:[P.ce+12,P.ce+40],a:[-.5,.8],l:[40,110]}],
 leurre:P=>[[[P.kx+6,P.ky+4],[252,P.cy-4]]],
 space:{ce:[110,134],cy:[222,258],kx:[148,164],ky:[192,208]},
 grid:()=>[]};
