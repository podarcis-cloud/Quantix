/* 38 « Trop vite » (nouvelle histoire, R67) — Histoire : la particule dévale la glace, un tremplin de glace la lance en l'air,
   et elle survole la zone pour finir sur les pointes. Obstacle : sa vitesse — elle va trop loin. Geste : l'arrêter en plein vol
   (un auvent ou une butée en l'air) pour qu'elle retombe dans la zone. Leurre : un trait sous elle — elle rebondit et repart. */
module.exports={titre:'Trop vite',star:.8,
 gen:P=>({pal:'S',nd:[[195,130,160,P.n]],ball:[22,74],cup:[P.x,420,P.w,'B'],w:[[10,90,150,190,4],[150,190,185,186,4],[P.x+110,476,356,476,2],[356,200,356,476,2]]}),
 boxes:P=>[{x:[260,350],y:[130+P.n,400],a:[-3.14,3.14],l:[45,140]}],
 leurre:P=>[[[150,300],[260,330]]],
 grid:()=>[{x:150,n:150,w:90},{x:155,n:155,w:115},{x:150,n:150,w:100}]};
