/* Q-07-03 « Le manège inversé » — R94 · Ki · forme RELAIS (première machine du monde).
   Accès : la particule part en haut à gauche ; l'entonnoir est en haut à droite, au‑delà d'une étagère de pointes.
   Machine (montagnes russes) : l'entonnoir la pose sur une piste qui plonge le long du bord droit, traverse le fond, remonte
   la paroi gauche et s'enroule en VOÛTE ; sous la voûte, la gravité est inversée : la particule roule À L'ENVERS, plaquée au
   plafond, jusqu'au bout de la voûte où la gravité normale la reprend et la laisse tomber dans la zone, au centre.
   Composition : une grande boucle qui fait le tour de l'écran autour de la zone centrale (le cœur du manège). */
module.exports={titre:'Le manège inversé',star:.6,
 gen:P=>({pal:'S',ball:[40,36],cup:[P.cx,P.cy,104,'B'],mz:[[0,150,360,330]],grav:[[16,P.zt,P.zw,P.zb-P.zt,0,-P.g]],
  curves:[{pts:[[236,100],[256,124],[276,142]],m:0},{pts:[[350,100],[334,124],[318,142]],m:0},                 /* entonnoir */
   {pts:[[322,154],[336,214],[342,282],[336,342],[314,392],[290,414],[290,416],[240,430],[160,432],[90,424],[46,396],[26,350],[24,290],[34,236],[58,196],[96,170],[136,156],[170,162],[192,184],[P.ve,216]],m:0}],   /* la voûte se recourbe vers le bas : la particule repart vers la zone */
  w:[[P.sx,P.sy,232,P.sy,2]]}),
 boxes:P=>[{x:[22,46],y:[66,84],a:[.04,.14],l:[220,250]}],
 leurre:P=>[[[30,74],[148,330]]],   /* viser la zone directement : la piste et la zone de machine l'interdisent */
 grid:()=>{const o=[];for(const sx of [70])for(const sy of [104])o.push({g:.5,zt:110,zb:330,zw:176,ve:200,cx:148,cy:384,sx,sy});return o;}};
