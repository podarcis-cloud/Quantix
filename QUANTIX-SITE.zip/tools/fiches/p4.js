/* Prototype Glacier « Le grand tremplin » (R84).
   Histoire : la zone est en bas, de l'autre côté d'un gouffre ; tout le centre de l'écran est vide. Idée : amener la
   particule en haut de la piste d'élan — la glace fera le reste : descente, tremplin, long vol au‑dessus du gouffre,
   réception dans la grande paroi galbée, glissade jusqu'à la zone.
   Composition : un grand « C » de glace à gauche (la piste d'élan) répond à un grand « C » inversé à droite (la réception) ;
   entre les deux, le vide central est la scène du vol — une parabole qui traverse l'écran. */
module.exports={titre:'Le grand tremplin',star:.5,
 gen:P=>({pal:'S',ball:[322,36],cup:[P.cx,456,96,'B'],mz:[[0,140,360,340]],
  curves:[{pts:[[22,72],[42,98],[62,116]],m:0},{pts:[[140,72],[118,98],[98,116]],m:0},                                   /* entonnoir : fixe le point de chute */
   {pts:[[40,214],[70,252],[100,290],[126,312],[150,316],[P.lx,P.ly]],m:4},       /* piste d'élan + tremplin */
   {pts:[[226,120],[284,140],[326,190],[344,256],[340,320],[322,370],[300,396]],m:4}],             /* réception galbée */
  w:[[284,118,356,118,2],[70,474,P.cx-4,474,2]]}),
 boxes:P=>[{x:[300,350],y:[38,58],a:[3.04,3.16],l:[180,230]}],
 grid:()=>[{lx:160,ly:286,cx:200}]};
