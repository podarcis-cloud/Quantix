module.exports=require('./auto.js')(20);
