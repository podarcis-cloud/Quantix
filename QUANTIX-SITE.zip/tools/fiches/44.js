/* 44 « La patinoire » — Histoire : la particule dévale une patinoire en lacets ; au bout de chaque descente, un îlot de pointes
   l'attend. Obstacle : deux îlots, un par virage. Geste : deux déflecteurs qui la font tourner avant chaque îlot (slalom).
   Leurre : un seul long mur, qui la renvoie mais pas assez loin. */
module.exports={titre:'La patinoire',star:.55,
 gen:P=>({pal:'S',ball:[40,40],cup:[260,450,92,'R'],w:[
   [10,70,285,108+P.d,4],            /* 1re descente vers la droite */
   [342,98,356,134,2],               /* îlot 1 : pointes au bout, à droite */
   [356,196,75,240+P.d,4],           /* 2e descente vers la gauche */
   [6,236,18,278,2],                /* îlot 2 : pointes au bout, à gauche */
   [6,326,250,380,4]]}),            /* 3e descente vers la zone */
 boxes:P=>[{x:[295,340],y:[80,140],a:[.9,2.3],l:[35,80]},{x:[22,70],y:[220,275],a:[.9,2.3],l:[35,80]}],
 leurre:P=>[[[200,160],[330,300]]],
 grid:()=>[{d:20},{d:30},{d:40},{d:50}]};
