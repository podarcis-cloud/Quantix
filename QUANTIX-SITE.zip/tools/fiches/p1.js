/* Prototype Atelier « Les collines » (R84).
   Histoire : au départ, une corniche coupée par un gouffre ; au‑delà, l'entonnoir. Accès : un pont (on ne saute pas : la
   corniche penche vers le vide). Machine : une piste de poutres en vague — chute presque verticale qui s'adoucit (concave),
   vallée, colline : la particule DÉCOLLE au sommet (un instant de vol), retombe sur la descente, et la zone la reçoit.
   Composition : une seule grande ondulation, de l'entonnoir (haut gauche) à la zone (bas droite) ; le haut droit et le
   centre haut restent ouverts. */
module.exports={titre:'Les collines',star:.5,
 gen:P=>({pal:'S',ball:[326,40],cup:[258,456,96,'B'],mz:[[0,150,360,330]],
  curves:[{pts:[[34,84],[52,108],[66,126]],m:0},{pts:[[128,84],[110,108],[96,126]],m:0},                     /* entonnoir */
   {pts:[[70,140],[86,196],[112,252],[150,298],[198,320],[236,314],[P.cx,P.cy],[292,300],[306,318]],m:0},
   {pts:[[300,176],[334,198],[352,246],[354,306],[348,350],[336,384],[322,398]],m:0}],                                    /* dosseret : cueille le vol */
  w:[[262,64,352,56,0],[134,84,206,78,0],[206,200,262,200,2]]}),
 boxes:P=>[{x:[250,266],y:[56,66],a:[2.9,3.1],l:[50,80]}],
 grid:()=>{const o=[];for(const cx of [264,270])for(const cy of [292,300])o.push({cx,cy});return o;}};
