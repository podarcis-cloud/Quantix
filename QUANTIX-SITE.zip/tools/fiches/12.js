/* Q-01-12 « L'établi » — R118 · Ketsu · FINALE · R-20 Synthèse · rappel renversé du niveau 1.
   Énigme : la poutre de départ s'arrête au‑dessus des pointes qui gardent la machine ; la particule y tombe. Idée : la cueillir dans sa chute, au‑dessus des pointes de garde, et la reverser vers la gauche jusqu'au relais : le trait
   est à la fois le sol qui manque (niveau 2) et le mur qui renverse sa course (niveau 1).
   Machine (finale, signature du monde) : la grande spirale de l'Atelier — gabarit lacets.js en poutres, entonnoir, deux pistes
   sur les lignes d'or, virages à lèvre, glissade, tremplin, saut au‑dessus du vide, zone.
   Rôles : poutre de départ = PORTER (l'élan, trop fort) ; pointes de garde = PIÉGER (et FERMER l'entrée de la machine par la droite) ; entonnoir = relais ; machine = finale. */
const lacets=require('./lacets.js');
module.exports={titre:'L’établi',star:.08,
 gen:P=>{const c=lacets({m:0,tilt:18,cm:0,fm:0,yc:404,kx:110});c.ball=[338,20];
  c.w=c.w.filter(s=>s[4]!==2).concat([[356,36,P.bx,P.by,0],[P.gx,132,300,132,2]]);
  c.curves[0]={pts:[[128,100],[150,112],[166,124]],m:0};c.curves[1]={pts:[[P.ax,P.ay],[202,P.ay+(124-P.ay)*.5],[194,124]],m:0};return c;},
 boxes:P=>[{x:[P.bx-20,P.bx+4],y:[P.by+8,P.by+26],a:[2.72,2.98],l:[118,155]}],
 space:{bx:[268,280],by:[44,52],gx:[226,246],ax:[204,214],ay:[100,112]},
 grid:()=>[]};
