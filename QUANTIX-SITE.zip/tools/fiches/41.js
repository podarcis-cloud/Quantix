/* 41 « Le virage » — Histoire : la particule dévale la glace ; au bout de la descente, un îlot de pointes ; la suite du chemin
   repart vers la gauche, plus bas. Obstacle : elle ne tourne pas seule. Geste : un bouclier au bout de la descente, qui la fait
   tomber sur la descente suivante. (Version à un virage ; « La patinoire » (44) en enchaîne deux.) Leurre : un trait sous elle. */
module.exports={titre:'Le virage',star:.6,
 gen:P=>({pal:'S',nd:[[322,40,38,150]],ball:[40,40],cup:[8,440,92,'L'],w:[[10,70,285,108+P.d,4],[346,78,356,170,2],[356,196,40,260+P.d,4],[6,230,6,384,0]]}),
 boxes:P=>[{x:[280,321],y:[60,150],a:[.6,2.5],l:[40,120]}],
 leurre:P=>[[[200,150],[330,170]]],
 grid:()=>[{d:10},{d:20},{d:30}]};
