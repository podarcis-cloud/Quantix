module.exports=require('./auto.js')(22);
