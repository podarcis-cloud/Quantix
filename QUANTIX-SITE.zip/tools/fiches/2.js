/* Q-01-02 « Le pont » — R116 · Ki · type R-02 Ponter · hypothèse « un vide se saute ».
   Énigme : la rampe fixe dépose la particule au bord d'un gouffre, presque sans élan ; le bassin est de l'autre côté, plus bas.
   La moitié haute de l'écran est interdite : on ne peut ni sauter ni tendre un fil par‑dessus. Idée : le trait est un PONT —
   il prolonge la rampe jusqu'au bassin, particule qui roule sans jamais quitter la matière. Scénario : il tente de lancer la
   particule, rien ne le permet ; il comprend qu'il faut prolonger la piste. Rôles : rampe = PORTER ; gouffre = PIÉGER ;
   zones interdites = FERMER (le saut) ; bassin à paroi = PORTER. Composition : la rampe descend de haut gauche, le bassin
   répond en bas droite sur la ligne d'or basse. */
module.exports={titre:'Le pont',star:.5,
 gen:P=>({pal:'S',ball:[46,40],cup:[P.cx,P.cy,360-P.cx-8,'R'],nd:[[0,0,P.ex,480],[P.ex,0,360-P.ex,P.nt]],
  w:[[20,P.ry,P.ex,P.ry+P.dy,0]]}),
 boxes:P=>[{x:[P.ex+1,P.ex+14],y:[P.ry+P.dy-6,P.ry+P.dy+24],a:[Math.atan2(P.cy-P.ry-P.dy,P.cx-P.ex)-.18,Math.atan2(P.cy-P.ry-P.dy,P.cx-P.ex)+.18],l:[Math.hypot(P.cx-P.ex,P.cy-P.ry-P.dy)-14,Math.hypot(P.cx-P.ex,P.cy-P.ry-P.dy)+50]}],
 grid:()=>{const ry0=(cy,dy)=>130+dy-12;const o=[];for(const cy of [232,248])for(const cx of [282,296])for(const dy of [16,26])o.push({cx,cy,dy,ry:130,ex:132,nt:ry0(cy,dy)});return o;}};
