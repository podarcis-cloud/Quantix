/* 40 « Le demi‑tour » — Histoire : la glace l'emporte vers la droite, droit sur une paroi de pointes ; la zone est en bas,
   à gauche, derrière elle. Obstacle : le sens de la pente. Geste : un long lacet qui la recueille au bout de la glace et la
   ramène en descendant vers la gauche. Leurre : un mur au bout de la glace — elle rebondit, remonte, revient, sans fin. */
module.exports={titre:'Le demi‑tour',star:.7,
 gen:P=>({pal:'S',ball:[22,70],cup:[8,440,90,'L'],w:[[10,84,P.e,84+Math.round((P.e-10)*.58),4],[356,140,356,476,2],[110,476,354,476,2]]}),
 boxes:P=>[{x:[P.e+20,345],y:[84+Math.round((P.e-10)*.58)+10,84+Math.round((P.e-10)*.58)+90],a:[2.25,2.9],l:[140,280]}],
 leurre:P=>[[[P.e+30,90+Math.round((P.e-10)*.58)-40],[P.e+30,90+Math.round((P.e-10)*.58)+40]]],
 grid:()=>[{e:220},{e:250},{e:280}]};
