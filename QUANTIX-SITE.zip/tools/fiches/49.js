/* 49 « Le souffle » — Histoire : un haut mur sépare la particule de la zone ; juste devant le mur, une colonne d'air monte.
   Mais la pente l'emporte de l'autre côté, vers des pointes. Geste : une rampe qui la ramène et la dépose dans la colonne —
   l'air la soulève par‑dessus le mur. Leurre : la lancer vers le mur sans passer par l'air. */
module.exports={titre:'Le souffle',star:.55,
 gen:P=>({pal:'S',ball:[118,300],cup:[262,440,90,'R'],wind:[[150,40,94,430,P.fx,P.f]],
   w:[[140,316,44,344,0],[4,150,4,476,0],[0,470,148,470,2],[248,P.wh,248,476,0]]}),
 boxes:P=>[{x:[8,40],y:[370,440],a:[.05,.7],l:[100,180]}],
 leurre:P=>[[[150,320],[240,P.wh+10]]],
 grid:()=>{const o=[];for(const f of [-.6])for(const fx of [.08,.14])for(const wh of [140,180,220])o.push({f,fx,wh});return o;}};
