/* 46 « Le pendule » — Histoire : la particule tombe dans un creux de glace et s'y balance sans fin : rien ne la freine, mais
   rien ne l'en sort — elle remonte chaque fois juste au bord, sans jamais le passer. La zone est sur une corniche, au‑dessus
   du bord droit. Geste : prolonger le bord droit par une rampe qui la hisse jusqu'à la corniche.
   Leurre : une butée au fond du creux — elle s'arrête, mais au fond. */
function valley(b){ /* creux en parabole (segments de glace) : fond arrondi, bords à la même hauteur — un vrai pendule */
 const x0=12,x1=250,cx=(x0+x1)/2,yb=370,ytop=b+14,k=(yb-ytop)/Math.pow(cx-x0,2),o=[];let px=x0,py=ytop;
 for(let x=x0+17;x<=x1+0.1;x+=17){const y=Math.round(yb-k*Math.pow(x-cx,2));o.push([Math.round(px),py,Math.round(x),y,4]);px=x;py=y;}
 return o;}
module.exports={titre:'Le pendule',star:.8,
 gen:P=>({pal:'S',ball:[30,P.b],cup:[262,P.c,90,'R'],w:valley(P.b).concat([[258,P.c,258,476,0],[0,476,256,476,2]])}),
 boxes:P=>[{x:[195,240],y:[P.c-50,P.c+10],a:[-.9,.4],l:[40,110]}],
 leurre:P=>[[[120,330],[140,372]]],
 grid:()=>{const o=[];for(const b of [130])for(const c of [260,285,310])o.push({b,c});return o;}};
