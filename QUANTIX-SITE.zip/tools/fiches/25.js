/* Q-03-01-R01 « Le tapis » — DÉCOUVRIR.
   Énigme : la zone est plus haute que la particule. Idée : seul le tapis donne l'élan (≈ 40 u de hauteur, mesuré au banc) —
   il faut une rampe à sa sortie. Rôles : courte pente = PORTER (amène au tapis) ; tapis = PORTER (seule énergie) ;
   poteau = PORTER (zone en hauteur, au‑dessus du départ : FERME la ligne directe K1, faute d'énergie). Matière : structure. */
module.exports={titre:'Le tapis',star:.75,
 gen:P=>({pal:'S',ball:[24,P.by],cup:[264,P.cy,88,'R'],w:[[10,P.by+14,60,340,0],[60,340,200,340,3],[260,P.cy,260,476,0]]}),
 boxes:P=>[{x:[192,206],y:[332,346],a:[-.55,-.2],l:[55,90]}],
 grid:()=>{const o=[];for(const by of [314,322])for(const cy of [306,314,320])o.push({by,cy});return o;}};
