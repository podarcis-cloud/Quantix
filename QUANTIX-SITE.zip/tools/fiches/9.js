/* Q-01-09 « Le détour » — R118 · Ten · Simple · R-11 Boucler · H14 « ce qui est loin ne compte pas ».
   Énigme : la poutre de départ envoie la particule vers la gauche, droit sur les pointes. Le bassin est en bas, mais
   tout le bas de l'écran est interdit : impossible de tracer vers lui. Idée : l'élément décisif est à l'autre bout — la
   demi‑lune fixe accrochée au bord droit. Un long trait, dans la seule bande libre, renvoie la particule à travers tout
   l'écran jusqu'à la demi‑lune, qui la retourne et la laisse tomber dans le bassin.
   Leurre : viser le bassin (zone interdite) ; arrêter la particule à gauche (elle tombe sur les pointes).
   Rôles : poutre = PORTER (vers le mauvais côté) ; montant gauche = PORTER (arrête la particule au‑dessus du trait) ; haute paroi du bassin = FERMER (le rebond court depuis la gauche) ; zones interdites = FERMER (la ligne directe vers le bassin, et le raccourci du haut vers la demi‑lune) ;
   demi‑lune = PORTER (le retour) ; bassin = PORTER. */
module.exports={titre:'Le détour',star:.5,
 gen:P=>({pal:'S',ball:[110,36],cup:[P.cx,452,P.cw,'L'],nd:[[0,P.ny,P.nx,480-P.ny],[0,0,360,56],[150,56,150,46]],
  w:[[150,62,46,P.by,0],[3,40,5,P.by+44,0],[P.cx-5,236,P.cx-3,452,0]],
  curves:[{pts:[[P.mx,P.my-34],[332,P.my-22],[350,P.my+8],[354,P.my+50],[344,P.my+96],[318,P.my+124],[P.mx-10,P.my+134]],m:0}]   /* lèvre au‑dessus de l'arrivée : on entre par l'intérieur (§19) */}),
 boxes:P=>{const a=Math.atan2(P.my+12-(P.by+28),P.mx-18);return [{x:[8,28],y:[P.by+18,P.by+40],a:[a-.06,a+.06],l:[P.mx-30,P.mx+16]}];},
 space:{by:[84,96],ny:[190,214],nx:[250,290],mx:[290,310],my:[150,176],cx:[66,96],cw:[120,150]},
 grid:()=>[]};
