/* 39 « Le saut » — Histoire : la glace s'arrête net au bord d'une crevasse trop large pour un pont (l'énergie ne suffit pas) ;
   au fond, des pointes ; la zone est de l'autre côté, un peu plus haut. Geste : un tremplin au bord, pour qu'elle saute.
   Leurre : un pont — l'énergie s'épuise au milieu. */
module.exports={titre:'Le saut',star:.65,
 gen:P=>({pal:'S',ball:[22,60],cup:[P.x+4,P.h,348-P.x,'R'],w:[[10,74,130,250,4],[130,250,170,262,4],[170,470,P.x,470,2],[P.x,P.h,P.x,476,0]]}),
 boxes:P=>[{x:[150,172],y:[252,266],a:[-.9,-.15],l:[35,90]}],
 leurre:P=>[[[168,262],[P.x+2,P.h+2]]],
 grid:()=>{const o=[];for(const x of [270,290])for(const h of [240,270])o.push({x,h});return o;}};
