/* Q-03-06 « Saut de chaîne » — R128 · monde 3 Chaîne : le tapis donne l'élan.
   Spectacle d'abord : au lâcher, la chaîne bondit toute seule — tapis du haut, tremplin, crochet tapissé qui cueille la particule
   en plein vol et la relance dans l'autre sens, trois sauts en zigzag d'un bord à l'autre de l'écran (chaque tapis remet la
   vitesse à la même valeur : la machine est régulière). Puis la chute en bas à gauche : il manque le DERNIER MAILLON.
   Idée : le joueur croit qu'un trait suffit (une rampe) ; il découvre que la zone est plus haute que la chute : seul un tapis,
   tracé dans le bon sens (de gauche à droite), remonte la particule jusqu'à la zone. Mesuré : structure 0, tapis à l'envers 0.
   Géométrie : scratchpad m/jump.js → machines/chaine30.json. */
const M=require('./machines/chaine30.json');
module.exports={titre:'Saut de chaîne',star:.85,mat:3,
 gen:P=>({pal:'SA',ball:M.ball.slice(),ink:260,cup:M.cup.slice(),w:[],curves:M.curves.map(q=>({pts:q.pts.map(p=>p.slice()),m:q.m}))}),
 boxes:P=>[{x:[0,16],y:[362,440],a:[-.45,.15],l:[120,200]}],
 grid:()=>[{}]};
