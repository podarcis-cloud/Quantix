/* Q-01-06 « Les collines » — R120 · Shō · RELAIS (récompense) · R-08 Protéger · H4 « les pointes sont à fuir ».
   Énigme (inchangée) : entre la corniche et la machine, la seule pente est un lit de pointes. Idée : le COUVRIR — le trait se pose
   sur le danger et la pente mortelle devient le toboggan qui lance la particule dans la machine.
   Machine R120 (refaite : « courbes tracées par un enfant ») — LA VAGUE, d'un seul tenant, tracée par tools/rail.js :
   crochet d'accueil dont la lèvre épouse le vol (entrée sans choc) → longue descente → vallée (courbure sinusoïdale) →
   crête serrée où la particule DÉCOLLE → dosseret qui cueille le vol en rasant → zone.
   Géométrie calculée sur le vrai moteur (scratchpad m6.js) et figée dans machines/collines6.json. */
const M=require('./machines/collines6.json');
module.exports={titre:'Les collines',star:.12,
 gen:P=>({pal:'S',ball:[326,20],ink:201,cup:M.cup.slice(),mz:M.mz.map(r=>r.slice()),curves:M.curves.map(q=>({pts:q.pts.map(p=>p.slice()),m:0})),
  w:[[262,44,352,36,0],[P.sx0,P.sy0,P.sx1,P.sy0+P.dsy,2]],nd:P.nd}),
 boxes:P=>[{x:[258,276],y:[52,64],a:[2.8,2.95],l:[138,162]}],
 grid:()=>[{sx0:257,sy0:87,sx1:143,dsy:25,nd:[[140,0,70,66],[210,0,46,54]]}]};
