module.exports=require('./auto.js')(13,{nd:[[90,120,150,300]],space:{dx:[20,40],dw:[20,45]}});
