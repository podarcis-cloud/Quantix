/* 47 « La crevasse double » — Histoire : la particule dévale le glacier, file sur un premier lac gelé coupé par une crevasse,
   rebondit contre la paroi du sérac, puis redescend vers la gauche sur un second lac, lui aussi coupé. Des pointes au‑dessus
   de chaque crevasse interdisent de sauter. Geste : deux ponts. Leurre : un seul pont (elle tombe dans la seconde). */
const Y=x=>Math.round(300+(350-x)*(40/310));
module.exports={titre:'La crevasse double',star:.7,
 gen:P=>({pal:'S',ball:[30,40],cup:[8,430,86,'L'],
 nd:[[124,162,P.g+12,Y(130+P.g)-182],[144,Y(150)+14,P.h+12,470-Y(150)]],   /* sous chaque crevasse : on ne peut pas rattraper la chute, il faut un pont */
 w:[
   [10,60,90,150,4],[90,150,130,150,4],[130+P.g,150,296,150,4],[130,114,130+P.g,114,2],
   [352,110,352,330,0],[6,290,6,372,0],
   [128,196,132+P.g,196,2],[148,Y(150)+56,152+P.h,Y(150+P.h)+56,2],   /* le fond de chaque crevasse : des pointes — y tomber est fatal */
   [350,300,150+P.h,Y(150+P.h),4],[150,Y(150),40,Y(40),4],[150,Y(150)-38,150+P.h,Y(150+P.h)-38,2]]}),
 boxes:P=>[{x:[124,136],y:[148,156],a:[-.08,.08],l:[P.g+12,P.g+40]},{x:[150+P.h+2,150+P.h+14],y:[Y(150+P.h)-2,Y(150+P.h)+6],a:[Math.PI-.25,Math.PI+.05],l:[P.h+12,P.h+40]}],
 leurre:P=>[[[128,152],[136+P.g,152]]],
 grid:()=>{const o=[];for(const g of [100,120])for(const h of [110,130,150])o.push({g,h});return o;}};
