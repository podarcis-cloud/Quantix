/* Q-01-08 « La portée » — R118 · Ten · Simple · R-21 Lire la trajectoire · H8 « il faut viser la zone » (ici : il faut viser l'endroit où elle RETOMBE).
   Énigme : le tremplin fixe lance la particule en longue parabole au‑dessus d'un sol de pointes ; elle passe au‑dessus du
   bassin et sort de l'écran. Le bassin est sous un auvent : on n'y entre qu'en roulant, par la porte. Idée : lire la portée du tir — deviner où
   la particule va retomber, et y poser, avant de lâcher, la rampe qui la conduit sous l'auvent jusqu'au bassin.
   Leurre : la rattraper près du tremplin (elle n'y est pas encore redescendue) ; un petit déflecteur (le tir rebondit sur l'auvent).
   Rôles : tremplin = PORTER (le tir) ; auvent = FERMER (entrer par le haut). */
module.exports={titre:'La portée',star:.6,
 gen:P=>({pal:'S',ball:[34,30],cup:[P.cx,452,P.cw,'L'],
  curves:[{pts:[[14,50],[30,100],[52,160],[P.kx-30,P.ky-14],[P.kx,P.ky],[P.kx+30,P.ky-4],[P.kx+56,P.ky-P.kh]],m:0}],   /* tremplin concave : descente, creux, lèvre */
  w:[[P.cx-6,452-P.ah,P.cx+P.cw+8,452-P.ah,0]]}),
 boxes:P=>{const ex=P.cx+P.cw+4,ey=436,ang=Math.atan2(ey-P.ly,ex-P.lx),d=Math.hypot(ex-P.lx,ey-P.ly);return [{x:[P.lx-25,P.lx+25],y:[P.ly-25,P.ly+25],a:[ang-.2,ang+.2],l:[d-10,d+40]}];},
 space:{kx:[100,124],ky:[236,262],kh:[30,52],cx:[60,110],cw:[90,110],ah:[54,66],lx:[250,330],ly:[200,330]},
 grid:()=>[]};
