/* Gabarit de machine composée « Les lacets d'or » (R83) — utilisé par trois prototypes de mondes différents.
   Composition : axe vertical x = 180 ; les deux pistes sur les lignes d'or (y ≈ 183 et 297) ; virages en miroir de part et
   d'autre ; entonnoir et zone sur l'axe ; le centre bas reste dégagé (respiration) ; deux pistes seulement (pas de surcharge).
   Matière des pistes selon le monde : tapis (Chaîne, pistes à plat), glace ou structure (Glacier, Atelier, pistes inclinées). */
const AX=180,mir=P=>P.map(p=>[2*AX-p[0],p[1]]);
module.exports=function(o){const m=o.m,tilt=o.tilt||0,ya=183,yb=297,xl=62,xr=298;
 const right=[[xr-20,ya-46],[xr+14,ya-42],[xr+40,ya-20],[xr+50,ya+30],[xr+44,yb-34],[xr+26,yb-12],[xr,yb-tilt]];   /* virage droit, lèvre au‑dessus */
 const left=mir(right).map(p=>[p[0],p[1]+yb-ya]).map((p,i,a)=>i===a.length-1?[xl,o.yc-tilt*.5]:p);   /* virage gauche (miroir, une marche plus bas) */
 const laneA=m===3?[xl,ya,xr,ya,3]:[xl,ya-tilt,xr,ya+tilt,m];      /* piste haute → (tapis à plat, ou pente douce) */
 const laneB=m===3?[xr,yb,xl,yb,3]:[xr,yb-tilt,xl,yb+tilt,m];      /* piste basse ← */
 const R0={pal:'S',ball:[318,36],cup:[AX-45,456,90,'B'],mz:[[0,140,360,340]],
  curves:[{pts:[[134,64],[150,98],[166,124]],m:0},{pts:[[226,64],[210,98],[194,124]],m:0},     /* entonnoir sur l'axe */
   {pts:[[96,150],[70,154],[52,168],[48,180]],m:0},                                              /* butée galbée à gauche de la piste haute */
   {pts:right,m:o.cm},{pts:left.slice(0,-1).concat([[xl+6,o.yc]]),m:o.cm},
   {pts:[[xl+6,o.yc],[96,o.yc+8],[o.kx,o.yc+2],[o.kx+22,o.yc-10]],m:o.fm},
   {pts:[[AX+18,o.yc-84],[AX+62,o.yc-70],[AX+80,o.yc-38],[AX+68,o.yc-12],[AX+42,o.yc-4]],m:o.cm}],   /* dosseret galbé : cueille le saut et le dépose dans la zone */                    /* dernière glissade + tremplin vers la zone */
  w:[laneA,laneB,[AX-110,474,AX-46,474,2],[284,118,356,118,2]]};
 if(!o.flip)return R0;   /* version en miroir (départ en haut à gauche) : même composition, lecture inversée */
 const fx=x=>360-x;return {pal:R0.pal,ball:[fx(R0.ball[0]),R0.ball[1]],cup:[360-R0.cup[0]-R0.cup[2],R0.cup[1],R0.cup[2],'B'],mz:R0.mz,
  curves:R0.curves.map(cv=>({pts:cv.pts.map(p=>[fx(p[0]),p[1]]),m:cv.m})),w:R0.w.map(w=>[fx(w[0]),w[1],fx(w[2]),w[3],w[4]])};};
