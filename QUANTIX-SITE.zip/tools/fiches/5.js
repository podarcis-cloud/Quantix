/* Q-01-05 « Le demi-tour » — R118 (déplacé de la position 3) · Shō · R-04 Inverser · H3 « le plus court est le mieux ».
   Énigme : la rampe fixe éloigne la particule du bassin, en bas à gauche ; le haut gauche est interdit (pas de raccourci).
   Idée : la laisser partir loin à droite, puis la RENVOYER en arrière, sous la rampe, jusqu'au bassin.
   Leurre : une ligne qui descend tout droit du bout de la rampe vers le bassin (elle file trop vite et passe).
   Rôles : rampe = PORTER (l'élan) ; zone interdite = FERMER (raccourci par le haut) ; bassin à paroi gauche = PORTER. */
module.exports={titre:'Le demi-tour',star:.6,
 gen:P=>({pal:'S',ball:[46,40],cup:[14,442,94,'L'],w:[[20,80,P.ex,P.ey,0]],nd:[[0,0,P.nx,P.nh]]}),
 boxes:P=>[{x:[P.ex+90,P.ex+130],y:[P.ey+30,P.ey+70],a:[2.65,2.95],l:[120,190]}],
 leurre:P=>[[[P.ex+4,P.ey+6],[70,430]]],
 grid:()=>{const o=[];for(const ex of [180,196])for(const ey of [160,170])for(const nh of [210,240])o.push({ex,ey,nx:ex+10,nh});return o;}};
