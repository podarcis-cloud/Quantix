/* Q-01-09 « La grande descente » — PROTOTYPE DE MACHINE PHYSIQUE COURBE (forme Relais).
   Composition : la zone jouable occupe le haut de l'écran ; la machine dessine une grande vague qui descend en lacets
   (entonnoir → tapis → virage → tapis → virage → tapis → virage → toboggan de glace → tremplin), comme une piste de montagnes
   russes vue de profil ; la zone d'arrivée en bas à gauche répond au départ en haut à droite (diagonale de lecture).
   Normaliseurs : l'entonnoir et chaque tapis effacent les différences d'entrée. */
module.exports={titre:'La grande descente',star:.4,
 gen:P=>({pal:'S',ball:[322,36],cup:[8,452,82,'L'],mz:[[0,150,360,330]],
   curves:[
    {pts:[[26,92],[40,128],[70,158]],m:0},{pts:[[164,92],[150,128],[120,158]],m:0},        /* entonnoir galbé */
    {pts:[[52,150],[28,168],[24,196],[42,206]],m:0},                                       /* butée galbée : renvoie vers le tapis */
    {pts:[[268,166],[310,170],[338,190],[348,226],[344,262],[326,286],[302,295]],m:0},               /* virage droit (demi‑lune) */
    {pts:[[96,250],[56,252],[28,272],[18,310],[24,348],[46,368],[72,376]],m:0},                     /* virage gauche */
    {pts:[[252,340],[296,344],[324,364],[334,394],[324,420],[298,432],[262,436]],m:0},               /* dernier virage */
    {pts:[[262,436],[200,442],[150,440],[P.k,426]],m:4}],                                  /* toboggan de glace + tremplin */
   w:[[40,204,290,214,3],[304,292,66,302,3],[72,374,272,380,3],[96,474,150,474,2],[236,150,356,150,2]]}),
 boxes:P=>[{x:[300,350],y:[55,110],a:[2.9,3.1],l:[150,230]}],
 grid:()=>[{k:110},{k:120}]};
