/* auto.js — R120 : fiche générique pour RÉPARER un niveau existant sans le réécrire (mondes 2 à 4, économie de quota).
   L'idée du niveau (décor, matières, départ) ne bouge pas ; leviers : bassin déplacé / élargi (P.dx, P.dw), départ décalé (P.bx),
   et zones interdites ajoutées pour fermer les traits courts (o.nd, écrit à la main après lecture de SHOW=1).
   Le geste est cherché dans des boîtes autour de la solution de référence (± 14 u, ± 0,18 rad, ± 25 % de longueur) :
   fiche.js garde la réalisation la plus jouable au doigt. Usage : fiches/N.js = module.exports=require('./auto.js')(N,{…}). */
module.exports=function(num,o){o=o||{};const D=require('../design.js'),L0=JSON.parse(JSON.stringify(D.X.LEVELS[num-1]));
 const sol0=o.sol||L0.optsol,mat=o.mat!==undefined?o.mat:(L0.optmat||0);
 return {titre:L0.n,star:o.star||.6,mat,
  gen:P=>{const c={pal:L0.pal||'S',ball:[L0.ball[0]+(P.bx||0),L0.ball[1]],ink:L0.ink,w:(o.w||L0.w).map(s=>s.slice()),
    cup:[Math.max(4,Math.min(356-L0.cup[2]-(P.dw||0),L0.cup[0]+(P.dx||0)-(P.dw||0)/2)),L0.cup[1]+(P.dy||0),L0.cup[2]+(P.dw||0),L0.cup[3]]};
   const nd=(L0.nd||[]).concat(o.nd||[]);if(nd.length)c.nd=nd;
   for(const k of ['curves','mz','rails','wind','grav','mag'])if(L0[k])c[k]=JSON.parse(JSON.stringify(L0[k]));
   /* dosseret (o.back) : paroi de lumière dressée sur le bord fermé du bassin, qui se courbe au-dessus de lui (virage sinusoïdal,
      tools/rail.js) : une arrivée trop longue est cueillie et versée dans le bassin. Toujours au-dessus de la zone. */
   if(o.back&&P.bh){const R=require('../rail.js').rail,right=c.cup[3]!=='L',x0=right?c.cup[0]+c.cup[2]:c.cup[0],y0=c.cup[1]-56;
    const pts=R(x0,y0,-90,[['L',P.bh],['T',right?-(P.bk||60):(P.bk||60),P.br||40]]);(c.curves=c.curves||[]).push({pts:pts.map(q=>[q[0],q[1]]),m:0});}
   return c;},
  boxes:P=>sol0.map(s=>{const a=Math.atan2(s[1][1]-s[0][1],s[1][0]-s[0][0]),l=Math.hypot(s[1][1]-s[0][1],s[1][0]-s[0][0]),e=o.e||14;
   return {x:[s[0][0]-e,s[0][0]+e],y:[s[0][1]-e,s[0][1]+e],a:[a-.18,a+.18],l:[l*.75,l*1.25]};}),
  space:Object.assign({dx:[-40,40],dw:[0,50]},o.space||{})};};
