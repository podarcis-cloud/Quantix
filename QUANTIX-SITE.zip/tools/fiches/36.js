/* Q-03-12 « La chaîne complète » — R129 · finale du monde 3 Chaîne : un VRAI LOOPING.
   La particule glisse de la corniche ; il manque le maillon qui MONTE jusqu'à la piste d'entrée (une ligne de structure ne
   monte pas, seul un tapis tracé dans le bon sens le fait). Puis le spectacle : la piste d'élan la lance dans le looping —
   montée par la droite, passage tête en bas, descente par la gauche — et la particule TRAVERSE sa propre piste d'entrée
   pour ressortir dessous (pistes « traversables » : solides quand on y roule, traversées quand on les coupe vite, champ
   `pass` des courbes, R129), puis file vers la zone, cueillie par un dosseret.
   Géométrie : scratchpad m/boucle.js, m/l36.js → machines/boucle36.json. */
const M=require('./machines/boucle36.json');
module.exports={titre:'La chaîne complète',star:.6,mat:3,
 gen:P=>JSON.parse(JSON.stringify({pal:"SA",ball:M.ball,ink:220,cup:M.cup,w:M.w,curves:M.curves,flow:M.flow,nd:[[0,300,262,180]]})),
 boxes:P=>[{x:[64,80],y:[268,284],a:[-.42,-.2],l:[70,100]}],
 grid:()=>[{}]};
