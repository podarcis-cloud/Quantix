/* Q-01-11 « La moitié » — R90 · Ketsu · type R-10 Détourner (par le bas) · hypothèse H9 « le décor est inerte ».
   Énigme : une longue poutre fixe fait plonger la particule vers des pointes ; la zone est sur un balcon, plus haut que la fin
   de la poutre. Leurre : un pont à plat depuis le bout de la poutre jusqu'au balcon — la particule bute contre le pied du
   balcon. Idée : la poutre fixe n'est que la MOITIÉ d'une vallée ; le trait est l'autre moitié — une remontée qui rend à la
   particule l'élan de sa chute et la hisse sur le balcon. Scénario : pont plat → la particule bute ; il voit qu'elle a de la
   vitesse en bas ; il comprend qu'il faut la faire remonter.
   Rôles : poutre fixe = PORTER (la descente) ; pointes = PIÉGER (la chute) ; poteau du balcon = FERMER (K1 pont à plat) ;
   balcon = PORTER. Composition : la grande diagonale de la poutre et le trait du joueur dessinent un V dont la pointe est
   sur la ligne d'or basse ; le balcon répond au départ en diagonale. */
module.exports={titre:'La moitié',star:.5,
 gen:P=>({pal:'S',ball:[30,P.sy],cup:[P.cx,P.cy,354-P.cx,'R'],
  curves:[{pts:[[16,P.sy+20],[50,P.sy+90],[86,Math.max(P.sy+150,214)],[120,272],[156,310],[196,333],[236,343],[P.tx,345]],m:0}],   /* la moitié de vallée : chute qui s'adoucit */
  w:[[P.cx-4,P.cy,P.cx-4,476,0],[P.tx+20,474,P.cx-6,474,2]]}),
 boxes:P=>{const ang=Math.atan2(P.cy-6-360,P.cx+10-P.tx),d=Math.hypot(P.cx+10-P.tx,P.cy-6-360);return [{x:[P.tx-30,P.tx+6],y:[352,370],a:[ang-.25,ang+.2],l:[d-10,d+50]}];},
 leurre:P=>[[[P.tx-4,345],[290,345]]],
 space:{tx:[236,252],cy:[296,320],sy:[110,150],cx:[268,284]},
 grid:()=>[]};
