module.exports=require('./auto.js')(23);
