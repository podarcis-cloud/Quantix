/* Q-02-12 « La fonte » — R126 · finale du monde 2 Fonderie.
   Esquisse de Simon dans l'éditeur (Q-02-12, 10 oct.), rendue fonctionnelle : la particule tombe ; le joueur la dévie sur la
   plaque du sol, qui la relance PAR DESSOUS dans un premier tube en arche ; elle redescend, frappe une plaque de rebond (le
   bonus de la Fonderie) qui la renvoie dans un second tube ; celui‑ci monte, se recourbe vers la gauche et la verse dans la
   zone, perchée en haut à gauche — plus haut que le départ de la machine : la plaque rend plus qu'elle ne reçoit.
   Tubes : tracé central lissé + deux parois parallèles (scratchpad m/tubes.js, m/m24d.js, réglage m/g24.js) ;
   géométrie figée dans machines/fonte24.json. */
const M=require('./machines/fonte24.json');
module.exports={titre:'La fonte',star:.55,
 gen:P=>({pal:'SB',ball:[22,26],ink:286,cup:M.cup.slice(),w:M.w.map(s=>s.slice()),nd:M.nd.map(r=>r.slice()),curves:M.curves.map(q=>({pts:q.pts.map(p=>p.slice()),m:q.m}))}),
 boxes:P=>[{x:[0,30],y:[230,360],a:[.6,1.5],l:[30,160]}],
 grid:()=>[{}]};
