/* Q-07-04 « Le champ de travers » — R96 · Shō · Simple · R-04 Inverser · hypothèse : « tomber, c'est vers le bas ».
   Histoire : la zone est derrière un haut mur, à gauche ; la particule tombe à droite. Au pied du mur, un champ dont la
   gravité tire vers le HAUT et vers la GAUCHE. Idée : y conduire la particule — le champ la soulève par‑dessus le mur et la
   laisse retomber dans la zone. Leurre : une rampe qui la lance vers le mur (elle s'y écrase, trop bas).
   Rôles : mur = FERMER (accès direct) ; champ = PORTER ; zone = PORTER. */
module.exports={titre:'Le champ de travers',star:.6,obstacle:false,
 gen:P=>({pal:'S',ball:[322,P.by],cup:[16,452,104,'L'],nd:[[262,P.by+40,98,440-P.by]],grav:[[160,P.zt,P.zw,476-P.zt,-P.gx,-P.gy]],
  w:[]}),
 boxes:P=>[{x:[318,350],y:[P.by+14,P.by+34],a:[2.6,2.95],l:[90,170]}],
 leurre:P=>[[[330,P.by+20],[155,P.wt-10]]],
 grid:()=>{const o=[];for(const by of [250])for(const gy of [.6])for(const zw of [50])o.push({by,wt:170,gy,gx:.3,zt:120,zw});return o;}};
