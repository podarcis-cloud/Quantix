/* Q-02-06 « Ta plaque » — R124 · monde 2 Fonderie : la plaque rend plus qu'elle ne reçoit.
   Machine dessinée par Simon dans l'éditeur (Q-02-06, 10 oct.) et mise au propre : un SERPENTIN de lumière — tube à deux
   parois parallèles (largeur constante 38 u) sur un tracé central lissé, ouvert par le bas à gauche. Le joueur trace une plaque
   qui relance la particule dans l'embouchure ; elle monte, passe l'arche, redescend en lacets ; au virage droit, la paroi
   extérieure est une plaque de rebond (le bonus de la Fonderie) qui la relance ; la sortie tombe dans le bassin, scellé sous
   le tube. Géométrie : scratchpad m/tube.js → machines/serpentin18.json. */
const M=require('./machines/serpentin18.json');
module.exports={titre:'Ta plaque',star:.5,mat:1,
 gen:P=>({pal:'SB',ball:[40,40],ink:200,cup:M.cup.slice(),w:[],curves:M.curves.map(q=>({pts:q.pts.map(p=>p.slice()),m:q.m}))}),
 boxes:P=>[{x:[4,36],y:[290,370],a:[.2,.6],l:[50,110]}],
 grid:()=>[{}]};
