/* 45 « Le passage gardé » — Histoire : la glace descend vers une grande zone interdite qui garde tout le centre ; en dessous,
   des pointes ; la zone est de l'autre côté. On ne peut rien construire au‑dessus du vide gardé.
   Geste : un tremplin AVANT la zone interdite, pour qu'elle la survole d'un saut. Leurre : tracer au bord de la zone interdite. */
module.exports={titre:'Le passage gardé',star:.6,
 gen:P=>({pal:'S',ball:[22,90],nd:[[150,0,P.w,480]],cup:[150+P.w+6,P.h,348-(150+P.w+6),'R'],
   w:[[10,104,120,190,4],[120,190,148,196,4],[150,470,150+P.w,470,2],[150+P.w+2,P.h,150+P.w+2,476,0]]}),
 boxes:P=>[{x:[100,146],y:[186,202],a:[-1,-.15],l:[45,100]}],
 leurre:P=>[[[146,150],[146,198]]],
 grid:()=>{const o=[];for(const w of [110,118])for(const h of [222,230,238])o.push({w,h});return o;}};
