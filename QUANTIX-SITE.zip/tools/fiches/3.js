/* Q-01-03 « Le colimaçon » — R120 · Ki · RELAIS (révélation de la machine du monde) · R-05 Rattraper · H8 « il faut viser la zone ».
   Énigme (inchangée) : la particule tombe droit sur un lit de pointes ; la zone est enfermée dans la machine (non traçable) :
   il faut viser le RELAIS — la courbe d'accueil en haut — avec une rampe qui cueille la chute ; la machine fait le reste.
   Machine R120 (refaite à la demande de Simon : « courbes tracées par un enfant ») : LACETS HARMONIEUX —
   courbe d'accueil (la particule s'y pose en rasant), puis trois crochets en J alternés droite / gauche / droite.
   Chaque crochet est construit par tools/rail.js : sa lèvre épouse la trajectoire de vol à 0,8 u près (entrée sans choc),
   puis un virage à courbure sinusoïdale (raccord G2, comme les clothoïdes des vraies montagnes russes) la retourne.
   Géométrie calculée sur le vrai moteur (scratchpad m3.js) et figée dans machines/lacets3.json. */
const M=require('./machines/lacets3.json');
module.exports={titre:'Le colimaçon',star:.1,
 gen:P=>({pal:'S',ball:[P.bx,24],ink:135,cup:M.cup.slice(),mz:M.mz.map(r=>r.slice()),curves:M.curves.map(q=>({pts:q.pts.map(p=>p.slice()),m:0})),
  w:[[6,P.sy,P.sx,P.sy,2]],nd:[[P.nx,P.ny||0,P.nw||360-P.nx,140-(P.ny||0)]]}),   /* R120 : ciel interdit à droite : la rampe ne peut pas lâcher la particule au-dessus du premier crochet */
 boxes:P=>[{x:[P.bx-24,P.bx+16],y:[40,64],a:[-.02,.26],l:[100,175]}],
 grid:()=>[{bx:56,sx:110,sy:118,nx:190,ny:40,nw:110}]};
