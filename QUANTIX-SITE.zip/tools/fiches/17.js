module.exports=require('./auto.js')(17);
