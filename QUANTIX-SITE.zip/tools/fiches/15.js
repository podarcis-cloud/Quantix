module.exports=require('./auto.js')(15,{back:1,space:{bh:[30,110],bk:[40,90],br:[25,60]}});
