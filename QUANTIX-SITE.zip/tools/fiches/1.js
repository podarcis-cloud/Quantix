/* Q-01-01 « Le premier trait » — R116 · Ki · R-01 Découvrir · hypothèse « cet élément est un décor ».
   GÉOMÉTRIE DESSINÉE PAR SIMON (éditeur, Q-01-01) ; la fiche ne fait que la mesurer et placer le noyau.
   Énigme : les deux poutres et le crochet en C ne sont pas un décor : ils prennent la particule en charge, la font tourner et la
   renvoient vers la gauche, droit sur le tapis de pointes. Le bassin est en bas, au centre.
   Idée (R116, mesurée au doigt) : le trait est un MUR — posé à la sortie du crochet, il arrête la particule renvoyée vers les pointes
   et la laisse tomber dans le bassin. Scénario : il laisse la particule faire son tour, la voit filer vers les pointes, lui barre la route. Rôles : poutres + crochet =
   PORTER (l'élan) ; pointes = PIÉGER (la chute naturelle) ; zone interdite au‑dessus des pointes = FERMER (la petite tablette
   de 10 u qui suffisait, R118) ; bassin = PORTER. */
module.exports={titre:'Le premier trait',star:.7,
 gen:P=>({pal:'S',ball:[60,40],cup:[P.cx,456,Math.min(P.cw,352-P.cx),P.side],
  w:[[30,90,110,155,0],[110,155,235,155,0],[25,297,P.pe,297,2]],nd:P.ndw?[[P.ndx,222,P.ndw,46]]:[],
  curves:[{pts:[[288,183],[285,200],[280,215],[273,227],[265,236],[255,242],[243,246],[229,247],[214,246]],m:0},
          {pts:[[213,121],[231,121],[246,123],[259,128],[269,135],[277,143],[283,154],[287,168],[288,183]],m:0}]}),
 boxes:P=>[{x:[128,160],y:[185,225],a:[.85,1.45],l:[55,120]}],
 space:{pe:[150,200],cx:[188,226],cw:[110,140],side:['R'],ndx:[86,104],ndw:[0,0,36,48]},
 grid:()=>[]};
