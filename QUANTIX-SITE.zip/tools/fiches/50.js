/* 50 « Vent de face » (R71) — Histoire : un lac à traverser, coupé par une fosse de pointes ; au‑dessus de la fosse, un vent
   souffle à contre‑sens et repousse la particule. Geste : un pont qui DESCEND vers la zone, assez pentu pour vaincre le vent.
   Leurre : un pont plat — sans vent il suffirait ; avec le vent, la particule cale au milieu et revient. */
module.exports={titre:'Vent de face',star:.6,obstacle:true,
 gen:P=>({pal:'S',ball:[30,150],cup:[262,P.cy,90,'R'],wind:[[110,60,170,300,-P.fx,0]],
   w:[[10,170,110,200,0],[110,470,262,470,2],[262,P.cy,262,476,0]]}),
 boxes:P=>[{x:[100,118],y:[195,208],a:[.3,1.05],l:[160,260]}],
 leurre:P=>[[[108,201],[264,P.cy-60]]]   /* pont en pente douce : suffit sans vent, cale avec */,
 grid:()=>{const o=[];for(const fx of [.12,.16,.2])for(const cy of [330,380])o.push({fx,cy});return o;}};
