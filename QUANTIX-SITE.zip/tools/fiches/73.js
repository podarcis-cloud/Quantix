/* Q-07-01-R01 « Tomber vers le haut » — R94 · Ki · Découvrir · hypothèse : « le haut est le haut ».
   Énigme : la zone est perchée en haut à droite, bien au‑dessus de la particule, qui tombe vers des pointes. Au centre, une
   colonne où la gravité est inversée. Idée : y conduire la particule — elle y « tombe » vers le haut, ressort au sommet et
   retombe sur le balcon. Leurre : une rampe qui monte vers la zone (aucune énergie pour monter).
   Rôles : colonne = PORTER ; pointes = PIÉGER (la chute naturelle) ; balcon = PORTER. */
module.exports={titre:'Tomber vers le haut',star:.55,
 gen:P=>({pal:'S',ball:[40,P.by],cup:[P.cx,P.cy,360-P.cx-6,'R'],grav:[[P.gx,P.gt,P.gw,470-P.gt,P.ux,-P.g]],
  curves:[{pts:[[156,P.ct+44],[200,P.ct+26],[240,P.ct+12],[296,P.ct]],m:0}],   /* voûte : sous la gravité inversée elle devient une pente qui mène au balcon */
  w:[[16,P.by+16,84,P.by+22,0]]}),   /* la particule part PLUS BAS que la zone : seule la colonne peut l'y porter */
 boxes:P=>[{x:[84,100],y:[P.by+18,P.by+30],a:[.15,.9],l:[60,150]}],
 leurre:P=>[[[86,P.by+20],[P.cx,P.cy-6]]],
 grid:()=>{const o=[];for(const by of [300,320])for(const g of [.3,.35,.4])o.push({by,g,ux:0,cy:170,gx:160,gw:110,gt:80,cx:276,ct:76});return o;}};
