module.exports=require('./auto.js')(16);
