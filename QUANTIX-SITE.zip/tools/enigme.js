/* enigme.js — CONTRÔLE « ÉNIGME » (R74). Un niveau est une énigme si :
   (1) toutes ses solutions passent par la même idée : la famille de la solution de référence = l'ensemble U des éléments que sa
       trajectoire touche (murs, plaques, tapis) ou traverse (zones de champ) ; toute solution qui ne touche pas TOUT U est un
       RACCOURCI ;
   (2) les raccourcis évidents sont cherchés exprès (ligne directe de la particule à la zone dans chaque matière, rampe depuis le
       départ, pont vers la zone) puis au hasard (3 000 traits) ;
   (3) chaque élément a un rôle : soit il est dans U (il porte la solution), soit le retirer OUVRE un raccourci (il le bloque) ;
       sinon il est INUTILE.
   Usage : node enigme.js 25 26 …   (niveaux installés, avec optsol)                                   */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js');
const FIELDS=['wind','grav','mag','port','mov','curves','mz'],COST={0:1,1:1.9,3:1.7,5:1};
let seed=23;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
function near(tr,w){return tr.some(q=>{const ax=w[2]-w[0],ay=w[3]-w[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((q[0]-w[0])*ax+(q[1]-w[1])*ay)/l)):0;return Math.hypot(q[0]-w[0]-u*ax,q[1]-w[1]-u*ay)<19;});}   /* contact = rayon + demi‑épaisseur du mur ≈ 14,5 */
function inZone(tr,z){return tr.some(q=>q[0]>z[0]&&q[0]<z[0]+z[2]&&q[1]>z[1]&&q[1]<z[1]+z[3]);}
function touched(c,tr){const s=new Set();(c.w||[]).forEach((w,i)=>{if(near(tr,w))s.add('w'+i);});
 (c.curves||[]).forEach((cv,i)=>{const P=cv.pts||[];for(let k=1;k<P.length;k++)if(near(tr,[P[k-1][0],P[k-1][1],P[k][0],P[k][1]])){s.add('c'+i);break;}});   /* R118 : les courbes comptent dans l'idée */
 for(const f of ['wind','grav'])(c[f]||[]).forEach((z,i)=>{if(inZone(tr,z))s.add(f+i);});return s;}
function audit(idx){
 seed=1000+idx*7919;   /* R92 : tirage reproductible par niveau (indépendant de l'ordre des niveaux) */
 const L=JSON.parse(JSON.stringify(X.LEVELS[idx])),c={ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w};for(const f of FIELDS)if(L[f])c[f]=L[f];
 const mats=[0].concat((L.pal||'').includes('A')?[3]:[]).concat((L.pal||'').includes('B')?[1]:[]).concat((L.pal||'').includes('C')?[5]:[]);
 const ref=LAB.run(idx,c,L.optsol.map(p=>({pts:p,mat:L.optmat||0})));if(!ref.ok)return {n:L.n,err:'la solution de référence échoue'};
 let U=touched(c,ref.tr);
 /* la fiche peut nommer les éléments qui portent l'idée (ex. ['grav0']) : un appui accessoire (corniche de départ) touché par la
    solution de référence n'est alors pas exigé des autres solutions */
 let PASS=[];try{const RG=JSON.parse(require('fs').readFileSync(__dirname+'/fiches/registre.json'));const e=RG[String(idx+1)];if(e&&e.pass)PASS=e.pass;if(e&&e.U)U=new Set(e.U);}catch(_){}
 /* passages obligés (ex. la gorge de l'entonnoir d'une machine) : « P0 », « P1 »… comptent comme éléments de l'idée */
 const isShort=(cc,ss)=>{const r=LAB.run(idx,cc,ss);if(!r.ok)return false;const T=touched(c,r.tr);PASS.forEach((z,i)=>{if(inZone(r.tr,z))T.add('P'+i);});for(const u of U)if(!T.has(u))return true;return false;};
 function cands(cc){const o=[],b=L.ball,cp=L.cup;
  for(const m of mats)for(const dy of [12,22,34])for(const dx of [-12,0,12])for(const tx of [.15,.5,.85])for(const ty of [-34,-12,0]){
   const p=[[b[0]+dx,b[1]+dy],[Math.round(cp[0]+cp[2]*tx),cp[1]+ty]];if(D.drawable(cc,p))o.push([{pts:p,mat:m}]);}
  for(let k=0;k<+(process.env.NS||2500);k++){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,l=10+rnd()*Math.min(230,cc.ink/(COST[m]||1)),
   p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*l),Math.round(y+Math.sin(a)*l)]];if(D.drawable(cc,p))o.push([{pts:p,mat:m}]);}
  return o;}
 const C0=cands(c);let shortcuts=0,ex=null;for(const ss of C0){const len=ss.reduce((a,s)=>a+Math.hypot(s.pts[1][0]-s.pts[0][0],s.pts[1][1]-s.pts[0][1])*(COST[s.mat]||1),0);if(len>c.ink)continue;
  if(isShort(c,ss)){shortcuts++;ex=ex||ss[0].pts;}}
 /* rôle de chaque élément hors U : le retirer doit ouvrir un raccourci (sinon : inutile) */
 /* rôle de chaque élément hors U : le retirer doit créer des solutions qui n'existaient pas (il bloquait un chemin) */
 const sub=C0.slice(0,1200),W0=new Set();sub.forEach((ss,k)=>{if(LAB.run(idx,c,ss).ok)W0.add(k);});
 const useless=[];(c.w||[]).forEach((w,i)=>{if(U.has('w'+i))return;const c2=Object.assign({},c,{w:c.w.filter((_,j)=>j!==i)});
  let opens=false;for(let k=0;k<sub.length&&!opens;k++){if(W0.has(k))continue;if(LAB.run(idx,c2,sub[k]).ok)opens=true;}
  if(!opens)useless.push('w'+i+(w[4]===2?'(pointes)':w[4]===3?'(tapis)':w[4]===1?'(rebond)':w[4]===4?'(glace)':''));});
 return {n:L.n,U:[...U],shortcuts,ex,useless};}
for(const a of process.argv.slice(2)){const r=audit(+a-1);
 if(r.err){console.log('#'+a,r.n,'—',r.err);continue;}
 const noIdea=!r.U.length;const ok=!r.shortcuts&&!r.useless.length&&!noIdea;
 console.log(`#${a} ${r.n.padEnd(20)} ${ok?'ÉNIGME ✓':'✗'} · idée = ${noIdea?'AUCUN élément utilisé':'touche '+r.U.join('+')} · raccourcis ${r.shortcuts}${r.ex?' ex. '+JSON.stringify(r.ex):''} · éléments inutiles ${r.useless.join(',')||'aucun'}`);}
