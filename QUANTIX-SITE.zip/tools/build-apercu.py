"""build-apercu.py N [U] — aperçu jouable autonome ouvert sur la carte du monde N
(tous ses niveaux débloqués, rien n'est sauvegardé de plus). Sortie : /mnt/user-data/outputs/quantix-apercu-mondeN.html
Règle (demande utilisateur) : ne livrer que l'aperçu du monde en cours, pas tout le jeu."""
import base64,re,sys,os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));W=int(sys.argv[1]);U=int(sys.argv[2]) if len(sys.argv)>2 and sys.argv[2].isdigit() else W;SKIP='skipintro' in sys.argv  # skipintro : didacticiel d'ouverture considéré comme fait (outils d'édition proposés)  # U : débloquer les mondes jusqu'à U (ex. didacticiel : 1 3)
def uri(p):
    m={'jpg':'image/jpeg','png':'image/png','mp3':'audio/mpeg'}[p.rsplit('.',1)[1]]
    return 'data:%s;base64,%s'%(m,base64.b64encode(open(os.path.join(ROOT,p),'rb').read()).decode())
h=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
css=open(os.path.join(ROOT,'assets/css/quantix.css'),encoding='utf-8').read().replace('url(../img/ui/hero.jpg)','url('+uri('assets/img/ui/hero.jpg')+')')
h=h.replace('<link rel="manifest" href="manifest.webmanifest">\n','').replace('<link rel="apple-touch-icon" href="assets/img/ui/icon-192.png">','')
h=h.replace('<link rel="icon" href="assets/img/ui/icon-192.png" sizes="192x192">','<link rel="icon" href="%s" sizes="192x192">'%uri('assets/img/ui/icon-192.png'))
h=re.sub(r'<link rel="stylesheet" href="assets/css/quantix\.css(\?v=[^"]*)?">',lambda m:'<style>\n'+css+'\n</style>',h,count=1)   # R236 : adresse versionnée
for f in ['worldart','i18n','levels','visuals','tuto-scenes','tuto','editor','hero','fin-sound','haptics','transitions','engine','sound','runlog','events']:
    js=open(os.path.join(ROOT,'assets/js/%s.js'%f),encoding='utf-8').read()
    for m in sorted(set(re.findall(r"assets/[A-Za-z0-9_./-]+\.(?:jpg|png|mp3)",js))):js=js.replace(m,uri(m))
    if f=='hero':js='window.QHERO_IMG=['+','.join('"'+uri('assets/img/hero/h%02d.jpg'%(k+1))+'"' for k in range(11))+'];\n'+js   # R188 : fonds du héros (chemins construits à l'exécution)
    mt=re.search(r'<script src="assets/js/%s\.js(\?v=[^"]*)?"></script>'%re.escape(f),h);assert mt,f;h=h[:mt.start()]+'<script>\n'+js+'\n</script>'+h[mt.end():]   # R236 : adresse versionnée
# skipintro : si le joueur n'a pas encore d'état de didacticiel, il est traité comme ayant fini les mondes précédents :
# intro faite, fiches d'outils vues (sauf monde 1), éléments des niveaux précédents vus. Seules les règles NOUVELLES du monde s'affichent.
SKIPJS="if(!TUTO._intro()){var f0=worldRange(%d)[0],s0=[];if(f0>0){s0=TUTO._tools.slice();for(var j0=0;j0<f0;j0++)s0=s0.concat(TUTO._elemsOf(LEVELS[j0]));}TUTO.load({v:1,i:1,s:s0},0);if(typeof persist==='function')persist();}"%W
boot=('<script>/* APERÇU monde %d : ouverture directe sur sa carte, niveaux du monde débloqués */\n'
      'setTimeout(function(){try{%svar r=worldRange(%d);S.unlocked=Math.max(S.unlocked,worldRange(%d).slice(-1)[0]);openWorld(%d);}catch(e){console.log(e);}},450);</script>\n</body>')%(W,SKIPJS if SKIP else '',W,U,W)
if 'plein' in sys.argv and False:   # R194 : le plein cadre est dans le site ; option gardée pour de futurs prototypes
   # R190 : prototype « Plein cadre » (studio/), injecté dans l'aperçu seulement
    _pc=open(os.path.join(ROOT,'studio/proto-plein-cadre.css'),encoding='utf-8').read();_pj=open(os.path.join(ROOT,'studio/proto-plein-cadre.js'),encoding='utf-8').read()
    h=h.replace('</head>','<style>\n'+_pc+'\n</style>\n</head>',1);boot=boot.replace('</body>','<script>\n'+_pj+'\n</script>\n</body>')
if 'home' in sys.argv:boot=boot.replace('openWorld(%d);'%W,'').replace('ouverture directe sur sa carte','ouverture sur l\'accueil')   # R188 : aperçu de l'accueil
if 'fin' in sys.argv:boot=boot.replace('openWorld(%d);'%W,"for(var q9=0;q9<LEVELS.length;q9++)S.best[q9]=Math.max(S.best[q9]||0,1);goto('game');loadLevel(LEVELS.length-1);setTimeout(function(){S.mode='run';BUS.emit('level.complete',{});},900);").replace('ouverture directe sur sa carte','ouverture sur la célébration finale')   # R201 : aperçu de la fin du jeu
if 'capture' in sys.argv:boot=boot.replace('</body>','<script>\n'+open(os.path.join(ROOT,'studio/apercu-capture.js'),encoding='utf-8').read()+'\n</script>\n</body>')   # R286 : captation des parcours (base de l\'artefact)
h=h.replace('</body>',boot,1)
# R115 : Quantone embarqué (le jeu l'ouvre en plein écran ; dans l'aperçu autonome il n'y a pas de dossier studio/)
_q=os.path.join(ROOT,'studio/quantone.html')
if os.path.exists(_q):
    _b=base64.b64encode(open(_q,'rb').read()).decode()
    h=h.replace('</body>','<script>window.QT_SRC=new TextDecoder().decode(Uint8Array.from(atob("%s"),function(c){return c.charCodeAt(0);}));</script>\n</body>'%_b,1)
h=re.sub(r'<meta name="viewport" content="[^"]*">','<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">',h,count=1)
out='/mnt/user-data/outputs/quantix-apercu-monde%d.html'%W;open(out,'w',encoding='utf-8').write(h);print(out,'%.1f Mo'%(len(h.encode())/1e6))
