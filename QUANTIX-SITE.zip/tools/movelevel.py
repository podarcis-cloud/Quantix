"""movelevel.py SRC DST — R118 : copie l'entrée du niveau SRC (levels.js + LV_EN_N/LV_EN_T) dans la case DST (la case SRC est gardée
telle quelle, à réécrire ensuite). Le monde (wd) de DST est conservé."""
import re,sys,importlib.util
R='/home/claude/q/';src,dst=int(sys.argv[1]),int(sys.argv[2])
p=R+'assets/js/levels.js';s=open(p,encoding='utf-8').read()
st=[m.start() for m in re.finditer(r'^\{wd:',s,re.M)];assert len(st)==132
def ent(n):a=st[n-1];m=re.compile(r"tip:'(?:[^'\\]|\\.)*'\},?\n").search(s,a);return a,m.end()
a,b=ent(src);E=s[a:b];wd=re.match(r'\{wd:(\d+)',s[st[dst-1]:]).group(1);E=re.sub(r'^\{wd:\d+','{wd:'+wd,E)
a2,b2=ent(dst);s=s[:a2]+E+s[b2:];open(p,'w',encoding='utf-8').write(s)
ip=R+'assets/js/i18n.js';t=open(ip,encoding='utf-8').read()
def items(name):a=t.index('var %s=['%name);b=t.index('];',a);return a,b,list(re.finditer(r"'(?:[^'\\]|\\.)*'",t[a:b]))
for name in ('LV_EN_N','LV_EN_T'):
    a,b,it=items(name);assert len(it)==132;val=it[src-1].group(0);d=it[dst-1]
    t=t[:a+d.start()]+val+t[a+d.end():]
open(ip,'w',encoding='utf-8').write(t);print('OK',src,'→',dst)
