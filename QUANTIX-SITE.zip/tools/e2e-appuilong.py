# Appui long : pas de menu d'automation sur un bouton sans valeur (outils), menu conservé sur un curseur (R383)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
J="""async(s)=>{const el=document.querySelector(s),b=el.getBoundingClientRect(),o={bubbles:true,clientX:b.x+b.width/2,clientY:b.y+b.height/2,pointerType:'touch',pointerId:5};
 el.dispatchEvent(new PointerEvent('pointerdown',o));await new Promise(r=>setTimeout(r,700));const m=!!document.getElementById('auMenu');el.dispatchEvent(new PointerEvent('pointerup',o));return m}"""
with sync_playwright() as pw:
    b=pw.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True);pg=ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(1000)
    chk(pg.evaluate(J,'.dk[data-m="line"]')is False,'outil Droite : pas de menu')
    chk(pg.evaluate(J,'.dk[data-m="draw"]')is False,'outil Trait : pas de menu')
    chk(pg.evaluate(J,'input[type=range]')is True,'curseur : menu conservé')
    chk(not er,'aucune erreur JS')
    b.close()
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
