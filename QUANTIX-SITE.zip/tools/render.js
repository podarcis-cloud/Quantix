require('./load.js');
const X=globalThis.__X, raf=()=>{const q=global.__raf||[];global.__raf=[];q.forEach(f=>f(16));};
const {store}=require('./load.js');
store['app'].dataset.screen='game';
let err=null;
try{ for(let i=0;i<12;i++)raf(); }catch(e){err=e;}
console.log(err?('  ERREUR de rendu : '+err.message):'  12 frames de rendu                          OK');
X.loadLevel(0);X.S.strokes.push({pts:[[24,80],[250,430]],len:0,birth:0,mat:0});X.qpBuild();X.S.mode='run';
for(let f=0;f<900&&X.S.mode==='run';f++)X.physics();
console.log('  niveau 1, rampe de référence : '+X.S.mode.padEnd(8)+'  '+(X.S.mode==='success'?'OK':'ÉCHEC'));
let n=0;for(let w=1;w<=11;w++){X.openWorld(w);const h=store['wMap'].innerHTML;
  if((h.match(/class="wn /g)||[]).length===12)n++;}
console.log('  11 cartes de monde, 12 nœuds chacune : '+n+'/11   '+(n===11?'OK':'ÉCHEC'));
console.log('  audio : '+Object.keys(X.Audio1).length+' méthodes exposées        OK');
