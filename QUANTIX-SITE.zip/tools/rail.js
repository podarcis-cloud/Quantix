/* rail.js — R120 : tracé de pistes de machine HARMONIEUSES (fini les courbes « à la main »).
   Une piste est écrite comme un trajet de tortue : départ (x, y, cap en degrés, 0 = vers la droite, 90 = vers le bas),
   puis des ordres :
     ['L', longueur]            ligne droite
     ['T', angle°, rayon]       virage à courbure SINUSOÏDALE : la courbure monte et redescend en douceur
                                (κ(s) = κmax·sin²(πs/ℓ), ℓ = 2·|angle|·rayon) — pas d'à‑coup ni à l'entrée ni à la sortie
                                (raccord G2, comme les clothoïdes des vraies montagnes russes). angle > 0 : sens horaire à l'écran.
   Sortie : points réguliers (pas ≈ 6 u) que le moteur lisse encore (Catmull‑Rom) → la piste est la même pour l'œil et la physique.
   rail.end(pts) donne le dernier point et le cap de sortie, pour enchaîner. */
const D2R=Math.PI/180;
function rail(x,y,cap,cmds,step){step=step||6;let a=cap*D2R;const out=[[x,y]];let acc=0;const ds=.25;
 const push=()=>{acc+=ds;if(acc>=step-1e-9){acc=0;out.push([+x.toFixed(1),+y.toFixed(1)]);}};
 for(const c of cmds){
  if(c[0]==='L'){const n=Math.round(c[1]/ds);for(let i=0;i<n;i++){x+=Math.cos(a)*ds;y+=Math.sin(a)*ds;push();}}
  else if(c[0]==='T'){const th=c[1]*D2R,R=c[2],len=2*Math.abs(th)*R,km=Math.sign(th)/R*2*Math.abs(th)/len*2/2*1,n=Math.round(len/ds);
   /* ∫ κmax·sin²(πs/ℓ) ds = κmax·ℓ/2 = θ  →  κmax = 2θ/ℓ */
   const kmax=2*th/len;for(let i=0;i<n;i++){const s=(i+.5)*ds,k=kmax*Math.pow(Math.sin(Math.PI*s/len),2);a+=k*ds;x+=Math.cos(a)*ds;y+=Math.sin(a)*ds;push();}}}
 const last=out[out.length-1];if(Math.hypot(last[0]-x,last[1]-y)>1)out.push([+x.toFixed(1),+y.toFixed(1)]);
 out.cap=a/D2R;out.x=x;out.y=y;return out;}
/* fluidité d'un trajet : à‑coups = variations brusques d'accélération (chocs), en images */
function jolts(tr,from,thr){thr=thr||1.1;let n=0;const at=[];for(let i=Math.max(3,from||0);i<tr.length;i++){
 const a1=[tr[i][0]-2*tr[i-1][0]+tr[i-2][0],tr[i][1]-2*tr[i-1][1]+tr[i-2][1]],a0=[tr[i-1][0]-2*tr[i-2][0]+tr[i-3][0],tr[i-1][1]-2*tr[i-2][1]+tr[i-3][1]];
 const j=Math.hypot(a1[0]-a0[0],a1[1]-a0[1]);if(j>thr){n++;if(at.length<12)at.push([i,Math.round(tr[i][0]),Math.round(tr[i][1]),+j.toFixed(1)]);}}
 return {n,at};}
module.exports={rail,jolts};
