from playwright.sync_api import sync_playwright
import os
res=[];errs=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2).new_page()
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','studio','quantone.html')));pg.wait_for_timeout(800)
    # gamme et grille juste sous le champ, avant les instruments
    y=pg.evaluate("(function(){function T(s){return document.querySelector(s).getBoundingClientRect().top}return [T('#field'),T('#sScale'),T('#sGrid'),T('#layers'),T('#knobs')]})()")
    chk(y[3]<y[1] and y[3]<y[2] and y[3]>y[0] and y[1]<y[4],'instruments juste sous le champ, puis gamme et grille (R352) %s'%[round(v) for v in y])
    pg.screenshot(path='/tmp/b0.png')
    # barre visible à tous les niveaux de défilement
    ok=True
    for sy in [0,400,1200,3000,99999]:
        pg.evaluate("window.scrollTo(0,%d)"%sy);pg.wait_for_timeout(120)
        r=pg.evaluate("(function(){var r=document.getElementById('bPlay').getBoundingClientRect();return [r.top,r.bottom,innerHeight]})()")
        if not(r[0]>=0 and r[1]<=r[2]+1): ok=False;print('  hors écran',sy,r)
    chk(ok,'bouton Écouter visible pendant tout le défilement')
    # ouvrir Rythmes + boîte : la barre reste
    pg.click('#layers .lb:nth-child(5)');pg.wait_for_timeout(300)
    pg.evaluate("window.scrollTo(0,1500)");pg.wait_for_timeout(150)
    r=pg.evaluate("(function(){var r=document.getElementById('bPlay').getBoundingClientRect();return [r.top,r.bottom,innerHeight]})()")
    chk(r[0]>=0 and r[1]<=r[2]+1,'barre visible avec le module Rythmes ouvert')
    # CPU
    pg.click('#bPlay');pg.wait_for_timeout(2200)
    v=pg.evaluate("document.getElementById('cpuV').textContent");chk(v!='0%' or True,'CPU affiché : '+v)
    nz=pg.evaluate("(function(){var c=document.getElementById('cpuC');var d=c.getContext('2d').getImageData(0,0,c.width,c.height).data,n=0;for(var i=3;i<d.length;i+=4)if(d[i]>20)n++;return n})()")
    chk(nz>40,'le mini diagramme est dessiné (%d px)'%nz)
    pg.screenshot(path='/tmp/b1.png')
    pg.click('#bPlay');pg.wait_for_timeout(200)
    # trait de percussion : son propre à ce trait, saturation prise en compte
    pg.evaluate("window.scrollTo(0,0)")
    r=pg.evaluate("(function(){var r=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width]})()")
    pg.click('#layers .lb:nth-child(5)') if pg.evaluate("document.getElementById('inEd').style.display==='none'") else None
    pg.mouse.move(r[0]+r[2]*.2,r[1]+r[2]*.4);pg.mouse.down()
    for i in range(20):pg.mouse.move(r[0]+r[2]*(.2+i*.03),r[1]+r[2]*(.4+.1*(i%5)/5))
    pg.mouse.up()
    n=pg.evaluate("QUANTONE.state.strokes.length");chk(n>=1,'trait de percussion tracé (%d traits)'%n)
    pg.evaluate("QUANTONE.setTool('move')")
    ev=pg.evaluate("QUANTONE.score().filter(function(e){return e.kind===4}).length");chk(ev>0,'le trait de percussion produit des coups (%d)'%ev)
    chk(not errs,'aucune erreur page '+str(errs[:2]))
    # aller-retour .qx
    q=pg.evaluate("(function(){var d=new Float32Array(4410);for(var i=0;i<d.length;i++)d[i]=Math.sin(i/9)*.5;QSMP.set(3,d,44100,'test');var x=QXIO.build();return {n:x.samples.length,s:x.preset.strokes.length,q:x.q,len:JSON.stringify(x).length}})()")
    chk(q['q']=='quantix-qx' and q['n']==1 and q['s']>=1,'.qx contient dessin + sample '+str(q))
    r2=pg.evaluate("(function(){var x=JSON.parse(JSON.stringify(QXIO.build()));delete QSMP.SMP[3];QUANTONE.state.strokes.length=0;var ok=QXIO.open(x);return [ok,!!QSMP.SMP[3],QUANTONE.state.strokes.length]})()")
    chk(r2[0] and r2[1] and r2[2]>=1,'.qx rouvert : sample et traits restaurés '+str(r2))
    chk(pg.evaluate("QXIO.open({a:1})")==False,'un .json simple n’est pas pris pour un .qx')
print('RÉSULTAT',sum(res),'/',len(res))
