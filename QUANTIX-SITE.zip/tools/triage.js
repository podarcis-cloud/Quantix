/* triage.js — TRI RAPIDE DES NIVEAUX EXISTANTS (R73), pour traiter les mondes restants au meilleur rythme.
   Pour chaque niveau : 4 000 traits au hasard ; on garde les gagnants, du moins cher au plus cher, et on cherche le premier qui
     (1) est assez long pour la position (coût minimal : 40 / 80 / 120 u), (2) réussit à la ligne droite (P_ligne ≥ 0,85),
     (3) ÉCHOUE quand on retire la mécanique du monde (champ vidé, matière du joueur ramenée à de la structure),
   et on vérifie qu'aucun gagnant plus court que le seuil n'existe.
   Verdict : GARDER (le niveau est bon tel quel : on fixe solution, noyau, encre = 1,3 × coût) · TRIVIAL · DÉCOR (la mécanique ne
   sert pas) · FRAGILE · MULTI (aucun gagnant à un trait). Les GARDER sont écrits dans OUT (format w3apply.py).
   Usage : OUT=triage.json node triage.js 49 50 …                                                        */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const COST={0:1,1:1.9,3:1.7,5:1},MINLEN=p=>p<=3?40:p<=8?80:120,FIELDS=['wind','grav','mag','port','mov','ent','gate','sup','det','tdil'];
let seed=17;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}function g(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
const out=process.env.OUT||'triage.json',res=fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{};
for(const a of process.argv.slice(2)){const idx=+a-1,pos=idx%12+1,L=JSON.parse(JSON.stringify(X.LEVELS[idx]));
 const c={ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup,star:L.star,nd:L.nd,w:L.w,softball:L.softball};for(const f of FIELDS)if(L[f])c[f]=L[f];
 const mats=[0].concat((L.pal||'S').includes('B')?[1]:[]).concat((L.pal||'S').includes('A')?[3]:[]).concat((L.pal||'S').includes('C')?[5]:[]);
 const strip=JSON.parse(JSON.stringify(c));for(const f of FIELDS)if(strip[f])strip[f]=[];strip.w=(strip.w||[]).map(w=>[w[0],w[1],w[2],w[3],[1,3,4].includes(w[4])?0:w[4]]);
 const hasMeca=FIELDS.some(f=>c[f]&&c[f].length)||mats.length>1||(c.w||[]).some(w=>[1,3,4].includes(w[4]))||!!c.softball;
 const wins=[];let t=0;while(t<4000){const m=mats[Math.floor(rnd()*mats.length)],x=rnd()*360,y=rnd()*480,an=rnd()*6.2832,l=8+rnd()*Math.min(230,L.ink/(COST[m]||1)),
  p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(an)*l),Math.round(y+Math.sin(an)*l)]];if(!D.drawable(c,p))continue;t++;const r=LAB.run(idx,c,[{pts:p,mat:m}]);if(r.ok)wins.push({p,m,l,cost:l*(COST[m]||1)});}
 let verdict,info='';
 if(LAB.run(idx,c,[]).ok)verdict='RÉUSSIT SEUL';
 else if(!wins.length)verdict='MULTI';
 else{wins.sort((u,v)=>u.cost-v.cost);const minL=wins[0].l;info='plus court '+Math.round(minL)+' u, '+wins.length+' gagnants';
  if(minL<MINLEN(pos))verdict='TRIVIAL';
  else{let keep=null,anyMeca=false;
   for(const w of wins.slice(0,40)){const needs=!hasMeca||!LAB.run(idx,strip,[{pts:w.p,mat:0}]).ok;if(!needs)continue;anyMeca=true;
    let s=0;for(let k=0;k<24;k++)if(LAB.run(idx,c,[{pts:w.p.map(q=>[q[0]+g()*3,q[1]+g()*3]),mat:w.m}]).ok)s++;if(s/24>=.85){keep=w;keep.pl=s/24;break;}}
   if(keep){const ink=Math.round(Math.max(keep.cost*1.3,keep.cost+25)),c2=Object.assign({},c,{ink});let r=LAB.run(idx,c2,[{pts:keep.p,mat:keep.m}]),star=c.star;
    if(!r.star){const q=r.tr[Math.floor(r.tr.length*.6)];star=[Math.round(q[0]),Math.round(q[1])];c2.star=star;r=LAB.run(idx,c2,[{pts:keep.p,mat:keep.m}]);}
    if(r.ok&&r.star){verdict='GARDER';res[a]={n:L.n,cup:L.cup,ink,star,optsol:[keep.p],optmat:keep.m};info+=' · solution '+Math.round(keep.l)+' u, P_ligne '+Math.round(keep.pl*100)+' %, encre '+ink;}
    else verdict='FRAGILE';}
   else verdict=anyMeca?'FRAGILE':'DÉCOR';}}
 fs.writeFileSync(out,JSON.stringify(res,null,1));
 console.log(`#${a} ${L.n.padEnd(22)} ${verdict.padEnd(12)} ${info}`);}
