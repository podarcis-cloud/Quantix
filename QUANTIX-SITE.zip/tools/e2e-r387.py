# R387 : mondes (aucun par défaut, bascule, mémoire, .qx), forme fermée, centre, bouton Track, ligne bibliothèque
import sys,math
from playwright.sync_api import sync_playwright
U='http://localhost:8765/studio/quantone.html';ok=0;n=0
def T(name,c):
    global ok,n;n+=1;ok+=bool(c);print(('OK   ' if c else 'FAIL ')+name)
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':780},has_touch=True,is_mobile=True);pg=c.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)));pg.goto(U);pg.wait_for_timeout(1500)
    on=lambda:pg.evaluate("[...document.querySelectorAll('#worlds .wb')].map(b=>b.classList.contains('on')?1:0).join('')")
    pre=lambda:pg.evaluate("QXIO.build().preset")
    wb=lambda i:pg.locator('#worlds .wb').nth(i)
    T('aucun monde au départ',on()=='0000' and pre()['amb']==-1)
    wb(1).click();T('clic = sélection',on()=='0100' and pre()['amb']==1)
    wb(1).click();T('reclic = désélection',on()=='0000' and pre()['amb']==-1)
    q=pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.echo=.6;q.preset.k.grain=.3;QXIO.open(q);return QXIO.build().preset.k})()")
    T('réglage utilisateur en mode neutre',abs(q['echo']-.6)<.01)
    wb(2).click();k2=pre()['k'];T('monde appliqué (réglages du monde)',abs(k2['echo']-.6)>.001 or abs(k2['grain']-.3)>.001)
    wb(2).click();k3=pre()['k'];T('retour neutre = réglages de l\'utilisateur',abs(k3['echo']-.6)<.01 and abs(k3['grain']-.3)<.01)
    # mémoire par monde
    wb(0).click();pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.rev=.77;q.preset.amb=0;QXIO.open(q)})()")
    wb(3).click();wb(0).click();T('mémoire du monde 0 conservée',abs(pre()['k']['rev']-.77)<.01)
    # appui long = réglages d'origine
    box=wb(0).bounding_box();pg.mouse.move(box['x']+20,box['y']+20);pg.mouse.down();pg.wait_for_timeout(900);pg.mouse.up();pg.wait_for_timeout(200)
    T('appui long : retour aux réglages d\'origine',abs(pre()['k']['rev']-.77)>.01 and on()=='1000')
    # .qx : sauvegarde / réouverture
    wb(0).click();wb(1).click();pg.evaluate("(()=>{var q=QXIO.build();q.preset.k.breath=.55;QXIO.open(q)})()")
    q=pg.evaluate("QXIO.build()");pg.evaluate("(q)=>{QXIO.open(q)}",q);T('.qx : ambiance et réglages reviennent',on()=='0100' and abs(pre()['k']['breath']-.55)<.01)
    old=pg.evaluate("(()=>{var q=QXIO.build();delete q.preset.amb;delete q.preset.wm;q.preset.world=2;return QXIO.open(q)})()")
    T('ancien .qx (sans amb) s\'ouvre',old is not False and on()=='0010')
    # forme fermée : départ = arrivée exact
    pg.evaluate("window.scrollTo(0,0)");pg.wait_for_timeout(150)
    pg.evaluate("QUANTONE.setTool('draw')")
    cv=pg.locator('#cv').bounding_box();X=lambda u:cv['x']+u*cv['width'];Y=lambda v:cv['y']+v*cv['height']
    ns0=len(pre()['strokes'])
    pg.mouse.move(X(.5),Y(.3));pg.mouse.down();pg.wait_for_timeout(30)
    for i in range(1,41):
        a=-math.pi/2+i*2*math.pi/40;pg.mouse.move(X(.5+.18*math.cos(a)),Y(.5+.2*math.sin(a)),steps=2);pg.wait_for_timeout(8)
    pg.mouse.move(X(.5),Y(.3));pg.mouse.up();pg.wait_for_timeout(400)
    s=pre()['strokes'];T('forme fermée conservée (départ = arrivée)',len(s)==ns0+1 and len(s[-1]['p'])>10)
    # centre : déplacement
    pg.evaluate("QUANTONE.setTool('move')");pg.wait_for_timeout(100)
    cen=pg.evaluate("(()=>{var s=QXIO.build().preset.strokes.slice(-1)[0].p;var sx=0,sy=0;s.forEach(q=>{sx+=q[0];sy+=q[1]});return [sx/s.length,sy/s.length]})()")
    before=pre()['strokes'][-1]['p'][0][:]
    pg.mouse.move(X(cen[0]),Y(cen[1]));pg.mouse.down();pg.mouse.move(X(cen[0]+.1),Y(cen[1]+.1),steps=6);pg.mouse.up();pg.wait_for_timeout(200)
    after=pre()['strokes'][-1]['p'][0]
    T('forme déplacée en la prenant par le centre',abs(after[0]-before[0])>.04)
    # bouton Track : dans la barre fixe, à droite
    r=pg.evaluate("(()=>{var f=document.getElementById('qFloat'),b=document.getElementById('qFileBar');if(!f||f.parentElement!==b)return null;var a=f.getBoundingClientRect(),c=document.getElementById('qFileBtn').getBoundingClientRect();return [Math.abs(a.top+a.height/2-c.top-c.height/2),innerWidth-a.right,getComputedStyle(b).position]})()")
    T('Track aligné à Fichier, à droite, barre sticky',r and r[0]<4 and r[1]<20 and r[2]=='sticky')
    pg2=c.new_page();pg2.add_init_script("localStorage.setItem('qVec','2')");pg2.goto(U);pg2.wait_for_timeout(1500)
    cv=pg2.locator('#cv').bounding_box();X=lambda u:cv['x']+u*cv['width'];Y=lambda v:cv['y']+v*cv['height']
    pg2.mouse.move(X(.5),Y(.3));pg2.mouse.down();pg2.wait_for_timeout(30)
    for i in range(1,41):
        a=-math.pi/2+i*2*math.pi/40;pg2.mouse.move(X(.5+.18*math.cos(a)),Y(.5+.2*math.sin(a)),steps=2);pg2.wait_for_timeout(8)
    pg2.mouse.move(X(.5),Y(.3));pg2.mouse.up();pg2.wait_for_timeout(400)
    s2=pg2.evaluate("QXIO.build().preset.strokes");T('correction vectorielle : forme fermée non écrasée',len(s2)==1 and len(s2[0]['p'])>40)
    pg3=c.new_page();pg3.goto(U);pg3.wait_for_timeout(1500)
    pg3.evaluate("(()=>{var q=QXIO.build();q.preset.strokes=[{l:0,p:[[.1,.5],[.3,.4],[.5,.6],[.8,.5]]}];QXIO.open(q);QLIBSAVE('Test',function(){},'Alpha');})()");pg3.wait_for_timeout(150)
    T('≡＋ : indicateur d\'attente pendant la capture',pg3.evaluate("document.getElementById('qLibBtn').classList.contains('qbusy')"))
    T('aucune erreur de page',not errs)
    if errs:print(errs[:3])
    b.close()
print('RÉSULTAT %d / %d'%(ok,n));sys.exit(0 if ok==n else 1)
