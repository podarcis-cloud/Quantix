/* fixstar.js — replace le noyau : sur la trajectoire EXACTE de la solution optimale (le bouton
   « Voir la solution » le prend donc toujours), et pris par ~40–75 % des exécutions au doigt.
   Usage : node fixstar.js 1 2 … → écrit les nouvelles positions dans assets/js/levels.js */
const DF=require('./difficulty.js'),X=DF.X,fs=require('fs');
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function run(idx,strokes){X.loadLevel(idx);for(const s of strokes)X.S.strokes.push({pts:s.pts,len:plen(s.pts),birth:0,mat:s.mat||0});
 X.qpBuild();X.S.mode='run';const tr=[];for(let f=0;f<1300&&X.S.mode==='run';f++){X.physics();tr.push([X.S.ball.x,X.S.ball.y]);}return {ok:X.S.mode==='success',tr};}
let L=fs.readFileSync('../assets/js/levels.js','utf8');
for(const a of process.argv.slice(2)){const idx=+a-1,LV=X.LEVELS[idx],mat=LV.optmat||0,sol=LV.optsol;if(!sol){console.log('#'+a,'pas de solution optimale');continue;}
 const keep=LV.star;LV.star=null;const ex=run(idx,sol.map(p=>({pts:p,mat})));if(!ex.ok){LV.star=keep;console.log('#'+a,LV.n,'solution exacte en échec — ignoré');continue;}
 const trs=[];DF.setSeed(idx*13+5);for(let k=0;k<50;k++){const g=DF.gesture(LV,sol,DF.EXEC,mat);const r=run(idx,g);if(r.ok)trs.push(r.tr);}
 const z=LV.zone;let best=null;
 for(let i=0;i<ex.tr.length;i+=3){const [sx,sy]=ex.tr[i];
  if(Math.hypot(sx-LV.ball[0],sy-LV.ball[1])<45)continue;if(sx>z[0]-12&&sx<z[0]+z[2]+12&&sy>z[1]-20&&sy<z[1]+z[3]+10)continue;if(sx<8||sx>352||sy<8)continue;
  let h=0;for(const t of trs)if(t.some(q=>Math.hypot(q[0]-sx,q[1]-sy)<20.5))h++;const f=trs.length?h/trs.length:0;
  const sc=Math.abs(f-.55);if(f>=+(process.env.FMIN||.4)&&f<=+(process.env.FMAX||.8)&&(!best||sc<best.sc))best={x:Math.round(sx),y:Math.round(sy),f,sc};}
 if(!best){LV.star=keep;console.log('#'+a,LV.n,'aucune position satisfaisante — noyau inchangé');continue;}
 const m=L.match(new RegExp("\\{wd:\\d+,n:'"+LV.n.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+"'[\\s\\S]*?tip:'[^']*'\\},\\n"));
 const e=m[0].replace(/star:\[[^\]]*\]/,'star:['+best.x+','+best.y+']');L=L.replace(m[0],e);LV.star=[best.x,best.y];
 console.log('#'+a,LV.n.padEnd(22),'noyau',JSON.stringify(keep),'→',JSON.stringify([best.x,best.y]),'| pris par',Math.round(best.f*100)+'% des exécutions au doigt');}
fs.writeFileSync('../assets/js/levels.js',L);
