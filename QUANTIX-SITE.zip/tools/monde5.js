/* monde5.js — non-régression du monde 5 (R69) : la glace est un obstacle, pas d'essai « sans mécanique ».
   Pour chaque niveau muni d'une solution optimale (optsol, matière optmat) :
   - sans trait : ne doit pas réussir ;
   - bouton « Voir la solution optimale » : réussit AVEC le noyau, progression intacte ;
   - même solution, tapis fixes et matière élan ramenés à de la structure : doit échouer
     (le tapis est indispensable — principe d'énergie, handbook §11 sexies). */
require('./load.js');
const X=globalThis.__X,{store}=require('./load.js');const ST=X.S;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
let bad=0,n=0;
for(let i=48;i<60;i++){const LVi=X.LEVELS[i];if(!LVi.optsol){console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'(ancien niveau conservé — à reconcevoir)');continue;}n++;
 X.loadLevel(i);X.qpBuild();ST.mode='run';for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();const seul=ST.mode==='success';
 X.loadLevel(i);const before=JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);ST.mode='fail';
 store['rSolution'].onclick.call(store['rSolution'],{});for(let f=0;f<1300&&ST.mode==='run';f++)X.physics();
 const win=ST.mode==='success',star=ST.gotStar,intact=before===JSON.stringify([ST.best[i],ST.bestMat[i],ST.unlocked]);
 const ok=!seul&&win&&star&&intact;if(!ok)bad++;
 console.log(String(i+1).padStart(2),LVi.n.padEnd(22),'seul:',seul?'RÉUSSIT(!)':'non','| solution:',win?'réussit':'ÉCHOUE','| noyau',star?'oui':'NON','| progression',intact?'intacte':'TOUCHÉE',ok?' OK':' <<<');}
console.log(bad?bad+' problème(s)':'monde 5 : '+n+'/'+n+' OK');process.exitCode=bad?1:0;
