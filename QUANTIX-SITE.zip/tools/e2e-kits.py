# Banque de kits externe (R365) : chargement, menu groupé, application d'un kit, absence de banque, secours hors ligne
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
U='http://localhost:8765/studio/quantone.html'
with sync_playwright() as pw:
    b=pw.chromium.launch();cx=b.new_context(viewport={'width':390,'height':844});er=[]
    pg=cx.new_page();pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto(U);pg.wait_for_timeout(1200);pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(400)
    n=pg.evaluate("[].filter.call(document.querySelectorAll('#dmKit optgroup'),g=>/^(Banque|Bank) ·/.test(g.label)).length")
    chk(n==9,'9 familles de la banque dans le menu (%d)'%n)
    k=pg.evaluate("[].filter.call(document.querySelectorAll('#dmKit optgroup'),g=>/^(Banque|Bank) ·/.test(g.label)).reduce((a,g)=>a+g.children.length,0)")
    chk(k==47,'47 kits disponibles (%d)'%k)
    pg.select_option('#dmKit','Sampler 12 bits');pg.wait_for_timeout(300)
    chk(pg.evaluate("QFX3.inst[4].preset=='Sampler 12 bits'&&QFX3.inst[4].p.grit==.45&&QFX3.inst[4].p.tone==4800"),'un kit de la banque règle bien la batterie')
    chk(pg.evaluate("[].every.call(document.querySelectorAll('#dmKit option'),(o,i,a)=>true)&&document.getElementById('dmKit').value=='Sampler 12 bits'"),'le kit choisi reste sélectionné')
    pg.close()
    # banque absente + secours hors ligne (localStorage du contexte)
    pg=cx.new_page();pg.on('pageerror',lambda e:er.append(str(e)));pg.route('**/KIT_bank.zip',lambda r:r.abort())
    pg.goto(U);pg.wait_for_timeout(1200);pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(400)
    chk(pg.evaluate("document.querySelectorAll('#dmKit optgroup').length")>=10,'hors ligne : la banque revient du cache local')
    pg.close()
    cx2=b.new_context(viewport={'width':390,'height':844});pg=cx2.new_page();pg.on('pageerror',lambda e:er.append(str(e)));pg.route('**/KIT_bank.zip',lambda r:r.abort())
    pg.goto(U);pg.wait_for_timeout(1200);pg.evaluate("QFX3.open(4)");pg.wait_for_timeout(400)
    chk(pg.evaluate("[].some.call(document.querySelectorAll('#dmKit option[disabled]'),o=>/KIT_bank/.test(o.textContent))"),'sans banque : entrée grisée « non installée », kits synthétisés intacts')
    chk(pg.evaluate("document.querySelectorAll('#dmKit optgroup')[0].children.length")==14,'les 14 kits synthétisés restent là')
    chk(not er,'aucune erreur %s'%er[:1])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
