/* galerie-niveaux.js — exporte les niveaux montrés par le banc des rendus (JSON sur la sortie standard). */
require('./load.js');const X=globalThis.__X;const out={};
for(const i of (process.argv[2]||'84,85,86,87,89,95').split(',').map(Number)){X.loadLevel(i);const l=X.LEVELS[i],o={};
 for(const k in l){if(typeof l[k]!=='function'&&!/^_/.test(k))o[k]=l[k];}o.idx=i;o.walls=l.walls;out[i]=o;}
process.stdout.write('\n@@JSON@@'+JSON.stringify(out));
