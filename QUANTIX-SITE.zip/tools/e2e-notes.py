# Édition par note (R377) : appui long sur un trait → fenêtre ; réglages par note appliqués à score()
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/studio/quantone.html');pg.wait_for_timeout(900)
    pg.evaluate("(()=>{const st=QUANTONE.state;st.layer=0;st.strokes=[{layer:0,pts:Array.from({length:30},(_,i)=>[.1+i*.027,.4,i*30])}]})()")
    pg.click('#qdock .dk[data-m="move"]');pg.wait_for_timeout(200)
    bx=pg.locator('#cv').bounding_box()
    x=bx['x']+bx['width']*.35;y=bx['y']+bx['height']*.4
    # sélectionner d'abord par un toucher, puis appui long
    pg.mouse.click(x,y);pg.wait_for_timeout(150)
    pg.mouse.move(x,y);pg.mouse.down();pg.wait_for_timeout(800);pg.mouse.up();pg.wait_for_timeout(250)
    S=pg.evaluate("QNOTE.state()")
    chk(S['open'] and S['n']>=3,'appui long sur un trait : la fenêtre des notes s’ouvre (%s)'%S)
    chk(pg.locator('#qnote .qd button').count()==S['n'],'une pastille numérotée par note')
    # réglage de la note sélectionnée via le curseur
    pg.evaluate("(()=>{const r=document.querySelector('#qnote input[data-nt]');r.value=40;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))})()")
    nt=pg.evaluate("QUANTONE.state.strokes[0].nt")
    chk(nt and list(nt.values())[0].get('vel')==40,'curseur : vélocité de la note mémorisée sur le trait (%s)'%nt)
    # onglet legato et décalage
    pg.click('#qnote .qt [data-t="leg"]');pg.evaluate("(()=>{const r=document.querySelector('#qnote input[data-nt]');r.value=200;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))})()")
    pg.click('#qnote .qt [data-t="off"]');pg.evaluate("(()=>{const r=document.querySelector('#qnote input[data-nt]');r.value=25;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))})()")
    sc=pg.evaluate("Object.keys(QUANTONE.state.strokes[0].nt)[0]")
    # accès à score() : exposé par le banc ?
    has=pg.evaluate("typeof QFX3.score")
    chk(has=='function','score() exposé pour les tests')
    if has=='function':
        evs=pg.evaluate("QFX3.score().filter(e=>e.si===0).map(e=>({sc:e.sc,v:e.v,dur:e.dur,off:e.off||0}))")
        a=[x for x in evs if str(x['sc'])==sc][0];o=[x for x in evs if str(x['sc'])!=sc][0]
        chk(a['v']<o['v']*0.5,'vélocité 40 : la note est plus douce que les autres')
        chk(a['dur']>o['dur']*1.5,'legato 200 % : la note dure plus longtemps')
        chk(abs(a['off']-.25)<1e-6,'décalage +25 % : événement décalé')
    # raccourcis
    pg.click('#qnote [data-q="ramp"]');pg.wait_for_timeout(100)
    pg.click('#qnote [data-q="zero"]');pg.wait_for_timeout(100)
    chk(pg.evaluate("QUANTONE.state.strokes[0].nt")is None,'Remettre à zéro : plus aucun réglage par note')
    pg.click('#qnote .qt [data-t="vol"]');pg.click('#qnote [data-q="vary"]');pg.wait_for_timeout(100)
    chk(pg.evaluate("!!QUANTONE.state.strokes[0].nt"),'Variation : valeurs légèrement différentes')
    # règle Q1 : chaque curseur de la fenêtre a une clé d’automation
    k=pg.evaluate("QAUTO.key(document.querySelector('#qnote input[data-nt]'))")
    chk(k and k[0].startswith('nt:0:'),'curseur de note automatisable (%s)'%k)
    d=pg.evaluate("(k)=>{const d=QAUTO.desc(k);d.set(1);const a=document.querySelector('#qnote input[data-nt]').value;d.set(0);return [a,document.querySelector('#qnote input[data-nt]').value]}",k[0])
    chk(d[0]!=d[1],'automation : set() agit sur la note (%s)'%d)
    # persistance : le code du préréglage garde les réglages par note, et le rechargement les restitue
    c=pg.evaluate("document.getElementById('code').value")
    chk('"nt"' in c,'le préréglage (code) contient les réglages par note')
    pg.evaluate("(()=>{delete QUANTONE.state.strokes[0].nt})()")
    pg.evaluate("document.getElementById('bApply').click()");pg.wait_for_timeout(200)
    chk(pg.evaluate("!!QUANTONE.state.strokes[0].nt"),'le rechargement du préréglage restitue les réglages par note')
    # fermeture
    pg.click('#qnote [data-q="x"]');chk(not pg.evaluate("QNOTE.state().open"),'fermer la fenêtre')
    # un tracé normal ne s’ouvre pas sur un simple déplacement
    pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x,y+60,steps=6);pg.wait_for_timeout(700);pg.mouse.up()
    chk(not pg.evaluate("QNOTE.state().open"),'un glissement déplace le trait sans ouvrir la fenêtre')
    chk(not er,'aucune erreur page %s'%er[:2])
print('RÉSULTAT %d / %d'%(sum(res),len(res)))
