/* hardtune.js — durcir un niveau pour l'ère de l'éditeur (R51).
   Cherche une variante (bassin plus étroit / déplacé, encre réduite) qui fait passer P_hasard sous la cible de sa position,
   en gardant : 0 réussite au hasard sans la mécanique du monde, une solution que l'on réussit à la ligne droite (P_ligne ≥ 0,9),
   un noyau traversé par 15 à 35 % des solutions et pris par la solution retenue.
   Usage : OUT=hard.json node hardtune.js 28 30 …   (écrit les variantes retenues ; w3apply.py les inscrit dans levels.js) */
const D=require('./design.js'),X=D.X,LAB=require('./lab.js'),fs=require('fs');
const COST={0:1,1:1.9,3:1.7,5:1};
const TGT=p=>p<=2?.04:p<=5?.015:p<=9?.005:.002;
let seed=11;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
function gauss(){return Math.sqrt(-2*Math.log(rnd()+1e-12))*Math.cos(6.2832*rnd());}
function matsOf(L){const p=L.pal||'S',m=[0];if(p.includes('B'))m.push(1);if(p.includes('A'))m.push(3);if(p.includes('C'))m.push(5);return m;}
function base(L){return {n:L.n,ink:L.ink,pal:L.pal,ball:L.ball,cup:L.cup.slice(),star:null,nd:L.nd,w:L.w,wind:L.wind,grav:L.grav,mag:L.mag,port:L.port,mov:L.mov,ent:L.ent,gate:L.gate,sup:L.sup,det:L.det,tdil:L.tdil,softball:L.softball};}
function sample(idx,c,N,keep){const mats=matsOf(c),wins=[];let ok=0,tries=0,guard=0;
 while(tries<N&&guard<N*20){guard++;const m=mats[Math.floor(rnd()*mats.length)],maxL=Math.min(230,c.ink/COST[m]);if(maxL<15)continue;
  const x=rnd()*360,y=rnd()*480,a=rnd()*6.2832,len=15+rnd()*(maxL-15),p=[[Math.round(x),Math.round(y)],[Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len)]];
  if(!D.drawable(c,p))continue;tries++;const r=LAB.run(idx,c,[{pts:p,mat:m}]);if(r.ok){ok++;if(keep&&wins.length<keep)wins.push({pts:p,mat:m,tr:r.tr});}}
 return {p:ok/Math.max(1,tries),wins:wins};}
function pLigne(idx,c,w,T){let s=0;for(let k=0;k<T;k++){const p=w.pts.map(q=>[q[0]+gauss()*3,q[1]+gauss()*3]);if(LAB.run(idx,c,[{pts:p,mat:w.mat}]).ok)s++;}return s/T;}
const out=process.env.OUT||'hard.json',res=fs.existsSync(out)?JSON.parse(fs.readFileSync(out)):{};
for(const a of process.argv.slice(2)){const idx=+a-1,L=JSON.parse(JSON.stringify(X.LEVELS[idx])),  /* copie : lab.run réécrit le niveau en mémoire */
 pos=idx%12+1,tgt=TGT(pos),b0=base(L),t0=Date.now();
 const vars=[];for(const kw of [1,.9,.82,.74,.66])for(const ki of [1,.85,.7,.6])for(const dx of [0,-10,10])vars.push({kw,ki,dx});
 let best=null,cands=[];
 for(const v of vars){if(Date.now()-t0>240000)break;
  const c=base(L);c.cup=[Math.max(4,Math.min(356-Math.round(L.cup[2]*v.kw),L.cup[0]+v.dx+Math.round(L.cup[2]*(1-v.kw)/2))),L.cup[1],Math.max(40,Math.round(L.cup[2]*v.kw)),L.cup[3]];c.ink=Math.round(L.ink*v.ki);
  let s=sample(idx,c,1200,60);const dbg=process.env.DBG;if(dbg)console.log('  var',JSON.stringify(v),'p',(s.p*100).toFixed(2));
  if(s.p>tgt&&process.env.ND&&s.wins.length>=6){ /* second levier : une zone interdite posée là où se tracent la plupart des solutions faciles,
      sans toucher la meilleure solution, le départ ni le bassin */
   let keep=null;for(const w of s.wins.slice(0,16)){const pl=pLigne(idx,c,w,12);if(!keep||pl>keep.pl)keep={w,pl};}
   const sol0=keep.w.pts,mid=w=>[(w.pts[0][0]+w.pts[1][0])/2,(w.pts[0][1]+w.pts[1][1])/2];
   const hitR=(r,x,y,m)=>x>r[0]-m&&x<r[0]+r[2]+m&&y>r[1]-m&&y<r[1]+r[3]+m;
   const segHit=(r,p0,p1)=>{for(let k=0;k<=12;k++){const x=p0[0]+(p1[0]-p0[0])*k/12,y=p0[1]+(p1[1]-p0[1])*k/12;if(hitR(r,x,y,8))return true;}return false;};
   let bestR=null;
   for(const sz of [[80,160],[120,120],[60,240],[160,80]])for(let x=0;x+sz[0]<=360;x+=20)for(let y=20;y+sz[1]<=470;y+=20){const r=[x,y,sz[0],sz[1]];
    if(segHit(r,sol0[0],sol0[1])||hitR(r,c.ball[0],c.ball[1],16)||hitR(r,c.cup[0]+c.cup[2]/2,c.cup[1]-20,c.cup[2]/2+10))continue;
    let n=0;for(const w of s.wins){const m=mid(w);if(hitR(r,m[0],m[1],0))n++;}if(!bestR||n>bestR.n)bestR={r,n};}
   if(bestR&&bestR.n>=3){c.nd=(c.nd||[]).concat([bestR.r]);s=sample(idx,c,1200,60);if(dbg)console.log('    + zone interdite',JSON.stringify(bestR.r),'→',(s.p*100).toFixed(2));}}
  if(s.p===0||s.p>tgt)continue;
  const sans=(L.wd===1)?0:sample(idx,LAB.strip(c),900,0).p;   /* monde 1 : pas de mécanique à contourner */if(dbg)console.log('    sans',sans);if(sans>0)continue;
  let sol=null;for(const w of s.wins.slice(0,40)){const pl=pLigne(idx,c,w,+(process.env.PT||20));if(sol&&sol.pl>=.95)break;if(!sol||pl>sol.pl)sol={pts:w.pts,mat:w.mat,pl,tr:w.tr};}
  if(process.env.DBG)console.log('    P_ligne',sol&&sol.pl);if(!sol||sol.pl<.85)continue;
  const st=LAB.star({wins:s.wins},[0,20,360,470]);if(!st)continue;c.star=[st.x,st.y];
  const r=LAB.run(idx,c,[{pts:sol.pts,mat:sol.mat}]);if(!r.ok||!r.star){ /* le noyau doit être sur la trajectoire de la solution */
   const q=sol.tr[Math.floor(sol.tr.length*.45)];c.star=[Math.round(q[0]),Math.round(q[1])];const r2=LAB.run(idx,c,[{pts:sol.pts,mat:sol.mat}]);if(!r2.ok||!r2.star)continue;}
  const score=Math.abs(Math.log(s.p/(tgt*.6)));   /* viser ~60 % de la cible : ni trop facile, ni impossible */
  cands.push({score,P_hasard:s.p,P_ligne:sol.pl,cup:c.cup,ink:c.ink,star:c.star,optsol:[sol.pts],optmat:sol.mat,n:L.n,v,c:c,nd:c.nd||null});}
 /* vérification : la mesure à 1 200 lignes est bruitée — on remesure à 3 000 et on garde la première variante vraiment sous la cible */
 cands.sort((a,b)=>a.score-b.score);
 for(const k of cands){if(Date.now()-t0>270000)break;const ph=sample(idx,k.c,3000,0).p;if(ph>0&&ph<=tgt){k.P_hasard=ph;delete k.c;best=k;break;}}
 if(best){res[a]=best;fs.writeFileSync(out,JSON.stringify(res,null,1));}
 console.log(`#${a} ${L.n.padEnd(20)} cible ≤ ${(tgt*100).toFixed(1)} % → ${best?('P_hasard '+(best.P_hasard*100).toFixed(2)+' % · P_ligne '+Math.round(best.P_ligne*100)+' % · bassin '+JSON.stringify(best.cup)+' · encre '+best.ink):'AUCUNE VARIANTE CONFORME'} (${Math.round((Date.now()-t0)/1000)} s)`);}
