# Quantone dans le jeu : plus de ligne « Fermer · Quantone » du cadre ; Fermer est dans l'en-tête de Quantone/Track (R395)
from playwright.sync_api import sync_playwright
res=[]
def chk(c,m):res.append(bool(c));print(('OK    ' if c else 'ÉCHEC ')+m)
with sync_playwright() as pw:
    b=pw.chromium.launch();pg=b.new_page(viewport={'width':390,'height':844});er=[];pg.on('pageerror',lambda e:er.append(str(e)))
    pg.goto('http://localhost:8765/index.html');pg.evaluate("localStorage.clear()");pg.reload();pg.wait_for_timeout(1500)
    pg.evaluate("QTOV.open()");pg.wait_for_timeout(3500)
    chk(pg.evaluate("getComputedStyle(document.getElementById('qtOv')).display")=='flex','Quantone ouvert dans le jeu')
    chk(pg.evaluate("document.getElementById('qtX').offsetParent===null"),'ligne « Fermer · Quantone » du cadre retirée')
    fr=pg.frame_locator('#qtF')
    y=pg.evaluate("document.getElementById('qtF').getBoundingClientRect().top")
    chk(y<4,'le cadre commence tout en haut (%d px)'%y)
    fr.locator('#qClose').click();pg.wait_for_timeout(300)
    chk(pg.evaluate("getComputedStyle(document.getElementById('qtOv')).display")=='flex','1ʳᵉ touche : demande confirmation, reste ouvert')
    fr.locator('#qClose').click();pg.wait_for_timeout(500)
    chk(pg.evaluate("getComputedStyle(document.getElementById('qtOv')).display")=='none','2ᵉ touche : Quantone se ferme')
    chk(not er,'aucune erreur JS %s'%er)
    print('RÉSULTAT',sum(res),'/',len(res));b.close()
