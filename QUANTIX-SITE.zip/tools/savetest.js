const fs=require('fs');
let DB={}, throwOn=null;
global.localStorage={getItem:k=>k in DB?DB[k]:null,
 setItem:(k,v)=>{if(throwOn==='write')throw new Error('QuotaExceeded');DB[k]=v;},
 removeItem:k=>{delete DB[k];}};
global.window={matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener(){},
 ResizeObserver:null,get localStorage(){if(throwOn==='access')throw new Error('bloqué');return global.localStorage;}};
global.navigator={};global.Audio=function(){return{setAttribute(){},pause(){},play(){return Promise.resolve()},addEventListener(){}};};
global.atob=s=>Buffer.from(s,'base64').toString('binary');
global.Blob=function(){};global.URL={createObjectURL:()=>'blob:x'};
const re=/id="([A-Za-z0-9_-]+)"/g;const html=fs.readFileSync('quantix-R20.html','utf8');
const IDS=new Set();let m;while((m=re.exec(html)))IDS.add(m[1]);
const store={};
function fake(id){const o={id,style:{setProperty(){},display:''},dataset:{},_w:0,_h:0,
 classList:{toggle(){},add(){},remove(){},contains(){return false}},
 setAttribute(){},getAttribute(){return 'false'},addEventListener(){},appendChild(){},
 querySelectorAll(s2){return s2==='i'?[{className:''},{className:''},{className:''}]:[];},
 getBoundingClientRect(){return{left:0,top:0}},firstElementChild:{innerHTML:''},
 insertAdjacentHTML(){},lastElementChild:{lastElementChild:{}},
 getContext(){return new Proxy({},{get:(t,k)=>/create(Radial|Linear)Gradient/.test(k)?()=>({addColorStop(){}}):()=>{}})},
 set innerHTML(v){},get innerHTML(){return ''},set textContent(v){},get textContent(){return ''},
 set width(v){o._w=v},get width(){return o._w},set height(v){o._h=v},get height(){return o._h},
 get clientWidth(){return 360},get clientHeight(){return 480}};return o;}
global.document={getElementById:id=>IDS.has(id)?(store[id]||(store[id]=fake(id))):null,addEventListener(){},documentElement:fake('r')};
global.requestAnimationFrame=()=>{};
let T=[];global.setTimeout=(f,d)=>{T.push(f);return T.length;};global.clearTimeout=()=>{};
require('./testq.js');
const X=global.__X;
console.log('stockage disponible :',X.SAVE.available());
// progression simulée
X.S.best[0]=3;X.S.bestMat[0]=41;X.S.unlocked=7;X.S.seen=5;X.OPT.mus=false;
X.SAVE.write(X.saveState());
console.log('écrit :',Object.keys(DB)[0],'|',DB['quantix.save.v1'].length,'octets');
// remise à zéro puis restauration
X.S.best[0]=0;X.S.unlocked=0;X.S.seen=0;X.OPT.mus=true;
console.log('restauration :',X.restore());
console.log('  étoiles niveau 1 :',X.S.best[0],'| débloqué :',X.S.unlocked,'| vu :',X.S.seen,'| musique :',X.OPT.mus);
// schéma inconnu ignoré
DB['quantix.save.v1']=JSON.stringify({v:99,best:[1,2,3]});
console.log('schéma v99 rejeté :',X.SAVE.read()===null);
// JSON corrompu
DB['quantix.save.v1']='{pas du json';
console.log('JSON corrompu toléré :',X.SAVE.read()===null);
// quota plein
throwOn='write';
console.log('quota plein toléré :',X.SAVE.write({v:1})===false);
