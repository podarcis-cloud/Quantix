require('./load.js');
const X=globalThis.__X;
let DB={}, throwOn=null;
const realLS={getItem:k=>k in DB?DB[k]:null,
 setItem:(k,v)=>{if(throwOn==='write')throw new Error('QuotaExceeded');DB[k]=v;},
 removeItem:k=>{delete DB[k];}};
global.localStorage=realLS;
Object.defineProperty(global.window,'localStorage',{configurable:true,
 get(){if(throwOn==='access')throw new Error('bloqué');return realLS;}});
let T=[];global.setTimeout=(f,d)=>{T.push(f);return T.length;};global.clearTimeout=()=>{};
console.log('stockage disponible :',X.SAVE.available());
// progression simulée
X.S.best[0]=3;X.S.bestMat[0]=41;X.S.unlocked=7;X.S.seen=5;X.OPT.mus=false;
X.SAVE.write(X.saveState());
console.log('écrit :',Object.keys(DB)[0],'|',DB['quantix.save.v1'].length,'octets');
// remise à zéro puis restauration
X.S.best[0]=0;X.S.unlocked=0;X.S.seen=0;X.OPT.mus=true;
console.log('restauration :',X.restore());
console.log('  étoiles niveau 1 :',X.S.best[0],'| débloqué :',X.S.unlocked,'| vu :',X.S.seen,'| musique :',X.OPT.mus);
// schéma inconnu ignoré
DB['quantix.save.v1']=JSON.stringify({v:99,best:[1,2,3]});
console.log('schéma v99 rejeté :',X.SAVE.read()===null);
// JSON corrompu
DB['quantix.save.v1']='{pas du json';
console.log('JSON corrompu toléré :',X.SAVE.read()===null);
// quota plein
throwOn='write';
console.log('quota plein toléré :',X.SAVE.write({v:1})===false);
