#!/usr/bin/env python3
"""rapport-evenements.py — rapport sur les parcours joueurs (décrochage, progression, logique de résolution, outils, qualité des niveaux).
Sources (combinables) :
  --export FICHIER.json   export du Worker (/export?key=…) : {batches:[{pid,sid,ev:[…]}],players:[…]}
  --events DOSSIER        documents de la collection `evenements_beta` (ArtifactData out_dir) : {st,ev:[…]}
  --runs   DOSSIER        documents de `parcours_beta` (anciens essais, 1 doc = 1 essai) → convertis en événements APPROXIMATIFS (sessions
                          reconstruites par écart > 30 min ; pas de contacts ni de temps réel de préparation).
  --out FICHIER.md        écrit le rapport (sinon stdout)
Événement : {s session, k n°, t ms, y type, l niveau (1-based), d données}. Types : ss se sr lv vw ck tm sk ed la ct bx rs ab er."""
import sys,re,json,glob,math,argparse,collections,statistics as ST
ap=argparse.ArgumentParser();ap.add_argument('--export');ap.add_argument('--events');ap.add_argument('--runs');ap.add_argument('--out');A=ap.parse_args()
# ---------- niveaux (nom, encre max, solution de référence) ----------
LV='/home/claude/q2/assets/js/levels.js'
src=open(LV,encoding='utf-8').read();ents=[m.start() for m in re.finditer(r'^\{wd:',src,re.M)];META={}
def plen(p):return sum(math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]) for i in range(1,len(p)))
for k,a in enumerate(ents):
    e=src[a:ents[k+1] if k+1<len(ents) else len(src)];nm=re.search(r"n:'((?:[^'\\]|\\.)*)'",e);ink=re.search(r"\bink:(\d+)",e);o=re.search(r"optsol:(\[\[\[.*?\]\]\]),optmat:(\d+)",e);ref=None
    if o:
        try:ref={'p':json.loads(o.group(1)),'mat':int(o.group(2))}
        except Exception:pass
    META[k+1]={'n':nm.group(1) if nm else '','ink':int(ink.group(1)) if ink else None,'ref':ref,'wd':int(re.search(r'wd:(\d+)',e).group(1))}
NL=len(META)
def reflen(l):
    r=META.get(l,{}).get('ref');return sum(plen(q) for q in r['p']) if r else None
# ---------- chargement ----------
EV=[];PL={};SRC=[]
def add(pid,sid,ev,extra=None):
    for e in ev:
        EV.append({'p':pid,'s':sid,'k':e.get('k',0),'t':e.get('t',0),'y':e.get('y'),'l':e.get('l',0),'d':e.get('d')})
if A.export:
    j=json.load(open(A.export));SRC.append('export serveur')
    for b in j.get('batches',[]):add(b['pid'],b['sid'],b['ev'])
    for p in j.get('players',[]):PL[p['pid']]=p
if A.events:
    SRC.append('base Aperçu (evenements_beta)')
    for f in glob.glob(A.events.rstrip('/')+'/*.json'):
        d=json.load(open(f));add(d['st']['pid'],d['ev'][0]['s'],d['ev'])
if A.runs:
    SRC.append('anciens essais (approximation)');R=[json.load(open(f)) for f in glob.glob(A.runs.rstrip('/')+'/*.json')];by=collections.defaultdict(list)
    for r in R:by[r['pid']].append(r)
    for pid,rs in by.items():
        rs.sort(key=lambda r:(r['t'],r['n']));sess=0;prev=None;k=0;t0=None
        for r in rs:
            from datetime import datetime
            ts=datetime.strptime(r['t'][:16],'%Y-%m-%dT%H:%M').timestamp()
            if prev is None or ts-prev>1800:sess+=1;k=0;t0=ts;sid='%08x'%(abs(hash(pid+str(sess)))%(16**8));ev=[];EV.append({'p':pid,'s':sid,'k':0,'t':0,'y':'ss','l':0,'d':{'gap':None,'approx':1}})
            t=int((ts-t0)*1000);l=r['lvl'];tp=r.get('td',0)
            if not any(x['p']==pid and x['s']==sid and x['y']=='lv' and x['l']==l for x in EV[-40:]):EV.append({'p':pid,'s':sid,'k':k,'t':t,'y':'lv','l':l,'d':{'ink':r['mx']}});k+=1
            for i,s in enumerate(r['s']):EV.append({'p':pid,'s':sid,'k':k,'t':t,'y':'sk','l':l,'d':{'m':s['m'],'len':s['l'],'p':s['p'],'i':i}});k+=1
            EV.append({'p':pid,'s':sid,'k':k,'t':t,'y':'la','l':l,'d':{'n':r['n'],'tp':tp,'ink':r['ink'],'mx':r['mx'],'ns':len(r['s']),'mat':[s['m'] for s in r['s']]}});k+=1
            bp=r.get('bp') or []
            EV.append({'p':pid,'s':sid,'k':k,'t':t+1000,'y':'rs','l':l,'d':{'r':r['r'] if r['r']!='abandon' else 'ab','n':r['n'],'f':r.get('f',0),'ink':r.get('ink2',r['ink']),'x':bp[-2] if bp else None,'y':bp[-1] if bp else None,'ns':len(r['s']),'star':r.get('star',0),'bp':bp}});k+=1
            prev=ts
if not EV:sys.exit('Aucune donnée : donne --export, --events ou --runs.')
# dédoublonnage (pid,s,k,y)
seen=set();E=[]
for e in sorted(EV,key=lambda e:(e['p'],e['s'],e['k'],e['t'])):
    key=(e['p'],e['s'],e['k'],e['y'])
    if key in seen:continue
    seen.add(key);E.append(e)
SESS=collections.OrderedDict()
for e in E:SESS.setdefault((e['p'],e['s']),[]).append(e)
players=sorted({e['p'] for e in E});NP=len(players)
out=[]
def P(*a):out.append(' '.join(str(x) for x in a))
def med(a):return ST.median(a) if a else None
def pct(a,b):return '%d %%'%round(100*a/b) if b else '–'
def small(n):return ' ⚠ n=%d (indicatif)'%n if n<3 else ''
# ---------- structure : essais ----------
TR=[]   # un essai = {p,s,l,n,sk:[strokes courants],tp,mx,ink,r,x,y,ed:{},tools:[]}
LVP=collections.defaultdict(lambda:collections.defaultdict(list))   # niveau -> joueur -> essais
ENT=collections.defaultdict(set);SESL=collections.defaultdict(set);TOOLM=collections.Counter();TOOLE=collections.defaultdict(collections.Counter);ERR=collections.Counter()
SUM=[]
for (pid,sid),ev in SESS.items():
    cur=[];edc=collections.Counter();lvl=0;tm=[];la=None;lvlist=[];info={'p':pid,'s':sid,'act':None,'dur':None,'why':None,'gap':None,'n':None,'approx':False,'lvs':[],'last':0}
    for e in ev:
        y=e['y'];d=e['d'] or {}
        if y=='ss':info['gap']=d.get('gap');info['n']=d.get('n');info['approx']=bool(d.get('approx'));info['w']=d.get('w');info['b']=d.get('b')
        elif y=='se':info['act']=d.get('act');info['dur']=d.get('dur');info['why']=d.get('why')
        elif y=='er':ERR[(d.get('m') or '')[:60]]+=1
        elif y=='lv':
            lvl=e['l'];cur=[];edc=collections.Counter();tm=[];ENT[lvl].add(pid);SESL[lvl].add((pid,sid));info['lvs'].append(lvl);info['last']=lvl
        elif y=='tm':TOOLM[d.get('m')]+=1;tm.append(d.get('m'))
        elif y=='sk':cur.append(d)
        elif y=='ed':
            o=d.get('o');edc[o]+=1;TOOLE[e['l']][o]+=1
            if o=='und' and cur:cur.pop()
            elif o=='clr':cur=[]
        elif y=='la':la={'p':pid,'s':sid,'l':e['l'] or lvl,'n':d.get('n'),'tp':d.get('tp'),'mx':d.get('mx'),'ink':d.get('ink'),'ns':d.get('ns'),'sk':[{'m':x['m'],'p':x['p'],'len':x.get('l',0)} for x in (d.get('g') or [])] or list(cur),'g':bool(d.get('g')),'ed':dict(edc),'tm':list(tm),'r':None}
        elif y in('rs','ab') and la:
            la['r']='ab' if y=='ab' else d.get('r');la['x']=d.get('x');la['y']=d.get('y');la['f']=d.get('f');la['ink_end']=d.get('ink');la['bp']=d.get('bp')
            TR.append(la);LVP[la['l']][pid].append(la);la=None;edc=collections.Counter();tm=[]
    SUM.append(info)
# ---------- 1. vue d'ensemble ----------
P('# Rapport parcours joueurs');P('')
P('Sources :',', '.join(SRC),'· %d joueur(s), %d session(s), %d essai(s), %d événements'%(NP,len(SESS),len(TR),len(E)));
if any(s['approx'] for s in SUM):P('⚠ Données « anciens essais » : sessions reconstruites (écart > 30 min), pas de temps de préparation réel ni de contacts.')
if NP<3:P('⚠ **Moins de 3 joueurs : ne rien décider définitivement** ; les chiffres décrivent un testeur expert (borne basse de difficulté).')
act=[s['act'] for s in SUM if s['act'] is not None];ns=collections.Counter(s['p'] for s in SUM)
P('');P('## 1. Joueurs et sessions')
P('- sessions par joueur : médiane',med(list(ns.values())),'· max',max(ns.values()))
if act:P('- durée active par session : médiane %d s, max %d s (%d sessions mesurées)'%(med(act),max(act),len(act)))
gaps=[s['gap'] for s in SUM if s['gap'] is not None];
if gaps:P('- retour : %d reprises mesurées, délai médian %s h ; retour ≥ 20 h : %d'%(len(gaps),med(gaps),sum(1 for g in gaps if g>=20)))
cc=collections.Counter(PL[p].get('country') for p in players if p in PL)
if cc:P('- pays :',dict(cc))
bl=collections.Counter(s.get('b') for s in SUM if s.get('b'));
if bl:P('- versions :',dict(bl))
if ERR:P('- erreurs de script :',dict(ERR.most_common(5)))
# ---------- 2. progression et décrochage ----------
P('');P('## 2. Progression et décrochage')
done=collections.defaultdict(set);seenl=collections.defaultdict(set)
for l,pp in LVP.items():
    for pid,ts in pp.items():
        seenl[pid].add(l)
        if any(t['r']=='ok' for t in ts):done[pid].add(l)
nd=[len(done[p]) for p in players];mx=[max(done[p]) if done[p] else 0 for p in players]
P('- niveaux terminés par joueur : moyenne %.1f, médiane %s, max %s ; plus haut niveau terminé : médiane %s'%(ST.mean(nd),med(nd),max(nd),med(mx)))
lastlv=collections.Counter()
for p in players:
    ss=[s for s in SUM if s['p']==p];
    if ss:
        lastlv[max(ss,key=lambda s:(s['n'] or 0,s['s']))['last']]+=1
P('- **dernier niveau vu (où le joueur s\'est arrêté)** :',dict(sorted(lastlv.items())) if lastlv else '–')
P('');P('| niv | nom | joueurs | terminé | échecs/essai | 1er essai réussi | essais médian | abandons |');P('|--|--|--|--|--|--|--|--|')
rows=[]
for l in sorted(LVP):
    pp=LVP[l];nplay=len(pp);nok=sum(1 for p in pp if any(t['r']=='ok' for t in pp[p]))
    alltr=[t for ts in pp.values() for t in ts];fails=sum(1 for t in alltr if t['r'] not in('ok','ab'));ab=sum(1 for t in alltr if t['r']=='ab')
    ft=sum(1 for ts in pp.values() if ts[0]['r']=='ok')
    ttok=[next(i+1 for i,t in enumerate(ts) if t['r']=='ok') for ts in pp.values() if any(t['r']=='ok' for t in ts)]
    P('| %d | %s | %d | %s | %d/%d | %s | %s | %d |'%(l,META.get(l,{}).get('n','')[:18],nplay,pct(nok,nplay),fails,len(alltr),pct(ft,nplay),(med(ttok) if ttok else '–'),ab))
    rows.append((l,nplay,nok,ft,ttok,alltr))
# ---------- 3. qualité par niveau ----------
P('');P('## 3. Qualité des niveaux (signaux)')
flags=[]
for l,nplay,nok,ft,ttok,alltr in rows:
    m=META.get(l,{});ok=[t for t in alltr if t['r']=='ok'];rl=reflen(l);F=[]
    ratios=[(t.get('ink_end') if t.get('ink_end') is not None else t['ink'])/t['mx'] for t in ok if t.get('mx')]
    if ratios:
        r=med(ratios)
        if r<.45:F.append('encre généreuse (%d %% de l\'encre utilisée en médiane)'%round(100*r))
        if r>=.95:F.append('encre très serrée (%d %%)'%round(100*r))
    if rl and ok:
        cheap=[t for t in ok if (t.get('ink_end') if t.get('ink_end') is not None else t['ink'])<0.6*rl]
        if cheap:F.append('réussite avec encre << référence (%d/%d) : contournement ? référence non optimale ?'%(len(cheap),len(ok)))
    if nplay>=1 and ttok and med(ttok)>=6:F.append('difficile : %s essais médians avant réussite'%med(ttok))
    if nplay>=3 and ft/nplay<.25:F.append('1er essai réussi seulement %s'%pct(ft,nplay))
    cause=collections.Counter(t['r'] for t in alltr if t['r'] not in('ok','ab'))
    if sum(cause.values())>=3:F.append('échecs récurrents : %s'%dict(cause))
    tps=[t['tp'] for t in alltr if t.get('tp')];
    if tps and med(tps)>60000:F.append('lecture longue (préparation médiane %d s)'%(med(tps)/1000))
    if nplay<nok+0 :pass
    if F:flags.append((l,nplay,F))
for l,nplay,F in flags:
    P('- **N%d %s**%s :'%(l,META.get(l,{}).get('n',''),small(nplay)),' ; '.join(F))
if not flags:P('- aucun signal')
# ---------- 4. sorties du terrain ----------
P('');P('## 4. Où la particule sort (échecs « out »)')
for l,nplay,nok,ft,ttok,alltr in rows:
    o=[(t['x'],t['y']) for t in alltr if t['r']=='out' and t.get('x') is not None]
    if len(o)>=3:
        g=collections.Counter((int(max(0,min(359,x))//60)*60,int(max(0,min(479,y))//60)*60) for x,y in o)
        P('- N%d : %d sorties ; zones (case 60 px, x,y) : %s'%(l,len(o),', '.join('(%d,%d)×%d'%(a,b,n) for (a,b),n in g.most_common(3))))
# ---------- 5. logique de résolution ----------
P('');P('## 5. Logique de résolution (familles de solutions réussies)')
def sig(sk):
    if not sk:return None
    s0=sk[0];p=s0.get('p') or []
    if len(p)<4:return None
    dx,dy=p[-2]-p[0],p[-1]-p[1];ang=int(((math.degrees(math.atan2(dy,dx))+360+22.5)%360)//45);return (len(sk),tuple(sorted({s.get('m',0) for s in sk})),'%d,%d'%(p[0]//60*60,p[1]//60*60),ang)
def refsig(l):
    r=META.get(l,{}).get('ref')
    if not r:return None
    q=r['p'][0];dx,dy=q[-1][0]-q[0][0],q[-1][1]-q[0][1];return (len(r['p']),(r['mat'],),'%d,%d'%(q[0][0]//60*60,q[0][1]//60*60),int(((math.degrees(math.atan2(dy,dx))+360+22.5)%360)//45))
ANG=['→','↘','↓','↙','←','↖','↑','↗']
for l,nplay,nok,ft,ttok,alltr in rows:
    ok=[t for t in alltr if t['r']=='ok' and sig(t['sk'])];
    if not ok:continue
    fam=collections.Counter(sig(t['sk']) for t in ok);rs=refsig(l);top=fam.most_common(2)
    fmt=lambda s:'%d trait(s) mat%s départ(%s) %s'%(s[0],list(s[1]),s[2],ANG[s[3]])
    line='- N%d : '%l+' ; '.join('%s ×%d'%(fmt(s),n) for s,n in top)
    if rs:
        inref=sum(n for s,n in fam.items() if s[2]==rs[2] and s[3]==rs[3]);line+=' · proche de la référence (%s) : %d/%d'%(fmt(rs),inref,len(ok))
        if inref==0 and len(ok)>=2:line+=' ⚠ aucune solution du type prévu'
    # édition avant réussite
    eds=collections.Counter()
    for t in ok:eds.update(t['ed'])
    if eds:line+=' · outils avant réussite %s'%dict(eds)
    P(line)
# distance au tracé de référence (géométrie finale seulement)
def pts2(p):return [(p[i],p[i+1]) for i in range(0,len(p)-1,2)]
def dseg(q,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];L=dx*dx+dy*dy;t=0 if not L else max(0,min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dy)/L));return math.hypot(q[0]-a[0]-t*dx,q[1]-a[1]-t*dy)
def dist_ref(l,sk):
    r=META.get(l,{}).get('ref')
    if not r:return None
    S_=[pts2(x['p']) for x in sk if x.get('p')];segs=[(a[i],a[i+1]) for a in S_ for i in range(len(a)-1)]
    if not segs:return None
    out=[]
    for poly in r['p']:
        for i in range(len(poly)-1):
            for k in range(5):
                q=(poly[i][0]+(poly[i+1][0]-poly[i][0])*k/5,poly[i][1]+(poly[i+1][1]-poly[i][1])*k/5);out.append(min(dseg(q,a,b) for a,b in segs))
    return ST.mean(out)
DR=[]
for l,nplay,nok,ft,ttok,alltr in rows:
    ds=[dist_ref(l,t['sk']) for t in alltr if t['r']=='ok' and t.get('g')]
    ds=[d for d in ds if d is not None]
    if ds:DR.append('N%d : %d px (n=%d)'%(l,med(ds),len(ds)))
if DR:P('');P('- distance moyenne tracé final ↔ solution de référence (px, 0 = identique) : '+' ; '.join(DR))
# apprentissage : essai n → n+1 (changements)
chg=collections.Counter();tot=0
for l,pp in LVP.items():
    for pid,ts in pp.items():
        for a,b in zip(ts,ts[1:]):
            if a['r'] in('ok','ab'):continue
            tot+=1;sa,sb=sig(a['sk']),sig(b['sk'])
            if sa==sb and a['ns']==b['ns']:chg['mêmes traits (rejeu ou micro-réglage)']+=1
            elif b['ns']>a['ns']:chg['trait ajouté']+=1
            elif b['ns']<a['ns']:chg['trait retiré']+=1
            else:chg['trait déplacé/changé']+=1
if tot:P('');P('- après un échec, l\'essai suivant (%d cas) : %s'%(tot,', '.join('%s %s'%(pct(v,tot),k) for k,v in chg.most_common())))
# ---------- 6. outils ----------
P('');P('## 6. Outils d\'édition')
if TOOLM or any(TOOLE.values()):
    P('- modes choisis :',dict(TOOLM) or '–')
    te=collections.Counter()
    for l,c in TOOLE.items():te.update(c)
    P('- opérations :',dict(te))
    pu=[l for l,c in TOOLE.items() if any(k in c for k in('del','mov','scl'))]
    P('- niveaux où gomme/déplacer/échelle servent :',sorted(pu) or 'aucun')
else:P('- aucune donnée d\'outils (anciens essais ou jeu sans journal).')
P('');P('---');P('Limites : voir `docs/PARCOURS_BETA.md`. Décision définitive seulement avec ≥ 3 joueurs ; les débutants mesurent la vraie difficulté.')
txt='\n'.join(out)
open(A.out,'w',encoding='utf-8').write(txt) if A.out else print(txt)
