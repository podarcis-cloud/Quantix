/* tolerance.js — robustesse au doigt : on perturbe chaque extrémité de trait de ±J px
   (grille 3×3 par point) et on mesure la part des variantes qui réussissent encore.
   Une solution de référence doit tolérer ce tremblement ; sinon le niveau exige
   une précision artificielle (protocole maître §2). */
require('./load.js');
const X=globalThis.__X;
function plen(p){let d=0;for(let i=1;i<p.length;i++)d+=Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]);return d;}
function run(i,s){X.loadLevel(i);for(const p of s)X.S.strokes.push({pts:p,len:plen(p),birth:0,mat:0});
 X.qpBuild();X.S.mode='run';for(let f=0;f<900&&X.S.mode==='run';f++)X.physics();return X.S.mode==='success';}
module.exports=function(i,s,J){J=J||4;const off=[-J,0,J];let ok=0,n=0;
 // perturbe un point à la fois (toutes les combinaisons seraient trop coûteuses sur 3 traits)
 s.forEach((p,si)=>p.forEach((pt,pi)=>{for(const dx of off)for(const dy of off){
   const s2=s.map((q,qi)=>q.map((r,ri)=>(qi===si&&ri===pi)?[r[0]+dx,r[1]+dy]:r));n++;if(run(i,s2))ok++;}}));
 return ok/n;};
