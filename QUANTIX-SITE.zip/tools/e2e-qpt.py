# R403 — formats .qpt (un pattern) et .qxp v2 (une track) : aller-retour, références « pool: », .qxp réel de Simon, import des anciens préréglages
# Usage : python3 e2e-qpt.py [port] [chemin .qxp]   (défaut 8765 ; .qxp réel de Simon)
import sys, os, json, base64, time, tempfile, numpy as np
from playwright.sync_api import sync_playwright
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
QXP = sys.argv[2] if len(sys.argv) > 2 else '/tmp/claude-0/agent-qpt/fidelite/ref/simon.qxp'
U = 'http://localhost:%d/studio/' % PORT
res = []
def chk(c, m): res.append(bool(c)); print(('OK    ' if c else 'ÉCHEC ') + m, flush=True)
TMP = tempfile.mkdtemp(prefix='qpt-')
Q = json.load(open(QXP)); BL = {b['name']: b for b in Q['blocks'] if b['kind'] == 'qx'}
ENC = "()=>{window.__enc=function(b){var out=[];for(var c=0;c<Math.min(2,b.numberOfChannels);c++){var d=b.getChannelData(c),u=new Int16Array(d.length),i,v;for(i=0;i<d.length;i++){v=d[i];u[i]=v<-1?-32768:v>1?32767:Math.round(v*32767);}var s='',x=new Uint8Array(u.buffer);for(i=0;i<x.length;i+=8192)s+=String.fromCharCode.apply(null,x.subarray(i,i+8192));out.push(btoa(s));}return {sr:b.sampleRate,ch:out};}}"
def dec(o):
    ch = [np.frombuffer(base64.b64decode(s), dtype=np.int16).astype(np.float32) / 32767 for s in o['ch']]
    return np.stack(ch * (2 // len(ch))), o['sr']
def env(x, sr, w=.05):
    m = x.mean(0); k = int(sr * w); n = len(m) // k; return np.sqrt((m[:n * k].reshape(n, k) ** 2).mean(1) + 1e-12)
def spec(x, sr, nfft=4096):
    m = x.mean(0); n = len(m) // nfft; S = np.abs(np.fft.rfft(m[:n * nfft].reshape(n, nfft) * np.hanning(nfft), axis=1)).mean(0); f = np.fft.rfftfreq(nfft, 1 / sr)
    e = 40 * 2 ** (np.arange(0, 28) / 3); return np.array([20 * np.log10(S[(f >= a) & (f < z)].mean() + 1e-9) for a, z in zip(e[:-1], e[1:])])
def same_sound(A, B, sr, tag, skip=3.):
    n = min(A.shape[1], B.shape[1]); a0 = int(skip * sr); A, B = A[:, a0:n], B[:, a0:n]
    r = float(np.corrcoef(env(A, sr), env(B, sr))[0, 1]); sA, sB = spec(A, sr), spec(B, sr); mk = sA >= sA.max() - 60
    ds = float(np.abs((sB - sB[mk].mean()) - (sA - sA[mk].mean()))[mk].max()); lv = float(20 * np.log10(np.sqrt((B ** 2).mean()) / np.sqrt((A ** 2).mean())))
    chk(r >= .98 and ds <= 2 and abs(lv) <= 1, '%s : même son (enveloppe r=%.4f ≥ 0,98 ; spectre ≤ %.1f dB ≤ 2 ; niveau %+.2f dB)' % (tag, r, ds, lv))
def dl(pg, sel, open_btn):
    pg.click(open_btn); pg.wait_for_timeout(300)
    with pg.expect_download(timeout=120000) as d: pg.click(sel)
    p = os.path.join(TMP, d.value.suggested_filename); d.value.save_as(p); return p, d.value.suggested_filename
with sync_playwright() as pw:
    br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); er = []
    # ── A. Pattern : .qx → .qpt → Pattern ──
    ctx = br.new_context(viewport={'width': 390, 'height': 844}, accept_downloads=True); pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append(str(e)))
    pg.goto(U + 'quantone.html'); pg.wait_for_timeout(1500); pg.evaluate(ENC)
    chk(pg.evaluate("JSON.stringify(QSMP.pooln)===JSON.stringify(QPT.POOLN)"), 'table des sons intégrés identique dans qpt.js et Pattern')
    J = BL['Boucle acide melo']['qx']
    pg.evaluate("(J)=>QXIO.open(J)", J); pg.wait_for_timeout(300)
    REF = dec(pg.evaluate("()=>new Promise(r=>{QEXPORT.opt.auto=false;QEXPORT.opt.loops=2;QEXPORT.render(b=>r(__enc(b)))})"))
    A = pg.evaluate("QXIO.build()")   # après le rendu (le rendu laisse des arrondis flottants dans les réglages automatisés)
    LC = pg.evaluate("QUANTONE.loopLen()*QEXPORT.cycle()")
    p, nm = dl(pg, '#qfFile', '#qFileBtn')
    F = json.load(open(p)); sz = os.path.getsize(p)
    chk(nm.endswith('.qpt') and F.get('q') == 'quantone-pattern' and F.get('v') == 1, 'Exporter ▸ Fichier pattern : un .qpt (%s)' % nm)
    chk(all(s.get('ref', '').startswith('pool:') and 'pcm' not in s for s in F['samples']) and len(F['samples']) == 8, 'les 8 sons intégrés sont désignés par référence (%s)' % ', '.join(s.get('ref', '?') for s in F['samples'][:3]))
    chk('au' not in F, 'sans « avec le son » : pas de son dans le fichier')
    chk(sz < 20000, 'taille du .qpt : %d o (au lieu de %d o pour le .qx)' % (sz, len(json.dumps(J))))
    print('      .qpt Boucle acide melo : %d o' % sz)
    chk(F['pat'] == A['preset'], 'le .qpt garde le préréglage tel quel (pat = preset())')
    # on change d'état puis on rouvre le fichier par l'interface
    pg.evaluate("(J)=>QXIO.open(J)", BL['Boucle 8']['qx']); pg.wait_for_timeout(300)
    pg.set_input_files('#file', p); pg.wait_for_function("JSON.stringify(QXIO.build().preset)!==%s" % json.dumps(json.dumps(BL['Boucle 8']['qx']['preset'])), timeout=20000); pg.wait_for_timeout(800)
    B = pg.evaluate("QXIO.build()")
    chk(B['preset'] == A['preset'], 'Ouvrir un fichier… : préréglage identique après l’aller-retour')
    chk([(s['slot'], s['name'], s['sr'], len(s['pcm'])) for s in B['samples']] == [(s['slot'], s['name'], s['sr'], len(s['pcm'])) for s in A['samples']], 'mêmes échantillons (emplacement, nom, fréquence, longueur)')
    chk(all((s.get('src') or '').startswith('pool:') for s in B['samples']), 'l’origine « pool: » est retenue (réexport sans nouvelle vérification)')
    err = pg.evaluate("""(a)=>{const [A,B]=a;return A.map((s,i)=>{const x=atob(s.pcm),y=atob(B[i].pcm);let e=0,t=0;for(let k=0;k<x.length;k+=2){let u=x.charCodeAt(k)|(x.charCodeAt(k+1)<<8),v=y.charCodeAt(k)|(y.charCodeAt(k+1)<<8);if(u>32767)u-=65536;if(v>32767)v-=65536;e+=(u-v)*(u-v);t+=u*u;}return 10*Math.log10(e/t+1e-12)})}""", [A['samples'], B['samples']])
    chk(max(err) < -25, 'sons rechargés recalés sur l’original (écart max %.1f dB ; décodeur MP3 de Safari ≠ Chromium)' % max(err))
    OUT = dec(pg.evaluate("()=>new Promise(r=>{QEXPORT.opt.auto=false;QEXPORT.opt.loops=2;QEXPORT.render(b=>r(__enc(b)))})"))
    same_sound(REF[0], OUT[0], REF[1], 'Pattern avant / après .qpt', skip=.5)
    # adaptateurs de lecture permanents : .qx (ancien format) par Ouvrir un fichier… ; une track (.qxp) dans Pattern → message
    pq = os.path.join(TMP, 'ancien.qx'); json.dump(BL['Boucle 8']['qx'], open(pq, 'w'))
    pg.set_input_files('#file', pq); pg.wait_for_timeout(1200)
    chk(pg.evaluate("QXIO.build().preset") == BL['Boucle 8']['qx']['preset'] or pg.evaluate("JSON.stringify(QXIO.build().preset.strokes)") == json.dumps(BL['Boucle 8']['qx']['preset']['strokes'], separators=(',', ':')), 'Pattern lit toujours un .qx')
    pg.set_input_files('#file', QXP); pg.wait_for_timeout(1500)
    m = pg.evaluate("document.getElementById('toast').textContent")
    chk('Track' in m, 'Pattern ▸ Ouvrir une track (.qxp) : message « ouvre-la dans Track » (%s)' % m[:50])
    pg.evaluate("(J)=>QXIO.open(J)", J); pg.wait_for_timeout(300)
    # avec le son
    pg.click('#qFileBtn'); pg.wait_for_timeout(300); pg.check('#qfSnd'); pg.wait_for_timeout(100)
    with pg.expect_download(timeout=120000) as d: pg.click('#qfFile')
    p2 = os.path.join(TMP, 'avec-son.qpt'); d.value.save_as(p2); F2 = json.load(open(p2))
    chk(F2.get('au') and F2['au'].get('l') and abs(F2['au']['len'] - LC) < .01, '« avec le son » : son du pattern joint (%.2f s, %d o)' % (F2.get('au', {}).get('len', 0), os.path.getsize(p2)))
    print('      .qpt avec le son : %d o' % os.path.getsize(p2))
    # hors ligne : sons intégrés introuvables → message clair, motif chargé quand même
    pg3 = ctx.new_page(); pg3.on('pageerror', lambda e: er.append(str(e)))
    pg3.route('**/assets/audio/pool/**', lambda r: r.abort()); pg3.goto(U + 'quantone.html'); pg3.wait_for_timeout(1300)
    pg3.evaluate("()=>{window.__T=[];var t=window.toast;}")
    pg3.set_input_files('#file', p); pg3.wait_for_timeout(1500)
    msg = pg3.evaluate("[...document.querySelectorAll('.toast,#toast')].map(e=>e.textContent).join(' | ')")
    chk('introuvables' in msg or 'not found' in msg, 'hors ligne : message « sons intégrés introuvables » (%s)' % msg[:70])
    chk(pg3.evaluate("JSON.stringify(QXIO.build().preset)") == json.dumps(A['preset'], separators=(',', ':'), ensure_ascii=False) or pg3.evaluate("QUANTONE.state.strokes.length") == len(A['preset']['strokes']), 'hors ligne : le motif s’ouvre quand même')
    pg3.close()
    # Track lit le .qpt avec le son : élément de bibliothèque avec son (pas de re-rendu)
    pt = ctx.new_page(); pt.on('pageerror', lambda e: er.append('T:' + str(e))); pt.goto(U + 'morceau.html'); pt.wait_for_timeout(1200)
    pt.set_input_files('#fPr', p2); pt.wait_for_timeout(1500)
    it = pt.evaluate("new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>{const i=g.result.filter(x=>x.proj==='Importés'||x.name==='Boucle acide melo').pop();r(i?{name:i.name,au:!!(i.au&&i.au.l&&i.au.l.length),n:i.qx.samples.length}:null)}}})")
    chk(it and it['au'] and it['n'] == 8, 'Track ▸ Ouvrir un fichier… (.qpt) : pattern ajouté à la bibliothèque avec son son (%s)' % it)
    pt.close(); ctx.close()

    # ── B. Import unique des anciens préréglages ──
    ctx = br.new_context(viewport={'width': 390, 'height': 844}); pg = ctx.new_page(); pg.on('pageerror', lambda e: er.append(str(e)))
    pg.goto(U + 'quantone.html'); pg.wait_for_timeout(600)
    P1 = dict(J['preset']); P1['date'] = '2026-10-12T21:04:00.000Z'; P2 = dict(BL['Boucle 8']['qx']['preset'])
    pg.evaluate("(L)=>{localStorage.setItem('quantone.mine',JSON.stringify(L));localStorage.removeItem('qx.mineMigr');}", [P1, P2]); pg.reload(); pg.wait_for_timeout(1800)
    CNT = "new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onupgradeneeded=()=>o.result.createObjectStore('items',{keyPath:'id'});o.onsuccess=()=>{const g=o.result.transaction('items').objectStore('items').getAll();g.onsuccess=()=>r(g.result.filter(x=>x.proj==='Anciens préréglages').map(x=>x.id+'|'+x.name))}})"
    L1 = pg.evaluate(CNT)
    chk(len(L1) == 2 and pg.evaluate("localStorage.getItem('qx.mineMigr')") == '1', 'préréglages importés dans la bibliothèque, projet « Anciens préréglages » (%s)' % L1)
    chk(pg.evaluate("JSON.parse(localStorage.getItem('quantone.mine')).length") == 2, 'la clé d’origine est gardée (aucune perte)')
    # renommer, puis relancer l'import sans drapeau : pas de doublon, le nom choisi reste
    pg.evaluate("(id)=>new Promise(r=>{const o=indexedDB.open('qxlib',1);o.onsuccess=()=>{const tx=o.result.transaction('items','readwrite'),s=tx.objectStore('items'),g=s.get(id);g.onsuccess=()=>{const i=g.result;i.name='Renommé';s.put(i);};tx.oncomplete=()=>r(1)}})", L1[0].split('|')[0])
    pg.evaluate("localStorage.removeItem('qx.mineMigr')"); pg.reload(); pg.wait_for_timeout(1500)
    pt = ctx.new_page(); pt.goto(U + 'morceau.html'); pt.wait_for_timeout(1200)   # Track lance aussi l'import (même base)
    L2 = pg.evaluate(CNT)
    chk(len(L2) == 2 and any(x.endswith('|Renommé') for x in L2), 'import idempotent : relancé deux fois (Pattern + Track), pas de doublon, renommage gardé (%s)' % L2)
    pg.evaluate("(()=>{var b=document.getElementById('qLibMgr');b.click();})()"); pg.wait_for_timeout(400)
    chk('Anciens préréglages' in pg.evaluate("document.getElementById('qLibPanel').textContent"), 'Bibliothèque… : le projet « Anciens préréglages » apparaît')
    ctx.close()

    # ── C. Track : .qxp réel de Simon (v1) → .qxp v2 → même son ──
    def track_load(path, tag):
        c = br.new_context(viewport={'width': 390, 'height': 844}, accept_downloads=True); t = c.new_page(); t.on('pageerror', lambda e: er.append('T:' + str(e)))
        t.goto(U + 'morceau.html'); t.wait_for_timeout(1200); t.evaluate(ENC); t0 = time.time()
        t.set_input_files('#fPr', path); t.wait_for_function("MORCEAU.P().blocks.length===%d&&MORCEAU.P().clips.length===%d" % (len(Q['blocks']), len(Q['clips'])), timeout=300000); t.wait_for_timeout(500)
        print('      %s : ouvert en %.1f s' % (tag, time.time() - t0)); return c, t
    c1, t1 = track_load(QXP, '.qxp v1')
    S1 = t1.evaluate("(()=>{const P=MORCEAU.P();return JSON.stringify({t:P.tracks,c:P.clips,m:P.master,l:P.loop,b:P.bpm})})()")
    R1 = dec(t1.evaluate("async()=>__enc(await MORCEAU.exportBuf())"))
    p, nm = dl(t1, '#qfFile', '#bFile')
    V2 = json.load(open(p)); sz = os.path.getsize(p)
    chk(nm.endswith('.qxp') and V2.get('v') == 2 and all(b['kind'] in ('pat', 'audio') for b in V2['blocks']), 'Exporter ▸ Fichier track : .qxp v2 (%s)' % nm)
    chk(all('pcm' not in s for s in V2['samples'].values()) and all(s.get('ref', '').startswith('pool:') for s in V2['samples'].values()), 'table partagée : %d sons, tous des références (aucun PCM)' % len(V2['samples']))
    chk(sz < 60000, 'taille du .qxp de Simon : %d o en v2 (v1 : %d o, −%.1f %%)' % (sz, os.path.getsize(QXP), 100 - 100 * sz / os.path.getsize(QXP)))
    print('      .qxp v2 de Simon : %d o' % sz)
    p3, _ = None, None
    t1.click('#bFile'); t1.wait_for_timeout(300); t1.check('#qfSnd')
    with t1.expect_download(timeout=120000) as d: t1.click('#qfFile')
    p3 = os.path.join(TMP, 'simon-son.qxp'); d.value.save_as(p3); V3 = json.load(open(p3))
    chk(V3.get('au') and len(V3['au']) == 3, '« avec le son » : son de chaque bloc pattern joint (%d o)' % os.path.getsize(p3))
    print('      .qxp v2 avec le son : %d o' % os.path.getsize(p3))
    c1.close()
    c2, t2 = track_load(p, '.qxp v2')
    S2 = t2.evaluate("(()=>{const P=MORCEAU.P();return JSON.stringify({t:P.tracks,c:P.clips,m:P.master,l:P.loop,b:P.bpm})})()")
    chk(S1 == S2, 'v2 relu : pistes, clips, master (compresseur 0,4 gardé), boucle et tempo identiques')
    R2 = dec(t2.evaluate("async()=>__enc(await MORCEAU.exportBuf())"))
    same_sound(R1[0], R2[0], R1[1], '.qxp de Simon v1 → v2')
    c2.close()
    c3, t3 = track_load(p3, '.qxp v2 avec le son')
    chk(t3.evaluate("MORCEAU.P().blocks.filter(b=>b.kind==='qx').every(b=>b.au===1)"), 'avec le son : Track joue le son du fichier (pas de re-rendu)')
    R3 = dec(t3.evaluate("async()=>__enc(await MORCEAU.exportBuf())"))
    same_sound(R1[0], R3[0], R1[1], '.qxp v2 avec le son')
    c3.close()
    chk(not er, 'aucune erreur JS ' + str(er[:2]))
    br.close()
print('RÉSULTAT %d / %d' % (sum(res), len(res)))
sys.exit(0 if all(res) else 1)
