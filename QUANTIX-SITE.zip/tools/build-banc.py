"""build-banc.py — construit le banc d'essai : aperçu (tous mondes ouverts) + panneau de test + prototype injecté.
Usage : python3 tools/build-banc.py   (le prototype vient de tools/fiches/9.js, variante passée en argument JSON)"""
import subprocess,sys,json,os
R=os.path.dirname(os.path.abspath(__file__))+'/..'
P=sys.argv[1] if len(sys.argv)>1 else '{"ke":175}'
subprocess.run(['python3',R+'/tools/build-apercu.py','1','11','skipintro'],check=True,capture_output=True)
proto=subprocess.run(['node','-e',"const F=require('%s/tools/fiches/9.js');const c=F.gen(%s);c.ink=320;c.star=null;console.log(JSON.stringify(c));"%(R,P)],capture_output=True,text=True).stdout.strip().split('\n')[-1]
s=open('/mnt/user-data/outputs/quantix-apercu-monde1.html',encoding='utf-8').read()
panel=open(R+'/tools/banc-panel.html',encoding='utf-8').read().replace('__PROTO__',proto)
s=s.replace('</body>',panel+'</body>',1)
open('/mnt/user-data/outputs/quantix-banc-essai.html','w',encoding='utf-8').write(s);print('banc construit')
