# Mettre en ligne le point d'ingestion Quantix (Cloudflare, gratuit) — depuis un iPhone, sans ligne de commande

1. Crée un compte sur dash.cloudflare.com (e-mail + mot de passe, formule gratuite).
2. **Base** : menu « Storage & Databases » → « D1 SQL Database » → « Create » → nom `quantix-events`. Ouvre-la → onglet « Console » → colle le contenu de `schema.sql` → « Execute ».
3. **Worker** : « Workers & Pages » → « Create » → « Create Worker » → nom `quantix-events` → « Deploy » → « Edit code » → efface tout, colle `ingest.js` → « Deploy ».
4. **Liaison** : Worker → « Settings » → « Bindings » → « Add » → « D1 database » → variable `DB` → base `quantix-events`.
5. **Variables** : « Settings » → « Variables and Secrets » → ajoute
   - `ALLOWED_ORIGIN` (texte) = l'adresse de ton site GitHub Pages sans barre finale, ex. `https://tonpseudo.github.io`
   - `ADMIN_KEY` (secret) = une longue phrase au hasard (garde-la : elle sert à lire les données).
6. Copie l'adresse du Worker (`https://quantix-events.TON-SOUS-DOMAINE.workers.dev`) et donne-la-moi : je la mets dans le jeu (`ENDPOINT` de events.js).
7. Vérifier : ouvre `https://…workers.dev/stats?key=TA_CLE` → doit afficher `{"players":0,…}`.
8. Lire les données avec Claude : ouvre `https://…workers.dev/export?key=TA_CLE` et envoie-moi le fichier (ou colle-le) ; je l'importe dans la base du projet.

Limites gratuites (ordre de grandeur) : ~100 000 requêtes/jour et 100 000 écritures D1/jour ; un joueur actif = quelques lots par session → large pour une bêta.
