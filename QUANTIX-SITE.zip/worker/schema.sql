-- Quantix · base D1 « quantix-events » (à exécuter une fois dans la console D1 du tableau de bord Cloudflare)
CREATE TABLE IF NOT EXISTS batches (
  pid TEXT NOT NULL, sid TEXT NOT NULL, k0 INTEGER NOT NULL,
  n INTEGER NOT NULL, build TEXT, at TEXT NOT NULL, body TEXT NOT NULL,
  PRIMARY KEY (pid, sid, k0)
);
CREATE TABLE IF NOT EXISTS players (
  pid TEXT PRIMARY KEY, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
  country TEXT, build TEXT, lang TEXT, w INTEGER, h INTEGER, dpr REAL, sessions INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_batches_at ON batches(at);
