/* Quantix · point d'ingestion des événements de jeu (Cloudflare Worker + base D1).
   POST /        corps text/plain = JSON {st:{pid,build,lang,w,h,dpr,n…}, ev:[…≤200]}  → enregistre un lot (idempotent : pid+sid+k0)
   GET  /export?key=ADMIN_KEY&after=ROWID&limit=200 → lots au format JSON (pour Claude / archivage)
   GET  /stats?key=ADMIN_KEY                          → joueurs, sessions, lots, événements, répartition par pays
   Variables : ADMIN_KEY (secret), ALLOWED_ORIGIN (ex. https://TON-COMPTE.github.io). Liaison D1 : DB.
   Vie privée : pas d'IP stockée ; pays grossier (en-tête Cloudflare) enregistré une fois par joueur ; aucune donnée personnelle. */
const MAX_BODY = 262144, MAX_EV = 200;
const HEX12 = /^[0-9a-f]{12}$/, HEX8 = /^[0-9a-f]{8}$/;
function cors(env, req) {
  const o = req.headers.get('Origin') || '', ok = env.ALLOWED_ORIGIN && (o === env.ALLOWED_ORIGIN || /^http:\/\/localhost(:\d+)?$/.test(o));
  return { 'Access-Control-Allow-Origin': ok ? o : (env.ALLOWED_ORIGIN || 'null'), 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' };
}
const J = (o, s, h) => new Response(JSON.stringify(o), { status: s || 200, headers: Object.assign({ 'Content-Type': 'application/json' }, h || {}) });
function clean(st) {
  const s = (v, n) => String(v == null ? '' : v).slice(0, n), i = (v) => (Number.isFinite(+v) ? Math.round(+v) : null);
  return { build: s(st.build, 8), lang: s(st.lang, 5), w: i(st.w), h: i(st.h), dpr: Number.isFinite(+st.dpr) ? +(+st.dpr).toFixed(2) : null };
}
export default {
  async fetch(req, env) {
    const h = cors(env, req), url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: h });
    if (req.method === 'GET' && (url.pathname === '/export' || url.pathname === '/stats')) {
      if (!env.ADMIN_KEY || url.searchParams.get('key') !== env.ADMIN_KEY) return J({ error: 'forbidden' }, 403, h);
      if (url.pathname === '/stats') {
        const q = async (sql) => (await env.DB.prepare(sql).first()) || {};
        const a = await q('SELECT COUNT(*) AS players, COALESCE(SUM(sessions),0) AS sessions FROM players');
        const b = await q('SELECT COUNT(*) AS batches, COALESCE(SUM(n),0) AS events FROM batches');
        const c = await env.DB.prepare('SELECT country, COUNT(*) AS n FROM players GROUP BY country ORDER BY n DESC').all();
        return J({ players: a.players, sessions: a.sessions, batches: b.batches, events: b.events, countries: c.results }, 200, h);
      }
      const after = parseInt(url.searchParams.get('after') || '0', 10) || 0, limit = Math.min(500, parseInt(url.searchParams.get('limit') || '200', 10) || 200);
      const r = await env.DB.prepare('SELECT rowid AS r, pid, sid, k0, n, build, at, body FROM batches WHERE rowid > ? ORDER BY rowid LIMIT ?').bind(after, limit).all();
      const rows = r.results || [];
      return J({ next: rows.length ? rows[rows.length - 1].r : after, batches: rows.map((x) => ({ r: x.r, pid: x.pid, sid: x.sid, k0: x.k0, n: x.n, build: x.build, at: x.at, ev: JSON.parse(x.body) })),
        players: (await env.DB.prepare('SELECT * FROM players').all()).results }, 200, h);
    }
    if (req.method !== 'POST') return J({ error: 'method' }, 405, h);
    const o = req.headers.get('Origin');
    if (o && env.ALLOWED_ORIGIN && o !== env.ALLOWED_ORIGIN && !/^http:\/\/localhost(:\d+)?$/.test(o)) return J({ error: 'origin' }, 403, h);
    const raw = await req.text();
    if (raw.length > MAX_BODY) return J({ error: 'size' }, 413, h);
    let p; try { p = JSON.parse(raw); } catch (e) { return J({ error: 'json' }, 400, h); }
    const st = p && p.st, ev = p && p.ev;
    if (!st || !HEX12.test(String(st.pid || '')) || !Array.isArray(ev) || !ev.length || ev.length > MAX_EV) return J({ error: 'shape' }, 400, h);
    const sid = String(ev[0].s || ''); if (!HEX8.test(sid)) return J({ error: 'sid' }, 400, h);
    for (const e of ev) if (!e || typeof e.k !== 'number' || typeof e.t !== 'number' || typeof e.y !== 'string' || e.y.length > 4) return J({ error: 'event' }, 400, h);
    const c = clean(st), now = new Date().toISOString(), country = (req.cf && req.cf.country) || req.headers.get('CF-IPCountry') || null;
    const body = JSON.stringify(ev);
    await env.DB.batch([
      env.DB.prepare('INSERT OR IGNORE INTO batches (pid,sid,k0,n,build,at,body) VALUES (?,?,?,?,?,?,?)').bind(st.pid, sid, ev[0].k | 0, ev.length, c.build, now, body),
      env.DB.prepare('INSERT INTO players (pid,first_seen,last_seen,country,build,lang,w,h,dpr,sessions) VALUES (?,?,?,?,?,?,?,?,?,?) ' +
        'ON CONFLICT(pid) DO UPDATE SET last_seen=excluded.last_seen, build=excluded.build, lang=excluded.lang, w=excluded.w, h=excluded.h, dpr=excluded.dpr, sessions=MAX(sessions, excluded.sessions)')
        .bind(st.pid, now, now, country, c.build, c.lang, c.w, c.h, c.dpr, Math.min(9999, parseInt(st.n, 10) || 1)),
    ]);
    return J({ ok: true, n: ev.length }, 200, h);
  },
};
