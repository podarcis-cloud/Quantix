/* ===== ETAGE 7C DEBUT ===== R511 · Monde 7 (7) — étage 7 des créatures actives, troisième créature : le RUBAN
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage7b.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans ruban : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : window.QXE6.ruban (table de dessin déjà appelée par qxcrea.js dessinerAct).
   ruban (d'après la vidéo de référence : long filament perlé bleuté, translucide, enroulé autour d'un corps vert bioluminescent
          à nervure ondulée ; extrémité fine terminée par deux points rouge-orangé) :
          un corps vert (x,y) qui dérive lentement (x ± ax, y ± ay, pulsation w, phase ph) ; son filament fait une BOUCLE autour
          de lui (rayon R, ouverture arc degrés, sens sg) puis s'étire en une queue (longueur L2) orientée a (degrés), qui ondule
          (onde partie de l'extrémité, sw px). Attente active : dérive, respiration, ondulation, vague de lumière dans les perles.
          Quand la particule touche le filament (à moins de r px), le ruban l'enroule : il l'emporte LE LONG DE SA LONGUEUR
          (sp px par image, lentement), autour du corps puis jusqu'au bout de la queue, pesanteur suspendue, et la RELÂCHE à
          l'extrémité, dans l'axe de la queue, avec sa vitesse d'arrivée (bornée vmin..vmax). Pause cd. Jamais absorbée.
          Effet neuf : un CONVOYEUR VIVANT — un manège lent qui fait faire un tour à la particule et la renvoie dans l'axe de la queue.
   Tout est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1 (crForce d'origine). */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7c) return;
F.e7c = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180, TAU = Math.PI * 2;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'ruban'); CACHE.set(cr, v); } return v; }
function segD(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let u = l > 1e-9 ? ((px - ax) * dx + (py - ay) * dy) / l : 0; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const x = ax + dx * u - px, y = ay + dy * u - py; return Math.sqrt(x * x + y * y); }
function rbPos(e, t) { const w = e.w || .007, ph = e.ph || 0; return [e.x + (e.ax || 0) * Math.sin(t * w + ph), e.y + (e.ay || 0) * Math.sin(t * w * .71 + ph * 1.3)]; }
function lens(e) { const R = e.R || 34; return [R * (e.arc || 300) * D2R, e.L2 || 90]; }   // [longueur de la boucle, longueur de la queue]
/* point du filament à l'abscisse curviligne s (0 = racine sur le corps, La+L2 = extrémité) ; o = [x, y, tx, ty] */
function rbPt(e, t, s, o, q) {
  q = q || rbPos(e, t); o = o || [0, 0, 0, 0];
  const R = e.R || 34, sg = e.sg == null ? 1 : e.sg, a = (e.a || 0) * D2R, arc = (e.arc || 300) * D2R, La = R * arc, L2 = e.L2 || 90;
  const th1 = a - sg * Math.PI / 2, th0 = th1 - sg * arc;
  if (s < La) { const th = th0 + sg * s / R, wb = 1.6 * Math.sin(t * .021 - s * .09 + (e.ph || 0));   // boucle : légère houle des perles
    const rr = R + wb; o[0] = q[0] + rr * Math.cos(th); o[1] = q[1] + rr * Math.sin(th); o[2] = -Math.sin(th) * sg; o[3] = Math.cos(th) * sg; return o; }
  const d = Math.min(s - La, L2), ux = Math.cos(a), uy = Math.sin(a), sw = e.sw == null ? 5 : e.sw, k = d / L2;
  const ond = sw * k * k * Math.sin(t * .024 + (L2 - d) * .07 + (e.ph || 0)) + 1.6 * Math.sin(t * .021 - La * .09 + (e.ph || 0)) * (1 - k);
  const bx = q[0] + R * Math.cos(th1), by = q[1] + R * Math.sin(th1);
  o[0] = bx + ux * d - uy * ond; o[1] = by + uy * d + ux * ond; o[2] = ux; o[3] = uy; return o;
}
F.e7cPos = rbPos; F.e7cPt = rbPt;
F.crPos = function (e, t) { return e.t === 'ruban' ? rbPos(e, t) : oPos(e, t); };
function acc(e, st, tt) { const n = tt - st.in, T0 = 30, sp = e.sp || 2.2, va = st.v0; return n <= T0 ? va * n + (sp - va) * n * n / (2 * T0) : va * T0 + (sp - va) * T0 / 2 + sp * (n - T0); }
const P = [0, 0, 0, 0], P2 = [0, 0, 0, 0], NS = 40;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  let ax = b.cpx == null ? b.x : b.cpx, ay = b.cpy == null ? b.y : b.cpy;
  oForce(b, sub, lv, g);
  if ((ax - b.x) * (ax - b.x) + (ay - b.y) * (ay - b.y) > 900) { ax = b.x; ay = b.y; }
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'ruban') continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0, sp: 0 }), q = rbPos(e, t), Lt = lens(e), Ltot = Lt[0] + Lt[1];
    if (st.h) {
      const s = st.s0 + acc(e, st, t), s1 = st.s0 + acc(e, st, t + 1);   // abscisse portée (raccord doux de la vitesse d'arrivée)
      if (s >= Ltot) {                                  // relâche à l'extrémité, dans l'axe de la queue, avec sa vitesse d'arrivée
        rbPt(e, t, Ltot, P, q); rbPt(e, t, Ltot - 8, P2, q);
        let ux = P[0] - P2[0], uy = P[1] - P2[1]; const l = Math.hypot(ux, uy) || 1; ux /= l; uy /= l;
        const vm = Math.max(e.vmin || 3, Math.min(e.vmax || 9, st.vin));
        b.x = P[0]; b.y = P[1]; b.vx = ux * vm; b.vy = uy * vm; st.h = 0; st.out = t; st.cd = t + (e.cd || 90);
        if (racine.BUS) BUS.emit('creature.spit', { x: b.x, y: b.y });
      } else {
        const k = Math.min(1, (t - st.in) / 16), kk = k * k * (3 - 2 * k), q1 = rbPos(e, t + 1);
        rbPt(e, t, s, P, q); rbPt(e, t + 1, Math.min(Ltot, s1), P2, q1);
        const ox = st.ox * (1 - kk), oy = st.oy * (1 - kk), k1 = Math.min(1, (t + 1 - st.in) / 16), kk1 = k1 * k1 * (3 - 2 * k1);
        b.x = P[0] + ox; b.y = P[1] + oy;
        b.vx = P2[0] + st.ox * (1 - kk1) - b.x; b.vy = P2[1] + st.oy * (1 - kk1) - b.y - gg / sub;
      }
    } else if (t >= st.cd) {
      let best = 1e9, bs = 0;
      for (let k = 0; k <= NS; k++) { rbPt(e, t, Ltot * k / NS, P, q); const d = Math.hypot(P[0] - b.x, P[1] - b.y); if (d < best) { best = d; bs = Ltot * k / NS; } }
      let hit = best < (e.r || 18);
      if (!hit) { let px = 0, py = 0; for (let k = 0; k <= NS; k++) { rbPt(e, t, Ltot * k / NS, P, q); if (k && segDD(px, py, P[0], P[1], ax, ay, b.x, b.y) < (e.r || 18)) { hit = true; bs = Ltot * k / NS; break; } px = P[0]; py = P[1]; } }
      if (hit && bs < Ltot - 4) {
        const v0 = Math.hypot(b.vx, b.vy), sp = e.sp || 2.2, va = Math.min(v0, sp * 2.5), s0 = bs;
        st.h = 1; st.in = t; st.vin = v0; st.s0 = s0; st.v0 = va;
        rbPt(e, t, s0, P, q); st.ox = b.x - P[0]; st.oy = b.y - P[1];
        if (racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
      }
    }
  }
  b.cpx = b.x; b.cpy = b.y;
};
/* distance entre deux segments (trajet de la bille × tronçon du filament) */
function segDD(ax, ay, bx, by, cx, cy, dx, dy) {
  const d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax), d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax),
    d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx), d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx);
  if (d1 * d2 < 0 && d3 * d4 < 0) return 0;
  return Math.min(segD(ax, ay, cx, cy, dx, dy), segD(bx, by, cx, cy, dx, dy), segD(cx, cy, ax, ay, bx, by), segD(dx, dy, ax, ay, bx, by));
}

/* ───────────── RENDU : sprites pré-calculés (perle éclairée, corps vert à nervure, halos) ─────────────
   Le filament est dessiné perle par perle le long de la MÊME courbe que la physique (la particule roule vraiment dessus) ;
   le corps : NA images d'une ondulation de la nervure (menée par l'avant), volume en dégradé, translucide, tourné lentement. */
const NA = 20, BW = 76, BH = 120, DPR = 2;
let BODY = null, BEAD = null, BEADL = null, GLOW = null, GREEN = null, RED = null;
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function rad(s, stops) { const c = cv(s, s), g = c.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  stops.forEach(z => r.addColorStop(z[0], z[1])); g.fillStyle = r; g.fillRect(0, 0, s, s); return c; }
function sprites() {
  if (BODY) return;
  /* perle : petite sphère bleutée translucide, éclairée en haut à gauche, liseré clair (volume, jamais plate) */
  const mk = lit => { const s = 16 * DPR, c = cv(s, s), g = c.getContext('2d'); g.scale(DPR, DPR);
    const r = g.createRadialGradient(6, 5.5, .4, 8, 8, 6.4);
    r.addColorStop(0, lit ? 'rgba(240,255,255,.98)' : 'rgba(214,240,255,.9)'); r.addColorStop(.35, lit ? 'rgba(150,236,255,.85)' : 'rgba(110,190,240,.6)');
    r.addColorStop(.8, lit ? 'rgba(60,150,220,.5)' : 'rgba(40,110,190,.32)'); r.addColorStop(1, 'rgba(20,40,90,0)');
    g.fillStyle = r; g.beginPath(); g.arc(8, 8, 6.4, 0, TAU); g.fill();
    g.strokeStyle = lit ? 'rgba(220,250,255,.75)' : 'rgba(170,215,245,.45)'; g.lineWidth = .6; g.beginPath(); g.arc(8, 8, 5.2, 0, TAU); g.stroke(); return c; };
  BEAD = mk(0); BEADL = mk(1);
  GLOW = rad(96, [[0, 'rgba(140,220,255,.5)'], [.45, 'rgba(90,150,255,.16)'], [1, 'rgba(60,90,200,0)']]);
  GREEN = rad(128, [[0, 'rgba(120,255,110,.42)'], [.5, 'rgba(60,200,90,.15)'], [1, 'rgba(20,120,60,0)']]);
  RED = rad(24, [[0, 'rgba(255,236,200,1)'], [.35, 'rgba(255,140,80,.95)'], [1, 'rgba(255,80,40,0)']]);
  /* corps : sac allongé vert, translucide, stries radiales fines, nervure ondulée lumineuse (onde menée par l'avant = haut du sprite) */
  const c = cv(BW * DPR * NA, BH * DPR), g = c.getContext('2d'), N = 36;
  for (let f = 0; f < NA; f++) {
    const ph = f / NA * TAU; g.save(); g.translate((f * BW + BW / 2) * DPR, BH / 2 * DPR); g.scale(DPR, DPR);
    const HL = 50, X = [], Y = [], Wd = [];
    for (let k = 0; k <= N; k++) { const u = k / N, y = -HL + u * HL * 2; Y.push(y); X.push(2.4 * Math.sin(ph - u * 4.2) * (.4 + .6 * u));
      Wd.push(23 * Math.pow(Math.sin(Math.PI * (.04 + u * .92)), .7) * (1 + .1 * Math.sin(ph + u * 6)) + 1); }
    const path = () => { g.beginPath(); g.moveTo(X[0], Y[0] - 2); for (let k = 0; k <= N; k++) g.lineTo(X[k] + Wd[k], Y[k]); g.lineTo(X[N], Y[N] + 2); for (let k = N; k >= 0; k--) g.lineTo(X[k] - Wd[k], Y[k]); g.closePath(); };
    path(); const gr = g.createLinearGradient(-26, 0, 26, 0);
    gr.addColorStop(0, 'rgba(20,90,40,.5)'); gr.addColorStop(.3, 'rgba(110,230,110,.5)'); gr.addColorStop(.45, 'rgba(170,255,150,.55)');
    gr.addColorStop(.7, 'rgba(60,170,80,.42)'); gr.addColorStop(1, 'rgba(14,60,40,.55)'); g.fillStyle = gr; g.fill();
    g.save(); g.clip();
    g.lineWidth = .5; g.strokeStyle = 'rgba(180,255,170,.22)'; g.beginPath();           // stries (texture fibreuse du sac)
    for (let k = 1; k < N; k += 1) { const sd = k % 2 ? 1 : -1; g.moveTo(X[k], Y[k]); g.quadraticCurveTo(X[k] + sd * Wd[k] * .5, Y[k] + 3, X[k] + sd * Wd[k], Y[k] + 5 * Math.sin(ph + k)); }
    g.stroke();
    g.fillStyle = 'rgba(255,255,255,.1)'; g.beginPath(); g.ellipse(-8, -6, 7, 30, -.08, 0, TAU); g.fill();       // reflet (volume)
    g.restore();
    path(); g.strokeStyle = 'rgba(190,255,170,.45)'; g.lineWidth = .9; g.stroke();
    /* nervure : zigzag lumineux qui ondule */
    for (const [lw, col] of [[4.2, 'rgba(120,255,90,.28)'], [1.8, 'rgba(200,255,120,.9)'], [.7, 'rgba(250,255,220,.95)']]) {
      g.beginPath(); for (let k = 1; k < N; k++) { const zz = X[k] + 5.5 * Math.sin(k * 1.35 + ph * 2) * Math.sin(Math.PI * k / N); k > 1 ? g.lineTo(zz, Y[k]) : g.moveTo(zz, Y[k]); }
      g.strokeStyle = col; g.lineWidth = lw; g.stroke(); }
    g.restore();
  }
  BODY = c;
}
const Q = [0, 0, 0, 0], CIL = { a: new Float32Array(400), n: 0 };
function dessinerRuban(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  sprites();
  const c = e.c; st = run ? (st || {}) : {};
  const held = run && st.h && b;
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, q = rbPos(c, t), Lt = lens(c), Ltot = Lt[0] + Lt[1];
  const sb = held ? Math.min(Ltot, st.s0 + acc(c, st, fr)) : -1;
  const near = b && run && !held ? Math.max(0, 1 - Math.hypot(b.x - q[0], b.y - q[1]) / 150) : 0, lum = held ? 1 : .35 + .45 * near;
  e.lum7 = e.lum7 == null ? lum : e.lum7 + (lum - e.lum7) * Math.min(1, dt * 3);
  e.ph7 = ((e.ph7 || 0) + dt * (held ? .7 : .32)) % 1;
  e.rot7 = (e.rot7 == null ? (c.ph || 0) : e.rot7) + dt * (.05 + (held ? .12 : 0)) * (c.sg == null ? 1 : c.sg);   // le corps tourne lentement dans sa boucle
  ctx.save();
  /* halos additifs : vert du corps, bleu du filament */
  ctx.globalCompositeOperation = 'lighter';
  const gs = (110 + 30 * e.lum7); ctx.globalAlpha = .5 + .35 * e.lum7; ctx.drawImage(GREEN, q[0] - gs / 2, q[1] - gs / 2, gs, gs);
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = .92;
  /* corps (sprite animé, tourné, léger roulis : écrasement ≥ 0,8) */
  const fi = Math.floor(e.ph7 * NA) % NA, roll = .86 + .14 * Math.cos(T * .37 + (c.ph || 0)), bs = (c.R || 34) * 1.75 / 100;
  ctx.save(); ctx.translate(q[0], q[1]); ctx.rotate(e.rot7 + .4 * Math.sin(T * .11)); ctx.scale(bs * roll * 1.2, bs);
  ctx.drawImage(BODY, fi * BW * DPR, 0, BW * DPR, BH * DPR, -BW / 2, -BH / 2, BW, BH); ctx.restore();
  /* filament perlé : perles le long de la courbe physique, plus petites vers l'extrémité ; vague de lumière qui court
     de la racine vers la pointe (attente) ou qui accompagne la particule (portage) */
  const step = 5.2, n = Math.floor(Ltot / step), wave = (T * 38) % (Ltot + 120) - 60;
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = 'rgba(120,200,255,.32)'; ctx.lineWidth = 1.2; ctx.beginPath();
  for (let k = 0; k <= n; k++) { rbPt(c, t, k * step, Q, q); k ? ctx.lineTo(Q[0], Q[1]) : ctx.moveTo(Q[0], Q[1]); }
  ctx.stroke(); ctx.globalCompositeOperation = 'source-over';
  for (let k = 0; k <= n; k++) {
    const s = k * step; rbPt(c, t, s, Q, q);
    const taper = s < Lt[0] ? 1 : 1 - .55 * (s - Lt[0]) / Lt[1];
    const dl = held ? Math.abs(s - sb) : Math.abs(s - wave), li = Math.max(0, 1 - dl / (held ? 34 : 26)) * (held ? 1 : .55 + .45 * e.lum7);
    const r = (3.1 + .5 * Math.sin(s * .9 + T * 2)) * taper * (1 + .25 * li);
    ctx.globalAlpha = .62 + .38 * li; ctx.drawImage(li > .3 ? BEADL : BEAD, Q[0] - r * 1.25, Q[1] - r * 1.25, r * 2.5, r * 2.5);
    if (k % 2 === 0) { const sd = (k & 2) ? 1 : -1, cl = 3.2 * taper + 1.2 * Math.sin(T * 3 + k), j = CIL.n;   // cils fins de part et d'autre (un seul tracé)
      CIL.a[j] = Q[0] - Q[3] * sd * r; CIL.a[j + 1] = Q[1] + Q[2] * sd * r; CIL.a[j + 2] = Q[0] - Q[3] * sd * (r + cl) - Q[2] * 1.5; CIL.a[j + 3] = Q[1] + Q[2] * sd * (r + cl) - Q[3] * 1.5; CIL.n += 4; }
  }
  ctx.globalAlpha = .35; ctx.strokeStyle = 'rgba(190,230,255,.8)'; ctx.lineWidth = .5; ctx.beginPath();
  for (let j = 0; j < CIL.n; j += 4) { ctx.moveTo(CIL.a[j], CIL.a[j + 1]); ctx.lineTo(CIL.a[j + 2], CIL.a[j + 3]); }
  ctx.stroke(); CIL.n = 0;
  /* pointe : deux points rouge-orangé qui palpitent */
  rbPt(c, t, Ltot, Q, q); const px = Q[0], py = Q[1], tx = Q[2], ty = Q[3], pr = 4.5 + .8 * Math.sin(T * 2.3);
  ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .85;
  ctx.drawImage(RED, px + tx * 3 - ty * 2.6 - pr, py + ty * 3 + tx * 2.6 - pr, pr * 2, pr * 2);
  ctx.drawImage(RED, px + tx * 3 + ty * 2.6 - pr, py + ty * 3 - tx * 2.6 - pr, pr * 2, pr * 2);
  if (held) { ctx.globalAlpha = .6; ctx.drawImage(GLOW, b.x - 18, b.y - 18, 36, 36); }
  ctx.restore();
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).ruban = dessinerRuban;
racine.QXE7C = { ruban: dessinerRuban, sprites };
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 7C FIN ===== */
