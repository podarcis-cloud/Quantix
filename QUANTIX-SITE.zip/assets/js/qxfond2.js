/* =====================================================================
   QXF2 — branchement de QXFOND + QXPOOL dans le jeu (mondes décorés).
   scene() du moteur appelle QXF2.scene(c, lv, env) ; si la fonction rend
   true, le fond a été pris en charge (canevas laissé TRANSPARENT, image
   et couches en CSS sous lui) et le moteur saute son ancien décor.
   Coupe-circuit : localStorage 'qxfond2' = '0' → décor d'origine.
   Sobre : SEUL le réglage « réduire les animations » du jeu (RM) compte, comme le jeu depuis R296
   (fond10 : on n'écoute plus prefers-reduced-motion du système).
   FUSION (fond10) : pool recomposé '<monde>__fu' (+ '__fu2' en alternance) et anciens éléments retenus
   (QXFU, calque « écran » dans .qxf). Monde 12 (fluides) : nouveaux éléments seuls ; un niveau peut être
   forcé sur un décor par window.QXF2_FORCE = { idx: 'fluides' } (aperçu). Budget : REGL.budget ms/image,
   dégradation automatique par paliers au-delà (QXF2.mesure().degrade).
   env = { W, H, scale, RM, S, cv, hote, bus }
   ===================================================================== */
(function (racine) {
  'use strict';
  var NOMS = { 1: 'atelier', 2: 'fonderie', 3: 'chaine', 4: 'glacier', 5: 'soufflerie', 6: 'mecanique', 7: 'gravite', 8: 'magnetisme', 9: 'faille', 10: 'filaments', 11: 'quantique', 12: 'fluides' };
  var REGL = { attenuation: 0.72, vent: 170, vie: 2.4, qualite: 1, margeBut: 14, budget: 6, retardAudio: 25, imageMax: 40, periodeEv: 45, palierInitial: { magnetisme: [1, 2] } };   // vie 2,4 = défaut de l'atlas fusion   // réglages du branchement (le reste est dans les mondes)
  var actifLS = true;
  try { actifLS = racine.localStorage.getItem('qxfond2') !== '0'; } catch (e) {}
  try { var v0 = parseFloat(racine.localStorage.getItem('qxfond2vie')); if (v0 >= 0 && v0 <= 3) REGL.vie = v0; } catch (e) {}   // richesse « Vie » (0–3), réglable dans l'aperçu
  var D = racine.QXF2_DONNEES || { mondes: {}, images: {}, voiles: {}, ancres: {} };
  var cur = null, busOk = false, dernier = 0, t = 0, bille = { x: 0, y: 0, vx: 0, vy: 0 }, sortie = [0, 0], prete = false;
  var stats = { n: 0, ms: 0, rebonds: 0 };

  function pret() {
    if (prete) return true;
    if (!racine.QXFOND || !racine.QXPOOL) return false;
    var M = {}, k; for (k in D.mondes) M[k] = D.mondes[k];
    if (racine.QXFU) { var F = racine.QXFU.configs(D.mondes, REGL.vie); for (k in F) M[k] = F[k]; }
    racine.QXFOND.configurer(M); racine.QXPOOL.configurer(M); racine.QXF2_MONDES = M; prete = true;
    return true;
  }
  function nomDe(lv) { var f = racine.QXF2_FORCE; return (f && lv && f[lv.idx]) || NOMS[lv && lv.wd]; }
  function actif(lv) { var n = lv && nomDe(lv); return !!(actifLS && n && D.mondes[n] && pret()); }
  function demonter() { if (cur) { if (cur.fu) cur.fu.detruire(); cur.fond.detruire(); cur = null; } racine.QXF2_ACTIF = false; racine.QXF2_FU = false; }

  function geoDe(lv, k) {                          // champs du VRAI niveau → px du canevas
    var g = { puits: [], aimants: [], vents: [], murs: [], portails: [], detecteurs: [] }, i, q;
    for (i = 0; lv.grav && i < lv.grav.length; i++) { q = lv.grav[i]; g.puits.push({ x: (q[0] + q[2] / 2) * k, y: (q[1] + q[3] / 2) * k, r: Math.max(34, Math.min(q[2], q[3]) * 0.5 * k), f: q[5] < 0 ? -0.7 : 1 }); }
    for (i = 0; lv.mag && i < lv.mag.length; i++) { q = lv.mag[i]; g.aimants.push({ x: q[0] * k, y: q[1] * k, r: q[2] * k, f: q[3] < 0 ? -1 : 1 }); }
    for (i = 0; lv.wind && i < lv.wind.length; i++) { q = lv.wind[i]; g.vents.push({ x: q[0] * k, y: q[1] * k, l: q[2] * k, h: q[3] * k, fx: q[4], fy: q[5] }); }
    // phase 2 (NON TESTÉ dans le jeu) : murs (matériau 4 = glace, cf. tuto « ice »), portails (paires d'extrémités)
    for (i = 0; lv.walls && i < lv.walls.length; i++) { q = lv.walls[i]; if (q[5] === 1) continue; g.murs.push({ x1: q[0] * k, y1: q[1] * k, x2: q[2] * k, y2: q[3] * k, glace: q[4] === 4 }); }
    for (i = 0; lv.port && i < lv.port.length; i++) { q = lv.port[i]; g.portails.push({ x: q[0] * k, y: q[1] * k, r: 30 * k }, { x: q[2] * k, y: q[3] * k, r: 30 * k }); }
    for (i = 0; lv.det && i < lv.det.length; i++) { q = lv.det[i]; g.detecteurs.push({ x: q[0] * k, y: q[1] * k, r: (q[2] || 30) * k }); }   // détecteurs [x, y, r]
    return g;
  }
  function monter(lv, env) {
    demonter();
    var nom = nomDe(lv), hote = env.hote, rh = hote.getBoundingClientRect(), rc = env.cv.getBoundingClientRect(), k = env.scale;
    var zone = { x: rc.left - rh.left, y: rc.top - rh.top, l: rc.width, h: rc.height };
    if (zone.l < 40 || rh.width < 40) return false;
    var cup = lv.cup, but = cup ? { x: (cup[0] + cup[2] / 2) * k, y: (cup[1] - 30) * k, r: Math.max(cup[2] / 2 + 6, 44) * k } : null;
    var rang = (lv.idx || 0) % 12;
    var fond = racine.QXFOND.creer(hote, { monde: nom, image: D.images[nom], voile: D.voiles[nom], l: rh.width, h: rh.height, zone: zone,
      reussite: but ? { x: but.x + zone.x, y: but.y + zone.y, r: but.r } : null });
    fond.regler({ profondeur: rang / 11, qualite: REGL.qualite, sobre: false });
    var c0 = fond.cadre, M = racine.QXF2_MONDES || {}, nomP = M[nom + '__fu'] ? nom + '__fu' : nom, geo = geoDe(lv, k);
    var cadreP = { versEcran: function (u, v) { var p = c0.versEcran(u, v); return [p[0] - zone.x, p[1] - zone.y]; }, vImage: function (y) { return c0.vImage(y + zone.y); }, lI: c0.lI };
    var pool2 = M[nom + '__fu2'] ? racine.QXPOOL.creer({ monde: nom + '__fu2', l: zone.l, h: zone.h, zone: null, reussite: but, ancres: D.ancres[nom], graine: 11, attenuation: REGL.attenuation, geo: geo, cadre: cadreP }) : null;
    var wdM = (racine.QXFU && racine.QXFU.NOMWD[nom]) || lv.wd, aim = null, ai;
    for (ai = 0; lv.mag && ai < lv.mag.length; ai++) if (lv.mag[ai][3] >= 0) { aim = [lv.mag[ai][0], lv.mag[ai][1]]; break; }   // aimant principal (attirant d'abord) : centre commun des ferrofluides anciens
    if (!aim && lv.mag && lv.mag.length) aim = [lv.mag[0][0], lv.mag[0][1]];
    var fu = null;
    try { fu = racine.QXFU && racine.QXFU.creer({ nom: nom, wd: wdM, n: rang + 1, racine: hote.querySelector('.qxf'), l: rh.width, h: rh.height, zone: zone, k: k, aimant: aim,
      but: but ? { x: but.x + zone.x, y: but.y + zone.y, r: but.r } : null, periodeEv: REGL.periodeEv }); } catch (e) { fu = null; if (racine.console) console.warn('QXFU', e); }
    var pool = racine.QXPOOL.creer({ monde: nomP, l: zone.l, h: zone.h, zone: null, reussite: but, ancres: D.ancres[nom], graine: 11, attenuation: REGL.attenuation, geo: geo, cadre: cadreP });
    cur = { idx: lv.idx, nom: nom, fond: fond, pool: pool, pool2: pool2, alt: pool2 ? M[nom + '__fu2'].__alt : null, fu: fu, wrap: null, deg: 0, ema: 0, nImg: 0, fen: 0, nf: 0, scale: k, cle: Math.round(rh.width) + 'x' + Math.round(rh.height) + '@' + Math.round(zone.x) + ',' + Math.round(zone.y), zone: zone, vents: geoDe(lv, k).vents, sobre: null, rang: rang };
    racine.QXF2_ACTIF = true; racine.QXF2_FU = !!fu;
    var p0 = (REGL.palierInitial[nom] || [0, 0])[(racine.devicePixelRatio || 1) > 1.5 ? 1 : 0];   // pré-dégradation mesurée (Magnétisme : soie + ferrofluides)
    if (mobileDense()) p0 = Math.max(p0, 1);   /* R454 : iPhone (DPR ≥ 2,5, doigt) : calques anciens à demi-résolution, toile de fusion à 30 im/s */
    if (lourdOff) p0 = Math.max(p0, 4);        /* R454 : ?lourd=0 → éléments lourds coupés d'office */
    cur.degMin = p0; cur.t0m = performance.now(); cur.tDeg = 0; cur.tRem = 0; cur.verrou = false; cur.fi = 16.7; cur.fuN = 0; cur.fuDt = 0; cur.cadFu = 1; cur.vieDeg = 1; cur.figeCSS = false; cur.raison = p0 ? 'initial' : ''; cur.ra = 0;
    appliquer(p0);
    return true;
  }
  /* R454 — paliers 0–6 : 1 calques anciens ½ résolution + toile de fusion à 30 im/s · 2 cadence ×2 interne · 3 Vie ½ ·
     4 éléments lourds coupés + fusion à 20 im/s · 5 Vie ¼ · 6 couches CSS figées (la poussière du pool reste vivante) */
  function appliquer(d) {
    cur.deg = d;
    if (cur.fu) cur.fu.degrader(d >= 4 ? 3 : Math.min(2, d));
    cur.cadFu = d >= 4 ? 3 : d >= 1 ? 2 : 1;
    var vd = d >= 5 ? 0.25 : d >= 3 ? 0.5 : 1, fg = d >= 6;
    if (vd !== cur.vieDeg || fg !== cur.figeCSS) { cur.vieDeg = vd; cur.figeCSS = fg; cur.sobre = null; }
  }
  function degrader(raison) {                       // un palier de plus ; une rechute peu après une remontée verrouille le palier
    if (cur.deg >= 6) return;
    var now = performance.now(); if (cur.tRem && now - cur.tRem < 12000) cur.verrou = true;
    appliquer(cur.deg + 1); cur.raison = raison || 'js'; cur.tDeg = now; cur.fen = 0; cur.nf = 0;
  }
  function mobileDense() { try { return (racine.devicePixelRatio || 1) >= 2.5 && racine.matchMedia('(pointer: coarse)').matches; } catch (e) { return false; } }
  var lourdOff = false; try { lourdOff = racine.localStorage.getItem('qxlourd') === '0'; } catch (e) {}
  /* R454 — gouverneur au coût RÉEL. La musique d'abord : si l'ordonnanceur audio s'est réveillé en retard de plus de
     REGL.retardAudio ms, un palier tout de suite ; puis l'intervalle réel entre images (JS + tramage + composition, que
     l'ancien budget JS ne voyait pas) ; puis l'ancien critère JS. Remontée d'un palier après 10 s de calme. */
  function gouverner(ms, now) {
    cur.nImg++; cur.ema = cur.nImg < 2 ? ms : cur.ema * 0.9 + ms * 0.1;
    if (cur.nImg > 20 && !(cur.fu && cur.fu.evActif())) { cur.fen += ms; cur.nf++; }
    if (now - cur.t0m < 1500) return;             // mise en route : montage du décor, décodage du rendu musical
    var depuis = now - Math.max(cur.tDeg, cur.t0m + 1500), ra = racine.QXRET ? racine.QXRET.max(Math.min(1500, depuis)) : 0; cur.ra = ra;
    if (ra > REGL.retardAudio && depuis > 600) { degrader('audio ' + Math.round(ra) + ' ms'); return; }
    if (cur.fi > REGL.imageMax && depuis > 1200) { degrader('image ' + Math.round(cur.fi) + ' ms'); return; }
    if (cur.nf >= 24) { var mj = cur.fen / cur.nf; cur.fen = 0; cur.nf = 0; if (mj > REGL.budget && depuis > 1000) { degrader('js ' + mj.toFixed(1) + ' ms'); return; } }
    if (cur.deg > cur.degMin && !cur.verrou && depuis > 10000 && now - cur.tRem > 10000 && ra < REGL.retardAudio * 0.5 && cur.fi < REGL.imageMax * 0.7 && cur.ema < REGL.budget * 0.6) {
      appliquer(cur.deg - 1); cur.tRem = now; cur.raison = 'remontée'; }
  }
  function flow(x, y) {                            // le vent du niveau porte la poussière et les lignes d'émission
    var u = 4, v = 0, V = cur.vents, i, w;
    for (i = 0; i < V.length; i++) { w = V[i]; if (x >= w.x && x <= w.x + w.l && y >= w.y && y <= w.y + w.h) { u += w.fx * REGL.vent; v += w.fy * REGL.vent; } }
    sortie[0] = u; sortie[1] = v; return sortie;
  }
  function brancher(bus) {
    if (busOk || !bus) return;
    busOk = true;
    var ev = function (type) { return function (e) { if (cur && e) cur.pool.evenement(type, { x: e.x * cur.scale, y: e.y * cur.scale, nx: -(e.nx || 0), ny: -(e.ny || 0), v: (e.v || 0) * 60 * cur.scale }); }; };
    var ev2 = function (type) { return function (e) { if (cur && e && cur.pool2) cur.pool2.evenement(type, { x: e.x * cur.scale, y: e.y * cur.scale, nx: -(e.nx || 0), ny: -(e.ny || 0), v: (e.v || 0) * 60 * cur.scale }); }; };
    bus.on('ball.bounce', ev('rebond')); bus.on('ball.impact', ev('rebond')); bus.on('ball.boost', ev('elan'));   /* fond10 : tout choc réel (mur, trait : ball.impact, émis au-delà de 0,9 px/image) est un rebond pour le décor */
    bus.on('ball.bounce', ev2('rebond')); bus.on('ball.impact', ev2('rebond')); bus.on('ball.boost', ev2('elan'));
    var fuReb = function (e) { stats.rebonds++; if (cur && cur.fu && e) cur.fu.rebond({ x: e.x, y: e.y, v: e.v || 0, nx: e.nx || 0, ny: e.ny || 0 }); };
    bus.on('ball.bounce', fuReb); bus.on('ball.impact', fuReb);
  }
  function scene(c, lv, env) {
    if (!actif(lv)) { if (cur) demonter(); return false; }
    brancher(env.bus);
    var rh = env.hote.getBoundingClientRect(), rc = env.cv.getBoundingClientRect();
    var cle = Math.round(rh.width) + 'x' + Math.round(rh.height) + '@' + Math.round(rc.left - rh.left) + ',' + Math.round(rc.top - rh.top);
    if (!cur || cur.idx !== lv.idx || cur.cle !== cle || cur.scale !== env.scale) { if (!monter(lv, env)) return false; }
    var t0 = performance.now(), fiMs = t0 - dernier, dt = Math.min(0.05, fiMs / 1000 || 0); dernier = t0; t += dt;
    if (fiMs > 0 && fiMs < 250) cur.fi = cur.fi * 0.92 + fiMs * 0.08;   /* R454 : intervalle réel entre images */
    var sobre = !!env.RM;   /* fond10 : comme le jeu (R296), le réglage système n'est plus lu */
    if (sobre !== cur.sobre) {
      cur.sobre = sobre;
      var vieP = Math.min(1.5, REGL.vie) * (cur.vieDeg || 1);
      cur.fond.regler({ profondeur: cur.rang / 11, qualite: REGL.qualite, sobre: sobre || !!cur.figeCSS });   /* R454 : palier 6 fige les couches CSS */
      cur.pool.regler({ niveau: cur.rang + 1, vie: vieP, qualite: REGL.qualite, sobre: sobre, courant: 1 });
      if (cur.pool2) cur.pool2.regler({ niveau: cur.rang + 1, vie: vieP, qualite: REGL.qualite, sobre: sobre, courant: 1 });
    }
    var S = env.S, b = S && S.ball, k = env.scale, enJeu = S && S.mode === 'run';
    if (b) { bille.x = b.x * k; bille.y = b.y * k; bille.vx = enJeu ? b.vx * 60 * k : 0; bille.vy = enJeu ? b.vy * 60 * k : 0; }
    c.clearRect(0, 0, env.W, env.H);                // canevas transparent : le fond est dessous, en CSS
    if (cur.fu) { cur.fuDt += dt; if (sobre || (cur.fuN++ % cur.cadFu) === 0) {   /* R454 : toile de fusion à cadence réduite (elle garde son image entre deux tracés) */
      cur.fu.rendre(sobre ? 0 : Math.min(0.15, cur.fuDt), t, b ? { x: b.x, y: b.y, vx: enJeu ? b.vx * 60 : 0, vy: enJeu ? b.vy * 60 : 0 } : null, sobre); cur.fuDt = 0; } }   // anciens retenus (calque « écran » sous le canevas)
    if (!sobre) {
      var v = Math.hypot(bille.vx, bille.vy), en = Math.min(1, 0.25 + v / 500);
      cur.fond.update(dt, b ? { x: bille.x + cur.zone.x, y: bille.y + cur.zone.y } : null);
      cur.pool.update(dt, flow, en, b ? bille : null);
      c.save(); c.scale(1 / k, 1 / k);
      cur.pool.dessiner(c, t, 'arriere'); cur.pool.dessiner(c, t, 'avant');
      if (cur.pool2) {                             // nouveaux éléments en alternance (ex. Mécanique : cadrans ↔ mécanismes anciens)
        var op = 0, ia; for (ia = 0; ia < cur.alt.length; ia++) op = Math.max(op, racine.QXFU.enveloppeCyc(cur.alt[ia], t));
        cur.pool2.update(dt, flow, en, b ? bille : null);
        if (op > 0.004) { if (!cur.wrap) cur.wrap = racine.QXFU.contexteAlpha(c); cur.wrap.mult = op; cur.pool2.dessiner(cur.wrap, t, 'arriere'); cur.pool2.dessiner(cur.wrap, t, 'avant'); cur.wrap.mult = 1; }
      }
      c.restore();
    }
    var ms = performance.now() - t0;
    stats.n++; stats.ms += ms;
    if (!sobre) gouverner(ms, t0 + ms);           // R454 : gouverneur au coût réel (voir gouverner)
    return true;
  }
  function basculer(on) {                         // décor nouveau ↔ d'origine, sans recharger la page
    actifLS = !!on; try { racine.localStorage.setItem('qxfond2', on ? '1' : '0'); } catch (e) {}
    if (!on) demonter();
    return actifLS;
  }
  function vie(x) {                                // richesse du pool (0–3), appliquée au prochain cadre
    REGL.vie = Math.max(0, Math.min(3, +x || 0)); try { racine.localStorage.setItem('qxfond2vie', String(REGL.vie)); } catch (e) {}
    prete = false; demonter();                     // fusion : densités recomposées selon la vie → nouveau montage au prochain cadre
    return REGL.vie;
  }
  racine.QXF2 = { scene: scene, actif: actif, demonter: demonter, basculer: basculer, vie: vie, geoDe: geoDe, noms: NOMS, reglages: REGL,
    get actifLS() { return actifLS; },
    get courant() { return cur; },
    diag: function () { return cur ? { fi: cur.fi, deg: cur.deg, ra: cur.ra || 0, raison: cur.raison, ms: cur.ema, verrou: cur.verrou } : null; },   // R454 : ligne ?diag=1
    evenement: function () { if (cur && cur.fu) cur.fu.evenement(t); },   // aperçu : provoque l'événement rare (Magnétisme)
    mesure: function (raz) { var m = { n: stats.n, ms: stats.n ? stats.ms / stats.n : 0, rebonds: stats.rebonds, nom: cur ? cur.nom : null, degrade: cur ? cur.deg : 0, ema: cur ? cur.ema : 0,
      elements: cur ? cur.pool.noms.concat(cur.pool2 ? cur.pool2.noms.map(function (x) { return '↻' + x; }) : []) : [], anciens: cur && cur.fu ? cur.fu.info() : null };
      if (raz) { stats.n = 0; stats.ms = 0; stats.rebonds = 0; } return m; } };
})(typeof window !== 'undefined' ? window : globalThis);

/* QXVENT — zone de vent du jeu sans chevrons : filets fins portés par le vent (1 px, queue en fondu, tête nette), quatre
   échelles (lointain long et pâle → grain court et vif). Le sens se lit au mouvement et à l'effilement, jamais par une flèche.
   Appelé par engine.js à la place des chevrons quand le nouveau décor est actif. (c, w=[x,y,l,h,fx,fy], t, sobre, couleur) */
(function (racine) {
  function h(n) { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); }
  var LEN = [52, 34, 24, 11], VIT = [0.7, 1.1, 1.5, 2.3], AMP = [3.2, 2.2, 1.6, 0.8], ACL = [0.3, 0.5, 0.62, 0.9], ABD = [0.1, 0.28, 0.58, 1];
  racine.QXVENT = function (c, w, t, sobre, col, tirets) {   // tirets : zone de gravité (bord pointillé), mêmes filets, sens = celui de la pesanteur locale
    var x0 = w[0], y0 = w[1], L = w[2], H = w[3], hor = Math.abs(w[4]) > Math.abs(w[5]), sg = hor ? (w[4] > 0 ? 1 : -1) : (w[5] > 0 ? 1 : -1);
    var lon = hor ? L : H, lar = hor ? H : L, n = Math.max(8, Math.min(72, Math.round(lon * lar / 760))), d = sobre ? 0 : t * 1.5, cl, b, k;
    function pt(pos, lat, premier) { var x = hor ? (sg > 0 ? x0 + pos : x0 + L - pos) : x0 + lat, y = hor ? y0 + lat : (sg > 0 ? y0 + pos : y0 + H - pos); if (premier) c.moveTo(x, y); else c.lineTo(x, y); }
    c.save(); c.lineCap = 'round'; c.lineJoin = 'round';
    c.globalAlpha = 0.055; c.fillStyle = col; c.fillRect(x0, y0, L, H);
    c.globalAlpha = tirets ? 0.34 : 0.24; c.strokeStyle = col; c.lineWidth = 1; if (tirets) c.setLineDash([3, 4]); c.strokeRect(x0 + 0.5, y0 + 0.5, L - 1, H - 1); if (tirets) c.setLineDash([]);
    for (cl = 0; cl < 4; cl++) for (b = 0; b < 4; b++) {
      c.globalAlpha = ACL[cl] * ABD[b]; c.lineWidth = cl === 0 ? 0.8 : 1; c.beginPath();
      for (k = cl; k < n; k += 4) {
        var g = k * 7.31 + x0 * 0.013 + y0 * 0.017, len = LEN[cl] * (0.7 + 0.6 * h(g)), v = VIT[cl] * (0.8 + 0.4 * h(g + 1));
        var lat = 5 + (lar - 10) * (0.5 * h(g + 2) + 0.5 * ((k + 0.5) / n)), s = ((h(g + 3) * (lon + len) + d * v) % (lon + len)) - len;
        var p0 = s + len * b / 4, p1 = s + len * (b + 1) / 4; if (p1 < 0 || p0 > lon) continue; if (p0 < 0) p0 = 0; if (p1 > lon) p1 = lon;
        pt(p0, lat + AMP[cl] * Math.sin(p0 * 0.05 + g), true); pt((p0 + p1) / 2, lat + AMP[cl] * Math.sin((p0 + p1) * 0.025 + g)); pt(p1, lat + AMP[cl] * Math.sin(p1 * 0.05 + g));
        if (b === 3 && cl > 1 && p1 < lon) { var hx = hor ? (sg > 0 ? x0 + p1 : x0 + L - p1) : x0 + lat + AMP[cl] * Math.sin(p1 * 0.05 + g), hy = hor ? y0 + lat + AMP[cl] * Math.sin(p1 * 0.05 + g) : (sg > 0 ? y0 + p1 : y0 + H - p1); c.rect(hx - 0.6, hy - 0.6, 1.2, 1.2); }
      }
      c.stroke();
    }
    c.restore();
  };
})(typeof window !== 'undefined' ? window : this);
