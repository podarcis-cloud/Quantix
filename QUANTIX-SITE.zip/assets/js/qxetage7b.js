/* ===== CHOEUR DEBUT ===== R507 · Monde 7 — étage 7 des créatures actives : le CHŒUR (seconde créature ; l'autre est la Culbute)
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage6.js :
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Sans Chœur dans le niveau, l'enveloppe appelle l'original et s'arrête là :
     trajectoires strictement inchangées.
   · RENDU : window.QXE6.choeur(...) — appelé par le crochet ÉTAGE 6 de qxcrea.js (dessinerAct, racine.QXE6[c.t]).
   choeur (CHŒUR, colonie de cellules bioluminescentes) : une chaîne de n cellules liées, ancrée par sa tête en (x,y), orientée a
          (degrés), longue de L. Elle ondule en permanence (onde MENÉE PAR LA TÊTE : sw px, pulsation w, phase ph) et parle en lumière
          (vague de lueur tête → queue). Quand la particule entre dans son couloir (à moins de r px de la chaîne), le Chœur la GUIDE
          sans la saisir : la pesanteur est compensée (part cg), l'écart à la chaîne est doucement rappelé (kc) et la particule est
          poussée le long de la colonie (accélération k, jusqu'à vmax) ; au bout de la queue, elle continue seule avec sa vitesse.
          Effet neuf : un COULOIR VIVANT — une route courbe et lente que la particule suit, au lieu d'une prise ou d'un rebond.
   Tout est fonction de S.frames et de la bille (jamais du hasard ni de l'horloge) : solutions et rejeux exacts. */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7b) return;
F.e7b = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'choeur'); CACHE.set(cr, v); } return v; }
// point de la chaîne à l'abscisse s (0 = tête, 1 = queue) ; l'onde part de la tête, son amplitude croît vers la queue
function chPt(e, t, s, o) {
  const a = (e.a || 0) * D2R, ux = Math.cos(a), uy = Math.sin(a), L = e.L || 160, w = e.w || .021, sw = e.sw == null ? 9 : e.sw;
  const ond = sw * (.25 + .75 * s) * Math.sin(w * t - 2.4 * s + (e.ph || 0)) + sw * .3 * Math.sin(w * .43 * t + 1.7 + (e.ph || 0));
  o = o || [0, 0]; o[0] = e.x + ux * L * s - uy * ond; o[1] = e.y + uy * L * s + ux * ond; return o;
}
F.e7Pt = chPt;
F.crPos = function (e, t) { return e.t === 'choeur' ? chPt(e, t, .5) : oPos(e, t); };
const P = [0, 0];
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  oForce(b, sub, lv, g);
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'choeur') continue;
    let st = cs[i]; if (!st || t <= 1) st = cs[i] = { on: -999, s: 0, n: 0 };
    const a = (e.a || 0) * D2R, ux = Math.cos(a), uy = Math.sin(a), L = e.L || 160;
    const s = ((b.x - e.x) * ux + (b.y - e.y) * uy) / L;
    if (s < -.04 || s > 1) continue;
    chPt(e, t, Math.max(0, s), P);
    const dx = b.x - P[0], dy = b.y - P[1], d = -dx * uy + dy * ux;   // écart signé à la chaîne (perpendiculaire)
    if (Math.abs(d) > (e.r || 34)) continue;
    // guidage : compense la pesanteur, rappelle vers la chaîne, pousse le long de la colonie
    b.vy -= (e.cg == null ? .92 : e.cg) * gg / sub;
    const vp = -b.vx * uy + b.vy * ux, va = b.vx * ux + b.vy * uy, kc = e.kc == null ? .012 : e.kc;
    const dp = -d * kc / sub - vp * ((e.kd == null ? .05 : e.kd) / sub);
    const k = e.k == null ? .05 : e.k, vmax = e.vmax == null ? 2.6 : e.vmax, da = va < vmax ? Math.min(k / sub, vmax - va) : -(va - vmax) * .03 / sub;
    b.vx += -uy * dp + ux * da; b.vy += ux * dp + uy * da;
    if (st.af !== t) { st.af = t; if (st.on !== t - 1) st.n++; st.on = t; st.s = s; }
  }
};

/* ---------- RENDU (atlas pré-calculé : cellule épaisse éclairée, membrane, noyau, soies ; halo) ---------- */
let ATL = null;
function atlas() {
  if (ATL) return ATL;
  const N = 96, mk = () => { const c = document.createElement('canvas'); c.width = c.height = N; return c; };
  const cel = mk(), g = cel.getContext('2d'), m = N / 2, R = N * .3;
  // soies : fines, irrégulières (fonction de l'indice), avant le corps
  g.lineCap = 'round';
  for (let i = 0; i < 46; i++) {
    const an = i / 46 * Math.PI * 2 + Math.sin(i * 2.3) * .05, l = R * (.22 + .16 * (.5 + .5 * Math.sin(i * 1.7))), cu = Math.sin(i * .9) * .25;
    g.strokeStyle = 'rgba(170,240,230,' + (.18 + .12 * (.5 + .5 * Math.sin(i * 3.1))) + ')'; g.lineWidth = .9;
    g.beginPath(); g.moveTo(m + Math.cos(an) * R * .96, m + Math.sin(an) * R * .96);
    g.quadraticCurveTo(m + Math.cos(an + cu * .3) * (R + l * .6), m + Math.sin(an + cu * .3) * (R + l * .6), m + Math.cos(an + cu) * (R + l), m + Math.sin(an + cu) * (R + l)); g.stroke();
  }
  // corps sphérique : ombre propre en bas à droite, lumière en haut à gauche
  let gr = g.createRadialGradient(m - R * .38, m - R * .42, R * .1, m, m, R);
  gr.addColorStop(0, 'rgba(214,255,246,.96)'); gr.addColorStop(.35, 'rgba(96,214,206,.9)'); gr.addColorStop(.78, 'rgba(30,112,128,.92)'); gr.addColorStop(1, 'rgba(12,46,64,.95)');
  g.fillStyle = gr; g.beginPath(); g.arc(m, m, R, 0, Math.PI * 2); g.fill();
  // nervures de membrane (méridiens courbes)
  g.save(); g.beginPath(); g.arc(m, m, R, 0, Math.PI * 2); g.clip();
  g.strokeStyle = 'rgba(200,255,245,.16)'; g.lineWidth = 1;
  for (let i = -2; i <= 2; i++) { g.beginPath(); g.ellipse(m, m, R * (.25 + Math.abs(i) * .18), R, .5, 0, Math.PI * 2); g.stroke(); }
  // noyau translucide, décalé
  gr = g.createRadialGradient(m + R * .12, m + R * .1, 0, m + R * .12, m + R * .1, R * .36);
  gr.addColorStop(0, 'rgba(240,255,210,.85)'); gr.addColorStop(.6, 'rgba(150,230,180,.35)'); gr.addColorStop(1, 'rgba(150,230,180,0)');
  g.fillStyle = gr; g.fillRect(0, 0, N, N);
  g.restore();
  // liseré de membrane + reflet
  g.strokeStyle = 'rgba(180,250,240,.55)'; g.lineWidth = 1.4; g.beginPath(); g.arc(m, m, R - .7, 0, Math.PI * 2); g.stroke();
  g.fillStyle = 'rgba(255,255,255,.55)'; g.beginPath(); g.ellipse(m - R * .4, m - R * .46, R * .2, R * .11, -.6, 0, Math.PI * 2); g.fill();
  // halo de lumière froide
  const hal = mk(), h = hal.getContext('2d'); gr = h.createRadialGradient(m, m, 0, m, m, m);
  gr.addColorStop(0, 'rgba(120,255,225,.55)'); gr.addColorStop(.35, 'rgba(70,210,200,.22)'); gr.addColorStop(1, 'rgba(40,160,180,0)');
  h.fillStyle = gr; h.fillRect(0, 0, N, N);
  return (ATL = { cel, hal, N, R });
}
/* R513 · RENDU REFAIT (Simon : « rangée de perles ») : un CORPS CONTINU — manteau translucide épais, effilé de la tête vers la queue,
   qui ondule avec la chaîne (onde menée par la tête) et respire par une onde de constriction ; les cellules sont FONDUES dedans
   (organites vus par transparence, sans contour propre), soies métachronales sur les bords, lumière froide qui parcourt le corps.
   Aucun changement de physique : mêmes points chPt (S.frames). */
const M = 22, Q = [], NX = new Float32Array(M + 1), NY = new Float32Array(M + 1), W = new Float32Array(M + 1);
function dessinerChoeur(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, A = atlas(), n = c.n || 7, s0 = c.sz || 1, t = fr, P2 = racine.FLUID.e7Pt;
  st = run && st ? st : {};
  const actif = run && st.on != null && fr - st.on < 3, rec = run && st.on != null && fr >= st.on ? Math.max(0, 1 - (fr - st.on) / 90) : 0;
  e.ac = (e.ac || 0) + ((actif ? 1 : 0) - (e.ac || 0)) * Math.min(1, dt * 2.2);   // montée lente de la voix lumineuse
  const ac = e.ac, vit = .045 + .03 * ac;
  for (let k = 0; k <= M; k++) { const s = k / M, p = Q[k] || (Q[k] = [0, 0]); P2(c, t, s, p);
    const ond = 1 + .09 * Math.sin(.05 * t - 7 * s);                                     // constriction qui descend le corps
    W[k] = s0 * (2 + 13.5 * Math.pow(Math.sin(Math.PI * Math.min(1, .3 + s * .8)), .55) * (1 - .5 * s)) * ond; }
  for (let k = 0; k <= M; k++) { const a = Q[Math.max(0, k - 1)], z = Q[Math.min(M, k + 1)], tx = z[0] - a[0], ty = z[1] - a[1], l = Math.hypot(tx, ty) || 1; NX[k] = -ty / l; NY[k] = tx / l; }
  const ax = (c.a || 0) * D2R, ux = Math.cos(ax), uy = Math.sin(ax);
  const sd = ux > 0 ? -1 : 1;   // côté « haut » (vers la lumière) : normale dont la composante y est négative
  const contour = (f) => { ctx.beginPath(); const h = Q[0], w0 = W[0] * f; ctx.moveTo(h[0] - NX[0] * w0, h[1] - NY[0] * w0);
    ctx.quadraticCurveTo(h[0] - ux * w0 * 1.9, h[1] - uy * w0 * 1.9, h[0] + NX[0] * w0, h[1] + NY[0] * w0);   // tête arrondie
    for (let k = 0; k <= M; k++) ctx.lineTo(Q[k][0] + NX[k] * W[k] * f, Q[k][1] + NY[k] * W[k] * f);
    for (let k = M; k >= 0; k--) ctx.lineTo(Q[k][0] - NX[k] * W[k] * f, Q[k][1] - NY[k] * W[k] * f); ctx.closePath(); };
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  // halo froid le long du corps (lueur qui court de la tête vers la queue)
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < n; i++) { const s = i / (n - 1), k = Math.round(s * M), wv = Math.pow(Math.max(0, Math.sin(vit * t - 3.2 * s)), 3);
    const l = .16 + .3 * wv + .4 * ac * (.4 + .6 * wv) + .3 * rec * Math.max(0, 1 - Math.abs(s - (st.s || 0)) * 3); if (l < .2) continue;
    const hs = (24 + 14 * l) * s0 * (1.1 - .35 * s); ctx.globalAlpha = Math.min(1, l); ctx.drawImage(A.hal, Q[k][0] - hs, Q[k][1] - hs, hs * 2, hs * 2); }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  // soies métachronales sur les deux bords (une seule passe)
  ctx.beginPath();
  for (let k = 2; k < M; k++) for (const sg of [-1, 1]) {
    const bx = Q[k][0] + NX[k] * W[k] * sg, by = Q[k][1] + NY[k] * W[k] * sg, ph = .09 * t - k * .5, Ls = (4.5 + 1.5 * Math.sin(k * 1.7)) * s0, sw = 2.6 * Math.sin(ph) * s0;
    const tx = NY[k] * sg * -1, ty = NX[k] * sg;
    ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + NX[k] * sg * Ls * .55, by + NY[k] * sg * Ls * .55, bx + NX[k] * sg * Ls + tx * sw * sg, by + NY[k] * sg * Ls + ty * sw * sg); }
  ctx.strokeStyle = 'rgba(170,240,230,.32)'; ctx.lineWidth = .7; ctx.stroke();
  // manteau : volume de cylindre (bords sombres, bande claire du côté lumière), translucide
  const mx = Q[M >> 1][0], my = Q[M >> 1][1], wm = W[M >> 2] * 1.1, gx = -uy * wm, gy = ux * wm;
  const gr = ctx.createLinearGradient(mx + gx * sd, my + gy * sd, mx - gx * sd, my - gy * sd);
  gr.addColorStop(0, 'rgba(10,42,60,.72)'); gr.addColorStop(.3, 'rgba(70,190,190,.62)'); gr.addColorStop(.5, 'rgba(150,240,226,.55)');
  gr.addColorStop(.75, 'rgba(40,130,150,.6)'); gr.addColorStop(1, 'rgba(8,34,54,.78)');
  contour(1); ctx.fillStyle = gr; ctx.fill();
  // cellules fondues dans le manteau (organites translucides, sans contour), constrictions douces, noyaux qui s'allument
  for (let i = n - 1; i >= 0; i--) { const s = i / (n - 1), k = Math.round(s * M), br = 1 + .06 * Math.sin(.05 * t - 2.1 * s), rr = W[k] * .92 * br, sz = rr / A.R * A.N;
    ctx.globalAlpha = .42; ctx.drawImage(A.cel, Q[k][0] - sz / 2, Q[k][1] - sz / 2, sz, sz); }
  ctx.globalAlpha = 1; ctx.beginPath();
  for (let i = 0; i < n - 1; i++) { const k = Math.round((i + .5) / (n - 1) * M), w = W[k] * .9;
    ctx.moveTo(Q[k][0] + NX[k] * w, Q[k][1] + NY[k] * w); ctx.quadraticCurveTo(Q[k][0] + ux * 3 * s0, Q[k][1] + uy * 3 * s0, Q[k][0] - NX[k] * w, Q[k][1] - NY[k] * w); }
  ctx.strokeStyle = 'rgba(200,255,245,.13)'; ctx.lineWidth = 1.6 * s0; ctx.stroke();
  // liseré de membrane et reflet continu du côté lumière
  contour(1); ctx.strokeStyle = 'rgba(190,252,242,.5)'; ctx.lineWidth = 1.1; ctx.stroke();
  ctx.beginPath(); for (let k = 1; k < M - 4; k++) { const x2 = Q[k][0] + NX[k] * W[k] * .55 * sd, y2 = Q[k][1] + NY[k] * W[k] * .55 * sd; k > 1 ? ctx.lineTo(x2, y2) : ctx.moveTo(x2, y2); }
  ctx.strokeStyle = 'rgba(240,255,252,.38)'; ctx.lineWidth = 1.8 * s0; ctx.stroke();
  // tête : bouche ciliée lumineuse
  ctx.fillStyle = 'rgba(230,255,248,.85)'; ctx.beginPath(); ctx.arc(Q[1][0] - ux * W[1] * .45, Q[1][1] - uy * W[1] * .45, 1.4 * s0, 0, 7); ctx.fill();
  ctx.restore();
}
racine.QXE6 = racine.QXE6 || {};
racine.QXE6.choeur = dessinerChoeur;
/* R513 · préchauffage accroché depuis ce fichier (qxcrea.js intact) : l'atlas du Chœur se fabrique au chargement du niveau, pas au premier dessin */
function accroche() {
  const ll = racine.loadLevel; if (typeof ll !== 'function' || ll.e7b) return;
  const w = racine.loadLevel = function (i) { const r = ll.apply(this, arguments);
    try { const lv = racine.LEVELS && racine.LEVELS[i]; if (lv && lv.cr && lv.cr.some(c => c.t === 'choeur')) (racine.requestAnimationFrame || setTimeout)(atlas); } catch (e) {} return r; };
  w.e7b = 1;
}
if (typeof document !== 'undefined') { if (document.readyState === 'complete') accroche(); else racine.addEventListener('load', accroche); }
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== CHOEUR FIN ===== */
