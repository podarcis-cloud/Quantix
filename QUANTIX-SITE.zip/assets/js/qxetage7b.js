/* ===== CHOEUR DEBUT ===== R507 · Monde 7 — étage 7 des créatures actives : le CHŒUR (seconde créature ; l'autre est la Culbute)
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage6.js :
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Sans Chœur dans le niveau, l'enveloppe appelle l'original et s'arrête là :
     trajectoires strictement inchangées.
   · RENDU : window.QXE6.choeur(...) — appelé par le crochet ÉTAGE 6 de qxcrea.js (dessinerAct, racine.QXE6[c.t]).
   choeur (CHŒUR, colonie de cellules bioluminescentes) : une chaîne de n cellules liées, ancrée par sa tête en (x,y), orientée a
          (degrés), longue de L. Elle ondule en permanence (onde MENÉE PAR LA TÊTE : sw px, pulsation w, phase ph) et parle en lumière
          (vague de lueur tête → queue). Quand la particule entre dans son couloir (à moins de r px de la chaîne), le Chœur la GUIDE
          sans la saisir : la pesanteur est compensée (part cg), l'écart à la chaîne est doucement rappelé (kc) et la particule est
          poussée le long de la colonie (accélération k, jusqu'à vmax) ; au bout de la queue, elle continue seule avec sa vitesse.
          Effet neuf : un COULOIR VIVANT — une route courbe et lente que la particule suit, au lieu d'une prise ou d'un rebond.
   Tout est fonction de S.frames et de la bille (jamais du hasard ni de l'horloge) : solutions et rejeux exacts. */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7b) return;
F.e7b = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'choeur'); CACHE.set(cr, v); } return v; }
// point de la chaîne à l'abscisse s (0 = tête, 1 = queue) ; l'onde part de la tête, son amplitude croît vers la queue
function chPt(e, t, s, o) {
  const a = (e.a || 0) * D2R, ux = Math.cos(a), uy = Math.sin(a), L = e.L || 160, w = e.w || .021, sw = e.sw == null ? 9 : e.sw;
  const ond = sw * (.25 + .75 * s) * Math.sin(w * t - 2.4 * s + (e.ph || 0)) + sw * .3 * Math.sin(w * .43 * t + 1.7 + (e.ph || 0));
  o = o || [0, 0]; o[0] = e.x + ux * L * s - uy * ond; o[1] = e.y + uy * L * s + ux * ond; return o;
}
F.e7Pt = chPt;
F.crPos = function (e, t) { return e.t === 'choeur' ? chPt(e, t, .5) : oPos(e, t); };
const P = [0, 0];
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  oForce(b, sub, lv, g);
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'choeur') continue;
    let st = cs[i]; if (!st || t <= 1) st = cs[i] = { on: -999, s: 0, n: 0 };
    const a = (e.a || 0) * D2R, ux = Math.cos(a), uy = Math.sin(a), L = e.L || 160;
    const s = ((b.x - e.x) * ux + (b.y - e.y) * uy) / L;
    if (s < -.04 || s > 1) continue;
    chPt(e, t, Math.max(0, s), P);
    const dx = b.x - P[0], dy = b.y - P[1], d = -dx * uy + dy * ux;   // écart signé à la chaîne (perpendiculaire)
    if (Math.abs(d) > (e.r || 34)) continue;
    // guidage : compense la pesanteur, rappelle vers la chaîne, pousse le long de la colonie
    b.vy -= (e.cg == null ? .92 : e.cg) * gg / sub;
    const vp = -b.vx * uy + b.vy * ux, va = b.vx * ux + b.vy * uy, kc = e.kc == null ? .012 : e.kc;
    const dp = -d * kc / sub - vp * ((e.kd == null ? .05 : e.kd) / sub);
    const k = e.k == null ? .05 : e.k, vmax = e.vmax == null ? 2.6 : e.vmax, da = va < vmax ? Math.min(k / sub, vmax - va) : -(va - vmax) * .03 / sub;
    b.vx += -uy * dp + ux * da; b.vy += ux * dp + uy * da;
    if (st.af !== t) { st.af = t; if (st.on !== t - 1) st.n++; st.on = t; st.s = s; }
  }
};

/* ---------- RENDU R521 (refonte complète, physique inchangée) ----------
   Simon (R519) : « trop transparente », « hors charte ». Le Chœur reprend le langage du Chœur des figurants (qxcrea.js creerChoeur) :
   palette perle / aqua / sarcelle / lueur, cellules elliptiques à double membrane fine, noyau et vacuole, cils métachronaux, fils nacrés ;
   ici fondues dans UN corps continu (colonie en ruban) : manteau à plusieurs couches (sous-couche sombre qui absorbe le décor, chair
   sarcelle en volume de cylindre, voile perle opalin, liseré interne, contre-jour), cellules vues par transparence (noyau, vacuole,
   nervures de jonction), grain fin, nervures longitudinales, canal lumineux.
   · ATLAS : la colonie droite est peinte UNE fois dans une texture (par tranches au chargement du niveau, ≤ 2 ms par image),
     puis posée tranche par tranche le long de la chaîne chPt (strip-warp, 18 drawImage) : courbes continues, aucune pièce visible.
   · VIVANT (par image, léger) : halo doux bicouche, cils des bords et couronne de la tête (onde métachronale), constriction qui descend
     le corps, bioluminescence des noyaux qui voyage de la tête à la queue, perle qui court dans le canal ; tout s'intensifie à l'approche
     (e.ex) et pendant le guidage (st.on), la lumière suit la particule le long des cellules.
   · ATTENTE ACTIVE : avant le lâcher, l'onde suit une horloge de rendu (S.frames est figé) ; au lâcher / au retour, la phase rejoint
     en douceur celle de la physique (jamais d'onde à rebours, accélération bornée) : forme et lumière continues. */
const TAU = Math.PI * 2;
const PAL = { perle: [214, 230, 232], aqua: [118, 200, 196], sarc: [46, 120, 128], lueur: [110, 238, 196], abysse: [4, 10, 18], lilas: [186, 166, 255] };
const rgba = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
const hs = i => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const sst = u => u <= 0 ? 0 : u >= 1 ? 1 : u * u * u * (u * (u * 6 - 15) + 10);
const TPX = 3, HWM = 12.5, MG = 2;   // texture : 3 px par unité, demi-largeur max 12,5 unités, marge
function cvs(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }
/* demi-largeur (facteur 0..1) : tête pleine et arrondie, ventre en avant, effilement doux vers la queue, jonctions de cellules à peine pincées */
function prof(s, n) {
  const f = s < .16 ? .84 + .16 * Math.sin(Math.PI / 2 * s / .16) : .17 + .83 * Math.pow(Math.cos(Math.PI / 2 * (s - .16) / .84), .85);
  return f * (1 - .055 * Math.pow(Math.cos(Math.PI * s * n), 10) * (s > .03 && s < .97 ? 1 : 0));
}
const TX = {};   // textures par (L, n, sz)
let SPR = null;
function sprites() {
  if (SPR) return SPR;
  const mk = (stops) => { const s = 64, c = cvs(s, s), g = c.getContext('2d'), r = g.createRadialGradient(32, 32, 0, 32, 32, 32); stops.forEach(t => r.addColorStop(t[0], t[1])); g.fillStyle = r; g.fillRect(0, 0, s, s); return c; };
  SPR = {
    hal: mk([[0, rgba(PAL.aqua, .5)], [.3, rgba(PAL.aqua, .22)], [.65, rgba(PAL.sarc, .07)], [1, rgba(PAL.sarc, 0)]]),          // halo froid
    voi: mk([[0, rgba([196, 200, 240], .26)], [.45, rgba([150, 160, 226], .09)], [1, rgba([120, 120, 210], 0)]]),             // voile opalin large (lilas froid du monde)
    pho: mk([[0, 'rgba(236,255,248,1)'], [.1, rgba(PAL.lueur, .95)], [.3, rgba(PAL.lueur, .3)], [.62, rgba(PAL.lueur, .06)], [1, rgba(PAL.lueur, 0)]]),   // photophore
    per: mk([[0, rgba(PAL.perle, .9)], [.22, rgba(PAL.perle, .35)], [.6, rgba(PAL.aqua, .06)], [1, rgba(PAL.aqua, 0)]])
  };
  return SPR;
}
/* coupe transversale du manteau (haut = côté lumière) : liseré, voile opalin, bande claire, chair sarcelle, ombre propre, contre-jour */
function coupe() {
  const c = cvs(1, 256), g = c.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256);
  [[0, 'rgba(214,230,232,0)'], [.025, 'rgba(232,244,246,.74)'], [.06, 'rgba(214,218,248,.7)'], [.13, 'rgba(184,230,228,.8)'], [.24, 'rgba(206,240,236,.88)'],
   [.36, 'rgba(146,208,206,.86)'], [.52, 'rgba(100,172,178,.84)'], [.7, 'rgba(70,136,150,.84)'], [.86, 'rgba(46,96,118,.86)'], [.94, 'rgba(74,134,150,.8)'],
   [.975, 'rgba(150,214,210,.62)'], [1, 'rgba(118,200,196,0)']].forEach(t => gr.addColorStop(t[0], t[1]));
  g.fillStyle = gr; g.fillRect(0, 0, 1, 256); return c;
}
/* étapes de fabrication de la texture (chacune ≤ ~2 ms) */
function etapesTex(L, n, sz) {
  const k = L + '|' + n + '|' + sz; if (TX[k]) return null;
  const T = TX[k] = { L, n, sz, ok: 0, cv: null, x0: 0, cap: 0, tc: 0, H: 0, nuc: [] };
  const HW = HWM * sz, hw0 = HW * prof(0, n), hw1 = HW * prof(1, n), cap = hw0 * 1.05, tc = hw1 * 1.4;
  T.cap = cap; T.tc = tc; T.x0 = (cap + MG); T.H = HW + MG;
  const Wt = (cap + L + tc + 2 * MG) * TPX, Ht = 2 * (HW + MG) * TPX;
  const hwU = u => u < 0 ? hw0 * Math.sqrt(Math.max(0, 1 - (u / cap) * (u / cap))) : u > L ? hw1 * Math.sqrt(Math.max(0, 1 - ((u - L) / tc) * ((u - L) / tc))) : HW * prof(u / L, n);
  let g = null;
  const unit = () => { g.setTransform(TPX, 0, 0, TPX, T.x0 * TPX, T.H * TPX); };
  const contour = (f) => { g.beginPath(); const N = Math.ceil(cap + L + tc);
    for (let j = 0; j <= N; j++) { const u = -cap + j * (cap + L + tc) / N; j ? g.lineTo(u, -hwU(u) * f) : g.moveTo(u, -hwU(u) * f); }
    for (let j = N; j >= 0; j--) { const u = -cap + j * (cap + L + tc) / N; g.lineTo(u, hwU(u) * f); } g.closePath(); };
  const cel = [];   // cellules : centre s, demi-longueur, noyau (décalage), vacuole
  for (let i = 0; i < n; i++) { const s = (i + .5) / n; cel.push({ s, x: s * L, a: L / n * .5 * .94, h: HW * prof(s, n) * .8, nx: (hs(i * 3.1) - .5) * .5, ny: -.18 + (hs(i * 5.7) - .5) * .3, vx: (hs(i * 7.3) - .5) * .9, vy: .25 + .2 * hs(i * 2.9) }); }
  T.nuc = cel.map(q => ({ s: Math.min(1, Math.max(0, (q.x + q.nx * q.a) / L)), y: q.ny * q.h }));
  return [
    () => { T.cv = cvs(Wt, Ht); g = T.cv.getContext('2d'); g.lineCap = 'round'; g.lineJoin = 'round';
      /* 1. sous-couche sombre (absorbe le décor : la colonie se détache même sur un fond clair) */
      unit(); contour(1.02); g.fillStyle = 'rgba(6,18,30,.32)'; g.fill();
      T.cp = coupe(); },
    /* 2. chair en volume (coupe étirée colonne par colonne : le modelé suit l'effilement), en 4 tranches */
    ...[0, 1, 2, 3].map(q => () => { g.setTransform(1, 0, 0, 1, 0, 0);
      for (let px = Math.floor(Wt * q / 4); px < Math.floor(Wt * (q + 1) / 4); px++) { const u = px / TPX - T.x0, h = hwU(u); if (h <= .05) continue; g.drawImage(T.cp, 0, 0, 1, 256, px, (T.H - h) * TPX, 1, 2 * h * TPX); } }),
    () => { unit(); contour(1); g.save(); g.clip();
      /* 3. cellules fondues : cytoplasme clair (dégradé radial décalé vers la lumière), double membrane fine, jonctions nervurées */
      for (const q of cel) { g.save(); g.translate(q.x, -q.h * .12); g.scale(q.a, q.h); const r = g.createRadialGradient(-.15, -.3, 0, 0, 0, 1);
        r.addColorStop(0, rgba(PAL.perle, .34)); r.addColorStop(.45, rgba(PAL.aqua, .22)); r.addColorStop(.8, rgba(PAL.aqua, .1)); r.addColorStop(.96, rgba(PAL.perle, .2)); r.addColorStop(1, rgba(PAL.perle, 0));
        g.fillStyle = r; g.beginPath(); g.arc(0, 0, 1, 0, TAU); g.restore(); g.fill(); }
      g.beginPath(); for (const q of cel) g.ellipse(q.x, -q.h * .12, q.a * .97, q.h * .97, 0, 0, TAU);
      g.strokeStyle = rgba(PAL.perle, .08); g.lineWidth = 2.6; g.stroke(); g.strokeStyle = rgba(PAL.perle, .15); g.lineWidth = .45; g.stroke();
      g.beginPath(); for (let i = 1; i < n; i++) { const x = i / n * L, h = HW * prof(i / n, n) * .98; g.moveTo(x - .6, -h); g.bezierCurveTo(x + 1.6, -h * .4, x + 1.6, h * .4, x - .6, h); }
      g.strokeStyle = rgba(PAL.perle, .1); g.lineWidth = 2.2; g.stroke(); g.strokeStyle = rgba(PAL.perle, .26); g.lineWidth = .5; g.stroke();
      /* 4. noyaux (anneau nacré, nucléole) et vacuoles sombres cerclées de perle */
      g.beginPath(); for (const q of cel) { const x = q.x + q.nx * q.a, y = q.ny * q.h, r = Math.min(3.2, q.h * .34); g.moveTo(x + r, y); g.arc(x, y, r, 0, TAU); }
      g.fillStyle = rgba(PAL.aqua, .22); g.fill(); g.strokeStyle = rgba(PAL.perle, .28); g.lineWidth = .45; g.stroke();
      g.beginPath(); for (const q of cel) { const x = q.x + q.vx * q.a, y = q.vy * q.h, r = Math.min(1.7, q.h * .18) * (.8 + .4 * hs(q.s * 99)); g.moveTo(x + r, y); g.arc(x, y, r, 0, TAU); }
      g.fillStyle = rgba(PAL.abysse, .2); g.fill(); g.strokeStyle = rgba(PAL.perle, .3); g.lineWidth = .4; g.stroke();
      g.restore(); },
    () => { unit(); contour(1); g.save(); g.clip();
      /* 5. nervures longitudinales (fibres du manteau) et canal central lumineux */
      g.beginPath(); for (const fz of [-.62, -.3, .34, .66]) { for (let u = 0; u <= L; u += 1.5) { const y = hwU(u) * fz; u ? g.lineTo(u, y) : g.moveTo(u, y); } }
      g.strokeStyle = rgba(PAL.perle, .13); g.lineWidth = .42; g.stroke();
      g.beginPath(); for (let u = -cap * .5; u <= L; u += 1.5) { const y = hwU(u) * .06 * Math.sin(u * .21); u > -cap * .5 ? g.lineTo(u, y) : g.moveTo(u, y); }
      g.strokeStyle = rgba(PAL.lueur, .12); g.lineWidth = 2.4; g.stroke(); g.strokeStyle = rgba(PAL.lueur, .34); g.lineWidth = .6; g.stroke();
      /* 6. grain interne fin */
      g.beginPath(); for (let j = 0; j < 340; j++) { const u = -cap + hs(j * 1.31) * (cap + L), h = hwU(u), y = (hs(j * 2.77) * 2 - 1) * h * .9, r = .18 + .26 * hs(j * 4.1); g.moveTo(u + r, y); g.arc(u, y, r, 0, TAU); }
      g.fillStyle = rgba(PAL.perle, .2); g.fill();
      /* 7. reflet doux du côté lumière (bande continue, s'éteint vers la queue) */
      const rf = g.createLinearGradient(-cap, 0, L * .75, 0); rf.addColorStop(0, 'rgba(250,255,255,.0)'); rf.addColorStop(.12, 'rgba(250,255,255,.4)'); rf.addColorStop(.55, 'rgba(240,252,255,.22)'); rf.addColorStop(1, 'rgba(240,252,255,0)');
      g.beginPath(); for (let u = -cap * .6; u <= L * .75; u += 1.5) { const y = -hwU(u) * .66; u > -cap * .6 ? g.lineTo(u, y) : g.moveTo(u, y); }
      g.strokeStyle = rf; g.lineWidth = 1.7; g.stroke(); g.lineWidth = .6; g.strokeStyle = 'rgba(255,255,255,.2)'; g.stroke();
      g.restore();
      /* 8. bord : trois passes (halo, liseré moyen, fil nacré) — doux, jamais un contour dur */
      contour(1); g.strokeStyle = rgba(PAL.aqua, .1); g.lineWidth = 2.6; g.stroke(); g.strokeStyle = rgba(PAL.perle, .22); g.lineWidth = 1.1; g.stroke(); g.strokeStyle = rgba(PAL.perle, .55); g.lineWidth = .45; g.stroke();
      /* 9. tête : sillon buccal (lèvre nacrée) et deux ocelles */
      g.beginPath(); g.ellipse(-cap * .55, 0, cap * .32, hw0 * .5, 0, -1.3, 1.3); g.strokeStyle = rgba(PAL.perle, .5); g.lineWidth = .6; g.stroke();
      g.fillStyle = rgba(PAL.perle, .85); g.beginPath(); g.arc(-cap * .3, -hw0 * .42, .75, 0, TAU); g.arc(-cap * .3, hw0 * .38, .65, 0, TAU); g.fill();
      g.setTransform(1, 0, 0, 1, 0, 0); },
    () => { const z = cvs(2, 2).getContext('2d'), S2 = sprites(); z.drawImage(T.cv, 0, 0, 2, 2); for (const k in S2) z.drawImage(S2[k], 0, 0, 2, 2); T.ok = 1; }   // envoi au GPU avant le premier dessin
  ];
}
let FILE = [], PRE = 0;
function prechauffe(lv) {
  sprites();
  for (const c of (lv && lv.cr) || []) if (c.t === 'choeur') { const q = etapesTex(c.L || 160, Math.max(5, Math.min(12, c.n || 8)), c.sz || 1); if (q) FILE.push(...q); }
  if (PRE) return; PRE = 1;
  const pas = () => { const t0 = performance.now(); while (FILE.length && performance.now() - t0 < 2) FILE.shift()();
    if (FILE.length) (racine.requestAnimationFrame || setTimeout)(pas); else PRE = 0; };
  pas();
}
function texture(c) {
  const L = c.L || 160, n = Math.max(5, Math.min(12, c.n || 8)), sz = c.sz || 1, k = L + '|' + n + '|' + sz;
  let T = TX[k]; if (!T) { etapesTex(L, n, sz).forEach(f => f()); T = TX[k]; }
  else if (!T.ok) { while (FILE.length && !T.ok) FILE.shift()(); }
  return T;
}
const wrap = a => a - Math.round(a / TAU) * TAU;
/* point de la chaîne pour des phases données (même formule que chPt : th1 = w·t + ph, th2 = 0,43·w·t + 1,7 + ph) */
function chR(e, th1, th2, s, o) {
  const a = (e.a || 0) * D2R, ux = Math.cos(a), uy = Math.sin(a), L = e.L || 160, sw = e.sw == null ? 9 : e.sw;
  const ond = sw * (.25 + .75 * s) * Math.sin(th1 - 2.4 * s) + sw * .3 * Math.sin(th2);
  o[0] = e.x + ux * L * s - uy * ond; o[1] = e.y + uy * L * s + ux * ond; return o;
}
const M = 16, QX = new Float32Array(M + 2), QY = new Float32Array(M + 2), TXn = new Float32Array(M + 2), TYn = new Float32Array(M + 2), KW = new Float32Array(M + 2), PT = [0, 0];
/* phase affichée : horloge d'attente (rendu) avant le lâcher, phase physique ensuite ; raccord sans onde à rebours */
function phases(e, c, run, fr, dt) {   // état à plat dans e (champs c7*) : la mesure à blanc du raccord C1 (copie superficielle de e) le restaure
  const w = c.w || .021, ph = c.ph || 0;
  if (e.c7tw == null) { e.c7tw = 0; e.c7md = -1; e.c7fr = 0; e.c7d1 = 0; e.c7d2 = 0; e.c7k = 1; e.c7dur = 1; e.c7l1 = 0; e.c7l2 = 0; }
  if (!run) e.c7tw += dt * 60;
  const t = run ? fr : e.c7tw, p1 = w * t + ph, p2 = .43 * w * t + 1.7 + ph;
  const md = run ? 1 : 0, saut = e.c7md !== -1 && (e.c7md !== md || (run && (fr < e.c7fr || fr - e.c7fr > 8)));
  if (saut) {   // la forme affichée devient la référence ; on rejoint la nouvelle phase en avançant plus vite (jamais à rebours)
    let d1 = wrap(e.c7l1 - p1), d2 = wrap(e.c7l2 - p2); if (d1 > 1e-6) d1 -= TAU; if (d2 > 1e-6) d2 -= TAU;
    const r1 = w * 60, r2 = .43 * w * 60;
    e.c7d1 = d1; e.c7d2 = d2; e.c7k = 0; e.c7dur = Math.max(1.2, -d1 * 1.875 / (1.6 * r1), -d2 * 1.875 / (1.6 * r2));
  }
  if (e.c7k < 1 && dt > 0) e.c7k = Math.min(1, e.c7k + dt / e.c7dur);
  const f = 1 - sst(e.c7k), th1 = p1 + e.c7d1 * f, th2 = p2 + e.c7d2 * f;
  e.c7md = md; e.c7fr = fr; e.c7l1 = th1; e.c7l2 = th2;
  return [th1, th2];
}
function dessinerChoeur(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, S2 = sprites(), n = Math.max(5, Math.min(12, c.n || 8)), s0 = c.sz || 1, L = c.L || 160;
  if (!TX[L + '|' + n + '|' + s0]) prechauffe({ cr: [c] });
  const X = TX[L + '|' + n + '|' + s0];
  if (!X.ok) { if (FILE.length && dt > 0) FILE.shift()(); if (!X.ok) return; }   // texture en cours (≤ 2 ms par image) : la colonie apparaît dès qu'elle est prête
  e.c7in = Math.min(1, (e.c7in || 0) + dt * 2.5);                                  // apparition douce (0,4 s), jamais un pop
  st = run && st ? st : {};
  const th = phases(e, c, run, fr, dt);
  const actif = run && st.on != null && fr - st.on < 3, rec = run && st.on != null && fr >= st.on ? Math.max(0, 1 - (fr - st.on) / 90) : 0;
  const ka = Math.min(1, dt * 2.2);
  e.c7ac = (e.c7ac || 0) + ((actif ? 1 : 0) - (e.c7ac || 0)) * ka;              // la voix lumineuse monte lentement pendant le guidage
  e.c7ap = (e.c7ap || 0) + ((e.ex || 0) - (e.c7ap || 0)) * ka;                   // approche (excitation calculée par dessinerAct)
  e.c7sg = e.c7sg == null ? .5 : e.c7sg + ((st.s != null && rec > 0 ? st.s : e.c7sg) - e.c7sg) * Math.min(1, dt * 5);   // où la particule est guidée
  e.c7lt = (e.c7lt || 0) + dt * (.55 + .5 * e.c7ac);                             // horloge de la lumière (voyage tête → queue)
  const ac = e.c7ac, ap = e.c7ap, lt = e.c7lt, sg = e.c7sg, Tc = T;
  /* chaîne : tête (s = 0) → queue ; point d'extrapolation pour la calotte de la tête et la pointe de la queue */
  for (let k = 0; k <= M; k++) { chR(c, th[0], th[1], k / M, PT); QX[k] = PT[0]; QY[k] = PT[1]; }
  for (let k = 0; k <= M; k++) { const a = Math.max(0, k - 1), z = Math.min(M, k + 1), tx = QX[z] - QX[a], ty = QY[z] - QY[a], l = Math.hypot(tx, ty) || 1; TXn[k] = tx / l; TYn[k] = ty / l;
    KW[k] = 1 + .07 * Math.sin(3 * T - 7 * k / M) * (k / M); }   // constriction qui descend le corps
  const fl = TXn[M >> 1] >= 0 ? 1 : -1;   // côté lumière toujours vers le haut de l'écran (jamais en miroir à l'envers)
  const nx = k => -TYn[k] * fl, ny = k => TXn[k] * fl;   // normale « bas » de la texture
  const HW = HWM * s0, bx = b && run ? b.x : 1e9, by = b && run ? b.y : 1e9;
  const lum = .5 + .45 * ap + .5 * ac;
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; const IN = sst(e.c7in);
  /* 1. halo doux bicouche (voile opalin large + halo froid serré), plus fort là où la lumière passe et autour de la particule guidée */
  ctx.globalCompositeOperation = 'lighter';
  for (let k = 1; k < M; k += 3) { const s = k / M, R = HW * (4.2 - 1.6 * s) * (1 + .15 * ap); ctx.globalAlpha = IN * (Math.min(1, .75 * lum * (1 - .4 * s))); ctx.drawImage(S2.voi, QX[k] - R, QY[k] - R, 2 * R, 2 * R); }
  for (let k = 0; k <= M; k += 2) { const s = k / M, wv = Math.pow(Math.max(0, Math.sin(lt * 2.2 - s * 5)), 4), near = rec * Math.max(0, 1 - Math.abs(s - sg) * 3.2);
    const R = HW * prof(s, n) * (2.3 + .6 * wv + .5 * ac); ctx.globalAlpha = IN * (Math.min(1, (.34 + .25 * wv) * lum + .5 * near)); ctx.drawImage(S2.hal, QX[k] - R, QY[k] - R, 2 * R, 2 * R); }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = IN * (1);
  /* 2. cils fins des deux bords (onde métachronale menée par la tête) + couronne de la bouche */
  ctx.beginPath();
  for (let k = 1; k < M; k++) { const s = k / M, w = HW * prof(s, n) * KW[k];
    for (let j = 0; j < 2; j++) { const u = (k + j * .5) / M; if (u >= 1) continue; const kk = Math.min(M - 1, k), sw2 = w;
      for (const sd of [-1, 1]) { const ph2 = Tc * 5.2 - u * 26 + sd + j * 1.3, Ls = (3.2 + 1.6 * hs(k * 7 + j * 3 + sd)) * s0 * (1 + .3 * ap), bw = Math.sin(ph2);
        const ex = QX[kk] + (QX[kk + 1] - QX[kk]) * j * .5, ey = QY[kk] + (QY[kk + 1] - QY[kk]) * j * .5, Nx = nx(kk) * sd, Ny = ny(kk) * sd, Tx = TXn[kk], Ty = TYn[kk];
        const ax = ex + Nx * sw2 * .96, ay = ey + Ny * sw2 * .96;
        ctx.moveTo(ax, ay); ctx.quadraticCurveTo(ax + Nx * Ls * .6 - Tx * bw * .6, ay + Ny * Ls * .6 - Ty * bw * .6, ax + Nx * Ls + Tx * (1.2 + 1.6 * bw), ay + Ny * Ls + Ty * (1.2 + 1.6 * bw)); } } }
  const hcx = QX[0] - TXn[0] * X.cap * .55, hcy = QY[0] - TYn[0] * X.cap * .55;
  for (let j = -5; j <= 5; j++) { const an = Math.atan2(-TYn[0], -TXn[0]) + j * .27, Lc = (6 + 2.2 * Math.cos(j * .6)) * s0 * (1 + .25 * ap), bw = Math.sin(Tc * 4.4 + j * .8) * .28;
    const ax = hcx + Math.cos(an) * X.cap * .62, ay = hcy + Math.sin(an) * X.cap * .62;
    ctx.moveTo(ax, ay); ctx.quadraticCurveTo(ax + Math.cos(an) * Lc * .55, ay + Math.sin(an) * Lc * .55, ax + Math.cos(an + bw) * Lc, ay + Math.sin(an + bw) * Lc); }
  ctx.strokeStyle = rgba(PAL.perle, .42 + .2 * ap); ctx.lineWidth = .55; ctx.stroke();
  /* 3. corps : texture droite posée tranche par tranche le long de la chaîne (calotte de tête, 16 tranches, pointe de queue) */
  const Mt = ctx.getTransform(), sh = TPX, Ht = X.cv.height, ky = fl;
  const pose = (x0, y0, tx, ty, u0, du, kw) => {   // tranche de texture [u0, u0+du] (unités) posée en (x0,y0) dans la direction (tx,ty)
    const cs = tx, sn = ty, a = cs, b2 = sn, c2 = -sn * ky, d = cs * ky;
    ctx.setTransform(Mt.a * a + Mt.c * b2, Mt.b * a + Mt.d * b2, Mt.a * c2 + Mt.c * d, Mt.b * c2 + Mt.d * d, Mt.a * x0 + Mt.c * y0 + Mt.e, Mt.b * x0 + Mt.d * y0 + Mt.f);
    ctx.drawImage(X.cv, (X.x0 + u0) * sh, 0, du * sh, Ht, -.2, -X.H * kw, du + .45, 2 * X.H * kw); };
  pose(QX[0] - TXn[0] * (X.cap + MG), QY[0] - TYn[0] * (X.cap + MG), TXn[0], TYn[0], -X.cap - MG, X.cap + MG, KW[0]);
  for (let k = 0; k < M; k++) { const dx = QX[k + 1] - QX[k], dy = QY[k + 1] - QY[k], dl = Math.hypot(dx, dy) || 1e-3; ctx.globalAlpha = IN * (1);
    const cs = dx / dl, sn = dy / dl, du = L / M, a = cs, b2 = sn, c2 = -sn * ky, d = cs * ky, kw = (KW[k] + KW[k + 1]) / 2;
    ctx.setTransform(Mt.a * a + Mt.c * b2, Mt.b * a + Mt.d * b2, Mt.a * c2 + Mt.c * d, Mt.b * c2 + Mt.d * d, Mt.a * QX[k] + Mt.c * QY[k] + Mt.e, Mt.b * QX[k] + Mt.d * QY[k] + Mt.f);
    ctx.drawImage(X.cv, (X.x0 + k * du) * sh, 0, du * sh, Ht, -.2, -X.H * kw, dl + .45, 2 * X.H * kw); }
  pose(QX[M], QY[M], TXn[M], TYn[M], L, X.tc + MG, KW[M]);
  ctx.setTransform(Mt);
  /* 4. bioluminescence : noyaux qui s'allument l'un après l'autre de la tête vers la queue ; perle qui court dans le canal */
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < X.nuc.length; i++) { const q = X.nuc[i], f = q.s * M, k = Math.min(M - 1, f | 0), r = f - k;
    const px = QX[k] + (QX[k + 1] - QX[k]) * r, py = QY[k] + (QY[k + 1] - QY[k]) * r, yy = q.y * KW[k];
    const cx = px + nx(k) * yy, cy = py + ny(k) * yy;
    const wv = Math.pow(Math.max(0, Math.sin(lt * 2.2 - q.s * 5)), 3), near = rec * Math.max(0, 1 - Math.abs(q.s - sg) * 3.2);
    const I = Math.min(1, .3 + .55 * wv + .25 * ap + .35 * ac + .6 * near + .12 * Math.sin(Tc * 1.3 + i * 2.1)), R = (4.2 + 3 * wv + 2 * near) * s0;
    ctx.globalAlpha = IN * (I); ctx.drawImage(S2.pho, cx - R, cy - R, 2 * R, 2 * R);
    if (wv > .2 || near > .2) { const R2 = HW * prof(q.s, n) * 1.1; ctx.globalAlpha = IN * (.28 * Math.max(wv, near)); ctx.drawImage(S2.per, px - R2, py - R2, 2 * R2, 2 * R2); } }
  { const u = (lt * .16) % 1, f = u * M, k = Math.min(M - 1, f | 0), r = f - k, px = QX[k] + (QX[k + 1] - QX[k]) * r, py = QY[k] + (QY[k + 1] - QY[k]) * r, R = 3.4 * s0;
    ctx.globalAlpha = IN * (.7 * Math.sin(Math.PI * u)); ctx.drawImage(S2.pho, px - R, py - R, 2 * R, 2 * R); }
  ctx.restore();
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
racine.QXE6 = racine.QXE6 || {};
racine.QXE6.choeur = dessinerChoeur;
racine.QXE7B = { choeur: dessinerChoeur, prechauffe, texture, TX, etapes: etapesTex, pts: () => [QX[0], QY[0], QX[M >> 1], QY[M >> 1], QX[M], QY[M]] };   // tests : continuité
/* préchauffage accroché depuis ce fichier (qxcrea.js intact) : la texture du Chœur se fabrique par tranches au chargement du niveau */
function accroche() {
  const ll = racine.loadLevel; if (typeof ll !== 'function' || ll.e7b) return;
  const w = racine.loadLevel = function (i) { const r = ll.apply(this, arguments);
    try { const lv = racine.LEVELS && racine.LEVELS[i]; if (lv && lv.cr && lv.cr.some(c => c.t === 'choeur')) prechauffe(lv); } catch (e) {} return r; };
  w.e7b = 1;
}
if (typeof document !== 'undefined') { if (document.readyState === 'complete') accroche(); else racine.addEventListener('load', accroche); }
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== CHOEUR FIN ===== */
