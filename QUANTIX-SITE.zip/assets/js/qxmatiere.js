/* =====================================================================
   QXMATIERE v1 (L2) — matière en suspension et bulles, entièrement connectées à QXLUMIERE. Voir DOSSIER-PARTICULES.md.
   Deux systèmes séparés (interfaces communes) :
     • lumiere_poussiere : neige marine, détritus/fibres, minéraux/paillettes, phytoplancton, zooplancton, poussière fine + ALLUVIONS (panaches de sédiments) — FLOTTENT
     • lumiere_bulles    : bulles (5 types de corps × 8 directions de lumière), colonnes, voiles et microbulles, éclatement — REMONTENT
   Lumière : chaque objet interroge QXLUMIERE.eclairer(x, y) (intensité, direction, teinte) ; Tyndall, liseré côté source, éclat spéculaire,
   transmission / réfraction, silhouette, retard de l'eau par plan, bioluminescence ; atlas reteinté à la couleur de la lumière.
   Contrat QXPOOL inchangé ; rien n'est alloué dans dessiner(). Coupe-circuit : localStorage qxmatiere = '0'.
   Interfaces L3 (créatures, moteurs de niveau) : QXALLUVIONS.emettre / perturber / stimuler / sillage / update — non câblées ici.
   ===================================================================== */
(function (racine) {
  'use strict';
  const LUM = racine.QXLUMIERE;
  if (!LUM || !LUM._noyau) return;
  const K = LUM._noyau, TAU = Math.PI * 2, Q8 = Math.PI / 4;
  const { borne, lisse, melange, rgba, toile, aleatoire, gauss, melBlanc, mel3, radial, scene, palierDe, inerte, PHASE, STYLE } = K;
  const coupe = () => { if (K.coupe()) return true; try { if (racine.localStorage.getItem('qxmatiere') === '0') return true; } catch (e) {} try { return /[?&]matiere=0/.test(racine.location.search); } catch (e) { return false; } };

  /* ---------- Jetons (B7) ---------- */
  const FAMS = ['neige', 'detritus', 'mineraux', 'phyto', 'zoo', 'poussiere'];
  const NEI = 0, DET = 1, MIN = 2, PHY = 3, ZOO = 4, POU = 5, NFL = 5;           // NFL : familles à bibliothèque de formes
  const PUB = [3, 4, 6, 2, 7, 5];                                                 // famille interne → code public (QXLUMIERE.FAMILLES / STYLE)
  const fam = (o) => Object.assign({ alpha: 1, sigma: 0.5, formes: 1, alea: 1, vitesse: 1, derive: 1, turb: 1, rotation: 1, eclat: 0.4, reflexion: 1, refraction: 0.6, diffusion: 1, bio: 0, plans: 1, flou: 1, vie: [22, 44], bille: 1, chute: 2 }, o);
  const DEFM = {
    graine: 1, react: 1, presence: 1, retard: 2.2, densite: 1, diversite: 1, ecart: 44, ambiante: 1,
    courant: { force: 1, sens: 0.1, turb: 1, echelle: 1 },
    neige: fam({ n: 150, taille: [3, 14], sigma: 0.55, eclat: 0.25, refraction: 0.6, bio: 0.25, chute: 3.2 }),
    detritus: fam({ n: 26, taille: [4, 16], sigma: 0.5, eclat: 0.6, refraction: 0.3, chute: 2, rotation: 0.8 }),
    mineraux: fam({ n: 54, taille: [2.2, 7], sigma: 0.45, eclat: 1, refraction: 0.15, chute: 8, rotation: 1.2, diffusion: 0.8 }),
    phyto: fam({ n: 40, taille: [3.6, 13], sigma: 0.45, eclat: 0.1, refraction: 1, bio: 0.8, chute: 0.7 }),
    zoo: fam({ n: 12, taille: [6, 18], sigma: 0.4, eclat: 0.1, refraction: 1, bio: 0.5, chute: 0.4, sauts: 1 }),
    poussiere: fam({ n: 680, taille: [0.6, 1.9], sigma: 0.45, eclat: 1, scint: 1, chute: 1.2, vie: [12, 30] }),
    alluvions: { alpha: 1, debit: 0.5, max: 16, taille: 1, hauteur: 0.14, panache: 1, retombee: 1, turbidite: 0.5, diffusion: 1, grains: 1, bille: 1, murs: 0.6, vie: [9, 18] },
    bulles: { alpha: 1, debit: 0.9, max: 90, taille: [1.1, 6.5], sigma: 0.55, alea: 1, vitesse: 1, sinuosite: 1, grossit: 1, oscillation: 1, eclatement: 1, reflexion: 1, refraction: 1, sillage: 1, bille: 1, plans: 1, libres: 0.08 },
    colonnes: { alpha: 1, n: 2, x: [0.3, 0.74], rafales: 1, largeur: 1, voile: 0.6 },
    microbulles: { alpha: 1, n: 50, taille: 1, vitesse: 1, scint: 1, voile: 0.5 }
  };
  /* R531 — matière PAR MONDE (dramaturgie, générique pour tous les niveaux) : poussière solaire au début, neige et paillettes au milieu,
     plancton bioluminescent dans les mondes obscurs. Moteurs de niveau (courant, vent, puits, aimants) et créatures : plus tard (L3). */
  const CFGM = {
    1: { poussiere: { n: 820 }, neige: { n: 70 }, detritus: { n: 14 }, mineraux: { n: 40 }, phyto: { n: 10 }, zoo: { n: 4 }, alluvions: { debit: 0.3 }, bulles: { debit: 0.5 }, colonnes: { n: 1 }, microbulles: { n: 30 } },
    2: { neige: { n: 60 }, detritus: { n: 10 }, mineraux: { n: 110, eclat: 0.8 }, phyto: { n: 0 }, zoo: { n: 0 }, poussiere: { n: 380 }, alluvions: { debit: 0.9, turbidite: 0.6 },
      bulles: { debit: 1.8, libres: 0.4, max: 120 }, colonnes: { n: 2, x: [0.4, 0.5], voile: 1 }, microbulles: { n: 90 } },   // chambre à bulles : rouge sombre, jamais doré
    3: { detritus: { n: 44 }, poussiere: { n: 620 }, neige: { n: 110 }, mineraux: { n: 60 }, phyto: { n: 16 }, zoo: { n: 6 }, bulles: { debit: 0.7 } },
    4: { neige: { n: 320, chute: 4.2 }, mineraux: { n: 120, eclat: 1.3 }, poussiere: { n: 420 }, detritus: { n: 8 }, phyto: { n: 8 }, zoo: { n: 2 }, alluvions: { debit: 0.2 }, bulles: { debit: 0.5 }, microbulles: { n: 40 } },
    5: { poussiere: { n: 980 }, neige: { n: 90 }, detritus: { n: 30 }, mineraux: { n: 50 }, phyto: { n: 6 }, zoo: { n: 2 }, courant: { force: 1.8, turb: 1.5 }, alluvions: { debit: 0.6 }, bulles: { debit: 0.6 } },
    6: { mineraux: { n: 150, eclat: 1.3 }, detritus: { n: 36 }, poussiere: { n: 620 }, neige: { n: 60 }, phyto: { n: 4 }, zoo: { n: 0 }, bulles: { debit: 0.4 } },
    7: { phyto: { n: 80, bio: 1 }, neige: { n: 160, chute: 2 }, poussiere: { n: 460 }, zoo: { n: 14 }, mineraux: { n: 40 }, bulles: { debit: 0.6 } },
    8: { mineraux: { n: 170, eclat: 1.4 }, poussiere: { n: 520 }, phyto: { n: 40 }, zoo: { n: 10 }, neige: { n: 90 }, bulles: { debit: 0.6 } },
    9: { neige: { n: 90 }, mineraux: { n: 90, eclat: 1.2 }, poussiere: { n: 520 }, phyto: { n: 50, bio: 1 }, zoo: { n: 12 }, alluvions: { debit: 0.7, turbidite: 0.4 },
      bulles: { debit: 0.6 }, colonnes: { n: 1, x: [0.6, 0.66] }, microbulles: { n: 40 } },
    10: { zoo: { n: 26, bio: 0.8 }, phyto: { n: 90, bio: 1 }, detritus: { n: 50 }, neige: { n: 120 }, poussiere: { n: 360 }, bulles: { debit: 0.6 } },
    11: { phyto: { n: 130, bio: 1 }, zoo: { n: 30, bio: 1 }, neige: { n: 140, bio: 0.5 }, poussiere: { n: 260 }, mineraux: { n: 30 }, detritus: { n: 10 }, bulles: { debit: 0.4 }, microbulles: { n: 30 } },
    12: { phyto: { n: 56 }, zoo: { n: 16 } }
  };
  const LIM = { neige: 500, detritus: 100, mineraux: 240, phyto: 160, zoo: 50, poussiere: 1200 };   // capacités (bornes des curseurs)
  K.DEF.matiere = DEFM; for (const id in CFGM) { LUM.CFG[id] = LUM.CFG[id] || {}; LUM.CFG[id].matiere = CFGM[id]; }
  let NBANDES = 0, VERM = 1, SERIE = 0, OVR = { densite: 1, diversite: 1, debit: 1, taille: 1, alea: 1 };
  const cfgM = id => LUM.cfgDe(id).matiere;

  /* =====================================================================
     ATLAS : maître blanc + copie teintée par région (reteinte par bandes, hors dessiner())
     ===================================================================== */
  function creerAtlas(cell, cols, regions) {
    let row = 0; const R = regions.map(n => { const r = { y0: row * cell, n }; row += Math.max(1, Math.ceil(n / cols)); r.y1 = row * cell; return r; });
    const W = cols * cell, H = row * cell, M = toile(W, H), TB = [], gTB = [];
    for (let i = 0; i < row; i++) { const c = toile(W, cell); TB.push(c); gTB.push(c.getContext('2d')); }   // copie teintée découpée en RANGÉES : une reteinte n'invalide qu'une petite toile (pas de recopie de l'atlas entier)
    const RW = R.map(r => r.y0 / cell);
    return { cell, cols, R, W, H, M, gM: M.getContext('2d'), TB, gTB, ton: R.map(() => [-99, -99, -99]), coul: R.map(() => '#fff'), cur: R.map(r => r.y1 / cell), fx: (k) => (k % cols) * cell, fy: (r, k) => R[r].y0 + ((k / cols) | 0) * cell, row: (r, k) => RW[r] + ((k / cols) | 0) };
  }
  function poser(at, r, k, c) { at.gM.drawImage(c, at.fx(k), at.fy(r, k)); }
  function teinter(at, r, rgb, tout) {                     // marque la région ; tout = reteinte immédiate (création seulement)
    const t = at.ton[r]; if (!tout && Math.abs(t[0] - rgb[0]) + Math.abs(t[1] - rgb[1]) + Math.abs(t[2] - rgb[2]) < 6) return;
    t[0] = rgb[0]; t[1] = rgb[1]; t[2] = rgb[2]; at.coul[r] = rgba(rgb, 1);   // une chaîne au plus par région et par 0,4 s (hors dessiner)
    const r0 = at.R[r].y0 / at.cell; if (tout || at.cur[r] >= at.R[r].y1 / at.cell) at.cur[r] = r0;   // en cours : on continue sans repartir du début (pas de rangées jamais atteintes)
    if (tout) while (bande(at)) { /* tout de suite */ }
  }
  function bande(at) {                                     // UNE rangée (W × cell px) ; renvoie vrai s'il reste du travail — travail étalé, jamais de pic
    for (let r = 0; r < at.R.length; r++) {
      const q = at.cur[r]; if (q >= at.R[r].y1 / at.cell) continue;
      const g = at.gTB[q], c = at.cell;
      g.globalCompositeOperation = 'copy'; g.drawImage(at.M, 0, q * c, at.W, c, 0, 0, at.W, c);
      g.globalCompositeOperation = 'source-in'; g.fillStyle = at.coul[r]; g.fillRect(0, 0, at.W, c); g.globalCompositeOperation = 'source-over';
      at.cur[r] = q + 1; NBANDES++; return true;
    }
    return false;
  }
  function flouter(c, r, passes) {                         // flou boîte séparable (création seulement)
    const S = c.width, g = c.getContext('2d'), im = g.getImageData(0, 0, S, S), d = im.data, a = new Float32Array(S * S), b = new Float32Array(S * S), n = 2 * r + 1;
    for (let i = 0; i < S * S; i++) a[i] = d[i * 4 + 3];
    for (let p = 0; p < (passes || 2); p++) {
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { let s = 0; for (let k = -r; k <= r; k++) { const xx = x + k; if (xx >= 0 && xx < S) s += a[y * S + xx]; } b[y * S + x] = s / n; }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { let s = 0; for (let k = -r; k <= r; k++) { const yy = y + k; if (yy >= 0 && yy < S) s += b[yy * S + x]; } a[y * S + x] = s / n; }
    }
    for (let i = 0; i < S * S; i++) { d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = 255; d[i * 4 + 3] = a[i]; }
    g.putImageData(im, 0, 0); return c;
  }
  const W1 = a => 'rgba(255,255,255,' + a.toFixed(3) + ')';
  function normaliser(c, cible) {                       // l'alpha maximal de la forme vaut « cible » (le contraste interne est gardé)
    const g = c.getContext('2d'), im = g.getImageData(0, 0, c.width, c.height), d = im.data, v = [];
    for (let i = 3; i < d.length; i += 4) if (d[i] > 12) v.push(d[i]); v.sort((a, b) => a - b);
    const m = Math.max(20, v.length ? v[Math.floor(v.length * 0.9)] : 255), k = Math.min(3.5, cible * 255 / m);   // 90e centile → cible : l'intérieur translucide reste lisible for (let i = 3; i < d.length; i += 4) d[i] = Math.min(255, d[i] * k); g.putImageData(im, 0, 0);
    let r = 1; const S = c.width, h = S / 2;                  // étendue réelle (rayon des pixels nets) → facteur d'échelle d'affichage
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) if (d[(y * S + x) * 4 + 3] > 60) { const q = Math.hypot(x + 0.5 - h, y + 0.5 - h); if (q > r) r = q; }
    return r;
  }

  /* =====================================================================
     GÉNÉRATEUR PROCÉDURAL DE FORMES (blanc, centre m, rayon utile ≈ 13 px sur 32) — aucune forme ronde parfaite, aucun anneau
     ===================================================================== */
  function contour(g, A, cx, cy, r, irr, n, ax, rot) {
    const h2 = irr * 0.22 * A(), h3 = irr * 0.16 * A(), h5 = irr * 0.09 * A(), p2 = A() * TAU, p3 = A() * TAU, p5 = A() * TAU, c = Math.cos(rot || 0), s = Math.sin(rot || 0);
    g.beginPath();
    for (let j = 0; j < n; j++) {
      const a = j / n * TAU, q = r * (1 + h2 * Math.cos(2 * a + p2) + h3 * Math.cos(3 * a + p3) + h5 * Math.cos(5 * a + p5) + irr * 0.14 * (A() - 0.5));
      const u = Math.cos(a) * q * ax, v = Math.sin(a) * q / ax, x = cx + u * c - v * s, y = cy + u * s + v * c;
      if (j) g.lineTo(x, y); else g.moveTo(x, y);
    }
    g.closePath();
  }
  function courbe(g, A, x0, y0, a0, L, n, ond, w, al) {   // trait ondulé (filaments, soies, fibres, queues)
    g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = W1(al); g.lineWidth = w; g.beginPath(); g.moveTo(x0, y0);
    let x = x0, y = y0, a = a0; const pas = L / n;
    for (let i = 0; i < n; i++) { a += (A() - 0.5) * ond; x += Math.cos(a) * pas; y += Math.sin(a) * pas; g.lineTo(x, y); }
    g.stroke(); return [x, y];
  }
  function grains(g, A, cx, cy, sx, sy, n, a0, a1, smax) { for (let i = 0; i < n; i++) { g.fillStyle = W1(a0 + (a1 - a0) * A()); const s = 0.6 + smax * A() * A(); g.fillRect(cx + gauss(A) * sx - s / 2, cy + gauss(A) * sy - s / 2, s, s); } }
  function fNeige(g, A, m) {
    const t = A(), R = 13;
    if (t < 0.55 || t >= 0.86) {                 // floc multi-lobes (comète si t ≥ 0,86 : traîne de mucus orientée)
      const n = 3 + ((A() * 6) | 0), sp = 0.45 + 0.55 * A(), ax = 0.7 + 0.6 * A();
      for (let i = 0; i < n; i++) { contour(g, A, m + gauss(A) * R * 0.3 * sp * ax, m + gauss(A) * R * 0.24 * sp / ax, R * (0.16 + 0.22 * A()), 1.3, 14, 0.75 + 0.5 * A(), A() * 3); g.fillStyle = W1(0.14 + 0.24 * A()); g.fill(); }
      g.globalCompositeOperation = 'destination-out'; const nh = (A() * 4) | 0;
      for (let i = 0; i < nh; i++) { contour(g, A, m + gauss(A) * R * 0.22, m + gauss(A) * R * 0.18, R * (0.05 + 0.08 * A()), 1, 9, 1, 0); g.fillStyle = W1(0.4 + 0.5 * A()); g.fill(); }
      g.globalCompositeOperation = 'source-over'; grains(g, A, m, m, R * 0.26, R * 0.2, 4 + ((A() * 10) | 0), 0.4, 0.95, 1.2);
      const nf = t >= 0.86 ? 3 + ((A() * 3) | 0) : (A() * 2.6) | 0, ac = A() * TAU;
      for (let i = 0; i < nf; i++) courbe(g, A, m, m, t >= 0.86 ? ac + (A() - 0.5) * 0.6 : A() * TAU, R * (0.55 + 0.5 * A()), 6, 0.9, 0.45 + 0.6 * A(), 0.12 + 0.22 * A());
    } else if (t < 0.74) {                       // filament muqueux : réseau lâche
      const nb = 2 + ((A() * 3) | 0);
      for (let i = 0; i < nb; i++) { const a = A() * TAU, x0 = m - Math.cos(a) * R * 0.8, y0 = m - Math.sin(a) * R * 0.8; courbe(g, A, x0, y0, a, R * (1.2 + 0.5 * A()), 10, 0.8, 0.5 + 0.7 * A(), 0.2 + 0.3 * A()); }
      grains(g, A, m, m, R * 0.35, R * 0.3, 3 + ((A() * 6) | 0), 0.35, 0.8, 1);
    } else {                                     // pelote fécale : bâtonnet arrondi granuleux
      const L0 = R * (0.55 + 0.4 * A()), w = R * (0.17 + 0.1 * A()), a = (A() - 0.5) * 0.6;
      g.save(); g.translate(m, m); g.rotate(a); g.beginPath(); g.moveTo(-L0, -w); g.quadraticCurveTo(0, -w * (1.2 + 0.4 * (A() - 0.5)), L0, -w * 0.9); g.arc(L0, 0, w * 0.9, -Math.PI / 2, Math.PI / 2); g.quadraticCurveTo(0, w * (1.1 + 0.3 * A()), -L0, w); g.arc(-L0, 0, w, Math.PI / 2, Math.PI * 1.5);
      g.fillStyle = W1(0.38 + 0.2 * A()); g.fill(); g.restore(); grains(g, A, m, m, L0 * 0.4, w * 0.4, 8, 0.5, 1, 0.8);
    }
  }
  function fDetritus(g, A, m) {
    const t = A(), R = 13;
    if (t < 0.38) {                              // fibre effilochée
      const a = A() * TAU, x0 = m - Math.cos(a) * R, y0 = m - Math.sin(a) * R, w = 0.6 + 0.9 * A();
      courbe(g, A, x0, y0, a, R * 2, 14, 0.35, w * 2.4, 0.18); const A2 = aleatoire((A() * 1e9) | 0); A2(); const fin = courbe(g, A, x0, y0, a, R * 2, 14, 0.35, w, 0.85);
      for (let i = 0; i < 2 + ((A() * 3) | 0); i++) courbe(g, A, fin[0], fin[1], a + (A() - 0.5) * 1.6, R * (0.15 + 0.25 * A()), 3, 0.6, 0.4, 0.4);
    } else if (t < 0.7) {                        // fragment plat déchiqueté, nervures
      contour(g, A, m, m, R * (0.5 + 0.35 * A()), 2.2, 11, 0.55 + 0.5 * A(), A() * 3); g.fillStyle = W1(0.22 + 0.2 * A()); g.fill(); g.strokeStyle = W1(0.55); g.lineWidth = 0.6; g.stroke();
      for (let i = 0; i < 1 + ((A() * 3) | 0); i++) courbe(g, A, m + gauss(A) * 3, m + gauss(A) * 3, A() * TAU, R * 0.6, 4, 0.5, 0.45, 0.35);
    } else if (t < 0.88) {                       // écaille / exuvie : bande courbe à côtes
      const r0 = R * (0.55 + 0.3 * A()), a0 = A() * TAU, sp = 1 + 1.4 * A(), ep = R * (0.16 + 0.12 * A());
      g.beginPath(); g.arc(m, m + r0 * 0.4, r0, a0, a0 + sp); g.arc(m, m + r0 * 0.4, r0 - ep, a0 + sp, a0, true); g.closePath(); g.fillStyle = W1(0.3 + 0.2 * A()); g.fill();
      g.strokeStyle = W1(0.6); g.lineWidth = 0.5; const nc = 3 + ((A() * 4) | 0);
      for (let i = 1; i < nc; i++) { const a = a0 + sp * i / nc; g.beginPath(); g.moveTo(m + Math.cos(a) * r0, m + r0 * 0.4 + Math.sin(a) * r0); g.lineTo(m + Math.cos(a) * (r0 - ep), m + r0 * 0.4 + Math.sin(a) * (r0 - ep)); g.stroke(); }
    } else {                                     // brindille ramifiée
      const a = A() * TAU, x0 = m - Math.cos(a) * R * 0.9, y0 = m - Math.sin(a) * R * 0.9; const p = courbe(g, A, x0, y0, a, R * 1.7, 8, 0.4, 1.1, 0.7);
      for (let i = 0; i < 2 + ((A() * 3) | 0); i++) { const u = 0.3 + 0.5 * A(); courbe(g, A, x0 + (p[0] - x0) * u, y0 + (p[1] - y0) * u, a + (A() < 0.5 ? 1 : -1) * (0.5 + 0.6 * A()), R * (0.3 + 0.3 * A()), 3, 0.4, 0.6, 0.6); }
    }
  }
  function fMineraux(g, A, m) {
    const t = A(), R = 12;
    if (t < 0.5) {                               // éclat facetté
      const n = 3 + ((A() * 4) | 0), r0 = R * (0.45 + 0.4 * A()), ax = 0.6 + 0.8 * A(), P = [];
      for (let i = 0; i < n; i++) { const a = i / n * TAU + (A() - 0.5) * 1.1, r = r0 * (0.55 + 0.6 * A()); P.push([m + Math.cos(a) * r * ax, m + Math.sin(a) * r / ax]); }
      g.beginPath(); P.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.closePath(); g.fillStyle = W1(0.5 + 0.2 * A()); g.fill();
      const c = [m + gauss(A) * 2, m + gauss(A) * 2]; for (let i = 0; i < n; i++) if (A() < 0.6) { g.beginPath(); g.moveTo(c[0], c[1]); g.lineTo(P[i][0], P[i][1]); g.lineTo(P[(i + 1) % n][0], P[(i + 1) % n][1]); g.closePath(); g.fillStyle = W1(A() < 0.5 ? 0.35 : 0.85); g.fill(); }
      g.strokeStyle = W1(0.9); g.lineWidth = 0.5; g.beginPath(); P.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.closePath(); g.stroke();
    } else if (t < 0.78) {                       // paillette plate (mica) : hexagone allongé, très mince
      g.save(); g.translate(m, m); g.rotate(A() * 3); const a = R * (0.6 + 0.35 * A()), b = a * (0.22 + 0.25 * A());
      g.beginPath(); for (let i = 0; i < 6; i++) { const q = i / 6 * TAU + (A() - 0.5) * 0.3; g.lineTo(Math.cos(q) * a * (0.8 + 0.3 * A()), Math.sin(q) * b); } g.closePath(); g.fillStyle = W1(0.55 + 0.3 * A()); g.fill(); g.strokeStyle = W1(1); g.lineWidth = 0.4; g.stroke(); g.restore();
    } else {                                     // grain arrondi, dense, piqué
      contour(g, A, m, m, R * (0.35 + 0.3 * A()), 0.9, 10, 0.75 + 0.5 * A(), A() * 3); g.fillStyle = W1(0.7 + 0.2 * A()); g.fill(); grains(g, A, m, m, R * 0.18, R * 0.18, 5, 0.85, 1, 0.8);
    }
  }
  function fPhyto(g, A, m) {
    const t = A(), R = 13;
    g.save(); g.translate(m, m); g.rotate((A() - 0.5) * 1.2);
    if (t < 0.2) {                               // diatomée centrique (valve) : disque légèrement polygonal plein, stries rayonnantes, aire centrale
      const r = R * (0.5 + 0.35 * A()); contour(g, A, 0, 0, r, 0.25, 22, 0.9 + 0.2 * A(), 0); g.fillStyle = W1(0.22 + 0.1 * A()); g.fill(); g.strokeStyle = W1(0.55); g.lineWidth = 0.5; g.stroke();
      const ns = 14 + ((A() * 14) | 0); g.strokeStyle = W1(0.22 + 0.1 * A()); g.lineWidth = 0.4; for (let i = 0; i < ns; i++) { const a = i / ns * TAU; g.beginPath(); g.moveTo(Math.cos(a) * r * 0.25, Math.sin(a) * r * 0.25); g.lineTo(Math.cos(a) * r * 0.92, Math.sin(a) * r * 0.92); g.stroke(); }
      contour(g, A, (A() - 0.5) * 2, (A() - 0.5) * 2, r * 0.22, 0.6, 9, 1, 0); g.fillStyle = W1(0.5); g.fill();
    } else if (t < 0.38) {                       // pennée (navette) : raphé + stries
      const a = R * (0.75 + 0.2 * A()), b = a * (0.16 + 0.12 * A()); g.beginPath(); g.moveTo(-a, 0); g.quadraticCurveTo(0, -b * 2, a, 0); g.quadraticCurveTo(0, b * 2, -a, 0); g.fillStyle = W1(0.25); g.fill(); g.strokeStyle = W1(0.55); g.lineWidth = 0.45; g.stroke();
      g.beginPath(); g.moveTo(-a * 0.8, 0); g.lineTo(a * 0.8, 0); g.strokeStyle = W1(0.5); g.stroke(); const ns = 8 + ((A() * 8) | 0); g.strokeStyle = W1(0.2);
      for (let i = 1; i < ns; i++) { const x = -a + 2 * a * i / ns, h = b * Math.sqrt(1 - x * x / (a * a)) * 0.9; g.beginPath(); g.moveTo(x, -h); g.lineTo(x, h); g.stroke(); }
      for (let i = 0; i < 2; i++) { g.fillStyle = W1(0.6); g.beginPath(); g.ellipse((i ? 1 : -1) * a * (0.3 + 0.2 * A()), 0, a * 0.18, b * 0.6, 0, 0, TAU); g.fill(); }
    } else if (t < 0.58) {                       // chaîne à soies (Chaetoceros)
      const nc = 3 + ((A() * 4) | 0), w = R * 1.7 / nc, h = w * (0.55 + 0.3 * A()), cb = (A() - 0.5) * 0.12;
      for (let i = 0; i < nc; i++) { const x = (i - (nc - 1) / 2) * w, y = (i - (nc - 1) / 2) * (i - (nc - 1) / 2) * cb * w;
        g.beginPath(); g.ellipse(x, y, w * 0.44, h * 0.5, 0, 0, TAU); g.fillStyle = W1(0.24 + 0.1 * A()); g.fill(); g.fillStyle = W1(0.65); g.beginPath(); g.ellipse(x + (A() - 0.5) * w * 0.3, y, w * 0.14, h * 0.2, A(), 0, TAU); g.fill();
        if (A() < 0.8) { for (const sg of [-1, 1]) { g.strokeStyle = W1(0.3); g.lineWidth = 0.4; g.beginPath(); g.moveTo(x + w * 0.4, y + sg * h * 0.4); g.quadraticCurveTo(x + w * 0.6, y + sg * h * 1.5, x + w * (0.2 + 0.6 * A()), y + sg * R * (0.7 + 0.4 * A())); g.stroke(); } } }
    } else if (t < 0.72) {                       // dinoflagellé à cornes (Ceratium)
      const r = R * 0.32; contour(g, A, 0, 0, r, 0.5, 14, 1.1, 0); g.fillStyle = W1(0.3); g.fill();
      const corne = (a, L, w0) => { g.beginPath(); g.moveTo(Math.cos(a + 0.5) * r * 0.8, Math.sin(a + 0.5) * r * 0.8); g.quadraticCurveTo(Math.cos(a) * L * 0.6, Math.sin(a) * L * 0.6 + (A() - 0.5) * 3, Math.cos(a) * L, Math.sin(a) * L); g.quadraticCurveTo(Math.cos(a) * L * 0.6, Math.sin(a) * L * 0.6, Math.cos(a - 0.5) * r * 0.8, Math.sin(a - 0.5) * r * 0.8); g.closePath(); g.fillStyle = W1(w0); g.fill(); };
      corne(-Math.PI / 2 + (A() - 0.5) * 0.3, R * (0.95 + 0.1 * A()), 0.3); corne(Math.PI / 2 - 0.35 - 0.3 * A(), R * (0.6 + 0.3 * A()), 0.28); corne(Math.PI / 2 + 0.35 + 0.3 * A(), R * (0.5 + 0.35 * A()), 0.28);
      g.strokeStyle = W1(0.5); g.lineWidth = 0.4; g.beginPath(); g.ellipse(0, 0, r * 1.05, r * 0.25, 0, 0, TAU); g.stroke(); grains(g, A, 0, 0, r * 0.3, r * 0.3, 4, 0.5, 0.85, 1);
    } else if (t < 0.84) {                       // colonie en étoile (Asterionella)
      const n = 5 + ((A() * 4) | 0); for (let i = 0; i < n; i++) { const a = i / n * TAU + (A() - 0.5) * 0.4, L0 = R * (0.75 + 0.2 * A()); g.save(); g.rotate(a); g.beginPath(); g.ellipse(L0 * 0.55, 0, L0 * 0.5, 0.9 + 0.5 * A(), 0, 0, TAU); g.fillStyle = W1(0.35 + 0.2 * A()); g.fill(); g.fillStyle = W1(0.7); g.fillRect(L0 * 0.15, -0.6, 1.4, 1.2); g.restore(); }
    } else {                                     // cellule à plastes (contenu interne)
      const a = R * (0.45 + 0.3 * A()), b = a * (0.6 + 0.35 * A()); contour(g, A, 0, 0, a, 0.35, 16, a / b > 1 ? Math.sqrt(a / b) : 1, 0); g.fillStyle = W1(0.16); g.fill(); g.strokeStyle = W1(0.45); g.lineWidth = 0.5; g.stroke();
      const np = 2 + ((A() * 5) | 0); for (let i = 0; i < np; i++) { contour(g, A, gauss(A) * a * 0.3, gauss(A) * b * 0.3, a * (0.14 + 0.14 * A()), 0.8, 9, 1.2, A() * 3); g.fillStyle = W1(0.55 + 0.35 * A()); g.fill(); }
    }
    g.restore();
  }
  function fZoo(g, A, m) {                       // orientés tête vers +x
    const t = A(), R = 13;
    g.save(); g.translate(m, m);
    if (t < 0.42) {                              // copépode : prosome en goutte, urosome segmenté, antennes longues, œil
      const L0 = R * (0.55 + 0.15 * A()), w = L0 * (0.38 + 0.12 * A());
      g.beginPath(); g.moveTo(L0 * 0.55, 0); g.bezierCurveTo(L0 * 0.5, -w, -L0 * 0.25, -w * 0.9, -L0 * 0.35, 0); g.bezierCurveTo(-L0 * 0.25, w * 0.9, L0 * 0.5, w, L0 * 0.55, 0); g.fillStyle = W1(0.3 + 0.1 * A()); g.fill(); g.strokeStyle = W1(0.55); g.lineWidth = 0.5; g.stroke();
      for (let i = 1; i < 4; i++) { g.strokeStyle = W1(0.25); g.beginPath(); const x = L0 * (0.4 - i * 0.18); g.moveTo(x, -w * 0.8); g.lineTo(x, w * 0.8); g.stroke(); }
      for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(-L0 * 0.45 - i * L0 * 0.16, (A() - 0.5) * 0.6, L0 * 0.09, w * (0.28 - i * 0.04), 0, 0, TAU); g.fillStyle = W1(0.35); g.fill(); }
      for (const sg of [-1, 1]) courbe(g, A, L0 * 0.45, sg * w * 0.4, sg * (1.15 + 0.35 * A()) - 0.25 * sg, R * (0.95 + 0.3 * A()), 7, 0.25, 0.45, 0.45);
      for (const sg of [-1, 1]) courbe(g, A, -L0 * 1.05, sg * 0.3, Math.PI + sg * 0.25, R * 0.3, 3, 0.3, 0.35, 0.4);
      g.fillStyle = W1(0.95); g.beginPath(); g.ellipse(L0 * 0.42, 0, 1, 0.9, 0, 0, TAU); g.fill();
    } else if (t < 0.6) {                        // nauplius : bouclier en poire + 3 paires d'appendices à soies
      const r = R * (0.35 + 0.1 * A()); contour(g, A, 0, 0, r, 0.5, 14, 1.15, 0); g.fillStyle = W1(0.3); g.fill(); g.strokeStyle = W1(0.5); g.lineWidth = 0.5; g.stroke();
      for (let i = 0; i < 3; i++) for (const sg of [-1, 1]) { const p = courbe(g, A, r * (0.5 - i * 0.4), sg * r * 0.6, sg * (Math.PI / 2 - 0.3 + i * 0.3), R * (0.45 + 0.15 * A()), 4, 0.4, 0.6, 0.5); courbe(g, A, p[0], p[1], sg * (Math.PI / 2 + 0.5), R * 0.2, 2, 0.3, 0.3, 0.35); }
      g.fillStyle = W1(0.95); g.fillRect(r * 0.55, -0.6, 1.3, 1.2);
    } else if (t < 0.78) {                       // appendiculaire : tronc ovale + longue queue ondulante (corde)
      const r = R * (0.25 + 0.08 * A()); g.beginPath(); g.ellipse(R * 0.45, 0, r * 1.25, r, 0, 0, TAU); g.fillStyle = W1(0.32); g.fill(); g.strokeStyle = W1(0.5); g.lineWidth = 0.5; g.stroke(); grains(g, A, R * 0.45, 0, r * 0.4, r * 0.3, 3, 0.6, 0.9, 1.2);
      g.lineCap = 'round'; const amp = 2 + 2.5 * A(), k = 0.35 + 0.25 * A(), ph = A() * TAU;
      for (let p = 0; p < 2; p++) { g.strokeStyle = W1(p ? 0.6 : 0.16); g.lineWidth = p ? 0.6 : 2.6; g.beginPath(); for (let x = R * 0.45 - r; x > -R * 1.05; x -= 1) { const y = amp * Math.sin((R * 0.45 - x) * k + ph) * ((R * 0.45 - x) / (R * 1.5)); if (x > R * 0.45 - r - 1) g.moveTo(x, y); else g.lineTo(x, y); } g.stroke(); }
    } else if (t < 0.9) {                        // larve zoé : carapace + épines rostrale/dorsale + yeux + abdomen courbe
      const r = R * (0.32 + 0.08 * A()); contour(g, A, 0, 0, r, 0.35, 14, 1.05, 0); g.fillStyle = W1(0.3); g.fill(); g.strokeStyle = W1(0.55); g.lineWidth = 0.5; g.stroke();
      courbe(g, A, r * 0.9, 0, 0.1 * (A() - 0.5), R * (0.55 + 0.2 * A()), 3, 0.05, 0.5, 0.6); courbe(g, A, 0, -r * 0.9, -Math.PI / 2 - 0.2, R * (0.5 + 0.3 * A()), 3, 0.05, 0.5, 0.6);
      g.strokeStyle = W1(0.4); g.lineWidth = 1.6; g.beginPath(); g.moveTo(-r * 0.7, r * 0.3); g.quadraticCurveTo(-R * 0.9, r * 0.6, -R * 0.75, R * 0.65); g.stroke();
      for (const sg of [-1, 1]) { g.fillStyle = W1(0.95); g.beginPath(); g.ellipse(r * 0.6, sg * r * 0.45, 1.3, 1.1, 0, 0, TAU); g.fill(); }
    } else {                                     // chaetognathe : corps en flèche, nageoires, crochets
      const L0 = R * (0.95 + 0.1 * A()), w = 1 + 0.6 * A(); g.beginPath(); g.ellipse(0, 0, L0, w, 0, 0, TAU); g.fillStyle = W1(0.32); g.fill();
      for (const x of [-L0 * 0.4, -L0 * 0.8]) for (const sg of [-1, 1]) { g.beginPath(); g.moveTo(x + 2, sg * w); g.lineTo(x - 2, sg * (w + 2 + A())); g.lineTo(x - 3, sg * w); g.closePath(); g.fillStyle = W1(0.25); g.fill(); }
      for (const sg of [-1, 1]) courbe(g, A, L0, sg * 0.4, sg * 0.6, 2.5, 2, 0.4, 0.4, 0.7);
    }
    g.restore();
  }
  const GEN = [fNeige, fDetritus, fMineraux, fPhyto, fZoo];
  const CS = 32, NVAR = 16, NSH = NFL * NVAR, NPT = 6;   // 6 cellules « points » : poussière ×3, éclat, microbulle ×2
  /* Bibliothèque particules : régions 0 corps (net, doux, flou) · 1 liseré (8 directions) + points · 2 silhouette */
  function bibliotheque(graine) {
    const A = aleatoire(1009 + graine * 7919), at = creerAtlas(CS, 32, [NSH * 3, NSH * 8 + NPT, NSH]), meta = new Float32Array(NSH);
    const net = toile(CS, CS), gn = net.getContext('2d'), dur = toile(CS, CS), gd = dur.getContext('2d'), tmp = toile(CS, CS), gt = tmp.getContext('2d');
    for (let f = 0; f < NFL; f++) for (let v = 0; v < NVAR; v++) {
      const s = f * NVAR + v; gn.clearRect(0, 0, CS, CS); GEN[f](gn, A, CS / 2); const ext = normaliser(net, 0.95);
      poser(at, 0, s * 3, net);
      const d1 = toile(CS, CS); d1.getContext('2d').drawImage(net, 0, 0); flouter(d1, 1, 2); poser(at, 0, s * 3 + 1, d1);
      const d2 = toile(CS, CS); d2.getContext('2d').drawImage(net, CS * 0.15, CS * 0.15, CS * 0.7, CS * 0.7); flouter(d2, 2, 2); poser(at, 0, s * 3 + 2, d2);   // bokeh : forme réduite ×0,7 puis floue (dessin ×1/0,7)
      poser(at, 2, s, d1);
      gd.clearRect(0, 0, CS, CS); gd.globalCompositeOperation = 'lighter'; for (let k = 0; k < 4; k++) gd.drawImage(net, 0, 0); gd.globalCompositeOperation = 'source-over';   // masque « dur »
      const refr = f === PHY || f === ZOO ? 0.5 : f === NEI ? 0.3 : 0.12;
      for (let k = 0; k < 8; k++) {
        const ux = Math.cos(k * Q8), uy = Math.sin(k * Q8), c = toile(CS, CS), g = c.getContext('2d');
        g.drawImage(dur, 0, 0); g.globalCompositeOperation = 'destination-out'; g.drawImage(dur, -ux * 1.8, -uy * 1.8);   // garde le bord tourné vers la source
        gt.clearRect(0, 0, CS, CS); gt.globalCompositeOperation = 'source-over'; gt.drawImage(dur, 0, 0); gt.globalCompositeOperation = 'destination-out'; gt.drawImage(dur, ux * 1.4, uy * 1.4); gt.globalCompositeOperation = 'source-over';
        g.globalCompositeOperation = 'source-over'; g.globalAlpha = refr; g.drawImage(tmp, 0, 0); g.globalAlpha = 1;   // point de réfraction / transmission côté opposé
        g.globalCompositeOperation = 'destination-in'; g.drawImage(net, 0, 0); g.drawImage(net, 0, 0); g.globalCompositeOperation = 'lighter'; g.drawImage(c, 0, 0);   // module par la densité réelle (cellules translucides)
        poser(at, 1, s * 8 + k, c);
      }
      meta[s] = borne(13 / ext, 0.85, 2.4);                   // la taille d'une particule désigne l'étendue visible de sa forme
    }
    const P0 = NSH * 8, pt = (stops, S) => { const c = toile(CS, CS), g = c.getContext('2d'), r = g.createRadialGradient(CS / 2, CS / 2, 0, CS / 2, CS / 2, S); for (const [o, a] of stops) r.addColorStop(o, W1(a)); g.fillStyle = r; g.fillRect(0, 0, CS, CS); return c; };
    poser(at, 1, P0, pt([[0, 1], [0.25, 0.7], [0.6, 0.15], [1, 0]], 6));                 // poussière douce
    poser(at, 1, P0 + 1, pt([[0, 1], [0.3, 0.9], [0.55, 0.2], [1, 0]], 3.2));            // éclat net
    { const c = pt([[0, 1], [0.3, 0.5], [1, 0]], 3), g = c.getContext('2d'); g.fillStyle = W1(0.7); g.fillRect(CS / 2 + 2, CS / 2 - 3, 1.4, 1.4); poser(at, 1, P0 + 2, c); }   // grain double
    poser(at, 1, P0 + 3, pt([[0, 1], [0.15, 0.8], [0.4, 0.22], [1, 0]], 9));             // éclat spéculaire (doux, sans branches)
    poser(at, 1, P0 + 4, pt([[0, 0.35], [0.55, 0.45], [0.8, 0.9], [1, 0]], 4));          // microbulle (bord plus clair que le centre, non creux)
    poser(at, 1, P0 + 5, pt([[0, 0.9], [0.5, 0.35], [1, 0]], 5));
    return { at, P0, meta };
  }

  /* ---------- Bulles : 36 corps (sphère, ellipsoïde, oscillante, calotte, doublet) × 8 directions de lumière ---------- */
  const CSB = 48, NB = 36, TYPB = new Uint8Array(NB);
  function bibBulles(graine) {
    const A = aleatoire(77 + graine * 131), at = creerAtlas(CSB, 16, [NB, NB * 8]), m = CSB / 2, r0 = CSB * 0.36;
    for (let s = 0; s < NB; s++) {
      const typ = s < 8 ? 0 : s < 16 ? 1 : s < 26 ? 2 : s < 32 ? 3 : 4; TYPB[s] = typ;   // 0 sphère · 1 ellipsoïde · 2 oscillante · 3 calotte · 4 doublet
      const H = [0, 0, 0, 0, 0, 0], P = [0, 0, 0, 0, 0, 0]; let ax = 1;
      if (typ === 0) { H[2] = 0.01 + 0.02 * A(); } else if (typ === 1) { ax = 1.1 + 0.15 * A(); H[2] = 0.02 * A(); H[3] = 0.02 * A(); }
      else if (typ === 2) { ax = 1.04 + 0.2 * A(); for (let h = 2; h <= 5; h++) H[h] = (0.03 + 0.11 * A()) / (h - 1) * (h === 3 ? 1.6 : 1); }
      for (let h = 2; h <= 5; h++) P[h] = A() * TAU;
      const rayon = a => { let q = 1; for (let h = 2; h <= 5; h++) q += H[h] * Math.cos(h * a + P[h]); return q; };
      const chemin = (g, rr) => {
        g.beginPath();
        if (typ === 3) {                          // calotte : dôme en haut, base plate ondulée
          const w = rr * (1.15 + 0.15 * A()), hd = rr * (0.85 + 0.15 * A()), yb = m + rr * 0.35; g.moveTo(m - w, yb);
          for (let j = 0; j <= 24; j++) { const a = Math.PI + j / 24 * Math.PI; g.lineTo(m + Math.cos(a) * w, yb + Math.sin(a) * hd * (1 + 0.04 * Math.sin(5 * a + P[2]))); }
          for (let j = 0; j <= 12; j++) { const x = m + w - 2 * w * j / 12; g.lineTo(x, yb + 1.5 * Math.sin(j * 1.3 + P[3]) * (1 - Math.abs(j / 6 - 1))); }
        } else if (typ === 4) {                   // doublet : deux bulles soudées
          const ra = rr * 0.7, rb = rr * (0.45 + 0.15 * A()), dx = rr * 0.42; g.ellipse(m - dx * 0.6, m + 2, ra, ra * 0.94, 0, 0, TAU); g.moveTo(m + dx + rb, m - rr * 0.25); g.ellipse(m + dx, m - rr * 0.25, rb, rb * 0.95, 0, 0, TAU);
        } else for (let j = 0; j <= 56; j++) { const a = j / 56 * TAU, q = rr * rayon(a); const x = m + Math.cos(a) * q * ax, y = m + Math.sin(a) * q / ax; if (j) g.lineTo(x, y); else g.moveTo(x, y); }
        g.closePath();
      };
      // limbe sombre (réflexion totale au bord : le bord renvoie le fond sombre) + voile intérieur très léger
      const li = toile(CSB, CSB), gl = li.getContext('2d'); gl.lineWidth = CSB * (0.03 + 0.07 * A()); gl.strokeStyle = W1(0.55 + 0.2 * A()); chemin(gl, r0); gl.stroke(); gl.fillStyle = W1(0.06); chemin(gl, r0); gl.fill();
      poser(at, 0, s, li);
      const dur = toile(CSB, CSB), gd = dur.getContext('2d'); gd.fillStyle = '#fff'; chemin(gd, r0); gd.fill();
      const anneauTot = 0.1 + 0.35 * A(), img = 0.2 + 0.5 * A(), spec = 0.6 + 0.4 * A(), ep = 1.4 + 3.2 * A(), off = (A() - 0.5) * 0.9, bandeImg = A() < 0.55, nSec = (A() * 3) | 0,
        anneauInt = A() < 0.45 ? 0.15 + 0.25 * A() : 0, sr0 = 0.1 + 0.16 * A(), ia = 0.38 + 0.2 * A(), irr = 0.3 + 0.25 * A(), sec = [];
      for (let q = 0; q < nSec; q++) sec.push([(A() - 0.5) * 2.2, 0.45 + 0.4 * A(), 0.04 + 0.05 * A(), 0.25 + 0.4 * A()]);   // reflets secondaires (autres sources, rebonds)
      for (let k = 0; k < 8; k++) {
        const ux = Math.cos(k * Q8), uy = Math.sin(k * Q8), c = toile(CSB, CSB), g = c.getContext('2d');
        // anneau argenté de réflexion totale tout autour (faible) + croissant fort côté source
        g.drawImage(dur, 0, 0); g.globalCompositeOperation = 'destination-out'; g.drawImage(dur, -ux * ep, -uy * ep); g.globalCompositeOperation = 'source-over';
        const ring = toile(CSB, CSB), gr = ring.getContext('2d'); gr.lineWidth = 1.2; gr.strokeStyle = W1(anneauTot); chemin(gr, r0 * 0.97); gr.stroke(); g.drawImage(ring, 0, 0);
        // image renversée du plafond (côté opposé, intérieure, douce) : la bulle est une lentille divergente
        const ix = m - ux * r0 * ia, iy = m - uy * r0 * ia, ir = r0 * irr * 1.3;
        g.save(); chemin(g, r0 * 0.92); g.clip(); g.translate(ix, iy); g.rotate(k * Q8 + Math.PI / 2); g.scale(1, bandeImg ? 0.38 : 0.8);   // image renversée : tache, ou bande (le plafond vu à l'envers)
        const f = g.createRadialGradient(0, 0, 0, 0, 0, ir); f.addColorStop(0, W1(img)); f.addColorStop(0.55, W1(img * 0.4)); f.addColorStop(1, W1(0)); g.fillStyle = f; g.fillRect(-ir, -ir, 2 * ir, 2 * ir); g.restore();
        if (anneauInt) { g.save(); g.lineWidth = 0.9; g.strokeStyle = W1(anneauInt); g.beginPath(); g.arc(m, m, r0 * 0.74, k * Q8 - 1.1, k * Q8 + 1.1); g.stroke(); g.restore(); }   // anneau intérieur (seconde réflexion totale)
        for (const q of sec) { const a2 = k * Q8 + q[0], x2 = m + Math.cos(a2) * r0 * q[1], y2 = m + Math.sin(a2) * r0 * q[1], f2 = g.createRadialGradient(x2, y2, 0, x2, y2, r0 * q[2] * 2.2); f2.addColorStop(0, W1(q[3])); f2.addColorStop(1, W1(0)); g.fillStyle = f2; g.fillRect(0, 0, CSB, CSB); }
        // reflet spéculaire net côté source (décalé selon la bulle)
        const a = k * Q8 + off, sx = m + Math.cos(a) * r0 * 0.6, sy = m + Math.sin(a) * r0 * 0.6, sr = r0 * sr0, fs = g.createRadialGradient(sx, sy, 0, sx, sy, sr);
        fs.addColorStop(0, W1(spec)); fs.addColorStop(0.45, W1(spec * 0.45)); fs.addColorStop(1, W1(0)); g.fillStyle = fs; g.fillRect(0, 0, CSB, CSB);
        poser(at, 1, s * 8 + k, c);
      }
    }
    return { at };
  }

  /* ---------- Alluvions : 8 nuages fractals (fBm), deux régions : diffusion (lumière) · voile (turbidité) ---------- */
  const CSA = 64, NAV = 8;
  function bibAlluvions(graine) {
    const A = aleatoire(4242 + graine * 17), at = creerAtlas(CSA, 4, [NAV, NAV]), S = CSA;
    for (let v = 0; v < NAV; v++) {
      const c = toile(S, S), g = c.getContext('2d'), im = g.createImageData(S, S), d = im.data, oct = [], ax = 0.65 + 0.7 * A(), cx = S / 2 + gauss(A) * 3, cy = S / 2 + gauss(A) * 3;
      for (let o = 0; o < 4; o++) { const n = 4 << o, L = new Float32Array((n + 1) * (n + 1)); for (let i = 0; i < L.length; i++) L[i] = A(); for (let j = 0; j <= n; j++) { L[j * (n + 1) + n] = L[j * (n + 1)]; L[n * (n + 1) + j] = L[j]; } oct.push([n, L]); }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        let v2 = 0, amp = 0.55, tot = 0;
        for (const [n, L] of oct) { const fx = x / S * n, fy = y / S * n, ix = fx | 0, iy = fy | 0, tx = fx - ix, ty = fy - iy, sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty), w = n + 1;
          const a = L[iy * w + ix], b = L[iy * w + ix + 1], cc = L[(iy + 1) * w + ix], dd = L[(iy + 1) * w + ix + 1]; v2 += amp * ((a * (1 - sx) + b * sx) * (1 - sy) + (cc * (1 - sx) + dd * sx) * sy); tot += amp; amp *= 0.55; }
        v2 /= tot; const dx = (x - cx) / (S * 0.44) * ax, dy = (y - cy) / (S * 0.44) / ax, rr = Math.sqrt(dx * dx + dy * dy), env = 1 - lisse(0.15, 1, rr + (v2 - 0.5) * 1.5);
        const fen = lisse(0, 9, x) * lisse(0, 9, S - 1 - x) * lisse(0, 9, y) * lisse(0, 9, S - 1 - y), al = (env * lisse(0.42, 0.9, v2) * 0.75 + env * env * 0.12) * fen; const i = (y * S + x) * 4; d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = borne(al * 255 * 0.9, 0, 255);
      }
      g.putImageData(im, 0, 0); poser(at, 0, v, c); poser(at, 1, v, c);
    }
    return { at };
  }

  /* =====================================================================
     OUTILS PARTAGÉS : repère (cache de la transformation de base), retard de l'eau, teintes vivantes
     ===================================================================== */
  function base() { return { bs: 1, bx: 0, by: 0, w: -1, ctx: null, ok: true }; }
  function lireBase(B, ctx, force) {                    // allocation (DOMMatrix) seulement si la toile change de taille ou sur demande (zoom du banc)
    if (!force && ctx === B.ctx && ctx.canvas.width === B.w) return;
    const m = ctx.getTransform(); B.bs = m.a; B.bx = m.e; B.by = m.f; B.ok = Math.abs(m.b) < 1e-6 && Math.abs(m.c) < 1e-6 && Math.abs(m.a - m.d) < 1e-6; B.ctx = ctx; B.w = ctx.canvas.width;
  }
  function tonsDe(L, T) {                               // teinte de la lumière courante (comme le champ L1) → corps / liseré
    const cu = L.M.cur, cr = cu.C, nu = cu.N;
    for (let j = 0; j < 3; j++) T.cD[j] = melange(melange(L.cFais[j], L.cCre[j], cr), L.cNuit[j], nu);
    for (let j = 0; j < 3; j++) { T.corps[j] = Math.round(melange(melange(L.cMat[j], T.cD[j], 0.6), L.cLum[j], 0.3) * 0.75 + 255 * 0.25); T.lis[j] = Math.round(melange(melange(L.cLum[j], T.cD[j], 0.4), 255, 0.35)); }
  }

  /* =====================================================================
     SYSTÈME « MATIÈRE QUI FLOTTE » + ALLUVIONS
     ===================================================================== */
  let SYS = null, SYSB = null;
  function systemeMatiere(sc, p, L) {
    const id = L.id, ech = Math.max(0.4, sc.l * sc.h / (390 * 844)), E = L.E;
    let C = cfgM(id), ver = VERM, serie = SERIE;
    let BIB = bibliotheque(C.graine + SERIE), at = BIB.at, AL = bibAlluvions(C.graine + SERIE).at;
    const T = { cD: [0, 0, 0], corps: [0, 0, 0], lis: [0, 0, 0], t: -9 };
    const majTeintes = (tout) => { tonsDe(L, T); teinter(at, 0, T.corps, tout); teinter(at, 1, T.lis, tout); teinter(AL, 0, T.corps, tout); };
    teinter(at, 2, L.cFond, true); teinter(AL, 1, L.cFond, true); majTeintes(true);
    const glow = radial(32, L.cBio, [[0, 0.9], [0.2, 0.55], [0.5, 0.14], [1, 0]]);
    // --- capacités et rangées par famille (les plans sont fixés à la naissance : tri par profondeur en 3 passes, coût constant)
    const CAP = FAMS.map(f => Math.round(LIM[f] * Math.max(1, ech))), D0 = [], CAPE = 120; let NP = 0; for (let f = 0; f < 6; f++) { D0.push(NP); NP += CAP[f]; }
    const E0 = NP, N = NP + CAPE;
    const x = new Float32Array(N), y = new Float32Array(N), vx = new Float32Array(N), vy = new Float32Array(N), ux = new Float32Array(N), uy = new Float32Array(N), z = new Float32Array(N), s = new Float32Array(N);
    const rot = new Float32Array(N), om = new Float32Array(N), tl = new Float32Array(N), omt = new Float32Array(N), asp = new Float32Array(N), fl = new Float32Array(N), op = new Float32Array(N), ph = new Float32Array(N), fq = new Float32Array(N);
    const age = new Float32Array(N), vie = new Float32Array(N), ev = new Float32Array(N), bio = new Float32Array(N), hop = new Float32Array(N), hx = new Float32Array(N), hy = new Float32Array(N), gb = new Float32Array(N);
    const va = new Uint8Array(N), pl = new Uint8Array(N), fa = new Uint8Array(N), on = new Uint8Array(N);
    let extFlow = null, extGeo = null, k = 1, kq = 1, pal = 'cinema', maxSaut = 0, msU = 0, msD = 0;
    const n = new Int32Array(6), NQ = new Int32Array(6); let nEm = 0, curE = 0;
    // effectifs dessinés par palier (par famille) : le Standard est maigre exprès (budget ≤ 0,8 ms) — peu d'objets, chacun en un seul appel
    const KQS = { cinema: [1, 1, 1, 1, 1, 1], standard: [0.22, 0.36, 0.3, 0.32, 0.36, 0.11]   /* R531 : Standard plus riche (×1,5 env.), budget libéré par les caustiques */, sobre: [0.06, 0.1, 0.08, 0.08, 0.15, 0.015] };
    function majNQ() { const K = kq === 0 ? null : KQS[pal] || KQS.cinema; for (let f = 0; f < 6; f++) NQ[f] = K ? Math.min(n[f], Math.round(n[f] * K[f] + (n[f] > 0 && K[f] > 0 ? 0.5 : 0))) : 0; }
    const A = aleatoire((((sc.alea ? sc.alea() : 0.5) * 4294967296) >>> 0) ^ (C.graine * 2654435761));
    // poids des plans
    const wP = new Float32Array(3);
    function poidsPlans(P) { const k = borne(P.plans, 0, 2); wP[2] = 0.12 * k; wP[0] = Math.min(0.6, 0.42 * k); wP[1] = 1 - wP[0] - wP[2]; }
    function init(i, f, initial) {
      const P = C[FAMS[f]], al = borne(P.alea * C.diversite * OVR.diversite, 0, 1.5);
      fa[i] = f; on[i] = 1;
      const u = i >= E0 ? 0.5 : ((i - D0[f]) * 0.6180339887 + 0.31) % 1, w0 = kq < 1 && i - D0[f] < NQ[f] ? wP[0] * 0.45 : wP[0], tier = i >= E0 ? 1 : (u < w0 ? 0 : u < 1 - wP[2] ? 1 : 2); pl[i] = tier;   // Standard : moins de plan lointain (voilé), plus de net
      z[i] = tier === 0 ? 0.06 + 0.32 * A() : tier === 1 ? 0.4 + 0.42 * A() : 0.84 + 0.16 * A();
      const t0 = P.taille[0], t1 = Math.max(t0, P.taille[1]), e = borne(Math.abs(gauss(A)) * P.sigma / 1.35, 0, 1);
      s[i] = t0 * Math.pow(t1 / t0, melange(0.3, e, Math.min(1, al)));
      const nv = Math.max(1, Math.round(NVAR * borne(P.formes * C.diversite * OVR.diversite, 0, 1))); va[i] = (A() * nv) | 0;
      const rs = f === MIN ? 1.3 : f === DET ? 0.5 : f === ZOO ? 0 : 0.3;
      rot[i] = A() * TAU * Math.min(1, al); om[i] = (A() - 0.5) * rs * P.rotation * (0.3 + 0.7 * Math.min(1, al)); tl[i] = A() * TAU; omt[i] = (A() - 0.5) * (f === MIN ? 1.1 : 0.6) * P.rotation * Math.min(1, al);
      asp[i] = 1 - 0.32 * A() * Math.min(1, al); fl[i] = al > 0.1 && A() < 0.5 ? -1 : 1; op[i] = (0.65 + 0.35 * A()) * (1 - 0.25 * Math.min(1, al) * A());
      ph[i] = A() * TAU; fq[i] = 0.6 + 3.8 * A();                        // ≤ 0,7 Hz
      vie[i] = melange(P.vie[0], P.vie[1], A()); age[i] = initial ? A() * vie[i] : 0; ev[i] = 0; ux[i] = 0; uy[i] = 0; gb[i] = 0;
      vx[i] = gauss(A) * 1.5 * Math.min(1, al); vy[i] = P.chute * (0.5 + A()) * (f === ZOO ? (A() - 0.3) : 1);
      bio[i] = f === PHY ? (A() < 0.45 ? 0.6 + 0.4 * A() : 0) : f === ZOO ? (A() < 0.35 ? 1 : 0) : f === NEI ? (A() < 0.08 ? 0.7 : 0) : 0;
      hop[i] = 0.5 + 3 * A(); hx[i] = 0; hy[i] = 0;
      if (f === ZOO) rot[i] = A() * TAU;
      x[i] = A() * sc.l; y[i] = A() * sc.h;
      if (kq < 1 && i < E0 && i - D0[f] < NQ[f]) viser(i);
    }
    // Standard / Sobre : peu d'objets dessinés → on les fait naître de préférence DANS la lumière (3 essais, garde le plus éclairé).
    // Physiquement la matière est partout, mais seule celle des faisceaux se voit (Tyndall) : rien n'est dépensé pour de l'invisible.
    const EV = { i: 0, dx: 0, dy: 1, idx: 0, c: 0, r: 0, g: 0, b: 0, rev: 0, expo: 1, froid: 0 };
    function viser(i) { let bi = -1; for (let t = 0; t < 3; t++) { const xx = A() * sc.l, yy = A() * sc.h; L.eclairer(xx, yy, EV); const v = EV.i + 0.05 * A(); if (v > bi) { bi = v; x[i] = xx; y[i] = yy; } } }
    function compter() { for (let f = 0; f < 6; f++) n[f] = Math.min(CAP[f], Math.round(C[FAMS[f]].n * ech * C.densite * OVR.densite)); majNQ(); }
    function initFam(f) { poidsPlans(C[FAMS[f]]); for (let i = D0[f]; i < D0[f] + CAP[f]; i++) init(i, f, true); }
    function initTout() { compter(); for (let f = 0; f < 6; f++) initFam(f); for (let i = E0; i < N; i++) on[i] = 0; nEm = 0; }
    initTout();
    const SIGS = FAMS.map(f => sig(C[f]));
    function sig(P) { return [P.taille[0], P.taille[1], P.sigma, P.formes, P.alea, P.plans, P.rotation, P.chute].join(','); }
    function relire() {                                  // réglages vivants : la plupart s'appliquent sans relancer ; les réglages de structure relancent la seule famille touchée
      C = cfgM(id); ver = VERM; compter();
      if (serie !== SERIE || BIB.graine !== C.graine) { serie = SERIE; BIB = bibliotheque(C.graine + SERIE); BIB.graine = C.graine; at = BIB.at; AL = bibAlluvions(C.graine + SERIE).at; teinter(at, 2, L.cFond, true); teinter(AL, 1, L.cFond, true); majTeintes(true); initTout(); return; }
      for (let f = 0; f < 6; f++) { const g = sig(C[FAMS[f]]); if (g !== SIGS[f]) { SIGS[f] = g; initFam(f); } }
    }
    BIB.graine = C.graine;
    // --- retard de l'eau par plan + bioluminescence ambiante
    const lagG = new Float32Array([1, 1, 1]), lagR = new Float32Array([1, 1, 1]); let bioAmb = 0;
    // --- alluvions
    const NA = 24, ax_ = new Float32Array(NA), ay_ = new Float32Array(NA), ar = new Float32Array(NA), ar1 = new Float32Array(NA), aage = new Float32Array(NA), avie = new Float32Array(NA), aop = new Float32Array(NA), avx = new Float32Array(NA), avy = new Float32Array(NA), arot = new Float32Array(NA), agr = new Float32Array(NA);
    const ava = new Uint8Array(NA), aon = new Uint8Array(NA); let tAmb = 1 + 2 * A(), tBil = 0, bpx = 0, bpy = 0, bv = 0, bvx = 0, bvy = 0, bOk = false;
    function bouffee(qx, qy, force, pvx, pvy) {
      const Ca = C.alluvions, cap = Math.min(NA, kq < 1 ? (kq < 0.5 ? 0 : Math.min(3, Math.round(Ca.max * 0.5))) : Math.round(Ca.max)); let j = -1, nn = 0;
      for (let i = 0; i < NA; i++) { if (aon[i]) nn++; else if (j < 0) j = i; } if (j < 0 || nn >= cap) return -1;
      const f = borne(force, 0.2, 2); ax_[j] = qx; ay_[j] = qy; ar[j] = (6 + 8 * A()) * Ca.taille * (0.7 + 0.3 * f); ar1[j] = ar[j] * (2.2 + 1.6 * A());
      aage[j] = 0; avie[j] = melange(Ca.vie[0], Ca.vie[1], A()) * (0.7 + 0.3 * f); aop[j] = 0.6 + 0.4 * A(); ava[j] = (A() * NAV) | 0; arot[j] = A() * TAU;
      avx[j] = (pvx || 0) * 0.25 + gauss(A) * 3; avy[j] = -(5 + 9 * A()) * Ca.panache * f + (pvy || 0) * 0.15; agr[j] = 0; aon[j] = 1; return j;
    }
    function solDe(xx) { return sc.h * (1 - C.alluvions.hauteur * (0.35 + 0.65 * A())); }
    function prochesMur(qx, qy, R) { const M = (extGeo || sc.geo || {}).murs || []; for (let k = 0; k < M.length; k++) { const w = M[k], ex = w.x2 - w.x1, ey = w.y2 - w.y1, ll = ex * ex + ey * ey + 1e-6, t = borne(((qx - w.x1) * ex + (qy - w.y1) * ey) / ll, 0, 1), dx = qx - (w.x1 + ex * t), dy = qy - (w.y1 + ey * t); if (dx * dx + dy * dy < R * R) return true; } return false; }
    function majAlluvions(dt) {
      const Ca = C.alluvions; if (Ca.alpha <= 0) return;
      tAmb -= dt * Ca.debit * C.ambiante; if (tAmb < 0) {                       // remise en suspension ambiante : sol, puis pied des murs
        tAmb = 2 + 5 * A() * A(); const M = (extGeo || sc.geo || {}).murs || [];
        if (M.length && A() < Ca.murs * 0.5) { const w = M[(A() * M.length) | 0], t = A(); bouffee(w.x1 + (w.x2 - w.x1) * t, w.y1 + (w.y2 - w.y1) * t + 4 + 6 * A(), 0.6, 0, 0); }
        else bouffee(A() * sc.l, solDe(), 0.7 + 0.5 * A(), gauss(A) * 6, 0);
      }
      for (let j = 0; j < NA; j++) {
        if (!aon[j]) continue; aage[j] += dt; const u = aage[j] / avie[j]; if (u >= 1) { aon[j] = 0; continue; }
        const fx = (extFlow || sc.flux)(ax_[j], ay_[j]);
        ar[j] += (ar1[j] - ar[j]) * Math.min(1, dt / 3.5);
        avy[j] += (2.2 * Ca.retombee - avy[j]) * Math.min(1, dt * 0.45);                       // panache qui monte puis retombe
        avx[j] += (fx[0] * 0.3 * C.courant.force - avx[j]) * Math.min(1, dt * 0.3);
        ax_[j] += avx[j] * dt; ay_[j] += avy[j] * dt; arot[j] += 0.04 * dt;
        agr[j] += dt * Ca.grains * (1 - u) * 1.4 * (kq < 1 ? 0.5 : 1);
        if (agr[j] > 1) { agr[j] -= 1; emettre(ax_[j] + gauss(A) * ar[j] * 0.35, ay_[j] + gauss(A) * ar[j] * 0.2, avx[j], 4, A() < 0.7 ? MIN : NEI, 1, { vie: 5 + 6 * A(), taille: 0.7, chute: 1.6 }); }
      }
    }
    // --- forces
    function perturber(qx, qy, R, force, pvx, pvy, inst) {
      const R2 = R * R, kd = inst ? 1 : dtL; pvx = pvx || 0; pvy = pvy || 0;
      for (let f = 0; f < 6; f++) { const e = D0[f] + n[f]; for (let i = D0[f]; i < e; i++) poussee(i, qx, qy, R, R2, force, pvx, pvy, kd); }
      for (let i = E0; i < N; i++) if (on[i]) poussee(i, qx, qy, R, R2, force, pvx, pvy, kd);
      for (let j = 0; j < NA; j++) if (aon[j]) { const dx = ax_[j] - qx, dy = ay_[j] - qy, d = Math.sqrt(dx * dx + dy * dy) + 1; if (d < R + ar[j]) { const q = (1 - d / (R + ar[j])) * kd; avx[j] += (dx / d * force * 0.3 + pvx * 0.3) * q; avy[j] += (dy / d * force * 0.3 + pvy * 0.3) * q; } }
    }
    function poussee(i, qx, qy, R, R2, force, pvx, pvy, kd) {
      const dx = x[i] - qx, dy = y[i] - qy, d2 = dx * dx + dy * dy; if (d2 >= R2) return;
      const d = Math.sqrt(d2) + 0.001, q = 1 - d / R, sens = C[FAMS[fa[i]]].bille;
      ux[i] += ((dx / d - dy / d * 0.35) * force + pvx * 0.6) * q * (0.4 + 0.6 * z[i]) * sens * kd; uy[i] += ((dy / d + dx / d * 0.35) * force + pvy * 0.6) * q * (0.4 + 0.6 * z[i]) * sens * kd;   // écart + léger tourbillon
      ev[i] = Math.min(1.5, ev[i] + q * 1.2 * kd * (kd === 1 ? 1 : 6));
      if (fa[i] === ZOO && hop[i] > 0.4) { hop[i] = 0; hx[i] = dx / d; hy[i] = dy / d; }   // fuite du zooplancton
    }
    function stimuler(qx, qy, R, kk) { const R2 = R * R; for (let i = 0; i < N; i++) { if (!on[i] || bio[i] <= 0) continue; const dx = x[i] - qx, dy = y[i] - qy, d2 = dx * dx + dy * dy; if (d2 < R2) ev[i] = Math.min(1.5, ev[i] + kk * (1 - Math.sqrt(d2) / R)); } }
    function emettre(qx, qy, pvx, pvy, f, n2, o) {
      o = o || {}; let e = 0;
      for (let m = 0; m < (n2 || 1); m++) {
        let j = E0 + curE, tr = 0; while (on[j] && tr < CAPE) { curE = (curE + 1) % CAPE; j = E0 + curE; tr++; } if (on[j]) break;
        curE = (curE + 1) % CAPE; init(j, f, false); x[j] = qx + gauss(A) * (o.dispersion === undefined ? 4 : o.dispersion) * 0.5; y[j] = qy + gauss(A) * (o.dispersion === undefined ? 4 : o.dispersion) * 0.5;
        s[j] *= o.taille || 1; vie[j] = (o.vie || 6) * (0.8 + 0.4 * A()); vx[j] = (pvx || 0) * 0.3 + gauss(A) * 2; vy[j] = (pvy || 0) * 0.3 + (o.chute ? C[FAMS[f]].chute * o.chute : vy[j]); nEm++; e++;
      }
      return e;
    }
    // --- mouvement : courant générique + turbulence sans divergence (fonction de courant, 2 octaves) + marche individuelle
    let dtL = 1 / 60, tT = 0;
    function pas(i, f, dt, t, P, cf, cs, cn, tb, ke) {
      const X = x[i], Y = y[i], zz = z[i], par = 0.45 + 0.75 * zz;
      const fx = (extFlow || sc.flux)(X, Y);
      const a1 = X * 0.011 * ke + 1.7 + t * 0.07, b1 = Y * 0.009 * ke - t * 0.05, a2 = X * 0.031 * ke + t * 0.13 + ph[i] * 0.05, b2 = Y * 0.027 * ke + 2.1 - t * 0.11;
      const s1 = Math.sin(a1), c1 = Math.cos(a1), s2 = Math.sin(b1), c2 = Math.cos(b1), s3 = Math.sin(a2), c3 = Math.cos(a2), s4 = Math.sin(b2), c4 = Math.cos(b2);
      let ax = fx[0] * 0.35 * P.derive * cf + cs * 7 * cf + tb * P.turb * (-9 * s1 * s2 - 4 * s3 * s4) + 1.6 * Math.sin(t * 0.21 + ph[i]) * P.alea;
      let ay = fx[1] * 0.35 * P.derive * cf + cn * 7 * cf + tb * P.turb * (-9 * 1.22 * c1 * c2 - 4 * 1.15 * c3 * c4);
      if (f === ZOO && P.sauts > 0) {                    // sauts brefs puis glisse ; tête dans le sens du saut
        hop[i] += dt; if (hop[i] > 2.2 + 3 * ((ph[i] * 7) % 1) / P.sauts) { hop[i] = 0; const a = rot[i] + (A() - 0.5) * 1.6; hx[i] = Math.cos(a); hy[i] = Math.sin(a); }
        const ih = Math.exp(-hop[i] / 0.28) * 62 * P.sauts; ax += hx[i] * ih; ay += hy[i] * ih;
        if (ih > 4) { const cible = Math.atan2(hy[i], hx[i]); let d = cible - rot[i]; d -= Math.round(d / TAU) * TAU; rot[i] += d * Math.min(1, dt * 6); }
      }
      vx[i] += (A() - 0.5) * 5 * dt * P.alea; vx[i] *= 1 - 0.25 * dt;
      const vv = P.vitesse; let mx = (vx[i] + ax) * par * vv + ux[i], my = (vy[i] + ay) * par * vv + uy[i];
      const m2 = mx * mx + my * my; if (m2 > 6400) { const q = 80 / Math.sqrt(m2); mx *= q; my *= q; }   // ≤ 80 px/s : saut ≤ 2,7 px par image à 30 i/s
      x[i] = X + mx * dt; y[i] = Y + my * dt;
      const am = Math.min(1, dt * 1.8); ux[i] -= ux[i] * am; uy[i] -= uy[i] * am; ev[i] -= ev[i] * Math.min(1, dt / 1.6);
      if (f !== ZOO) rot[i] += om[i] * dt; tl[i] += omt[i] * dt; age[i] += dt;
      const ddx = x[i] - X, ddy = y[i] - Y, sx = Math.sqrt(ddx * ddx + ddy * ddy); if (sx > maxSaut) maxSaut = sx;   // saut euclidien par image
      if (age[i] > vie[i] || y[i] < -20 || y[i] > sc.h + 20 || x[i] < -20 || x[i] > sc.l + 20) { if (i < E0) init(i, f, false); else { on[i] = 0; nEm--; } }
    }
    const ECL = { i: 0, dx: 0, dy: 1, idx: 0, c: 0, r: 0, g: 0, b: 0, rev: 0, expo: 1, froid: 0 }, B = base(), cap = sc.NORME.opaciteMax.particules;
    const STF = PUB.map(pc => STYLE[pc]), BIBO = { at: null, AL: null, P0: 0 };
    let tCol = 0;
    const S0 = {
      regler(kk) { const av = pal; k = kk; pal = palierDe(L, kk); kq = kk <= 0.01 ? 0 : pal === 'sobre' ? 0.15 : pal === 'standard' ? 0.5 : 1; majNQ();
        if (av !== pal && kq > 0) for (let f = 0; f < 6; f++) { poidsPlans(C[FAMS[f]]); for (let i = D0[f]; i < D0[f] + NQ[f]; i++) init(i, f, true); } },   // changement de palier (rare) : replacement unique
      effectif() { let t = 0; for (let f = 0; f < 6; f++) t += NQ[f]; return t + nEm; },
      evenement(type, e) { if (type !== 'rebond') return; perturber(e.x, e.y, 140, 90, 0, 0, true); stimuler(e.x, e.y, 120, 1.2); if (e.y > sc.h * (1 - C.alluvions.hauteur * 1.6) || prochesMur(e.x, e.y, 30)) bouffee(e.x, e.y, 1.5, 0, 0); },
      emettre(qx, qy, pvx, pvy, famille, n2, o) {
        if (famille === 'alluvion' || famille === 'sediment' || famille === 8) { let e = 0; for (let m = 0; m < (n2 || 1); m++) if (bouffee(qx, qy, (o && o.force) || 1, pvx, pvy) >= 0) e++; return e; }
        const pc = typeof famille === 'string' ? LUM.FAMILLES[famille] : famille, f = PUB.indexOf(pc); return emettre(qx, qy, pvx, pvy, f < 0 ? NEI : f, n2, o);
      },
      perturber, stimuler,
      bibliotheque: () => { BIBO.at = at; BIBO.AL = AL; BIBO.P0 = BIB.P0; return BIBO; },
      lireSaut() { const m = maxSaut; maxSaut = 0; return m; },
      stats: () => ({ update: msU, dessin: msD, n: S0.effectif(), alluvions: aon.reduce((a, b) => a + b, 0) }),
      update(dt) {
        const t0 = performance.now(); L.maj(sc.t); if (ver !== VERM) relire(); dtL = dt; if (kq === 0) return;
        if (sc.t - T.t > 0.4) { T.t = sc.t; majTeintes(false); } bande(at); bande(at); bande(AL);
        // retard de l'eau (par plan) et bioluminescence ambiante
        const gNow = E.lum * E.G; for (let q = 0; q < 3; q++) { const tau = C.retard * (q === 2 ? 1 : q === 1 ? 1.5 : 2.2); lagG[q] += (gNow - lagG[q]) * (1 - Math.exp(-dt / Math.max(0.05, tau))); lagR[q] = borne((lagG[q] + 0.04) / (gNow + 0.04), 0.35, 2.4); }
        bioAmb = lisse(0.55, 1, E.bioVis);
        const b = sc.bille, t = sc.t; tT = t;
        if (b) {                                         // bille : écart, remous, bioluminescence, sédiments soulevés
          if (bOk) { const ix = (b.x - bpx) / Math.max(dt, 1e-3), iy = (b.y - bpy) / Math.max(dt, 1e-3); bvx += (ix - bvx) * 0.3; bvy += (iy - bvy) * 0.3; } bpx = b.x; bpy = b.y; bOk = true; bv = Math.hypot(bvx, bvy);
          perturber(b.x, b.y, C.ecart, 120 + 0.4 * Math.min(300, bv), bvx * 0.15, bvy * 0.15, false); stimuler(b.x, b.y, C.ecart * 1.3, dt * (1.5 + bv / 60));
          tBil -= dt; if (tBil < 0 && bv > 35 && (b.y > sc.h * (1 - C.alluvions.hauteur * 1.6) || prochesMur(b.x, b.y, 28))) { tBil = 0.3; bouffee(b.x - bvx * 0.05, b.y + 4, 0.6 + Math.min(1.2, bv / 150) * C.alluvions.bille, bvx, -Math.abs(bvy) * 0.3); }
        } else bOk = false;
        const obst = L.obst; for (let o = 0; o < 8; o++) { const r = obst[o * 3 + 2]; if (r > 0) perturber(obst[o * 3], obst[o * 3 + 1], r + 22, 90, 0, 0, false); }
        const cf = C.courant.force, cs = Math.cos(C.courant.sens * Math.PI) * 0.6, cn = Math.sin(C.courant.sens * Math.PI) * 0.25, tb = C.courant.turb, ke = 1 / Math.max(0.3, C.courant.echelle);
        for (let f = 0; f < 6; f++) { const P = C[FAMS[f]], e = D0[f] + NQ[f]; for (let i = D0[f]; i < e; i++) pas(i, f, dt, t, P, cf, cs, cn, tb, ke); }
        for (let i = E0; i < N; i++) if (on[i]) pas(i, fa[i], dt, t, C[FAMS[fa[i]]], cf, cs, cn, tb, ke);
        if (pal !== 'sobre') majAlluvions(dt);
        msU = performance.now() - t0;
      },
      majExterne(dt, flow, geo) { extFlow = flow || null; extGeo = geo || null; },
      _interne: () => ({ x, y, s, z, va, pl, fa, op, age, vie, n, D0, CAP, lagR, bioAmb, gb, ev, kq, pal, E0, on }),   // tests du banc (lecture seule)
      dessiner(ctx, t, force) {
        if (k <= 0.01 || kq === 0) return; const t0 = performance.now();
        lireBase(B, ctx, force); const bs = B.bs, bx = B.bx, by = B.by, cin = pal === 'cinema', Ga = Math.sqrt(E.Ga), react = C.react, amb = (0.1 + 0.3 * E.diffus) * C.ambiante, att = 1 - 0.3 * L.M.cur.B;
        const im = null, P0 = BIB.P0;
        // 1) alluvions (derrière) : voile de turbidité (source-over, plancher) puis diffusion (lighter)
        const Ca = C.alluvions;
        if (Ca.alpha > 0 && pal !== 'sobre') for (let j = 0; j < NA; j++) {
          if (!aon[j]) continue; const X = ax_[j], Y = ay_[j], R = ar[j], u = aage[j] / avie[j], env = lisse(0, 0.12, u) * (1 - lisse(0.55, 1, u));
          const calm = sc.calme(X, Y) * sc.loinDuBut(X, Y, R * 0.8) * lisse(-R * 0.3, R, Y) * (1 - lisse(sc.h - R, sc.h + R * 0.3, Y)); if (calm < 0.02 || env <= 0) continue;
          L.eclairer(X, Y, ECL); const I = (ECL.i * 2 + 0.05) * lagR[1] * Ga * react, ic = I > 1.3 ? 1.3 : I, bA = env * calm * aop[j] * Ca.alpha * att, d = R * 2.3;
          const c = Math.cos(arot[j]), sn = Math.sin(arot[j]), sx0 = AL.fx(ava[j]);
          ctx.setTransform(bs * c * d / CSA, bs * sn * d / CSA, -bs * sn * d / CSA * 0.62, bs * c * d / CSA * 0.62, bs * X + bx, bs * Y + by);
          if (pal === 'cinema') { ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = Math.min(0.45, bA * Ca.turbidite * 0.5); } else ctx.globalAlpha = 0;   // Standard : diffusion seule (un appel)
          if (pal === 'cinema') ctx.drawImage(AL.TB[AL.row(1, ava[j])], sx0, 0, CSA, CSA, -CSA / 2, -CSA / 2, CSA, CSA);
          ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(cap, bA * (amb * 0.5 + Ca.diffusion * ic * 0.55)); ctx.drawImage(AL.TB[AL.row(0, ava[j])], sx0, 0, CSA, CSA, -CSA / 2, -CSA / 2, CSA, CSA);
        }
        // 2) matière : 3 passes par plan (loin → près)
        ctx.globalCompositeOperation = 'lighter';
        for (let q = 0; q < 3; q++) {
          for (let f = 0; f < 6; f++) { const e = D0[f] + NQ[f]; for (let i = D0[f]; i < e; i++) if (pl[i] === q) tracer(ctx, i, f, t, q, bs, bx, by, cin, Ga, react, amb, att, im, P0); }
          if (q === 1) for (let i = E0; i < N; i++) if (on[i]) tracer(ctx, i, fa[i], t, 1, bs, bx, by, cin, Ga, react, amb, att, im, P0);
        }
        ctx.setTransform(bs, 0, 0, bs, bx, by); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
        msD = performance.now() - t0;
      }
    };
    function tracer(ctx, i, f, t, q, bs, bx, by, cin, Ga, react, amb, att, im, P0) {
      const X = x[i], Y = y[i], u = age[i] / vie[i], env = Math.min(1, u / 0.12, (1 - u) / 0.15); if (env <= 0) return;
      const P = C[FAMS[f]], zz = z[i], zf = 0.62 + 0.8 * zz, bord = lisse(-2, 18, Y) * (1 - lisse(sc.h - 18, sc.h + 2, Y)), flou = P.flou, bl = flou <= 0.15 ? 0 : (zz > 0.9 - 0.08 * flou ? 2 : zz < 0.12 + 0.12 * flou ? 1 : 0);
      let d = s[i] * zf * (bl === 2 ? 1 + 0.8 * flou : 1); if (!cin) d = d * 1.25 > 10 ? 10 : d * 1.25; const calm = sc.calme(X, Y) * sc.loinDuBut(X, Y, d + 4) * bord; if (calm < 0.02) return;
      const St = STF[f], e = L.eclairer(X, Y, ECL);
      const I = (e.i * 2.6 + 0.03) * lagR[q] * Ga * react, ic = I > 1.5 ? 1.5 : I, voile = 0.45 + 0.55 * zz;
      const base = env * calm * op[i] * P.alpha * voile * att * (bl === 2 ? 0.8 : 1) * C.presence * (cin ? 2.2 : 3.2);
      if (base < 0.01) return;
      // bioluminescence : lueur (jeton bio) quand la lumière baisse, plus vive si l'eau est perturbée (≤ 2 Hz, sans flash)
      let gl = 0; if (bio[i] > 0 && P.bio > 0) { const cib = bio[i] * P.bio * (bioAmb * (0.55 + 0.45 * Math.sin(t * 0.9 + ph[i])) + ev[i]); gb[i] += (cib - gb[i]) * (cib > gb[i] ? 0.12 : 0.03); gl = gb[i]; }
      if (f === POU) {                                    // poussière fine : visible surtout dans les faisceaux (∝ I²), scintillement lent
        const tw = 0.55 + 0.45 * Math.sin(t * fq[i] + ph[i]) * P.scint, a = base * (amb * 0.25 + P.diffusion * ic * Math.sqrt(ic) * 2.1) * tw;
        if (a < 0.012) return; const dd = Math.max(1.7, d * 2.7), v = va[i] % 3;
        ctx.setTransform(bs * dd / CS, 0, 0, bs * dd / CS, bs * X + bx, bs * Y + by); ctx.globalAlpha = a > cap ? cap : a; ctx.drawImage(at.TB[at.row(1, P0 + v)], at.fx(P0 + v), 0, CS, CS, -CS / 2, -CS / 2, CS, CS);
        if (gl > 0.02) { ctx.globalAlpha = Math.min(0.5, gl * base * 2); ctx.drawImage(glow, -CS, -CS, CS * 2, CS * 2); }
        return;
      }
      // repère de la forme : rotation, miroir, culbute (aspect), taille ; la forme occupe ≈ 0,8 de la cellule
      const va3 = (f * NVAR + va[i]), tilt = f === ZOO ? 1 : 0.42 + 0.58 * Math.abs(Math.cos(tl[i])), r = rot[i], c = Math.cos(r), sn = Math.sin(r), dd = d / 0.8 * BIB.meta[va3] * (bl === 2 ? 1 / 0.7 : 1);
      const sxf = dd / CS * fl[i], sy = dd / CS * asp[i] * tilt;
      const a0 = bs * c * sxf, b0 = bs * sn * sxf, c0 = -bs * sn * sy, d0 = bs * c * sy, e0 = bs * X + bx, f0 = bs * Y + by;
      // silhouette (Cinéma, premier plan, dans la lumière) : la forme se détache en sombre sur un faisceau
      if (cin && q === 2 && ic > 0.25 && d > 4) { ctx.globalCompositeOperation = 'source-over'; ctx.setTransform(a0, b0, c0, d0, e0, f0); ctx.globalAlpha = Math.min(0.3, base * 0.22 * ic); ctx.drawImage(at.TB[at.row(2, va3)], at.fx(va3), 0, CS, CS, -CS / 2, -CS / 2, CS, CS); ctx.globalCompositeOperation = 'lighter'; }
      // corps : transmission + diffusion (Tyndall) ; ambiante faible hors faisceau
      let aC = base * (0.35 + 0.65 * St.transm) * (amb * 1.2 + P.diffusion * St.diff * ic * 1.3) * (0.3 + P.refraction) / (0.3 + DEFM[FAMS[f]].refraction);   // réfraction / transmission : corps traversé (valeur d'origine = inchangé)
      // liseré côté source (+ point de réfraction opposé cuit) : direction continue (cellule la plus proche + rotation résiduelle)
      const la = Math.atan2(-e.dy, -e.dx); let aL = base * P.reflexion * St.rim * ic * 2 * (bl === 2 ? 0.3 : 1) * (0.75 + 0.25 * P.refraction);
      // Standard : UN seul appel par forme nette — la cellule « liseré » (bord côté source + transmission cuite) porte aussi le corps
      if (!cin) { if (bl === 0 && d > 6 && aL > aC && pal !== 'sobre') { aL += aC * 0.8; aC = 0; } else { aC += aL * 0.6; aL = 0; } }   // petites : corps plein (lisible) ; grandes dans un faisceau : liseré orienté
      if (aC > 0.01) { ctx.setTransform(a0, b0, c0, d0, e0, f0); ctx.globalAlpha = aC > cap ? cap : aC; ctx.drawImage(at.TB[at.row(0, va3 * 3 + bl)], at.fx(va3 * 3 + bl), 0, CS, CS, -CS / 2, -CS / 2, CS, CS); }
      if (aL > 0.015 && pal !== 'sobre') {
        let phs = fl[i] > 0 ? la - r : Math.PI - (la - r); phs -= Math.floor(phs / TAU) * TAU; const kk = Math.round(phs / Q8), res = phs - kk * Q8, kd = kk & 7, cr = Math.cos(res), sr = Math.sin(res);
        const ma = c * sxf * cr - sn * sy * sr, mb = sn * sxf * cr + c * sy * sr, mc = -c * sxf * sr - sn * sy * cr, md = -sn * sxf * sr + c * sy * cr;
        ctx.setTransform(bs * ma, bs * mb, bs * mc, bs * md, e0, f0); ctx.globalAlpha = aL > cap ? cap : aL; const kc = va3 * 8 + kd; ctx.drawImage(at.TB[at.row(1, kc)], at.fx(kc), 0, CS, CS, -CS / 2, -CS / 2, CS, CS);
      }
      // éclat spéculaire (minéraux, paillettes, fibres) : quand la face s'aligne sur la lumière (≤ 0,5 Hz), doux, jamais de flash
      if (P.eclat > 0 && St.glint > 0 && ic > 0.12 && bl !== 2) {
        const al = Math.cos(2 * (r + tl[i] * 0.5 - la)), g12 = al > 0.6 ? Math.pow(al, 12) : 0;
        if (g12 > 0.02) { const ag = base * P.eclat * St.glint * ic * g12 * 3, gs = 2.6 + d * 0.7, ox = Math.cos(la) * d * 0.18, oy = Math.sin(la) * d * 0.18;
          if (ag > 0.015) { ctx.setTransform(bs * gs / CS, 0, 0, bs * gs / CS, bs * (X + ox) + bx, bs * (Y + oy) + by); ctx.globalAlpha = ag > cap ? cap : ag; ctx.drawImage(at.TB[at.row(1, P0 + 3)], at.fx(P0 + 3), 0, CS, CS, -CS / 2, -CS / 2, CS, CS); } }
      }
      if (gl > 0.02) { const gs = d * 2.6 + 5; ctx.setTransform(bs * gs / 32, 0, 0, bs * gs / 32, e0, f0); ctx.globalAlpha = Math.min(0.5, gl * base * 1.6); ctx.drawImage(glow, -16, -16, 32, 32); }
    }
    SYS = S0; return S0;
  }

  /* =====================================================================
     SYSTÈME « BULLES » (remontent) : régimes droit / zigzag / spirale selon la taille, grossissement, oscillation de forme,
     éclatement sous la surface, colonnes en rafales + voiles de microbulles, sillages, bille
     ===================================================================== */
  function systemeBulles(sc, p, L) {
    const id = L.id, E = L.E, ech = Math.max(0.4, sc.l / 390); let C = cfgM(id), ver = VERM, serie = SERIE;
    const A = aleatoire((((sc.alea ? sc.alea() : 0.3) * 4294967296) >>> 0) ^ 0x5bd1);
    let BB = bibBulles(C.graine + SERIE), at = BB.at; const T = { cD: [0, 0, 0], corps: [0, 0, 0], lis: [0, 0, 0], t: -9 };
    teinter(at, 0, L.cFond, true); tonsDe(L, T); teinter(at, 1, T.lis, true);
    const N = Math.round(200 * Math.max(1, ech)), NM = Math.round(520 * Math.max(1, ech));
    const x = new Float32Array(N), y = new Float32Array(N), y0 = new Float32Array(N), r0 = new Float32Array(N), v = new Float32Array(N), ph = new Float32Array(N), fz = new Float32Array(N), az = new Float32Array(N), ux = new Float32Array(N);
    const fo = new Float32Array(N), ao = new Float32Array(N), age = new Float32Array(N), fin = new Float32Array(N), dx0 = new Float32Array(N), op = new Float32Array(N), sil = new Float32Array(N), z = new Float32Array(N), fl = new Float32Array(N);
    const reg = new Uint8Array(N), va = new Uint8Array(N), on = new Uint8Array(N), org = new Uint8Array(N);
    const mx = new Float32Array(NM), my = new Float32Array(NM), mv = new Float32Array(NM), mph = new Float32Array(NM), mage = new Float32Array(NM), mvie = new Float32Array(NM), mz = new Float32Array(NM), ms = new Float32Array(NM), mux = new Float32Array(NM), mamb = new Uint8Array(NM), mon = new Uint8Array(NM), morg = new Uint8Array(NM); let ORG = 0;
    const GRP = [[], [], []]; for (let s = 0; s < NB; s++) GRP[TYPB[s] <= 1 ? 0 : TYPB[s] === 2 ? 1 : 2].push(s);
    const cols = []; function colonnes() { cols.length = 0; const Cc = C.colonnes; for (let i = 0; i < Cc.n; i++) cols.push({ x: melange(Cc.x[0], Cc.x[1], Cc.n === 1 ? 0.5 : i / (Cc.n - 1)) * sc.l + gauss(A) * 6, t: 1 + 3 * A(), rafale: 0, tv: A() }); }
    colonnes();
    let k = 1, kq = 1, pal = 'cinema', nOn = 0, nM = 0, maxSaut = 0, msU = 0, msD = 0, bpx = 0, bpy = 0, bvx = 0, bvy = 0, bOk = false, tSil = 0;
    const yHaut = Math.max(2, 6 - L.oy);
    function naitre(px, py, rr, zz) {
      const Cb = C.bulles, cap = Math.min(N, Math.round(Cb.max * Math.max(1, ech) * (kq < 1 ? 0.6 : 1))); if (nOn >= cap) return -1;
      let j = -1; for (let i = 0; i < N; i++) if (!on[i]) { j = i; break; } if (j < 0) return -1;
      const al = borne(Cb.alea * OVR.alea, 0, 1.5), t0 = Cb.taille[0], t1 = Math.max(t0, Cb.taille[1]);
      const e = borne(Math.abs(gauss(A)) * Cb.sigma / 1.35, 0, 1); r0[j] = borne(rr || t0 * Math.pow(t1 / t0, melange(0.35, e, Math.min(1, al))) * OVR.taille, 0.35, 9);
      const r = r0[j]; reg[j] = r < 1.4 ? 0 : r < 3 ? 1 : 2;                                          // droit / zigzag / spirale
      v[j] = Math.min(32, (r < 1.4 ? 4 + 3.5 * r * r : 13 + 2.6 * r) * (1 + (A() - 0.5) * 0.5 * al)) * Cb.vitesse;   // Stokes puis plateau (ralenti contemplatif)
      fz[j] = (reg[j] === 0 ? 0.15 : reg[j] === 1 ? 0.55 : 0.4) * (1 + (A() - 0.5) * 0.6 * al); az[j] = (reg[j] === 0 ? 0.6 + A() : (1.2 + 0.8 * r) * (0.6 + 0.8 * A() * al + 0.4 * (1 - al))) * Cb.sinuosite;
      fo[j] = 0.7 + 0.9 * A(); ao[j] = (r > 2.4 ? 0.05 + 0.1 * A() * al : 0.015) * Cb.oscillation; ph[j] = A() * TAU; dx0[j] = gauss(A) * 1.2 * al; op[j] = 0.7 + 0.3 * A(); sil[j] = A() * 2;
      const G = GRP[r < 2.4 ? 0 : r < 3.8 ? 1 : 2]; va[j] = G[(A() * G.length * Math.max(0.15, Math.min(1, al))) | 0]; fl[j] = A() < 0.5 ? -1 : 1;
      const wN = 0.12 * Cb.plans, wF = 0.35 * Cb.plans, u = A(); z[j] = zz !== undefined ? zz : u < wF ? 0.1 + 0.3 * A() : u < 1 - wN ? 0.4 + 0.45 * A() : 0.86 + 0.14 * A();
      x[j] = px; y[j] = py; y0[j] = py; age[j] = 0; fin[j] = 0; ux[j] = 0; org[j] = ORG; on[j] = 1; nOn++; return j;
    }
    function micro(px, py, rr, vv, amb) {
      const cap = kq < 1 ? Math.round(14 * Math.max(1, ech)) : NM;   // Standard : 14 microbulles au plus if (nM >= cap) return -1;
      let j = -1; for (let i = 0; i < NM; i++) if (!mon[i]) { j = i; break; } if (j < 0) return -1;
      mx[j] = px; my[j] = py; ms[j] = (rr || 0.35 + 0.7 * A() * A()) * C.microbulles.taille; mv[j] = (vv || 5 + 10 * A()) * C.microbulles.vitesse * (0.6 + 0.6 * A()); mph[j] = A() * TAU; mage[j] = 0; mvie[j] = 6 + 14 * A(); mz[j] = 0.2 + 0.8 * A(); mux[j] = 0; mamb[j] = amb ? 1 : 0; morg[j] = ORG; mon[j] = 1; nM++; return j;
    }
    function voile(px, py, nn, larg) { for (let q = 0; q < nn; q++) micro(px + gauss(A) * larg, py + gauss(A) * larg * 0.6, 0, 0, 0); }
    function relire() { C = cfgM(id); ver = VERM; if (serie !== SERIE) { serie = SERIE; BB = bibBulles(C.graine + SERIE); at = BB.at; teinter(at, 0, L.cFond, true); tonsDe(L, T); teinter(at, 1, T.lis, true); GRP.forEach(g => (g.length = 0)); for (let s = 0; s < NB; s++) GRP[TYPB[s] <= 1 ? 0 : TYPB[s] === 2 ? 1 : 2].push(s); } colonnes(); }
    let nAmb = 0;
    function maj(dt, t) {
      const Cb = C.bulles, Cc = C.colonnes, Cm = C.microbulles, deb = Cb.debit * OVR.debit;
      ORG = 1;
      for (const c of cols) {                                   // colonnes : rafales irrégulières (Poisson), tailles mélangées, voile de microbulles
        c.t -= dt * deb * Cc.rafales; if (c.t < 0) { c.rafale = 1 + ((A() * 4 * Cb.alea + 1) | 0); c.t = (0.8 + 5 * A() * A()) * (1 + Cb.alea); }
        c.tv += dt * Cc.voile * deb * 6 * (kq < 1 ? 0.3 : 1); while (c.tv > 1) { c.tv -= 1; micro(c.x + gauss(A) * 7 * Cc.largeur, sc.h + 2, 0, 0, 0); }
        if (c.rafale > 0 && A() < dt * 6) { naitre(c.x + gauss(A) * (2 + 3 * Cb.alea) * Cc.largeur, sc.h + 4, 0); c.rafale--; }
      }
      ORG = 0;
      if (A() < dt * Cb.libres * deb) naitre(A() * sc.l, sc.h + 4, 0);
      if (A() < dt * Cb.libres * deb * 0.25) { const px = A() * sc.l, nn = 3 + ((A() * 5) | 0); for (let q = 0; q < nn; q++) naitre(px + gauss(A) * 5, sc.h + 4 + A() * 12, 0); }   // grappe
      const cibleAmb = Math.round(Cm.n * Math.max(1, ech) * (kq < 1 ? 0.3 : 1)); while (nAmb < cibleAmb) { if (micro(A() * sc.l, sc.h * (0.2 + 0.85 * A()), 0, 0, 1) < 0) break; nAmb++; }
      if (A() < dt * Cm.voile * 0.12) voile(A() * sc.l, sc.h * (0.55 + 0.4 * A()), 8 + ((A() * 14) | 0), 10);   // voile isolé (nuage de microbulles)
      const b = sc.bille;
      if (b) { if (bOk) { bvx += ((b.x - bpx) / Math.max(dt, 1e-3) - bvx) * 0.3; bvy += ((b.y - bpy) / Math.max(dt, 1e-3) - bvy) * 0.3; } bpx = b.x; bpy = b.y; bOk = true;
        const bv = Math.hypot(bvx, bvy); tSil -= dt; if (bv > 70 && tSil < 0) { tSil = 0.09 / Cb.sillage; micro(b.x - bvx * 0.04 + gauss(A) * 3, b.y - bvy * 0.04 + gauss(A) * 3, 0.4 + 0.5 * A(), 4 + 6 * A(), 0); } } else bOk = false;
      for (let i = 0; i < N; i++) {
        if (!on[i]) continue; const X = x[i], Y = y[i], f = sc.flux(X, Y);
        age[i] += dt; const h = borne((y0[i] - Y) / sc.h, 0, 1), r = r0[i] * (1 + 0.2 * Cb.grossit * h), vit = v[i] * (1 + 0.1 * h);
        const latP = reg[i] === 0 ? az[i] * 0.5 * fz[i] * TAU * Math.cos(t * fz[i] * TAU + ph[i]) * 0.3 : az[i] * fz[i] * TAU * Math.cos(age[i] * fz[i] * TAU + ph[i]);
        if (b) { const dx = X - b.x, dy = Y - b.y, d2 = dx * dx + dy * dy, R = 30 + r * 2; if (d2 < R * R) { const d = Math.sqrt(d2) + 0.5; ux[i] += dx / d * 140 * (1 - d / R) * dt * 8 * Cb.bille; } }
        ux[i] -= ux[i] * Math.min(1, dt * 2.5); if (ux[i] > 60) ux[i] = 60; else if (ux[i] < -60) ux[i] = -60;
        let wx = f[0] * 0.25 * sc.courant * C.courant.force + dx0[i] + latP + ux[i], wy = -(vit - f[1] * 0.2); const w2 = wx * wx + wy * wy;
        if (w2 > 7225) { const q = 85 / Math.sqrt(w2); wx *= q; wy *= q; }   // ≤ 85 px/s : saut ≤ 2,9 px par image à 30 i/s
        x[i] += wx * dt; y[i] += wy * dt;
        const sx = Math.sqrt(wx * wx + wy * wy) * dt; if (sx > maxSaut) maxSaut = sx;
        if (reg[i] === 2 && A() < dt * 0.3 * sil[i] * Cb.sillage) micro(x[i] + gauss(A), y[i] + r * 2, 0.35 + 0.4 * A(), vit * 0.5, 0);   // sillage de microbulles
        if (y[i] < yHaut + r && !fin[i]) fin[i] = 0.001;
        if (fin[i]) { fin[i] += dt; if (fin[i] > 0.4) { on[i] = 0; nOn--; const m = Math.round((r > 1.6 ? 2 + 3 * A() : A() < 0.4 ? 1 : 0) * Cb.eclatement); for (let q = 0; q < m; q++) { const j = micro(x[i] + gauss(A) * r, y[i] + 3 + A() * 4, 0.3 + 0.4 * A(), 2 + 3 * A(), 0); if (j >= 0) mvie[j] = 1.5 + 2 * A(); } } }   // éclatement : quelques microbulles
        if (x[i] < -20 || x[i] > sc.l + 20) { on[i] = 0; nOn--; }
      }
      for (let i = 0; i < NM; i++) {
        if (!mon[i]) continue; const X = mx[i], Y = my[i], f = sc.flux(X, Y); mage[i] += dt;
        if (b) { const dx = X - b.x, dy = Y - b.y, d2 = dx * dx + dy * dy; if (d2 < 900) { const d = Math.sqrt(d2) + 0.5; mux[i] += dx / d * 120 * (1 - d / 30) * dt * 6; } }
        mux[i] -= mux[i] * Math.min(1, dt * 2.5);
        mx[i] += (f[0] * 0.3 * C.courant.force + 1.2 * Math.sin(t * 1.3 + mph[i]) + mux[i]) * dt; my[i] -= (mv[i] - f[1] * 0.2) * (0.5 + 0.7 * mz[i]) * dt;
        if (mage[i] > mvie[i] || my[i] < yHaut || mx[i] < -10 || mx[i] > sc.l + 10) { mon[i] = 0; nM--; if (mamb[i]) nAmb--; }
      }
    }
    const ECL = { i: 0, dx: 0, dy: 1, idx: 0, c: 0, r: 0, g: 0, b: 0, rev: 0, expo: 1, froid: 0 }, Bt = base(), cap = sc.NORME.opaciteMax.particules;
    let lagG = 1, lagR = 1;
    const S0 = {
      regler(kk) { k = kk; pal = palierDe(L, kk); kq = kk <= 0.01 || pal === 'sobre' ? 0 : pal === 'standard' ? 0.8 : 1; },
      effectif: () => nOn + nM,
      update(dt) {
        const t0 = performance.now(); L.maj(sc.t); if (ver !== VERM) relire(); if (kq === 0) return;
        if (sc.t - T.t > 0.4) { T.t = sc.t; tonsDe(L, T); teinter(at, 1, T.lis, false); } bande(at);
        const gNow = E.lum * E.G; lagG += (gNow - lagG) * (1 - Math.exp(-dt / Math.max(0.05, C.retard * 1.3))); lagR = borne((lagG + 0.04) / (gNow + 0.04), 0.35, 2.4);
        maj(dt * (0.55 + 0.45 * kq), sc.t); msU = performance.now() - t0;
      },
      dessiner(ctx, t, force) {
        if (k <= 0.01 || kq === 0) return; const t0 = performance.now(); lireBase(Bt, ctx, force);
        const bs = Bt.bs, bx = Bt.bx, by = Bt.by, Ga = Math.sqrt(E.Ga), Cb = C.bulles, Cm = C.microbulles, react = C.react, amb = (0.1 + 0.3 * E.diffus) * C.ambiante, CSb = CSB;
        // microbulles et voiles : points qui scintillent dans les faisceaux (ref2)
        ctx.globalCompositeOperation = 'lighter';
        const aM0 = Cm.alpha, aMc = C.colonnes.alpha, PB = SYS ? SYS.bibliotheque() : null;
        if (PB && aM0 + aMc > 0) { const imP = PB.at.TB[PB.at.row(1, PB.P0 + 4)], sx4 = PB.at.fx(PB.P0 + 4);
          for (let i = 0; i < NM; i++) { if (!mon[i]) continue; const X = mx[i], Y = my[i], u = mage[i] / mvie[i], env = Math.min(1, u / 0.1, (1 - u) / 0.15); if (env <= 0) continue;
            const calm = sc.calme(X, Y) * sc.loinDuBut(X, Y, 4); if (calm < 0.02) continue; L.eclairer(X, Y, ECL);
            const I = (ECL.i * 2 + 0.04) * lagR * Ga * react, ic = I > 1.4 ? 1.4 : I, tw = 0.6 + 0.4 * Math.sin(t * 2.2 + mph[i]) * Cm.scint;
            const a = env * calm * (0.4 + 0.6 * mz[i]) * (morg[i] ? aMc : aM0) * (amb * 0.4 + ic * 1.1) * tw * C.presence * 1.8; if (a < 0.012) continue; const d = Math.max(1.2, ms[i] * 3.2 * (0.6 + 0.6 * mz[i]));
            ctx.setTransform(bs * d / CS, 0, 0, bs * d / CS, bs * X + bx, bs * Y + by); ctx.globalAlpha = a > cap ? cap : a; ctx.drawImage(imP, sx4, 0, CS, CS, -CS / 2, -CS / 2, CS, CS); } }
        // bulles : limbe sombre (source-over) puis lumière (anneau de réflexion totale, croissant côté source, image renversée, reflet) orientée sans saut
        const aB0 = Cb.alpha, aBc = Cb.alpha * C.colonnes.alpha;
        if (aB0 > 0) for (let i = 0; i < N; i++) {
          if (!on[i]) continue; const h = borne((y0[i] - y[i]) / sc.h, 0, 1), r = r0[i] * (1 + 0.2 * Cb.grossit * h), X = x[i], Y = y[i];
          const calm = sc.calme(X, Y) * sc.loinDuBut(X, Y, r + 4) * lisse(-2, 14, Y); if (calm < 0.02) continue;
          const env = Math.min(1, age[i] / 0.6) * (fin[i] ? Math.max(0, 1 - fin[i] / 0.4) : 1); if (env <= 0) continue;
          L.eclairer(X, Y, ECL); const I = (ECL.i * 1.7 + 0.08) * lagR * Ga * react, ic = I > 1.3 ? 1.3 : I, la = Math.atan2(-ECL.dy, -ECL.dx), zz = z[i];
          const base = env * calm * op[i] * (org[i] ? aBc : aB0) * (0.45 + 0.55 * zz) * (zz > 0.85 ? 0.7 : 1) * C.presence * 1.8, rr = r * (0.7 + 0.6 * zz) * (zz > 0.85 ? 1.35 : 1);
          if (r < 1.1) {                                    // petite bulle : point
            const d = Math.max(1.3, rr * 3.2), a = base * (0.15 * amb + 0.85 * ic); if (a < 0.012 || !PB) continue;
            ctx.setTransform(bs * d / CS, 0, 0, bs * d / CS, bs * X + bx, bs * Y + by); ctx.globalAlpha = a > cap ? cap : a; ctx.drawImage(PB.at.TB[PB.at.row(1, PB.P0 + 4)], PB.at.fx(PB.P0 + 4), 0, CS, CS, -CS / 2, -CS / 2, CS, CS); continue;
          }
          const pop = fin[i] ? 1 - 0.45 * Math.min(1, fin[i] / 0.4) : 1;                                         // aplatissement à l'éclatement
          const osc = 1 + ao[i] * Math.sin(t * fo[i] * TAU + ph[i]), spir = reg[i] === 2 ? 0.86 + 0.14 * Math.cos(age[i] * fz[i] * TAU + ph[i]) : 1;
          const k2 = rr / (CSb * 0.36), sxx = k2 * osc * 1.04 * spir * fl[i], syy = k2 / osc * 0.96 * pop;
          if (kq === 1 || rr > 2.6) { ctx.globalCompositeOperation = 'source-over'; ctx.setTransform(bs * sxx, 0, 0, bs * syy, bs * X + bx, bs * Y + by); ctx.globalAlpha = Math.min(0.5, base * 0.6);
          ctx.drawImage(at.TB[at.row(0, va[i])], at.fx(va[i]), 0, CSb, CSb, -CSb / 2, -CSb / 2, CSb, CSb); }   // Standard : limbe sombre seulement pour les grosses
          ctx.globalCompositeOperation = 'lighter';
          let phs = fl[i] > 0 ? la : Math.PI - la; phs -= Math.floor(phs / TAU) * TAU; const kk = Math.round(phs / Q8), res = phs - kk * Q8, kd = kk & 7, cr = Math.cos(res), sr = Math.sin(res);
          const a = base * Cb.reflexion * (0.22 * amb + 0.85 * ic) * (0.7 + 0.3 * Cb.refraction); if (a < 0.012) continue;
          ctx.setTransform(bs * sxx * cr, bs * syy * sr, -bs * sxx * sr, bs * syy * cr, bs * X + bx, bs * Y + by); ctx.globalAlpha = a > 0.85 ? 0.85 : a;
          const kc = va[i] * 8 + kd; ctx.drawImage(at.TB[at.row(1, kc)], at.fx(kc), 0, CSb, CSb, -CSb / 2, -CSb / 2, CSb, CSb);
        }
        ctx.setTransform(bs, 0, 0, bs, bx, by); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; msD = performance.now() - t0;
      },
      emettre(px, py, n2, rr) { let e = 0; for (let m = 0; m < (n2 || 1); m++) if ((rr && rr < 1 ? micro(px + gauss(A) * 3, py, rr, 0, 0) : naitre(px + gauss(A) * 3, py, rr)) >= 0) e++; return e; },
      voile, reglages(o) { if (o.alea !== undefined) OVR.alea = borne(o.alea, 0, 1.5); if (o.debit !== undefined) OVR.debit = borne(o.debit / Math.max(0.01, C.bulles.debit), 0, 6); if (o.taille !== undefined) OVR.taille = borne(o.taille, 0.3, 3); },
      perturber(qx, qy, R, force) { for (let i = 0; i < N; i++) if (on[i]) { const dx = x[i] - qx, dy = y[i] - qy, d = Math.hypot(dx, dy) + 0.5; if (d < R) ux[i] += dx / d * force * 0.4 * (1 - d / R); } },
      bibliotheque: () => ({ at, typ: TYPB }), lireSaut() { const m = maxSaut; maxSaut = 0; return m; }, stats: () => ({ update: msU, dessin: msD, n: nOn, micro: nM })
    };
    SYSB = S0; return S0;
  }

  /* =====================================================================
     BRANCHEMENT dans QXLUMIERE (éléments du pool) + API
     ===================================================================== */
  K.brancher({
    creerP(sc, p) { if (coupe()) return inerte; return systemeMatiere(sc, p, scene(sc)); },
    creerB(sc, p) { if (coupe()) return inerte; return systemeBulles(sc, p, scene(sc)); },
    particules(o) { if (o.densite !== undefined) OVR.densite = borne(o.densite, 0, 2.5); if (o.diversite !== undefined) OVR.diversite = borne(o.diversite, 0, 1); VERM++; },
    bulles(o) { if (SYSB) SYSB.reglages(o); },
    bibliotheque() { return { particules: SYS ? SYS.bibliotheque() : null, bulles: SYSB ? SYSB.bibliotheque() : null }; },
    dessinerSysteme(nom, ctx, t, force) { const s = nom === 'bulles' ? SYSB : SYS; if (s) s.dessiner(ctx, t, force !== false); },
    lireSaut() { return Math.max(SYS ? SYS.lireSaut() : 0, SYSB ? SYSB.lireSaut() : 0); }
  });
  /* Galerie (banc) : bibliothèque de formes réelle, teinte courante, liseré pour une direction de lumière */
  function galerie(ctx, mode, W, H, dir) {
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    const kd = ((Math.round((dir === undefined ? -2.3 : dir) / Q8) % 8) + 8) % 8;
    if (mode === 'particules' && SYS) {
      const { at } = SYS.bibliotheque(), cell = Math.floor(Math.min(W / 8, H / 10)), noms = ['neige', 'détritus', 'minéraux', 'phyto', 'zoo'];
      ctx.globalCompositeOperation = 'lighter';
      for (let f = 0; f < NFL; f++) for (let v = 0; v < NVAR; v++) { const s = f * NVAR + v, X = (v % 8) * cell, Y = (f * 2 + (v >> 3)) * cell; ctx.globalAlpha = 0.85; ctx.drawImage(at.TB[at.row(0, s * 3)], at.fx(s * 3), 0, CS, CS, X, Y, cell, cell); ctx.globalAlpha = 1; ctx.drawImage(at.TB[at.row(1, s * 8 + kd)], at.fx(s * 8 + kd), 0, CS, CS, X, Y, cell, cell); }
      ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = 'rgba(160,190,200,0.8)'; ctx.font = Math.max(9, cell * 0.22) + 'px system-ui'; noms.forEach((nm, f) => ctx.fillText(nm, 2, f * 2 * cell + 11));
      return;
    }
    if (mode === 'bulles' && SYSB) {
      const { at } = SYSB.bibliotheque(), cols = 9, cell = Math.floor(Math.min(W / cols, H / 4));
      for (let s = 0; s < NB; s++) { const X = (s % cols) * cell, Y = ((s / cols) | 0) * cell; ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 0.6; ctx.drawImage(at.TB[at.row(0, s)], at.fx(s), 0, CSB, CSB, X, Y, cell, cell); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1; ctx.drawImage(at.TB[at.row(1, s * 8 + kd)], at.fx(s * 8 + kd), 0, CSB, CSB, X, Y, cell, cell); }
      ctx.globalCompositeOperation = 'source-over'; return;
    }
    if (mode === 'alluvions' && SYS) {
      const { AL } = SYS.bibliotheque(), cell = Math.floor(Math.min(W / 4, H / 2));
      for (let v = 0; v < NAV; v++) { const X = (v % 4) * cell, Y = ((v / 4) | 0) * cell; ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(AL.TB[AL.row(0, v)], AL.fx(v), 0, CSA, CSA, X, Y, cell, cell); }
      ctx.globalCompositeOperation = 'source-over';
    }
  }
  racine.QXMATIERE = {
    version: 1, DEF: DEFM, CFG: CFGM, FAMILLES: FAMS, LIM,
    maj() { VERM++; }, nouvelleSerie() { SERIE++; VERM++; return SERIE; }, serie: () => SERIE,
    galerie, stats() { return { particules: SYS ? SYS.stats() : null, bulles: SYSB ? SYSB.stats() : null, bandes: NBANDES }; },
    get particules() { return SYS; }, get bulles() { return SYSB; }
  };
  /* QXALLUVIONS : couche partagée (ambiantes + créatures L3 + moteurs de niveau L3). Les créatures et moteurs de niveau ne sont PAS câblés en L2. */
  racine.QXALLUVIONS = {
    FAMILLES: LUM.FAMILLES,
    emettre(x, y, vx, vy, famille, n, opts) {   // famille : 'bulle' | 'microbulle' | 'alluvion' | 'neige' | 'detritus' | 'mineraux' | 'phytoplancton' | 'zooplancton' | 'poussiere'
      if (!PHASE.alluvions) return 0; const f = typeof famille === 'string' ? LUM.FAMILLES[famille] : famille;
      if (f === 0 || f === 1) return SYSB ? SYSB.emettre(x, y, n, f === 1 ? 0.5 : opts && opts.rayon) : 0;
      return SYS ? SYS.emettre(x, y, vx, vy, famille, n, opts) : 0;
    },
    perturber(x, y, rayon, force, vx, vy, inst) { if (!PHASE.alluvions) return; if (SYS) SYS.perturber(x, y, rayon, force, vx, vy, inst); if (SYSB) SYSB.perturber(x, y, rayon, force); },
    stimuler(x, y, rayon, k) { if (PHASE.alluvions && SYS) SYS.stimuler(x, y, rayon, k === undefined ? 1 : k); },   // bioluminescence déclenchée
    update(dt, flow, geo) { if (SYS && PHASE.niveau) SYS.majExterne(dt, flow, geo); },                              // L3 : courant, vent, puits, aimants (éteint)
    sillage(x, y, vx, vy, taille) {
      if (!PHASE.alluvions) return; const v = Math.min(1, Math.hypot(vx || 0, vy || 0) / 120), t = taille || 1;
      if (SYSB && v > 0.2) SYSB.emettre(x, y, 1 + ((v * 2) | 0), 0.6);
      if (SYS) { SYS.perturber(x, y, 26 * t + 14, 110 * v, vx, vy); SYS.stimuler(x, y, 30 * t, v); }
    },
    get instance() { return SYS; }, get bulles() { return SYSB; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
