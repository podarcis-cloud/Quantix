/* ===== ETAGE 8B DEBUT ===== R517 · Monde 8 — étage 8 des créatures actives, 2e créature : la FRONDE (cténophore)
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage7d.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans fronde : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : window.QXE6.fronde (table de dessin appelée par qxcrea.js dessinerAct) ; corps pré-calculé en atlas (rangées de palettes
     ciliées irisées dont l'onde court du pôle à la bouche), fabriqué image par image à la demande (≈ 1 ms la première fois, puis rien).
   fronde (cténophore, groseille de mer : Pleurobrachia / Mertensia) : un ovoïde de verre vivant qui nage lentement en boucle
          (x ± ax, y ± ay, pulsation w, phase ph ; cap = sens de nage, jamais de demi-tour), deux longs tentacules à tentilles traînant
          dans son sillage. Au contact (rayon r) elle CAPTE la particule par son courant cilié et la fait GRAVITER autour d'elle
          (rayon R, vitesse angulaire om rad/image, sens = sens d'arrivée), la boucle se resserre doucement ; au moins mn degrés
          parcourus, elle la LIBÈRE TANGENTIELLEMENT quand la tangente de l'orbite passe par le cap la (degrés), avec un gain doux :
          vitesse = vitesse d'arrivée + dv, bornée vmin..vmax. Pause cd. Elle n'absorbe jamais : la particule reste dehors, tenue
          au bout d'un tentacule.
          Effet neuf : une FRONDE VIVANTE — capture en orbite lente puis lancer tangent dans un cap fixe, avec un gain d'élan.
   Tout est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1 (crForce d'origine). */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e8b) return;
F.e8b = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180, TAU = Math.PI * 2;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'fronde'); CACHE.set(cr, v); } return v; }
function segD(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let u = l > 1e-9 ? ((px - ax) * dx + (py - ay) * dy) / l : 0; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const x = ax + dx * u - px, y = ay + dy * u - py; return Math.sqrt(x * x + y * y); }
const sm = u => (u = u < 0 ? 0 : u > 1 ? 1 : u, u * u * (3 - 2 * u));
const wrap = a => a - Math.floor(a / TAU) * TAU;            // [0, 2π)
/* nage en boucle lente (ellipse) : le cap tourne toujours dans le même sens */
function frPos(e, t) { const w = e.w || .006, a = t * w + (e.ph || 0); return [e.x + (e.ax || 0) * Math.cos(a), e.y + (e.ay || 0) * Math.sin(a)]; }
/* orbite : angle et rayon de la particule autour du centre, u images après la capture */
function orb(e, st, u) { const om = e.om || .05; return [st.p0 + st.dir * om * u, st.R0 + ((e.R || 30) - st.R0) * sm(u / 30)]; }
F.crPos = function (e, t) { return e.t === 'fronde' ? frPos(e, t) : oPos(e, t); };
F.e8bPos = frPos;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  let ax = b.cpx == null ? b.x : b.cpx, ay = b.cpy == null ? b.y : b.cpy;
  oForce(b, sub, lv, g);                                // autres créatures + remise à zéro (frames<=1)
  if ((ax - b.x) * (ax - b.x) + (ay - b.y) * (ay - b.y) > 900) { ax = b.x; ay = b.y; }
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'fronde') continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0 }), q = frPos(e, t);
    if (st.h) {
      const u = t - st.in, o = orb(e, st, u), om = e.om || .05, tau = o[0] + st.dir * Math.PI / 2, la = (e.la || 0) * D2R;
      if (u * om >= (e.mn == null ? 220 : e.mn) * D2R && wrap(st.dir * (la - tau)) < om + 1e-9) {   // lâcher tangent, cap la
        const sp = Math.max(e.vmin || 2.5, Math.min(e.vmax || 7, st.vin + (e.dv == null ? 1.5 : e.dv)));
        b.x = q[0] + o[1] * Math.cos(o[0]); b.y = q[1] + o[1] * Math.sin(o[0]);
        b.vx = Math.cos(la) * sp; b.vy = Math.sin(la) * sp; st.h = 0; st.out = t; st.cd = t + (e.cd || 90);
        if (racine.BUS) BUS.emit('creature.spit', { x: b.x, y: b.y });
      } else {
        const q1 = frPos(e, t + 1), o1 = orb(e, st, u + 1);
        b.x = q[0] + o[1] * Math.cos(o[0]); b.y = q[1] + o[1] * Math.sin(o[0]);
        b.vx = q1[0] + o1[1] * Math.cos(o1[0]) - b.x; b.vy = q1[1] + o1[1] * Math.sin(o1[0]) - b.y - gg / sub;
      }
    } else if (t >= st.cd && segD(q[0], q[1], ax, ay, b.x, b.y) < (e.r || 28)) {
      const rx = b.x - q[0], ry = b.y - q[1], cz = rx * b.vy - ry * b.vx;
      st.h = 1; st.in = t; st.vin = Math.hypot(b.vx, b.vy); st.p0 = Math.atan2(ry, rx); st.R0 = Math.max(6, Math.hypot(rx, ry));
      st.dir = e.sens ? (e.sens > 0 ? 1 : -1) : (cz >= 0 ? 1 : -1); st.out = null;
      if (racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
    }
  }
  b.cpx = b.x; b.cpy = b.y;
};

/* ───────────── RENDU ─────────────
   Corps : ovoïde épais de verre vivant (dégradé de volume, liseré, reflet, pharynx et canaux vus par transparence), huit rangées
   de palettes ciliées dont l'onde d'irisation (bleu, cyan, violet — jamais d'or) court du pôle aboral vers la bouche ; statocyste
   au pôle. Repère de l'atlas : bouche vers +x (devant), pôle vers -x. Tentacules : partent des deux gaines latérales, traînent sur
   la route passée (crPos(t-k·pas)) en ondulant ; tentilles en fines boucles. En capture, un tentacule se tend vers la particule. */
const NA = 16, AW = 64, AH = 52, DPR = 2, BL = 22, BH = 16;
let ATL = null, GLOW = null; const FAIT = new Uint8Array(NA);
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function corps(g, f) {
  const ph = f / NA * TAU;
  g.save(); g.translate((f * AW + AW / 2) * DPR, AH / 2 * DPR); g.scale(DPR, DPR); g.lineCap = 'round'; g.lineJoin = 'round';
  /* profil ovoïde (bouche un peu plus étroite) : jamais une ellipse parfaite */
  const pt = (s, k) => { const a = s * TAU, cx = Math.cos(a), sy = Math.sin(a); const w = BH * (1 - .13 * cx) * (1 + .025 * Math.sin(ph + a * 2));
    return [BL * cx * (1 + .04 * cx), w * sy * k]; };
  const path = k => { g.beginPath(); for (let i = 0; i <= 40; i++) { const p = pt(i / 40, k); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.closePath(); };
  const halo = g.createRadialGradient(0, 0, 4, 0, 0, 30); halo.addColorStop(0, 'rgba(120,190,255,.16)'); halo.addColorStop(1, 'rgba(80,120,255,0)');
  g.fillStyle = halo; g.fillRect(-32, -26, 64, 52);
  path(1); const gr = g.createLinearGradient(0, -BH, 0, BH);
  gr.addColorStop(0, 'rgba(226,246,255,.62)'); gr.addColorStop(.28, 'rgba(150,204,246,.5)'); gr.addColorStop(.62, 'rgba(70,110,196,.48)'); gr.addColorStop(1, 'rgba(26,34,92,.66)');
  g.fillStyle = gr; g.fill();
  g.save(); g.clip();
  const vg = g.createRadialGradient(-6, -6, 2, 0, 0, 26); vg.addColorStop(0, 'rgba(255,255,255,.2)'); vg.addColorStop(.7, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(10,14,50,.35)');
  g.fillStyle = vg; g.fillRect(-26, -20, 52, 40);
  /* pharynx (aplati, de la bouche vers le centre) et canaux méridiens */
  g.fillStyle = 'rgba(190,170,255,.22)'; g.beginPath(); g.ellipse(9, 0, 11, 3.4 + .4 * Math.sin(ph), 0, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(170,220,255,.22)'; g.lineWidth = .8; g.beginPath(); g.moveTo(-2, 0); g.lineTo(-17, 0); g.stroke();
  /* gaines des tentacules (deux poches latérales sombres) */
  g.fillStyle = 'rgba(40,60,140,.35)'; for (const s of [-1, 1]) { g.beginPath(); g.ellipse(-4, s * 8, 6, 2.2, s * .25, 0, TAU); g.fill(); }
  /* huit rangées de palettes : quatre visibles devant, quatre derrière (plus pâles) ; l'onde d'irisation court du pôle (-x) à la bouche (+x) */
  for (let r = 0; r < 8; r++) {
    const k = Math.cos((r + .5) / 8 * Math.PI), front = r < 4 ? 1 : 0, kk = r < 4 ? k : -Math.cos((r - 3.5) / 8 * Math.PI);
    for (let j = 0; j < 13; j++) {
      const s = .5 + (j / 12 - .5) * .78, p = pt(s, kk * .92), w = Math.sin(j * .9 - ph * 2), a = Math.max(0, w);
      const hue = 190 + 90 * (.5 + .5 * Math.sin(j * .55 - ph * 2 + r)), al = (front ? .2 : .08) + (front ? .55 : .2) * a * a;
      g.fillStyle = 'hsla(' + hue.toFixed(0) + ',90%,' + (62 + 18 * a).toFixed(0) + '%,' + al.toFixed(2) + ')';
      g.beginPath(); g.ellipse(p[0], p[1], 1.5, .7 + .5 * a, 0, 0, TAU); g.fill();
    }
  }
  g.restore();
  path(1); g.strokeStyle = 'rgba(228,246,255,.72)'; g.lineWidth = 1; g.stroke();
  /* lèvre de la bouche, statocyste au pôle, reflet */
  g.strokeStyle = 'rgba(236,250,255,.7)'; g.lineWidth = 1.2; g.beginPath(); g.ellipse(BL * 1.02, 0, 1.6, 5, 0, -1.4, 1.4); g.stroke();
  g.fillStyle = 'rgba(190,255,236,' + (.5 + .3 * Math.sin(ph)) + ')'; g.beginPath(); g.arc(-BL + 2.4, 0, 1.6, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.6; g.beginPath(); g.ellipse(-2, -2, 15, 10, 0, -2.5, -1.3); g.stroke();
  g.restore();
}
let NF = 0;
/* image f de l'atlas (fabriquée à la demande) ; en plus, une seule image manquante par appel est préparée d'avance (petite tranche
   ≈ 1 ms) : pendant l'attente avant le lâcher, l'atlas se complète sans à-coup */
function cadre(f) { if (!ATL) ATL = cv(AW * DPR * NA, AH * DPR); const g = ATL.getContext('2d');
  if (!FAIT[f]) { corps(g, f); FAIT[f] = 1; NF++; }
  else if (NF < NA) { let k = f; while (FAIT[k]) k = (k + 1) % NA; corps(g, k); FAIT[k] = 1; NF++; }
  return ATL; }
function glow() {
  if (GLOW) return GLOW; const s = 128, c = cv(s, s), g = c.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  r.addColorStop(0, 'rgba(150,215,255,.5)'); r.addColorStop(.45, 'rgba(140,130,255,.15)'); r.addColorStop(1, 'rgba(90,110,220,0)'); g.fillStyle = r; g.fillRect(0, 0, s, s); return (GLOW = c);
}
const NT = 20, PAS = 5;
function cap(c, t) { const a = frPos(c, t - 2), b = frPos(c, t + 2); const dx = b[0] - a[0], dy = b[1] - a[1];
  return Math.abs(dx) + Math.abs(dy) < 1e-6 ? -Math.PI / 2 : Math.atan2(dy, dx); }
function dessinerFronde(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, ph = c.ph || 0;
  st = run ? (st || {}) : {};
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, held = run && st.h && b;
  const p = frPos(c, t), h = cap(c, t) + .1 * Math.sin(t * .021 + ph);           // la tête mène : léger lacet
  e.cf8 = ((e.cf8 || 0) + dt * (held ? .95 : .55)) % 1; const fi = Math.floor(e.cf8 * NA) % NA, A = cadre(fi);
  const near = b && run ? Math.max(0, 1 - Math.hypot(b.x - p[0], b.y - p[1]) / 120) : 0, lum = held ? .85 : .3 + .45 * near;
  e.lum8 = (e.lum8 == null ? lum : e.lum8 + (lum - e.lum8) * Math.min(1, dt * 3));
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* tentacules : nés aux gaines, ils suivent la route passée (sillage), ondulent ; tenue, le premier se tend vers la particule */
  const ch = Math.cos(h), sh = Math.sin(h), tg = held ? sm((fr - st.in) / 20) : 0;
  ctx.beginPath(); const TT = [];
  for (const s of [-1, 1]) {
    const ox = p[0] - 4 * ch - s * 8 * sh, oy = p[1] - 4 * sh + s * 8 * ch, pts = [];
    for (let k = 0; k <= NT; k++) {
      const tk = t - k * PAS, q = frPos(c, tk), hk = cap(c, tk), w = Math.sin(tk * .03 - k * .5 + s * 1.3 + ph) * (2 + k * .55);
      let X = q[0] - (14 + k * 2.2) * Math.cos(hk) - Math.sin(hk) * (s * (8 + k * .9) + w), Y = q[1] - (14 + k * 2.2) * Math.sin(hk) + Math.cos(hk) * (s * (8 + k * .9) + w);
      const u = k / NT; X = X + (ox - X) * Math.pow(1 - u, 6); Y = Y + (oy - Y) * Math.pow(1 - u, 6);
      if (held && s < 0) { const m = tg * sm(u * 1.5); const lx = ox + (b.x - ox) * u, ly = oy + (b.y - oy) * u;
        const bow = 10 * Math.sin(u * Math.PI) * Math.sin(fr * .05); X += (lx + bow * sh - X) * m; Y += (ly - bow * ch - Y) * m; }
      pts.push([X, Y]);
    }
    TT.push(pts); ctx.moveTo(pts[0][0], pts[0][1]);
    for (let k = 1; k < NT; k++) ctx.quadraticCurveTo(pts[k][0], pts[k][1], (pts[k][0] + pts[k + 1][0]) / 2, (pts[k][1] + pts[k + 1][1]) / 2);
  }
  ctx.strokeStyle = 'rgba(120,170,240,.16)'; ctx.lineWidth = 4.2; ctx.stroke();      // gaine (volume)
  ctx.strokeStyle = 'rgba(200,232,255,.55)'; ctx.lineWidth = 1.5; ctx.stroke();      // tentacule
  ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = .5; ctx.stroke();       // reflet
  /* tentilles : fines boucles qui frémissent le long des tentacules */
  ctx.beginPath();
  for (const pts of TT) for (let k = 3; k < NT - 3; k++) {
    const a = pts[k], n = pts[k + 1], dx = n[0] - a[0], dy = n[1] - a[1], l = Math.hypot(dx, dy) || 1, sg = k & 1 ? 1 : -1, nx = -dy / l * sg, ny = dx / l * sg;
    const ln = (4 + 2 * Math.sin(t * .04 + k)) * (1 - k / NT * .5), cu = 2.5 * Math.sin(t * .05 + k * 1.7);
    ctx.moveTo(a[0], a[1]); ctx.quadraticCurveTo(a[0] + nx * ln * .6 + dx / l * cu, a[1] + ny * ln * .6 + dy / l * cu, a[0] + nx * ln - dx / l * 2, a[1] + ny * ln - dy / l * 2);
  }
  ctx.strokeStyle = 'rgba(200,226,255,.3)'; ctx.lineWidth = .7; ctx.stroke();
  /* lueur : discrète, plus vive quand la particule approche ou tourne */
  ctx.globalCompositeOperation = 'lighter';
  const gs = 60 + 34 * e.lum8; ctx.globalAlpha = .3 + .5 * e.lum8; ctx.drawImage(GLOW || glow(), p[0] - gs / 2, p[1] - gs / 2, gs, gs);
  if (held) { ctx.globalAlpha = .45; ctx.drawImage(GLOW, b.x - 15, b.y - 15, 30, 30); }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  /* corps : orienté selon le cap ; respiration et roulis lent (écrasement doux, jamais sous 0,82 : le corps reste épais) */
  const rl = .91 + .09 * Math.cos(t * .013 + ph), br = 1 + .03 * Math.sin(t * .05 + ph);
  ctx.translate(p[0], p[1]); ctx.rotate(h); ctx.scale(br, rl / br);
  ctx.drawImage(A, fi * AW * DPR, 0, AW * DPR, AH * DPR, -AW / 2, -AH / 2, AW, AH);
  ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).fronde = dessinerFronde;
racine.QXE8B = { fronde: dessinerFronde, cadre };
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 8B FIN ===== */
