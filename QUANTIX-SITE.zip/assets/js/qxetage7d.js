/* ===== ETAGE 7D DEBUT ===== R512 · Monde 7 (7) — étage 7 des créatures actives : la VORTICELLE
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage7b.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans vorticelle : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : window.QXE6.vort (table de dessin appelée par qxcrea.js dessinerAct) ; cloche pré-calculée en atlas (cils qui battent).
   vort (colonie de vorticelles, d'après ref2) : une touffe ancrée en (x,y) ; de fins pédoncules ramifiés portent des cloches
          translucides qui se balancent. La cloche « chasseuse » est au bout d'un pédoncule de longueur L, direction a (degrés),
          balancement ±sw degrés (pulsation w, phase ph). Au contact (rayon r) elle CUEILLE la particule dans sa coupe (sans l'absorber),
          puis le pédoncule SE BANDE LENTEMENT (dur images) : la cloche recule en arc vers la direction arm (degrés), longueur La.
          Au bout de la tension, le pédoncule SE CONTRACTE D'UN COUP EN TIRE-BOUCHON et la particule part, catapultée avec une vitesse
          et une direction fixées (v, la degrés). Le pédoncule se redéploie ensuite lentement (cd images) : RESSORT VIVANT.
   Tout est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1 (crForce d'origine). */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7d) return;
F.e7d = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'vort'); CACHE.set(cr, v); } return v; }
const sm = u => (u = u < 0 ? 0 : u > 1 ? 1 : u, u * u * (3 - 2 * u));
function restAng(e, t) { return ((e.a == null ? -90 : e.a) + (e.sw == null ? 9 : e.sw) * Math.sin(t * (e.w || .012) + (e.ph || 0))) * D2R; }
/* état du pédoncule chasseur : [angle rad, longueur, contraction 0..1] */
function vState(e, t, st) {
  const L = e.L || 150;
  if (st && st.h) { const s = sm((t - st.in) / (e.dur || 80)), ar = (e.arm == null ? (e.a == null ? -90 : e.a) : e.arm) * D2R;
    let d = ar - st.a; d -= Math.round(d / (Math.PI * 2)) * Math.PI * 2; return [st.a + d * s, L + ((e.La || L * .8) - L) * s, 0]; }
  const ra = restAng(e, t);
  if (st && st.out != null && t - st.out < (e.cd || 170)) {
    const u = t - st.out, ar = st.ra, k = u < 7 ? sm(u / 7) : 1 - sm((u - 10) / ((e.cd || 170) - 10));   // coup sec puis redéploiement lent
    let d = ra - ar; d -= Math.round(d / (Math.PI * 2)) * Math.PI * 2; const s = sm((u - 6) / ((e.cd || 170) - 6));
    return [ar + d * s, L * (1 - .62 * k) + (st.rl - L) * (1 - s) * (1 - k), k];
  }
  return [ra, L, 0];
}
function vPos(e, t, st) { const v = vState(e, t, st); return [e.x + v[1] * Math.cos(v[0]), e.y + v[1] * Math.sin(v[0])]; }
F.crPos = function (e, t) { return e.t === 'vort' ? vPos(e, t) : oPos(e, t); };
F.e7dPos = vPos; F.e7dState = vState;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  oForce(b, sub, lv, g);                                // autres créatures + remise à zéro (frames<=1)
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'vort') continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0 });
    if (st.h) {
      const dur = e.dur || 80;
      if (t - st.in >= dur) {                           // détente en tire-bouchon : catapulte
        const v = vState(e, t, st), la = (e.la || 0) * D2R, sp = e.v || 4;
        b.vx = Math.cos(la) * sp; b.vy = Math.sin(la) * sp; st.h = 0; st.out = t; st.ra = v[0]; st.rl = v[1]; st.cd = t + (e.cd || 170);
        if (racine.BUS) BUS.emit('creature.spit', { x: b.x, y: b.y });
      } else {
        const q = vPos(e, t, st), q1 = vPos(e, t + 1, st), k = Math.min(1, (t - st.in) / 16), m = sm(k);
        const tx = st.cx + (q[0] - st.cx) * m, ty = st.cy + (q[1] - st.cy) * m, k1 = sm(Math.min(1, (t + 1 - st.in) / 16));
        const nx = st.cx + (q1[0] - st.cx) * k1, ny = st.cy + (q1[1] - st.cy) * k1;
        b.x = tx; b.y = ty; b.vx = nx - tx; b.vy = ny - ty - gg / sub;
      }
    } else if (t >= st.cd) {
      const q = vPos(e, t, st);
      if (Math.hypot(b.x - q[0], b.y - q[1]) < (e.r || 22)) {
        const v = vState(e, t, st); st.h = 1; st.in = t; st.a = v[0]; st.cx = b.x; st.cy = b.y; st.out = null;
        if (racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
      }
    }
  }
};

/* ───────────── RENDU ─────────────
   Cloche : corps en coupe évasée, épais et éclairé (dégradé latéral de volume, liseré, reflet), péristome bordé de cils qui battent
   (NA images d'une onde métachronale), vacuoles et macronoyau en C vus par transparence. Pédoncules : traits fins à double ton
   (gaine claire + fil spasmonème sombre) ; en contraction, le pédoncule s'enroule en tire-bouchon. */
const NA = 12, AW = 48, AH = 56, DPR = 2;
let ATL = null, GLOW = null;
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
/* R518 · atlas fabriqué image par image, en tâche de fond dès le chargement d'un niveau à vorticelle (comme 7a) :
   plus de saccade au premier dessin ; une image pas encore faite est remplacée par la plus proche déjà faite. */
let AG = null, FAIT = null, NFAIT = 0, PRE = 0;
function atlas() {
  if (!ATL) { ATL = cv(AW * DPR * NA, AH * DPR); AG = ATL.getContext('2d'); FAIT = new Uint8Array(NA); }
  return ATL;
}
function atlasF(f) {
  atlas(); if (FAIT[f]) return; FAIT[f] = 1; NFAIT++;
  const g = AG;
  {
    const ph = f / NA * Math.PI * 2; g.save(); g.translate((f * AW + AW / 2) * DPR, 6 * DPR); g.scale(DPR, DPR); g.lineCap = 'round'; g.lineJoin = 'round';
    /* repère : bouche (péristome) en haut (y≈6), base (pied) en bas (y≈44) ; la cloche « respire » légèrement */
    const br = 1 + .04 * Math.sin(ph), RW = 15 * br, top = 6, bot = 44;
    /* profil de cloche renversée : lèvre légèrement évasée, ventre rond, col concave vers le pied (jamais un cône droit) */
    const prof = u => RW * (Math.pow(Math.cos(Math.min(1, u) * Math.PI / 2), .62) * (1 - .12 * u) + .1 * Math.exp(-u * 14) - .05 * Math.sin(u * Math.PI)) + 1.4 * u;
    const path = () => { g.beginPath(); const N = 24; for (let k = 0; k <= N; k++) { const u = k / N; g.lineTo(prof(u), top + u * (bot - top)); }
      for (let k = N; k >= 0; k--) { const u = k / N; g.lineTo(-prof(u), top + u * (bot - top)); } g.closePath(); };
    /* cils du péristome (couronne qui bat, onde qui fait le tour) */
    g.beginPath();
    for (let k = 0; k < 15; k++) { const s = -1 + 2 * k / 14, x0 = s * RW * 1.02, y0 = top - 1.5 + Math.abs(s) * 1.2, p = ph * 2 - k * .7;
      const ln = 6 + 1.5 * Math.cos(k * 1.3), bend = 3.2 * Math.sin(p);
      g.moveTo(x0, y0); g.quadraticCurveTo(x0 + s * 2 + bend * .4, y0 - ln * .55, x0 + s * 3.5 + bend, y0 - ln); }
    g.strokeStyle = 'rgba(205,240,255,.55)'; g.lineWidth = .6; g.stroke();
    path(); const gr = g.createLinearGradient(-RW, 0, RW, 0);
    gr.addColorStop(0, 'rgba(36,62,110,.6)'); gr.addColorStop(.22, 'rgba(150,206,240,.55)'); gr.addColorStop(.4, 'rgba(222,246,255,.62)');
    gr.addColorStop(.66, 'rgba(120,160,226,.45)'); gr.addColorStop(1, 'rgba(32,36,92,.62)'); g.fillStyle = gr; g.fill();
    g.save(); g.clip();
    const vg = g.createLinearGradient(0, top, 0, bot); vg.addColorStop(0, 'rgba(255,255,255,.14)'); vg.addColorStop(.6, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(20,20,60,.3)');
    g.fillStyle = vg; g.fillRect(-RW - 2, top, RW * 2 + 4, bot - top);
    /* macronoyau en C, vacuoles (une contractile qui pulse), granules */
    g.strokeStyle = 'rgba(190,176,255,.34)'; g.lineWidth = 1.7; g.beginPath(); g.moveTo(6, 13); g.bezierCurveTo(-4, 14, -5, 25, 1, 29); g.stroke();
    const vp = .5 + .5 * Math.sin(ph); g.fillStyle = 'rgba(150,255,226,' + (.25 + .3 * vp) + ')'; g.beginPath(); g.arc(-6, 15, 2.2 + 1.2 * vp, 0, 7); g.fill();
    g.fillStyle = 'rgba(200,236,255,.35)'; for (const [x, y, r] of [[5, 13, 1.6], [-3, 30, 1.8], [6, 31, 1.3], [-8, 22, 1.2], [2, 36, 1.1], [-1, 12, 1.1]]) { g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); }
    g.restore();
    path(); g.strokeStyle = 'rgba(232,248,255,.8)'; g.lineWidth = 1; g.stroke();
    /* lèvre du péristome (bourrelet épais éclairé) */
    g.beginPath(); g.ellipse(0, top, RW, 2.6, 0, 0, Math.PI * 2); g.fillStyle = 'rgba(170,220,250,.35)'; g.fill(); g.strokeStyle = 'rgba(240,252,255,.85)'; g.lineWidth = 1.1; g.stroke();
    /* reflet latéral */
    g.beginPath(); for (let k = 2; k <= 18; k++) { const u = k / 24; g.lineTo(-prof(u) * .6, top + u * (bot - top)); } g.strokeStyle = 'rgba(255,255,255,.38)'; g.lineWidth = 1.5; g.stroke();
    g.restore();
  }
}
function prechauffe() {
  if (PRE) return; PRE = 1; atlas(); glow();
  const pas = () => { const t0 = performance.now(); let f = 0;
    while (NFAIT < NA && performance.now() - t0 < 2) { while (FAIT[f]) f++; atlasF(f); }
    if (NFAIT < NA) (racine.requestAnimationFrame || setTimeout)(pas); };
  pas();
}
function proche(fi) { if (FAIT[fi]) return fi; for (let d = 1; d < NA; d++) { const a = (fi + d) % NA, b = (fi - d + NA) % NA; if (FAIT[a]) return a; if (FAIT[b]) return b; } atlasF(fi); return fi; }
function glow() {
  if (GLOW) return GLOW; const s = 128, c = cv(s, s), g = c.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  r.addColorStop(0, 'rgba(150,225,255,.5)'); r.addColorStop(.45, 'rgba(120,160,255,.16)'); r.addColorStop(1, 'rgba(90,110,220,0)'); g.fillStyle = r; g.fillRect(0, 0, s, s); return (GLOW = c);
}
/* pédoncule de (x0,y0) à (x1,y1), courbé de cb px, enroulé (k 0..1) en tire-bouchon — ajouté au chemin courant (un seul tracé pour
   toute la colonie : deux stroke par image) */
function tige(ctx, x0, y0, x1, y1, cb, k) {
  const dx = x1 - x0, dy = y1 - y0, l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l, N = k > .02 ? 30 : 6, tours = 5.5;
  for (let i = 0; i <= N; i++) { const u = i / N, c = 4 * u * (1 - u) * cb, sp = k > .02 ? k * 5 * Math.sin(u * tours * Math.PI * 2) * Math.min(1, u * 4, (1 - u) * 6) : 0;
    const x = x0 + dx * u + nx * (c + sp), y = y0 + dy * u + ny * (c + sp); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
}
function tracer(ctx, w) {
  ctx.strokeStyle = 'rgba(150,200,235,.3)'; ctx.lineWidth = w + 2.2; ctx.stroke();      // gaine
  ctx.strokeStyle = 'rgba(214,242,255,.62)'; ctx.lineWidth = w; ctx.stroke();           // tige
}
function cloche(ctx, A, fi, x, y, ang, s, alpha) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang + Math.PI / 2); ctx.scale(s, s); ctx.globalAlpha = alpha;
  fi = proche(fi); ctx.drawImage(A, fi * AW * DPR, 0, AW * DPR, AH * DPR, -AW / 2, -6, AW, AH); ctx.restore();
}
/* figurants de la colonie : branches fixées sur le tronc (fraction f du tronc), direction relative da, longueur l, échelle s */
const FIG = [[.5, -58, .62, .8], [.8, 46, .56, .74]];
function dessinerVort(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const A = atlas(), G = glow(), c = e.c, ph = c.ph || 0; if (!PRE) prechauffe();
  st = run ? (st || {}) : {};
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, held = run && st.h && b;
  const v = vState(c, t, run ? st : null), L = c.L || 150, bx = c.x, by = c.y;
  const hx = bx + v[1] * Math.cos(v[0]), hy = by + v[1] * Math.sin(v[0]);
  const tens = held ? sm((fr - st.in) / (c.dur || 80)) : 0;
  e.cf7 = ((e.cf7 || 0) + dt * (held ? 1.6 : .7)) % 1; const fi = Math.floor(e.cf7 * NA) % NA;
  const near = b && run ? Math.max(0, 1 - Math.hypot(b.x - hx, b.y - hy) / 110) : 0, lum = held ? .6 + .4 * tens : .3 + .4 * near;
  e.lum7 = (e.lum7 == null ? lum : e.lum7 + (lum - e.lum7) * Math.min(1, dt * 4));
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* tronc commun : de l'ancrage vers le point de ramification (la tige chasseuse en part) */
  const ra = restAng(c, t * .5), tl = Math.min(L * .5, 70), jx = bx + tl * Math.cos(ra), jy = by + tl * Math.sin(ra);
  ctx.beginPath(); tige(ctx, bx, by, jx, jy, 2, 0); tracer(ctx, 2.1);
  const B = [];
  /* figurants : balancement propre ; de temps en temps l'un d'eux se contracte et se redéploie lentement */
  for (let i = 0; i < FIG.length; i++) {
    const f = FIG[i], ox = bx + (jx - bx) * f[0], oy = by + (jy - by) * f[0];
    const per = 520 + 130 * i, u = (t + i * 233 + ph * 90) % per, kk = u < 6 ? sm(u / 6) : u < 150 ? 1 - sm((u - 6) / 144) : 0;
    const a = ra + (f[1] + 7 * Math.sin(t * .011 * (1 + .17 * i) + i * 1.9 + ph)) * D2R, l = L * f[2] * (1 - .6 * kk);
    const sc = f[3] * (1 - .25 * kk), lb = Math.max(l, 44 * sc + 10); const ex = ox + lb * Math.cos(a), ey = oy + lb * Math.sin(a), fx = ex - 38 * sc * Math.cos(a), fy = ey - 38 * sc * Math.sin(a);
    B.push([ox, oy, fx, fy, 4 * Math.sin(t * .013 + i), kk, ex, ey, a + .12 * Math.sin(t * .02 + i), sc, (fi + i * 3) % NA]);
  }
  /* tige chasseuse : arc de tension pendant le bandage (elle ploie), tire-bouchon à la détente */
  const cb = held ? 14 * tens * (1 + .08 * Math.sin(fr * .9)) : 5 * Math.sin(t * .017 + ph);
  const ca = Math.atan2(hy - jy, hx - jx), cs = (1 - .15 * v[2]) * (held ? 1 - .08 * tens : 1);
  ctx.beginPath(); for (const q of B) tige(ctx, q[0], q[1], q[2], q[3], q[4], q[5]);
  tige(ctx, jx, jy, hx - 38 * cs * Math.cos(ca), hy - 38 * cs * Math.sin(ca), cb, v[2]); tracer(ctx, held ? 1.3 + .5 * tens : 1.2);
  for (const q of B) cloche(ctx, A, q[10], q[6], q[7], q[8], q[9], .78);
  ctx.globalCompositeOperation = 'lighter';
  const gs = 44 + 26 * e.lum7; ctx.globalAlpha = .45 + .5 * e.lum7; ctx.drawImage(G, hx - gs / 2, hy - gs / 2, gs, gs);
  ctx.globalCompositeOperation = 'source-over';
  /* la cloche s'oriente selon sa tige ; tenue, elle se resserre un peu sur la particule (sans l'avaler) */
  cloche(ctx, A, fi, hx, hy, ca, cs, .95);
  if (held) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .35 + .35 * tens; ctx.drawImage(G, b.x - 16, b.y - 16, 32, 32); }
  ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).vort = dessinerVort;
racine.QXE7D = { vort: dessinerVort, atlas, prechauffe };
function accroche() {
  const ll = racine.loadLevel; if (typeof ll !== 'function' || ll.e7d) return;
  const w = racine.loadLevel = function (i) { const r = ll.apply(this, arguments);
    try { const lv = racine.LEVELS && racine.LEVELS[i]; if (lv && lv.cr && lv.cr.some(c => c.t === 'vort')) prechauffe(); } catch (e) {} return r; };
  w.e7d = 1;
}
if (typeof document !== 'undefined') { if (document.readyState === 'complete') accroche(); else racine.addEventListener('load', accroche); }
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 7D FIN ===== */
