/* ===== ETAGE 7D DEBUT ===== R512 (rendu refait R522) · Monde 7 (7) — étage 7 des créatures actives : la VORTICELLE
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage7b.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans vorticelle : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : window.QXE6.vort (table de dessin appelée par qxcrea.js dessinerAct) ; cloche pré-calculée en atlas (cils qui battent).
   vort (colonie de vorticelles, d'après ref2) : une touffe ancrée en (x,y) ; de fins pédoncules ramifiés portent des cloches
          translucides qui se balancent. La cloche « chasseuse » est au bout d'un pédoncule de longueur L, direction a (degrés),
          balancement ±sw degrés (pulsation w, phase ph). Au contact (rayon r) elle CUEILLE la particule dans sa coupe (sans l'absorber),
          puis le pédoncule SE BANDE LENTEMENT (dur images) : la cloche recule en arc vers la direction arm (degrés), longueur La.
          Au bout de la tension, le pédoncule SE CONTRACTE D'UN COUP EN TIRE-BOUCHON et la particule part, catapultée avec une vitesse
          et une direction fixées (v, la degrés). Le pédoncule se redéploie ensuite lentement (cd images) : RESSORT VIVANT.
   Tout est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1 (crForce d'origine). */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7d) return;
F.e7d = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'vort'); CACHE.set(cr, v); } return v; }
const sm = u => (u = u < 0 ? 0 : u > 1 ? 1 : u, u * u * (3 - 2 * u));
function restAng(e, t) { return ((e.a == null ? -90 : e.a) + (e.sw == null ? 9 : e.sw) * Math.sin(t * (e.w || .012) + (e.ph || 0))) * D2R; }
/* état du pédoncule chasseur : [angle rad, longueur, contraction 0..1] */
function vState(e, t, st) {
  const L = e.L || 150;
  if (st && st.h) { const s = sm((t - st.in) / (e.dur || 80)), ar = (e.arm == null ? (e.a == null ? -90 : e.a) : e.arm) * D2R;
    let d = ar - st.a; d -= Math.round(d / (Math.PI * 2)) * Math.PI * 2; return [st.a + d * s, L + ((e.La || L * .8) - L) * s, 0]; }
  const ra = restAng(e, t);
  if (st && st.out != null && t - st.out < (e.cd || 170)) {
    const u = t - st.out, ar = st.ra, k = u < 7 ? sm(u / 7) : 1 - sm((u - 10) / ((e.cd || 170) - 10));   // coup sec puis redéploiement lent
    let d = ra - ar; d -= Math.round(d / (Math.PI * 2)) * Math.PI * 2; const s = sm((u - 6) / ((e.cd || 170) - 6));
    return [ar + d * s, L * (1 - .62 * k) + (st.rl - L) * (1 - s) * (1 - k), k];
  }
  return [ra, L, 0];
}
function vPos(e, t, st) { const v = vState(e, t, st); return [e.x + v[1] * Math.cos(v[0]), e.y + v[1] * Math.sin(v[0])]; }
F.crPos = function (e, t) { return e.t === 'vort' ? vPos(e, t) : oPos(e, t); };
F.e7dPos = vPos; F.e7dState = vState;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  oForce(b, sub, lv, g);                                // autres créatures + remise à zéro (frames<=1)
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'vort') continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0 });
    if (st.h) {
      const dur = e.dur || 80;
      if (t - st.in >= dur) {                           // détente en tire-bouchon : catapulte
        const v = vState(e, t, st), la = (e.la || 0) * D2R, sp = e.v || 4;
        b.vx = Math.cos(la) * sp; b.vy = Math.sin(la) * sp; st.h = 0; st.out = t; st.ra = v[0]; st.rl = v[1]; st.cd = t + (e.cd || 170);
        if (racine.BUS) BUS.emit('creature.spit', { x: b.x, y: b.y });
      } else {
        const q = vPos(e, t, st), q1 = vPos(e, t + 1, st), k = Math.min(1, (t - st.in) / 16), m = sm(k);
        const tx = st.cx + (q[0] - st.cx) * m, ty = st.cy + (q[1] - st.cy) * m, k1 = sm(Math.min(1, (t + 1 - st.in) / 16));
        const nx = st.cx + (q1[0] - st.cx) * k1, ny = st.cy + (q1[1] - st.cy) * k1;
        b.x = tx; b.y = ty; b.vx = nx - tx; b.vy = ny - ty - gg / sub;
      }
    } else if (t >= st.cd) {
      const q = vPos(e, t, st);
      if (Math.hypot(b.x - q[0], b.y - q[1]) < (e.r || 22)) {
        const v = vState(e, t, st); st.h = 1; st.in = t; st.a = v[0]; st.cx = b.x; st.cy = b.y; st.out = null;
        if (racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
      }
    }
  }
};

/* ───────────── RENDU R522 (refonte complète, d'après ref2-vorticelle.mp4) ─────────────
   La physique ci-dessus est INCHANGÉE (octet pour octet) ; tout ce qui suit est du dessin pur.
   · ZOOÏDES (cloches) : verre épais translucide, pré-rendus en ATLAS (5 degrés de fermeture × 8 phases de la couronne ciliée) :
     chair sombre qui absorbe le fond, teinte volumique, bord intérieur lumineux en 4 passes (aucun contour net), stries de la
     pellicule, grain fin, vacuoles alimentaires (anneau éclairé + reflet), vacuole contractile qui bat, macronoyau en fer à cheval,
     fibrilles du myonème qui montent dans la cloche, lèvre du péristome en bourrelet (avant éclairé), disque buccal, couronne de
     cils (40) en onde métachronale. Fermée, la cloche s'arrondit en dôme et rentre ses cils (comme la vidéo).
   · PÉDONCULE : un seul arbre continu (raccords C1 aux fourches), tube translucide (chair sombre + deux parois lumineuses) avec
     fibre contractile interne (myonème) en hélice ; à la détente il s'enroule EN SPIRALE 3D (brins avant éclairés), puis se
     redéploie lentement. L'onde part de la cloche : le tronc suit avec retard (visco-élastique), la cloche penche en retard puis
     dépasse. Une perle de lumière remonte le pédoncule vers la cloche.
   · LUMIÈRE : bioluminescence interne douce (couleur du monde), halo multicouche qui s'intensifie à l'approche et à la prise.
   · PALETTE : Monde 7 (Gravité) pervenche/lilas ; Monde 8 (Magnétisme) lilas rosé. Pas de blanc plein, pas d'or. */
const TAU = Math.PI * 2, cl1 = v => v < 0 ? 0 : v > 1 ? 1 : v;
const hs = n => { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };
const rgba = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
const wrapA = d => d - Math.round(d / TAU) * TAU;
const PAL = {
  7: { c1: [176, 192, 255], c2: [236, 240, 255], c3: [10, 10, 36], ac: [198, 168, 255], a2: [164, 206, 255] },
  8: { c1: [206, 184, 255], c2: [248, 236, 255], c3: [20, 8, 36], ac: [246, 164, 236], a2: [196, 196, 255] }
};
const NK = 5, NP = 8, CW = 60, CH = 76, OY = 15, PXA = 2.6;   // cellule : bouche en (CW/2, OY), pied à OY + 46
const PO = [[0, 17], [2.5, 14.6], [7, 14.9], [14, 13.8], [22, 11.4], [30, 7.4], [37, 3.9], [42, 2.4], [46, 1.8]];   // ouverte (calice)
const PCF = [[9, 3.8], [11, 10.2], [16, 13.6], [23, 13.8], [30, 10.6], [36, 6.2], [40.5, 3.4], [43.5, 2.3], [46, 1.8]];   // fermée (dôme)
function profil(k) {
  const P = PO.map((p, i) => [p[0] + (PCF[i][0] - p[0]) * k, p[1] + (PCF[i][1] - p[1]) * k]), n = P.length, Y = [], R = [];
  for (let i = 0; i < n - 1; i++) { const p0 = P[Math.max(0, i - 1)], p1 = P[i], p2 = P[i + 1], p3 = P[Math.min(n - 1, i + 2)];
    for (let j = 0; j < 5; j++) { const t = j / 5, t2 = t * t, t3 = t2 * t, f = (a, b, c, d) => .5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      Y.push(f(p0[0], p1[0], p2[0], p3[0])); R.push(f(p0[1], p1[1], p2[1], p3[1])); } }
  Y.push(P[n - 1][0]); R.push(P[n - 1][1]);
  return { Y, R, y0: P[0][0], r0: P[0][1], eb: P[0][1] * (.24 + .34 * k) };
}
function rAt(Pf, y) { const Y = Pf.Y, R = Pf.R; if (y <= Y[0]) return R[0]; for (let i = 1; i < Y.length; i++) if (Y[i] >= y) { const u = (y - Y[i - 1]) / ((Y[i] - Y[i - 1]) || 1); return R[i - 1] + (R[i] - R[i - 1]) * u; } return R[R.length - 1]; }
function corps(g, Pf, sc) {
  const Y = Pf.Y, R = Pf.R; sc = sc || 1; g.beginPath(); g.moveTo(-Pf.r0 * sc, Pf.y0); g.ellipse(0, Pf.y0, Pf.r0 * sc, Pf.eb * sc, 0, Math.PI, TAU, false);
  for (let i = 1; i < Y.length; i++) g.lineTo(R[i] * sc, Y[i]); for (let i = Y.length - 1; i >= 1; i--) g.lineTo(-R[i] * sc, Y[i]); g.closePath();
}
/* une image clé de zooïde (repère : bouche en 0, pied en +46) */
function cle(g, k, p, C) {
  const Pf = profil(k), K1 = C.c1, K2 = C.c2, K3 = C.c3, KA = C.ac, KB = C.a2, op = 1 - k, y0 = Pf.y0, r0 = Pf.r0, eb = Pf.eb;
  const mx = (x, y) => x * (1 - .08 * k), my = y => y + k * 9 * (1 - y / 46);   // contenu interne : suit l'arrondi de la cloche
  g.lineCap = 'round'; g.lineJoin = 'round';
  /* cils de l'arrière (derrière la lèvre) */
  const cils = back => { g.beginPath(); const N = 40;
    for (let i = 0; i < N; i++) { const th = (i + .5) / N * TAU, s = Math.sin(th); if ((s < 0) !== back) continue;
      const rx = r0 * Math.cos(th) * .95, ry = y0 + eb * s * .95; let dx = Math.cos(th) * .85, dy = -.72 + .18 * s; const dl = Math.hypot(dx, dy); dx /= dl; dy /= dl;
      const Lc = (6.2 + 1.8 * hs(i * 2.3)) * Math.pow(op, 1.4), bt = .62 * Math.sin(TAU * p - th * 3), cb = Math.cos(bt), sb = Math.sin(bt), ex = dx * cb - dy * sb, ey = dx * sb + dy * cb;
      g.moveTo(rx, ry); g.quadraticCurveTo(rx + dx * Lc * .55, ry + dy * Lc * .55, rx + ex * Lc, ry + ey * Lc); }
    g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(K2, 1);
    g.globalAlpha = (back ? .04 : .07) * op; g.lineWidth = 1.5; g.stroke(); g.globalAlpha = (back ? .2 : .46) * op; g.lineWidth = .42; g.stroke(); };
  if (op > .03) cils(true);
  /* 1. halo externe doux */
  corps(g, Pf); g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(K1, 1);
  g.globalAlpha = .045; g.lineWidth = 7.5; g.stroke(); g.globalAlpha = .08; g.lineWidth = 3.6; g.stroke();
  /* 2. chair sombre (absorbe le décor : la cloche se détache) */
  g.globalCompositeOperation = 'source-over'; g.fillStyle = rgba(K3, 1); g.globalAlpha = .62; g.fill();
  /* 3. teinte volumique : flancs plus lumineux (verre épais vu de biais), haut éclairé par la bouche */
  g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1;
  let gr = g.createLinearGradient(-17, 0, 17, 0);
  gr.addColorStop(0, rgba(K1, .3)); gr.addColorStop(.28, rgba(K1, .09)); gr.addColorStop(.55, rgba(K1, .06)); gr.addColorStop(.85, rgba(K1, .13)); gr.addColorStop(1, rgba(K1, .22));
  g.fillStyle = gr; g.fill();
  gr = g.createLinearGradient(0, y0 - 4, 0, 46); gr.addColorStop(0, rgba(K2, .14)); gr.addColorStop(.5, rgba(K1, .03)); gr.addColorStop(1, rgba(K1, 0)); g.fillStyle = gr; g.fill();
  g.save(); g.clip();
  /* 4. bord intérieur lumineux (4 passes, le côté gauche reçoit la lumière) : pas de contour net */
  gr = g.createLinearGradient(-17, 0, 17, 0); gr.addColorStop(0, rgba(K2, 1)); gr.addColorStop(.5, rgba(K1, .75)); gr.addColorStop(1, rgba(K1, .6));
  g.strokeStyle = gr; for (const [w, a] of [[10, .05], [5.5, .09], [2.8, .17], [1.2, .44]]) { g.globalAlpha = a; g.lineWidth = w; g.stroke(); }
  /* 5. stries de la pellicule (anneaux très pâles qui épousent la rondeur) */
  g.beginPath(); for (let y = y0 + 4; y < 42; y += 3.1) { const r = rAt(Pf, y) * .98; g.moveTo(-r, y); g.quadraticCurveTo(0, y + r * .3, r, y); }
  g.strokeStyle = rgba(K2, 1); g.globalAlpha = .06; g.lineWidth = .35; g.stroke();
  /* 6. fibrilles du myonème qui montent du pied dans la cloche */
  g.beginPath(); for (let j = -2; j <= 2; j++) { g.moveTo(j * .35, 46); g.quadraticCurveTo(j * 1.3, 39, j * 3.4, my(27)); }
  g.strokeStyle = rgba(K1, 1); g.globalAlpha = .16; g.lineWidth = .45; g.stroke();
  /* 7. grain fin (endoplasme) */
  for (let pass = 0; pass < 2; pass++) { g.beginPath();
    for (let i = pass; i < 170; i += 2) { const y = my(3 + 38 * hs(i * 1.7)), r = rAt(Pf, y) * .8, x = (hs(i * 3.3) * 2 - 1) * r, rr = .22 + .42 * hs(i * 5.1); g.moveTo(x + rr, y); g.arc(x, y, rr, 0, TAU); }
    g.fillStyle = rgba(pass ? KA : K2, 1); g.globalAlpha = pass ? .3 : .22; g.fill(); }
  /* 8. vacuoles alimentaires : creux sombre, anneau éclairé, reflet */
  const VAC = [[-5, 10, 2.4], [4.5, 12.5, 1.8], [-6.8, 19, 2.0], [6, 20.5, 2.6], [-2, 27, 1.6], [3, 31, 1.4], [.5, 16.5, 1.2], [-3.5, 33.5, 1.1]];
  for (const v of VAC) { const x = mx(v[0]), y = my(v[1]), r = v[2];
    g.globalCompositeOperation = 'source-over'; g.fillStyle = rgba(K3, 1); g.globalAlpha = .26; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(K2, 1); g.globalAlpha = .34; g.lineWidth = .55; g.stroke();
    g.fillStyle = rgba(K2, 1); g.globalAlpha = .55; g.beginPath(); g.arc(x - r * .38, y - r * .38, r * .22, 0, TAU); g.fill(); }
  /* 9. macronoyau en fer à cheval (bande teintée, bord interne plus sombre) + micronoyau */
  g.globalCompositeOperation = 'lighter';
  g.beginPath(); g.moveTo(mx(6), my(9.5)); g.bezierCurveTo(mx(-3), my(7.5), mx(-9), my(16), mx(-5), my(23)); g.bezierCurveTo(mx(-2), my(28), mx(4.5), my(27.5), mx(5.5), my(24));
  g.strokeStyle = rgba(KA, 1); g.globalAlpha = .13; g.lineWidth = 4.8; g.stroke(); g.globalAlpha = .26; g.lineWidth = 2.9; g.stroke();
  g.globalCompositeOperation = 'source-over'; g.strokeStyle = rgba(K3, 1); g.globalAlpha = .3; g.lineWidth = 1; g.stroke();
  g.globalCompositeOperation = 'lighter'; g.fillStyle = rgba(KA, 1); g.globalAlpha = .5; g.beginPath(); g.arc(mx(-1), my(18), .9, 0, TAU); g.fill();
  /* 10. vacuole contractile qui bat (gonfle puis se vide en un cycle) */
  const vp = .5 - .5 * Math.cos(TAU * p), vr = 1.2 + 1.6 * vp;
  g.fillStyle = rgba(KB, 1); g.globalAlpha = .16; g.beginPath(); g.arc(mx(8), my(6), vr, 0, TAU); g.fill();
  g.strokeStyle = rgba(KB, 1); g.globalAlpha = .55; g.lineWidth = .5; g.stroke();
  /* 11. reflet de verre sur l'épaule gauche */
  g.beginPath(); for (let y = y0 + 3; y <= 27; y += 2) { const x = -rAt(Pf, y) * .64; y === y0 + 3 ? g.moveTo(x, y) : g.lineTo(x, y); }
  g.strokeStyle = rgba(K2, 1); g.globalAlpha = .07; g.lineWidth = 2.2; g.stroke(); g.globalAlpha = .22; g.lineWidth = .7; g.stroke();
  g.restore();
  /* 12. lèvre du péristome : bourrelet (arrière fin, avant épais éclairé) ; disque buccal */
  g.globalCompositeOperation = 'lighter';
  if (op > .03) { g.beginPath(); g.ellipse(0, y0 - eb * .2, r0 * .62, eb * .55, 0, 0, TAU); g.fillStyle = rgba(K1, 1); g.globalAlpha = .1 * op; g.fill();
    g.strokeStyle = rgba(K2, 1); g.globalAlpha = .22 * op; g.lineWidth = .5; g.stroke(); }
  g.beginPath(); g.ellipse(0, y0, r0, eb, 0, Math.PI, TAU, false); g.strokeStyle = rgba(K2, 1); g.globalAlpha = .34; g.lineWidth = .9; g.stroke();
  g.beginPath(); g.ellipse(0, y0, r0, eb, 0, 0, Math.PI, false); g.strokeStyle = rgba(K1, 1); g.globalAlpha = .14; g.lineWidth = 3.2; g.stroke();
  g.strokeStyle = rgba(K2, 1); g.globalAlpha = .62 * (1 - .55 * k); g.lineWidth = 1.35; g.stroke();
  if (op > .03) cils(false);
  g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
}
const ATL = {}, PRE = {};
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function atlas(wd) {
  wd = wd === 8 ? 8 : 7; let A = ATL[wd]; if (A) return A;
  A = ATL[wd] = { k: [], fait: new Uint8Array(NK * NP), n: 0, C: PAL[wd], spr: {} }; return A;   // une petite toile par image clé (lecture plus rapide qu'une grande planche)
}
function atlasF(A, i) {
  if (A.fait[i]) return; A.fait[i] = 1; A.n++;
  const kq = (i / NP) | 0, pq = i % NP, k = A.k[i] = cv(Math.ceil(CW * PXA), Math.ceil(CH * PXA)), g = k.getContext('2d'); g.setTransform(PXA, 0, 0, PXA, CW / 2 * PXA, OY * PXA);
  cle(g, kq / (NK - 1), pq / NP, A.C);
  try { if (racine.createImageBitmap) createImageBitmap(k).then(bm => { A.k[i] = bm; }, () => {}); } catch (er) {}   // image figée : lecture la plus rapide
}
function prechauffe(wd) {
  wd = wd === 8 ? 8 : 7; if (PRE[wd]) return; PRE[wd] = 1; const A = atlas(wd); sprites(A);
  const pas = () => { const t0 = performance.now(); let f = 0; const N = NK * NP;
    while (A.n < N && performance.now() - t0 < 3) { while (A.fait[f]) f++; atlasF(A, f); }
    if (A.n < N) (racine.requestAnimationFrame || setTimeout)(pas); };
  pas();
}
function proche(A, kq, pq) { const i = kq * NP + pq; if (A.fait[i]) return i; for (let d = 1; d < NP; d++) { const a = kq * NP + (pq + d) % NP; if (A.fait[a]) return a; } atlasF(A, i); return i; }
function sprite(A, nom, c, a0) {
  if (A.spr[nom]) return A.spr[nom]; const s = 96, k = cv(s, s), g = k.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  r.addColorStop(0, rgba(c, a0)); r.addColorStop(.3, rgba(c, a0 * .42)); r.addColorStop(.65, rgba(c, a0 * .1)); r.addColorStop(1, rgba(c, 0)); g.fillStyle = r; g.fillRect(0, 0, s, s); return (A.spr[nom] = k);
}
function sprites(A) { const C = A.C; sprite(A, 'g', C.c1, .7); sprite(A, 'a', C.ac, .8); sprite(A, 'w', C.c2, .9); }
/* une cloche : (x, y) = BOUCHE, ang = direction de la bouche, k fermeture 0..1, ph phase des cils (0..1), lum surbrillance */
function cloche(ctx, A, x, y, ang, s, k, ph, lum) {
  const kf = cl1(k) * (NK - 1), i0 = Math.min(NK - 2, Math.floor(kf)), fk = kf - i0, pq = ((Math.floor(ph * NP) % NP) + NP) % NP, W = CW * PXA, Hh = CH * PXA;
  const M = ctx.getTransform(), c = Math.cos(ang + Math.PI / 2), sn = Math.sin(ang + Math.PI / 2);
  ctx.transform(c * s, sn * s, -sn * s, c * s, x, y);
  const a = proche(A, i0, pq), b = proche(A, i0 + 1, pq);
  ctx.globalCompositeOperation = 'source-over';
  /* fondu entre deux degrés de fermeture seulement au milieu de l'intervalle (une seule image le reste du temps : perf) */
  if (fk < .2) { ctx.globalAlpha = 1; ctx.drawImage(A.k[a], -CW / 2, -OY, CW, CH); }
  else if (fk > .8) { ctx.globalAlpha = 1; ctx.drawImage(A.k[b], -CW / 2, -OY, CW, CH); }
  else { const m = (fk - .2) / .6; ctx.globalAlpha = 1 - m * (m > .5 ? 1 : .6); ctx.drawImage(A.k[a], -CW / 2, -OY, CW, CH);
    ctx.globalAlpha = m < .5 ? Math.min(1, m * 1.4) : 1; ctx.drawImage(A.k[b], -CW / 2, -OY, CW, CH); }
  ctx.setTransform(M); ctx.globalCompositeOperation = 'source-over';
}
/* contraction rendue (u images après la détente) : coup sec lissé (12 images) avec dépassement, tenue, redéploiement lent */
function kR(u, cd) { if (u <= 0) return 0; if (u < 12) return 1.06 * sm(u / 12); if (u < 24) return 1.06 - .06 * sm((u - 12) / 12); if (u < 34) return 1; return 1 - sm((u - 34) / Math.max(1, cd - 34)); }
/* tête du pédoncule chasseur pour le DESSIN : [angle, longueur, contraction] ; tenue = physique exacte */
function tete(c, t, st) {
  const L = c.L || 150, cd = c.cd || 170;
  if (st && st.out != null && t >= st.out && t - st.out < cd) { const u = t - st.out, ra = restAng(c, t), d = wrapA(ra - st.ra), s = sm((u - 6) / (cd - 6)); return [st.ra + d * s, L + (st.rl - L) * (1 - s), kR(u, cd)]; }
  if (st && st.in != null && t >= st.in && (st.h || (st.out != null && t < st.out))) { const v = vState(c, t, { h: 1, in: st.in, a: st.a }); return [v[0], v[1], 0]; }
  return [restAng(c, t), L, 0];
}
/* Bézier cubique échantillonnée, avec spirale (k), dans des Path2D : axe P, myonème M, brins avant FR ; renvoie les points */
const XS = new Float32Array(160), YS = new Float32Array(160);
function courbe(P, M, FR, x0, y0, x1, y1, x2, y2, x3, y3, kk, nT, R, w, ph, garde) {
  const N = kk > .01 ? Math.max(24, Math.ceil(nT * 12)) : 12; let av = false;
  for (let i = 0; i <= N; i++) {
    const t = i / N, u = 1 - t, bx = u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3, by = u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3;
    const dx = 3 * u * u * (x1 - x0) + 6 * u * t * (x2 - x1) + 3 * t * t * (x3 - x2), dy = 3 * u * u * (y1 - y0) + 6 * u * t * (y2 - y1) + 3 * t * t * (y3 - y2), dl = Math.hypot(dx, dy) || 1, nx = -dy / dl, ny = dx / dl;
    const th = TAU * nT * t + ph, env = kk > .01 ? Math.pow(Math.sin(Math.PI * t), .45) : 0, off = R * kk * env * Math.sin(th);
    const x = bx + nx * off, y = by + ny * off; i ? P.lineTo(x, y) : P.moveTo(x, y);
    const mo = off + w * .27 * Math.sin(t * 9 + ph * 2) * (1 - .6 * kk); i ? M.lineTo(bx + nx * mo, by + ny * mo) : M.moveTo(bx + nx * mo, by + ny * mo);
    if (kk > .05) { const f = Math.cos(th) > 0; if (f && av) FR.lineTo(x, y); else if (f) FR.moveTo(x, y); av = f; }
    if (garde) { XS[i] = x; YS[i] = y; }
  }
  return N;
}
/* tube translucide : halo, chair sombre, paroi éclairée, cœur assombri (deux parois lumineuses), en un seul tracé par couche */
function tube(ctx, P, w, C, lum) {
  if (lum > .25) { ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = rgba(C.c1, 1); ctx.globalAlpha = .1 * (lum - .25); ctx.lineWidth = w * 3.2; ctx.stroke(P); }   // lueur du pédoncule : à l'approche et en prise seulement
  ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = rgba(C.c1, 1); ctx.globalAlpha = .66; ctx.lineWidth = w + 1; ctx.stroke(P);   // paroi
  ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = rgba(C.c3, 1); ctx.globalAlpha = .62; ctx.lineWidth = w * .5; ctx.stroke(P);   // cœur sombre : deux parois lumineuses
}
const dir = a => [Math.cos(a), Math.sin(a)];
function dessinerVort(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, LV = racine.LEVELS, SS = racine.S, wd = (LV && SS && LV[SS.li] && LV[SS.li].wd) === 8 ? 8 : 7;
  const A = atlas(wd), C = A.C; if (!PRE[wd]) prechauffe(wd);
  const GG = sprite(A, 'g', C.c1, .7), GA = sprite(A, 'a', C.ac, .8), GW = sprite(A, 'w', C.c2, .9);
  st = run ? (st || {}) : {};
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, held = !!(run && st.h && b), ph = c.ph || 0, L = c.L || 150, cd = c.cd || 170, a0 = (c.a == null ? -90 : c.a) * D2R;
  const STt = run ? st : null;
  /* tête (physique exacte en prise) + raccord de régime (attente ↔ jeu, rejeu) : écart amorti en 45 images, base fixe */
  const tg = tete(c, t, STt); let Aa = tg[0], Ln = tg[1], kk = tg[2];
  const tA = s => tete(c, s, STt)[0], A8 = tA(t - 8), A20 = tA(t - 20), A22 = tA(t - 22), A0 = tg[0];
  let tau = a0 + .45 * wrapA(A22 - a0) + .03 * Math.sin(t * .017 + ph);
  let tilt = -.9 * wrapA(A0 - A8) + .45 * wrapA(A8 - A20) + .07 * Math.sin(t * .021 + ph + 1);
  const bascule = e.v7run !== undefined && (e.v7run !== run || (run && (fr < e.v7fr || fr - e.v7fr > 8)));
  if (bascule && e.v7A) { e.v7D = [wrapA(e.v7A[0] - Aa), e.v7A[1] - Ln, e.v7A[2] - kk, wrapA(e.v7A[3] - tau), e.v7A[4] - tilt]; e.v7u = 0;
    e.v7T = Math.max(45, Math.min(220, 1.5 * (Math.abs(e.v7D[0]) * Ln + Math.abs(e.v7D[1]) + 40 * Math.abs(e.v7D[4])))); }   // durée : vitesse de rattrapage ≤ ~2 px/image
  if (e.v7D) { let f = 1 - sm(e.v7u / (e.v7T || 45)); if (held) f *= 1 - sm((fr - st.in) / 12); if (f <= 0.001) e.v7D = null; else { Aa += e.v7D[0] * f; Ln += e.v7D[1] * f; kk = Math.max(0, kk + e.v7D[2] * f); tau += e.v7D[3] * f; tilt += e.v7D[4] * f; } e.v7u += dt * 60; }
  if (dt > 0) { e.v7run = run; e.v7fr = fr; e.v7A = [Aa, Ln, kk, tau, tilt]; }
  /* retards visco-élastiques : le tronc suit la tête avec 22 images de retard ; la cloche penche en retard puis dépasse */
  const bx = c.x, by = c.y, Lt = .26 * L, dT = dir(tau), jx = bx + dT[0] * Lt, jy = by + dT[1] * Lt;
  const hx = bx + Ln * Math.cos(Aa), hy = by + Ln * Math.sin(Aa);
  const sc = L < 85 ? .76 : .84, BL = 46 * sc;
  const phi = Math.atan2(hy - jy, hx - jx) + tilt, dP = dir(phi);
  let fx = hx - dP[0] * BL, fy = hy - dP[1] * BL, Hx = hx, Hy = hy;
  if (kk > 0) { const q = 1 - .7 * Math.min(1, kk); fx = jx + (fx - jx) * q; fy = jy + (fy - jy) * q; Hx = fx + dP[0] * BL; Hy = fy + dP[1] * BL; }
  if (dt > 0) e.v7H = [Hx, Hy, phi, fx, fy];   // suivi (tests de continuité)
  /* lumière : approche, prise (tension), détente */
  const tens = held ? sm((fr - st.in) / (c.dur || 80)) : 0, near = b && run ? Math.max(0, 1 - Math.hypot(b.x - Hx, b.y - Hy) / 120) : 0;
  const lumT = held ? .62 + .38 * tens : kk > 0 ? .5 * kk : .18 + .55 * near;
  e.lum7 = e.lum7 == null ? lumT : e.lum7 + (lumT - e.lum7) * Math.min(1, dt * 5); const lum = e.lum7;
  /* fermeture de la couronne : respire au repos, s'ouvre grand à l'approche, enserre (sans l'avaler) en prise, se ferme à la détente */
  const kT = held ? .3 * sm((fr - st.in) / 18) : 0;   // au repos : grand ouvert (une seule image d'atlas) ; la vie vient des cils et de la vacuole
  e.kc7 = e.kc7 == null ? kT : e.kc7 + (kT - e.kc7) * Math.min(1, dt * 7); const kc = Math.max(0, e.kc7, Math.min(1, kk * 1.15));
  e.cp7 = ((e.cp7 || 0) + dt * (1.5 + 1.3 * lum)) % 1;
  /* figurants (fixés au tronc, hors de l'arc balayé par la chasseuse) */
  if (!e.v7F) { const arm = (c.arm == null ? (c.a == null ? -90 : c.a) : c.arm) * D2R, d = wrapA(arm - a0), lo = d < 0 ? a0 + d : a0, hi = d < 0 ? a0 : a0 + d, back = a0 + Math.PI;
    const Lt0 = .26 * L, jx0 = c.x + Lt0 * Math.cos(a0), jy0 = c.y + Lt0 * Math.sin(a0);   // figurant hors de l'écran : on ne le pose pas
    e.v7F = [[lo - 50 * D2R, .62, .7, 0], [hi + 46 * D2R, .95, .66, 1]].filter(f => { const px = jx0 + .6 * L * Math.cos(f[0]), py = jy0 + .6 * L * Math.sin(f[0]);
      return Math.abs(wrapA(f[0] - back)) >= 60 * D2R && px > 12 && px < 348 && py > 12 && py < 468; }); }
  const P2 = new Path2D(), M = new Path2D(), FR = new Path2D(), FIGB = [];
  /* tronc : Bézier de l'ancrage (direction fixe) au point de fourche (tangente tau) */
  const da = dir(a0);
  courbe(P2, M, FR, bx, by, bx + da[0] * Lt * .4, by + da[1] * Lt * .4, jx - dT[0] * Lt * .4, jy - dT[1] * Lt * .4, jx, jy, 0, 1, 0, 2.9, ph, false);
  for (let i = 0; i < e.v7F.length; i++) {
    const f = e.v7F[i], ox = bx + (jx - bx) * f[1], oy = by + (jy - by) * f[1];
    const per = 560 + 150 * i, u = ((t + i * 233 + ph * 90 + 200) % per), kf = u < 180 ? kR(u, 180) : 0;
    const ps = f[0] + .8 * wrapA(tau - a0) + (6 * Math.sin(t * .011 * (1 + .17 * i) + i * 1.9 + ph)) * D2R, s2 = sc * f[2], bl = 46 * s2, lf = .6 * L;
    const pd = dir(ps), nod = ps + .09 * Math.sin(t * .019 + i * 2.1) - .5 * (6 * D2R) * Math.cos(t * .011 * (1 + .17 * i) + i * 1.9 + ph) * .3;
    const ex = ox + pd[0] * lf, ey = oy + pd[1] * lf, nd = dir(nod); let ffx = ex - nd[0] * bl, ffy = ey - nd[1] * bl;
    const q = 1 - .62 * Math.min(1, kf); ffx = ox + (ffx - ox) * q; ffy = oy + (ffy - oy) * q; const D = Math.hypot(ffx - ox, ffy - oy);
    const dm = dir(tau + .6 * wrapA(ps - tau));   // départ de la branche : entre le tronc et sa direction (fourche, pas de croisement)
    courbe(P2, M, FR, ox, oy, ox + dm[0] * D * .35, oy + dm[1] * D * .35, ffx - nd[0] * D * .4, ffy - nd[1] * D * .4, ffx, ffy, kf, Math.max(2.5, (lf - bl) / 8), 5.4 * s2, 1.9, ph + i, false);
    FIGB.push([ffx + nd[0] * bl, ffy + nd[1] * bl, nod, s2, Math.min(1, kf * 1.15), e.cp7 + .37 * (i + 1)]);
  }
  /* pédoncule chasseur : de la fourche (tangente tau) au pied de la cloche (tangente phi) ; spirale à la détente */
  const D = Math.hypot(fx - jx, fy - jy), nT = Math.max(3, (L * .74 - BL) / 8);
  const NC = courbe(P2, M, FR, jx, jy, jx + dT[0] * D * .4, jy + dT[1] * D * .4, fx - dP[0] * D * .4, fy - dP[1] * D * .4, fx, fy, kk, nT, 6.2 * sc, 2.1, ph, true);
  const OFF = racine.QX7D_OFF | 0; if (OFF & 32) return;
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* crampon d'ancrage */
  ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .5; ctx.drawImage(GG, bx - 6, by - 6, 12, 12);
  if (!(OFF & 1)) tube(ctx, P2, 2.5, C, lum);   // un seul arbre, un seul passage par couche (perf)
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = rgba(C.ac, 1); ctx.globalAlpha = .42 + .4 * Math.min(1, kk + tens * .6); ctx.lineWidth = .6; ctx.stroke(M);     // myonème
  /* brins AVANT de la spirale : un second tube par-dessus (ils croisent les brins arrière : spirale en relief, pas un zigzag) */
  if (kk > .05 || FIGB.some(q => q[4] > .05)) { tube(ctx, FR, 2.0, C, 0); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = rgba(C.c2, 1); ctx.globalAlpha = .3; ctx.lineWidth = .7; ctx.stroke(FR); }
  /* perle de lumière qui remonte vers la cloche (plus vive et plus rapide quand elle se bande) */
  { const u = held ? ((fr - st.in) * .02) % 1 : ((t * .005 + ph * .3) % 1), f = u * NC, i = Math.min(NC - 1, f | 0), r = f - i, px = XS[i] + (XS[i + 1] - XS[i]) * r, py = YS[i] + (YS[i + 1] - YS[i]) * r, R = 5 + 3 * lum;
    ctx.globalAlpha = (.35 + .4 * lum) * Math.sin(Math.PI * u); ctx.drawImage(GA, px - R, py - R, 2 * R, 2 * R); }
  /* cloches figurantes */
  if (!(OFF & 2)) for (const q of FIGB) cloche(ctx, A, q[0], q[1], q[2], q[3], q[4], q[5], 0);
  /* halo multicouche + bioluminescence interne de la chasseuse */
  const cx = Hx - dP[0] * BL * .42, cy = Hy - dP[1] * BL * .42, pu = .5 + .5 * Math.sin(t * .045 + ph);
  ctx.globalCompositeOperation = 'lighter';
  let R = 30 * sc * (1 + .5 * lum); if (lum > .22) { ctx.globalAlpha = .25 * (lum - .1); ctx.drawImage(GG, cx - R, cy - R, 2 * R, 2 * R); }
  R = 16 * sc * (1 + .25 * lum); ctx.globalAlpha = .16 + .3 * lum + .08 * pu; ctx.drawImage(GA, cx - R, cy - R, 2 * R, 2 * R);
  if (!(OFF & 8)) cloche(ctx, A, Hx, Hy, phi, sc, kc, e.cp7, lum);
  ctx.globalCompositeOperation = 'lighter';
  R = 8 * sc; ctx.globalAlpha = (.18 + .32 * lum) * (.7 + .3 * pu); ctx.drawImage(GA, cx - R, cy - R + 0, 2 * R, 2 * R);    // cœur bioluminescent
  if (held) { R = 13 + 5 * tens; ctx.globalAlpha = .22 + .3 * tens; ctx.drawImage(GW, b.x - R, b.y - R, 2 * R, 2 * R); }   // la coupe éclaire la particule
  ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).vort = dessinerVort;
racine.QXE7D = { vort: dessinerVort, atlas, prechauffe, cle, PAL };
function accroche() {
  const ll = racine.loadLevel; if (typeof ll !== 'function' || ll.e7d) return;
  const w = racine.loadLevel = function (i) { const r = ll.apply(this, arguments);
    try { const lv = racine.LEVELS && racine.LEVELS[i]; if (lv && lv.cr && lv.cr.some(c => c.t === 'vort')) prechauffe(lv.wd); } catch (e) {} return r; };
  w.e7d = 1;
}
if (typeof document !== 'undefined') { if (document.readyState === 'complete') accroche(); else racine.addEventListener('load', accroche); }
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 7D FIN ===== */
