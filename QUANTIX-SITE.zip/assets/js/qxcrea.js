/* QXCREA R470 · figurants décoratifs (société d'arrière-plan + avant-plan ponctuel) · moteur de créatures (QXMOTIFS, banc v5) + évasion de Fluides sur la constellation + décor vivant des niveaux Fluides (QXCREA.niveau). Chargé à la demande par engine.js (jamais au démarrage). */
/* =====================================================================
   QXMOTIFS — motifs de décor du monde « Mécanique des fluides ».
   Aucune dépendance au DOM : chaque motif ne connaît que le contexte 2D
   qu'on lui passe dans draw(). Coordonnées = unités de niveau (360 × 470).
   API : QXMOTIFS.<nom> = { init(w,h,seed,opts), update(dt,flow,energy), draw(ctx,alpha) }
         QXMOTIFS.create(nom) → nouvelle instance indépendante (même API).
   flow(x,y) → [u,v] en unités/s ; le tableau rendu peut être réutilisé
   par l'appelant : on le lit immédiatement, on ne le conserve jamais.
   ===================================================================== */
(function (racine) {
  'use strict';

  /* ---------- Jetons de palette (seul endroit où vivent les couleurs) ---------- */
  const palette = {
    abysse:  [4, 10, 18],     // fond le plus profond
    sarcelle:[46, 120, 128],  // bleu-vert profond (corps, voiles)
    aqua:    [118, 200, 196], // halos froids
    perle:   [214, 230, 232], // membranes, liserés nacrés
    ambre:   [226, 168, 96],  // touches chaudes rares
    lueur:   [110, 238, 196], // bioluminescence froide aqua-vert
    mauve:   [182, 154, 232], // la particule (seule teinte chaude-froide hors décor)
    // Opacité de base de chaque motif (multipliée par l'alpha de draw) ;
    // biolum module toutes les lueurs (0 = éteint), modifiable à chaud.
    alpha: { cells: 0.5, filament: 0.6, top: 0.5, snow: 0.75, bubbles: 0.6, biolum: 1 }
  };
  /* ---------- Rythme de la bioluminescence (impulsions lentes et irrégulières) ---------- */
  const BIO = {
    attente: [1.5, 6],        // pause aléatoire entre deux impulsions (s), raccourcie par energy
    duree: [3.5, 6],          // durée d'un passage complet (s)
    intensite: [0.35, 0.6],   // intensité ordinaire
    probaVive: 0.55,          // × energy² : chance qu'une impulsion soit vive (intensité 1, plus rapide)
    probaAmbre: 0.15          // chance d'un passage ambre
  };
  const TAU = Math.PI * 2;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const rgb = c => rgba(c, 1);

  /* ---------- Utilitaires partagés ---------- */
  // Générateur pseudo-aléatoire déterministe (mulberry32)
  function aleatoire(graine) {
    let s = graine >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  // Ramène v dans [a-m, b+m] en le faisant réapparaître de l'autre côté
  function enroule(v, a, b, m) {
    const L = b - a + 2 * m;
    if (v < a - m) return v + L;
    if (v > b + m) return v - L;
    return v;
  }
  // Rotationnel local du champ (s⁻¹) par différences finies
  function tourbillon(flow, x, y, h) {
    const a = flow(x + h, y)[1], b = flow(x - h, y)[1];
    const c = flow(x, y + h)[0], d = flow(x, y - h)[0];
    return ((a - b) - (c - d)) / (2 * h);
  }
  // Petite aide de cache : les dégradés dépendent du contexte, on les recrée si celui-ci change
  function cacheContexte(fabrique) {
    let ctxCourant = null, valeur = null;
    return ctx => {
      if (ctx !== ctxCourant) { ctxCourant = ctx; valeur = fabrique(ctx); }
      return valeur;
    };
  }

  // Impulsion lumineuse : pos parcourt 0 → 1 le long de l'organisme, puis repos
  function lueurNeuve(r) {
    return { pos: 0, vit: 0, int: 0, attente: r() * BIO.attente[1], ambre: false };
  }
  function avancerLueur(l, dt, energy, r) {
    if (l.int > 0) {
      l.pos += l.vit * dt;
      if (l.pos > 1.2) { l.int = 0; l.attente = BIO.attente[0] + r() * (BIO.attente[1] - BIO.attente[0]); }
      return;
    }
    l.attente -= dt * (1 + 2.5 * energy);
    if (l.attente > 0) return;
    const vive = r() < BIO.probaVive * energy * energy;
    l.pos = 0;
    l.vit = (vive ? 1.6 : 1) / (BIO.duree[0] + r() * (BIO.duree[1] - BIO.duree[0]));
    l.int = vive ? 1 : BIO.intensite[0] + r() * (BIO.intensite[1] - BIO.intensite[0]);
    l.ambre = r() < BIO.probaAmbre;
  }
  // Enveloppe douce d'une impulsion (monte, tient, s'éteint)
  const enveloppe = l => l.int * Math.sin(Math.PI * borne(l.pos / 1.2, 0, 1));
  const cloche = (d, w) => Math.exp(-(d * d) / (w * w));
  const enrouleAngle = d => d - Math.round(d / TAU) * TAU;
  // Particule : excitation 0 (loin) → 1 (au contact), lue dans RG.part = { on, x, y }
  function excitation(RG, x, y, portee) {
    const p = RG.part;
    if (!p || !p.on) return 0;
    return borne(1 - Math.hypot(p.x - x, p.y - y) / portee, 0, 1);
  }

  /* =====================================================================
     1. CELLULES — paramécies translucides
     ===================================================================== */
  function creerCellules() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NB_CILS = 80;
    const cosC = new Float32Array(NB_CILS), sinC = new Float32Array(NB_CILS);
    for (let i = 0; i < NB_CILS; i++) { cosC[i] = Math.cos(i / NB_CILS * TAU); sinC[i] = Math.sin(i / NB_CILS * TAU); }
    let W = 360, H = 470, cellules = [], t = 0;
    const couleurs = {
      membrane: rgb(P.perle), cils: rgb(P.perle), vacuole: rgb(P.perle),
      ombre: rgb(P.abysse), noyau: rgb(P.aqua), ambre: rgb(P.ambre), lueur: rgb(P.lueur)
    };
    const BANDES_CILS = [0.5, 0.26, 0.1];      // demi-largeurs angulaires (rad) des bandes de cils allumés
    const ALPHA_BANDES = [0.35, 0.55, 0.9];
    let rl = Math.random;                       // tirages du rythme lumineux
    // Trace les cils d'indice [i0, i1] (modulo NB_CILS) avec la même géométrie que le tracé normal
    function cheminCils(ctx, c, a, b, i0, i1) {
      for (let j = i0; j <= i1; j++) {
        const i = ((j % NB_CILS) + NB_CILS) % NB_CILS;
        const px = a * cosC[i], py = b * sinC[i];
        let nx = b * cosC[i], ny = a * sinC[i];
        const nl = 1 / Math.hypot(nx, ny); nx *= nl; ny *= nl;
        const ph = c.cph + c.ph - i * 0.55;
        const L = (2.6 + 1.6 * Math.sin(ph)) * (1 + 0.6 * c.exc * (1 + 0.6 * Math.max(0, Math.cos(i / NB_CILS * TAU - c.pv))));
        const pli = (1.4 + 1.2 * c.exc) * Math.cos(ph);  // battement tangent
        ctx.moveTo(px + nx * 0.8, py + ny * 0.8);
        ctx.lineTo(px + nx * (0.8 + L) - ny * pli, py + ny * (0.8 + L) + nx * pli);
      }
    }
    // Corps : disque unité, cœur presque vide, bord lumineux (lu sous scale(a,b))
    const degrades = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.07));
      g.addColorStop(0.55, rgba(P.sarcelle, 0.10));
      g.addColorStop(0.86, rgba(P.aqua, 0.16));
      g.addColorStop(0.97, rgba(P.perle, 0.30));
      g.addColorStop(1, rgba(P.perle, 0));
      return { corps: g };
    });

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const q = borne((opts && opts.quality) || 1, 0.5, 1);
        const r = aleatoire(seed);
        rl = aleatoire(seed ^ 0x9e37);
        const n = (opts && opts.n) || Math.max(3, Math.round(5 * q));
        cellules = [];
        for (let i = 0; i < n; i++) {
          const a = 30 + r() * 20;
          const prof = 0.6 + r() * 0.4;               // profondeur : petite = lointaine, plus pâle
          const vac = [];
          const nv = 4 + Math.floor(r() * 6);
          for (let k = 0; k < nv; k++) {
            const ang = r() * TAU, rad = Math.sqrt(r()) * 0.55;
            vac.push({ ox: Math.cos(ang) * rad - 0.15, oy: Math.sin(ang) * rad * 0.8, r: 2.2 + r() * 3, ph: r() * TAU });
          }
          const grains = new Float32Array(2 * Math.round(14 * q));
          for (let k = 0; k < grains.length; k += 2) {
            const ang = r() * TAU, rad = Math.sqrt(r()) * 0.8;
            grains[k] = Math.cos(ang) * rad; grains[k + 1] = Math.sin(ang) * rad;
          }
          cellules.push({
            x: r() * W, y: r() * H, vx: 0, vy: 0,
            a: a * prof, b: a * prof * (0.46 + r() * 0.08), prof,
            ang: r() * TAU, rot: (r() - 0.5) * 0.3, ph: r() * TAU,
            etire: 1, vac, grains, noyau: { ox: 0.1 + r() * 0.2, oy: (r() - 0.5) * 0.3, r: 0.22 + r() * 0.08 },
            ambre: r() < 0.25, lueur: lueurNeuve(r), exc: 0, cph: 0, pv: 0, gobe: 0
          });
        }
      },

      reglage(o) { if (o && o.gobe !== undefined) { cellules[o.gobe].gobe = 1; return; } Object.assign(RG, o); },
      n() { return cellules.length; },
      pos(i) { const c = cellules[i]; return [c.x, c.y]; },
      // Placement direct du corps (la mise en scène pilote la position ; les appendices suivent)
      place(i, x, y) { const c = cellules[i]; c.x = x; c.y = y; },
      vise(i, tx, ty, g) { const c = cellules[i]; c.tx = tx; c.ty = ty; c.g = g; },
      geo() { return cellules.map(c => ({ k: 'cell', x: c.x, y: c.y, ang: c.ang, a: c.a * c.etire, b: c.b / Math.sqrt(c.etire) })); },
      update(dt, flow, energy) {
        t += dt;
        const k = Math.min(1, dt * 1.2);
        for (const c of cellules) {
          const f = flow(c.x, c.y); const u = f[0], v = f[1];
          // Nage propre le long du grand axe + entraînement par le courant (plus fort pour les proches)
          const nage = (3 + 4 * energy) * RG.vit;
          const cx = Math.cos(c.ang), cy = Math.sin(c.ang);
          c.vx += (u * 0.55 * c.prof + cx * nage - c.vx) * k;
          c.vy += (v * 0.55 * c.prof + cy * nage - c.vy) * k;
          c.x = enroule(c.x + c.vx * dt, 0, W, 50);
          c.y = enroule(c.y + c.vy * dt, 0, H, 50);
          // Le tourbillon local fait tourner la cellule ; elle s'oriente doucement vers sa vitesse
          const w = tourbillon(flow, c.x, c.y, 12);
          const vit = Math.hypot(c.vx, c.vy);
          let cible = Math.atan2(c.vy, c.vx) - c.ang;
          cible -= Math.round(cible / TAU) * TAU;
          c.ang += (c.rot + 0.5 * w + cible * Math.min(1, vit / 40) * 0.6) * dt;
          if (c.g) { let d = Math.atan2(c.ty - c.y, c.tx - c.x) - c.ang; d -= Math.round(d / TAU) * TAU; c.ang += d * c.g * 2 * dt; c.vx += Math.cos(c.ang) * c.g * 30 * dt; c.vy += Math.sin(c.ang) * c.g * 30 * dt; }
          // Étirement le long de l'axe selon la vitesse relative : la membrane cède un peu
          // Particule : les cils s'emballent (surtout du côté qui la regarde), le corps s'effile
          // pour l'attaque, se ramasse pour la fuite
          c.exc += (excitation(RG, c.x, c.y, 150) - c.exc) * k;
          if (RG.part && RG.part.on) c.pv = Math.atan2(RG.part.y - c.y, RG.part.x - c.x) - c.ang;
          c.cph += dt * (4.5 + vit * 0.08 + 4 * energy + 14 * c.exc * (RG.mode === 'cont' ? 0.35 : 1));
          const forme = RG.mode === 'agr' ? 0.28 : RG.mode === 'evite' ? -0.24 : RG.mode === 'cont' ? -0.06 : 0.08;
          const cibleEtire = Math.max(0.74, 1 + Math.min(0.22, vit / 180) + 0.03 * Math.sin(t * 1.3 + c.ph) + forme * c.exc);
          c.etire += (cibleEtire - c.etire) * k;
          c.gobe = Math.max(0, c.gobe - dt * 0.35);
          avancerLueur(c.lueur, dt, energy, rl);
        }
      },

      draw(ctx, alpha) {
        const A = alpha * P.alpha.cells;
        if (A <= 0.001) return;
        const g = degrades(ctx);
        ctx.save();
        ctx.lineCap = 'round';
        for (const c of cellules) {
          const a = c.a * c.etire, b = c.b / Math.sqrt(c.etire); // conserve l'aire
          const Ac = A * (0.5 + 0.5 * c.prof);
          ctx.save();
          ctx.translate(c.x, c.y);
          ctx.rotate(c.ang);

          // Corps translucide (dégradé unité étiré en ellipse)
          ctx.save();
          ctx.scale(a, b);
          ctx.globalAlpha = Ac;
          ctx.fillStyle = g.corps;
          ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fill();
          ctx.restore();

          // Cils : vague métachronale qui parcourt le pourtour, tracée deux fois (flou + net)
          ctx.beginPath();
          cheminCils(ctx, c, a, b, 0, NB_CILS - 1);
          ctx.strokeStyle = couleurs.cils;
          ctx.globalAlpha = Ac * 0.07; ctx.lineWidth = 2.4; ctx.stroke();
          ctx.globalAlpha = Ac * 0.22; ctx.lineWidth = 0.55; ctx.stroke();

          // Double membrane : liseré lumineux + paroi intérieure
          ctx.strokeStyle = couleurs.membrane;
          ctx.beginPath(); ctx.ellipse(0, 0, a, b, 0, 0, TAU);
          ctx.globalAlpha = Ac * 0.06; ctx.lineWidth = 5; ctx.stroke();      // halo flou
          ctx.globalAlpha = Ac * 0.55; ctx.lineWidth = 0.9; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, 0, a * 0.9, b * 0.84, 0, 0, TAU);
          ctx.globalAlpha = Ac * 0.14; ctx.lineWidth = 1.6; ctx.stroke();

          // Sillon oral : courbe douce de l'avant vers le milieu
          ctx.beginPath();
          ctx.moveTo(a * 0.75, -b * 0.35);
          ctx.quadraticCurveTo(a * 0.2, b * 0.25, -a * 0.05, b * 0.05);
          ctx.globalAlpha = Ac * 0.16; ctx.lineWidth = 0.8; ctx.stroke();

          // Granulations (texture cytoplasmique)
          ctx.fillStyle = couleurs.membrane;
          ctx.globalAlpha = Ac * 0.22;
          ctx.beginPath();
          for (let k = 0; k < c.grains.length; k += 2) ctx.rect(c.grains[k] * a - 0.4, c.grains[k + 1] * b - 0.4, 0.8, 0.8);
          ctx.fill();

          // Noyau : grand anneau diffus
          const n = c.noyau;
          ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, n.r * b * 1.6, 0, TAU);
          ctx.fillStyle = couleurs.noyau; ctx.globalAlpha = Ac * 0.06; ctx.fill();
          ctx.strokeStyle = couleurs.membrane; ctx.globalAlpha = Ac * 0.13; ctx.lineWidth = 0.7; ctx.stroke();

          // Vacuoles : anneaux qui respirent, intérieur légèrement assombri
          ctx.beginPath();
          for (const v of c.vac) {
            const rr = v.r * c.prof * (1 + 0.12 * Math.sin(t * 1.7 + v.ph));
            const vx = v.ox * a, vy = v.oy * b;
            ctx.moveTo(vx + rr, vy); ctx.arc(vx, vy, rr, 0, TAU);
          }
          ctx.fillStyle = couleurs.ombre; ctx.globalAlpha = Ac * 0.35; ctx.fill();
          ctx.strokeStyle = c.ambre ? couleurs.ambre : couleurs.vacuole;
          ctx.globalAlpha = Ac * 0.5; ctx.lineWidth = 0.8; ctx.stroke();

          // Bioluminescence : l'impulsion fait le tour de la membrane le long des rangées de cils,
          // puis saute de vacuole en vacuole
          const I = Ac * P.alpha.biolum * enveloppe(c.lueur);
          if (I > 0.004) {
            const pos = c.lueur.pos;
            const th = c.ph + pos * TAU * 1.1;      // tête de l'impulsion
            ctx.globalCompositeOperation = 'lighter';
            const teinte = c.lueur.ambre ? couleurs.ambre : couleurs.lueur;
            ctx.strokeStyle = teinte; ctx.fillStyle = teinte;
            // Membrane : halo diffus + filet net, traîne derrière la tête
            ctx.beginPath(); ctx.ellipse(0, 0, a + 1, b + 1, 0, th - 1.1, th + 0.15);
            ctx.globalAlpha = I * 0.16; ctx.lineWidth = 9; ctx.stroke();
            ctx.globalAlpha = I * 0.6; ctx.lineWidth = 1.2; ctx.stroke();
            // Cils allumés, en bandes concentriques (dégradé sans dégradé)
            const ic = th / TAU * NB_CILS;
            for (let k = 0; k < BANDES_CILS.length; k++) {
              const dn = BANDES_CILS[k] / TAU * NB_CILS;
              ctx.beginPath(); cheminCils(ctx, c, a, b, Math.round(ic - dn * 2.2), Math.round(ic + dn * 0.6));
              ctx.globalAlpha = I * ALPHA_BANDES[k]; ctx.lineWidth = 0.7 + k * 0.1; ctx.stroke();
            }
            // Vacuoles : relais successifs, chacune avec un halo doux
            const nv = c.vac.length;
            for (let k = 0; k < nv; k++) {
              const v = c.vac[k];
              const iv = I * cloche(pos - (0.25 + 0.75 * k / nv), 0.09);
              if (iv < 0.004) continue;
              const rr = v.r * c.prof * (1 + 0.12 * Math.sin(t * 1.7 + v.ph));
              const vx = v.ox * a, vy = v.oy * b;
              ctx.beginPath(); ctx.arc(vx, vy, rr * 2.4, 0, TAU);
              ctx.globalAlpha = iv * 0.16; ctx.fill();
              ctx.beginPath(); ctx.arc(vx, vy, rr, 0, TAU);
              ctx.globalAlpha = Math.min(1, iv * 1.4); ctx.lineWidth = 1; ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
          }
          if (c.gobe > 0.004) {
            ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = rgb(P.mauve);
            ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, b * (0.5 + 0.8 * c.gobe), 0, TAU); ctx.globalAlpha = Ac * 0.35 * c.gobe; ctx.fill();
            ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, 1.5 + 2.5 * c.gobe, 0, TAU); ctx.globalAlpha = Ac * 1.4 * c.gobe; ctx.fill();
            ctx.globalCompositeOperation = 'source-over';
          }

          ctx.restore();
        }
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     2. FILAMENT — flagellé nacré (chaîne suivie-du-chef)
     ===================================================================== */
  function creerFilament() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const N = 32, SEG = 4.8;
    // Profil de largeur : tête bulbeuse, cou pincé, corps effilé
    const larg = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const s = i / (N - 1);
      larg[i] = i < 5 ? 5.6 + 1.2 * Math.sin(i / 4 * Math.PI) : i === 5 ? 3.0 : 3.4 * (1 - (s - 0.18) / 0.82) + 0.7;
    }
    const gx = new Float32Array(N), gy = new Float32Array(N); // bord gauche
    const dx = new Float32Array(N), dy = new Float32Array(N); // bord droit
    const nxs = new Float32Array(N), nys = new Float32Array(N);
    // Onde de nage : amplitude croissante vers la queue, ~0,9 longueur d'onde sur le corps
    const NAGE = { amplitude: 6.5, nombreOnde: 0.9, pulsation: 4.2, gainEnergie: 3.5, sillage: 0.18 };
    const ampl = new Float32Array(N);
    for (let i = 0; i < N; i++) { const s = i / (N - 1); ampl[i] = NAGE.amplitude * (0.08 + 0.92 * Math.pow(s, 1.3)); }
    let W = 360, H = 470, vers = [], t = 0, rl = Math.random;
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre) };

    function nouveau(r) {
      const px = new Float32Array(N), py = new Float32Array(N);   // ligne moyenne (trajectoire)
      const qx = new Float32Array(N), qy = new Float32Array(N);   // corps affiché (ligne + onde)
      const x = r() * W, y = r() * H, cap = r() * TAU;
      for (let i = 0; i < N; i++) {
        px[i] = x - Math.cos(cap) * SEG * i;
        py[i] = y - Math.sin(cap) * SEG * i;
      }
      return { px, py, qx, qy, cap, ph: r() * TAU, phase: 0, freq: 1.5 + r() * 0.4, echelle: 0.9 + r() * 0.25, lueurs: [lueurNeuve(r), lueurNeuve(r)], exc: 0, amp: 1, gobe: 0 };
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const q = borne((opts && opts.quality) || 1, 0.5, 1);
        const r = aleatoire(seed);
        rl = aleatoire(seed ^ 0x51ed);
        vers = [];
        const n = (opts && opts.n) || (q >= 0.75 ? 2 : 1);
        for (let i = 0; i < n; i++) {
          const v = nouveau(r);
          if (i > 0) for (let k = 0; k < N; k++) { v.px[k] += W / 2; v.py[k] += H / 2; }
          vers.push(v);
        }
      },

      reglage(o) { if (o && o.gobe !== undefined) { vers[o.gobe].gobe = 1; return; } Object.assign(RG, o); },
      n() { return vers.length; },
      pos(i) { return [vers[i].px[0], vers[i].py[0]]; },
      place(i, x, y) { vers[i].px[0] = x; vers[i].py[0] = y; },
      vise(i, tx, ty, g) { const v = vers[i]; v.tx = tx; v.ty = ty; v.g = g; },
      geo() { return vers.map(v => ({ k: 'chaine', px: v.qx, py: v.qy, lg: larg, N, e: v.echelle, p: { ant: 34, queue: 2, flancs: 0, voile: 9 } })); },
      update(dt, flow, energy) {
        t += dt;
        const dtc = Math.min(dt, 1 / 30);
        for (const v of vers) {
          const { px, py } = v;
          // Pilotage : errance lente + retour vers le centre près des bords
          const ecX = W / 2 - px[0], ecY = H / 2 - py[0];
          const loin = Math.min(1, Math.hypot(ecX, ecY) / 220);
          let versCentre = Math.atan2(ecY, ecX) - v.cap;
          versCentre -= Math.round(versCentre / TAU) * TAU;
          v.cap += (0.35 * Math.sin(t * 0.29 + v.ph) + versCentre * loin * loin * 0.8) * dtc;
          // Légère embardée de la tête (la propulsion vient de l'onde du corps)
          const balai = v.cap + NAGE.sillage * Math.sin(t * v.freq + v.ph);
          if (v.g) { let d = Math.atan2(v.ty - py[0], v.tx - px[0]) - v.cap; d -= Math.round(d / TAU) * TAU; v.cap += d * v.g * 2.2 * dtc; }
          const vit = (12 + 14 * energy) * v.echelle * RG.vit;
          v.exc += (excitation(RG, px[0], py[0], 160) - v.exc) * Math.min(1, dtc * 2.5);
          const md = RG.mode, ampC = 1 + v.exc * (md === 'agr' ? -0.45 : md === 'evite' ? 0.5 : md === 'cont' ? -0.25 : 0.2);
          v.amp += (ampC - v.amp) * Math.min(1, dtc * 2);
          v.phase += (NAGE.pulsation + NAGE.gainEnergie * energy + v.exc * (md === 'cont' ? 1 : 5)) * dtc * (0.5 + 0.5 * RG.vit);
          v.gobe = Math.max(0, v.gobe - dtc * 0.35);
          const f = flow(px[0], py[0]);
          px[0] += (Math.cos(balai) * vit + f[0] * 0.8) * dtc;
          py[0] += (Math.sin(balai) * vit + f[1] * 0.8) * dtc;
          // Corps cinématique (suivi du chef, sans inertie) : il repasse dans le sillage de la tête,
          // d'où l'onde qui descend le long du corps ; le courant le déporte un peu.
          for (let i = 1; i < N; i++) {
            const fi = flow(px[i], py[i]);
            px[i] += fi[0] * 0.3 * dtc; py[i] += fi[1] * 0.3 * dtc;
          }
          // Lissage léger (raideur en flexion) puis contraintes de longueur
          for (let i = 1; i < N - 1; i++) {
            px[i] += ((px[i - 1] + px[i + 1]) * 0.5 - px[i]) * 0.03;
            py[i] += ((py[i - 1] + py[i + 1]) * 0.5 - py[i]) * 0.03;
          }
          const seg = SEG * v.echelle;
          for (let i = 1; i < N; i++) {
            const ex = px[i] - px[i - 1], ey = py[i] - py[i - 1];
            const k = seg / (Math.hypot(ex, ey) || 1);
            px[i] = px[i - 1] + ex * k; py[i] = py[i - 1] + ey * k;
          }
          // Sortie d'écran : tout le ver passe de l'autre côté
          const m = 90;
          let sx = 0, sy = 0;
          if (px[0] < -m) sx = W + 2 * m; else if (px[0] > W + m) sx = -(W + 2 * m);
          if (py[0] < -m) sy = H + 2 * m; else if (py[0] > H + m) sy = -(H + 2 * m);
          if (sx || sy) for (let i = 0; i < N; i++) { px[i] += sx; py[i] += sy; }
          // Corps affiché : onde progressive tête → queue, perpendiculaire à la ligne moyenne
          const e = v.echelle;
          for (let i = 0; i < N; i++) {
            const a = i > 0 ? i - 1 : 0, b = i < N - 1 ? i + 1 : N - 1;
            let tx = px[a] - px[b], ty = py[a] - py[b];
            const l = 1 / (Math.hypot(tx, ty) || 1);
            const dep = ampl[i] * e * v.amp * Math.sin(v.phase - i / (N - 1) * NAGE.nombreOnde * TAU);
            v.qx[i] = px[i] - ty * l * dep; v.qy[i] = py[i] + tx * l * dep;
          }
          avancerLueur(v.lueurs[0], dt, energy, rl);
          avancerLueur(v.lueurs[1], dt, energy, rl);
        }
      },

      draw(ctx, alpha) {
        const A = alpha * P.alpha.filament;
        if (A <= 0.001) return;
        ctx.save();
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        for (const v of vers) {
          const px = v.qx, py = v.qy, e = v.echelle;
          // Contour : normales lissées sur les voisins
          for (let i = 0; i < N; i++) {
            const a = i > 0 ? i - 1 : 0, b = i < N - 1 ? i + 1 : N - 1;
            let tx = px[a] - px[b], ty = py[a] - py[b];
            const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
            const w = larg[i] * e;
            nxs[i] = -ty; nys[i] = tx;
            gx[i] = px[i] - ty * w; gy[i] = py[i] + tx * w;
            dx[i] = px[i] + ty * w; dy[i] = py[i] - tx * w;
          }
          const capTete = Math.atan2(py[0] - py[1], px[0] - px[1]);
          // Halo aqua très doux le long de l'axe
          ctx.beginPath(); ctx.moveTo(px[0], py[0]);
          for (let i = 1; i < N; i++) ctx.lineTo(px[i], py[i]);
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.05; ctx.lineWidth = 16 * e; ctx.stroke();

          // Corps translucide + liseré nacré
          // Contour fermé : bord gauche, calotte de tête, bord droit
          ctx.beginPath();
          ctx.moveTo(gx[N - 1], gy[N - 1]);
          for (let i = N - 2; i >= 1; i--) ctx.lineTo(gx[i], gy[i]);
          ctx.arc(px[0], py[0], larg[0] * e, capTete + Math.PI / 2, capTete - Math.PI / 2, true);
          for (let i = 1; i < N; i++) ctx.lineTo(dx[i], dy[i]);
          ctx.closePath();
        
          ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.22; ctx.fill();
          ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.08; ctx.fill();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.8; ctx.stroke();

          // Reflet tubulaire : ligne claire décalée côté lumière
          ctx.beginPath();
          for (let i = 1; i < N - 2; i++) {
            const k = larg[i] * e * 0.45;
            const x = px[i] + nxs[i] * k, y = py[i] + nys[i] * k;
            i === 1 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
          }
          ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.7; ctx.stroke();

          // Annelures discrètes le long du corps
          ctx.beginPath();
          for (let i = 6; i < N - 1; i += 2) {
            const k = larg[i] * e * 0.7;
            ctx.moveTo(px[i] - nxs[i] * k, py[i] - nys[i] * k);
            ctx.lineTo(px[i] + nxs[i] * k, py[i] + nys[i] * k);
          }
          ctx.globalAlpha = A * 0.12; ctx.lineWidth = 0.5; ctx.stroke();

          // Tête : deux vacuoles près du cou + strie interne
          ctx.beginPath();
          for (let s = -1; s <= 1; s += 2) {
            const x = px[3] + nxs[3] * s * 2.2 * e, y = py[3] + nys[3] * s * 2.2 * e;
            ctx.moveTo(x + 1.3 * e, y); ctx.arc(x, y, 1.3 * e, 0, TAU);
          }
          ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath();
          ctx.arc(px[1], py[1], 2.8 * e, capTete - 1.2, capTete + 1.2);
          ctx.globalAlpha = A * 0.18; ctx.stroke();

          // Bioluminescence : impulsions qui descendent de la tête vers la queue
          ctx.globalCompositeOperation = 'lighter';
          for (let k = 0; k < 2; k++) {
            const lu = v.lueurs[k];
            const I = A * P.alpha.biolum * enveloppe(lu);
            if (I < 0.004) continue;
            const c = lu.pos * (N + 4) - 2;              // nœud éclairé (peut déborder aux extrémités)
            ctx.strokeStyle = lu.ambre ? coul.ambre : coul.lueur;
            const i0 = Math.max(0, Math.floor(c - 6)), i1 = Math.min(N - 1, Math.ceil(c + 2));
            for (let i = i0; i < i1; i++) {
              const li = I * cloche(i + 0.5 - c, i + 0.5 < c ? 4 : 1.5);   // traîne derrière, front net
              if (li < 0.004) continue;
              ctx.beginPath(); ctx.moveTo(px[i], py[i]); ctx.lineTo(px[i + 1], py[i + 1]);
              ctx.globalAlpha = li * 0.13; ctx.lineWidth = larg[i] * e * 3.6; ctx.stroke();   // halo
              ctx.globalAlpha = li * 0.8; ctx.lineWidth = larg[i] * e * 0.8; ctx.stroke();    // cœur
            }
          }
          // Les deux vacuoles du cou respirent faiblement
          const souffle = A * P.alpha.biolum * 0.18 * (0.5 + 0.5 * Math.sin(t * 0.7 + v.ph));
          if (souffle > 0.004) {
            ctx.beginPath();
            for (let s = -1; s <= 1; s += 2) {
              const x = px[3] + nxs[3] * s * 2.2 * e, y = py[3] + nys[3] * s * 2.2 * e;
              ctx.moveTo(x + 1.3 * e, y); ctx.arc(x, y, 1.3 * e, 0, TAU);
            }
            ctx.strokeStyle = coul.lueur; ctx.globalAlpha = souffle; ctx.lineWidth = 1; ctx.stroke();
          }
          if (v.gobe > 0.004) {
            ctx.fillStyle = rgb(P.mauve);
            ctx.beginPath(); ctx.arc(px[2], py[2], 4 + 9 * v.gobe, 0, TAU); ctx.globalAlpha = A * 0.3 * v.gobe; ctx.fill();
            ctx.beginPath(); ctx.arc(px[2], py[2], 1.5 + 2 * v.gobe, 0, TAU); ctx.globalAlpha = A * 1.4 * v.gobe; ctx.fill();
          }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
      }
    };
  }
  /* =====================================================================
     3. SYSTOLE — cloche ciliée à réaction (réf. 65109 : vacuole contractile étoilée)
     Une Cellule ouverte à l'arrière. La vacuole étoilée se remplit pendant le relâchement,
     puis la cloche se ferme d'un coup : la poussée = vitesse de fermeture (dc/dt), d'où une
     nage par à-coups. Chaque systole lâche un anneau tourbillonnaire. Quatre flagelles de
     Filament traînent du bord, ondulent au rythme du pouls et se resserrent à la contraction.
     ===================================================================== */
  function creerSystole() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NS = 24, NF = 4, NFP = 15, NR = 4, NG = 36, NV = 7, NVEL = 18;
    const sx = new Float32Array(NS), sw = new Float32Array(NS), sl = new Float32Array(NS);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(0.35, -0.2, 0, 0.05, 0, 1.05);
      g.addColorStop(0, rgba(P.perle, 0.11));
      g.addColorStop(0.5, rgba(P.sarcelle, 0.15));
      g.addColorStop(0.84, rgba(P.aqua, 0.2));
      g.addColorStop(1, rgba(P.perle, 0.3));
      return g;
    });
    // Profil temporel : fermeture rapide (26 % du cycle), relâchement lent
    const contraction = f => f < 0.26 ? 0.5 - 0.5 * Math.cos(Math.PI * f / 0.26) : 0.5 + 0.5 * Math.cos(Math.PI * (f - 0.26) / 0.74);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    function dims() {
      const e = s.echelle, c = s.c, gn = s.gon;
      s.A = 30 * e * (1 + 0.17 * c - 0.07 * gn);
      s.B = 21 * e * (1 - 0.22 * c + 0.2 * gn);
      s.RO = s.B * (0.64 - 0.36 * c + 0.16 * gn);
    }
    function profil() {
      const a = s.A, b = s.B, ro = s.RO, c = s.c;
      for (let i = 0; i < NS; i++) {
        const q = i / (NS - 1);
        sx[i] = a * (1 - 1.86 * q);
        let w = q < 0.55 ? b * Math.pow(Math.sin(Math.PI / 2 * q / 0.55), 0.6) : b + (ro - b) * (0.5 - 0.5 * Math.cos(Math.PI * (q - 0.55) / 0.45));
        if (q > 0.1) w *= 1 + 0.05 * c * Math.sin(q * 41 + t * 2.4);      // la membrane se froisse en se fermant
        sw[i] = w; sl[i] = s.bend * a * q * q;                              // la cloche se plie dans les virages
      }
    }
    function cheminCorps(ctx) {
      ctx.beginPath(); ctx.moveTo(sx[NS - 1], -sw[NS - 1] + sl[NS - 1]);
      for (let i = NS - 2; i >= 0; i--) ctx.lineTo(sx[i], -sw[i] + sl[i]);
      for (let i = 1; i < NS; i++) ctx.lineTo(sx[i], sw[i] + sl[i]);
      ctx.quadraticCurveTo(sx[NS - 1] + s.A * 0.32, sl[NS - 1], sx[NS - 1], -sw[NS - 1] + sl[NS - 1]);
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0x5157);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ang: r() * TAU, angv: 0, ph: r() * TAU,
          f: r(), c: 0, dc: 0, acc: 0, bend: 0, gon: 0, ecart: 1, frq: 0.6, exc: 0, gobe: 0, gl: 0, cph: 0, ri: 0,
          echelle: 1.02 + 0.14 * r(), lueur: lueurNeuve(r), anneaux: [], fx: [], fy: [], g: 0, tx: 0, ty: 0,
          grains: new Float32Array(NG * 3), vac: [] };
        s.c = contraction(s.f); dims();
        for (let j = 0; j < NF; j++) {
          const X = new Float32Array(NFP), Y = new Float32Array(NFP);
          for (let i = 0; i < NFP; i++) { X[i] = s.x - Math.cos(s.ang) * (s.A * 0.86 + i * 4.4); Y[i] = s.y - Math.sin(s.ang) * (s.A * 0.86 + i * 4.4); }
          s.fx.push(X); s.fy.push(Y);
        }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, a: 0, r: 0, vie: 0 });
        for (let k = 0; k < NG; k++) { s.grains[k * 3] = r(); s.grains[k * 3 + 1] = (r() * 2 - 1) * 0.8; s.grains[k * 3 + 2] = 0.5 + r() * 0.7; }
        for (let k = 0; k < 4; k++) s.vac.push({ q: 0.5 + r() * 0.3, k: (r() - 0.5) * 1.1, r: 1.5 + r() * 2, ph: r() * TAU, ambre: k === 0 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.tx = tx; s.ty = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: s.A }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.x, s.y, 170);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        // Intention → forme : la cloche se gonfle (curiosité) ou s'effile (attaque, fuite)
        let gon = 0.15 * Math.sin(t * 0.31 + s.ph), frq = 0.42 + 0.45 * energy, ecart = 1;
        if (e > 0.01) {
          if (md === 'cont') { gon += e; frq -= 0.12 * e; ecart = 1 + 0.7 * e; }
          else if (md === 'actif') { gon += 0.6 * e * Math.sin(t * 1.7 + s.ph); frq += 0.35 * e; ecart = 1 + 0.5 * e * Math.sin(t * 2.3); }
          else if (md === 'agr') { gon -= 0.7 * e; frq += 1.1 * e; ecart = 1 - 0.8 * e; }
          else if (md === 'evite') { gon -= 0.9 * e; frq += 1.3 * e; ecart = 1 + 1.1 * e; }
          else if (md === 'suit') { gon += 0.35 * e; frq += 0.2 * e; }
          else { gon += 0.5 * e; frq += 0.15 * e; ecart = 1 + 0.3 * e; }
        }
        s.gon += (gon - s.gon) * Math.min(1, h * 1.8);
        s.ecart += (ecart - s.ecart) * Math.min(1, h * 2);
        s.frq += (frq * (0.5 + 0.5 * RG.vit) - s.frq) * Math.min(1, h * 1.5);
        // Pouls
        const f0 = s.f; s.f += s.frq * h;
        const pic = f0 < 0.26 && s.f >= 0.26;
        if (s.f >= 1) s.f -= 1;
        const cp = s.c; s.c = contraction(s.f); const dc = (s.c - cp) / h; s.dc = dc;
        const cx = Math.cos(s.ang), cy = Math.sin(s.ang);
        const pousse = (dc > 0 ? dc * 36 : dc * 3) * s.echelle * (0.8 + 0.3 * energy);
        s.acc = pousse;
        const fr = Math.exp(-1.7 * h);
        s.vx = s.vx * fr + cx * pousse * h; s.vy = s.vy * fr + cy * pousse * h;
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.35) * h, ny = s.y + (s.vy + fl[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let j = 0; j < NF; j++) for (let i = 0; i < NFP; i++) { s.fx[j][i] += jx; s.fy[j][i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        // Pilotage : on braque surtout pendant le relâchement (bord ouvert)
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.ty - s.y, s.tx - s.x) - s.ang);
        else {
          const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 190);
          d = 0.6 * Math.sin(t * 0.21 + s.ph) + enrouleAngle(Math.atan2(ecY, ecX) - s.ang) * loin * loin;
        }
        const gain = s.g ? 1.5 * s.g : 0.6, braque = 0.3 + 0.7 * (1 - s.c);
        s.angv += (borne(d, -1.3, 1.3) * gain * braque - s.angv) * Math.min(1, h * 2.5);
        s.ang += s.angv * h;
        s.bend += (-s.angv * 0.42 - s.bend) * Math.min(1, h * 3.5);
        dims();
        const ca = Math.cos(s.ang), sa = Math.sin(s.ang), bx = -0.86 * s.A, bl = s.bend * s.A;
        // Anneau tourbillonnaire au pic de la contraction
        if (pic) {
          const an = s.anneaux[s.ri++ % NR];
          an.x = s.x + bx * ca - bl * sa; an.y = s.y + bx * sa + bl * ca;
          an.vx = -ca * 22 + s.vx * 0.1; an.vy = -sa * 22 + s.vy * 0.1; an.a = s.ang; an.r = s.RO * 1.05; an.vie = 1;
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.2 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 7; an.vie -= h / 1.9;
        }
        // Flagelles : ancrés au bord, ondulent au pouls, traînent par inertie
        const seg = 4.4 * s.echelle;
        for (let j = 0; j < NF; j++) {
          const X = s.fx[j], Y = s.fy[j], u = (j / (NF - 1)) * 2 - 1;
          const lx = bx + 1, ly = bl + u * s.RO * 0.8;
          X[0] = s.x + lx * ca - ly * sa; Y[0] = s.y + lx * sa + ly * ca;
          const base = s.ang + Math.PI - u * 0.3 * s.ecart * (1.15 - 0.75 * s.c);
          for (let i = 1; i < NFP; i++) {
            const q = i / (NFP - 1);
            const ai = base + (0.42 + 0.25 * e) * q * Math.sin(TAU * 2 * s.f - i * 0.55 + j * 1.7) + s.bend * 0.9 * q;
            const tx = X[i - 1] + Math.cos(ai) * seg, ty = Y[i - 1] + Math.sin(ai) * seg;
            const k = Math.min(1, h * (16 - 13 * q));
            X[i] += (tx - X[i]) * k; Y[i] += (ty - Y[i]) * k;
            const ex2 = X[i] - X[i - 1], ey2 = Y[i] - Y[i - 1], l = seg / (Math.hypot(ex2, ey2) || 1);
            X[i] = X[i - 1] + ex2 * l; Y[i] = Y[i - 1] + ey2 * l;
          }
        }
        s.gl += h * (0.012 + Math.max(0, dc) * 0.03);                    // cyclose : les grains glissent vers l'arrière à chaque poussée
        s.cph += h * (6 + 5 * energy + 9 * e + Math.max(0, dc) * 3);
        s.gobe = Math.max(0, s.gobe - h * 0.35);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.72; if (A <= 0.001) return;
        const a = s.A, b = s.B, ro = s.RO, c = s.c, e = s.echelle;
        profil();
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de sillage : tore vu de profil (ellipse fine + deux volutes qui tournent)
        ctx.strokeStyle = coul.perle;
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const v = an.vie, sn = Math.sin(an.a), cs = Math.cos(an.a);
          ctx.beginPath(); ctx.ellipse(an.x, an.y, an.r * 0.28, an.r, an.a, 0, TAU);
          ctx.globalAlpha = A * 0.3 * v * v; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x - sn * an.r * sg, qy = an.y + cs * an.r * sg, rr = 1.8 + (1 - v) * 2.2, a0 = an.a + (1 - v) * 9 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.4);
          }
          ctx.globalAlpha = A * 0.5 * v; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // 2. Flagelles nacrés (style Filament : halo, fil, base épaisse, perles)
        ctx.beginPath();
        for (let j = 0; j < NF; j++) {
          const X = s.fx[j], Y = s.fy[j];
          ctx.moveTo(X[0], Y[0]);
          for (let i = 1; i < NFP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
          ctx.lineTo(X[NFP - 1], Y[NFP - 1]);
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        for (let j = 0; j < NF; j++) { const X = s.fx[j], Y = s.fy[j]; ctx.moveTo(X[0], Y[0]); for (let i = 1; i < 6; i++) ctx.lineTo(X[i], Y[i]); }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 1.7; ctx.stroke();
        ctx.beginPath();
        for (let j = 0; j < NF; j++) for (let i = 2; i < NFP; i += 3) { const rr = 1.15 * (1 - i / NFP * 0.6); ctx.moveTo(s.fx[j][i] + rr, s.fy[j][i]); ctx.arc(s.fx[j][i], s.fy[j][i], rr, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.fill();

        // 3. Cloche (repère local : apex en +x)
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.ang);
        cheminCorps(ctx);
        ctx.save(); ctx.scale(a, b); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        ctx.strokeStyle = coul.perle;
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.9; ctx.stroke();
        // Sous-ombrelle : paroi intérieure en U
        ctx.beginPath();
        for (let i = NS - 1; i >= 5; i--) ctx.lineTo(sx[i], -0.74 * sw[i] + sl[i]);
        for (let i = 5; i < NS; i++) ctx.lineTo(sx[i], 0.74 * sw[i] + sl[i]);
        ctx.globalAlpha = A * 0.15; ctx.lineWidth = 1.3; ctx.stroke();
        ctx.quadraticCurveTo(sx[NS - 1] + a * 0.3, sl[NS - 1], sx[NS - 1], -0.74 * sw[NS - 1] + sl[NS - 1]);
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (0.22 + 0.12 * c); ctx.fill();
        // Kinéties : stries qui épousent la courbure
        ctx.beginPath();
        for (let k = -3; k <= 3; k++) {
          if (!k) continue; const f = k / 3.6;
          ctx.moveTo(sx[1], f * sw[1] + sl[1]);
          for (let i = 2; i < NS; i++) ctx.lineTo(sx[i], f * sw[i] + sl[i]);
        }
        ctx.globalAlpha = A * 0.08; ctx.lineWidth = 0.5; ctx.stroke();
        // Vélum : membrane de l'ouverture + ses plis radiaux
        const xr = sx[NS - 1], lr = sl[NS - 1], cxv = xr + a * 0.32;
        ctx.beginPath();
        for (let k = 1; k < 8; k++) {
          const u = k / 8, m = 1 - u;
          const vx = m * m * xr + 2 * u * m * cxv + u * u * xr, vy = m * m * (lr - ro) + 2 * u * m * lr + u * u * (lr + ro);
          ctx.moveTo(vx, vy); ctx.lineTo(vx - 3 - 3 * c, vy + (u - 0.5) * 4);
        }
        ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.5; ctx.stroke();
        // Granulations qui glissent vers l'arrière (cyclose liée à la poussée)
        ctx.fillStyle = coul.perle; ctx.beginPath();
        for (let k = 0; k < NG; k++) {
          const q = (s.grains[k * 3] + s.gl) % 1, fi = q * 0.92 * (NS - 1), i0 = fi | 0, u = fi - i0, i1 = Math.min(NS - 1, i0 + 1);
          const x = sx[i0] + (sx[i1] - sx[i0]) * u, w = sw[i0] + (sw[i1] - sw[i0]) * u, l = sl[i0] + (sl[i1] - sl[i0]) * u;
          const sz = s.grains[k * 3 + 2] * (q > 0.8 ? (1 - q) * 5 : 1);
          ctx.rect(x - sz * 0.5, s.grains[k * 3 + 1] * w * 0.8 + l - sz * 0.5, sz, sz);
        }
        ctx.globalAlpha = A * 0.26; ctx.fill();
        // Noyau
        const inn = Math.round(0.2 * (NS - 1));
        ctx.beginPath(); ctx.arc(sx[inn], sl[inn] + sw[inn] * 0.25, b * 0.24, 0, TAU);
        ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.7; ctx.stroke();
        // Vacuoles digestives
        ctx.beginPath();
        for (const v of s.vac) {
          const i = Math.round(v.q * (NS - 1)), rr = v.r * e * (1 + 0.1 * Math.sin(t * 1.6 + v.ph));
          const x = sx[i], y = v.k * sw[i] * 0.6 + sl[i];
          ctx.moveTo(x + rr, y); ctx.arc(x, y, rr, 0, TAU);
        }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
        // Vacuole contractile étoilée : se remplit au relâchement, se vide à la systole
        const iv = Math.round(0.38 * (NS - 1)), vx0 = sx[iv], vy0 = sl[iv] - 0.12 * sw[iv];
        const plein = 1 - c, rv = (2 + 3.4 * plein) * e;
        ctx.beginPath();
        for (let k = 0; k < NV; k++) {
          const q = k / NV * TAU + s.ph, Lr = (4.5 + 8.5 * plein) * e * (0.8 + 0.2 * Math.sin(k * 2.1 + s.ph));
          const q2 = q + 0.35 * (0.5 - plein);                           // les canaux se tordent en se vidant
          ctx.moveTo(vx0 + Math.cos(q) * rv, vy0 + Math.sin(q) * rv * 0.9);
          ctx.quadraticCurveTo(vx0 + Math.cos(q2) * (rv + Lr * 0.6), vy0 + Math.sin(q2) * (rv + Lr * 0.6) * 0.9, vx0 + Math.cos(q) * (rv + Lr), vy0 + Math.sin(q) * (rv + Lr) * 0.9);
        }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 2.6; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.34; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(vx0, vy0, rv, 0, TAU);
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.8; ctx.stroke();
        // Cils : vague métachronale, couchés vers l'arrière selon la vitesse et la poussée
        const lean = borne(Math.hypot(s.vx, s.vy) * 0.045 + Math.max(0, s.acc) * 0.004, 0, 2);
        ctx.beginPath();
        for (let sd = -1; sd <= 1; sd += 2) for (let i = 1; i < NS - 1; i++) {
          const i0 = i - 1, i1 = i + 1;
          let tx = sx[i1] - sx[i0], ty = sd * (sw[i1] - sw[i0]) + (sl[i1] - sl[i0]);
          const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
          const nx = sd * ty, ny = -sd * tx;
          for (let hh = 0; hh < 2; hh++) {
            const fx = hh ? (sx[i] + sx[i1]) / 2 : sx[i], fy = hh ? (sd * (sw[i] + sw[i1]) + sl[i] + sl[i1]) / 2 : sd * sw[i] + sl[i];
            const ph = s.cph - (i + hh * 0.5) * 0.55 + (sd > 0 ? 0 : 1.3);
            const L = (2.3 + 1.4 * Math.sin(ph)) * (1 + 0.45 * s.exc), pli = 1.3 * Math.cos(ph);
            ctx.moveTo(fx + nx * 0.8, fy + ny * 0.8);
            ctx.lineTo(fx + nx * (0.8 + L) + tx * pli - lean * L * 0.4, fy + ny * (0.8 + L) + ty * pli);
          }
        }
        ctx.strokeStyle = coul.perle;
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 2.2; ctx.stroke();
        ctx.globalAlpha = A * 0.24; ctx.lineWidth = 0.5; ctx.stroke();
        // Frange du vélum : longue quand la cloche se gonfle (curiosité)
        ctx.beginPath();
        const fr = 3 + 6 * Math.max(0, s.gon) + 1.5 * s.ecart;
        for (let k = 0; k <= NVEL; k++) {
          const u = k / NVEL, m = 1 - u;
          const vx = m * m * xr + 2 * u * m * cxv + u * u * xr, vy = m * m * (lr - ro) + 2 * u * m * lr + u * u * (lr + ro);
          const ph = s.cph * 1.4 - k * 0.7, L = fr * (0.75 + 0.25 * Math.sin(ph));
          const sp = (u - 0.5) * (0.5 + 0.5 * s.ecart);
          ctx.moveTo(vx, vy); ctx.lineTo(vx - L, vy + sp * L * 1.4 + Math.cos(ph) * 1.1);
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // Bioluminescence : de l'apex au bord le long de la membrane
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        ctx.globalCompositeOperation = 'lighter';
        if (I > 0.004 && s.lueur.pos < 0.6) {
          const cc = s.lueur.pos / 0.5 * (NS + 2) - 1;
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NS - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 < cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath();
            ctx.moveTo(sx[i], -sw[i] + sl[i]); ctx.lineTo(sx[i + 1], -sw[i + 1] + sl[i + 1]);
            ctx.moveTo(sx[i], sw[i] + sl[i]); ctx.lineTo(sx[i + 1], sw[i + 1] + sl[i + 1]);
            ctx.globalAlpha = li * 0.15; ctx.lineWidth = 7; ctx.stroke();
            ctx.globalAlpha = li * 0.7; ctx.lineWidth = 1.1; ctx.stroke();
          }
        }
        // La vacuole étoilée s'allume à chaque systole (très faible) et au gobage (mauve)
        const sys = A * P.alpha.biolum * 0.14 * Math.max(0, s.dc) / 4;
        if (sys > 0.004) { ctx.beginPath(); ctx.arc(vx0, vy0, rv * 2.2, 0, TAU); ctx.fillStyle = coul.lueur; ctx.globalAlpha = Math.min(0.2, sys); ctx.fill(); }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(vx0, vy0, (7 + 12 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.22 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(vx0, vy0, rv * (0.6 + 0.6 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
        // Bioluminescence (suite) : l'impulsion descend les flagelles
        if (I > 0.004 && s.lueur.pos > 0.4) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cf = (s.lueur.pos - 0.45) / 0.75 * (NFP + 3) - 1;
          for (let i = 0; i < NFP - 1; i++) {
            const li = I * cloche(i + 0.5 - cf, i + 0.5 < cf ? 4 : 1.3); if (li < 0.004) continue;
            ctx.beginPath();
            for (let j = 0; j < NF; j++) { ctx.moveTo(s.fx[j][i], s.fy[j][i]); ctx.lineTo(s.fx[j][i + 1], s.fy[j][i + 1]); }
            ctx.globalAlpha = li * 0.14; ctx.lineWidth = 5; ctx.stroke();
            ctx.globalAlpha = li * 0.75; ctx.lineWidth = 0.9; ctx.stroke();
          }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     4. CULBUTE — toupie ciliée à axe instable (réf. 43798 : effet Djanibekov)
     Un corps de Cellule (ellipsoïde 3D) porte une trompe de Filament le long de son axe
     intermédiaire. Il tourne vraiment selon les équations d'Euler (I1 < I2 < I3) : la
     rotation autour de la trompe est instable, d'où des culbutes de 180° périodiques.
     La trompe bat en hélice et TIRE le corps : chaque culbute retourne la trajectoire.
     Quand il vise (particule, proie), un couple amortit la culbute et la trompe se tend.
     ===================================================================== */
  function creerCulbute() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const EA = 31, EB = 13, EC = 14, I1 = 1, I2 = 1.65, I3 = 2.3;
    const NST = 16, NMER = 8, NMS = 14, NB = 3, NBC = 28, NGR = 26, NCOL = 12, NTF = 9;
    const R = new Float64Array(9), w = new Float64Array(3), tau = new Float64Array(3), pj = new Float64Array(3);
    const SX = new Float32Array(NST), SY = new Float32Array(NST), SZ = new Float32Array(NST);
    const mer = new Float32Array(NMER * NMS * 3), merP = new Float32Array(NMER * NMS * 3);
    const bande = new Float32Array(NB * NBC * 9), cilP = new Float32Array(NB * NBC * 5);
    const grains = new Float32Array(NGR * 3), grP = new Float32Array(NGR * 3);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.3, -0.3, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.13));
      g.addColorStop(0.5, rgba(P.sarcelle, 0.16));
      g.addColorStop(0.85, rgba(P.aqua, 0.18));
      g.addColorStop(0.97, rgba(P.perle, 0.3));
      g.addColorStop(1, rgba(P.perle, 0));
      return g;
    });
    // Géométrie propre (repère du corps, e2 = axe de la trompe)
    for (let m = 0; m < NMER; m++) for (let j = 0; j < NMS; j++) {
      const ph = m / NMER * TAU, th = Math.PI * (0.08 + 0.84 * j / (NMS - 1)), o = (m * NMS + j) * 3;
      mer[o] = EA * Math.sin(th) * Math.cos(ph); mer[o + 1] = EB * Math.cos(th); mer[o + 2] = EC * Math.sin(th) * Math.sin(ph);
    }
    const LAT = [0.3, 0.5, 0.7];
    for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k < NBC; k++) {
      const th = Math.PI * LAT[bnd], ph = (k + bnd * 0.5) / NBC * TAU, o = (bnd * NBC + k) * 9;
      const x = EA * Math.sin(th) * Math.cos(ph), y = EB * Math.cos(th), z = EC * Math.sin(th) * Math.sin(ph);
      let nx = x / (EA * EA), ny = y / (EB * EB), nz = z / (EC * EC); const nl = 1 / Math.hypot(nx, ny, nz);
      let gx = -EA * Math.sin(ph), gz = EC * Math.cos(ph); const gl = 1 / Math.hypot(gx, gz);
      bande[o] = x; bande[o + 1] = y; bande[o + 2] = z; bande[o + 3] = nx * nl; bande[o + 4] = ny * nl; bande[o + 5] = nz * nl;
      bande[o + 6] = gx * gl; bande[o + 7] = 0; bande[o + 8] = gz * gl;
    }
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;
    function projeter(x, y, z) { pj[0] = R[0] * x + R[1] * y + R[2] * z; pj[1] = R[3] * x + R[4] * y + R[5] * z; pj[2] = R[6] * x + R[7] * y + R[8] * z; }
    // Un pas des équations d'Euler (corps rigide libre + couple propre tau)
    function pas(h) {
      const w1 = w[0], w2 = w[1], w3 = w[2];
      w[0] += ((I2 - I3) * w2 * w3 + tau[0]) / I1 * h;
      w[1] += ((I3 - I1) * w3 * w1 + tau[1]) / I2 * h;
      w[2] += ((I1 - I2) * w1 * w2 + tau[2]) / I3 * h;
      for (let r = 0; r < 9; r += 3) {
        const a = R[r], b = R[r + 1], c = R[r + 2];
        R[r] = a + h * (b * w[2] - c * w[1]); R[r + 1] = b + h * (c * w[0] - a * w[2]); R[r + 2] = c + h * (a * w[1] - b * w[0]);
      }
    }
    function orthonormer() {
      let l = 1 / Math.hypot(R[0], R[3], R[6]); R[0] *= l; R[3] *= l; R[6] *= l;
      const d = R[0] * R[1] + R[3] * R[4] + R[6] * R[7]; R[1] -= d * R[0]; R[4] -= d * R[3]; R[7] -= d * R[6];
      l = 1 / Math.hypot(R[1], R[4], R[7]); R[1] *= l; R[4] *= l; R[7] *= l;
      R[2] = R[3] * R[7] - R[6] * R[4]; R[5] = R[6] * R[1] - R[0] * R[7]; R[8] = R[0] * R[4] - R[3] * R[1];
    }
    const mix = (a, b, k) => a + (b - a) * k;

    const TG = new Float32Array(NST * 2), TD = new Float32Array(NST * 2);
    function traceTige(ctx, A) {
      // Corps de la trompe : ruban effilé (largeur 3,2 → 0,6) rempli comme le Filament
      for (let i = 0; i < NST; i++) {
        const a = i ? i - 1 : 0, b = i < NST - 1 ? i + 1 : NST - 1;
        let tx = SX[b] - SX[a], ty = SY[b] - SY[a]; const l = 1 / (Math.hypot(tx, ty) || 1);
        const wd = (3.2 - 2.6 * i / (NST - 1)) * (1 - 0.25 * (s.ext - 1)) * (1 + 0.15 * Math.sin(s.psi - i * 0.6));
        TG[i * 2] = SX[i] - ty * l * wd; TG[i * 2 + 1] = SY[i] + tx * l * wd; TD[i * 2] = SX[i] + ty * l * wd; TD[i * 2 + 1] = SY[i] - tx * l * wd;
      }
      ctx.beginPath(); ctx.moveTo(TG[0], TG[1]);
      for (let i = 1; i < NST; i++) ctx.lineTo(TG[i * 2], TG[i * 2 + 1]);
      for (let i = NST - 1; i >= 0; i--) ctx.lineTo(TD[i * 2], TD[i * 2 + 1]);
      ctx.closePath();
      ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.25; ctx.fill(); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.08; ctx.fill();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(SX[0], SY[0]);
      for (let i = 1; i < NST - 1; i++) ctx.quadraticCurveTo(SX[i], SY[i], (SX[i] + SX[i + 1]) / 2, (SY[i] + SY[i + 1]) / 2);
      ctx.lineTo(SX[NST - 1], SY[NST - 1]);
      ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 6; ctx.stroke();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.5; ctx.stroke();

      // Annelures perpendiculaires (suivent la torsion de l'hélice)
      ctx.beginPath();
      for (let i = 2; i < NST - 1; i += 2) {
        let tx = SX[i + 1] - SX[i - 1], ty = SY[i + 1] - SY[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1);
        const k = 2.1 * (1 - i / NST * 0.6) * (0.6 + 0.4 * Math.sin(s.psi - i * 0.6));
        ctx.moveTo(SX[i] - ty * l * k, SY[i] + tx * l * k); ctx.lineTo(SX[i] + ty * l * k, SY[i] - tx * l * k);
      }
      ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.5; ctx.stroke();
      // Tête de Filament au bout de la trompe : bulbe allongé, deux vacuoles, lèvre ciliée
      const bx = SX[NST - 1], by = SY[NST - 1], ta = Math.atan2(SY[NST - 1] - SY[NST - 3], SX[NST - 1] - SX[NST - 3]);
      const hl = 3.6 + 1.4 * s.ext, hw = 2.6 + 0.5 * s.ext, ca = Math.cos(ta), sa = Math.sin(ta);
      ctx.beginPath(); ctx.ellipse(bx + ca * hl * 0.6, by + sa * hl * 0.6, hl, hw, ta, 0, TAU);
      ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.3; ctx.fill(); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.1; ctx.fill();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.75; ctx.stroke();
      ctx.beginPath();
      for (let sg = -1; sg <= 1; sg += 2) { const vx = bx + ca * hl * 0.3 - sa * sg * hw * 0.45, vy = by + sa * hl * 0.3 + ca * sg * hw * 0.45; ctx.moveTo(vx + 0.9, vy); ctx.arc(vx, vy, 0.9, 0, TAU); }
      ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.5; ctx.stroke();
      ctx.beginPath();
      for (let k = 0; k < 9; k++) {
        const q = ta - 1.2 + k / 8 * 2.4, L = (2 + 1.2 * Math.sin(s.cph * 1.4 - k * 0.8)) * (1 + 0.6 * s.exc);
        const x0 = bx + ca * hl * 0.6 + Math.cos(q) * hl, y0 = by + sa * hl * 0.6 + Math.sin(q) * hw * 1.1;
        ctx.moveTo(x0, y0); ctx.lineTo(x0 + Math.cos(q) * L, y0 + Math.sin(q) * L);
      }
      ctx.globalAlpha = A * 0.38; ctx.lineWidth = 0.5; ctx.stroke();
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xd1a);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        const a0 = r() * TAU, b0 = 0.5 + r() * 0.5, c = Math.cos(a0), sn = Math.sin(a0), cb = Math.cos(b0), sb = Math.sin(b0);
        R[0] = c; R[1] = -sn * cb; R[2] = sn * sb; R[3] = sn; R[4] = c * cb; R[5] = -c * sb; R[6] = 0; R[7] = sb; R[8] = cb;
        w[0] = 0.05; w[1] = 3.6 + r(); w[2] = 0.04;
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ph: r() * TAU, psi: 0, cph: 0, ext: 1, amp: 1,
          exc: 0, gobe: 0, lueur: lueurNeuve(r), g: 0, tx: 0, ty: 0, vac: [] };
        for (let k = 0; k < NGR; k++) {
          const u = r() * TAU, v = Math.acos(2 * r() - 1), rr = 0.78 * Math.cbrt(r());
          grains[k * 3] = EA * rr * Math.sin(v) * Math.cos(u); grains[k * 3 + 1] = EB * rr * Math.cos(v); grains[k * 3 + 2] = EC * rr * Math.sin(v) * Math.sin(u);
        }
        for (let k = 0; k < 5; k++) s.vac.push([(r() - 0.5) * EA * 1.1, (r() - 0.5) * EB * 0.9, (r() - 0.5) * EC * 1.1, 1.6 + r() * 1.8, r() < 0.3]);
        for (let i = 0; i < NST; i++) { projeter(0, EB * 0.9 + i * 2.8, 0); SX[i] = s.x + pj[0]; SY[i] = s.y + pj[1]; SZ[i] = pj[2]; }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.tx = tx; s.ty = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: EA }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.x, s.y, 170);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        // Paramètres libres (culbutes) puis mélange vers la réponse du comportement
        let spin = (3 + 3 * energy) * (0.6 + 0.4 * RG.vit), kA = s.g ? 3.5 * s.g : 0, kD = s.g ? 1.2 : 0, kick = 0.08;
        let ext = 1 + 0.08 * Math.sin(t * 0.6 + s.ph), amp = 1, bf = 7 + 6 * energy, tire = 1, regardePart = false;
        if (e > 0.01) {
          let m;
          if (md === 'cont') m = [1.0, 5, 2.2, 0.02, 1 + 0.6 * e, 0.45, 5, 0.35, 1];
          else if (md === 'suit') m = [2, 4, 1.8, 0.04, 1.25, 0.8, 8, 0.7, 1];
          else if (md === 'actif') m = [7.5, 0.6, 0, 0.9, 1 + 0.25 * Math.sin(t * 3), 1.25, 12, 1, 0];
          else if (md === 'agr') m = [2.6, 9, 2.6, 0.02, 1 + 0.75 * e, 0.22, 17, 1.7, 1];
          else if (md === 'evite') m = [9, 4, 0.4, 1.1, 0.5, 1.5, 15, 1.4, 0];
          else m = [4, 3, 1, 0.1, 1.15, 1, 9, 1, 0];
          spin = mix(spin, m[0], e); kA = mix(kA, m[1], e); kD = mix(kD, m[2], e); kick = mix(kick, m[3], e);
          ext = mix(ext, m[4], e); amp = mix(amp, m[5], e); bf = mix(bf, m[6], e); tire = mix(tire, m[7], e); regardePart = m[8] > 0;
        }
        // Couples : régulation de |ω| (moteur ciliaire), visée de la trompe, petite perturbation déterministe
        tau[0] = tau[1] = tau[2] = 0;
        const lookOk = regardePart || s.g > 0;
        if (kA > 0 && lookOk) {
          const lx = regardePart ? RG.part.x : s.tx, ly = regardePart ? RG.part.y : s.ty;
          let dx = lx - s.x, dy = ly - s.y; const dl = Math.hypot(dx, dy) || 1; dx /= dl; dy /= dl;
          const tx = -R[7] * dy, ty = R[7] * dx, tz = R[1] * dy - R[4] * dx;
          tau[0] = kA * (R[0] * tx + R[3] * ty + R[6] * tz) - kD * w[0];
          tau[1] = kA * (R[1] * tx + R[4] * ty + R[7] * tz);
          tau[2] = kA * (R[2] * tx + R[5] * ty + R[8] * tz) - kD * w[2];
        }
        const wm = Math.hypot(w[0], w[1], w[2]) || 1, ks = 1.4 * (spin - wm) / wm;
        tau[0] += ks * w[0] * I1 + kick * Math.sin(t * 1.7 + s.ph) * I1;
        tau[1] += ks * w[1] * I2;
        tau[2] += ks * w[2] * I3 + kick * Math.cos(t * 1.1 + s.ph) * I3;
        const n = Math.ceil(h * 240), hh = h / n;
        for (let k = 0; k < n; k++) pas(hh);
        orthonormer();
        // Translation : la trompe bat et tire le corps dans sa direction (projetée)
        s.ext += (ext - s.ext) * Math.min(1, h * 2.2);
        s.amp += (amp - s.amp) * Math.min(1, h * 2.5);
        s.psi += bf * h;
        s.cph += h * (8 + 10 * energy + 16 * e * (md === 'evite' || md === 'actif' || md === 'agr' ? 1 : 0.3));
        const pull = (7 + 11 * energy) * RG.vit * tire * (0.75 + 0.25 * Math.sin(s.psi));
        let tvx = R[1] * pull, tvy = R[4] * pull;
        if (s.g) { const dx = s.tx - s.x, dy = s.ty - s.y, d = Math.hypot(dx, dy) || 1; tvx += dx / d * 9 * s.g; tvy += dy / d * 9 * s.g; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 180); tvx += ecX * loin * loin * 0.12; tvy += ecY * loin * loin * 0.12; }
        s.vx += (tvx - s.vx) * Math.min(1, h * 1.6); s.vy += (tvy - s.vy) * Math.min(1, h * 1.6);
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.4) * h, ny = s.y + (s.vy + fl[1] * 0.4) * h;
        s.x = enroule(nx, 0, W, 70); s.y = enroule(ny, 0, H, 70);
        const jx = s.x - nx, jy = s.y - ny;
        // Trompe : hélice dans le repère du corps, l'extrémité traîne pendant les culbutes
        const L = 60 * s.ext, seg = L / (NST - 1);
        for (let i = 0; i < NST; i++) {
          const q = i / (NST - 1), Aq = s.amp * 5.5 * Math.pow(q, 1.2), ph = s.psi - i * 0.6;
          projeter(Aq * Math.sin(ph), EB * 0.9 + i * seg, Aq * Math.cos(ph) * 0.7);
          const wx = s.x + pj[0], wy = s.y + pj[1], wz = pj[2];
          if (i === 0) { SX[0] = wx; SY[0] = wy; SZ[0] = wz; continue; }
          SX[i] += jx; SY[i] += jy;
          const k = Math.min(1, h * (36 - 30 * q));
          SX[i] += (wx - SX[i]) * k; SY[i] += (wy - SY[i]) * k; SZ[i] += (wz - SZ[i]) * k;
          const ex2 = SX[i] - SX[i - 1], ey2 = SY[i] - SY[i - 1], ez2 = SZ[i] - SZ[i - 1], l = seg / (Math.hypot(ex2, ey2, ez2) || 1);
          SX[i] = SX[i - 1] + ex2 * l; SY[i] = SY[i - 1] + ey2 * l; SZ[i] = SZ[i - 1] + ez2 * l;
        }
        s.gobe = Math.max(0, s.gobe - h * 0.35);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.72; if (A <= 0.001) return;
        // Silhouette : projection orthographique de l'ellipsoïde = ellipse (axes propres de P·Pᵀ)
        const m00 = R[0] * EA, m01 = R[1] * EB, m02 = R[2] * EC, m10 = R[3] * EA, m11 = R[4] * EB, m12 = R[5] * EC;
        const Sxx = m00 * m00 + m01 * m01 + m02 * m02, Syy = m10 * m10 + m11 * m11 + m12 * m12, Sxy = m00 * m10 + m01 * m11 + m02 * m12;
        const th = 0.5 * Math.atan2(2 * Sxy, Sxx - Syy), mo = (Sxx + Syy) / 2, di = Math.sqrt((Sxx - Syy) * (Sxx - Syy) / 4 + Sxy * Sxy);
        const ra = Math.sqrt(mo + di), rb = Math.sqrt(Math.max(1, mo - di));
        // Projections
        for (let k = 0; k < NMER * NMS; k++) { projeter(mer[k * 3], mer[k * 3 + 1], mer[k * 3 + 2]); merP[k * 3] = s.x + pj[0]; merP[k * 3 + 1] = s.y + pj[1]; merP[k * 3 + 2] = pj[2]; }
        const ex = s.exc;
        for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k < NBC; k++) {
          const o = (bnd * NBC + k) * 9, q = (bnd * NBC + k) * 5;
          const ph = s.cph - k * 0.5 + bnd * 1.1, L = (3 + 1.5 * Math.sin(ph)) * (1 + 0.5 * ex), pli = 1.6 * Math.cos(ph);
          const bx = bande[o], by = bande[o + 1], bz = bande[o + 2];
          projeter(bx + bande[o + 3] * 0.6, by + bande[o + 4] * 0.6, bz + bande[o + 5] * 0.6);
          cilP[q] = s.x + pj[0]; cilP[q + 1] = s.y + pj[1]; cilP[q + 4] = pj[2];
          projeter(bx + bande[o + 3] * (0.6 + L) + bande[o + 6] * pli, by + bande[o + 4] * (0.6 + L) - L * 0.25, bz + bande[o + 5] * (0.6 + L) + bande[o + 8] * pli);
          cilP[q + 2] = s.x + pj[0]; cilP[q + 3] = s.y + pj[1];
        }
        for (let k = 0; k < NGR; k++) { projeter(grains[k * 3], grains[k * 3 + 1], grains[k * 3 + 2]); grP[k * 3] = s.x + pj[0]; grP[k * 3 + 1] = s.y + pj[1]; grP[k * 3 + 2] = pj[2]; }
        const tigeDevant = SZ[3] >= 0;
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const mers = (devant) => {
          ctx.beginPath();
          for (let m = 0; m < NMER; m++) for (let j = 0; j < NMS - 1; j++) {
            const o = (m * NMS + j) * 3, z = merP[o + 2] + merP[o + 5];
            if ((z >= 0) !== devant) continue;
            ctx.moveTo(merP[o], merP[o + 1]); ctx.lineTo(merP[o + 3], merP[o + 4]);
          }
        };
        const cils = (devant, b0, b1) => {
          ctx.beginPath();
          for (let k = b0 * NBC; k < b1 * NBC; k++) { const q = k * 5; if ((cilP[q + 4] >= 0) !== devant) continue; ctx.moveTo(cilP[q], cilP[q + 1]); ctx.lineTo(cilP[q + 2], cilP[q + 3]); }
        };
        // Plan arrière
        ctx.strokeStyle = coul.perle;
        mers(false); ctx.globalAlpha = A * 0.08; ctx.lineWidth = 0.5; ctx.stroke();
        cils(false, 0, NB); ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.45; ctx.stroke();
        if (!tigeDevant) traceTige(ctx, A * 0.75);
        // Corps
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(th); ctx.scale(ra, rb);
        ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill();
        ctx.restore();
        ctx.strokeStyle = coul.perle;
        ctx.beginPath(); ctx.ellipse(s.x, s.y, ra, rb, th, 0, TAU);
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.9; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(s.x, s.y, ra * 0.9, rb * 0.86, th, 0, TAU);
        ctx.globalAlpha = A * 0.12; ctx.lineWidth = 1.4; ctx.stroke();
        // Intérieur : grains (arrière pâles, avant nets), vacuoles, macronoyau
        ctx.fillStyle = coul.perle;
        for (let pass = 0; pass < 2; pass++) {
          ctx.beginPath();
          for (let k = 0; k < NGR; k++) { const z = grP[k * 3 + 2]; if ((z >= 0) !== (pass === 1)) continue; const sz = 0.7 + z * 0.02; ctx.rect(grP[k * 3] - sz / 2, grP[k * 3 + 1] - sz / 2, sz, sz); }
          ctx.globalAlpha = A * (pass ? 0.34 : 0.14); ctx.fill();
        }
        ctx.beginPath();
        for (const v of s.vac) { projeter(v[0], v[1], v[2]); const rr = v[3] * (1 + 0.012 * pj[2]); ctx.moveTo(s.x + pj[0] + rr, s.y + pj[1]); ctx.arc(s.x + pj[0], s.y + pj[1], rr, 0, TAU); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.7; ctx.stroke();
        projeter(-EA * 0.3, -EB * 0.15, 0);
        const nux = s.x + pj[0], nuy = s.y + pj[1];
        ctx.beginPath(); ctx.arc(nux, nuy, 6, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.18; ctx.lineWidth = 0.7; ctx.stroke();
        // Méridiens (kinéties) et bandes ciliées avant : ils tournent avec le corps
        mers(true); ctx.globalAlpha = A * 0.22; ctx.lineWidth = 0.55; ctx.stroke();
        ctx.beginPath();
        for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k <= NBC; k++) {
          const q = (bnd * NBC + (k % NBC)) * 5;
          if (k === 0 || cilP[q + 4] < 0) ctx.moveTo(cilP[q], cilP[q + 1]); else ctx.lineTo(cilP[q], cilP[q + 1]);
        }
        ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.6; ctx.stroke();
        cils(true, 0, NB); ctx.globalAlpha = A * 0.08; ctx.lineWidth = 2.2; ctx.stroke(); ctx.globalAlpha = A * 0.34; ctx.lineWidth = 0.5; ctx.stroke();
        // Reflet spéculaire : le point de l'ellipsoïde dont la normale regarde la lumière
        {
          const hx = -0.25, hy = -0.35, hz = 0.9;
          const n0 = R[0] * hx + R[3] * hy + R[6] * hz, n1 = R[1] * hx + R[4] * hy + R[7] * hz, n2 = R[2] * hx + R[5] * hy + R[8] * hz;
          const dn = 1 / Math.sqrt(EA * EA * n0 * n0 + EB * EB * n1 * n1 + EC * EC * n2 * n2);
          projeter(EA * EA * n0 * dn * 0.92, EB * EB * n1 * dn * 0.92, EC * EC * n2 * dn * 0.92);
          ctx.fillStyle = coul.perle;
          ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 5, 0, TAU); ctx.globalAlpha = A * 0.07; ctx.fill();
          ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 1.5, 0, TAU); ctx.globalAlpha = A * 0.4; ctx.fill();
        }
        // Collerette à la base de la trompe
        ctx.beginPath();
        for (let k = 0; k < NCOL; k++) {
          const q = k / NCOL * TAU, L = 3 + 1.5 * Math.sin(s.cph * 1.2 - k * 0.9);
          projeter(Math.cos(q) * 4, EB * 0.82, Math.sin(q) * 4); const x0 = s.x + pj[0], y0 = s.y + pj[1];
          projeter(Math.cos(q) * (4 + L), EB * 0.82 + L * 0.5, Math.sin(q) * (4 + L));
          ctx.moveTo(x0, y0); ctx.lineTo(s.x + pj[0], s.y + pj[1]);
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // Touffes polaires : longs cils en éventail aux deux bouts du fuseau, battent en 3D
        for (let pass = 0; pass < 2; pass++) {
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) for (let k = 0; k < NTF; k++) {
            const u = (k / (NTF - 1) - 0.5) * 2.2, ph = s.cph * 0.8 - k * 0.7 + (sg > 0 ? 0 : 2), L = (13 + 4 * Math.sin(ph)) * (1 + 0.35 * ex);
            const dy = Math.sin(u) * 0.7 + 0.35 * Math.cos(ph), dz = Math.cos(u) * 0.5 * Math.sin(ph * 0.5 + k);
            const bx = sg * EA * 0.93, by = Math.sin(u) * 3, bz = Math.cos(u) * 2;
            projeter(bx, by, bz); const x0 = s.x + pj[0], y0 = s.y + pj[1], z0 = pj[2];
            if ((z0 >= 0) !== (pass === 1)) continue;
            projeter(bx + sg * L * 0.55, by + dy * L * 0.6, bz + dz * L);
            const x2 = s.x + pj[0], y2 = s.y + pj[1];
            projeter(bx + sg * L * 0.85, by + dy * L, bz + dz * L * 1.4);
            ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x2, y2, s.x + pj[0], s.y + pj[1]);
          }
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * (pass ? 0.42 : 0.16); ctx.lineWidth = 0.6; ctx.stroke();
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 2.4; ctx.stroke();
        }
        if (tigeDevant) traceTige(ctx, A);
        // Lumières : bioluminescence (trompe → bande équatoriale) et particule absorbée (mauve)
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cc = (1 - s.lueur.pos / 0.6) * (NST + 2);
          for (let i = 0; i < NST - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 > cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath(); ctx.moveTo(SX[i], SY[i]); ctx.lineTo(SX[i + 1], SY[i + 1]);
            ctx.globalAlpha = li * 0.15; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.75; ctx.lineWidth = 1.2; ctx.stroke();
          }
          const lb = I * cloche(s.lueur.pos - 0.85, 0.22);
          if (lb > 0.004) { cils(true, 1, 2); ctx.globalAlpha = Math.min(1, lb * 1.2); ctx.lineWidth = 0.7; ctx.stroke(); ctx.globalAlpha = lb * 0.2; ctx.lineWidth = 3; ctx.stroke(); }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.x, s.y, 8 + 14 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.2 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(nux, nuy, 2 + 4 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.85 * s.gobe; ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     5. CHŒUR — colonie de cellules tenues par des fils (réf. 38578 + 28007)
     Huit petites Cellules en anneau, reliées par des fils de Filament et noyées dans une
     membrane commune. Une onde péristaltique fait le tour de l'anneau : c'est la rame.
     Les fils mous pendent, les fils tendus vibrent ; la membrane se froisse quand elle se
     comprime. Cycle lent : la colonie se divise en deux, s'éloigne, puis se recoud fil à fil.
     Au cœur, deux trèfles de filament enlacés se séparent avec elle.
     ===================================================================== */
  function creerChoeur() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const K = 10, HK = 5, NCIL = 14, NK = 44, CA = 8.2, CB = 5.4;
    const px = new Float32Array(K), py = new Float32Array(K), vx = new Float32Array(K), vy = new Float32Array(K);
    const perle = new Float32Array(2 * K), tx = new Float32Array(K), ty = new Float32Array(K), oa = new Float32Array(K), ox = new Float32Array(K), oy = new Float32Array(K);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const c = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      c.addColorStop(0, rgba(P.perle, 0.1)); c.addColorStop(0.55, rgba(P.sarcelle, 0.14));
      c.addColorStop(0.86, rgba(P.aqua, 0.2)); c.addColorStop(0.97, rgba(P.perle, 0.34)); c.addColorStop(1, rgba(P.perle, 0));
      const m = ctx.createRadialGradient(0, 0, 0.2, 0, 0, 1);
      m.addColorStop(0, rgba(P.sarcelle, 0.02)); m.addColorStop(0.7, rgba(P.sarcelle, 0.09)); m.addColorStop(0.93, rgba(P.aqua, 0.12)); m.addColorStop(1, rgba(P.perle, 0.05));
      return { cell: c, mem: m };
    });
    const R0 = 38, REPOS = 2 * R0 * Math.sin(Math.PI / K);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;
    const lisse = u => u * u * (3 - 2 * u);
    const groupe = i => (i < K / 2 ? 0 : 1);

    // Membrane : courbe fermée lissée passant au large des cellules [i0, i0+n)
    function cheminMembrane(ctx, i0, n, cx, cy, marge) {
      for (let k = 0; k < n; k++) {
        const i = (i0 + k) % K; let dx = px[i] - cx, dy = py[i] - cy; const l = 1 / (Math.hypot(dx, dy) || 1);
        ox[k] = px[i] + dx * l * marge; oy[k] = py[i] + dy * l * marge;
      }
      ctx.moveTo((ox[n - 1] + ox[0]) / 2, (oy[n - 1] + oy[0]) / 2);
      for (let k = 0; k < n; k++) { const k2 = (k + 1) % n; ctx.quadraticCurveTo(ox[k], oy[k], (ox[k] + ox[k2]) / 2, (oy[k] + oy[k2]) / 2); }
    }
    // Filament enroulé en pelote lâche (spirale qui respire) — le flagelle de la colonie au repos
    function trefle(ctx, cx, cy, rot, sc) {
      for (let k = 0; k <= NK; k++) {
        const u = k / NK, q = u * TAU * 2.6 + rot, r = sc * (2 + 11 * u + 1.6 * Math.sin(u * 23 + rot * 1.7));
        const x = cx + Math.cos(q) * r, y = cy + Math.sin(q) * r * 0.82;
        k ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xc0e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.68 : 0.32);
        s = { hx, hy, cx: hx + (r() - 0.5) * 40, cy: hy + (r() - 0.5) * 40, vx: 0, vy: 0, hd: r() * TAU, angv: 0, ph: r() * TAU, rot: 0, wav: 0,
          sig: 0, etat: 0, tEtat: 3 + r() * 9, lobe: 0, bouche: 0, serre: 0, exc: 0, gobe: 0, cph: 0, pa: 0, rotv: 0.15,
          lueur: lueurNeuve(r), g: 0, tx: 0, ty: 0, cell: [] };
        for (let i = 0; i < K; i++) {
          const q = s.hd + i / K * TAU;
          px[i] = s.cx + Math.cos(q) * R0; py[i] = s.cy + Math.sin(q) * R0; vx[i] = vy[i] = 0; oa[i] = q;
          s.cell.push({ ph: r() * TAU, vac: 0.3 + r() * 0.4, ambre: r() < 0.25, nx: (r() - 0.5) * 0.5, rr: 0.9 + r() * 0.2, k: 0.82 + r() * 0.34 });
        }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.cx, s.cy]; },
      place(i, x, y) { s.cx = x; s.cy = y; },
      vise(i, tx_, ty_, g) { s.tx = tx_; s.ty = ty_; s.g = g; },
      geo() { return [{ k: 'disque', x: s.cx, y: s.cy, r: R0 + 10 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.cx, s.cy, 180);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        if (RG.part && RG.part.on) s.pa = Math.atan2(RG.part.y - s.cy, RG.part.x - s.cx);
        // Réponse : pseudopode vers la particule, bouche qui s'ouvre, boule serrée, anneau qui tourne
        let lobe = 0, bouche = 0, serre = 0, rotv = 0.15 + 0.1 * energy;
        if (e > 0.01) {
          if (md === 'cont') lobe = 0.9 * e;
          else if (md === 'suit') lobe = 0.55 * e;
          else if (md === 'actif') { lobe = 0.6 * e * (0.5 + 0.5 * Math.sin(t * 2.1)); rotv += 1.4 * e; }
          else if (md === 'agr') { bouche = borne((e - 0.25) * 1.6, 0, 1); lobe = 0.3 * e; }
          else if (md === 'evite') { serre = 0.75 * e; rotv += 2.2 * e; }
          else { lobe = 0.4 * e; rotv += 0.9 * e; }
        }
        if (s.gobe > 0) { bouche *= 1 - s.gobe; serre = Math.max(serre, 0.35 * s.gobe); }
        s.lobe += (lobe - s.lobe) * Math.min(1, h * 2);
        s.bouche += (bouche - s.bouche) * Math.min(1, h * 3);
        s.serre += (serre - s.serre) * Math.min(1, h * 2.5);
        s.rotv += (rotv - s.rotv) * Math.min(1, h);
        s.rot += s.rotv * h;
        // Division / refusion (suspendue quand la particule capte l'attention)
        s.tEtat -= h * (e > 0.35 ? 0 : 1);
        if (s.etat === 0 && s.tEtat <= 0) { s.etat = 1; s.tEtat = 2.6; }
        else if (s.etat === 1) { s.sig = Math.min(1, s.sig + h / 2.6); if (s.tEtat <= 0) { s.etat = 2; s.tEtat = 3.2; } }
        else if (s.etat === 2 && s.tEtat <= 0) { s.etat = 3; s.tEtat = 3.4; }
        else if (s.etat === 3) { s.sig = Math.max(0, s.sig - h / 3.4); if (s.sig <= 0) { s.etat = 0; s.tEtat = 9 + 4 * Math.sin(t + s.ph) ** 2; } }
        if (e > 0.35 && s.etat !== 0) { s.etat = 3; }
        // Pilotage du centre : la colonie rame (vitesse modulée par l'onde)
        s.wav += h * (2.2 + 2 * energy + 2.5 * e) * (0.6 + 0.4 * RG.vit);
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.ty - s.cy, s.tx - s.cx) - s.hd);
        else { const ecX = s.hx - s.cx, ecY = s.hy - s.cy, loin = Math.min(1, Math.hypot(ecX, ecY) / 170); d = 0.5 * Math.sin(t * 0.17 + s.ph) + enrouleAngle(Math.atan2(ecY, ecX) - s.hd) * loin * loin; }
        s.angv += (borne(d, -1.2, 1.2) * (s.g ? 1.3 * s.g : 0.5) - s.angv) * Math.min(1, h * 2);
        s.hd += s.angv * h;
        const rame = 0.55 + 0.45 * Math.max(0, Math.sin(s.wav * 2)), vit = (5 + 9 * energy + (s.g ? 7 * s.g : 0)) * RG.vit * rame * (1 - 0.4 * s.serre * (md === 'evite' ? -1 : 1));
        s.vx += (Math.cos(s.hd) * vit - s.vx) * Math.min(1, h * 2); s.vy += (Math.sin(s.hd) * vit - s.vy) * Math.min(1, h * 2);
        const fl = flow(s.cx, s.cy);
        const ncx = s.cx + (s.vx + fl[0] * 0.35) * h, ncy = s.cy + (s.vy + fl[1] * 0.35) * h;
        s.cx = enroule(ncx, 0, W, 80); s.cy = enroule(ncy, 0, H, 80);
        const jx = s.cx - ncx, jy = s.cy - ncy;
        if (jx || jy) for (let i = 0; i < K; i++) { px[i] += jx; py[i] += jy; }
        // Cibles de chaque cellule (anneau uni ↔ deux demi-colonies)
        const ss = lisse(s.sig), base = s.hd + s.rot;
        for (let i = 0; i < K; i++) {
          let q = base + i / K * TAU;
          let r = R0 * s.cell[i].rr * (1 + 0.16 * Math.sin(s.wav - i / K * TAU) + 0.07 * Math.sin(t * 0.43 + i * 1.9 + s.ph)) * (1 + 0.16 * Math.cos(q - s.hd) - 0.06 * Math.cos(2 * (q - s.hd))) * (1 - 0.36 * s.serre);
          if (s.lobe > 0.001 || s.bouche > 0.001) {
            const dq = enrouleAngle(q - s.pa);
            r += s.lobe * 26 * cloche(dq, 0.55) + s.bouche * 9 * cloche(dq, 1.1);
            q += s.bouche * 0.8 * Math.sign(dq) * cloche(dq, 1.2);
          }
          let fx = s.cx + Math.cos(q) * r, fy = s.cy + Math.sin(q) * r;
          if (ss > 0.001) {
            const gi = groupe(i), j = i % HK, mg = base + (gi * HK + (HK - 1) / 2) / K * TAU;
            const scx = s.cx + Math.cos(mg) * (8 + ss * 30), scy = s.cy + Math.sin(mg) * (8 + ss * 30);
            const qa = mg + (j - (HK - 1) / 2) * (TAU / HK) * (0.9 + 0.1 * Math.sin(s.wav * 0.5)), rr = 22 * (1 + 0.1 * Math.sin(s.wav - j));
            fx += (scx + Math.cos(qa) * rr - fx) * ss; fy += (scy + Math.sin(qa) * rr - fy) * ss;
          }
          tx[i] = fx; ty[i] = fy;
        }
        // Dynamique : ressort amorti vers la cible (dépassement = gelée), répulsion de contact
        const n = Math.ceil(h * 120), hh = h / n;
        for (let st = 0; st < n; st++) {
          for (let i = 0; i < K; i++) {
            vx[i] += ((tx[i] - px[i]) * 34 - vx[i] * 6.2) * hh; vy[i] += ((ty[i] - py[i]) * 34 - vy[i] * 6.2) * hh;
          }
          for (let i = 0; i < K; i++) for (let j = i + 1; j < K; j++) {
            const dx = px[j] - px[i], dy = py[j] - py[i], d2 = dx * dx + dy * dy;
            if (d2 < 196 && d2 > 0.01) { const d1 = Math.sqrt(d2), f = (14 - d1) * 30 * hh / d1; vx[i] -= dx * f; vy[i] -= dy * f; vx[j] += dx * f; vy[j] += dy * f; }
          }
          for (let i = 0; i < K; i++) { px[i] += vx[i] * hh; py[i] += vy[i] * hh; }
        }
        // Orientation des cellules : vers l'extérieur de leur groupe, avec retard (inertie)
        for (let i = 0; i < K; i++) {
          const gi = groupe(i);
          let gx = 0, gy = 0;
          if (ss > 0.001) { for (let k = gi * HK; k < gi * HK + HK; k++) { gx += px[k]; gy += py[k]; } gx = s.cx + (gx / HK - s.cx) * ss; gy = s.cy + (gy / HK - s.cy) * ss; }
          else { gx = s.cx; gy = s.cy; }
          const cible = Math.atan2(py[i] - gy, px[i] - gx) + Math.PI / 2 + 0.3 * Math.sin(t * 0.9 + s.cell[i].ph);
          oa[i] += enrouleAngle(cible - oa[i]) * Math.min(1, h * 3);
        }
        s.cph += h * (7 + 6 * energy + 12 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.7; if (A <= 0.001) return;
        const ss = lisse(s.sig), G = degr(ctx);
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // Centres des deux groupes (confondus quand la colonie est unie)
        let g0x = 0, g0y = 0, g1x = 0, g1y = 0;
        for (let i = 0; i < HK; i++) { g0x += px[i]; g0y += py[i]; g1x += px[i + HK]; g1y += py[i + HK]; }
        g0x = s.cx + (g0x / HK - s.cx) * ss; g0y = s.cy + (g0y / HK - s.cy) * ss; g1x = s.cx + (g1x / HK - s.cx) * ss; g1y = s.cy + (g1y / HK - s.cy) * ss;
        // 1. Membrane commune (ou deux membranes pendant la division)
        let rm = 0; for (let i = 0; i < K; i++) rm += Math.hypot(px[i] - s.cx, py[i] - s.cy); rm = rm / K + 12;
        const membrane = (i0, n, cx, cy, rmoy, Am) => {
          if (Am < 0.01) return;
          ctx.beginPath(); cheminMembrane(ctx, i0, n, cx, cy, 11);
          ctx.save(); ctx.translate(cx, cy); ctx.scale(rmoy, rmoy); ctx.fillStyle = G.mem; ctx.globalAlpha = Am; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Am * 0.06; ctx.lineWidth = 6; ctx.stroke();
          ctx.globalAlpha = Am * 0.4; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath(); cheminMembrane(ctx, i0, n, cx, cy, 6.5); ctx.globalAlpha = Am * 0.1; ctx.lineWidth = 1.3; ctx.stroke();
        };
        membrane(0, K, s.cx, s.cy, rm, A * (1 - ss));
        if (ss > 0.01) { membrane(0, HK, g0x, g0y, 34, A * ss); membrane(HK, HK, g1x, g1y, 34, A * ss); }
        // Froissement : plis courts là où la membrane est comprimée
        ctx.beginPath();
        for (let i = 0; i < K; i++) {
          const j = (i + 1) % K; if (ss > 0.4 && groupe(i) !== groupe(j)) continue;
          const d = Math.hypot(px[j] - px[i], py[j] - py[i]), comp = borne((REPOS * 0.98 - d) / (REPOS * 0.35), 0, 1);
          if (comp < 0.08) continue;
          const mx = (px[i] + px[j]) / 2, my = (py[i] + py[j]) / 2; let dx = mx - s.cx, dy = my - s.cy; const l = 1 / (Math.hypot(dx, dy) || 1); dx *= l; dy *= l;
          for (let k = -1; k <= 1; k++) { const ox2 = mx + dx * 9 - dy * k * 3.2, oy2 = my + dy * 9 + dx * k * 3.2, L = (2 + 2.5 * comp) * (k ? 0.7 : 1); ctx.moveTo(ox2, oy2); ctx.lineTo(ox2 - dx * L, oy2 - dy * L); }
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // 2. Rayons fins des cellules vers leur cœur
        ctx.beginPath();
        for (let i = 0; i < K; i++) {
          const cx = groupe(i) ? g1x : g0x, cy = groupe(i) ? g1y : g0y, mx = (px[i] + cx) / 2, my = (py[i] + cy) / 2, cu = 4 * Math.sin(t * 0.8 + i);
          ctx.moveTo(px[i], py[i]); ctx.quadraticCurveTo(mx - (py[i] - cy) * cu / 30, my + (px[i] - cx) * cu / 30, cx, cy);
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.45; ctx.stroke();
        // 3. Fils entre voisines : les mous pendent vers le centre, les tendus vibrent ; ceux qui
        //    relient les deux moitiés cassent à la division et sont relancés à la refusion
        ctx.beginPath(); let np = 0;
        for (let i = 0; i < K; i++) {
          let j = (i + 1) % K; const coupe = groupe(i) !== groupe(j);
          let fr = 1; if (coupe) { fr = borne(1 - ss * 1.9, 0, 1); if (fr <= 0.02) { j = groupe(i) * HK; fr = borne((ss - 0.5) * 2.2, 0, 1); } }
          if (fr <= 0.02) continue;
          const dx = px[j] - px[i], dy = py[j] - py[i], d = Math.hypot(dx, dy) || 1;
          let nx = -dy / d, ny = dx / d; const mx0 = (px[i] + px[j]) / 2, my0 = (py[i] + py[j]) / 2;
          if ((s.cx - mx0) * nx + (s.cy - my0) * ny < 0) { nx = -nx; ny = -ny; }
          const mou = Math.max(0, REPOS - d), tendu = Math.max(0, d - REPOS) / REPOS;
          const sag = mou * 0.6 + tendu * 3.5 * Math.sin(t * 41 + i * 2) + (coupe ? (1 - fr) * 6 : 0);
          const ex = px[i] + dx * fr, ey = py[i] + dy * fr;
          const cxq = px[i] + dx * fr * 0.5 + nx * sag * fr, cyq = py[i] + dy * fr * 0.5 + ny * sag * fr;
          ctx.moveTo(px[i], py[i]); ctx.quadraticCurveTo(cxq, cyq, ex, ey);
          if (fr > 0.99) { perle[np++] = 0.25 * px[i] + 0.5 * cxq + 0.25 * ex; perle[np++] = 0.25 * py[i] + 0.5 * cyq + 0.25 * ey; }
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 3; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.65; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < np; k += 2) { ctx.moveTo(perle[k] + 1.2, perle[k + 1]); ctx.arc(perle[k], perle[k + 1], 1.2, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.fill();
        // 4. Cœur : deux trèfles de filament enlacés, qui se séparent avec la colonie
        ctx.beginPath(); trefle(ctx, g0x, g0y, t * 0.5 + s.ph, 1 - 0.2 * ss); trefle(ctx, g1x, g1y, -t * 0.5 + s.ph + 1, 1 - 0.2 * ss);
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 3.5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.36; ctx.lineWidth = 0.6; ctx.stroke();
        // 5. Cellules (mini-Cellules : corps à dégradé, double membrane, cils métachronaux)
        for (let i = 0; i < K; i++) {
          const kc = s.cell[i].k; ctx.save(); ctx.translate(px[i], py[i]); ctx.rotate(oa[i]); ctx.scale(CA * kc, CB * kc);
          ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fillStyle = G.cell; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        }
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const kc = s.cell[i].k; ctx.moveTo(px[i] + Math.cos(oa[i]) * CA * kc, py[i] + Math.sin(oa[i]) * CA * kc); ctx.ellipse(px[i], py[i], CA * kc, CB * kc, oa[i], 0, TAU); }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.8; ctx.stroke();
        // Cils : plus longs et plus rapides du côté qui rame (arrière de la colonie)
        ctx.beginPath();
        const hx = Math.cos(s.hd), hy = Math.sin(s.hd);
        for (let i = 0; i < K; i++) {
          const ca = Math.cos(oa[i]), sa = Math.sin(oa[i]);
          const rameur = 0.5 + 0.5 * borne(-((px[i] - s.cx) * hx + (py[i] - s.cy) * hy) / R0, -1, 1);
          for (let k = 0; k < NCIL; k++) {
            const q = k / NCIL * TAU, kc = s.cell[i].k, lx = CA * kc * Math.cos(q), ly = CB * kc * Math.sin(q);
            let nx = CB * Math.cos(q), ny = CA * Math.sin(q); const nl = 1 / Math.hypot(nx, ny); nx *= nl; ny *= nl;
            const ph = s.cph * (1 + 0.6 * rameur) + s.cell[i].ph - k * 0.6, L = (1.8 + 1.1 * Math.sin(ph)) * (1 + 0.6 * rameur + 0.4 * s.exc), pl = 0.9 * Math.cos(ph);
            const ax = lx + nx * 0.6, ay = ly + ny * 0.6, bx = lx + nx * (0.6 + L) - ny * pl, by = ly + ny * (0.6 + L) + nx * pl;
            ctx.moveTo(px[i] + ax * ca - ay * sa, py[i] + ax * sa + ay * ca); ctx.lineTo(px[i] + bx * ca - by * sa, py[i] + bx * sa + by * ca);
          }
        }
        ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.45; ctx.stroke();
        // Noyaux et vacuoles
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const c = s.cell[i], x = px[i] + Math.cos(oa[i]) * CA * c.nx, y = py[i] + Math.sin(oa[i]) * CA * c.nx; ctx.moveTo(x + 2.2, y); ctx.arc(x, y, 2.2, 0, TAU); }
        ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.12; ctx.fill(); ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.5; ctx.stroke();
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const c = s.cell[i], rr = 1.3 * (1 + 0.15 * Math.sin(t * 1.7 + c.ph)), x = px[i] - Math.cos(oa[i]) * CA * c.vac, y = py[i] - Math.sin(oa[i]) * CA * c.vac; ctx.moveTo(x + rr, y); ctx.arc(x, y, rr, 0, TAU); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.4; ctx.fill(); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.6; ctx.stroke();
        // 6. Lumières : l'impulsion fait le tour de l'anneau, de cellule en cellule
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const tete = s.lueur.pos * K * 1.25;
          ctx.fillStyle = ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < K; i++) {
            const li = I * cloche(i - tete, i < tete ? 2 : 0.8); if (li < 0.004) continue;
            ctx.beginPath(); ctx.ellipse(px[i], py[i], CA + 1, CB + 1, oa[i], 0, TAU);
            ctx.globalAlpha = li * 0.18; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.8; ctx.lineWidth = 0.9; ctx.stroke();
            const j = (i + 1) % K; if (ss > 0.4 && groupe(i) !== groupe(j)) continue; ctx.beginPath(); ctx.moveTo(px[i], py[i]); ctx.lineTo(px[j], py[j]); ctx.globalAlpha = li * 0.35; ctx.lineWidth = 0.8; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.cx, s.cy, 6 + 22 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.16 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(s.cx, s.cy, 1.5 + 3 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); trefle(ctx, s.cx, s.cy, t * 0.5 + s.ph, 1); ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.5 * s.gobe; ctx.lineWidth = 0.8; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }


  /* =====================================================================
     DÉCOR VIVANT — poils, antennes, voiles translucides (greffés sur geo())
     Chaque poil est une chaîne à inertie : l'ancre bouge, le reste suit en retard et flotte.
     ===================================================================== */
  function creerDecor() {
    const P = palette;
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), lueur: rgb(P.lueur), ambre: rgb(P.ambre) };
    let t = 0; const etat = {};
    const nouveauPoil = (n, L, ph, bille) => ({ x: new Float32Array(n), y: new Float32Array(n), n, L, ph, bille, ok: false });
    function majPoil(h, ax, ay, ang, dt, flow, bend, raideur) {
      const n = h.n;
      if (!h.ok) { for (let i = 0; i < n; i++) { h.x[i] = ax + Math.cos(ang) * h.L * i; h.y[i] = ay + Math.sin(ang) * h.L * i; } h.ok = true; }
      h.x[0] = ax; h.y[0] = ay;
      for (let i = 1; i < n; i++) {
        const s = i / (n - 1), a = ang + bend * Math.sin(t * 1.3 + h.ph + i * 0.7) * s;
        const tx = h.x[i - 1] + Math.cos(a) * h.L, ty = h.y[i - 1] + Math.sin(a) * h.L;
        const f = flow(h.x[i], h.y[i]), k = Math.min(1, dt * raideur * (1.25 - 0.8 * s));
        h.x[i] += (tx - h.x[i]) * k + f[0] * 0.14 * s * dt; h.y[i] += (ty - h.y[i]) * k + f[1] * 0.14 * s * dt;
        const ex = h.x[i] - h.x[i - 1], ey = h.y[i] - h.y[i - 1], l = Math.hypot(ex, ey) || 1;
        h.x[i] = h.x[i - 1] + ex / l * h.L; h.y[i] = h.y[i - 1] + ey / l * h.L;
      }
    }
    function tracePoil(ctx, h, A) {
      const n = h.n, x0 = h.x[0], y0 = h.y[0], x1 = h.x[n - 1], y1 = h.y[n - 1];
      // Effilement sans dégradé : moitié proximale nacrée, moitié distale aqua plus pâle
      const mid = n >> 1;
      ctx.beginPath(); ctx.moveTo(x0, y0);
      for (let i = 1; i <= mid; i++) ctx.lineTo(h.x[i], h.y[i]);
      ctx.globalAlpha = A * 0.55; ctx.strokeStyle = coul.perle; ctx.lineWidth = h.bille ? 0.8 : 0.55; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(h.x[mid], h.y[mid]);
      for (let i = mid + 1; i < n - 1; i++) ctx.quadraticCurveTo(h.x[i], h.y[i], (h.x[i] + h.x[i + 1]) / 2, (h.y[i] + h.y[i + 1]) / 2);
      ctx.lineTo(x1, y1);
      ctx.globalAlpha = A * 0.2; ctx.strokeStyle = coul.aqua; ctx.lineWidth = h.bille ? 0.7 : 0.45; ctx.stroke();
      if (h.bille) {
        ctx.fillStyle = coul.lueur; ctx.globalAlpha = A * 0.12; ctx.beginPath(); ctx.arc(x1, y1, h.bille * 3, 0, TAU); ctx.fill();
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.7; ctx.beginPath(); ctx.arc(x1, y1, h.bille, 0, TAU); ctx.fill();
      }
    }
    function majVoile(vo, n, bx, by, ox, oy, dt, k) {
      if (!vo.x || vo.x.length !== n) { vo.x = Float32Array.from(ox); vo.y = Float32Array.from(oy); }
      const kk = Math.min(1, dt * k);
      for (let i = 0; i < n; i++) { vo.x[i] += (ox[i] - vo.x[i]) * kk; vo.y[i] += (oy[i] - vo.y[i]) * kk; }
    }
    function traceVoile(ctx, vo, n, bx, by, A) {
      ctx.beginPath(); ctx.moveTo(bx[0], by[0]);
      for (let i = 1; i < n; i++) ctx.lineTo(bx[i], by[i]);
      for (let i = n - 1; i >= 0; i--) ctx.lineTo(vo.x[i], vo.y[i]);
      ctx.closePath(); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.075; ctx.fill();
      ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.03; ctx.fill();
      ctx.beginPath(); ctx.moveTo(vo.x[0], vo.y[0]); for (let i = 1; i < n; i++) ctx.lineTo(vo.x[i], vo.y[i]);
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.beginPath(); for (let i = 1; i < n - 1; i += 2) { ctx.moveTo(bx[i], by[i]); ctx.lineTo(vo.x[i], vo.y[i]); }
      ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.4; ctx.stroke();
    }
    function st(cle, f) { return etat[cle] || (etat[cle] = f()); }

    // Cellule : couronne de poils, deux antennes à perle, longs fouets arrière, jupe translucide
    function majCell(g, id, dt, flow) {
      const S = st('c' + id, () => ({ h: [], vo: {}, bx: new Float32Array(9), by: new Float32Array(9), ox: new Float32Array(9), oy: new Float32Array(9) }));
      if (!S.h.length) {
        for (let j = 0; j < 12; j++) S.h.push({ q: (j / 12) * TAU + 0.2, p: nouveauPoil(5, 3.2 + (j % 3) * 0.8, j * 1.7, 0) });
        S.h.push({ q: -0.38, p: nouveauPoil(6, 5, 0.3, 1.2), ant: 1 }, { q: 0.38, p: nouveauPoil(6, 5, 2.1, 1.2), ant: 1 });
        S.h.push({ q: Math.PI - 0.22, p: nouveauPoil(7, 6, 1, 0), fouet: 1 }, { q: Math.PI + 0.22, p: nouveauPoil(7, 6, 4, 0), fouet: 1 });
      }
      const ca = Math.cos(g.ang), sa = Math.sin(g.ang);
      for (const o of S.h) {
        const lx = g.a * Math.cos(o.q), ly = g.b * Math.sin(o.q), nxl = g.b * Math.cos(o.q), nyl = g.a * Math.sin(o.q);
        const ang = g.ang + Math.atan2(nyl, nxl);
        majPoil(o.p, g.x + lx * ca - ly * sa, g.y + lx * sa + ly * ca, o.fouet ? g.ang + Math.PI + (o.q > Math.PI ? 0.25 : -0.25) : ang, dt, flow, o.ant ? 0.9 : o.fouet ? 0.7 : 0.5, o.fouet ? 3 : 4.5);
      }
      for (let i = 0; i < 9; i++) {
        const q = Math.PI * (0.62 + 0.76 * i / 8), lx = g.a * Math.cos(q), ly = g.b * Math.sin(q);
        S.bx[i] = g.x + lx * ca - ly * sa; S.by[i] = g.y + lx * sa + ly * ca;
        const nxl = g.b * Math.cos(q), nyl = g.a * Math.sin(q), la = g.ang + Math.atan2(nyl, nxl), d = 13 + 6 * Math.sin(t * 1.5 + i * 0.8);
        S.ox[i] = S.bx[i] + Math.cos(la) * d - ca * 8; S.oy[i] = S.by[i] + Math.sin(la) * d - sa * 8;
      }
      majVoile(S.vo, 9, S.bx, S.by, S.ox, S.oy, dt, 2.2);
      S.g = g;
    }
    function traceCell(ctx, id, A) {
      const S = etat['c' + id]; if (!S) return;
      traceVoile(ctx, S.vo, 9, S.bx, S.by, A);
      for (const o of S.h) tracePoil(ctx, o.p, A * (o.fouet ? 1 : 0.8));
    }
    // Corps en chaîne : antennes de tête, fouets de queue, poils de flanc, voile latéral
    function majChaine(g, id, dt, flow) {
      const N = g.N, p = g.p, e = g.e || 1;
      const S = st('k' + id, () => ({ a: [], q: [], f: [], vo: [{}, {}], bx: [new Float32Array(N), new Float32Array(N)], by: [new Float32Array(N), new Float32Array(N)], ox: [new Float32Array(N), new Float32Array(N)], oy: [new Float32Array(N), new Float32Array(N)] }));
      if (!S.a.length) {
        if (p.ant) for (let s = 0; s < 2; s++) S.a.push(nouveauPoil(7, p.ant / 6, s * 2.3, 1.3));
        for (let s = 0; s < (p.queue || 0); s++) S.q.push(nouveauPoil(8, 4.5, s * 3.1, 0));
        if (p.flancs) for (let i = 6; i < N - 4; i += p.flancs) for (let s = 0; s < 2; s++) S.f.push({ i, s: s ? 1 : -1, p: nouveauPoil(4, 3.4, i + s * 5, 0) });
      }
      const px = g.px, py = g.py, nxs = [], nys = [];
      for (let i = 0; i < N; i++) { const a = Math.max(0, i - 1), b = Math.min(N - 1, i + 1); let tx = px[a] - px[b], ty = py[a] - py[b]; const l = 1 / (Math.hypot(tx, ty) || 1); nxs[i] = -ty * l; nys[i] = tx * l; }
      const hang = Math.atan2(py[0] - py[2], px[0] - px[2]);
      S.a.forEach((h, s) => majPoil(h, px[1] + nxs[1] * (s ? 1 : -1) * 2, py[1] + nys[1] * (s ? 1 : -1) * 2, hang + (s ? 0.55 : -0.55), dt, flow, 0.7, 3.4));
      const tang = Math.atan2(py[N - 1] - py[N - 3], px[N - 1] - px[N - 3]);
      S.q.forEach((h, s) => majPoil(h, px[N - 1], py[N - 1], tang + (s ? 0.35 : -0.35), dt, flow, 0.8, 2.6));
      for (const o of S.f) majPoil(o.p, px[o.i] + nxs[o.i] * o.s * g.lg[o.i] * e, py[o.i] + nys[o.i] * o.s * g.lg[o.i] * e, Math.atan2(nys[o.i] * o.s, nxs[o.i] * o.s) + o.s * 0.9, dt, flow, 0.6, 4);
      if (p.voile) for (let s = 0; s < 2; s++) {
        const sg = s ? 1 : -1, v = S.vo[s];
        for (let i = 0; i < N; i++) {
          const w = g.lg[i] * e, k = i / (N - 1);
          S.bx[s][i] = px[i] + nxs[i] * sg * w; S.by[s][i] = py[i] + nys[i] * sg * w;
          const d = p.voile * Math.sin(Math.PI * Math.min(1, k * 1.15)) * (0.6 + 0.4 * Math.sin(t * 1.7 - i * 0.5 + s * 2)) + 1;
          S.ox[s][i] = S.bx[s][i] + nxs[i] * sg * d; S.oy[s][i] = S.by[s][i] + nys[i] * sg * d;
        }
        majVoile(v, N, S.bx[s], S.by[s], S.ox[s], S.oy[s], dt, 3);
      }
    }
    function traceChaine(ctx, g, id, A) {
      const S = etat['k' + id]; if (!S) return;
      if (g.p.voile) for (let s = 0; s < 2; s++) traceVoile(ctx, S.vo[s], g.N, S.bx[s], S.by[s], A);
      for (const h of S.q) tracePoil(ctx, h, A); for (const o of S.f) tracePoil(ctx, o.p, A * 0.8); for (const h of S.a) tracePoil(ctx, h, A * 1.1);
    }
    return {
      update(dt, flow, geos) { t += dt; geos.forEach((g, i) => { if (g.k === 'cell') majCell(g, i, dt, flow); else if (g.k === 'chaine') majChaine(g, i, dt, flow); }); },
      draw(ctx, geos, alpha) { ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; const A = alpha * 0.62; geos.forEach((g, i) => { if (g.k === 'cell') traceCell(ctx, i, A); else if (g.k === 'chaine') traceChaine(ctx, g, i, A); }); ctx.restore(); },
      reset() { for (const k in etat) delete etat[k]; },
      // Décale tous les points mémorisés (utile quand le motif hôte est téléporté ou s'enroule)
      decale(dx, dy) {
        const sh = h => { if (h && h.x && h.y) for (let i = 0; i < h.x.length; i++) { h.x[i] += dx; h.y[i] += dy; } };
        for (const k in etat) { const S = etat[k];
          if (S.h) S.h.forEach(o => sh(o.p)); if (S.a) S.a.forEach(sh); if (S.q) S.q.forEach(sh); if (S.f) S.f.forEach(o => sh(o.p));
          if (S.vo) { if (Array.isArray(S.vo)) S.vo.forEach(sh); else sh(S.vo); } }
      }
    };
  }

  /* =====================================================================
     ÉTAGE 3 — outils partagés : corps rigide (équations d'Euler) et enveloppe convexe
     ===================================================================== */
  function corpsRigide(I1, I2, I3) {
    const R = new Float64Array(9), w = new Float64Array(3), tau = new Float64Array(3), pj = new Float64Array(3);
    const o = {
      R, w, tau, pj,
      init(a0, b0) {
        const c = Math.cos(a0), sn = Math.sin(a0), cb = Math.cos(b0), sb = Math.sin(b0);
        R[0] = c; R[1] = -sn * cb; R[2] = sn * sb; R[3] = sn; R[4] = c * cb; R[5] = -c * sb; R[6] = 0; R[7] = sb; R[8] = cb;
      },
      proj(x, y, z) { pj[0] = R[0] * x + R[1] * y + R[2] * z; pj[1] = R[3] * x + R[4] * y + R[5] * z; pj[2] = R[6] * x + R[7] * y + R[8] * z; },
      pas(h) {
        const w1 = w[0], w2 = w[1], w3 = w[2];
        w[0] += ((I2 - I3) * w2 * w3 + tau[0]) / I1 * h;
        w[1] += ((I3 - I1) * w3 * w1 + tau[1]) / I2 * h;
        w[2] += ((I1 - I2) * w1 * w2 + tau[2]) / I3 * h;
        for (let r = 0; r < 9; r += 3) {
          const a = R[r], b = R[r + 1], c = R[r + 2];
          R[r] = a + h * (b * w[2] - c * w[1]); R[r + 1] = b + h * (c * w[0] - a * w[2]); R[r + 2] = c + h * (a * w[1] - b * w[0]);
        }
      },
      orth() {
        let l = 1 / Math.hypot(R[0], R[3], R[6]); R[0] *= l; R[3] *= l; R[6] *= l;
        const d = R[0] * R[1] + R[3] * R[4] + R[6] * R[7]; R[1] -= d * R[0]; R[4] -= d * R[3]; R[7] -= d * R[6];
        l = 1 / Math.hypot(R[1], R[4], R[7]); R[1] *= l; R[4] *= l; R[7] *= l;
        R[2] = R[3] * R[7] - R[6] * R[4]; R[5] = R[6] * R[1] - R[0] * R[7]; R[8] = R[0] * R[4] - R[3] * R[1];
      },
      // Couple qui aligne l'axe propre n° col sur la direction monde (dx,dy,dz) ; amortit les deux autres rotations
      viser(col, dx, dy, dz, kA, kD) {
        const ex = R[col], ey = R[3 + col], ez = R[6 + col];
        const tx = ey * dz - ez * dy, ty = ez * dx - ex * dz, tz = ex * dy - ey * dx;
        for (let k = 0; k < 3; k++) tau[k] += kA * (R[k] * tx + R[3 + k] * ty + R[6 + k] * tz) - (k === col ? 0 : kD * w[k]);
      },
      // Moteur ciliaire : ramène |ω| vers spin, petite perturbation déterministe
      moteur(spin, kick, t, ph) {
        const wm = Math.hypot(w[0], w[1], w[2]) || 1, ks = 1.4 * (spin - wm) / wm;
        tau[0] += ks * w[0] * I1 + kick * Math.sin(t * 1.7 + ph) * I1;
        tau[1] += ks * w[1] * I2;
        tau[2] += ks * w[2] * I3 + kick * Math.cos(t * 1.1 + ph) * I3;
      },
      avancer(h) { const n = Math.ceil(h * 240), hh = h / n; for (let k = 0; k < n; k++) o.pas(hh); o.orth(); }
    };
    return o;
  }
  // Enveloppe convexe (chaîne monotone d'Andrew) de n points (X,Y) ; écrit les indices dans out, renvoie leur nombre
  function enveloppeConvexe(X, Y, n, idx, out) {
    for (let i = 0; i < n; i++) idx[i] = i;
    const ix = Array.prototype.slice.call(idx, 0, n).sort((a, b) => X[a] - X[b] || Y[a] - Y[b]);
    let k = 0;
    const croix = (o, a, b) => (X[a] - X[o]) * (Y[b] - Y[o]) - (Y[a] - Y[o]) * (X[b] - X[o]);
    for (let i = 0; i < n; i++) { while (k >= 2 && croix(out[k - 2], out[k - 1], ix[i]) <= 0) k--; out[k++] = ix[i]; }
    for (let i = n - 2, b = k + 1; i >= 0; i--) { while (k >= b && croix(out[k - 2], out[k - 1], ix[i]) <= 0) k--; out[k++] = ix[i]; }
    return k - 1;
  }
  const melange = (a, b, k) => a + (b - a) * k;
  const lisseP = u => u * u * (3 - 2 * u);

  /* =====================================================================
     6. CORTÈGE — colonie-siphon (étage 3 : Systole × Chœur ; greffe : col harponneur 28007)
     Une tige (le fil du Chœur) porte en tête un flotteur, puis six petites cloches de Systole
     en fermeture éclair, puis trois polypes pêcheurs à long tentacule. Les cloches sont des
     oscillateurs couplés (Kuramoto) : elles se synchronisent en onde métachronale qui court
     de l'avant vers l'arrière ; le décalage visé change selon l'intention (onde lente = glisse,
     salve synchrone = bond, alternance = galop). Elle braque en pompant plus fort d'un côté.
     ===================================================================== */
  function creerCortege() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NB = 6, NS = 34, NC = 3, NTP = 16, NBS = 9, NR = 10, SEG = 4.2;
    const ATT = [2, 4, 6, 8, 10, 12], CORM = [17, 24, 31];
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(0.35, -0.2, 0, 0.05, 0, 1.05);
      g.addColorStop(0, rgba(P.perle, 0.14)); g.addColorStop(0.5, rgba(P.sarcelle, 0.18));
      g.addColorStop(0.84, rgba(P.aqua, 0.22)); g.addColorStop(1, rgba(P.perle, 0.34));
      const f = ctx.createRadialGradient(-0.3, -0.35, 0, 0, 0, 1);
      f.addColorStop(0, rgba(P.perle, 0.32)); f.addColorStop(0.45, rgba(P.aqua, 0.16)); f.addColorStop(0.9, rgba(P.sarcelle, 0.18)); f.addColorStop(1, rgba(P.perle, 0.3));
      return { cloche: g, flot: f };
    });
    const contraction = f => f < 0.26 ? 0.5 - 0.5 * Math.cos(Math.PI * f / 0.26) : 0.5 + 0.5 * Math.cos(Math.PI * (f - 0.26) / 0.74);
    const bx = new Float32Array(NBS), bw = new Float32Array(NBS), dph = new Float32Array(NB);
    const nxs = new Float32Array(NS), nys = new Float32Array(NS);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    // Profil d'une cloche (repère local, apex en +x) : rapide, sans courbure
    function profil(a, b, ro, c, ph) {
      for (let i = 0; i < NBS; i++) {
        const q = i / (NBS - 1);
        bx[i] = a * (1 - 1.86 * q);
        let w = q < 0.55 ? b * Math.pow(Math.sin(Math.PI / 2 * q / 0.55), 0.6) : b + (ro - b) * (0.5 - 0.5 * Math.cos(Math.PI * (q - 0.55) / 0.45));
        if (q > 0.15) w *= 1 + 0.07 * c * Math.sin(q * 23 + ph);
        bw[i] = w;
      }
    }
    function cheminCloche(ctx, k) {
      ctx.moveTo(bx[NBS - 1], -bw[NBS - 1] * k);
      for (let i = NBS - 2; i >= 0; i--) ctx.lineTo(bx[i], -bw[i] * k);
      for (let i = 1; i < NBS; i++) ctx.lineTo(bx[i], bw[i] * k);
    }
    const angTige = i => { const a = Math.max(0, i - 1), b = Math.min(NS - 1, i + 1); return Math.atan2(s.sy[a] - s.sy[b], s.sx[a] - s.sx[b]); };

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xc07e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.64 : 0.34);
        s = { hx, hy, x: hx + (r() - 0.5) * 50, y: hy + (r() - 0.5) * 50, vx: 0, vy: 0, ang: r() * TAU, angv: 0, ph0: r() * TAU, bend: 0,
          ph: new Float32Array(NB), c: new Float32Array(NB), dc: new Float32Array(NB), amp: new Float32Array(NB), flash: new Float32Array(NB),
          sx: new Float32Array(NS), sy: new Float32Array(NS), lag: 0.14, K: 1.4, frq: 0.6, exc: 0, gobe: 0, tl: 1, curl: 0.15, harp: 0, gon: 0,
          tex: [], tey: [], pa: new Float32Array(NC), tlk: new Float32Array(NC), anneaux: [], ri: 0, lueur: lueurNeuve(r),
          g: 0, gx: 0, gy: 0, cph: 0, e: 0.95 + 0.1 * r(), u: 0 };
        for (let i = 0; i < NB; i++) { s.ph[i] = r(); s.amp[i] = 1; s.c[i] = contraction(s.ph[i]); }
        for (let i = 0; i < NS; i++) { s.sx[i] = s.x - Math.cos(s.ang) * SEG * i; s.sy[i] = s.y - Math.sin(s.ang) * SEG * i; }
        for (let k = 0; k < NC; k++) {
          const X = new Float32Array(NTP), Y = new Float32Array(NTP), j = CORM[k];
          for (let i = 0; i < NTP; i++) { X[i] = s.sx[j] - Math.cos(s.ang) * i * 3.6; Y[i] = s.sy[j] - Math.sin(s.ang) * i * 3.6; }
          s.tex.push(X); s.tey.push(Y); s.pa[k] = s.ang + Math.PI + (k % 2 ? 1 : -1) * 1.2; s.tlk[k] = 1;
        }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, a: 0, r: 0, vie: 0 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      centre() { return [s.sx[14], s.sy[14]]; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 30 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 190) - s.exc) * Math.min(1, h * 2.5));
        // Intention → synchronie : décalage de phase visé, couplage, cadence ; tentacules
        let lag = 0.14, K = 1.4, frq = 0.5 + 0.55 * energy, tl = 1, curl = 0.15, harp = 0, gon = 0;
        if (e > 0.01) {
          if (md === 'cont') { lag = melange(lag, 0.24, e); frq -= 0.15 * e; tl = 1 + 0.45 * e; gon = e; }
          else if (md === 'actif') { lag = melange(lag, 0.5, e); K = 2.2; frq += 0.35 * e; tl = 1 + 0.15 * e; }
          else if (md === 'agr') { lag = melange(lag, 0, e); K = melange(K, 4.5, e); frq += 0.45 * e; harp = e; }
          else if (md === 'suit') { lag = melange(lag, 0.09, e); tl = 1 + 0.3 * e; gon = 0.4 * e; }
          else if (md === 'evite') { lag = melange(lag, 0.02, e); K = melange(K, 5, e); frq += 0.9 * e; tl = 1 - 0.5 * e; curl = melange(curl, 2.4, e); }
          else { lag = melange(lag, 0.32, e); tl = 1 + 0.25 * e; gon = 0.5 * e; }
        }
        const kk = Math.min(1, h * 1.6);
        s.lag += (lag - s.lag) * kk; s.K += (K - s.K) * kk; s.frq += (frq * (0.55 + 0.45 * RG.vit) - s.frq) * kk;
        s.tl += (tl - s.tl) * kk; s.curl += (curl - s.curl) * kk; s.harp += (harp - s.harp) * kk; s.gon += (gon - s.gon) * kk;
        // Cap visé
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.gy - s.y, s.gx - s.x) - s.ang);
        else {
          const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 180);
          d = 0.7 * Math.sin(t * 0.19 + s.ph0) + enrouleAngle(Math.atan2(ecY, ecX) - s.ang) * loin * loin;
        }
        s.u += (borne(d * 0.9, -0.8, 0.8) * (s.g ? Math.min(1, 0.45 + s.g) : 0.6) - s.u) * Math.min(1, h * 3);
        // Oscillateurs couplés (plus proches voisins, onde avant → arrière)
        for (let i = 0; i < NB; i++) {
          let cpl = 0;
          if (i > 0) cpl += Math.sin(TAU * (s.ph[i - 1] - s.ph[i] - s.lag));
          if (i < NB - 1) cpl += Math.sin(TAU * (s.ph[i + 1] - s.ph[i] + s.lag));
          dph[i] = s.frq + s.K * 0.09 * cpl;
        }
        let F = 0, Tq = 0;
        const fwx = Math.cos(s.ang), fwy = Math.sin(s.ang);
        for (let i = 0; i < NB; i++) {
          const side = i % 2 ? 1 : -1;
          s.amp[i] += (1 + side * s.u - s.amp[i]) * Math.min(1, h * 4);
          const f0 = s.ph[i]; s.ph[i] += Math.max(0.05, dph[i]) * h;
          const pic = f0 < 0.26 && s.ph[i] >= 0.26;
          if (s.ph[i] >= 1) s.ph[i] -= 1;
          const cp = s.c[i]; s.c[i] = contraction(s.ph[i]); s.dc[i] = (s.c[i] - cp) / h;
          const f = Math.max(0, s.dc[i]) * s.amp[i];
          F += f; Tq += side * f;
          s.flash[i] = Math.max(0, s.flash[i] - h * 2.2);
          if (pic) {
            s.flash[i] = 1;
            const j = ATT[i], ta = angTige(j) + side * 0.32, an = s.anneaux[s.ri++ % NR];
            const mx = s.sx[j] + nxs[j] * side * 5.5 * s.e - Math.cos(ta) * 8 * s.e, my = s.sy[j] + nys[j] * side * 5.5 * s.e - Math.sin(ta) * 8 * s.e;
            an.x = mx; an.y = my; an.vx = -Math.cos(ta) * 18 + s.vx * 0.1; an.vy = -Math.sin(ta) * 18 + s.vy * 0.1; an.a = ta; an.r = 3.4 * s.e * s.amp[i]; an.vie = 1;
          }
        }
        const pousse = F * 9.5 * s.e * (0.85 + 0.3 * energy), fr = Math.exp(-1.5 * h);
        s.vx = s.vx * fr + fwx * pousse * h; s.vy = s.vy * fr + fwy * pousse * h;
        s.angv += (Tq * 1.05 - 2.4 * s.angv) * h * 2.2;
        s.ang += s.angv * h;
        s.bend += (-s.angv * 0.5 - s.bend) * Math.min(1, h * 3);
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.35) * h, ny = s.y + (s.vy + fl[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 110); s.y = enroule(ny, 0, H, 110);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let i = 0; i < NS; i++) { s.sx[i] += jx; s.sy[i] += jy; }
          for (let k = 0; k < NC; k++) for (let i = 0; i < NTP; i++) { s.tex[k][i] += jx; s.tey[k][i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        // Tige : suivi du chef, raide dans le nectosome, souple et dérivante vers la queue
        const sx = s.sx, sy = s.sy, seg = SEG * s.e;
        sx[0] = s.x; sy[0] = s.y;
        for (let i = 1; i < NS; i++) { const fi = flow(sx[i], sy[i]), q = i / NS; sx[i] += fi[0] * 0.3 * q * h; sy[i] += fi[1] * 0.3 * q * h; }
        for (let i = 1; i < NS - 1; i++) {
          const kr = i < 14 ? 0.3 : 0.05;
          sx[i] += ((sx[i - 1] + sx[i + 1]) * 0.5 - sx[i]) * kr; sy[i] += ((sy[i - 1] + sy[i + 1]) * 0.5 - sy[i]) * kr;
        }
        // Le nectosome garde l'axe du flotteur (sinon il se plierait sous les poussées)
        for (let i = 1; i < NS; i++) {
          if (i < 13) { const kq = 0.35 * (1 - i / 13); sx[i] += (sx[0] - fwx * seg * i - sx[i]) * kq; sy[i] += (sy[0] - fwy * seg * i - sy[i]) * kq; }
          const ex = sx[i] - sx[i - 1], ey = sy[i] - sy[i - 1], k = seg / (Math.hypot(ex, ey) || 1);
          sx[i] = sx[i - 1] + ex * k; sy[i] = sy[i - 1] + ey * k;
        }
        for (let i = 0; i < NS; i++) { const a = angTige(i); nxs[i] = -Math.sin(a); nys[i] = Math.cos(a); }
        // Polypes et tentacules : pêche (cont), harpon (agr), spirale serrée (evite)
        const pon = RG.part && RG.part.on;
        let hk = -1, hd = 1e9;
        if (pon && s.harp > 0.05) for (let k = 0; k < NC; k++) { const j = CORM[k], dd = Math.hypot(RG.part.x - sx[j], RG.part.y - sy[j]); if (dd < hd) { hd = dd; hk = k; } }
        for (let k = 0; k < NC; k++) {
          const j = CORM[k], side = k % 2 ? 1 : -1, ta = angTige(j), arr = ta + Math.PI;
          const cible = arr + side * (1.05 + 0.5 * s.gon + 0.2 * Math.sin(t * 0.8 + k * 2));
          s.pa[k] += enrouleAngle(cible - s.pa[k]) * Math.min(1, h * 2.5);
          const harpe = k === hk ? s.harp * borne(1.6 - hd / 110, 0, 1) : 0;
          s.tlk[k] += ((s.tl + 1.3 * harpe) - s.tlk[k]) * Math.min(1, h * (harpe > 0.1 ? 6 : 2));
          const X = s.tex[k], Y = s.tey[k], pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
          X[0] = sx[j] + pc * 10 * s.e; Y[0] = sy[j] + ps * 10 * s.e;
          let a0;
          if (harpe > 0.05) a0 = Math.atan2(RG.part.y - Y[0], RG.part.x - X[0]);
          else {
            const wt = 0.3 + 0.45 * s.gon, vxm = Math.cos(arr) * (1 - wt) + pc * wt, vym = Math.sin(arr) * (1 - wt) + ps * wt;
            a0 = Math.atan2(vym, vxm);
            if (pon && s.gon > 0.05) a0 += enrouleAngle(Math.atan2(RG.part.y - Y[0], RG.part.x - X[0]) - a0) * 0.35 * s.gon;
          }
          const sg = 3.6 * s.e * s.tlk[k];
          let a = a0;
          for (let i = 1; i < NTP; i++) {
            const q = i / (NTP - 1);
            a += (harpe > 0.05 ? 0.02 : 0.13) * Math.sin(t * 2.1 - i * 0.6 + k * 1.9) * (1 - harpe) + s.curl * 0.3 * side * q;
            const tx = X[i - 1] + Math.cos(a) * sg, ty = Y[i - 1] + Math.sin(a) * sg;
            const kf = Math.min(1, h * ((harpe > 0.05 ? 22 : 13) - 10 * q));
            X[i] += (tx - X[i]) * kf; Y[i] += (ty - Y[i]) * kf;
            const ex = X[i] - X[i - 1], ey = Y[i] - Y[i - 1], l = sg / (Math.hypot(ex, ey) || 1);
            X[i] = X[i - 1] + ex * l; Y[i] = Y[i - 1] + ey * l;
          }
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.4 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 4; an.vie -= h / 1.5;
        }
        s.cph += h * (6 + 5 * energy + 8 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const sx = s.sx, sy = s.sy, e = s.e, G = degr(ctx);
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de sillage (petits tores de profil)
        ctx.strokeStyle = coul.perle; ctx.beginPath();
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const sn = Math.sin(an.a), cs = Math.cos(an.a);
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x - sn * an.r * sg, qy = an.y + cs * an.r * sg, rr = 1 + (1 - an.vie) * 1.6, a0 = an.a + (1 - an.vie) * 8 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.2);
          }
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.6; ctx.stroke();
        // 2. Tentacules : fil + tentilles (crochets perlés), plus denses vers le bout
        ctx.beginPath();
        for (let k = 0; k < NC; k++) {
          const X = s.tex[k], Y = s.tey[k]; ctx.moveTo(X[0], Y[0]);
          for (let i = 1; i < NTP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
          ctx.lineTo(X[NTP - 1], Y[NTP - 1]);
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 4; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        const perles = [];
        for (let k = 0; k < NC; k++) {
          const X = s.tex[k], Y = s.tey[k];
          for (let i = 2; i < NTP - 1; i++) {
            let tx = X[i + 1] - X[i - 1], ty = Y[i + 1] - Y[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
            const sd = i % 2 ? 1 : -1, L = (2.2 + 1.6 * i / NTP) * (1 + 0.3 * Math.sin(s.cph * 0.7 - i + k)) * e;
            const ex = X[i] - ty * sd * L - tx * L * 0.5, ey = Y[i] + tx * sd * L - ty * L * 0.5;
            ctx.moveTo(X[i], Y[i]); ctx.quadraticCurveTo(X[i] - ty * sd * L * 0.8, Y[i] + tx * sd * L * 0.8, ex, ey);
            perles.push(ex, ey);
          }
        }
        ctx.globalAlpha = A * 0.26; ctx.lineWidth = 0.45; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < perles.length; k += 2) { ctx.moveTo(perles[k] + 0.75, perles[k + 1]); ctx.arc(perles[k], perles[k + 1], 0.75, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.fill();
        // 3. Tige : épaisse et annelée dans le nectosome, fil perlé ensuite
        ctx.beginPath(); ctx.moveTo(sx[0], sy[0]);
        for (let i = 1; i < NS - 1; i++) ctx.quadraticCurveTo(sx[i], sy[i], (sx[i] + sx[i + 1]) / 2, (sy[i] + sy[i + 1]) / 2);
        ctx.lineTo(sx[NS - 1], sy[NS - 1]);
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.75; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(sx[0], sy[0]); for (let i = 1; i < 14; i++) ctx.lineTo(sx[i], sy[i]);
        ctx.globalAlpha = A * 0.22; ctx.lineWidth = 2.4; ctx.stroke();
        ctx.beginPath();
        for (let i = 14; i < NS; i += 2) { const rr = 0.9 * (1 - (i - 14) / NS); ctx.moveTo(sx[i] + rr, sy[i]); ctx.arc(sx[i], sy[i], rr, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.fill();
        // 4. Polypes pêcheurs (petites Cellules en goutte) : pédoncule, corps, bouche ciliée
        for (let k = 0; k < NC; k++) {
          const j = CORM[k], pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
          ctx.beginPath(); ctx.moveTo(sx[j], sy[j]); ctx.lineTo(sx[j] + pc * 3 * e, sy[j] + ps * 3 * e);
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
          const cx = sx[j] + pc * 6.5 * e, cy = sy[j] + ps * 6.5 * e, gonf = 1 + 0.12 * Math.sin(t * 1.4 + k * 2);
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(s.pa[k]);
          ctx.beginPath(); ctx.moveTo(-3.5 * e, 0); ctx.bezierCurveTo(-3.5 * e, -3.6 * e * gonf, 3.6 * e, -2.8 * e * gonf, 4.4 * e, 0);
          ctx.bezierCurveTo(3.6 * e, 2.8 * e * gonf, -3.5 * e, 3.6 * e * gonf, -3.5 * e, 0);
          ctx.save(); ctx.scale(4.4 * e, 3.4 * e); ctx.fillStyle = G.cloche; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.7; ctx.stroke();
          ctx.beginPath(); ctx.arc(-0.6 * e, 0, 1.2 * e, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
          ctx.strokeStyle = s.gobe > 0.01 ? coul.mauve : coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.5; ctx.stroke();
          ctx.beginPath();
          for (let m = 0; m < 5; m++) { const q = (m / 4 - 0.5) * 1.6, L = (1.6 + 0.9 * Math.sin(s.cph * 1.3 - m)) * e; ctx.moveTo(4.4 * e, 0); ctx.lineTo(4.4 * e + Math.cos(q) * L, Math.sin(q) * L); }
          ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.restore();
        }
        // 5. Nectosome : six cloches en fermeture éclair (arrière d'abord pour le recouvrement)
        for (let i = NB - 1; i >= 0; i--) {
          const j = ATT[i], side = i % 2 ? 1 : -1, c = s.c[i], am = s.amp[i];
          const ta = angTige(j) + side * (0.32 + 0.12 * c) + s.bend * 0.3;
          const a = 8.6 * e * (1 + 0.16 * c), b = 6.1 * e * (1 - 0.24 * c) * (0.92 + 0.08 * am), ro = b * (0.66 - 0.34 * c);
          profil(a, b, ro, c, t * 2.4 + i);
          ctx.save(); ctx.translate(sx[j] + nxs[j] * side * 6.4 * e, sy[j] + nys[j] * side * 6.4 * e); ctx.rotate(ta);
          ctx.beginPath(); cheminCloche(ctx, 1); ctx.quadraticCurveTo(bx[NBS - 1] + a * 0.3, 0, bx[NBS - 1], -bw[NBS - 1]);
          ctx.save(); ctx.scale(a, b); ctx.fillStyle = G.cloche; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 3.5; ctx.stroke();
          ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.75; ctx.stroke();
          // sous-ombrelle
          ctx.beginPath(); for (let k2 = NBS - 1; k2 >= 3; k2--) ctx.lineTo(bx[k2], -0.7 * bw[k2]); for (let k2 = 3; k2 < NBS; k2++) ctx.lineTo(bx[k2], 0.7 * bw[k2]);
          ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (0.32 + 0.14 * c); ctx.fill();
          ctx.beginPath(); ctx.ellipse(bx[NBS - 1] + 0.6, 0, 1.4 + a * 0.12 * (1 - c), bw[NBS - 1], 0, 0, TAU); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.6; ctx.stroke();
          // vacuole étoilée miniature : pleine au relâchement
          const plein = 1 - c, vx0 = bx[2], rv = (0.8 + 1.3 * plein) * e;
          ctx.beginPath();
          for (let k2 = 0; k2 < 5; k2++) { const q = k2 / 5 * TAU + i, L = (1.8 + 3.2 * plein) * e; ctx.moveTo(vx0 + Math.cos(q) * rv, Math.sin(q) * rv); ctx.lineTo(vx0 + Math.cos(q + 0.3 * (0.5 - plein)) * (rv + L), Math.sin(q + 0.3 * (0.5 - plein)) * (rv + L)); }
          ctx.globalAlpha = A * 0.35; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.beginPath(); ctx.arc(vx0, 0, rv, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill(); ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.55; ctx.stroke();
          // frange du vélum + cils couchés par la poussée
          const xr = bx[NBS - 1];
          ctx.beginPath();
          for (let k2 = 0; k2 <= 5; k2++) { const u = k2 / 5 - 0.5, y0 = u * 2 * bw[NBS - 1], L = (2.4 + 1.6 * s.gon + 1.2 * Math.sin(s.cph * 1.3 - k2 + i)) * e; ctx.moveTo(xr, y0); ctx.lineTo(xr - L, y0 + u * L * (1.2 - c)); }
          for (let sd = -1; sd <= 1; sd += 2) for (let k2 = 1; k2 < NBS - 1; k2++) {
            const ph = s.cph - k2 * 0.6 + i * 1.3, L = (1.1 + 0.7 * Math.sin(ph)) * e;
            ctx.moveTo(bx[k2], sd * bw[k2]); ctx.lineTo(bx[k2] - L * (0.4 + 0.5 * c), sd * (bw[k2] + L));
          }
          ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.45; ctx.stroke();
          // éclair de contraction (très doux) : on lit la salve qui court
          const fl = A * P.alpha.biolum * s.flash[i] * s.flash[i];
          if (fl > 0.004) {
            ctx.globalCompositeOperation = 'lighter'; ctx.beginPath(); cheminCloche(ctx, 1);
            ctx.strokeStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = fl * 0.45; ctx.lineWidth = 0.7; ctx.stroke();
            ctx.globalCompositeOperation = 'source-over';
          }
          ctx.restore();
        }
        // 6. Flotteur (pneumatophore) : bulle nacrée, pore apical, crête ciliée
        {
          const ca = s.ang, pr = 1 + 0.06 * Math.sin(t * 1.1 + s.ph0);
          ctx.save(); ctx.translate(sx[0] + Math.cos(ca) * 3, sy[0] + Math.sin(ca) * 3); ctx.rotate(ca);
          ctx.beginPath(); ctx.arc(0, 0, 13 * e, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.05; ctx.fill();
          ctx.beginPath(); ctx.ellipse(0, 0, 8.4 * e * pr, 5.6 * e, 0, 0, TAU);
          ctx.save(); ctx.scale(8.4 * e, 5.6 * e); ctx.fillStyle = G.flot; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.65; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(-0.8, 0, 6.2 * e * pr, 3.8 * e, 0, 0, TAU); ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath(); ctx.arc(7.6 * e, 0, 1, 0, TAU); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.7; ctx.fill();
          ctx.beginPath();
          for (let k = 0; k < 11; k++) { const x0 = (k / 10 - 0.5) * 12 * e, y0 = -5.4 * e * Math.sqrt(Math.max(0, 1 - Math.pow(x0 / (8.5 * e), 2))), L = (2.2 + 1.2 * Math.sin(s.cph * 1.1 - k * 0.7)) * e; ctx.moveTo(x0, y0); ctx.lineTo(x0 - L * 0.5, y0 - L); }
          ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.beginPath(); ctx.arc(-1.6 * e, -1.4 * e, 1.3, 0, TAU); ctx.globalAlpha = A * 0.5; ctx.fill();
          ctx.restore();
        }
        // 7. Lumières : l'impulsion descend la tige du flotteur vers les polypes ; gobage mauve
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const cc = s.lueur.pos * (NS + 4) - 2;
          ctx.strokeStyle = ctx.fillStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NS - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 < cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath(); ctx.moveTo(sx[i], sy[i]); ctx.lineTo(sx[i + 1], sy[i + 1]);
            ctx.globalAlpha = li * 0.14; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.75; ctx.lineWidth = 1; ctx.stroke();
          }
          for (let k = 0; k < NC; k++) {
            const li = I * cloche(cc - CORM[k], 2.5); if (li < 0.004) continue;
            const X = s.tex[k], Y = s.tey[k]; ctx.beginPath(); ctx.moveTo(X[0], Y[0]); for (let i = 1; i < NTP; i++) ctx.lineTo(X[i], Y[i]);
            ctx.globalAlpha = li * 0.5; ctx.lineWidth = 0.8; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          for (let k = 0; k < NC; k++) {
            const j = CORM[k], gk = s.gobe * cloche(1 - s.gobe - k * 0.12, 0.5), pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
            const cx = sx[j] + pc * 6 * e, cy = sy[j] + ps * 6 * e;
            ctx.beginPath(); ctx.arc(cx, cy, 3 + 6 * gk, 0, TAU); ctx.globalAlpha = A * 0.25 * gk; ctx.fill();
            ctx.beginPath(); ctx.arc(cx, cy, 1 + 1.4 * gk, 0, TAU); ctx.globalAlpha = A * 0.95 * gk; ctx.fill();
          }
          const cg = (1 - s.gobe) * (NS + 4);
          ctx.strokeStyle = coul.mauve;
          for (let i = 0; i < NS - 1; i++) { const li = A * s.gobe * cloche(i - cg, 3); if (li < 0.01) continue; ctx.beginPath(); ctx.moveTo(sx[i], sy[i]); ctx.lineTo(sx[i + 1], sy[i + 1]); ctx.globalAlpha = li * 0.6; ctx.lineWidth = 1.4; ctx.stroke(); }
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     7. VOLTE — cloche gyroscopique à fronde (étage 3 : Culbute × Systole)
     Une vraie cloche 3D (de révolution, ovale) dont l'axe est l'axe intermédiaire d'inertie :
     elle culbute comme la Culbute (Djanibekov). La vacuole étoilée se charge pendant qu'elle
     tourne ; elle ne tire son jet que lorsque l'axe instable passe dans la bonne direction —
     une fronde à visée par le temps. Le jet part selon l'axe 3D : vu de face, il ne la déplace
     pas. La trompe de la Culbute devient un manubrium qui sort de la cloche (col harponneur).
     ===================================================================== */
  function creerVolte() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NM = 14, NU = 7, NT = 8, NTP = 13, NMN = 10, NR = 3, NRIM = 28, OZ = 0.82;
    const NPT = NM * NU + 1;
    const CR = corpsRigide(1, 1.55, 2.05), R = CR.R, pj = CR.pj, w = CR.w;
    const PX = new Float32Array(NPT), PY = new Float32Array(NPT), PZ = new Float32Array(NM * NU);
    const prR = new Float32Array(NU), prY = new Float32Array(NU), nR = new Float32Array(NU), nY = new Float32Array(NU);
    const RX = new Float32Array(NRIM), RY = new Float32Array(NRIM), RZ = new Float32Array(NRIM);
    const idx = new Int16Array(NPT), hull = new Int16Array(NPT + 2);
    const MX = new Float32Array(NMN), MY = new Float32Array(NMN), MZ = new Float32Array(NMN);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.3, -0.35, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.2)); g.addColorStop(0.45, rgba(P.sarcelle, 0.22));
      g.addColorStop(0.8, rgba(P.aqua, 0.22)); g.addColorStop(0.96, rgba(P.perle, 0.34)); g.addColorStop(1, rgba(P.perle, 0.08));
      return g;
    });
    // Profil d'un tir : fermeture brusque, réouverture avec dépassement (la cloche s'évase)
    const tir = f => { if (f < 0.2) return 0.5 - 0.5 * Math.cos(Math.PI * f / 0.2); const x = (f - 0.2) / 0.8, c = (1 - x) * Math.cos(Math.PI * x * 1.5); return c < 0 ? c * 0.45 : c; };
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    function forme() {
      const e = s.e, c = s.c, sw = lisseP(borne(s.q, 0, 1));
      s.Rb = 19 * e * (1 - 0.3 * c + 0.1 * sw + 0.14 * s.gon);
      s.Hb = 23 * e * (1 + 0.24 * c - 0.05 * sw - 0.08 * s.gon);
      for (let j = 0; j < NU; j++) {
        const u = 0.06 + 0.94 * j / (NU - 1);
        prR[j] = s.Rb * Math.pow(Math.sin(Math.PI / 2 * u), 0.72) * (1 + (u > 0.8 ? 0.12 * (u - 0.8) / 0.2 * (1 - c) : 0));
        prY[j] = s.Hb * (0.55 - Math.pow(u, 1.2));
      }
      for (let j = 0; j < NU; j++) {
        const a = Math.max(0, j - 1), b = Math.min(NU - 1, j + 1), dr = prR[b] - prR[a], dy = prY[b] - prY[a], l = 1 / (Math.hypot(dr, dy) || 1);
        nR[j] = -dy * l; nY[j] = dr * l;
      }
    }
    function projeterTout() {
      for (let m = 0; m < NM; m++) {
        const ph = m / NM * TAU + s.rotM, cp = Math.cos(ph), sp = Math.sin(ph) * OZ;
        for (let j = 0; j < NU; j++) {
          const k = m * NU + j; CR.proj(prR[j] * cp, prY[j], prR[j] * sp);
          PX[k] = s.x + pj[0]; PY[k] = s.y + pj[1];
          PZ[k] = R[6] * nR[j] * cp + R[7] * nY[j] + R[8] * nR[j] * sp;   // z de la normale : face avant > 0
        }
      }
      CR.proj(0, s.Hb * 0.58, 0); PX[NPT - 1] = s.x + pj[0]; PY[NPT - 1] = s.y + pj[1];
      const rr = prR[NU - 1], yr = prY[NU - 1];
      for (let k = 0; k < NRIM; k++) { const ph = k / NRIM * TAU + s.rotM; CR.proj(rr * Math.cos(ph), yr, rr * Math.sin(ph) * OZ); RX[k] = s.x + pj[0]; RY[k] = s.y + pj[1]; RZ[k] = pj[2]; }
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0x701e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        CR.init(r() * TAU, 0.6 + r() * 0.6);
        w[0] = 0.06; w[1] = 3 + r(); w[2] = 0.05;
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ph: r() * TAU, e: 1 + 0.1 * r(),
          q: r() * 0.6, fire: 0, qf: 0, c: 0, cp: 0, gon: 0, ecart: 1, harp: 0, exc: 0, gobe: 0, cph: 0, rotM: 0, flash: 0, Rb: 19, Hb: 23,
          lueur: lueurNeuve(r), g: 0, gx: 0, gy: 0, tex: [], tey: [], anneaux: [], ri: 0, thr: 0.8, qr: 1, spin: 3, kA: 0, kD: 0, kick: 0.1 };
        forme();
        for (let k = 0; k < NT; k++) { const X = new Float32Array(NTP), Y = new Float32Array(NTP); for (let i = 0; i < NTP; i++) { X[i] = s.x; Y[i] = s.y + i * 4; } s.tex.push(X); s.tey.push(Y); }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, ax: 0, ay: 0, az: 1, r: 0, vie: 0 });
        for (let i = 0; i < NMN; i++) { CR.proj(0, s.Hb * 0.4 - i * 3, 0); MX[i] = s.x + pj[0]; MY[i] = s.y + pj[1]; MZ[i] = pj[2]; }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 24 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 180) - s.exc) * Math.min(1, h * 2.5));
        // [spin, kA, kD, kick, seuil d'alignement, vitesse de charge, écart des tentacules, gonflement, harpon]
        let m = [(1.5 + 1.8 * energy) * (0.6 + 0.4 * RG.vit), s.g ? 2.2 * s.g : 0, s.g ? 1 : 0, 0.1, 0.82, 1, 1, 0, 0];
        if (e > 0.01) {
          let b;
          if (md === 'cont') b = [1.1, 4, 2.2, 0.02, 0.9, 0.5, 1.7, 1, 0];
          else if (md === 'actif') b = [6.5, 0.4, 0, 0.8, 0.5, 1.7, 1.1, 0.3, 0];
          else if (md === 'agr') b = [1.6, 8, 2.6, 0.02, 0.62, 1.9, 0.45, 0, 1];
          else if (md === 'suit') b = [2, 3.5, 1.6, 0.04, 0.75, 1, 1, 0.4, 0];
          else if (md === 'evite') b = [7, 4, 0.4, 0.9, 0.3, 2.3, 0.35, 0, 0];
          else b = [3.5, 3, 1, 0.1, 0.7, 1.1, 1.25, 0.5, 0];
          for (let k = 0; k < 9; k++) m[k] = melange(m[k], b[k], e);
        }
        const kk = Math.min(1, h * 2);
        s.spin += (m[0] - s.spin) * kk; s.kA += (m[1] - s.kA) * kk; s.kD += (m[2] - s.kD) * kk; s.kick += (m[3] - s.kick) * kk;
        s.thr += (m[4] - s.thr) * kk; s.qr += (m[5] - s.qr) * kk; s.ecart += (m[6] - s.ecart) * kk; s.gon += (m[7] - s.gon) * kk; s.harp += (m[8] - s.harp) * kk;
        // Direction voulue (cible, ou errance autour de son coin)
        let Dx, Dy;
        if (s.g) { Dx = s.gx - s.x; Dy = s.gy - s.y; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 150), a = Math.atan2(ecY, ecX) * loin + (1 - loin) * (t * 0.13 + s.ph); Dx = Math.cos(a); Dy = Math.sin(a); }
        const Dl = Math.hypot(Dx, Dy) || 1; Dx /= Dl; Dy /= Dl;
        // Corps rigide : moteur ciliaire + visée de l'axe (e2) ; pendant un tir, le jet stabilise un peu
        CR.tau[0] = CR.tau[1] = CR.tau[2] = 0;
        if (s.kA > 0.05) CR.viser(1, Dx, Dy, 0.15, s.kA, s.kD);
        CR.moteur(s.spin * (s.fire > 0 ? 0.6 : 1), s.kick, t, s.ph);
        CR.avancer(h);
        // Charge de la vacuole puis tir quand l'axe instable passe dans la bonne direction
        const ax = R[1], ay = R[4], lp = Math.hypot(ax, ay), align = (ax * Dx + ay * Dy) / (lp || 1);
        if (s.fire <= 0) {
          s.q += h * (0.3 + 0.45 * energy) * s.qr;
          if ((s.q >= 0.55 && align > s.thr && lp > 0.5) || s.q >= 1.8) {
            s.fire = 1e-4; s.qf = Math.min(1.3, s.q); s.q = 0; s.flash = 1;
            const an = s.anneaux[s.ri++ % NR]; CR.proj(0, prY[NU - 1], 0);
            an.x = s.x + pj[0]; an.y = s.y + pj[1]; an.ax = R[1]; an.ay = R[4]; an.az = R[7];
            an.vx = -R[1] * 30 + s.vx * 0.1; an.vy = -R[4] * 30 + s.vy * 0.1; an.r = prR[NU - 1] * 0.95; an.vie = 1;
          }
        } else { s.fire += h / 0.6; if (s.fire >= 1) s.fire = 0; }
        s.cp = s.c; s.c = s.fire > 0 ? tir(s.fire) : 0;
        const dc = (s.c - s.cp) / h;
        const pousse = (dc > 0 ? dc * 30 * s.qf : 0) * s.e * (0.8 + 0.35 * energy) * (0.6 + 0.4 * RG.vit);
        const fr = Math.exp(-1.5 * h);
        s.vx = s.vx * fr + ax * pousse * h; s.vy = s.vy * fr + ay * pousse * h;
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.4) * h, ny = s.y + (s.vy + fl[1] * 0.4) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let k = 0; k < NT; k++) for (let i = 0; i < NTP; i++) { s.tex[k][i] += jx; s.tey[k][i] += jy; }
          for (let i = 0; i < NMN; i++) { MX[i] += jx; MY[i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        s.rotM += h * 0.25;
        forme(); projeterTout();
        // Tentacules du bord : traînent derrière l'axe, s'écartent quand la cloche est vue de face,
        // se plaquent au tir (suivi), s'étalent en curiosité
        const bx2 = -ax, by2 = -ay;
        for (let k = 0; k < NT; k++) {
          const ri = Math.round(k / NT * NRIM) % NRIM, X = s.tex[k], Y = s.tey[k];
          X[0] = RX[ri]; Y[0] = RY[ri];
          let rx = RX[ri] - s.x, ry = RY[ri] - s.y; const rl2 = 1 / (Math.hypot(rx, ry) || 1); rx *= rl2; ry *= rl2;
          const wr = (0.35 * s.ecart + 0.55 * (1 - lp)) * (1 - 0.75 * Math.max(0, s.c));
          const a0 = Math.atan2(by2 * 1.3 + ry * wr, bx2 * 1.3 + rx * wr), sg = 4.9 * s.e * (1 + 0.2 * s.gon);
          let a = a0;
          for (let i = 1; i < NTP; i++) {
            const q = i / (NTP - 1);
            a += 0.11 * Math.sin(t * 2.3 - i * 0.55 + k * 0.9) + 0.03 * (k % 2 ? 1 : -1);
            const tx = X[i - 1] + Math.cos(a) * sg, ty = Y[i - 1] + Math.sin(a) * sg, kf = Math.min(1, h * (14 - 11.5 * q));
            X[i] += (tx - X[i]) * kf; Y[i] += (ty - Y[i]) * kf;
            const ex = X[i] - X[i - 1], ey = Y[i] - Y[i - 1], l = sg / (Math.hypot(ex, ey) || 1);
            X[i] = X[i - 1] + ex * l; Y[i] = Y[i - 1] + ey * l;
          }
        }
        // Manubrium (trompe) : pend de l'apex, sort par l'ouverture ; harpon vers la particule
        let prox = 0;
        if (RG.part && RG.part.on && s.harp > 0.05) prox = s.harp * borne(1.5 - Math.hypot(RG.part.x - s.x, RG.part.y - s.y) / 90, 0, 1);
        s.ext = (s.ext || 1) + ((1 + 1.4 * prox) - (s.ext || 1)) * Math.min(1, h * 4);
        const Lm = s.Hb * 1.15 * s.ext, sgm = Lm / (NMN - 1);
        for (let i = 0; i < NMN; i++) {
          const q = i / (NMN - 1), am = 2.2 * q * (1 - prox);
          CR.proj(am * Math.sin(t * 1.9 - i * 0.7), s.Hb * 0.4 - i * sgm, am * Math.cos(t * 1.6 - i * 0.6));
          let wx = s.x + pj[0], wy = s.y + pj[1];
          if (prox > 0.05 && i > 2) { const k2 = prox * (q - 0.2); wx += (RG.part.x - wx) * k2 * 0.6; wy += (RG.part.y - wy) * k2 * 0.6; }
          if (i === 0) { MX[0] = wx; MY[0] = wy; MZ[0] = pj[2]; continue; }
          const kf = Math.min(1, h * (30 - 24 * q));
          MX[i] += (wx - MX[i]) * kf; MY[i] += (wy - MY[i]) * kf; MZ[i] += (pj[2] - MZ[i]) * kf;
          const ex = MX[i] - MX[i - 1], ey = MY[i] - MY[i - 1], l = Math.hypot(ex, ey) || 1;
          if (l > sgm) { MX[i] = MX[i - 1] + ex / l * sgm; MY[i] = MY[i - 1] + ey / l * sgm; }
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.2 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 6; an.vie -= h / 1.8;
        }
        s.flash = Math.max(0, s.flash - h * 1.8);
        s.cph += h * (7 + 8 * energy + 12 * e + 10 * Math.max(0, dc) * 0.1);
        s.gobe = Math.max(0, s.gobe - h * 0.32);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const e = s.e, ouvVue = R[7] < 0;          // l'ouverture regarde l'observateur
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de jet : vrais cercles 3D projetés + deux volutes
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const v = an.vie, rot = Math.atan2(an.ay, an.ax) + Math.PI / 2, mi = Math.max(1, an.r * Math.abs(an.az));
          ctx.beginPath(); ctx.ellipse(an.x, an.y, an.r, mi, rot, 0, TAU);
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32 * v * v; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x + Math.cos(rot) * an.r * sg, qy = an.y + Math.sin(rot) * an.r * sg, rr = 1.6 + (1 - v) * 2.4, a0 = rot + (1 - v) * 9 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.4);
          }
          ctx.globalAlpha = A * 0.45 * v; ctx.lineWidth = 0.7; ctx.stroke();
        }
        const tentacules = (Aa) => {
          ctx.beginPath();
          for (let k = 0; k < NT; k++) {
            const X = s.tex[k], Y = s.tey[k]; ctx.moveTo(X[0], Y[0]);
            for (let i = 1; i < NTP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
            ctx.lineTo(X[NTP - 1], Y[NTP - 1]);
          }
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = Aa * 0.07; ctx.lineWidth = 4.5; ctx.stroke();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Aa * 0.42; ctx.lineWidth = 0.7; ctx.stroke();
          ctx.beginPath();
          for (let k = 0; k < NT; k++) for (let i = 3; i < NTP; i += 3) { const rr = 0.9 * (1 - i / NTP * 0.5); ctx.moveTo(s.tex[k][i] + rr, s.tey[k][i]); ctx.arc(s.tex[k][i], s.tey[k][i], rr, 0, TAU); }
          ctx.fillStyle = coul.perle; ctx.globalAlpha = Aa * 0.4; ctx.fill();
        };
        if (!ouvVue) tentacules(A);
        // 2. Silhouette : enveloppe convexe des points de la cloche
        const nh = enveloppeConvexe(PX, PY, NPT, idx, hull);
        let cx = 0, cy = 0; for (let k = 0; k < nh; k++) { cx += PX[hull[k]]; cy += PY[hull[k]]; } cx /= nh; cy /= nh;
        let rmax = 1; for (let k = 0; k < nh; k++) rmax = Math.max(rmax, Math.hypot(PX[hull[k]] - cx, PY[hull[k]] - cy));
        ctx.beginPath(); ctx.moveTo(PX[hull[0]], PY[hull[0]]);
        for (let k = 1; k <= nh; k++) { const a = hull[k % nh], b = hull[(k + 1) % nh]; ctx.quadraticCurveTo(PX[a], PY[a], (PX[a] + PX[b]) / 2, (PY[a] + PY[b]) / 2); }
        ctx.closePath();
        ctx.save(); ctx.translate(cx, cy); ctx.scale(rmax, rmax); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.85; ctx.stroke();
        // 3. Méridiens (kinéties) et parallèles : arrière pâles, avant nets
        const reseau = (devant) => {
          ctx.beginPath();
          for (let m = 0; m < NM; m++) for (let j = 0; j < NU - 1; j++) {
            const k = m * NU + j; if ((PZ[k] + PZ[k + 1] >= 0) !== devant) continue;
            ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k + 1], PY[k + 1]);
          }
          for (let j = 3; j < 4; j++) for (let m = 0; m < NM; m++) {
            const k = m * NU + j, k2 = ((m + 1) % NM) * NU + j; if ((PZ[k] + PZ[k2] >= 0) !== devant) continue;
            ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k2], PY[k2]);
          }
        };
        reseau(false); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.05; ctx.lineWidth = 0.5; ctx.stroke();
        // 4. Ouverture : voile sombre et vélum, plus visibles quand elle nous regarde
        ctx.beginPath(); for (let k = 0; k <= NRIM; k++) { const i = k % NRIM; k ? ctx.lineTo(RX[i], RY[i]) : ctx.moveTo(RX[i], RY[i]); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (ouvVue ? 0.38 : 0.12) * Math.min(1, Math.abs(R[7]) * 2 + 0.2); ctx.fill();
        // 5. Manubrium (vu à travers la mésoglée), lèvres buccales
        ctx.beginPath(); ctx.moveTo(MX[0], MY[0]);
        for (let i = 1; i < NMN - 1; i++) ctx.quadraticCurveTo(MX[i], MY[i], (MX[i] + MX[i + 1]) / 2, (MY[i] + MY[i + 1]) / 2);
        ctx.lineTo(MX[NMN - 1], MY[NMN - 1]);
        ctx.strokeStyle = coul.sarcelle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 4.2 * e; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        for (let i = 2; i < NMN - 1; i += 2) { let tx = MX[i + 1] - MX[i - 1], ty = MY[i + 1] - MY[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1), k = 2 * e; ctx.moveTo(MX[i] - ty * l * k, MY[i] + tx * l * k); ctx.lineTo(MX[i] + ty * l * k, MY[i] - tx * l * k); }
        ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.5; ctx.stroke();
        {
          const ex = MX[NMN - 1], ey = MY[NMN - 1], ta = Math.atan2(ey - MY[NMN - 3], ex - MX[NMN - 3]);
          ctx.beginPath();
          for (let k = 0; k < 4; k++) {
            const q = ta + (k - 1.5) * 0.7, L = (4 + 1.5 * Math.sin(s.cph * 0.8 + k)) * e * (1 + 0.5 * s.harp);
            ctx.moveTo(ex, ey); ctx.quadraticCurveTo(ex + Math.cos(q) * L, ey + Math.sin(q) * L, ex + Math.cos(q + 0.9) * L * 1.1, ey + Math.sin(q + 0.9) * L * 1.1);
          }
          ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // 6. Vacuole étoilée à l'apex, tracée SUR le dôme (canaux le long des méridiens)
        const plein = borne(s.q, 0, 1) * (1 - Math.max(0, s.c)), u0 = 0.18, rr0 = s.Rb * 0.18 * (0.6 + 0.6 * plein);
        CR.proj(0, s.Hb * 0.36, 0); const vx0 = s.x + pj[0], vy0 = s.y + pj[1];
        ctx.beginPath();
        for (let k = 0; k < 7; k++) {
          const ph = k / 7 * TAU + s.ph + s.rotM, Lr = 0.12 + 0.42 * plein;
          let x0, y0;
          for (let st = 0; st <= 3; st++) {
            const u = u0 + Lr * st / 3, rr = s.Rb * Math.pow(Math.sin(Math.PI / 2 * u), 0.72) * 0.9, yy = s.Hb * (0.55 - Math.pow(u, 1.2)) - 1.5, tw = 0.25 * (0.5 - plein) * st / 3;
            CR.proj(rr * Math.cos(ph + tw), yy, rr * Math.sin(ph + tw) * OZ);
            const X = s.x + pj[0], Y = s.y + pj[1];
            if (st === 0) { ctx.moveTo(X, Y); x0 = X; y0 = Y; } else ctx.lineTo(X, Y);
          }
        }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 2.4; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(vx0, vy0, rr0 + 1, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.8; ctx.stroke();
        // 7. Réseau avant + bord épais (vélum) + peigne de cils au bord
        reseau(true); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.15; ctx.lineWidth = 0.5; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < NRIM; k++) { const k2 = (k + 1) % NRIM; if (RZ[k] + RZ[k2] < 0) continue; ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k2], RY[k2]); }
        ctx.globalAlpha = A * 0.08; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.6; ctx.lineWidth = 1.1; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < NRIM; k++) { const k2 = (k + 1) % NRIM; if (RZ[k] + RZ[k2] >= 0) continue; ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k2], RY[k2]); }
        ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.8; ctx.stroke();
        ctx.beginPath();
        const bxv = -R[1], byv = -R[4];
        for (let k = 0; k < NRIM; k++) {
          let rx = RX[k] - s.x, ry = RY[k] - s.y; const l = 1 / (Math.hypot(rx, ry) || 1); rx *= l; ry *= l;
          const ph = s.cph - k * 0.65, L = (2.4 + 1.3 * Math.sin(ph)) * e * (1 + 0.4 * s.exc);
          ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k] + (rx * 0.7 + bxv * 0.6) * L + Math.cos(ph) * 0.6, RY[k] + (ry * 0.7 + byv * 0.6) * L + Math.sin(ph) * 0.6);
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.45; ctx.stroke();
        // Reflet spéculaire
        {
          const hx = -0.25, hy = -0.4, hz = 0.88, n0 = R[0] * hx + R[3] * hy + R[6] * hz, n1 = R[1] * hx + R[4] * hy + R[7] * hz, n2 = R[2] * hx + R[5] * hy + R[8] * hz;
          if (n1 > -0.2) { const ph = Math.atan2(n2, n0); CR.proj(s.Rb * 0.6 * Math.cos(ph), s.Hb * (0.3 + 0.2 * n1), s.Rb * 0.6 * Math.sin(ph) * OZ);
            ctx.fillStyle = coul.perle; ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 5, 0, TAU); ctx.globalAlpha = A * 0.06; ctx.fill();
            ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 1.4, 0, TAU); ctx.globalAlpha = A * 0.4; ctx.fill(); }
        }
        if (ouvVue) tentacules(A);
        // 8. Lumières : le bord s'allume au tir ; impulsion apex → bord → tentacules ; gobage mauve
        ctx.globalCompositeOperation = 'lighter';
        const fl = A * P.alpha.biolum * s.flash;
        if (fl > 0.004) {
          ctx.beginPath(); for (let k = 0; k <= NRIM; k++) { const i = k % NRIM; k ? ctx.lineTo(RX[i], RY[i]) : ctx.moveTo(RX[i], RY[i]); }
          ctx.strokeStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = fl * 0.5; ctx.lineWidth = 0.9; ctx.stroke();
          ctx.beginPath(); ctx.arc(vx0, vy0, rr0 * 3, 0, TAU); ctx.fillStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.fill();
        }
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cc = s.lueur.pos / 0.6 * (NU + 1) - 0.5;
          for (let j = 0; j < NU - 1; j++) {
            const li = I * cloche(j + 0.5 - cc, j + 0.5 < cc ? 2.5 : 0.9); if (li < 0.004) continue;
            ctx.beginPath();
            for (let m = 0; m < NM; m++) { const k = m * NU + j; if (PZ[k] < -0.1) continue; ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k + 1], PY[k + 1]); }
            ctx.globalAlpha = li * 0.08; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = li * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
          }
          if (s.lueur.pos > 0.45) {
            const cf = (s.lueur.pos - 0.5) / 0.7 * (NTP + 3) - 1;
            for (let i = 0; i < NTP - 1; i++) {
              const li = I * cloche(i + 0.5 - cf, i + 0.5 < cf ? 4 : 1.3); if (li < 0.004) continue;
              ctx.beginPath(); for (let k = 0; k < NT; k++) { ctx.moveTo(s.tex[k][i], s.tey[k][i]); ctx.lineTo(s.tex[k][i + 1], s.tey[k][i + 1]); }
              ctx.globalAlpha = li * 0.13; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = li * 0.7; ctx.lineWidth = 0.8; ctx.stroke();
            }
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(vx0, vy0, (6 + 12 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.22 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(vx0, vy0, rr0 * (0.8 + 0.6 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.moveTo(MX[0], MY[0]); for (let i = 1; i < NMN; i++) ctx.lineTo(MX[i], MY[i]);
          ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.45 * s.gobe; ctx.lineWidth = 1.6; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     8. BRAISE — tore à éversion, fourrure de cils incandescents
        (étage 3 : Chœur × Culbute ; greffe : pli de planaire 91368, réf. lumière 49248)
     Le Chœur s'est refermé en tore : sa peau tourne sans fin autour du tube (éversion),
     passe par le trou et ressort dehors — un tapis roulant qui la propulse le long de son
     axe. Les dix cellules du Chœur, prises dans la peau, font ce tour : on lit la nage en
     les suivant. L'axe est celui d'un corps rigide (Culbute) : elle s'oriente, se retourne
     en jouant. Pour saisir, elle se plie en V comme une planaire et referme le tore sur la
     proie ; de temps à autre elle s'étrangle en 8 (souvenir de la division) puis se rouvre.
     ===================================================================== */
  function creerBraise() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NTH = 40, NPS = 10, NCELL = 10, NE = 18;
    const CR = corpsRigide(1, 1.18, 1.95), R = CR.R, pj = CR.pj, w = CR.w;
    const CX = new Float32Array(NTH), CY = new Float32Array(NTH), OX = new Float32Array(NTH), OY = new Float32Array(NTH), IX = new Float32Array(NTH), IY = new Float32Array(NTH);
    const NC3 = NTH * NPS;
    const B0 = new Float32Array(NC3 * 2), B1 = new Float32Array(NC3 * 2), BM = new Float32Array(NC3 * 2), BZ = new Float32Array(NC3), BG = new Float32Array(NC3);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const c = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      c.addColorStop(0, rgba(P.perle, 0.12)); c.addColorStop(0.55, rgba(P.sarcelle, 0.14));
      c.addColorStop(0.86, rgba(P.aqua, 0.2)); c.addColorStop(0.97, rgba(P.perle, 0.34)); c.addColorStop(1, rgba(P.perle, 0));
      return c;
    });
    const p3 = new Float64Array(6);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    // Point du tore (repère corps, axe = e3) : anneau étranglé, rayon de tube, pli en V
    function point(th, ps, rOff) {
      const R0 = s.R0 * (1 - 0.88 * s.pin * Math.pow(Math.sin(th), 2)) * (1 + 0.05 * Math.sin(3 * th + t * 0.9 + s.ph));
      const ct = Math.cos(th), st = Math.sin(th), r = s.r * (1 + 0.12 * s.puls * Math.cos(ps)) + rOff;
      const ex = ct, ey = st;                                         // radial dans le plan
      let x = R0 * ct + r * Math.cos(ps) * ex, y = R0 * st * (1 - 0.12 * s.pin) + r * Math.cos(ps) * ey, z = r * Math.sin(ps) * (1 + 0.18 * s.vit);
      let nx = Math.cos(ps) * ex, ny = Math.cos(ps) * ey, nz = Math.sin(ps);
      if (s.pli > 0.002) {                                            // pli : chaque moitié pivote autour de l'axe x
        const a = s.pli * Math.tanh(y / 7), ca = Math.cos(a), sa = Math.sin(a);
        const y2 = y * ca - z * sa, z2 = y * sa + z * ca; y = y2; z = z2;
        const ny2 = ny * ca - nz * sa, nz2 = ny * sa + nz * ca; ny = ny2; nz = nz2;
      }
      p3[0] = x; p3[1] = y; p3[2] = z; p3[3] = nx; p3[4] = ny; p3[5] = nz;
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xb4a1);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.66 : 0.34);
        CR.init(r() * TAU, 0.9 + r() * 0.5);
        w[0] = 0.1; w[1] = 0.1; w[2] = 0.6;
        s = { hx, hy, x: hx + (r() - 0.5) * 50, y: hy + (r() - 0.5) * 50, vx: 0, vy: 0, ph: r() * TAU, e: 0.95 + 0.1 * r(),
          R0: 23, r: 8.5, flux: 0, fv: 1, puls: 0, vit: 0, pin: 0, pli: 0, pliC: 0, etat: 0, tEtat: 6 + r() * 6, herisse: 0, glow: 0.4, onde: 0,
          exc: 0, gobe: 0, cph: 0, lueur: lueurNeuve(r), g: 0, gx: 0, gy: 0, spin: 0.5, kA: 0, kD: 0, kick: 0, tilt: 0.75, rev: 1,
          cells: [], braises: [], eb: 0, ei: 0 };
        for (let i = 0; i < NCELL; i++) s.cells.push({ th: i / NCELL * TAU + r() * 0.2, ps: r() * TAU, ph: r() * TAU, k: 0.85 + r() * 0.3, ambre: r() < 0.3 });
        for (let i = 0; i < NE; i++) s.braises.push({ x: 0, y: 0, vx: 0, vy: 0, vie: 0, r: 0.6 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; s.pliC = 1.2; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 32 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 190) - s.exc) * Math.min(1, h * 2.5));
        const pon = RG.part && RG.part.on, dP = pon ? Math.hypot(RG.part.x - s.x, RG.part.y - s.y) : 1e9;
        // [débit d'éversion, spin roue, kick (culbutes), kA, kD, hérissement, éclat, pli, inclinaison]
        let m = [(1.1 + 1.6 * energy) * (0.55 + 0.45 * RG.vit), 0.5, 0.05, s.g ? 2.5 * s.g : 0, s.g ? 1.4 : 0, 0, 0.5 + 0.35 * energy, 0, 0.75];
        if (e > 0.01) {
          let b;
          if (md === 'cont') b = [0.7, 0.25, 0.01, 3.5, 2.4, 0, 0.45, 0, 1.15];       // se présente de face : le trou regarde
          else if (md === 'actif') b = [2.4, 0.4, 1.1, 0.6, 0, 0.2, 0.75, 0, 0.6];      // se retourne en jouant
          else if (md === 'agr') b = [2.9, 0.2, 0.02, 7, 2.6, 0.1, 1, borne(1.6 - dP / 55, 0, 1) * 1.05, 0.45];
          else if (md === 'suit') b = [1.3, 0.4, 0.04, 3, 1.6, 0, 0.5, 0, 0.8];
          else if (md === 'evite') b = [3.2, 2.4, 0.5, 4, 0.6, 1, 0.9, 0, 0.3];          // fourrure hérissée, roue rapide
          else b = [1.6, 1.4, 0.1, 3, 1.2, 0.2, 0.6, 0, 0.6];
          for (let k = 0; k < 9; k++) m[k] = melange(m[k], b[k], e);
        }
        const kk = Math.min(1, h * 2);
        s.fv += (m[0] - s.fv) * kk; s.spin += (m[1] - s.spin) * kk; s.kick += (m[2] - s.kick) * kk; s.kA += (m[3] - s.kA) * kk; s.kD += (m[4] - s.kD) * kk;
        s.herisse += (m[5] - s.herisse) * kk; s.glow += (m[6] - s.glow) * kk; s.tilt += (m[8] - s.tilt) * kk;
        s.pliC = Math.max(m[7], s.pliC - h * 0.5);
        s.pli += (s.pliC - s.pli) * Math.min(1, h * 3.2);
        // Étranglement en 8 (division avortée du Chœur), suspendu quand la particule capte l'attention
        s.tEtat -= h * (e > 0.35 ? 0 : 1);
        if (s.etat === 0 && s.tEtat <= 0) { s.etat = 1; s.tEtat = 2.4; }
        else if (s.etat === 1) { s.pin = Math.min(1, s.pin + h / 2.4); if (s.tEtat <= 0) { s.etat = 2; s.tEtat = 1.4; } }
        else if (s.etat === 2 && s.tEtat <= 0) { s.etat = 3; }
        else if (s.etat === 3) { s.pin = Math.max(0, s.pin - h / 2.8); if (s.pin <= 0) { s.etat = 0; s.tEtat = 11 + 4 * Math.sin(t + s.ph) ** 2; } }
        if (e > 0.35 && s.etat === 1) s.etat = 3;
        // Orientation : l'axe vise la cible, incliné vers l'observateur (on voit le trou)
        let Dx, Dy;
        if (s.g) { Dx = s.gx - s.x; Dy = s.gy - s.y; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 160), a = Math.atan2(ecY, ecX) * loin + (1 - loin) * (Math.sin(t * 0.11 + s.ph) * 2.2 + s.ph); Dx = Math.cos(a); Dy = Math.sin(a); }
        if (md === 'cont' && pon && e > 0.2) { Dx = melange(Dx / (Math.hypot(Dx, Dy) || 1), RG.part.x - s.x, 0.5 * e); Dy = melange(Dy / (Math.hypot(Dx, Dy) || 1), RG.part.y - s.y, 0.5 * e); }
        const Dl = Math.hypot(Dx, Dy) || 1, ct = Math.cos(s.tilt), st = Math.sin(s.tilt);
        CR.tau[0] = CR.tau[1] = CR.tau[2] = 0;
        if (s.kA > 0.05) CR.viser(2, Dx / Dl * ct, Dy / Dl * ct, st, s.kA, s.kD);
        else CR.viser(2, Math.cos(t * 0.2 + s.ph) * ct, Math.sin(t * 0.2 + s.ph) * ct, st, 0.6, 0.4);
        CR.tau[2] += (s.spin - w[2]) * 1.2;                             // roue : la colonie tourne sur elle-même
        CR.tau[1] += s.kick * 3 * Math.sin(t * 0.9 + s.ph);               // culbutes (axe intermédiaire)
        CR.tau[0] += s.kick * 2 * Math.cos(t * 0.7 + s.ph * 2);
        CR.avancer(h);
        // Éversion : la peau tourne autour du tube ; le débit pulse (onde du Chœur) et pousse le long de l'axe
        s.onde += h * (1.6 + 1.2 * energy + 2 * e);
        s.puls = 0.5 + 0.5 * Math.sin(s.onde * 2);
        const fl = s.fv * (0.7 + 0.5 * s.puls);
        s.flux += fl * h;
        s.vit = fl / 3;
        const ax = R[2], ay = R[5], pousse = fl * 11 * s.e * (1 - 0.6 * s.pli);
        const k2 = Math.min(1, h * 1.8);
        s.vx += (ax * pousse - s.vx) * k2; s.vy += (ay * pousse - s.vy) * k2;
        const f0 = flow(s.x, s.y);
        const nx = s.x + (s.vx + f0[0] * 0.35) * h, ny = s.y + (s.vy + f0[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) for (const b of s.braises) { b.x += jx; b.y += jy; }
        s.R0 = 23 * s.e * (1 - 0.06 * s.puls - 0.12 * s.herisse) ;
        s.r = 8.5 * s.e * (1 + 0.06 * s.puls);
        // Étincelles : se détachent de la fourrure à l'arrière et dérivent dans le sillage
        s.eb += h * (2 + 7 * s.glow * s.vit);
        while (s.eb >= 1) {
          s.eb -= 1; const b = s.braises[s.ei++ % NE];
          point(rl() * TAU, Math.PI * (0.6 + 0.8 * rl()), 3); CR.proj(p3[0], p3[1], p3[2]);
          b.x = s.x + pj[0]; b.y = s.y + pj[1]; b.vx = -ax * (8 + 10 * rl()) + (rl() - 0.5) * 6; b.vy = -ay * (8 + 10 * rl()) + (rl() - 0.5) * 6; b.vie = 1; b.r = 0.5 + 0.6 * rl();
        }
        for (const b of s.braises) {
          if (b.vie <= 0) continue;
          const f = flow(b.x, b.y), k = Math.exp(-1.6 * h);
          b.vx = b.vx * k + f[0] * 0.3 * h; b.vy = b.vy * k + f[1] * 0.3 * h; b.x += b.vx * h; b.y += b.vy * h; b.vie -= h / 1.6;
        }
        s.cph += h * (7 + 6 * energy + 10 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const e = s.e, G = degr(ctx);
        // Ligne centrale projetée + bords de silhouette (projection orthographique : décalage de ±r)
        for (let i = 0; i < NTH; i++) { point(i / NTH * TAU, 0, -s.r * (1 + 0.12 * s.puls)); CR.proj(p3[0], p3[1], p3[2]); CX[i] = s.x + pj[0]; CY[i] = s.y + pj[1]; }
        const rT = s.r;
        for (let i = 0; i < NTH; i++) {
          const a = (i + NTH - 1) % NTH, b = (i + 1) % NTH; let tx = CX[b] - CX[a], ty = CY[b] - CY[a]; const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
          OX[i] = CX[i] - ty * rT; OY[i] = CY[i] + tx * rT; IX[i] = CX[i] + ty * rT; IY[i] = CY[i] - tx * rT;
        }
        // Le sens « extérieur » dépend du sens de parcours : on garde la courbe la plus longue comme bord externe
        let lo = 0, li = 0; for (let i = 0; i < NTH; i++) { const j = (i + 1) % NTH; lo += Math.hypot(OX[j] - OX[i], OY[j] - OY[i]); li += Math.hypot(IX[j] - IX[i], IY[j] - IY[i]); }
        const ext = lo >= li, EXx = ext ? OX : IX, EXy = ext ? OY : IY, INx = ext ? IX : OX, INy = ext ? IY : OY;
        const trou = borne((Math.abs(R[8]) * s.R0 * (1 - 0.5 * s.pin) - rT * 1.05) / 6, 0, 1) * (1 - 0.6 * s.pli);
        // Fourrure : base et pointe de chaque cil (penchés contre le défilement de la peau)
        let n = 0;
        const L0 = 3.6 * e, flx = s.flux * 1.0;
        for (let i = 0; i < NTH; i++) {
          const th = (i + 0.5 * (i % 2)) / NTH * TAU;
          for (let k = 0; k < NPS; k++, n++) {
            const ps = k / NPS * TAU + flx + (i % 2) * 0.39;
            point(th, ps, 0);
            const x = p3[0], y = p3[1], z = p3[2], nx = p3[3], ny = p3[4], nz = p3[5];
            const ph = s.cph - k * 0.9 - i * 0.25, L = L0 * (1 + 0.28 * Math.sin(ph)) * (1 + 0.7 * s.herisse) * (1 + 0.25 * s.exc);
            const pente = (0.9 - 0.7 * s.herisse) * (0.4 + 0.6 * Math.min(1, s.vit)) + 0.3 * Math.cos(ph);
            // tangente poloïdale (sens du défilement)
            const tx = -Math.sin(ps) * Math.cos(th), ty = -Math.sin(ps) * Math.sin(th), tz = Math.cos(ps);
            CR.proj(x + nx * 0.6, y + ny * 0.6, z + nz * 0.6); B0[n * 2] = s.x + pj[0]; B0[n * 2 + 1] = s.y + pj[1];
            CR.proj(x + nx * (0.6 + L * 0.6) - tx * L * pente * 0.15, y + ny * (0.6 + L * 0.6) - ty * L * pente * 0.15, z + nz * (0.6 + L * 0.6) - tz * L * pente * 0.15);
            BM[n * 2] = s.x + pj[0]; BM[n * 2 + 1] = s.y + pj[1];
            CR.proj(x + nx * (0.6 + L) - tx * L * pente, y + ny * (0.6 + L) - ty * L * pente, z + nz * (0.6 + L) - tz * L * pente);
            B1[n * 2] = s.x + pj[0]; B1[n * 2 + 1] = s.y + pj[1];
            BZ[n] = R[6] * nx + R[7] * ny + R[8] * nz;
            // éclat : l'onde fait le tour du tore (θ), plus vive côté extérieur
            BG[n] = s.glow * (0.45 + 0.55 * Math.pow(0.5 + 0.5 * Math.cos(th - s.onde * 1.3), 3)) * (0.7 + 0.3 * Math.cos(ps));
          }
        }
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Étincelles du sillage
        ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = coul.ambre;
        for (const b of s.braises) { if (b.vie <= 0) continue; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * (0.6 + 0.4 * b.vie), 0, TAU); ctx.globalAlpha = A * 0.55 * b.vie * b.vie * s.glow; ctx.fill(); }
        ctx.globalCompositeOperation = 'source-over';
        // 2. Fourrure arrière (sous le tube)
        const fourrure = (devant, Aa) => {
          ctx.beginPath();
          for (let q = 0; q < NC3; q++) { if ((BZ[q] >= 0) !== devant) continue; ctx.moveTo(B0[q * 2], B0[q * 2 + 1]); ctx.quadraticCurveTo(BM[q * 2], BM[q * 2 + 1], B1[q * 2], B1[q * 2 + 1]); }
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Aa * 0.16; ctx.lineWidth = 0.45; ctx.stroke();
          // pointes incandescentes, en trois paliers d'éclat
          ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = coul.ambre;
          for (let bin = 0; bin < 3; bin++) {
            const lo2 = bin / 3, hi2 = (bin + 1) / 3; ctx.beginPath();
            for (let q = 0; q < NC3; q++) {
              if ((BZ[q] >= 0) !== devant) continue; const g = BG[q]; if (g < lo2 || g >= hi2 && bin < 2) continue;
              ctx.moveTo(BM[q * 2], BM[q * 2 + 1]); ctx.lineTo(B1[q * 2], B1[q * 2 + 1]);
            }
            const gg = (bin + 0.5) / 3;
            ctx.globalAlpha = Aa * 0.07 * gg; ctx.lineWidth = 2.6; ctx.stroke();
            ctx.globalAlpha = Aa * (0.22 + 0.6 * gg); ctx.lineWidth = 0.6; ctx.stroke();
          }
          ctx.globalCompositeOperation = 'source-over';
        };
        // aura : la fourrure rougeoie comme un halo autour du tube
        ctx.globalCompositeOperation = 'lighter';
        ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
        ctx.strokeStyle = coul.ambre; ctx.globalAlpha = A * 0.035 * s.glow; ctx.lineWidth = rT * 2 + 14; ctx.stroke();
        ctx.globalAlpha = A * 0.05 * s.glow; ctx.lineWidth = rT * 2 + 6; ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';
        fourrure(false, A * 0.5);
        // 3. Tube : un seul trait épais le long de la ligne centrale = silhouette exacte du tore
        ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
        ctx.strokeStyle = coul.sarcelle; ctx.globalAlpha = A * 0.34; ctx.lineWidth = rT * 2; ctx.stroke();
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.25; ctx.lineWidth = rT * 1.1; ctx.stroke();
        // modelé : reflet décalé vers la lumière
        ctx.save(); ctx.translate(-rT * 0.32, -rT * 0.38);
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = rT * 0.7; ctx.stroke(); ctx.restore();
        // volume : l'intérieur du tube (côté trou) plonge dans l'ombre, l'extérieur prend la lumière
        ctx.beginPath(); for (let i = 0; i <= NTH; i++) { const j = i % NTH, x = (CX[j] + INx[j]) / 2, y = (CY[j] + INy[j]) / 2; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = rT * 0.9; ctx.stroke();
        ctx.beginPath(); for (let i = 0; i <= NTH; i++) { const j = i % NTH, x = CX[j] * 0.3 + EXx[j] * 0.7, y = CY[j] * 0.3 + EXy[j] * 0.7; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.1; ctx.lineWidth = rT * 0.45; ctx.stroke();
        // bords : externe net, interne seulement si le trou se voit
        ctx.beginPath(); ctx.moveTo(EXx[0], EXy[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(EXx[i], EXy[i]); ctx.closePath();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.8; ctx.stroke();
        if (trou > 0.02) {
          ctx.beginPath(); ctx.moveTo(INx[0], INy[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(INx[i], INy[i]); ctx.closePath();
          ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.28 * trou; ctx.fill();
          ctx.globalAlpha = A * 0.4 * trou; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // anneaux poloïdaux : la peau défile (on voit le tapis roulant)
        ctx.beginPath();
        for (let i = 0; i < NTH; i += 3) {
          const th = i / NTH * TAU; let first = true;
          for (let k = 0; k <= 10; k++) {
            const ps = k / 10 * TAU; point(th, ps, 0.2);
            const nz = R[6] * p3[3] + R[7] * p3[4] + R[8] * p3[5]; CR.proj(p3[0], p3[1], p3[2]);
            if (nz < 0) { first = true; continue; }
            first ? ctx.moveTo(s.x + pj[0], s.y + pj[1]) : ctx.lineTo(s.x + pj[0], s.y + pj[1]); first = false;
          }
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.13; ctx.lineWidth = 0.5; ctx.stroke();
        // 4. Les cellules du Chœur, prises dans la peau, font le tour du tube
        for (let c = 0; c < NCELL; c++) {
          const ce = s.cells[c], ps = ce.ps + s.flux;
          point(ce.th, ps, 0.4); const nz = R[6] * p3[3] + R[7] * p3[4] + R[8] * p3[5];
          CR.proj(p3[0], p3[1], p3[2]); const x = s.x + pj[0], y = s.y + pj[1];
          point(ce.th, ps + 0.25, 0.4); CR.proj(p3[0], p3[1], p3[2]);
          const ang = Math.atan2(s.y + pj[1] - y, s.x + pj[0] - x), fac = 0.35 + 0.65 * Math.abs(nz), Ac = A * (nz >= 0 ? 1 : 0.35);
          const a = 4 * ce.k * e, b = 2.7 * ce.k * e * fac;
          ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
          ctx.beginPath(); ctx.ellipse(0, 0, a, b, 0, 0, TAU);
          ctx.save(); ctx.scale(a, b); ctx.fillStyle = G; ctx.globalAlpha = Ac; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Ac * 0.55; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, 0, a * 0.78, b * 0.7, 0, 0, TAU); ctx.globalAlpha = Ac * 0.18; ctx.lineWidth = 0.5; ctx.stroke();
          ctx.beginPath(); ctx.arc(a * 0.25, 0, 1.2 * ce.k, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = Ac * 0.2; ctx.fill();
          ctx.beginPath(); ctx.arc(-a * 0.4, 0, 0.8, 0, TAU); ctx.fillStyle = ce.ambre ? coul.ambre : coul.perle; ctx.globalAlpha = Ac * 0.5; ctx.fill();
          ctx.restore();
        }
        // 5. Fourrure avant
        fourrure(true, A);
        // 6. Lumières : impulsion qui fait le tour du tore ; gobage mauve au cœur du pli
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const tete = s.lueur.pos * NTH * 1.2;
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NTH; i++) {
            const l2 = I * cloche(i - tete, i < tete ? 5 : 1.5); if (l2 < 0.004) continue; const j = (i + 1) % NTH;
            ctx.beginPath(); ctx.moveTo(EXx[i], EXy[i]); ctx.lineTo(EXx[j], EXy[j]);
            ctx.globalAlpha = l2 * 0.14; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = l2 * 0.65; ctx.lineWidth = 1; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.x, s.y, (6 + 18 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.2 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(s.x, s.y, (1.5 + 3 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
          ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.12 * s.gobe; ctx.lineWidth = rT * 1.4; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  const fabriques = { cells: creerCellules, filament: creerFilament, systole: creerSystole, culbute: creerCulbute, choeur: creerChoeur, cortege: creerCortege, volte: creerVolte, braise: creerBraise };
  const QXMOTIFS = {
    palette,
    noms: Object.keys(fabriques),
    create(nom) { return fabriques[nom](); }
  };
  for (const nom of QXMOTIFS.noms) QXMOTIFS[nom] = fabriques[nom]();
  QXMOTIFS.decor = creerDecor;
  racine.QXMOTIFS = QXMOTIFS;
})(typeof window !== 'undefined' ? window : globalThis);
/* =====================================================================
   QXCREA (R462) — « Évasion de Fluides » sur la VRAIE constellation.
   Chargé à la demande (jamais au démarrage). Dessine dans une surcouche
   alignée sur le canevas de QXCONST (même repère : px CSS de la carte),
   lit les positions réelles des nœuds et le tracé réel des liens.
   API : QXCREA.play({ inst, mode:'sequence'|'final', lang, sobre, fin(raison) })
         QXCREA.stop() ; QXCREA.etat ; QXCREA.stats()
   ===================================================================== */
(function (racine) {
'use strict';
const M = racine.QXMOTIFS;
const TAU = Math.PI * 2, H = 1 / 60, WW = 4000, WH = 4000;
function rng(seed){let s=seed>>>0;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
const clamp=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,u)=>a+(b-a)*u;
const sm=u=>{u=clamp(u,0,1);return u*u*(3-2*u);};
const eo=u=>{u=clamp(u,0,1);return 1-(1-u)*(1-u)*(1-u);};
const eback=u=>{u=clamp(u,0,1);const c=1.9;return 1+(c+1)*Math.pow(u-1,3)+c*Math.pow(u-1,2);};
const gss=(x,w)=>Math.exp(-(x*x)/(w*w));
const adiff=a=>a-Math.round(a/TAU)*TAU;
const rgba=(c,a)=>'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';
const CY=[127,216,230],PER=[226,240,244],LUE=[110,238,196],MAU=[182,154,232];
const F=11;
const TXT={
  fr:{flu:'Fluides',pousse:'Quelque chose pousse contre la membrane',une:'Elles s’échappent, une à une',touche:'Chaque monde touché devient fluide',
      cont:'La contagion gagne les derniers mondes',fin:'Les onze mondes sont colonisés',col:'Colonisés',passer:'Passer'},
  en:{flu:'Fluids',pousse:'Something presses against the membrane',une:'They escape, one by one',touche:'Every world they touch turns fluid',
      cont:'The contagion reaches the last worlds',fin:'All eleven worlds are colonised',col:'Colonised',passer:'Skip'}
};
/* créatures : motif, étiquette, instant de percée, monde cible (0 = Atelier … 10 = Quantique), durée du voyage, échelle, écart de sortie */
const CRE=[
 ['systole','Systole',5.6,10,2.5,.58,0],
 ['cells','Paramécie',8.9,7,4.4,.52,-.42],
 ['filament','Filament',11.1,1,9.2,.5,.34],
 ['culbute','Culbute',11.65,9,3.4,.56,-.18],
 ['choeur','Chœur',14.2,4,6.8,.48,.42],
 ['cortege','Cortège',16.4,0,9.4,.5,-.5],
 ['volte','Volte',16.95,5,6.2,.6,.16],
 ['braise','Braise',19.1,2,7.2,.56,-.3]
];
const CONT=[[3,[2,4],27.2,2],[6,[7,5],27.75,7],[8,[9,7],28.3,9]];
const T0=1.6,T_FIN=33.2;
/* gouverneur : [plafond de particules, DPR max, volutes, décor des créatures, sillages] */
const NIVQ=[[420,2,1,1,1],[260,1.5,0,1,1],[150,1,0,0,1],[90,1,0,0,0]];

function mkCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function mkGlow(c){const s=96,k=mkCanvas(s,s),g=k.getContext('2d'),r=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);
  r.addColorStop(0,rgba(c,1));r.addColorStop(.18,rgba(c,.55));r.addColorStop(.45,rgba(c,.16));r.addColorStop(1,rgba(c,0));g.fillStyle=r;g.fillRect(0,0,s,s);return k;}
function mkRing(c){const s=128,k=mkCanvas(s,s),g=k.getContext('2d'),r=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);
  r.addColorStop(0,rgba(c,0));r.addColorStop(.36,rgba(c,0));r.addColorStop(.41,rgba(c,.55));r.addColorStop(.55,rgba(c,.18));r.addColorStop(1,rgba(c,0));g.fillStyle=r;g.fillRect(0,0,s,s);return k;}
let SPR=null;
function sprites(){ if(SPR)return SPR;
  const SPEC=(()=>{const s=64,k=mkCanvas(s,s),g=k.getContext('2d');g.translate(s/2,s/2);g.scale(1,.55);const r=g.createRadialGradient(0,0,0,0,0,s/2);
    r.addColorStop(0,'rgba(255,255,255,.95)');r.addColorStop(.35,'rgba(240,250,252,.35)');r.addColorStop(1,'rgba(240,250,252,0)');g.fillStyle=r;g.beginPath();g.arc(0,0,s/2,0,TAU);g.fill();return k;})();
  SPR={SPEC,RCY:mkRing(CY),cy:mkGlow(CY),pe:mkGlow(PER),lu:mkGlow(LUE),ma:mkGlow(MAU),dark:mkGlow([2,6,11])};return SPR;}
function lsGet(k){try{return racine.localStorage.getItem(k);}catch(e){return null;}}
function reduitOS(){try{return !!(racine.matchMedia&&racine.matchMedia('(prefers-reduced-motion: reduce)').matches);}catch(e){return false;}}

let style=false;
function poserStyle(){ if(style)return; style=true; const s=document.createElement('style'); s.textContent=`
.qxc-cv{position:absolute;left:0;top:0;pointer-events:none}
.qxc-prise{position:absolute;inset:0;pointer-events:auto;background:transparent;-webkit-tap-highlight-color:transparent}
.qxc-hud{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 39px);text-align:center;pointer-events:none;z-index:3;transition:opacity .5s}
.qxc-leg{margin:0 auto;max-width:320px;min-height:17px;font-size:12.5px;line-height:1.35;color:#C9D8DE;letter-spacing:.01em;transition:opacity .32s,transform .32s;text-shadow:0 0 10px rgba(3,8,13,.9)}
.qxc-leg.fl{color:#BFF0F4}
.qxc-cpt{margin:5px auto 0;font-size:9px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:rgba(159,230,238,.85);opacity:0;transition:opacity .6s}
.qxc-j{display:block;width:84px;height:1.5px;margin:5px auto 0;background:rgba(159,230,238,.14);position:relative;overflow:hidden}
.qxc-j i{position:absolute;left:0;top:0;bottom:0;width:0;background:rgba(159,230,238,.85);transition:width .5s}
.qxc-passer{position:absolute;right:14px;bottom:calc(env(safe-area-inset-bottom,0px) + 18px);z-index:4;min-height:34px;padding:0 15px;border-radius:999px;
  border:1px solid rgba(234,246,255,.2);background:rgba(10,14,26,.5);color:rgba(234,246,255,.82);font:inherit;font-size:12px;letter-spacing:.08em;cursor:pointer;
  -webkit-tap-highlight-color:transparent;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);transition:opacity .4s}
.qxc-sous{transition:opacity .4s}
`; document.head.appendChild(s); }

let cur=null;

function Scene(o){
  const inst=o.inst, R0=inst.racine, LG=TXT[o.lang==='en'?'en':'fr'];
  const sobre=!!o.sobre||reduitOS();
  let mode=o.mode==='final'?'final':(sobre?'abrege':'sequence');
  const S2=sprites();
  let detruit=false, raf=0, tPrev=0, acc=0, nImg=0;
  /* ---------- DOM ---------- */
  poserStyle();
  const cv=document.createElement('canvas');cv.className='qxc-cv';const ctx=cv.getContext('2d');
  inst.poser(cv);
  let prise=null,hud=null,leg=null,cpt=null,jau=null,bP=null,sous=R0.querySelector('.qxk-s');
  if(mode!=='final'){
    prise=document.createElement('div');prise.className='qxc-prise';prise.setAttribute('aria-hidden','true');inst.poser(prise);
    hud=document.createElement('div');hud.className='qxc-hud';hud.setAttribute('aria-live','polite');
    hud.innerHTML='<p class="qxc-leg"></p><p class="qxc-cpt"><span></span><b class="qxc-j"><i></i></b></p>';
    leg=hud.firstChild;cpt=hud.lastChild;jau=cpt.querySelector('i');R0.appendChild(hud);
    bP=document.createElement('button');bP.type='button';bP.className='qxc-passer';bP.textContent=LG.passer;R0.appendChild(bP);
    const passer=(ev)=>{if(ev){ev.preventDefault();ev.stopPropagation();}sauter();};
    bP.addEventListener('click',passer);prise.addEventListener('pointerdown',passer);
    if(sous){sous.classList.add('qxc-sous');sous.style.opacity='0';}
  }
  /* ---------- géométrie réelle ---------- */
  let geoV=-1,l=0,h=0,G=1,dpr=1,niv=mode==='final'?1:0;   // état final : d'emblée un cran plus léger
  const N=[],RBv=[],COL=[],NOMS=[],LK=[];let RF=34,GLW=[],RINGW=[],PCOL=[];
  const RB=i=>RBv[i];
  const GR={body:[],cyb:[],liq:[],lien:[],iri:null};
  function regeo(force){
    const g=inst.geo(); if(!g||!g.l||!g.P||!g.P[12])return false;
    if(g.v===geoV&&!force)return true;
    const prem=geoV<0; geoV=g.v; l=g.l; h=g.h;
    let som=0;for(let i=0;i<12;i++){const p=g.P[i+1];N[i]=[p.x,p.y];RBv[i]=p.R+7;if(i<11)som+=RBv[i];COL[i]=g.C[i+1]||CY;NOMS[i]=g.noms[i]||'';}
    G=som/11/21;RF=g.P[12].R+11;RBv[F]=RF;   // Fluides : un peu plus grande que son anneau, sans mordre sur son étiquette
    for(let i=0;i<11;i++)LK[i]=(g.liens[i+1]||[]).map(q=>[q[0],q[1]]);
    if(prem){GLW=COL.map(mkGlow);RINGW=COL.map(mkRing);PCOL=['rgb(127,216,230)','rgb(232,246,248)','rgb(110,238,196)','rgb(182,154,232)'].concat(COL.map(c=>'rgb('+c+')'));}
    tailleCanvas();mkDegrades();
    if(!prem){for(const e of E){const f=e.ch?e.s/e.ch.tot:0;e.ch=construireChemin(e.cible,e.aEx);e.s=f*e.ch.tot;e.kT=e.kT0*G;e.k0=e.kT;}
      for(const s of SEEDS){s.k=s.k1*G;s.k0=s.k;}}
    return true;
  }
  function tailleCanvas(){dpr=Math.min(NIVQ[niv][1],racine.devicePixelRatio||1,2);cv.width=Math.round(l*dpr);cv.height=Math.round(h*dpr);cv.style.width=l+'px';cv.style.height=h+'px';}
  function mkDegrades(){
    GR.body=[];GR.liq=[];GR.cyb=[];GR.lien=[];
    for(let i=0;i<12;i++){const r=RB(i),c=COL[i];
      let g=ctx.createRadialGradient(-r*.32,-r*.38,r*.05,0,0,r);
      g.addColorStop(0,rgba(c,0));g.addColorStop(.62,rgba(c,.03));g.addColorStop(.84,rgba(c,.12));g.addColorStop(.96,rgba(c,.3));g.addColorStop(1,rgba(c,.45));GR.body.push(g);
      g=ctx.createRadialGradient(-r*.32,-r*.38,r*.05,0,0,r);
      g.addColorStop(0,rgba(CY,.02));g.addColorStop(.7,rgba(CY,.08));g.addColorStop(1,rgba(CY,.32));GR.cyb.push(g);
      g=ctx.createLinearGradient(0,-r,0,r);g.addColorStop(0,rgba([60,160,175],.26));g.addColorStop(.55,rgba([20,80,96],.42));g.addColorStop(1,rgba([6,34,46],.62));GR.liq.push(g);
    }
    for(let i=0;i<11;i++){const a=N[i+1],b=N[i];const g=ctx.createLinearGradient(a[0],a[1],b[0],b[1]);g.addColorStop(0,rgba(CY,.95));g.addColorStop(.55,rgba([150,220,225],.7));g.addColorStop(1,rgba(COL[i],.85));GR.lien.push(g);}
    if(ctx.createConicGradient){const g=ctx.createConicGradient(0,0,0);
      g.addColorStop(0,'rgba(140,222,232,.95)');g.addColorStop(.16,'rgba(182,154,232,.85)');g.addColorStop(.3,'rgba(226,180,120,.45)');g.addColorStop(.42,'rgba(118,200,196,.8)');
      g.addColorStop(.58,'rgba(232,244,248,.95)');g.addColorStop(.72,'rgba(110,238,196,.7)');g.addColorStop(.86,'rgba(160,140,230,.7)');g.addColorStop(1,'rgba(140,222,232,.95)');GR.iri=g;}
    else GR.iri='rgba(170,220,230,.8)';
  }
  /* ---------- état ---------- */
  let passeF=false,R=rng(20261120),T=T0,souffle=0,assomb=0,flashEcran=0,niveauF=.9,fondu=1,tFinal=-1;
  const NP=i=>i===F?72:44;
  const PX=[],PY=[];for(let i=0;i<12;i++){PX.push(new Float32Array(NP(i)));PY.push(new Float32Array(NP(i)));}
  const B=[];for(let i=0;i<12;i++)B.push({pokes:[],glint:0,wob:0,colT:-1e9,lvl:0,flash:0,cicat:[],pulse:0,spT:R()*2});
  const lien=new Float32Array(11),lienRes=new Float32Array(11);
  const VAGUES=[],ANN=[],ECL=[],RAYS=[],GRAINES=[];
  let LEGT='';
  const NPM=420;
  const P={x:new Float32Array(NPM),y:new Float32Array(NPM),vx:new Float32Array(NPM),vy:new Float32Array(NPM),a:new Float32Array(NPM),v:new Float32Array(NPM),s:new Float32Array(NPM),k:new Uint8Array(NPM),c:new Uint8Array(NPM),l:new Uint8Array(NPM),ph:new Float32Array(NPM)};
  let pn=0;
  function emet(x,y,vx,vy,vie,s,k,c,l2){if(pn>=NIVQ[niv][0])return;const i=pn++;P.x[i]=x;P.y[i]=y;P.vx[i]=vx;P.vy[i]=vy;P.a[i]=0;P.v[i]=vie;P.s[i]=s;P.k[i]=k;P.c[i]=c;P.l[i]=l2;P.ph[i]=R()*TAU;}
  function gerbe(x,y,ang,ouv,n,v0,c,l2,vie){v0*=G;for(let j=0;j<n;j++){const a=ang+(R()-.5)*ouv,v=v0*(.25+R()*.9),r=R();
    emet(x,y,Math.cos(a)*v,Math.sin(a)*v,(vie||1)*(.5+R()*.9),r<.18?1.6:.7+R()*.9,r<.16?1:r<.42?2:0,R()<.3?1:c,l2);}}
  /* ---------- chemins le long des VRAIS liens ---------- */
  function horsDe(pts,i,d){return pts.filter(q=>Math.hypot(q[0]-N[i][0],q[1]-N[i][1])>d);}
  function construireChemin(c,aExit){
    const raw=[],seg=[];const f=N[F];
    const ex=Math.cos(aExit),ey=Math.sin(aExit);
    let prem=null;
    for(let i=10;i>=c;i--){
      let pts=LK[i].slice().reverse();                                  // du nœud i+1 vers le nœud i
      pts=horsDe(pts,i+1,i+1===F?RF+16*G:RB(i+1)+18*G);
      pts=horsDe(pts,i,i>c?RB(i)+18*G:RB(i)+1);
      if(!pts.length){const a=N[i+1],b=N[i];pts=[[lerp(a[0],b[0],.5),lerp(a[1],b[1],.5)]];}
      if(i===10){prem=pts;
        const p3=pts[0],q=pts[Math.min(1,pts.length-1)];let ux=q[0]-p3[0],uy=q[1]-p3[1];const ul=Math.hypot(ux,uy)||1;ux/=ul;uy/=ul;
        if(pts.length<2){ux=N[10][0]-f[0];uy=N[10][1]-f[1];const u2=Math.hypot(ux,uy)||1;ux/=u2;uy/=u2;}
        const p0=[f[0]+ex*(RF+9*G),f[1]+ey*(RF+9*G)],p1=[p0[0]+ex*16*G,p0[1]+ey*16*G],p2=[p3[0]-ux*14*G,p3[1]-uy*14*G];
        for(let j=0;j<24;j++){const u=j/24,v=1-u;raw.push([v*v*v*p0[0]+3*v*v*u*p1[0]+3*v*u*u*p2[0]+u*u*u*p3[0],v*v*v*p0[1]+3*v*v*u*p1[1]+3*v*u*u*p2[1]+u*u*u*p3[1]]);seg.push(10);}
      }
      for(const q of pts){raw.push(q);seg.push(i);}
      if(i>c){                                                         // contourne le nœud i par un arc
        const b=N[i],rr=RB(i)+8*G,last=raw[raw.length-1];
        let nxt=horsDe(LK[i-1].slice().reverse(),i,RB(i)+18*G);nxt=nxt.length?nxt[0]:N[i-1];
        const a1=Math.atan2(last[1]-b[1],last[0]-b[0]),a2=Math.atan2(nxt[1]-b[1],nxt[0]-b[0]);let da=adiff(a2-a1);
        if(Math.abs(Math.abs(da)-Math.PI)<.25)da=Math.PI*(i%2?1:-1);
        const na=Math.max(3,Math.ceil(Math.abs(da)/.16));
        for(let j=0;j<=na;j++){const q=a1+da*j/na;raw.push([b[0]+Math.cos(q)*rr,b[1]+Math.sin(q)*rr]);seg.push(j<na/2?i:i-1);}
      }
    }
    {const b=N[c],last=raw[raw.length-1];let ax=b[0]-last[0],ay=b[1]-last[1];const al=Math.hypot(ax,ay)||1;ax/=al;ay/=al;raw.push([b[0]-ax*(RB(c)+1),b[1]-ay*(RB(c)+1)]);seg.push(c);}
    let X=[],Y=[],S=[];
    for(let j=0;j<raw.length-1;j++){const a=raw[j],b=raw[j+1],ll=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.ceil(ll/2));
      for(let k=0;k<n;k++){X.push(a[0]+(b[0]-a[0])*k/n);Y.push(a[1]+(b[1]-a[1])*k/n);S.push(seg[j]);}}
    X.push(raw[raw.length-1][0]);Y.push(raw[raw.length-1][1]);S.push(c);
    for(let it=0;it<3;it++){const X2=X.slice(),Y2=Y.slice(),w=6;
      for(let j=1;j<X.length-1;j++){let sx=0,sy=0,n=0;for(let k=-w;k<=w;k++){const q=clamp(j+k,0,X.length-1);sx+=X[q];sy+=Y[q];n++;}const fz=Math.min(1,j/8,(X.length-1-j)/8);X2[j]=lerp(X[j],sx/n,fz);Y2[j]=lerp(Y[j],sy/n,fz);}X=X2;Y=Y2;}
    const L=new Float32Array(X.length);for(let j=1;j<X.length;j++)L[j]=L[j-1]+Math.hypot(X[j]-X[j-1],Y[j]-Y[j-1]);
    const lent=new Float32Array(X.length);
    for(let j=0;j<X.length;j++){let m=1;for(let i=c+1;i<=10;i++){const d=Math.hypot(X[j]-N[i][0],Y[j]-N[i][1])-RB(i);m=Math.min(m,1-.38*gss(d-6*G,16*G));}lent[j]=m;}
    return{X:Float32Array.from(X),Y:Float32Array.from(Y),L,S,lent,tot:L[L.length-1],c};
  }
  function idx(ch,s){s=clamp(s,0,ch.tot);let lo=0,hi=ch.L.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(ch.L[m]<s)lo=m;else hi=m;}return lo;}
  const _p=[0,0,0,0];
  function surChemin(ch,s){const j=idx(ch,s),j2=Math.min(j+1,ch.X.length-1),ll=(ch.L[j2]-ch.L[j])||1,u=clamp((s-ch.L[j])/ll,0,1);
    _p[0]=lerp(ch.X[j],ch.X[j2],u);_p[1]=lerp(ch.Y[j],ch.Y[j2],u);
    const ja=Math.max(0,j-3),jb=Math.min(ch.X.length-1,j+4);let tx=ch.X[jb]-ch.X[ja],ty=ch.Y[jb]-ch.Y[ja];const tl=Math.hypot(tx,ty)||1;_p[2]=tx/tl;_p[3]=ty/tl;return _p;}
  function profil(ch,s){const j=idx(ch,s);return (.42+.58*sm(s/(120*G)))*(1-.55*sm(1-(ch.tot-s)/(80*G)))*ch.lent[j];}
  /* polyligne réelle entre deux nœuds voisins (contagion) */
  function lienEntre(a,b){const i=Math.min(a,b);let pts=LK[i].slice();if(a>b)pts.reverse();
    pts=horsDe(horsDe(pts,a,RB(a)+2),b,RB(b)+1);if(pts.length<2)pts=[N[a],N[b]];
    const L=[0];for(let j=1;j<pts.length;j++)L.push(L[j-1]+Math.hypot(pts[j][0]-pts[j-1][0],pts[j][1]-pts[j-1][1]));return{pts,L,tot:L[L.length-1]};}
  function surLien(lk,u){const s=u*lk.tot;let j=0;while(j<lk.L.length-2&&lk.L[j+1]<s)j++;const ll=(lk.L[j+1]-lk.L[j])||1,f=clamp((s-lk.L[j])/ll,0,1);
    return[lerp(lk.pts[j][0],lk.pts[j+1][0],f),lerp(lk.pts[j][1],lk.pts[j+1][1],f)];}
  /* ---------- membranes ---------- */
  function poke(i,id,ang,d,w){const b=B[i];let p=null;for(const q of b.pokes)if(q.id===id){p=q;break;}
    if(!p){if(b.pokes.length>5)return;p={id,a:ang,d:0,v:0,w,drive:true};b.pokes.push(p);}p.a=ang;p.w=w;p.tgt=d;p.drive=true;p.held=true;}
  function relache(i,id,kick){for(const q of B[i].pokes)if(q.id===id){q.drive=false;q.held=false;q.v+=kick||0;}}
  function majBulles(){
    for(let i=0;i<12;i++){const b=B[i];
      for(let k=b.pokes.length-1;k>=0;k--){const p=b.pokes[k];
        if(p.drive){p.d+=(p.tgt-p.d)*Math.min(1,H*14);p.v=0;if(!p.held){p.drive=false;}p.held=false;}
        else{p.v+=(-320*p.d-6.5*p.v)*H;p.d+=p.v*H;if(Math.abs(p.d)<.04&&Math.abs(p.v)<.3)b.pokes.splice(k,1);}}
      b.glint=Math.max(0,b.glint-H*1.6);b.wob*=Math.exp(-H*1.1);b.flash=Math.max(0,b.flash-H*2.2);b.pulse*=Math.exp(-H*5);
      if(b.colT>-1e8)b.lvl=(mode==='final'?.4:.5)*eo((T-b.colT)/3.4);
    }
  }
  function forme(i,rev){
    const b=B[i],n=NP(i),r0=RB(i)*rev,X=PX[i],Y=PY[i];
    const br=1+.022*Math.sin(T*1.25+i*1.7)+.07*b.pulse+(i===F?.012*Math.sin(T*3.1):0);
    const w=.012+.05*b.wob;
    for(let k=0;k<n;k++){const q=k/n*TAU;let r=r0*br*(1+w*Math.sin(2*q+T*.9+i)+w*.8*Math.sin(3*q-T*1.3+i*2)+w*.5*Math.sin(5*q+T*2.1));
      for(const p of b.pokes){const x=adiff(q-p.a);r+=p.d*(.74*gss(x,p.w)+.26*gss(x,p.w*.42));}
      X[k]=Math.cos(q)*r;Y[k]=Math.sin(q)*r;}
  }
  function trace(i){const X=PX[i],Y=PY[i],n=X.length;ctx.beginPath();ctx.moveTo((X[n-1]+X[0])/2,(Y[n-1]+Y[0])/2);
    for(let k=0;k<n;k++){const k2=k+1<n?k+1:0;ctx.quadraticCurveTo(X[k],Y[k],(X[k]+X[k2])/2,(Y[k]+Y[k2])/2);}ctx.closePath();}
  /* ---------- créatures ---------- */
  const E=[];let SEEDS=[];
  const _o=[0,0,0,0],_o2=[0,0,0,0],_w=[0,0];
  function orbite(i,ph,rho,om,t,out){const a=om*t+ph,rr=rho*(1+.18*Math.sin(t*.7+ph*3));
    out[0]=N[i][0]+Math.cos(a)*rr;out[1]=N[i][1]+Math.sin(a)*rr*.72+(i===F?2*G:RB(i)*.14);
    const vx=-Math.sin(a)*om,vy=Math.cos(a)*om*.72;const ll=Math.hypot(vx,vy)||1;out[2]=vx/ll;out[3]=vy/ll;return out;}
  const rhoAq=e=>(8+3.3*(e.j%5))*RF/35;
  function versMonde(ob,x,y,out){out[0]=2000+(x-180)/ob.k0;out[1]=2000+(y-235)/ob.k0;return out;}
  function animer(ob,energie,g,dt){
    versMonde(ob,ob.qx,ob.qy,_w);
    ob.m.place(0,_w[0],_w[1]);
    ob.m.reglage({vit:ob.vit||1});ob.m.vise(0,_w[0]+ob.hx*320,_w[1]+ob.hy*320,g);
    ob.m.update(dt,ob.flow,energie);
    if(ob.dec&&NIVQ[niv][3]){ob.geo=ob.m.geo();const p=ob.m.pos(0),v=ob.lp?Math.hypot(p[0]-ob.lp[0],p[1]-ob.lp[1])/dt:0;ob.lp=[p[0],p[1]];ob.dec.update(dt*(1+Math.min(4,v/90)),ob.flow,ob.geo);}
  }
  function preparer(ob,x,y,hx,hy,n){
    versMonde(ob,x,y,_w);const p=ob.m.pos(0),x0=p[0],y0=p[1];n=n||150;
    for(let k=0;k<n;k++){const u=Math.min(1,k/(n*.47));ob.m.place(0,lerp(x0,_w[0],u),lerp(y0,_w[1],u));ob.m.vise(0,_w[0]+hx*320,_w[1]+hy*320,2.6);ob.m.update(H,ob.flow,.4);
      if(ob.dec){ob.geo=ob.m.geo();ob.dec.update(H,ob.flow,ob.geo);}}
  }
  function creerCreatures(fin){
    E.length=0;
    CRE.forEach((c,j)=>{
      const m=M.create(c[0]);m.init(WW,WH,700+j*131,{quality:.8,n:1,slot:0});
      const e={m,nm:c[0],lab:c[1],te:c[2],cible:c[3],duree:c[4],kT0:c[5],kT:c[5]*G,aEx:Math.atan2(N[10][1]-N[F][1],N[10][0]-N[F][0])+c[6],j,
        etat:'aqua',s:0,k:c[5]*G*.3,qx:N[F][0],qy:N[F][1],hx:1,hy:0,flo:[0,0],dec:(c[0]==='cells'||c[0]==='filament')?M.decor():null,geo:null,
        hist:new Float32Array(80),hn:0,hi:0,tE:0,em:0,ph:j*.83,base:1,vit:1,clip:F};
      e.ch=construireChemin(e.cible,e.aEx);
      let t1=0;for(let s=0;s<e.ch.tot;s+=1)t1+=1/profil(e.ch,s);e.base=t1/e.duree;
      e.flow=()=>e.flo;e.k0=e.kT;
      E.push(e);
    });
    SEEDS=CONT.map((c,j)=>{const src=E.find(e=>e.cible===c[3]);const m=M.create(src.nm);m.init(WW,WH,1900+j*77,{quality:.6,n:1,slot:0});
      return{cible:c[0],src:c[1],tA:c[2],m,nm:src.nm,k1:src.kT0*.36,k:src.kT0*.36*G,qx:N[c[0]][0],qy:N[c[0]][1],hx:1,hy:0,flo:[0,0],dec:null,ph:j*2.1,fait:false,vit:1,j,flow:null};});
    for(const s of SEEDS){s.flow=()=>s.flo;s.k0=s.k;}
    if(fin){                                                            // état final : chacune dans son monde
      for(const e of E){e.etat='colon';e.clip=e.cible;e.k=e.kT*.6;orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);e.qx=_o[0];e.qy=_o[1];preparer(e,_o[0],_o[1],_o[2],_o[3],70);}
      for(const s of SEEDS){s.fait=true;s.tA=-10;orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);s.qx=_o[0];s.qy=_o[1];s.kk=s.k;preparer(s,_o[0],_o[1],_o[2],_o[3],70);}
    } else {
      for(const s of SEEDS)preparer(s,N[s.cible][0],N[s.cible][1],1,0);
      for(const e of E){const om=(e.j%2?-1:1)*(.42+.06*e.j);orbite(F,e.ph,rhoAq(e),om,1.95,_o);preparer(e,_o[0],_o[1],_o[2],_o[3]);}
    }
  }
  function piloter(e){
    const t=T;let qx,qy,hx,hy,k,v=0,clip=-1;
    const kAq=e.kT*.30,kIn=e.kT*.6;
    const om=(e.j%2?-1:1)*(.42+.06*e.j),rho=rhoAq(e);
    if(e.etat==='aqua'&&t>=e.te-1.5)e.etat='sortie';
    if(e.etat==='aqua'){orbite(F,e.ph,rho,om,t,_o);qx=_o[0];qy=_o[1];hx=_o[2];hy=_o[3];k=kAq;v=rho*Math.abs(om);clip=F;}
    else if(e.etat==='sortie'){
      const u=(t-(e.te-1.5))/1.5;orbite(F,e.ph,rho,om,t,_o);
      const ex=Math.cos(e.aEx),ey=Math.sin(e.aEx),f=N[F],g9=9*G;
      if(u<.62){const w=sm(u/.62);const tx=f[0]+ex*(RF-g9),ty=f[1]+ey*(RF-g9);qx=lerp(_o[0],tx,w);qy=lerp(_o[1],ty,w);
        const dx=tx-qx,dy=ty-qy;const ll=Math.hypot(dx,dy);if(ll>1){hx=dx/ll;hy=dy/ll;}else{hx=ex;hy=ey;}k=lerp(kAq,kAq*1.25,w);}
      else{const w=(u-.62)/.38,we=Math.pow(w,1.5);const rr=lerp(RF-g9,RF+g9,we);qx=f[0]+ex*rr;qy=f[1]+ey*rr;hx=ex;hy=ey;k=lerp(kAq*1.25,e.kT*.72,we);
        poke(F,'c'+e.j,e.aEx,Math.max(0,rr-RF+g9)*sm(w/.35)+.9*Math.sin(t*60)*w,.42-.14*w);
        qx+=Math.sin(t*47+e.j)*.5*w;qy+=Math.cos(t*43)*.5*w;}
      clip=F;v=30;
      if(t>=e.te){percee(e);}
    }
    else if(e.etat==='voyage'){
      const dt=t-e.te;const burst=150*G*Math.exp(-dt*3.2);
      const vv=e.base*profil(e.ch,e.s)+burst*(1-sm(e.s/(e.ch.tot*.6)));
      e.s+=vv*H;v=vv/G;
      const p=surChemin(e.ch,e.s);const amp=2.2*G*sm(e.s/(50*G))*sm((e.ch.tot-e.s)/(50*G));const nx=-p[3],ny=p[2];const fl=amp*Math.sin(e.s/G*.055+e.ph)+amp*.4*Math.sin(t*3.1+e.ph);
      qx=p[0]+nx*fl;qy=p[1]+ny*fl;
      const pa=surChemin(e.ch,e.s+10*G);hx=pa[2];hy=pa[3];
      k=lerp(e.kT*.72,e.kT,eo(dt/.7));
      const sg=e.ch.S[idx(e.ch,e.s)];if(sg<11){lien[sg]=1;lienRes[sg]=Math.max(lienRes[sg],.34);}
      for(let i=0;i<11;i++){if(i===e.cible)continue;const dx=qx-N[i][0],dy=qy-N[i][1],d=Math.hypot(dx,dy);
        if(d<RB(i)+16*G){poke(i,'p'+e.j,Math.atan2(dy,dx),-2.6*G*(1-clamp((d-RB(i)-4*G)/(12*G),0,1)),.5);B[i].glint=Math.max(B[i].glint,.55);B[i].wob=Math.max(B[i].wob,.35);}}
      e.em+=H*(26+v*.12);
      while(e.em>1){e.em--;const bx=qx-hx*9*k/.4+(R()-.5)*4,by=qy-hy*9*k/.4+(R()-.5)*4,r=R();
        emet(bx,by,-hx*10*G+(R()-.5)*14,-hy*10*G+(R()-.5)*14,.8+R()*1.1,r<.12?1.5:.6+R()*.8,r<.1?1:0,r<.35?1:r<.5?2:0,0);}
      if(e.s>=e.ch.tot-.5){e.etat='entree';e.tE=t;const q=surChemin(e.ch,e.ch.tot);e.ex=q[0];e.ey=q[1];e.ax=q[2];e.ay=q[3];e.ca=Math.atan2(e.ey-N[e.cible][1],e.ex-N[e.cible][0]);
        B[e.cible].glint=1;souffle=Math.max(souffle,.35);}
    }
    else if(e.etat==='entree'){
      const c=e.cible,u=t-e.tE,r=RB(c);
      if(u<.55){const w=sm(u/.55);const pen=r*.52*w;qx=e.ex+e.ax*pen;qy=e.ey+e.ay*pen;hx=e.ax;hy=e.ay;k=lerp(e.kT,e.kT*.66,w);
        poke(c,'e'+e.j,e.ca,-pen*.95,.42+.1*w);v=40;}
      else{
        if(!e.pop){entree(e);}
        const w=sm((u-.55)/1.05);orbite(c,e.ph,r*.36,(e.j%2?-1:1)*.5,t,_o);
        const sx=e.ex+e.ax*r*.52,sy=e.ey+e.ay*r*.52;qx=lerp(sx,_o[0],w);qy=lerp(sy,_o[1],w);
        hx=lerp(e.ax,_o[2],w);hy=lerp(e.ay,_o[3],w);const ll=Math.hypot(hx,hy)||1;hx/=ll;hy/=ll;k=lerp(e.kT*.66,kIn,eo((u-.55)/.8));clip=c;v=20;
        if(u>1.6)e.etat='colon';}
    }
    else{const c=e.cible;orbite(c,e.ph,RB(c)*.36,(e.j%2?-1:1)*.5,t,_o);qx=_o[0];qy=_o[1];hx=_o[2];hy=_o[3];k=kIn;clip=c;v=8;}
    e.qx=qx;e.qy=qy;e.hx=hx;e.hy=hy;e.k=k;e.clip=clip;
    const V=Math.min(40,v*.25);e.flo[0]=-hx*V;e.flo[1]=-hy*V;
    e.vit=e.etat==='voyage'?1.6:e.etat==='sortie'?1.5:1;
    if(e.etat==='voyage'){e.hist[e.hi*2]=qx;e.hist[e.hi*2+1]=qy;e.hi=(e.hi+1)%40;e.hn=Math.min(40,e.hn+1);}
    else if(e.hn>0)e.hn=Math.max(0,e.hn-1);
  }
  function percee(e){
    e.etat='voyage';e.s=0;
    const f=N[F],ex=Math.cos(e.aEx),ey=Math.sin(e.aEx),x=f[0]+ex*(RF+9*G),y=f[1]+ey*(RF+9*G);
    relache(F,'c'+e.j,-70);
    B[F].wob=1;B[F].flash=1;B[F].cicat.push({a:e.aEx,t:T,sd:e.j*7+3});
    gerbe(x,y,e.aEx,1.1,34,95,0,0,1.1);gerbe(x,y,e.aEx+Math.PI,2.2,14,50,1,1,.8);
    ANN.push({x,y,t:T,d:.8,r0:3,r1:34*G,c:CY,w:1.5},{x:f[0],y:f[1],t:T+.06,d:1.1,r0:RF+2,r1:RF+26*G,c:PER,w:.7});
    ECL.push({x,y,t:T,d:.55,s:70*G,g:S2.cy},{x,y,t:T,d:.25,s:34*G,g:S2.pe});
    RAYS.push({x,y,a:e.aEx,t:T,d:.5,sd:e.j});
    VAGUES.push({x:f[0],y:f[1],t:T,v:330*G,f:.9});
    souffle=1;flashEcran=.18;niveauF=Math.max(.5,niveauF-.05);
    legende(e.lab+'  →  '+NOMS[e.cible],1);
    try{Audio1.playSfx('colo_perce',1);}catch(_){}
  }
  function entree(e){
    e.pop=1;const c=e.cible,b=B[c];
    try{Audio1.playSfx('colo_entree',1,c);}catch(_){}
    relache(c,'e'+e.j,170);b.wob=1;b.flash=1;b.colT=T;b.glint=1;
    gerbe(e.ex,e.ey,e.ca,1.6,30,70,0,1,1);gerbe(N[c][0],N[c][1],0,TAU,22,34,4+c,1,1.2);
    ANN.push({x:N[c][0],y:N[c][1],t:T,d:1.1,r0:RB(c),r1:RB(c)+34*G,c:CY,w:1.4},{x:N[c][0],y:N[c][1],t:T+.12,d:.9,r0:RB(c)*.6,r1:RB(c)+8*G,c:COL[c],w:.7});
    ECL.push({x:N[c][0],y:N[c][1],t:T,d:.7,s:RB(c)*3.4,g:S2.cy});
    VAGUES.push({x:N[c][0],y:N[c][1],t:T,v:260*G,f:.5});
    souffle=Math.max(souffle,.6);compteur();
  }
  function majContagion(){
    for(const c of CONT){const tA=c[2],dur=1.5;
      for(let q=0;q<2;q++){const id=c[0]*10+q;let g=GRAINES.find(o2=>o2.id===id);
        if(!g&&T>=tA-dur){const lk=lienEntre(c[1][q],c[0]);const a=lk.pts[0],a2=lk.pts[Math.min(1,lk.pts.length-1)];
          g={id,lk,t0:tA-dur+q*.12,dur:dur-q*.12,x:a[0],y:a[1],lien:Math.min(c[0],c[1][q]),hist:[],fait:false};
          GRAINES.push(g);B[c[1][q]].pulse=1;gerbe(a[0],a[1],Math.atan2(a2[1]-a[1],a2[0]-a[0]),1.2,10,40,0,1,.8);}
        if(g&&!g.fait){const u=eo((T-g.t0)/g.dur),p=surLien(g.lk,u);g.x=p[0];g.y=p[1];lien[g.lien]=1;lienRes[g.lien]=Math.max(lienRes[g.lien],.34);
          g.hist.push(g.x,g.y);if(g.hist.length>36)g.hist.splice(0,2);
          if(R()<.7)emet(g.x+(R()-.5)*3,g.y+(R()-.5)*3,(R()-.5)*12,(R()-.5)*12,.7+R()*.6,.6+R()*.8,R()<.15?1:0,R()<.4?1:2,0);
          if(T>=g.t0+g.dur)g.fait=true;}}
      const s=SEEDS.find(o2=>o2.cible===c[0]);
      if(!s.fait&&T>=tA){s.fait=true;const b=B[c[0]];b.colT=T;b.wob=1;b.flash=1;b.glint=1;b.pokes.push({id:'z',a:-1.2,d:3*G,v:60,w:.6,drive:false});
        gerbe(N[c[0]][0],N[c[0]][1],0,TAU,30,48,0,1,1.1);ANN.push({x:N[c[0]][0],y:N[c[0]][1],t:T,d:1,r0:RB(c[0]),r1:RB(c[0])+30*G,c:CY,w:1.3});
        ECL.push({x:N[c[0]][0],y:N[c[0]][1],t:T,d:.6,s:60*G,g:S2.cy});souffle=Math.max(souffle,.4);VAGUES.push({x:N[c[0]][0],y:N[c[0]][1],t:T,v:240*G,f:.4});compteur();}
    }
  }
  function piloterSeed(s){if(!s.fait)return;const c=s.cible,u=T-s.tA;orbite(c,s.ph,RB(c)*.3,(s.j%2?1:-1)*.6,T,_o2);
    s.qx=_o2[0];s.qy=_o2[1];s.hx=_o2[2];s.hy=_o2[3];s.kk=lerp(s.k*.3,s.k,eo(u/1.2));s.flo[0]=0;s.flo[1]=0;}
  /* ---------- texte (DOM, au-dessus de l'en-tête de la carte) ---------- */
  function legende(t,fl){if(!leg||LEGT===t)return;LEGT=t;leg.style.opacity='0';leg.style.transform='translateY(4px)';
    setTimeout(()=>{if(detruit||LEGT!==t)return;leg.textContent=t;leg.classList.toggle('fl',!!fl);leg.style.opacity='1';leg.style.transform='none';},320);}
  function nCol(){let n=0;for(let i=0;i<11;i++)if(B[i].colT>-1e8)n++;return n;}
  function compteur(){if(!cpt)return;const n=nCol();cpt.firstChild.textContent=LG.col+'  '+n+' / 11';jau.style.width=(n/11*100).toFixed(1)+'%';}
  function scenario(){
    if(T<4.2)legende(LG.flu);
    else if(T<5.6)legende(LG.pousse);
    else if(T>=7.6&&T<8.9&&LEGT.indexOf('→')>=0)legende(LG.une);
    else if(T>=21&&T<26.9&&LEGT.indexOf('→')>=0&&T-19.1>2.2)legende(LG.touche);
    else if(T>=26.9&&T<29.6)legende(LG.cont);
    else if(T>=29.6){legende(LG.fin);if(!legende.fs){legende.fs=1;try{Audio1.playSfx('colo_fin',1);}catch(_){}}}
    if(cpt&&T>2.3&&cpt.style.opacity!=='1'){cpt.style.opacity='1';compteur();}
  }
  /* ---------- pas de simulation ---------- */
  function pas(){
    T+=H;
    scenario();
    for(let i=0;i<11;i++){lien[i]=Math.max(lienRes[i],lien[i]-H*.55);}
    if(T<2.2){lien[10]=1;lienRes[10]=.22;}
    for(const e of E){if(T<1.95)continue;piloter(e);animer(e,e.etat==='voyage'?.7:.45,2.6,H);}
    majContagion();
    for(const s of SEEDS){if(!s.fait)continue;piloterSeed(s);animer(s,.4,2.4,H);}
    if(T>=2.1&&!B[F].rev){B[F].rev=1;const f=N[F];
      ECL.push({x:f[0],y:f[1],t:T,d:1,s:190*G,g:S2.cy},{x:f[0],y:f[1],t:T,d:.4,s:70*G,g:S2.pe});
      ANN.push({x:f[0],y:f[1],t:T,d:1.4,r0:8,r1:120*G,c:CY,w:2},{x:f[0],y:f[1],t:T+.12,d:1.6,r0:RF,r1:RF+50*G,c:PER,w:1});
      gerbe(f[0],f[1],0,TAU,90,120,0,1,1.4);VAGUES.push({x:f[0],y:f[1],t:T,v:300*G,f:1});souffle=1;flashEcran=.22;B[F].wob=1;
      for(let i=0;i<11;i++)B[i].wob=Math.max(B[i].wob,.3);}
    for(const e of E){for(const db of (e.j===0?[1.75,1.3,.85,.45]:[1.25,.8,.42])){const tb=e.te-db;if(T>=tb&&T-H<tb){B[F].pulse=Math.max(B[F].pulse,e.j===0?.9:.7);B[F].glint=1;
      ECL.push({x:N[F][0],y:N[F][1],t:T,d:.45,s:RF*3.6,g:S2.cy});}}}
    let tens=0;for(const e of E)if(e.etat==='sortie'){const u=(T-(e.te-1.5))/1.5;tens=Math.max(tens,sm((u-.3)/.7));}
    assomb+=(tens*.2-assomb)*Math.min(1,H*4);
    communs(H);
    for(const v of VAGUES){const rr=(T-v.t)*v.v,a=v.f*Math.exp(-(T-v.t)*1.1);for(let i=0;i<12;i++){const d=Math.hypot(N[i][0]-v.x,N[i][1]-v.y);const g=a*gss(d-rr,26*G);if(g>B[i].glint)B[i].glint=g;}}
  }
  function communs(dt){
    majBulles();
    for(let i=0;i<pn;i++){P.a[i]+=dt;if(P.a[i]>=P.v[i]){pn--;for(const k in P)P[k][i]=P[k][pn];i--;continue;}
      const kk=P.k[i],dr=kk===2?.93:.965;P.vx[i]*=dr;P.vy[i]*=dr;if(kk===3){P.vy[i]-=dt*6;P.vx[i]+=Math.sin(P.a[i]*3+P.ph[i])*dt*8;}
      P.x[i]+=P.vx[i]*dt;P.y[i]+=P.vy[i]*dt;}
    for(let i=0;i<12;i++){const b=B[i];if(b.colT<-1e8||T-b.colT<2)continue;b.spT-=dt;
      if(b.spT<=0){b.spT=(mode==='final'?2.4:1.1)+R()*2.2;const a=-Math.PI/2+(R()-.5)*1.4,r=RB(i);emet(N[i][0]+Math.cos(a)*r,N[i][1]+Math.sin(a)*r,Math.cos(a)*8,Math.sin(a)*8-4,2.4+R()*1.6,1.1+R()*.8,3,R()<.5?0:2,1);}}
    souffle*=Math.exp(-dt*2.2);flashEcran=Math.max(0,flashEcran-dt*.9);
    for(let k=VAGUES.length-1;k>=0;k--)if(T-VAGUES[k].t>2.2)VAGUES.splice(k,1);
    for(let k=ANN.length-1;k>=0;k--)if(T-ANN[k].t>ANN[k].d)ANN.splice(k,1);
    for(let k=ECL.length-1;k>=0;k--)if(T-ECL[k].t>ECL[k].d)ECL.splice(k,1);
    for(let k=RAYS.length-1;k>=0;k--)if(T-RAYS[k].t>RAYS[k].d)RAYS.splice(k,1);
  }
  /* état final léger : créatures dans leur monde, spores, lueur cyan */
  function pasFinal(dt){
    T+=dt;
    for(const e of E){piloter(e);animer(e,.3,2.4,dt);}
    for(const s of SEEDS){piloterSeed(s);animer(s,.3,2.4,dt);}
    communs(dt);
  }
  /* séquence abrégée (mouvement réduit) : les mondes se colorent l'un après l'autre, sans voyage */
  const ORD=[10,7,1,9,4,0,5,2,3,6,8];
  function pasAbrege(dt){
    T+=dt;const u=T-T0;
    if(u<1.2)legende(LG.flu);else if(u<4.6)legende(LG.touche);else legende(LG.fin);
    if(cpt&&u>.6&&cpt.style.opacity!=='1'){cpt.style.opacity='1';compteur();}
    ORD.forEach((i,k)=>{if(B[i].colT<-1e8&&u>=1+k*.3){B[i].colT=T;compteur();}});
    majBulles();
  }
  /* ---------- rendu ---------- */
  function dessinerLiens(){
    ctx.lineCap='round';ctx.lineJoin='round';ctx.globalCompositeOperation='lighter';
    for(let i=0;i<11;i++){const lv=lien[i];if(lv<=.01)continue;const pts=LK[i];if(!pts||pts.length<2)continue;
      ctx.strokeStyle=GR.lien[i];ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let j=1;j<pts.length;j++)ctx.lineTo(pts[j][0],pts[j][1]);
      ctx.globalAlpha=lv*.22;ctx.lineWidth=5.5;ctx.stroke();ctx.globalAlpha=lv*.75;ctx.lineWidth=1.1;ctx.stroke();}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function colDe(i){const b=B[i];if(b.colT<-1e8)return 0;return mode==='final'&&b.colT<0?1:clamp((T-b.colT)/2.5,0,1);}
  function dessinerBulleFond(i,rev,A){
    const b=B[i],x=N[i][0],y=N[i][1],r=RB(i)*rev,col=colDe(i);
    ctx.save();ctx.translate(x,y);
    ctx.globalCompositeOperation='lighter';
    const fin=mode==='final';
    ctx.globalAlpha=A*clamp((fin?.1:.16)+.3*b.glint+.4*b.flash+.2*col+(i===F?(fin?.12:.3)+.4*b.pulse:0),0,1);
    const hs=r*2.44;ctx.drawImage(i===F||col>.5?S2.RCY:RINGW[i],-hs,-hs,hs*2,hs*2);
    ctx.globalCompositeOperation='source-over';ctx.globalAlpha=A;
    ctx.scale(rev,rev);
    trace(i);ctx.fillStyle=GR.body[i];ctx.fill();
    if(col>0||i===F){ctx.globalAlpha=A*(i===F?.5:col*.45);ctx.fillStyle=GR.cyb[i];ctx.fill();}
    if(NIVQ[niv][2]){ctx.save();ctx.clip();ctx.globalCompositeOperation='lighter';const R0b=RB(i);
      ctx.rotate(T*.18+i*1.3);ctx.lineWidth=R0b*.42;ctx.globalAlpha=.07*A;ctx.strokeStyle=GR.iri;ctx.beginPath();ctx.arc(0,0,R0b*.78,0,2.3);ctx.stroke();
      ctx.rotate(2.6-T*.07);ctx.globalAlpha=.05*A;ctx.beginPath();ctx.arc(R0b*.1,0,R0b*.62,0,1.8);ctx.stroke();ctx.restore();}
    ctx.restore();
    const lvl=i===F?niveauF*rev:b.lvl;
    if(lvl>.01){const R0b=RB(i);ctx.save();ctx.translate(x,y);ctx.scale(rev,rev);trace(i);ctx.clip();
      const yl=R0b-lvl*2*R0b,amp=((i===F?.9:.6)+2.6*Math.exp(-Math.max(0,T-b.colT)*.9)*(b.colT>=0?1:0)+1.6*b.wob)*G;
      const MY=(xx)=>yl+amp*Math.sin(xx/G*.15+T*1.8+i)+amp*.35*Math.sin(xx/G*.29-T*2.4);
      ctx.beginPath();ctx.moveTo(-R0b-3,R0b+3);for(let k=0;k<=18;k++){const xx=-R0b-3+(2*R0b+6)*k/18;ctx.lineTo(xx,MY(xx));}
      ctx.lineTo(R0b+3,R0b+3);ctx.closePath();ctx.fillStyle=GR.liq[i];const AL=A*(fin?.62:1);ctx.globalAlpha=AL*(i===F?1:clamp(lvl/.3,0,1));ctx.fill();
      ctx.globalCompositeOperation='lighter';ctx.beginPath();for(let k=0;k<=18;k++){const xx=-R0b-3+(2*R0b+6)*k/18,yy=MY(xx);k?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);}
      ctx.strokeStyle='rgba(170,240,245,.45)';ctx.lineWidth=.7;ctx.globalAlpha=AL;ctx.stroke();ctx.globalAlpha=.08*AL;ctx.lineWidth=3;ctx.stroke();
      ctx.fillStyle='rgba(200,250,250,.7)';
      for(let k=0;k<4;k++){const ph=((T*.32+k*.27+i*.13)%1),xx=Math.sin(k*2.4+i)*R0b*.55+Math.sin(T*2+k)*1.2,yy=lerp(R0b*.9,yl+2,ph);ctx.globalAlpha=.5*AL*Math.sin(ph*Math.PI);ctx.beginPath();ctx.arc(xx,yy,.7+.4*(k%2),0,TAU);ctx.fill();}
      ctx.restore();}
  }
  function dessinerBulleVerre(i,rev,A){
    const b=B[i],R0b=RB(i),col=colDe(i);
    ctx.save();ctx.translate(N[i][0],N[i][1]);ctx.scale(rev,rev);
    trace(i);
    ctx.globalAlpha=A;ctx.strokeStyle='rgba(2,8,14,.35)';ctx.lineWidth=2.2;ctx.stroke();
    ctx.save();ctx.rotate(T*.22+i*.9);ctx.strokeStyle=GR.iri;ctx.lineWidth=1.25;ctx.globalAlpha=A*clamp(.45+.4*b.glint+.4*b.flash,0,1);ctx.stroke();ctx.restore();
    ctx.globalAlpha=A;ctx.strokeStyle=i===F||col>0?'rgba(170,240,245,'+(.25+.35*Math.max(col,i===F?1:0))+')':rgba(COL[i],.35);ctx.lineWidth=.6;ctx.stroke();
    ctx.globalCompositeOperation='lighter';
    const g=.55+.45*b.glint;
    ctx.save();ctx.rotate(-.72);ctx.globalAlpha=.5*g*A;ctx.drawImage(S2.SPEC,-R0b*.42,-R0b*.78,R0b*.84,R0b*.36);ctx.restore();
    ctx.lineCap='round';ctx.strokeStyle='rgba(245,252,255,1)';ctx.globalAlpha=.55*g*A;ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(0,0,R0b*.8,Math.PI*1.1,Math.PI*1.38);ctx.stroke();
    ctx.globalAlpha=.22*g*A;ctx.lineWidth=.9;ctx.beginPath();ctx.arc(0,0,R0b*.8,Math.PI*1.44,Math.PI*1.5);ctx.stroke();
    ctx.globalAlpha=.2*g*A;ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,R0b*.84,Math.PI*.12,Math.PI*.32);ctx.stroke();
    if(b.glint>.05){ctx.globalAlpha=.9*b.glint*A;ctx.drawImage(S2.pe,-R0b*.55-5,-R0b*.52-5,10,10);}
    if(i===F){for(const e of E){if(e.etat!=='sortie')continue;const u=(T-(e.te-1.5))/1.5;if(u<.6)continue;const w=sm((u-.6)/.4),rr=RF+Math.max(0,(lerp(RF-9*G,RF+9*G,Math.pow((u-.62)/.38,1.5))-RF+9*G))*.95;
      const s=(10+26*w)*G;ctx.globalAlpha=.55*w;ctx.drawImage(S2.cy,Math.cos(e.aEx)*rr-s/2,Math.sin(e.aEx)*rr-s/2,s,s);ctx.globalAlpha=.6*w*w;ctx.drawImage(S2.pe,Math.cos(e.aEx)*rr-3,Math.sin(e.aEx)*rr-3,6,6);}
      for(const c of b.cicat){const u=T-c.t,a=.25+.75*Math.exp(-u*1.4);const r0=rng(c.sd);ctx.strokeStyle='rgba(200,250,252,1)';ctx.globalAlpha=a*.8*A;ctx.lineWidth=.7;ctx.beginPath();
        for(let k=0;k<3;k++){let q=c.a+(r0()-.5)*.12,rr=R0b+(r0()-.5)*2;ctx.moveTo(Math.cos(q)*rr,Math.sin(q)*rr);for(let s=0;s<3;s++){q+=(r0()-.5)*.22;rr+=(r0()-.6)*5;ctx.lineTo(Math.cos(q)*rr,Math.sin(q)*rr);}}ctx.stroke();
        if(u<1.2){ctx.globalAlpha=(1-u/1.2)*A;ctx.drawImage(S2.cy,Math.cos(c.a)*R0b-9,Math.sin(c.a)*R0b-9,18,18);}}}
    if(col>0){const br=.5+.5*Math.sin(T*1.6+i);ctx.strokeStyle='rgb(127,216,230)';ctx.globalAlpha=A*col*(.18+.16*br);ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,R0b+4.5+br,0,TAU);ctx.stroke();
      ctx.globalAlpha=A*col*.08;ctx.lineWidth=4;ctx.stroke();}
    if(b.flash>0){ctx.globalAlpha=b.flash*.5*A;ctx.drawImage(i===F||col>0?S2.cy:GLW[i],-R0b*1.4,-R0b*1.4,R0b*2.8,R0b*2.8);}
    ctx.restore();
  }
  function revF(){if(mode==='final'||mode==='abrege')return 1;if(T<2.1)return 0;return Math.max(.02,eback((T-2.1)/.75));}
  function dessinerCreature(ob,clip,alpha){
    if(alpha<=.01)return;
    ctx.save();
    if(clip>=0){const rv=clip===F?revF():1;ctx.translate(N[clip][0],N[clip][1]);ctx.scale(rv,rv);trace(clip);ctx.clip();ctx.scale(1/rv,1/rv);ctx.translate(-N[clip][0],-N[clip][1]);}
    const k=ob.kk||ob.k,p=ob.m.pos(0);
    ctx.translate(ob.qx,ob.qy);ctx.scale(k,k);ctx.translate(-p[0],-p[1]);
    ob.m.draw(ctx,alpha);
    if(ob.dec&&ob.geo&&NIVQ[niv][3])ob.dec.draw(ctx,ob.geo,.85*alpha);
    ctx.restore();
  }
  function sillage(e){
    if(e.hn<3||!NIVQ[niv][4])return;
    ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle='rgb(127,216,230)';
    const n=e.hn,fade=e.etat==='colon'?0:1;
    let px=e.hist[((e.hi-1+40)%40)*2],py=e.hist[((e.hi-1+40)%40)*2+1];
    for(let j=2;j<n;j++){const q=((e.hi-j+40)%40)*2,x=e.hist[q],y=e.hist[q+1],u=j/n;
      ctx.globalAlpha=.32*(1-u)*fade;ctx.lineWidth=(3.2*(1-u)+.3)*G;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(x,y);ctx.stroke();px=x;py=y;}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function particules(l2){
    ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
    for(let i=0;i<pn;i++){if(P.l[i]!==l2)continue;const u=P.a[i]/P.v[i],k=P.k[i];let a=(1-u)*(u<.08?u/.08:1);
      const x=P.x[i],y=P.y[i],s=P.s[i];ctx.fillStyle=PCOL[P.c[i]];
      if(k===0){a*=.55+.45*Math.sin(P.a[i]*14+P.ph[i]);ctx.globalAlpha=clamp(a,0,1);ctx.fillRect(x-s/2,y-s/2,s,s);}
      else if(k===1){ctx.globalAlpha=clamp(a*(.6+.4*Math.sin(P.a[i]*9+P.ph[i])),0,1);const L=s*2.6;ctx.strokeStyle=PCOL[P.c[i]];ctx.lineWidth=.55;ctx.beginPath();ctx.moveTo(x-L,y);ctx.lineTo(x+L,y);ctx.moveTo(x,y-L);ctx.lineTo(x,y+L);ctx.stroke();ctx.fillRect(x-.7,y-.7,1.4,1.4);}
      else if(k===2){ctx.globalAlpha=clamp(a,0,1);ctx.strokeStyle=PCOL[P.c[i]];ctx.lineWidth=s*.7;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-P.vx[i]*.05,y-P.vy[i]*.05);ctx.stroke();}
      else{const f=Math.sin(Math.PI*Math.min(1,u*1.3));ctx.globalAlpha=clamp(f*.5,0,1);ctx.drawImage(P.c[i]===2?S2.lu:S2.cy,x-s*3,y-s*3,s*6,s*6);ctx.globalAlpha=clamp(f*.9,0,1);ctx.fillRect(x-s*.4,y-s*.4,s*.8,s*.8);}}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function effets(){
    ctx.globalCompositeOperation='lighter';
    for(const a of ANN){const u=(T-a.t)/a.d;if(u<0)continue;const r=lerp(a.r0,a.r1,eo(u));ctx.strokeStyle=rgba(a.c,1);ctx.globalAlpha=(1-u)*(1-u)*.8;ctx.lineWidth=a.w*(1-u*.6);ctx.beginPath();ctx.arc(a.x,a.y,r,0,TAU);ctx.stroke();
      ctx.globalAlpha=(1-u)*(1-u)*.12;ctx.lineWidth=a.w*5;ctx.stroke();}
    for(const f of ECL){const u=(T-f.t)/f.d;const s=f.s*(.6+.4*eo(u));ctx.globalAlpha=(1-u)*(1-u);ctx.drawImage(f.g,f.x-s/2,f.y-s/2,s,s);}
    ctx.lineCap='round';
    for(const r of RAYS){const u=(T-r.t)/r.d,r0=rng(r.sd+11);ctx.strokeStyle='rgb(220,248,250)';
      for(let k=0;k<9;k++){const a=r.a+(r0()-.5)*1.5,L=(18+r0()*34)*G,d0=4+L*eo(u)*.6;ctx.globalAlpha=(1-u)*(.35+r0()*.4);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(r.x+Math.cos(a)*d0,r.y+Math.sin(a)*d0);ctx.lineTo(r.x+Math.cos(a)*(d0+L*(1-u*.5)),r.y+Math.sin(a)*(d0+L*(1-u*.5)));ctx.stroke();}}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function dessinerAnnonceF(){
    if(T>1.5&&T<2.5){const u=(T-1.5)/.6,f=N[F],a=T<2.1?eo(u):1-(T-2.1)/.4;ctx.globalCompositeOperation='lighter';ctx.globalAlpha=clamp(a,0,1);
      const s=(8+40*eo(u))*G;ctx.drawImage(S2.cy,f[0]-s/2,f[1]-s/2,s,s);ctx.drawImage(S2.pe,f[0]-4,f[1]-4,8,8);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
  }
  function rendu(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,l,h);
    const fin=mode==='final',ab=mode==='abrege';
    const A=fin?(tFinal<0?.85:passeF?.85*clamp((T-tFinal)/.8,0,1):.85+.15*(1-clamp((T-tFinal)/2,0,1))):ab?sm((T-T0)/.6):sm((T-T0)/.9);
    if(assomb>.005){ctx.fillStyle='rgba(1,4,8,'+assomb+')';ctx.fillRect(0,0,l,h);}
    if(!fin&&!ab)dessinerLiens();
    particules(0);
    const rv=revF();
    for(let i=0;i<12;i++)forme(i,1);
    // pendant la séquence, seules les bulles touchées (et Fluides) prennent la membrane pleine ; les autres restent légères
    for(let i=0;i<11;i++)dessinerBulleFond(i,1,A*(fin||ab?Math.max(.15,colDe(i)):.55+.45*colDe(i)));
    if(rv>0)dessinerBulleFond(F,rv,A);
    if(!fin&&!ab)dessinerAnnonceF();
    const aq=clamp((T-2.2)/.8,0,1);
    if(!ab){for(const e of E){if(T<1.95)break;if(e.clip>=0)dessinerCreature(e,e.clip,(e.clip===F&&!fin?aq*1.2:1.2)*(fin?A/.85:1));}
      for(const s of SEEDS)if(s.fait)dessinerCreature(s,s.cible,clamp((T-s.tA)/.8,0,1)*(fin?A/.85:1));}
    else if(T-T0>4.4){const a=sm((T-T0-4.4)/.8);for(const e of E)dessinerCreature(e,e.cible,a);for(const s of SEEDS)dessinerCreature(s,s.cible,a);}
    for(let i=0;i<11;i++)dessinerBulleVerre(i,1,A*(fin||ab?Math.max(.3,colDe(i)):.6+.4*colDe(i)));
    if(rv>0)dessinerBulleVerre(F,rv,A);
    if(!fin&&!ab){
      for(const e of E)if(e.etat==='voyage'||e.etat==='entree'||(e.etat==='colon'&&e.hn>0))sillage(e);
      for(const g of GRAINES){if(g.fait&&T-g.t0-g.dur>.6)continue;const hh=g.hist,fa=g.fait?1-(T-g.t0-g.dur)/.6:1;ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle='rgb(127,216,230)';
        for(let j=2;j<hh.length;j+=2){const u=j/hh.length;ctx.globalAlpha=.5*u*fa;ctx.lineWidth=2.2*u*G;ctx.beginPath();ctx.moveTo(hh[j-2],hh[j-1]);ctx.lineTo(hh[j],hh[j+1]);ctx.stroke();}
        if(!g.fait){ctx.globalAlpha=1;ctx.drawImage(S2.cy,g.x-9*G,g.y-9*G,18*G,18*G);ctx.drawImage(S2.pe,g.x-3,g.y-3,6,6);}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
      for(const e of E){if(e.clip>=0||T<1.95)continue;
        const s=78*e.k;ctx.globalAlpha=.46;ctx.drawImage(S2.dark,e.qx-s,e.qy-s,s*2,s*2);
        ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.16;ctx.drawImage(S2.cy,e.qx-s*.7,e.qy-s*.7,s*1.4,s*1.4);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;
        dessinerCreature(e,-1,1.3);}
    }
    particules(1);
    effets();
    if(flashEcran>.005){ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(127,216,230,'+flashEcran*.4+')';ctx.fillRect(0,0,l,h);ctx.globalCompositeOperation='source-over';}
  }
  /* ---------- fin / passer ---------- */
  let fini=false;
  function annoncerFin(raison){if(fini)return;fini=true;try{if(o.fin)o.fin(raison);}catch(e){}}
  function nettoyerUI(){
    if(prise){prise.remove();prise=null;}
    if(bP){bP.remove();bP=null;}
    if(hud){const hd=hud;hud=null;hd.style.opacity='0';setTimeout(()=>hd.remove(),600);}
    if(sous)sous.style.opacity='';
  }
  function versFinal(raison){
    annoncerFin(raison);
    mode='final';nettoyerUI();
    for(let i=0;i<12;i++){const b=B[i];if(i<11&&b.colT<-1e8)b.colT=T-10;b.pokes.length=0;b.flash=0;}
    VAGUES.length=0;ANN.length=0;ECL.length=0;RAYS.length=0;GRAINES.length=0;assomb=0;flashEcran=0;
    for(const e of E){if(e.etat!=='colon'){e.etat='colon';e.hn=0;orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);preparer(e,_o[0],_o[1],_o[2],_o[3],40);}}
    for(const s of SEEDS){if(!s.fait){s.fait=true;s.tA=T-5;orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);preparer(s,_o[0],_o[1],_o[2],_o[3],40);}}
    tFinal=T;passeF=raison==='passe';
    if(sobre){rendu();arreterBoucle();}
  }
  function sauter(){if(mode==='final'||detruit)return;versFinal('passe');}
  /* ---------- boucle + gouverneur ---------- */
  const mes={n:0,s:0,fen:[],max:0,t0:0};let fige=false;
  function image(now){
    raf=0;if(detruit)return;
    if(!R0.isConnected){detruire();return;}
    try{
      const t0=performance.now();
      if(!regeo()){raf=racine.requestAnimationFrame(image);return;}
      const dt=Math.min(.1,Math.max(0,(now-tPrev)/1000));tPrev=now;
      if(mode==='sequence'){acc+=dt;let n=0;while(acc>=H&&n<4){pas();acc-=H;n++;}if(n===4)acc=0;if(T>=T_FIN)versFinal('fin');rendu();}
      else if(mode==='abrege'){pasAbrege(dt);rendu();if(T-T0>5.8)versFinal('fin');}
      else{nImg++;if(nImg%2===0){pasFinal(Math.min(1/15,dt*2||1/30));rendu();}else{if(raf===0)raf=racine.requestAnimationFrame(image);return;}}
      const ms=performance.now()-t0;mes.n++;mes.s+=ms;mes.max=Math.max(mes.max,ms);mes.fen.push(ms);
      if(!mes.t0)mes.t0=now;
      if(mes.fen.length>=45||(mes.fen.length>=8&&now-mes.t0>1500)){const moy=mes.fen.reduce((a,b)=>a+b,0)/mes.fen.length;mes.fen=[];mes.t0=now;
        if(moy>8&&niv<NIVQ.length-1){niv++;tailleCanvas();if(pn>NIVQ[niv][0])pn=NIVQ[niv][0];}}
    }catch(e){try{console.warn('QXCREA',e);}catch(e2){}annoncerFin('erreur');detruire();return;}
    if(!fige&&!detruit)raf=racine.requestAnimationFrame(image);
  }
  function arreterBoucle(){fige=true;if(raf){racine.cancelAnimationFrame(raf);raf=0;}}
  function surVis(){if(detruit)return;if(document.hidden){if(raf){racine.cancelAnimationFrame(raf);raf=0;}}else if(!raf&&!fige){tPrev=performance.now();raf=racine.requestAnimationFrame(image);}}
  function surTaille(){if(!detruit&&fige){setTimeout(()=>{if(!detruit&&regeo()){if(mode==='final')pasFinal(1/60);rendu();}},160);}}
  function detruire(){
    if(detruit)return;detruit=true;if(raf)racine.cancelAnimationFrame(raf);raf=0;
    document.removeEventListener('visibilitychange',surVis);racine.removeEventListener('resize',surTaille);
    nettoyerUI();if(hud)hud.remove();cv.remove();if(cur===ctl)cur=null;
  }
  /* ---------- démarrage ---------- */
  if(!regeo()){detruire();return null;}
  R=rng(20261120);
  if(mode==='final'){T=40;for(let i=0;i<11;i++)B[i].colT=-5;niveauF=.5;creerCreatures(true);}
  else creerCreatures(false);
  if(mode==='abrege'){niveauF=.5;for(const e of E){e.etat='colon';e.clip=e.cible;e.k=e.kT*.6;}for(const s of SEEDS){s.fait=true;s.tA=-10;s.kk=s.k;}
    for(const e of E){orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);e.qx=_o[0];e.qy=_o[1];preparer(e,_o[0],_o[1],_o[2],_o[3],60);}
    for(const s of SEEDS){orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);s.qx=_o[0];s.qy=_o[1];preparer(s,_o[0],_o[1],_o[2],_o[3],60);}}
  document.addEventListener('visibilitychange',surVis);racine.addEventListener('resize',surTaille);
  inst.surDetruire(detruire);
  if(mode==='final'&&sobre){rendu();fige=true;}
  else{tPrev=performance.now();raf=racine.requestAnimationFrame(image);}
  const ctl={
    stop:detruire,passer:sauter,
    get etat(){return detruit?'repos':mode;},
    stats(){return{ms:mes.n?mes.s/mes.n:0,max:mes.max,images:mes.n,niveau:niv,T,particules:pn,colonises:nCol(),dpr};},
    seek(t){if(mode!=='sequence')return T;while(T<t-1e-9&&mode==='sequence'){pas();if(T>=T_FIN)versFinal('fin');}rendu();return T;}   // test
  };
  return ctl;
}

racine.QXCREA={
  version:'R463',
  play(o){
    try{
      if(lsGet('qxcrea')==='0'){if(o&&o.fin)o.fin('coupe');return null;}
      if(!o||!o.inst||!o.inst.geo||!M||!document.createElement('canvas').getContext)return null;
      if(cur)cur.stop();
      cur=Scene(o);return cur;
    }catch(e){try{console.warn('QXCREA',e);}catch(e2){}if(cur){try{cur.stop();}catch(e3){}}cur=null;if(o&&o.fin)o.fin('erreur');return null;}
  },
  stop(){if(cur)cur.stop();cur=null;},
  get etat(){return cur?cur.etat:'repos';},
  stats(){return cur?cur.stats():null;},
  get scene(){return cur;}
};
})(window);
/* =====================================================================
   QXCREA.niveau (R463) — DÉCOR VIVANT des niveaux Fluides, après la libération (S.crea=1).
   Les créatures nagent derrière le jeu, sans aucun contact avec la bille ni la physique :
   rien n'est écrit dans l'état du jeu, aucun tirage du hasard du moteur (graines propres, mulberry32).
   Repère = unités de niveau (360 × 470). Chaque créature vit dans son propre monde (W/k × H/k)
   et est dessinée à l'échelle k. Le courant vient de FLUID.sample (lecture seule) + une dérive douce.
   API : QXCREA.niveau.dessiner(ctx, lv, env) · .vider() · .stats() · .actif
         env = { RM, S, ms (temps de la précédente image du jeu) }
   ===================================================================== */
(function (racine) {
'use strict';
const M = racine.QXMOTIFS;
if (!M || !racine.QXCREA) return;
const W = 360, H = 470, TAU = Math.PI * 2;
/* calibrage : échelle (unités de niveau par unité de créature), opacité de base */
const CAL = { cells: [.72, .82], filament: [.74, .8], systole: [.64, .72], culbute: [.64, .84], choeur: [.58, .7], cortege: [.64, .8], volte: [.64, .9], braise: [.6, .68] };
const NOMS = ['cells', 'filament', 'systole', 'culbute', 'choeur', 'cortege', 'volte', 'braise'];
/* poids = coût de dessin relatif (mesuré : braise ≈ 2,9 ms, chœur 1,9, cortège 1,2, systole 1,1, les autres < 0,2 sur le banc d'essai) */
const POIDS = { cells: .12, filament: .1, culbute: .15, volte: .15, systole: .6, cortege: .65, choeur: 1, braise: 1.4 };
/* paliers : budget de poids, poils/voiles, qualité (cells, filament) ; les plus lourdes s'effacent d'abord */
const PAL = [[2.2, 1, .8], [1.25, 0, .7], [.65, 0, .6], [.3, 0, .5]];
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const lisse = (a, b, x) => { const u = Math.max(0, Math.min(1, (x - a) / (b - a))); return u * u * (3 - 2 * u); };
function reduitOS() { try { return !!(racine.matchMedia && racine.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
let cur = null, verrou = -1;   // verrou : palier imposé (aperçu, tests) ; -1 = adaptatif
const mes = { n: 0, s: 0, max: 0 };

/* ───── R469 · IMPLANTATION + COMPORTEMENT des créatures du décor ─────
   IMPLANTATION : les créatures vivent SUR LE PARCOURS (départ → étoile → arrivée, abords des murs, traits du joueur),
   jamais dessus : zones interdites douces autour de la bille, de la coupe, de l'étoile et des murs (elles s'écartent
   et pâlissent) ; elles sont dessinées SOUS le jeu, donc ne cachent jamais rien.
   COMPORTEMENT : une petite machine à états par créature, déterministe (graine du niveau + temps accumulé, aucun Math.random) :
     derive (repos, respiration lente) → cherche (patrouille par impulsions, cap qui balaie, antennes qui tâtent)
     → tate (arrêt sur un lieu, antennes tendues, éclair) → appel (le chef gonfle et émet une onde + un signal)
     → echo (les autres répondent en retard, se tournent) → rejoint (rapprochement) → ronde (danse à deux, arcs de lueur).
   Événements du jeu : lancement (sursaut, toutes se tournent), suit (filature à distance de la bille), recul (la bille
   arrive trop vite : fuite + alerte relayée), inspecte (nouveau trait tracé), fete (victoire : ronde autour de la coupe,
   éclairs en chaîne), abattu (échec : la lumière tombe, elles coulent un peu).
   Tempéraments : contemplatif · actif · social · agressif (vitesse, accélération, audace, goût de l'appel).
   Rien n'est écrit dans l'état du jeu ; la physique ne voit jamais ces créatures. */
const BORD = 16, VSIG = 240;                     // marge du terrain ; vitesse d'un signal lumineux (unités/s)
const TEMP = {                                   // vmax, amax, rythme de nage (Hz), audace (distance de filature), appel (goût), couleur
  contemplatif: { v: 34, a: 70, hz: .9, dist: 92, appel: .35, col: 1 },
  actif:        { v: 62, a: 150, hz: 1.7, dist: 74, appel: .2, col: 0 },
  social:       { v: 48, a: 110, hz: 1.3, dist: 84, appel: .8, col: 1 },
  agressif:     { v: 78, a: 220, hz: 2.2, dist: 56, appel: .15, col: 2 }
};
const TEMP_DE = { cells: 'social', filament: 'actif', systole: 'contemplatif', culbute: 'actif', choeur: 'social', cortege: 'social', volte: 'agressif', braise: 'agressif' };
/* lueurs pré-rendues (une fois) : dessinées en « lighter », sans dégradé dans la boucle */
const LUM = ['110,238,196', '127,216,230', '232,248,252'];   // lueur (vert d'eau), aqua, perle
let SPR = null;
function sprites() {
  if (SPR) return SPR; SPR = [];
  for (const c of LUM) {
    const k = document.createElement('canvas'); k.width = k.height = 64; const g = k.getContext('2d');
    const r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    r.addColorStop(0, 'rgba(' + c + ',.9)'); r.addColorStop(.25, 'rgba(' + c + ',.42)'); r.addColorStop(.6, 'rgba(' + c + ',.1)'); r.addColorStop(1, 'rgba(' + c + ',0)');
    g.fillStyle = r; g.fillRect(0, 0, 64, 64); SPR.push(k);
  }
  return SPR;
}
function halo(ctx, i, x, y, R, a) { if (a <= .01 || R <= .5) return; ctx.globalAlpha = Math.min(1, a); ctx.drawImage(sprites()[i], x - R, y - R, R * 2, R * 2); }
const q = (v, p0, p1, p2) => (1 - v) * (1 - v) * p0 + 2 * (1 - v) * v * p1 + v * v * p2;   // point d'une courbe de Bézier quadratique
const wrapA = a => a - Math.round(a / TAU) * TAU;
function dSeg(px, py, s) {                       // distance point–segment, renvoie aussi la normale (dans _n)
  const ax = s[0], ay = s[1], bx = s[2], by = s[3], ex = bx - ax, ey = by - ay, l2 = ex * ex + ey * ey || 1;
  let u = ((px - ax) * ex + (py - ay) * ey) / l2; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const qx = ax + ex * u, qy = ay + ey * u, dx = px - qx, dy = py - qy, d = Math.hypot(dx, dy) || 1e-3;
  _n[0] = dx / d; _n[1] = dy / d; return d;
}
const _n = [0, 0];
function arrivee(lv) {
  if (lv.cup) return [lv.cup[0] + lv.cup[2] / 2, lv.cup[1] - 26];
  if (lv.zone) { const z = lv.zone; return [z[0] + z[2] / 2, z[1] + z[3] / 2]; }
  return [W / 2, H - 60];
}
function zonesCalmes(lv) {                       // [x, y, rayon interdit] : départ, arrivée, étoile (la lisibilité d'abord)
  const Z = [], A = arrivee(lv);
  if (lv.ball) Z.push([lv.ball[0], lv.ball[1], 30]);
  Z.push([A[0], A[1], lv.cup ? Math.max(40, lv.cup[2] * .45) : 46]);
  if (lv.star) Z.push([lv.star[0], lv.star[1], 30]);
  return Z;
}
/* LIEUX : points d'intérêt le long du parcours, décalés de côté (on longe le chemin, on ne s'y pose pas) */
function lieux(lv, Z, murs) {
  const L = [], A = lv.ball || [60, 60], F = arrivee(lv), chemin = [A];
  if (lv.star) chemin.push(lv.star); chemin.push(F);
  const ok = (x, y) => {
    if (x < BORD + 8 || x > W - BORD - 8 || y < BORD + 10 || y > H - BORD - 10) return false;
    for (const z of Z) if (Math.hypot(x - z[0], y - z[1]) < z[2] + 14) return false;
    for (const s of murs) if (dSeg(x, y, s) < 18) return false;
    return true;
  };
  const ajoute = (x, y, w) => { if (ok(x, y)) L.push([x, y, w]); };
  for (let j = 0; j + 1 < chemin.length; j++) {
    const a = chemin[j], b = chemin[j + 1], ex = b[0] - a[0], ey = b[1] - a[1], l = Math.hypot(ex, ey) || 1, nx = -ey / l, ny = ex / l;
    for (let f = .15; f < .95; f += .14) for (const s of [1, -1]) for (const o of [36, 58]) ajoute(a[0] + ex * f + nx * o * s, a[1] + ey * f + ny * o * s, 1);
  }
  for (const z of Z) for (let q = 0; q < 6; q++) { const an = q * TAU / 6 + .4; ajoute(z[0] + Math.cos(an) * (z[2] + 26), z[1] + Math.sin(an) * (z[2] + 26), 1.3); }   // les abords du départ, de l'étoile, de la coupe
  for (const s of murs) {                       // le bout des murs : là où la bille ricoche
    if (s[4] === 2) continue;
    for (const e of [[s[0], s[1]], [s[2], s[3]]]) for (let q = 0; q < 4; q++) { const an = q * TAU / 4 + .78; ajoute(e[0] + Math.cos(an) * 30, e[1] + Math.sin(an) * 30, .8); }
  }
  if (L.length < 4) for (let gx = 0; gx < 5; gx++) for (let gy = 0; gy < 6; gy++) ajoute(50 + gx * 65, 50 + gy * 72, .5);
  return L;
}
function choisir(lv) {                           // créatures, déterministe selon l'indice du niveau
  const idx = lv.idx || 0, r = rng(0x5EA0 + idx * 7919), noms = NOMS.slice();
  for (let i = noms.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)), x = noms[i]; noms[i] = noms[j]; noms[j] = x; }
  const ext = lv.wd !== 12 || !!lv.cr;           // mondes colonisés (et niveaux d'essai) : créatures légères seulement
  if (ext) for (let i = noms.length - 1; i >= 0; i--) if (POIDS[noms[i]] > .15) noms.splice(i, 1);
  const n = ext ? 2 : 2 + ((idx * 5 + Math.floor(r() * 3)) % 3);   // R469 : toujours au moins deux (elles se parlent)
  const choix = []; let pds = 0;
  for (const nom of noms) { if (choix.length >= n) break; if (pds + POIDS[nom] > PAL[0][0]) continue; choix.push(nom); pds += POIDS[nom]; }
  const E = [];
  for (let i = 0; i < choix.length; i++) {
    const nom = choix[i], cal = CAL[nom], tn = i === 0 ? 'social' : (TEMP_DE[nom] === 'social' && i > 0 ? (i % 2 ? 'contemplatif' : 'actif') : TEMP_DE[nom]);
    E.push({ nom, k: cal[0] * (ext ? 1.02 : 1.08) * (.94 + .12 * r()), a0: Math.min(1, cal[1] * (ext ? 1.05 : 1.15)), seed: (idx * 131 + i * 977 + 4243) >>> 0, rang: i,
      poids: POIDS[nom], m: null, dec: null, geo: null, flo: [0, 0], fld: [0, 0], ap: 0, tn, T: TEMP[tn], chef: i === 0,
      x: 0, y: 0, vx: 0, vy: 0, cap: r() * TAU, capV: 0, ph: r() * TAU, lum: .3, fl: 0, gon: 0, etat: 'derive', tE: 0, dur: 2,
      tx: 0, ty: 0, ax: 0, ay: 0, wp: 0, lieu: -1, autre: -1, ant: 0, antX: 0, antY: 0, mode: '', part: { on: false, x: 0, y: 0 },
      tr: new Float32Array(24), trN: 0, trT: 0, R: rng(0xC0FFEE ^ (idx * 7907 + i * 104729)) });
  }
  return E.sort((x, y) => x.poids - y.poids);
}
function monter(lv) {
  vider();
  const E = choisir(lv), Z = zonesCalmes(lv);
  const murs = []; for (const s of (lv.w || [])) if (s && s.length >= 4) murs.push(s);
  const LI = lieux(lv, Z, murs);
  const SIG = [], RG = []; for (let i = 0; i < 8; i++) SIG.push({ on: false, a: 0, b: 0, t0: 0, d: 1, kind: 0, cx: 0, cy: 0 }); for (let i = 0; i < 12; i++) RG.push({ on: false, x: 0, y: 0, t0: 0, d: 1, r0: 0, r1: 0, c: 0, a: 0 });
  cur = { idx: lv.idx, E, t: 0, tPrev: 0, pal: 0, ema: 0, emaJ: 0, nImg: 0, tDeg: 0, tRem: 0, Z, murs, LI, SIG, RG, fondu: 0,
    mode0: '', nStk: 0, tMode: 0, arr: arrivee(lv), cr: lv.cr || null, tAppel: 3 + (lv.idx || 0) % 3, F: null };
  /* ancres : on répartit les créatures le long du parcours (échantillonnage du plus éloigné) */
  const pris = [];
  for (const e of E) {
    let best = -1, bs = -1;
    for (let j = 0; j < LI.length; j++) {
      let d = 1e9; for (const p of pris) d = Math.min(d, Math.hypot(LI[j][0] - LI[p][0], LI[j][1] - LI[p][1]));
      if (cur.cr) for (const c of cur.cr) d = Math.min(d, Math.hypot(LI[j][0] - c.x, LI[j][1] - c.y) - (c.r || c.rc || 30) - 30);   // loin des créatures actives
      const s = Math.min(d, 160) * LI[j][2] + e.R() * 25;
      if (s > bs) { bs = s; best = j; }
    }
    if (best < 0) { e.ax = 80 + e.rang * 90; e.ay = 140; } else { pris.push(best); e.ax = LI[best][0]; e.ay = LI[best][1]; e.lieu = best; }
    e.x = e.ax; e.y = e.ay; e.tx = e.ax; e.ty = e.ay; e.dur = 1 + e.rang * .9;
    e.m = M.create(e.nom);
    e.m.init(W / e.k, H / e.k, e.seed, { quality: PAL[0][2], n: 1, slot: e.rang % 2 });
    e.m.reglage({ mode: 'cont', vit: .7, part: e.part });
    e.m.place(0, e.x / e.k, e.y / e.k);
    if (e.nom === 'cells' || e.nom === 'filament') e.dec = M.decor();
    e.flow = () => { e.flo[0] = e.vx / e.k; e.flo[1] = e.vy / e.k; return e.flo; };           // le corps « sent » sa propre nage : il s'oriente et s'étire dans le sens du mouvement
    e.flowD = () => { e.fld[0] = -e.vx * .5 / e.k; e.fld[1] = -e.vy * .5 / e.k; return e.fld; };  // poils et voiles traînent derrière
    for (let s = 0; s < 24; s++) corps(e, 1 / 30, true);
  }
  figMonter(lv);   // R470
  try { if (lv.wd === 12 && racine.QXF2 && racine.QXF2.vivants) racine.QXF2.vivants(.45); } catch (er) {}
}
function vider() {
  if (!cur) return;
  cur = null;
  try { if (racine.QXF2 && racine.QXF2.vivants) racine.QXF2.vivants(1); } catch (er) {}
}
/* le corps (motif) suit la position comportementale : placé, orienté vers un point devant le cap, puis animé */
function corps(e, dt, prep) {
  const k = e.k, cv = e.cap + e.capV;
  e.m.place(0, e.x / k, e.y / k);
  e.m.vise(0, (e.x + Math.cos(cv) * 70) / k, (e.y + Math.sin(cv) * 70) / k, 1.1);
  const en = e.etat === 'derive' ? .15 : e.etat === 'abattu' ? .05 : (e.etat === 'tate' || e.etat === 'appel' || e.etat === 'fete' || e.etat === 'recul') ? 1 : .55;
  e.m.update(dt, e.flow, en);
  e.m.place(0, e.x / k, e.y / k);
  if (e.dec && (prep || PAL[cur.pal][1])) { e.geo = e.m.geo(); const sp = Math.hypot(e.vx, e.vy); e.dec.update(dt * (1 + Math.min(3, sp / 50)), e.flowD, e.geo); }
}
/* ── signaux et ondes (tableaux pré-alloués, aucun objet créé par image) ── */
function onde(x, y, r0, r1, d, c, a) {
  let s = null; for (const o of cur.RG) if (!o.on) { s = o; break; } if (!s) return;
  s.on = true; s.x = x; s.y = y; s.r0 = r0; s.r1 = r1; s.d = d; s.c = c; s.a = a; s.t0 = cur.t;
}
function signal(a, b, kind) {                    // une impulsion de lumière voyage de a vers b le long d'un arc ; à l'arrivée, b réagit
  let s = null; for (const o of cur.SIG) if (!o.on) { s = o; break; } if (!s) return;
  const A = cur.E[a], B = cur.E[b], d = Math.hypot(B.x - A.x, B.y - A.y);
  s.on = true; s.a = a; s.b = b; s.kind = kind; s.t0 = cur.t; s.d = Math.max(.25, d / VSIG);
  const nx = -(B.y - A.y) / (d || 1), ny = (B.x - A.x) / (d || 1), bo = (a < b ? 1 : -1) * Math.min(60, d * .3);
  s.cx = (A.x + B.x) / 2 + nx * bo; s.cy = (A.y + B.y) / 2 + ny * bo;
}
function emet(e, kind) {                         // e appelle (kind 0), répond (1) ou alerte (2)
  const i = cur.E.indexOf(e);
  e.fl = 1; e.gon = 1;
  onde(e.x, e.y, 6, kind === 2 ? 34 : 42, kind === 1 ? .8 : 1.1, e.T.col, kind === 1 ? .4 : .55);   // R477 : plus de grand cercle (95 px → 42)
  for (let j = 0; j < cur.E.length; j++) if (j !== i && cur.E[j].ap > .02) { if (kind === 1 && j !== e.autre) continue; signal(i, j, kind); }
}
function recoit(e, s) {
  const A = cur.E[s.a];
  e.fl = Math.max(e.fl, .8); e.gon = Math.max(e.gon, .6);
  if (e.etat === 'suit' || e.etat === 'recul' || e.etat === 'fete' || e.etat === 'abattu') { if (s.kind === 2) e.fl = 1; return; }
  if (s.kind === 0) { passe(e, 'echo', .35 + .25 * e.R()); e.autre = s.a; }
  else if (s.kind === 1) { if (e.etat === 'appel' || e.etat === 'derive' || e.etat === 'cherche') { passe(e, 'rejoint', 2.5); e.autre = s.a; } }
  else e.cap = Math.atan2(A.y - e.y, A.x - e.x);
}
function passe(e, etat, dur) { e.etat = etat; e.tE = 0; e.dur = dur; }
function prochainLieu(e) {                       // un lieu du parcours, pas trop près de l'actuel, ni de la bille
  const LI = cur.LI; if (!LI.length) { e.tx = e.ax; e.ty = e.ay; return; }
  let best = 0, bs = -1e9;
  for (let j = 0; j < LI.length; j++) {
    const d = Math.hypot(LI[j][0] - e.x, LI[j][1] - e.y), da = Math.hypot(LI[j][0] - e.ax, LI[j][1] - e.ay);
    let s = (d > 50 && d < 190 ? 1 : d < 45 ? -6 : 0) - da / 260 + e.R() * .9 + LI[j][2] * .3;
    for (const o of cur.E) if (o !== e) s -= Math.max(0, 1 - Math.hypot(LI[j][0] - o.tx, LI[j][1] - o.ty) / 70);
    if (s > bs) { bs = s; best = j; }
  }
  e.tx = LI[best][0]; e.ty = LI[best][1]; e.lieu = best;
}
/* ── événements du jeu (lus, jamais écrits) ── */
function evenements(S, b) {
  const m = S ? S.mode : '', run = m === 'run' || m === 'replay';
  if (m !== cur.mode0) {
    if (run && cur.mode0 !== 'run') for (const e of cur.E) { passe(e, 'alerte', .35 + e.rang * .12); e.fl = 1; e.gon = .8; if (b) e.cap = Math.atan2(b.y - e.y, b.x - e.x); }
    else if (m === 'success') { cur.E.forEach((e, i) => { passe(e, 'fete', 99); e.ph = i * 1.3; }); onde(cur.arr[0], cur.arr[1], 12, 56, 1.4, 1, .55); }   // R477 : ni gris-perle ni grand cercle
    else if (m === 'fail') for (const e of cur.E) { passe(e, 'abattu', 2.2); }
    else if (!run) for (const e of cur.E) if (e.etat === 'suit' || e.etat === 'recul' || e.etat === 'alerte' || e.etat === 'fete') passe(e, 'cherche', 6);
    cur.mode0 = m; cur.tMode = cur.t;
  }
  const st = S && S.strokes, n = st ? st.length : 0;
  if (n > cur.nStk && !run) {                    // un nouveau trait : la plus proche vient le tâter
    const s = st[n - 1], p = s && s.pts && s.pts[s.pts.length >> 1];
    if (p) {
      let e0 = null, dm = 1e9; for (const e of cur.E) { const d = Math.hypot(e.x - p[0], e.y - p[1]); if (d < dm) { dm = d; e0 = e; } }
      if (e0) {
        const q = s.pts[0], r = s.pts[s.pts.length - 1], ex = r[0] - q[0], ey = r[1] - q[1], l = Math.hypot(ex, ey) || 1;
        let nx = -ey / l, ny = ex / l; if (ny > 0) { nx = -nx; ny = -ny; }   // on se pose au-dessus du trait
        e0.tx = Math.max(BORD, Math.min(W - BORD, p[0] + nx * 26)); e0.ty = Math.max(BORD, Math.min(H - BORD, p[1] + ny * 26));
        passe(e0, 'inspecte', 3); e0.antX = p[0]; e0.antY = p[1];
      }
    }
  }
  cur.nStk = n;
}
/* ── la machine à états d'une créature : renvoie la vitesse voulue dans _v ── */
const _v = [0, 0];
function cerveau(e, i, dt, S, b, run) {
  const T = e.T, t = cur.t; e.tE += dt;
  let vd = 0, tx = e.tx, ty = e.ty, regard = null, hz = T.hz, lum = .3;
  e.capV = 0; e.ant = Math.max(0, e.ant - dt * 2);
  const avant = e.etat, tE0 = e.tE;
  switch (e.etat) {
    case 'derive': {                             // repos : lente dérive autour de l'ancre, respiration
      tx = e.ax + 22 * Math.sin(t * .5 + e.ph); ty = e.ay + 14 * Math.sin(t * .37 + e.ph * 1.7);
      vd = T.v * .22; hz = T.hz * .5; lum = .28 + .1 * Math.sin(t * 1.4 + e.ph);
      if (e.tE > e.dur) {
        cur.tAppel -= e.dur;
        if (e.chef && cur.E.length > 1 && cur.tAppel <= 0) { passe(e, 'appel', 1.1); cur.tAppel = 7 + 5 * e.R(); }
        else { passe(e, 'cherche', 7); e.wp = 2 + Math.floor(e.R() * 2); prochainLieu(e); }
      }
      break;
    }
    case 'cherche': {                            // patrouille : nage par impulsions vers un lieu, le cap balaie, les antennes tâtent
      vd = T.v; e.capV = .55 * Math.sin(t * 3.1 + e.ph); lum = .4; e.ant = Math.max(e.ant, .5);
      if (Math.hypot(tx - e.x, ty - e.y) < 16 || e.tE > e.dur) { passe(e, 'tate', .9 + .6 * e.R()); e.antX = tx + Math.cos(e.cap) * 30; e.antY = ty + Math.sin(e.cap) * 30; }
      break;
    }
    case 'tate': case 'inspecte': {              // arrêt : antennes tendues vers le lieu (ou le trait), petit éclair à mi-parcours
      const insp = e.etat === 'inspecte', d = Math.hypot(tx - e.x, ty - e.y);
      if (insp && d > 14 && e.tE < 1.6) { vd = T.v * 1.1; lum = .5; e.ant = .7; regard = 1; break; }
      vd = 0; e.ant = 1; regard = 1; lum = .5 + .3 * Math.sin(e.tE * 9);
      e.capV = .25 * Math.sin(e.tE * 7);
      if (e.tE > e.dur * .45 && e.tE - dt <= e.dur * .45) { e.fl = Math.max(e.fl, .7); onde(e.antX, e.antY, 3, 22, .5, e.T.col, .6); }
      if (e.tE > (insp ? 2.4 : e.dur)) {
        if (insp) { passe(e, 'derive', 1.5); break; }
        if (--e.wp > 0) { passe(e, 'cherche', 7); prochainLieu(e); }
        else if (e.R() < T.appel && cur.E.length > 1) passe(e, 'appel', 1);
        else { passe(e, 'derive', 2 + 3 * e.R()); e.ax = e.x; e.ay = e.y; }
      }
      break;
    }
    case 'appel': {                              // le chef se gonfle, la lumière monte… puis l'onde et le signal partent
      vd = 0; hz = 3; const u = e.tE / e.dur; lum = .4 + .6 * u; e.gon = Math.max(e.gon, u * .7);
      if (e.tE >= e.dur) { emet(e, 0); passe(e, 'attend', 2.6); }
      break;
    }
    case 'attend': { vd = 0; lum = .5; if (e.tE > e.dur) passe(e, 'derive', 2); break; }
    case 'echo': {                               // un signal est arrivé : elle se tourne, attend (écho), puis répond
      const A = cur.E[e.autre]; vd = 0; lum = .6; e.ant = 1;
      if (A) e.cap += wrapA(Math.atan2(A.y - e.y, A.x - e.x) - e.cap) * Math.min(1, dt * 8);
      if (e.tE > e.dur) { emet(e, 1); passe(e, 'rejoint', 3); }
      break;
    }
    case 'rejoint': {                            // rapprochement vers l'autre, puis ronde
      const A = cur.E[e.autre]; if (!A) { passe(e, 'derive', 2); break; }
      tx = A.x; ty = A.y; vd = T.v * 1.15; lum = .5; e.ant = .8;
      if (Math.hypot(A.x - e.x, A.y - e.y) < 62) { passe(e, 'ronde', 2.8); if (A.etat === 'attend' || A.etat === 'rejoint' || A.etat === 'derive') { passe(A, 'ronde', 2.8); A.autre = cur.E.indexOf(e); } }
      else if (e.tE > e.dur) passe(e, 'derive', 2);
      break;
    }
    case 'ronde': {                              // danse à deux autour du centre commun, impulsions synchrones
      const A = cur.E[e.autre]; if (!A) { passe(e, 'derive', 2); break; }
      const cx = (A.x + e.x) / 2, cy = (A.y + e.y) / 2, an = Math.atan2(e.y - cy, e.x - cx) + 1.6;
      tx = cx + Math.cos(an) * 34; ty = cy + Math.sin(an) * 34; vd = T.v * .9; hz = 2; lum = .55 + .35 * Math.max(0, Math.sin(t * 6));
      if (e.tE > e.dur) { passe(e, 'derive', 2.5 + 2 * e.R()); prochainLieu(e); e.ax = e.tx; e.ay = e.ty; }
      break;
    }
    case 'alerte': { vd = 0; lum = .9; regard = 2; if (e.tE > e.dur) passe(e, run ? 'suit' : 'derive', 2); break; }
    case 'suit': {                               // filature : derrière la bille, de côté, à distance ; s'écarte si elle fonce dessus
      if (!b) { passe(e, 'derive', 2); break; }
      const sp = Math.hypot(b.vx, b.vy), ux = sp > .3 ? b.vx / sp : 0, uy = sp > .3 ? b.vy / sp : 1, side = (i % 2 ? 1 : -1);
      const D = T.dist + 14 * Math.sin(t * 1.3 + e.ph);
      tx = b.x - ux * D * .75 - uy * side * D * .6; ty = b.y - uy * D * .75 + ux * side * D * .6;
      vd = T.v * 1.35; hz = T.hz * 1.4; lum = .55; regard = 2; e.ant = 1;
      const dx = e.x - b.x, dy = e.y - b.y, d = Math.hypot(dx, dy) || 1, ferme = -(b.vx * dx + b.vy * dy) / d;   // vitesse d'approche (unités/image)
      if (d < 70 && ferme > 2.2) { passe(e, 'recul', .8); e.fl = 1; e.tx = e.x + dx / d * 70 + (-dy / d) * 40 * side; e.ty = e.y + dy / d * 70 + (dx / d) * 40 * side; emet(e, 2); }
      else if (e.tn === 'agressif' && e.tE > 2.2 && d > 60) { passe(e, 'charge', .7); }
      break;
    }
    case 'charge': {                             // l'agressive fonce vers la bille… et vire au dernier moment
      if (!b) { passe(e, 'derive', 2); break; }
      tx = b.x; ty = b.y; vd = T.v * 1.8; hz = 4; lum = .8; regard = 2; e.ant = 1;
      if (Math.hypot(b.x - e.x, b.y - e.y) < 48 || e.tE > e.dur) { passe(e, 'recul', .6); const a = Math.atan2(e.y - b.y, e.x - b.x) + .9; e.tx = e.x + Math.cos(a) * 60; e.ty = e.y + Math.sin(a) * 60; e.fl = 1; }
      break;
    }
    case 'recul': { vd = T.v * 2; hz = 5; lum = .9; if (e.tE > e.dur) passe(e, run ? 'suit' : 'derive', 2); break; }
    case 'fete': {                               // victoire : ronde autour de la coupe, éclairs en chaîne
      const A = cur.arr, n = cur.E.length, an = t * .9 + i * TAU / n;
      tx = A[0] + Math.cos(an) * 66; ty = A[1] - 18 + Math.sin(an) * 40; vd = T.v * 1.2; hz = 2;
      const ph = (t * 1.6 - i / n) % 1; lum = .5 + .5 * (ph < .15 ? 1 - ph / .15 : 0);
      if (ph < dt * 1.6) { e.fl = 1; onde(e.x, e.y, 6, 40, .7, i % 3, .6); }
      break;
    }
    case 'abattu': { tx = e.x; ty = e.y + 30; vd = 10; hz = .4; lum = .12; if (e.tE > e.dur) { passe(e, 'derive', 2); e.ax = e.x; e.ay = e.y; } break; }
  }
  if (e.etat === avant && e.tE >= tE0) { e.tx = tx; e.ty = ty; }   // un changement d'état a déjà posé sa propre cible
  /* regard : vers la bille ou le lieu tâté ; sinon dans le sens de la nage */
  const sp = Math.hypot(e.vx, e.vy);
  let cible = sp > 10 ? Math.atan2(e.vy, e.vx) : e.cap;
  if (regard === 2 && b) cible = Math.atan2(b.y - e.y, b.x - e.x); else if (regard === 1) cible = Math.atan2(e.antY - e.y, e.antX - e.x);
  e.cap += wrapA(cible - e.cap) * Math.min(1, dt * (regard ? 7 : 4));
  e.lum += (lum - e.lum) * Math.min(1, dt * 4);
  /* nage par impulsions : la poussée bat avec la pulsation (même rythme que la lumière) */
  e.ph += dt * TAU * hz;
  const puls = Math.pow(Math.max(0, Math.sin(e.ph)), 2);
  e.puls = puls;
  const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy) || 1, fr = Math.min(1, d / 40);   // freinage à l'approche
  _v[0] = dx / d * vd * fr; _v[1] = dy / d * vd * fr;
  return .35 + 1.3 * puls;
}
/* ── intégration : inertie, poussée pulsée, zones interdites, murs, bords ── */
function bouge(e, dt, b, gain) {
  const T = e.T;
  let ax = (_v[0] - e.vx) * 3.2 * gain, ay = (_v[1] - e.vy) * 3.2 * gain;
  for (const z of cur.Z) { const dx = e.x - z[0], dy = e.y - z[1], d = Math.hypot(dx, dy) || 1, R = z[2] + 10; if (d < R) { const f = (R - d) * 9; ax += dx / d * f; ay += dy / d * f; } }
  if (b) { const dx = e.x - b.x, dy = e.y - b.y, d = Math.hypot(dx, dy) || 1, R = 40; if (d < R) { const f = (R - d) * 14; ax += dx / d * f; ay += dy / d * f; } }
  if (cur.cr) for (const c of cur.cr) { const dx = e.x - c.x, dy = e.y - c.y, d = Math.hypot(dx, dy) || 1, R = (c.r || c.rc || 30) + 28; if (d < R) { const f = (R - d) * 6; ax += dx / d * f; ay += dy / d * f; } }
  for (const s of cur.murs) { const d = dSeg(e.x, e.y, s); if (d < 22) { const f = (22 - d) * 10; ax += _n[0] * f; ay += _n[1] * f; } }
  for (const o of cur.E) if (o !== e) { const dx = e.x - o.x, dy = e.y - o.y, d = Math.hypot(dx, dy) || 1; if (d < 34) { ax += dx / d * (34 - d) * 6; ay += dy / d * (34 - d) * 6; } }
  const am = T.a * (.4 + gain), al = Math.hypot(ax, ay); if (al > am * 2.2) { ax *= am * 2.2 / al; ay *= am * 2.2 / al; }
  e.vx += ax * dt; e.vy += ay * dt;
  const vm = T.v * 2.1, sp = Math.hypot(e.vx, e.vy); if (sp > vm) { e.vx *= vm / sp; e.vy *= vm / sp; }
  e.vx *= 1 - Math.min(1, dt * .6); e.vy *= 1 - Math.min(1, dt * .6);
  e.x += e.vx * dt; e.y += e.vy * dt;
  if (e.x < BORD) { e.x = BORD; e.vx = Math.abs(e.vx) * .5; } if (e.x > W - BORD) { e.x = W - BORD; e.vx = -Math.abs(e.vx) * .5; }
  if (e.y < BORD) { e.y = BORD; e.vy = Math.abs(e.vy) * .5; } if (e.y > H - BORD) { e.y = H - BORD; e.vy = -Math.abs(e.vy) * .5; }
  e.fl = Math.max(0, e.fl - dt * 2.2); e.gon = Math.max(0, e.gon - dt * 1.6);
  e.trT += dt; if (e.trT > .05) { e.trT = 0; e.tr.copyWithin(2, 0, 22); e.tr[0] = e.x; e.tr[1] = e.y; if (e.trN < 12) e.trN++; }   // sillage : 12 positions
}
/* ── dessin des gestes (sous et sur le corps) ── */
function sillage(ctx, e, A) {
  const sp = Math.hypot(e.vx, e.vy); if (sp < 25 || e.trN < 3) return;
  const a = A * Math.min(1, (sp - 25) / 60) * .8, c = LUM[e.T.col];
  ctx.lineCap = 'round';
  for (let j = 1; j < e.trN; j++) {
    ctx.strokeStyle = 'rgba(' + c + ',' + (a * (1 - j / e.trN)).toFixed(3) + ')'; ctx.lineWidth = 3.2 * (1 - j / e.trN) + .4;
    ctx.beginPath(); ctx.moveTo(e.tr[j * 2 - 2], e.tr[j * 2 - 1]); ctx.lineTo(e.tr[j * 2], e.tr[j * 2 + 1]); ctx.stroke();
  }
}
function antennes(ctx, e, A, t, b) {             // deux antennes souples qui tâtent devant la créature
  const u = e.ant; if (u < .05) return;
  const cv = e.cap + e.capV * .6, hl = e.hl, hx = e.x + Math.cos(cv) * hl, hy = e.y + Math.sin(cv) * hl;
  let L = 16 + 16 * u; if (e.etat === 'tate' || e.etat === 'inspecte') L += 8 * Math.sin(e.tE * 11);
  if ((e.etat === 'suit' || e.etat === 'charge') && b) L += 6;
  let pr = 1; if (cur && cur.cr) for (const c of cur.cr) pr = Math.min(pr, .35 + .65 * lisse((c.r || c.rc || 30) + 10, (c.r || c.rc || 30) + 110, Math.hypot(e.x - c.x, e.y - c.y)));   // R474 : discrètes près des actives
  const aa = Math.min(1, A * .5 * u * pr);
  ctx.strokeStyle = 'rgba(' + LUM[e.T.col === 2 ? 1 : e.T.col] + ',' + aa.toFixed(3) + ')'; ctx.lineWidth = .65; ctx.lineCap = 'round';   // R474 : fines, teinte du décor (plus de blanc)
  for (let s = -1; s <= 1; s += 2) {
    const sw = .42 * s + .3 * Math.sin(t * (e.etat === 'cherche' ? 5 : 3) + e.ph + s), a1 = cv + sw, a2 = cv + sw * .4 + .25 * Math.sin(t * 4.3 + s * 2 + e.ph);
    const mx = hx + Math.cos(a1) * L * .55, my = hy + Math.sin(a1) * L * .55, ex = mx + Math.cos(a2) * L * .55, ey = my + Math.sin(a2) * L * .55;
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.quadraticCurveTo(mx, my, ex, ey); ctx.stroke();
    halo(ctx, e.T.col === 2 ? 1 : e.T.col, ex, ey, 3 + 2 * u + 4 * e.fl, A * pr * (.35 + .5 * e.fl));
  }
}
function dessinerSignaux(ctx, A0) {
  const t = cur.t;
  ctx.lineCap = 'round';
  for (const s of cur.SIG) {
    if (!s.on) continue;
    const u = (t - s.t0) / s.d, a = cur.E[s.a], b = cur.E[s.b];
    if (u >= 1) { s.on = false; recoit(b, s); onde(b.x, b.y, 4, 26, .6, b.T.col, .5); continue; }   // R477 : plus d'anneau gris-perle (teinte de la receveuse, plus discret)
    const c = LUM[s.kind === 0 ? 0 : s.kind === 1 ? 1 : 2];
    /* l'arc lumineux : un fil ténu qui se dessine, une tête brillante, une traîne */
    ctx.strokeStyle = 'rgba(' + c + ',' + (A0 * .32 * (1 - u * .5)).toFixed(3) + ')'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(a.x, a.y);
    for (let j = 1; j <= 10; j++) { const v = j / 10; ctx.lineTo(q(v, a.x, s.cx, b.x), q(v, a.y, s.cy, b.y)); }
    ctx.stroke();
    for (let j = 0; j < 6; j++) {
      const v0 = Math.max(0, u - j * .045), v1 = Math.max(0, u - (j + 1) * .045);
      ctx.strokeStyle = 'rgba(' + c + ',' + (A0 * (1 - j / 6)).toFixed(3) + ')'; ctx.lineWidth = 3.4 - j * .45;
      ctx.beginPath(); ctx.moveTo(q(v0, a.x, s.cx, b.x), q(v0, a.y, s.cy, b.y)); ctx.lineTo(q(v1, a.x, s.cx, b.x), q(v1, a.y, s.cy, b.y)); ctx.stroke();
    }
    halo(ctx, s.kind === 0 ? 0 : s.kind === 1 ? 1 : 2, q(u, a.x, s.cx, b.x), q(u, a.y, s.cy, b.y), 18, A0);
  }
  for (const o of cur.RG) {
    if (!o.on) continue;
    const u = (t - o.t0) / o.d; if (u >= 1) { o.on = false; continue; }
    const r = o.r0 + (o.r1 - o.r0) * (1 - (1 - u) * (1 - u));
    ctx.strokeStyle = 'rgba(' + LUM[o.c] + ',' + Math.min(1, A0 * o.a * 1.3 * (1 - u)).toFixed(3) + ')'; ctx.lineWidth = 1.4 + 3 * (1 - u);
    ctx.beginPath(); ctx.arc(o.x, o.y, r, 0, TAU); ctx.stroke();
  }
}
function liens(ctx, A0) {                        // ronde : un filament de lueur fugace relie les danseuses
  const t = cur.t;
  for (const e of cur.E) {
    if (e.etat !== 'ronde' || e.autre < 0) continue;
    const o = cur.E[e.autre]; if (!o || cur.E.indexOf(e) > e.autre) continue;
    const a = A0 * (.4 + .5 * Math.max(0, Math.sin(t * 6))), mx = (e.x + o.x) / 2 + 10 * Math.sin(t * 4), my = (e.y + o.y) / 2 + 10 * Math.cos(t * 3.3);
    ctx.strokeStyle = 'rgba(' + LUM[0] + ',' + a.toFixed(3) + ')'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.quadraticCurveTo(mx, my, o.x, o.y); ctx.stroke();
  }
}
function dessiner(ctx, lv, env) {
  if (!lv) { vider(); act = null; return; }
  if (!lv.cr) act = null;
  if (!cur || cur.idx !== lv.idx) monter(lv);
  const t0 = performance.now();
  let dt = cur.tPrev ? (t0 - cur.tPrev) / 1000 : 1 / 60; cur.tPrev = t0;
  if (dt > .05) dt = .05; if (dt < 0) dt = 0;
  const lent = !!(env && env.RM) || reduitOS();
  const dts = lent ? dt * .12 : dt;              // mouvement réduit : presque immobiles, sans sursaut
  cur.t += dts; cur.fondu = Math.min(1, cur.fondu + dt / 1.2);
  const P = PAL[cur.pal], S = env && env.S, b = S && S.ball, run = S && (S.mode === 'run' || S.mode === 'replay');
  const bv = run ? b : null;                     // la bille ne compte (filature, recul) que lorsqu'elle roule
  if (!lent) evenements(S, b);
  figurants(ctx, dt, dts, lent, S, b, run);   // R470 : la société décorative, derrière tout le reste
  if (lv.wd === 5) e5Decor(ctx, dts, S, b, run, lv);   // R484 · ÉTAGE 5 : décor vivant du Monde 5
  let pds = 0;
  for (let i = 0; i < cur.E.length; i++) {
    const e = cur.E[i];
    if (pds + e.poids > P[0] + 1e-6) { e.ap = 0; continue; } pds += e.poids;
    const g = cerveau(e, i, dts, S, bv, run);
    bouge(e, dts, bv || (b ? b : null), g);
    /* la bille (ou le lieu tâté) excite les cils / la trompe du motif : il la « regarde » */
    const k = e.k, pt = e.part;
    if (bv && Math.hypot(bv.x - e.x, bv.y - e.y) < 150) { pt.on = true; pt.x = bv.x / k; pt.y = bv.y / k; }
    else if (e.ant > .6) { pt.on = true; pt.x = e.antX / k; pt.y = e.antY / k; }
    else pt.on = false;
    const md = e.etat === 'recul' ? 'evite' : e.etat === 'charge' ? 'agr' : e.etat === 'suit' ? 'suit' : (e.etat === 'cherche' || e.etat === 'fete') ? 'actif' : 'cont';
    if (md !== e.mode) { e.mode = md; e.m.reglage({ mode: md }); }
    corps(e, dts, false);
    if (!e.hl) { const g0 = e.m.geo()[0]; e.hl = Math.max(8, Math.min(26, (g0.k === 'cell' ? g0.a : g0.r || 14) * k * .8)); }
    /* présence : nette, sauf tout près de ce qu'il faut lire (coupe, étoile, bille) */
    let f = 1;
    for (const z of cur.Z) f = Math.min(f, lisse(z[2] * .7, z[2] * 1.3, Math.hypot(e.x - z[0], e.y - z[1])));
    if (b) f = Math.min(f, lisse(24, 60, Math.hypot(e.x - b.x, e.y - b.y)));
    const cible = e.a0 * (.4 + .6 * f) * (e.etat === 'abattu' ? .55 : 1);
    e.ap += (cible - e.ap) * Math.min(1, dt * 3);
    const A = e.ap * cur.fondu;
    if (A < .01) continue;
    /* sous le corps : sillage + halo qui respire avec la nage */
    sillage(ctx, e, A);
    ctx.globalCompositeOperation = 'lighter';
    halo(ctx, e.T.col, e.x, e.y, e.hl * (2.2 + .6 * e.puls + 1.8 * e.fl + 1 * e.gon), A * (.22 + .45 * e.lum + .7 * e.fl));
    ctx.globalCompositeOperation = 'source-over';
    ctx.save();
    const q = 1 + .14 * e.gon + .04 * e.puls * (e.lum > .4 ? 1 : 0);       // gonflement : appel, signal reçu, sursaut
    ctx.translate(e.x, e.y); ctx.scale(k * q, k * q); ctx.translate(-e.x / k, -e.y / k);
    e.m.draw(ctx, A);
    if (e.dec && P[1] && e.geo) e.dec.draw(ctx, e.geo, .8 * A);
    ctx.restore();
    ctx.globalCompositeOperation = 'lighter';
    antennes(ctx, e, A, cur.t, bv);
    if (e.fl > .02) halo(ctx, 2, e.x, e.y, e.hl * (1 + e.fl), A * e.fl * .9);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.globalCompositeOperation = 'lighter';
  liens(ctx, cur.fondu);
  dessinerSignaux(ctx, cur.fondu);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  if (lv.cr) dessinerAct(ctx, lv, env);          // niveaux d'essai : la créature active par-dessus le décor (c'est elle qui agit)
  const ms = performance.now() - t0 - (cur.F ? cur.F.ms : 0);   // R470 : les figurants ont leur propre mesure
  mes.n++; mes.s += ms; if (ms > mes.max) mes.max = ms;
  cur.nImg++; if (cur.nImg > 6) cur.ema = cur.nImg < 9 ? ms : cur.ema * .92 + ms * .08;   // les premières images (caches, montage) ne comptent pas
  const mj = env && env.ms > 0 ? env.ms : 0; if (cur.nImg > 6) cur.emaJ = cur.nImg < 9 ? mj : cur.emaJ * .92 + mj * .08;
  if (cur.nImg > 10) {                           // qualité adaptative : notre coût (> 2,5 ms) ou l'image du jeu (> 8 ms)
    const now = t0;
    if (verrou >= 0) cur.pal = verrou;
    else if ((cur.ema > 2.5 || cur.emaJ > 8 || (cur.F && cur.F.ems > 1.8)) && cur.pal < PAL.length - 1 && now - cur.tDeg > 1200) { cur.pal++; cur.tDeg = now; cur.ema *= .6; }
    else if (cur.pal > 0 && cur.ema < 1.2 && cur.emaJ < 5 && now - cur.tDeg > 10000 && now - cur.tRem > 10000) { cur.pal--; cur.tRem = now; cur.tDeg = now; }
  }
}
/* ───── R473 · CRÉATURES ACTIVES — VIE, BIOLUMINESCENCE, FLUIDE ─────
   lv.cr : voir fluides.js (physique, intouchée). Ici : le DESSIN seul.
   La physique agit au point FLUID.crPos(c, S.frames). Le CORPS dessiné nage dans une enveloppe autour de ce point d'ancrage ;
   tout ce qui dit l'effet réel reste calé sur la physique : courant des cils = disque de rayon r centré sur l'ancrage, orienté au cap ;
   portée de la glu = filaments dont la pointe est à r de l'ancrage (quel que soit l'écart du corps) ; iris de la gueule = ancrage
   (l'enveloppe se referme dès que la bille approche, que la gueule tient ou recrache), siphon = cap de crachat.
   VIE COMMUNE (vie()) : horloge propre par créature (le tempo change sans saut de phase), errance en bruit lissé, respiration,
   pool de phases : REPOS (errance lente) · CURIOSITÉ (sursaut spontané, désynchronisé au hasard) · ALERTE (la bille approche) ·
   ACTION (effet réel) · RÉCUPÉRATION (la lumière retombe lentement). Ondes de bioluminescence (photophores en séquence).
   FLUIDE (particules en coordonnées du monde : elles restent dans l'eau quand le corps bouge) : bulles de respiration,
   traînées luminescentes, spirales d'aspiration, volutes. Aucune flèche, aucun grand cercle, aucun flash blanc.
   Charte : cils = cyan-vert froid · glu = mauve-magenta électrique · gueule = bleu-violet profond, éclats turquoise.
   Lisibilité sur le décor : une ombre douce sous le corps (absorption) + une lueur propre très basse. */
const hs = n => { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };   // hachage déterministe (rendu seul)
const cl01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
const nz = (t, s) => .55 * Math.sin(t + s) + .3 * Math.sin(1.73 * t + 2.1 * s + 1) + .15 * Math.sin(2.91 * t + 3.7 * s + 2);   // bruit lissé (-1..1)
const TEINTE = {
  cils:   { c1: [92, 236, 196], c2: [184, 255, 234], c3: [16, 78, 76], ac: [150, 255, 200] },
  glu:    { c1: [212, 104, 255], c2: [255, 186, 248], c3: [66, 22, 100], ac: [255, 112, 214] },
  gueule: { c1: [118, 104, 255], c2: [204, 198, 255], c3: [20, 16, 78], ac: [64, 236, 224] },
  bulle:  { c1: [116, 196, 255], c2: [214, 236, 255], c3: [12, 34, 84], ac: [255, 146, 206] },   // R474 · physalie : azur de gaz, glande corail
  systole: { c1: [178, 248, 104], c2: [232, 255, 204], c3: [28, 62, 22], ac: [156, 168, 255] },   // R475 · systole : vert-chartreuse de muscle vivant, nœud pervenche
  cortege: { c1: [186, 166, 255], c2: [240, 234, 255], c3: [30, 20, 72], ac: [128, 255, 214] },   // R476 · cortège : lilas opalin, photophores menthe
  braise:  { c1: [128, 212, 255], c2: [228, 246, 255], c3: [10, 30, 66], ac: [196, 176, 255] },   // R477 · braise : bleu glacé, blanc bioluminescent, accents lilas (ni cuivre ni orange)
  leurre:  { c1: [138, 222, 255], c2: [236, 250, 255], c3: [6, 24, 52], ac: [138, 255, 216] },     // R480 · leurre : cyan glacé, filament blanc, appât menthe
  echasse: { c1: [190, 184, 255], c2: [238, 240, 255], c3: [16, 18, 56], ac: [130, 236, 255] }     // R480 · échassière : lilas pâle, pattes blanc bleuté, relais cyan
};
const K_AB = 'rgb(4,10,18)';
const rgb = c => 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
let act = null; const SPA = {};
/* sprites pré-rendus (une fois par couleur) : lueur douce, photophore (cœur + halo), ombre */
function sprite(cle, c, sorte) {
  const k0 = cle + sorte; if (SPA[k0]) return SPA[k0];
  const k = document.createElement('canvas'); k.width = k.height = 64; const g = k.getContext('2d');
  const r = g.createRadialGradient(32, 32, 0, 32, 32, 32), s = c[0] + ',' + c[1] + ',' + c[2];
  if (sorte === 'x') {                               // R480 : cristal de givre (six branches fines et leurs rameaux)
    g.translate(32, 32); g.lineCap = 'round'; g.strokeStyle = 'rgba(' + s + ',1)';
    const gl = g.createRadialGradient(0, 0, 0, 0, 0, 30); gl.addColorStop(0, 'rgba(' + s + ',.35)'); gl.addColorStop(.4, 'rgba(' + s + ',.08)'); gl.addColorStop(1, 'rgba(' + s + ',0)');
    g.fillStyle = gl; g.fillRect(-32, -32, 64, 64);
    for (let j = 0; j < 6; j++) { g.save(); g.rotate(j * Math.PI / 3 + .26); g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -27);
      g.moveTo(0, -11); g.lineTo(-6, -17); g.moveTo(0, -11); g.lineTo(6, -17); g.moveTo(0, -19); g.lineTo(-4, -23); g.moveTo(0, -19); g.lineTo(4, -23);
      g.lineWidth = 2.6; g.globalAlpha = .9; g.stroke(); g.restore(); }
    g.beginPath(); g.arc(0, 0, 3.2, 0, TAU); g.fillStyle = 'rgba(255,255,255,.95)'; g.fill(); return (SPA[k0] = k);
  }
  if (sorte === 'o') { r.addColorStop(0, 'rgba(2,5,12,.62)'); r.addColorStop(.45, 'rgba(2,5,12,.34)'); r.addColorStop(1, 'rgba(2,5,12,0)'); }
  else if (sorte === 'p') {
    const w = [Math.round(c[0] * .35 + 166), Math.round(c[1] * .35 + 166), Math.round(c[2] * .35 + 166)].join(',');
    r.addColorStop(0, 'rgba(' + w + ',1)'); r.addColorStop(.1, 'rgba(' + s + ',.95)'); r.addColorStop(.28, 'rgba(' + s + ',.32)'); r.addColorStop(.6, 'rgba(' + s + ',.07)'); r.addColorStop(1, 'rgba(' + s + ',0)');
  } else { r.addColorStop(0, 'rgba(' + s + ',.8)'); r.addColorStop(.25, 'rgba(' + s + ',.36)'); r.addColorStop(.6, 'rgba(' + s + ',.08)'); r.addColorStop(1, 'rgba(' + s + ',0)'); }
  g.fillStyle = r; g.fillRect(0, 0, 64, 64); return (SPA[k0] = k);
}
function spr(ctx, im, x, y, R, a) { if (a <= .01 || R <= .3) return; ctx.globalAlpha = a > 1 ? 1 : a; ctx.drawImage(im, x - R, y - R, R * 2, R * 2); }
/* particules du milieu (coordonnées du monde) : 0 bulle · 1 traînée lumineuse · 2 spirale d'aspiration · 3 volute */
const NPA = 80, CHP = ['x', 'y', 'vx', 'vy', 'tx', 'ty', 'age', 'vie', 's', 'w', 'k'];
const luP = (Q, i) => { const k = Q.k[i]; return k === 2 ? Math.min(1, Q.age[i] * 2.5) * cl01((Q.vx[i] - Q.s[i]) / (Q.s[i] + 4)) : Math.sin(Math.PI * Q.age[i] / Q.vie[i]) * (k === 1 ? Q.s[i] : 1); };
function pool() { return { x: new Float32Array(NPA), y: new Float32Array(NPA), vx: new Float32Array(NPA), vy: new Float32Array(NPA), tx: new Float32Array(NPA), ty: new Float32Array(NPA),
  age: new Float32Array(NPA), vie: new Float32Array(NPA), s: new Float32Array(NPA), w: new Float32Array(NPA), k: new Uint8Array(NPA), n: 0, rr: 0, cx: 0, cy: 0 }; }
function emP(Q, k, x, y, vx, vy, vie, s, w) {
  let i; if (Q.n < NPA) i = Q.n++; else { i = Q.rr; Q.rr = (Q.rr + 1) % NPA; }
  if (k === 2) { x = Q.cx + Math.cos(vy) * vx; y = Q.cy + Math.sin(vy) * vx; }
  Q.k[i] = k; Q.x[i] = Q.tx[i] = x; Q.y[i] = Q.ty[i] = y; Q.vx[i] = vx; Q.vy[i] = vy; Q.age[i] = 0; Q.vie[i] = vie; Q.s[i] = s || 1; Q.w[i] = w || 0;
}
function majPart(Q, dt) {
  for (let i = 0; i < Q.n; i++) {
    Q.age[i] += dt;
    if (Q.age[i] >= Q.vie[i]) { const j = --Q.n; for (const f of CHP) Q[f][i] = Q[f][j]; i--; continue; }
    const k = Q.k[i];
    if (k === 2) {                                  // spirale : vx = rayon, vy = angle autour du centre ; w = vitesse d'entrée ; s = rayon d'arrivée
      Q.vx[i] -= dt * Q.w[i] * (1 + 14 / Math.max(4, Q.vx[i])); Q.vy[i] += dt * (1.3 + 26 / Math.max(5, Q.vx[i]));
      if (Q.vx[i] <= Q.s[i]) { Q.vie[i] = Q.age[i] + .001; Q.vx[i] = Q.s[i]; }
      Q.x[i] = Q.cx + Math.cos(Q.vy[i]) * Q.vx[i]; Q.y[i] = Q.cy + Math.sin(Q.vy[i]) * Q.vx[i];
    } else {
      const dr = k === 0 ? .9 : k === 3 ? .6 : (Q.w[i] || .35);
      if (k === 0) Q.vy[i] -= 7 * dt;               // la bulle monte
      Q.vx[i] *= 1 - dr * dt; Q.vy[i] *= 1 - dr * dt;
      Q.x[i] += Q.vx[i] * dt + (k === 0 ? Math.sin(Q.age[i] * 7 + i) * .12 : 0); Q.y[i] += Q.vy[i] * dt;
    }
    const lg = Math.min(1, dt * (k === 2 ? 7 : 7)); Q.tx[i] += (Q.x[i] - Q.tx[i]) * lg; Q.ty[i] += (Q.y[i] - Q.ty[i]) * lg;
  }
}
function dessinerPart(ctx, Q, e) {
  if (!Q.n) return;
  ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
  for (let bin = 0; bin < 3; bin++) {
    const lo = bin / 3, hi = (bin + 1) / 3, aB = (bin + .5) / 3;
    ctx.beginPath(); let nb = 0;                      // bulles : petits anneaux nets
    for (let i = 0; i < Q.n; i++) { if (Q.k[i] !== 0) continue; const u = Q.age[i] / Q.vie[i], f = Math.sin(Math.PI * Math.min(1, u * 1.6 + .02)) * (1 - u * .5); if (f < lo || f >= hi) continue;
      const rr = Q.s[i] * (1 + .5 * u); ctx.moveTo(Q.x[i] + rr, Q.y[i]); ctx.arc(Q.x[i], Q.y[i], rr, 0, TAU); nb++; }
    if (nb) { ctx.strokeStyle = e.K2; ctx.globalAlpha = .55 * aB; ctx.lineWidth = .5; ctx.stroke(); }
    ctx.beginPath(); nb = 0;                          // traînées : du point retardé à la tête
    for (let i = 0; i < Q.n; i++) { const k = Q.k[i]; if (k !== 1 && k !== 2) continue; const f = luP(Q, i); if (f < lo || f >= hi) continue;
      if (k === 2) {                                 // spirale : la traîne suit la courbe (angle et rayon en arrière)
        const r0 = Q.vx[i], a0 = Q.vy[i]; ctx.moveTo(Q.x[i], Q.y[i]);
        for (let q = 1; q <= 5; q++) { const rq = r0 * (1 + .05 * q) + q * .8, aq = a0 - q * (.05 + 2.2 / Math.max(6, rq)); ctx.lineTo(Q.cx + Math.cos(aq) * rq, Q.cy + Math.sin(aq) * rq); }
      } else { ctx.moveTo(Q.tx[i], Q.ty[i]); ctx.lineTo(Q.x[i], Q.y[i]); }
      nb++; }
    if (nb) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .2 * aB; ctx.lineWidth = 2.2; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .75 * aB; ctx.lineWidth = .55; ctx.stroke(); }
    ctx.beginPath(); nb = 0;                          // volutes : une spirale fine qui s'enroule en grandissant
    for (let i = 0; i < Q.n; i++) { if (Q.k[i] !== 3) continue; const u = Q.age[i] / Q.vie[i], f = Math.sin(Math.PI * u); if (f < lo || f >= hi) continue;
      const R0 = Q.s[i] * (.5 + .9 * u), a0 = Q.w[i] > 0 ? u * 5 : -u * 5, sg = Q.w[i] > 0 ? 1 : -1;
      for (let q = 0; q <= 16; q++) { const t = q / 16, an = a0 + sg * t * 4.4, rr = R0 * (.3 + .7 * t), px = Q.x[i] + Math.cos(an) * rr, py = Q.y[i] + Math.sin(an) * rr; q ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }   // R494 : volute lisse (16 pts, < 1 tour)
      nb++; }
    if (nb) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .07 * aB; ctx.lineWidth = 1.8; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .26 * aB; ctx.lineWidth = .35; ctx.stroke(); }   // R494 : voile + filet
  }
  const pp = e.SP;                                    // têtes lumineuses des traînées
  for (let i = 0; i < Q.n; i++) { const k = Q.k[i]; if (k !== 1 && k !== 2) continue; spr(ctx, k === 2 ? e.SA : pp, Q.x[i], Q.y[i], k === 2 ? 3 : 2.6 * Q.s[i], luP(Q, i) * (k === 2 ? .9 : .7)); }
  ctx.globalCompositeOperation = 'source-over';
}
function monterAct(lv) {
  act = { idx: lv.idx, tPrev: 0, t: 0, E: [], tr: new Float32Array(240), tf: new Uint8Array(120), tn: 0, fr0: -1, ms: 0, n: 0 };
  (lv.cr || []).forEach((c, i) => {
    const TT = TEINTE[c.t] || TEINTE.cils, al = Math.random();      // léger désynchronisé aléatoire (rendu seul)
    act.E.push({ c, i, al: 0, gon: 0, fl: 0, ex: 0, ph: hs(i * 7 + (lv.idx || 0)) * TAU, vph: 0, flux: hs(i + 3), puls: 0,
      ouv: .45, lx: 0, ly: 0, arcs: [], tArc: .4, gx: null, gk: 0, cg: null,
      px: new Float32Array(80), py: new Float32Array(80), cb: new Float32Array(400), tip: new Float32Array(48), gluFin: 0,
      /* vie */
      vit: .1, ac: 0, ali: 0, tl: al * 40, tw: al * 60, rs: al, bz: -2 - 4 * al, bp: 3, W: [], lqT: .5 + 2 * al, s1: al * 9, s2: hs(al * 3) * 9, s3: hs(al * 5) * 9,
      ox: 0, oy: 0, ox0: null, oy0: 0, bvx: 0, bvy: 0, bT: al * 2, vT: al, sT: al, Q: pool(), hd: 0,
      T: TT, K1: rgb(TT.c1), K2: rgb(TT.c2), K3: rgb(TT.c3), KA: rgb(TT.ac),
      SG: sprite(c.t, TT.c1, 'g'), SP: sprite(c.t, TT.c1, 'p'), SA: sprite(c.t + 'a', TT.ac, 'p'), SAG: sprite(c.t + 'a', TT.ac, 'g'), SO: sprite('', TT.c1, 'o') });
  });
}
/* VIE : pool de phases + horloges propres + ondes de bioluminescence */
function vie(e, dt, etat, prox) {
  e.bz -= dt;
  if (e.bz < -e.bp) { e.bz = 1.3 + 1.9 * Math.random(); e.bp = 3.5 + 6 * Math.random(); }   // sursaut de curiosité, puis pause au hasard
  const cur = etat === 0 && e.bz > 0;
  const vt = etat === 0 ? (cur ? .62 : .1) : etat === 1 ? .55 + .45 * prox : 1;
  e.vit += (vt - e.vit) * Math.min(1, dt * (vt > e.vit ? 3.2 : 1.1));
  const at = etat >= 2 ? 1 : 0;
  e.ac += (at - e.ac) * Math.min(1, dt * (at > e.ac ? 6 : .8));      // retombe lentement : récupération, la lumière s'éteint en douceur
  e.tl += dt * (.6 + 1.5 * e.vit + .9 * e.ac);
  e.tw += dt * (.17 + .5 * e.vit);
  e.rs += dt * (.2 + .3 * e.vit + .25 * e.ac);
  e.lqT -= dt;
  if (e.lqT <= 0) {
    if (e.W.length > 4) e.W.shift();
    e.W.push({ t: 0, d: e.ac > .5 ? .6 : e.vit > .4 ? .85 : 1.35, I: .55 + .45 * Math.max(e.vit, e.ac), em: 0 });
    e.lqT = e.ac > .5 ? .32 + .2 * Math.random() : etat === 1 ? .5 + .3 * Math.random() : cur ? .8 + .6 * Math.random() : 1.9 + 2.6 * Math.random();
  }
  for (let j = e.W.length - 1; j >= 0; j--) { const w = e.W[j]; w.t += dt / w.d; if (w.t > 1.45) e.W.splice(j, 1); }
}
function ondeA(e, u) {        // intensité de la bioluminescence au point u (0 = départ de l'onde, 1 = arrivée)
  let s = 0;
  for (const w of e.W) { const z = (u - (w.t * 1.3 - .15)) / .12; if (z > -3 && z < 3) s += w.I * Math.exp(-z * z); }
  return s > 1.2 ? 1.2 : s;
}
function ombre(ctx, e, x, y, rx, ry, rot, a) {   // absorption douce sous le corps : le décor recule, la créature se détache
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(rx, ry); ctx.globalAlpha = a; ctx.drawImage(e.SO, -1, -1, 2, 2); ctx.restore();
}
/* sillage de la bille, par segments marqués : 1 = dans les cils, 2 = recrachée, 3 = engluée — fin, jamais un ruban épais */
const SCOL = [null, 'rgba(92,236,196,', 'rgba(64,236,224,', 'rgba(212,104,255,', 'rgba(116,196,255,', 'rgba(178,248,104,', 'rgba(186,166,255,', 'rgba(128,212,255,', 'rgba(138,255,216,', 'rgba(190,184,255,'];
function sillageAct(ctx) {
  const n = act.tn; if (n < 2) return;
  ctx.lineCap = 'round';
  for (let pass = 0; pass < 2; pass++) for (let j = 1; j < n; j++) {
    const f = act.tf[j]; if (!f) continue;
    const age = (n - j) / n, al = (pass ? .55 : .12) * (1 - age) * (1 - age);
    if (al < .01) continue;
    ctx.strokeStyle = SCOL[f] + al.toFixed(3) + ')'; ctx.lineWidth = pass ? .9 : 4.5;
    ctx.beginPath(); ctx.moveTo(act.tr[j * 2 - 2], act.tr[j * 2 - 1]); ctx.lineTo(act.tr[j * 2], act.tr[j * 2 + 1]); ctx.stroke();
  }
}
/* tracé à deux passes : voile de lumière large et bas + filet net */
function deuxTraits(ctx, col, a, wl, wn, kl) { ctx.strokeStyle = col; ctx.globalAlpha = Math.min(1, a * (kl || .14)); ctx.lineWidth = wl; ctx.stroke(); ctx.globalAlpha = Math.min(1, a); ctx.lineWidth = wn; ctx.stroke(); }

/* ═════ CILS : ciliée cyan-vert, axe = cap ═════
   Errance : glisse le long de son axe (avance / recule, comme une paramécie), dérive latérale, cap qui oscille sans jamais
   cesser de montrer le courant. Repos : vague de cils lente, cyclose (vacuoles qui tournent dans le corps), photophores rares.
   Alerte : la vague s'accélère, les photophores courent de la queue au cap. Action : cyclose rapide, le noyau se divise,
   les vacuoles se multiplient ; chaque onde de lumière qui atteint l'avant lâche une traînée luminescente SUR LE CAP.
   Le courant : lignes de courant du disque d'action (centré sur la physique), poussières, bulles emportées, volutes à la sortie. */
function dessinerCils(ctx, e, x, y, etat, st, b, T, dt) {
  const c = e.c, r = c.r, a = (c.a || 0) * Math.PI / 180, I = e.al, X = e.ex, V = e.vit, AC = e.ac;
  const L = Math.min(48, r * .9), B = L * .36, sc = L / 28;
  const amp = 1 - .3 * AC;
  let ou = (e.wx * r * .16 + r * .06 * V * Math.sin(e.tl * 1.2 + e.s1)) * amp, ov = e.wy * r * .14 * amp;
  const wob = e.wr * (.22 + .12 * V) * amp, ca = Math.cos(a), sa = Math.sin(a);
  const queue = ou - L * 1.45, xq = x + ca * queue - sa * ov, xt = x + ca * (ou + L) - sa * ov;   // jamais hors de l'écran
  if (ca > .3 && xq < 2) ou += (2 - xq) / ca; if (ca < -.3 && xq > W - 2) ou += (xq - W + 2) / ca;
  if (ca > .3 && xt > W - 2) ou -= (xt - W + 2) / ca; if (ca < -.3 && xt < 2) ou -= (2 - xt) / ca;
  const bxw = x + ca * ou - sa * ov, byw = y + sa * ou + ca * ov, cb2 = Math.cos(a + wob), sb2 = Math.sin(a + wob);
  if (e.ox0 !== null && dt > 0) { e.bvx += ((bxw - e.ox0) / dt - e.bvx) * Math.min(1, dt * 4); e.bvy += ((byw - e.oy0) / dt - e.bvy) * Math.min(1, dt * 4); }
  e.ox0 = bxw; e.oy0 = byw;
  const W2 = (lx, ly, o) => { o[0] = bxw + cb2 * lx - sb2 * ly; o[1] = byw + sb2 * lx + cb2 * ly; return o; };
  e.vph += dt * (2.2 + 4 * V + 6 * AC);
  e.flux += dt * (.08 + .14 * V + .45 * AC);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* 0. ombre + lueur propre sous le corps */
  ombre(ctx, e, bxw, byw, L * 1.75, B * 2.6, a + wob, .55);
  ctx.globalCompositeOperation = 'lighter';
  ctx.save(); ctx.translate(bxw, byw); ctx.rotate(a + wob); ctx.scale(L * 1.5, B * 2.4); ctx.globalAlpha = .1 + .12 * V + .2 * AC; ctx.drawImage(e.SG, -1, -1, 2, 2); ctx.restore();
  /* 1. le courant, dans le repère du disque d'action (centré sur la physique, orienté au cap) */
  ctx.save(); ctx.translate(x, y); ctx.rotate(a);
  const dB0 = B * 1.9;
  for (let l = 0; l < 5; l++) {
    const o = [-.8, -.45, -.1, .38, .78][l] * r, h = Math.sqrt(r * r - o * o) * .96, NQ = 16;
    ctx.beginPath();
    for (let q2 = 0; q2 <= NQ; q2++) {
      const s = -h + 2 * h * q2 / NQ, g = Math.max(0, 1 - ((s - ou) / (L * 1.35)) * ((s - ou) / (L * 1.35)));
      let oy = o; const dv = o - ov; if (Math.abs(dv) < dB0) oy = o + (dv < 0 ? -1 : 1) * (dB0 - Math.abs(dv)) * g * g;
      oy += Math.sin(s * .07 - e.flux * 6 + l * 1.3) * (1 + .8 * V);
      e.cb[q2 * 2] = s; e.cb[q2 * 2 + 1] = oy;
      if (q2) ctx.lineTo(s, oy); else ctx.moveTo(s, oy);
    }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = .06 + .07 * V + .1 * AC; ctx.lineWidth = .55; ctx.stroke();
    for (let pp = 0; pp < 2; pp++) {                   // deux lueurs parcourent chaque ligne dans le sens du cap
      const u = (e.flux * (1.3 + .3 * l) + l * .27 + pp * .5 + e.ph) % 1, q0 = Math.floor(u * NQ * .999), ql = Math.max(0, q0 - 3);
      ctx.beginPath(); ctx.moveTo(e.cb[ql * 2], e.cb[ql * 2 + 1]);
      for (let q2 = ql + 1; q2 <= q0 + 1 && q2 <= NQ; q2++) ctx.lineTo(e.cb[q2 * 2], e.cb[q2 * 2 + 1]);
      deuxTraits(ctx, e.K1, Math.sin(Math.PI * u) * (.2 + .25 * V + .35 * AC) * (pp ? .6 : 1), 2.6, .7, .25);
    }
  }
  const NM = r > 60 ? 18 : 12;                        // poussières emportées (contournent le corps)
  const motes = [];
  ctx.beginPath();
  for (let j = 0; j < NM; j++) {
    const o = (hs(j * 3.1 + 1) * 2 - 1) * r * .9, h = Math.sqrt(r * r - o * o);
    const u = (e.flux * (.75 + .5 * hs(j * 7.3)) + hs(j * 1.7)) % 1, s = -h + 2 * h * u;
    let oy = o; const dB = B * 1.7, g = Math.max(0, 1 - ((s - ou) / (L * 1.3)) * ((s - ou) / (L * 1.3))), dv = o - ov;
    if (Math.abs(dv) < dB) oy = o + (dv < 0 ? -1 : 1) * (dB - Math.abs(dv)) * g * g;
    oy += Math.sin(T * 1.1 + j * 2.1) * 1.1;
    const env = Math.sin(Math.PI * u), al = env * env;
    if (al < .05) continue;
    const len = (5 + 12 * (.4 * V + AC)) * env;
    motes.push(s, oy, al);
    ctx.moveTo(s - len, oy - .3); ctx.lineTo(s - 1, oy);
  }
  ctx.strokeStyle = e.K1; ctx.lineWidth = .6; ctx.globalAlpha = .12 + .1 * V + .2 * AC; ctx.stroke();
  ctx.fillStyle = e.K2; ctx.beginPath();
  for (let j = 0; j < motes.length; j += 3) { ctx.moveTo(motes[j] + .7, motes[j + 1]); ctx.arc(motes[j], motes[j + 1], .7, 0, TAU); }
  ctx.globalAlpha = .4 + .25 * V + .3 * AC; ctx.fill();
  ctx.restore();
  ctx.globalCompositeOperation = 'source-over';
  /* 2. le corps */
  ctx.save(); ctx.translate(bxw, byw); ctx.rotate(a + wob);
  const br = Math.sin(e.rs * TAU), NS = 22, px = e.px, py = e.py;
  for (let k = 0; k <= NS; k++) {
    const s = -.5 * Math.cos(Math.PI * k / NS) + .5 * (2 * k / NS - 1), w = (s > 0 ? B * Math.sqrt(Math.max(0, 1 - Math.pow(s, 3.2))) : B * Math.pow(Math.max(0, 1 - Math.pow(-s, 1.7)), .75) * (1 + .12 * s)) * (1 + .035 * br);
    const yc = B * .2 * Math.sin(2.1 * s - e.vph * .32) * (.6 - .4 * s) * (1 + .6 * V);
    px[k] = s * L; py[k] = yc - w; px[2 * NS + 1 - k] = s * L; py[2 * NS + 1 - k] = yc + w;
  }
  const NP = 2 * NS + 2;
  const corps = sx => { ctx.beginPath(); ctx.moveTo(px[0] * sx, py[0] * sx); for (let k = 1; k < NP; k++) ctx.lineTo(px[k] * sx, py[k] * sx); ctx.closePath(); };
  if (!e.cg || e.cgc !== ctx) {
    const g = ctx.createRadialGradient(L * .25, -B * .2, 0, 0, 0, L); e.cgc = ctx;
    g.addColorStop(0, 'rgba(184,255,234,.2)'); g.addColorStop(.45, 'rgba(16,78,76,.32)'); g.addColorStop(.8, 'rgba(92,236,196,.2)'); g.addColorStop(1, 'rgba(184,255,234,.3)');
    e.cg = g;
  }
  corps(1); ctx.fillStyle = e.cg; ctx.globalAlpha = .78; ctx.fill();
  /* cils : deux rangées, vague métachronale qui file vers le cap */
  const NC = 46, cb = e.cc || (e.cc = new Float32Array(600)); let nc = 0;
  for (let side = 0; side < 2; side++) for (let k = 0; k < NC; k++) {
    const kf = 1 + (NS - 2.02) * k / (NC - 1), kk = Math.floor(kf), fk = kf - kk, id = side ? 2 * NS + 1 - kk : kk, id2 = side ? id - 1 : id + 1;
    const bx = px[id] + (px[id2] - px[id]) * fk, by = py[id] + (py[id2] - py[id]) * fk, nx0 = px[side ? id - 1 : id + 1] - px[side ? id + 1 : id - 1], ny0 = py[side ? id - 1 : id + 1] - py[side ? id + 1 : id - 1];
    const nl = Math.hypot(nx0, ny0) || 1, tx = nx0 / nl, ty = ny0 / nl, nx = side ? -ty : ty, ny = side ? tx : -tx;
    const ph = e.vph - k * .5 + side * .4, lc = (2.6 + 1 * Math.sin(ph)) * (1 + .25 * V + .2 * AC) * sc;
    const tilt = .3 + (.32 + .25 * V) * Math.cos(ph), ct = Math.cos(tilt), stt = Math.sin(tilt);
    const ex = bx + (nx * ct + Math.abs(tx) * stt) * lc, ey = by + ny * ct * lc;
    cb[nc++] = bx; cb[nc++] = by; cb[nc++] = bx + nx * lc * .55 - Math.abs(tx) * lc * .25 * Math.sin(ph); cb[nc++] = by + ny * lc * .55; cb[nc++] = ex; cb[nc++] = ey;
  }
  const traceCils = (i0, i1) => { for (let i = i0; i < i1; i++) { const o = i * 6; ctx.moveTo(cb[o], cb[o + 1]); ctx.quadraticCurveTo(cb[o + 2], cb[o + 3], cb[o + 4], cb[o + 5]); } };
  ctx.beginPath(); traceCils(0, 2 * NC);
  deuxTraits(ctx, e.K2, .26 + .14 * V, 1.6 * sc, .28 * sc + .05, .25);
  /* touffe caudale : longs cils qui ondulent derrière, plus amples quand elle s'agite */
  ctx.beginPath();
  for (let j = 0; j < 4; j++) {
    const yb = (j - 1.5) * B * .18, L2 = L * (.36 + .07 * j) * (1 + .25 * V), w = Math.sin(e.vph * .6 + j * 1.3) * (2.5 + 2 * V) * sc;
    ctx.moveTo(-L * .96, yb); ctx.quadraticCurveTo(-L - L2 * .5, yb + w, -L - L2, yb - w * .6 + (j - 1.5) * 2);
  }
  deuxTraits(ctx, e.K2, .3 + .15 * V, 2 * sc, .4 * sc + .1, .2);
  /* membrane double */
  corps(1); deuxTraits(ctx, e.K2, .55 + .2 * V + .2 * AC, 4 * sc, .6 * sc + .1, .12);
  corps(.84); ctx.strokeStyle = e.K1; ctx.globalAlpha = .2; ctx.lineWidth = .8 * sc; ctx.stroke();
  /* sillon oral + vestibule (la bouche respire) */
  ctx.beginPath(); ctx.moveTo(L * .66, -B * .45); ctx.quadraticCurveTo(L * .25, B * .3, L * .02, B * .12);
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .34; ctx.lineWidth = .7 * sc; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(L * .04, B * .14, B * (.16 + .04 * br), B * .1, .4, 0, TAU); ctx.globalAlpha = .45; ctx.lineWidth = .55 * sc; ctx.stroke();
  /* cyclose : vacuoles alimentaires qui tournent dans le corps ; en action elles se multiplient (bourgeonnent du noyau) */
  const NV0 = 5, NVX = 4, nuX = -L * .1, nuY = B * .04, cyc = e.tl * (.28 + .5 * AC) + e.ph;
  const vac = [];
  for (let j = 0; j < NV0 + NVX; j++) {
    let f = 1; if (j >= NV0) { f = cl01(AC * 4 - (j - NV0) * .6); if (f <= .02) continue; }
    const ph = cyc + j / (NV0 + (j >= NV0 ? NVX : 0)) * TAU * (j >= NV0 ? 1 : 1) + (j >= NV0 ? .4 : 0);
    let vx = Math.cos(ph) * L * .56, vy = Math.sin(ph) * B * .5 * (.85 + .15 * Math.cos(ph * 2));
    if (f < 1) { const m = f * f; vx = nuX + (vx - nuX) * m; vy = nuY + (vy - nuY) * m; }
    const vr = (1.5 + .5 * (j % 3)) * sc * (.55 + .45 * f) * (1 + .1 * Math.sin(e.tl * 2 + j));
    vac.push(vx, vy, vr, f);
  }
  ctx.beginPath(); for (let j = 0; j < vac.length; j += 4) { ctx.moveTo(vac[j] + vac[j + 2], vac[j + 1]); ctx.arc(vac[j], vac[j + 1], vac[j + 2], 0, TAU); }
  ctx.fillStyle = K_AB; ctx.globalAlpha = .4; ctx.fill(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .5; ctx.lineWidth = .5 * sc; ctx.stroke();
  /* noyau (macronoyau réniforme + micronoyau) ; en action il s'étire et se divise */
  const dv = B * .34 * AC * (.6 + .4 * Math.sin(e.tl * 1.6)), nrx = B * (.52 - .14 * AC), nry = B * (.34 - .05 * AC);
  ctx.beginPath(); ctx.ellipse(nuX - dv, nuY, nrx, nry, .18, 0, TAU);
  if (AC > .05) { ctx.moveTo(nuX + dv + nrx, nuY); ctx.ellipse(nuX + dv, nuY, nrx, nry, -.18, 0, TAU); }
  ctx.fillStyle = e.K3; ctx.globalAlpha = .55; ctx.fill(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .4 + .2 * AC; ctx.lineWidth = .6 * sc; ctx.stroke();
  ctx.beginPath(); ctx.arc(nuX + B * .55, nuY - B * .22, .9 * sc, 0, TAU); ctx.fillStyle = e.K2; ctx.globalAlpha = .55; ctx.fill();
  /* vacuoles contractiles avant/arrière : canaux en étoile, en alternance avec la respiration */
  ctx.beginPath();
  for (let v = 0; v < 2; v++) {
    const pv = .5 + .5 * Math.sin(e.rs * TAU * 2 + v * Math.PI), vcx = v ? L * .5 : -L * .6, vcy = v ? -B * .08 : B * .05;
    for (let j = 0; j < 6; j++) { const an = j * TAU / 6 + .3; ctx.moveTo(vcx + Math.cos(an) * 1.4 * sc, vcy + Math.sin(an) * 1.4 * sc); ctx.lineTo(vcx + Math.cos(an) * (2.6 + 2.6 * pv) * sc, vcy + Math.sin(an) * (2.6 + 2.6 * pv) * sc * .7); }
    ctx.moveTo(vcx + 1.4 * sc * (.6 + .6 * pv), vcy); ctx.arc(vcx, vcy, 1.4 * sc * (.6 + .6 * pv), 0, TAU);
  }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .45; ctx.lineWidth = .5 * sc; ctx.stroke();
  /* granulations */
  ctx.fillStyle = e.K2; ctx.globalAlpha = .35; ctx.beginPath();
  for (let j = 0; j < 16; j++) { const g2 = cyc * .6 + hs(j * 5.7) * TAU, gx = Math.cos(g2) * L * .7 * hs(j * 2.3 + 1), gy = Math.sin(g2) * B * .55 * hs(j * 9.1); ctx.rect(gx - .4, gy - .4, .8, .8); }
  ctx.fill();
  /* 3. bioluminescence : les ondes courent de la queue au cap — cils, photophores, membrane */
  ctx.globalCompositeOperation = 'lighter';
  for (let band = 0; band < 2; band++) {
    ctx.beginPath(); let any = false;
    for (let side = 0; side < 2; side++) for (let k = 0; k < NC; k++) {
      const v = ondeA(e, k / (NC - 1)); if (v < (band ? .55 : .25)) continue;
      const o = (side * NC + k) * 6; ctx.moveTo(cb[o], cb[o + 1]); ctx.quadraticCurveTo(cb[o + 2], cb[o + 3], cb[o + 4], cb[o + 5]); any = true;
    }
    if (any) { ctx.strokeStyle = band ? e.K2 : e.K1; ctx.globalAlpha = band ? .7 : .4; ctx.lineWidth = (band ? .3 : .65) * sc; ctx.stroke(); }
  }
  const NPH = 9;
  for (let side = 0; side < 2; side++) for (let j = 0; j < NPH; j++) {
    const u = (j + .5) / NPH, k = Math.round(1 + u * (NS - 2)), id = side ? 2 * NS + 1 - k : k, v = ondeA(e, u);
    const fx = px[id] * .9, fy = py[id] * .72 + (side ? -1 : 1) * .5;
    spr(ctx, e.SP, fx, fy, (2.2 + 3 * v) * sc, .2 + .1 * V + .8 * v);
  }
  if (AC > .02) spr(ctx, e.SG, nuX, nuY, B * 1.6, .35 * AC * (.7 + .3 * Math.sin(e.tl * 3)));
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 4. le milieu : traînées luminescentes lâchées sur le cap, bulles de respiration, volutes à la sortie du courant */
  const Q = e.Q, o = PA;
  for (const w of e.W) if (!w.em && w.t > .85) { w.em = 1; const n = AC > .5 ? 3 : 1 + (V > .5);
    for (let j = 0; j < n; j++) { W2(L * 1.02, (j - (n - 1) / 2) * B * .5, o); const sp = 26 + 30 * V + 26 * AC + 8 * j; emP(Q, 1, o[0], o[1], Math.cos(a + (j - (n - 1) / 2) * .12) * sp, Math.sin(a + (j - (n - 1) / 2) * .12) * sp, 1.5 + .4 * j, .8 + .25 * AC, .25); } }
  e.bT -= dt * (1 + 1.5 * V + AC);
  if (e.bT <= 0) { W2(L * .04, B * .14, o); emP(Q, 0, o[0], o[1], ca * (10 + 10 * V) + (Math.random() - .5) * 4, sa * (10 + 10 * V) - 2, 2 + Math.random(), .8 + .9 * Math.random()); e.bT = 1.3 + 1.2 * Math.random(); }
  e.vT -= dt * (.6 + V + 1.5 * AC);
  if (e.vT <= 0) { const sd = (e.hd = 1 - e.hd) ? 1 : -1, s0 = r * .62, l0 = sd * r * (.35 + .2 * Math.random());
    emP(Q, 3, x + ca * s0 - sa * l0, y + sa * s0 + ca * l0, ca * 9 - sa * sd * 3, sa * 9 + ca * sd * 3, 2.2, 3 + 2 * Math.random(), sd); e.vT = .9 + .8 * Math.random(); }
  majPart(Q, dt); dessinerPart(ctx, Q, e);
  if (b && etat === 2) { ctx.globalCompositeOperation = 'lighter'; spr(ctx, e.SG, b.x, b.y, 18, .22); ctx.globalCompositeOperation = 'source-over'; }
}

/* ═════ GLU : cténophore mauve-magenta, filaments collants, électricité ténue ═════
   Errance : dérive et balancement ; les filaments traînent derrière le mouvement (frottement), mais leur pointe reste à r de
   l'ancrage : la portée affichée est la vraie. Respiration : le corps se contracte, les filaments s'évasent, une bulle s'échappe.
   Palettes ciliées : ondes lumineuses (magenta ↔ rose) qui descendent les huit rangées, plus vives à l'alerte.
   Toile : fils de mucus qui se tendent entre les pointes, perlés (le bord de la zone collante, sans cercle).
   Action (engluée) : fils + arcs jusqu'à la bille, digestion : le pharynx s'allume, des grains y tournent. */
function arcAjoute(e, de, a, vie, T, f) { if (e.arcs.length > 9) e.arcs.shift(); e.arcs.push({ de, a, t0: T, vie, gr: Math.floor(hs(T * 13.7 + e.arcs.length) * 9999), f: f || 1 }); }
function pointArc(e, k, b, x, y, out) {   // -1 = corps, -2 = bille, ≥ 0 = bout de filament
  if (k === -1) { out[0] = x + e.ox; out[1] = y + e.oy; } else if (k === -2 && b) { out[0] = b.x; out[1] = b.y; } else if (k <= -10) { out[0] = x + e.tip[(-k - 10) * 2] * .5 + e.ox * .5; out[1] = y + e.tip[(-k - 10) * 2 + 1] * .5 + e.oy * .5; }
  else { out[0] = x + e.tip[k * 2]; out[1] = y + e.tip[k * 2 + 1]; }
}
const PA = [0, 0], PB = [0, 0];
function tracerArc(ctx, x1, y1, x2, y2, gr, T, ec) {
  const dx = x2 - x1, dy = y2 - y1, D = Math.hypot(dx, dy) || 1, nx = -dy / D, ny = dx / D, n = D > 60 ? 9 : 6;
  const g = gr + Math.floor(T * 22);
  ctx.moveTo(x1, y1); let bxp = 0, byp = 0;
  for (let i = 1; i < n; i++) {
    const u = i / n, j = (hs(g * 1.3 + i * 7.7) - .5) * Math.min(D * .3, 14) * ec * Math.sin(Math.PI * u) * 1.6;
    const qx = x1 + dx * u + nx * j, qy = y1 + dy * u + ny * j; ctx.lineTo(qx, qy);
    if (i === (n >> 1)) { bxp = qx; byp = qy; }
  }
  ctx.lineTo(x2, y2);
  if (hs(g * .7) > .45) {
    const s = hs(g * 2.1) > .5 ? 1 : -1, bl = D * (.18 + .15 * hs(g * 3.3));
    let qx = bxp, qy = byp; ctx.moveTo(qx, qy);
    for (let i = 1; i <= 3; i++) { qx += (dx / D * .55 + nx * s * .8) * bl / 3 + (hs(g + i * 4.1) - .5) * 3; qy += (dy / D * .55 + ny * s * .8) * bl / 3 + (hs(g + i * 6.3) - .5) * 3; ctx.lineTo(qx, qy); }
  }
}
function dessinerGlu(ctx, e, x, y, etat, st, b, T, dt, fr) {
  const c = e.c, r = c.r, I = e.al, X = e.ex, V = e.vit, AC = e.ac, englue = etat === 2 && b;
  const ry = Math.min(18, r * .56), rx = ry * .74, sc = ry / 13.4;
  const br = Math.sin(e.rs * TAU), amp = (7 + r * .14) * (1 - .55 * AC);
  const ox = e.wx * amp, oy = e.wy * amp * .8 + 1.2 * Math.sin(e.tl * 1.1 + e.ph);
  e.ox = ox; e.oy = oy;
  if (e.ox0 !== null && dt > 0) { e.bvx += ((ox - e.ox0) / dt - e.bvx) * Math.min(1, dt * 3); e.bvy += ((oy - e.oy0) / dt - e.bvy) * Math.min(1, dt * 3); }
  e.ox0 = ox; e.oy0 = oy;
  const rot = e.wr * .3 + cl01(Math.abs(e.bvx) / 30) * Math.sign(e.bvx) * .12 + .06 * Math.sin(e.tl * .7 + e.ph);
  const bx = b ? b.x - x : 0, by = b ? b.y - y : 0, bd = Math.hypot(bx, by) || 1, ba = Math.atan2(by, bx);
  /* ombre + lueur */
  ombre(ctx, e, x + ox, y + oy, ry * 1.9, ry * 2.2, rot, .5);
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, ox, oy, ry * 2.6, .1 + .12 * V + .22 * AC + .06 * (.5 + .5 * br));
  ctx.globalCompositeOperation = 'source-over';
  /* 1. filaments : la pointe est à la vraie portée (r) depuis l'ancrage, quelle que soit la dérive du corps */
  const NF = 21, NSEG = 8, tip = e.tip, P = e.cb, near = [];
  const drx = -e.bvx * .09, dry = -e.bvy * .09, sy = 1 + .045 * br, sx2 = 1 - .03 * br;
  for (let i = 0; i < NF; i++) {
    const th = i / NF * TAU + .2 + .1 * Math.sin(e.tl * .4 + i * 1.7) + .05 * br;
    const r0x = ox + Math.cos(th) * rx * .92 * sx2, r0y = oy + Math.sin(th) * ry * .92 * sy, dirx = Math.cos(th), diry = Math.sin(th);
    const lg = i % 3 === 0, Rf = r * ((lg ? .97 : .7 + .14 * hs(i * 2.7)) + .04 * Math.sin(e.tl * .55 + i * 2.3)) * (englue ? .8 : 1);
    const od = r0x * dirx + r0y * diry, Lf = Math.max(3, -od + Math.sqrt(Math.max(0, od * od - (r0x * r0x + r0y * r0y) + Rf * Rf)));
    let lean = 0;
    if (b && (etat === 1 || englue)) lean = Math.max(0, Math.cos(th - ba)) * (englue ? .25 : .45 * X);
    const cur = Math.sin(e.tl * .3 + i * 2.2) * .9, o = i * (NSEG + 1) * 2;
    P[o] = r0x; P[o + 1] = r0y;
    for (let s = 1; s <= NSEG; s++) {
      const u = s / NSEG, wv = (Math.sin(u * 3.6 - e.tl * (1.3 + 2 * V) + i * 1.9) * (.5 + 1.4 * u) + (3 + 1.6 * cur) * u * u) * sc;
      let sx = r0x + dirx * Lf * u - diry * wv + drx * u * u, sy2 = r0y + diry * Lf * u + dirx * wv + u * u * 2.2 * sc + dry * u * u;
      if (lean > 0) { sx += (bx - sx) * lean * u * u; sy2 += (by - sy2) * lean * u * u; }
      P[o + s * 2] = sx; P[o + s * 2 + 1] = sy2;
    }
    tip[i * 2] = P[o + NSEG * 2]; tip[i * 2 + 1] = P[o + NSEG * 2 + 1];
    near.push([Math.cos(th - ba), i]);
  }
  const fil = (s0, s1) => { ctx.beginPath(); for (let i = 0; i < NF; i++) { const o = i * (NSEG + 1) * 2; ctx.moveTo(P[o + s0 * 2], P[o + s0 * 2 + 1]); for (let s = s0 + 1; s <= s1; s++) ctx.lineTo(P[o + s * 2], P[o + s * 2 + 1]); } };
  fil(0, 4); deuxTraits(ctx, e.K2, .42 + .25 * V + .2 * AC, 2.4 * sc, .34 * sc + .05, .2);
  fil(4, NSEG); deuxTraits(ctx, e.K1, .32 + .25 * V + .2 * AC, 2.2 * sc, .3 * sc + .04, .2);
  /* toile de mucus entre pointes voisines : fils perlés qui se tendent et se relâchent (le bord collant, sans cercle) */
  ctx.beginPath(); const perles = [];
  for (let i = 0; i < NF; i++) {
    const j = (i + 1) % NF, v = Math.sin(e.tl * .45 + i * 1.7 + e.ph); if (v < .35 - .3 * V) continue;
    const ax = tip[i * 2], ay = tip[i * 2 + 1], bx2 = tip[j * 2], by2 = tip[j * 2 + 1], mx = (ax + bx2) * .5 * .86, my = (ay + by2) * .5 * .86 + 2.5;
    ctx.moveTo(ax, ay); ctx.quadraticCurveTo(mx, my, bx2, by2);
    perles.push(.25 * ax + .5 * mx + .25 * bx2, .25 * ay + .5 * my + .25 * by2);
  }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .18 + .15 * V + .1 * AC; ctx.lineWidth = .4; ctx.stroke();
  ctx.globalCompositeOperation = 'lighter';
  for (let j = 0; j < perles.length; j += 2) spr(ctx, e.SP, perles[j], perles[j + 1], 2.2 * sc, .35 + .25 * V);
  /* colloblastes : perles collantes en bout de filament, allumées tour à tour (vague qui fait le tour) */
  for (let i = 0; i < NF; i++) {
    const tw = Math.pow(.5 + .5 * Math.sin(e.tl * 1.9 - i * TAU / NF * 2), 4);
    spr(ctx, i % 2 ? e.SA : e.SP, tip[i * 2], tip[i * 2 + 1], (i % 3 ? 2 : 3.2) * sc * (1 + tw), .25 + .25 * V + .55 * tw * (.4 + .6 * Math.max(V, AC)));
  }
  ctx.globalCompositeOperation = 'source-over';
  /* 2. le corps : ovale translucide qui respire, huit rangées de palettes qui tournent et s'irisent */
  ctx.save(); ctx.translate(ox, oy); ctx.rotate(rot); ctx.scale(sx2, sy);
  if (!e.cg || e.cgc !== ctx) {
    const g = ctx.createRadialGradient(-rx * .2, -ry * .3, 0, 0, 0, ry); e.cgc = ctx;
    g.addColorStop(0, 'rgba(255,186,248,.18)'); g.addColorStop(.55, 'rgba(66,22,100,.3)'); g.addColorStop(.85, 'rgba(212,104,255,.22)'); g.addColorStop(1, 'rgba(255,186,248,.34)');
    e.cg = g;
  }
  ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, 0, TAU); ctx.fillStyle = e.cg; ctx.globalAlpha = 1; ctx.fill();
  deuxTraits(ctx, e.K2, .5 + .25 * V, 4 * sc, .6 * sc + .1, .14);
  ctx.beginPath(); ctx.ellipse(0, ry * .06, rx * .5, ry * .66, 0, 0, TAU); ctx.strokeStyle = e.K1; ctx.globalAlpha = .3 + .3 * AC; ctx.lineWidth = .6 * sc; ctx.stroke();   // pharynx
  /* digestion : grains qui tournent dans le pharynx, plus nombreux et plus vifs en action */
  const ND = 3 + Math.round(5 * AC);
  ctx.fillStyle = e.K2; ctx.beginPath();
  for (let j = 0; j < ND; j++) { const an = e.tl * (.6 + 1.6 * AC) * (j % 2 ? 1 : -1) + j * 2.4, rr = .3 + .55 * hs(j * 3.3); ctx.moveTo(Math.cos(an) * rx * .45 * rr + .7, ry * .06 + Math.sin(an) * ry * .6 * rr); ctx.arc(Math.cos(an) * rx * .45 * rr, ry * .06 + Math.sin(an) * ry * .6 * rr, .7 * sc, 0, TAU); }
  ctx.globalAlpha = .4 + .4 * AC; ctx.fill();
  const rotM = e.tl * .5 + e.ph, NR = 8, NPL = 7;
  const plDim = [], plLit = [], plLitA = [];
  ctx.beginPath();
  for (let m = 0; m < NR; m++) {
    const ph = rotM + m * TAU / NR, sx = Math.sin(ph), fr2 = Math.cos(ph);
    if (fr2 < -.3) continue;
    const ax2 = Math.abs(sx) * rx * .9;
    ctx.moveTo(0, -ry * .9); ctx.ellipse(0, 0, Math.max(.01, ax2), ry * .9, 0, -Math.PI / 2, Math.PI / 2, sx < 0);
    for (let j = 0; j < NPL; j++) {
      const v = -Math.PI / 2 + Math.PI * (j + .5) / NPL, qx = Math.cos(v) * ax2 * (sx < 0 ? -1 : 1), qy = Math.sin(v) * ry * .9;
      const w = ondeA(e, (j + .5) / NPL) + .35 * Math.max(0, Math.sin(e.tl * 5 - j * 1.1 + m * .8)) * (.3 + V);
      (w > .45 ? (m % 2 ? plLitA : plLit) : plDim).push(qx, qy, w);
    }
  }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .26 + .1 * V; ctx.lineWidth = .45 * sc + .05; ctx.stroke();
  ctx.fillStyle = e.K2; ctx.beginPath();
  for (let j = 0; j < plDim.length; j += 3) { ctx.moveTo(plDim[j] + .6, plDim[j + 1]); ctx.arc(plDim[j], plDim[j + 1], .5 * sc, 0, TAU); }
  ctx.globalAlpha = .32; ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  for (let j = 0; j < plLit.length; j += 3) spr(ctx, e.SP, plLit[j], plLit[j + 1], 2.4 * sc, .5 * plLit[j + 2]);
  for (let j = 0; j < plLitA.length; j += 3) spr(ctx, e.SA, plLitA[j], plLitA[j + 1], 2.4 * sc, .5 * plLitA[j + 2]);
  spr(ctx, e.SP, 0, -ry * .8, 3 * sc, .5 + .3 * Math.sin(e.tl * 2.3));      // organe apical (statocyste)
  if (AC > .02) spr(ctx, e.SG, 0, ry * .1, ry * 1.1, .4 * AC * (.75 + .25 * Math.sin(e.tl * 4)));
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 3. électricité : arcs ténus, brefs ; plus fréquents quand la bille approche, continus quand elle est engluée */
  e.tArc -= dt;
  near.sort((p, q) => q[0] - p[0]);
  if (e.tArc <= 0 && !englue) {
    if (etat === 1 && b && X > .2) { arcAjoute(e, near[(hs(T) * 3) | 0][1], -1, .16 + .1 * hs(T * 3), T); e.tArc = .18 + .3 * (1 - X) * hs(T * 5); }
    else { const i = (hs(T * 1.9) * NF) | 0, k = hs(T * 4.4); arcAjoute(e, i, k < .55 ? (i + 1) % NF : -(10 + ((i + 3) % NF)), .14 + .1 * hs(T * 7), T, .85); e.tArc = .5 + 1.4 * hs(T * 2.7) * (1 - .5 * V); }
  }
  if (st.in && st.in === fr && b) { for (let j = 0; j < 4; j++) arcAjoute(e, near[j][1], -2, .3 + .1 * j, T, 1.2); e.fl = 1; }
  ctx.globalCompositeOperation = 'lighter';
  for (let j = e.arcs.length - 1; j >= 0; j--) {
    const A = e.arcs[j], age = (T - A.t0) / A.vie;
    if (age >= 1 || age < 0) { e.arcs.splice(j, 1); continue; }
    if (A.a === -2 && !b) continue;
    pointArc(e, A.de, b, 0, 0, PA); pointArc(e, A.a, b, 0, 0, PB);
    const f = Math.pow(1 - age, .6) * (hs(A.gr + Math.floor(T * 30)) > .25 ? 1 : .35) * A.f;
    ctx.beginPath(); tracerArc(ctx, PA[0], PA[1], PB[0], PB[1], A.gr, T, 1);
    deuxTraits(ctx, e.K1, .85 * f, 2.6 * sc, .5 * sc + .05, .22);
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .45 * f; ctx.lineWidth = .25; ctx.stroke();
  }
  /* 4. engluée : deux filaments étirés jusqu'à la bille + arcs continus qui faiblissent avec la tension */
  if (englue) {
    const tension = Math.min(1, bd / 170), casse = bd > 150;
    if (!casse) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.beginPath();
      for (let j = 0; j < 3; j++) {
        const i = near[j][1], ox2 = tip[i * 2] * .3 + ox * .7, oy2 = tip[i * 2 + 1] * .3 + oy * .7, sag = (18 * (1 - tension) + 5) * (1 + .2 * j);
        const mx = (ox2 + bx) / 2 + Math.sin(e.tl * 1.7 + j * 2) * 3, my = (oy2 + by) / 2 + sag;
        ctx.moveTo(ox2, oy2); ctx.quadraticCurveTo(mx, my, bx, by);
      }
      deuxTraits(ctx, e.K1, .7 - .35 * tension, 2.6, .9 * (1 - tension) + .35, .2);
      ctx.globalCompositeOperation = 'lighter';
      const f = (1 - tension * .7) * (hs(Math.floor(T * 18)) > .2 ? 1 : .4);
      for (let j = 0; j < 2; j++) {
        ctx.beginPath(); tracerArc(ctx, ox, oy, bx, by, 77 + j * 911, T, 1 - tension * .4);
        deuxTraits(ctx, e.K1, (.7 - .2 * j) * f, 2.4, .45, .2);
      }
      e.gluFin = 1;
    } else if (e.gluFin > 0) {
      for (let j = 0; j < 3; j++) arcAjoute(e, near[j][1], -2, .2, T, .8);
      e.gluFin = 0;
    }
  }
  ctx.globalCompositeOperation = 'lighter';
  if (e.fl > .02 && b) spr(ctx, e.SG, bx, by, 16 + 14 * e.fl, .5 * e.fl);
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 5. le milieu : bulle de respiration (au pic d'expiration), spores qui dérivent et se prennent dans la toile */
  const Q = e.Q; Q.cx = x; Q.cy = y;
  e.bT -= dt * (1 + V);
  if (e.bT <= 0) { const an = -Math.PI / 2 + rot; emP(Q, 0, x + ox + Math.cos(an) * ry, y + oy + Math.sin(an) * ry, (Math.random() - .5) * 5, -6, 2.4, .9 + .8 * Math.random()); e.bT = 1.6 + 1.6 * Math.random(); }
  e.sT -= dt * (.5 + .8 * V);
  if (e.sT <= 0) { const an = Math.random() * TAU, d0 = r * 1.5; emP(Q, 1, x + Math.cos(an) * d0, y + Math.sin(an) * d0, -Math.cos(an) * 11, -Math.sin(an) * 11, 2.6, .6, .15); e.sT = .7 + .9 * Math.random(); }
  for (let i = 0; i < Q.n; i++) if (Q.k[i] === 1 && Q.w[i] < .2) {      // la spore touche la toile : elle s'arrête
    const dx = Q.x[i] - x, dy = Q.y[i] - y; if (dx * dx + dy * dy < r * r * .95) { Q.vx[i] *= .8; Q.vy[i] *= .8; Q.s[i] = Math.min(1.2, Q.s[i] + dt * 2); }
  }
  majPart(Q, dt); dessinerPart(ctx, Q, e);
}
/* la bille engluée : jauge de tenue en filament + crépitement à sa surface (aucun voile) */
function dessinerBilleGluee(ctx, b, left, tot, T) {
  const x = b.x, y = b.y, f = Math.min(1, left / tot), R = 13.5, G = TEINTE.glu;
  const K1 = rgb(G.c1), K2 = rgb(G.c2);
  ctx.save(); ctx.lineCap = 'round';
  ctx.globalCompositeOperation = 'lighter';
  ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.strokeStyle = K1; ctx.globalAlpha = .14; ctx.lineWidth = .6; ctx.stroke();
  const a0 = -Math.PI / 2, a1 = a0 + TAU * f;
  ctx.beginPath(); ctx.arc(x, y, R, a0, a1); deuxTraits(ctx, K1, .9, 3, .9, .2);
  spr(ctx, sprite('glu', G.c1, 'p'), x + Math.cos(a1) * R, y + Math.sin(a1) * R, 5, .9);
  const g = Math.floor(T * 16);
  ctx.beginPath();
  for (let j = 0; j < 2; j++) {
    const an = hs(g * 3.1 + j) * TAU, l = 4 + 3 * hs(g + j * 5);
    let qx = x + Math.cos(an) * 10, qy = y + Math.sin(an) * 10; ctx.moveTo(qx, qy);
    for (let i = 1; i <= 3; i++) { qx += Math.cos(an) * l / 3 + (hs(g * 7 + i + j * 3) - .5) * 3; qy += Math.sin(an) * l / 3 + (hs(g * 9 + i + j * 3) - .5) * 3; ctx.lineTo(qx, qy); }
  }
  ctx.strokeStyle = K2; ctx.globalAlpha = .7; ctx.lineWidth = .45; ctx.stroke();
  ctx.restore();
}

/* ═════ GUEULE : organisme à iris bleu-violet, siphon vers le cap, tentacules luminescents ═════
   Errance : dérive et pivote (±10°) ; l'enveloppe se referme dès l'alerte : iris sur l'ancrage, siphon sur le cap exact.
   Respiration au repos : inspiration (l'iris s'ouvre, des grains spiralent vers la bouche — l'aspiration) /
   expiration (l'iris se resserre, un chapelet de bulles sort du siphon SUR LE CAP de crachat — la direction se lit sans flèche).
   Prise : l'iris se ferme ; digestion : anneaux de lumière qui se resserrent dans le corps ; compte à rebours = photophores du
   pourtour qui s'éteignent un à un. Annonce : le siphon s'allume turquoise, les bulles s'en échappent de plus en plus fort.
   Expulsion : jet de fines traînées + gerbe de bulles le long du cap. Recharge : les photophores se rallument un à un. */
function dessinerGueule(ctx, e, x, y, etat, st, b, T, dt, fr) {
  const c = e.c, R = c.rc || 24, hold = c.hold || 70, a = (c.a || 0) * Math.PI / 180, I = e.al, X = e.ex, V = e.vit, sc = R / 26;
  const held = etat === 2, left = held ? st.h - fr : 0, prete = !st.cd || fr >= st.cd;
  const ann = held && left < 30 ? 1 - left / 30 : 0;
  const expu = etat === 3 ? (fr - st.out) / 40 : -1;
  const d = b ? Math.hypot(b.x - x, b.y - y) : 1e9;
  /* alignement : l'enveloppe se referme quand il faut que ce soit exact */
  const aliC = (etat >= 1 || ann > 0 || (b && d < R * 3.2)) ? 1 : 0;
  e.ali += (aliC - e.ali) * Math.min(1, dt * (aliC ? 7 : 1.2));
  const amp = 1 - e.ali, ox = e.wx * 10 * amp, oy = e.wy * 9 * amp, wob = e.wr * .26 * amp;
  if (e.ox0 !== null && dt > 0) { e.bvx += ((ox - e.ox0) / dt - e.bvx) * Math.min(1, dt * 3); e.bvy += ((oy - e.oy0) / dt - e.bvy) * Math.min(1, dt * 3); }
  e.ox0 = ox; e.oy0 = oy;
  const br = Math.sin(e.rs * TAU), insp = Math.max(0, br), expi = Math.max(0, -br);
  /* ouverture de l'iris */
  let cib = .38 + .14 * br;
  if (etat === 1) cib = .58 + .3 * X;
  if (held) cib = .16 - .08 * ann;
  if (expu >= 0) cib = expu < .25 ? .95 : .55;
  if (!prete && !held && expu < 0) cib = .28 + .05 * br;
  e.ouv += (cib - e.ouv) * Math.min(1, dt * (expu >= 0 && expu < .25 ? 14 : 4));
  let lx = 0, ly = 0;
  if (b && etat === 1) { const dd = d || 1; lx = (b.x - x) / dd * R * .14 * X; ly = (b.y - y) / dd * R * .14 * X; }
  e.lx += (lx - e.lx) * Math.min(1, dt * 5); e.ly += (ly - e.ly) * Math.min(1, dt * 5);
  if (held) { const q = 1 - left / hold; e.puls += dt * (2.2 + 7 * q); } else e.puls += dt * 1.2;
  const beat = held ? Math.pow(Math.max(0, Math.sin(e.puls * Math.PI)), 6) : 0;
  const gs = 1 + .045 * beat - .05 * ann + .06 * e.gon + .045 * br * (1 - e.ali);
  const aa = a + wob, ca = Math.cos(aa), sa = Math.sin(aa), cx = x + ox, cy = y + oy;
  /* ombre + lueur propre */
  ombre(ctx, e, cx, cy, R * 2.1, R * 2, 0, .55);
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, cx, cy, R * 2.3, .1 + .1 * V + .2 * e.ac + .05 * insp);
  ctx.globalCompositeOperation = 'source-over';
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(aa); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* 1. tentacules traînants (à l'opposé du siphon), photophores qui s'y allument en chapelet */
  const NT = 5, tb = e.cc || (e.cc = new Float32Array(NT * 22));
  const dlx = -(e.bvx * ca + e.bvy * sa) * .25, dly = -(-e.bvx * sa + e.bvy * ca) * .25;
  ctx.beginPath();
  for (let j = 0; j < NT; j++) {
    const th = Math.PI + (j - (NT - 1) / 2) * .34, Lt = R * (1.3 + .5 * hs(j * 3.7 + 1)) * (1 - .25 * ann), x0 = Math.cos(th) * R * .95, y0 = Math.sin(th) * R * .95;
    for (let s = 0; s <= 10; s++) {
      const u = s / 10, w = Math.sin(u * 4 - e.tl * (1.2 + 2 * V) + j * 1.7) * (1.5 + 4 * u) * sc;
      const qx = x0 + Math.cos(th) * Lt * u - Math.sin(th) * w + dlx * u * u, qy = y0 + Math.sin(th) * Lt * u + Math.cos(th) * w + dly * u * u;
      tb[j * 22 + s * 2] = qx; tb[j * 22 + s * 2 + 1] = qy; s ? ctx.lineTo(qx, qy) : ctx.moveTo(qx, qy);
    }
  }
  deuxTraits(ctx, e.K2, .3 + .2 * V, 2 * sc, .35 * sc + .05, .22);
  ctx.globalCompositeOperation = 'lighter';
  for (let j = 0; j < NT; j++) for (let s = 2; s <= 10; s += 2) { const v = ondeA(e, s / 10); spr(ctx, (s + j) % 4 ? e.SP : e.SA, tb[j * 22 + s * 2], tb[j * 22 + s * 2 + 1], (1.8 + 2.4 * v) * sc, .15 + .75 * v); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.scale(gs, gs);
  /* 2. frange de cils sur le pourtour arrière, vague métachronale */
  e.vph += dt * (1.6 + 4 * V);
  ctx.beginPath();
  for (let j = 0; j < 44; j++) {
    const th = Math.PI + (j / 43 - .5) * 4.5, ux = Math.cos(th), uy = Math.sin(th), ph = e.vph - j * .45;
    const rb = R * (1 + .022 * Math.sin(5 * th + e.tl * .9 + e.ph)), lc = R * (.12 + .035 * Math.sin(ph)) * (1 - .3 * ann) * 1.18;
    const bend = (.35 + .25 * V) * Math.cos(ph);
    const x0 = ux * rb, y0 = uy * rb, x1 = x0 + (ux - uy * bend) * lc, y1 = y0 + (uy + ux * bend) * lc;
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 + ux * lc * .6, y0 + uy * lc * .6, x1, y1);
  }
  deuxTraits(ctx, e.K2, .22 + .14 * V, 1.6 * sc, .28 * sc + .05, .25);
  /* 3. corps : contour lobé qui s'étire en siphon vers le cap */
  const NPt = 56, px = e.px, py = e.py, sip = 1 + .25 * ann + (expu >= 0 ? .2 * (1 - expu) : 0) + .06 * expi * (1 - e.ali);
  for (let k = 0; k < NPt; k++) {
    const th = k / NPt * TAU - Math.PI, rr = R * (1 + .025 * Math.sin(5 * th + e.tl * .9 + e.ph) * (1 - Math.exp(-th * th * 3))) + R * .48 * sip * Math.exp(-(th / .36) * (th / .36));
    px[k] = Math.cos(th) * rr; py[k] = Math.sin(th) * rr;
  }
  const corps = () => { ctx.beginPath(); ctx.moveTo(px[0], py[0]); for (let k = 1; k < NPt; k++) ctx.lineTo(px[k], py[k]); ctx.closePath(); };
  if (!e.cg || e.cgc !== ctx) {
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 1.15); e.cgc = ctx;
    g.addColorStop(0, 'rgba(4,6,20,.4)'); g.addColorStop(.35, 'rgba(20,16,78,.35)'); g.addColorStop(.8, 'rgba(118,104,255,.2)'); g.addColorStop(1, 'rgba(204,198,255,.3)');
    e.cg = g;
  }
  corps(); ctx.fillStyle = e.cg; ctx.globalAlpha = 1; ctx.fill();
  corps(); deuxTraits(ctx, e.K2, .5 + .2 * V + .2 * beat, 4.5 * sc, .65 * sc + .08, .12);
  ctx.beginPath(); ctx.arc(0, 0, R * .88, 0, TAU); ctx.strokeStyle = e.K1; ctx.globalAlpha = .22; ctx.lineWidth = 1 * sc; ctx.stroke();
  /* 4. digestion : anneaux de lumière qui se resserrent dans le corps (péristaltisme) */
  ctx.globalCompositeOperation = 'lighter';
  if (held || e.ac > .05) {
    for (let k = 0; k < 3; k++) {
      const u = (e.tl * (.45 + .6 * ann) + k / 3) % 1, rr = R * (.84 - .55 * u);
      ctx.beginPath(); ctx.arc(0, 0, rr, 0, TAU); ctx.strokeStyle = k % 2 ? e.KA : e.K1; ctx.globalAlpha = Math.sin(Math.PI * u) * .4 * e.ac; ctx.lineWidth = .7 * sc; ctx.stroke();
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  /* 5. iris : lamelles spiralées ; l'ouverture respire, se décentre, se ferme */
  const ox2 = e.lx * Math.cos(-aa) - e.ly * Math.sin(-aa), oy2 = e.lx * Math.sin(-aa) + e.ly * Math.cos(-aa);
  const ra = Math.max(2.5 * sc, R * .66 * e.ouv), NB = 11, tw = .9 + 1.3 * (1 - e.ouv), rI = e.tl * .14 + e.ph;
  ctx.beginPath();
  for (let j = 0; j < NB; j++) {
    const t0 = rI + j * TAU / NB, t1 = t0 + tw;
    const x0 = Math.cos(t0) * R * .86, y0 = Math.sin(t0) * R * .86, x1 = ox2 + Math.cos(t1) * ra, y1 = oy2 + Math.sin(t1) * ra;
    const tm = (t0 + t1) / 2 + .25, rm = (R * .86 + ra) * .5 * 1.05;
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(ox2 * .5 + Math.cos(tm) * rm, oy2 * .5 + Math.sin(tm) * rm, x1, y1);
  }
  deuxTraits(ctx, e.K2, .36 + .22 * V + .2 * ann, 2 * sc, .5 * sc + .05, .16);
  ctx.beginPath(); ctx.arc(ox2, oy2, ra, 0, TAU); ctx.fillStyle = K_AB; ctx.globalAlpha = .4; ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  deuxTraits(ctx, e.K1, .5 + .3 * V + .3 * beat, 3.2 * sc, .6 * sc + .08, .2);
  if (etat === 1 || insp > .5) { ctx.beginPath(); ctx.arc(ox2, oy2, ra, rI * 3, rI * 3 + 1.4); ctx.strokeStyle = e.KA; ctx.globalAlpha = .35 * Math.max(X, insp - .5); ctx.lineWidth = .7 * sc; ctx.stroke(); }
  /* 6. photophores du pourtour : chenille lente au repos · compte à rebours pendant la prise · recharge après le crachat */
  const NPh = 14, fc = held ? left / hold : !prete ? 1 - (st.cd - fr) / (c.cd || 90) : 1;
  for (let j = 0; j < NPh; j++) {
    const an = j / NPh * TAU + .22, u = j / NPh;
    let v;
    if (held) v = u < fc ? .55 + .45 * (u > fc - 1 / NPh ? .5 + .5 * Math.sin(T * 12) : 1) : 0;
    else if (!prete) v = u < fc ? .35 : 0;
    else v = .3 + .7 * ondeA(e, u);
    spr(ctx, held ? e.SA : e.SP, Math.cos(an) * R * .95, Math.sin(an) * R * .95, (1.6 + 2.4 * v) * sc, .12 + .8 * v);
  }
  /* granules en couronne */
  ctx.beginPath();
  for (let j = 0; j < 14; j++) { const an = j * TAU / 14 + e.tl * .05, rr = R * (.72 + .08 * Math.sin(j * 2.3 + e.tl)); ctx.moveTo(Math.cos(an) * rr + .5, Math.sin(an) * rr); ctx.arc(Math.cos(an) * rr, Math.sin(an) * rr, .5 * sc, 0, TAU); }
  ctx.fillStyle = e.K2; ctx.globalAlpha = .35; ctx.fill();
  /* 7. siphon : canal et lèvres ; s'allume turquoise quand le crachat s'annonce */
  const sx = R * (1 + .48 * sip) - 1.5 * sc;
  ctx.beginPath(); ctx.moveTo(ra + ox2, oy2); ctx.lineTo(sx - 2, 0);
  ctx.strokeStyle = e.KA; ctx.globalAlpha = .16 + .55 * ann + .15 * expi; ctx.lineWidth = .7 * sc; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(sx, 0, 1.4 * sc, R * .12, 0, 0, TAU); deuxTraits(ctx, e.K2, .5 + .45 * ann + .2 * V, 2.4 * sc, .7 * sc, .2);
  spr(ctx, e.SAG, sx, 0, R * (.35 + .35 * ann), .12 + .2 * expi + .45 * ann + (expu >= 0 && expu < .3 ? .5 : 0));
  /* expulsion : gerbe de fines traînées + front d'onde doux (pas d'éclair) */
  if (expu >= 0) {
    const g = expu, fa = Math.pow(1 - g, 1.4), adv = 1 - Math.exp(-3.2 * g * 1.6);
    for (let pass = 0; pass < 2; pass++) {
      ctx.beginPath();
      for (let j = 0; j < 16; j++) {
        const an = (hs(j * 4.3) - .5) * (.5 + .5 * hs(j * 1.9)), v = 30 + 85 * hs(j * 2.9), dd = sx + v * adv, ll = (6 + 16 * hs(j * 8.1)) * (1 - g * .7);
        const ca2 = Math.cos(an), sa2 = Math.sin(an), cv = (hs(j * 6.1) - .5) * 6 * adv;
        const d0 = pass ? dd - ll * .35 : dd - ll, d1 = pass ? dd : dd - ll * .3;
        ctx.moveTo(ca2 * d0 - sa2 * cv * (d0 / dd), sa2 * d0 + ca2 * cv * (d0 / dd)); ctx.lineTo(ca2 * d1 - sa2 * cv * (d1 / dd), sa2 * d1 + ca2 * cv * (d1 / dd));
      }
      ctx.strokeStyle = pass ? e.K2 : e.KA; ctx.globalAlpha = (pass ? .7 : .3) * fa; ctx.lineWidth = pass ? .5 : .45; ctx.stroke();
    }
    ctx.beginPath();
    for (let j = 0; j < 3; j++) {
      const L2 = 20 + 70 * adv * (.7 + .3 * j), w = (j - 1) * 6;
      ctx.moveTo(sx, 0); ctx.bezierCurveTo(sx + L2 * .33, w + Math.sin(T * 6 + j) * 4, sx + L2 * .66, w * 1.6 - Math.sin(T * 5 + j) * 5, sx + L2, w * 2.2);
    }
    deuxTraits(ctx, e.KA, .55 * fa, 3, .5, .2);
    const rw = 4 + 30 * adv;
    ctx.beginPath(); ctx.arc(sx - 4, 0, rw, -.8, .8); deuxTraits(ctx, e.K1, .3 * fa, 3.5, .5, .14);
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 8. le milieu : aspiration (spirales vers la bouche), bulles du siphon sur le cap, gerbe à l'expulsion */
  const Q = e.Q; Q.cx = x; Q.cy = y;
  const lipx = cx + ca * (R * (1 + .48 * sip)) * gs, lipy = cy + sa * (R * (1 + .48 * sip)) * gs;
  const aspire = prete && !held && expu < 0 ? (etat === 1 ? .6 + .9 * X : .1 + .9 * insp * (.5 + .5 * V)) : 0;
  e.sT -= dt * aspire * 10;
  if (e.sT <= 0 && aspire > 0) { emP(Q, 2, x, y, R * (1.7 + 1.1 * Math.random()), Math.random() * TAU, 8, R * .3, 9 + 22 * aspire); e.sT = .5 + .6 * Math.random(); }
  if (st.in && st.in === fr) for (let i = 0; i < Q.n; i++) if (Q.k[i] === 2) Q.w[i] *= 4;   // happée : tout s'engouffre d'un coup
  const souffle = expu < 0 ? (ann > 0 ? .5 + 2.5 * ann : prete && !held && etat === 0 ? expi * expi * .9 : 0) : 0;
  e.bT -= dt * souffle * 5;
  if (e.bT <= 0 && souffle > 0) { const sp = 18 + 30 * ann + 10 * Math.random(), j2 = (Math.random() - .5) * .25; emP(Q, 0, lipx, lipy, Math.cos(a + j2) * sp, Math.sin(a + j2) * sp, 1.6 + Math.random(), .7 + .9 * Math.random()); e.bT = .35 + .4 * Math.random(); }
  if (st.out === fr && !e.gerbe) {
    e.gerbe = 1;
    for (let j = 0; j < 14; j++) { const j2 = (Math.random() - .5) * .7, sp = 40 + 80 * Math.random(); emP(Q, j % 3 ? 0 : 1, lipx, lipy, Math.cos(a + j2) * sp, Math.sin(a + j2) * sp, 1.4 + Math.random(), j % 3 ? .8 + 1.2 * Math.random() : 1.1, .9); }
  }
  if (st.out !== fr) e.gerbe = 0;
  majPart(Q, dt); dessinerPart(ctx, Q, e);
}

let H6 = null;   // ===== ETAGE 6 (R485) : aides de dessin prêtées à qxetage6.js =====
function dessinerAct(ctx, lv, env) {
  if (!act || act.idx !== lv.idx) monterAct(lv);
  const FL = racine.FLUID, S = env && env.S, b = S && S.ball, fr = S ? S.frames : 0, run = S && S.mode === 'run';
  const t0 = performance.now(); let dt = act.tPrev ? (t0 - act.tPrev) / 1000 : 1 / 60; act.tPrev = t0; if (dt > .05) dt = .05;
  if (act.dtF) dt = act.dtF;                       // tests : pas de temps imposé (planches reproductibles)
  const lent = (env && env.RM) || reduitOS();
  if (lent) dt *= .12;
  act.t += dt;
  const T = act.t;
  if (!run || fr <= 1) { if (fr <= 1) act.tn = 0; }
  if (run && b && fr !== act.fr0) {
    act.fr0 = fr;
    let f = 0;
    for (const e of act.E) { const st = (b.cs && b.cs[e.i]) || {}; if (e.c.t === 'cils' && st.on > fr - 2) f = 1; else if (e.c.t === 'gueule' && st.out && fr >= st.out && fr - st.out < 45) f = 2; }
    if (b.glu > fr) f = 3;
    if (b.bul > fr) f = 4;
    for (const e of act.E) if (e.c.t === 'systole') { const st = (b.cs && b.cs[e.i]) || {}; if (st.on > fr - 20) f = 5; }
    for (const e of act.E) if (e.c.t === 'cortege') { const st = (b.cs && b.cs[e.i]) || {}; if (st.h) f = 6; }
    if (b.brz > fr) f = 7;
    for (const e of act.E) if (e.c.t === 'leurre' || e.c.t === 'echasse') { const st = (b.cs && b.cs[e.i]) || {}; if (st.h || (st.out && fr >= st.out && fr - st.out < 40)) f = e.c.t === 'leurre' ? 8 : 9; }   // R480
    f = e5Flag(b, fr, f);   // R484 · ÉTAGE 5
    if (act.tn >= 120) { act.tr.copyWithin(0, 2); act.tf.copyWithin(0, 1); act.tn = 119; }
    act.tr[act.tn * 2] = b.x; act.tr[act.tn * 2 + 1] = b.y; act.tf[act.tn] = f; act.tn++;
  }
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  sillageAct(ctx);
  ctx.globalCompositeOperation = 'source-over';
  for (const e of act.E) {
    const c = e.c, p = FL.crPos(c, fr);
    let st = (b && b.cs && b.cs[e.i]) || {};
    if (b && b.cs && fr <= 1) st = {};
    const x = p[0], y = p[1], d = b ? Math.hypot(b.x - x, b.y - y) : 1e9;
    const appr = b && d > 1 ? -((b.x - x) * b.vx + (b.y - y) * b.vy) / d : 0;
    /* ÉTAT lisible : 0 veille · 1 alerte (elle approche) · 2 action · 3 relâche */
    let etat = 0;
    const R0 = c.t === 'gueule' ? (c.rc || 24) : c.r;
    if (run && d < R0 + 90 && appr > .3) etat = 1;
    if (c.t === 'cils' && st.on > fr - 3) etat = 2;
    if (c.t === 'gueule' && st.h > fr) etat = 2;
    if (c.t === 'glu' && b && b.glu > fr) etat = 2;
    if (c.t === 'gueule' && st.out && fr >= st.out && fr - st.out < 40) etat = 3;
    if (c.t === 'bulle' && b && b.bul > fr && st.in && fr >= st.in) etat = 2;
    if (c.t === 'bulle' && st.out && fr >= st.out && fr - st.out < 50) etat = 3;
    if (c.t === 'systole' && st.on > fr - 3) etat = 2;
    else if (c.t === 'systole' && st.on && fr - st.on < 40 && fr >= st.on) etat = 3;
    if (c.t === 'cortege' && st.h) etat = 2;
    else if (c.t === 'cortege' && st.out && fr >= st.out && fr - st.out < 50) etat = 3;
    if (c.t === 'braise' && st.in != null && fr >= st.in && fr - st.in < 24) etat = 2;
    else if (c.t === 'braise' && st.in != null && fr >= st.in && fr - st.in < 80) etat = 3;
    if ((c.t === 'leurre' || c.t === 'echasse') && st.h) etat = 2;   // R480
    else if ((c.t === 'leurre' || c.t === 'echasse') && st.out && fr >= st.out && fr - st.out < 50) etat = 3;
    if (c.t === 'leurre' && etat === 1 && b) { const q = FL.crBulbe(c, fr, st), d2 = Math.hypot(b.x - q[0], b.y - q[1]); if (d2 > (c.r || 18) + Math.max(110, c.att || 0)) etat = 0; }
    etat = e5Etat(c, st, fr, etat);   // R484 · ÉTAGE 5
    if (act.force != null && !run) etat = act.force;   // tests : phase imposée (planches)
    e.al += ((etat === 0 ? (lv.wd !== 12 ? .62 : .4) : etat === 1 ? .8 : 1) - e.al) * Math.min(1, dt * 6);
    const prox = etat === 1 ? (run ? cl01(1 - (d - R0) / 90) : .7) : 0;
    const cibX = etat === 0 ? 0 : etat === 1 ? .25 + .65 * prox : 1;
    e.ex += (cibX - e.ex) * Math.min(1, dt * (cibX > e.ex ? 6 : 1.6));
    e.gon = Math.max(0, e.gon - dt * 1.8); e.fl = Math.max(0, e.fl - dt * 2.5);
    if (c.t === 'gueule' && (st.in === fr || st.out === fr)) e.gon = 1;
    vie(e, dt, etat, prox);
    e.wx = nz(e.tw, e.s1); e.wy = nz(e.tw * 1.13 + 3, e.s2); e.wr = nz(e.tw * .87 + 7, e.s3);
    if (c.t === 'cils') dessinerCils(ctx, e, x, y, etat, st, b, T, dt);
    else if (c.t === 'gueule') dessinerGueule(ctx, e, x, y, etat, st, b, T, dt, fr);
    else if (c.t === 'glu') dessinerGlu(ctx, e, x, y, etat, st, b, T, dt, fr);
    else if (c.t === 'bulle') dessinerBulle(ctx, e, x, y, etat, st, b, T, dt, fr);
    else if (c.t === 'systole') dessinerSystole(ctx, e, x, y, etat, st, b, T, dt, fr, run);
    else if (c.t === 'cortege') dessinerCortege(ctx, e, x, y, etat, st, b, T, dt, fr, run);
    else if (c.t === 'braise') dessinerBraise(ctx, e, x, y, etat, st, b, T, dt, fr);
    else if (c.t === 'leurre') dessinerLeurre(ctx, e, x, y, etat, st, b, T, dt, fr, run);
    else if (c.t === 'echasse') dessinerEchasse(ctx, e, x, y, etat, st, b, T, dt, fr, run);
    // ===== ETAGE 6 DEBUT ===== R485 : anémone-fleur (coque) et amphipode (amphi), dessinés par qxetage6.js
    else if (racine.QXE6 && racine.QXE6[c.t]) racine.QXE6[c.t](ctx, e, x, y, etat, st, b, T, dt, fr, run, H6 || (H6 = { spr, sprite, ombre }));
    // ===== ETAGE 6 FIN =====
    else if (E5D[c.t]) E5D[c.t](ctx, e, x, y, etat, st, b, T, dt, fr, run);   // R484 · ÉTAGE 5
  }
  dialogue(ctx, dt, fr, run);
  langage(ctx, dt, b, fr, run, lv);
  e5Langage(ctx, dt, b, fr, run);   // R484 · ÉTAGE 5
  if (b && b.bul > fr) dessinerBilleBulle(ctx, b, b.bul - fr, b.bd || 120, T);
  if (b && b.glu > fr) dessinerBilleGluee(ctx, b, b.glu - fr, b.gd || (lv.cr[0] && lv.cr[0].dur) || 300, T);
  ctx.restore();
  act.ms += performance.now() - t0; act.n++;
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
/* ═════ R474 · ÉTAGE 2 — PHYSALIE (bulle) : flotteur de gaz azur, glande corail, crête plissée, tentacules pêcheurs ═════
   Errance : le flotteur se balance et dérive autour de l'ancrage ; la crête ondule ; des bulles fines montent du pore.
   Repos : la glande à gaz (corail) bat lentement, des bulles internes montent dans le flotteur (convection), les tentacules
   pendent et ondulent (vague lente), photophores de la crête rares. Alerte : le flotteur se gonfle, les tentacules s'étirent vers
   la particule, la vague de lumière court sur la crête. Action : le flotteur cède son gaz — il se dégonfle, la particule part dans
   une bulle irisée (fine, déformable, jamais un grand cercle) qui monte ; des bulles s'en détachent. À la fin, la bulle s'amincit,
   tremble, puis crève : gouttelettes et bulles, la chute reprend. Récupération : le flotteur se regonfle, la glande se rallume.
   La portée réelle (r) se lit au bout des tentacules (distance r depuis l'ancrage, comme la glu). */
function dessinerBulle(ctx, e, x, y, etat, st, b, T, dt, fr) {
  const c = e.c, r = c.r || 24, V = e.vit, AC = e.ac, X = e.ex, sc = r / 24 * 1.5;   // R475 : corps ×1,5 (la portée physique r ne change pas)
  const br = Math.sin(e.rs * TAU), amp = (6 + r * .12) * (1 - .5 * AC);
  const ox = e.wx * amp, oy = e.wy * amp * .7 + 1.5 * Math.sin(e.tl * .9 + e.ph);
  if (e.ox0 !== null && dt > 0) { e.bvx += ((ox - e.ox0) / dt - e.bvx) * Math.min(1, dt * 3); e.bvy += ((oy - e.oy0) / dt - e.bvy) * Math.min(1, dt * 3); }
  e.ox0 = ox; e.oy0 = oy;
  /* gonflement : plein au repos, plus en alerte ; vidé à la prise ; se regonfle pendant la pause (cd) */
  let inf = 1 + .12 * X;
  if (st.in && fr >= st.in && st.cd > fr) { const tot = Math.max(1, st.cd - st.in), u = (fr - st.in) / tot; inf = .62 + .38 * Math.pow(cl01((u - .12) / .88), .7); }
  e.inf = e.inf == null ? inf : e.inf + (inf - e.inf) * Math.min(1, dt * 5);
  const rv = r * 1.5, I = e.inf, rx = rv * .68 * I * (1 + .04 * br), ry = rv * .4 * (.55 + .45 * I) * (1 - .03 * br), fy = -rv * .36;   // flotteur au-dessus de l'ancrage
  const rot = -.22 + e.wr * .18 + cl01(Math.abs(e.bvx) / 30) * Math.sign(e.bvx) * .1 + .07 * Math.sin(e.tl * .6 + e.ph);
  const cx = ox, cy = oy + fy, co = Math.cos(rot), si = Math.sin(rot);
  const W2 = (lx, ly, o) => { o[0] = cx + lx * co - ly * si; o[1] = cy + lx * si + ly * co; return o; };
  const bx = b ? b.x - x : 0, by = b ? b.y - y : 0, ba = Math.atan2(by, bx);
  const Q = e.Q; Q.cx = x; Q.cy = y; majPart(Q, dt);
  ombre(ctx, e, x + cx, y + cy + ry * .5, rx * 1.75, ry * 2.6, rot, .66);   // R475 : silhouette détachée du fond orangé
  ombre(ctx, e, x + cx * .5, y + cy * .3 + r * .45, r * .9, r * .75, 0, .3);
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, cx, cy, rx * 2.1, .08 + .1 * V + .14 * AC + .05 * (.5 + .5 * br));
  ctx.globalCompositeOperation = 'source-over';
  /* 1. tentacules pêcheurs + polypes : la pointe la plus longue touche la vraie portée r (depuis l'ancrage, pas depuis le corps) */
  const NF = 11, NS = 9, P = e.cb, pk = [0, 0], ret = etat === 2 ? .55 : etat === 3 ? .7 : 1;
  for (let i = 0; i < NF; i++) {
    const u0 = (i + .5) / NF, lx = (u0 * 2 - 1) * rx * .78, base = W2(lx, ry * .82 * Math.sqrt(1 - Math.min(.9, (lx / rx) * (lx / rx))), pk);
    const r0x = base[0], r0y = base[1], th = Math.PI / 2 + (u0 - .5) * 1.5 + .12 * Math.sin(e.tl * .35 + i * 1.3) + rot * .4;
    const dirx = Math.cos(th), diry = Math.sin(th), lg = i % 2 === 0;
    const Rf = r * (lg ? .98 : .8 + .1 * hs(i * 3.1)) * ret;
    const od = r0x * dirx + r0y * diry, Lf = Math.max(4, -od + Math.sqrt(Math.max(0, od * od - (r0x * r0x + r0y * r0y) + Rf * Rf)));
    const lean = b && etat === 1 ? Math.max(0, Math.cos(th - ba)) * .4 * X : 0, o = i * (NS + 1) * 2;
    P[o] = r0x; P[o + 1] = r0y;
    for (let s2 = 1; s2 <= NS; s2++) {
      const u = s2 / NS, wv = Math.sin(u * 4.2 - e.tl * (1.1 + 1.8 * V) + i * 1.7) * (.6 + 2.2 * u) * sc - e.bvx * .05 * u * u;
      let sx = r0x + dirx * Lf * u - diry * wv, sy = r0y + diry * Lf * u + dirx * wv;
      if (lean > 0) { sx += (bx - sx) * lean * u * u; sy += (by - sy) * lean * u * u; }
      P[o + s2 * 2] = sx; P[o + s2 * 2 + 1] = sy;
    }
  }
  ctx.beginPath(); for (let i = 0; i < NF; i++) { const o = i * (NS + 1) * 2; ctx.moveTo(P[o], P[o + 1]); for (let s2 = 1; s2 <= NS; s2++) ctx.lineTo(P[o + s2 * 2], P[o + s2 * 2 + 1]); }
  deuxTraits(ctx, e.K1, .44 + .22 * V + .2 * AC, 2.2 * sc, .3 * sc + .08, .2);
  /* cnidocystes : perles le long des tentacules, allumées par une onde qui descend */
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < NF; i++) { const o = i * (NS + 1) * 2; for (let s2 = 3; s2 <= NS; s2 += 2) { const w = Math.pow(.5 + .5 * Math.sin(e.tl * 2.1 - s2 * .7 + i * 2.2), 6); spr(ctx, s2 === NS ? e.SA : e.SP, P[o + s2 * 2], P[o + s2 * 2 + 1], (1.3 + 1.3 * w) * sc, .26 + .2 * V + .6 * w * (.4 + .6 * Math.max(V, AC))); } }
  ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath();                                       // polypes nourriciers : courtes massues sous le flotteur
  for (let i = 0; i < 6; i++) { const lx = ((i + .5) / 6 * 2 - 1) * rx * .55, a = W2(lx, ry * .85, pk), ax = a[0], ay = a[1], L = (4.5 + 2 * hs(i * 5.3)) * sc * (.8 + .2 * I), sw = .35 * Math.sin(e.tl * 1.3 + i * 2.1);
    ctx.moveTo(ax, ay); ctx.quadraticCurveTo(ax + sw * L * .5, ay + L * .6, ax + sw * L, ay + L); ctx.moveTo(ax + sw * L + 1.1 * sc, ay + L); ctx.arc(ax + sw * L, ay + L, 1.1 * sc, 0, TAU); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .35 + .2 * V; ctx.lineWidth = .5 * sc + .1; ctx.stroke();
  /* 2. le flotteur : ovoïde asymétrique, double membrane, crête plissée */
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(rot);
  if (!e.cg || e.cgc !== ctx) {
    const g = ctx.createRadialGradient(-.25, -.35, 0, 0, 0, 1); e.cgc = ctx;
    g.addColorStop(0, 'rgba(214,236,255,.2)'); g.addColorStop(.5, 'rgba(12,34,84,.32)'); g.addColorStop(.82, 'rgba(116,196,255,.2)'); g.addColorStop(1, 'rgba(214,236,255,.36)');
    e.cg = g;
  }
  const flot = (k) => { ctx.beginPath(); ctx.moveTo(-rx * k, ry * .1 * k); ctx.bezierCurveTo(-rx * .7 * k, -ry * 1.25 * k, rx * .75 * k, -ry * 1.15 * k, rx * k, -ry * .15 * k); ctx.bezierCurveTo(rx * 1.08 * k, ry * .85 * k, -rx * .75 * k, ry * 1.05 * k, -rx * k, ry * .1 * k); };
  ctx.save(); ctx.scale(rx, ry); flotN(ctx); ctx.fillStyle = K_AB; ctx.globalAlpha = .34; ctx.fill(); ctx.globalAlpha = 1; ctx.fillStyle = e.cg; ctx.fill(); ctx.restore();   // R475 : fond d'abysse sous le gaz (contraste)
  flot(1); deuxTraits(ctx, e.K2, .62 + .22 * V + .1 * AC, 3.4 * sc, .5 * sc + .2, .16);
  flot(.8); ctx.strokeStyle = e.K1; ctx.globalAlpha = .26 + .12 * V; ctx.lineWidth = .45 * sc; ctx.stroke();   // paroi interne (double membrane)
  /* crête : voile plissé au sommet, ondulation qui court ; photophores en onde */
  const NC = 11, cr0 = [], cr1 = [];
  for (let j = 0; j <= NC; j++) { const u = j / NC, lx = (-.62 + 1.2 * u) * rx, top = -ry * (1.02 - 1.1 * (u - .52) * (u - .52)) * (.96), h = (3.2 + 3.4 * Math.sin(Math.PI * u)) * sc * (.7 + .3 * I) * (1 + .18 * Math.sin(e.tl * 1.6 - u * 6 + e.ph));
    cr0.push(lx, top); cr1.push(lx + .8 * sc * Math.sin(e.tl * 1.6 - u * 6), top - h); }
  ctx.beginPath(); ctx.moveTo(cr0[0], cr0[1]);
  for (let j = 1; j <= NC; j++) ctx.quadraticCurveTo(cr1[j * 2 - 2] * .5 + cr1[j * 2] * .5, Math.min(cr1[j * 2 - 1], cr1[j * 2 + 1]) - 1.2 * sc, cr1[j * 2], cr1[j * 2 + 1]);
  ctx.lineTo(cr0[NC * 2], cr0[NC * 2 + 1]);
  ctx.fillStyle = e.K1; ctx.globalAlpha = .07 + .05 * V; ctx.fill(); deuxTraits(ctx, e.K2, .38 + .2 * V, 2.4 * sc, .4 * sc + .05, .14);
  ctx.beginPath(); for (let j = 1; j < NC; j++) { ctx.moveTo(cr0[j * 2], cr0[j * 2 + 1]); ctx.lineTo(cr1[j * 2], cr1[j * 2 + 1] + .6 * sc); }   // plis
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .22 + .15 * V; ctx.lineWidth = .35 * sc; ctx.stroke();
  /* intérieur : bulles de convection qui montent, glande à gaz corail (bat), grains */
  const NB = 4 + Math.round(3 * V + 3 * AC);
  ctx.beginPath();
  for (let j = 0; j < NB; j++) { const u = (e.tl * (.12 + .05 * hs(j * 1.7)) * (1 + V) + hs(j * 4.1)) % 1, lx = (hs(j * 2.9) - .5) * rx * 1.1 + Math.sin(u * 9 + j) * 1.2 * sc, ly = ry * (.55 - 1.3 * u), rr = (.7 + 1.1 * hs(j * 6.1)) * sc * (.6 + .4 * u);
    if (lx * lx / (rx * rx * .7) + ly * ly / (ry * ry * .7) > 1) continue; ctx.moveTo(lx + rr, ly); ctx.arc(lx, ly, rr, 0, TAU); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .4 + .25 * V; ctx.lineWidth = .4 * sc; ctx.stroke();
  ctx.globalCompositeOperation = 'lighter';
  const gl = .5 + .5 * Math.sin(e.tl * (1.2 + 2 * V) + e.ph), gA = (.22 + .3 * V + .25 * AC) * (.55 + .45 * gl) * (.4 + .6 * I);
  spr(ctx, e.SAG, -rx * .18, ry * .5, (8 + 4 * gl) * sc, gA); spr(ctx, e.SA, -rx * .18, ry * .5, (2.8 + 1 * gl) * sc, Math.min(1, gA * 1.4));
  for (let j = 0; j < 6; j++) { const u = (j + .5) / 6, w = ondeA(e, u); const k = 2 + j * 2; spr(ctx, e.SP, cr1[k], cr1[k + 1] + 1.2 * sc, (1.2 + 1.6 * w) * sc, .22 + .7 * w + .12 * V); }   // photophores de crête (toujours veilleurs)
  /* R475 : chapelet de photophores sur le flanc bas du flotteur — l'onde les allume l'un après l'autre (sens inverse de la crête) */
  for (let j = 0; j < 9; j++) { const u = (j + .5) / 9, w = ondeA(e, 1 - u), lx = (-.8 + 1.6 * u) * rx, ly = ry * (.62 - .25 * (u - .5) * (u - .5) * 4) * (.9 + .1 * I);
    spr(ctx, j % 3 === 1 ? e.SA : e.SP, lx, ly, (1 + 1.4 * w) * sc, .2 + .65 * w + .15 * V + .2 * AC); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 3. le milieu : bulles du pore (repos), volutes de chaleur (alerte), gerbe au crèvement */
  e.tArc -= dt;
  if (e.tArc <= 0) { const p0 = W2(rx * .9, -ry * .4, pk); emP(Q, 0, x + p0[0], y + p0[1], (hs(T * 3.3) - .5) * 6, -6 - 6 * V, 2.2 + 1.5 * hs(T), (.9 + .8 * hs(T * 5.1)) * sc);
    if (etat === 1) emP(Q, 3, x + cx + (hs(T * 7) - .5) * rx, y + cy - ry * 1.6, 0, -9, 1.6, 4 * sc, hs(T * 2) - .5);
    e.tArc = etat === 1 ? .22 : .9 + 1.4 * hs(T * 1.9); }
  /* R475 : sillage lumineux — gouttes de lumière lâchées par les pointes des tentacules, qui restent dans l'eau quand le corps dérive */
  e.tSl = (e.tSl || 0) - dt;
  if (e.tSl <= 0) { const i = (Math.floor(T * 7.3) % NF), o = i * (NS + 1) * 2 + NS * 2; emP(Q, 1, x + P[o], y + P[o + 1], -e.bvx * .3 + (hs(T * 4.1) - .5) * 3, 2 + 3 * hs(T * 6.7), 1.6 + .8 * hs(T * 2.7), .8 + .5 * V + .4 * AC, .5);
    e.tSl = etat >= 1 ? .09 : .2 + .15 * hs(T * 3.9); }
  if (b && b.bul > fr && dt > 0 && hs(T * 17.3) < dt * 9) emP(Q, 0, b.x + (hs(T * 5.7) - .5) * 14, b.y - 6, (hs(T * 2.3) - .5) * 6, -10, 1.4, .9 + .6 * hs(T * 3.1));   // bulles qui quittent la bulle
  if (st.out === fr && b && e.pop !== fr) { e.pop = fr; for (let j = 0; j < 10; j++) { const a = j / 10 * TAU + hs(j * 3.7), v = 22 + 26 * hs(j * 1.3); emP(Q, j % 3 ? 1 : 0, b.x + Math.cos(a) * 9, b.y + Math.sin(a) * 9, Math.cos(a) * v, Math.sin(a) * v - 4, .5 + .4 * hs(j), j % 3 ? .9 : 1.3, .9); } }
  ctx.restore();
  dessinerPart(ctx, Q, e);
}
/* ═════ R475 · ÉTAGE 2 — SYSTOLE (Col-long × Ver) : cœur-soufflet, tonneau de muscle translucide ouvert aux deux bouts ═════
   L'axe du tonneau = la direction réelle de la poussée (a) : bouche large et frangée derrière, tuyère étroite devant.
   Le rythme est celui de la physique (S.frames, per, off, dur) : pendant la DIASTOLE le tonneau se gonfle, aspire (des poussières
   glissent vers la bouche), et les photophores du dos s'allument un à un de la bouche vers la tuyère — le battement s'annonce.
   SYSTOLE : une vague de contraction court le long des anneaux musculaires (péristaltisme du ver) dans le sens de la poussée,
   la tuyère crache un jet de fines traînées dont la portée est celle de l'effet. Récupération : la lumière retombe, il se regonfle.
   Aucune flèche : la direction se lit à la vague, à la forme (bouche → tuyère) et au jet. */
const SYN = 15;
function dessinerSystoleR475(ctx, e, x, y, etat, st, b, T, dt, fr, run) {   // R494 : ancien rendu (bancs A/B) — nouveau : bloc REPASSE M1-4 SYSTOLE
  const c = e.c, r = c.r || 30, per = c.per || 90, pd = c.dur || 14, sc = r / 24, V = e.vit, AC = e.ac;
  let hp;
  if (run) hp = (fr + (c.off || 0)) % per; else { e.hk = ((e.hk == null ? (c.off || 0) : e.hk) + dt * 60) % per; hp = e.hk; }
  const sys = hp < pd, us = sys ? hp / pd : 0, ud = sys ? 0 : (hp - pd) / (per - pd);       // avancée de la systole / de la diastole
  const pr = sys ? 0 : Math.pow(ud, 1.6);                                                    // charge (gonflement, compte des photophores)
  e.sq = sys ? 1 : Math.max(0, (e.sq || 0) - dt * 4);
  const amp = 3 * (1 - .6 * AC), ox = e.wx * amp, oy = e.wy * amp * .8;
  const rot = (c.a || 0) * Math.PI / 180 + e.wr * .07 + .03 * Math.sin(e.tl * .7 + e.ph), co = Math.cos(rot), si = Math.sin(rot);
  const hl = r * .95, R0 = r * .46 * (1 + .1 * pr - .04 * (1 - pr) * (sys ? 0 : 1)) * (1 + .03 * Math.sin(e.rs * TAU));
  /* profil : rayon le long de l'axe (bouche large derrière, tuyère étroite devant), creusé par la vague de contraction */
  const rad = e.rad || (e.rad = new Float32Array(SYN + 1)), sqz = e.sqz || (e.sqz = new Float32Array(SYN + 1));
  const wc = -1.25 + 2.6 * us;
  for (let j = 0; j <= SYN; j++) {
    const s = j / SYN * 2 - 1, v = (s + 1) / 2, base = .8 + .16 * Math.sin(Math.PI * v) - .2 * v * v;   // R475b : tonneau (pas de goulot)
    const z = (s - wc) / .32, q = sys ? .46 * Math.exp(-z * z) : 0;
    sqz[j] = q; rad[j] = R0 * base * (1 - q);
  }
  const Q = e.Q; Q.cx = x; Q.cy = y; majPart(Q, dt);
  const L2W = (lx, ly, o) => { o[0] = x + ox + lx * co - ly * si; o[1] = y + oy + lx * si + ly * co; return o; }, pk = [0, 0];
  ombre(ctx, e, x + ox, y + oy + 3, hl * 1.35, R0 * 1.9, rot, .58);
  ctx.save(); ctx.translate(x + ox, y + oy); ctx.rotate(rot); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, 0, 0, hl * 1.5, .07 + .08 * V + .16 * e.sq + .08 * pr);
  ctx.globalCompositeOperation = 'source-over';
  const corps = (k) => { ctx.beginPath();
    for (let j = 0; j <= SYN; j++) { const lx = (j / SYN * 2 - 1) * hl; j ? ctx.lineTo(lx, -rad[j] * k) : ctx.moveTo(lx, -rad[j] * k); }
    for (let j = SYN; j >= 0; j--) ctx.lineTo((j / SYN * 2 - 1) * hl, rad[j] * k); ctx.closePath(); };
  /* 1. tunique : fond d'abysse + chair translucide, double paroi */
  corps(1); ctx.fillStyle = K_AB; ctx.globalAlpha = .36; ctx.fill(); ctx.fillStyle = e.K3; ctx.globalAlpha = .4; ctx.fill(); ctx.fillStyle = e.K1; ctx.globalAlpha = .07 + .06 * pr + .08 * e.sq; ctx.fill();
  ctx.beginPath(); for (let j = 0; j <= SYN; j++) { const lx = (j / SYN * 2 - 1) * hl; j ? ctx.lineTo(lx, -rad[j]) : ctx.moveTo(lx, -rad[j]); }
  ctx.moveTo(-hl, rad[0]); for (let j = 1; j <= SYN; j++) ctx.lineTo((j / SYN * 2 - 1) * hl, rad[j]);
  deuxTraits(ctx, e.K2, .55 + .2 * V + .2 * e.sq, 3.2 * sc, .5 * sc + .15, .16);
  corps(.62); ctx.strokeStyle = e.K1; ctx.globalAlpha = .2 + .12 * V; ctx.lineWidth = .4 * sc; ctx.stroke();   // intestin (paroi interne)
  /* 2. anneaux musculaires : ellipses fines en travers ; celui que la vague serre s'allume */
  ctx.globalCompositeOperation = 'lighter';
  for (let j = 2; j < SYN; j += 2) { const lx = (j / SYN * 2 - 1) * hl, q = sqz[j] / .46;
    ctx.beginPath(); ctx.ellipse(lx, 0, (1.3 + 1.2 * q) * sc, rad[j] * .97, 0, 0, TAU);
    deuxTraits(ctx, q > .2 ? e.K2 : e.K1, .1 + .07 * V + .8 * q, (1.6 + 2.6 * q) * sc, (.3 + .35 * q) * sc, .22); }
  /* 3. tuyère (devant) : anneau étroit ; bouche (derrière) : lèvres frangées de cils qui battent plus vite à l'aspiration */
  const rT = rad[SYN], rB = rad[0];
  ctx.beginPath(); ctx.ellipse(hl, 0, 1.6 * sc + 1.2 * e.sq * sc, rT, 0, 0, TAU); deuxTraits(ctx, e.K2, .5 + .45 * e.sq, 2.4 * sc, .5 * sc, .25);
  ctx.beginPath(); ctx.ellipse(-hl, 0, 2.6 * sc * (1 + .3 * pr), rB, 0, 0, TAU); ctx.strokeStyle = e.K1; ctx.globalAlpha = .3 + .2 * pr; ctx.lineWidth = .6 * sc; ctx.stroke();
  ctx.beginPath();
  for (let j = 0; j < 14; j++) { const q = -Math.PI / 2 + (j + .5) / 14 * Math.PI, ly = Math.sin(q) * rB, Lc = (2.2 + 1.6 * Math.sin(e.tl * (5 + 5 * pr) - j * .8)) * sc;
    ctx.moveTo(-hl - Math.cos(q) * 1.5 * sc, ly); ctx.lineTo(-hl - Math.cos(q) * 1.5 * sc - Lc * (.9 + .3 * Math.cos(q)), ly * (1 + .12 * Lc / rB)); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .3 + .25 * pr; ctx.lineWidth = .35 * sc + .1; ctx.stroke();
  /* 4. nœud pervenche (pacemaker) près de la bouche : bat au rythme ; photophores du dos : se chargent un à un, puis l'onde court */
  const nb = sys ? 1 - us : .25 + .75 * pr;
  spr(ctx, e.SAG, -hl * .62, -rB * .2, (6 + 5 * nb) * sc, .18 + .4 * nb); spr(ctx, e.SA, -hl * .62, -rB * .2, (2 + 1.2 * nb) * sc, .4 + .6 * nb);
  const NP = 7;
  for (let j = 0; j < NP; j++) { const u = (j + .5) / NP, jj = Math.round(u * SYN), lx = (u * 2 - 1) * hl * .86;
    const ch = sys ? Math.exp(-Math.pow((u * 2 - 1 - wc) / .3, 2)) : cl01((pr * 1.08 - u * .92) * 9), w = ondeA(e, u);
    spr(ctx, e.SP, lx, -rad[jj] * .72, (1 + 1.5 * ch + .8 * w) * sc, .14 + .7 * ch + .4 * w + .1 * V);
    spr(ctx, e.SP, lx, rad[jj] * .72, (.8 + 1.1 * ch) * sc, .1 + .5 * ch * (1 - .5 * u)); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 5. le milieu : aspiration (poussières vers la bouche) en diastole ; jet de traînées + volutes à la systole */
  e.tArc -= dt;
  if (!sys && e.tArc <= 0) { const sd = hs(T * 3.7) - .5; L2W(-hl - r * (.55 + .35 * hs(T * 5.3)), sd * r * 1.1, pk);
    const p2 = L2W(-hl, sd * rB * .6, [0, 0]), vx = (p2[0] - pk[0]) * 1.3, vy = (p2[1] - pk[1]) * 1.3;
    emP(Q, 1, pk[0], pk[1], vx, vy, .7, .35 + .3 * pr, .2); e.tArc = .3 + .35 * (1 - pr); }
  if (sys && dt > 0) { const n = 2 + (AC > .5 ? 2 : 0);
    for (let j = 0; j < n; j++) { const sd = (hs(T * 9.1 + j) - .5), v = (55 + 40 * hs(T * 4.3 + j)) * (1 - .4 * us), p0 = L2W(hl, sd * rT * 1.4, pk), aj = rot + sd * .35;
      emP(Q, 1, p0[0], p0[1], Math.cos(aj) * v, Math.sin(aj) * v, .45 + .2 * hs(T * 2.2 + j), .9 + .5 * e.sq, 2.4); } }
  if (!sys && e.wasSys) {
    for (const sg of [-1, 1]) { const p0 = L2W(hl + r * .6, sg * rT * 1.2, pk); emP(Q, 3, p0[0], p0[1], Math.cos(rot) * 8, Math.sin(rot) * 8, 1.1, 4.5 * sc, sg); } }
  e.wasSys = sys;
  dessinerPart(ctx, Q, e);
}
/* ═════ R476 · ÉTAGE 3 (monde 3, Chaîne) — CORTÈGE et BRAISE, et leur langage de lumière ═════
   Charte de l'étage 3 (milieu aquatique) : lilas opalin / menthe (cortège) · bleu glacé, cyan, blanc bioluminescent, lilas (braise) — R477 : ni cuivre, ni orange, ni doré.
   Effet de particule propre à l'étage : le SILLAGE-LANGAGE — touchée par une créature de l'étage, la particule égrène derrière elle
   des perles de lumière qui clignotent selon le « mot » de cette créature (cortège · — · ; braise — · ·), puis s'éteignent :
   la particule parle la langue de celle qui l'a portée. Rendu seul ; la physique (fluides.js) ne dépend que de la créature ancrée. */
const NCH = 15, MOT = { cortege: [0, .07, .2], braise: [0, .13, .2], leurre: [0, .06, .22], echasse: [0, .15, .21] };   // R480 : leurre · · — ; échassière — — ·
/* R477 · CORTÈGE affiné : colonne en courbe continue (spline de Catmull-Rom rééchantillonnée), ondulation par propagation de phase
   (l'onde naît derrière le flotteur, voyage vers la queue et s'amortit), cloches translucides à plusieurs couches (ombrelle très
   transparente, sous-ombrelle, nervures radiaires fines, bord lumineux, petit cœur, frange), polypes détaillés dont les tentacules
   suivent avec un retard visco-élastique et laissent une traînée lumineuse, plancton qui dérive dans l'eau (ancré au monde),
   bioluminescence en pulsations douces qui voyagent le long de la tige. Rendu seul (fluides.js inchangé). */
const NSP = 28, NTP = 2, NTN = 8, NPL = 8, NCL = 4;   // R481 : colonne 36→28 points, 4 cloches (« wagons ») au lieu de 6, 2 polypes pêcheurs
function crSpline(CX, CY, n, SX, SY, m) {          // Catmull-Rom uniforme : n points de contrôle → m points lissés
  for (let k = 0; k < m; k++) {
    const g = k / (m - 1) * (n - 1), i = Math.min(n - 2, Math.floor(g)), t = g - i, t2 = t * t, t3 = t2 * t;
    const i0 = i > 0 ? i - 1 : 0, i3 = i + 2 < n ? i + 2 : n - 1;
    const a = -.5 * t3 + t2 - .5 * t, b = 1.5 * t3 - 2.5 * t2 + 1, cc = -1.5 * t3 + 2 * t2 + .5 * t, d = .5 * t3 - .5 * t2;
    SX[k] = a * CX[i0] + b * CX[i] + cc * CX[i + 1] + d * CX[i3]; SY[k] = a * CY[i0] + b * CY[i] + cc * CY[i + 1] + d * CY[i3];
  }
}
function crTrace(ctx, X, Y, n) {                     // tracé lisse (milieux + courbes quadratiques) : aucun angle visible
  ctx.moveTo(X[0], Y[0]);
  for (let j = 1; j < n - 1; j++) ctx.quadraticCurveTo(X[j], Y[j], (X[j] + X[j + 1]) / 2, (Y[j] + Y[j + 1]) / 2);
  ctx.lineTo(X[n - 1], Y[n - 1]);
}
/* R479 · TÊTE DU CORTÈGE : plaque semi-lunaire (planaire à tête en marteau) décrite par un seul contour lisse.
   Repère local : x vers l'avant, y latéral, origine = attache du cou au milieu du bord concave arrière.
   o : ouverture des deux lobes avant (la « bouche »), g : enroulement du croissant (1 = enveloppe la particule, < 0 = détente). */
const NHC = 27, NHD = 61, NNK = 5, HCX = new Float32Array(NHC), HCY = new Float32Array(NHC), HLX = new Float32Array(NHD), HLY = new Float32Array(NHD);
const HDEMI = [[0, 1.25], [1.1, 3], [.9, 5.4], [-.4, 7.7], [-2.4, 9.5], [-4.8, 10.3], [-2.9, 10.95], [0, 10.6], [2.7, 9.3], [4.6, 7.3], [5.9, 5], [6.6, 3], [6.7, 1.5]];
const HTIP = [5, 21], HFR = [7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19], HRHO = 7.3, HCC = 13.9, NVN = 9;
const HOC = new Float32Array(24), HVN = new Float32Array(NVN * 6), HDF = [0, 0];
function hDef(x, y, g, o) {                        // flexion du croissant : g > 0 s'enroule autour du creux (enveloppe), g < 0 se détend vers l'arrière
  if (g < 0) { const R = 1 / (g * .115), d = x - .6, th = Math.abs(y) / R, rr = R - d; o[0] = .6 + R - rr * Math.cos(th); o[1] = (y < 0 ? -1 : 1) * rr * Math.sin(th); return o; }
  const l = Math.abs(y), rad = Math.max(HRHO - .5, HRHO + (6.6 - .095 * l * l) - x), al = Math.PI - l / HRHO * 1.2;
  o[0] = x + (HCC + rad * Math.cos(al) - x) * g; o[1] = y + ((y < 0 ? -1 : 1) * rad * Math.sin(al) - y) * g; return o;
}
function teteForme(o, g, tl, ph, Ax, Ay, ca, sa, hz, OX, OY) {
  for (let i = 0; i < NHC; i++) {
    const side = i < 13 ? -1 : i > 13 ? 1 : 0, j = side < 0 ? i : 26 - i;
    let x, y;
    if (!side) { x = 7 - 3.6 * o; y = 0; }
    else { const P = HDEMI[j]; x = P[0]; y = P[1];
      if (j === 5) { x += -.5 * o + .7 * Math.sin(tl * 1.1 + side * 1.3 + ph); y += .5 * o + .35 * Math.sin(tl * .8 + side); }   // pointes : oreillettes souples
      else if (j === 4 || j === 6) { x += .35 * Math.sin(tl * 1.1 + side * 1.3 + ph - .4); }
      if (j >= 11) { x += (j === 11 ? .6 : .9) * o; y += (j === 11 ? 1.4 : 1.8) * o; }                 // lobes avant : s'écartent
      if (j >= 9 && j <= 10) y += .5 * o;
      if (j >= 10 && j <= 12) x += (1 - o) * (j - 9) * .25;                                            // repos : front plein, à peine échancré
      y *= side; }
    hDef(x, y, g, HDF); HCX[i] = HDF[0]; HCY[i] = HDF[1];
    if (side && j >= 7) { const m = side < 0 ? j - 7 : 11 + 7 - j; hDef(x - .95 - .1 * (12 - j), y * .93, g, HDF); HOC[2 * m] = HDF[0]; HOC[2 * m + 1] = HDF[1]; }   // points oculaires (repère local)
  }
  for (let v = 0; v < NVN; v++) {                  // nervures radiales : de l'attache vers le bord avant, en suivant la plaque
    const l = (v - (NVN - 1) / 2) / ((NVN - 1) / 2) * 9.2, al = Math.abs(l), xf = 6.4 - .095 * al * al - .7, xm = 3.2 - .075 * al * al * .3;
    const P = [[1.2, l * .1], [xm, l * .55], [xf, l * .97]];
    for (let q = 0; q < 3; q++) { hDef(P[q][0], P[q][1], g, HDF); HVN[6 * v + 2 * q] = HDF[0]; HVN[6 * v + 2 * q + 1] = HDF[1]; }
  }
  crSpline(HCX, HCY, NHC, HLX, HLY, NHD);
  for (let k = 0; k < NHD; k++) { OX[k] = Ax + (HLX[k] * ca - HLY[k] * sa) * hz; OY[k] = Ay + (HLX[k] * sa + HLY[k] * ca) * hz; }
}
function teteDetails(ctx, e, HX, HY, Ax, Ay, ca, sa, hz, V, AC, dt, bp) {
  const W = (lx, ly, o) => { o[0] = Ax + (lx * ca - ly * sa) * hz; o[1] = Ay + (lx * sa + ly * ca) * hz; return o; }, q = e.pq2 || (e.pq2 = [0, 0]);
  const ix = c => Math.round(c / (NHC - 1) * (NHD - 1)), o = e.mo || 0, g = e.cup || 0;
  /* épaisseur : seconde couche de chair sur la plaque, plus dense vers le creux */
  ctx.beginPath(); crTrace(ctx, HX, HY, NHD); ctx.closePath();
  ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.K3; ctx.globalAlpha = .22; ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .06 + .05 * V + .07 * AC + .05 * Math.max(0, g); ctx.fill();
  W(2.4, 0, q); spr(ctx, e.SG, q[0], q[1], 8 * hz, .1 + .07 * V + .1 * AC);
  /* bord antérieur lumineux (d'une pointe à l'autre), un peu plus vif que la peau */
  const t0 = ix(HTIP[0]), t1 = ix(HTIP[1]);
  ctx.beginPath(); ctx.moveTo(HX[t0], HY[t0]); for (let k = t0 + 1; k < t1; k++) ctx.quadraticCurveTo(HX[k], HY[k], (HX[k] + HX[k + 1]) / 2, (HY[k] + HY[k + 1]) / 2);
  deuxTraits(ctx, e.K2, .42 + .2 * V + .2 * AC, 1.8 * hz, .26 * hz, .2);
  /* nervures radiales fines : de l'attache vers le bord avant, en éventail, dans l'épaisseur de la plaque */
  ctx.beginPath();
  for (let v = 0; v < NVN; v++) { const P = HVN, i = 6 * v; ctx.moveTo(Ax + (P[i] * ca - P[i + 1] * sa) * hz, Ay + (P[i] * sa + P[i + 1] * ca) * hz);
    ctx.quadraticCurveTo(Ax + (P[i + 2] * ca - P[i + 3] * sa) * hz, Ay + (P[i + 2] * sa + P[i + 3] * ca) * hz, Ax + (P[i + 4] * ca - P[i + 5] * sa) * hz, Ay + (P[i + 4] * sa + P[i + 5] * ca) * hz); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .12 + .06 * V + .08 * AC; ctx.lineWidth = .2 * hz; ctx.stroke();
  /* points oculaires : une rangée de très petits yeux le long du bord avant, qui brillent doucement en vague */
  for (let m = 0; m < 12; m++) { const pu = Math.pow(.5 + .5 * Math.sin(e.tl * 1.6 - Math.abs(m - 5.5) * .8 + e.ph), 3);
    spr(ctx, e.SP, Ax + (HOC[2 * m] * ca - HOC[2 * m + 1] * sa) * hz, Ay + (HOC[2 * m] * sa + HOC[2 * m + 1] * ca) * hz, (.36 + .16 * pu) * hz, .22 + .35 * pu + .15 * V + .2 * AC); }
  /* bouche : lueur douce dans le creux entre les lobes ; quand elle enveloppe la particule, la lumière la baigne */
  W(6.2 - 2.4 * o + (HCC - 6.2) * Math.max(0, g), 0, q); spr(ctx, e.SAG, q[0], q[1], (3 + 3 * o) * hz, .05 + .18 * o * (.4 + .6 * Math.max(0, g)));
  if (bp) spr(ctx, e.SAG, bp.x, bp.y, 9 * hz, .14 * Math.min(1, g));
  /* deux antennes très fines, nées près des oreillettes, tirées vers l'arrière ; la pointe traîne (visco-élastique) */
  const NAN = 7, AN = e.an || (e.an = new Float32Array(NAN * 4)), sgA = 1.75 * hz, iniA = !e.an0; e.an0 = 1;
  ctx.beginPath();
  for (let s = 0; s < 2; s++) {
    const kr = ix(s ? NHC - 4 : 3), o2 = s * NAN * 2, sd = s ? 1 : -1, a0 = Math.atan2(-sa, -ca) + sd * (.95 - .5 * Math.max(0, g));
    let px = HX[kr], py = HY[kr]; AN[o2] = px; AN[o2 + 1] = py;
    for (let k = 1; k < NAN; k++) {
      const u = k / (NAN - 1), aq = a0 - sd * .9 * u * u + (.3 + .2 * V) * Math.sin(e.tl * 1.7 - u * 3.4 + e.ph + s) * u;
      px += Math.cos(aq) * sgA; py += Math.sin(aq) * sgA; const i = o2 + 2 * k;
      if (iniA || dt <= 0) { AN[i] = px; AN[i + 1] = py; continue; }
      const kv = Math.min(1, dt * 15 / (1 + k * .9)); AN[i] += (px - AN[i]) * kv; AN[i + 1] += (py - AN[i + 1]) * kv;
      const ex = AN[i] - AN[i - 2], ey = AN[i + 1] - AN[i - 1], dd = Math.hypot(ex, ey) || 1; if (dd > sgA * 1.15) { const k2 = sgA * 1.15 / dd; AN[i] = AN[i - 2] + ex * k2; AN[i + 1] = AN[i - 1] + ey * k2; }
    }
    ctx.moveTo(AN[o2], AN[o2 + 1]); for (let k = 1; k < NAN - 1; k++) { const i = o2 + 2 * k; ctx.quadraticCurveTo(AN[i], AN[i + 1], (AN[i] + AN[i + 2]) / 2, (AN[i + 1] + AN[i + 3]) / 2); } ctx.lineTo(AN[o2 + 2 * NAN - 2], AN[o2 + 2 * NAN - 1]);
  }
  deuxTraits(ctx, e.K2, .3 + .12 * V + .12 * AC, 1.2 * hz, .16 * hz, .2);
  for (let s = 0; s < 2; s++) { const i = s * NAN * 2 + 2 * NAN - 2; spr(ctx, e.SA, AN[i], AN[i + 1], .5 * hz, .3 + .2 * Math.pow(.5 + .5 * Math.sin(e.tl * 2 + s * 2), 3)); }
}
function crTraceSuite(ctx, X, Y, n) {              // prolonge le tracé courant le long de la colonne (lissé)
  ctx.lineTo(X[0], Y[0]);
  for (let j = 1; j < n - 1; j++) ctx.quadraticCurveTo(X[j], Y[j], (X[j] + X[j + 1]) / 2, (Y[j] + Y[j + 1]) / 2);
  ctx.lineTo(X[n - 1], Y[n - 1]);
}
function dessinerCortege(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, r = c.r || 24, sc = r / 24 * 1.5, V = e.vit, AC = e.ac, seg = 6.2 * sc;
  const dl = Math.hypot(c.ax || 0, c.ay || 0) || 1, rx = (c.ax || 0) / dl, ry = (c.ay || 0) / dl;
  const CX = e.chx || (e.chx = new Float32Array(NCH)), CY = e.chy || (e.chy = new Float32Array(NCH));
  const ox = e.wx * 1.5, oy = e.wy * 1.5 + 1.2 * Math.sin(e.tl * .8 + e.ph), hx = x + ox, hy = y + oy;
  if (!e.ch0) { e.ch0 = 1; const sg = Math.cos((fr) * (c.w || .02) + (c.ph || 0)) >= 0 ? 1 : -1; for (let j = 0; j < NCH; j++) { CX[j] = hx - sg * rx * seg * j; CY[j] = hy - sg * ry * seg * j + j * j * .08; } }
  /* 1. squelette souple : la colonie SUIT sa tête ; léger affaissement ; rigidité de flexion (lissage) puis longueur conservée */
  CX[0] = hx; CY[0] = hy;
  const Ls = seg * (1 - .12 * AC);
  for (let j = 1; j < NCH; j++) {
    CY[j] += (.25 + .01 * j) * dt * 6;
    const ex = CX[j] - CX[j - 1], ey = CY[j] - CY[j - 1], k = Ls / (Math.hypot(ex, ey) || 1);
    CX[j] = CX[j - 1] + ex * k; CY[j] = CY[j - 1] + ey * k;
  }
  const fl = Math.min(1, dt * 9) * .5;
  for (let j = 1; j < NCH - 1; j++) { CX[j] += ((CX[j - 1] + CX[j + 1]) / 2 - CX[j]) * fl; CY[j] += ((CY[j - 1] + CY[j + 1]) / 2 - CY[j]) * fl; }
  for (let j = 1; j < NCH; j++) { const ex = CX[j] - CX[j - 1], ey = CY[j] - CY[j - 1], k = Ls / (Math.hypot(ex, ey) || 1); CX[j] = CX[j - 1] + ex * k; CY[j] = CY[j - 1] + ey * k; }
  /* 2. colonne lissée + onde qui voyage (phase propagée de la tête vers la queue, amplitude qui naît puis s'amortit) */
  const SX = e.sx || (e.sx = new Float32Array(NSP)), SY = e.sy || (e.sy = new Float32Array(NSP));
  const DX = e.dsx || (e.dsx = new Float32Array(NSP)), DY = e.dsy || (e.dsy = new Float32Array(NSP)), NX = e.nsx || (e.nsx = new Float32Array(NSP)), NY = e.nsy || (e.nsy = new Float32Array(NSP));
  crSpline(CX, CY, NCH, SX, SY, NSP);
  const A0 = (4.6 + 1.8 * V) * sc * (1 - .22 * AC), wt = e.tl * 1.15 + e.ph;   // R479 : grandes S lentes (planaire)
  for (let k = 0; k < NSP; k++) {
    const a = k > 0 ? k - 1 : 0, bb = k < NSP - 1 ? k + 1 : NSP - 1, tx = SX[bb] - SX[a], ty = SY[bb] - SY[a], l = Math.hypot(tx, ty) || 1;
    NX[k] = -ty / l; NY[k] = tx / l;
    const u = k / (NSP - 1), env = Math.sin(Math.PI * Math.min(1, u * 1.25)) * (1 - .35 * u) * Math.min(1, u * 5), w = A0 * env * (Math.sin(wt - u * 7.6) + .14 * Math.sin(2 * wt - u * 15.2 + 1));
    DX[k] = SX[k] + NX[k] * w; DY[k] = SY[k] + NY[k] * w;
  }
  const at = u => { const g = u * (NSP - 1), i = Math.min(NSP - 2, g | 0), f = g - i; return i + f; };   // u → indice continu
  const Q = e.Q; Q.cx = hx; Q.cy = hy; majPart(Q, dt);
  /* cloches : oscillateurs couplés — onde métachronale au repos, galop en alerte, salve synchrone en action */
  const dC = etat === 2 || etat === 3 ? 0 : etat === 1 ? Math.PI : .95;
  e.dlt = e.dlt == null ? dC : e.dlt + (dC - e.dlt) * Math.min(1, dt * 2.2);
  e.bph = (e.bph || 0) + dt * TAU * (.45 + .8 * V + 1.1 * AC);
  /* ombre douce sous la colonie */
  for (let k = 6; k < NSP; k += 14) ombre(ctx, e, DX[k], DY[k] + 4, 20 * sc, 13 * sc, 0, .6);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* 3. plancton : poussière vivante qui dérive dans l'eau autour de la route (coordonnées du monde, déterministe en T) */
  ctx.globalCompositeOperation = 'lighter';
  const px0 = c.x != null ? c.x : x, py0 = c.y != null ? c.y : y, spX = Math.abs(c.ax || 60) * .9 + 40 * sc, spY = Math.abs(c.ay || 40) * .9 + 26 * sc;
  ctx.beginPath();
  for (let k = 0; k < NPL; k++) {
    const h1 = hs(k * 3.1 + 1), h2 = hs(k * 5.7 + 2), h3 = hs(k * 7.3 + 3), sp = .12 + .2 * h3;
    const pxk = px0 + (h1 * 2 - 1) * spX + Math.sin(T * sp + k * 2.3) * 9 * sc + Math.sin(T * .07 + k) * 6 * sc, pyk = py0 + (h2 * 2 - 1) * spY + 10 * sc + Math.cos(T * sp * 1.3 + k) * 6 * sc - ((T * (1.5 + 2 * h3) + h1 * 40) % 40 - 20) * .4 * sc;
    const tw = .5 + .5 * Math.sin(T * (1.1 + 1.7 * h2) + k * 1.9), lu = .1 + .22 * tw * tw + .25 * V * tw;
    if (k % 3 === 0) { spr(ctx, e.SA, pxk, pyk, (.6 + .35 * h3) * sc, lu); continue; }      // un grain sur trois : photophore menthe
    const rr = (.28 + .2 * h3) * sc * (.7 + .5 * tw); ctx.moveTo(pxk + rr, pyk); ctx.arc(pxk, pyk, rr, 0, TAU);   // les autres : poussière en un seul remplissage
  }
  ctx.fillStyle = e.K2; ctx.globalAlpha = .35 + .2 * V; ctx.fill();
  /* 4. lueur propre le long de la colonie */
  spr(ctx, e.SG, hx, hy, 28 * sc, .1 + .08 * V + .14 * AC); for (let k = 10; k < NSP; k += 10) spr(ctx, e.SG, DX[k], DY[k], 18 * sc, .065 + .05 * V);
  /* 5. R479 · CORPS ET TÊTE EN UNE SEULE FORME (planaire à tête en marteau) : chair translucide à largeur variable (cou fin,
     corps plein puis effilé vers la queue) ; le contour longe un flanc, remonte le cou qui ondule, fait le tour de la tête en
     croissant et redescend l'autre flanc : un seul tracé lisse, aucun raccord. La tête est d'abord orientée (état, particule). */
  const bh = Math.atan2(DY[0] - DY[3], DX[0] - DX[3]), cbo = (v, a) => v < -a ? -a : v > a ? a : v;
  const hz = sc * 1.1, nL = 4.2 * sc, MC = (7.6 + (HCC - 7.6) * cl01(e.cup || 0)) * hz;                       // échelle de la tête, cou au repos, attache → creux de la bouche
  let turn = .22 * Math.sin(e.tl * .45 + e.ph * 2), kH = 4.5, oT = .1 + .12 * Math.max(0, Math.sin(e.tl * 1.3 + e.ph)), gT = .1 * Math.sin(e.tl * .9 + e.ph), kG = 3, ext = 0;
  const dIn = st.h && st.in != null ? fr - st.in : 1e9, dOut = st.out != null && fr >= st.out ? fr - st.out : 1e9;
  if (b && run) {
    const rel = crWrapA(Math.atan2(b.y - hy, b.x - hx) - bh), db = Math.hypot(b.x - hx, b.y - hy);
    if (etat === 1) { const pq = cl01(1 - (db - r) / 80); turn = cbo(rel, 1.1) * (.3 + .7 * pq); oT = .2 + .75 * pq; gT = -.22 * pq; kG = 5; kH = 6;
      ext = pq * Math.min(6 * sc, Math.max(0, db - nL - MC - 5 * sc)); }                                 // approche : la tête se tourne, le croissant s'ouvre et s'étale
    else if (etat === 2) { turn = cbo(rel, 2.6); kH = dIn < 18 ? 11 : 7; ext = Math.min(12 * sc, Math.max(0, db - nL - MC));
      if (dIn < 4) { oT = 1; gT = -.15; kG = 14; } else if (dIn < 18) { oT = .8; gT = 1; kG = 9; }      // prise : bouche grande ouverte puis le croissant se referme autour
      else { oT = .74 + .05 * Math.sin(e.tl * 2.3); gT = .9 + .07 * Math.sin(e.tl * 1.7 + e.ph); kG = 5; } }   // port : elle reste enveloppée (le bord respire)
    else if (etat === 3 && dOut < 50) { const rv = crWrapA(Math.atan2(b.vy, b.vx) - bh); turn = cbo(rv, .8) * (1 - dOut / 50); kH = 10; ext = 3.6 * sc * Math.sin(Math.PI * Math.min(1, dOut / 11));
      if (dOut < 6) { oT = 1; gT = -.8; kG = 30; } else if (dOut < 22) { oT = .55; gT = -.15; kG = 7; } else { oT = .25; gT = 0; kG = 4; } }   // lancer : détente sèche du croissant
  } else if (etat === 1) { oT = .75; gT = -.18; ext = 2 * sc; turn = .5; }
  else if (etat === 2) { oT = .72; gT = .9; turn = -.35; }
  else if (etat === 3) { oT = 1; gT = -.5; ext = 3 * sc * (.5 + .5 * Math.sin(e.tl * 5)); }
  e.hA = e.hA == null ? bh + turn : e.hA + crWrapA(bh + turn - e.hA) * Math.min(1, dt * kH);
  e.mo = (e.mo || 0) + (oT - (e.mo || 0)) * Math.min(1, dt * 10); e.cup = (e.cup || 0) + (gT - (e.cup || 0)) * Math.min(1, dt * kG);
  e.ext = (e.ext || 0) + (ext - (e.ext || 0)) * Math.min(1, dt * 12);
  const hA = e.hA, ca = Math.cos(hA), sa = Math.sin(hA), Ln = nL + e.ext, Ax = DX[0] + ca * Ln, Ay = DY[0] + sa * Ln;
  const HX = e.hdx || (e.hdx = new Float32Array(NHD)), HY = e.hdy || (e.hdy = new Float32Array(NHD));
  teteForme(e.mo, e.cup, e.tl, e.ph, Ax, Ay, ca, sa, hz, HX, HY);
  /* largeur du corps : cou fin, plein vers u≈.2, effilé ensuite ; respiration propagée */
  const EX = e.bex || (e.bex = new Float32Array(NSP * 2)), EY = e.bey || (e.bey = new Float32Array(NSP * 2)), WB = e.bwb || (e.bwb = new Float32Array(NSP));
  const bre = e.tl * 1.9 + e.ph;
  for (let k = 0; k < NSP; k++) { const u = k / (NSP - 1), s0 = cl01(u / .17), w = sc * (.45 + 4.3 * Math.pow(1 - u, 1.2) * (.29 + .71 * s0 * s0 * (3 - 2 * s0))) * (1 + .07 * Math.sin(bre - u * 7) - .08 * AC);
    WB[k] = w; EX[k] = DX[k] + NX[k] * w; EY[k] = DY[k] + NY[k] * w; EX[2 * NSP - 1 - k] = DX[k] - NX[k] * w; EY[2 * NSP - 1 - k] = DY[k] - NY[k] * w; }
  /* cou : courbe de Bézier du corps vers l'attache (arrière du bord concave), ondulation lente, léger étranglement */
  const p1x = DX[0] + Math.cos(bh) * Ln * .45, p1y = DY[0] + Math.sin(bh) * Ln * .45, p2x = Ax - ca * Ln * .42, p2y = Ay - sa * Ln * .42, wo = Math.sin(e.tl * 2.1 + e.ph) * .9 * sc;
  const NKX = e.nkx || (e.nkx = new Float32Array(NNK * 4)), wa = 1.25 * hz;
  for (let j = 0; j < NNK; j++) { const t = (j + 1) / (NNK + 1), mt = 1 - t, b0 = mt * mt * mt, b1 = 3 * mt * mt * t, b2 = 3 * mt * t * t, b3 = t * t * t;
    const sw = wo * Math.sin(Math.PI * t), px = b0 * DX[0] + b1 * p1x + b2 * p2x + b3 * Ax - sa * sw, py = b0 * DY[0] + b1 * p1y + b2 * p2y + b3 * Ay + ca * sw;
    const tx = -(3 * mt * mt * (p1x - DX[0]) + 6 * mt * t * (p2x - p1x) + 3 * t * t * (Ax - p2x)), ty = -(3 * mt * mt * (p1y - DY[0]) + 6 * mt * t * (p2y - p1y) + 3 * t * t * (Ay - p2y)), tl = Math.hypot(tx, ty) || 1;
    const w = WB[0] + (wa - WB[0]) * t - .3 * sc * Math.sin(Math.PI * t); NKX[4 * j] = px; NKX[4 * j + 1] = py; NKX[4 * j + 2] = -ty / tl * w; NKX[4 * j + 3] = tx / tl * w; }
  /* contour unique : flanc + (queue → cou) · cou + · tête (croissant) · cou − · flanc − (cou → queue) */
  const NU = 2 * NSP + 2 * NNK + NHD, UX = e.ux || (e.ux = new Float32Array(NU)), UY = e.uy || (e.uy = new Float32Array(NU));
  let n = 0;
  for (let k = NSP - 1; k >= 0; k--) { UX[n] = EX[k]; UY[n++] = EY[k]; }
  for (let j = 0; j < NNK; j++) { UX[n] = NKX[4 * j] + NKX[4 * j + 2]; UY[n++] = NKX[4 * j + 1] + NKX[4 * j + 3]; }
  for (let j = 0; j < NHD; j++) { UX[n] = HX[j]; UY[n++] = HY[j]; }
  for (let j = NNK - 1; j >= 0; j--) { UX[n] = NKX[4 * j] - NKX[4 * j + 2]; UY[n++] = NKX[4 * j + 1] - NKX[4 * j + 3]; }
  for (let k = 0; k < NSP; k++) { UX[n] = EX[2 * NSP - 1 - k]; UY[n++] = EY[2 * NSP - 1 - k]; }
  ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath(); crTrace(ctx, UX, UY, n); ctx.closePath();
  ctx.fillStyle = e.K3; ctx.globalAlpha = .38; ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .05 + .04 * V + .07 * AC; ctx.fill();
  deuxTraits(ctx, e.K2, .34 + .14 * V + .18 * AC, 2.2 * sc, .34 * sc, .16);   // peau : liseré fin + voile, d'un seul tenant
  /* bandes longitudinales lumineuses (comme le planaire) : deux bandes latérales + moelle qui remonte le cou jusqu'au creux de la tête */
  for (const f of [-.5, .5]) { ctx.beginPath(); ctx.moveTo(DX[1] + NX[1] * WB[1] * f, DY[1] + NY[1] * WB[1] * f);
    for (let k = 2; k < NSP - 2; k++) { const k2 = k + 1; ctx.quadraticCurveTo(DX[k] + NX[k] * WB[k] * f, DY[k] + NY[k] * WB[k] * f, (DX[k] + NX[k] * WB[k] * f + DX[k2] + NX[k2] * WB[k2] * f) / 2, (DY[k] + NY[k] * WB[k] * f + DY[k2] + NY[k2] * WB[k2] * f) / 2); }
    deuxTraits(ctx, e.K2, .2 + .1 * V + .14 * AC, 1.6 * sc, .24 * sc, .2); }
  ctx.beginPath(); ctx.moveTo(Ax + ca * 1.6 * hz, Ay + sa * 1.6 * hz); for (let j = NNK - 1; j >= 0; j--) ctx.lineTo(NKX[4 * j], NKX[4 * j + 1]);
  crTraceSuite(ctx, DX, DY, NSP);
  deuxTraits(ctx, e.K1, .2 + .1 * V + .15 * AC, 2 * sc, .3 * sc, .15);   // moelle (discrète)
  /* berceau : échantillon de la colonne le plus proche de la particule portée */
  let kb = -1;
  if (b && (etat === 2 || (etat === 3 && st.out != null && fr - st.out < 8))) { let bd = 1e9; for (let k = 0; k < (NSP >> 1); k++) { const ddx = DX[k] - b.x, ddy = DY[k] - b.y, dd = ddx * ddx + ddy * ddy; if (dd < bd) { bd = dd; kb = k; } } if (bd > 196 * sc * sc) kb = -1; }
  const gAm = kb < 0 ? 0 : etat === 2 ? cl01(st.in != null ? (fr - st.in - 4) / 14 : 1) : cl01(1 - (fr - st.out) / 8);
  e.grp = (e.grp || 0) + (gAm - (e.grp || 0)) * Math.min(1, dt * 8);
  ctx.beginPath();
  for (let k = 3; k < NSP - 3; k += 3) {
    const u = k / (NSP - 1), w = WB[k], t0x = DX[k + 1] - DX[k - 1], t0y = DY[k + 1] - DY[k - 1], tq = Math.hypot(t0x, t0y) || 1, tx = t0x / tq, ty = t0y / tq;
    const rp = Math.sin(e.tl * 2.1 + e.ph - u * 9), gk = kb >= 0 ? e.grp * cl01(1 - Math.abs(k - kb) / 6) : 0;
    for (let sd = -1; sd <= 1; sd += 2) {
      const nx = NX[k] * sd, ny = NY[k] * sd, x0 = DX[k] + nx * w * .42 - tx * w * .1, y0 = DY[k] + ny * w * .42 - ty * w * .1, sl = w * (.7 + .3 * rp * sd);
      let qx = DX[k] + nx * w * (1.08 + .1 * rp) + tx * sl, qy = DY[k] + ny * w * (1.08 + .1 * rp) + ty * sl;
      const cx = DX[k] + nx * w * .78 + tx * sl * .15, cy = DY[k] + ny * w * .78 + ty * sl * .15;
      if (gk > 0) { qx += (b.x - qx) * gk * .55; qy += (b.y - qy) * gk * .55; }
      ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, qx, qy);
    }
  }
  deuxTraits(ctx, e.K2, .09 + .05 * V + .08 * AC, 1.2 * sc, .2 * sc, .25);   // R479 : côtes à peine esquissées (plis de chair)
  if (kb >= 0 && e.grp > .05) { spr(ctx, e.SAG, b.x, b.y, (6 + 2 * Math.sin(e.tl * 3)) * sc, .16 * e.grp); spr(ctx, e.SG, DX[kb], DY[kb], 9 * sc, .14 * e.grp); }
  /* 6. polypes et tentacules : retard visco-élastique (la pointe suit plus tard que la base), traînée lumineuse */
  const TQ = e.tq || (e.tq = new Float32Array(NTP * NTN * 2)), TS = e.ts || (e.ts = new Float32Array(NTP * NTN * 2));
  const ini = !e.tq0; e.tq0 = 1;
  for (let p = 0; p < NTP; p++) {
    const kk = at(.68 + p * .16) | 0, ax = DX[kk], ay = DY[kk], sd = NY[kk] > 0 ? 1 : -1, nx = NX[kk] * sd, ny = NY[kk] * sd;   // normale tournée vers le bas
    const Lp = 5.2 * sc, wq = WB[kk] * .8, bx = ax + nx * (Lp * .2 + wq), by = ay + ny * (Lp * .2 + wq), mx = ax + nx * (Lp + wq), my = ay + ny * (Lp + wq);
    const Lt = (22 + 6 * (p % 2) + 3 * p) * sc * (1 - .35 * AC), sgT = Lt / (NTN - 1), o = p * NTN * 2;
    const cyc = (T * .15 + p * .29 + e.ph) % 1;
    for (let q = 0; q < NTN; q++) {
      const u = q / (NTN - 1), sw = Math.sin(e.tl * 1.25 - u * 3.4 + p * 1.7) * (3.2 + 2 * V) * u * sc, cu = Math.sin(e.tl * .6 + p) * .35 * u;
      const gx = mx + (nx * Math.cos(cu) - ny * Math.sin(cu)) * Lt * u - ny * sw, gy = my + (ny * Math.cos(cu) + nx * Math.sin(cu)) * Lt * u + nx * sw + u * u * 3 * sc;
      if (ini || q === 0) { TQ[o + 2 * q] = gx; TQ[o + 2 * q + 1] = gy; if (ini || q === 0) { TS[o + 2 * q] = gx; TS[o + 2 * q + 1] = gy; } continue; }
      const kv = Math.min(1, dt * 14 / (1 + q * .9));                                   // visco-élastique : la pointe traîne
      TQ[o + 2 * q] += (gx - TQ[o + 2 * q]) * kv; TQ[o + 2 * q + 1] += (gy - TQ[o + 2 * q + 1]) * kv;
      const ks = Math.min(1, dt * 2.6); TS[o + 2 * q] += (TQ[o + 2 * q] - TS[o + 2 * q]) * ks; TS[o + 2 * q + 1] += (TQ[o + 2 * q + 1] - TS[o + 2 * q + 1]) * ks;
    }
    for (let q = 1; q < NTN; q++) { const i0 = o + 2 * q - 2, i1 = o + 2 * q, ex = TQ[i1] - TQ[i0], ey = TQ[i1 + 1] - TQ[i0 + 1], d = Math.hypot(ex, ey) || 1; if (d > sgT * 1.25) { const k2 = sgT * 1.25 / d; TQ[i1] = TQ[i0] + ex * k2; TQ[i1 + 1] = TQ[i0 + 1] + ey * k2; } }
  }
  /* traînées lumineuses (chemin récent, large et très pâle) puis tentacules : deux tracés pour les quatre */
  for (const [A, w, col, al] of [[TS, 3 * sc, e.K1, .05 + .05 * V + .06 * AC], [TQ, .3 * sc + .12, e.K2, .34 + .15 * V + .2 * AC]]) {
    ctx.beginPath();
    for (let p = 0; p < NTP; p++) { const o = p * NTN * 2; ctx.moveTo(TQ[o], TQ[o + 1]); for (let q = 1; q < NTN; q++) { const i = o + 2 * q, j = q < NTN - 1 ? i + 2 : i; ctx.quadraticCurveTo(A[i], A[i + 1], (A[i] + A[j]) / 2, (A[i + 1] + A[j + 1]) / 2); } }
    ctx.strokeStyle = col; ctx.globalAlpha = al; ctx.lineWidth = w; ctx.stroke();
  }
  for (let p = 0; p < NTP; p++) {
    const kk = at(.68 + p * .16) | 0, ax = DX[kk], ay = DY[kk], sd = NY[kk] > 0 ? 1 : -1, nx = NX[kk] * sd, ny = NY[kk] * sd;   // normale tournée vers le bas
    const Lp = 5.2 * sc, wq = WB[kk] * .8, bx = ax + nx * (Lp * .2 + wq), by = ay + ny * (Lp * .2 + wq), mx = ax + nx * (Lp + wq), my = ay + ny * (Lp + wq);
    const Lt = (22 + 6 * (p % 2) + 3 * p) * sc * (1 - .35 * AC), sgT = Lt / (NTN - 1), o = p * NTN * 2;
    const cyc = (T * .15 + p * .29 + e.ph) % 1;
    for (let q = 4; q < NTN; q += 4) { const i = o + 2 * q, u = q / (NTN - 1), pu = Math.pow(.5 + .5 * Math.sin(e.tl * 2.4 - u * 7 + p), 4);
      spr(ctx, e.SP, TQ[i], TQ[i + 1], (.65 + .5 * pu) * sc, .2 + .35 * pu + .2 * V + .4 * ondeA(e, .6 + u * .4)); }   // cnidocystes : perles qui s'allument en descendant
    /* polype (gastrozoïde) : petite goutte translucide, bouche lumineuse, trois palpes */
    const ang = Math.atan2(ny, nx);
    ctx.save(); ctx.translate(bx, by); ctx.rotate(ang);
    const bw = (1.9 + .3 * Math.sin(e.tl * 1.8 + p)) * sc;
    ctx.beginPath(); ctx.moveTo(0, -bw * .5); ctx.bezierCurveTo(Lp * .45, -bw * 1.25, Lp * .95, -bw * .6, Lp, 0); ctx.bezierCurveTo(Lp * .95, bw * .6, Lp * .45, bw * 1.25, 0, bw * .5); ctx.closePath();
    ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.K3; ctx.globalAlpha = .45; ctx.fill();
    ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .08 + .06 * V; ctx.fill();
    for (let q = -1; q <= 1; q++) { ctx.moveTo(Lp * .3, q * bw * .7); ctx.quadraticCurveTo(Lp * .2, q * bw * 1.6, Lp * (.05 + .05 * Math.sin(e.tl * 3 + q + p)), q * bw * 2.1); }   // trois palpes
    deuxTraits(ctx, e.K2, .3 + .15 * V, 1.6 * sc, .26 * sc, .2);
    ctx.restore();
    const meal = cyc > .78 ? 1 - (cyc - .78) / .22 : 0;
    if (meal > 0) spr(ctx, e.SAG, mx, my, (3 + 4 * meal) * sc, .1 + .35 * meal); spr(ctx, e.SA, mx, my, (.9 + .5 * meal) * sc, .35 + .3 * V + .4 * meal);
    /* pêche : un grain de plancton dérive vers la pointe, se fait prendre, remonte le long du tentacule ; la bouche s'allume */
    const tip = o + 2 * (NTN - 1);
    if (cyc < .5) { const a = cyc / .5, qx = TQ[tip] + (1 - a) * (12 + 5 * p) * sc * Math.cos(p * 2.1 + e.ph), qy = TQ[tip + 1] + (1 - a) * 10 * sc * Math.sin(p * 1.7 + e.ph) + 3 * sc;
      spr(ctx, e.SAG, qx, qy, 3.4 * sc, .1 + .16 * a); spr(ctx, e.SA, qx, qy, 1.2 * sc, .35 + .4 * a); }
    else if (cyc < .78) { const a = (cyc - .5) / .28, g = (1 - a) * (NTN - 1), q = Math.min(NTN - 2, g | 0), f = g - q, i = o + 2 * q, qx = TQ[i] + (TQ[i + 2] - TQ[i]) * f, qy = TQ[i + 1] + (TQ[i + 3] - TQ[i + 1]) * f;
      spr(ctx, e.SAG, qx, qy, 4 * sc, .28); spr(ctx, e.SA, qx, qy, 1.3 * sc, .8); }
  }
  /* 8. six cloches translucides, de part et d'autre de la tige, ouvertes vers l'arrière ; chacune pulse à sa phase */
  for (let i = 0; i < NCL; i++) {
    const g = at(.1 + i * .13), k = g | 0, sd = i % 2 ? 1 : -1, tx = DX[k + 1] - DX[k], ty = DY[k + 1] - DY[k], ta = Math.atan2(-ty, -tx);   // axe : vers la tête
    const ph = e.bph - i * e.dlt, cn = .5 - .5 * Math.cos(ph), sys = Math.sin(ph) > .6;
    const gr = 1 - i * .06, off = 7.6 * sc * gr, bx = DX[k] + NX[k] * sd * off, by = DY[k] + NY[k] * sd * off, Lb = 10 * sc * gr * (1 + .1 * cn), Wb = (5.6 - 1.7 * cn) * sc * gr;
    const I = .4 + .18 * V + .3 * AC + .3 * ondeA(e, i / (NCL + 4) + .1), rot = ta + sd * (.32 - .1 * cn);
    /* pédoncule : fil courbe de la tige à la cloche */
    ctx.beginPath(); ctx.moveTo(DX[k], DY[k]); ctx.quadraticCurveTo(DX[k] + NX[k] * sd * off * .4 + Math.cos(ta) * 2 * sc, DY[k] + NY[k] * sd * off * .4 + Math.sin(ta) * 2 * sc, bx + Math.cos(rot) * Lb * .42, by + Math.sin(rot) * Lb * .42);
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .2 + .1 * V; ctx.lineWidth = .3 * sc; ctx.stroke();
    ctx.save(); ctx.translate(bx, by); ctx.rotate(rot);
    const xr = -Lb * .5, xa = Lb * .5;
    /* ombrelle (couche extérieure) : remplissage très transparent */
    ctx.beginPath(); ctx.moveTo(xr, -Wb); ctx.bezierCurveTo(-Lb * .05, -Wb * 1.18, xa, -Wb * .78, xa, 0); ctx.bezierCurveTo(xa, Wb * .78, -Lb * .05, Wb * 1.18, xr, Wb); ctx.quadraticCurveTo(xr + Lb * .12, 0, xr, -Wb);
    ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.K3; ctx.globalAlpha = .17; ctx.fill();
    ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .03 + .06 * cn * (.5 + AC); ctx.fill();
    ctx.strokeStyle = e.K1; ctx.globalAlpha = Math.min(1, I * .62); ctx.lineWidth = .28 * sc + .08; ctx.stroke();
    /* sous-ombrelle : seconde couche intérieure, plus pâle */
    /* R481 : sous-ombrelle fondue dans les nervures (allègement) */
    /* bord lumineux (l'ouverture vue de biais) */
    ctx.beginPath(); ctx.ellipse(xr + Lb * .04, 0, (.7 + .9 * cn) * sc, Wb * .98, 0, -Math.PI * .5, Math.PI * .5);   // demi-bord : l'ouverture se lit sans faire « gobelet »
    deuxTraits(ctx, e.K2, I * (.45 + .45 * cn), 2 * sc, .28 * sc, .25);
    /* nervures radiaires fines (de l'apex au bord) */
    ctx.beginPath(); for (const v of [-.8, -.35, .35, .8]) { ctx.moveTo(xa * .92, v * Wb * .18); ctx.quadraticCurveTo(Lb * .08, v * Wb * 1.02, xr + Lb * .02, v * Wb); }
    /* frange : filaments courts qui traînent derrière l'ouverture */
    for (let q = 0; q < 4; q++) { const yq = (q / 3 - .5) * 1.5 * Wb, wv = Math.sin(e.tl * 3.2 + q * 1.3 + i) * 1.2 * sc; ctx.moveTo(xr, yq); ctx.quadraticCurveTo(xr - (2 + cn * 1.5) * sc, yq * 1.12 + wv * .5, xr - (4.2 + 2 * cn) * sc, yq * 1.2 + wv); }   // nervures + frange : un seul tracé
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .12 + .2 * cn + .08 * V; ctx.lineWidth = .23 * sc; ctx.stroke();
    /* petit cœur (manubrium) */
    spr(ctx, e.SA, Lb * .1, 0, (.9 + .5 * cn) * sc, .3 + .4 * cn + .2 * V);
    ctx.restore();
    if (sys && dt > 0 && hs(T * 7.3 + i) < (.12 + .5 * AC)) { const v = 26 + 30 * AC, ca = Math.cos(rot), sa = Math.sin(rot); emP(Q, 1, bx - ca * Lb * .6, by - sa * Lb * .6, -ca * v, -sa * v, .45, .7 + .4 * AC, 2.6); }
  }
  /* 9. photophores de la tige : pulsations douces qui voyagent de la tête à la queue (et l'onde de lumière quand elle « parle ») */
  for (let k = 2; k < NSP; k += 4) { const u = k / (NSP - 1), pu = Math.pow(.5 + .5 * Math.sin(e.tl * 2 - u * 11), 5), w = ondeA(e, u);
    const ke = (k >> 1) & 1 ? k : 2 * NSP - 1 - k; spr(ctx, e.SP, DX[k] + (EX[ke] - DX[k]) * .8, DY[k] + (EY[ke] - DY[k]) * .8, (.8 + 1.1 * pu + 1.3 * w) * sc, .1 + .34 * pu + .7 * w + .1 * V); }   // R478 : sur le liseré, d'un côté puis de l'autre
  if (etat === 3 && st.out === fr - 1) for (let i = 0; i < NCL; i++) { const k = at(.1 + i * .13) | 0; emP(Q, 3, DX[k], DY[k], 0, 0, 1.1, 4 * sc, i % 2 ? 1 : -1); }   // salve : volutes
  /* 10. R479 · TÊTE EN CROISSANT (d'après le planaire Bipalium) : épaisseur, nervures radiales, rangée de points oculaires,
     deux antennes très fines tirées vers l'arrière (retard visco-élastique). Le contour fait déjà partie de la forme unique. */
  teteDetails(ctx, e, HX, HY, Ax, Ay, ca, sa, hz, V, AC, dt, b && etat === 2 && e.cup > .4 ? b : null);
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  e.lx = hx; e.ly = hy;
  dessinerPart(ctx, Q, e);
}
/* BRAISE : tore à éversion vu en perspective ; la peau roule sur le tube (bandes qui passent par le trou), fourrure de cils
   bioluminescents (R477 : bleu glacé, pointes menthe, cœur blanc ; ni cuivre ni orange) ; les dix cellules du Chœur font le tour ; parfois elle s'étrangle en 8 (souvenir de division) puis se rouvre ;
   de temps en temps elle culbute (l'axe bascule). Au contact : éclat, gerbe d'étincelles dans le sens de la particule. */
const BM = 20, BK = 3;   // R481 : anneau 26→20 points, 3 bandes
function dessinerBraiseR481(ctx, e, x, y, etat, st, b, T, dt, fr) {   // R494 : ancien rendu (bancs A/B) — nouveau : bloc REPASSE M1-4 BRAISE
  const c = e.c, r = (c.r || 26) * 1.2, sc = r / 26, V = e.vit, AC = e.ac;   // R478 : dessin agrandi de 20 % (rendu seul ; rayon physique inchangé)
  const ox = e.wx * 2.2, oy = e.wy * 2 + 1.5 * Math.sin(e.tl * .7 + e.ph), cx = x + ox, cy = y + oy;
  const flash = st.in != null && fr >= st.in && fr - st.in < 40 ? 1 - (fr - st.in) / 40 : 0;
  if (st.in != null && st.in !== e.lastIn && fr >= st.in && fr - st.in < 4) { e.lastIn = st.in; e.fl = 1; if (b) { const a0 = Math.atan2(b.vy, b.vx); for (let k = 0; k < 9; k++) { const a = a0 + (hs(T * 3 + k) - .5) * .9, v = 40 + 50 * hs(T * 5 + k); emP(e.Q, 1, b.x, b.y, Math.cos(a) * v, Math.sin(a) * v, .5 + .3 * hs(k + T), 1.2, 1.6); } } }
  e.fl = Math.max(0, (e.fl || 0) - dt * 1.5);
  /* horloges de rendu : éversion (accélère en alerte et action), culbute (toutes ~11 s), étranglement en 8 (toutes ~17 s) */
  e.ev = (e.ev || 0) + dt * (.35 + .7 * V + 1.6 * AC + 2.5 * e.fl);
  const cu = (T + e.ph * 3) % 11, flip = cu < 1.6 ? .5 - .5 * Math.cos(Math.PI * cu / 1.6) : 0;
  const dv = (T + e.ph * 5) % 17, pinch = AC > .4 ? 0 : dv < 3.2 ? Math.sin(Math.PI * dv / 3.2) * .9 : 0;
  const tilt = 1.02 + .12 * Math.sin(e.tl * .4 + e.ph) + flip * Math.PI, ct = Math.cos(tilt), stt = Math.sin(tilt);
  let rot = .25 * Math.sin(e.tw * .6 + e.ph) + e.wr * .1;
  if (b && etat >= 1) { const ab = Math.atan2(b.y - cy, b.x - cx) - Math.PI / 2; e.ro = (e.ro == null ? rot : e.ro) + (crWrapA(ab - (e.ro || 0)) * .25) * Math.min(1, dt * 3); rot = e.ro; } else e.ro = rot;
  const co = Math.cos(rot), si = Math.sin(rot), Rm = r * .74, rt = r * .27 * (1 + .1 * e.fl - .06 * AC);
  const Q = e.Q; Q.cx = cx; Q.cy = cy; majPart(Q, dt);
  const P = (phi, psi, out) => {                      // tore → écran ; out = [x, y, profondeur]
    const rr = Rm * (1 - pinch * .5 * Math.pow(Math.sin(phi), 2)) + rt * Math.cos(psi), X = rr * Math.cos(phi), Yp = rr * Math.sin(phi), Z = rt * Math.sin(psi);
    const Y = Yp * ct - Z * stt, D = Yp * stt + Z * ct;
    out[0] = cx + X * co - Y * si; out[1] = cy + X * si + Y * co; out[2] = D; return out; };
  const pt = e.pt || (e.pt = [0, 0, 0]), p2 = e.p2 || (e.p2 = [0, 0, 0]);
  ombre(ctx, e, cx, cy + 4, Rm * 1.55, Rm * (.95 + .5 * Math.abs(ct)), rot, .78);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, cx, cy, Rm * 2.1, .08 + .1 * V + .2 * AC + .35 * e.fl);
  /* corps du tube : anneau sombre translucide (deux bords) */
  ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath(); for (let i = 0; i <= BM; i++) { P(i / BM * TAU, 0, pt); i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); }
  ctx.strokeStyle = e.K3; ctx.globalAlpha = .68; ctx.lineWidth = rt * 2.2; ctx.stroke();   // R481 : tube sombre en un trait (au lieu de deux)
  ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = e.K1; ctx.globalAlpha = .13 + .08 * V + .13 * AC + .26 * e.fl; ctx.lineWidth = rt * 1.2; ctx.stroke();   // chair translucide qui luit (un trait)
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .12 + .06 * V; ctx.lineWidth = rt * .22; ctx.stroke();   // R477 : reflet de verre au milieu du tube
  ctx.globalCompositeOperation = 'lighter';
  /* bandes d'éversion : la peau passe par le trou et ressort dehors ; deux passes (arrière pâle, avant vif) */
  const e0 = e.ev * 1.4;
  for (let pass = 0; pass < 2; pass++) for (let gq = 0; gq < 2; gq++) {   // R481 : bandes regroupées par teinte (dehors / dedans) : 4 tracés au lieu de 10
    ctx.beginPath(); let fm = 0, nb = 0;
    for (let k = 0; k < BK; k++) {
      const psi = e0 + k * TAU / BK, fr2 = .5 + .5 * Math.cos(psi); if ((fr2 > .5 ? 0 : 1) !== gq) continue; fm += fr2; nb++; let on = false;
      for (let i = 0; i <= BM; i++) { P(i / BM * TAU, psi, pt); const vis = pass ? pt[2] >= -1 : pt[2] < 1; if (vis) { on ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); on = true; } else on = false; }
    }
    if (!nb) continue; fm /= nb;
    deuxTraits(ctx, gq ? e.K2 : e.K1, ((pass ? .24 : .07) + (pass ? .4 : .1) * fm * (.6 + .6 * V + .8 * AC) + .35 * e.fl) * (gq ? .5 : 1), 3.2, .4, .3);
  }
  /* fourrure de cils bioluminescents : cils souples qui battent en vague métachronale autour de l'anneau ; pointes menthe */
  ctx.beginPath();
  const Lc = (3.2 + 1.6 * V + 2.6 * AC + 2.2 * e.fl) * sc, tips = e.tips || (e.tips = new Float32Array(24)); let nt = 0;
  for (let i = 0; i < BM; i++) for (let k = 0; k < 2; k++) {
    const phi = (i + .5 * k) / BM * TAU, psi = e0 + k * 3.1 + i * .37; P(phi, psi, pt); if (pt[2] < -rt * .6) continue;
    const fl = hs(Math.floor(T * 5 + i * 3 + k * 7) * .37 + i); if (fl < .32 - .25 * AC) continue;
    const nx = pt[0] - cx, ny = pt[1] - cy, l = Math.hypot(nx, ny) || 1, ux = nx / l, uy = ny / l, L = Lc * (.55 + .6 * fl), bat = Math.sin(e.tl * 4.5 - phi * 3) * .6;
    const mx = pt[0] + ux * L * .55 - uy * bat * L * .3, my = pt[1] + uy * L * .55 + ux * bat * L * .3, qx = pt[0] + ux * L - uy * bat * L * .7, qy = pt[1] + uy * L + ux * bat * L * .7;
    ctx.moveTo(pt[0], pt[1]); ctx.quadraticCurveTo(mx, my, qx, qy);
    if (fl > .72 && nt < tips.length) { tips[nt++] = qx; tips[nt++] = qy; }
  }
  deuxTraits(ctx, e.K1, .42 + .25 * V + .3 * AC + .4 * e.fl, 2.4, .45, .25);
  const SM = e.SM || (e.SM = sprite('braisem', [150, 255, 222], 'p'));
  for (let j = 0; j < nt; j += 2) spr(ctx, SM, tips[j], tips[j + 1], (.8 + .5 * AC) * sc, .3 + .3 * V + .4 * e.fl);
  /* bords nets de l'anneau (avant) */
  ctx.beginPath(); for (const ps of [0, Math.PI]) { let on = false; for (let i = 0; i <= BM; i++) { P(i / BM * TAU, ps + Math.PI / 2, pt); if (pt[2] > -rt * .5) { on ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); on = true; } else on = false; } }
  deuxTraits(ctx, e.K2, .45 + .2 * V + .3 * e.fl, 2.4, .6, .22);   // R481 : les deux bords en un tracé
  /* R478 · liserés : bord extérieur et bord du trou, fins et nets (la silhouette se lit sur le décor) */
  for (const ps of [0, Math.PI]) { ctx.beginPath(); for (let i = 0; i <= BM; i++) { P(i / BM * TAU, ps, pt); i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); }
    deuxTraits(ctx, ps ? e.K1 : e.K2, ps ? .32 + .2 * V : .4 + .2 * V + .3 * e.fl, 2.6, ps ? .45 : .55, .2); }
  /* les dix cellules du Chœur font le tour du tube : petites perles cerclées ; à l'avant, nettes */
  const CEL = e.cel || (e.cel = new Float32Array(20)); let nc = 0;
  for (let i = 0; i < 8; i++) {
    const phi = i * TAU / 8 + e.ev * .12, psi = e0 * .9 + i * 1.3; P(phi, psi, pt); const fz = cl01(.5 + pt[2] / (rt * 2)), w = ondeA(e, i / 8);
    spr(ctx, e.SP, pt[0], pt[1], (1.2 + 1.2 * w + .8 * e.fl) * sc, (.15 + .5 * fz) * (.6 + .4 * V) + .5 * w);
    if (fz > .55) { CEL[nc++] = pt[0]; CEL[nc++] = pt[1]; }
  }
  ctx.beginPath(); for (let j = 0; j < nc; j += 2) { ctx.moveTo(CEL[j] + 1.9 * sc, CEL[j + 1]); ctx.arc(CEL[j], CEL[j + 1], 1.9 * sc, 0, TAU); }   // R481 : cercles des cellules en un tracé
  if (nc) { ctx.strokeStyle = e.K2; ctx.globalAlpha = .42; ctx.lineWidth = .4; ctx.stroke(); }
  /* cœur lumineux au centre du trou (halo lilas, noyau blanc bioluminescent) : bat lentement, s'emballe en alerte */
  const hb = .5 + .5 * Math.sin(e.tl * (1.5 + 3 * AC) + e.ph), SW = e.SW || (e.SW = sprite('braisec', [236, 250, 255], 'p'));
  spr(ctx, e.SAG, cx, cy, (5 + 3 * hb + 6 * e.fl) * sc, .22 + .16 * hb + .3 * e.fl); spr(ctx, e.SG, cx, cy, (3 + 1.5 * hb) * sc, .28 + .15 * hb); spr(ctx, SW, cx, cy, (1.7 + .7 * hb) * sc, .62 + .3 * hb);
  /* grains de lumière : ils montent doucement, plus nombreux quand elle s'anime */
  if (dt > 0 && hs(T * 13.1) < .08 + .3 * AC + .5 * e.fl) { const a = hs(T * 2.9) * TAU; P(a, 0, pt); emP(Q, 1, pt[0], pt[1], (hs(T * 4.1) - .5) * 10, -12 - 18 * hs(T * 6.3), .9 + .6 * hs(T), .6 + .5 * AC, .5); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  e.lx = cx; e.ly = cy;
  dessinerPart(ctx, Q, e);
}
/* ═════ R480 · ÉTAGE 4 (Monde 4, Glacier) — LEURRE et ÉCHASSIÈRE ═════
   Charte de l'étage 4 (eau de fonte sous la glace) : bleu glacé, cyan, menthe, lilas, blanc — ni cuivre, ni orange, ni doré.
   Chaque créature est UNE forme organique continue (contours de Bézier lisses), translucide, à lignes fines lumineuses ;
   le mouvement naît de la propagation de phase et du retard visco-élastique. Rendu seul : la physique (fluides.js) ne dépend que de
   crBulbe (leurre) et crPos (échassière). Effet de particule de l'étage : le GIVRE-LANGAGE — touchée par une créature de l'étage, la
   particule sème de fins cristaux de givre qui clignotent selon le mot de la créature (leurre · · — ; échassière — — ·) puis
   descendent lentement en s'éteignant, comme du givre qui se dépose. */
const LRN = 26;                                     // points du filament (mutualisés en un seul tracé)
/* LEURRE : larve minuscule et translucide, filament très long qui ondule en S lents et traîne en retard sur le balancement,
   bulbe-leurre au bout (goutte translucide, lumière d'appât qui pulse). Repos : le filament dessine des S lents, des pulsations
   lumineuses descendent du corps au bulbe, le plancton s'approche du bulbe et s'y éteint (elle se nourrit). Alerte : le bulbe
   s'allume plus vite. Action : la particule pend au bulbe, le filament se tend (S écrasés) ; au lancer, une onde de fouet court
   du corps au bulbe. */
function dessinerLeurreR482(ctx, e, x, y, etat, st, b, T, dt, fr, run) {   // R494 : ancien rendu (gardé pour les bancs) — nouveau : bloc REPASSE M1-4 LEURRE
  const c = e.c, FL = racine.FLUID, V = e.vit, AC = e.ac, L = c.L || 80;
  const q = FL.crBulbe(c, fr, run ? st : null), q1 = FL.crBulbe(c, fr + 1, run ? st : null), app = run && !st.h ? cl01(Math.abs(st.att || 0) * 2.5 + Math.abs(st.ext || 0) / 25) : 0;   // R482 : app = le bulbe va vers la bille
  const held = !!st.h && run;
  const idle = run ? 0 : .07 * Math.sin(T * .55 + e.ph) + .03 * Math.sin(T * 1.3);   // hors essai : le pendule respire à peine
  let phi = q[2] + idle, bx = x + L * Math.sin(phi), by = y + L * Math.cos(phi);
  if (held && b) { bx = b.x; by = b.y; }
  const dphi = run ? q1[2] - q[2] : .07 * .55 / 60 * Math.cos(T * .55 + e.ph);
  e.dp = e.dp == null ? dphi : e.dp + (dphi - e.dp) * Math.min(1, dt * 3);          // retard : le filament suit le balancement avec du retard
  /* corps : larve suspendue, tête à l'opposé du filament, bascule à contre-balancement */
  const hx = x + e.wx * 2.2 + 4 * Math.sin(T * .37 + e.ph), hy = y + e.wy * 1.6 + Math.sin(e.tl * .7 + e.ph) * 1.2 + 3 * Math.sin(T * .74 + e.ph);   // R482 : elle nage autour de son ancrage (huit lent)
  const ch = Math.atan2(by - hy, bx - hx), ax = ch + Math.PI + (.55 + .3 * Math.sin(e.tw * .6 + e.ph)) * (Math.sin(e.ph) >= 0 ? 1 : -1) - e.dp * 9 + .12 * e.wr + .38 * Math.sin(T * .45 + e.ph * 2);
  const ca = Math.cos(ax), sa = Math.sin(ax), Lb = 23, tx0 = hx - ca * Lb * .5, ty0 = hy - sa * Lb * .5;
  /* filament : corde queue → bulbe + S lents (onde qui descend) + traîne visco-élastique + onde de fouet au lancer */
  if (st.out === fr && run) e.fq = 0;
  if (e.fq != null) { e.fq += dt * 2.4; if (e.fq > 1.3) e.fq = null; }
  const FX = e.fx || (e.fx = new Float32Array(LRN)), FY = e.fy || (e.fy = new Float32Array(LRN));
  const dx = bx - tx0, dy = by - ty0, dl = Math.hypot(dx, dy) || 1, nx = -dy / dl, ny = dx / dl;
  const hk = ((-ca) * nx + (-sa) * ny) * dl * .5, amp = (.065 + .02 * V) * dl * (held ? .35 : 1), wt = e.tl * .9 + e.ph, lag = -e.dp * 26 * dl * (1 - app);
  for (let k = 0; k < LRN; k++) {
    const u = k / (LRN - 1), env = Math.sin(Math.PI * u), sw = Math.sin(wt - u * 7.4) * (.55 + .45 * u) + .2 * Math.sin(2.1 * wt - u * 13 + 1);
    let w = amp * env * sw + lag * u * (1 - u) * (1.3 - u) + hk * u * (1 - u) * (1 - u) * 2.2;   // hk : le filament quitte la queue dans l'axe du corps
    if (e.fq != null) { const z = (u - e.fq) / .09; w += 11 * (1 - e.fq * .7) * Math.exp(-z * z) * Math.sin(u * 40 - e.fq * 30); }
    FX[k] = tx0 + dx * u + nx * w; FY[k] = ty0 + dy * u + ny * w;
  }
  const tb = Math.atan2(FY[LRN - 1] - FY[LRN - 3], FX[LRN - 1] - FX[LRN - 3]);
  const bvx = run ? q1[0] - q[0] : 0, bvy = run ? q1[1] - q[1] : 0, cuX = Math.sin(T * .7 + e.ph) * 1.4, cuY = Math.cos(T * .53 + e.ph) * .8;   // R481 : vitesse du bulbe (traînée) + courant lent
  ombre(ctx, e, hx, hy, 15, 9, ax, .45);
  ombre(ctx, e, bx, by, 13, 13, 0, .32 + .2 * AC);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  /* filament (un seul tracé lissé, deux passes) + gaine proche du corps */
  ctx.beginPath(); ctx.moveTo(FX[0], FY[0]);
  for (let k = 1; k < LRN - 1; k++) ctx.quadraticCurveTo(FX[k], FY[k], (FX[k] + FX[k + 1]) / 2, (FY[k] + FY[k + 1]) / 2);
  ctx.lineTo(FX[LRN - 1], FY[LRN - 1]);
  deuxTraits(ctx, e.K1, .5 + .25 * V + .25 * AC, 3.2, .62, .2);
  ctx.beginPath(); ctx.moveTo(FX[0], FY[0]);
  for (let k = 1; k < 7; k++) ctx.quadraticCurveTo(FX[k], FY[k], (FX[k] + FX[k + 1]) / 2, (FY[k] + FY[k + 1]) / 2);
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .32; ctx.lineWidth = 1.1; ctx.stroke();
  /* R481 · poils fluides le long du filament : un sur deux points, côtés alternés ; ils traînent derrière le balancement */
  ctx.beginPath();
  for (let k = 2; k < LRN - 1; k += 3) {
    const u = k / (LRN - 1), tx = FX[k + 1] - FX[k - 1], ty = FY[k + 1] - FY[k - 1], tl = Math.hypot(tx, ty) || 1, sd = hs(k * 2.9 + e.i) > .5 ? 1 : -1;
    const Lh = 6 + 9 * hs(k * 1.7 + e.i);                 // cils longs, inégaux, couchés vers le bulbe (ils traînent), ondulés par le courant
    poil(ctx, FX[k], FY[k], -ty / tl * sd, tx / tl * sd, Lh, tx / tl * Lh * .75 - bvx * u * 3 + cuX * 1.6, ty / tl * Lh * .75 - bvy * u * 3 + cuY * 1.6, 2.6 * Math.sin(T * 1.9 - u * 6 + k));
    if (k % 6 === 5) poil(ctx, FX[k], FY[k], ty / tl * sd, -tx / tl * sd, Lh * .7, tx / tl * Lh * .6 + cuX, ty / tl * Lh * .6 + cuY, 2 * Math.sin(T * 2.2 - u * 5 + k * 2));
  }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .42 + .15 * V; ctx.lineWidth = .85; ctx.stroke();   // R482 : lisibles à l'échelle iPhone
  /* pulsations lumineuses qui descendent le filament (plus fréquentes en alerte et en action) */
  const np = 2 + (V > .5 ? 1 : 0);
  for (let j = 0; j < np; j++) {
    const u = ((T * (.16 + .2 * V + .2 * AC) + j / np + e.ph) % 1), g = u * (LRN - 1), i = Math.min(LRN - 2, g | 0), f = g - i;
    spr(ctx, e.SP, FX[i] + (FX[i + 1] - FX[i]) * f, FY[i] + (FY[i + 1] - FY[i]) * f, 2.2 + 1.2 * AC, .55 * Math.sin(Math.PI * u));
  }
  /* corps (une seule forme : tête ronde, nuque, repli de nageoire qui s'évase vers la queue, pointe effilée dans le filament) */
  const bend = Math.sin(e.tl * 1.7 + e.ph) * .9 + e.dp * 30;
  ctx.translate(hx, hy); ctx.rotate(ax); ctx.scale(1.35, 1.35);
  const tbt = (1.3 + .8 * V) * (held ? .5 : 1), P = (px, py) => [px, py + bend * (px - 7) * (px - 7) / 120 + tbt * Math.sin(T * 3.4 + e.ph - px * .33) * (9 - px) / 21];   // R482 : onde de nage qui court de la tête à la queue
  ctx.beginPath();
  let p = P(9, 0); ctx.moveTo(p[0], p[1]);
  const pts = [[8.7, -1.9, 6.6, -2.1], [4, -2.2, 1.2, -1.5], [-2.6, -1.3, -5, -2.1], [-8.4, -2.5, -10.4, -1], [-11.4, -.3, -12.4, 0]];
  for (const s of pts) { const a = P(s[0], s[1]), z = P(s[2], s[3]); ctx.quadraticCurveTo(a[0], a[1], z[0], z[1]); }
  const pb = [[-11.4, .4, -10.4, 1.1], [-8.4, 2.6, -5, 2.3], [-2.4, 1.6, .6, 2.2], [3.2, 3.5, 5.8, 2.5], [8.5, 2.2, 9, 0]];
  for (const s of pb) { const a = P(s[0], s[1]), z = P(s[2], s[3]); ctx.quadraticCurveTo(a[0], a[1], z[0], z[1]); }
  ctx.closePath();
  ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.K3; ctx.globalAlpha = .35; ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .13 + .06 * AC; ctx.fill();
  deuxTraits(ctx, e.K2, .34 + .25 * AC, 1.6, .3, .3);
  /* corde dorsale et nageoires pectorales (fins traits qui battent) */
  ctx.beginPath(); p = P(6.2, -.3); ctx.moveTo(p[0], p[1]); for (const xx of [3, 0, -3, -6, -9, -11.6]) { p = P(xx, -.2 + .1 * Math.sin(xx + e.tl * 2)); ctx.lineTo(p[0], p[1]); }
  const fl = Math.sin(T * (6 + 6 * V)) * 1.3;
  p = P(5, -1.9); ctx.moveTo(p[0], p[1]); ctx.quadraticCurveTo(p[0] - 1.5, p[1] - 2.2 - fl, p[0] - 3.4, p[1] - 1.1 - fl * .5);
  p = P(5, 2.2); ctx.moveTo(p[0], p[1]); ctx.quadraticCurveTo(p[0] - 1.5, p[1] + 2.2 + fl, p[0] - 3.4, p[1] + 1.2 + fl * .5);
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .38; ctx.lineWidth = .4; ctx.stroke();
  ctx.beginPath();                                       // R481 : poils fins sur le dos et le ventre (repère du corps), ondulent en vague
  for (let j = 0; j < 8; j++) { const xx = 6 - j * 2.2, sd = j & 1 ? 1 : -1, pp = P(xx, sd * (xx < -4 ? 2.2 : 2)); poil(ctx, pp[0], pp[1], -.35, sd, 4 + 1.2 * hs(j), -1.6 - e.dp * 40, 0, 1.3 * Math.sin(T * 2.6 - j * .8)); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .5; ctx.lineWidth = .7; ctx.stroke();
  p = P(3.6, 1.1); spr(ctx, e.SA, p[0], p[1], 2.6 + .8 * AC, .4 + .3 * Math.sin(e.tl * 1.4));   // vitellus lumineux (menthe)
  p = P(7.2, -.5); ctx.beginPath(); ctx.arc(p[0], p[1], .62, 0, TAU); ctx.fillStyle = e.K2; ctx.globalAlpha = .8; ctx.fill();   // œil minuscule
  ctx.restore();
  /* bulbe-leurre : goutte translucide, cœur d'appât qui pulse ; s'éclaire à la prise */
  ctx.save(); ctx.lineCap = 'round'; ctx.globalCompositeOperation = 'lighter';
  const pul = .5 + .5 * Math.sin(T * (1.7 + 2.5 * V) + e.ph), hit = st.in && run && fr - st.in < 30 && fr >= st.in ? 1 - (fr - st.in) / 30 : 0;
  const rb = 4.6 + .5 * pul + 1.2 * AC + 1.2 * app, ex = FX[LRN - 1], ey = FY[LRN - 1], cb = Math.cos(tb), sb = Math.sin(tb);
  const gx = ex + cb * rb * .9, gy = ey + sb * rb * .9;
  ctx.beginPath(); ctx.moveTo(ex - cb * 1.5, ey - sb * 1.5);
  ctx.bezierCurveTo(ex + cb * rb * .4 - sb * rb * 1.05, ey + sb * rb * .4 + cb * rb * 1.05, gx + cb * rb * 1.25 - sb * rb * .9, gy + sb * rb * 1.25 + cb * rb * .9, gx + cb * rb, gy + sb * rb);
  ctx.bezierCurveTo(gx + cb * rb * 1.25 + sb * rb * .9, gy + sb * rb * 1.25 - cb * rb * .9, ex + cb * rb * .4 + sb * rb * 1.05, ey + sb * rb * .4 - cb * rb * 1.05, ex - cb * 1.5, ey - sb * 1.5);
  ctx.fillStyle = e.K1; ctx.globalAlpha = .12 + .1 * pul; ctx.fill();
  deuxTraits(ctx, e.K2, .5 + .3 * pul + .3 * hit, 2.4, .5, .22);
  spr(ctx, e.SAG, gx, gy, 11 + 6 * pul + 10 * AC + 14 * hit + 10 * app, .14 + .14 * pul + .2 * AC + .3 * hit + .3 * app);   // l'appât s'allume à l'approche
  spr(ctx, e.SA, gx, gy, 3 + 1.6 * pul + 1.5 * hit, .55 + .4 * pul);
  spr(ctx, e.SP, gx - sb * rb * .35 - cb * rb * .3, gy + cb * rb * .35 - sb * rb * .3, 1.2, .6);   // reflet de verre
  ctx.beginPath();                                       // R481 : couronne de poils autour du bulbe (traînent derrière lui, ondulent)
  for (let j = 0; j < 10; j++) { const an = tb - 1.9 + j * .42, cA = Math.cos(an), sA = Math.sin(an), rr = rb * (j === 0 || j === 9 ? .8 : 1.02);
    poil(ctx, gx + cA * rr, gy + sA * rr, cA, sA, 7 + 3.5 * hs(j * 3.3 + e.i) + 1.5 * AC, app && b ? (b.x - gx) * .12 * app + cuX * (1 - app) : -bvx * 3 + cuX, app && b ? (b.y - gy) * .12 * app + cuY * (1 - app) : -bvy * 3 + cuY, 1.8 * Math.sin(T * 2.3 + j * 1.1)); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .5 + .2 * pul; ctx.lineWidth = .95; ctx.stroke();
  /* plancton : il dérive vers le bulbe-appât et s'y éteint (elle se nourrit) — positions ancrées au monde */
  const sp = e.SP;
  for (let j = 0; j < 6; j++) {
    const P0 = 4.2 + 2.6 * hs(j * 3.1 + e.i), u = ((T + hs(j * 7.7 + e.i) * P0) % P0) / P0, an = hs(j * 5.3 + e.i) * TAU + .3 * Math.sin(T * .2 + j);
    const R0 = 26 + 34 * hs(j * 2.2 + e.i), sx = x + Math.sin(phi) * L * .8 + Math.cos(an) * R0, sy = y + Math.cos(phi) * L * .8 + Math.sin(an) * R0;
    const m = u * u * (3 - 2 * u), px = sx + (gx - sx) * m + Math.sin(T * 1.3 + j) * 2 * (1 - m), py = sy + (gy - sy) * m;
    spr(ctx, sp, px, py, 1.1 + .4 * hs(j), (u < .1 ? u * 10 : u > .92 ? (1 - u) * 12 : 1) * (.3 + .3 * m));
    if (u > .9) e.fl = Math.max(e.fl, .4);
  }
  if (e.fl > .05) spr(ctx, e.SAG, gx, gy, 16, .25 * e.fl);
  ctx.restore();
  e.lx = gx; e.ly = gy; e.hx = hx; e.hy = hy;
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
/* R483 · ÉCHASSIÈRE = ARAIGNÉE NAGEUSE (prototype isolé /tmp/proto-arachne validé par Simon) : vrai squelette 3D léger projeté
   en perspective. Corps fin translucide à noyau bioluminescent, deux nageoires à nervures, huit longs bras-rubans en couronne
   (courbure continue avec un coude doux, liseré lumineux), poils fluides. Nage en parapluie (les bras s'ouvrent puis se referment
   en poussée, la pointe traîne) ; pirouette « tutu » toutes les 14 s hors portage : rotation sur l'axe, corolle puis parapluie,
   poils enroulés en hélice autour des bras puis déroulés ; micro-bulles qui se détachent à la poussée et en pirouette.
   Même physique qu'avant (crPos, nage à la rencontre st.eox/eoy, portage, dépose avec plongée) : rendu seul. */
function poil(ctx, x0, y0, nx, ny, L, dx, dy, w) {   // R481 : base, normale, longueur, dérive (traînée + courant), ondulation
  const tx = -ny, ty = nx;
  ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 + nx * L * .55 + tx * w * .5 + dx * .35, y0 + ny * L * .55 + ty * w * .5 + dy * .35, x0 + nx * L + tx * w + dx, y0 + ny * L + ty * w + dy);
}
const ARACHNE = (function () {   // R483 · même code que /tmp/proto-arachne/arachne.html
  const TAU = Math.PI * 2;
  const NB = 8;            // bras
  const NS = 10;           // segments par bras
  const HB = 3;            // poils par bras
  const HS = 11;            // points par poil
  const NF = 5;            // filaments longs du corps
  const FS = 14;           // points par filament
  // Palette froide (alignée sur qxcrea : perle, aqua, lilas, menthe)
  const C = {
    bras: '150,196,255', lis: '196,232,255', poil: '168,246,228', fil: '200,214,255',
    corps: '190,184,255', noyau: '226,246,255', aile: '176,170,250', veine: '214,236,255'
  };
  const cl = (v, a, b) => (v < a ? a : v > b ? b : v);
  const ss = (a, b, v) => { const x = cl((v - a) / (b - a), 0, 1); return x * x * (3 - 2 * x); };
  const mix = (a, b, k) => a + (b - a) * k;
  const fract = v => v - Math.floor(v);

  // Irrégularité déterministe par bras (mulberry32)
  function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const jeux = {};
  function jeu(seed) {
    if (jeux[seed]) return jeux[seed];
    const r = rng(seed * 7919 + 13), A = [];
    for (let i = 0; i < NB; i++) A.push({ dphi: (r() - .5) * .22, lon: .9 + r() * .2, ph: (r() - .5) * .16, curl: (r() - .5) * .25, ondu: r() * TAU, hp: r() * TAU });
    const F = [];
    for (let k = 0; k < NF; k++) F.push({ a: k / NF * TAU + r() * .5, lon: .85 + r() * .35, ph: r() * TAU });
    return (jeux[seed] = { A, F });
  }

  // Sprite de lueur (une seule fois) : pas de gradient par élément
  let lueur = null;
  function sprite() {
    if (lueur) return lueur;
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(236,250,255,1)'); gr.addColorStop(.25, 'rgba(150,232,255,.55)');
    gr.addColorStop(.6, 'rgba(120,170,255,.14)'); gr.addColorStop(1, 'rgba(120,170,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return (lueur = c);
  }

  /* ---------- Pirouette : courbes-clés en fonction de u ∈ [0,1] ---------- */
  // angle polaire de la racine (0 = bras vers le bas / parapluie fermé, π/2 = corolle horizontale)
  const KT = [[0, .55], [.12, .42], [.38, 1.78], [.52, 1.82], [.74, .2], [.88, .28], [1, .62]];
  const KL = [[0, 1], [.12, .95], [.38, 1.1], [.52, 1.12], [.74, 1.3], [.9, 1.15], [1, 1]];
  const KC = [[0, -.1], [.12, -.1], [.38, .12], [.52, .05], [.74, -.42], [.9, -.25], [1, -.1]];
  function cle(K, u) {
    if (u <= K[0][0]) return K[0][1];
    for (let i = 1; i < K.length; i++) if (u <= K[i][0]) { const a = K[i - 1], b = K[i]; return mix(a[1], b[1], ss(0, 1, (u - a[0]) / (b[0] - a[0]))); }
    return K[K.length - 1][1];
  }
  // Angle de rotation tabulé : vitesse ∝ poussée / inertie (plus rapide repliée = patineuse)
  const TABN = 256, TOUR = 2 * TAU;
  const TAB = new Float32Array(TABN + 1), VIT = new Float32Array(TABN + 1);
  (function () {
    let acc = 0, vmax = 0; const v = [];
    for (let i = 0; i <= TABN; i++) {
      const u = i / TABN, th = cle(KT, u), L = cle(KL, u);
      const I = .25 + Math.pow(Math.sin(th) * L, 2);
      v.push(Math.pow(Math.sin(Math.PI * u), 1.6) / I);
    }
    for (let i = 0; i <= TABN; i++) { TAB[i] = acc; acc += v[i]; vmax = Math.max(vmax, v[i]); }
    for (let i = 0; i <= TABN; i++) { TAB[i] *= TOUR / acc; VIT[i] = v[i] / vmax; }
  })();
  const tab = (T, u) => { const x = cl(u, 0, 1) * TABN, i = Math.floor(x), k = x - i; return i >= TABN ? T[TABN] : mix(T[i], T[i + 1], k); };

  /* ---------- Pulsation (nage en parapluie) ---------- */
  const TH_C = .5, TH_O = 1.66;
  function pulse(p) { // p : phase 0..1 → angle racine
    p = fract(p);
    if (p < .6) { const x = p / .6; return TH_C + (TH_O - TH_C) * (1 - Math.pow(1 - x, 2.2)); }  // ouverture lente
    const x = (p - .6) / .4; return TH_O - (TH_O - TH_C) * ss(0, 1, x);                         // poussée
  }

  /* ---------- État global à l'instant t ---------- */
  function etat(t, o) {
    const P = o.periode || 2.4, cyc = o.cycle || 14, dur = o.duree || 3.6;
    const tc = ((t - (o.decal == null ? 6 : o.decal)) % cyc + cyc) % cyc;
    const u = tc / dur;                               // >1 après la pirouette
    const E = ss(0, .12, u) * (1 - ss(.86, 1.08, u));  // poids de la pirouette sur la forme
    const W = ss(.12, .4, u) * (1 - ss(.8, 1.2, u));   // enroulement des poils (déroulé après)
    const nb = Math.floor((t - (o.decal == null ? 6 : o.decal)) / cyc), sp = o.spin == null ? 1 : o.spin;
    return {
      t, P, u, E: E * sp, W: W * sp,
      rot: o.rot != null ? o.rot : nb * TOUR + tab(TAB, u) + t * .05,  // nb*TOUR : continuité visuelle (2 tours entiers)
      vit: (u <= 1 ? tab(VIT, u) : 0) * sp
    };
  }

  // tampons réutilisés
  const TP15 = new Float32Array(NS + 1), TP14 = new Float32Array(NS + 1), TSS = new Float32Array(NS + 1), TSS2 = new Float32Array(NS + 1);
  for (let j = 0; j <= NS; j++) { const s = j / NS; TP15[j] = Math.pow(s, 1.5); TP14[j] = Math.pow(s, 1.4); TSS[j] = ss(.22, .5, s); TSS2[j] = s * s * 1.6; }
  const P3 = []; for (let i = 0; i < NB; i++) P3.push(new Float32Array((NS + 1) * 3));
  const SX = []; for (let i = 0; i < NB; i++) SX.push(new Float32Array((NS + 1) * 3)); // x, y, f
  const BX = new Float32Array(24), BY = new Float32Array(24);
  function lisse(X, Y, n) {   // tracé lissé par les milieux (quadratiques), ajouté au path courant
    ctx_.moveTo(X[0], Y[0]);
    for (let m = 1; m < n; m++) ctx_.quadraticCurveTo(X[m], Y[m], (X[m] + X[m + 1]) / 2, (Y[m] + Y[m + 1]) / 2);
    ctx_.lineTo(X[n], Y[n]);
  }
  let ctx_ = null;
  const ord = new Array(NB), prof = new Float32Array(NB), L = new Float32Array((NS + 1) * 2), R = new Float32Array((NS + 1) * 2);

  function draw(ctx, t, x, y, scale, opts) {
    ctx_ = ctx;
    const o = opts || {}, J = jeu(o.seed || 1), S = etat(t, o), A0 = o.alpha == null ? 1 : o.alpha, sr = o.serre || 0;
    const hd = o.heading || 0, ch = Math.cos(hd), sh = Math.sin(hd);
    const pit = o.pitch == null ? .5 : o.pitch, cp = Math.cos(pit), sp = Math.sin(pit), D = 4.2;
    // respiration du corps
    const ph = fract(t / S.P), pou = ph > .6 ? Math.sin(Math.PI * (ph - .6) / .4) : 0;
    // projection : creature (X,Y,Z) → écran ; renvoie dans out[k..k+2]
    function proj(X, Y, Z, out, k) {
      const X1 = X * ch - Y * sh, Y1 = X * sh + Y * ch;
      const Y2 = Y1 * cp - Z * sp, Z2 = Y1 * sp + Z * cp, f = D / (D - Z2);
      out[k] = x + X1 * f * scale; out[k + 1] = y - Y2 * f * scale; out[k + 2] = Z2; return f;
    }

    /* --- squelette des bras (3D) --- */
    const rootY = -.04, rootR = .07, ds = 1 / NS, kc = S.E > 0 ? cle(KC, S.u) : 0, kl = S.E > 0 ? cle(KL, S.u) : 1;
    for (let i = 0; i < NB; i++) {
      const a = J.A[i], p = P3[i], lon = a.lon * (S.E > 0 ? mix(1, kl, S.E) : 1);
      const phi0 = i / NB * TAU + a.dphi + S.rot;
      let X = Math.cos(phi0) * rootR, Y = rootY, Z = Math.sin(phi0) * rootR;
      p[0] = X; p[1] = Y; p[2] = Z;
      let zm = 0;
      for (let j = 1; j <= NS; j++) {
        const s = j / NS;
        // onde de phase : la pointe traîne (retard visco-élastique)
        const thP = pulse((t - .42 * s + a.ph) / S.P);
        const thS = S.E > 0 ? cle(KT, S.u - .07 * s) : 0;
        const curl = (S.E > 0 ? mix(-.12 + a.curl * .4 - .35 * pou, kc, S.E) : -.12 + a.curl * .4 - .35 * pou) + a.curl * .2;
        const th = mix(mix(thP, thS, S.E), .62, sr) + curl * TSS2[j]
          - mix(.62, .18, S.E) * Math.sin(thP) * TSS[j]   // coude doux : le bras part à plat puis plonge
          + (S.E > 0 ? S.E * Math.sin(Math.PI * cl(S.u * 1.6, 0, 1)) * .32 * s * Math.sin(3.4 * Math.PI * s - S.rot * 1.5 + i * 1.9) : 0);   // ourlet ondulant du tutu
        // traînée azimutale pendant la rotation + petite ondulation latérale
        const phi = phi0 - 2.1 * S.vit * TP14[j] + .09 * s * Math.sin(TAU * t / S.P - 3.2 * s + a.ondu);
        const st = Math.sin(th), Lg = lon * ds * 1.1;
        X += st * Math.cos(phi) * Lg; Y -= Math.cos(th) * Lg; Z += st * Math.sin(phi) * Lg;
        p[j * 3] = X; p[j * 3 + 1] = Y; p[j * 3 + 2] = Z;
      }
      const sx = SX[i];
      for (let j = 0; j <= NS; j++) { proj(p[j * 3], p[j * 3 + 1], p[j * 3 + 2], sx, j * 3); zm += sx[j * 3 + 2]; }
      prof[i] = zm / (NS + 1); ord[i] = i;
    }
    ord.sort((a, b) => prof[a] - prof[b]);

    const WMAX = .046 * scale;
    function bras(i) {
      const sx = SX[i];
      for (let j = 0; j <= NS; j++) {
        const s = j / NS, a = Math.max(j - 1, 0) * 3, b = Math.min(j + 1, NS) * 3;
        let tx = sx[b] - sx[a], ty = sx[b + 1] - sx[a + 1]; const n = Math.hypot(tx, ty) || 1; tx /= n; ty /= n;
        const f = D / (D - sx[j * 3 + 2]);
        const w = WMAX * f * (1 - Math.pow(s, 1.25)) * (.45 + .55 * ss(0, .22, s)) * (1 + .12 * Math.sin(s * 9 - t * 2 + i));
        L[j * 2] = sx[j * 3] - ty * w; L[j * 2 + 1] = sx[j * 3 + 1] + tx * w; R[j * 2] = sx[j * 3] + ty * w; R[j * 2 + 1] = sx[j * 3 + 1] - tx * w;
      }
      ctx.moveTo(L[0], L[1]);
      for (let j = 1; j < NS; j++) ctx.quadraticCurveTo(L[j * 2], L[j * 2 + 1], (L[j * 2] + L[j * 2 + 2]) / 2, (L[j * 2 + 1] + L[j * 2 + 3]) / 2);
      ctx.lineTo(sx[NS * 3], sx[NS * 3 + 1]);
      for (let j = NS - 1; j > 0; j--) ctx.quadraticCurveTo(R[j * 2], R[j * 2 + 1], (R[j * 2] + R[j * 2 - 2]) / 2, (R[j * 2 + 1] + R[j * 2 - 1]) / 2);
      ctx.lineTo(R[0], R[1]); ctx.closePath();
    }
    function groupe(k0, k1, da, lis) {
      ctx.beginPath();
      for (let k = k0; k < k1; k++) bras(ord[k]);
      ctx.globalAlpha = (lis ? .22 : .3) * da; ctx.fillStyle = 'rgb(' + C.bras + ')'; ctx.fill();
      if (!lis) return;
      ctx.globalAlpha = .66 * da; ctx.strokeStyle = 'rgb(' + C.lis + ')'; ctx.lineWidth = Math.max(.8, scale * .012); ctx.stroke();
    }

    // point sur un bras (3D) à l'abscisse s (prolongé au-delà de la pointe)
    const tmp = [0, 0, 0];
    function surBras(i, s, out) {
      const p = P3[i], x2 = s * NS; let j = Math.floor(x2); if (j >= NS) j = NS - 1; if (j < 0) j = 0;
      const k = x2 - j;
      out[0] = p[j * 3] + (p[j * 3 + 3] - p[j * 3]) * k; out[1] = p[j * 3 + 1] + (p[j * 3 + 4] - p[j * 3 + 1]) * k; out[2] = p[j * 3 + 2] + (p[j * 3 + 5] - p[j * 3 + 2]) * k;
      const tx = p[j * 3 + 3] - p[j * 3], ty = p[j * 3 + 4] - p[j * 3 + 1], tz = p[j * 3 + 5] - p[j * 3 + 2], n = Math.hypot(tx, ty, tz) || 1;
      out[3] = tx / n; out[4] = ty / n; out[5] = tz / n;
    }

    /* --- 1. bras de derrière --- */
    const moitie = NB >> 1;
    groupe(0, moitie, .55 * A0, false);

    /* --- 2. jupe-membrane (tutu / parapluie) entre les racines --- */
    {
      const sj = .3, pts = [], q = [0, 0, 0, 0, 0, 0], c = [0, 0, 0];
      proj(0, rootY, 0, c, 0);
      const az = [];
      for (let i = 0; i < NB; i++) { surBras(i, sj, q); const r = [0, 0, 0]; proj(q[0], q[1], q[2], r, 0); pts.push(r); az.push(i); }
      ctx.beginPath();
      for (let k = 0; k <= NB; k++) {
        const a = pts[k % NB], b = pts[(k + 1) % NB];
        if (k === 0) ctx.moveTo(a[0], a[1]);
        else { const pr = pts[(k - 1) % NB]; const mx = (pr[0] + a[0]) / 2, my = (pr[1] + a[1]) / 2; ctx.quadraticCurveTo(mix(mx, c[0], .38), mix(my, c[1], .38), a[0], a[1]); }
      }
      ctx.closePath();
      ctx.globalAlpha = .3 * A0; ctx.strokeStyle = 'rgb(' + C.lis + ')'; ctx.lineWidth = Math.max(.7, scale * .009); ctx.stroke();
    }

    /* --- 3. poils fluides (un seul path, un seul stroke) --- */
    {
      const q = [0, 0, 0, 0, 0, 0], r = [0, 0, 0], W = S.W, ouv = S.E > 0 || W > 0 ? Math.sin(cle(KT, S.u)) : 1, hs = W > .02 ? HS : 4, fs = W > .02 ? FS : 5, PX = BX, PY = BY, tours = mix(.9, 1.6, S.E > 0 ? ouv : 1);
      ctx.beginPath();
      for (let i = 0; i < NB; i++) {
        const a = J.A[i];
        for (let h = 0; h < HB; h++) {
          const sb = .3 + h * .24, Lh = (.36 + .09 * Math.sin(a.hp + h * 2.1)) * (1 + .35 * W);
          surBras(i, sb, q);
          const bx = q[0], by = q[1], bz = q[2], tx = q[3], ty = q[4], tz = q[5];
          // repère normal au bras (pour l'hélice)
          let n1x = ty * 0 - tz * 1, n1y = 0, n1z = tx * 1 - ty * 0; // T × Y
          let nn = Math.hypot(n1x, n1z); if (nn < 1e-3) { n1x = 1; n1z = 0; nn = 1; } n1x /= nn; n1z /= nn;
          const n2x = ty * n1z - tz * n1y, n2y = tz * n1x - tx * n1z, n2z = tx * n1y - ty * n1x;
          // repos : traîne dans le courant (vers l'arrière = bas) + ondulation
          let X = bx, Y = by, Z = bz, dx = tx * .55, dy = ty * .55 - .6, dz = tz * .55;
          for (let m = 0; m <= hs; m++) {
            const u = m / hs;
            let hx, hy, hz;
            if (m > 0 && W < .97) {
              const w = .55 * Math.sin(t * 1.7 - u * 5 + a.hp + h) * u;
              const ex = dx + w * n1x, ey = dy, ez = dz + w * n1z, en = Math.hypot(ex, ey, ez) || 1, st = Lh / hs;
              X += ex / en * st; Y += ey / en * st; Z += ez / en * st;
            }
            hx = X; hy = Y; hz = Z;
            if (W > 0) {
              // hélice autour du bras, de la base vers la pointe et au-delà
              surBras(i, sb + u * (1 - sb), q);
              const ps = a.hp + h * 1.7 + TAU * tours * W * u + S.rot * .5, R = (.025 + .04 * Math.sin(Math.PI * Math.min(u * 1.2, 1) * .5 + .3)) * (.4 + .6 * W) * (.45 + .55 * ouv);
              const cs = Math.cos(ps) * R, sn = Math.sin(ps) * R;
              const ox = q[0] + cs * n1x + sn * n2x, oy = q[1] + cs * n1y + sn * n2y, oz = q[2] + cs * n1z + sn * n2z;
              const k = W * ss(0, .25, u + .05);
              hx = mix(hx, ox, k); hy = mix(hy, oy, k); hz = mix(hz, oz, k);
            }
            proj(hx, hy, hz, r, 0); PX[m] = r[0]; PY[m] = r[1];
          }
          lisse(PX, PY, hs);
        }
      }
      // longs filaments du corps : traînent dessous, s'enroulent en spirale autour d'elle pendant la pirouette
      for (let k = 0; k < NF; k++) {
        const f = J.F[k], Lf = (.72 + .2 * W) * f.lon;
        for (let m = 0; m <= fs; m++) {
          const u = m / fs;
          const wav = .16 * u * Math.sin(t * 1.4 - u * 4.5 + f.ph);
          let ax = Math.cos(f.a) * (.05 + .12 * u) + wav * Math.cos(f.a + 1.57);
          let az2 = Math.sin(f.a) * (.05 + .12 * u) + wav * Math.sin(f.a + 1.57);
          let ay = -.12 - u * Lf;
          if (S.W > 0) {
            const ou = ouv;   // ouverture de la corolle : spirale large ouverte, serrée repliée
            const ang = f.a + S.rot * .92 - TAU * (.6 + .35 * fract(f.ph)) * S.W * u, rr = .08 + u * (.22 + .4 * ou) * f.lon;
            const sy = -.12 - u * Lf * (.3 + .45 * (1 - ou)) + .1 * Math.sin(Math.PI * u);
            const k2 = S.W * ss(0, .15, u);
            ax = mix(ax, Math.cos(ang) * rr, k2); az2 = mix(az2, Math.sin(ang) * rr, k2); ay = mix(ay, sy, k2);
          }
          proj(ax, ay, az2, r, 0); PX[m] = r[0]; PY[m] = r[1];
        }
        lisse(PX, PY, fs);
      }
      ctx.globalAlpha = (.34 + .22 * W) * A0; ctx.strokeStyle = 'rgb(' + C.poil + ')';
      ctx.lineWidth = Math.max(1, scale * .011); ctx.lineJoin = 'round'; ctx.stroke();
    }

    /* --- 4. corps, nageoires, noyau --- */
    {
      const a = [0, 0, 0], b = [0, 0, 0];
      const lb = 1 + .07 * pou;
      proj(0, .24 * lb, 0, a, 0); proj(0, -.12, 0, b, 0);
      let ax = a[0] - b[0], ay = a[1] - b[1]; const L = Math.hypot(ax, ay) || 1; const ux = ax / L, uy = ay / L, nx = -uy, ny = ux;
      const w = .075 * scale / lb;
      // nageoires (clione) : deux voiles fines à mi-corps, rabattues vers l'arrière, battent avec la pulsation
      const flap = .8 + .3 * Math.sin(TAU * t / S.P + 1.2), sc = scale;
      const fx = mix(b[0], a[0], .42), fy = mix(b[1], a[1], .42);
      ctx.beginPath();
      const ven = [];
      for (const sg of [-1, 1]) {
        const bx = fx + nx * w * .5 * sg, by = fy + ny * w * .5 * sg, ond = .025 * Math.sin(t * 2.3 + sg);
        const ox = nx * sg * flap, oy = ny * sg * flap;
        const tx = bx + ox * .27 * sc - ux * .13 * sc, ty = by + oy * .27 * sc - uy * .13 * sc;
        ctx.moveTo(bx + ux * .06 * sc, by + uy * .06 * sc);
        ctx.bezierCurveTo(bx + ox * .1 * sc + ux * .1 * sc, by + oy * .1 * sc + uy * .1 * sc, bx + ox * .24 * sc + ux * .03 * sc, by + oy * .24 * sc + uy * .03 * sc, tx, ty);
        ctx.bezierCurveTo(bx + ox * (.2 + ond) * sc - ux * .14 * sc, by + oy * (.2 + ond) * sc - uy * .14 * sc, bx + ox * .07 * sc - ux * (.05 - ond) * sc, by + oy * .07 * sc - uy * (.05 - ond) * sc, bx - ux * .05 * sc, by - uy * .05 * sc);
        ctx.closePath();
        ven.push([bx, by, ox, oy]);
      }
      // nervures (un path)
      for (const v of ven) for (let k = 0; k < 3; k++) {
        const e = .14 + k * .055, d = .02 - k * .055;
        ctx.moveTo(v[0], v[1]);
        ctx.quadraticCurveTo(v[0] + v[2] * e * .6 * sc + ux * d * .3 * sc, v[1] + v[3] * e * .6 * sc + uy * d * .3 * sc,
          v[0] + v[2] * e * sc + ux * d * sc - ux * .04 * sc, v[1] + v[3] * e * sc + uy * d * sc - uy * .04 * sc);
      }
      // corps en fuseau (même path que les nageoires et nervures)
      ctx.moveTo(a[0], a[1]);
      ctx.bezierCurveTo(a[0] + nx * w * .35, a[1] + ny * w * .35, b[0] + nx * w * 1.5, b[1] + ny * w * 1.5, b[0], b[1]);
      ctx.bezierCurveTo(b[0] - nx * w * 1.5, b[1] - ny * w * 1.5, a[0] - nx * w * .35, a[1] - ny * w * .35, a[0], a[1]);
      ctx.globalAlpha = .26 * A0; ctx.fillStyle = 'rgb(' + C.corps + ')'; ctx.fill();
      ctx.globalAlpha = .7 * A0; ctx.strokeStyle = 'rgb(' + C.lis + ')'; ctx.lineWidth = Math.max(.8, scale * .011); ctx.stroke();
      // noyau bioluminescent (pulse avec la poussée)
      const nk = .45 + .55 * pou, mx = mix(b[0], a[0], .3), my = mix(b[1], a[1], .3);
      const g = sprite(), rg = scale * (.2 + .08 * nk);
      ctx.globalAlpha = (.35 + .4 * nk) * A0; ctx.drawImage(g, mx - rg, my - rg, rg * 2, rg * 2);
      ctx.beginPath(); ctx.ellipse(mx, my, w * .22, w * .9, Math.atan2(uy, ux) + Math.PI / 2, 0, TAU);
      ctx.globalAlpha = (.35 + .3 * nk) * A0; ctx.fillStyle = 'rgb(' + C.noyau + ')'; ctx.fill();
    }

    /* --- 5. bras de devant --- */
    groupe(moitie, NB, A0, true);

    /* --- 5b. micro-bulles : se détachent des bras à la poussée et surtout pendant la pirouette,
           montent lentement avec une dérive douce et s'éteignent (sans état : chaque bulle renaît à date fixe) --- */
    {
      const NBU = 12, VIE = 2.3, r = [0, 0, 0], oB = o.rot != null ? { periode: o.periode, cycle: o.cycle, duree: o.duree, decal: o.decal, spin: o.spin } : o;
      ctx.beginPath();
      for (let k = 0; k < NBU; k++) {
        const off = fract(k * .618034) * VIE, n = Math.floor((t - off) / VIE), tb = n * VIE + off, age = (t - tb) / VIE;
        const h = fract(Math.sin((k + 1) * 12.9898 + n * 78.233) * 43758.5453);
        const pb = fract(tb / S.P), p0 = .12 + .5 * (pb > .6 ? 1 : 0);   // plus nombreuses à la poussée et en pirouette
        if (h > p0 + .9) continue;
        const Sb = etat(tb, oB);
        if (h > p0 + .9 * Sb.E) continue;
        const a2 = J.A[k % NB], phi = (k % NB) / NB * TAU + a2.dphi + Sb.rot - 1.2 * Sb.vit;
        const th = mix(pulse((tb + a2.ph) / S.P), cle(KT, Sb.u), Sb.E), sl = .45 + .5 * fract(h * 7.31);
        const lon = sl * 1.1 * a2.lon * mix(1, cle(KL, Sb.u), Sb.E);
        const dr = .12 * Math.sin(age * 3 + k) * age;
        const X = Math.sin(th) * Math.cos(phi) * lon + dr, Y = -.04 - Math.cos(th) * lon * .8 + age * .55, Z = Math.sin(th) * Math.sin(phi) * lon;
        proj(X, Y, Z, r, 0);
        if (o.trace) { const dd = o.trace(tb); r[0] -= dd[0]; r[1] -= dd[1]; }
        const rb = (.5 + .7 * fract(h * 3.7)) * (scale / 60) * (1 - .4 * age);
        ctx.moveTo(r[0] + rb, r[1]); ctx.arc(r[0], r[1], rb, 0, TAU);
      }
      ctx.globalAlpha = .42 * A0; ctx.strokeStyle = 'rgb(' + C.lis + ')'; ctx.lineWidth = Math.max(.6, scale * .008); ctx.stroke();
    }

    /* --- 6. lueurs qui voyagent le long des bras après chaque poussée --- */
    {
      const g = sprite(), q = [0, 0, 0, 0, 0, 0], r = [0, 0, 0];
      for (let k = NB - 2; k < NB; k++) {
        const i = ord[k], sl = fract((t + J.A[i].ph) / S.P - .62) * 1.6;
        if (sl > 1) continue;
        surBras(i, sl, q); proj(q[0], q[1], q[2], r, 0);
        const rr = scale * .13 * (1 - sl * .5);
        ctx.globalAlpha = .55 * Math.sin(Math.PI * sl) * A0;
        ctx.drawImage(g, r[0] - rr, r[1] - rr, rr * 2, rr * 2);
      }
    }
    ctx.globalAlpha = 1;
  }

  return { draw, etat };
})();
const ECH_SC = 52;   // unités de niveau par longueur de bras : ~112 px au repos, corolle ≤ ~150 px sur iPhone
function dessinerEchasse(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, FL = racine.FLUID;
  let kn = 0;
  if (run && st.h && st.k) { const z = Math.min(1, (fr - st.k) / (c.kd || 24)); kn = z * z * (3 - 2 * z); }
  else if (run && st.out && fr >= st.out && fr - st.out < 36) { const z = 1 - (fr - st.out) / 36; kn = z * z * (3 - 2 * z); }
  const drop = c.drop == null ? 12 : c.drop, bob = (1.6 * Math.sin(e.tl * .8 + e.ph) + 1 * Math.sin(e.tl * 1.9)) * (1 - kn) * (st.h && run ? .25 : 1);
  const bx = x + (run ? st.eox || 0 : 0), by = y + (run ? st.eoy || 0 : 0) + kn * drop + bob;   // R482 : elle nage à la rencontre de la bille
  // orientation selon la vitesse (lissée) : la tête penche vers où elle va ; plonge en avant à la dépose
  const vx = e.pbx == null || !run ? 0 : bx - e.pbx; e.pbx = bx;
  e.evx = e.evx == null ? vx : e.evx + (vx - e.evx) * Math.min(1, dt * 2.5);
  const hd = Math.max(-.5, Math.min(.5, -e.evx * 1.1)) - (st.dir || 0) * .35 * kn;
  // pirouette : horloge S.frames en jeu, jamais pendant un portage ni juste après la dépose (fondu, rotation cumulée sans saut)
  const tA = run ? fr / 60 : T, dec = 9 - 4.1 * e.i, ok = !(run && (st.h || (st.out && fr - st.out < 40 && fr >= st.out)));
  e.spk = e.spk == null ? (ok ? 1 : 0) : e.spk + ((ok ? 1 : 0) - e.spk) * Math.min(1, dt * 3);
  const r0 = ARACHNE.etat(tA, { decal: dec }).rot;
  e.rA = e.rA == null ? r0 : e.rA + (e.rP == null ? 0 : crWrapA(r0 - e.rP)) * e.spk; e.rP = r0;
  e.ser = (e.ser || 0) + ((run && st.h ? 1 : 0) - (e.ser || 0)) * Math.min(1, dt * 4);
  ombre(ctx, e, bx, by + 30, 30, 10, 0, .35);
  const o = e.AO || (e.AO = { decal: 0, heading: 0, alpha: 1, spin: 1, rot: 0, serre: 0, seed: 1, trace: null });
  o.decal = dec; o.heading = hd; o.alpha = .8 + .2 * (e.al || 1); o.spin = e.spk; o.rot = e.rA; o.serre = e.ser * .8; o.seed = 1 + e.i;
  if (run) { const q1 = FL.crPos(c, fr), dd = e.TD || (e.TD = [0, 0]); o.trace = tb => { const q0 = FL.crPos(c, Math.round(tb * 60)); dd[0] = q1[0] - q0[0]; dd[1] = q1[1] - q0[1]; return dd; }; } else o.trace = null;
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ARACHNE.draw(ctx, tA, bx, by, ECH_SC, o);
  ctx.restore();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  /* passagers : petits isopodes translucides, discrets, posés à la naissance des bras ; sauts vers une voisine de l'étage, puis retour */
  const vois = act.E.filter(o => o !== e && (o.c.t === 'leurre' || o.c.t === 'echasse') && o.lx != null);
  const tc = run ? fr / 60 : T, PS = e.PS || (e.PS = sprite('echassep', TEINTE.echasse.ac, 'p'));
  ctx.beginPath(); const PSX = e.psx || (e.psx = new Float32Array(3)), PSY = e.psy || (e.psy = new Float32Array(3)), PSW = e.psw || (e.psw = new Float32Array(3));
  for (let j = 0; j < 3; j++) {
    const xl = [-15, 1, 14][j], hx0 = bx + xl, hy0 = by - 3 + 1.2 * Math.sin(e.tl * 1.3 + j);
    let px = hx0, py = hy0;
    if (st.h && run && j === 0 && b) { px = b.x - 7; py = b.y - 5; }
    const C = 15, cu = (tc + j * 5.1 + e.i * 2.3) % C, o = vois.length ? vois[j % vois.length] : null;
    const tx = o ? (o.c.t === 'leurre' ? o.hx : o.lx) : null, ty = o ? (o.c.t === 'leurre' ? o.hy - 3 : o.ly - 4) : null;
    if (j < 2 && tx != null) {
      if (cu < 1.3) { const v = cu / 1.3, vv = v * v * (3 - 2 * v); px = px + (tx - px) * vv; py = py + (ty - py) * vv - 26 * Math.sin(Math.PI * v); }
      else if (cu < 7) { px = tx; py = ty; }
      else if (cu < 8.3) { const v = (cu - 7) / 1.3, vv = v * v * (3 - 2 * v); px = tx + (px - tx) * vv; py = ty + (py - ty) * vv - 26 * Math.sin(Math.PI * v); }
    }
    const pw = Math.sin(T * 2 + j * 2), ro = .3 * Math.sin(T * .7 + j) + (j - 1) * .3, cr = Math.cos(ro), sr = Math.sin(ro);
    const Pq = (uu, vv) => [px + uu * cr - vv * sr, py + uu * sr + vv * cr];
    let a = Pq(3, .4), z; ctx.moveTo(a[0], a[1]);
    a = Pq(2.4, -2.2 - .2 * pw); z = Pq(-1, -2); ctx.quadraticCurveTo(a[0], a[1], z[0], z[1]);
    a = Pq(-3.4, -1.6); z = Pq(-3.2, .5); ctx.quadraticCurveTo(a[0], a[1], z[0], z[1]);
    a = Pq(-2.4, 1.6); z = Pq(0, 1.3); ctx.quadraticCurveTo(a[0], a[1], z[0], z[1]);
    a = Pq(2.4, 1.4); ctx.quadraticCurveTo(a[0], a[1], Pq(3, .4)[0], Pq(3, .4)[1]);
    PSX[j] = Pq(.6, -.3)[0]; PSY[j] = Pq(.6, -.3)[1]; PSW[j] = pw;
  }
  ctx.fillStyle = e.KA; ctx.globalAlpha = .14; ctx.fill(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .3; ctx.lineWidth = .45; ctx.stroke();
  ctx.restore();
  e.lx = bx; e.ly = by;
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
function crWrapA(a) { while (a > Math.PI) a -= TAU; while (a < -Math.PI) a += TAU; return a; }
/* SILLAGE-LANGAGE (effet de particule de l'étage 3) : perles qui clignotent selon le mot de la créature, puis s'éteignent */
const LGK = { cortege: 0, braise: 1, leurre: 2, echasse: 3 };
function langage(ctx, dt, b, fr, run, lv) {
  const L = act.lang || (act.lang = { x: new Float32Array(64), y: new Float32Array(64), a: new Float32Array(64), k: new Uint8Array(64), q: new Uint8Array(64), n: 0, i: 0, f0: -1 });
  if (!run || fr <= 1) { if (fr <= 1) L.n = 0; }
  let src = null;
  if (run && b) {
    if (b.brz > fr) src = 'braise';
    for (const e of act.E) if (e.c.t === 'cortege') { const st = (b.cs && b.cs[e.i]) || {}; if (st.h || (st.out && fr - st.out < 70 && fr >= st.out)) src = 'cortege'; }
    for (const e of act.E) if (e.c.t === 'leurre' || e.c.t === 'echasse') { const st = (b.cs && b.cs[e.i]) || {}; if (st.h || (st.out && fr - st.out < 70 && fr >= st.out)) src = e.c.t; }   // R480 : givre-langage
    if (src && fr !== L.f0 && fr % 3 === 0) { L.f0 = fr; const j = L.n < 64 ? L.n++ : (L.i = (L.i + 1) % 64); L.x[j] = b.x + (LGK[src] > 1 ? (hs(fr) - .5) * 8 : 0); L.y[j] = b.y; L.a[j] = 0; L.k[j] = LGK[src]; L.q[j] = (fr / 3) % 3; }
  }
  for (let j = 0; j < L.n; j++) { const k = L.k[j]; L.a[j] += dt; if (k === 1) { L.y[j] -= dt * 9 * (1 + L.a[j]); L.x[j] += Math.sin(L.a[j] * 5 + j) * dt * 4; } else if (k > 1) { L.y[j] += dt * 5; L.x[j] += Math.sin(L.a[j] * 1.7 + j) * dt * 2.5; } }   // le givre descend lentement en se balançant
  const G0 = TEINTE.cortege, G1 = TEINTE.braise;
  const s0 = sprite('cortegea', G0.ac, 'p'), s1 = sprite('braise', G1.c1, 'p'), g0 = sprite('cortege', G0.c1, 'g'), g1 = sprite('braise', G1.c1, 'g');
  const GS = [s0, s1, sprite('givrel', TEINTE.leurre.c2, 'x'), sprite('givree', TEINTE.echasse.c2, 'x')], GG = [g0, g1, sprite('leurrea', TEINTE.leurre.ac, 'g'), sprite('echassea', TEINTE.echasse.ac, 'g')], GM = ['cortege', 'braise', 'leurre', 'echasse'];
  ctx.globalCompositeOperation = 'lighter';
  for (let j = 0; j < L.n; j++) {
    const k = L.k[j], a = L.a[j], vie = k === 1 ? 1.3 : k > 1 ? 2.4 : 1.8; if (a > vie) continue;
    const m = MOT[GM[k]], ph = (a * 1.25 + m[L.q[j]] * 3) % 1, on = ph < .18 ? 1 : ph < .3 ? .45 : .12, env = Math.sin(Math.PI * Math.min(1, a / vie)) * (1 - a / vie * .4);
    spr(ctx, GS[k], L.x[j], L.y[j], (k === 1 ? 1.6 : k > 1 ? 3.4 - j % 3 * .5 : 1.9) * (1 - a / vie * .5), env * (k > 1 ? .25 + .75 * on : on));
    if (on > .9) spr(ctx, GG[k], L.x[j], L.y[j], 6, env * .22);
  }
  if (src && b) { const k = LGK[src]; spr(ctx, GG[k], b.x, b.y, 13 + 2 * Math.sin(act.t * 7), .3); if (k > 1) spr(ctx, GS[k], b.x, b.y, 7.5 + .8 * Math.sin(act.t * 2), .32); }   // la particule elle-même luit (étage 4 : elle se couvre de givre)
  ctx.globalCompositeOperation = 'source-over';
}
/* DIALOGUE DE LUMIÈRE : chaque créature de l'étage 3 « parle » à intervalle régulier (horloge = S.frames en jeu, sinon temps de rendu) ;
   son mot (trois perles, rythme propre) vole en arc vers une voisine — l'autre créature de l'étage, une créature active d'un autre étage,
   ou tour à tour les figurants du décor — qui s'éclaire en réponse puis répond à son tour. Aucune flèche : des perles et un fil qui s'efface. */
function dialogue(ctx, dt, fr, run) {
  const L3 = act.E.filter(e => MOT[e.c.t]); if (!L3.length) return;   // R480 : l'étage 4 parle aussi
  const tc = run ? fr / 60 : act.t, PER = 6.4;
  ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
  for (const e of L3) {
    const off = e.i * PER / 2 + 1.1, cyc = Math.floor((tc + off) / PER), u = ((tc + off) % PER) / PER;
    if (u > .3) { e.parle = 0; continue; }
    /* l'interlocuteur */
    let tx = null, ty = null, tgt = null, dec = null;
    const autres = act.E.filter(o => o !== e);
    if (autres.length) { tgt = autres[cyc % autres.length]; tx = tgt.lx != null ? tgt.lx : racine.FLUID.crPos(tgt.c, fr)[0]; ty = tgt.ly != null ? tgt.ly : racine.FLUID.crPos(tgt.c, fr)[1]; }
    else if (cur && cur.E.length) { const vis = cur.E.filter(o => o.ap > .05); if (vis.length) { dec = vis[cyc % vis.length]; tx = dec.x; ty = dec.y; } }
    if (tx == null || e.lx == null) continue;
    const s = u / .3, x0 = e.lx, y0 = e.ly, d = Math.hypot(tx - x0, ty - y0) || 1, bo = (cyc % 2 ? 1 : -1) * Math.min(70, d * .28);
    const mx = (x0 + tx) / 2 - (ty - y0) / d * bo, my = (y0 + ty) / 2 + (tx - x0) / d * bo;
    const P = (v) => { const m = 1 - v; return [m * m * x0 + 2 * v * m * mx + v * v * tx, m * m * y0 + 2 * v * m * my + v * v * ty]; };
    if (s < .04) e.fl = Math.max(e.fl || 0, .6);
    /* fil qui s'efface derrière le mot */
    ctx.beginPath(); for (let q = 0; q <= 12; q++) { const v = Math.max(0, s - .35) + q / 12 * Math.min(s, .35), p = P(Math.min(1, v)); q ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = .1 * (1 - s * .6); ctx.lineWidth = 1.6; ctx.stroke(); ctx.globalAlpha = .28 * (1 - s * .6); ctx.lineWidth = .45; ctx.stroke();
    const m = MOT[e.c.t];
    for (let q = 0; q < 3; q++) { const v = s - m[q] * .6; if (v < 0 || v > 1) continue; const p = P(v); spr(ctx, q ? e.SP : e.SA, p[0], p[1], q ? 1.5 : 2.1, .85 * Math.sin(Math.PI * Math.min(1, v * 1.05 + .02))); }
    if (s > .9) { const k = (s - .9) / .1;              // arrivée : la voisine s'éclaire et répond
      if (tgt) { tgt.fl = Math.max(tgt.fl || 0, .8 * k); spr(ctx, tgt.SAG, tx, ty, 10 + 8 * k, .3 * (1 - k * .5)); }
      if (dec) { dec.fl = Math.max(dec.fl, .8); dec.gon = Math.max(dec.gon, .5); } }
  }
  ctx.globalCompositeOperation = 'source-over';
}
function flotN(ctx) { ctx.beginPath(); ctx.moveTo(-1, .1); ctx.bezierCurveTo(-.7, -1.25, .75, -1.15, 1, -.15); ctx.bezierCurveTo(1.08, .85, -.75, 1.05, -1, .1); }
/* la particule dans sa bulle : film irisé fin qui tremble, s'amincit et crève (temps restant = minceur + tremblement) */
function dessinerBilleBulle(ctx, b, left, tot, T) {
  const x = b.x, y = b.y, f = Math.min(1, left / tot), G = TEINTE.bulle, K1 = rgb(G.c1), K2 = rgb(G.c2), KA = rgb(G.ac);
  const R = 16 + .8 * Math.sin(T * 3.1), tr = .04 + .1 * (1 - f) * (1 - f);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const path = (k) => { ctx.beginPath(); for (let j = 0; j <= 28; j++) { const a = j / 28 * TAU, rr = R * k * (1 + tr * Math.sin(2 * a + T * 5.3) + tr * .7 * Math.sin(3 * a - T * 7.1) + .03 * Math.sin(a - T * 2)) * (1 + .05 * Math.max(0, -Math.sin(a))); j ? ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * .96) : ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * .96); } ctx.closePath(); };
  path(1); ctx.fillStyle = K1; ctx.globalAlpha = .05 + .04 * f; ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  deuxTraits(ctx, K1, .32 + .4 * f, 2.6, .5 + .35 * f, .22);
  ctx.beginPath(); ctx.arc(x, y, R * .86, -2.6 + .2 * Math.sin(T), -1.35); ctx.strokeStyle = K2; ctx.globalAlpha = .45 * f + .15; ctx.lineWidth = .7; ctx.stroke();   // reflets (film de savon)
  ctx.beginPath(); ctx.arc(x, y, R * .9, .3 + .3 * Math.sin(T * 1.3), 1.25); ctx.strokeStyle = KA; ctx.globalAlpha = .3 * f + .1; ctx.lineWidth = .5; ctx.stroke();
  spr(ctx, sprite('bulle', G.c2, 'p'), x - R * .45, y - R * .5, 3.2, .55 + .3 * f);
  ctx.restore();
}
/* ───── R470 · FIGURANTS : une société décorative en arrière-plan ─────
   Des créatures plus petites, plus fines, très translucides, teintées par la brume du monde (lointain pâle et lent,
   médian, proche plus net), qui ne touchent à rien : elles vivent DERRIÈRE le jeu et derrière les créatures « réelles ».
   VIE SOCIALE : un metteur en scène (déterministe : graine du niveau + temps, aucun Math.random) enchaîne des HISTOIRES
   de 10 à 30 s sur 1 à 3 « scènes » simultanées, sans répéter les dernières :
     banc (volée en V qui se forme, voyage, se disperse en éclairs) · duo (couple qui danse, pulsations accordées)
     · parent (un petit suit, se distrait, est rappelé) · chasse (jeu de chat : touche, rôles inversés)
     · cour (courtisan, esquives, acceptation ou refus) · ronde (rassemblement autour d'une spore lumineuse)
     · sieste (grappe endormie, réveil en cascade) · conversation (impulsions de lumière relayées en chaîne)
     · migration (une file traverse tout l'écran, vague de lueur) · solitaire (un curieux l'approche, il s'esquive)
     · rivalité (face-à-face, gonflements alternés, l'un recule) · accord (rythmes différents qui se synchronisent)
     · rencontre (un figurant salue une créature réelle, qui répond d'un éclair).
   Hors histoire : flânerie, petits bancs spontanés, accord des pulsations entre voisins (Kuramoto).
   AVANT-PLAN : toutes les ~25-40 s (graine), un figurant monte au premier plan (plus grand, net, lumineux, alpha ≤ .55),
   traverse au-dessus du jeu en évitant la bille, puis redescend dans son plan. Dessiné par QXCREA.niveau.avant (engine.js).
   Coût : tableaux pré-alloués, couleurs fixes (alpha par globalAlpha), lueurs pré-rendues ; quantité selon le palier. */
const FN = [9, 7, 6, 5], FSL = [3, 2, 2, 1];                 // figurants et scènes simultanées par palier
const FPL = { sc: [.6, .82, 1.08, 2.7], al: [.2, .31, .43, .52], vit: [.42, .68, 1, 1.2], brume: [.55, .28, .08, 0], par: [-.8, -.3, .35, 1.6], lw: [.55, .8, 1, 1.35] };
const FCOL = [[110, 238, 196], [127, 216, 230], [232, 248, 252], [182, 154, 232]];   // lueur, aqua, perle, mauve
const zp = (arr, z) => { const i = Math.max(0, Math.min(2.999, z)), k = i | 0, u = i - k; return arr[k] + (arr[k + 1] - arr[k]) * u; };
const HIST = ['banc', 'duo', 'parent', 'chasse', 'cour', 'ronde', 'sieste', 'conversation', 'migration', 'solitaire', 'rivalite', 'accord', 'rencontre'];
const HMIN = { banc: 3, duo: 2, parent: 2, chasse: 2, cour: 2, ronde: 3, sieste: 3, conversation: 4, migration: 3, solitaire: 1, rivalite: 2, accord: 3, rencontre: 1 };
const HMAX = { banc: 5, duo: 2, parent: 2, chasse: 2, cour: 2, ronde: 5, sieste: 4, conversation: 5, migration: 5, solitaire: 1, rivalite: 2, accord: 4, rencontre: 2 };
const HDUR = { banc: [16, 22], duo: [13, 20], parent: [17, 25], chasse: [12, 20], cour: [15, 23], ronde: [17, 25], sieste: [15, 22], conversation: [14, 22], migration: [20, 28], solitaire: [11, 16], rivalite: [11, 17], accord: [14, 20], rencontre: [11, 16] };
const DASH = [.22, .3], NODASH = [];
let FW = -1, FCS = null, FSP = null;                          // couleurs et lueurs par (couleur, pas de profondeur 0..6), selon le monde
function figTeintes(wd) {
  if (FW === wd && FCS) return; FW = wd;
  let wc = [96, 128, 160];
  try { const h = (racine.WORLDS && racine.WORLDS[(wd || 1) - 1] || {}).c; if (h && h.length === 7) wc = [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; } catch (e) {}
  const fog = [96 * .8 + wc[0] * .2 * .6, 128 * .8 + wc[1] * .2 * .7, 160 * .8 + wc[2] * .2 * .9];   // brume froide, à peine teintée du monde (jamais dorée)
  FCS = []; FSP = [];
  for (let c = 0; c < FCOL.length; c++) {
    const L = [], S2 = [];
    for (let s = 0; s < 7; s++) {
      const z = s / 2, b = zp(FPL.brume, z), C = FCOL[c], g = (C[0] + C[1] + C[2]) / 3;
      const rgb = [0, 1, 2].map(k => Math.round((C[k] * (1 - b * .45) + g * b * .45) * (1 - b) + fog[k] * b));
      L.push('rgb(' + rgb.join(',') + ')');
      const k = document.createElement('canvas'); k.width = k.height = 48; const gx = k.getContext('2d');
      const r = gx.createRadialGradient(24, 24, 0, 24, 24, 24), cs = rgb.join(','), dur = z < 1 ? .35 : z < 2.5 ? .6 : .85;   // lointain : lueur plus diffuse (flou)
      r.addColorStop(0, 'rgba(' + cs + ',' + dur + ')'); r.addColorStop(.3, 'rgba(' + cs + ',' + (dur * .45).toFixed(2) + ')'); r.addColorStop(.7, 'rgba(' + cs + ',.07)'); r.addColorStop(1, 'rgba(' + cs + ',0)');
      gx.fillStyle = r; gx.fillRect(0, 0, 48, 48); S2.push(k);
    }
    FCS.push(L); FSP.push(S2);
  }
}
function figMonter(lv) {
  figTeintes(lv.wd);
  const idx = lv.idx || 0, R = rng(0xF16A + idx * 6151), A = [];
  for (let i = 0; i < 9; i++) {
    const z0 = [1, 0, 2, 1, 2, 0, 1, 2, 0][i];                   // trois plans, trois figurants chacun ; aux paliers bas, les derniers s'effacent (les trois plans restent)
    A.push({ i, z0: z0, zc: z0, taille: 6 + 3.4 * R(), morph: (i + idx) % 3, col: (i * 3 + idx) % 4, hz: .55 + .5 * R(), hzM: 1, ph: R() * TAU, puls: 0,
      lum: .3, lumT: .3, fl: 0, mul: 1, mulT: 1, x: 30 + R() * 300, y: 40 + R() * 390, vx: 0, vy: 0, cap: R() * TAU, tx: 0, ty: 0, vd: 0,
      w1: .025 + .03 * R(), w2: .02 + .025 * R(), p1: R() * TAU, p2: R() * TAU, sol: false, st: -1, role: 0, look: 0, lookOn: 0, got: -9, gotF: -1,
      ap: 0, de: -1, lookT: 0, rx: 0, ry: 0, tr: new Float32Array(16), trN: 0, trT: 0, wake: -1, dim: 1, K: .5, R: rng(0xBEE5 ^ (idx * 3571 + i * 7121)) });
  }
  A[3].sol = true;                                              // un solitaire dans le plan médian
  const SL = []; for (let i = 0; i < 3; i++) SL.push({ on: false, type: '', t: 0, dur: 1, m: new Int8Array(6), nm: 0, ph: 0, tp: 0, x: 0, y: 0, k: 0, a: 0, b: 0, gap: 1.5 + i * 2.5 + R() * 2, last: -9 });
  const IMP = []; for (let i = 0; i < 10; i++) IMP.push({ on: false, a: 0, b: 0, ri: -1, t0: 0, d: 1, c: 0 });
  const RGF = []; for (let i = 0; i < 10; i++) RGF.push({ on: false, x: 0, y: 0, t0: 0, d: 1, r0: 0, r1: 0, a: 0, c: 0, s: 0 });
  const SPK = []; for (let i = 0; i < 12; i++) SPK.push({ on: false, x: 0, y: 0, vx: 0, vy: 0, t0: 0, d: 1 });
  cur.F = { A, n: 9, SL, IMP, RGF, SPK, R, t: 0, hist: [-1, -1, -1, -1, -1], hi: 0, LKa: new Int8Array(20), LKb: new Int8Array(20), LKx: new Float32Array(20), LKy: new Float32Array(20), LKal: new Float32Array(20), nLK: 0,
    av: -1, avT: 0, avDur: 0, tAv: 13 + R() * 9, ax0: 0, ay0: 0, ax1: 0, ay1: 0, mode0: '', bx: 0, by: 0, ord: new Int8Array(9), ms: 0, ems: 0, nb: [0, 0, 0, 0], motes: 0 };
  for (let k = 0; k < 9; k++) cur.F.ord[k] = k;
  for (let s = 0; s < 40; s++) figPas(1 / 20, null, null, false, true, false);   // déjà installés quand le niveau s'ouvre
}
/* ── outils ── */
function fLibre(F, a) { return a.st === -1 && a.i < F.n; }
function fVa(a, x, y, v) { a.tx = x; a.ty = y; a.vd = v; }
function fLien(F, a, b, al, px, py) { if (F.nLK >= 20 || al < .01) return; const k = F.nLK++; F.LKa[k] = a; F.LKb[k] = b; F.LKx[k] = px || 0; F.LKy[k] = py || 0; F.LKal[k] = al; }
function fOnde(F, x, y, r0, r1, d, a, c, s) { let o = null; for (const q of F.RGF) if (!q.on) { o = q; break; } if (!o) return; o.on = true; o.x = x; o.y = y; o.r0 = r0; o.r1 = r1; o.d = d; o.a = a; o.c = c; o.s = s; o.t0 = F.t; }
function fImp(F, a, b, ri) { let o = null; for (const q of F.IMP) if (!q.on) { o = q; break; } if (!o) return 0; const A = F.A[a]; let bx, by;
  if (ri >= 0) { const e = cur.E[ri]; bx = e.x; by = e.y; } else { bx = F.A[b].x; by = F.A[b].y; }
  o.on = true; o.a = a; o.b = b; o.ri = ri; o.t0 = F.t; o.d = Math.max(.35, Math.hypot(bx - A.x, by - A.y) / 120); o.c = A.col; A.fl = Math.max(A.fl, .7); return o.d; }
function fSpore(F, x, y) { for (let j = 0; j < 6; j++) for (const p of F.SPK) if (!p.on) { const an = j * TAU / 6 + F.R() * .5; p.on = true; p.x = x; p.y = y; p.vx = Math.cos(an) * 14; p.vy = Math.sin(an) * 14 - 8; p.t0 = F.t; p.d = 1.6 + F.R(); break; } }
function fPointCalme(F, R) {                                   // un point loin de ce qu'il faut lire (bille, coupe, étoile, murs)
  let bx = 180, by = 235, bs = -1;
  for (let k = 0; k < 10; k++) {
    const x = 50 + R() * 260, y = 60 + R() * 350; let s = 200;
    for (const z of cur.Z) s = Math.min(s, Math.hypot(x - z[0], y - z[1]) - z[2]);
    for (const w of cur.murs) s = Math.min(s, dSeg(x, y, w) + 10);
    if (F.bx) s = Math.min(s, Math.hypot(x - F.bx, y - F.by) - 20);
    if (s > bs) { bs = s; bx = x; by = y; }
  }
  return [bx, by];
}
const _fc = [0, 0];
function fCentre(F, s) { let x = 0, y = 0; for (let j = 0; j < s.nm; j++) { x += F.A[s.m[j]].x; y += F.A[s.m[j]].y; } _fc[0] = x / s.nm; _fc[1] = y / s.nm; return _fc; }
function fFin(F, s) {
  for (let j = 0; j < s.nm; j++) { const a = F.A[s.m[j]]; if (a.st !== -2) a.st = -1; a.de = -1; a.hzM = 1; a.mulT = 1; a.lumT = .3; a.lookOn = 0; a.K = .5; a.dim = 1; }
  s.on = false; s.gap = 1.5 + F.R() * 3.5;
}
function fRecrute(F, s, type) {
  const R = F.R, lib = [];
  for (const a of F.A) if (fLibre(F, a) && (type === 'solitaire' ? true : !a.sol) && a.x > -10 && a.x < 370) lib.push(a);
  if (type === 'solitaire') { const so = F.A.find(a => a.sol && fLibre(F, a)); if (!so) return false; const c = lib.filter(a => !a.sol); if (!c.length) return false; let b = c[0], bd = 1e9; for (const a of c) { const d = Math.hypot(a.x - so.x, a.y - so.y); if (d < bd) { bd = d; b = a; } } s.m[0] = b.i; s.m[1] = so.i; s.nm = 2; return true; }
  if (lib.length < HMIN[type]) return false;
  const g = lib[Math.floor(R() * lib.length)], n = Math.min(HMAX[type], lib.length, HMIN[type] + Math.floor(R() * (HMAX[type] - HMIN[type] + 1)));
  lib.sort((p, q) => (Math.hypot(p.x - g.x, p.y - g.y) + 90 * Math.abs(p.z0 - g.z0)) - (Math.hypot(q.x - g.x, q.y - g.y) + 90 * Math.abs(q.z0 - g.z0)));
  s.nm = n; for (let j = 0; j < n; j++) s.m[j] = lib[j].i;
  if (type === 'parent' && F.A[s.m[0]].taille < F.A[s.m[1]].taille) { const t = s.m[0]; s.m[0] = s.m[1]; s.m[1] = t; }
  return true;
}
function fLance(F, s) {
  const R = F.R, nn = F.A.filter(a => fLibre(F, a)).length, vis = cur.E.some(e => e.ap > .1);
  let best = -1, bs = -1;
  for (let h = 0; h < HIST.length; h++) {
    const ty = HIST[h]; if (F.hist.indexOf(h) >= 0) continue;
    if (ty !== 'solitaire' && nn < HMIN[ty]) continue;
    if (ty === 'rencontre' && !vis) continue;
    if (F.SL.some(o => o.on && o.type === ty)) continue;
    const w = R() * (ty === 'migration' || ty === 'banc' || ty === 'conversation' || ty === 'ronde' ? 1.25 : 1);
    if (w > bs) { bs = w; best = h; }
  }
  if (best < 0) { s.gap = 1.5; return; }
  const type = HIST[best];
  if (!fRecrute(F, s, type)) { s.gap = 1.2; F.hist[F.hi] = best; F.hi = (F.hi + 1) % F.hist.length; return; }
  F.hist[F.hi] = best; F.hi = (F.hi + 1) % F.hist.length;
  const si = F.SL.indexOf(s);
  s.on = true; s.type = type; s.t = 0; s.ph = 0; s.tp = 0; s.k = 0; s.a = 0; s.b = R() < .55 ? 1 : 0;
  s.dur = HDUR[type][0] + R() * (HDUR[type][1] - HDUR[type][0]);
  for (let j = 0; j < s.nm; j++) { const a = F.A[s.m[j]]; a.st = si; a.role = j; }
  const P = fPointCalme(F, R); s.x = P[0]; s.y = P[1];
  if (type === 'rencontre') { let bi = 0, bd = 1e9; const a = F.A[s.m[0]]; cur.E.forEach((e, k) => { if (e.ap > .1) { const d = Math.hypot(e.x - a.x, e.y - a.y); if (d < bd) { bd = d; bi = k; } } }); s.a = bi; s.k = R() * TAU; }
  if (type === 'migration') { const C = fCentre(F, s); s.a = C[0] < 180 ? -1 : 1; s.y = 110 + R() * 250; s.b = R() < .5 ? -1 : 1; }
  if (type === 'accord') for (let j = 0; j < s.nm; j++) F.A[s.m[j]].hzM = .7 + .65 * j / Math.max(1, s.nm - 1);
  if (type === 'chasse') s.a = 0;
  if (type === 'banc') s.k = R() * 6;
}
/* ── les histoires ── */
function fHistoire(F, s, dt) {
  const A = F.A, m = s.m, n = s.nm, t = s.t, T = F.t, R = F.R;
  const M = j => A[m[j]];
  switch (s.type) {
    case 'banc': {
      const L = M(0), u = T * .16 + s.k, px = 180 + 135 * Math.sin(u * 1.1 + s.k), py = 235 + 165 * Math.sin(u * .72 + s.k * 2);
      if (t < 3.5) { fVa(L, px, py, 8); for (let j = 1; j < n; j++) fVa(M(j), L.x, L.y, 34); }
      else if (t < s.dur - 2.5) {
        fVa(L, px, py, 30); const c = Math.cos(L.cap), si = Math.sin(L.cap);
        for (let j = 1; j < n; j++) {
          const row = (j + 1) >> 1, side = j % 2 ? 1 : -1, bk = 15 * row, lat = side * 12 * row + 4 * Math.sin(T * 2 + j);
          const a = M(j); fVa(a, L.x - c * bk - si * lat, L.y - si * bk + c * lat, 48); a.K = 2.5; a.gotF = L.i;
          if (L.puls > .7) fLien(F, L.i, a.i, .3 * L.puls);
        }
      } else {
        if (s.ph === 0) { s.ph = 1; const C = fCentre(F, s); for (let j = 0; j < n; j++) { const a = M(j), d = Math.hypot(a.x - C[0], a.y - C[1]) || 1, an = d > 2 ? Math.atan2(a.y - C[1], a.x - C[0]) : j * 2.4; a.tx = a.x + Math.cos(an) * 70; a.ty = a.y + Math.sin(an) * 70; a.wake = T + j * .15; } }
        for (let j = 0; j < n; j++) M(j).vd = 55;
      }
      break;
    }
    case 'duo': {
      const a = M(0), b = M(1), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2, d = Math.hypot(a.x - b.x, a.y - b.y);
      if (s.ph === 0) { fVa(a, cx, cy, 30); fVa(b, cx, cy, 30); if (d < 34 || t > 4.5) { s.ph = 1; s.tp = t; s.x = cx; s.y = cy; a.fl = b.fl = .8; } }
      else if (t < s.dur - 2.5) {
        const u = t - s.tp, ox = s.x + 22 * Math.sin(u * .3), oy = s.y + 14 * Math.sin(u * .23) - u * 1.2, r = 15 + 8 * Math.sin(u * .8), th = u * 1.7;
        fVa(a, ox + Math.cos(th) * r, oy + Math.sin(th) * r, 46); fVa(b, ox - Math.cos(th) * r, oy - Math.sin(th) * r, 46);
        a.K = b.K = 3; a.gotF = b.i; b.gotF = a.i;
        fLien(F, a.i, b.i, .14 + .4 * a.puls);
      } else { if (s.ph === 1) { s.ph = 2; const an = Math.atan2(b.y - a.y, b.x - a.x); a.tx = a.x - Math.cos(an) * 70; a.ty = a.y - Math.sin(an) * 70; b.tx = b.x + Math.cos(an) * 70; b.ty = b.y + Math.sin(an) * 70; a.fl = b.fl = 1; } a.vd = b.vd = 26; }
      break;
    }
    case 'parent': {
      const P = M(0), p = M(1); P.mulT = 1.12; p.mulT = .62;
      if (t > s.tp) { s.tp = t + 6 + R() * 2; const Q = fPointCalme(F, R); s.x = Q[0]; s.y = Q[1]; }
      const distr = t > 7.5 && t < 11 && s.ph < 2;
      fVa(P, s.x, s.y, t > 9.2 && t < 11 ? 0 : 17);
      if (distr) { if (s.ph === 0) { s.ph = 1; s.k = R() * TAU; } fVa(p, P.x + Math.cos(s.k) * 62, P.y + Math.sin(s.k) * 62, 30); }
      else { const c = Math.cos(P.cap), si = Math.sin(P.cap); fVa(p, P.x - c * 15 - si * 6 * Math.sin(T * 3), P.y - si * 15 + c * 6 * Math.sin(T * 3), 44); }
      if (t > 9.4 && s.ph === 1) { s.ph = 2; P.lumT = .8; fImp(F, P.i, p.i, -1); }
      if (s.ph === 2 && p.got > T - 1 && p.got >= F.t - dt) { p.fl = 1; p.wake = T + .05; }
      if (t > 9.2 && t < 11) { P.lookOn = 1; P.look = Math.atan2(p.y - P.y, p.x - P.x); } else P.lookOn = 0;
      p.K = 2; p.gotF = P.i;
      const dd = Math.hypot(P.x - p.x, P.y - p.y); if (dd < 30) fLien(F, P.i, p.i, .12 + .15 * P.puls);
      break;
    }
    case 'chasse': {
      const c = M(s.a); s.tp += dt;
      let r = null, rd = 1e9; for (let j = 0; j < n; j++) if (j !== s.a) { const q = M(j), d = Math.hypot(q.x - c.x, q.y - c.y); if (d < rd) { rd = d; r = q; } }
      if (t < s.dur - 3 && s.k < 4) {
        if (s.tp < 1) { c.vd = 0; c.tx = c.x; c.ty = c.y; c.lookOn = 1; c.look = Math.atan2(r.y - c.y, r.x - c.x); }
        else { c.lookOn = 0; fVa(c, r.x + r.vx * .45, r.y + r.vy * .45, 66); c.lumT = .7; }
        for (let j = 0; j < n; j++) if (j !== s.a) {
          const q = M(j), dx = q.x - c.x, dy = q.y - c.y, d = Math.hypot(dx, dy) || 1, z = Math.sin(T * 2.6 + j * 1.7) * .9;
          let fx = dx / d - dy / d * z, fy = dy / d + dx / d * z;
          fx += (180 - q.x) / 260; fy += (235 - q.y) / 300;
          fVa(q, q.x + fx * 50, q.y + fy * 50, d < 90 ? 44 : 18); q.lumT = .5;
        }
        if (rd < 16 && s.tp > 1.4) { s.k++; c.fl = r.fl = 1; { const ex = c.x - r.x, ey = c.y - r.y, e = Math.hypot(ex, ey) || 1; c.vx += ex / e * 60; c.vy += ey / e * 60; } fOnde(F, (c.x + r.x) / 2, (c.y + r.y) / 2, 3, 24, .7, .7, r.col, r.zc); s.a = m.indexOf(r.i); s.tp = 0; }
      } else { const C = fCentre(F, s); for (let j = 0; j < n; j++) { fVa(M(j), C[0] + (j - 1) * 14, C[1] - 6 * t * 0, 12); if (j) fLien(F, M(0).i, M(j).i, .12 * M(0).puls); M(j).K = 2.5; M(j).gotF = M(0).i; } }
      break;
    }
    case 'cour': {
      const a = M(0), b = M(1), d = Math.hypot(a.x - b.x, a.y - b.y);
      if (s.ph === 0) { fVa(a, b.x, b.y, 30); fVa(b, b.x, b.y, 4); if (d < 44) { s.ph = 1; s.tp = t; } }
      else if (s.ph === 1) {                                          // parade : devant elle, balancement, gonflements
        const fa = Math.atan2(a.y - b.y, a.x - b.x), sw = Math.sin((t - s.tp) * 1.5) * .7;
        fVa(a, b.x + Math.cos(fa + sw) * 28, b.y + Math.sin(fa + sw) * 28, 30); a.mulT = 1 + .3 * a.puls; a.lumT = .9; a.lookOn = 1; a.look = fa + Math.PI;
        b.vd = 3; if (a.puls > .85) fLien(F, a.i, b.i, .25);
        if (t - s.tp > 2.6) { if (s.k < 2) { s.k++; s.ph = 0; const an = fa + Math.PI / 2 * (s.k % 2 ? 1 : -1); b.tx = b.x + Math.cos(an) * 55; b.ty = b.y + Math.sin(an) * 55; b.vd = 46; b.fl = .6; a.lookOn = 0; a.mulT = 1; s.tp = t; s.ph = 3; }
          else { s.ph = s.b ? 4 : 5; s.tp = t; a.lookOn = 0; a.mulT = 1; if (s.b) { a.fl = b.fl = 1; fOnde(F, (a.x + b.x) / 2, (a.y + b.y) / 2, 4, 30, .9, .6, b.col, b.zc); } else { b.fl = 1; fOnde(F, b.x, b.y, 4, 34, .7, .8, b.col, b.zc); } } }
      } else if (s.ph === 3) { a.vd = 10; a.tx = a.x; a.ty = a.y; if (t - s.tp > 1.1) s.ph = 0; }          // esquive : elle s'écarte, il hésite
      else if (s.ph === 4) { const u = t - s.tp, cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2, th = u * 1.8; fVa(a, cx + Math.cos(th) * 13, cy + Math.sin(th) * 13 - 1, 36); fVa(b, cx - Math.cos(th) * 13, cy - Math.sin(th) * 13 - 1, 36); a.K = b.K = 3; a.gotF = b.i; fLien(F, a.i, b.i, .2 + .35 * a.puls); if (u > 5) s.t = s.dur; }
      else { const an = Math.atan2(a.y - b.y, a.x - b.x); if (t - s.tp < .1) { a.tx = a.x + Math.cos(an) * 80; a.ty = a.y + Math.sin(an) * 80; b.tx = b.x - Math.cos(an) * 40; b.ty = b.y - Math.sin(an) * 40; } a.vd = 50; b.vd = 20; a.lumT = .1; a.mulT = .85; a.dim = .7; if (t - s.tp > 4) s.t = s.dur; }
      break;
    }
    case 'ronde': {
      s.y -= dt * 2.2; const mI = lisse(0, 2.5, t) * (1 - lisse(s.dur - 3, s.dur - 2, t));
      s.tp = mI;                                                      // intensité de la spore (dessinée par fDessinerFond)
      if (t < s.dur - 2) {
        for (let j = 0; j < n; j++) { const a = M(j), an = t * .55 + j * TAU / n, r = 30 + 4 * Math.sin(t * 1.3 + j); fVa(a, s.x + Math.cos(an) * r, s.y + Math.sin(an) * r * .8, Math.hypot(a.x - s.x, a.y - s.y) > 50 ? 52 : 26); a.K = 2.5; a.gotF = -3; a.lookOn = t > 4 ? 1 : 0; a.look = Math.atan2(s.y - a.y, s.x - a.x);
          if (mI > .3) fLien(F, a.i, -1, .1 * mI * a.puls, s.x, s.y); }
      } else { if (s.ph === 0) { s.ph = 1; fSpore(F, s.x, s.y); for (let j = 0; j < n; j++) { const a = M(j), an = Math.atan2(a.y - s.y, a.x - s.x); a.tx = a.x + Math.cos(an) * 60; a.ty = a.y + Math.sin(an) * 60; a.fl = 1; a.lookOn = 0; } } for (let j = 0; j < n; j++) M(j).vd = 34; }
      break;
    }
    case 'sieste': {
      if (s.ph === 0) { const C = fCentre(F, s); s.x = C[0]; s.y = Math.min(400, C[1] + 20); s.ph = 1; s.tp = s.dur - 5 - .55 * n; }
      if (t < s.tp) {
        const dort = t > 4;
        for (let j = 0; j < n; j++) { const a = M(j), an = j * TAU / n + .3, r = dort ? 8 + 1.5 * Math.sin(T * .7 + j) : 12; fVa(a, s.x + Math.cos(an) * r, s.y + Math.sin(an) * r * .7 + (dort ? Math.min(14, (t - 4) * 1.2) : 0), dort ? 5 : 26);
          if (dort) { a.lumT = .06; a.hzM = .35; a.mulT = .88; a.dim = .8; } }
      } else {
        const u = t - s.tp, k = Math.floor(u / .55);
        while (s.k <= k && s.k < n) { const a = M(s.k); a.fl = 1; a.mulT = 1.25; a.hzM = 1.4; a.lumT = .6; a.dim = 1; if (s.k + 1 < n) fImp(F, a.i, M(s.k + 1).i, -1); else fOnde(F, s.x, s.y, 6, 46, 1, .6, a.col, a.zc); s.k++; }
        if (u > .55 * n + 1.2) { if (s.ph === 1) { s.ph = 2; for (let j = 0; j < n; j++) { const a = M(j), an = j * TAU / n + .3; a.tx = a.x + Math.cos(an) * 70; a.ty = a.y + Math.sin(an) * 70 - 20; a.mulT = 1; } } for (let j = 0; j < n; j++) M(j).vd = 36; }
      }
      break;
    }
    case 'conversation': {
      if (s.ph === 0) { const C = fCentre(F, s); s.x = (C[0] * .5 + s.x * .5); s.y = (C[1] * .5 + s.y * .5); s.ph = 1; s.tp = 3; s.k = 0; s.b = 1; }
      const rr = 40 + 4 * n;
      for (let j = 0; j < n; j++) { const a = M(j), an = j * TAU / n + .5 + .06 * Math.sin(T * .4), q = 1 + .08 * Math.sin(T * .9 + j * 2); fVa(a, s.x + Math.cos(an) * rr * q, s.y + Math.sin(an) * rr * .75 * q, t < 3 ? 30 : 8);
        if (a.de >= 0 && T - a.got < 2) { const o = A[a.de]; a.lookOn = 1; a.look = Math.atan2(o.y - a.y, o.x - a.x); } }
      if (t > s.dur - 2.5) { if (s.ph === 1) { s.ph = 2; for (let j = 0; j < n; j++) { M(j).fl = 1; M(j).lumT = .8; } fOnde(F, s.x, s.y, 10, rr + 20, 1.2, .5, M(0).col, M(0).zc); } break; }
      if (t > s.tp) {
        const a = M(s.k), nx = (s.k + s.b + n) % n, d = fImp(F, a.i, M(nx).i, -1);
        if (F.R() < .22) fImp(F, a.i, M((s.k + 2 * s.b + n) % n).i, -1);   // une branche : deux répondent
        if (F.R() < .15) s.b = -s.b;                                     // le tour de parole change de sens
        s.k = nx; s.tp = t + (d || .5) + .35 + .5 * F.R();
      }
      break;
    }
    case 'migration': {
      const E = s.a;                                                     // côté de sortie (-1 gauche, 1 droite)
      if (s.ph === 0) {
        let tous = true;
        for (let j = 0; j < n; j++) { const a = M(j); fVa(a, E < 0 ? -60 : 420, a.y, 30); a.dim = Math.max(0, a.dim - dt * .7); if (a.dim > .02 && (E < 0 ? a.x > -25 : a.x < 385)) tous = false; }   // ils se fondent dans la brume
        if (tous || t > 5) { s.ph = 1; s.tp = t; for (let j = 0; j < n; j++) { const a = M(j); a.x = (E < 0 ? 420 : -60) - E * j * 24; a.y = s.y + s.b * j * 12; a.vx = E * 30; a.vy = 0; a.trN = 0; a.cap = E < 0 ? Math.PI : 0; a.dim = 1; } }
      } else {
        let tous = true;
        for (let j = 0; j < n; j++) { const a = M(j), u = t - s.tp; fVa(a, a.x + E * 70, s.y + s.b * j * 12 + 16 * Math.sin(u * .8 + j * .7) + u * s.b * 2, 34 / zp(FPL.vit, a.zc)); a.lumT = .35 + .55 * Math.max(0, Math.sin(u * 3 - j * .9)); a.K = 1.5; a.gotF = j ? M(j - 1).i : -1;
          if (E < 0 ? a.x > -30 : a.x < 390) tous = false; if (j && a.puls > .8) fLien(F, M(j - 1).i, a.i, .12); }
        if (tous) s.t = s.dur;
        if (t > s.dur - .1 && !tous) s.dur += .5;                         // on attend que la file soit passée
        if (t > 34) s.t = s.dur = 34;
      }
      break;
    }
    case 'solitaire': {
      const c = M(0), so = M(1), d = Math.hypot(c.x - so.x, c.y - so.y);
      if (t < 5) { const an = Math.atan2(c.y - so.y, c.x - so.x); fVa(c, so.x + Math.cos(an) * 52, so.y + Math.sin(an) * 52, 26); }
      else if (t < 8) { fVa(c, c.x, c.y, 0); c.lookOn = 1; c.look = Math.atan2(so.y - c.y, so.x - c.x); if (s.ph === 0) { s.ph = 1; fImp(F, c.i, so.i, -1); } }
      else { c.lumT = .12; c.dim = .75; fVa(c, c.x + (c.x - so.x) * .3, c.y + 25, 10); c.lookOn = 0; }
      if (s.ph === 1 && so.got > T - .2 && s.k === 0) { s.k = 1; so.fl = .45; }   // un seul petit éclair en réponse… et il garde ses distances
      const ex = so.x < 180 ? 20 : 340, ey = so.y < 235 ? 50 : 420;
      fVa(so, so.x + (ex - so.x) * .5, so.y + (ey - so.y) * .5, d < 110 ? 40 : 10); so.lumT = .2;
      if (d < 120) { so.lookOn = 1; so.look = Math.atan2(so.y - c.y, so.x - c.x); } else so.lookOn = 0;
      break;
    }
    case 'rivalite': {
      const a = M(0), b = M(1), d = Math.hypot(a.x - b.x, a.y - b.y);
      if (s.ph === 0) { fVa(a, s.x - 20, s.y, 32); fVa(b, s.x + 20, s.y, 32); if ((Math.hypot(a.x - s.x, a.y - s.y) < 34 && Math.hypot(b.x - s.x, b.y - s.y) < 34) || t > 6) { s.ph = 1; s.tp = t; s.k = 0; } }
      else if (s.ph === 1) {
        const u = t - s.tp, tour = Math.floor(u / 1.1), an = Math.atan2(b.y - a.y, b.x - a.x);
        a.lookOn = b.lookOn = 1; a.look = an; b.look = an + Math.PI;
        if (tour > s.k) { s.k = tour; const P = tour % 2 ? b : a, Q = tour % 2 ? a : b; P.mulT = 1.25 + .06 * tour; P.fl = 1; P.lumT = .9; Q.mulT = 1; Q.lumT = .35; fOnde(F, P.x, P.y, 3, 18 + 3 * tour, .6, .55, P.col, P.zc); }
        const lunge = Math.max(0, Math.sin((u % 1.1) / 1.1 * Math.PI)) * 6, P = s.k % 2 ? b : a, Q = s.k % 2 ? a : b, sg = P === a ? 1 : -1;
        fVa(P, s.x - sg * (17 - lunge) * Math.cos(an), s.y - sg * (17 - lunge) * Math.sin(an), 22); fVa(Q, s.x + sg * 19 * Math.cos(an), s.y + sg * 19 * Math.sin(an), 22);
        if (s.k >= 4) { s.ph = 2; s.tp = t; const L = s.b ? a : b, G = s.b ? b : a, aw = Math.atan2(L.y - G.y, L.x - G.x); L.tx = L.x + Math.cos(aw) * 95; L.ty = L.y + Math.sin(aw) * 95; L.vd = 62; L.lumT = .08; L.mulT = .82; L.dim = .7; L.lookOn = 0; G.mulT = 1.1; G.lumT = .8; G.fl = 1; }
      } else { const L = s.b ? a : b, G = s.b ? b : a; L.vd = 50; fVa(G, s.x, s.y, 10); G.lookOn = 1; G.look = Math.atan2(L.y - G.y, L.x - G.x); if (d > 70) G.lookOn = 0; }
      break;
    }
    case 'accord': {
      if (s.ph === 0) { const C = fCentre(F, s); s.x = C[0]; s.y = C[1]; s.ph = 1; }
      s.y -= dt * 2.5; s.x += Math.sin(T * .3) * dt * 6;
      const K = Math.min(4, t * .45);
      let cx = 0, cy = 0; for (let j = 0; j < n; j++) { cx += Math.cos(M(j).ph); cy += Math.sin(M(j).ph); }
      const ordre = Math.hypot(cx, cy) / n;                               // 1 = parfaitement accordées
      for (let j = 0; j < n; j++) { const a = M(j), an = j * TAU / n + t * .2, r = 22 - 6 * ordre; fVa(a, s.x + Math.cos(an) * r, s.y + Math.sin(an) * r, 22); a.K = K; a.gotF = -2;
        if (t > 9) a.hzM += (1 - a.hzM) * Math.min(1, dt * .5);
        if (ordre > .93) { a.lumT = .7; if (j) fLien(F, M(j - 1).i, a.i, .3 * a.puls); } }
      if (ordre > .93 && s.k === 0) { s.k = 1; fOnde(F, s.x, s.y, 6, 44, 1.1, .5, M(0).col, M(0).zc); }
      break;
    }
    case 'rencontre': {
      const e = cur.E[s.a]; if (!e || e.ap < .05) { s.t = s.dur; break; }
      for (let j = 0; j < n; j++) {
        const a = M(j), an = s.k + j * .8 + (t > 8 ? (t - 8) * .5 : 0), r = (e.hl || 16) * 2.2 + 26;
        fVa(a, e.x + Math.cos(an) * r, e.y + Math.sin(an) * r, t > s.dur - 2.5 ? 6 : 30); a.lookOn = t < s.dur - 2.5 ? 1 : 0; a.look = Math.atan2(e.y - a.y, e.x - a.x);
        if (t > 4.2 && s.ph === j) { s.ph++; fImp(F, a.i, -1, s.a); }
      }
      if (t > s.dur - 2.5 && s.b !== 9) { s.b = 9; for (let j = 0; j < n; j++) { const a = M(j), an = Math.atan2(a.y - e.y, a.x - e.x); a.tx = a.x + Math.cos(an) * 70; a.ty = a.y + Math.sin(an) * 70; } }
      if (t > s.dur - 2.5) for (let j = 0; j < n; j++) M(j).vd = 30;
      break;
    }
  }
}
/* ── l'avant-plan : un figurant monte au-dessus du jeu, traverse, redescend ── */
function fAvant(F, dt, lent) {
  if (F.av < 0) {
    if (lent || F.t < F.tAv) return;
    let best = -1, bs = -1e9;
    for (const a of F.A) if (fLibre(F, a) && !a.sol && a.x > 20 && a.x < 340 && a.y > 30 && a.y < 440) { const s = a.z0 * 2 + F.R() * 1.5 - (F.bx ? Math.max(0, 1 - Math.hypot(a.x - F.bx, a.y - F.by) / 120) * 4 : 0); if (s > bs) { bs = s; best = a.i; } }
    if (best < 0) { F.tAv = F.t + 3; return; }
    const a = F.A[best]; F.av = best; F.avT = 0; a.st = -2;
    let x1 = 360 - a.x + (F.R() - .5) * 80, y1 = 470 - a.y + (F.R() - .5) * 120;
    const dx = x1 - a.x, dy = y1 - a.y, l = Math.hypot(dx, dy) || 1; if (l < 230) { x1 = a.x + dx / l * 230; y1 = a.y + dy / l * 230; }
    F.ax1 = Math.max(-40, Math.min(400, x1)); F.ay1 = Math.max(30, Math.min(440, y1)); F.avDur = Math.max(7, Math.hypot(F.ax1 - a.x, F.ay1 - a.y) / 36 + 3.2);
    return;
  }
  const a = F.A[F.av]; F.avT += dt;
  const u = F.avT, up = lisse(0, 1.8, u), down = lisse(F.avDur - 2, F.avDur, u);
  a.zc = a.z0 + (3 - a.z0) * up * (1 - down);
  a.lumT = .55; a.K = 0;
  fVa(a, F.ax1, F.ay1, 40);
  if (u > F.avDur || lent) { a.zc = a.z0; a.st = -1; F.av = -1; F.tAv = F.t + 25 + F.R() * 15; }
}
/* ── un pas de simulation (comportement + intégration) ── */
function figPas(dt, S, b, run, prep, lent) {
  const F = cur.F, A = F.A, T = (F.t += dt);
  F.nLK = 0;
  F.n = FN[cur.pal]; const nsl = FSL[cur.pal];
  if (act && act.E.length >= 2 && act.idx === cur.idx) F.n = Math.max(3, F.n - 2);   // R481 : niveau en duo de créatures actives → deux figurants de moins (perf)
  if (b) { F.bx = b.x; F.by = b.y; } else F.bx = 0;
  /* moins de figurants (palier bas) : on referme les scènes concernées */
  for (const s of F.SL) if (s.on) { let ko = F.SL.indexOf(s) >= nsl; for (let j = 0; j < s.nm; j++) if (s.m[j] >= F.n) ko = true; if (ko) fFin(F, s); }
  if (F.av >= F.n) { const a = A[F.av]; a.zc = a.z0; a.st = -1; F.av = -1; }
  /* événements du jeu : un frisson se propage depuis la bille au lancement, la victoire illumine, l'échec assombrit */
  const md = S ? S.mode : '';
  if (md !== F.mode0 && !prep) {
    if ((md === 'run' || md === 'replay') && b) for (const a of A) a.wake = T + .1 + Math.hypot(a.x - b.x, a.y - b.y) / 260;
    else if (md === 'success') for (const a of A) a.wake = T + .2 + Math.hypot(a.x - cur.arr[0], a.y - cur.arr[1]) / 200;
    else if (md === 'fail') for (const a of A) { a.dim = .55; a.wake = -1; }
    else for (const a of A) if (a.st === -1) a.dim = 1;
    F.mode0 = md;
  }
  /* les scènes */
  for (let k = 0; k < F.SL.length; k++) {
    const s = F.SL[k]; if (k >= nsl) continue;
    if (!s.on) { s.gap -= dt; if (s.gap <= 0) fLance(F, s); continue; }
    s.t += dt; fHistoire(F, s, dt); if (s.t >= s.dur) fFin(F, s);
  }
  fAvant(F, dt, !!(prep || lent));
  /* chaque figurant */
  for (let i = 0; i < F.n; i++) {
    const a = A[i], vit = zp(FPL.vit, a.zc);
    if (a.st === -1) {                                                 // flânerie : un point d'attache qui fait lentement le tour de l'écran
      const hx = a.sol ? (a.p1 < Math.PI ? 34 : 326) + 20 * Math.sin(T * a.w1 * 3 + a.p2) : 180 + 140 * Math.sin(T * a.w1 + a.p1);
      const hy = 235 + 185 * Math.sin(T * a.w2 + a.p2);
      a.tx = hx + 22 * Math.sin(T * .31 + a.p2 * 3); a.ty = hy + 16 * Math.sin(T * .27 + a.p1 * 2); a.vd = 13; a.K = a.sol ? 0 : .6; a.gotF = -1; a.lookOn = T < a.lookT ? 1 : 0;
      if (!(md === 'fail')) a.dim += (1 - a.dim) * Math.min(1, dt * .3);
      a.lumT = .25 + .1 * Math.sin(T * .5 + a.p1);
    }
    if (a.wake > 0 && T >= a.wake) { a.wake = -1; a.fl = Math.max(a.fl, md === 'success' ? 1 : .55); if (b && md !== 'success') { a.lookT = T + 1.4; if (a.st === -1) a.lookOn = 1; a.look = Math.atan2(b.y - a.y, b.x - a.x); } }
    /* pulsation : rythme propre + accord avec les voisins (ou le meneur / la spore) */
    let dph = TAU * a.hz * a.hzM;
    if (a.K > 0) {
      if (a.gotF >= 0) dph += a.K * Math.sin(A[a.gotF].ph - a.ph);
      else if (a.gotF === -3) { const s = F.SL[a.st]; if (s) dph += a.K * Math.sin(T * TAU * .8 - a.ph); }
      else for (let j = 0; j < F.n; j++) { if (j === i) continue; const o = A[j]; if (a.gotF === -2 ? o.st !== a.st : Math.abs(o.zc - a.zc) > .6) continue; const d = Math.hypot(o.x - a.x, o.y - a.y); if (d < 80) dph += a.K * (1 - d / 80) * Math.sin(o.ph - a.ph); }
    }
    a.ph += dph * dt; if (a.ph > 1e4) a.ph -= 1e4 - (1e4 % TAU);
    const p = Math.max(0, Math.sin(a.ph)); a.puls = p * p * p;
    a.lum += (a.lumT - a.lum) * Math.min(1, dt * 2.5); a.mul += (a.mulT - a.mul) * Math.min(1, dt * 3);
    /* nage pulsée */
    const gain = .35 + 1.3 * a.puls, dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy) || 1, fr = Math.min(1, d / 30), v = a.vd * (a.st === -1 ? vit : 1.7 * Math.sqrt(vit)) * fr;   // en scène, le lointain reste un peu plus lent, sans traîner
    let ax = (dx / d * v - a.vx) * 2.4 * gain, ay = (dy / d * v - a.vy) * 2.4 * gain;
    for (let j = 0; j < F.n; j++) {                                    // séparation (même plan seulement : les plans se croisent, c'est la profondeur)
      if (j === i) continue; const o = A[j]; if (Math.abs(o.zc - a.zc) > .6) continue;
      const ex = a.x - o.x, ey = a.y - o.y, e = Math.hypot(ex, ey) || 1, Rr = a.sol || o.sol ? 80 : (a.st >= 0 && a.st === o.st ? 9 : 20);
      if (e < Rr) { const f = (Rr - e) * (a.sol ? 3 : 5); ax += ex / e * f; ay += ey / e * f; }
      else if (a.st === -1 && o.st === -1 && !a.sol && !o.sol && e < 70) { ax += (o.vx - a.vx) * .25; ay += (o.vy - a.vy) * .25; ax -= ex / e * 1.2; ay -= ey / e * 1.2; }   // petits bancs spontanés
    }
    if (F.bx) { const ex = a.x - F.bx, ey = a.y - F.by, e = Math.hypot(ex, ey) || 1, Rr = F.av === i ? 115 : 50; if (e < Rr) { const f = (Rr - e) * (F.av === i ? 8 : 4); ax += ex / e * f; ay += ey / e * f; } }
    if (F.av !== i) for (const z of cur.Z) { const ex = a.x - z[0], ey = a.y - z[1], e = Math.hypot(ex, ey) || 1, Rr = z[2] + 4; if (e < Rr) { const f = (Rr - e) * 3; ax += ex / e * f; ay += ey / e * f; } }
    if (a.st === -1 || (a.st >= 0 && F.SL[a.st].type !== 'migration')) { if (a.x < 8) ax += (8 - a.x) * 2; if (a.x > 352) ax -= (a.x - 352) * 2; if (a.y < 14) ay += (14 - a.y) * 2; if (a.y > 456) ay -= (a.y - 456) * 2; }
    const am = (a.st === -1 ? 120 : 200) * vit; let al = Math.hypot(ax, ay); if (al > am) { ax *= am / al; ay *= am / al; }
    a.vx += ax * dt; a.vy += ay * dt;
    const vm = (a.st === -1 ? 72 : 110) * vit, sp = Math.hypot(a.vx, a.vy); if (sp > vm) { a.vx *= vm / sp; a.vy *= vm / sp; }
    a.vx *= 1 - Math.min(1, dt * .5); a.vy *= 1 - Math.min(1, dt * .5);
    a.x += a.vx * dt; a.y += a.vy * dt;
    const cible = a.lookOn ? a.look : sp > 4 ? Math.atan2(a.vy, a.vx) : a.cap;
    a.cap += wrapA(cible - a.cap) * Math.min(1, dt * (a.lookOn ? 4 : 2.5));
    a.fl = Math.max(0, a.fl - dt * 1.6);
    a.trT += dt; if (a.trT > .07) { a.trT = 0; a.tr.copyWithin(2, 0, 14); a.tr[0] = a.x; a.tr[1] = a.y; if (a.trN < 8) a.trN++; }
  }
  /* impulsions, ondes, étincelles */
  for (const o of F.IMP) if (o.on && T - o.t0 >= o.d) { o.on = false; if (o.ri >= 0) { const e = cur.E[o.ri]; if (e) { e.fl = Math.max(e.fl, .75); e.gon = Math.max(e.gon, .5); onde(e.x, e.y, 6, 40, .8, e.T.col, .5); } } else { const r = A[o.b]; r.fl = 1; r.got = T; r.de = o.a; } }
  for (const o of F.RGF) if (o.on && T - o.t0 >= o.d) o.on = false;
  for (const p of F.SPK) if (p.on) { if (T - p.t0 >= p.d) p.on = false; else { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 1 - dt * .8; p.vy = p.vy * (1 - dt * .8) - 4 * dt; } }
}
/* ── dessin ── */
/* R474 · figurants plus fins : membrane à double contour (pellicule épaisse au front, fine au flanc), organites lisibles
   (noyau + nucléole, vacuoles contractiles qui battent, vacuoles digestives en cyclose, chloroplastes, granules), cils fins et
   nombreux en vague métachrone, flagelle ondulant, photophores minuscules (bien moins que les créatures actives).
   Trois niveaux de détail selon le plan : lointain (silhouette douce, flou), médian, proche. Respiration et micro-mouvements. */
const FD = { cil: [0, 10, 18], ten: [2, 3, 6], gr: [0, 3, 6] };
function fMembrane(ctx, A, lw, s, fa, ka, kb) {             // voile large et bas (épaisseur) + filet net : double trait
  ctx.globalAlpha = A * fa; ctx.fill();
  ctx.globalAlpha = A * ka; ctx.lineWidth = 2.4 * lw / s; ctx.stroke();
  ctx.globalAlpha = A * kb; ctx.lineWidth = .7 * lw / s; ctx.stroke();
}
function fLisse(ctx, X, Y, HW, sd, k, rev) {                 // bord lisse d'un ruban (courbes par les milieux)
  const n = X.length - 1, P = j => [X[j], Y[j] + sd * HW[j] * k];
  if (!rev) { let p = P(0); ctx.moveTo(p[0], p[1]); for (let j = 1; j < n; j++) { const a = P(j), b = P(j + 1); ctx.quadraticCurveTo(a[0], a[1], (a[0] + b[0]) / 2, (a[1] + b[1]) / 2); } }
  else { let p = P(n); ctx.lineTo(p[0], p[1]); for (let j = n - 1; j > 0; j--) { const a = P(j), b = P(j - 1); ctx.quadraticCurveTo(a[0], a[1], (a[0] + b[0]) / 2, (a[1] + b[1]) / 2); } }
}
function fCorps(ctx, a, A, t, z) {
  const s = a.taille * zp(FPL.sc, z) * a.mul * (1 + .08 * a.puls), lw = zp(FPL.lw, z), st = Math.round(Math.min(3, z) * 2), col = FCS[a.col][st], perle = FCS[2][st];
  const spd = Math.min(1, Math.hypot(a.vx, a.vy) / 40), nv = z < .6 ? 0 : z < 1.6 ? 1 : 2;      // niveau de détail : lointain · médian · proche
  ctx.save(); ctx.translate(a.rx, a.ry); ctx.rotate(a.cap + .06 * Math.sin(t * 1.7 + a.ph)); ctx.scale(s, s);
  ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const br = 1 + .045 * Math.sin(t * 1.35 + a.ph), c = (1 - .22 * a.puls) * br, ph = a.ph, wv = t * 2.6 + a.p1, fin = .5 * lw / s;
  const ilum = .35 + .65 * a.lum;                               // lueur interne (organites) : suit la conversation, reste basse
  let nx = .35, ny = 0;                                         // position du noyau
  if (a.morph === 0) {                                          // MÉDUSE : ombrelle à mésoglée épaisse, canaux, manubrium, tentacules
    const w = .85 * c;
    ctx.beginPath(); ctx.moveTo(-.35, -w); ctx.bezierCurveTo(-.1, -w * 1.2, .95, -w * .85, 1.05, 0); ctx.bezierCurveTo(.95, w * .85, -.1, w * 1.2, -.35, w);
    ctx.quadraticCurveTo(-.05 - .2 * a.puls, 0, -.35, -w);
    fMembrane(ctx, A, lw, s, .13, nv ? .13 : .22, nv ? .62 : .42);
    if (nv) {
      ctx.beginPath(); ctx.moveTo(-.18, -w * .78); ctx.bezierCurveTo(.05, -w * .95, .72, -w * .62, .8, 0); ctx.bezierCurveTo(.72, w * .62, .05, w * .95, -.18, w * .78);   // paroi interne
      ctx.moveTo(.8, 0); ctx.quadraticCurveTo(.3, -w * .25, -.25, -w * .55); ctx.moveTo(.8, 0); ctx.quadraticCurveTo(.3, w * .25, -.25, w * .55); ctx.moveTo(.8, 0); ctx.lineTo(-.2, 0);   // canaux radiaires
      ctx.globalAlpha = A * .3; ctx.lineWidth = fin; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(.9, -w * .42); ctx.quadraticCurveTo(1.08, 0, .9, w * .42); ctx.globalAlpha = A * .22; ctx.lineWidth = 1.1 * lw / s; ctx.stroke();   // mésoglée plus épaisse à l'apex
      ctx.beginPath(); for (let k = -1; k <= 1; k += 2) { ctx.moveTo(.32 + .05 * k, k * w * .36); ctx.ellipse(.32, k * w * .36, .15, .07, k * .5, 0, TAU); }   // gonades
      ctx.globalAlpha = A * .22; ctx.fill(); ctx.globalAlpha = A * .4; ctx.lineWidth = fin; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(.25, 0); for (let j = 1; j <= 4; j++) ctx.lineTo(.25 - j * .17, Math.sin(wv * .8 - j) * .05 * j);   // manubrium
      ctx.globalAlpha = A * .45; ctx.lineWidth = .9 * lw / s; ctx.stroke();
    }
    const nt = FD.ten[nv], L = 2.0 + .8 * spd;
    ctx.beginPath();
    for (let k = 0; k < nt; k++) {
      const u = nt === 1 ? .5 : k / (nt - 1), y0 = (u * 2 - 1) * w * .92, Lk = L * (.7 + .3 * Math.sin(k * 2.3 + 1)); ctx.moveTo(-.3 + .1 * Math.abs(u * 2 - 1), y0);
      for (let j = 1; j <= 6; j++) ctx.lineTo(-.3 - j * Lk / 6, y0 * (1 - .06 * j) + Math.sin(wv - j * .85 + k * 1.3) * (.04 + .045 * j));
    }
    ctx.globalAlpha = A * (nv ? .38 : .3); ctx.lineWidth = (nv === 2 ? .38 : .5) * lw / s; ctx.stroke();
    if (nv) {                                                    // photophores du bord de l'ombrelle (onde lente)
      ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = perle;
      for (let k = 0; k < 5; k++) { const u = k / 4, y0 = (u * 2 - 1) * w * .95, f = .5 + .5 * Math.sin(t * 2.2 - k * 1.1 + ph); ctx.globalAlpha = A * (.12 + .4 * f * f * ilum); ctx.beginPath(); ctx.arc(-.3 + .1 * Math.abs(u * 2 - 1), y0, .045, 0, TAU); ctx.fill(); }
      ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = col;
    }
  } else if (a.morph === 1) {                                   // CILIÉ : pellicule, rangées de peignes, cils en vague, cyclose
    const ry = .5 * (1 + .22 * a.puls) * br;
    ctx.beginPath(); ctx.ellipse(0, 0, 1.25, ry, 0, 0, TAU);
    fMembrane(ctx, A, lw, s, .12, nv ? .12 : .2, nv ? .6 : .4);
    if (nv) {
      ctx.beginPath(); ctx.ellipse(-.03, 0, 1.08, ry * .74, 0, 0, TAU); ctx.globalAlpha = A * .28; ctx.lineWidth = fin; ctx.stroke();   // ectoplasme / endoplasme
      ctx.beginPath(); ctx.ellipse(0, 0, 1.25, ry, 0, -.55, .55); ctx.globalAlpha = A * .5; ctx.lineWidth = 1.6 * lw / s; ctx.stroke();   // pellicule plus épaisse au front
      const nc = FD.cil[nv], cl = .2 + .04 * spd;                 // cils : vague métachrone (chaque cil un peu en retard sur son voisin)
      ctx.beginPath();
      for (let k = 0; k < nc; k++) {
        const th = k / nc * TAU, ex = Math.cos(th) * 1.25, ey = Math.sin(th) * ry, nxk = Math.cos(th) * ry, nyk = Math.sin(th) * 1.25, nn = Math.hypot(nxk, nyk) || 1;
        const sw = .7 * Math.sin(wv * 2.2 - k * .62), dx = nxk / nn, dy = nyk / nn, tx = -dy, ty = dx;
        ctx.moveTo(ex, ey); ctx.quadraticCurveTo(ex + dx * cl * .6 + tx * sw * cl * .3, ey + dy * cl * .6 + ty * sw * cl * .3, ex + (dx + tx * sw) * cl, ey + (dy + ty * sw) * cl);
      }
      ctx.globalAlpha = A * .34; ctx.lineWidth = .32 * lw / s; ctx.stroke();
      ctx.setLineDash(DASH); ctx.lineDashOffset = -t * 1.6 - ph * .1;   // rangées de peignes (irisation), plus fines
      ctx.beginPath(); ctx.moveTo(-1.05, 0); ctx.quadraticCurveTo(0, -.62 * ry / .5, 1.05, 0); ctx.moveTo(-1.05, 0); ctx.quadraticCurveTo(0, .62 * ry / .5, 1.05, 0);
      ctx.globalAlpha = A * (.3 + .45 * a.lum); ctx.lineWidth = .75 * lw / s; ctx.stroke(); ctx.setLineDash(NODASH);
      const vc = .5 + .5 * Math.sin(t * 2.9 + ph), vr = .05 + .075 * vc;   // vacuoles contractiles : elles battent en alternance
      ctx.beginPath(); ctx.moveTo(.72 + vr, .02); ctx.arc(.72, .02, vr, 0, TAU); const vr2 = .05 + .075 * (1 - vc); ctx.moveTo(-.72 + vr2, -.02); ctx.arc(-.72, -.02, vr2, 0, TAU);
      for (let k = 0; k < 3; k++) { const an = t * .55 + k * 2.1 + ph, vx = Math.cos(an) * .62, vy = Math.sin(an) * ry * .45, rr = .07 + .02 * k; ctx.moveTo(vx + rr, vy); ctx.arc(vx, vy, rr, 0, TAU); }   // vacuoles digestives en cyclose
      ctx.globalAlpha = A * .42; ctx.lineWidth = fin; ctx.stroke(); ctx.globalAlpha = A * .1; ctx.fill();
    }
    ctx.beginPath(); const L = 3 + spd;                          // deux longs fils traînants
    for (let k = -1; k <= 1; k += 2) { ctx.moveTo(-1.2, k * .15); for (let j = 1; j <= 6; j++) ctx.lineTo(-1.2 - j * L / 6, k * (.15 + j * .09) + Math.sin(wv * 1.1 - j * .8 + k) * (.05 + .055 * j)); }
    ctx.globalAlpha = A * .32; ctx.lineWidth = .4 * lw / s; ctx.stroke();
    nx = .02; ny = 0;
  } else {                                                      // FLAGELLÉ : ruban à pellicule striée, chloroplastes, stigma, flagelle
    const X = [], Yc = [], HW = [];
    for (let j = 0; j <= 6; j++) { X.push(1 - j * .55); Yc.push(Math.sin(wv - j * .9) * .3 * (j / 6 + .2)); HW.push(.55 * Math.sin(Math.PI * (j + .6) / 7.2) * c); }
    HW[0] *= .55; HW[6] *= .4;                                   // pointes effilées
    ctx.beginPath(); fLisse(ctx, X, Yc, HW, -1, 1, false); ctx.quadraticCurveTo(X[6] - .2, Yc[6], X[6], Yc[6] + HW[6]); fLisse(ctx, X, Yc, HW, 1, 1, true); ctx.quadraticCurveTo(X[0] + .22, Yc[0], X[0], Yc[0] - HW[0]); ctx.closePath();
    fMembrane(ctx, A, lw, s, .12, nv ? .12 : .2, nv ? .55 : .38);
    if (nv) {
      ctx.beginPath(); fLisse(ctx, X, Yc, HW, -1, .62, false); ctx.lineTo(X[6], Yc[6] + HW[6] * .62); fLisse(ctx, X, Yc, HW, 1, .62, true); ctx.closePath();
      ctx.globalAlpha = A * .26; ctx.lineWidth = fin; ctx.stroke();
      ctx.beginPath(); for (let j = 1; j <= 5; j++) { const u = j - .5; ctx.moveTo(X[j] + .1, Yc[j] - HW[j] * .8); ctx.quadraticCurveTo(X[j] + .02 * Math.sin(u), Yc[j], X[j] - .1, Yc[j] + HW[j] * .8); }   // stries obliques de la pellicule
      ctx.globalAlpha = A * .12; ctx.stroke();
      ctx.beginPath(); for (let j = 1; j <= 4; j++) { const x = X[j] + .1 * Math.sin(t * .7 + j), y = Yc[j] + HW[j] * .25 * Math.sin(j * 2.1 + ph); ctx.moveTo(x + .13, y); ctx.ellipse(x, y, .13, .06, .4 * Math.sin(j + ph), 0, TAU); }   // chloroplastes
      ctx.globalAlpha = A * .3; ctx.fill(); ctx.globalAlpha = A * .45; ctx.lineWidth = .35 * lw / s; ctx.stroke();
      if (nv === 2) { ctx.beginPath(); for (let j = 1; j <= 6; j++) for (let sd = -1; sd <= 1; sd += 2) { const y = Yc[j] + sd * HW[j], q = Math.sin(wv * 2 - j * 1.1 + sd); ctx.moveTo(X[j], y); ctx.lineTo(X[j] - .1 - .06 * q, y + sd * (.12 + .04 * q)); } ctx.globalAlpha = A * .3; ctx.lineWidth = .3 * lw / s; ctx.stroke(); }
    }
    ctx.beginPath(); ctx.moveTo(1.02, Yc[0]); const LF = 1.3 + .3 * spd;   // flagelle antérieur : il bat devant, l'onde part de la base
    for (let j = 1; j <= 8; j++) ctx.lineTo(1.02 + j * LF / 8, Yc[0] + Math.sin(t * 7 + a.p1 - j * .75) * .04 * j);
    ctx.globalAlpha = A * .4; ctx.lineWidth = .4 * lw / s; ctx.stroke();
    nx = .35 - .55; ny = Yc[1];
    if (nv) { ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = FCS[3][st]; ctx.globalAlpha = A * (.35 + .4 * ilum); ctx.beginPath(); ctx.arc(.82, Yc[0] - .08, .055, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = col; }   // stigma (tache oculaire)
  }
  if (nv) {                                                     // granules : poussière vivante, qui dérive lentement
    const ng = FD.gr[nv]; ctx.beginPath();
    for (let k = 0; k < ng; k++) { const an = t * (.3 + .07 * k) + k * 2.4 + ph, rr = .18 + .2 * ((k * 37) % 5) / 5, gx = nx + Math.cos(an) * rr * 1.5, gy = ny + Math.sin(an) * rr * .6; ctx.moveTo(gx + .03, gy); ctx.arc(gx, gy, .03, 0, TAU); }
    ctx.fillStyle = perle; ctx.globalAlpha = A * .45; ctx.fill();
  }
  /* noyau : enveloppe + nucléole ; il s'allume avec la pulsation (c'est par lui qu'elles se « parlent ») */
  const nr = (a.morph === 1 ? .22 : .17) + .05 * a.puls, na = Math.min(1, A * (.45 + .6 * a.lum + .8 * a.puls + 1.4 * a.fl));
  ctx.fillStyle = perle; ctx.strokeStyle = perle;
  if (nv) {
    ctx.beginPath(); ctx.ellipse(nx, ny, nr * (a.morph === 1 ? 1.35 : 1), nr, 0, 0, TAU); ctx.globalAlpha = na * .22; ctx.fill(); ctx.globalAlpha = na * .7; ctx.lineWidth = .45 * lw / s; ctx.stroke();
    ctx.globalCompositeOperation = 'lighter'; ctx.beginPath(); ctx.arc(nx + nr * .2, ny - nr * .15, nr * .38, 0, TAU); ctx.globalAlpha = na * .85; ctx.fill(); ctx.globalCompositeOperation = 'source-over';
  } else { ctx.beginPath(); ctx.arc(nx, ny, nr * .8, 0, TAU); ctx.globalAlpha = na * .7; ctx.fill(); }
  ctx.restore();
}
function fUn(ctx, F, a, t) {
  const z = a.zc, A = a.ap; if (A < .008 || a.x < -40 || a.x > 400 || a.y < -40 || a.y > 510) return;
  const st = Math.round(Math.min(3, z) * 2), s = a.taille * zp(FPL.sc, z) * a.mul;
  ctx.globalCompositeOperation = 'lighter';
  if (z > 1.5 && a.trN > 2) {                                         // sillage (plans proches seulement)
    ctx.strokeStyle = FCS[a.col][st]; ctx.lineCap = 'round';
    const sp = Math.min(1, Math.hypot(a.vx, a.vy) / 50), ox = a.rx - a.x, oy = a.ry - a.y;
    if (sp > .2) for (let j = 1; j < a.trN; j++) { ctx.globalAlpha = A * .35 * sp * (1 - j / a.trN); ctx.lineWidth = (1.6 * (1 - j / a.trN) + .3) * (z > 2.5 ? 1.8 : 1); ctx.beginPath(); ctx.moveTo(a.tr[j * 2 - 2] + ox, a.tr[j * 2 - 1] + oy); ctx.lineTo(a.tr[j * 2] + ox, a.tr[j * 2 + 1] + oy); ctx.stroke(); }
  }
  const Rg = s * (z < .6 ? 4 : 3) * (1 + .3 * a.puls + 1.2 * a.fl);
  ctx.globalAlpha = Math.min(1, A * (.9 + 1.1 * a.lum + 1.2 * a.puls * (.3 + a.lum) + 1.8 * a.fl)); ctx.drawImage(FSP[a.col][st], a.rx - Rg, a.ry - Rg, Rg * 2, Rg * 2);
  ctx.globalCompositeOperation = 'source-over';
  fCorps(ctx, a, A, t, z);
}
function fVis(F, a, S, b) {                                         // pâlit près de ce qu'il faut lire
  let f = 1;
  if (b) f = Math.min(f, lisse(16, a.zc > 2.5 ? 120 : 64, Math.hypot(a.x - b.x, a.y - b.y)));
  for (const z of cur.Z) f = Math.min(f, lisse(z[2] * .5, z[2] * 1.2, Math.hypot(a.x - z[0], a.y - z[1])));
  for (const w of cur.murs) f = Math.min(f, lisse(3, 22, dSeg(a.x, a.y, w)));
  const st = S && S.strokes;
  if (st) for (let k = 0; k < st.length && k < 6; k++) { const P = st[k].pts; if (!P) continue; const stp = Math.max(1, (P.length / 6) | 0); for (let j = 0; j < P.length; j += stp) f = Math.min(f, lisse(6, 28, Math.hypot(a.x - P[j][0], a.y - P[j][1]))); }
  if (cur.cr) for (const c of cur.cr) f = Math.min(f, lisse(c.r || c.rc || 30, (c.r || c.rc || 30) + 30, Math.hypot(a.x - c.x, a.y - c.y)));
  return f;
}
function fDessinerFond(ctx, dt, S, b, fondu) {
  const F = cur.F, t = F.t, A = F.A;
  /* parallaxe : les plans glissent les uns contre les autres (houle lente + position de la bille) */
  const bxN = b ? (b.x - 180) / 180 : 0, byN = b ? (b.y - 235) / 235 : 0;
  F.pbx = (F.pbx || 0) + (bxN - (F.pbx || 0)) * Math.min(1, dt * 1.5); F.pby = (F.pby || 0) + (byN - (F.pby || 0)) * Math.min(1, dt * 1.5);
  const DX = F.pbx * 9 + 8 * Math.sin(t * .045), DY = F.pby * 7 + 6 * Math.sin(t * .037 + 1);
  for (let i = 0; i < F.n; i++) {
    const a = A[i], k = zp(FPL.par, a.zc); a.rx = a.x + k * DX; a.ry = a.y + k * DY;
    let cible = zp(FPL.al, a.zc) * (.2 + .8 * fVis(F, a, S, b)) * a.dim;
    if (F.av === i) cible = Math.min(.55, cible * (.9 + .2 * a.lum));
    a.ap += (cible - a.ap) * Math.min(1, dt * 3);
  }
  /* ordre de dessin : du lointain au proche */
  const o = F.ord; for (let i = 1; i < 9; i++) { const v = o[i]; let j = i - 1; while (j >= 0 && A[o[j]].zc > A[v].zc) { o[j + 1] = o[j]; j--; } o[j + 1] = v; }
  /* spores des rondes */
  ctx.globalCompositeOperation = 'lighter';
  for (const s of F.SL) if (s.on && s.type === 'ronde' && s.tp > .01) {
    const pu = .6 + .4 * Math.max(0, Math.sin(t * TAU * .8)), R = 7 + 6 * pu;
    ctx.globalAlpha = Math.min(1, .55 * s.tp * fondu); ctx.drawImage(FSP[2][3], s.x - R * 1.8, s.y - R * 1.8, R * 3.6, R * 3.6);
    ctx.fillStyle = FCS[2][3]; ctx.globalAlpha = .5 * s.tp * fondu; ctx.beginPath(); ctx.arc(s.x, s.y, 1.6 + pu, 0, TAU); ctx.fill();
  }
  for (const p of F.SPK) if (p.on) { const u = (t - p.t0) / p.d; ctx.globalAlpha = .5 * (1 - u) * fondu; ctx.drawImage(FSP[2][3], p.x - 5, p.y - 5, 10, 10); }
  /* liens fugaces */
  ctx.lineCap = 'round';
  for (let k = 0; k < F.nLK; k++) {
    const a = A[F.LKa[k]], bb = F.LKb[k] >= 0 ? A[F.LKb[k]] : null, x2 = bb ? bb.rx : F.LKx[k], y2 = bb ? bb.ry : F.LKy[k];
    const w = Math.min(a.ap, bb ? bb.ap : a.ap) / .43, mx = (a.rx + x2) / 2 + 6 * Math.sin(t * 3 + k), my = (a.ry + y2) / 2 + 6 * Math.cos(t * 2.4 + k);
    ctx.strokeStyle = FCS[a.col][Math.round(Math.min(3, a.zc) * 2)]; ctx.globalAlpha = Math.min(1, 1.6 * F.LKal[k] * w * fondu); ctx.lineWidth = 1.1;
    ctx.beginPath(); ctx.moveTo(a.rx, a.ry); ctx.quadraticCurveTo(mx, my, x2, y2); ctx.stroke();
  }
  /* impulsions lumineuses en chemin */
  for (const p of F.IMP) {
    if (!p.on) continue;
    const a = A[p.a], u = Math.min(1, (t - p.t0) / p.d); let x2, y2, w;
    if (p.ri >= 0) { const e = cur.E[p.ri]; x2 = e.x; y2 = e.y; w = a.ap / .43; } else { const bb = A[p.b]; x2 = bb.rx; y2 = bb.ry; w = Math.min(a.ap, bb.ap) / .43; }
    const d = Math.hypot(x2 - a.rx, y2 - a.ry) || 1, cx = (a.rx + x2) / 2 - (y2 - a.ry) / d * d * .22, cy = (a.ry + y2) / 2 + (x2 - a.rx) / d * d * .22, st = Math.round(Math.min(3, a.zc) * 2);
    ctx.strokeStyle = FCS[p.c][st]; ctx.globalAlpha = Math.min(1, .34 * w * fondu); ctx.lineWidth = .8;
    ctx.beginPath(); ctx.moveTo(a.rx, a.ry); for (let j = 1; j <= 8; j++) { const v = j / 8 * u; ctx.lineTo(q(v, a.rx, cx, x2), q(v, a.ry, cy, y2)); } ctx.stroke();
    ctx.globalAlpha = Math.min(1, 1.2 * w * fondu); const hx = q(u, a.rx, cx, x2), hy = q(u, a.ry, cy, y2); ctx.drawImage(FSP[p.c][Math.min(6, st + 2)], hx - 9, hy - 9, 18, 18);
  }
  for (const r of F.RGF) { if (!r.on) continue; const u = (t - r.t0) / r.d, rr = r.r0 + (r.r1 - r.r0) * (1 - (1 - u) * (1 - u)); ctx.strokeStyle = FCS[r.c][Math.round(Math.min(3, r.s) * 2)]; ctx.globalAlpha = Math.min(1, r.a * zp(FPL.al, r.s) * 2 * (1 - u) * fondu); ctx.lineWidth = .6 + 1.6 * (1 - u); ctx.beginPath(); ctx.arc(r.x, r.y, rr, 0, TAU); ctx.stroke(); }
  ctx.globalCompositeOperation = 'source-over';
  /* les figurants, du lointain au proche ; celui de l'avant-plan sera dessiné par-dessus le jeu */
  for (let k = 0; k < 9; k++) { const i = o[k]; if (i >= F.n || i === F.av) continue; fUn(ctx, F, A[i], t); }
  ctx.globalAlpha = 1;
}
function figurants(ctx, dt, dts, lent, S, b, run) {
  if (!cur.F) return;
  const t0 = performance.now();
  figPas(dts, S, b, run, false, lent);
  fDessinerFond(ctx, dt, S, b, cur.fondu);
  const F = cur.F; F.ms = performance.now() - t0;
  fmes.n++; fmes.s += F.ms; if (F.ms > fmes.max) fmes.max = F.ms;
  F.nb[0]++; if (F.nb[0] > 6) F.ems = F.nb[0] < 9 ? F.ms : F.ems * .92 + F.ms * .08;
}
function figAvant(ctx, lv, env) {                                   // calque d'avant-plan (après la bille et les traits)
  if (!cur || !cur.F || cur.idx !== lv.idx) return;
  const F = cur.F; if (F.av < 0) return;
  const t0 = performance.now();
  try { fUn(ctx, F, F.A[F.av], F.t); } finally { ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
  const d = performance.now() - t0; fmes.s += d; fmes.av += d; fmes.nav++;
}
const fmes = { n: 0, s: 0, max: 0, av: 0, nav: 0 };
function visibles() { let p = 0; return cur.E.filter(e => { if (p + e.poids > PAL[cur.pal][0] + 1e-6) return false; p += e.poids; return true; }); }
// ===== ETAGE 5 DEBUT (R484 · Monde 5, Soufflerie — « l'air qui porte ») =====
/* Deux créatures actives tirées des vidéos de Simon (lot 2), transposées en palette froide, formes continues translucides :
   CLIONE (ange de mer, V3) : corps en fuseau d'un seul contour, tête ronde à deux petites cornes, deux ailes en miroir qui battent,
     viscère menthe lumineux vu par transparence, cils fins à la queue. Effet (fluides.js, t:'clione') : PORTE EN VOL PLANÉ — il nage
     vers la bille, se glisse dessous, l'agrippe de ses cônes buccaux et la porte à vitesse tenue, pesanteur et vent compensés ;
     chaque coup d'ailes la soulève un peu (battement calé sur la physique).
   VER À RAMES (Tomopteris, V4) : long fuseau translucide, rangée de rames frangées qui battent en onde métachronale (la vague court
     de la queue à la tête), couronne de tentacules fins devant, deux longs tentacules traînants. Effet (t:'rames') : TAPIS ONDULANT —
     la bille prise le long du corps est portée par le courant des rames jusqu'à la tête, où les tentacules la guident à la sortie.
   Effet de particule de l'étage : AIGRETTES — la particule portée porte une couronne de soies et sème de minuscules graines à aigrette
     qui montent en tournant et clignent au rythme du mot de la créature.
   Décor du Monde 5 (figurants nouveaux) : graines à aigrette, spore-mère et ses petits, planeurs en banc, fils de la vierge.
   Comportements sociaux nouveaux : relais lumineux (les aigrettes se passent une lueur le long d'un fil), mère-petits (les petits
   s'écartent puis reviennent), suivi en banc (les planeurs suivent la meneuse en échelon), évitement poli (deux voisins s'écartent
   en se saluant d'un éclat), poursuite joueuse (un fil de la vierge en poursuit un autre). Rendu seul : aucune incidence sur la physique. */
TEINTE.clione = { c1: [150, 196, 255], c2: [238, 246, 255], c3: [10, 20, 58], ac: [140, 255, 214] };   // clione : bleu glacé, liseré blanc, viscère menthe
TEINTE.rames = { c1: [112, 232, 240], c2: [226, 255, 252], c3: [6, 28, 46], ac: [190, 172, 255] };    // ver à rames : cyan, rames blanches, lueurs lilas
MOT.clione = [0, .1, .17]; MOT.rames = [0, .05, .1];                                                  // clione · · — · ; ver : trois perles rapides
SCOL[10] = 'rgba(150,196,255,'; SCOL[11] = 'rgba(112,232,240,';
const E5T = { clione: 1, rames: 1 };
function e5Poil(ctx, x0, y0, nx, ny, L, dx, dy, w) {   // poil fluide (copie locale : base, normale, longueur, dérive, ondulation)
  const tx = -ny, ty = nx;
  ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 + nx * L * .55 + tx * w * .5 + dx * .35, y0 + ny * L * .55 + ty * w * .5 + dy * .35, x0 + nx * L + tx * w + dx, y0 + ny * L + ty * w + dy);
}
function e5Ferme(ctx, X, Y, n) {                     // contour fermé lisse (milieux + quadratiques) : aucun angle
  ctx.moveTo((X[n - 1] + X[0]) / 2, (Y[n - 1] + Y[0]) / 2);
  for (let i = 0; i < n; i++) { const j = (i + 1) % n; ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[j]) / 2, (Y[i] + Y[j]) / 2); }
}
function e5Flag(b, fr, f) {
  for (const e of act.E) if (E5T[e.c.t]) { const st = (b.cs && b.cs[e.i]) || {}; if (st.h || (st.out && fr >= st.out && fr - st.out < 40)) f = e.c.t === 'clione' ? 10 : 11; }
  return f;
}
function e5Etat(c, st, fr, etat) {
  if (!E5T[c.t]) return etat;
  if (st.h) return 2;
  if (st.out && fr >= st.out && fr - st.out < 50) return 3;
  return etat;
}
/* ── R489 · REPASSE GRAPHIQUE (langage des figurants : SYSTOLE pour le clione, CORTÈGE pour le ver) ──
   Même silhouette, mêmes proportions, même mouvement et même logique de jeu qu'en R487 ; seul le RENDU change.
   Tout le raffinement est PRÉ-RENDU une fois (atlas d'images clés) : membranes à plusieurs couches (dégradé caché, pellicule
   plus dense au bord, paroi interne, stries, nervures), bords doux (voile large + filet fin), poils fluides, granules, noyau.
   En jeu : quelques drawImage (rotation, échelle, miroir) + les seuls tracés qui dépendent du jeu (cônes, tentacules). */
const E5PX = 6;                                       // pixels d'atlas par unité locale (≈ iPhone ×3 à l'échelle 1,35)
const E5A = {};
function e5Can(w, h) { const k = document.createElement('canvas'); k.width = Math.ceil(w); k.height = Math.ceil(h); return k; }
const e5rgba = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
function e5Mix(a, b, k) { return [Math.round(a[0] + (b[0] - a[0]) * k), Math.round(a[1] + (b[1] - a[1]) * k), Math.round(a[2] + (b[2] - a[2]) * k)]; }
function e5Doux(g, c, lw, a) {                        // bord doux : trois passes (voile large, mi-voile, filet)
  g.strokeStyle = e5rgba(c, a * .1); g.lineWidth = lw * 4.2; g.stroke();
  g.strokeStyle = e5rgba(c, a * .22); g.lineWidth = lw * 1.9; g.stroke();
  g.strokeStyle = e5rgba(c, a); g.lineWidth = lw * .55; g.stroke();
}
/* ── CLIONE ── repère local : y vers le bas = de la tête (−) à la queue (+), x latéral ; une unité = 1 px du niveau */
const CLR = [[0, -15.1], [.7, -15.3], [1.05, -16.9], [1.4, -15.3], [3.1, -14.4], [4.2, -12], [4.25, -9.2], [3.9, -6.6], [4.8, -3], [5.8, 1.6], [5.3, 6.6], [3.8, 11], [2, 14.8], [.7, 18.2]];
const CWX = new Float32Array(12), CWY = new Float32Array(12);
const CLN = CLR.length * 2, CLX = new Float32Array(CLN + 2), CLY = new Float32Array(CLN + 2);
const CLW_U = [[-.2, -2.4], [.42, -4.3], [.86, -4], [1.06, -.6], [.98, 3.4], [.62, 4.6], [.2, 3.8], [-.2, 2.6]];   // aile R487 (même palette), base élargie et fondue dans le flanc
const NWK = 24, NBK = 32, WL0 = 13.4, WBX = 3, WBY = 9, WBW = 22;   // images clés : 24 phases d'aile, 16 phases de corps
function clioneAtlas(TT) {
  const k0 = 'cl' + TT.c1.join(); if (E5A[k0]) return E5A[k0];
  const P = E5PX, C1 = TT.c1, C2 = TT.c2, C3 = TT.c3, CA = TT.ac, PER = e5Mix(C2, [255, 255, 255], .4);
  /* AILES : 24 images clés de la DÉFORMATION (flexion, onde de phase, creusement) ; la rotation du battement reste continue au blit */
  const fw = (WBW + WBX) * P, fh = WBY * 2 * P, AW = e5Can(fw * 6, fh * 4), g = AW.getContext('2d'), AV = e5Can(fw * 6, fh * 4), gv = AV.getContext('2d');
  g.lineCap = 'round'; g.lineJoin = 'round'; gv.lineCap = 'round';
  for (let f = 0; f < NWK; f++) {
    const wb = f / NWK * TAU, sb = Math.sin(wb), cb = Math.cos(wb), fl = -cb * 3.4, cup = 1 - .1 * sb;
    g.setTransform(P, 0, 0, P, (f % 6) * fw + WBX * P, ((f / 6) | 0) * fh + WBY * P);
    const def = (u, v) => [u * WL0, v * cup + fl * u * u + .55 * Math.sin(wb - u * 3.4) * u];
    for (let j = 0; j < 8; j++) { const q = def(CLW_U[j][0], CLW_U[j][1]); CWX[j] = q[0]; CWY[j] = q[1]; }
    g.beginPath(); e5Ferme(g, CWX, CWY, 8); g.closePath();
    const rg = g.createRadialGradient(0, 0, 0, 2, 0, WL0 * 1.1);           // pellicule : claire au bord, dense au bout, presque vide à la base
    rg.addColorStop(0, e5rgba(C3, .32)); rg.addColorStop(.35, e5rgba(C1, .14)); rg.addColorStop(.7, e5rgba(C1, .24)); rg.addColorStop(.92, e5rgba(C2, .34)); rg.addColorStop(1, e5rgba(C2, .2));
    g.fillStyle = rg; g.fill();
    e5Doux(g, C2, .5, .34);
    g.save(); g.clip();
    g.beginPath(); for (let j = 1; j < 7; j++) { const q = def(CLW_U[j][0] * .8, CLW_U[j][1] * .74); j === 1 ? g.moveTo(q[0], q[1]) : g.lineTo(q[0], q[1]); }   // paroi interne (épaisseur de la membrane)
    g.strokeStyle = e5rgba(C2, .2); g.lineWidth = .35; g.stroke();
    g.beginPath();                                                            // nervures : éventail depuis l'épaule, elles suivent la flexion
    for (let j = 0; j < 5; j++) { const vv = -3.2 + j * 1.6, m = def(.5, vv * .5), e2 = def(.98 - .1 * Math.abs(vv) / 4, vv); g.moveTo(.2, vv * .15); g.quadraticCurveTo(m[0], m[1], e2[0], e2[1]); }
    g.strokeStyle = e5rgba(PER, .2); g.lineWidth = .24; g.stroke();
    g.strokeStyle = e5rgba(C1, .08); g.lineWidth = 1.1; g.stroke();
    gv.setTransform(P, 0, 0, P, (f % 6) * fw + WBX * P, ((f / 6) | 0) * fh + WBY * P);   // calque lumineux des nervures (allumé par les pulsations)
    for (let j = 0; j < 5; j++) { const vv = -3.2 + j * 1.6, m = def(.5, vv * .5), e2 = def(.98 - .1 * Math.abs(vv) / 4, vv), lg2 = gv.createLinearGradient(0, 0, e2[0], e2[1]);
      lg2.addColorStop(0, e5rgba(CA, .8)); lg2.addColorStop(.6, e5rgba(C1, .4)); lg2.addColorStop(1, e5rgba(CA, .7));
      gv.beginPath(); gv.moveTo(.2, vv * .15); gv.quadraticCurveTo(m[0], m[1], e2[0], e2[1]); gv.strokeStyle = lg2; gv.globalAlpha = .18; gv.lineWidth = 1.6; gv.stroke(); gv.globalAlpha = .8; gv.lineWidth = .32; gv.stroke(); }
    gv.globalAlpha = 1;
    gv.beginPath(); e5Ferme(gv, CWX, CWY, 8); gv.closePath(); gv.strokeStyle = e5rgba(CA, .3); gv.lineWidth = .4; gv.stroke(); gv.strokeStyle = e5rgba(C1, .1); gv.lineWidth = 2; gv.stroke();
    g.beginPath();                                                            // stries fines transverses (muscle) : l'onde de phase se lit
    for (let j = 1; j < 6; j++) { const u = j / 6.2, a2 = def(u, -4.1 * Math.sin(Math.PI * Math.min(1, u + .1))), b2 = def(u, 4.3 * Math.sin(Math.PI * Math.min(1, u + .12))), m2 = def(u + .04, 0); g.moveTo(a2[0], a2[1]); g.quadraticCurveTo(m2[0], m2[1], b2[0], b2[1]); }
    g.strokeStyle = e5rgba(C2, .09); g.lineWidth = .3; g.stroke();
    g.restore();
    g.beginPath();                                                            // poils fluides du bord de fuite (traînent derrière le coup)
    for (let j = 0; j < 14; j++) { const u = .25 + j * .058, v = 3.5 + 1.1 * Math.sin(Math.PI * Math.min(1, u)), b0 = def(u, v), l = .9 + .4 * Math.sin(j * 1.7), dx = -cb * .6 * u, dy = 1;
      g.moveTo(b0[0], b0[1]); g.quadraticCurveTo(b0[0] + dx * .5 + .3 * Math.sin(wb + j), b0[1] + dy * l * .5, b0[0] + dx - .4 * sb, b0[1] + dy * l); }
    g.strokeStyle = e5rgba(C2, .3); g.lineWidth = .22; g.stroke();
    g.globalCompositeOperation = 'lighter';                                   // trois photophores minuscules le long du bord d'attaque
    for (let j = 0; j < 3; j++) { const q = def(.45 + j * .22, -3.9 + j * .9), r2 = g.createRadialGradient(q[0], q[1], 0, q[0], q[1], 1.3);
      r2.addColorStop(0, e5rgba(PER, .9)); r2.addColorStop(.3, e5rgba(C1, .35)); r2.addColorStop(1, e5rgba(C1, 0)); g.fillStyle = r2; g.fillRect(q[0] - 1.3, q[1] - 1.3, 2.6, 2.6); }
    g.globalCompositeOperation = 'destination-out';                          // la racine de l'aile se fond dans le flanc (aucun trait de jonction)
    const fo = g.createRadialGradient(-1, 0, 0, -1, 0, 5.5); fo.addColorStop(0, 'rgba(0,0,0,.92)'); fo.addColorStop(.55, 'rgba(0,0,0,.45)'); fo.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = fo; g.fillRect(-WBX, -WBY, 10, WBY * 2);
    gv.globalCompositeOperation = 'destination-out'; const fo2 = gv.createRadialGradient(-1, 0, 0, -1, 0, 5.5); fo2.addColorStop(0, 'rgba(0,0,0,.92)'); fo2.addColorStop(.55, 'rgba(0,0,0,.45)'); fo2.addColorStop(1, 'rgba(0,0,0,0)'); gv.fillStyle = fo2; gv.fillRect(-WBX, -WBY, 10, WBY * 2); gv.globalCompositeOperation = 'source-over';
    g.globalCompositeOperation = 'source-over';
  }
  /* CORPS : 16 images clés de l'ondulation de la queue (même contour que R487) ; fond sombre interne + pellicule + organes */
  const bw = 26 * P, bh = 42 * P, BY0 = 19, AB = e5Can(bw * 8, bh * 4), h = AB.getContext('2d');
  h.lineCap = 'round'; h.lineJoin = 'round';
  for (let f = 0; f < NBK; f++) {
    const W = f / NBK * TAU, sw = yl => 1.1 * Math.sin(W - yl * .14) * cl01((yl + 4) / 22);
    h.setTransform(P, 0, 0, P, (f % 8) * bw + 13 * P, ((f / 8) | 0) * bh + BY0 * P);
    const nR = CLR.length; let k = 0;
    for (let i = 0; i < nR; i++) { CLX[k] = CLR[i][0] + sw(CLR[i][1]); CLY[k] = CLR[i][1]; k++; }
    CLX[k] = sw(19.6); CLY[k] = 19.6; k++;
    for (let i = nR - 1; i >= 1; i--) { CLX[k] = -CLR[i][0] + sw(CLR[i][1]); CLY[k] = CLR[i][1]; k++; }
    h.beginPath(); e5Ferme(h, CLX, CLY, k); h.closePath();
    const lg = h.createLinearGradient(-6.2, 0, 6.2, 0);                       // pellicule dense aux flancs, cœur sombre et transparent
    lg.addColorStop(0, e5rgba(C2, .5)); lg.addColorStop(.12, e5rgba(C1, .3)); lg.addColorStop(.32, e5rgba(C3, .5)); lg.addColorStop(.5, e5rgba(C3, .56));
    lg.addColorStop(.68, e5rgba(C3, .5)); lg.addColorStop(.88, e5rgba(C1, .3)); lg.addColorStop(1, e5rgba(C2, .5));
    h.fillStyle = lg; h.fill();
    const hg = h.createRadialGradient(0, -12.5, 0, 0, -12.5, 5.5);             // tête plus claire (mésoglée épaisse)
    hg.addColorStop(0, e5rgba(C1, .26)); hg.addColorStop(1, e5rgba(C1, 0)); h.fillStyle = hg; h.fill();
    const vg = h.createLinearGradient(0, 8, 0, 19.6);                         // la queue s'efface
    vg.addColorStop(0, e5rgba(C1, 0)); vg.addColorStop(1, e5rgba(C2, .2)); h.fillStyle = vg; h.fill();
    const rimG = (al) => { const q = h.createLinearGradient(0, -17, 0, 20); q.addColorStop(0, e5rgba(C2, al)); q.addColorStop(.2, e5rgba(C2, al)); q.addColorStop(.3, e5rgba(C2, al * .3));
      q.addColorStop(.38, e5rgba(C2, al * .45)); q.addColorStop(.5, e5rgba(C2, al)); q.addColorStop(1, e5rgba(C2, al * .7)); return q; };   // le liseré s'efface à l'épaule (racine des ailes) : un seul tenant
    h.strokeStyle = rimG(.05); h.lineWidth = .58 * 4.2; h.stroke(); h.strokeStyle = rimG(.11); h.lineWidth = .58 * 1.9; h.stroke(); h.strokeStyle = rimG(.5); h.lineWidth = .58 * .55; h.stroke();
    h.save(); h.clip();
    h.beginPath(); for (let s = -1; s <= 1; s += 2) { h.moveTo(s * .4 + sw(-14), -14); for (let i = 5; i < nR; i++) h.lineTo(s * CLR[i][0] * .72 + sw(CLR[i][1]), CLR[i][1]); }   // paroi interne
    h.strokeStyle = e5rgba(C2, .2); h.lineWidth = .4; h.stroke();
    h.beginPath(); for (const fx of [-.42, -.2, .2, .42]) { h.moveTo(fx * 4 + sw(-8), -8); for (let y = -5; y <= 16; y += 3) h.lineTo(fx * 5.6 * (1 - Math.max(0, y - 4) / 17) + sw(y), y); }   // stries longitudinales
    h.strokeStyle = e5rgba(C2, .08); h.lineWidth = .35; h.stroke();
    h.beginPath(); h.ellipse(sw(-11.5), -11.4, 2.2, 1.7, 0, 0, TAU);          // ganglion céphalique (discret)
    h.fillStyle = e5rgba(C1, .1); h.fill(); h.strokeStyle = e5rgba(C2, .16); h.lineWidth = .25; h.stroke();
    h.beginPath(); h.moveTo(sw(1), 1); h.quadraticCurveTo(sw(-6) + .4, -7, sw(-11), -11);   // tube digestif
    h.strokeStyle = e5rgba(CA, .12); h.lineWidth = 1.6; h.stroke(); h.strokeStyle = e5rgba(CA, .28); h.lineWidth = .35; h.stroke();
    h.beginPath(); h.ellipse(sw(4.6), 4.6, 2.5, 4.6, 0, 0, TAU);              // viscère : un seul sac fusiforme (vu par transparence), dégradé interne
    const vgr = h.createRadialGradient(sw(4.2) - .4, 3.6, 0, sw(4.6), 4.6, 4.8); vgr.addColorStop(0, e5rgba(e5Mix(CA, [255, 255, 255], .35), .55)); vgr.addColorStop(.55, e5rgba(CA, .28)); vgr.addColorStop(1, e5rgba(CA, .06));
    h.fillStyle = vgr; h.fill(); h.strokeStyle = e5rgba(CA, .28); h.lineWidth = .3; h.stroke();
    h.beginPath(); for (let j = 0; j < 4; j++) { const yy = 1.6 + j * 1.9; h.moveTo(sw(yy) - 1.9 + .3 * Math.abs(j - 1.5), yy); h.quadraticCurveTo(sw(yy), yy + .6, sw(yy) + 1.9 - .3 * Math.abs(j - 1.5), yy); }   // plis internes
    h.strokeStyle = e5rgba(CA, .16); h.lineWidth = .25; h.stroke();
    h.beginPath(); h.ellipse(sw(-1.6) + .2, -1.5, 1.7, 1.9, 0, 0, TAU); h.fillStyle = 'rgba(196,170,255,.3)'; h.fill();   // gonade lilas
    h.beginPath();                                                            // granules (cyclose figée dans l'image clé : ils bougent avec elle)
    for (let j = 0; j < 26; j++) { const yy = -13 + ((j * 37) % 31), xx = (hs(j * 1.7) - .5) * 2 * Math.max(.8, 4.4 - Math.abs(yy - 1) * .22) + sw(yy), r = .18 + .2 * hs(j); h.moveTo(xx + r, yy); h.arc(xx, yy, r, 0, TAU); }
    h.fillStyle = e5rgba(PER, .42); h.fill();
    h.restore();
    h.beginPath(); for (let s = -1; s <= 1; s += 2) { h.moveTo(s * .5 + sw(-15), -15.4); h.quadraticCurveTo(s * 1.1 + sw(-16), -16.4, s * 1.05 + sw(-16.9), -16.9); }   // cornes : filet plus vif
    h.strokeStyle = e5rgba(PER, .55); h.lineWidth = .45; h.stroke();
    h.beginPath();                                                            // cils fins de la tête (couronne céphalique)
    for (let j = 0; j < 9; j++) { const a = -2.4 + j * .1 * 6.2 / 8 * 1.6, x0 = Math.cos(a) * 3.6 + sw(-12), y0 = -12 + Math.sin(a) * 3.2; h.moveTo(x0, y0); h.quadraticCurveTo(x0 + Math.cos(a) * .6 + .3 * Math.sin(W + j), y0 + Math.sin(a) * .6, x0 + Math.cos(a) * 1.2 + .5 * Math.sin(W + j), y0 + Math.sin(a) * 1.2 + .3); }
    h.strokeStyle = e5rgba(C2, .28); h.lineWidth = .22; h.stroke();
  }
  return (E5A[k0] = { AW, AV, fw, fh, AB, bw, bh, BY0 });
}
function dessinerClione(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, V = e.vit, AC = e.ac, held = run && st.h && b, br = (b && b.r) || 8, SC = c.sc || 1.35;   // SC : échelle (plus grand qu'un figurant)
  const AT = e.atl || (e.atl = clioneAtlas(e.T));
  /* battement : calé sur la physique pendant le portage (chaque coup soulève la bille) */
  const per = c.per || 22, wb = held ? (fr - st.in) * TAU / per - Math.PI / 2 : T * (2.4 + 2.2 * V) + e.ph;
  const sb = Math.sin(wb), cb = Math.cos(wb);
  /* cible du corps : sous la bille (portage) ou à l'ancrage + rencontre (eox, eoy) + errance */
  const dir = held ? st.dir : (e.cdir || 1);
  let tx, ty, ta;
  if (held) { ta = dir * .5; const dd = 15.5 * SC + br + 1.2; tx = b.x - Math.sin(ta) * dd; ty = b.y + Math.cos(ta) * dd; }
  else {
    tx = x + (run ? st.eox || 0 : 0) + e.wx * 3; ty = y + (run ? st.eoy || 0 : 0) + e.wy * 2.2 - 1.4 * Math.max(0, sb);
    ta = .12 * Math.sin(e.tl * .5 + e.ph);
    if (etat === 1 && b) { const a2 = Math.atan2(b.x - tx, -(b.y - ty)); ta += Math.max(-.6, Math.min(.6, a2)) * .7; }
  }
  const kp = 1 - Math.exp(-dt * (held ? 20 : st.out && fr - st.out < 30 ? 2.5 : 5));
  if (e.cx == null || !run && fr <= 1 && e.cxr !== 1) { e.cx = tx; e.cy = ty; e.ang = ta; e.cxr = 1; }
  e.cx += (tx - e.cx) * kp; e.cy += (ty - e.cy) * kp; e.ang += (ta - e.ang) * kp; e.ang = e.ang > .8 ? .8 : e.ang < -.8 ? -.8 : e.ang;   // tête toujours vers le haut
  if (held) e.cdir = st.dir;
  const bx = e.cx, by = e.cy, ca = Math.cos(e.ang), sa = Math.sin(e.ang);
  e.lx = bx; e.ly = by - 6;
  ombre(ctx, e, bx, by + 4, 16 * SC, 22 * SC, e.ang, .5);
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; spr(ctx, e.SG, bx, by - 2 * SC, (24 + 6 * AC) * SC, .12 + .14 * AC); ctx.restore();   // halo pré-rendu derrière
  ctx.save(); ctx.translate(bx, by); ctx.rotate(e.ang); ctx.scale(SC, SC); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const W = e.tl * 1.9 + e.ph, sw = yl => 1.1 * Math.sin(W - yl * .14) * cl01((yl + 4) / 22);   // la queue ondule (même loi que l'image clé)
  /* ailes (parapodes) : image clé de la déformation (onde de phase) × rotation continue du battement ; miroir pour l'autre aile */
  const amp = .72 + .25 * AC, Lw = 12.5 + 2 * AC + 1.2 * V, WT = e.wt || (e.wt = new Float32Array(4)), kx = Lw / WL0, ky = 1 + .15 * AC;
  const wf = (((wb % TAU) + TAU) % TAU) / TAU * NWK, fi = Math.floor(wf) % NWK, fj = (fi + 1) % NWK, fu = wf - Math.floor(wf);   // fondu entre deux images clés voisines (« lighter » : exact)
  const sxw = (fi % 6) * AT.fw, syw = ((fi / 6) | 0) * AT.fh, sxj = (fj % 6) * AT.fw, syj = ((fj / 6) | 0) * AT.fh;
  const pw = Math.pow(.5 + .5 * Math.sin(e.tl * 1.1 + e.ph * 2), 3), fl5 = e.fl5 = Math.max(0, (e.fl5 || 0) - dt * 1.2), h0 = e.h5;   // pulsation lente ; éclair à la prise
  if (held && !h0) e.fl5 = 1; e.h5 = !!held;
  ctx.globalCompositeOperation = 'lighter';
  for (let s = -1; s <= 1; s += 2) {
    const a0 = -.15 + amp * sb, an = s > 0 ? a0 : Math.PI - a0, cA = Math.cos(an), sA = Math.sin(an), fl = -cb * 3.4;
    ctx.save(); ctx.translate(s * 3, -5.4); ctx.rotate(an); ctx.scale(kx, s > 0 ? ky : -ky);
    const aw = (.82 + .18 * AC) * (s * dir > 0 ? 1 : .8);                    // profondeur : l'aile du côté opposé à la nage est plus pâle
    ctx.globalAlpha = aw * (1 - fu); ctx.drawImage(AT.AW, sxw, syw, AT.fw, AT.fh, -WBX, -WBY, WBW + WBX, WBY * 2);
    ctx.globalAlpha = aw * fu; ctx.drawImage(AT.AW, sxj, syj, AT.fw, AT.fh, -WBX, -WBY, WBW + WBX, WBY * 2);
    const lum = cl01(.06 + .45 * pw + .55 * AC + .6 * fl5);                  // nervures lumineuses : pulsation + prise de la bille
    if (lum > .02) { ctx.globalAlpha = lum * (1 - fu); ctx.drawImage(AT.AV, sxw, syw, AT.fw, AT.fh, -WBX, -WBY, WBW + WBX, WBY * 2); ctx.globalAlpha = lum * fu; ctx.drawImage(AT.AV, sxj, syj, AT.fw, AT.fh, -WBX, -WBY, WBW + WBX, WBY * 2); }
    const uu = (e.tl * .7 + e.ph + (s > 0 ? 0 : .5)) % 1.4;                  // une perle de lumière remonte le bord d'attaque jusqu'au bout
    if (uu < 1) spr(ctx, e.SP, uu * WL0 * 1.02, -3.9 * Math.sin(Math.PI * Math.min(1, uu * .9 + .1)) * (1 - .1 * sb) - cb * 3.4 * uu * uu, 1.5, .8 * Math.sin(Math.PI * uu));
    ctx.restore();
    const u = 1.06, v = -.6 * ky + fl * u * u, nx = -sA * s, ny = cA * s;
    WT[s > 0 ? 0 : 2] = s * 3 + cA * Lw * u + nx * v; WT[s > 0 ? 1 : 3] = -5.4 + sA * Lw * u + ny * v;
  }
  for (let s = 0; s < 2; s++) { spr(ctx, e.SP, WT[2 * s], WT[2 * s + 1], 2 + 1.2 * AC, .45 + .3 * pw + .4 * AC); spr(ctx, e.SG, WT[2 * s], WT[2 * s + 1], 5 + 3 * fl5, .12 + .25 * fl5); }   // points de lumière au bout des ailes
  /* corps : image clé de l'ondulation (16 phases) */
  const bf = Math.round((((W % TAU) + TAU) % TAU) / TAU * NBK) % NBK;
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.drawImage(AT.AB, (bf % 8) * AT.bw, ((bf / 8) | 0) * AT.bh, AT.bw, AT.bh, -13, -AT.BY0, 26, 42);
  /* lumière interne (vivante) : viscère qui respire, onde qui remonte le tube digestif, yeux */
  ctx.globalCompositeOperation = 'lighter';
  const pv = .5 + .5 * Math.sin(e.tl * 1.4 + e.ph);
  spr(ctx, e.SA, sw(4.2), 3.8, 4 + 1.5 * pv + 2.5 * AC, .35 + .2 * pv + .25 * AC);
  spr(ctx, e.SAG, sw(4.5), 4.5, 10 + 4 * AC + 6 * fl5, .2 + .15 * pv + .2 * AC + .3 * fl5);
  spr(ctx, e.SG, sw(-12), -12.5, 6 + 2 * pw, .1 + .12 * pw + .15 * AC);
  const ow = (e.tl * .45 + e.ph) % 1.6; if (ow < 1) { const yy = 3 - ow * 14.5; spr(ctx, e.SA, sw(yy), yy, 2.2, .55 * Math.sin(Math.PI * ow)); }
  spr(ctx, e.SP, 1.6 + sw(-11.5), -11.5, 1.2, .75); spr(ctx, e.SP, -1.6 + sw(-11.5), -11.5, 1.2, .75);
  spr(ctx, e.SP, 1.05 + sw(-17), -17, .9, .5 + .3 * pv); spr(ctx, e.SP, -1.05 + sw(-17), -17, .9, .5 + .3 * pv);
  /* cônes buccaux : la « cage » qui sort de la tête et agrippe la bille (alerte → portage), puis se rétracte — bord doux, bouts perlés */
  const exT = held ? 1 : etat === 1 ? .35 + .3 * (e.ex || 0) : etat === 3 ? .4 : 0;
  e.cg5 = (e.cg5 || 0) + (exT - (e.cg5 || 0)) * Math.min(1, dt * (exT > (e.cg5 || 0) ? 8 : 3));
  if (e.cg5 > .03) {
    let lbx = 0, lby = -15 - (br + 1.2) / SC;
    if (b && (held || etat === 1)) { const dx = b.x - bx, dy = b.y - by; lbx = (ca * dx + sa * dy) / SC; lby = (-sa * dx + ca * dy) / SC; }
    ctx.beginPath(); let ex = 0, ey = 0; const TX = e.cgt || (e.cgt = new Float32Array(6));
    for (let j = 0; j < 3; j++) { const o = (j - 1) * .95, gx = lbx + Math.sin(o) * br * 1.05 / SC, gy = lby + Math.cos(o) * br * .95 / SC, u = e.cg5;
      const hx = (j - 1) * 1.3, hy = -14.6; ex = hx + (gx - hx) * u; ey = hy + (gy - hy) * u;
      ctx.moveTo(hx, hy); ctx.quadraticCurveTo(hx + (j - 1) * 4 * u + Math.sin(T * 5 + j) * .8, (hy + ey) / 2, ex, ey); TX[j * 2] = ex; TX[j * 2 + 1] = ey; }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = .1 * e.cg5; ctx.lineWidth = 4.2; ctx.stroke();   // cônes : voile large, mi-voile, filet ténu (tentacules gélatineux, pas des baguettes)
    ctx.globalAlpha = .2 * e.cg5; ctx.lineWidth = 1.8; ctx.stroke();
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .42 * e.cg5; ctx.lineWidth = .5; ctx.stroke();
    for (let j = 0; j < 3; j++) spr(ctx, e.SP, TX[j * 2], TX[j * 2 + 1], 1.6, .7 * e.cg5);
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* micro-bulles aux pointes des ailes à chaque coup (descente) */
  const Q = e.Q, rate = held ? 3.5 : etat === 1 ? 1.6 : .45;
  e.bT -= dt * rate * Math.max(0, sb);
  if (e.bT <= 0) { for (let s = 0; s < 2; s++) { const lx = WT[2 * s] * SC, ly = WT[2 * s + 1] * SC; emP(Q, 0, bx + ca * lx - sa * ly, by + sa * lx + ca * ly, (s ? -1 : 1) * 4 - dir * (held ? 6 : 0), 6, 1 + .6 * hs(fr + s), .9 + .5 * hs(fr * 3 + s)); } e.bT = .45 + .3 * hs(fr * 7); }
  majPart(Q, dt); dessinerPart(ctx, Q, e);
}
/* ── VER À RAMES ── repère local : x le long de l'axe (queue −L/2 → tête +L/2), y latéral
   R489 : même géométrie que R487 (fuseau, 14 points, rames 2..11 des deux côtés, onde métachronale, couronne, traînants) ;
   rendu pré-rendu : corps = 16 images clés de l'ondulation (L0 = 110, étiré à L), rame = 24 images clés de la déformation,
   les deux fondues deux à deux en « lighter » (aucun saut) ; sous le corps, un seul remplissage sombre vivant (profondeur). */
const RMN = 14, RMX = new Float32Array(RMN), RMY = new Float32Array(RMN), RMW = new Float32Array(RMN), RMNX = new Float32Array(RMN), RMNY = new Float32Array(RMN), ROX = new Float32Array(RMN * 2 + 4), ROY = new Float32Array(RMN * 2 + 4);
const RL0 = 110, RA0 = 2.3, NRB = 16, NRR = 24, RPX = 5, RRL = 7.5, RRX = 1.5, RRW = 15, RRH = 7;   // corps : longueur et amplitude de référence ; rame : 7,5 u (+ franges)
function ramesGeo(L, W, A) {                          // axe ondulant, demi-largeurs et normales (même loi qu'en R487)
  for (let k = 0; k < RMN; k++) {
    const u = k / (RMN - 1); RMX[k] = -L / 2 + u * L; RMY[k] = A * Math.sin(W - (1 - u) * 5.2) * (.4 + .6 * (1 - u));   // R489 : la tête mène, le corps suit (onde tête → queue, amplitude croissante)
    RMW[k] = u < .5 ? .7 + 4.6 * Math.sin(u / .5 * Math.PI / 2) : 5.3 - 2 * (u - .5) / .5;
  }
  for (let k = 0; k < RMN; k++) { const k0 = Math.max(0, k - 1), k1 = Math.min(RMN - 1, k + 1), dx = RMX[k1] - RMX[k0], dy = RMY[k1] - RMY[k0], l = Math.hypot(dx, dy) || 1; RMNX[k] = -dy / l; RMNY[k] = dx / l; }
}
function ramesContour(ctx, L) {                       // contour fermé du corps (queue effilée, fuseau, tête arrondie)
  let n = 0;
  for (let k = 0; k < RMN; k++) { ROX[n] = RMX[k] + RMNX[k] * RMW[k]; ROY[n] = RMY[k] + RMNY[k] * RMW[k]; n++; }
  ROX[n] = L / 2 + 3.4; ROY[n] = RMY[RMN - 1]; n++;
  for (let k = RMN - 1; k >= 0; k--) { ROX[n] = RMX[k] - RMNX[k] * RMW[k]; ROY[n] = RMY[k] - RMNY[k] * RMW[k]; n++; }
  ROX[n] = -L / 2 - 4; ROY[n] = RMY[0]; n++;
  ctx.beginPath(); e5Ferme(ctx, ROX, ROY, n); ctx.closePath();
}
function ramesAtlas(TT) {
  const k0 = 'rm' + TT.c1.join(); if (E5A[k0]) return E5A[k0];
  const P = RPX, C1 = TT.c1, C2 = TT.c2, C3 = TT.c3, CA = TT.ac, PER = e5Mix(C2, [255, 255, 255], .4);
  /* CORPS : additif (la profondeur sombre est le remplissage vivant dessous) */
  const bw = (RL0 + 12) * P, bh = 22 * P, AB = e5Can(bw * 2, bh * 8), h = AB.getContext('2d');
  h.lineCap = 'round'; h.lineJoin = 'round';
  for (let f = 0; f < NRB; f++) {
    const W = f / NRB * TAU; ramesGeo(RL0, W, RA0);
    h.setTransform(P, 0, 0, P, (f % 2) * bw + (RL0 / 2 + 6) * P, ((f / 2) | 0) * bh + 11 * P);
    ramesContour(h, RL0);
    const lg = h.createLinearGradient(0, -6.5, 0, 6.5);                       // pellicule dense aux flancs, presque vide au milieu
    lg.addColorStop(0, e5rgba(C2, .42)); lg.addColorStop(.16, e5rgba(C1, .22)); lg.addColorStop(.42, e5rgba(C1, .06)); lg.addColorStop(.58, e5rgba(C1, .06)); lg.addColorStop(.84, e5rgba(C1, .22)); lg.addColorStop(1, e5rgba(C2, .42));
    h.fillStyle = lg; h.fill();
    const tg = h.createLinearGradient(-RL0 / 2 - 4, 0, RL0 / 2 + 3, 0);        // profondeur : la queue s'efface, la tête est plus claire
    tg.addColorStop(0, e5rgba(C3, 0)); tg.addColorStop(.25, e5rgba(C1, .03)); tg.addColorStop(.85, e5rgba(C1, .1)); tg.addColorStop(1, e5rgba(C2, .22)); h.fillStyle = tg; h.fill();
    e5Doux(h, C2, .55, .5);
    h.save(); h.clip();
    h.beginPath();                                                            // paroi interne
    for (let s = -1; s <= 1; s += 2) { for (let k = 1; k < RMN; k++) { const x = RMX[k] + RMNX[k] * RMW[k] * .66 * s, y = RMY[k] + RMNY[k] * RMW[k] * .66 * s; k === 1 ? h.moveTo(x, y) : h.lineTo(x, y); } }
    h.strokeStyle = e5rgba(C2, .16); h.lineWidth = .35; h.stroke();
    h.beginPath();                                                            // anneaux (segments) : arcs transverses fins, un par rame et un entre deux
    for (let k = 1; k < RMN - 1; k++) for (let hh = 0; hh < 2; hh++) { const x = RMX[k] + hh * (RMX[k + 1] - RMX[k]) * .5, yc = RMY[k] + hh * (RMY[k + 1] - RMY[k]) * .5, w = RMW[k] * .95;
      h.moveTo(x - .3, yc - w); h.quadraticCurveTo(x + .9, yc, x - .3, yc + w); }
    h.strokeStyle = e5rgba(C2, .1); h.lineWidth = .3; h.stroke();
    h.beginPath();                                                            // granules
    for (let j = 0; j < 46; j++) { const u = .06 + .9 * hs(j * 2.3), k = Math.min(RMN - 1, Math.round(u * (RMN - 1))), x = -RL0 / 2 + u * RL0, y = RMY[k] + (hs(j * 5.1) - .5) * 1.5 * RMW[k], r = .16 + .2 * hs(j); h.moveTo(x + r, y); h.arc(x, y, r, 0, TAU); }
    h.fillStyle = e5rgba(PER, .4); h.fill();
    h.restore();
    h.beginPath(); h.moveTo(RMX[1], RMY[1]); for (let k = 2; k < RMN - 1; k++) h.lineTo(RMX[k], RMY[k] + .25 * Math.sin(k * 1.9));   // tube digestif lilas
    h.strokeStyle = e5rgba(CA, .1); h.lineWidth = 3.2; h.stroke(); h.strokeStyle = e5rgba(CA, .3); h.lineWidth = 1.2; h.stroke(); h.strokeStyle = e5rgba(e5Mix(CA, [255, 255, 255], .5), .45); h.lineWidth = .3; h.stroke();
    const hx = RL0 / 2, hy = RMY[RMN - 1];                                     // tête : deux yeux minuscules, mésoglée claire
    h.beginPath(); h.arc(hx - 1.2, hy - 1.5, .45, 0, TAU); h.arc(hx - 1.2, hy + 1.5, .45, 0, TAU); h.fillStyle = e5rgba(PER, .7); h.fill();
  }
  /* RAME : palette membraneuse (pinnule) + peigne dense de soies au bord distal ; la déformation (flexion, onde) est dans l'image clé */
  const rw = (RRW + RRX) * P, rh = RRH * 2 * P, AR = e5Can(rw * 6, rh * 4), g = AR.getContext('2d');
  g.lineCap = 'round'; g.lineJoin = 'round';
  const RX = new Float32Array(10), RY = new Float32Array(10);
  for (let f = 0; f < NRR; f++) {
    const ph = f / NRR * TAU, c1 = Math.cos(ph), s1 = Math.sin(ph);
    g.setTransform(P, 0, 0, P, (f % 6) * rw + RRX * P, ((f / 6) | 0) * rh + RRH * P);
    const def = (x, y) => { const u = x / RRL; return [x, y + 1.8 * c1 * u * u + .5 * Math.sin(ph - u * 3) * u]; };
    const SH = [[-.4, -.45], [2.5, -.8], [5.2, -1.9], [7.3, -2.2], [8.3, -1], [8.1, .3], [7.4, 1.6], [5.3, 1.9], [2.6, .9], [-.4, .45]];   // pinnule : étroite à la base, large et arrondie au bout
    for (let j = 0; j < 10; j++) { const q = def(SH[j][0], SH[j][1] * (1 - .12 * s1)); RX[j] = q[0]; RY[j] = q[1]; }
    g.beginPath(); e5Ferme(g, RX, RY, 10); g.closePath();
    const rg = g.createRadialGradient(0, 0, 0, 1, 0, 9);
    rg.addColorStop(0, e5rgba(C1, .08)); rg.addColorStop(.5, e5rgba(C1, .2)); rg.addColorStop(.85, e5rgba(C2, .34)); rg.addColorStop(1, e5rgba(C2, .2));
    g.fillStyle = rg; g.fill(); e5Doux(g, C2, .45, .45);
    g.beginPath(); for (let j = -1; j <= 1; j++) { const a2 = def(0, 0), m = def(4, j * .7), e2 = def(7.6, j * 1.4); g.moveTo(a2[0], a2[1]); g.quadraticCurveTo(m[0], m[1], e2[0], e2[1]); }   // nervures (acicule au centre)
    g.strokeStyle = e5rgba(PER, .3); g.lineWidth = .22; g.stroke(); g.strokeStyle = e5rgba(C1, .1); g.lineWidth = .9; g.stroke();
    g.beginPath();                                                            // peigne : 15 soies fines, elles traînent derrière le coup (retard de phase)
    for (let j = 0; j < 15; j++) { const t = j / 14, an = -1.15 + t * 2.3, bx = 7.6 + Math.cos(an) * .9, by = Math.sin(an) * 2.05, b0 = def(bx, by), l = 2.6 + 1.1 * Math.sin(t * Math.PI) + .4 * hs(j);
      const dx = Math.cos(an * .55), dy = Math.sin(an * .55), lag = -1.3 * c1 - .4, w = .5 * Math.sin(ph * 2 + j * .7);
      g.moveTo(b0[0], b0[1]); g.quadraticCurveTo(b0[0] + dx * l * .55 - dy * w, b0[1] + dy * l * .55 + lag * .35 + dx * w, b0[0] + dx * l, b0[1] + dy * l + lag); }
    g.strokeStyle = e5rgba(C1, .1); g.lineWidth = .9; g.stroke(); g.strokeStyle = e5rgba(C2, .42); g.lineWidth = .2; g.stroke();
    g.globalCompositeOperation = 'lighter';                                   // glande lumineuse au bout de la pinnule
    const q = def(7.2, 0), r2 = g.createRadialGradient(q[0], q[1], 0, q[0], q[1], 1.6);
    r2.addColorStop(0, e5rgba(PER, .9)); r2.addColorStop(.3, e5rgba(CA, .4)); r2.addColorStop(1, e5rgba(CA, 0)); g.fillStyle = r2; g.fillRect(q[0] - 1.6, q[1] - 1.6, 3.2, 3.2);
    g.globalCompositeOperation = 'source-over';
  }
  return (E5A[k0] = { AB, bw, bh, AR, rw, rh });
}
function dessinerRames(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, V = e.vit, AC = e.ac, held = run && st.h && b, L = c.L || 120, a = (c.a || 0) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
  const AT = e.atl || (e.atl = ramesAtlas(e.T));
  const eop = run ? st.eop || 0 : 0, bob = 1.4 * Math.sin(e.tl * .6 + e.ph);
  const cx = x - sa * (eop + bob), cy = y + ca * (eop + bob);
  e.lx = cx + ca * L * .45; e.ly = cy + sa * L * .45;
  const ub = held ? cl01((st.u || 0) / L) : -1;      // où est la bille le long du corps (0 queue → 1 tête)
  const pw = Math.pow(.5 + .5 * Math.sin(e.tl * .9 + e.ph * 2), 3), fl5 = e.fl5 = Math.max(0, (e.fl5 || 0) - dt * 1.1);   // respiration lumineuse ; éclair à la prise
  if (held && !e.h5) e.fl5 = 1; e.h5 = !!held;
  ombre(ctx, e, cx, cy + 5, L * .5, 11, a, .45);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let j = 0; j < 3; j++) spr(ctx, e.SG, cx + ca * L * (j - 1) * .3, cy + sa * L * (j - 1) * .3, 18 + 4 * AC + 8 * fl5, .07 + .08 * AC + .12 * fl5 + .03 * pw);   // halo doux le long du corps
  ctx.restore();
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(a); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const W = e.tl * 2.3 + e.ph; ramesGeo(L, W, RA0);
  ctx.globalCompositeOperation = 'lighter';
  /* rames : image clé de la déformation (fondu de deux voisines) × angle du battement (continu) ; un côté un peu plus pâle (profondeur) */
  const om = T * (3.2 + 2.2 * V + 2.4 * AC) + e.ph, PT = e.pt || (e.pt = new Float32Array(RMN * 8));
  let np = 0; const m0 = ctx.getTransform(), ma = m0.a, mb = m0.b, mc = m0.c, md = m0.d, me = m0.e, mf = m0.f;   // R489 : matrice composée à la main (pas de save/restore par rame)
  for (let k = 2; k < RMN - 2; k++) {
    const u = k / (RMN - 1), ph = om - k * .8, s1 = Math.sin(ph), c1 = Math.cos(ph), near = ub >= 0 ? Math.exp(-Math.pow((u - ub) / .14, 2)) : 0;
    const rf = (((ph % TAU) + TAU) % TAU) / TAU * NRR, i0 = Math.floor(rf) % NRR, i1 = (i0 + 1) % NRR, fu = rf - Math.floor(rf);
    for (let s = -1; s <= 1; s += 2) {
      const bxl = RMX[k] + RMNX[k] * RMW[k] * s * .85, byl = RMY[k] + RMNY[k] * RMW[k] * s * .85;
      const an = Math.atan2(RMNY[k] * s, RMNX[k] * s) + s * (.62 + .38 * s1 * (1 + .6 * near)), Lp = (6.6 + 1.1 * Math.sin(k * 1.3) + 1.4 * AC + 2 * near) * (.75 + .25 * Math.sin(u * Math.PI));
      const cA = Math.cos(an), sA = Math.sin(an), bend = 1.8 * c1 * s, kx = Lp / RRL, al = (s > 0 ? 1 : .78) * (.85 + .15 * AC + .3 * near);
      const la = cA * kx, lb = sA * kx, lc = -sA * s, ld = cA * s;
      ctx.setTransform(ma * la + mc * lb, mb * la + md * lb, ma * lc + mc * ld, mb * lc + md * ld, ma * bxl + mc * byl + me, mb * bxl + md * byl + mf);
      if (fu < .97) { ctx.globalAlpha = Math.min(1, al * (1 - fu)); ctx.drawImage(AT.AR, (i0 % 6) * AT.rw, ((i0 / 6) | 0) * AT.rh, AT.rw, AT.rh, -RRX, -RRH, RRW + RRX, RRH * 2); }
      if (fu > .03) { ctx.globalAlpha = Math.min(1, al * fu); ctx.drawImage(AT.AR, (i1 % 6) * AT.rw, ((i1 / 6) | 0) * AT.rh, AT.rw, AT.rh, -RRX, -RRH, RRW + RRX, RRH * 2); }
      PT[np * 4] = bxl + cA * Lp * .96 - sA * bend; PT[np * 4 + 1] = byl + sA * Lp * .96 + cA * bend; PT[np * 4 + 2] = u; PT[np * 4 + 3] = near; np++;
    }
  }
  ctx.setTransform(m0);
  /* corps : profondeur (un remplissage sombre vivant) puis la pellicule pré-rendue, fondue entre deux images clés */
  ramesContour(ctx, L);
  ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.K3; ctx.globalAlpha = .42; ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  const bf = (((W % TAU) + TAU) % TAU) / TAU * NRB, j0 = Math.floor(bf) % NRB, j1 = (j0 + 1) % NRB, bu = bf - Math.floor(bf), sx = L / RL0, ab = .9 + .1 * AC;
  ctx.save(); ctx.scale(sx, 1);
  ctx.globalAlpha = ab * (1 - bu); ctx.drawImage(AT.AB, (j0 % 2) * AT.bw, ((j0 / 2) | 0) * AT.bh, AT.bw, AT.bh, -RL0 / 2 - 6, -11, RL0 + 12, 22);
  ctx.globalAlpha = ab * bu; ctx.drawImage(AT.AB, (j1 % 2) * AT.bw, ((j1 / 2) | 0) * AT.bh, AT.bw, AT.bh, -RL0 / 2 - 6, -11, RL0 + 12, 22);
  ctx.restore();
  /* bioluminescence : lueurs aux bases des rames (vague queue → tête, ou autour de la bille), perles au bout des pinnules, pulsation qui court dans le tube */
  for (let k = 3; k < RMN - 2; k += 2) { const u = k / (RMN - 1), w = ub >= 0 ? Math.exp(-Math.pow((u - ub) / .12, 2)) : ondeA(e, u);
    spr(ctx, e.SA, RMX[k] + RMNX[k] * RMW[k] * .9, RMY[k] + RMNY[k] * RMW[k] * .9, 1.6 + 2.4 * w, .3 + .6 * w);
    spr(ctx, e.SA, RMX[k] - RMNX[k] * RMW[k] * .9, RMY[k] - RMNY[k] * RMW[k] * .9, 1.4 + 2 * w, .22 + .5 * w); }
  for (let q = 0; q < np; q++) { const u = PT[q * 4 + 2], w = Math.max(PT[q * 4 + 3], ondeA(e, u), fl5 * Math.exp(-Math.pow((u - (ub >= 0 ? ub : .5)) / (.15 + .6 * (1 - fl5)), 2)));
    spr(ctx, e.SP, PT[q * 4], PT[q * 4 + 1], 1.3 + 1.6 * w, .25 + .2 * pw + .55 * w); }
  const gp = (e.tl * .5 + e.ph) % 1.5; if (gp < 1) { const kk = Math.min(RMN - 2, 1 + gp * (RMN - 3)), k = kk | 0, f = kk - k, gx = RMX[k] + (RMX[k + 1] - RMX[k]) * f, gy = RMY[k] + (RMY[k + 1] - RMY[k]) * f, ia = Math.sin(Math.PI * gp);
    spr(ctx, e.SAG, gx, gy, 7, .25 * ia); spr(ctx, e.SA, gx, gy, 2.4, .6 * ia); }
  if (ub >= 0) { const k = Math.min(RMN - 2, Math.round(ub * (RMN - 1))); spr(ctx, e.SAG, RMX[k], RMY[k], 10 + 6 * fl5, .25 + .3 * fl5); }
  /* couronne de tentacules fins devant (ils s'orientent vers la sortie quand la bille arrive à la tête) + deux longs tentacules traînants : bord doux, bouts perlés */
  const hx = L / 2 + 2, hy = RMY[RMN - 1], gd = held && ub > .7 ? (c.ea || 0) * Math.PI / 180 * cl01((ub - .7) / .3) : 0, TX = e.tt5 || (e.tt5 = new Float32Array(14));
  ctx.beginPath();
  for (let j = 0; j < 5; j++) { const o = (j - 2) * .34 + gd + .1 * Math.sin(T * 1.3 + j), Lt = 20 + 6 * hs(j + 2) + 3 * V, w2 = 3.6 * Math.sin(T * 1.9 + j * 1.3), cu = (j - 2) * 2.2;
    const ex = hx + Math.cos(o) * Lt - Math.sin(o) * cu, ey = hy + Math.sin(o) * Lt + Math.cos(o) * cu, r0x = hx - 1.6 + .6 * Math.cos((j - 2) * .5), r0y = hy + (j - 2) * .9; ctx.moveTo(r0x, r0y); ctx.quadraticCurveTo(hx + Math.cos(o) * Lt * .5 - Math.sin(o) * w2, hy + Math.sin(o) * Lt * .5 + Math.cos(o) * w2, ex, ey); TX[j * 2] = ex; TX[j * 2 + 1] = ey; }
  for (let s = -1; s <= 1; s += 2) { const w3 = 2.5 * Math.sin(T * 1.1 + s), ex = hx - 9 - 2 * V, ey = hy + s * (19 + w3 * 1.2);
    ctx.moveTo(hx - 1, hy + s * 2); ctx.bezierCurveTo(hx + 7, hy + s * 9, hx - 2, hy + s * (14 + w3), ex, ey); TX[10 + (s > 0 ? 2 : 0)] = ex; TX[11 + (s > 0 ? 2 : 0)] = ey; }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .05 + .04 * AC; ctx.lineWidth = 3; ctx.stroke();
  ctx.globalAlpha = .1 + .06 * AC; ctx.lineWidth = 1.1; ctx.stroke();
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .3 + .12 * V; ctx.lineWidth = .38; ctx.stroke();
  for (let j = 0; j < 7; j++) spr(ctx, j < 5 ? e.SP : e.SA, TX[j * 2], TX[j * 2 + 1], 1.2 + .5 * pw, .3 + .3 * pw + .3 * fl5);
  spr(ctx, e.SP, hx - 1.5, hy - 1.6, 1.1, .8); spr(ctx, e.SP, hx - 1.5, hy + 1.6, 1.1, .8); spr(ctx, e.SG, hx - 2, hy, 6, .14 + .1 * pw);
  /* le courant : de fines traînées glissent le long du corps, de la queue vers la tête */
  ctx.beginPath();
  const vc = 26 + 30 * AC;
  for (let j = 0; j < 6; j++) { const s = j % 2 ? 1 : -1, xx = -L / 2 + ((T * vc + j * L / 6 + 40 * hs(j)) % L), off = s * (RMW[7] + 12 + 3 * hs(j + 5)) + .8 * Math.sin(T * 4 + j); ctx.moveTo(xx + 1, off); ctx.arc(xx, off, 1, 0, TAU); }
  ctx.fillStyle = e.K2; ctx.globalAlpha = .2 + .3 * AC; ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* micro-bulles qui montent du dos */
  const Q = e.Q; e.bT -= dt * (held ? 2.6 : .5 + V);
  if (e.bT <= 0) { const u = hs(fr * 1.7 + e.i), lx = -L / 2 + u * L; emP(Q, 0, cx + ca * lx + sa * 6, cy + sa * lx - ca * 6, 3 * ca, -4, 1.2 + .6 * hs(fr), .8 + .5 * hs(fr + 3)); e.bT = .5 + .4 * hs(fr * 5); }
  majPart(Q, dt); dessinerPart(ctx, Q, e);
}
const E5D = { clione: dessinerClione, rames: dessinerRames };
/* ── AIGRETTES (effet de particule de l'étage 5) : la particule portée se couvre d'une couronne de soies et sème des graines à aigrette ── */
const E5L = { x: new Float32Array(40), y: new Float32Array(40), a: new Float32Array(40), r: new Float32Array(40), k: new Uint8Array(40), n: 0, i: 0, f0: -1 };
function e5Langage(ctx, dt, b, fr, run) {
  const L = E5L; if (!run || fr <= 1) { if (fr <= 1) L.n = 0; }
  let src = null, dir = 1;
  if (run && b) for (const e of act.E) if (E5T[e.c.t]) { const st = (b.cs && b.cs[e.i]) || {}; if (st.h || (st.out && fr - st.out < 70 && fr >= st.out)) { src = e; if (st.dir) dir = st.dir; } }
  if (src && fr !== L.f0 && fr % 4 === 0) { L.f0 = fr; const j = L.n < 40 ? L.n++ : (L.i = (L.i + 1) % 40); L.x[j] = b.x + (hs(fr) - .5) * 6; L.y[j] = b.y - 3; L.a[j] = 0; L.r[j] = hs(fr * 3) * TAU; L.k[j] = src.c.t === 'clione' ? 0 : 1; }
  if (!L.n && !src) return;
  for (let j = 0; j < L.n; j++) { L.a[j] += dt; L.y[j] -= dt * (9 + 5 * L.a[j]); L.x[j] += (Math.sin(L.a[j] * 1.6 + j) * 5 - dir * 4) * dt; L.r[j] += dt * (.8 + (j % 3) * .3); }
  ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
  for (let bin = 0; bin < 2; bin++) {
    ctx.beginPath(); let nb = 0;
    for (let j = 0; j < L.n; j++) {
      const a = L.a[j], vie = 2.6; if (a > vie) continue;
      const m = MOT[L.k[j] ? 'rames' : 'clione'], ph = (a * 1.1 + m[j % 3] * 3) % 1, on = ph < .2 ? 1 : .35, env = Math.sin(Math.PI * Math.min(1, a / vie));
      if ((on > .5 ? 1 : 0) !== bin) continue;
      const x0 = L.x[j], y0 = L.y[j], r = L.r[j], cr = Math.cos(r), sr = Math.sin(r), s0 = 1 - a / vie * .3;
      const tx = x0 - sr * 3.4 * s0, ty = y0 + cr * 3.4 * s0;                    // tige
      ctx.moveTo(tx, ty); ctx.lineTo(x0, y0);
      for (let q = -2; q <= 2; q++) { const aq = r - Math.PI / 2 + q * .42, l = 3.6 * s0; ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 + Math.cos(aq) * l * .6, y0 + Math.sin(aq) * l * .6 - .5, x0 + Math.cos(aq + q * .12) * l, y0 + Math.sin(aq + q * .12) * l); }
      nb += env;
    }
    if (nb) { const TT = TEINTE.clione; ctx.strokeStyle = bin ? 'rgb(238,246,255)' : rgb(TT.c1); ctx.globalAlpha = bin ? .62 : .32; ctx.lineWidth = bin ? 1 : .8; ctx.stroke(); }
  }
  if (src && b) {                                     // la particule elle-même : couronne de soies qui tourne doucement
    const t = act.t, R = (b.r || 8) + 1;
    ctx.beginPath();
    for (let q = 0; q < 10; q++) { const aq = q * TAU / 10 + t * .6, l = 4.5 + 1.2 * Math.sin(t * 3 + q * 1.7); ctx.moveTo(b.x + Math.cos(aq) * R, b.y + Math.sin(aq) * R);
      ctx.quadraticCurveTo(b.x + Math.cos(aq + .15) * (R + l * .6), b.y + Math.sin(aq + .15) * (R + l * .6), b.x + Math.cos(aq + .3) * (R + l), b.y + Math.sin(aq + .3) * (R + l)); }
    ctx.strokeStyle = src.K2; ctx.globalAlpha = .45; ctx.lineWidth = 1; ctx.stroke();
    spr(ctx, src.SG, b.x, b.y, 14 + 2 * Math.sin(act.t * 4), .26);
  }
  ctx.globalCompositeOperation = 'source-over';
}
/* ── DÉCOR VIVANT DU MONDE 5 : figurants nouveaux et interactions sociales (rendu seul, horloge de rendu) ── */
const E5C = [[110, 238, 196], [127, 216, 230], [232, 248, 252], [182, 154, 232]].map(rgb);   // menthe, aqua, perle, mauve
let E5F = null;
/* R487 : 9 figurants (3 aigrettes · 1 spore-mère + 2 petits · 2 planeurs · 1 fil de la vierge), sans lueur individuelle, un tracé par groupe */
const E5G = { aig: [0, 3], mere: 3, pet: [4, 6], plan: [6, 8], fil: 8 };
function e5Monter(lv) {
  const R = rng(0xA1E5 + (lv.idx || 0) * 977), A = [];
  const add = (k, n, f) => { for (let i = 0; i < n; i++) A.push(Object.assign({ k, x: 20 + R() * 320, y: 40 + R() * 400, vx: 0, vy: 0, ph: R() * TAU, s: .8 + .4 * R(), fl: 0, ap: 0, rot: R() * TAU, far: 1 }, f ? f(i) : {})); };
  add('aig', 3); add('mere', 1, () => ({ s: 1.1 })); add('petit', 2, i => ({ s: .5, o: i * Math.PI }));
  add('plan', 2, i => ({ s: i ? .8 : 1, rang: i })); add('fil', 1, () => ({ L: 46 }));
  E5F = { idx: lv.idx, A, t: 0, rel: { t0: 3 + R() * 3 }, sal: 0, ms: 0, n: 0 };
}
function e5Vent(lv, x, y) { let wx = 0, wy = 0; if (lv.wind) for (const w of lv.wind) if (x > w[0] && x < w[0] + w[2] && y > w[1] && y < w[1] + w[3]) { wx += w[4]; wy += w[5]; } return [wx, wy]; }
function e5Decor(ctx, dt, S, b, run, lv) {
  if (!E5F || E5F.idx !== lv.idx) e5Monter(lv);
  const t0 = performance.now(), F = E5F, pal = cur ? cur.pal : 0; if (pal >= 3) return;
  F.t += dt; const t = F.t, A = F.A, nMax = pal >= 2 ? 6 : A.length, lead = A[E5G.plan[0]], mere = A[E5G.mere], fil = A[E5G.fil];
  for (let i = 0; i < A.length; i++) {
    const a = A[i]; let tx, ty;
    if (a.k === 'aig') { tx = a.x + 6 + 5 * Math.sin(t * .2 + a.ph); ty = a.y - 3 + 4 * Math.sin(t * .5 + a.ph); a.rot += dt * .3 * Math.sin(t * .4 + a.ph); }
    else if (a.k === 'mere') { tx = 180 + 120 * Math.sin(t * .045 + a.ph); ty = 240 + 140 * Math.sin(t * .061 + a.ph * 1.3); }
    else if (a.k === 'petit') { const far = .5 + .5 * Math.sin(t * .23 + a.o * 2), r = 10 + 26 * far * far; tx = mere.x + Math.cos(a.o + t * .7) * r; ty = mere.y + Math.sin(a.o + t * .7) * r * .8; a.far = far; }   // mère-petits
    else if (a.k === 'plan') { if (!a.rang) { tx = 180 + 150 * Math.sin(t * .07 + 1); ty = 230 + 150 * Math.sin(t * .11); }
      else { const hd = Math.atan2(lead.vy, lead.vx); tx = lead.x - Math.cos(hd) * 14 + Math.sin(hd) * 9; ty = lead.y - Math.sin(hd) * 14 - Math.cos(hd) * 9; } }   // suivi en échelon
    else { tx = lead.x - 34 * Math.cos(t * .5); ty = lead.y - 26 * Math.sin(t * .4); }   // le fil de la vierge poursuit le banc
    const w = e5Vent(lv, a.x, a.y), kk = a.k === 'aig' ? .5 : a.k === 'petit' ? 2.2 : a.k === 'plan' ? (a.rang ? 1.6 : .8) : .6;
    a.vx += ((tx - a.x) * kk - a.vx) * Math.min(1, dt * 1.5) + w[0] * 28 * dt; a.vy += ((ty - a.y) * kk - a.vy) * Math.min(1, dt * 1.5) + w[1] * 28 * dt;
    a.x += a.vx * dt; a.y += a.vy * dt;
    if (a.x < -20) a.x += 400; if (a.x > 380) a.x -= 400; if (a.y < -20) a.y += 520; if (a.y > 500) a.y -= 520;
    a.fl = Math.max(0, a.fl - dt * 1.4);
    let f = 1; if (cur) for (const z of cur.Z) f = Math.min(f, lisse(z[2] * .6, z[2] * 1.2, Math.hypot(a.x - z[0], a.y - z[1])));
    if (b) f = Math.min(f, lisse(26, 64, Math.hypot(a.x - b.x, a.y - b.y)));
    a.ap += ((i < nMax ? f : 0) - a.ap) * Math.min(1, dt * 2.5);
  }
  /* évitement poli : la meneuse croise la spore-mère → le banc s'écarte, éclat de salut */
  if (Math.hypot(lead.x - mere.x, lead.y - mere.y) < 46) { for (let i = E5G.plan[0]; i < E5G.plan[1]; i++) { const a = A[i], dx = a.x - mere.x, dy = a.y - mere.y, d = Math.hypot(dx, dy) || 1; a.vx += dx / d * 60 * dt; a.vy += dy / d * 60 * dt; }
    if (t - F.sal > 4) { F.sal = t; lead.fl = 1; mere.fl = .8; } }
  /* relais lumineux : la lueur passe d'aigrette en aigrette le long d'un fil */
  const RL = F.rel; let rel = null;
  if (t > RL.t0) { const u = (t - RL.t0) / .9, k = Math.floor(u); if (k >= 2) RL.t0 = t + 7 + 5 * hs(t); else { const a0 = A[k], a1 = A[k + 1], s2 = u - k; a0.fl = Math.max(a0.fl, 1 - s2 * .5); if (s2 > .8) a1.fl = 1; rel = [a0, a1, s2]; } }
  if (!ctx) return;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* aigrettes : tige + parasol de soies (un tracé) ; lueur = alpha du tracé */
  ctx.beginPath(); let al = 0;
  for (let i = E5G.aig[0]; i < E5G.aig[1]; i++) { const a = A[i]; if (a.ap < .02) continue; al = Math.max(al, a.ap * (.34 + .4 * a.fl)); const r = a.rot, cr = Math.cos(r), sr = Math.sin(r), s2 = 6 * a.s;
    ctx.moveTo(a.x, a.y); ctx.lineTo(a.x - sr * s2, a.y + cr * s2);
    for (let q = -3; q <= 3; q++) { const aq = r - Math.PI / 2 + q * .36 + .05 * Math.sin(t * 2 + q + i), l = s2 * (1.1 - .05 * Math.abs(q)); ctx.moveTo(a.x, a.y); ctx.quadraticCurveTo(a.x + Math.cos(aq) * l * .55, a.y + Math.sin(aq) * l * .55 - .8, a.x + Math.cos(aq + q * .08) * l, a.y + Math.sin(aq + q * .08) * l); } }
  if (al) { ctx.strokeStyle = E5C[2]; ctx.globalAlpha = al; ctx.lineWidth = 1; ctx.stroke(); }
  if (rel) { const [a0, a1, s2] = rel, mx = (a0.x + a1.x) / 2, my = (a0.y + a1.y) / 2 - 18, m = 1 - s2, px = m * m * a0.x + 2 * s2 * m * mx + s2 * s2 * a1.x, py = m * m * a0.y + 2 * s2 * m * my + s2 * s2 * a1.y;
    ctx.beginPath(); ctx.moveTo(a0.x, a0.y); ctx.quadraticCurveTo(mx, my, a1.x, a1.y); ctx.strokeStyle = E5C[1]; ctx.globalAlpha = .2 * Math.min(a0.ap, a1.ap); ctx.lineWidth = 1; ctx.stroke();
    spr(ctx, E5S('p', 1), px, py, 2.6, .8 * Math.min(a0.ap, a1.ap)); }
  /* spore-mère et petits : sphères translucides (un remplissage + un liseré) + couronne de la mère + lien quand un petit revient */
  ctx.beginPath();
  for (let i = E5G.mere; i < E5G.pet[1]; i++) { const a = A[i]; if (a.ap < .02) continue; const r = (a.k === 'mere' ? 7.5 : 2.8) * (1 + .05 * Math.sin(t * 1.5 + a.ph)); ctx.moveTo(a.x + r, a.y); ctx.ellipse(a.x, a.y, r, r * .92, .3, 0, TAU); }
  for (let j = 0; j < 7 && mere.ap > .02; j++) { const an = j * TAU / 7 + t * .2, rr = 9.5 + .8 * Math.sin(t * 2 + j); ctx.moveTo(mere.x + Math.cos(an) * 7.6, mere.y + Math.sin(an) * 7); ctx.lineTo(mere.x + Math.cos(an + .1) * rr, mere.y + Math.sin(an + .1) * rr * .92); }
  for (let i = E5G.pet[0]; i < E5G.pet[1]; i++) { const a = A[i]; if (a.ap > .02 && a.far < .25) { ctx.moveTo(a.x, a.y); ctx.lineTo(mere.x, mere.y); } }
  ctx.fillStyle = E5C[0]; ctx.globalAlpha = .1 * mere.ap; ctx.fill(); ctx.strokeStyle = E5C[2]; ctx.globalAlpha = (.38 + .3 * mere.fl) * mere.ap; ctx.lineWidth = 1; ctx.stroke();
  /* planeurs : aile en croissant, s'inclinent dans les virages */
  ctx.beginPath(); al = 0;
  for (let i = E5G.plan[0]; i < E5G.plan[1]; i++) { const a = A[i]; if (a.ap < .02) continue; al = Math.max(al, a.ap * (.45 + .4 * a.fl)); const hd = Math.atan2(a.vy, a.vx), bank = Math.max(-.6, Math.min(.6, (hd - (a.hd0 || hd)) * 8)); a.hd0 = hd;
    const ch = Math.cos(hd), sh = Math.sin(hd), sz = 7 * a.s, fl = Math.sin(t * 4 + a.ph) * .25, wl = sz * (1 - .3 * Math.abs(bank)), P = (fx, fy) => [a.x + ch * fx - sh * fy, a.y + sh * fx + ch * fy];
    const n0 = P(sz * .5, 0), l1 = P(-sz * .1, -wl * (1.1 + fl)), l2 = P(-sz * .55, -wl * .9), m0 = P(-sz * .2, 0), r2 = P(-sz * .55, wl * .9), r1 = P(-sz * .1, wl * (1.1 - fl));
    ctx.moveTo(n0[0], n0[1]); ctx.quadraticCurveTo(l1[0], l1[1], l2[0], l2[1]); ctx.quadraticCurveTo(m0[0], m0[1], r2[0], r2[1]); ctx.quadraticCurveTo(r1[0], r1[1], n0[0], n0[1]); }
  if (al) { ctx.fillStyle = E5C[3]; ctx.globalAlpha = .16; ctx.fill(); ctx.strokeStyle = E5C[2]; ctx.globalAlpha = al; ctx.lineWidth = 1; ctx.stroke(); }
  /* fil de la vierge : long filament ondulant + perle qui court le long */
  if (fil.ap > .02) { const hd = Math.atan2(fil.vy, fil.vx) + Math.PI, ch = Math.cos(hd), sh = Math.sin(hd), ub = (t * .35) % 1; let bx = 0, by = 0;
    ctx.beginPath(); for (let q = 0; q <= 10; q++) { const u = q / 10, l = u * fil.L, w = 4 * Math.sin(t * 2.2 - u * 6 + fil.ph) * u, px = fil.x + ch * l - sh * w, py = fil.y + sh * l + ch * w; q ? ctx.lineTo(px, py) : ctx.moveTo(px, py); if (Math.abs(u - ub) < .051) { bx = px; by = py; } }
    ctx.strokeStyle = E5C[1]; ctx.globalAlpha = .32 * fil.ap; ctx.lineWidth = 1; ctx.stroke();
    if (bx) { ctx.beginPath(); ctx.arc(bx, by, 1.4, 0, TAU); ctx.fillStyle = E5C[2]; ctx.globalAlpha = .7 * fil.ap; ctx.fill(); } }
  ctx.restore(); ctx.globalAlpha = 1;
  F.ms += performance.now() - t0; F.n++;
}
const E5SP = {};
function E5S(sorte, c) { const k = sorte + c; return E5SP[k] || (E5SP[k] = sprite('e5' + c, [[110, 238, 196], [127, 216, 230], [232, 248, 252], [182, 154, 232]][c], sorte)); }
/* tests : créature isolée sur une planche (page t/r484/iso.html) et mesure du décor */
racine.QXCREA.e5Demo = (ctx, type, x, y, o) => {
  o = o || {}; const TT = TEINTE[type], c = Object.assign({ t: type }, o.c || {});
  const e = o.e || { c, i: o.i || 0, al: 1, ex: o.ex || 0, ph: o.ph || .7, tl: 0, tw: 0, vit: o.vit || .3, ac: o.ac || 0, W: [], wx: 0, wy: 0, bT: 0, Q: pool(), fl: 0,
    T: TT, K1: rgb(TT.c1), K2: rgb(TT.c2), K3: rgb(TT.c3), KA: rgb(TT.ac), SG: sprite(type, TT.c1, 'g'), SP: sprite(type, TT.c1, 'p'), SA: sprite(type + 'a', TT.ac, 'p'), SAG: sprite(type + 'a', TT.ac, 'g'), SO: sprite('', TT.c1, 'o') };
  e.vit = o.vit == null ? e.vit : o.vit; e.ac = o.ac == null ? e.ac : o.ac; e.tl = o.t * (.6 + 1.5 * e.vit + .9 * e.ac); e.ex = o.ex || 0;
  const st = o.st || {}, b = o.b || null, run = !!o.run;
  if (!act) act = { E: [], t: 0 };
  ctx.save(); E5D[type](ctx, e, x, y, o.etat || 0, st, b, o.t, o.dt || 1 / 60, o.fr || 0, run); ctx.restore(); return e;
};
racine.QXCREA.e5Decor = (ctx, lv, t, b) => { if (!E5F || E5F.idx !== lv.idx) e5Monter(lv); const n = Math.round(t * 30); for (let i = 0; i < n; i++) e5Decor(null, 1 / 30, null, b || null, false, lv); E5F.ms = 0; E5F.n = 0; e5Decor(ctx, 1 / 60, null, b || null, false, lv); return E5F.ms / E5F.n; };
racine.QXCREA.e5Ms = () => { const F = E5F; if (!F || !F.n) return 0; const m = F.ms / F.n; F.ms = 0; F.n = 0; return m; };
// ===== ETAGE 5 FIN =====
racine.QXCREA.actMs = () => { if (!act || !act.n) return 0; const m = act.ms / act.n; act.ms = 0; act.n = 0; return m; };
racine.QXCREA.actForce = v => { if (act) act.force = v; return !!act; };   // R473 : tests (phase imposée hors essai)
racine.QXCREA.actDt = v => { if (act) act.dtF = v; return !!act; };   // R473 : tests (pas de temps imposé)
racine.QXCREA.actT = v => { if (!act) return null; if (v != null) act.t = v; return act.t; };   // R483 : tests (horloge des créatures, gros plans de la pirouette)
racine.QXCREA.teteDemo = (ctx, x, y, ang, o, g, t, sc) => {   // R479 : planche « tête seule » (tests visuels)
  const TT = TEINTE.cortege, e = { K1: rgb(TT.c1), K2: rgb(TT.c2), K3: rgb(TT.c3), SG: sprite('cortege', TT.c1, 'g'), SP: sprite('cortege', TT.c1, 'p'), SA: sprite('cortegea', TT.ac, 'p'), SAG: sprite('cortegea', TT.ac, 'g'), tl: t, ph: 0, mo: o, cup: g };
  const hz = sc * 1.1, ca = Math.cos(ang), sa = Math.sin(ang), HX = new Float32Array(NHD), HY = new Float32Array(NHD), NB = 14, UX = [], UY = [];
  teteForme(o, g, t, 0, x, y, ca, sa, hz, HX, HY);
  const C = [];
  for (let k = 0; k < NB; k++) { const u = k / (NB - 1), d = (1.5 + u * 34) * hz, lat = Math.sin(t * 1.2 - u * 3) * u * 4 * hz, w = hz * (1.25 + 1.6 * Math.min(1, u * 3)) * (1 - .3 * u);
    C.push([x - ca * d - sa * lat, y - sa * d + ca * lat, w]); }
  for (let k = NB - 1; k >= 0; k--) { UX.push(C[k][0] + sa * C[k][2]); UY.push(C[k][1] - ca * C[k][2]); }
  for (let k = 0; k < NHD; k++) { UX.push(HX[k]); UY.push(HY[k]); }
  for (let k = 0; k < NB; k++) { UX.push(C[k][0] - sa * C[k][2]); UY.push(C[k][1] + ca * C[k][2]); }
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); crTrace(ctx, UX, UY, UX.length); ctx.closePath();
  ctx.fillStyle = e.K3; ctx.globalAlpha = .38; ctx.fill(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .06; ctx.fill();
  deuxTraits(ctx, e.K2, .4, 2.2 * sc, .34 * sc, .16);
  teteDetails(ctx, e, HX, HY, x, y, ca, sa, hz, .3, g > .5 ? .4 : 0, 0, null);
  ctx.restore();
};
racine.QXCREA.dbg = () => act && act.E.map(e => [racine.FLUID.crPos(e.c, 0), 1]);
racine.QXCREA.niveau = {
  dessiner(ctx, lv, env) { try { dessiner(ctx, lv, env); } catch (e) { try { ctx.restore(); } catch (e2) {} vider(); racine.QXCREA.niveau.panne = String(e && e.message || e); } },
  vider,
  get actif() { return !!cur; },
  pos() { return cur ? visibles().map(e => { const p = e.m.pos(0); return [+(p[0] * e.k).toFixed(2), +(p[1] * e.k).toFixed(2)]; }) : []; },
  stats() { return { ms: mes.n ? mes.s / mes.n : 0, max: mes.max, images: mes.n, palier: cur ? cur.pal : -1, ema: cur ? cur.ema : 0, emaJeu: cur ? cur.emaJ : 0,
    creatures: cur ? visibles().map(e => e.nom) : [], toutes: cur ? cur.E.map(e => e.nom) : [], idx: cur ? cur.idx : null }; },
  etats() { return cur ? cur.E.map(e => e.etat + ':' + e.tn + '@' + Math.round(e.x) + ',' + Math.round(e.y) + '>' + Math.round(e.tx) + ',' + Math.round(e.ty)) : []; },
  signaux() { return cur ? cur.SIG.filter(s => s.on).length : 0; },   // R469 : test
  lieux() { return cur ? cur.LI.map(p => [Math.round(p[0]), Math.round(p[1])]) : []; },   // R469 : test
  raz() { mes.n = 0; mes.s = 0; mes.max = 0; fmes.n = 0; fmes.s = 0; fmes.max = 0; fmes.av = 0; fmes.nav = 0; },
  /* R470 : calque d'avant-plan (appelé par engine.js APRÈS la bille et les traits) + outils de test */
  avant(ctx, lv, env) { try { figAvant(ctx, lv, env); } catch (e) { racine.QXCREA.niveau.panne = String(e && e.message || e); } },
  figurants() { const F = cur && cur.F; if (!F) return null; return { n: F.n, ms: fmes.n ? fmes.s / fmes.n : 0, max: fmes.max, msAvant: fmes.nav ? fmes.av / fmes.nav : 0, av: F.av, tAv: +(F.tAv - F.t).toFixed(1), t: +F.t.toFixed(1),
    scenes: F.SL.filter(s => s.on).map(s => s.type + ' ' + s.t.toFixed(1) + '/' + s.dur.toFixed(0) + ' ph' + s.ph + ' k' + s.k + ' @' + Math.round(s.x) + ',' + Math.round(s.y) + ' [' + Array.from(s.m.slice(0, s.nm)).join(',') + ']'), imp: F.IMP.filter(o => o.on).length, liens: F.nLK,
    A: F.A.slice(0, F.n).map(a => [Math.round(a.x), Math.round(a.y), +a.zc.toFixed(2), +a.ap.toFixed(2), a.st]) }; },
  figForce(type, av) { const F = cur && cur.F; if (!F) return 0; if (av) { F.tAv = F.t; return 1; }   // tests : force une histoire / l'avant-plan
    for (const o of F.SL) if (o.on) fFin(F, o); const h = HIST.indexOf(type); if (h < 0) return 0;
    F.hist = HIST.map((x, k) => k).filter(k => k !== h); F.hi = 0; const s = F.SL[0]; fLance(F, s); F.hist = [-1, -1, -1, -1, -1]; F.hi = 0; return s.on ? s.type : 0; },
  /* R474 : planche d'essai — un figurant isolé, dessiné à une échelle donnée (tests seulement) */
  echantillon(ctx, x, y, morph, col, z, taille, t, puls, lum, cap, wd) { figTeintes(wd || 2); const a = { rx: x, ry: y, x, y, cap: cap || 0, taille, mul: 1, puls: puls || 0, lum: lum == null ? .3 : lum, fl: 0, ph: 1.3 + morph, p1: .7 * col + morph, vx: 30, vy: 0, morph, col, zc: z, ap: zp(FPL.al, z), trN: 0, i: morph * 4 + col };
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; const st = Math.round(Math.min(3, z) * 2), Rg = taille * zp(FPL.sc, z) * (z < .6 ? 4 : 3) * (1 + .3 * a.puls);
    ctx.globalAlpha = Math.min(1, a.ap * (.9 + 1.1 * a.lum)); ctx.drawImage(FSP[col][st], x - Rg, y - Rg, Rg * 2, Rg * 2); ctx.globalCompositeOperation = 'source-over'; fCorps(ctx, a, a.ap, t, z); ctx.restore(); },
  palier(p) { verrou = p >= 0 && p < PAL.length ? p | 0 : -1; if (cur && verrou >= 0) cur.pal = verrou; return verrou; }
};
// ===== REPASSE M1-4 LEURRE DEBUT (R494) : leurre — chair translucide pré-rendue (texture posée en tranches cisaillées), filament-tube effilé,
//   soies visco-élastiques (ressorts amortis), bulbe-appât pré-rendu (membranes, nervures, lentille), pulsations qui voyagent, réponse à la prise =====
const RM = { ancien: 0 };                            // caches du bloc (textures pré-rendues, une fois) ; ancien : bancs A/B (tests)
function rmCv(w, h) { const k = document.createElement('canvas'); k.width = w; k.height = h; return k; }
function rmRnd(s) { return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
const LR_PTS = [[8.7, -1.9, 6.6, -2.1], [4, -2.2, 1.2, -1.5], [-2.6, -1.3, -5, -2.1], [-8.4, -2.5, -10.4, -1], [-11.4, -.3, -12.4, 0]];
const LR_PB = [[-11.4, .4, -10.4, 1.1], [-8.4, 2.6, -5, 2.3], [-2.4, 1.6, .6, 2.2], [3.2, 3.5, 5.8, 2.5], [8.5, 2.2, 9, 0]];
const LR_X0 = -14.6, LR_Y0 = -6, LR_W = 25.2, LR_H = 12, LR_PX = 12;
function lrTex() {                                   // corps de la larve, au repos (non courbé) : une seule chair, organes vus par transparence
  if (RM.lr) return RM.lr;
  const K = TEINTE.leurre, c1 = K.c1.join(','), c2 = K.c2.join(','), c3 = K.c3.join(','), ac = K.ac.join(','), R = rmRnd(9173);
  const k = rmCv(Math.ceil(LR_W * LR_PX), Math.ceil(LR_H * LR_PX)), g = k.getContext('2d');
  g.setTransform(LR_PX, 0, 0, LR_PX, -LR_X0 * LR_PX, -LR_Y0 * LR_PX); g.lineCap = 'round'; g.lineJoin = 'round';
  const corps = () => { g.beginPath(); g.moveTo(9, 0); for (const s of LR_PTS) g.quadraticCurveTo(s[0], s[1], s[2], s[3]); for (const s of LR_PB) g.quadraticCurveTo(s[0], s[1], s[2], s[3]); g.closePath(); };
  const fin = () => { g.beginPath(); g.moveTo(1.5, -1.8); g.bezierCurveTo(-2.5, -3.2, -6.5, -4.6, -9.6, -3.2); g.bezierCurveTo(-11.8, -2.2, -13.4, -.8, -13.9, 0);
    g.bezierCurveTo(-13.4, .8, -11.8, 2.3, -9.6, 3.2); g.bezierCurveTo(-6.5, 4.5, -3.8, 3.7, -.5, 2.3); g.closePath(); };
  /* repli de nageoire : voile très clair, rayons fins (nervures), liseré doux */
  fin(); g.fillStyle = 'rgba(' + c3 + ',.28)'; g.fill(); g.fillStyle = 'rgba(' + c1 + ',.07)'; g.fill();
  g.save(); fin(); g.clip();
  const gf = g.createLinearGradient(0, -5, 0, 5); gf.addColorStop(0, 'rgba(' + c2 + ',.12)'); gf.addColorStop(.35, 'rgba(' + c1 + ',.02)'); gf.addColorStop(.65, 'rgba(' + c1 + ',.02)'); gf.addColorStop(1, 'rgba(' + c2 + ',.12)');
  g.fillStyle = gf; g.fillRect(-15, -6, 18, 12);
  g.beginPath(); for (let x = .6; x > -13.6; x -= .56) { const s = (x + 13.6) / 14.2; for (const sd of [-1, 1]) { g.moveTo(x, sd * 1.4); g.quadraticCurveTo(x - .5, sd * 3, x - 1.3 - .4 * (1 - s), sd * 5.2); } }
  g.strokeStyle = 'rgba(' + c2 + ',.05)'; g.lineWidth = .22; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.13)'; g.lineWidth = .05; g.stroke();
  for (let i = 0; i < 90; i++) { const x = -14 + 15 * R(), y = (R() - .5) * 9; g.fillStyle = 'rgba(' + c2 + ',' + (.04 + .06 * R()).toFixed(3) + ')'; g.fillRect(x, y, .09, .09); }
  g.restore();
  fin(); g.strokeStyle = 'rgba(' + c1 + ',.07)'; g.lineWidth = .7; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.34)'; g.lineWidth = .07; g.stroke();
  /* chair : absorption + dégradé radial étiré (bord plus dense que le cœur : pellicule) */
  corps(); g.fillStyle = 'rgba(' + c3 + ',.5)'; g.fill();
  g.save(); corps(); g.clip();
  g.save(); g.translate(-1.2, -.2); g.scale(11.5, 3.1); const gr = g.createRadialGradient(.15, -.2, 0, 0, 0, 1);
  gr.addColorStop(0, 'rgba(' + c1 + ',.10)'); gr.addColorStop(.55, 'rgba(' + c1 + ',.13)'); gr.addColorStop(.82, 'rgba(' + c2 + ',.26)'); gr.addColorStop(1, 'rgba(' + c2 + ',.42)');
  g.fillStyle = gr; g.fillRect(-1.3, -1.3, 2.6, 2.6); g.restore();
  /* myomères : fines stries courbes qui épousent le corps */
  g.beginPath(); for (let x = 3.2; x > -12; x -= .82) { g.moveTo(x + .45, -2.6); g.quadraticCurveTo(x - .55, -.9, x - .1, 0); g.quadraticCurveTo(x - .55, .9, x + .45, 2.8); }
  g.strokeStyle = 'rgba(' + c2 + ',.05)'; g.lineWidth = .3; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.16)'; g.lineWidth = .05; g.stroke();
  /* corde (notocorde) à vacuoles + tube neural */
  g.beginPath(); g.moveTo(5.2, -.35); g.bezierCurveTo(1, -.25, -6, -.15, -12.6, 0); g.strokeStyle = 'rgba(' + c2 + ',.1)'; g.lineWidth = .9; g.stroke();
  g.strokeStyle = 'rgba(' + c2 + ',.32)'; g.lineWidth = .08; g.stroke();
  g.beginPath(); for (let x = 4.6; x > -11.8; x -= .62) { const w = .26 * (1 - (4.6 - x) / 22); g.moveTo(x + .22, -.25 + .015 * (4.6 - x)); g.ellipse(x, -.25 + .015 * (4.6 - x), .22, w + .05, 0, 0, TAU); }
  g.strokeStyle = 'rgba(' + c2 + ',.14)'; g.lineWidth = .05; g.stroke();
  g.beginPath(); g.moveTo(6.2, -1.2); g.bezierCurveTo(2, -1.05, -5, -1, -11.5, -.35); g.strokeStyle = 'rgba(' + c1 + ',.16)'; g.lineWidth = .14; g.stroke();
  /* intestin : tube sombre à lumière menthe, granules */
  g.beginPath(); g.moveTo(5.2, .9); g.bezierCurveTo(3, 1.7, -1, 1.2, -3, 1.4); g.quadraticCurveTo(-5.5, 1.6, -6.6, 2.1);
  g.strokeStyle = 'rgba(' + c3 + ',.6)'; g.lineWidth = 1.05; g.stroke(); g.strokeStyle = 'rgba(' + ac + ',.12)'; g.lineWidth = .7; g.stroke(); g.strokeStyle = 'rgba(' + ac + ',.32)'; g.lineWidth = .1; g.stroke();
  for (let i = 0; i < 16; i++) { const u = R(), x = 5 - 11 * u, y = 1.2 + .5 * Math.sin(u * 5) + (R() - .5) * .5; g.beginPath(); g.arc(x, y, .08 + .1 * R(), 0, TAU); g.fillStyle = 'rgba(' + ac + ',' + (.25 + .3 * R()).toFixed(2) + ')'; g.fill(); }
  /* tête : vésicule cérébrale, otolithe, œil pigmenté à lentille */
  g.beginPath(); g.ellipse(6.4, -.75, 1.45, 1.05, -.1, 0, TAU); g.fillStyle = 'rgba(' + c1 + ',.1)'; g.fill(); g.strokeStyle = 'rgba(' + c2 + ',.26)'; g.lineWidth = .07; g.stroke();
  g.beginPath(); g.arc(5.6, -.45, .3, 0, TAU); g.strokeStyle = 'rgba(' + c2 + ',.4)'; g.lineWidth = .06; g.stroke();
  /* grain interne */
  for (let i = 0; i < 220; i++) { const x = -12 + 20.5 * R(), y = (R() - .5) * 4.6; g.fillStyle = 'rgba(' + c2 + ',' + (.04 + .09 * R()).toFixed(3) + ')'; g.fillRect(x, y, .07 + .05 * R(), .07); }
  g.restore();
  g.beginPath(); g.arc(7.25, -.5, .66, 0, TAU); g.fillStyle = 'rgba(3,8,16,.85)'; g.fill(); g.strokeStyle = 'rgba(' + c2 + ',.75)'; g.lineWidth = .1; g.stroke();
  g.beginPath(); g.arc(7.45, -.7, .17, 0, TAU); g.fillStyle = 'rgba(' + c2 + ',.85)'; g.fill();
  /* bord : double trait doux (voile + filet), jamais un contour dur */
  corps(); g.strokeStyle = 'rgba(' + c1 + ',.08)'; g.lineWidth = .9; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.16)'; g.lineWidth = .32; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.5)'; g.lineWidth = .08; g.stroke();
  return (RM.lr = k);
}
const LB_PX = 46;                                    // bulbe : unités de rb
function lbTex() {                                   // bulbe-appât au repos, axe +x, col à l'origine
  if (RM.lb) return RM.lb;
  const K = TEINTE.leurre, c1 = K.c1.join(','), c2 = K.c2.join(','), c3 = K.c3.join(','), ac = K.ac.join(','), R = rmRnd(4421);
  const k = rmCv(Math.ceil(3.1 * LB_PX), Math.ceil(2.6 * LB_PX)), g = k.getContext('2d');
  g.setTransform(LB_PX, 0, 0, LB_PX, .55 * LB_PX, 1.3 * LB_PX); g.lineCap = 'round';
  const goutte = (s, ox) => { g.beginPath(); g.moveTo(ox + -.3 * s, 0);
    g.bezierCurveTo(ox + .25 * s, .95 * s, ox + 1.95 * s, 1.15 * s, ox + 2.02 * s, 0); g.bezierCurveTo(ox + 1.95 * s, -1.15 * s, ox + .25 * s, -.95 * s, ox - .3 * s, 0); g.closePath(); };
  goutte(1, 0); g.fillStyle = 'rgba(' + c3 + ',.45)'; g.fill();
  g.save(); goutte(1, 0); g.clip();
  g.save(); g.translate(1.05, 0); g.scale(1.15, .95); const gr = g.createRadialGradient(-.1, -.15, 0, 0, 0, 1);
  gr.addColorStop(0, 'rgba(' + ac + ',.16)'); gr.addColorStop(.5, 'rgba(' + c1 + ',.1)'); gr.addColorStop(.8, 'rgba(' + c2 + ',.22)'); gr.addColorStop(1, 'rgba(' + c2 + ',.42)');
  g.fillStyle = gr; g.fillRect(-1.3, -1.3, 2.6, 2.6); g.restore();
  /* nervures : du col vers l'organe et au-delà, en éventail */
  g.beginPath(); for (let j = -3; j <= 3; j++) { const a = j * .17; g.moveTo(-.25, 0); g.bezierCurveTo(.25, a * 1.3, .7, a * 2.4, 1.05 + .4 * Math.cos(a * 3), a * 3.1 * (1 - .1 * Math.abs(j))); }
  g.strokeStyle = 'rgba(' + c2 + ',.08)'; g.lineWidth = .07; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.26)'; g.lineWidth = .018; g.stroke();
  /* membrane interne décalée */
  goutte(.78, .24); g.strokeStyle = 'rgba(' + c2 + ',.2)'; g.lineWidth = .028; g.stroke(); g.fillStyle = 'rgba(' + c1 + ',.05)'; g.fill();
  /* organe-appât : réflecteur sombre en coupe + lentille menthe */
  g.beginPath(); g.arc(1.02, 0, .5, Math.PI * .55, Math.PI * 1.45); g.strokeStyle = 'rgba(' + c3 + ',.35)'; g.lineWidth = .12; g.stroke(); g.strokeStyle = 'rgba(' + c1 + ',.12)'; g.lineWidth = .03; g.stroke();
  const gl = g.createRadialGradient(1.12, -.05, 0, 1.07, 0, .44); gl.addColorStop(0, 'rgba(' + c2 + ',.45)'); gl.addColorStop(.45, 'rgba(' + ac + ',.22)'); gl.addColorStop(1, 'rgba(' + ac + ',.06)');
  g.beginPath(); g.ellipse(1.07, 0, .42, .38, 0, 0, TAU); g.fillStyle = gl; g.fill(); g.strokeStyle = 'rgba(' + c2 + ',.3)'; g.lineWidth = .02; g.stroke();
  for (let i = 0; i < 70; i++) { const x = -.1 + 2 * R(), y = (R() - .5) * 1.7; g.fillStyle = 'rgba(' + c2 + ',' + (.05 + .1 * R()).toFixed(3) + ')'; g.fillRect(x, y, .025, .025); }
  g.restore();
  /* reflet de verre (croissant) + bord double */
  g.beginPath(); g.ellipse(.95, -.42, .55, .2, -.25, Math.PI * 1.1, Math.PI * 1.9); g.strokeStyle = 'rgba(' + c2 + ',.35)'; g.lineWidth = .05; g.stroke();
  goutte(1, 0); g.strokeStyle = 'rgba(' + c1 + ',.1)'; g.lineWidth = .2; g.stroke(); g.strokeStyle = 'rgba(' + c2 + ',.55)'; g.lineWidth = .035; g.stroke();
  return (RM.lb = k);
}
/* soies visco-élastiques : la pointe est une masse sur ressort amorti attachée à (base + repos) → retard, dépassement, retour */
function soieMaj(Hh, i, tx, ty, bx, by, L, dt) {
  const o = i * 4;
  if (!(Hh[o] === Hh[o])) { Hh[o] = tx; Hh[o + 1] = ty; Hh[o + 2] = Hh[o + 3] = 0; return; }
  const h = dt > .034 ? .034 : dt;
  Hh[o + 2] += ((tx - Hh[o]) * 90 - Hh[o + 2] * 11) * h; Hh[o + 3] += ((ty - Hh[o + 1]) * 90 - Hh[o + 3] * 11) * h;
  Hh[o] += Hh[o + 2] * h; Hh[o + 1] += Hh[o + 3] * h;
  const dx = Hh[o] - bx, dy = Hh[o + 1] - by, d = Math.hypot(dx, dy), m = 1.3 * L;
  if (d > m) { Hh[o] = bx + dx * m / d; Hh[o + 1] = by + dy * m / d; }
}
function soieTrace(ctx, bx, by, nx, ny, L, px, py, cw, dem) {   // base, direction de racine, longueur, pointe ; courbe continue (la racine part dans l'axe) ; dem : moitié de base seule (effilé)
  const mx = bx + nx * L * .45, my = by + ny * L * .45, qx = (mx + px) * .5 + cw * ny, qy = (my + py) * .5 - cw * nx;
  if (dem) { const ax = (bx + mx) * .5, ay = (by + my) * .5, bx2 = (mx + qx) * .5, by2 = (my + qy) * .5, cx2 = (qx + px) * .5, cy2 = (qy + py) * .5;   // de Casteljau t = .5
    const dx = (ax + bx2) * .5, dy = (ay + by2) * .5, ex = (bx2 + cx2) * .5, ey = (by2 + cy2) * .5; ctx.moveTo(bx, by); ctx.bezierCurveTo(ax, ay, dx, dy, (dx + ex) * .5, (dy + ey) * .5); return; }
  ctx.moveTo(bx, by); ctx.bezierCurveTo(mx, my, qx, qy, px, py);
}
function dessinerLeurre(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  if (RM.ancien) return dessinerLeurreR482(ctx, e, x, y, etat, st, b, T, dt, fr, run);
  const c = e.c, FL = racine.FLUID, V = e.vit, AC = e.ac, L = c.L || 80;
  /* —— cinématique : identique à R482 (positions du bulbe = physique) —— */
  const q = FL.crBulbe(c, fr, run ? st : null), q1 = FL.crBulbe(c, fr + 1, run ? st : null), app = run && !st.h ? cl01(Math.abs(st.att || 0) * 2.5 + Math.abs(st.ext || 0) / 25) : 0;
  const held = !!st.h && run;
  const idle = run ? 0 : .07 * Math.sin(T * .55 + e.ph) + .03 * Math.sin(T * 1.3);
  let phi = q[2] + idle, bx = x + L * Math.sin(phi), by = y + L * Math.cos(phi);
  if (held && b) { bx = b.x; by = b.y; }
  const dphi = run ? q1[2] - q[2] : .07 * .55 / 60 * Math.cos(T * .55 + e.ph);
  e.dp = e.dp == null ? dphi : e.dp + (dphi - e.dp) * Math.min(1, dt * 3);
  const hx = x + e.wx * 2.2 + 4 * Math.sin(T * .37 + e.ph), hy = y + e.wy * 1.6 + Math.sin(e.tl * .7 + e.ph) * 1.2 + 3 * Math.sin(T * .74 + e.ph);
  const ch = Math.atan2(by - hy, bx - hx), ax = ch + Math.PI + (.55 + .3 * Math.sin(e.tw * .6 + e.ph)) * (Math.sin(e.ph) >= 0 ? 1 : -1) - e.dp * 9 + .12 * e.wr + .38 * Math.sin(T * .45 + e.ph * 2);
  const ca = Math.cos(ax), sa = Math.sin(ax);
  const bend0 = Math.sin(e.tl * 1.7 + e.ph) * .9 + e.dp * 30, bend = bend0 / Math.sqrt(1 + bend0 * bend0 * .25), tbt = (1.3 + .8 * V) * (held ? .5 : 1), ww = T * 3.4 + e.ph;
  const fY = px => bend * (px - 7) * (px - 7) / 120 + tbt * Math.sin(ww - px * .33) * (9 - px) / 21;
  const xq = -12.9, yq = fY(xq), tx0 = hx + 1.35 * (ca * xq - sa * yq), ty0 = hy + 1.35 * (sa * xq + ca * yq);   // R494 : le filament naît au bout de la queue (jonction fondue)
  if (st.out === fr && run) e.fq = 0;
  if (e.fq != null) { e.fq += dt * 2.4; if (e.fq > 1.3) e.fq = null; }
  const FX = e.fx || (e.fx = new Float32Array(LRN)), FY = e.fy || (e.fy = new Float32Array(LRN));
  const dx = bx - tx0, dy = by - ty0, dl = Math.hypot(dx, dy) || 1, nx = -dy / dl, ny = dx / dl;
  const hk = ((-ca) * nx + (-sa) * ny) * dl * .5, amp = (.065 + .02 * V) * dl * (held ? .35 : 1), wt = e.tl * .9 + e.ph, lag = -e.dp * 26 * dl * (1 - app);
  for (let k = 0; k < LRN; k++) {
    const u = k / (LRN - 1), env = Math.sin(Math.PI * u), sw = Math.sin(wt - u * 7.4) * (.55 + .45 * u) + .2 * Math.sin(2.1 * wt - u * 13 + 1);
    let w = amp * env * sw + lag * u * (1 - u) * (1.3 - u) + hk * u * (1 - u) * (1 - u) * 2.2;
    if (e.fq != null) { const z = (u - e.fq) / .14; w += 7 * (1 - e.fq * .7) * Math.exp(-z * z) * Math.sin(u * 17 - e.fq * 14); }   // R494 : fouet adouci (plus de pli anguleux)
    FX[k] = tx0 + dx * u + nx * w; FY[k] = ty0 + dy * u + ny * w;
  }
  const tb = Math.atan2(FY[LRN - 1] - FY[LRN - 3], FX[LRN - 1] - FX[LRN - 3]);
  const bvx = run ? q1[0] - q[0] : 0, bvy = run ? q1[1] - q[1] : 0, cuX = Math.sin(T * .7 + e.ph) * 1.4, cuY = Math.cos(T * .53 + e.ph) * .8;
  /* —— lumière : appât, prise (éclair au bulbe puis onde qui REMONTE le filament jusqu'au corps), lancer (onde de fouet) —— */
  const pul = .5 + .5 * Math.sin(T * (1.7 + 2.5 * V) + e.ph), hit = st.in && run && fr - st.in < 30 && fr >= st.in ? 1 - (fr - st.in) / 30 : 0;
  if (st.in && run && fr === st.in) e.rmt = 0;
  if (e.rmt != null) { e.rmt += dt * 1.25; if (e.rmt > 1.35) e.rmt = null; }
  const rmt = e.rmt, ondeR = u => { if (rmt == null) return 0; const z = ((1 - u) - rmt) / .1; return z > -3 && z < 3 ? Math.exp(-z * z) * (1 - .45 * rmt) : 0; };
  const corpsLum = rmt != null && rmt > .9 ? Math.sin(Math.PI * Math.min(1, (rmt - .9) / .45)) : 0;
  ombre(ctx, e, hx, hy, 17, 10, ax, .5);
  ombre(ctx, e, bx, by, 14, 14, 0, .34 + .2 * AC);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* —— filament : tube effilé translucide (ruban rempli : bords lumineux, cœur clair), canal axial, perles —— */
  const RX = e.rx || (e.rx = new Float32Array(LRN * 2)), RY = e.ry || (e.ry = new Float32Array(LRN * 2));
  for (let k = 0; k < LRN; k++) {
    const k0 = k ? k - 1 : 0, k1 = k < LRN - 1 ? k + 1 : k, tx = FX[k1] - FX[k0], ty = FY[k1] - FY[k0], tl = Math.hypot(tx, ty) || 1, u = k / (LRN - 1);
    const w = (.95 - .58 * Math.pow(u, .7)) * (1 + .12 * Math.sin(T * 2.2 - u * 9)) * (held ? .85 : 1) + .5 * ondeR(u);
    RX[k] = FX[k] - ty / tl * w; RY[k] = FY[k] + tx / tl * w; RX[2 * LRN - 1 - k] = FX[k] + ty / tl * w; RY[2 * LRN - 1 - k] = FY[k] - tx / tl * w;
  }
  const ruban = () => { ctx.beginPath(); ctx.moveTo(RX[0], RY[0]); for (let k = 1; k < 2 * LRN; k++) ctx.lineTo(RX[k], RY[k]); ctx.closePath(); };
  ruban(); ctx.fillStyle = 'rgba(6,24,52,.4)'; ctx.globalAlpha = 1; ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = e.K1; ctx.globalAlpha = .1 + .06 * V + .05 * AC; ctx.fill();
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .045 + .03 * AC; ctx.lineWidth = 2.2; ctx.stroke();   // voile
  const bord = (s0) => { ctx.beginPath(); ctx.moveTo(RX[s0], RY[s0]); for (let k = 1; k < LRN; k++) ctx.lineTo(RX[s0 + k], RY[s0 + k]); };
  bord(0); ctx.strokeStyle = e.K2; ctx.globalAlpha = .28 + .12 * V + .1 * AC; ctx.lineWidth = .32; ctx.stroke();
  bord(LRN); ctx.globalAlpha = .18 + .1 * V; ctx.stroke();
  ctx.beginPath(); ctx.moveTo(FX[0], FY[0]); for (let k = 1; k < LRN - 1; k++) ctx.quadraticCurveTo(FX[k], FY[k], (FX[k] + FX[k + 1]) / 2, (FY[k] + FY[k + 1]) / 2); ctx.lineTo(FX[LRN - 1], FY[LRN - 1]);
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .2 + .1 * V; ctx.lineWidth = .22; ctx.stroke();   // canal axial
  /* perles (photophores) régulières le long du canal ; elles s'allument au passage des pulsations */
  const np = 2 + (V > .5 ? 1 : 0), vp = T * (.16 + .2 * V + .2 * AC) + e.ph;
  for (let k = 3; k < LRN - 1; k += 2) {
    const u = k / (LRN - 1); let w = 0; for (let j = 0; j < np; j++) { const z = (u - ((vp + j / np) % 1)) / .06; if (z > -3 && z < 3) w += Math.exp(-z * z); }
    w += 1.4 * ondeR(u);
    spr(ctx, e.SP, FX[k], FY[k], 1.05 + .9 * w, .16 + .1 * V + .55 * w);
  }
  for (let j = 0; j < np; j++) {                      // pulsations : halo doux multicouche qui descend
    const u = ((vp + j / np) % 1), g = u * (LRN - 1), i = Math.min(LRN - 2, g | 0), f = g - i, px = FX[i] + (FX[i + 1] - FX[i]) * f, py = FY[i] + (FY[i + 1] - FY[i]) * f, s = Math.sin(Math.PI * u);
    spr(ctx, e.SAG, px, py, 6 + 2 * AC, .1 * s); spr(ctx, e.SG, px, py, 3.2 + AC, .3 * s); spr(ctx, e.SP, px, py, 1.6 + .6 * AC, .55 * s);
  }
  if (rmt != null && rmt < 1) { const u = 1 - rmt, g = u * (LRN - 1), i = Math.min(LRN - 2, g | 0), f = g - i, px = FX[i] + (FX[i + 1] - FX[i]) * f, py = FY[i] + (FY[i + 1] - FY[i]) * f;
    spr(ctx, e.SAG, px, py, 9, .25 * (1 - .5 * rmt)); spr(ctx, e.SA, px, py, 2.6, .7 * (1 - .4 * rmt)); }
  /* soies du filament : couchées vers le bulbe, elles traînent derrière le balancement (ressorts amortis) */
  const NS = 14, SH = e.sh || (e.sh = new Float32Array(NS * 4).fill(NaN)), SL = e.sl || (e.sl = new Float32Array(NS * 5));
  let ns = 0;
  for (let j = 0; j < NS; j++) {
    const g = 2.4 + (j + .7 * (hs(j * 5.1 + e.i) - .5)) * (LRN - 3.8) / NS, i = g | 0, f = g - i, u = g / (LRN - 1), sd = (j & 1 ? 1 : -1) * (hs(j * 2.9 + e.i) > .82 ? -1 : 1), la = .14 + .42 * hs(j * 4.7 + e.i);
    const px = FX[i] + (FX[i + 1] - FX[i]) * f, py = FY[i] + (FY[i + 1] - FY[i]) * f, tx = FX[i + 1] - FX[i], ty = FY[i + 1] - FY[i], tl = Math.hypot(tx, ty) || 1, ux = tx / tl, uy = ty / tl;
    const rw = (.95 - .58 * Math.pow(u, .7)) * .75, bx0 = px - uy * sd * rw, by0 = py + ux * sd * rw;
    const Ls = (2.6 + 5 * Math.pow(hs(j * 1.7 + e.i), 1.5)) * (1 - .3 * u), nxs = -uy * sd * la + ux * (1 - la * la * .5), nys = ux * sd * la + uy * (1 - la * la * .5);
    const wq = Math.sin(T * (1.5 + .8 * hs(j * 3.7)) - u * 6 + j * 2.1) * 1.1, ox = nxs * Ls + cuX * .4 * u * hs(j * 1.3) + wq * -uy * sd, oy = nys * Ls + cuY * .4 * u * hs(j * 1.3) + wq * ux * sd;
    soieMaj(SH, j, bx0 + ox, by0 + oy, bx0, by0, Ls, dt);
    SL[ns * 5] = bx0; SL[ns * 5 + 1] = by0; SL[ns * 5 + 2] = nxs; SL[ns * 5 + 3] = nys; SL[ns * 5 + 4] = Ls; ns++;
  }
  for (let d = 0; d < 2; d++) { ctx.beginPath(); for (let j = 0; j < ns; j++) soieTrace(ctx, SL[j * 5], SL[j * 5 + 1], SL[j * 5 + 2], SL[j * 5 + 3], SL[j * 5 + 4], SH[j * 4], SH[j * 4 + 1], .3 * Math.sin(T * 2.3 + j), d);
    if (!d) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .04 + .03 * V; ctx.lineWidth = 1.2; ctx.stroke(); }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = d ? .12 + .06 * V : .08 + .05 * V; ctx.lineWidth = d ? .3 : .2; ctx.stroke(); }
  for (let j = 1; j < ns; j += 3) spr(ctx, e.SP, SH[j * 4], SH[j * 4 + 1], .7, .18 + .2 * V);
  /* —— corps : texture pré-rendue posée en 12 tranches cisaillées le long de l'onde de nage (une seule chair, sans jointure) —— */
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.translate(hx, hy); ctx.rotate(ax); ctx.scale(1.35, 1.35);
  const M0 = ctx.getTransform(), TX = lrTex(), NT = 12, sw = LR_W / NT;
  for (let s = 0; s < NT; s++) {
    const x0 = LR_X0 + s * sw, x1 = x0 + sw, f0 = fY(x0), sl = (fY(x1) - f0) / sw, ov = s < NT - 1 ? .09 : 0;
    ctx.setTransform(M0.a + M0.c * sl, M0.b + M0.d * sl, M0.c, M0.d, M0.e + M0.c * (f0 - sl * x0), M0.f + M0.d * (f0 - sl * x0));
    ctx.drawImage(TX, s * sw * LR_PX, 0, (sw + ov) * LR_PX, LR_H * LR_PX, x0, LR_Y0, sw + ov, LR_H);
  }
  ctx.setTransform(M0);
  const P = (px, py) => [px, py + fY(px)];
  ctx.globalCompositeOperation = 'lighter';
  /* lumière interne : vitellus menthe qui respire, onde de lumière qui court de la tête à la queue le long de la corde */
  let p = P(3.2, 1.2); spr(ctx, e.SAG, p[0], p[1], 4.2 + 1.2 * AC + 3 * corpsLum, .16 + .1 * Math.sin(e.tl * 1.4) + .4 * corpsLum); spr(ctx, e.SA, p[0], p[1], 1.6 + .5 * AC, .35 + .2 * Math.sin(e.tl * 1.4) + .4 * corpsLum);
  const uc = (e.tl * .45 + e.ph) % 1, xc = 6 - 18.5 * uc; p = P(xc, -.25); spr(ctx, e.SG, p[0], p[1], 2.4, .3 * Math.sin(Math.PI * uc) + .3 * corpsLum);
  spr(ctx, e.SP, p[0], p[1], .9, .5 * Math.sin(Math.PI * uc));
  p = P(7.25, -.5); spr(ctx, e.SP, p[0], p[1], 1.1, .25 + .2 * V + .4 * corpsLum);   // éclat de l'œil
  /* cils sensoriels de la tête et de la nageoire (deux passes, ils ondulent en vague) */
  ctx.beginPath();
  for (let j = 0; j < 9; j++) { const a = -1.25 + j * .31, cA = Math.cos(a), sA = Math.sin(a), pp = P(7 + 1.95 * cA, -.2 + 2.05 * sA); poil(ctx, pp[0], pp[1], cA * .6 - .4, sA, 1.1 + .9 * hs(j * 3.1), -.7 - e.dp * 20, 0, .5 * Math.sin(T * 2.6 - j * .8)); }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .05; ctx.lineWidth = .7; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .26; ctx.lineWidth = .12; ctx.stroke();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.restore();
  /* —— bulbe-appât : goutte pré-rendue (membranes, nervures, lentille), lueurs multicouches, couronne de cils à inertie —— */
  ctx.save(); ctx.lineCap = 'round';
  const rb = 4.6 + .5 * pul + 1.2 * AC + 1.2 * app, ex = FX[LRN - 1], ey = FY[LRN - 1], cb = Math.cos(tb), sb = Math.sin(tb);
  const gx = ex + cb * rb * .9, gy = ey + sb * rb * .9;
  const M1 = ctx.getTransform(), s1 = rb * (1 + .04 * Math.sin(T * 3.1 + e.ph) + .1 * hit);
  ctx.transform(cb * s1, sb * s1, -sb * s1 * (1 - .03 * pul), cb * s1 * (1 - .03 * pul), ex, ey);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; const BT = lbTex(); ctx.drawImage(BT, -.55, -1.3, BT.width / LB_PX, BT.height / LB_PX);
  ctx.setTransform(M1);
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SAG, gx, gy, 12 + 6 * pul + 10 * AC + 14 * hit + 10 * app, .1 + .1 * pul + .16 * AC + .3 * hit + .25 * app);
  spr(ctx, e.SAG, gx, gy, 6 + 2 * pul + 4 * hit, .16 + .12 * pul + .3 * hit);
  spr(ctx, e.SA, gx + cb * .2, gy + sb * .2, 2.4 + 1.3 * pul + 1.6 * hit, .5 + .35 * pul + .3 * hit);
  spr(ctx, e.SP, gx + cb * .3, gy + sb * .3, 1 + .4 * pul, .5 + .4 * pul);
  /* couronne : 16 cils souples qui naissent de la membrane, traînent et ondulent ; tendus vers la bille qui s'approche */
  const NC = 13, CH = e.ch || (e.ch = new Float32Array(NC * 4).fill(NaN)), CL = e.cl || (e.cl = new Float32Array(NC * 5));
  for (let j = 0; j < NC; j++) {
    const an = tb + (j / (NC - 1) - .5) * 4.4 + .18 * (hs(j * 7.3 + e.i) - .5), cA = Math.cos(an), sA = Math.sin(an), lx = .9 + 1.0 * cA * 1.0, rr = rb * (.95 + .1 * Math.cos(an - tb));
    const b0x = ex + cb * rb * .9 + cA * rr, b0y = ey + sb * rb * .9 + sA * rr, Lc = (3.8 + 5.5 * Math.pow(hs(j * 3.3 + e.i), 1.4) + 1.5 * AC) * (.7 + .3 * Math.cos(an - tb));
    let dxp = (-bvx * 3 + cuX) * .55, dyp = (-bvy * 3 + cuY) * .55; if (app && b) { dxp = (b.x - gx) * .12 * app + cuX * (1 - app); dyp = (b.y - gy) * .12 * app + cuY * (1 - app); }
    const wv = 1.1 * Math.sin(T * 2.3 + j * 1.1) * (.6 + .4 * hs(j * 1.9));
    soieMaj(CH, j, b0x + cA * Lc + dxp - sA * wv, b0y + sA * Lc + dyp + cA * wv, b0x, b0y, Lc, dt);
    CL[j * 5] = b0x; CL[j * 5 + 1] = b0y; CL[j * 5 + 2] = cA; CL[j * 5 + 3] = sA; CL[j * 5 + 4] = Lc;
  }
  for (let d = 0; d < 2; d++) { ctx.beginPath(); for (let j = 0; j < NC; j++) soieTrace(ctx, CL[j * 5], CL[j * 5 + 1], CL[j * 5 + 2], CL[j * 5 + 3], CL[j * 5 + 4], CH[j * 4], CH[j * 4 + 1], .8 * Math.sin(T * 1.7 + j * .9), d);
    if (!d) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .06 + .04 * pul + .1 * hit; ctx.lineWidth = 1.1; ctx.stroke(); }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = (d ? .16 : .12) + .08 * pul + .15 * hit; ctx.lineWidth = d ? .3 : .2; ctx.stroke(); }
  for (let j = 0; j < NC; j += 2) { const w = .5 + .5 * Math.sin(T * 2.6 - j * .7 + e.ph); spr(ctx, j % 4 ? e.SP : e.SA, CH[j * 4], CH[j * 4 + 1], .8 + .5 * w + .8 * hit, (.15 + .3 * w) * (.6 + .4 * pul) + .4 * hit); }
  /* plancton : il dérive vers l'appât et s'y éteint (elle se nourrit) */
  const sp = e.SP;
  for (let j = 0; j < 6; j++) {
    const P0 = 4.2 + 2.6 * hs(j * 3.1 + e.i), u = ((T + hs(j * 7.7 + e.i) * P0) % P0) / P0, an = hs(j * 5.3 + e.i) * TAU + .3 * Math.sin(T * .2 + j);
    const R0 = 26 + 34 * hs(j * 2.2 + e.i), sx = x + Math.sin(phi) * L * .8 + Math.cos(an) * R0, sy = y + Math.cos(phi) * L * .8 + Math.sin(an) * R0;
    const m = u * u * (3 - 2 * u), px = sx + (gx - sx) * m + Math.sin(T * 1.3 + j) * 2 * (1 - m), py = sy + (gy - sy) * m;
    spr(ctx, sp, px, py, 1.1 + .4 * hs(j), (u < .1 ? u * 10 : u > .92 ? (1 - u) * 12 : 1) * (.3 + .3 * m));
    if (u > .9) e.fl = Math.max(e.fl, .4);
  }
  if (e.fl > .05) spr(ctx, e.SAG, gx, gy, 16, .22 * e.fl);
  ctx.restore();
  e.lx = gx; e.ly = gy; e.hx = hx; e.hy = hy;
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
// ===== REPASSE M1-4 LEURRE FIN =====
// ===== REPASSE M1-4 SYSTOLE DEBUT (R494) : systole — tonneau de chair translucide (tube ombré pré-calculé, grain, fibres circulaires et
//   longitudinales, paroi interne, courant visible dans le tube), lèvres frangées de cils en vague, nœud pacemaker à nerfs lumineux,
//   vague de contraction qui s'allume en voyageant ; même profil, même rythme, même jet (rendu seul) =====
function rmGrain() {                                  // tuile de grain fin (une fois)
  if (RM.gr) return RM.gr;
  const k = rmCv(64, 64), g = k.getContext('2d'), R = rmRnd(31337);
  for (let i = 0; i < 260; i++) { const a = .05 + .22 * R() * R(); g.fillStyle = 'rgba(255,255,255,' + a.toFixed(3) + ')'; g.fillRect(R() * 64, R() * 64, R() < .8 ? 1 : 1.6, R() < .8 ? 1 : 1.6); }
  return (RM.gr = k);
}
function syCache(ctx, e) {                            // dégradés et motif propres au contexte (créés une fois, réutilisés)
  if (e.syc && e.syc.ctx === ctx) return e.syc;
  const K = TEINTE.systole, c1 = K.c1.join(','), c2 = K.c2.join(','), c3 = K.c3.join(',');
  const tube = ctx.createLinearGradient(0, -1, 0, 1);  // coupe du tube : rives denses et claires, cœur transparent (pellicule)
  tube.addColorStop(0, 'rgba(' + c2 + ',.34)'); tube.addColorStop(.1, 'rgba(' + c1 + ',.2)'); tube.addColorStop(.3, 'rgba(' + c1 + ',.07)'); tube.addColorStop(.55, 'rgba(' + c1 + ',.04)');
  tube.addColorStop(.8, 'rgba(' + c1 + ',.11)'); tube.addColorStop(.93, 'rgba(' + c1 + ',.2)'); tube.addColorStop(1, 'rgba(' + c2 + ',.3)');
  const lon = ctx.createLinearGradient(-1, 0, 1, 0);   // le long de l'axe : bouche plus sombre, tuyère plus vive
  lon.addColorStop(0, 'rgba(' + c3 + ',.35)'); lon.addColorStop(.35, 'rgba(' + c3 + ',0)'); lon.addColorStop(.8, 'rgba(' + c1 + ',0)'); lon.addColorStop(1, 'rgba(' + c1 + ',.12)');
  const ins = ctx.createLinearGradient(0, -1, 0, 1);   // lumière du tube interne (intestin) : creux sombre, bords nets
  ins.addColorStop(0, 'rgba(' + c3 + ',.05)'); ins.addColorStop(.25, 'rgba(' + c3 + ',.4)'); ins.addColorStop(.75, 'rgba(' + c3 + ',.4)'); ins.addColorStop(1, 'rgba(' + c3 + ',.05)');
  return (e.syc = { ctx, tube, lon, ins, gr: ctx.createPattern(rmGrain(), 'repeat') });
}
function dessinerSystole(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  if (RM.ancien) return dessinerSystoleR475(ctx, e, x, y, etat, st, b, T, dt, fr, run);
  const c = e.c, r = c.r || 30, per = c.per || 90, pd = c.dur || 14, sc = r / 24, V = e.vit, AC = e.ac;
  let hp;
  if (run) hp = (fr + (c.off || 0)) % per; else { e.hk = ((e.hk == null ? (c.off || 0) : e.hk) + dt * 60) % per; hp = e.hk; }
  const sys = hp < pd, us = sys ? hp / pd : 0, ud = sys ? 0 : (hp - pd) / (per - pd);
  const pr = sys ? 0 : Math.pow(ud, 1.6);
  e.sq = sys ? 1 : Math.max(0, (e.sq || 0) - dt * 4);
  const amp = 3 * (1 - .6 * AC), ox = e.wx * amp, oy = e.wy * amp * .8;
  const rot = (c.a || 0) * Math.PI / 180 + e.wr * .07 + .03 * Math.sin(e.tl * .7 + e.ph), co = Math.cos(rot), si = Math.sin(rot);
  const hl = r * .95, R0 = r * .46 * (1 + .1 * pr - .04 * (1 - pr) * (sys ? 0 : 1)) * (1 + .03 * Math.sin(e.rs * TAU));
  const rad = e.rad || (e.rad = new Float32Array(SYN + 1)), sqz = e.sqz || (e.sqz = new Float32Array(SYN + 1));
  const wc = -1.25 + 2.6 * us;
  /* R494 : la contraction ondule aussi l'axe (le tube se tord un peu derrière la vague) ; flexion lente de respiration */
  const ay = e.ay2 || (e.ay2 = new Float32Array(SYN + 1));
  for (let j = 0; j <= SYN; j++) {
    const s = j / SYN * 2 - 1, v = (s + 1) / 2, base = .8 + .16 * Math.sin(Math.PI * v) - .2 * v * v;
    const z = (s - wc) / .32, q = sys ? .46 * Math.exp(-z * z) : 0;
    sqz[j] = q; rad[j] = R0 * base * (1 - q) * (1 + .028 * Math.sin(v * 13 - e.tl * 2.2 + e.ph) * Math.sin(Math.PI * v));   // R494 : membrane qui ondule à peine
    ay[j] = (1.1 * Math.sin(e.tl * .9 - v * 3 + e.ph) * (.4 + .6 * v) + (sys ? 1.4 * Math.exp(-z * z) * Math.sin(v * 9 - us * 6) : 0)) * sc * (.5 + .5 * v * v);
  }
  const Q = e.Q; Q.cx = x; Q.cy = y; majPart(Q, dt);
  const L2W = (lx, ly, o) => { o[0] = x + ox + lx * co - ly * si; o[1] = y + oy + lx * si + ly * co; return o; }, pk = [0, 0];
  const C = syCache(ctx, e), X = j => (j / SYN * 2 - 1) * hl;
  ombre(ctx, e, x + ox, y + oy + 3, hl * 1.35, R0 * 1.9, rot, .58);
  ctx.save(); ctx.translate(x + ox, y + oy); ctx.rotate(rot); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, 0, 0, hl * 1.5, .05 + .06 * V + .14 * e.sq + .07 * pr);
  ctx.globalCompositeOperation = 'source-over';
  const bord = (k, sd) => { for (let j = 0; j <= SYN; j++) { const px = X(j), py = ay[j] + sd * rad[j] * k; j ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } };
  const corps = k => { ctx.beginPath(); bord(k, -1); for (let j = SYN; j >= 0; j--) ctx.lineTo(X(j), ay[j] + rad[j] * k); ctx.closePath(); };
  /* 1. chair : absorption, puis coupe de tube (dégradé étiré au corps), assombrissement côté bouche, grain */
  const Rm = R0 * .9;
  corps(1); ctx.fillStyle = K_AB; ctx.globalAlpha = .34; ctx.fill(); ctx.fillStyle = e.K3; ctx.globalAlpha = .32; ctx.fill();
  ctx.save(); ctx.scale(hl, Rm); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = C.tube; ctx.globalAlpha = .85 + .4 * pr + .5 * e.sq; ctx.fill(); ctx.restore();
  ctx.save(); ctx.scale(hl, Rm); ctx.fillStyle = C.lon; ctx.globalAlpha = 1; ctx.fill(); ctx.restore();
  ctx.save(); ctx.scale(.22, .22); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = C.gr; ctx.globalAlpha = .14 + .06 * V; ctx.fill(); ctx.restore();   // grain fin (motif)
  /* 2. paroi interne (intestin) : creux sombre à bords nets, courant de particules qui le traverse vers la tuyère */
  corps(.6); ctx.save(); ctx.scale(hl, Rm * .6); ctx.fillStyle = C.ins; ctx.globalAlpha = 1; ctx.fill(); ctx.restore();
  ctx.globalCompositeOperation = 'lighter';
  ctx.beginPath(); bord(.6, -1); ctx.moveTo(X(0), ay[0] + rad[0] * .6); bord(.6, 1);
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .06; ctx.lineWidth = 1.6 * sc; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .16 + .08 * V; ctx.lineWidth = .22 * sc; ctx.stroke();
  const fl = e.flu = ((e.flu || 0) + dt * (.12 + .25 * V + (sys ? 2.2 * (1 - us) : 0))) % 1;   // courant interne (aspiration lente, chasse à la systole)
  for (let i = 0; i < 9; i++) { const u = (fl + hs(i * 3.7 + e.i)) % 1, j = Math.min(SYN, Math.round(u * SYN)), ly = ay[j] + (hs(i * 5.1) * 2 - 1) * rad[j] * .45;
    spr(ctx, i % 3 ? e.SP : e.SA, X(0) + u * 2 * hl, ly, (.5 + .4 * hs(i)) * sc, (.12 + .2 * Math.sin(Math.PI * u)) * (.6 + .4 * V + .6 * e.sq)); }
  /* 3. fibres : longitudinales (nervures qui épousent le profil) et circulaires (demi-anneaux avant, très fins, serrés) */
  ctx.beginPath(); for (const k of [-.6, .45]) { for (let j = 0; j <= SYN; j++) { const px = X(j), py = ay[j] + k * rad[j]; j ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .04 + .02 * V; ctx.lineWidth = 1.2 * sc; ctx.stroke(); ctx.globalAlpha = .06 + .03 * V; ctx.lineWidth = .12 * sc; ctx.stroke();
  ctx.beginPath(); for (const j9 of [1.6, 3.9, 5.7, 7.9, 9.6, 11.8, 13.5]) { const jj = j9 + .35 * Math.sin(e.tl * .8 + j9),  s0 = Math.floor(jj), f = jj - s0, rr = rad[s0] + (rad[Math.min(SYN, s0 + 1)] - rad[s0]) * f, py = ay[s0] + (ay[Math.min(SYN, s0 + 1)] - ay[s0]) * f, px = (jj / SYN * 2 - 1) * hl;
    ctx.moveTo(px, py - rr * .95); ctx.ellipse(px, py, (1.1 + .4 * Math.sin(jj * 2.3)) * sc, rr * .95, 0, -Math.PI / 2, Math.PI / 2); }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .02 + .015 * V + .03 * pr; ctx.lineWidth = 1.5 * sc; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .04 + .02 * V + .04 * pr; ctx.lineWidth = .11 * sc; ctx.stroke();
  /* R494 · vacuole contractile étoilée (langage du figurant systole) : se remplit en diastole, se vide d'un coup à la systole */
  const vx0 = -hl * .3, vy0 = ay[5] - rad[0] * .12, vr = (1.2 + 2.6 * pr) * sc * (sys ? 1 - .8 * Math.sin(Math.PI * Math.min(1, us * 2)) : 1);
  ctx.beginPath(); for (let k = 0; k < 7; k++) { const a = k / 7 * TAU + .3 + .08 * Math.sin(e.tl + k), l = vr + (2.6 + 1.2 * pr) * sc;
    ctx.moveTo(vx0 + Math.cos(a) * vr * .8, vy0 + Math.sin(a) * vr * .8); ctx.quadraticCurveTo(vx0 + Math.cos(a + .25) * l * .7, vy0 + Math.sin(a + .25) * l * .7, vx0 + Math.cos(a + .1) * l, vy0 + Math.sin(a + .1) * l); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .05 + .05 * pr; ctx.lineWidth = 1.2 * sc; ctx.stroke(); ctx.globalAlpha = .14 + .16 * pr; ctx.lineWidth = .16 * sc; ctx.stroke();
  ctx.beginPath(); ctx.arc(vx0, vy0, vr, 0, TAU); ctx.fillStyle = e.K1; ctx.globalAlpha = .05 + .07 * pr; ctx.fill(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .18 + .2 * pr; ctx.lineWidth = .16 * sc; ctx.stroke();
  spr(ctx, e.SG, vx0, vy0, vr * 2.2, .06 + .12 * pr);
  /* vacuoles nutritives : anneaux à cœur sombre qui tournent lentement (cyclose) */
  for (let k = 0; k < 4; k++) { const u = (e.tl * .035 + k * .27 + hs(k * 9.1 + e.i)) % 1, j = Math.min(SYN, Math.round((.15 + .7 * u) * SYN)), px = X(j), py = ay[j] + Math.sin(u * TAU * 2 + k) * rad[j] * .35, rv = (.7 + .5 * hs(k * 4.4)) * sc;
    ctx.beginPath(); ctx.arc(px, py, rv, 0, TAU); ctx.fillStyle = e.K3; ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = .35; ctx.fill(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .16 + .06 * V; ctx.lineWidth = .14 * sc; ctx.stroke(); spr(ctx, e.SP, px - rv * .3, py - rv * .3, rv * .7, .12); }
  /* 4. vague de contraction : bande de lumière qui voyage (anneaux serrés allumés, halo large + filet) */
  if (sys || e.sq > .05) { const wq = Math.max(-.99, Math.min(.99, wc)), jx = (wq + 1) / 2 * SYN, j0 = Math.min(SYN - 1, Math.floor(jx)), f = jx - j0, rr = rad[j0] + (rad[j0 + 1] - rad[j0]) * f, py = ay[j0] + (ay[j0 + 1] - ay[j0]) * f, px = wq * hl, I = sys ? Math.sin(Math.PI * us) * .6 + .4 : e.sq * .5;
    for (const d of [-1.6, 0, 1.6]) { ctx.beginPath(); ctx.ellipse(px + d * sc, py, 1.4 * sc, rr * .98, 0, 0, TAU); ctx.strokeStyle = e.K2; ctx.globalAlpha = .07 * I; ctx.lineWidth = 3 * sc; ctx.stroke(); ctx.globalAlpha = (d ? .25 : .55) * I; ctx.lineWidth = .3 * sc; ctx.stroke(); }
    spr(ctx, e.SG, px, py, rr * 1.6, .25 * I); }
  /* 5. bord : double trait doux (voile large et bas + filet fin), jamais un contour dur ; reflet spéculaire haut */
  ctx.beginPath(); bord(1, -1); ctx.moveTo(X(0), ay[0] + rad[0]); bord(1, 1);
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .07 + .04 * e.sq; ctx.lineWidth = 3 * sc; ctx.stroke();
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .09 + .05 * V; ctx.lineWidth = 1 * sc; ctx.stroke(); ctx.globalAlpha = .26 + .1 * V + .2 * e.sq; ctx.lineWidth = .2 * sc + .08; ctx.stroke();
  /* R494 · fourrure de cils des flancs : courts, en vague métachronale (deux passes : voile + filet) */
  for (let d = 0; d < 2; d++) { ctx.beginPath();
    for (const sd of [-1, 1]) for (let j = 1; j < SYN; j += .5) { const j0 = Math.floor(j), f = j - j0, rr = rad[j0] + (rad[j0 + 1] - rad[j0]) * f, yy = ay[j0] + (ay[j0 + 1] - ay[j0]) * f, px = (j / SYN * 2 - 1) * hl, py = yy + sd * rr;
      const w = Math.sin(e.tl * (4 + 3 * V) - j * .9 + (sd > 0 ? 1.3 : 0)), Lc = (1.3 + .5 * hs(j * 7.1 + sd) + .5 * w) * sc;
      ctx.moveTo(px, py); ctx.quadraticCurveTo(px - w * .4 * sc, py + sd * Lc * .6, px - (.9 + w * .7) * sc, py + sd * Lc); }
    ctx.strokeStyle = d ? e.K2 : e.K1; ctx.globalAlpha = d ? .2 + .08 * V : .06; ctx.lineWidth = (d ? .16 : .8) * sc; ctx.stroke(); }
  ctx.beginPath(); for (let j = 2; j <= SYN - 2; j++) { const px = X(j), py = ay[j] - rad[j] * .78; j > 2 ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = .1 + .05 * V; ctx.lineWidth = 1.1 * sc; ctx.stroke();
  /* 6. tuyère (devant) : lèvre fine fondue au bord ; bouche (derrière) : collerette translucide + frange de cils en vague métachronale */
  const rT = rad[SYN], rB = rad[0], yT = ay[SYN], yB = ay[0];
  ctx.beginPath(); ctx.ellipse(hl, yT, (1.3 + 1 * e.sq) * sc, rT, 0, -Math.PI / 2, Math.PI / 2); ctx.strokeStyle = e.K2; ctx.globalAlpha = .07 + .1 * e.sq; ctx.lineWidth = 2 * sc; ctx.stroke(); ctx.globalAlpha = .26 + .4 * e.sq; ctx.lineWidth = .2 * sc; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(hl, yT, (1.3 + 1 * e.sq) * sc, rT, 0, Math.PI / 2, Math.PI * 1.5); ctx.globalAlpha = .08 + .2 * e.sq; ctx.stroke();
  const ouv = 1 + .3 * pr;
  ctx.beginPath(); ctx.ellipse(-hl, yB, 2.6 * sc * ouv, rB * 1.04, 0, 0, TAU); ctx.fillStyle = e.K1; ctx.globalAlpha = .04 + .04 * pr; ctx.fill();
  ctx.beginPath(); ctx.ellipse(-hl, yB, 2.6 * sc * ouv, rB, 0, Math.PI / 2, Math.PI * 1.5); ctx.strokeStyle = e.K2; ctx.globalAlpha = .3 + .15 * pr; ctx.lineWidth = .22 * sc; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(-hl, yB, 2.6 * sc * ouv, rB, 0, -Math.PI / 2, Math.PI / 2); ctx.globalAlpha = .1 + .06 * pr; ctx.stroke();
  const NCI = 30, bat = 5 + 5 * pr;
  for (let d = 0; d < 2; d++) { ctx.beginPath();
    for (let j = 0; j < NCI; j++) { const q = -Math.PI / 2 + (j + .5) / NCI * Math.PI, cq = Math.cos(q), sq = Math.sin(q), ly = yB + sq * rB, lx = -hl - cq * 2.6 * sc * ouv * .9, w = Math.sin(e.tl * bat - j * .55);
      const Lc = (2.3 + .9 * hs(j * 3.3 + e.i) + 1.3 * w) * sc * (.8 + .3 * cq), dx = -(.85 + .25 * cq) * Lc, dy = sq * Lc * .45 + w * .6 * sc;
      ctx.moveTo(lx, ly); if (d) ctx.quadraticCurveTo(lx + dx * .45, ly + dy * .2, lx + dx * .5, ly + dy * .5); else ctx.quadraticCurveTo(lx + dx * .55, ly + dy * .1 - w * .5 * sc, lx + dx, ly + dy); }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = d ? .3 + .2 * pr : .13 + .1 * pr; ctx.lineWidth = (d ? .3 : .2) * sc; ctx.stroke(); }
  /* 7. nœud pervenche (pacemaker) : halos multicouches, nerfs fins qui partent vers la tuyère et s'allument à la décharge */
  const nb = sys ? 1 - us : .25 + .75 * pr, nx0 = -hl * .62, ny0 = ay[3] - rB * .2;
  spr(ctx, e.SAG, nx0, ny0, (8 + 6 * nb) * sc, .1 + .22 * nb); spr(ctx, e.SAG, nx0, ny0, (3.5 + 2 * nb) * sc, .2 + .35 * nb); spr(ctx, e.SA, nx0, ny0, (1.6 + 1 * nb) * sc, .45 + .55 * nb);
  ctx.beginPath(); for (const k of [-.5, .3]) { ctx.moveTo(nx0, ny0); let px = nx0, py = ny0; for (let j = 5; j <= SYN - 1; j += 3) { const qx = X(j), qy = ay[j] + k * rad[j] * (.4 + .6 * j / SYN) + .6 * sc * Math.sin(j * 1.7 + k * 5); ctx.quadraticCurveTo(px, py, (px + qx) / 2, (py + qy) / 2); px = qx; py = qy; } }
  ctx.strokeStyle = 'rgb(156,168,255)'; ctx.globalAlpha = .03 + .05 * nb; ctx.lineWidth = .9 * sc; ctx.stroke(); ctx.globalAlpha = .06 + .16 * nb * (sys ? 1 : .5); ctx.lineWidth = .12 * sc; ctx.stroke();
  if (sys) for (const k of [-.5, .3]) { const u = Math.min(1, us * 1.6), j = Math.min(SYN, Math.round(3 + u * (SYN - 4))); spr(ctx, e.SA, X(j), ay[j] + k * rad[j] * (.4 + .6 * j / SYN), 1.2 * sc, .6 * (1 - u)); }   // l'influx court le long des nerfs
  /* 8. photophores du dos (se chargent un à un, puis l'onde court) : halo + cœur */
  const NP = 7;
  for (let j = 0; j < NP; j++) { const u = (j + .5) / NP, jj = Math.round(u * SYN), lx = (u * 2 - 1) * hl * .86;
    const ch = sys ? Math.exp(-Math.pow((u * 2 - 1 - wc) / .3, 2)) : cl01((pr * 1.08 - u * .92) * 9), w = ondeA(e, u);
    spr(ctx, e.SG, lx, ay[jj] - rad[jj] * .72, (2.4 + 2.5 * ch) * sc, .06 + .3 * ch + .15 * w);
    spr(ctx, e.SP, lx, ay[jj] - rad[jj] * .72, (.8 + 1.1 * ch + .6 * w) * sc, .14 + .6 * ch + .35 * w + .1 * V);
    spr(ctx, e.SP, lx, ay[jj] + rad[jj] * .72, (.6 + .8 * ch) * sc, .08 + .4 * ch * (1 - .5 * u)); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  /* 9. le milieu : aspiration (poussières vers la bouche) en diastole ; jet de traînées + volutes à la systole (inchangé) */
  e.tArc -= dt;
  if (!sys && e.tArc <= 0) { const sd = hs(T * 3.7) - .5; L2W(-hl - r * (.55 + .35 * hs(T * 5.3)), sd * r * 1.1, pk);
    const p2 = L2W(-hl, sd * rB * .6, [0, 0]), vx = (p2[0] - pk[0]) * 1.3, vy = (p2[1] - pk[1]) * 1.3;
    emP(Q, 1, pk[0], pk[1], vx, vy, .7, .35 + .3 * pr, .2); e.tArc = .3 + .35 * (1 - pr); }
  if (sys && dt > 0) { const n = 2 + (AC > .5 ? 2 : 0);
    for (let j = 0; j < n; j++) { const sd = (hs(T * 9.1 + j) - .5), v = (55 + 40 * hs(T * 4.3 + j)) * (1 - .4 * us), p0 = L2W(hl, yT + sd * rT * 1.4, pk), aj = rot + sd * .35;
      emP(Q, 1, p0[0], p0[1], Math.cos(aj) * v, Math.sin(aj) * v, .45 + .2 * hs(T * 2.2 + j), .9 + .5 * e.sq, 2.4); } }
  if (!sys && e.wasSys) {
    for (const sg of [-1, 1]) { const p0 = L2W(hl + r * .6, yT + sg * rT * 1.2, pk); emP(Q, 3, p0[0], p0[1], Math.cos(rot) * 8, Math.sin(rot) * 8, 1.1, 4.5 * sc, sg); } }
  e.wasSys = sys;
  dessinerPart(ctx, Q, e);
}
// ===== REPASSE M1-4 SYSTOLE FIN =====
// ===== REPASSE M1-4 BRAISE DEBUT (R494) : braise — tore de chair translucide en volume (tube ombré en couches), peau qui ROULE (granules
//   et cellules emportés par l'éversion), voile central à nervures où la lumière voyage, fourrure continue de cils effilés en vague
//   métachronale (plus de clignotement), éclat de prise qui fait le tour de l'anneau. Même géométrie, mêmes horloges (rendu seul) =====
function dessinerBraise(ctx, e, x, y, etat, st, b, T, dt, fr) {
  if (RM.ancien) return dessinerBraiseR481(ctx, e, x, y, etat, st, b, T, dt, fr);
  const c = e.c, r = (c.r || 26) * 1.2, sc = r / 26, V = e.vit, AC = e.ac;
  const ox = e.wx * 2.2, oy = e.wy * 2 + 1.5 * Math.sin(e.tl * .7 + e.ph), cx = x + ox, cy = y + oy;
  const flash = st.in != null && fr >= st.in && fr - st.in < 40 ? 1 - (fr - st.in) / 40 : 0;
  if (st.in != null && st.in !== e.lastIn && fr >= st.in && fr - st.in < 4) { e.lastIn = st.in; e.fl = 1; e.tour = 0; e.tourA = b ? Math.atan2(b.y - cy, b.x - cx) : 0;
    if (b) { const a0 = Math.atan2(b.vy, b.vx); for (let k = 0; k < 9; k++) { const a = a0 + (hs(T * 3 + k) - .5) * .9, v = 40 + 50 * hs(T * 5 + k); emP(e.Q, 1, b.x, b.y, Math.cos(a) * v, Math.sin(a) * v, .5 + .3 * hs(k + T), 1.2, 1.6); } } }
  e.fl = Math.max(0, (e.fl || 0) - dt * 1.5);
  if (e.tour != null) { e.tour += dt * 1.6; if (e.tour > 1.2) e.tour = null; }
  e.ev = (e.ev || 0) + dt * (.35 + .7 * V + 1.6 * AC + 2.5 * e.fl);
  const cu = (T + e.ph * 3) % 11, flip = cu < 1.6 ? .5 - .5 * Math.cos(Math.PI * cu / 1.6) : 0;
  const dv = (T + e.ph * 5) % 17, pinch = AC > .4 ? 0 : dv < 3.2 ? Math.sin(Math.PI * dv / 3.2) * .9 : 0;
  const tilt = 1.02 + .12 * Math.sin(e.tl * .4 + e.ph) + flip * Math.PI, ct = Math.cos(tilt), stt = Math.sin(tilt);
  let rot = .25 * Math.sin(e.tw * .6 + e.ph) + e.wr * .1;
  if (b && etat >= 1) { const ab = Math.atan2(b.y - cy, b.x - cx) - Math.PI / 2; e.ro = (e.ro == null ? rot : e.ro) + (crWrapA(ab - (e.ro || 0)) * .25) * Math.min(1, dt * 3); rot = e.ro; } else e.ro = rot;
  const co = Math.cos(rot), si = Math.sin(rot), Rm = r * .74, rt = r * .27 * (1 + .1 * e.fl - .06 * AC);
  const Q = e.Q; Q.cx = cx; Q.cy = cy; majPart(Q, dt);
  const P = (phi, psi, out) => {
    const rr = Rm * (1 - pinch * .5 * Math.pow(Math.sin(phi), 2)) + rt * Math.cos(psi), X = rr * Math.cos(phi), Yp = rr * Math.sin(phi), Z = rt * Math.sin(psi);
    const Y = Yp * ct - Z * stt, D = Yp * stt + Z * ct;
    out[0] = cx + X * co - Y * si; out[1] = cy + X * si + Y * co; out[2] = D; return out; };
  const pt = e.pt || (e.pt = [0, 0, 0]);
  const NR = 40, tourL = phi => { if (e.tour == null) return 0; let d = Math.abs(crWrapA(phi + rot - e.tourA)) / Math.PI - e.tour; return Math.exp(-d * d * 30) * (1 - .6 * e.tour); };   // éclat qui fait le tour
  ombre(ctx, e, cx, cy + 4, Rm * 1.55, Rm * (.95 + .5 * Math.abs(ct)), rot, .78);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  spr(ctx, e.SG, cx, cy, Rm * 2.1, .06 + .08 * V + .18 * AC + .3 * e.fl);
  /* 1. voile central : film très fin tendu dans le trou, nervures radiales où des perles de lumière voyagent vers l'anneau */
  ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath(); for (let i = 0; i <= NR; i++) { P(i / NR * TAU, Math.PI, pt); i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); } ctx.closePath();
  ctx.fillStyle = e.K3; ctx.globalAlpha = .3; ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = e.K1; ctx.globalAlpha = .035 + .03 * V + .08 * e.fl; ctx.fill();
  const NV = 12, hb = .5 + .5 * Math.sin(e.tl * (1.5 + 3 * AC) + e.ph);
  ctx.beginPath(); for (let k = 0; k < NV; k++) { const phi = (k + .3 * Math.sin(k * 2.1)) / NV * TAU; P(phi, Math.PI, pt); const mx = cx + (pt[0] - cx) * .5 + (pt[1] - cy) * .08, my = cy + (pt[1] - cy) * .5 - (pt[0] - cx) * .08;
    ctx.moveTo(cx, cy); ctx.quadraticCurveTo(mx, my, pt[0], pt[1]); }
  ctx.strokeStyle = e.K1; ctx.globalAlpha = .04 + .03 * V; ctx.lineWidth = 1.4 * sc; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .1 + .06 * V + .2 * e.fl; ctx.lineWidth = .16 * sc; ctx.stroke();
  for (let k = 0; k < NV; k += 2) { const u = (e.tl * .5 + k * .37) % 1, phi = (k + .3 * Math.sin(k * 2.1)) / NV * TAU; P(phi, Math.PI, pt);
    spr(ctx, e.SP, cx + (pt[0] - cx) * u, cy + (pt[1] - cy) * u, (.7 + .5 * hb) * sc, .25 * Math.sin(Math.PI * u) * (.5 + .5 * V + AC)); }
  /* 2. tube en volume : couches concentriques le long de l'âme (absorption, chair, cœur clair) + liserés doux des deux bords */
  const AX = e.amx || (e.amx = new Float32Array(NR + 1)), AY = e.amy || (e.amy = new Float32Array(NR + 1)), AD = e.amd || (e.amd = new Float32Array(NR + 1));
  for (let i = 0; i <= NR; i++) { const phi = i / NR * TAU, rr = Rm * (1 - pinch * .5 * Math.pow(Math.sin(phi), 2)), X0 = rr * Math.cos(phi), Y0 = rr * Math.sin(phi) * ct;
    AX[i] = cx + X0 * co - Y0 * si; AY[i] = cy + X0 * si + Y0 * co; AD[i] = rr * Math.sin(phi) * stt; }
  ctx.beginPath(); for (let i = 0; i <= NR; i++) i ? ctx.lineTo(AX[i], AY[i]) : ctx.moveTo(AX[i], AY[i]);
  ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = e.K3; ctx.globalAlpha = .5; ctx.lineWidth = rt * 2.1; ctx.stroke();
  ctx.globalCompositeOperation = 'lighter';
  const lum = .6 + .5 * V + .6 * AC + 1.2 * e.fl;
  {                                                   // le tore a un dessus et un dessous : un dégradé (arrière pâle → avant vif) porte la lumière du tube, sans jointure
    const ib = Math.round(NR * .75), iF = Math.round(NR * .25), fs = AD[iF] >= 0 ? 1 : -1, K = TEINTE.braise.c1.join(','), K2b = TEINTE.braise.c2.join(',');
    const g1 = ctx.createLinearGradient(fs > 0 ? AX[ib] : AX[iF], fs > 0 ? AY[ib] : AY[iF], fs > 0 ? AX[iF] : AX[ib], fs > 0 ? AY[iF] : AY[ib]);
    g1.addColorStop(0, 'rgba(' + K + ',.45)'); g1.addColorStop(.5, 'rgba(' + K + ',.75)'); g1.addColorStop(1, 'rgba(' + K2b + ',1)');
    ctx.strokeStyle = g1; for (const [w, a] of [[1.75, .075], [.5, .08]]) { ctx.globalAlpha = a * lum; ctx.lineWidth = rt * w; ctx.stroke(); }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .05 + .04 * V; ctx.lineWidth = rt * .12; ctx.stroke(); }
  for (const psi of [0, Math.PI]) { ctx.beginPath(); for (let i = 0; i <= NR; i++) { P(i / NR * TAU, psi, pt); i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = .05 + .03 * V; ctx.lineWidth = 1.6 * sc; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = (psi ? .14 : .2) + .08 * V + .15 * e.fl; ctx.lineWidth = .22 * sc; ctx.stroke(); }
  /* 3. peau qui roule : bandes d'éversion très douces (voile) + granules/cellules emportés autour du tube (avant vifs, arrière pâles) */
  const e0 = e.ev * 1.4;
  for (let k = 0; k < BK; k++) { const psi = e0 + k * TAU / BK, fz = .5 + .5 * Math.cos(psi);
    ctx.beginPath(); let on = false; for (let i = 0; i <= NR; i++) { P(i / NR * TAU, psi, pt); if (pt[2] >= -rt * .2) { on ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); on = true; } else on = false; }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = (.03 + .07 * fz) * lum; ctx.lineWidth = .3 * sc; ctx.stroke(); }
  const NG = 26;
  for (let g = 0; g < NG; g++) { const phi = (g + hs(g * 3.3) * .8) / NG * TAU, psi = e0 * (1 + .05 * hs(g)) + hs(g * 7.7) * TAU; P(phi, psi, pt); const fz = cl01(.5 + pt[2] / (rt * 2)), w = tourL(phi);
    spr(ctx, g % 5 ? e.SP : e.SA, pt[0], pt[1], (.45 + .35 * hs(g * 1.9) + .6 * w) * sc, (.06 + .22 * fz) * (.7 + .3 * V + .5 * AC) + .6 * w * fz); }
  /* 4. fourrure de cils : continue (plus de clignotement), effilée, en vague métachronale ; pointes qui s'allument en onde */
  const NCB = 54, Lc = (3 + 1.4 * V + 2.4 * AC + 2.2 * e.fl) * sc, TP = e.tp2 || (e.tp2 = new Float32Array(NCB * 3)); let nt = 0;
  for (let d = 0; d < 2; d++) { ctx.beginPath();
    for (let i = 0; i < NCB; i++) { const inn = i >= 40, phi = inn ? (i - 40 + .5 * hs(i * 4.1)) / 14 * TAU : (i + .5 * hs(i * 4.1)) / 40 * TAU, psi = (inn ? Math.PI : 0) + (hs(i * 2.3) - .5) * .9; P(phi, psi, pt);
      const ia = Math.round(phi / TAU * NR) % (NR + 1); let nx = pt[0] - AX[ia], ny = pt[1] - AY[ia], l = Math.hypot(nx, ny); if (l < rt * .35) { nx = (pt[0] - cx) * (inn ? -1 : 1); ny = (pt[1] - cy) * (inn ? -1 : 1); l = Math.hypot(nx, ny) || 1; }
      const ux = nx / l, uy = ny / l, bat = Math.sin(e.tl * 4.2 - phi * 3) * .8 + .25 * Math.sin(e.tl * 1.1 + i), L = Lc * (.55 + .8 * hs(i * 5.7) * hs(i * 1.3 + 2)) * (1 + .15 * Math.sin(e.tl * 1.3 + i)) * (inn ? .5 : 1);
      const mx = pt[0] + ux * L * .5 - uy * bat * L * .25, my = pt[1] + uy * L * .5 + ux * bat * L * .25, qx = pt[0] + ux * L - uy * bat * L * .75, qy = pt[1] + uy * L + ux * bat * L * .75;
      ctx.moveTo(pt[0], pt[1]);
      if (d) ctx.quadraticCurveTo((pt[0] + mx) / 2, (pt[1] + my) / 2, (pt[0] + 2 * mx + qx) / 4, (pt[1] + 2 * my + qy) / 4); else { ctx.quadraticCurveTo(mx, my, qx, qy); if (nt < NCB) { TP[nt * 3] = qx; TP[nt * 3 + 1] = qy; TP[nt * 3 + 2] = phi; nt++; } } }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = d ? .24 + .14 * V + .2 * AC + .3 * e.fl : .13 + .08 * V + .12 * AC + .2 * e.fl; ctx.lineWidth = (d ? .26 : .16) * sc; ctx.stroke();
  }
  const SM = e.SM || (e.SM = sprite('braisem', [150, 255, 222], 'p'));
  for (let j = 0; j < nt; j++) { const w = Math.pow(.5 + .5 * Math.sin(e.tl * 2.2 - TP[j * 3 + 2] * 2), 4), t2 = tourL(TP[j * 3 + 2]); if (w + t2 < .15) continue;
    spr(ctx, SM, TP[j * 3], TP[j * 3 + 1], (.6 + .5 * w + .6 * t2) * sc, (.12 + .4 * w) * (.5 + .5 * V + .5 * AC) + .6 * t2 + .3 * e.fl); }
  /* 5. les cellules du Chœur font le tour du tube : petites cellules translucides (membrane + noyau), nettes à l'avant */
  for (let i = 0; i < 8; i++) {
    const phi = i * TAU / 8 + e.ev * .12, psi = e0 * .9 + i * 1.3; P(phi, psi, pt); const fz = cl01(.5 + pt[2] / (rt * 2)), w = ondeA(e, i / 8), rc = 1.7 * sc;
    spr(ctx, e.SG, pt[0], pt[1], (2.2 + 1.5 * w + .8 * e.fl) * sc, (.06 + .2 * fz) * (.6 + .4 * V) + .3 * w);
    if (fz > .45) { ctx.beginPath(); ctx.arc(pt[0], pt[1], rc, 0, TAU); ctx.fillStyle = e.K1; ctx.globalAlpha = .05 + .06 * fz; ctx.fill(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .1 + .2 * fz; ctx.lineWidth = .14 * sc; ctx.stroke();
      spr(ctx, e.SP, pt[0] + .3 * rc, pt[1] - .2 * rc, (.5 + .4 * w) * sc, .2 + .3 * fz + .4 * w); }
  }
  /* 6. cœur lumineux au centre du voile (halos multicouches, noyau blanc), bat lentement, s'emballe en alerte */
  const SW = e.SW || (e.SW = sprite('braisec', [236, 250, 255], 'p'));
  spr(ctx, e.SAG, cx, cy, (6 + 3 * hb + 7 * e.fl) * sc, .16 + .12 * hb + .3 * e.fl); spr(ctx, e.SG, cx, cy, (3.2 + 1.5 * hb) * sc, .24 + .14 * hb); spr(ctx, SW, cx, cy, (1.5 + .6 * hb) * sc, .5 + .3 * hb + .3 * e.fl);
  if (flash > 0) spr(ctx, e.SAG, cx, cy, Rm * 1.4, .25 * flash);
  if (dt > 0 && hs(T * 13.1) < .08 + .3 * AC + .5 * e.fl) { const a = hs(T * 2.9) * TAU; P(a, 0, pt); emP(Q, 1, pt[0], pt[1], (hs(T * 4.1) - .5) * 10, -12 - 18 * hs(T * 6.3), .9 + .6 * hs(T), .6 + .5 * AC, .4); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
  e.lx = cx; e.ly = cy;
  dessinerPart(ctx, Q, e);
}
// ===== REPASSE M1-4 BRAISE FIN =====
// ===== REPASSE M1-4 DEMO DEBUT (R494) : planches de test (créature active isolée, mondes 1 à 4) =====
racine.QXCREA.rmAncien = v => { RM.ancien = v ? 1 : 0; };
racine.QXCREA.rmTex = n => ({ lr: lrTex, lb: lbTex })[n]();
racine.QXCREA.actDemo = (ctx, lv, env) => { if (!lv) { act = null; return 0; } dessinerAct(ctx, lv, env); return act; };
// ===== REPASSE M1-4 DEMO FIN =====
})(window);
