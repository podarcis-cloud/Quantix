/* QXCREA R469 · moteur de créatures (QXMOTIFS, banc v5) + évasion de Fluides sur la constellation + décor vivant des niveaux Fluides (QXCREA.niveau). Chargé à la demande par engine.js (jamais au démarrage). */
/* =====================================================================
   QXMOTIFS — motifs de décor du monde « Mécanique des fluides ».
   Aucune dépendance au DOM : chaque motif ne connaît que le contexte 2D
   qu'on lui passe dans draw(). Coordonnées = unités de niveau (360 × 470).
   API : QXMOTIFS.<nom> = { init(w,h,seed,opts), update(dt,flow,energy), draw(ctx,alpha) }
         QXMOTIFS.create(nom) → nouvelle instance indépendante (même API).
   flow(x,y) → [u,v] en unités/s ; le tableau rendu peut être réutilisé
   par l'appelant : on le lit immédiatement, on ne le conserve jamais.
   ===================================================================== */
(function (racine) {
  'use strict';

  /* ---------- Jetons de palette (seul endroit où vivent les couleurs) ---------- */
  const palette = {
    abysse:  [4, 10, 18],     // fond le plus profond
    sarcelle:[46, 120, 128],  // bleu-vert profond (corps, voiles)
    aqua:    [118, 200, 196], // halos froids
    perle:   [214, 230, 232], // membranes, liserés nacrés
    ambre:   [226, 168, 96],  // touches chaudes rares
    lueur:   [110, 238, 196], // bioluminescence froide aqua-vert
    mauve:   [182, 154, 232], // la particule (seule teinte chaude-froide hors décor)
    // Opacité de base de chaque motif (multipliée par l'alpha de draw) ;
    // biolum module toutes les lueurs (0 = éteint), modifiable à chaud.
    alpha: { cells: 0.5, filament: 0.6, top: 0.5, snow: 0.75, bubbles: 0.6, biolum: 1 }
  };
  /* ---------- Rythme de la bioluminescence (impulsions lentes et irrégulières) ---------- */
  const BIO = {
    attente: [1.5, 6],        // pause aléatoire entre deux impulsions (s), raccourcie par energy
    duree: [3.5, 6],          // durée d'un passage complet (s)
    intensite: [0.35, 0.6],   // intensité ordinaire
    probaVive: 0.55,          // × energy² : chance qu'une impulsion soit vive (intensité 1, plus rapide)
    probaAmbre: 0.15          // chance d'un passage ambre
  };
  const TAU = Math.PI * 2;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const rgb = c => rgba(c, 1);

  /* ---------- Utilitaires partagés ---------- */
  // Générateur pseudo-aléatoire déterministe (mulberry32)
  function aleatoire(graine) {
    let s = graine >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  // Ramène v dans [a-m, b+m] en le faisant réapparaître de l'autre côté
  function enroule(v, a, b, m) {
    const L = b - a + 2 * m;
    if (v < a - m) return v + L;
    if (v > b + m) return v - L;
    return v;
  }
  // Rotationnel local du champ (s⁻¹) par différences finies
  function tourbillon(flow, x, y, h) {
    const a = flow(x + h, y)[1], b = flow(x - h, y)[1];
    const c = flow(x, y + h)[0], d = flow(x, y - h)[0];
    return ((a - b) - (c - d)) / (2 * h);
  }
  // Petite aide de cache : les dégradés dépendent du contexte, on les recrée si celui-ci change
  function cacheContexte(fabrique) {
    let ctxCourant = null, valeur = null;
    return ctx => {
      if (ctx !== ctxCourant) { ctxCourant = ctx; valeur = fabrique(ctx); }
      return valeur;
    };
  }

  // Impulsion lumineuse : pos parcourt 0 → 1 le long de l'organisme, puis repos
  function lueurNeuve(r) {
    return { pos: 0, vit: 0, int: 0, attente: r() * BIO.attente[1], ambre: false };
  }
  function avancerLueur(l, dt, energy, r) {
    if (l.int > 0) {
      l.pos += l.vit * dt;
      if (l.pos > 1.2) { l.int = 0; l.attente = BIO.attente[0] + r() * (BIO.attente[1] - BIO.attente[0]); }
      return;
    }
    l.attente -= dt * (1 + 2.5 * energy);
    if (l.attente > 0) return;
    const vive = r() < BIO.probaVive * energy * energy;
    l.pos = 0;
    l.vit = (vive ? 1.6 : 1) / (BIO.duree[0] + r() * (BIO.duree[1] - BIO.duree[0]));
    l.int = vive ? 1 : BIO.intensite[0] + r() * (BIO.intensite[1] - BIO.intensite[0]);
    l.ambre = r() < BIO.probaAmbre;
  }
  // Enveloppe douce d'une impulsion (monte, tient, s'éteint)
  const enveloppe = l => l.int * Math.sin(Math.PI * borne(l.pos / 1.2, 0, 1));
  const cloche = (d, w) => Math.exp(-(d * d) / (w * w));
  const enrouleAngle = d => d - Math.round(d / TAU) * TAU;
  // Particule : excitation 0 (loin) → 1 (au contact), lue dans RG.part = { on, x, y }
  function excitation(RG, x, y, portee) {
    const p = RG.part;
    if (!p || !p.on) return 0;
    return borne(1 - Math.hypot(p.x - x, p.y - y) / portee, 0, 1);
  }

  /* =====================================================================
     1. CELLULES — paramécies translucides
     ===================================================================== */
  function creerCellules() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NB_CILS = 80;
    const cosC = new Float32Array(NB_CILS), sinC = new Float32Array(NB_CILS);
    for (let i = 0; i < NB_CILS; i++) { cosC[i] = Math.cos(i / NB_CILS * TAU); sinC[i] = Math.sin(i / NB_CILS * TAU); }
    let W = 360, H = 470, cellules = [], t = 0;
    const couleurs = {
      membrane: rgb(P.perle), cils: rgb(P.perle), vacuole: rgb(P.perle),
      ombre: rgb(P.abysse), noyau: rgb(P.aqua), ambre: rgb(P.ambre), lueur: rgb(P.lueur)
    };
    const BANDES_CILS = [0.5, 0.26, 0.1];      // demi-largeurs angulaires (rad) des bandes de cils allumés
    const ALPHA_BANDES = [0.35, 0.55, 0.9];
    let rl = Math.random;                       // tirages du rythme lumineux
    // Trace les cils d'indice [i0, i1] (modulo NB_CILS) avec la même géométrie que le tracé normal
    function cheminCils(ctx, c, a, b, i0, i1) {
      for (let j = i0; j <= i1; j++) {
        const i = ((j % NB_CILS) + NB_CILS) % NB_CILS;
        const px = a * cosC[i], py = b * sinC[i];
        let nx = b * cosC[i], ny = a * sinC[i];
        const nl = 1 / Math.hypot(nx, ny); nx *= nl; ny *= nl;
        const ph = c.cph + c.ph - i * 0.55;
        const L = (2.6 + 1.6 * Math.sin(ph)) * (1 + 0.6 * c.exc * (1 + 0.6 * Math.max(0, Math.cos(i / NB_CILS * TAU - c.pv))));
        const pli = (1.4 + 1.2 * c.exc) * Math.cos(ph);  // battement tangent
        ctx.moveTo(px + nx * 0.8, py + ny * 0.8);
        ctx.lineTo(px + nx * (0.8 + L) - ny * pli, py + ny * (0.8 + L) + nx * pli);
      }
    }
    // Corps : disque unité, cœur presque vide, bord lumineux (lu sous scale(a,b))
    const degrades = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.07));
      g.addColorStop(0.55, rgba(P.sarcelle, 0.10));
      g.addColorStop(0.86, rgba(P.aqua, 0.16));
      g.addColorStop(0.97, rgba(P.perle, 0.30));
      g.addColorStop(1, rgba(P.perle, 0));
      return { corps: g };
    });

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const q = borne((opts && opts.quality) || 1, 0.5, 1);
        const r = aleatoire(seed);
        rl = aleatoire(seed ^ 0x9e37);
        const n = (opts && opts.n) || Math.max(3, Math.round(5 * q));
        cellules = [];
        for (let i = 0; i < n; i++) {
          const a = 30 + r() * 20;
          const prof = 0.6 + r() * 0.4;               // profondeur : petite = lointaine, plus pâle
          const vac = [];
          const nv = 4 + Math.floor(r() * 6);
          for (let k = 0; k < nv; k++) {
            const ang = r() * TAU, rad = Math.sqrt(r()) * 0.55;
            vac.push({ ox: Math.cos(ang) * rad - 0.15, oy: Math.sin(ang) * rad * 0.8, r: 2.2 + r() * 3, ph: r() * TAU });
          }
          const grains = new Float32Array(2 * Math.round(14 * q));
          for (let k = 0; k < grains.length; k += 2) {
            const ang = r() * TAU, rad = Math.sqrt(r()) * 0.8;
            grains[k] = Math.cos(ang) * rad; grains[k + 1] = Math.sin(ang) * rad;
          }
          cellules.push({
            x: r() * W, y: r() * H, vx: 0, vy: 0,
            a: a * prof, b: a * prof * (0.46 + r() * 0.08), prof,
            ang: r() * TAU, rot: (r() - 0.5) * 0.3, ph: r() * TAU,
            etire: 1, vac, grains, noyau: { ox: 0.1 + r() * 0.2, oy: (r() - 0.5) * 0.3, r: 0.22 + r() * 0.08 },
            ambre: r() < 0.25, lueur: lueurNeuve(r), exc: 0, cph: 0, pv: 0, gobe: 0
          });
        }
      },

      reglage(o) { if (o && o.gobe !== undefined) { cellules[o.gobe].gobe = 1; return; } Object.assign(RG, o); },
      n() { return cellules.length; },
      pos(i) { const c = cellules[i]; return [c.x, c.y]; },
      // Placement direct du corps (la mise en scène pilote la position ; les appendices suivent)
      place(i, x, y) { const c = cellules[i]; c.x = x; c.y = y; },
      vise(i, tx, ty, g) { const c = cellules[i]; c.tx = tx; c.ty = ty; c.g = g; },
      geo() { return cellules.map(c => ({ k: 'cell', x: c.x, y: c.y, ang: c.ang, a: c.a * c.etire, b: c.b / Math.sqrt(c.etire) })); },
      update(dt, flow, energy) {
        t += dt;
        const k = Math.min(1, dt * 1.2);
        for (const c of cellules) {
          const f = flow(c.x, c.y); const u = f[0], v = f[1];
          // Nage propre le long du grand axe + entraînement par le courant (plus fort pour les proches)
          const nage = (3 + 4 * energy) * RG.vit;
          const cx = Math.cos(c.ang), cy = Math.sin(c.ang);
          c.vx += (u * 0.55 * c.prof + cx * nage - c.vx) * k;
          c.vy += (v * 0.55 * c.prof + cy * nage - c.vy) * k;
          c.x = enroule(c.x + c.vx * dt, 0, W, 50);
          c.y = enroule(c.y + c.vy * dt, 0, H, 50);
          // Le tourbillon local fait tourner la cellule ; elle s'oriente doucement vers sa vitesse
          const w = tourbillon(flow, c.x, c.y, 12);
          const vit = Math.hypot(c.vx, c.vy);
          let cible = Math.atan2(c.vy, c.vx) - c.ang;
          cible -= Math.round(cible / TAU) * TAU;
          c.ang += (c.rot + 0.5 * w + cible * Math.min(1, vit / 40) * 0.6) * dt;
          if (c.g) { let d = Math.atan2(c.ty - c.y, c.tx - c.x) - c.ang; d -= Math.round(d / TAU) * TAU; c.ang += d * c.g * 2 * dt; c.vx += Math.cos(c.ang) * c.g * 30 * dt; c.vy += Math.sin(c.ang) * c.g * 30 * dt; }
          // Étirement le long de l'axe selon la vitesse relative : la membrane cède un peu
          // Particule : les cils s'emballent (surtout du côté qui la regarde), le corps s'effile
          // pour l'attaque, se ramasse pour la fuite
          c.exc += (excitation(RG, c.x, c.y, 150) - c.exc) * k;
          if (RG.part && RG.part.on) c.pv = Math.atan2(RG.part.y - c.y, RG.part.x - c.x) - c.ang;
          c.cph += dt * (4.5 + vit * 0.08 + 4 * energy + 14 * c.exc * (RG.mode === 'cont' ? 0.35 : 1));
          const forme = RG.mode === 'agr' ? 0.28 : RG.mode === 'evite' ? -0.24 : RG.mode === 'cont' ? -0.06 : 0.08;
          const cibleEtire = Math.max(0.74, 1 + Math.min(0.22, vit / 180) + 0.03 * Math.sin(t * 1.3 + c.ph) + forme * c.exc);
          c.etire += (cibleEtire - c.etire) * k;
          c.gobe = Math.max(0, c.gobe - dt * 0.35);
          avancerLueur(c.lueur, dt, energy, rl);
        }
      },

      draw(ctx, alpha) {
        const A = alpha * P.alpha.cells;
        if (A <= 0.001) return;
        const g = degrades(ctx);
        ctx.save();
        ctx.lineCap = 'round';
        for (const c of cellules) {
          const a = c.a * c.etire, b = c.b / Math.sqrt(c.etire); // conserve l'aire
          const Ac = A * (0.5 + 0.5 * c.prof);
          ctx.save();
          ctx.translate(c.x, c.y);
          ctx.rotate(c.ang);

          // Corps translucide (dégradé unité étiré en ellipse)
          ctx.save();
          ctx.scale(a, b);
          ctx.globalAlpha = Ac;
          ctx.fillStyle = g.corps;
          ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fill();
          ctx.restore();

          // Cils : vague métachronale qui parcourt le pourtour, tracée deux fois (flou + net)
          ctx.beginPath();
          cheminCils(ctx, c, a, b, 0, NB_CILS - 1);
          ctx.strokeStyle = couleurs.cils;
          ctx.globalAlpha = Ac * 0.07; ctx.lineWidth = 2.4; ctx.stroke();
          ctx.globalAlpha = Ac * 0.22; ctx.lineWidth = 0.55; ctx.stroke();

          // Double membrane : liseré lumineux + paroi intérieure
          ctx.strokeStyle = couleurs.membrane;
          ctx.beginPath(); ctx.ellipse(0, 0, a, b, 0, 0, TAU);
          ctx.globalAlpha = Ac * 0.06; ctx.lineWidth = 5; ctx.stroke();      // halo flou
          ctx.globalAlpha = Ac * 0.55; ctx.lineWidth = 0.9; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, 0, a * 0.9, b * 0.84, 0, 0, TAU);
          ctx.globalAlpha = Ac * 0.14; ctx.lineWidth = 1.6; ctx.stroke();

          // Sillon oral : courbe douce de l'avant vers le milieu
          ctx.beginPath();
          ctx.moveTo(a * 0.75, -b * 0.35);
          ctx.quadraticCurveTo(a * 0.2, b * 0.25, -a * 0.05, b * 0.05);
          ctx.globalAlpha = Ac * 0.16; ctx.lineWidth = 0.8; ctx.stroke();

          // Granulations (texture cytoplasmique)
          ctx.fillStyle = couleurs.membrane;
          ctx.globalAlpha = Ac * 0.22;
          ctx.beginPath();
          for (let k = 0; k < c.grains.length; k += 2) ctx.rect(c.grains[k] * a - 0.4, c.grains[k + 1] * b - 0.4, 0.8, 0.8);
          ctx.fill();

          // Noyau : grand anneau diffus
          const n = c.noyau;
          ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, n.r * b * 1.6, 0, TAU);
          ctx.fillStyle = couleurs.noyau; ctx.globalAlpha = Ac * 0.06; ctx.fill();
          ctx.strokeStyle = couleurs.membrane; ctx.globalAlpha = Ac * 0.13; ctx.lineWidth = 0.7; ctx.stroke();

          // Vacuoles : anneaux qui respirent, intérieur légèrement assombri
          ctx.beginPath();
          for (const v of c.vac) {
            const rr = v.r * c.prof * (1 + 0.12 * Math.sin(t * 1.7 + v.ph));
            const vx = v.ox * a, vy = v.oy * b;
            ctx.moveTo(vx + rr, vy); ctx.arc(vx, vy, rr, 0, TAU);
          }
          ctx.fillStyle = couleurs.ombre; ctx.globalAlpha = Ac * 0.35; ctx.fill();
          ctx.strokeStyle = c.ambre ? couleurs.ambre : couleurs.vacuole;
          ctx.globalAlpha = Ac * 0.5; ctx.lineWidth = 0.8; ctx.stroke();

          // Bioluminescence : l'impulsion fait le tour de la membrane le long des rangées de cils,
          // puis saute de vacuole en vacuole
          const I = Ac * P.alpha.biolum * enveloppe(c.lueur);
          if (I > 0.004) {
            const pos = c.lueur.pos;
            const th = c.ph + pos * TAU * 1.1;      // tête de l'impulsion
            ctx.globalCompositeOperation = 'lighter';
            const teinte = c.lueur.ambre ? couleurs.ambre : couleurs.lueur;
            ctx.strokeStyle = teinte; ctx.fillStyle = teinte;
            // Membrane : halo diffus + filet net, traîne derrière la tête
            ctx.beginPath(); ctx.ellipse(0, 0, a + 1, b + 1, 0, th - 1.1, th + 0.15);
            ctx.globalAlpha = I * 0.16; ctx.lineWidth = 9; ctx.stroke();
            ctx.globalAlpha = I * 0.6; ctx.lineWidth = 1.2; ctx.stroke();
            // Cils allumés, en bandes concentriques (dégradé sans dégradé)
            const ic = th / TAU * NB_CILS;
            for (let k = 0; k < BANDES_CILS.length; k++) {
              const dn = BANDES_CILS[k] / TAU * NB_CILS;
              ctx.beginPath(); cheminCils(ctx, c, a, b, Math.round(ic - dn * 2.2), Math.round(ic + dn * 0.6));
              ctx.globalAlpha = I * ALPHA_BANDES[k]; ctx.lineWidth = 0.7 + k * 0.1; ctx.stroke();
            }
            // Vacuoles : relais successifs, chacune avec un halo doux
            const nv = c.vac.length;
            for (let k = 0; k < nv; k++) {
              const v = c.vac[k];
              const iv = I * cloche(pos - (0.25 + 0.75 * k / nv), 0.09);
              if (iv < 0.004) continue;
              const rr = v.r * c.prof * (1 + 0.12 * Math.sin(t * 1.7 + v.ph));
              const vx = v.ox * a, vy = v.oy * b;
              ctx.beginPath(); ctx.arc(vx, vy, rr * 2.4, 0, TAU);
              ctx.globalAlpha = iv * 0.16; ctx.fill();
              ctx.beginPath(); ctx.arc(vx, vy, rr, 0, TAU);
              ctx.globalAlpha = Math.min(1, iv * 1.4); ctx.lineWidth = 1; ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
          }
          if (c.gobe > 0.004) {
            ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = rgb(P.mauve);
            ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, b * (0.5 + 0.8 * c.gobe), 0, TAU); ctx.globalAlpha = Ac * 0.35 * c.gobe; ctx.fill();
            ctx.beginPath(); ctx.arc(n.ox * a, n.oy * b, 1.5 + 2.5 * c.gobe, 0, TAU); ctx.globalAlpha = Ac * 1.4 * c.gobe; ctx.fill();
            ctx.globalCompositeOperation = 'source-over';
          }

          ctx.restore();
        }
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     2. FILAMENT — flagellé nacré (chaîne suivie-du-chef)
     ===================================================================== */
  function creerFilament() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const N = 32, SEG = 4.8;
    // Profil de largeur : tête bulbeuse, cou pincé, corps effilé
    const larg = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const s = i / (N - 1);
      larg[i] = i < 5 ? 5.6 + 1.2 * Math.sin(i / 4 * Math.PI) : i === 5 ? 3.0 : 3.4 * (1 - (s - 0.18) / 0.82) + 0.7;
    }
    const gx = new Float32Array(N), gy = new Float32Array(N); // bord gauche
    const dx = new Float32Array(N), dy = new Float32Array(N); // bord droit
    const nxs = new Float32Array(N), nys = new Float32Array(N);
    // Onde de nage : amplitude croissante vers la queue, ~0,9 longueur d'onde sur le corps
    const NAGE = { amplitude: 6.5, nombreOnde: 0.9, pulsation: 4.2, gainEnergie: 3.5, sillage: 0.18 };
    const ampl = new Float32Array(N);
    for (let i = 0; i < N; i++) { const s = i / (N - 1); ampl[i] = NAGE.amplitude * (0.08 + 0.92 * Math.pow(s, 1.3)); }
    let W = 360, H = 470, vers = [], t = 0, rl = Math.random;
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre) };

    function nouveau(r) {
      const px = new Float32Array(N), py = new Float32Array(N);   // ligne moyenne (trajectoire)
      const qx = new Float32Array(N), qy = new Float32Array(N);   // corps affiché (ligne + onde)
      const x = r() * W, y = r() * H, cap = r() * TAU;
      for (let i = 0; i < N; i++) {
        px[i] = x - Math.cos(cap) * SEG * i;
        py[i] = y - Math.sin(cap) * SEG * i;
      }
      return { px, py, qx, qy, cap, ph: r() * TAU, phase: 0, freq: 1.5 + r() * 0.4, echelle: 0.9 + r() * 0.25, lueurs: [lueurNeuve(r), lueurNeuve(r)], exc: 0, amp: 1, gobe: 0 };
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const q = borne((opts && opts.quality) || 1, 0.5, 1);
        const r = aleatoire(seed);
        rl = aleatoire(seed ^ 0x51ed);
        vers = [];
        const n = (opts && opts.n) || (q >= 0.75 ? 2 : 1);
        for (let i = 0; i < n; i++) {
          const v = nouveau(r);
          if (i > 0) for (let k = 0; k < N; k++) { v.px[k] += W / 2; v.py[k] += H / 2; }
          vers.push(v);
        }
      },

      reglage(o) { if (o && o.gobe !== undefined) { vers[o.gobe].gobe = 1; return; } Object.assign(RG, o); },
      n() { return vers.length; },
      pos(i) { return [vers[i].px[0], vers[i].py[0]]; },
      place(i, x, y) { vers[i].px[0] = x; vers[i].py[0] = y; },
      vise(i, tx, ty, g) { const v = vers[i]; v.tx = tx; v.ty = ty; v.g = g; },
      geo() { return vers.map(v => ({ k: 'chaine', px: v.qx, py: v.qy, lg: larg, N, e: v.echelle, p: { ant: 34, queue: 2, flancs: 0, voile: 9 } })); },
      update(dt, flow, energy) {
        t += dt;
        const dtc = Math.min(dt, 1 / 30);
        for (const v of vers) {
          const { px, py } = v;
          // Pilotage : errance lente + retour vers le centre près des bords
          const ecX = W / 2 - px[0], ecY = H / 2 - py[0];
          const loin = Math.min(1, Math.hypot(ecX, ecY) / 220);
          let versCentre = Math.atan2(ecY, ecX) - v.cap;
          versCentre -= Math.round(versCentre / TAU) * TAU;
          v.cap += (0.35 * Math.sin(t * 0.29 + v.ph) + versCentre * loin * loin * 0.8) * dtc;
          // Légère embardée de la tête (la propulsion vient de l'onde du corps)
          const balai = v.cap + NAGE.sillage * Math.sin(t * v.freq + v.ph);
          if (v.g) { let d = Math.atan2(v.ty - py[0], v.tx - px[0]) - v.cap; d -= Math.round(d / TAU) * TAU; v.cap += d * v.g * 2.2 * dtc; }
          const vit = (12 + 14 * energy) * v.echelle * RG.vit;
          v.exc += (excitation(RG, px[0], py[0], 160) - v.exc) * Math.min(1, dtc * 2.5);
          const md = RG.mode, ampC = 1 + v.exc * (md === 'agr' ? -0.45 : md === 'evite' ? 0.5 : md === 'cont' ? -0.25 : 0.2);
          v.amp += (ampC - v.amp) * Math.min(1, dtc * 2);
          v.phase += (NAGE.pulsation + NAGE.gainEnergie * energy + v.exc * (md === 'cont' ? 1 : 5)) * dtc * (0.5 + 0.5 * RG.vit);
          v.gobe = Math.max(0, v.gobe - dtc * 0.35);
          const f = flow(px[0], py[0]);
          px[0] += (Math.cos(balai) * vit + f[0] * 0.8) * dtc;
          py[0] += (Math.sin(balai) * vit + f[1] * 0.8) * dtc;
          // Corps cinématique (suivi du chef, sans inertie) : il repasse dans le sillage de la tête,
          // d'où l'onde qui descend le long du corps ; le courant le déporte un peu.
          for (let i = 1; i < N; i++) {
            const fi = flow(px[i], py[i]);
            px[i] += fi[0] * 0.3 * dtc; py[i] += fi[1] * 0.3 * dtc;
          }
          // Lissage léger (raideur en flexion) puis contraintes de longueur
          for (let i = 1; i < N - 1; i++) {
            px[i] += ((px[i - 1] + px[i + 1]) * 0.5 - px[i]) * 0.03;
            py[i] += ((py[i - 1] + py[i + 1]) * 0.5 - py[i]) * 0.03;
          }
          const seg = SEG * v.echelle;
          for (let i = 1; i < N; i++) {
            const ex = px[i] - px[i - 1], ey = py[i] - py[i - 1];
            const k = seg / (Math.hypot(ex, ey) || 1);
            px[i] = px[i - 1] + ex * k; py[i] = py[i - 1] + ey * k;
          }
          // Sortie d'écran : tout le ver passe de l'autre côté
          const m = 90;
          let sx = 0, sy = 0;
          if (px[0] < -m) sx = W + 2 * m; else if (px[0] > W + m) sx = -(W + 2 * m);
          if (py[0] < -m) sy = H + 2 * m; else if (py[0] > H + m) sy = -(H + 2 * m);
          if (sx || sy) for (let i = 0; i < N; i++) { px[i] += sx; py[i] += sy; }
          // Corps affiché : onde progressive tête → queue, perpendiculaire à la ligne moyenne
          const e = v.echelle;
          for (let i = 0; i < N; i++) {
            const a = i > 0 ? i - 1 : 0, b = i < N - 1 ? i + 1 : N - 1;
            let tx = px[a] - px[b], ty = py[a] - py[b];
            const l = 1 / (Math.hypot(tx, ty) || 1);
            const dep = ampl[i] * e * v.amp * Math.sin(v.phase - i / (N - 1) * NAGE.nombreOnde * TAU);
            v.qx[i] = px[i] - ty * l * dep; v.qy[i] = py[i] + tx * l * dep;
          }
          avancerLueur(v.lueurs[0], dt, energy, rl);
          avancerLueur(v.lueurs[1], dt, energy, rl);
        }
      },

      draw(ctx, alpha) {
        const A = alpha * P.alpha.filament;
        if (A <= 0.001) return;
        ctx.save();
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        for (const v of vers) {
          const px = v.qx, py = v.qy, e = v.echelle;
          // Contour : normales lissées sur les voisins
          for (let i = 0; i < N; i++) {
            const a = i > 0 ? i - 1 : 0, b = i < N - 1 ? i + 1 : N - 1;
            let tx = px[a] - px[b], ty = py[a] - py[b];
            const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
            const w = larg[i] * e;
            nxs[i] = -ty; nys[i] = tx;
            gx[i] = px[i] - ty * w; gy[i] = py[i] + tx * w;
            dx[i] = px[i] + ty * w; dy[i] = py[i] - tx * w;
          }
          const capTete = Math.atan2(py[0] - py[1], px[0] - px[1]);
          // Halo aqua très doux le long de l'axe
          ctx.beginPath(); ctx.moveTo(px[0], py[0]);
          for (let i = 1; i < N; i++) ctx.lineTo(px[i], py[i]);
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.05; ctx.lineWidth = 16 * e; ctx.stroke();

          // Corps translucide + liseré nacré
          // Contour fermé : bord gauche, calotte de tête, bord droit
          ctx.beginPath();
          ctx.moveTo(gx[N - 1], gy[N - 1]);
          for (let i = N - 2; i >= 1; i--) ctx.lineTo(gx[i], gy[i]);
          ctx.arc(px[0], py[0], larg[0] * e, capTete + Math.PI / 2, capTete - Math.PI / 2, true);
          for (let i = 1; i < N; i++) ctx.lineTo(dx[i], dy[i]);
          ctx.closePath();
        
          ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.22; ctx.fill();
          ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.08; ctx.fill();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.8; ctx.stroke();

          // Reflet tubulaire : ligne claire décalée côté lumière
          ctx.beginPath();
          for (let i = 1; i < N - 2; i++) {
            const k = larg[i] * e * 0.45;
            const x = px[i] + nxs[i] * k, y = py[i] + nys[i] * k;
            i === 1 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
          }
          ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.7; ctx.stroke();

          // Annelures discrètes le long du corps
          ctx.beginPath();
          for (let i = 6; i < N - 1; i += 2) {
            const k = larg[i] * e * 0.7;
            ctx.moveTo(px[i] - nxs[i] * k, py[i] - nys[i] * k);
            ctx.lineTo(px[i] + nxs[i] * k, py[i] + nys[i] * k);
          }
          ctx.globalAlpha = A * 0.12; ctx.lineWidth = 0.5; ctx.stroke();

          // Tête : deux vacuoles près du cou + strie interne
          ctx.beginPath();
          for (let s = -1; s <= 1; s += 2) {
            const x = px[3] + nxs[3] * s * 2.2 * e, y = py[3] + nys[3] * s * 2.2 * e;
            ctx.moveTo(x + 1.3 * e, y); ctx.arc(x, y, 1.3 * e, 0, TAU);
          }
          ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath();
          ctx.arc(px[1], py[1], 2.8 * e, capTete - 1.2, capTete + 1.2);
          ctx.globalAlpha = A * 0.18; ctx.stroke();

          // Bioluminescence : impulsions qui descendent de la tête vers la queue
          ctx.globalCompositeOperation = 'lighter';
          for (let k = 0; k < 2; k++) {
            const lu = v.lueurs[k];
            const I = A * P.alpha.biolum * enveloppe(lu);
            if (I < 0.004) continue;
            const c = lu.pos * (N + 4) - 2;              // nœud éclairé (peut déborder aux extrémités)
            ctx.strokeStyle = lu.ambre ? coul.ambre : coul.lueur;
            const i0 = Math.max(0, Math.floor(c - 6)), i1 = Math.min(N - 1, Math.ceil(c + 2));
            for (let i = i0; i < i1; i++) {
              const li = I * cloche(i + 0.5 - c, i + 0.5 < c ? 4 : 1.5);   // traîne derrière, front net
              if (li < 0.004) continue;
              ctx.beginPath(); ctx.moveTo(px[i], py[i]); ctx.lineTo(px[i + 1], py[i + 1]);
              ctx.globalAlpha = li * 0.13; ctx.lineWidth = larg[i] * e * 3.6; ctx.stroke();   // halo
              ctx.globalAlpha = li * 0.8; ctx.lineWidth = larg[i] * e * 0.8; ctx.stroke();    // cœur
            }
          }
          // Les deux vacuoles du cou respirent faiblement
          const souffle = A * P.alpha.biolum * 0.18 * (0.5 + 0.5 * Math.sin(t * 0.7 + v.ph));
          if (souffle > 0.004) {
            ctx.beginPath();
            for (let s = -1; s <= 1; s += 2) {
              const x = px[3] + nxs[3] * s * 2.2 * e, y = py[3] + nys[3] * s * 2.2 * e;
              ctx.moveTo(x + 1.3 * e, y); ctx.arc(x, y, 1.3 * e, 0, TAU);
            }
            ctx.strokeStyle = coul.lueur; ctx.globalAlpha = souffle; ctx.lineWidth = 1; ctx.stroke();
          }
          if (v.gobe > 0.004) {
            ctx.fillStyle = rgb(P.mauve);
            ctx.beginPath(); ctx.arc(px[2], py[2], 4 + 9 * v.gobe, 0, TAU); ctx.globalAlpha = A * 0.3 * v.gobe; ctx.fill();
            ctx.beginPath(); ctx.arc(px[2], py[2], 1.5 + 2 * v.gobe, 0, TAU); ctx.globalAlpha = A * 1.4 * v.gobe; ctx.fill();
          }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
      }
    };
  }
  /* =====================================================================
     3. SYSTOLE — cloche ciliée à réaction (réf. 65109 : vacuole contractile étoilée)
     Une Cellule ouverte à l'arrière. La vacuole étoilée se remplit pendant le relâchement,
     puis la cloche se ferme d'un coup : la poussée = vitesse de fermeture (dc/dt), d'où une
     nage par à-coups. Chaque systole lâche un anneau tourbillonnaire. Quatre flagelles de
     Filament traînent du bord, ondulent au rythme du pouls et se resserrent à la contraction.
     ===================================================================== */
  function creerSystole() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NS = 24, NF = 4, NFP = 15, NR = 4, NG = 36, NV = 7, NVEL = 18;
    const sx = new Float32Array(NS), sw = new Float32Array(NS), sl = new Float32Array(NS);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(0.35, -0.2, 0, 0.05, 0, 1.05);
      g.addColorStop(0, rgba(P.perle, 0.11));
      g.addColorStop(0.5, rgba(P.sarcelle, 0.15));
      g.addColorStop(0.84, rgba(P.aqua, 0.2));
      g.addColorStop(1, rgba(P.perle, 0.3));
      return g;
    });
    // Profil temporel : fermeture rapide (26 % du cycle), relâchement lent
    const contraction = f => f < 0.26 ? 0.5 - 0.5 * Math.cos(Math.PI * f / 0.26) : 0.5 + 0.5 * Math.cos(Math.PI * (f - 0.26) / 0.74);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    function dims() {
      const e = s.echelle, c = s.c, gn = s.gon;
      s.A = 30 * e * (1 + 0.17 * c - 0.07 * gn);
      s.B = 21 * e * (1 - 0.22 * c + 0.2 * gn);
      s.RO = s.B * (0.64 - 0.36 * c + 0.16 * gn);
    }
    function profil() {
      const a = s.A, b = s.B, ro = s.RO, c = s.c;
      for (let i = 0; i < NS; i++) {
        const q = i / (NS - 1);
        sx[i] = a * (1 - 1.86 * q);
        let w = q < 0.55 ? b * Math.pow(Math.sin(Math.PI / 2 * q / 0.55), 0.6) : b + (ro - b) * (0.5 - 0.5 * Math.cos(Math.PI * (q - 0.55) / 0.45));
        if (q > 0.1) w *= 1 + 0.05 * c * Math.sin(q * 41 + t * 2.4);      // la membrane se froisse en se fermant
        sw[i] = w; sl[i] = s.bend * a * q * q;                              // la cloche se plie dans les virages
      }
    }
    function cheminCorps(ctx) {
      ctx.beginPath(); ctx.moveTo(sx[NS - 1], -sw[NS - 1] + sl[NS - 1]);
      for (let i = NS - 2; i >= 0; i--) ctx.lineTo(sx[i], -sw[i] + sl[i]);
      for (let i = 1; i < NS; i++) ctx.lineTo(sx[i], sw[i] + sl[i]);
      ctx.quadraticCurveTo(sx[NS - 1] + s.A * 0.32, sl[NS - 1], sx[NS - 1], -sw[NS - 1] + sl[NS - 1]);
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0x5157);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ang: r() * TAU, angv: 0, ph: r() * TAU,
          f: r(), c: 0, dc: 0, acc: 0, bend: 0, gon: 0, ecart: 1, frq: 0.6, exc: 0, gobe: 0, gl: 0, cph: 0, ri: 0,
          echelle: 1.02 + 0.14 * r(), lueur: lueurNeuve(r), anneaux: [], fx: [], fy: [], g: 0, tx: 0, ty: 0,
          grains: new Float32Array(NG * 3), vac: [] };
        s.c = contraction(s.f); dims();
        for (let j = 0; j < NF; j++) {
          const X = new Float32Array(NFP), Y = new Float32Array(NFP);
          for (let i = 0; i < NFP; i++) { X[i] = s.x - Math.cos(s.ang) * (s.A * 0.86 + i * 4.4); Y[i] = s.y - Math.sin(s.ang) * (s.A * 0.86 + i * 4.4); }
          s.fx.push(X); s.fy.push(Y);
        }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, a: 0, r: 0, vie: 0 });
        for (let k = 0; k < NG; k++) { s.grains[k * 3] = r(); s.grains[k * 3 + 1] = (r() * 2 - 1) * 0.8; s.grains[k * 3 + 2] = 0.5 + r() * 0.7; }
        for (let k = 0; k < 4; k++) s.vac.push({ q: 0.5 + r() * 0.3, k: (r() - 0.5) * 1.1, r: 1.5 + r() * 2, ph: r() * TAU, ambre: k === 0 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.tx = tx; s.ty = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: s.A }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.x, s.y, 170);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        // Intention → forme : la cloche se gonfle (curiosité) ou s'effile (attaque, fuite)
        let gon = 0.15 * Math.sin(t * 0.31 + s.ph), frq = 0.42 + 0.45 * energy, ecart = 1;
        if (e > 0.01) {
          if (md === 'cont') { gon += e; frq -= 0.12 * e; ecart = 1 + 0.7 * e; }
          else if (md === 'actif') { gon += 0.6 * e * Math.sin(t * 1.7 + s.ph); frq += 0.35 * e; ecart = 1 + 0.5 * e * Math.sin(t * 2.3); }
          else if (md === 'agr') { gon -= 0.7 * e; frq += 1.1 * e; ecart = 1 - 0.8 * e; }
          else if (md === 'evite') { gon -= 0.9 * e; frq += 1.3 * e; ecart = 1 + 1.1 * e; }
          else if (md === 'suit') { gon += 0.35 * e; frq += 0.2 * e; }
          else { gon += 0.5 * e; frq += 0.15 * e; ecart = 1 + 0.3 * e; }
        }
        s.gon += (gon - s.gon) * Math.min(1, h * 1.8);
        s.ecart += (ecart - s.ecart) * Math.min(1, h * 2);
        s.frq += (frq * (0.5 + 0.5 * RG.vit) - s.frq) * Math.min(1, h * 1.5);
        // Pouls
        const f0 = s.f; s.f += s.frq * h;
        const pic = f0 < 0.26 && s.f >= 0.26;
        if (s.f >= 1) s.f -= 1;
        const cp = s.c; s.c = contraction(s.f); const dc = (s.c - cp) / h; s.dc = dc;
        const cx = Math.cos(s.ang), cy = Math.sin(s.ang);
        const pousse = (dc > 0 ? dc * 36 : dc * 3) * s.echelle * (0.8 + 0.3 * energy);
        s.acc = pousse;
        const fr = Math.exp(-1.7 * h);
        s.vx = s.vx * fr + cx * pousse * h; s.vy = s.vy * fr + cy * pousse * h;
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.35) * h, ny = s.y + (s.vy + fl[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let j = 0; j < NF; j++) for (let i = 0; i < NFP; i++) { s.fx[j][i] += jx; s.fy[j][i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        // Pilotage : on braque surtout pendant le relâchement (bord ouvert)
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.ty - s.y, s.tx - s.x) - s.ang);
        else {
          const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 190);
          d = 0.6 * Math.sin(t * 0.21 + s.ph) + enrouleAngle(Math.atan2(ecY, ecX) - s.ang) * loin * loin;
        }
        const gain = s.g ? 1.5 * s.g : 0.6, braque = 0.3 + 0.7 * (1 - s.c);
        s.angv += (borne(d, -1.3, 1.3) * gain * braque - s.angv) * Math.min(1, h * 2.5);
        s.ang += s.angv * h;
        s.bend += (-s.angv * 0.42 - s.bend) * Math.min(1, h * 3.5);
        dims();
        const ca = Math.cos(s.ang), sa = Math.sin(s.ang), bx = -0.86 * s.A, bl = s.bend * s.A;
        // Anneau tourbillonnaire au pic de la contraction
        if (pic) {
          const an = s.anneaux[s.ri++ % NR];
          an.x = s.x + bx * ca - bl * sa; an.y = s.y + bx * sa + bl * ca;
          an.vx = -ca * 22 + s.vx * 0.1; an.vy = -sa * 22 + s.vy * 0.1; an.a = s.ang; an.r = s.RO * 1.05; an.vie = 1;
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.2 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 7; an.vie -= h / 1.9;
        }
        // Flagelles : ancrés au bord, ondulent au pouls, traînent par inertie
        const seg = 4.4 * s.echelle;
        for (let j = 0; j < NF; j++) {
          const X = s.fx[j], Y = s.fy[j], u = (j / (NF - 1)) * 2 - 1;
          const lx = bx + 1, ly = bl + u * s.RO * 0.8;
          X[0] = s.x + lx * ca - ly * sa; Y[0] = s.y + lx * sa + ly * ca;
          const base = s.ang + Math.PI - u * 0.3 * s.ecart * (1.15 - 0.75 * s.c);
          for (let i = 1; i < NFP; i++) {
            const q = i / (NFP - 1);
            const ai = base + (0.42 + 0.25 * e) * q * Math.sin(TAU * 2 * s.f - i * 0.55 + j * 1.7) + s.bend * 0.9 * q;
            const tx = X[i - 1] + Math.cos(ai) * seg, ty = Y[i - 1] + Math.sin(ai) * seg;
            const k = Math.min(1, h * (16 - 13 * q));
            X[i] += (tx - X[i]) * k; Y[i] += (ty - Y[i]) * k;
            const ex2 = X[i] - X[i - 1], ey2 = Y[i] - Y[i - 1], l = seg / (Math.hypot(ex2, ey2) || 1);
            X[i] = X[i - 1] + ex2 * l; Y[i] = Y[i - 1] + ey2 * l;
          }
        }
        s.gl += h * (0.012 + Math.max(0, dc) * 0.03);                    // cyclose : les grains glissent vers l'arrière à chaque poussée
        s.cph += h * (6 + 5 * energy + 9 * e + Math.max(0, dc) * 3);
        s.gobe = Math.max(0, s.gobe - h * 0.35);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.72; if (A <= 0.001) return;
        const a = s.A, b = s.B, ro = s.RO, c = s.c, e = s.echelle;
        profil();
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de sillage : tore vu de profil (ellipse fine + deux volutes qui tournent)
        ctx.strokeStyle = coul.perle;
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const v = an.vie, sn = Math.sin(an.a), cs = Math.cos(an.a);
          ctx.beginPath(); ctx.ellipse(an.x, an.y, an.r * 0.28, an.r, an.a, 0, TAU);
          ctx.globalAlpha = A * 0.3 * v * v; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x - sn * an.r * sg, qy = an.y + cs * an.r * sg, rr = 1.8 + (1 - v) * 2.2, a0 = an.a + (1 - v) * 9 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.4);
          }
          ctx.globalAlpha = A * 0.5 * v; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // 2. Flagelles nacrés (style Filament : halo, fil, base épaisse, perles)
        ctx.beginPath();
        for (let j = 0; j < NF; j++) {
          const X = s.fx[j], Y = s.fy[j];
          ctx.moveTo(X[0], Y[0]);
          for (let i = 1; i < NFP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
          ctx.lineTo(X[NFP - 1], Y[NFP - 1]);
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        for (let j = 0; j < NF; j++) { const X = s.fx[j], Y = s.fy[j]; ctx.moveTo(X[0], Y[0]); for (let i = 1; i < 6; i++) ctx.lineTo(X[i], Y[i]); }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 1.7; ctx.stroke();
        ctx.beginPath();
        for (let j = 0; j < NF; j++) for (let i = 2; i < NFP; i += 3) { const rr = 1.15 * (1 - i / NFP * 0.6); ctx.moveTo(s.fx[j][i] + rr, s.fy[j][i]); ctx.arc(s.fx[j][i], s.fy[j][i], rr, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.fill();

        // 3. Cloche (repère local : apex en +x)
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.ang);
        cheminCorps(ctx);
        ctx.save(); ctx.scale(a, b); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        ctx.strokeStyle = coul.perle;
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.9; ctx.stroke();
        // Sous-ombrelle : paroi intérieure en U
        ctx.beginPath();
        for (let i = NS - 1; i >= 5; i--) ctx.lineTo(sx[i], -0.74 * sw[i] + sl[i]);
        for (let i = 5; i < NS; i++) ctx.lineTo(sx[i], 0.74 * sw[i] + sl[i]);
        ctx.globalAlpha = A * 0.15; ctx.lineWidth = 1.3; ctx.stroke();
        ctx.quadraticCurveTo(sx[NS - 1] + a * 0.3, sl[NS - 1], sx[NS - 1], -0.74 * sw[NS - 1] + sl[NS - 1]);
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (0.22 + 0.12 * c); ctx.fill();
        // Kinéties : stries qui épousent la courbure
        ctx.beginPath();
        for (let k = -3; k <= 3; k++) {
          if (!k) continue; const f = k / 3.6;
          ctx.moveTo(sx[1], f * sw[1] + sl[1]);
          for (let i = 2; i < NS; i++) ctx.lineTo(sx[i], f * sw[i] + sl[i]);
        }
        ctx.globalAlpha = A * 0.08; ctx.lineWidth = 0.5; ctx.stroke();
        // Vélum : membrane de l'ouverture + ses plis radiaux
        const xr = sx[NS - 1], lr = sl[NS - 1], cxv = xr + a * 0.32;
        ctx.beginPath();
        for (let k = 1; k < 8; k++) {
          const u = k / 8, m = 1 - u;
          const vx = m * m * xr + 2 * u * m * cxv + u * u * xr, vy = m * m * (lr - ro) + 2 * u * m * lr + u * u * (lr + ro);
          ctx.moveTo(vx, vy); ctx.lineTo(vx - 3 - 3 * c, vy + (u - 0.5) * 4);
        }
        ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.5; ctx.stroke();
        // Granulations qui glissent vers l'arrière (cyclose liée à la poussée)
        ctx.fillStyle = coul.perle; ctx.beginPath();
        for (let k = 0; k < NG; k++) {
          const q = (s.grains[k * 3] + s.gl) % 1, fi = q * 0.92 * (NS - 1), i0 = fi | 0, u = fi - i0, i1 = Math.min(NS - 1, i0 + 1);
          const x = sx[i0] + (sx[i1] - sx[i0]) * u, w = sw[i0] + (sw[i1] - sw[i0]) * u, l = sl[i0] + (sl[i1] - sl[i0]) * u;
          const sz = s.grains[k * 3 + 2] * (q > 0.8 ? (1 - q) * 5 : 1);
          ctx.rect(x - sz * 0.5, s.grains[k * 3 + 1] * w * 0.8 + l - sz * 0.5, sz, sz);
        }
        ctx.globalAlpha = A * 0.26; ctx.fill();
        // Noyau
        const inn = Math.round(0.2 * (NS - 1));
        ctx.beginPath(); ctx.arc(sx[inn], sl[inn] + sw[inn] * 0.25, b * 0.24, 0, TAU);
        ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.7; ctx.stroke();
        // Vacuoles digestives
        ctx.beginPath();
        for (const v of s.vac) {
          const i = Math.round(v.q * (NS - 1)), rr = v.r * e * (1 + 0.1 * Math.sin(t * 1.6 + v.ph));
          const x = sx[i], y = v.k * sw[i] * 0.6 + sl[i];
          ctx.moveTo(x + rr, y); ctx.arc(x, y, rr, 0, TAU);
        }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
        // Vacuole contractile étoilée : se remplit au relâchement, se vide à la systole
        const iv = Math.round(0.38 * (NS - 1)), vx0 = sx[iv], vy0 = sl[iv] - 0.12 * sw[iv];
        const plein = 1 - c, rv = (2 + 3.4 * plein) * e;
        ctx.beginPath();
        for (let k = 0; k < NV; k++) {
          const q = k / NV * TAU + s.ph, Lr = (4.5 + 8.5 * plein) * e * (0.8 + 0.2 * Math.sin(k * 2.1 + s.ph));
          const q2 = q + 0.35 * (0.5 - plein);                           // les canaux se tordent en se vidant
          ctx.moveTo(vx0 + Math.cos(q) * rv, vy0 + Math.sin(q) * rv * 0.9);
          ctx.quadraticCurveTo(vx0 + Math.cos(q2) * (rv + Lr * 0.6), vy0 + Math.sin(q2) * (rv + Lr * 0.6) * 0.9, vx0 + Math.cos(q) * (rv + Lr), vy0 + Math.sin(q) * (rv + Lr) * 0.9);
        }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 2.6; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.34; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(vx0, vy0, rv, 0, TAU);
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.8; ctx.stroke();
        // Cils : vague métachronale, couchés vers l'arrière selon la vitesse et la poussée
        const lean = borne(Math.hypot(s.vx, s.vy) * 0.045 + Math.max(0, s.acc) * 0.004, 0, 2);
        ctx.beginPath();
        for (let sd = -1; sd <= 1; sd += 2) for (let i = 1; i < NS - 1; i++) {
          const i0 = i - 1, i1 = i + 1;
          let tx = sx[i1] - sx[i0], ty = sd * (sw[i1] - sw[i0]) + (sl[i1] - sl[i0]);
          const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
          const nx = sd * ty, ny = -sd * tx;
          for (let hh = 0; hh < 2; hh++) {
            const fx = hh ? (sx[i] + sx[i1]) / 2 : sx[i], fy = hh ? (sd * (sw[i] + sw[i1]) + sl[i] + sl[i1]) / 2 : sd * sw[i] + sl[i];
            const ph = s.cph - (i + hh * 0.5) * 0.55 + (sd > 0 ? 0 : 1.3);
            const L = (2.3 + 1.4 * Math.sin(ph)) * (1 + 0.45 * s.exc), pli = 1.3 * Math.cos(ph);
            ctx.moveTo(fx + nx * 0.8, fy + ny * 0.8);
            ctx.lineTo(fx + nx * (0.8 + L) + tx * pli - lean * L * 0.4, fy + ny * (0.8 + L) + ty * pli);
          }
        }
        ctx.strokeStyle = coul.perle;
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 2.2; ctx.stroke();
        ctx.globalAlpha = A * 0.24; ctx.lineWidth = 0.5; ctx.stroke();
        // Frange du vélum : longue quand la cloche se gonfle (curiosité)
        ctx.beginPath();
        const fr = 3 + 6 * Math.max(0, s.gon) + 1.5 * s.ecart;
        for (let k = 0; k <= NVEL; k++) {
          const u = k / NVEL, m = 1 - u;
          const vx = m * m * xr + 2 * u * m * cxv + u * u * xr, vy = m * m * (lr - ro) + 2 * u * m * lr + u * u * (lr + ro);
          const ph = s.cph * 1.4 - k * 0.7, L = fr * (0.75 + 0.25 * Math.sin(ph));
          const sp = (u - 0.5) * (0.5 + 0.5 * s.ecart);
          ctx.moveTo(vx, vy); ctx.lineTo(vx - L, vy + sp * L * 1.4 + Math.cos(ph) * 1.1);
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // Bioluminescence : de l'apex au bord le long de la membrane
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        ctx.globalCompositeOperation = 'lighter';
        if (I > 0.004 && s.lueur.pos < 0.6) {
          const cc = s.lueur.pos / 0.5 * (NS + 2) - 1;
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NS - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 < cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath();
            ctx.moveTo(sx[i], -sw[i] + sl[i]); ctx.lineTo(sx[i + 1], -sw[i + 1] + sl[i + 1]);
            ctx.moveTo(sx[i], sw[i] + sl[i]); ctx.lineTo(sx[i + 1], sw[i + 1] + sl[i + 1]);
            ctx.globalAlpha = li * 0.15; ctx.lineWidth = 7; ctx.stroke();
            ctx.globalAlpha = li * 0.7; ctx.lineWidth = 1.1; ctx.stroke();
          }
        }
        // La vacuole étoilée s'allume à chaque systole (très faible) et au gobage (mauve)
        const sys = A * P.alpha.biolum * 0.14 * Math.max(0, s.dc) / 4;
        if (sys > 0.004) { ctx.beginPath(); ctx.arc(vx0, vy0, rv * 2.2, 0, TAU); ctx.fillStyle = coul.lueur; ctx.globalAlpha = Math.min(0.2, sys); ctx.fill(); }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(vx0, vy0, (7 + 12 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.22 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(vx0, vy0, rv * (0.6 + 0.6 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
        // Bioluminescence (suite) : l'impulsion descend les flagelles
        if (I > 0.004 && s.lueur.pos > 0.4) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cf = (s.lueur.pos - 0.45) / 0.75 * (NFP + 3) - 1;
          for (let i = 0; i < NFP - 1; i++) {
            const li = I * cloche(i + 0.5 - cf, i + 0.5 < cf ? 4 : 1.3); if (li < 0.004) continue;
            ctx.beginPath();
            for (let j = 0; j < NF; j++) { ctx.moveTo(s.fx[j][i], s.fy[j][i]); ctx.lineTo(s.fx[j][i + 1], s.fy[j][i + 1]); }
            ctx.globalAlpha = li * 0.14; ctx.lineWidth = 5; ctx.stroke();
            ctx.globalAlpha = li * 0.75; ctx.lineWidth = 0.9; ctx.stroke();
          }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     4. CULBUTE — toupie ciliée à axe instable (réf. 43798 : effet Djanibekov)
     Un corps de Cellule (ellipsoïde 3D) porte une trompe de Filament le long de son axe
     intermédiaire. Il tourne vraiment selon les équations d'Euler (I1 < I2 < I3) : la
     rotation autour de la trompe est instable, d'où des culbutes de 180° périodiques.
     La trompe bat en hélice et TIRE le corps : chaque culbute retourne la trajectoire.
     Quand il vise (particule, proie), un couple amortit la culbute et la trompe se tend.
     ===================================================================== */
  function creerCulbute() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const EA = 31, EB = 13, EC = 14, I1 = 1, I2 = 1.65, I3 = 2.3;
    const NST = 16, NMER = 8, NMS = 14, NB = 3, NBC = 28, NGR = 26, NCOL = 12, NTF = 9;
    const R = new Float64Array(9), w = new Float64Array(3), tau = new Float64Array(3), pj = new Float64Array(3);
    const SX = new Float32Array(NST), SY = new Float32Array(NST), SZ = new Float32Array(NST);
    const mer = new Float32Array(NMER * NMS * 3), merP = new Float32Array(NMER * NMS * 3);
    const bande = new Float32Array(NB * NBC * 9), cilP = new Float32Array(NB * NBC * 5);
    const grains = new Float32Array(NGR * 3), grP = new Float32Array(NGR * 3);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.3, -0.3, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.13));
      g.addColorStop(0.5, rgba(P.sarcelle, 0.16));
      g.addColorStop(0.85, rgba(P.aqua, 0.18));
      g.addColorStop(0.97, rgba(P.perle, 0.3));
      g.addColorStop(1, rgba(P.perle, 0));
      return g;
    });
    // Géométrie propre (repère du corps, e2 = axe de la trompe)
    for (let m = 0; m < NMER; m++) for (let j = 0; j < NMS; j++) {
      const ph = m / NMER * TAU, th = Math.PI * (0.08 + 0.84 * j / (NMS - 1)), o = (m * NMS + j) * 3;
      mer[o] = EA * Math.sin(th) * Math.cos(ph); mer[o + 1] = EB * Math.cos(th); mer[o + 2] = EC * Math.sin(th) * Math.sin(ph);
    }
    const LAT = [0.3, 0.5, 0.7];
    for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k < NBC; k++) {
      const th = Math.PI * LAT[bnd], ph = (k + bnd * 0.5) / NBC * TAU, o = (bnd * NBC + k) * 9;
      const x = EA * Math.sin(th) * Math.cos(ph), y = EB * Math.cos(th), z = EC * Math.sin(th) * Math.sin(ph);
      let nx = x / (EA * EA), ny = y / (EB * EB), nz = z / (EC * EC); const nl = 1 / Math.hypot(nx, ny, nz);
      let gx = -EA * Math.sin(ph), gz = EC * Math.cos(ph); const gl = 1 / Math.hypot(gx, gz);
      bande[o] = x; bande[o + 1] = y; bande[o + 2] = z; bande[o + 3] = nx * nl; bande[o + 4] = ny * nl; bande[o + 5] = nz * nl;
      bande[o + 6] = gx * gl; bande[o + 7] = 0; bande[o + 8] = gz * gl;
    }
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;
    function projeter(x, y, z) { pj[0] = R[0] * x + R[1] * y + R[2] * z; pj[1] = R[3] * x + R[4] * y + R[5] * z; pj[2] = R[6] * x + R[7] * y + R[8] * z; }
    // Un pas des équations d'Euler (corps rigide libre + couple propre tau)
    function pas(h) {
      const w1 = w[0], w2 = w[1], w3 = w[2];
      w[0] += ((I2 - I3) * w2 * w3 + tau[0]) / I1 * h;
      w[1] += ((I3 - I1) * w3 * w1 + tau[1]) / I2 * h;
      w[2] += ((I1 - I2) * w1 * w2 + tau[2]) / I3 * h;
      for (let r = 0; r < 9; r += 3) {
        const a = R[r], b = R[r + 1], c = R[r + 2];
        R[r] = a + h * (b * w[2] - c * w[1]); R[r + 1] = b + h * (c * w[0] - a * w[2]); R[r + 2] = c + h * (a * w[1] - b * w[0]);
      }
    }
    function orthonormer() {
      let l = 1 / Math.hypot(R[0], R[3], R[6]); R[0] *= l; R[3] *= l; R[6] *= l;
      const d = R[0] * R[1] + R[3] * R[4] + R[6] * R[7]; R[1] -= d * R[0]; R[4] -= d * R[3]; R[7] -= d * R[6];
      l = 1 / Math.hypot(R[1], R[4], R[7]); R[1] *= l; R[4] *= l; R[7] *= l;
      R[2] = R[3] * R[7] - R[6] * R[4]; R[5] = R[6] * R[1] - R[0] * R[7]; R[8] = R[0] * R[4] - R[3] * R[1];
    }
    const mix = (a, b, k) => a + (b - a) * k;

    const TG = new Float32Array(NST * 2), TD = new Float32Array(NST * 2);
    function traceTige(ctx, A) {
      // Corps de la trompe : ruban effilé (largeur 3,2 → 0,6) rempli comme le Filament
      for (let i = 0; i < NST; i++) {
        const a = i ? i - 1 : 0, b = i < NST - 1 ? i + 1 : NST - 1;
        let tx = SX[b] - SX[a], ty = SY[b] - SY[a]; const l = 1 / (Math.hypot(tx, ty) || 1);
        const wd = (3.2 - 2.6 * i / (NST - 1)) * (1 - 0.25 * (s.ext - 1)) * (1 + 0.15 * Math.sin(s.psi - i * 0.6));
        TG[i * 2] = SX[i] - ty * l * wd; TG[i * 2 + 1] = SY[i] + tx * l * wd; TD[i * 2] = SX[i] + ty * l * wd; TD[i * 2 + 1] = SY[i] - tx * l * wd;
      }
      ctx.beginPath(); ctx.moveTo(TG[0], TG[1]);
      for (let i = 1; i < NST; i++) ctx.lineTo(TG[i * 2], TG[i * 2 + 1]);
      for (let i = NST - 1; i >= 0; i--) ctx.lineTo(TD[i * 2], TD[i * 2 + 1]);
      ctx.closePath();
      ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.25; ctx.fill(); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.08; ctx.fill();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(SX[0], SY[0]);
      for (let i = 1; i < NST - 1; i++) ctx.quadraticCurveTo(SX[i], SY[i], (SX[i] + SX[i + 1]) / 2, (SY[i] + SY[i + 1]) / 2);
      ctx.lineTo(SX[NST - 1], SY[NST - 1]);
      ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 6; ctx.stroke();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.5; ctx.stroke();

      // Annelures perpendiculaires (suivent la torsion de l'hélice)
      ctx.beginPath();
      for (let i = 2; i < NST - 1; i += 2) {
        let tx = SX[i + 1] - SX[i - 1], ty = SY[i + 1] - SY[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1);
        const k = 2.1 * (1 - i / NST * 0.6) * (0.6 + 0.4 * Math.sin(s.psi - i * 0.6));
        ctx.moveTo(SX[i] - ty * l * k, SY[i] + tx * l * k); ctx.lineTo(SX[i] + ty * l * k, SY[i] - tx * l * k);
      }
      ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.5; ctx.stroke();
      // Tête de Filament au bout de la trompe : bulbe allongé, deux vacuoles, lèvre ciliée
      const bx = SX[NST - 1], by = SY[NST - 1], ta = Math.atan2(SY[NST - 1] - SY[NST - 3], SX[NST - 1] - SX[NST - 3]);
      const hl = 3.6 + 1.4 * s.ext, hw = 2.6 + 0.5 * s.ext, ca = Math.cos(ta), sa = Math.sin(ta);
      ctx.beginPath(); ctx.ellipse(bx + ca * hl * 0.6, by + sa * hl * 0.6, hl, hw, ta, 0, TAU);
      ctx.fillStyle = coul.sarcelle; ctx.globalAlpha = A * 0.3; ctx.fill(); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.1; ctx.fill();
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.75; ctx.stroke();
      ctx.beginPath();
      for (let sg = -1; sg <= 1; sg += 2) { const vx = bx + ca * hl * 0.3 - sa * sg * hw * 0.45, vy = by + sa * hl * 0.3 + ca * sg * hw * 0.45; ctx.moveTo(vx + 0.9, vy); ctx.arc(vx, vy, 0.9, 0, TAU); }
      ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.5; ctx.stroke();
      ctx.beginPath();
      for (let k = 0; k < 9; k++) {
        const q = ta - 1.2 + k / 8 * 2.4, L = (2 + 1.2 * Math.sin(s.cph * 1.4 - k * 0.8)) * (1 + 0.6 * s.exc);
        const x0 = bx + ca * hl * 0.6 + Math.cos(q) * hl, y0 = by + sa * hl * 0.6 + Math.sin(q) * hw * 1.1;
        ctx.moveTo(x0, y0); ctx.lineTo(x0 + Math.cos(q) * L, y0 + Math.sin(q) * L);
      }
      ctx.globalAlpha = A * 0.38; ctx.lineWidth = 0.5; ctx.stroke();
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xd1a);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        const a0 = r() * TAU, b0 = 0.5 + r() * 0.5, c = Math.cos(a0), sn = Math.sin(a0), cb = Math.cos(b0), sb = Math.sin(b0);
        R[0] = c; R[1] = -sn * cb; R[2] = sn * sb; R[3] = sn; R[4] = c * cb; R[5] = -c * sb; R[6] = 0; R[7] = sb; R[8] = cb;
        w[0] = 0.05; w[1] = 3.6 + r(); w[2] = 0.04;
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ph: r() * TAU, psi: 0, cph: 0, ext: 1, amp: 1,
          exc: 0, gobe: 0, lueur: lueurNeuve(r), g: 0, tx: 0, ty: 0, vac: [] };
        for (let k = 0; k < NGR; k++) {
          const u = r() * TAU, v = Math.acos(2 * r() - 1), rr = 0.78 * Math.cbrt(r());
          grains[k * 3] = EA * rr * Math.sin(v) * Math.cos(u); grains[k * 3 + 1] = EB * rr * Math.cos(v); grains[k * 3 + 2] = EC * rr * Math.sin(v) * Math.sin(u);
        }
        for (let k = 0; k < 5; k++) s.vac.push([(r() - 0.5) * EA * 1.1, (r() - 0.5) * EB * 0.9, (r() - 0.5) * EC * 1.1, 1.6 + r() * 1.8, r() < 0.3]);
        for (let i = 0; i < NST; i++) { projeter(0, EB * 0.9 + i * 2.8, 0); SX[i] = s.x + pj[0]; SY[i] = s.y + pj[1]; SZ[i] = pj[2]; }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.tx = tx; s.ty = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: EA }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.x, s.y, 170);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        // Paramètres libres (culbutes) puis mélange vers la réponse du comportement
        let spin = (3 + 3 * energy) * (0.6 + 0.4 * RG.vit), kA = s.g ? 3.5 * s.g : 0, kD = s.g ? 1.2 : 0, kick = 0.08;
        let ext = 1 + 0.08 * Math.sin(t * 0.6 + s.ph), amp = 1, bf = 7 + 6 * energy, tire = 1, regardePart = false;
        if (e > 0.01) {
          let m;
          if (md === 'cont') m = [1.0, 5, 2.2, 0.02, 1 + 0.6 * e, 0.45, 5, 0.35, 1];
          else if (md === 'suit') m = [2, 4, 1.8, 0.04, 1.25, 0.8, 8, 0.7, 1];
          else if (md === 'actif') m = [7.5, 0.6, 0, 0.9, 1 + 0.25 * Math.sin(t * 3), 1.25, 12, 1, 0];
          else if (md === 'agr') m = [2.6, 9, 2.6, 0.02, 1 + 0.75 * e, 0.22, 17, 1.7, 1];
          else if (md === 'evite') m = [9, 4, 0.4, 1.1, 0.5, 1.5, 15, 1.4, 0];
          else m = [4, 3, 1, 0.1, 1.15, 1, 9, 1, 0];
          spin = mix(spin, m[0], e); kA = mix(kA, m[1], e); kD = mix(kD, m[2], e); kick = mix(kick, m[3], e);
          ext = mix(ext, m[4], e); amp = mix(amp, m[5], e); bf = mix(bf, m[6], e); tire = mix(tire, m[7], e); regardePart = m[8] > 0;
        }
        // Couples : régulation de |ω| (moteur ciliaire), visée de la trompe, petite perturbation déterministe
        tau[0] = tau[1] = tau[2] = 0;
        const lookOk = regardePart || s.g > 0;
        if (kA > 0 && lookOk) {
          const lx = regardePart ? RG.part.x : s.tx, ly = regardePart ? RG.part.y : s.ty;
          let dx = lx - s.x, dy = ly - s.y; const dl = Math.hypot(dx, dy) || 1; dx /= dl; dy /= dl;
          const tx = -R[7] * dy, ty = R[7] * dx, tz = R[1] * dy - R[4] * dx;
          tau[0] = kA * (R[0] * tx + R[3] * ty + R[6] * tz) - kD * w[0];
          tau[1] = kA * (R[1] * tx + R[4] * ty + R[7] * tz);
          tau[2] = kA * (R[2] * tx + R[5] * ty + R[8] * tz) - kD * w[2];
        }
        const wm = Math.hypot(w[0], w[1], w[2]) || 1, ks = 1.4 * (spin - wm) / wm;
        tau[0] += ks * w[0] * I1 + kick * Math.sin(t * 1.7 + s.ph) * I1;
        tau[1] += ks * w[1] * I2;
        tau[2] += ks * w[2] * I3 + kick * Math.cos(t * 1.1 + s.ph) * I3;
        const n = Math.ceil(h * 240), hh = h / n;
        for (let k = 0; k < n; k++) pas(hh);
        orthonormer();
        // Translation : la trompe bat et tire le corps dans sa direction (projetée)
        s.ext += (ext - s.ext) * Math.min(1, h * 2.2);
        s.amp += (amp - s.amp) * Math.min(1, h * 2.5);
        s.psi += bf * h;
        s.cph += h * (8 + 10 * energy + 16 * e * (md === 'evite' || md === 'actif' || md === 'agr' ? 1 : 0.3));
        const pull = (7 + 11 * energy) * RG.vit * tire * (0.75 + 0.25 * Math.sin(s.psi));
        let tvx = R[1] * pull, tvy = R[4] * pull;
        if (s.g) { const dx = s.tx - s.x, dy = s.ty - s.y, d = Math.hypot(dx, dy) || 1; tvx += dx / d * 9 * s.g; tvy += dy / d * 9 * s.g; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 180); tvx += ecX * loin * loin * 0.12; tvy += ecY * loin * loin * 0.12; }
        s.vx += (tvx - s.vx) * Math.min(1, h * 1.6); s.vy += (tvy - s.vy) * Math.min(1, h * 1.6);
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.4) * h, ny = s.y + (s.vy + fl[1] * 0.4) * h;
        s.x = enroule(nx, 0, W, 70); s.y = enroule(ny, 0, H, 70);
        const jx = s.x - nx, jy = s.y - ny;
        // Trompe : hélice dans le repère du corps, l'extrémité traîne pendant les culbutes
        const L = 60 * s.ext, seg = L / (NST - 1);
        for (let i = 0; i < NST; i++) {
          const q = i / (NST - 1), Aq = s.amp * 5.5 * Math.pow(q, 1.2), ph = s.psi - i * 0.6;
          projeter(Aq * Math.sin(ph), EB * 0.9 + i * seg, Aq * Math.cos(ph) * 0.7);
          const wx = s.x + pj[0], wy = s.y + pj[1], wz = pj[2];
          if (i === 0) { SX[0] = wx; SY[0] = wy; SZ[0] = wz; continue; }
          SX[i] += jx; SY[i] += jy;
          const k = Math.min(1, h * (36 - 30 * q));
          SX[i] += (wx - SX[i]) * k; SY[i] += (wy - SY[i]) * k; SZ[i] += (wz - SZ[i]) * k;
          const ex2 = SX[i] - SX[i - 1], ey2 = SY[i] - SY[i - 1], ez2 = SZ[i] - SZ[i - 1], l = seg / (Math.hypot(ex2, ey2, ez2) || 1);
          SX[i] = SX[i - 1] + ex2 * l; SY[i] = SY[i - 1] + ey2 * l; SZ[i] = SZ[i - 1] + ez2 * l;
        }
        s.gobe = Math.max(0, s.gobe - h * 0.35);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.72; if (A <= 0.001) return;
        // Silhouette : projection orthographique de l'ellipsoïde = ellipse (axes propres de P·Pᵀ)
        const m00 = R[0] * EA, m01 = R[1] * EB, m02 = R[2] * EC, m10 = R[3] * EA, m11 = R[4] * EB, m12 = R[5] * EC;
        const Sxx = m00 * m00 + m01 * m01 + m02 * m02, Syy = m10 * m10 + m11 * m11 + m12 * m12, Sxy = m00 * m10 + m01 * m11 + m02 * m12;
        const th = 0.5 * Math.atan2(2 * Sxy, Sxx - Syy), mo = (Sxx + Syy) / 2, di = Math.sqrt((Sxx - Syy) * (Sxx - Syy) / 4 + Sxy * Sxy);
        const ra = Math.sqrt(mo + di), rb = Math.sqrt(Math.max(1, mo - di));
        // Projections
        for (let k = 0; k < NMER * NMS; k++) { projeter(mer[k * 3], mer[k * 3 + 1], mer[k * 3 + 2]); merP[k * 3] = s.x + pj[0]; merP[k * 3 + 1] = s.y + pj[1]; merP[k * 3 + 2] = pj[2]; }
        const ex = s.exc;
        for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k < NBC; k++) {
          const o = (bnd * NBC + k) * 9, q = (bnd * NBC + k) * 5;
          const ph = s.cph - k * 0.5 + bnd * 1.1, L = (3 + 1.5 * Math.sin(ph)) * (1 + 0.5 * ex), pli = 1.6 * Math.cos(ph);
          const bx = bande[o], by = bande[o + 1], bz = bande[o + 2];
          projeter(bx + bande[o + 3] * 0.6, by + bande[o + 4] * 0.6, bz + bande[o + 5] * 0.6);
          cilP[q] = s.x + pj[0]; cilP[q + 1] = s.y + pj[1]; cilP[q + 4] = pj[2];
          projeter(bx + bande[o + 3] * (0.6 + L) + bande[o + 6] * pli, by + bande[o + 4] * (0.6 + L) - L * 0.25, bz + bande[o + 5] * (0.6 + L) + bande[o + 8] * pli);
          cilP[q + 2] = s.x + pj[0]; cilP[q + 3] = s.y + pj[1];
        }
        for (let k = 0; k < NGR; k++) { projeter(grains[k * 3], grains[k * 3 + 1], grains[k * 3 + 2]); grP[k * 3] = s.x + pj[0]; grP[k * 3 + 1] = s.y + pj[1]; grP[k * 3 + 2] = pj[2]; }
        const tigeDevant = SZ[3] >= 0;
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const mers = (devant) => {
          ctx.beginPath();
          for (let m = 0; m < NMER; m++) for (let j = 0; j < NMS - 1; j++) {
            const o = (m * NMS + j) * 3, z = merP[o + 2] + merP[o + 5];
            if ((z >= 0) !== devant) continue;
            ctx.moveTo(merP[o], merP[o + 1]); ctx.lineTo(merP[o + 3], merP[o + 4]);
          }
        };
        const cils = (devant, b0, b1) => {
          ctx.beginPath();
          for (let k = b0 * NBC; k < b1 * NBC; k++) { const q = k * 5; if ((cilP[q + 4] >= 0) !== devant) continue; ctx.moveTo(cilP[q], cilP[q + 1]); ctx.lineTo(cilP[q + 2], cilP[q + 3]); }
        };
        // Plan arrière
        ctx.strokeStyle = coul.perle;
        mers(false); ctx.globalAlpha = A * 0.08; ctx.lineWidth = 0.5; ctx.stroke();
        cils(false, 0, NB); ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.45; ctx.stroke();
        if (!tigeDevant) traceTige(ctx, A * 0.75);
        // Corps
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(th); ctx.scale(ra, rb);
        ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill();
        ctx.restore();
        ctx.strokeStyle = coul.perle;
        ctx.beginPath(); ctx.ellipse(s.x, s.y, ra, rb, th, 0, TAU);
        ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.9; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(s.x, s.y, ra * 0.9, rb * 0.86, th, 0, TAU);
        ctx.globalAlpha = A * 0.12; ctx.lineWidth = 1.4; ctx.stroke();
        // Intérieur : grains (arrière pâles, avant nets), vacuoles, macronoyau
        ctx.fillStyle = coul.perle;
        for (let pass = 0; pass < 2; pass++) {
          ctx.beginPath();
          for (let k = 0; k < NGR; k++) { const z = grP[k * 3 + 2]; if ((z >= 0) !== (pass === 1)) continue; const sz = 0.7 + z * 0.02; ctx.rect(grP[k * 3] - sz / 2, grP[k * 3 + 1] - sz / 2, sz, sz); }
          ctx.globalAlpha = A * (pass ? 0.34 : 0.14); ctx.fill();
        }
        ctx.beginPath();
        for (const v of s.vac) { projeter(v[0], v[1], v[2]); const rr = v[3] * (1 + 0.012 * pj[2]); ctx.moveTo(s.x + pj[0] + rr, s.y + pj[1]); ctx.arc(s.x + pj[0], s.y + pj[1], rr, 0, TAU); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.7; ctx.stroke();
        projeter(-EA * 0.3, -EB * 0.15, 0);
        const nux = s.x + pj[0], nuy = s.y + pj[1];
        ctx.beginPath(); ctx.arc(nux, nuy, 6, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.18; ctx.lineWidth = 0.7; ctx.stroke();
        // Méridiens (kinéties) et bandes ciliées avant : ils tournent avec le corps
        mers(true); ctx.globalAlpha = A * 0.22; ctx.lineWidth = 0.55; ctx.stroke();
        ctx.beginPath();
        for (let bnd = 0; bnd < NB; bnd++) for (let k = 0; k <= NBC; k++) {
          const q = (bnd * NBC + (k % NBC)) * 5;
          if (k === 0 || cilP[q + 4] < 0) ctx.moveTo(cilP[q], cilP[q + 1]); else ctx.lineTo(cilP[q], cilP[q + 1]);
        }
        ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.6; ctx.stroke();
        cils(true, 0, NB); ctx.globalAlpha = A * 0.08; ctx.lineWidth = 2.2; ctx.stroke(); ctx.globalAlpha = A * 0.34; ctx.lineWidth = 0.5; ctx.stroke();
        // Reflet spéculaire : le point de l'ellipsoïde dont la normale regarde la lumière
        {
          const hx = -0.25, hy = -0.35, hz = 0.9;
          const n0 = R[0] * hx + R[3] * hy + R[6] * hz, n1 = R[1] * hx + R[4] * hy + R[7] * hz, n2 = R[2] * hx + R[5] * hy + R[8] * hz;
          const dn = 1 / Math.sqrt(EA * EA * n0 * n0 + EB * EB * n1 * n1 + EC * EC * n2 * n2);
          projeter(EA * EA * n0 * dn * 0.92, EB * EB * n1 * dn * 0.92, EC * EC * n2 * dn * 0.92);
          ctx.fillStyle = coul.perle;
          ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 5, 0, TAU); ctx.globalAlpha = A * 0.07; ctx.fill();
          ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 1.5, 0, TAU); ctx.globalAlpha = A * 0.4; ctx.fill();
        }
        // Collerette à la base de la trompe
        ctx.beginPath();
        for (let k = 0; k < NCOL; k++) {
          const q = k / NCOL * TAU, L = 3 + 1.5 * Math.sin(s.cph * 1.2 - k * 0.9);
          projeter(Math.cos(q) * 4, EB * 0.82, Math.sin(q) * 4); const x0 = s.x + pj[0], y0 = s.y + pj[1];
          projeter(Math.cos(q) * (4 + L), EB * 0.82 + L * 0.5, Math.sin(q) * (4 + L));
          ctx.moveTo(x0, y0); ctx.lineTo(s.x + pj[0], s.y + pj[1]);
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // Touffes polaires : longs cils en éventail aux deux bouts du fuseau, battent en 3D
        for (let pass = 0; pass < 2; pass++) {
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) for (let k = 0; k < NTF; k++) {
            const u = (k / (NTF - 1) - 0.5) * 2.2, ph = s.cph * 0.8 - k * 0.7 + (sg > 0 ? 0 : 2), L = (13 + 4 * Math.sin(ph)) * (1 + 0.35 * ex);
            const dy = Math.sin(u) * 0.7 + 0.35 * Math.cos(ph), dz = Math.cos(u) * 0.5 * Math.sin(ph * 0.5 + k);
            const bx = sg * EA * 0.93, by = Math.sin(u) * 3, bz = Math.cos(u) * 2;
            projeter(bx, by, bz); const x0 = s.x + pj[0], y0 = s.y + pj[1], z0 = pj[2];
            if ((z0 >= 0) !== (pass === 1)) continue;
            projeter(bx + sg * L * 0.55, by + dy * L * 0.6, bz + dz * L);
            const x2 = s.x + pj[0], y2 = s.y + pj[1];
            projeter(bx + sg * L * 0.85, by + dy * L, bz + dz * L * 1.4);
            ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x2, y2, s.x + pj[0], s.y + pj[1]);
          }
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * (pass ? 0.42 : 0.16); ctx.lineWidth = 0.6; ctx.stroke();
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 2.4; ctx.stroke();
        }
        if (tigeDevant) traceTige(ctx, A);
        // Lumières : bioluminescence (trompe → bande équatoriale) et particule absorbée (mauve)
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cc = (1 - s.lueur.pos / 0.6) * (NST + 2);
          for (let i = 0; i < NST - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 > cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath(); ctx.moveTo(SX[i], SY[i]); ctx.lineTo(SX[i + 1], SY[i + 1]);
            ctx.globalAlpha = li * 0.15; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.75; ctx.lineWidth = 1.2; ctx.stroke();
          }
          const lb = I * cloche(s.lueur.pos - 0.85, 0.22);
          if (lb > 0.004) { cils(true, 1, 2); ctx.globalAlpha = Math.min(1, lb * 1.2); ctx.lineWidth = 0.7; ctx.stroke(); ctx.globalAlpha = lb * 0.2; ctx.lineWidth = 3; ctx.stroke(); }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.x, s.y, 8 + 14 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.2 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(nux, nuy, 2 + 4 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.85 * s.gobe; ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     5. CHŒUR — colonie de cellules tenues par des fils (réf. 38578 + 28007)
     Huit petites Cellules en anneau, reliées par des fils de Filament et noyées dans une
     membrane commune. Une onde péristaltique fait le tour de l'anneau : c'est la rame.
     Les fils mous pendent, les fils tendus vibrent ; la membrane se froisse quand elle se
     comprime. Cycle lent : la colonie se divise en deux, s'éloigne, puis se recoud fil à fil.
     Au cœur, deux trèfles de filament enlacés se séparent avec elle.
     ===================================================================== */
  function creerChoeur() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const K = 10, HK = 5, NCIL = 14, NK = 44, CA = 8.2, CB = 5.4;
    const px = new Float32Array(K), py = new Float32Array(K), vx = new Float32Array(K), vy = new Float32Array(K);
    const perle = new Float32Array(2 * K), tx = new Float32Array(K), ty = new Float32Array(K), oa = new Float32Array(K), ox = new Float32Array(K), oy = new Float32Array(K);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const c = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      c.addColorStop(0, rgba(P.perle, 0.1)); c.addColorStop(0.55, rgba(P.sarcelle, 0.14));
      c.addColorStop(0.86, rgba(P.aqua, 0.2)); c.addColorStop(0.97, rgba(P.perle, 0.34)); c.addColorStop(1, rgba(P.perle, 0));
      const m = ctx.createRadialGradient(0, 0, 0.2, 0, 0, 1);
      m.addColorStop(0, rgba(P.sarcelle, 0.02)); m.addColorStop(0.7, rgba(P.sarcelle, 0.09)); m.addColorStop(0.93, rgba(P.aqua, 0.12)); m.addColorStop(1, rgba(P.perle, 0.05));
      return { cell: c, mem: m };
    });
    const R0 = 38, REPOS = 2 * R0 * Math.sin(Math.PI / K);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;
    const lisse = u => u * u * (3 - 2 * u);
    const groupe = i => (i < K / 2 ? 0 : 1);

    // Membrane : courbe fermée lissée passant au large des cellules [i0, i0+n)
    function cheminMembrane(ctx, i0, n, cx, cy, marge) {
      for (let k = 0; k < n; k++) {
        const i = (i0 + k) % K; let dx = px[i] - cx, dy = py[i] - cy; const l = 1 / (Math.hypot(dx, dy) || 1);
        ox[k] = px[i] + dx * l * marge; oy[k] = py[i] + dy * l * marge;
      }
      ctx.moveTo((ox[n - 1] + ox[0]) / 2, (oy[n - 1] + oy[0]) / 2);
      for (let k = 0; k < n; k++) { const k2 = (k + 1) % n; ctx.quadraticCurveTo(ox[k], oy[k], (ox[k] + ox[k2]) / 2, (oy[k] + oy[k2]) / 2); }
    }
    // Filament enroulé en pelote lâche (spirale qui respire) — le flagelle de la colonie au repos
    function trefle(ctx, cx, cy, rot, sc) {
      for (let k = 0; k <= NK; k++) {
        const u = k / NK, q = u * TAU * 2.6 + rot, r = sc * (2 + 11 * u + 1.6 * Math.sin(u * 23 + rot * 1.7));
        const x = cx + Math.cos(q) * r, y = cy + Math.sin(q) * r * 0.82;
        k ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
    }

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xc0e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.68 : 0.32);
        s = { hx, hy, cx: hx + (r() - 0.5) * 40, cy: hy + (r() - 0.5) * 40, vx: 0, vy: 0, hd: r() * TAU, angv: 0, ph: r() * TAU, rot: 0, wav: 0,
          sig: 0, etat: 0, tEtat: 3 + r() * 9, lobe: 0, bouche: 0, serre: 0, exc: 0, gobe: 0, cph: 0, pa: 0, rotv: 0.15,
          lueur: lueurNeuve(r), g: 0, tx: 0, ty: 0, cell: [] };
        for (let i = 0; i < K; i++) {
          const q = s.hd + i / K * TAU;
          px[i] = s.cx + Math.cos(q) * R0; py[i] = s.cy + Math.sin(q) * R0; vx[i] = vy[i] = 0; oa[i] = q;
          s.cell.push({ ph: r() * TAU, vac: 0.3 + r() * 0.4, ambre: r() < 0.25, nx: (r() - 0.5) * 0.5, rr: 0.9 + r() * 0.2, k: 0.82 + r() * 0.34 });
        }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.cx, s.cy]; },
      place(i, x, y) { s.cx = x; s.cy = y; },
      vise(i, tx_, ty_, g) { s.tx = tx_; s.ty = ty_; s.g = g; },
      geo() { return [{ k: 'disque', x: s.cx, y: s.cy, r: R0 + 10 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, ex = excitation(RG, s.cx, s.cy, 180);
        s.exc += (ex - s.exc) * Math.min(1, h * 2.5);
        const e = s.exc;
        if (RG.part && RG.part.on) s.pa = Math.atan2(RG.part.y - s.cy, RG.part.x - s.cx);
        // Réponse : pseudopode vers la particule, bouche qui s'ouvre, boule serrée, anneau qui tourne
        let lobe = 0, bouche = 0, serre = 0, rotv = 0.15 + 0.1 * energy;
        if (e > 0.01) {
          if (md === 'cont') lobe = 0.9 * e;
          else if (md === 'suit') lobe = 0.55 * e;
          else if (md === 'actif') { lobe = 0.6 * e * (0.5 + 0.5 * Math.sin(t * 2.1)); rotv += 1.4 * e; }
          else if (md === 'agr') { bouche = borne((e - 0.25) * 1.6, 0, 1); lobe = 0.3 * e; }
          else if (md === 'evite') { serre = 0.75 * e; rotv += 2.2 * e; }
          else { lobe = 0.4 * e; rotv += 0.9 * e; }
        }
        if (s.gobe > 0) { bouche *= 1 - s.gobe; serre = Math.max(serre, 0.35 * s.gobe); }
        s.lobe += (lobe - s.lobe) * Math.min(1, h * 2);
        s.bouche += (bouche - s.bouche) * Math.min(1, h * 3);
        s.serre += (serre - s.serre) * Math.min(1, h * 2.5);
        s.rotv += (rotv - s.rotv) * Math.min(1, h);
        s.rot += s.rotv * h;
        // Division / refusion (suspendue quand la particule capte l'attention)
        s.tEtat -= h * (e > 0.35 ? 0 : 1);
        if (s.etat === 0 && s.tEtat <= 0) { s.etat = 1; s.tEtat = 2.6; }
        else if (s.etat === 1) { s.sig = Math.min(1, s.sig + h / 2.6); if (s.tEtat <= 0) { s.etat = 2; s.tEtat = 3.2; } }
        else if (s.etat === 2 && s.tEtat <= 0) { s.etat = 3; s.tEtat = 3.4; }
        else if (s.etat === 3) { s.sig = Math.max(0, s.sig - h / 3.4); if (s.sig <= 0) { s.etat = 0; s.tEtat = 9 + 4 * Math.sin(t + s.ph) ** 2; } }
        if (e > 0.35 && s.etat !== 0) { s.etat = 3; }
        // Pilotage du centre : la colonie rame (vitesse modulée par l'onde)
        s.wav += h * (2.2 + 2 * energy + 2.5 * e) * (0.6 + 0.4 * RG.vit);
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.ty - s.cy, s.tx - s.cx) - s.hd);
        else { const ecX = s.hx - s.cx, ecY = s.hy - s.cy, loin = Math.min(1, Math.hypot(ecX, ecY) / 170); d = 0.5 * Math.sin(t * 0.17 + s.ph) + enrouleAngle(Math.atan2(ecY, ecX) - s.hd) * loin * loin; }
        s.angv += (borne(d, -1.2, 1.2) * (s.g ? 1.3 * s.g : 0.5) - s.angv) * Math.min(1, h * 2);
        s.hd += s.angv * h;
        const rame = 0.55 + 0.45 * Math.max(0, Math.sin(s.wav * 2)), vit = (5 + 9 * energy + (s.g ? 7 * s.g : 0)) * RG.vit * rame * (1 - 0.4 * s.serre * (md === 'evite' ? -1 : 1));
        s.vx += (Math.cos(s.hd) * vit - s.vx) * Math.min(1, h * 2); s.vy += (Math.sin(s.hd) * vit - s.vy) * Math.min(1, h * 2);
        const fl = flow(s.cx, s.cy);
        const ncx = s.cx + (s.vx + fl[0] * 0.35) * h, ncy = s.cy + (s.vy + fl[1] * 0.35) * h;
        s.cx = enroule(ncx, 0, W, 80); s.cy = enroule(ncy, 0, H, 80);
        const jx = s.cx - ncx, jy = s.cy - ncy;
        if (jx || jy) for (let i = 0; i < K; i++) { px[i] += jx; py[i] += jy; }
        // Cibles de chaque cellule (anneau uni ↔ deux demi-colonies)
        const ss = lisse(s.sig), base = s.hd + s.rot;
        for (let i = 0; i < K; i++) {
          let q = base + i / K * TAU;
          let r = R0 * s.cell[i].rr * (1 + 0.16 * Math.sin(s.wav - i / K * TAU) + 0.07 * Math.sin(t * 0.43 + i * 1.9 + s.ph)) * (1 + 0.16 * Math.cos(q - s.hd) - 0.06 * Math.cos(2 * (q - s.hd))) * (1 - 0.36 * s.serre);
          if (s.lobe > 0.001 || s.bouche > 0.001) {
            const dq = enrouleAngle(q - s.pa);
            r += s.lobe * 26 * cloche(dq, 0.55) + s.bouche * 9 * cloche(dq, 1.1);
            q += s.bouche * 0.8 * Math.sign(dq) * cloche(dq, 1.2);
          }
          let fx = s.cx + Math.cos(q) * r, fy = s.cy + Math.sin(q) * r;
          if (ss > 0.001) {
            const gi = groupe(i), j = i % HK, mg = base + (gi * HK + (HK - 1) / 2) / K * TAU;
            const scx = s.cx + Math.cos(mg) * (8 + ss * 30), scy = s.cy + Math.sin(mg) * (8 + ss * 30);
            const qa = mg + (j - (HK - 1) / 2) * (TAU / HK) * (0.9 + 0.1 * Math.sin(s.wav * 0.5)), rr = 22 * (1 + 0.1 * Math.sin(s.wav - j));
            fx += (scx + Math.cos(qa) * rr - fx) * ss; fy += (scy + Math.sin(qa) * rr - fy) * ss;
          }
          tx[i] = fx; ty[i] = fy;
        }
        // Dynamique : ressort amorti vers la cible (dépassement = gelée), répulsion de contact
        const n = Math.ceil(h * 120), hh = h / n;
        for (let st = 0; st < n; st++) {
          for (let i = 0; i < K; i++) {
            vx[i] += ((tx[i] - px[i]) * 34 - vx[i] * 6.2) * hh; vy[i] += ((ty[i] - py[i]) * 34 - vy[i] * 6.2) * hh;
          }
          for (let i = 0; i < K; i++) for (let j = i + 1; j < K; j++) {
            const dx = px[j] - px[i], dy = py[j] - py[i], d2 = dx * dx + dy * dy;
            if (d2 < 196 && d2 > 0.01) { const d1 = Math.sqrt(d2), f = (14 - d1) * 30 * hh / d1; vx[i] -= dx * f; vy[i] -= dy * f; vx[j] += dx * f; vy[j] += dy * f; }
          }
          for (let i = 0; i < K; i++) { px[i] += vx[i] * hh; py[i] += vy[i] * hh; }
        }
        // Orientation des cellules : vers l'extérieur de leur groupe, avec retard (inertie)
        for (let i = 0; i < K; i++) {
          const gi = groupe(i);
          let gx = 0, gy = 0;
          if (ss > 0.001) { for (let k = gi * HK; k < gi * HK + HK; k++) { gx += px[k]; gy += py[k]; } gx = s.cx + (gx / HK - s.cx) * ss; gy = s.cy + (gy / HK - s.cy) * ss; }
          else { gx = s.cx; gy = s.cy; }
          const cible = Math.atan2(py[i] - gy, px[i] - gx) + Math.PI / 2 + 0.3 * Math.sin(t * 0.9 + s.cell[i].ph);
          oa[i] += enrouleAngle(cible - oa[i]) * Math.min(1, h * 3);
        }
        s.cph += h * (7 + 6 * energy + 12 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.7; if (A <= 0.001) return;
        const ss = lisse(s.sig), G = degr(ctx);
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // Centres des deux groupes (confondus quand la colonie est unie)
        let g0x = 0, g0y = 0, g1x = 0, g1y = 0;
        for (let i = 0; i < HK; i++) { g0x += px[i]; g0y += py[i]; g1x += px[i + HK]; g1y += py[i + HK]; }
        g0x = s.cx + (g0x / HK - s.cx) * ss; g0y = s.cy + (g0y / HK - s.cy) * ss; g1x = s.cx + (g1x / HK - s.cx) * ss; g1y = s.cy + (g1y / HK - s.cy) * ss;
        // 1. Membrane commune (ou deux membranes pendant la division)
        let rm = 0; for (let i = 0; i < K; i++) rm += Math.hypot(px[i] - s.cx, py[i] - s.cy); rm = rm / K + 12;
        const membrane = (i0, n, cx, cy, rmoy, Am) => {
          if (Am < 0.01) return;
          ctx.beginPath(); cheminMembrane(ctx, i0, n, cx, cy, 11);
          ctx.save(); ctx.translate(cx, cy); ctx.scale(rmoy, rmoy); ctx.fillStyle = G.mem; ctx.globalAlpha = Am; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Am * 0.06; ctx.lineWidth = 6; ctx.stroke();
          ctx.globalAlpha = Am * 0.4; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath(); cheminMembrane(ctx, i0, n, cx, cy, 6.5); ctx.globalAlpha = Am * 0.1; ctx.lineWidth = 1.3; ctx.stroke();
        };
        membrane(0, K, s.cx, s.cy, rm, A * (1 - ss));
        if (ss > 0.01) { membrane(0, HK, g0x, g0y, 34, A * ss); membrane(HK, HK, g1x, g1y, 34, A * ss); }
        // Froissement : plis courts là où la membrane est comprimée
        ctx.beginPath();
        for (let i = 0; i < K; i++) {
          const j = (i + 1) % K; if (ss > 0.4 && groupe(i) !== groupe(j)) continue;
          const d = Math.hypot(px[j] - px[i], py[j] - py[i]), comp = borne((REPOS * 0.98 - d) / (REPOS * 0.35), 0, 1);
          if (comp < 0.08) continue;
          const mx = (px[i] + px[j]) / 2, my = (py[i] + py[j]) / 2; let dx = mx - s.cx, dy = my - s.cy; const l = 1 / (Math.hypot(dx, dy) || 1); dx *= l; dy *= l;
          for (let k = -1; k <= 1; k++) { const ox2 = mx + dx * 9 - dy * k * 3.2, oy2 = my + dy * 9 + dx * k * 3.2, L = (2 + 2.5 * comp) * (k ? 0.7 : 1); ctx.moveTo(ox2, oy2); ctx.lineTo(ox2 - dx * L, oy2 - dy * L); }
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.5; ctx.stroke();
        // 2. Rayons fins des cellules vers leur cœur
        ctx.beginPath();
        for (let i = 0; i < K; i++) {
          const cx = groupe(i) ? g1x : g0x, cy = groupe(i) ? g1y : g0y, mx = (px[i] + cx) / 2, my = (py[i] + cy) / 2, cu = 4 * Math.sin(t * 0.8 + i);
          ctx.moveTo(px[i], py[i]); ctx.quadraticCurveTo(mx - (py[i] - cy) * cu / 30, my + (px[i] - cx) * cu / 30, cx, cy);
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.45; ctx.stroke();
        // 3. Fils entre voisines : les mous pendent vers le centre, les tendus vibrent ; ceux qui
        //    relient les deux moitiés cassent à la division et sont relancés à la refusion
        ctx.beginPath(); let np = 0;
        for (let i = 0; i < K; i++) {
          let j = (i + 1) % K; const coupe = groupe(i) !== groupe(j);
          let fr = 1; if (coupe) { fr = borne(1 - ss * 1.9, 0, 1); if (fr <= 0.02) { j = groupe(i) * HK; fr = borne((ss - 0.5) * 2.2, 0, 1); } }
          if (fr <= 0.02) continue;
          const dx = px[j] - px[i], dy = py[j] - py[i], d = Math.hypot(dx, dy) || 1;
          let nx = -dy / d, ny = dx / d; const mx0 = (px[i] + px[j]) / 2, my0 = (py[i] + py[j]) / 2;
          if ((s.cx - mx0) * nx + (s.cy - my0) * ny < 0) { nx = -nx; ny = -ny; }
          const mou = Math.max(0, REPOS - d), tendu = Math.max(0, d - REPOS) / REPOS;
          const sag = mou * 0.6 + tendu * 3.5 * Math.sin(t * 41 + i * 2) + (coupe ? (1 - fr) * 6 : 0);
          const ex = px[i] + dx * fr, ey = py[i] + dy * fr;
          const cxq = px[i] + dx * fr * 0.5 + nx * sag * fr, cyq = py[i] + dy * fr * 0.5 + ny * sag * fr;
          ctx.moveTo(px[i], py[i]); ctx.quadraticCurveTo(cxq, cyq, ex, ey);
          if (fr > 0.99) { perle[np++] = 0.25 * px[i] + 0.5 * cxq + 0.25 * ex; perle[np++] = 0.25 * py[i] + 0.5 * cyq + 0.25 * ey; }
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 3; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.65; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < np; k += 2) { ctx.moveTo(perle[k] + 1.2, perle[k + 1]); ctx.arc(perle[k], perle[k + 1], 1.2, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.fill();
        // 4. Cœur : deux trèfles de filament enlacés, qui se séparent avec la colonie
        ctx.beginPath(); trefle(ctx, g0x, g0y, t * 0.5 + s.ph, 1 - 0.2 * ss); trefle(ctx, g1x, g1y, -t * 0.5 + s.ph + 1, 1 - 0.2 * ss);
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 3.5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.36; ctx.lineWidth = 0.6; ctx.stroke();
        // 5. Cellules (mini-Cellules : corps à dégradé, double membrane, cils métachronaux)
        for (let i = 0; i < K; i++) {
          const kc = s.cell[i].k; ctx.save(); ctx.translate(px[i], py[i]); ctx.rotate(oa[i]); ctx.scale(CA * kc, CB * kc);
          ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fillStyle = G.cell; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        }
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const kc = s.cell[i].k; ctx.moveTo(px[i] + Math.cos(oa[i]) * CA * kc, py[i] + Math.sin(oa[i]) * CA * kc); ctx.ellipse(px[i], py[i], CA * kc, CB * kc, oa[i], 0, TAU); }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.06; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.8; ctx.stroke();
        // Cils : plus longs et plus rapides du côté qui rame (arrière de la colonie)
        ctx.beginPath();
        const hx = Math.cos(s.hd), hy = Math.sin(s.hd);
        for (let i = 0; i < K; i++) {
          const ca = Math.cos(oa[i]), sa = Math.sin(oa[i]);
          const rameur = 0.5 + 0.5 * borne(-((px[i] - s.cx) * hx + (py[i] - s.cy) * hy) / R0, -1, 1);
          for (let k = 0; k < NCIL; k++) {
            const q = k / NCIL * TAU, kc = s.cell[i].k, lx = CA * kc * Math.cos(q), ly = CB * kc * Math.sin(q);
            let nx = CB * Math.cos(q), ny = CA * Math.sin(q); const nl = 1 / Math.hypot(nx, ny); nx *= nl; ny *= nl;
            const ph = s.cph * (1 + 0.6 * rameur) + s.cell[i].ph - k * 0.6, L = (1.8 + 1.1 * Math.sin(ph)) * (1 + 0.6 * rameur + 0.4 * s.exc), pl = 0.9 * Math.cos(ph);
            const ax = lx + nx * 0.6, ay = ly + ny * 0.6, bx = lx + nx * (0.6 + L) - ny * pl, by = ly + ny * (0.6 + L) + nx * pl;
            ctx.moveTo(px[i] + ax * ca - ay * sa, py[i] + ax * sa + ay * ca); ctx.lineTo(px[i] + bx * ca - by * sa, py[i] + bx * sa + by * ca);
          }
        }
        ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.45; ctx.stroke();
        // Noyaux et vacuoles
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const c = s.cell[i], x = px[i] + Math.cos(oa[i]) * CA * c.nx, y = py[i] + Math.sin(oa[i]) * CA * c.nx; ctx.moveTo(x + 2.2, y); ctx.arc(x, y, 2.2, 0, TAU); }
        ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.12; ctx.fill(); ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.5; ctx.stroke();
        ctx.beginPath();
        for (let i = 0; i < K; i++) { const c = s.cell[i], rr = 1.3 * (1 + 0.15 * Math.sin(t * 1.7 + c.ph)), x = px[i] - Math.cos(oa[i]) * CA * c.vac, y = py[i] - Math.sin(oa[i]) * CA * c.vac; ctx.moveTo(x + rr, y); ctx.arc(x, y, rr, 0, TAU); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.4; ctx.fill(); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.6; ctx.stroke();
        // 6. Lumières : l'impulsion fait le tour de l'anneau, de cellule en cellule
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const tete = s.lueur.pos * K * 1.25;
          ctx.fillStyle = ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < K; i++) {
            const li = I * cloche(i - tete, i < tete ? 2 : 0.8); if (li < 0.004) continue;
            ctx.beginPath(); ctx.ellipse(px[i], py[i], CA + 1, CB + 1, oa[i], 0, TAU);
            ctx.globalAlpha = li * 0.18; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.8; ctx.lineWidth = 0.9; ctx.stroke();
            const j = (i + 1) % K; if (ss > 0.4 && groupe(i) !== groupe(j)) continue; ctx.beginPath(); ctx.moveTo(px[i], py[i]); ctx.lineTo(px[j], py[j]); ctx.globalAlpha = li * 0.35; ctx.lineWidth = 0.8; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.cx, s.cy, 6 + 22 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.16 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(s.cx, s.cy, 1.5 + 3 * s.gobe, 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); trefle(ctx, s.cx, s.cy, t * 0.5 + s.ph, 1); ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.5 * s.gobe; ctx.lineWidth = 0.8; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }


  /* =====================================================================
     DÉCOR VIVANT — poils, antennes, voiles translucides (greffés sur geo())
     Chaque poil est une chaîne à inertie : l'ancre bouge, le reste suit en retard et flotte.
     ===================================================================== */
  function creerDecor() {
    const P = palette;
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), lueur: rgb(P.lueur), ambre: rgb(P.ambre) };
    let t = 0; const etat = {};
    const nouveauPoil = (n, L, ph, bille) => ({ x: new Float32Array(n), y: new Float32Array(n), n, L, ph, bille, ok: false });
    function majPoil(h, ax, ay, ang, dt, flow, bend, raideur) {
      const n = h.n;
      if (!h.ok) { for (let i = 0; i < n; i++) { h.x[i] = ax + Math.cos(ang) * h.L * i; h.y[i] = ay + Math.sin(ang) * h.L * i; } h.ok = true; }
      h.x[0] = ax; h.y[0] = ay;
      for (let i = 1; i < n; i++) {
        const s = i / (n - 1), a = ang + bend * Math.sin(t * 1.3 + h.ph + i * 0.7) * s;
        const tx = h.x[i - 1] + Math.cos(a) * h.L, ty = h.y[i - 1] + Math.sin(a) * h.L;
        const f = flow(h.x[i], h.y[i]), k = Math.min(1, dt * raideur * (1.25 - 0.8 * s));
        h.x[i] += (tx - h.x[i]) * k + f[0] * 0.14 * s * dt; h.y[i] += (ty - h.y[i]) * k + f[1] * 0.14 * s * dt;
        const ex = h.x[i] - h.x[i - 1], ey = h.y[i] - h.y[i - 1], l = Math.hypot(ex, ey) || 1;
        h.x[i] = h.x[i - 1] + ex / l * h.L; h.y[i] = h.y[i - 1] + ey / l * h.L;
      }
    }
    function tracePoil(ctx, h, A) {
      const n = h.n, x0 = h.x[0], y0 = h.y[0], x1 = h.x[n - 1], y1 = h.y[n - 1];
      // Effilement sans dégradé : moitié proximale nacrée, moitié distale aqua plus pâle
      const mid = n >> 1;
      ctx.beginPath(); ctx.moveTo(x0, y0);
      for (let i = 1; i <= mid; i++) ctx.lineTo(h.x[i], h.y[i]);
      ctx.globalAlpha = A * 0.55; ctx.strokeStyle = coul.perle; ctx.lineWidth = h.bille ? 0.8 : 0.55; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(h.x[mid], h.y[mid]);
      for (let i = mid + 1; i < n - 1; i++) ctx.quadraticCurveTo(h.x[i], h.y[i], (h.x[i] + h.x[i + 1]) / 2, (h.y[i] + h.y[i + 1]) / 2);
      ctx.lineTo(x1, y1);
      ctx.globalAlpha = A * 0.2; ctx.strokeStyle = coul.aqua; ctx.lineWidth = h.bille ? 0.7 : 0.45; ctx.stroke();
      if (h.bille) {
        ctx.fillStyle = coul.lueur; ctx.globalAlpha = A * 0.12; ctx.beginPath(); ctx.arc(x1, y1, h.bille * 3, 0, TAU); ctx.fill();
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.7; ctx.beginPath(); ctx.arc(x1, y1, h.bille, 0, TAU); ctx.fill();
      }
    }
    function majVoile(vo, n, bx, by, ox, oy, dt, k) {
      if (!vo.x || vo.x.length !== n) { vo.x = Float32Array.from(ox); vo.y = Float32Array.from(oy); }
      const kk = Math.min(1, dt * k);
      for (let i = 0; i < n; i++) { vo.x[i] += (ox[i] - vo.x[i]) * kk; vo.y[i] += (oy[i] - vo.y[i]) * kk; }
    }
    function traceVoile(ctx, vo, n, bx, by, A) {
      ctx.beginPath(); ctx.moveTo(bx[0], by[0]);
      for (let i = 1; i < n; i++) ctx.lineTo(bx[i], by[i]);
      for (let i = n - 1; i >= 0; i--) ctx.lineTo(vo.x[i], vo.y[i]);
      ctx.closePath(); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.075; ctx.fill();
      ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.03; ctx.fill();
      ctx.beginPath(); ctx.moveTo(vo.x[0], vo.y[0]); for (let i = 1; i < n; i++) ctx.lineTo(vo.x[i], vo.y[i]);
      ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.beginPath(); for (let i = 1; i < n - 1; i += 2) { ctx.moveTo(bx[i], by[i]); ctx.lineTo(vo.x[i], vo.y[i]); }
      ctx.globalAlpha = A * 0.1; ctx.lineWidth = 0.4; ctx.stroke();
    }
    function st(cle, f) { return etat[cle] || (etat[cle] = f()); }

    // Cellule : couronne de poils, deux antennes à perle, longs fouets arrière, jupe translucide
    function majCell(g, id, dt, flow) {
      const S = st('c' + id, () => ({ h: [], vo: {}, bx: new Float32Array(9), by: new Float32Array(9), ox: new Float32Array(9), oy: new Float32Array(9) }));
      if (!S.h.length) {
        for (let j = 0; j < 12; j++) S.h.push({ q: (j / 12) * TAU + 0.2, p: nouveauPoil(5, 3.2 + (j % 3) * 0.8, j * 1.7, 0) });
        S.h.push({ q: -0.38, p: nouveauPoil(6, 5, 0.3, 1.2), ant: 1 }, { q: 0.38, p: nouveauPoil(6, 5, 2.1, 1.2), ant: 1 });
        S.h.push({ q: Math.PI - 0.22, p: nouveauPoil(7, 6, 1, 0), fouet: 1 }, { q: Math.PI + 0.22, p: nouveauPoil(7, 6, 4, 0), fouet: 1 });
      }
      const ca = Math.cos(g.ang), sa = Math.sin(g.ang);
      for (const o of S.h) {
        const lx = g.a * Math.cos(o.q), ly = g.b * Math.sin(o.q), nxl = g.b * Math.cos(o.q), nyl = g.a * Math.sin(o.q);
        const ang = g.ang + Math.atan2(nyl, nxl);
        majPoil(o.p, g.x + lx * ca - ly * sa, g.y + lx * sa + ly * ca, o.fouet ? g.ang + Math.PI + (o.q > Math.PI ? 0.25 : -0.25) : ang, dt, flow, o.ant ? 0.9 : o.fouet ? 0.7 : 0.5, o.fouet ? 3 : 4.5);
      }
      for (let i = 0; i < 9; i++) {
        const q = Math.PI * (0.62 + 0.76 * i / 8), lx = g.a * Math.cos(q), ly = g.b * Math.sin(q);
        S.bx[i] = g.x + lx * ca - ly * sa; S.by[i] = g.y + lx * sa + ly * ca;
        const nxl = g.b * Math.cos(q), nyl = g.a * Math.sin(q), la = g.ang + Math.atan2(nyl, nxl), d = 13 + 6 * Math.sin(t * 1.5 + i * 0.8);
        S.ox[i] = S.bx[i] + Math.cos(la) * d - ca * 8; S.oy[i] = S.by[i] + Math.sin(la) * d - sa * 8;
      }
      majVoile(S.vo, 9, S.bx, S.by, S.ox, S.oy, dt, 2.2);
      S.g = g;
    }
    function traceCell(ctx, id, A) {
      const S = etat['c' + id]; if (!S) return;
      traceVoile(ctx, S.vo, 9, S.bx, S.by, A);
      for (const o of S.h) tracePoil(ctx, o.p, A * (o.fouet ? 1 : 0.8));
    }
    // Corps en chaîne : antennes de tête, fouets de queue, poils de flanc, voile latéral
    function majChaine(g, id, dt, flow) {
      const N = g.N, p = g.p, e = g.e || 1;
      const S = st('k' + id, () => ({ a: [], q: [], f: [], vo: [{}, {}], bx: [new Float32Array(N), new Float32Array(N)], by: [new Float32Array(N), new Float32Array(N)], ox: [new Float32Array(N), new Float32Array(N)], oy: [new Float32Array(N), new Float32Array(N)] }));
      if (!S.a.length) {
        if (p.ant) for (let s = 0; s < 2; s++) S.a.push(nouveauPoil(7, p.ant / 6, s * 2.3, 1.3));
        for (let s = 0; s < (p.queue || 0); s++) S.q.push(nouveauPoil(8, 4.5, s * 3.1, 0));
        if (p.flancs) for (let i = 6; i < N - 4; i += p.flancs) for (let s = 0; s < 2; s++) S.f.push({ i, s: s ? 1 : -1, p: nouveauPoil(4, 3.4, i + s * 5, 0) });
      }
      const px = g.px, py = g.py, nxs = [], nys = [];
      for (let i = 0; i < N; i++) { const a = Math.max(0, i - 1), b = Math.min(N - 1, i + 1); let tx = px[a] - px[b], ty = py[a] - py[b]; const l = 1 / (Math.hypot(tx, ty) || 1); nxs[i] = -ty * l; nys[i] = tx * l; }
      const hang = Math.atan2(py[0] - py[2], px[0] - px[2]);
      S.a.forEach((h, s) => majPoil(h, px[1] + nxs[1] * (s ? 1 : -1) * 2, py[1] + nys[1] * (s ? 1 : -1) * 2, hang + (s ? 0.55 : -0.55), dt, flow, 0.7, 3.4));
      const tang = Math.atan2(py[N - 1] - py[N - 3], px[N - 1] - px[N - 3]);
      S.q.forEach((h, s) => majPoil(h, px[N - 1], py[N - 1], tang + (s ? 0.35 : -0.35), dt, flow, 0.8, 2.6));
      for (const o of S.f) majPoil(o.p, px[o.i] + nxs[o.i] * o.s * g.lg[o.i] * e, py[o.i] + nys[o.i] * o.s * g.lg[o.i] * e, Math.atan2(nys[o.i] * o.s, nxs[o.i] * o.s) + o.s * 0.9, dt, flow, 0.6, 4);
      if (p.voile) for (let s = 0; s < 2; s++) {
        const sg = s ? 1 : -1, v = S.vo[s];
        for (let i = 0; i < N; i++) {
          const w = g.lg[i] * e, k = i / (N - 1);
          S.bx[s][i] = px[i] + nxs[i] * sg * w; S.by[s][i] = py[i] + nys[i] * sg * w;
          const d = p.voile * Math.sin(Math.PI * Math.min(1, k * 1.15)) * (0.6 + 0.4 * Math.sin(t * 1.7 - i * 0.5 + s * 2)) + 1;
          S.ox[s][i] = S.bx[s][i] + nxs[i] * sg * d; S.oy[s][i] = S.by[s][i] + nys[i] * sg * d;
        }
        majVoile(v, N, S.bx[s], S.by[s], S.ox[s], S.oy[s], dt, 3);
      }
    }
    function traceChaine(ctx, g, id, A) {
      const S = etat['k' + id]; if (!S) return;
      if (g.p.voile) for (let s = 0; s < 2; s++) traceVoile(ctx, S.vo[s], g.N, S.bx[s], S.by[s], A);
      for (const h of S.q) tracePoil(ctx, h, A); for (const o of S.f) tracePoil(ctx, o.p, A * 0.8); for (const h of S.a) tracePoil(ctx, h, A * 1.1);
    }
    return {
      update(dt, flow, geos) { t += dt; geos.forEach((g, i) => { if (g.k === 'cell') majCell(g, i, dt, flow); else if (g.k === 'chaine') majChaine(g, i, dt, flow); }); },
      draw(ctx, geos, alpha) { ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; const A = alpha * 0.62; geos.forEach((g, i) => { if (g.k === 'cell') traceCell(ctx, i, A); else if (g.k === 'chaine') traceChaine(ctx, g, i, A); }); ctx.restore(); },
      reset() { for (const k in etat) delete etat[k]; },
      // Décale tous les points mémorisés (utile quand le motif hôte est téléporté ou s'enroule)
      decale(dx, dy) {
        const sh = h => { if (h && h.x && h.y) for (let i = 0; i < h.x.length; i++) { h.x[i] += dx; h.y[i] += dy; } };
        for (const k in etat) { const S = etat[k];
          if (S.h) S.h.forEach(o => sh(o.p)); if (S.a) S.a.forEach(sh); if (S.q) S.q.forEach(sh); if (S.f) S.f.forEach(o => sh(o.p));
          if (S.vo) { if (Array.isArray(S.vo)) S.vo.forEach(sh); else sh(S.vo); } }
      }
    };
  }

  /* =====================================================================
     ÉTAGE 3 — outils partagés : corps rigide (équations d'Euler) et enveloppe convexe
     ===================================================================== */
  function corpsRigide(I1, I2, I3) {
    const R = new Float64Array(9), w = new Float64Array(3), tau = new Float64Array(3), pj = new Float64Array(3);
    const o = {
      R, w, tau, pj,
      init(a0, b0) {
        const c = Math.cos(a0), sn = Math.sin(a0), cb = Math.cos(b0), sb = Math.sin(b0);
        R[0] = c; R[1] = -sn * cb; R[2] = sn * sb; R[3] = sn; R[4] = c * cb; R[5] = -c * sb; R[6] = 0; R[7] = sb; R[8] = cb;
      },
      proj(x, y, z) { pj[0] = R[0] * x + R[1] * y + R[2] * z; pj[1] = R[3] * x + R[4] * y + R[5] * z; pj[2] = R[6] * x + R[7] * y + R[8] * z; },
      pas(h) {
        const w1 = w[0], w2 = w[1], w3 = w[2];
        w[0] += ((I2 - I3) * w2 * w3 + tau[0]) / I1 * h;
        w[1] += ((I3 - I1) * w3 * w1 + tau[1]) / I2 * h;
        w[2] += ((I1 - I2) * w1 * w2 + tau[2]) / I3 * h;
        for (let r = 0; r < 9; r += 3) {
          const a = R[r], b = R[r + 1], c = R[r + 2];
          R[r] = a + h * (b * w[2] - c * w[1]); R[r + 1] = b + h * (c * w[0] - a * w[2]); R[r + 2] = c + h * (a * w[1] - b * w[0]);
        }
      },
      orth() {
        let l = 1 / Math.hypot(R[0], R[3], R[6]); R[0] *= l; R[3] *= l; R[6] *= l;
        const d = R[0] * R[1] + R[3] * R[4] + R[6] * R[7]; R[1] -= d * R[0]; R[4] -= d * R[3]; R[7] -= d * R[6];
        l = 1 / Math.hypot(R[1], R[4], R[7]); R[1] *= l; R[4] *= l; R[7] *= l;
        R[2] = R[3] * R[7] - R[6] * R[4]; R[5] = R[6] * R[1] - R[0] * R[7]; R[8] = R[0] * R[4] - R[3] * R[1];
      },
      // Couple qui aligne l'axe propre n° col sur la direction monde (dx,dy,dz) ; amortit les deux autres rotations
      viser(col, dx, dy, dz, kA, kD) {
        const ex = R[col], ey = R[3 + col], ez = R[6 + col];
        const tx = ey * dz - ez * dy, ty = ez * dx - ex * dz, tz = ex * dy - ey * dx;
        for (let k = 0; k < 3; k++) tau[k] += kA * (R[k] * tx + R[3 + k] * ty + R[6 + k] * tz) - (k === col ? 0 : kD * w[k]);
      },
      // Moteur ciliaire : ramène |ω| vers spin, petite perturbation déterministe
      moteur(spin, kick, t, ph) {
        const wm = Math.hypot(w[0], w[1], w[2]) || 1, ks = 1.4 * (spin - wm) / wm;
        tau[0] += ks * w[0] * I1 + kick * Math.sin(t * 1.7 + ph) * I1;
        tau[1] += ks * w[1] * I2;
        tau[2] += ks * w[2] * I3 + kick * Math.cos(t * 1.1 + ph) * I3;
      },
      avancer(h) { const n = Math.ceil(h * 240), hh = h / n; for (let k = 0; k < n; k++) o.pas(hh); o.orth(); }
    };
    return o;
  }
  // Enveloppe convexe (chaîne monotone d'Andrew) de n points (X,Y) ; écrit les indices dans out, renvoie leur nombre
  function enveloppeConvexe(X, Y, n, idx, out) {
    for (let i = 0; i < n; i++) idx[i] = i;
    const ix = Array.prototype.slice.call(idx, 0, n).sort((a, b) => X[a] - X[b] || Y[a] - Y[b]);
    let k = 0;
    const croix = (o, a, b) => (X[a] - X[o]) * (Y[b] - Y[o]) - (Y[a] - Y[o]) * (X[b] - X[o]);
    for (let i = 0; i < n; i++) { while (k >= 2 && croix(out[k - 2], out[k - 1], ix[i]) <= 0) k--; out[k++] = ix[i]; }
    for (let i = n - 2, b = k + 1; i >= 0; i--) { while (k >= b && croix(out[k - 2], out[k - 1], ix[i]) <= 0) k--; out[k++] = ix[i]; }
    return k - 1;
  }
  const melange = (a, b, k) => a + (b - a) * k;
  const lisseP = u => u * u * (3 - 2 * u);

  /* =====================================================================
     6. CORTÈGE — colonie-siphon (étage 3 : Systole × Chœur ; greffe : col harponneur 28007)
     Une tige (le fil du Chœur) porte en tête un flotteur, puis six petites cloches de Systole
     en fermeture éclair, puis trois polypes pêcheurs à long tentacule. Les cloches sont des
     oscillateurs couplés (Kuramoto) : elles se synchronisent en onde métachronale qui court
     de l'avant vers l'arrière ; le décalage visé change selon l'intention (onde lente = glisse,
     salve synchrone = bond, alternance = galop). Elle braque en pompant plus fort d'un côté.
     ===================================================================== */
  function creerCortege() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NB = 6, NS = 34, NC = 3, NTP = 16, NBS = 9, NR = 10, SEG = 4.2;
    const ATT = [2, 4, 6, 8, 10, 12], CORM = [17, 24, 31];
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(0.35, -0.2, 0, 0.05, 0, 1.05);
      g.addColorStop(0, rgba(P.perle, 0.14)); g.addColorStop(0.5, rgba(P.sarcelle, 0.18));
      g.addColorStop(0.84, rgba(P.aqua, 0.22)); g.addColorStop(1, rgba(P.perle, 0.34));
      const f = ctx.createRadialGradient(-0.3, -0.35, 0, 0, 0, 1);
      f.addColorStop(0, rgba(P.perle, 0.32)); f.addColorStop(0.45, rgba(P.aqua, 0.16)); f.addColorStop(0.9, rgba(P.sarcelle, 0.18)); f.addColorStop(1, rgba(P.perle, 0.3));
      return { cloche: g, flot: f };
    });
    const contraction = f => f < 0.26 ? 0.5 - 0.5 * Math.cos(Math.PI * f / 0.26) : 0.5 + 0.5 * Math.cos(Math.PI * (f - 0.26) / 0.74);
    const bx = new Float32Array(NBS), bw = new Float32Array(NBS), dph = new Float32Array(NB);
    const nxs = new Float32Array(NS), nys = new Float32Array(NS);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    // Profil d'une cloche (repère local, apex en +x) : rapide, sans courbure
    function profil(a, b, ro, c, ph) {
      for (let i = 0; i < NBS; i++) {
        const q = i / (NBS - 1);
        bx[i] = a * (1 - 1.86 * q);
        let w = q < 0.55 ? b * Math.pow(Math.sin(Math.PI / 2 * q / 0.55), 0.6) : b + (ro - b) * (0.5 - 0.5 * Math.cos(Math.PI * (q - 0.55) / 0.45));
        if (q > 0.15) w *= 1 + 0.07 * c * Math.sin(q * 23 + ph);
        bw[i] = w;
      }
    }
    function cheminCloche(ctx, k) {
      ctx.moveTo(bx[NBS - 1], -bw[NBS - 1] * k);
      for (let i = NBS - 2; i >= 0; i--) ctx.lineTo(bx[i], -bw[i] * k);
      for (let i = 1; i < NBS; i++) ctx.lineTo(bx[i], bw[i] * k);
    }
    const angTige = i => { const a = Math.max(0, i - 1), b = Math.min(NS - 1, i + 1); return Math.atan2(s.sy[a] - s.sy[b], s.sx[a] - s.sx[b]); };

    return {
      init(w, h, seed, opts) {
        W = w; H = h; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xc07e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.64 : 0.34);
        s = { hx, hy, x: hx + (r() - 0.5) * 50, y: hy + (r() - 0.5) * 50, vx: 0, vy: 0, ang: r() * TAU, angv: 0, ph0: r() * TAU, bend: 0,
          ph: new Float32Array(NB), c: new Float32Array(NB), dc: new Float32Array(NB), amp: new Float32Array(NB), flash: new Float32Array(NB),
          sx: new Float32Array(NS), sy: new Float32Array(NS), lag: 0.14, K: 1.4, frq: 0.6, exc: 0, gobe: 0, tl: 1, curl: 0.15, harp: 0, gon: 0,
          tex: [], tey: [], pa: new Float32Array(NC), tlk: new Float32Array(NC), anneaux: [], ri: 0, lueur: lueurNeuve(r),
          g: 0, gx: 0, gy: 0, cph: 0, e: 0.95 + 0.1 * r(), u: 0 };
        for (let i = 0; i < NB; i++) { s.ph[i] = r(); s.amp[i] = 1; s.c[i] = contraction(s.ph[i]); }
        for (let i = 0; i < NS; i++) { s.sx[i] = s.x - Math.cos(s.ang) * SEG * i; s.sy[i] = s.y - Math.sin(s.ang) * SEG * i; }
        for (let k = 0; k < NC; k++) {
          const X = new Float32Array(NTP), Y = new Float32Array(NTP), j = CORM[k];
          for (let i = 0; i < NTP; i++) { X[i] = s.sx[j] - Math.cos(s.ang) * i * 3.6; Y[i] = s.sy[j] - Math.sin(s.ang) * i * 3.6; }
          s.tex.push(X); s.tey.push(Y); s.pa[k] = s.ang + Math.PI + (k % 2 ? 1 : -1) * 1.2; s.tlk[k] = 1;
        }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, a: 0, r: 0, vie: 0 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      centre() { return [s.sx[14], s.sy[14]]; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 30 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 190) - s.exc) * Math.min(1, h * 2.5));
        // Intention → synchronie : décalage de phase visé, couplage, cadence ; tentacules
        let lag = 0.14, K = 1.4, frq = 0.5 + 0.55 * energy, tl = 1, curl = 0.15, harp = 0, gon = 0;
        if (e > 0.01) {
          if (md === 'cont') { lag = melange(lag, 0.24, e); frq -= 0.15 * e; tl = 1 + 0.45 * e; gon = e; }
          else if (md === 'actif') { lag = melange(lag, 0.5, e); K = 2.2; frq += 0.35 * e; tl = 1 + 0.15 * e; }
          else if (md === 'agr') { lag = melange(lag, 0, e); K = melange(K, 4.5, e); frq += 0.45 * e; harp = e; }
          else if (md === 'suit') { lag = melange(lag, 0.09, e); tl = 1 + 0.3 * e; gon = 0.4 * e; }
          else if (md === 'evite') { lag = melange(lag, 0.02, e); K = melange(K, 5, e); frq += 0.9 * e; tl = 1 - 0.5 * e; curl = melange(curl, 2.4, e); }
          else { lag = melange(lag, 0.32, e); tl = 1 + 0.25 * e; gon = 0.5 * e; }
        }
        const kk = Math.min(1, h * 1.6);
        s.lag += (lag - s.lag) * kk; s.K += (K - s.K) * kk; s.frq += (frq * (0.55 + 0.45 * RG.vit) - s.frq) * kk;
        s.tl += (tl - s.tl) * kk; s.curl += (curl - s.curl) * kk; s.harp += (harp - s.harp) * kk; s.gon += (gon - s.gon) * kk;
        // Cap visé
        let d;
        if (s.g) d = enrouleAngle(Math.atan2(s.gy - s.y, s.gx - s.x) - s.ang);
        else {
          const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 180);
          d = 0.7 * Math.sin(t * 0.19 + s.ph0) + enrouleAngle(Math.atan2(ecY, ecX) - s.ang) * loin * loin;
        }
        s.u += (borne(d * 0.9, -0.8, 0.8) * (s.g ? Math.min(1, 0.45 + s.g) : 0.6) - s.u) * Math.min(1, h * 3);
        // Oscillateurs couplés (plus proches voisins, onde avant → arrière)
        for (let i = 0; i < NB; i++) {
          let cpl = 0;
          if (i > 0) cpl += Math.sin(TAU * (s.ph[i - 1] - s.ph[i] - s.lag));
          if (i < NB - 1) cpl += Math.sin(TAU * (s.ph[i + 1] - s.ph[i] + s.lag));
          dph[i] = s.frq + s.K * 0.09 * cpl;
        }
        let F = 0, Tq = 0;
        const fwx = Math.cos(s.ang), fwy = Math.sin(s.ang);
        for (let i = 0; i < NB; i++) {
          const side = i % 2 ? 1 : -1;
          s.amp[i] += (1 + side * s.u - s.amp[i]) * Math.min(1, h * 4);
          const f0 = s.ph[i]; s.ph[i] += Math.max(0.05, dph[i]) * h;
          const pic = f0 < 0.26 && s.ph[i] >= 0.26;
          if (s.ph[i] >= 1) s.ph[i] -= 1;
          const cp = s.c[i]; s.c[i] = contraction(s.ph[i]); s.dc[i] = (s.c[i] - cp) / h;
          const f = Math.max(0, s.dc[i]) * s.amp[i];
          F += f; Tq += side * f;
          s.flash[i] = Math.max(0, s.flash[i] - h * 2.2);
          if (pic) {
            s.flash[i] = 1;
            const j = ATT[i], ta = angTige(j) + side * 0.32, an = s.anneaux[s.ri++ % NR];
            const mx = s.sx[j] + nxs[j] * side * 5.5 * s.e - Math.cos(ta) * 8 * s.e, my = s.sy[j] + nys[j] * side * 5.5 * s.e - Math.sin(ta) * 8 * s.e;
            an.x = mx; an.y = my; an.vx = -Math.cos(ta) * 18 + s.vx * 0.1; an.vy = -Math.sin(ta) * 18 + s.vy * 0.1; an.a = ta; an.r = 3.4 * s.e * s.amp[i]; an.vie = 1;
          }
        }
        const pousse = F * 9.5 * s.e * (0.85 + 0.3 * energy), fr = Math.exp(-1.5 * h);
        s.vx = s.vx * fr + fwx * pousse * h; s.vy = s.vy * fr + fwy * pousse * h;
        s.angv += (Tq * 1.05 - 2.4 * s.angv) * h * 2.2;
        s.ang += s.angv * h;
        s.bend += (-s.angv * 0.5 - s.bend) * Math.min(1, h * 3);
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.35) * h, ny = s.y + (s.vy + fl[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 110); s.y = enroule(ny, 0, H, 110);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let i = 0; i < NS; i++) { s.sx[i] += jx; s.sy[i] += jy; }
          for (let k = 0; k < NC; k++) for (let i = 0; i < NTP; i++) { s.tex[k][i] += jx; s.tey[k][i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        // Tige : suivi du chef, raide dans le nectosome, souple et dérivante vers la queue
        const sx = s.sx, sy = s.sy, seg = SEG * s.e;
        sx[0] = s.x; sy[0] = s.y;
        for (let i = 1; i < NS; i++) { const fi = flow(sx[i], sy[i]), q = i / NS; sx[i] += fi[0] * 0.3 * q * h; sy[i] += fi[1] * 0.3 * q * h; }
        for (let i = 1; i < NS - 1; i++) {
          const kr = i < 14 ? 0.3 : 0.05;
          sx[i] += ((sx[i - 1] + sx[i + 1]) * 0.5 - sx[i]) * kr; sy[i] += ((sy[i - 1] + sy[i + 1]) * 0.5 - sy[i]) * kr;
        }
        // Le nectosome garde l'axe du flotteur (sinon il se plierait sous les poussées)
        for (let i = 1; i < NS; i++) {
          if (i < 13) { const kq = 0.35 * (1 - i / 13); sx[i] += (sx[0] - fwx * seg * i - sx[i]) * kq; sy[i] += (sy[0] - fwy * seg * i - sy[i]) * kq; }
          const ex = sx[i] - sx[i - 1], ey = sy[i] - sy[i - 1], k = seg / (Math.hypot(ex, ey) || 1);
          sx[i] = sx[i - 1] + ex * k; sy[i] = sy[i - 1] + ey * k;
        }
        for (let i = 0; i < NS; i++) { const a = angTige(i); nxs[i] = -Math.sin(a); nys[i] = Math.cos(a); }
        // Polypes et tentacules : pêche (cont), harpon (agr), spirale serrée (evite)
        const pon = RG.part && RG.part.on;
        let hk = -1, hd = 1e9;
        if (pon && s.harp > 0.05) for (let k = 0; k < NC; k++) { const j = CORM[k], dd = Math.hypot(RG.part.x - sx[j], RG.part.y - sy[j]); if (dd < hd) { hd = dd; hk = k; } }
        for (let k = 0; k < NC; k++) {
          const j = CORM[k], side = k % 2 ? 1 : -1, ta = angTige(j), arr = ta + Math.PI;
          const cible = arr + side * (1.05 + 0.5 * s.gon + 0.2 * Math.sin(t * 0.8 + k * 2));
          s.pa[k] += enrouleAngle(cible - s.pa[k]) * Math.min(1, h * 2.5);
          const harpe = k === hk ? s.harp * borne(1.6 - hd / 110, 0, 1) : 0;
          s.tlk[k] += ((s.tl + 1.3 * harpe) - s.tlk[k]) * Math.min(1, h * (harpe > 0.1 ? 6 : 2));
          const X = s.tex[k], Y = s.tey[k], pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
          X[0] = sx[j] + pc * 10 * s.e; Y[0] = sy[j] + ps * 10 * s.e;
          let a0;
          if (harpe > 0.05) a0 = Math.atan2(RG.part.y - Y[0], RG.part.x - X[0]);
          else {
            const wt = 0.3 + 0.45 * s.gon, vxm = Math.cos(arr) * (1 - wt) + pc * wt, vym = Math.sin(arr) * (1 - wt) + ps * wt;
            a0 = Math.atan2(vym, vxm);
            if (pon && s.gon > 0.05) a0 += enrouleAngle(Math.atan2(RG.part.y - Y[0], RG.part.x - X[0]) - a0) * 0.35 * s.gon;
          }
          const sg = 3.6 * s.e * s.tlk[k];
          let a = a0;
          for (let i = 1; i < NTP; i++) {
            const q = i / (NTP - 1);
            a += (harpe > 0.05 ? 0.02 : 0.13) * Math.sin(t * 2.1 - i * 0.6 + k * 1.9) * (1 - harpe) + s.curl * 0.3 * side * q;
            const tx = X[i - 1] + Math.cos(a) * sg, ty = Y[i - 1] + Math.sin(a) * sg;
            const kf = Math.min(1, h * ((harpe > 0.05 ? 22 : 13) - 10 * q));
            X[i] += (tx - X[i]) * kf; Y[i] += (ty - Y[i]) * kf;
            const ex = X[i] - X[i - 1], ey = Y[i] - Y[i - 1], l = sg / (Math.hypot(ex, ey) || 1);
            X[i] = X[i - 1] + ex * l; Y[i] = Y[i - 1] + ey * l;
          }
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.4 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 4; an.vie -= h / 1.5;
        }
        s.cph += h * (6 + 5 * energy + 8 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const sx = s.sx, sy = s.sy, e = s.e, G = degr(ctx);
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de sillage (petits tores de profil)
        ctx.strokeStyle = coul.perle; ctx.beginPath();
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const sn = Math.sin(an.a), cs = Math.cos(an.a);
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x - sn * an.r * sg, qy = an.y + cs * an.r * sg, rr = 1 + (1 - an.vie) * 1.6, a0 = an.a + (1 - an.vie) * 8 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.2);
          }
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.6; ctx.stroke();
        // 2. Tentacules : fil + tentilles (crochets perlés), plus denses vers le bout
        ctx.beginPath();
        for (let k = 0; k < NC; k++) {
          const X = s.tex[k], Y = s.tey[k]; ctx.moveTo(X[0], Y[0]);
          for (let i = 1; i < NTP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
          ctx.lineTo(X[NTP - 1], Y[NTP - 1]);
        }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 4; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        const perles = [];
        for (let k = 0; k < NC; k++) {
          const X = s.tex[k], Y = s.tey[k];
          for (let i = 2; i < NTP - 1; i++) {
            let tx = X[i + 1] - X[i - 1], ty = Y[i + 1] - Y[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
            const sd = i % 2 ? 1 : -1, L = (2.2 + 1.6 * i / NTP) * (1 + 0.3 * Math.sin(s.cph * 0.7 - i + k)) * e;
            const ex = X[i] - ty * sd * L - tx * L * 0.5, ey = Y[i] + tx * sd * L - ty * L * 0.5;
            ctx.moveTo(X[i], Y[i]); ctx.quadraticCurveTo(X[i] - ty * sd * L * 0.8, Y[i] + tx * sd * L * 0.8, ex, ey);
            perles.push(ex, ey);
          }
        }
        ctx.globalAlpha = A * 0.26; ctx.lineWidth = 0.45; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < perles.length; k += 2) { ctx.moveTo(perles[k] + 0.75, perles[k + 1]); ctx.arc(perles[k], perles[k + 1], 0.75, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.fill();
        // 3. Tige : épaisse et annelée dans le nectosome, fil perlé ensuite
        ctx.beginPath(); ctx.moveTo(sx[0], sy[0]);
        for (let i = 1; i < NS - 1; i++) ctx.quadraticCurveTo(sx[i], sy[i], (sx[i] + sx[i + 1]) / 2, (sy[i] + sy[i + 1]) / 2);
        ctx.lineTo(sx[NS - 1], sy[NS - 1]);
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.08; ctx.lineWidth = 5; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.75; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(sx[0], sy[0]); for (let i = 1; i < 14; i++) ctx.lineTo(sx[i], sy[i]);
        ctx.globalAlpha = A * 0.22; ctx.lineWidth = 2.4; ctx.stroke();
        ctx.beginPath();
        for (let i = 14; i < NS; i += 2) { const rr = 0.9 * (1 - (i - 14) / NS); ctx.moveTo(sx[i] + rr, sy[i]); ctx.arc(sx[i], sy[i], rr, 0, TAU); }
        ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.fill();
        // 4. Polypes pêcheurs (petites Cellules en goutte) : pédoncule, corps, bouche ciliée
        for (let k = 0; k < NC; k++) {
          const j = CORM[k], pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
          ctx.beginPath(); ctx.moveTo(sx[j], sy[j]); ctx.lineTo(sx[j] + pc * 3 * e, sy[j] + ps * 3 * e);
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
          const cx = sx[j] + pc * 6.5 * e, cy = sy[j] + ps * 6.5 * e, gonf = 1 + 0.12 * Math.sin(t * 1.4 + k * 2);
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(s.pa[k]);
          ctx.beginPath(); ctx.moveTo(-3.5 * e, 0); ctx.bezierCurveTo(-3.5 * e, -3.6 * e * gonf, 3.6 * e, -2.8 * e * gonf, 4.4 * e, 0);
          ctx.bezierCurveTo(3.6 * e, 2.8 * e * gonf, -3.5 * e, 3.6 * e * gonf, -3.5 * e, 0);
          ctx.save(); ctx.scale(4.4 * e, 3.4 * e); ctx.fillStyle = G.cloche; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.7; ctx.stroke();
          ctx.beginPath(); ctx.arc(-0.6 * e, 0, 1.2 * e, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
          ctx.strokeStyle = s.gobe > 0.01 ? coul.mauve : coul.perle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 0.5; ctx.stroke();
          ctx.beginPath();
          for (let m = 0; m < 5; m++) { const q = (m / 4 - 0.5) * 1.6, L = (1.6 + 0.9 * Math.sin(s.cph * 1.3 - m)) * e; ctx.moveTo(4.4 * e, 0); ctx.lineTo(4.4 * e + Math.cos(q) * L, Math.sin(q) * L); }
          ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.restore();
        }
        // 5. Nectosome : six cloches en fermeture éclair (arrière d'abord pour le recouvrement)
        for (let i = NB - 1; i >= 0; i--) {
          const j = ATT[i], side = i % 2 ? 1 : -1, c = s.c[i], am = s.amp[i];
          const ta = angTige(j) + side * (0.32 + 0.12 * c) + s.bend * 0.3;
          const a = 8.6 * e * (1 + 0.16 * c), b = 6.1 * e * (1 - 0.24 * c) * (0.92 + 0.08 * am), ro = b * (0.66 - 0.34 * c);
          profil(a, b, ro, c, t * 2.4 + i);
          ctx.save(); ctx.translate(sx[j] + nxs[j] * side * 6.4 * e, sy[j] + nys[j] * side * 6.4 * e); ctx.rotate(ta);
          ctx.beginPath(); cheminCloche(ctx, 1); ctx.quadraticCurveTo(bx[NBS - 1] + a * 0.3, 0, bx[NBS - 1], -bw[NBS - 1]);
          ctx.save(); ctx.scale(a, b); ctx.fillStyle = G.cloche; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 3.5; ctx.stroke();
          ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.75; ctx.stroke();
          // sous-ombrelle
          ctx.beginPath(); for (let k2 = NBS - 1; k2 >= 3; k2--) ctx.lineTo(bx[k2], -0.7 * bw[k2]); for (let k2 = 3; k2 < NBS; k2++) ctx.lineTo(bx[k2], 0.7 * bw[k2]);
          ctx.globalAlpha = A * 0.16; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (0.32 + 0.14 * c); ctx.fill();
          ctx.beginPath(); ctx.ellipse(bx[NBS - 1] + 0.6, 0, 1.4 + a * 0.12 * (1 - c), bw[NBS - 1], 0, 0, TAU); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.6; ctx.stroke();
          // vacuole étoilée miniature : pleine au relâchement
          const plein = 1 - c, vx0 = bx[2], rv = (0.8 + 1.3 * plein) * e;
          ctx.beginPath();
          for (let k2 = 0; k2 < 5; k2++) { const q = k2 / 5 * TAU + i, L = (1.8 + 3.2 * plein) * e; ctx.moveTo(vx0 + Math.cos(q) * rv, Math.sin(q) * rv); ctx.lineTo(vx0 + Math.cos(q + 0.3 * (0.5 - plein)) * (rv + L), Math.sin(q + 0.3 * (0.5 - plein)) * (rv + L)); }
          ctx.globalAlpha = A * 0.35; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.beginPath(); ctx.arc(vx0, 0, rv, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.fill(); ctx.globalAlpha = A * 0.55; ctx.lineWidth = 0.55; ctx.stroke();
          // frange du vélum + cils couchés par la poussée
          const xr = bx[NBS - 1];
          ctx.beginPath();
          for (let k2 = 0; k2 <= 5; k2++) { const u = k2 / 5 - 0.5, y0 = u * 2 * bw[NBS - 1], L = (2.4 + 1.6 * s.gon + 1.2 * Math.sin(s.cph * 1.3 - k2 + i)) * e; ctx.moveTo(xr, y0); ctx.lineTo(xr - L, y0 + u * L * (1.2 - c)); }
          for (let sd = -1; sd <= 1; sd += 2) for (let k2 = 1; k2 < NBS - 1; k2++) {
            const ph = s.cph - k2 * 0.6 + i * 1.3, L = (1.1 + 0.7 * Math.sin(ph)) * e;
            ctx.moveTo(bx[k2], sd * bw[k2]); ctx.lineTo(bx[k2] - L * (0.4 + 0.5 * c), sd * (bw[k2] + L));
          }
          ctx.globalAlpha = A * 0.28; ctx.lineWidth = 0.45; ctx.stroke();
          // éclair de contraction (très doux) : on lit la salve qui court
          const fl = A * P.alpha.biolum * s.flash[i] * s.flash[i];
          if (fl > 0.004) {
            ctx.globalCompositeOperation = 'lighter'; ctx.beginPath(); cheminCloche(ctx, 1);
            ctx.strokeStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = fl * 0.45; ctx.lineWidth = 0.7; ctx.stroke();
            ctx.globalCompositeOperation = 'source-over';
          }
          ctx.restore();
        }
        // 6. Flotteur (pneumatophore) : bulle nacrée, pore apical, crête ciliée
        {
          const ca = s.ang, pr = 1 + 0.06 * Math.sin(t * 1.1 + s.ph0);
          ctx.save(); ctx.translate(sx[0] + Math.cos(ca) * 3, sy[0] + Math.sin(ca) * 3); ctx.rotate(ca);
          ctx.beginPath(); ctx.arc(0, 0, 13 * e, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = A * 0.05; ctx.fill();
          ctx.beginPath(); ctx.ellipse(0, 0, 8.4 * e * pr, 5.6 * e, 0, 0, TAU);
          ctx.save(); ctx.scale(8.4 * e, 5.6 * e); ctx.fillStyle = G.flot; ctx.globalAlpha = A; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.65; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(-0.8, 0, 6.2 * e * pr, 3.8 * e, 0, 0, TAU); ctx.globalAlpha = A * 0.2; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath(); ctx.arc(7.6 * e, 0, 1, 0, TAU); ctx.fillStyle = coul.perle; ctx.globalAlpha = A * 0.7; ctx.fill();
          ctx.beginPath();
          for (let k = 0; k < 11; k++) { const x0 = (k / 10 - 0.5) * 12 * e, y0 = -5.4 * e * Math.sqrt(Math.max(0, 1 - Math.pow(x0 / (8.5 * e), 2))), L = (2.2 + 1.2 * Math.sin(s.cph * 1.1 - k * 0.7)) * e; ctx.moveTo(x0, y0); ctx.lineTo(x0 - L * 0.5, y0 - L); }
          ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.45; ctx.stroke();
          ctx.beginPath(); ctx.arc(-1.6 * e, -1.4 * e, 1.3, 0, TAU); ctx.globalAlpha = A * 0.5; ctx.fill();
          ctx.restore();
        }
        // 7. Lumières : l'impulsion descend la tige du flotteur vers les polypes ; gobage mauve
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const cc = s.lueur.pos * (NS + 4) - 2;
          ctx.strokeStyle = ctx.fillStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NS - 1; i++) {
            const li = I * cloche(i + 0.5 - cc, i + 0.5 < cc ? 4 : 1.4); if (li < 0.004) continue;
            ctx.beginPath(); ctx.moveTo(sx[i], sy[i]); ctx.lineTo(sx[i + 1], sy[i + 1]);
            ctx.globalAlpha = li * 0.14; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = li * 0.75; ctx.lineWidth = 1; ctx.stroke();
          }
          for (let k = 0; k < NC; k++) {
            const li = I * cloche(cc - CORM[k], 2.5); if (li < 0.004) continue;
            const X = s.tex[k], Y = s.tey[k]; ctx.beginPath(); ctx.moveTo(X[0], Y[0]); for (let i = 1; i < NTP; i++) ctx.lineTo(X[i], Y[i]);
            ctx.globalAlpha = li * 0.5; ctx.lineWidth = 0.8; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          for (let k = 0; k < NC; k++) {
            const j = CORM[k], gk = s.gobe * cloche(1 - s.gobe - k * 0.12, 0.5), pc = Math.cos(s.pa[k]), ps = Math.sin(s.pa[k]);
            const cx = sx[j] + pc * 6 * e, cy = sy[j] + ps * 6 * e;
            ctx.beginPath(); ctx.arc(cx, cy, 3 + 6 * gk, 0, TAU); ctx.globalAlpha = A * 0.25 * gk; ctx.fill();
            ctx.beginPath(); ctx.arc(cx, cy, 1 + 1.4 * gk, 0, TAU); ctx.globalAlpha = A * 0.95 * gk; ctx.fill();
          }
          const cg = (1 - s.gobe) * (NS + 4);
          ctx.strokeStyle = coul.mauve;
          for (let i = 0; i < NS - 1; i++) { const li = A * s.gobe * cloche(i - cg, 3); if (li < 0.01) continue; ctx.beginPath(); ctx.moveTo(sx[i], sy[i]); ctx.lineTo(sx[i + 1], sy[i + 1]); ctx.globalAlpha = li * 0.6; ctx.lineWidth = 1.4; ctx.stroke(); }
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     7. VOLTE — cloche gyroscopique à fronde (étage 3 : Culbute × Systole)
     Une vraie cloche 3D (de révolution, ovale) dont l'axe est l'axe intermédiaire d'inertie :
     elle culbute comme la Culbute (Djanibekov). La vacuole étoilée se charge pendant qu'elle
     tourne ; elle ne tire son jet que lorsque l'axe instable passe dans la bonne direction —
     une fronde à visée par le temps. Le jet part selon l'axe 3D : vu de face, il ne la déplace
     pas. La trompe de la Culbute devient un manubrium qui sort de la cloche (col harponneur).
     ===================================================================== */
  function creerVolte() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NM = 14, NU = 7, NT = 8, NTP = 13, NMN = 10, NR = 3, NRIM = 28, OZ = 0.82;
    const NPT = NM * NU + 1;
    const CR = corpsRigide(1, 1.55, 2.05), R = CR.R, pj = CR.pj, w = CR.w;
    const PX = new Float32Array(NPT), PY = new Float32Array(NPT), PZ = new Float32Array(NM * NU);
    const prR = new Float32Array(NU), prY = new Float32Array(NU), nR = new Float32Array(NU), nY = new Float32Array(NU);
    const RX = new Float32Array(NRIM), RY = new Float32Array(NRIM), RZ = new Float32Array(NRIM);
    const idx = new Int16Array(NPT), hull = new Int16Array(NPT + 2);
    const MX = new Float32Array(NMN), MY = new Float32Array(NMN), MZ = new Float32Array(NMN);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const g = ctx.createRadialGradient(-0.3, -0.35, 0, 0, 0, 1);
      g.addColorStop(0, rgba(P.perle, 0.2)); g.addColorStop(0.45, rgba(P.sarcelle, 0.22));
      g.addColorStop(0.8, rgba(P.aqua, 0.22)); g.addColorStop(0.96, rgba(P.perle, 0.34)); g.addColorStop(1, rgba(P.perle, 0.08));
      return g;
    });
    // Profil d'un tir : fermeture brusque, réouverture avec dépassement (la cloche s'évase)
    const tir = f => { if (f < 0.2) return 0.5 - 0.5 * Math.cos(Math.PI * f / 0.2); const x = (f - 0.2) / 0.8, c = (1 - x) * Math.cos(Math.PI * x * 1.5); return c < 0 ? c * 0.45 : c; };
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    function forme() {
      const e = s.e, c = s.c, sw = lisseP(borne(s.q, 0, 1));
      s.Rb = 19 * e * (1 - 0.3 * c + 0.1 * sw + 0.14 * s.gon);
      s.Hb = 23 * e * (1 + 0.24 * c - 0.05 * sw - 0.08 * s.gon);
      for (let j = 0; j < NU; j++) {
        const u = 0.06 + 0.94 * j / (NU - 1);
        prR[j] = s.Rb * Math.pow(Math.sin(Math.PI / 2 * u), 0.72) * (1 + (u > 0.8 ? 0.12 * (u - 0.8) / 0.2 * (1 - c) : 0));
        prY[j] = s.Hb * (0.55 - Math.pow(u, 1.2));
      }
      for (let j = 0; j < NU; j++) {
        const a = Math.max(0, j - 1), b = Math.min(NU - 1, j + 1), dr = prR[b] - prR[a], dy = prY[b] - prY[a], l = 1 / (Math.hypot(dr, dy) || 1);
        nR[j] = -dy * l; nY[j] = dr * l;
      }
    }
    function projeterTout() {
      for (let m = 0; m < NM; m++) {
        const ph = m / NM * TAU + s.rotM, cp = Math.cos(ph), sp = Math.sin(ph) * OZ;
        for (let j = 0; j < NU; j++) {
          const k = m * NU + j; CR.proj(prR[j] * cp, prY[j], prR[j] * sp);
          PX[k] = s.x + pj[0]; PY[k] = s.y + pj[1];
          PZ[k] = R[6] * nR[j] * cp + R[7] * nY[j] + R[8] * nR[j] * sp;   // z de la normale : face avant > 0
        }
      }
      CR.proj(0, s.Hb * 0.58, 0); PX[NPT - 1] = s.x + pj[0]; PY[NPT - 1] = s.y + pj[1];
      const rr = prR[NU - 1], yr = prY[NU - 1];
      for (let k = 0; k < NRIM; k++) { const ph = k / NRIM * TAU + s.rotM; CR.proj(rr * Math.cos(ph), yr, rr * Math.sin(ph) * OZ); RX[k] = s.x + pj[0]; RY[k] = s.y + pj[1]; RZ[k] = pj[2]; }
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0x701e);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.66 : 0.34), hy = H * (sl0 ? 0.64 : 0.36);
        CR.init(r() * TAU, 0.6 + r() * 0.6);
        w[0] = 0.06; w[1] = 3 + r(); w[2] = 0.05;
        s = { hx, hy, x: hx + (r() - 0.5) * 60, y: hy + (r() - 0.5) * 60, vx: 0, vy: 0, ph: r() * TAU, e: 1 + 0.1 * r(),
          q: r() * 0.6, fire: 0, qf: 0, c: 0, cp: 0, gon: 0, ecart: 1, harp: 0, exc: 0, gobe: 0, cph: 0, rotM: 0, flash: 0, Rb: 19, Hb: 23,
          lueur: lueurNeuve(r), g: 0, gx: 0, gy: 0, tex: [], tey: [], anneaux: [], ri: 0, thr: 0.8, qr: 1, spin: 3, kA: 0, kD: 0, kick: 0.1 };
        forme();
        for (let k = 0; k < NT; k++) { const X = new Float32Array(NTP), Y = new Float32Array(NTP); for (let i = 0; i < NTP; i++) { X[i] = s.x; Y[i] = s.y + i * 4; } s.tex.push(X); s.tey.push(Y); }
        for (let k = 0; k < NR; k++) s.anneaux.push({ x: 0, y: 0, vx: 0, vy: 0, ax: 0, ay: 0, az: 1, r: 0, vie: 0 });
        for (let i = 0; i < NMN; i++) { CR.proj(0, s.Hb * 0.4 - i * 3, 0); MX[i] = s.x + pj[0]; MY[i] = s.y + pj[1]; MZ[i] = pj[2]; }
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 24 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 180) - s.exc) * Math.min(1, h * 2.5));
        // [spin, kA, kD, kick, seuil d'alignement, vitesse de charge, écart des tentacules, gonflement, harpon]
        let m = [(1.5 + 1.8 * energy) * (0.6 + 0.4 * RG.vit), s.g ? 2.2 * s.g : 0, s.g ? 1 : 0, 0.1, 0.82, 1, 1, 0, 0];
        if (e > 0.01) {
          let b;
          if (md === 'cont') b = [1.1, 4, 2.2, 0.02, 0.9, 0.5, 1.7, 1, 0];
          else if (md === 'actif') b = [6.5, 0.4, 0, 0.8, 0.5, 1.7, 1.1, 0.3, 0];
          else if (md === 'agr') b = [1.6, 8, 2.6, 0.02, 0.62, 1.9, 0.45, 0, 1];
          else if (md === 'suit') b = [2, 3.5, 1.6, 0.04, 0.75, 1, 1, 0.4, 0];
          else if (md === 'evite') b = [7, 4, 0.4, 0.9, 0.3, 2.3, 0.35, 0, 0];
          else b = [3.5, 3, 1, 0.1, 0.7, 1.1, 1.25, 0.5, 0];
          for (let k = 0; k < 9; k++) m[k] = melange(m[k], b[k], e);
        }
        const kk = Math.min(1, h * 2);
        s.spin += (m[0] - s.spin) * kk; s.kA += (m[1] - s.kA) * kk; s.kD += (m[2] - s.kD) * kk; s.kick += (m[3] - s.kick) * kk;
        s.thr += (m[4] - s.thr) * kk; s.qr += (m[5] - s.qr) * kk; s.ecart += (m[6] - s.ecart) * kk; s.gon += (m[7] - s.gon) * kk; s.harp += (m[8] - s.harp) * kk;
        // Direction voulue (cible, ou errance autour de son coin)
        let Dx, Dy;
        if (s.g) { Dx = s.gx - s.x; Dy = s.gy - s.y; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 150), a = Math.atan2(ecY, ecX) * loin + (1 - loin) * (t * 0.13 + s.ph); Dx = Math.cos(a); Dy = Math.sin(a); }
        const Dl = Math.hypot(Dx, Dy) || 1; Dx /= Dl; Dy /= Dl;
        // Corps rigide : moteur ciliaire + visée de l'axe (e2) ; pendant un tir, le jet stabilise un peu
        CR.tau[0] = CR.tau[1] = CR.tau[2] = 0;
        if (s.kA > 0.05) CR.viser(1, Dx, Dy, 0.15, s.kA, s.kD);
        CR.moteur(s.spin * (s.fire > 0 ? 0.6 : 1), s.kick, t, s.ph);
        CR.avancer(h);
        // Charge de la vacuole puis tir quand l'axe instable passe dans la bonne direction
        const ax = R[1], ay = R[4], lp = Math.hypot(ax, ay), align = (ax * Dx + ay * Dy) / (lp || 1);
        if (s.fire <= 0) {
          s.q += h * (0.3 + 0.45 * energy) * s.qr;
          if ((s.q >= 0.55 && align > s.thr && lp > 0.5) || s.q >= 1.8) {
            s.fire = 1e-4; s.qf = Math.min(1.3, s.q); s.q = 0; s.flash = 1;
            const an = s.anneaux[s.ri++ % NR]; CR.proj(0, prY[NU - 1], 0);
            an.x = s.x + pj[0]; an.y = s.y + pj[1]; an.ax = R[1]; an.ay = R[4]; an.az = R[7];
            an.vx = -R[1] * 30 + s.vx * 0.1; an.vy = -R[4] * 30 + s.vy * 0.1; an.r = prR[NU - 1] * 0.95; an.vie = 1;
          }
        } else { s.fire += h / 0.6; if (s.fire >= 1) s.fire = 0; }
        s.cp = s.c; s.c = s.fire > 0 ? tir(s.fire) : 0;
        const dc = (s.c - s.cp) / h;
        const pousse = (dc > 0 ? dc * 30 * s.qf : 0) * s.e * (0.8 + 0.35 * energy) * (0.6 + 0.4 * RG.vit);
        const fr = Math.exp(-1.5 * h);
        s.vx = s.vx * fr + ax * pousse * h; s.vy = s.vy * fr + ay * pousse * h;
        const fl = flow(s.x, s.y);
        const nx = s.x + (s.vx + fl[0] * 0.4) * h, ny = s.y + (s.vy + fl[1] * 0.4) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) {
          for (let k = 0; k < NT; k++) for (let i = 0; i < NTP; i++) { s.tex[k][i] += jx; s.tey[k][i] += jy; }
          for (let i = 0; i < NMN; i++) { MX[i] += jx; MY[i] += jy; }
          for (const an of s.anneaux) { an.x += jx; an.y += jy; }
        }
        s.rotM += h * 0.25;
        forme(); projeterTout();
        // Tentacules du bord : traînent derrière l'axe, s'écartent quand la cloche est vue de face,
        // se plaquent au tir (suivi), s'étalent en curiosité
        const bx2 = -ax, by2 = -ay;
        for (let k = 0; k < NT; k++) {
          const ri = Math.round(k / NT * NRIM) % NRIM, X = s.tex[k], Y = s.tey[k];
          X[0] = RX[ri]; Y[0] = RY[ri];
          let rx = RX[ri] - s.x, ry = RY[ri] - s.y; const rl2 = 1 / (Math.hypot(rx, ry) || 1); rx *= rl2; ry *= rl2;
          const wr = (0.35 * s.ecart + 0.55 * (1 - lp)) * (1 - 0.75 * Math.max(0, s.c));
          const a0 = Math.atan2(by2 * 1.3 + ry * wr, bx2 * 1.3 + rx * wr), sg = 4.9 * s.e * (1 + 0.2 * s.gon);
          let a = a0;
          for (let i = 1; i < NTP; i++) {
            const q = i / (NTP - 1);
            a += 0.11 * Math.sin(t * 2.3 - i * 0.55 + k * 0.9) + 0.03 * (k % 2 ? 1 : -1);
            const tx = X[i - 1] + Math.cos(a) * sg, ty = Y[i - 1] + Math.sin(a) * sg, kf = Math.min(1, h * (14 - 11.5 * q));
            X[i] += (tx - X[i]) * kf; Y[i] += (ty - Y[i]) * kf;
            const ex = X[i] - X[i - 1], ey = Y[i] - Y[i - 1], l = sg / (Math.hypot(ex, ey) || 1);
            X[i] = X[i - 1] + ex * l; Y[i] = Y[i - 1] + ey * l;
          }
        }
        // Manubrium (trompe) : pend de l'apex, sort par l'ouverture ; harpon vers la particule
        let prox = 0;
        if (RG.part && RG.part.on && s.harp > 0.05) prox = s.harp * borne(1.5 - Math.hypot(RG.part.x - s.x, RG.part.y - s.y) / 90, 0, 1);
        s.ext = (s.ext || 1) + ((1 + 1.4 * prox) - (s.ext || 1)) * Math.min(1, h * 4);
        const Lm = s.Hb * 1.15 * s.ext, sgm = Lm / (NMN - 1);
        for (let i = 0; i < NMN; i++) {
          const q = i / (NMN - 1), am = 2.2 * q * (1 - prox);
          CR.proj(am * Math.sin(t * 1.9 - i * 0.7), s.Hb * 0.4 - i * sgm, am * Math.cos(t * 1.6 - i * 0.6));
          let wx = s.x + pj[0], wy = s.y + pj[1];
          if (prox > 0.05 && i > 2) { const k2 = prox * (q - 0.2); wx += (RG.part.x - wx) * k2 * 0.6; wy += (RG.part.y - wy) * k2 * 0.6; }
          if (i === 0) { MX[0] = wx; MY[0] = wy; MZ[0] = pj[2]; continue; }
          const kf = Math.min(1, h * (30 - 24 * q));
          MX[i] += (wx - MX[i]) * kf; MY[i] += (wy - MY[i]) * kf; MZ[i] += (pj[2] - MZ[i]) * kf;
          const ex = MX[i] - MX[i - 1], ey = MY[i] - MY[i - 1], l = Math.hypot(ex, ey) || 1;
          if (l > sgm) { MX[i] = MX[i - 1] + ex / l * sgm; MY[i] = MY[i - 1] + ey / l * sgm; }
        }
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const k = Math.exp(-2.2 * h);
          an.x += an.vx * h; an.y += an.vy * h; an.vx *= k; an.vy *= k; an.r += h * 6; an.vie -= h / 1.8;
        }
        s.flash = Math.max(0, s.flash - h * 1.8);
        s.cph += h * (7 + 8 * energy + 12 * e + 10 * Math.max(0, dc) * 0.1);
        s.gobe = Math.max(0, s.gobe - h * 0.32);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const e = s.e, ouvVue = R[7] < 0;          // l'ouverture regarde l'observateur
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Anneaux de jet : vrais cercles 3D projetés + deux volutes
        for (const an of s.anneaux) {
          if (an.vie <= 0) continue;
          const v = an.vie, rot = Math.atan2(an.ay, an.ax) + Math.PI / 2, mi = Math.max(1, an.r * Math.abs(an.az));
          ctx.beginPath(); ctx.ellipse(an.x, an.y, an.r, mi, rot, 0, TAU);
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32 * v * v; ctx.lineWidth = 0.8; ctx.stroke();
          ctx.beginPath();
          for (let sg = -1; sg <= 1; sg += 2) {
            const qx = an.x + Math.cos(rot) * an.r * sg, qy = an.y + Math.sin(rot) * an.r * sg, rr = 1.6 + (1 - v) * 2.4, a0 = rot + (1 - v) * 9 * sg;
            ctx.moveTo(qx + Math.cos(a0) * rr, qy + Math.sin(a0) * rr); ctx.arc(qx, qy, rr, a0, a0 + 4.4);
          }
          ctx.globalAlpha = A * 0.45 * v; ctx.lineWidth = 0.7; ctx.stroke();
        }
        const tentacules = (Aa) => {
          ctx.beginPath();
          for (let k = 0; k < NT; k++) {
            const X = s.tex[k], Y = s.tey[k]; ctx.moveTo(X[0], Y[0]);
            for (let i = 1; i < NTP - 1; i++) ctx.quadraticCurveTo(X[i], Y[i], (X[i] + X[i + 1]) / 2, (Y[i] + Y[i + 1]) / 2);
            ctx.lineTo(X[NTP - 1], Y[NTP - 1]);
          }
          ctx.strokeStyle = coul.aqua; ctx.globalAlpha = Aa * 0.07; ctx.lineWidth = 4.5; ctx.stroke();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Aa * 0.42; ctx.lineWidth = 0.7; ctx.stroke();
          ctx.beginPath();
          for (let k = 0; k < NT; k++) for (let i = 3; i < NTP; i += 3) { const rr = 0.9 * (1 - i / NTP * 0.5); ctx.moveTo(s.tex[k][i] + rr, s.tey[k][i]); ctx.arc(s.tex[k][i], s.tey[k][i], rr, 0, TAU); }
          ctx.fillStyle = coul.perle; ctx.globalAlpha = Aa * 0.4; ctx.fill();
        };
        if (!ouvVue) tentacules(A);
        // 2. Silhouette : enveloppe convexe des points de la cloche
        const nh = enveloppeConvexe(PX, PY, NPT, idx, hull);
        let cx = 0, cy = 0; for (let k = 0; k < nh; k++) { cx += PX[hull[k]]; cy += PY[hull[k]]; } cx /= nh; cy /= nh;
        let rmax = 1; for (let k = 0; k < nh; k++) rmax = Math.max(rmax, Math.hypot(PX[hull[k]] - cx, PY[hull[k]] - cy));
        ctx.beginPath(); ctx.moveTo(PX[hull[0]], PY[hull[0]]);
        for (let k = 1; k <= nh; k++) { const a = hull[k % nh], b = hull[(k + 1) % nh]; ctx.quadraticCurveTo(PX[a], PY[a], (PX[a] + PX[b]) / 2, (PY[a] + PY[b]) / 2); }
        ctx.closePath();
        ctx.save(); ctx.translate(cx, cy); ctx.scale(rmax, rmax); ctx.fillStyle = degr(ctx); ctx.globalAlpha = A; ctx.fill(); ctx.restore();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 5; ctx.stroke();
        ctx.globalAlpha = A * 0.42; ctx.lineWidth = 0.85; ctx.stroke();
        // 3. Méridiens (kinéties) et parallèles : arrière pâles, avant nets
        const reseau = (devant) => {
          ctx.beginPath();
          for (let m = 0; m < NM; m++) for (let j = 0; j < NU - 1; j++) {
            const k = m * NU + j; if ((PZ[k] + PZ[k + 1] >= 0) !== devant) continue;
            ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k + 1], PY[k + 1]);
          }
          for (let j = 3; j < 4; j++) for (let m = 0; m < NM; m++) {
            const k = m * NU + j, k2 = ((m + 1) % NM) * NU + j; if ((PZ[k] + PZ[k2] >= 0) !== devant) continue;
            ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k2], PY[k2]);
          }
        };
        reseau(false); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.05; ctx.lineWidth = 0.5; ctx.stroke();
        // 4. Ouverture : voile sombre et vélum, plus visibles quand elle nous regarde
        ctx.beginPath(); for (let k = 0; k <= NRIM; k++) { const i = k % NRIM; k ? ctx.lineTo(RX[i], RY[i]) : ctx.moveTo(RX[i], RY[i]); }
        ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * (ouvVue ? 0.38 : 0.12) * Math.min(1, Math.abs(R[7]) * 2 + 0.2); ctx.fill();
        // 5. Manubrium (vu à travers la mésoglée), lèvres buccales
        ctx.beginPath(); ctx.moveTo(MX[0], MY[0]);
        for (let i = 1; i < NMN - 1; i++) ctx.quadraticCurveTo(MX[i], MY[i], (MX[i] + MX[i + 1]) / 2, (MY[i] + MY[i + 1]) / 2);
        ctx.lineTo(MX[NMN - 1], MY[NMN - 1]);
        ctx.strokeStyle = coul.sarcelle; ctx.globalAlpha = A * 0.5; ctx.lineWidth = 4.2 * e; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.32; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath();
        for (let i = 2; i < NMN - 1; i += 2) { let tx = MX[i + 1] - MX[i - 1], ty = MY[i + 1] - MY[i - 1]; const l = 1 / (Math.hypot(tx, ty) || 1), k = 2 * e; ctx.moveTo(MX[i] - ty * l * k, MY[i] + tx * l * k); ctx.lineTo(MX[i] + ty * l * k, MY[i] - tx * l * k); }
        ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.5; ctx.stroke();
        {
          const ex = MX[NMN - 1], ey = MY[NMN - 1], ta = Math.atan2(ey - MY[NMN - 3], ex - MX[NMN - 3]);
          ctx.beginPath();
          for (let k = 0; k < 4; k++) {
            const q = ta + (k - 1.5) * 0.7, L = (4 + 1.5 * Math.sin(s.cph * 0.8 + k)) * e * (1 + 0.5 * s.harp);
            ctx.moveTo(ex, ey); ctx.quadraticCurveTo(ex + Math.cos(q) * L, ey + Math.sin(q) * L, ex + Math.cos(q + 0.9) * L * 1.1, ey + Math.sin(q + 0.9) * L * 1.1);
          }
          ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // 6. Vacuole étoilée à l'apex, tracée SUR le dôme (canaux le long des méridiens)
        const plein = borne(s.q, 0, 1) * (1 - Math.max(0, s.c)), u0 = 0.18, rr0 = s.Rb * 0.18 * (0.6 + 0.6 * plein);
        CR.proj(0, s.Hb * 0.36, 0); const vx0 = s.x + pj[0], vy0 = s.y + pj[1];
        ctx.beginPath();
        for (let k = 0; k < 7; k++) {
          const ph = k / 7 * TAU + s.ph + s.rotM, Lr = 0.12 + 0.42 * plein;
          let x0, y0;
          for (let st = 0; st <= 3; st++) {
            const u = u0 + Lr * st / 3, rr = s.Rb * Math.pow(Math.sin(Math.PI / 2 * u), 0.72) * 0.9, yy = s.Hb * (0.55 - Math.pow(u, 1.2)) - 1.5, tw = 0.25 * (0.5 - plein) * st / 3;
            CR.proj(rr * Math.cos(ph + tw), yy, rr * Math.sin(ph + tw) * OZ);
            const X = s.x + pj[0], Y = s.y + pj[1];
            if (st === 0) { ctx.moveTo(X, Y); x0 = X; y0 = Y; } else ctx.lineTo(X, Y);
          }
        }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = 2.4; ctx.stroke();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.4; ctx.lineWidth = 0.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(vx0, vy0, rr0 + 1, 0, TAU); ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.35; ctx.fill();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.6; ctx.lineWidth = 0.8; ctx.stroke();
        // 7. Réseau avant + bord épais (vélum) + peigne de cils au bord
        reseau(true); ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.15; ctx.lineWidth = 0.5; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < NRIM; k++) { const k2 = (k + 1) % NRIM; if (RZ[k] + RZ[k2] < 0) continue; ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k2], RY[k2]); }
        ctx.globalAlpha = A * 0.08; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.6; ctx.lineWidth = 1.1; ctx.stroke();
        ctx.beginPath(); for (let k = 0; k < NRIM; k++) { const k2 = (k + 1) % NRIM; if (RZ[k] + RZ[k2] >= 0) continue; ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k2], RY[k2]); }
        ctx.globalAlpha = A * 0.25; ctx.lineWidth = 0.8; ctx.stroke();
        ctx.beginPath();
        const bxv = -R[1], byv = -R[4];
        for (let k = 0; k < NRIM; k++) {
          let rx = RX[k] - s.x, ry = RY[k] - s.y; const l = 1 / (Math.hypot(rx, ry) || 1); rx *= l; ry *= l;
          const ph = s.cph - k * 0.65, L = (2.4 + 1.3 * Math.sin(ph)) * e * (1 + 0.4 * s.exc);
          ctx.moveTo(RX[k], RY[k]); ctx.lineTo(RX[k] + (rx * 0.7 + bxv * 0.6) * L + Math.cos(ph) * 0.6, RY[k] + (ry * 0.7 + byv * 0.6) * L + Math.sin(ph) * 0.6);
        }
        ctx.globalAlpha = A * 0.3; ctx.lineWidth = 0.45; ctx.stroke();
        // Reflet spéculaire
        {
          const hx = -0.25, hy = -0.4, hz = 0.88, n0 = R[0] * hx + R[3] * hy + R[6] * hz, n1 = R[1] * hx + R[4] * hy + R[7] * hz, n2 = R[2] * hx + R[5] * hy + R[8] * hz;
          if (n1 > -0.2) { const ph = Math.atan2(n2, n0); CR.proj(s.Rb * 0.6 * Math.cos(ph), s.Hb * (0.3 + 0.2 * n1), s.Rb * 0.6 * Math.sin(ph) * OZ);
            ctx.fillStyle = coul.perle; ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 5, 0, TAU); ctx.globalAlpha = A * 0.06; ctx.fill();
            ctx.beginPath(); ctx.arc(s.x + pj[0], s.y + pj[1], 1.4, 0, TAU); ctx.globalAlpha = A * 0.4; ctx.fill(); }
        }
        if (ouvVue) tentacules(A);
        // 8. Lumières : le bord s'allume au tir ; impulsion apex → bord → tentacules ; gobage mauve
        ctx.globalCompositeOperation = 'lighter';
        const fl = A * P.alpha.biolum * s.flash;
        if (fl > 0.004) {
          ctx.beginPath(); for (let k = 0; k <= NRIM; k++) { const i = k % NRIM; k ? ctx.lineTo(RX[i], RY[i]) : ctx.moveTo(RX[i], RY[i]); }
          ctx.strokeStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = fl * 0.5; ctx.lineWidth = 0.9; ctx.stroke();
          ctx.beginPath(); ctx.arc(vx0, vy0, rr0 * 3, 0, TAU); ctx.fillStyle = coul.lueur; ctx.globalAlpha = fl * 0.12; ctx.fill();
        }
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          const cc = s.lueur.pos / 0.6 * (NU + 1) - 0.5;
          for (let j = 0; j < NU - 1; j++) {
            const li = I * cloche(j + 0.5 - cc, j + 0.5 < cc ? 2.5 : 0.9); if (li < 0.004) continue;
            ctx.beginPath();
            for (let m = 0; m < NM; m++) { const k = m * NU + j; if (PZ[k] < -0.1) continue; ctx.moveTo(PX[k], PY[k]); ctx.lineTo(PX[k + 1], PY[k + 1]); }
            ctx.globalAlpha = li * 0.08; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = li * 0.4; ctx.lineWidth = 0.7; ctx.stroke();
          }
          if (s.lueur.pos > 0.45) {
            const cf = (s.lueur.pos - 0.5) / 0.7 * (NTP + 3) - 1;
            for (let i = 0; i < NTP - 1; i++) {
              const li = I * cloche(i + 0.5 - cf, i + 0.5 < cf ? 4 : 1.3); if (li < 0.004) continue;
              ctx.beginPath(); for (let k = 0; k < NT; k++) { ctx.moveTo(s.tex[k][i], s.tey[k][i]); ctx.lineTo(s.tex[k][i + 1], s.tey[k][i + 1]); }
              ctx.globalAlpha = li * 0.13; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = li * 0.7; ctx.lineWidth = 0.8; ctx.stroke();
            }
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(vx0, vy0, (6 + 12 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.22 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(vx0, vy0, rr0 * (0.8 + 0.6 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.moveTo(MX[0], MY[0]); for (let i = 1; i < NMN; i++) ctx.lineTo(MX[i], MY[i]);
          ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.45 * s.gobe; ctx.lineWidth = 1.6; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  /* =====================================================================
     8. BRAISE — tore à éversion, fourrure de cils incandescents
        (étage 3 : Chœur × Culbute ; greffe : pli de planaire 91368, réf. lumière 49248)
     Le Chœur s'est refermé en tore : sa peau tourne sans fin autour du tube (éversion),
     passe par le trou et ressort dehors — un tapis roulant qui la propulse le long de son
     axe. Les dix cellules du Chœur, prises dans la peau, font ce tour : on lit la nage en
     les suivant. L'axe est celui d'un corps rigide (Culbute) : elle s'oriente, se retourne
     en jouant. Pour saisir, elle se plie en V comme une planaire et referme le tore sur la
     proie ; de temps à autre elle s'étrangle en 8 (souvenir de la division) puis se rouvre.
     ===================================================================== */
  function creerBraise() {
    const RG = { vit: 1, mode: 'cont', part: null };
    const P = palette;
    const NTH = 40, NPS = 10, NCELL = 10, NE = 18;
    const CR = corpsRigide(1, 1.18, 1.95), R = CR.R, pj = CR.pj, w = CR.w;
    const CX = new Float32Array(NTH), CY = new Float32Array(NTH), OX = new Float32Array(NTH), OY = new Float32Array(NTH), IX = new Float32Array(NTH), IY = new Float32Array(NTH);
    const NC3 = NTH * NPS;
    const B0 = new Float32Array(NC3 * 2), B1 = new Float32Array(NC3 * 2), BM = new Float32Array(NC3 * 2), BZ = new Float32Array(NC3), BG = new Float32Array(NC3);
    const coul = { perle: rgb(P.perle), aqua: rgb(P.aqua), sarcelle: rgb(P.sarcelle), lueur: rgb(P.lueur), ambre: rgb(P.ambre), ombre: rgb(P.abysse), mauve: rgb(P.mauve) };
    const degr = cacheContexte(ctx => {
      const c = ctx.createRadialGradient(-0.25, -0.2, 0, 0, 0, 1);
      c.addColorStop(0, rgba(P.perle, 0.12)); c.addColorStop(0.55, rgba(P.sarcelle, 0.14));
      c.addColorStop(0.86, rgba(P.aqua, 0.2)); c.addColorStop(0.97, rgba(P.perle, 0.34)); c.addColorStop(1, rgba(P.perle, 0));
      return c;
    });
    const p3 = new Float64Array(6);
    let W = 360, H = 470, t = 0, rl = Math.random, s = null;

    // Point du tore (repère corps, axe = e3) : anneau étranglé, rayon de tube, pli en V
    function point(th, ps, rOff) {
      const R0 = s.R0 * (1 - 0.88 * s.pin * Math.pow(Math.sin(th), 2)) * (1 + 0.05 * Math.sin(3 * th + t * 0.9 + s.ph));
      const ct = Math.cos(th), st = Math.sin(th), r = s.r * (1 + 0.12 * s.puls * Math.cos(ps)) + rOff;
      const ex = ct, ey = st;                                         // radial dans le plan
      let x = R0 * ct + r * Math.cos(ps) * ex, y = R0 * st * (1 - 0.12 * s.pin) + r * Math.cos(ps) * ey, z = r * Math.sin(ps) * (1 + 0.18 * s.vit);
      let nx = Math.cos(ps) * ex, ny = Math.cos(ps) * ey, nz = Math.sin(ps);
      if (s.pli > 0.002) {                                            // pli : chaque moitié pivote autour de l'axe x
        const a = s.pli * Math.tanh(y / 7), ca = Math.cos(a), sa = Math.sin(a);
        const y2 = y * ca - z * sa, z2 = y * sa + z * ca; y = y2; z = z2;
        const ny2 = ny * ca - nz * sa, nz2 = ny * sa + nz * ca; ny = ny2; nz = nz2;
      }
      p3[0] = x; p3[1] = y; p3[2] = z; p3[3] = nx; p3[4] = ny; p3[5] = nz;
    }

    return {
      init(w_, h_, seed, opts) {
        W = w_; H = h_; t = 0;
        const r = aleatoire(seed); rl = aleatoire(seed ^ 0xb4a1);
        const sl0 = (opts && opts.slot) || 0, hx = W * (sl0 ? 0.64 : 0.36), hy = H * (sl0 ? 0.66 : 0.34);
        CR.init(r() * TAU, 0.9 + r() * 0.5);
        w[0] = 0.1; w[1] = 0.1; w[2] = 0.6;
        s = { hx, hy, x: hx + (r() - 0.5) * 50, y: hy + (r() - 0.5) * 50, vx: 0, vy: 0, ph: r() * TAU, e: 0.95 + 0.1 * r(),
          R0: 23, r: 8.5, flux: 0, fv: 1, puls: 0, vit: 0, pin: 0, pli: 0, pliC: 0, etat: 0, tEtat: 6 + r() * 6, herisse: 0, glow: 0.4, onde: 0,
          exc: 0, gobe: 0, cph: 0, lueur: lueurNeuve(r), g: 0, gx: 0, gy: 0, spin: 0.5, kA: 0, kD: 0, kick: 0, tilt: 0.75, rev: 1,
          cells: [], braises: [], eb: 0, ei: 0 };
        for (let i = 0; i < NCELL; i++) s.cells.push({ th: i / NCELL * TAU + r() * 0.2, ps: r() * TAU, ph: r() * TAU, k: 0.85 + r() * 0.3, ambre: r() < 0.3 });
        for (let i = 0; i < NE; i++) s.braises.push({ x: 0, y: 0, vx: 0, vy: 0, vie: 0, r: 0.6 });
      },
      reglage(o) { if (o && o.gobe !== undefined) { s.gobe = 1; s.pliC = 1.2; return; } Object.assign(RG, o); },
      n() { return 1; },
      pos() { return [s.x, s.y]; },
      place(i, x, y) { s.x = x; s.y = y; },
      vise(i, tx, ty, g) { s.gx = tx; s.gy = ty; s.g = g; },
      geo() { return [{ k: 'disque', x: s.x, y: s.y, r: 32 }]; },

      update(dt, flow, energy) {
        t += dt; const h = Math.min(dt, 1 / 30); if (h <= 0) return;
        const md = RG.mode, e = (s.exc += (excitation(RG, s.x, s.y, 190) - s.exc) * Math.min(1, h * 2.5));
        const pon = RG.part && RG.part.on, dP = pon ? Math.hypot(RG.part.x - s.x, RG.part.y - s.y) : 1e9;
        // [débit d'éversion, spin roue, kick (culbutes), kA, kD, hérissement, éclat, pli, inclinaison]
        let m = [(1.1 + 1.6 * energy) * (0.55 + 0.45 * RG.vit), 0.5, 0.05, s.g ? 2.5 * s.g : 0, s.g ? 1.4 : 0, 0, 0.5 + 0.35 * energy, 0, 0.75];
        if (e > 0.01) {
          let b;
          if (md === 'cont') b = [0.7, 0.25, 0.01, 3.5, 2.4, 0, 0.45, 0, 1.15];       // se présente de face : le trou regarde
          else if (md === 'actif') b = [2.4, 0.4, 1.1, 0.6, 0, 0.2, 0.75, 0, 0.6];      // se retourne en jouant
          else if (md === 'agr') b = [2.9, 0.2, 0.02, 7, 2.6, 0.1, 1, borne(1.6 - dP / 55, 0, 1) * 1.05, 0.45];
          else if (md === 'suit') b = [1.3, 0.4, 0.04, 3, 1.6, 0, 0.5, 0, 0.8];
          else if (md === 'evite') b = [3.2, 2.4, 0.5, 4, 0.6, 1, 0.9, 0, 0.3];          // fourrure hérissée, roue rapide
          else b = [1.6, 1.4, 0.1, 3, 1.2, 0.2, 0.6, 0, 0.6];
          for (let k = 0; k < 9; k++) m[k] = melange(m[k], b[k], e);
        }
        const kk = Math.min(1, h * 2);
        s.fv += (m[0] - s.fv) * kk; s.spin += (m[1] - s.spin) * kk; s.kick += (m[2] - s.kick) * kk; s.kA += (m[3] - s.kA) * kk; s.kD += (m[4] - s.kD) * kk;
        s.herisse += (m[5] - s.herisse) * kk; s.glow += (m[6] - s.glow) * kk; s.tilt += (m[8] - s.tilt) * kk;
        s.pliC = Math.max(m[7], s.pliC - h * 0.5);
        s.pli += (s.pliC - s.pli) * Math.min(1, h * 3.2);
        // Étranglement en 8 (division avortée du Chœur), suspendu quand la particule capte l'attention
        s.tEtat -= h * (e > 0.35 ? 0 : 1);
        if (s.etat === 0 && s.tEtat <= 0) { s.etat = 1; s.tEtat = 2.4; }
        else if (s.etat === 1) { s.pin = Math.min(1, s.pin + h / 2.4); if (s.tEtat <= 0) { s.etat = 2; s.tEtat = 1.4; } }
        else if (s.etat === 2 && s.tEtat <= 0) { s.etat = 3; }
        else if (s.etat === 3) { s.pin = Math.max(0, s.pin - h / 2.8); if (s.pin <= 0) { s.etat = 0; s.tEtat = 11 + 4 * Math.sin(t + s.ph) ** 2; } }
        if (e > 0.35 && s.etat === 1) s.etat = 3;
        // Orientation : l'axe vise la cible, incliné vers l'observateur (on voit le trou)
        let Dx, Dy;
        if (s.g) { Dx = s.gx - s.x; Dy = s.gy - s.y; }
        else { const ecX = s.hx - s.x, ecY = s.hy - s.y, loin = Math.min(1, Math.hypot(ecX, ecY) / 160), a = Math.atan2(ecY, ecX) * loin + (1 - loin) * (Math.sin(t * 0.11 + s.ph) * 2.2 + s.ph); Dx = Math.cos(a); Dy = Math.sin(a); }
        if (md === 'cont' && pon && e > 0.2) { Dx = melange(Dx / (Math.hypot(Dx, Dy) || 1), RG.part.x - s.x, 0.5 * e); Dy = melange(Dy / (Math.hypot(Dx, Dy) || 1), RG.part.y - s.y, 0.5 * e); }
        const Dl = Math.hypot(Dx, Dy) || 1, ct = Math.cos(s.tilt), st = Math.sin(s.tilt);
        CR.tau[0] = CR.tau[1] = CR.tau[2] = 0;
        if (s.kA > 0.05) CR.viser(2, Dx / Dl * ct, Dy / Dl * ct, st, s.kA, s.kD);
        else CR.viser(2, Math.cos(t * 0.2 + s.ph) * ct, Math.sin(t * 0.2 + s.ph) * ct, st, 0.6, 0.4);
        CR.tau[2] += (s.spin - w[2]) * 1.2;                             // roue : la colonie tourne sur elle-même
        CR.tau[1] += s.kick * 3 * Math.sin(t * 0.9 + s.ph);               // culbutes (axe intermédiaire)
        CR.tau[0] += s.kick * 2 * Math.cos(t * 0.7 + s.ph * 2);
        CR.avancer(h);
        // Éversion : la peau tourne autour du tube ; le débit pulse (onde du Chœur) et pousse le long de l'axe
        s.onde += h * (1.6 + 1.2 * energy + 2 * e);
        s.puls = 0.5 + 0.5 * Math.sin(s.onde * 2);
        const fl = s.fv * (0.7 + 0.5 * s.puls);
        s.flux += fl * h;
        s.vit = fl / 3;
        const ax = R[2], ay = R[5], pousse = fl * 11 * s.e * (1 - 0.6 * s.pli);
        const k2 = Math.min(1, h * 1.8);
        s.vx += (ax * pousse - s.vx) * k2; s.vy += (ay * pousse - s.vy) * k2;
        const f0 = flow(s.x, s.y);
        const nx = s.x + (s.vx + f0[0] * 0.35) * h, ny = s.y + (s.vy + f0[1] * 0.35) * h;
        s.x = enroule(nx, 0, W, 80); s.y = enroule(ny, 0, H, 80);
        const jx = s.x - nx, jy = s.y - ny;
        if (jx || jy) for (const b of s.braises) { b.x += jx; b.y += jy; }
        s.R0 = 23 * s.e * (1 - 0.06 * s.puls - 0.12 * s.herisse) ;
        s.r = 8.5 * s.e * (1 + 0.06 * s.puls);
        // Étincelles : se détachent de la fourrure à l'arrière et dérivent dans le sillage
        s.eb += h * (2 + 7 * s.glow * s.vit);
        while (s.eb >= 1) {
          s.eb -= 1; const b = s.braises[s.ei++ % NE];
          point(rl() * TAU, Math.PI * (0.6 + 0.8 * rl()), 3); CR.proj(p3[0], p3[1], p3[2]);
          b.x = s.x + pj[0]; b.y = s.y + pj[1]; b.vx = -ax * (8 + 10 * rl()) + (rl() - 0.5) * 6; b.vy = -ay * (8 + 10 * rl()) + (rl() - 0.5) * 6; b.vie = 1; b.r = 0.5 + 0.6 * rl();
        }
        for (const b of s.braises) {
          if (b.vie <= 0) continue;
          const f = flow(b.x, b.y), k = Math.exp(-1.6 * h);
          b.vx = b.vx * k + f[0] * 0.3 * h; b.vy = b.vy * k + f[1] * 0.3 * h; b.x += b.vx * h; b.y += b.vy * h; b.vie -= h / 1.6;
        }
        s.cph += h * (7 + 6 * energy + 10 * e);
        s.gobe = Math.max(0, s.gobe - h * 0.3);
        avancerLueur(s.lueur, dt, energy, rl);
      },

      draw(ctx, alpha) {
        const A = alpha * 0.74; if (A <= 0.001) return;
        const e = s.e, G = degr(ctx);
        // Ligne centrale projetée + bords de silhouette (projection orthographique : décalage de ±r)
        for (let i = 0; i < NTH; i++) { point(i / NTH * TAU, 0, -s.r * (1 + 0.12 * s.puls)); CR.proj(p3[0], p3[1], p3[2]); CX[i] = s.x + pj[0]; CY[i] = s.y + pj[1]; }
        const rT = s.r;
        for (let i = 0; i < NTH; i++) {
          const a = (i + NTH - 1) % NTH, b = (i + 1) % NTH; let tx = CX[b] - CX[a], ty = CY[b] - CY[a]; const l = 1 / (Math.hypot(tx, ty) || 1); tx *= l; ty *= l;
          OX[i] = CX[i] - ty * rT; OY[i] = CY[i] + tx * rT; IX[i] = CX[i] + ty * rT; IY[i] = CY[i] - tx * rT;
        }
        // Le sens « extérieur » dépend du sens de parcours : on garde la courbe la plus longue comme bord externe
        let lo = 0, li = 0; for (let i = 0; i < NTH; i++) { const j = (i + 1) % NTH; lo += Math.hypot(OX[j] - OX[i], OY[j] - OY[i]); li += Math.hypot(IX[j] - IX[i], IY[j] - IY[i]); }
        const ext = lo >= li, EXx = ext ? OX : IX, EXy = ext ? OY : IY, INx = ext ? IX : OX, INy = ext ? IY : OY;
        const trou = borne((Math.abs(R[8]) * s.R0 * (1 - 0.5 * s.pin) - rT * 1.05) / 6, 0, 1) * (1 - 0.6 * s.pli);
        // Fourrure : base et pointe de chaque cil (penchés contre le défilement de la peau)
        let n = 0;
        const L0 = 3.6 * e, flx = s.flux * 1.0;
        for (let i = 0; i < NTH; i++) {
          const th = (i + 0.5 * (i % 2)) / NTH * TAU;
          for (let k = 0; k < NPS; k++, n++) {
            const ps = k / NPS * TAU + flx + (i % 2) * 0.39;
            point(th, ps, 0);
            const x = p3[0], y = p3[1], z = p3[2], nx = p3[3], ny = p3[4], nz = p3[5];
            const ph = s.cph - k * 0.9 - i * 0.25, L = L0 * (1 + 0.28 * Math.sin(ph)) * (1 + 0.7 * s.herisse) * (1 + 0.25 * s.exc);
            const pente = (0.9 - 0.7 * s.herisse) * (0.4 + 0.6 * Math.min(1, s.vit)) + 0.3 * Math.cos(ph);
            // tangente poloïdale (sens du défilement)
            const tx = -Math.sin(ps) * Math.cos(th), ty = -Math.sin(ps) * Math.sin(th), tz = Math.cos(ps);
            CR.proj(x + nx * 0.6, y + ny * 0.6, z + nz * 0.6); B0[n * 2] = s.x + pj[0]; B0[n * 2 + 1] = s.y + pj[1];
            CR.proj(x + nx * (0.6 + L * 0.6) - tx * L * pente * 0.15, y + ny * (0.6 + L * 0.6) - ty * L * pente * 0.15, z + nz * (0.6 + L * 0.6) - tz * L * pente * 0.15);
            BM[n * 2] = s.x + pj[0]; BM[n * 2 + 1] = s.y + pj[1];
            CR.proj(x + nx * (0.6 + L) - tx * L * pente, y + ny * (0.6 + L) - ty * L * pente, z + nz * (0.6 + L) - tz * L * pente);
            B1[n * 2] = s.x + pj[0]; B1[n * 2 + 1] = s.y + pj[1];
            BZ[n] = R[6] * nx + R[7] * ny + R[8] * nz;
            // éclat : l'onde fait le tour du tore (θ), plus vive côté extérieur
            BG[n] = s.glow * (0.45 + 0.55 * Math.pow(0.5 + 0.5 * Math.cos(th - s.onde * 1.3), 3)) * (0.7 + 0.3 * Math.cos(ps));
          }
        }
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        // 1. Étincelles du sillage
        ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = coul.ambre;
        for (const b of s.braises) { if (b.vie <= 0) continue; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * (0.6 + 0.4 * b.vie), 0, TAU); ctx.globalAlpha = A * 0.55 * b.vie * b.vie * s.glow; ctx.fill(); }
        ctx.globalCompositeOperation = 'source-over';
        // 2. Fourrure arrière (sous le tube)
        const fourrure = (devant, Aa) => {
          ctx.beginPath();
          for (let q = 0; q < NC3; q++) { if ((BZ[q] >= 0) !== devant) continue; ctx.moveTo(B0[q * 2], B0[q * 2 + 1]); ctx.quadraticCurveTo(BM[q * 2], BM[q * 2 + 1], B1[q * 2], B1[q * 2 + 1]); }
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Aa * 0.16; ctx.lineWidth = 0.45; ctx.stroke();
          // pointes incandescentes, en trois paliers d'éclat
          ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = coul.ambre;
          for (let bin = 0; bin < 3; bin++) {
            const lo2 = bin / 3, hi2 = (bin + 1) / 3; ctx.beginPath();
            for (let q = 0; q < NC3; q++) {
              if ((BZ[q] >= 0) !== devant) continue; const g = BG[q]; if (g < lo2 || g >= hi2 && bin < 2) continue;
              ctx.moveTo(BM[q * 2], BM[q * 2 + 1]); ctx.lineTo(B1[q * 2], B1[q * 2 + 1]);
            }
            const gg = (bin + 0.5) / 3;
            ctx.globalAlpha = Aa * 0.07 * gg; ctx.lineWidth = 2.6; ctx.stroke();
            ctx.globalAlpha = Aa * (0.22 + 0.6 * gg); ctx.lineWidth = 0.6; ctx.stroke();
          }
          ctx.globalCompositeOperation = 'source-over';
        };
        // aura : la fourrure rougeoie comme un halo autour du tube
        ctx.globalCompositeOperation = 'lighter';
        ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
        ctx.strokeStyle = coul.ambre; ctx.globalAlpha = A * 0.035 * s.glow; ctx.lineWidth = rT * 2 + 14; ctx.stroke();
        ctx.globalAlpha = A * 0.05 * s.glow; ctx.lineWidth = rT * 2 + 6; ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';
        fourrure(false, A * 0.5);
        // 3. Tube : un seul trait épais le long de la ligne centrale = silhouette exacte du tore
        ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
        ctx.strokeStyle = coul.sarcelle; ctx.globalAlpha = A * 0.34; ctx.lineWidth = rT * 2; ctx.stroke();
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.25; ctx.lineWidth = rT * 1.1; ctx.stroke();
        // modelé : reflet décalé vers la lumière
        ctx.save(); ctx.translate(-rT * 0.32, -rT * 0.38);
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = rT * 0.7; ctx.stroke(); ctx.restore();
        // volume : l'intérieur du tube (côté trou) plonge dans l'ombre, l'extérieur prend la lumière
        ctx.beginPath(); for (let i = 0; i <= NTH; i++) { const j = i % NTH, x = (CX[j] + INx[j]) / 2, y = (CY[j] + INy[j]) / 2; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.strokeStyle = coul.ombre; ctx.globalAlpha = A * 0.3; ctx.lineWidth = rT * 0.9; ctx.stroke();
        ctx.beginPath(); for (let i = 0; i <= NTH; i++) { const j = i % NTH, x = CX[j] * 0.3 + EXx[j] * 0.7, y = CY[j] * 0.3 + EXy[j] * 0.7; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.strokeStyle = coul.aqua; ctx.globalAlpha = A * 0.1; ctx.lineWidth = rT * 0.45; ctx.stroke();
        // bords : externe net, interne seulement si le trou se voit
        ctx.beginPath(); ctx.moveTo(EXx[0], EXy[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(EXx[i], EXy[i]); ctx.closePath();
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.07; ctx.lineWidth = 4; ctx.stroke(); ctx.globalAlpha = A * 0.45; ctx.lineWidth = 0.8; ctx.stroke();
        if (trou > 0.02) {
          ctx.beginPath(); ctx.moveTo(INx[0], INy[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(INx[i], INy[i]); ctx.closePath();
          ctx.fillStyle = coul.ombre; ctx.globalAlpha = A * 0.28 * trou; ctx.fill();
          ctx.globalAlpha = A * 0.4 * trou; ctx.lineWidth = 0.7; ctx.stroke();
        }
        // anneaux poloïdaux : la peau défile (on voit le tapis roulant)
        ctx.beginPath();
        for (let i = 0; i < NTH; i += 3) {
          const th = i / NTH * TAU; let first = true;
          for (let k = 0; k <= 10; k++) {
            const ps = k / 10 * TAU; point(th, ps, 0.2);
            const nz = R[6] * p3[3] + R[7] * p3[4] + R[8] * p3[5]; CR.proj(p3[0], p3[1], p3[2]);
            if (nz < 0) { first = true; continue; }
            first ? ctx.moveTo(s.x + pj[0], s.y + pj[1]) : ctx.lineTo(s.x + pj[0], s.y + pj[1]); first = false;
          }
        }
        ctx.strokeStyle = coul.perle; ctx.globalAlpha = A * 0.13; ctx.lineWidth = 0.5; ctx.stroke();
        // 4. Les cellules du Chœur, prises dans la peau, font le tour du tube
        for (let c = 0; c < NCELL; c++) {
          const ce = s.cells[c], ps = ce.ps + s.flux;
          point(ce.th, ps, 0.4); const nz = R[6] * p3[3] + R[7] * p3[4] + R[8] * p3[5];
          CR.proj(p3[0], p3[1], p3[2]); const x = s.x + pj[0], y = s.y + pj[1];
          point(ce.th, ps + 0.25, 0.4); CR.proj(p3[0], p3[1], p3[2]);
          const ang = Math.atan2(s.y + pj[1] - y, s.x + pj[0] - x), fac = 0.35 + 0.65 * Math.abs(nz), Ac = A * (nz >= 0 ? 1 : 0.35);
          const a = 4 * ce.k * e, b = 2.7 * ce.k * e * fac;
          ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
          ctx.beginPath(); ctx.ellipse(0, 0, a, b, 0, 0, TAU);
          ctx.save(); ctx.scale(a, b); ctx.fillStyle = G; ctx.globalAlpha = Ac; ctx.fill(); ctx.restore();
          ctx.strokeStyle = coul.perle; ctx.globalAlpha = Ac * 0.55; ctx.lineWidth = 0.6; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, 0, a * 0.78, b * 0.7, 0, 0, TAU); ctx.globalAlpha = Ac * 0.18; ctx.lineWidth = 0.5; ctx.stroke();
          ctx.beginPath(); ctx.arc(a * 0.25, 0, 1.2 * ce.k, 0, TAU); ctx.fillStyle = coul.aqua; ctx.globalAlpha = Ac * 0.2; ctx.fill();
          ctx.beginPath(); ctx.arc(-a * 0.4, 0, 0.8, 0, TAU); ctx.fillStyle = ce.ambre ? coul.ambre : coul.perle; ctx.globalAlpha = Ac * 0.5; ctx.fill();
          ctx.restore();
        }
        // 5. Fourrure avant
        fourrure(true, A);
        // 6. Lumières : impulsion qui fait le tour du tore ; gobage mauve au cœur du pli
        ctx.globalCompositeOperation = 'lighter';
        const I = A * P.alpha.biolum * enveloppe(s.lueur);
        if (I > 0.004) {
          const tete = s.lueur.pos * NTH * 1.2;
          ctx.strokeStyle = s.lueur.ambre ? coul.ambre : coul.lueur;
          for (let i = 0; i < NTH; i++) {
            const l2 = I * cloche(i - tete, i < tete ? 5 : 1.5); if (l2 < 0.004) continue; const j = (i + 1) % NTH;
            ctx.beginPath(); ctx.moveTo(EXx[i], EXy[i]); ctx.lineTo(EXx[j], EXy[j]);
            ctx.globalAlpha = l2 * 0.14; ctx.lineWidth = 6; ctx.stroke(); ctx.globalAlpha = l2 * 0.65; ctx.lineWidth = 1; ctx.stroke();
          }
        }
        if (s.gobe > 0.004) {
          ctx.fillStyle = coul.mauve;
          ctx.beginPath(); ctx.arc(s.x, s.y, (6 + 18 * s.gobe) * e, 0, TAU); ctx.globalAlpha = A * 0.2 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.arc(s.x, s.y, (1.5 + 3 * s.gobe), 0, TAU); ctx.globalAlpha = A * 0.9 * s.gobe; ctx.fill();
          ctx.beginPath(); ctx.moveTo(CX[0], CY[0]); for (let i = 1; i < NTH; i++) ctx.lineTo(CX[i], CY[i]); ctx.closePath();
          ctx.strokeStyle = coul.mauve; ctx.globalAlpha = A * 0.12 * s.gobe; ctx.lineWidth = rT * 1.4; ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      }
    };
  }

  const fabriques = { cells: creerCellules, filament: creerFilament, systole: creerSystole, culbute: creerCulbute, choeur: creerChoeur, cortege: creerCortege, volte: creerVolte, braise: creerBraise };
  const QXMOTIFS = {
    palette,
    noms: Object.keys(fabriques),
    create(nom) { return fabriques[nom](); }
  };
  for (const nom of QXMOTIFS.noms) QXMOTIFS[nom] = fabriques[nom]();
  QXMOTIFS.decor = creerDecor;
  racine.QXMOTIFS = QXMOTIFS;
})(typeof window !== 'undefined' ? window : globalThis);
/* =====================================================================
   QXCREA (R462) — « Évasion de Fluides » sur la VRAIE constellation.
   Chargé à la demande (jamais au démarrage). Dessine dans une surcouche
   alignée sur le canevas de QXCONST (même repère : px CSS de la carte),
   lit les positions réelles des nœuds et le tracé réel des liens.
   API : QXCREA.play({ inst, mode:'sequence'|'final', lang, sobre, fin(raison) })
         QXCREA.stop() ; QXCREA.etat ; QXCREA.stats()
   ===================================================================== */
(function (racine) {
'use strict';
const M = racine.QXMOTIFS;
const TAU = Math.PI * 2, H = 1 / 60, WW = 4000, WH = 4000;
function rng(seed){let s=seed>>>0;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
const clamp=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,u)=>a+(b-a)*u;
const sm=u=>{u=clamp(u,0,1);return u*u*(3-2*u);};
const eo=u=>{u=clamp(u,0,1);return 1-(1-u)*(1-u)*(1-u);};
const eback=u=>{u=clamp(u,0,1);const c=1.9;return 1+(c+1)*Math.pow(u-1,3)+c*Math.pow(u-1,2);};
const gss=(x,w)=>Math.exp(-(x*x)/(w*w));
const adiff=a=>a-Math.round(a/TAU)*TAU;
const rgba=(c,a)=>'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';
const CY=[127,216,230],PER=[226,240,244],LUE=[110,238,196],MAU=[182,154,232];
const F=11;
const TXT={
  fr:{flu:'Fluides',pousse:'Quelque chose pousse contre la membrane',une:'Elles s’échappent, une à une',touche:'Chaque monde touché devient fluide',
      cont:'La contagion gagne les derniers mondes',fin:'Les onze mondes sont colonisés',col:'Colonisés',passer:'Passer'},
  en:{flu:'Fluids',pousse:'Something presses against the membrane',une:'They escape, one by one',touche:'Every world they touch turns fluid',
      cont:'The contagion reaches the last worlds',fin:'All eleven worlds are colonised',col:'Colonised',passer:'Skip'}
};
/* créatures : motif, étiquette, instant de percée, monde cible (0 = Atelier … 10 = Quantique), durée du voyage, échelle, écart de sortie */
const CRE=[
 ['systole','Systole',5.6,10,2.5,.58,0],
 ['cells','Paramécie',8.9,7,4.4,.52,-.42],
 ['filament','Filament',11.1,1,9.2,.5,.34],
 ['culbute','Culbute',11.65,9,3.4,.56,-.18],
 ['choeur','Chœur',14.2,4,6.8,.48,.42],
 ['cortege','Cortège',16.4,0,9.4,.5,-.5],
 ['volte','Volte',16.95,5,6.2,.6,.16],
 ['braise','Braise',19.1,2,7.2,.56,-.3]
];
const CONT=[[3,[2,4],27.2,2],[6,[7,5],27.75,7],[8,[9,7],28.3,9]];
const T0=1.6,T_FIN=33.2;
/* gouverneur : [plafond de particules, DPR max, volutes, décor des créatures, sillages] */
const NIVQ=[[420,2,1,1,1],[260,1.5,0,1,1],[150,1,0,0,1],[90,1,0,0,0]];

function mkCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function mkGlow(c){const s=96,k=mkCanvas(s,s),g=k.getContext('2d'),r=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);
  r.addColorStop(0,rgba(c,1));r.addColorStop(.18,rgba(c,.55));r.addColorStop(.45,rgba(c,.16));r.addColorStop(1,rgba(c,0));g.fillStyle=r;g.fillRect(0,0,s,s);return k;}
function mkRing(c){const s=128,k=mkCanvas(s,s),g=k.getContext('2d'),r=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);
  r.addColorStop(0,rgba(c,0));r.addColorStop(.36,rgba(c,0));r.addColorStop(.41,rgba(c,.55));r.addColorStop(.55,rgba(c,.18));r.addColorStop(1,rgba(c,0));g.fillStyle=r;g.fillRect(0,0,s,s);return k;}
let SPR=null;
function sprites(){ if(SPR)return SPR;
  const SPEC=(()=>{const s=64,k=mkCanvas(s,s),g=k.getContext('2d');g.translate(s/2,s/2);g.scale(1,.55);const r=g.createRadialGradient(0,0,0,0,0,s/2);
    r.addColorStop(0,'rgba(255,255,255,.95)');r.addColorStop(.35,'rgba(240,250,252,.35)');r.addColorStop(1,'rgba(240,250,252,0)');g.fillStyle=r;g.beginPath();g.arc(0,0,s/2,0,TAU);g.fill();return k;})();
  SPR={SPEC,RCY:mkRing(CY),cy:mkGlow(CY),pe:mkGlow(PER),lu:mkGlow(LUE),ma:mkGlow(MAU),dark:mkGlow([2,6,11])};return SPR;}
function lsGet(k){try{return racine.localStorage.getItem(k);}catch(e){return null;}}
function reduitOS(){try{return !!(racine.matchMedia&&racine.matchMedia('(prefers-reduced-motion: reduce)').matches);}catch(e){return false;}}

let style=false;
function poserStyle(){ if(style)return; style=true; const s=document.createElement('style'); s.textContent=`
.qxc-cv{position:absolute;left:0;top:0;pointer-events:none}
.qxc-prise{position:absolute;inset:0;pointer-events:auto;background:transparent;-webkit-tap-highlight-color:transparent}
.qxc-hud{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 39px);text-align:center;pointer-events:none;z-index:3;transition:opacity .5s}
.qxc-leg{margin:0 auto;max-width:320px;min-height:17px;font-size:12.5px;line-height:1.35;color:#C9D8DE;letter-spacing:.01em;transition:opacity .32s,transform .32s;text-shadow:0 0 10px rgba(3,8,13,.9)}
.qxc-leg.fl{color:#BFF0F4}
.qxc-cpt{margin:5px auto 0;font-size:9px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:rgba(159,230,238,.85);opacity:0;transition:opacity .6s}
.qxc-j{display:block;width:84px;height:1.5px;margin:5px auto 0;background:rgba(159,230,238,.14);position:relative;overflow:hidden}
.qxc-j i{position:absolute;left:0;top:0;bottom:0;width:0;background:rgba(159,230,238,.85);transition:width .5s}
.qxc-passer{position:absolute;right:14px;bottom:calc(env(safe-area-inset-bottom,0px) + 18px);z-index:4;min-height:34px;padding:0 15px;border-radius:999px;
  border:1px solid rgba(234,246,255,.2);background:rgba(10,14,26,.5);color:rgba(234,246,255,.82);font:inherit;font-size:12px;letter-spacing:.08em;cursor:pointer;
  -webkit-tap-highlight-color:transparent;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);transition:opacity .4s}
.qxc-sous{transition:opacity .4s}
`; document.head.appendChild(s); }

let cur=null;

function Scene(o){
  const inst=o.inst, R0=inst.racine, LG=TXT[o.lang==='en'?'en':'fr'];
  const sobre=!!o.sobre||reduitOS();
  let mode=o.mode==='final'?'final':(sobre?'abrege':'sequence');
  const S2=sprites();
  let detruit=false, raf=0, tPrev=0, acc=0, nImg=0;
  /* ---------- DOM ---------- */
  poserStyle();
  const cv=document.createElement('canvas');cv.className='qxc-cv';const ctx=cv.getContext('2d');
  inst.poser(cv);
  let prise=null,hud=null,leg=null,cpt=null,jau=null,bP=null,sous=R0.querySelector('.qxk-s');
  if(mode!=='final'){
    prise=document.createElement('div');prise.className='qxc-prise';prise.setAttribute('aria-hidden','true');inst.poser(prise);
    hud=document.createElement('div');hud.className='qxc-hud';hud.setAttribute('aria-live','polite');
    hud.innerHTML='<p class="qxc-leg"></p><p class="qxc-cpt"><span></span><b class="qxc-j"><i></i></b></p>';
    leg=hud.firstChild;cpt=hud.lastChild;jau=cpt.querySelector('i');R0.appendChild(hud);
    bP=document.createElement('button');bP.type='button';bP.className='qxc-passer';bP.textContent=LG.passer;R0.appendChild(bP);
    const passer=(ev)=>{if(ev){ev.preventDefault();ev.stopPropagation();}sauter();};
    bP.addEventListener('click',passer);prise.addEventListener('pointerdown',passer);
    if(sous){sous.classList.add('qxc-sous');sous.style.opacity='0';}
  }
  /* ---------- géométrie réelle ---------- */
  let geoV=-1,l=0,h=0,G=1,dpr=1,niv=mode==='final'?1:0;   // état final : d'emblée un cran plus léger
  const N=[],RBv=[],COL=[],NOMS=[],LK=[];let RF=34,GLW=[],RINGW=[],PCOL=[];
  const RB=i=>RBv[i];
  const GR={body:[],cyb:[],liq:[],lien:[],iri:null};
  function regeo(force){
    const g=inst.geo(); if(!g||!g.l||!g.P||!g.P[12])return false;
    if(g.v===geoV&&!force)return true;
    const prem=geoV<0; geoV=g.v; l=g.l; h=g.h;
    let som=0;for(let i=0;i<12;i++){const p=g.P[i+1];N[i]=[p.x,p.y];RBv[i]=p.R+7;if(i<11)som+=RBv[i];COL[i]=g.C[i+1]||CY;NOMS[i]=g.noms[i]||'';}
    G=som/11/21;RF=g.P[12].R+11;RBv[F]=RF;   // Fluides : un peu plus grande que son anneau, sans mordre sur son étiquette
    for(let i=0;i<11;i++)LK[i]=(g.liens[i+1]||[]).map(q=>[q[0],q[1]]);
    if(prem){GLW=COL.map(mkGlow);RINGW=COL.map(mkRing);PCOL=['rgb(127,216,230)','rgb(232,246,248)','rgb(110,238,196)','rgb(182,154,232)'].concat(COL.map(c=>'rgb('+c+')'));}
    tailleCanvas();mkDegrades();
    if(!prem){for(const e of E){const f=e.ch?e.s/e.ch.tot:0;e.ch=construireChemin(e.cible,e.aEx);e.s=f*e.ch.tot;e.kT=e.kT0*G;e.k0=e.kT;}
      for(const s of SEEDS){s.k=s.k1*G;s.k0=s.k;}}
    return true;
  }
  function tailleCanvas(){dpr=Math.min(NIVQ[niv][1],racine.devicePixelRatio||1,2);cv.width=Math.round(l*dpr);cv.height=Math.round(h*dpr);cv.style.width=l+'px';cv.style.height=h+'px';}
  function mkDegrades(){
    GR.body=[];GR.liq=[];GR.cyb=[];GR.lien=[];
    for(let i=0;i<12;i++){const r=RB(i),c=COL[i];
      let g=ctx.createRadialGradient(-r*.32,-r*.38,r*.05,0,0,r);
      g.addColorStop(0,rgba(c,0));g.addColorStop(.62,rgba(c,.03));g.addColorStop(.84,rgba(c,.12));g.addColorStop(.96,rgba(c,.3));g.addColorStop(1,rgba(c,.45));GR.body.push(g);
      g=ctx.createRadialGradient(-r*.32,-r*.38,r*.05,0,0,r);
      g.addColorStop(0,rgba(CY,.02));g.addColorStop(.7,rgba(CY,.08));g.addColorStop(1,rgba(CY,.32));GR.cyb.push(g);
      g=ctx.createLinearGradient(0,-r,0,r);g.addColorStop(0,rgba([60,160,175],.26));g.addColorStop(.55,rgba([20,80,96],.42));g.addColorStop(1,rgba([6,34,46],.62));GR.liq.push(g);
    }
    for(let i=0;i<11;i++){const a=N[i+1],b=N[i];const g=ctx.createLinearGradient(a[0],a[1],b[0],b[1]);g.addColorStop(0,rgba(CY,.95));g.addColorStop(.55,rgba([150,220,225],.7));g.addColorStop(1,rgba(COL[i],.85));GR.lien.push(g);}
    if(ctx.createConicGradient){const g=ctx.createConicGradient(0,0,0);
      g.addColorStop(0,'rgba(140,222,232,.95)');g.addColorStop(.16,'rgba(182,154,232,.85)');g.addColorStop(.3,'rgba(226,180,120,.45)');g.addColorStop(.42,'rgba(118,200,196,.8)');
      g.addColorStop(.58,'rgba(232,244,248,.95)');g.addColorStop(.72,'rgba(110,238,196,.7)');g.addColorStop(.86,'rgba(160,140,230,.7)');g.addColorStop(1,'rgba(140,222,232,.95)');GR.iri=g;}
    else GR.iri='rgba(170,220,230,.8)';
  }
  /* ---------- état ---------- */
  let passeF=false,R=rng(20261120),T=T0,souffle=0,assomb=0,flashEcran=0,niveauF=.9,fondu=1,tFinal=-1;
  const NP=i=>i===F?72:44;
  const PX=[],PY=[];for(let i=0;i<12;i++){PX.push(new Float32Array(NP(i)));PY.push(new Float32Array(NP(i)));}
  const B=[];for(let i=0;i<12;i++)B.push({pokes:[],glint:0,wob:0,colT:-1e9,lvl:0,flash:0,cicat:[],pulse:0,spT:R()*2});
  const lien=new Float32Array(11),lienRes=new Float32Array(11);
  const VAGUES=[],ANN=[],ECL=[],RAYS=[],GRAINES=[];
  let LEGT='';
  const NPM=420;
  const P={x:new Float32Array(NPM),y:new Float32Array(NPM),vx:new Float32Array(NPM),vy:new Float32Array(NPM),a:new Float32Array(NPM),v:new Float32Array(NPM),s:new Float32Array(NPM),k:new Uint8Array(NPM),c:new Uint8Array(NPM),l:new Uint8Array(NPM),ph:new Float32Array(NPM)};
  let pn=0;
  function emet(x,y,vx,vy,vie,s,k,c,l2){if(pn>=NIVQ[niv][0])return;const i=pn++;P.x[i]=x;P.y[i]=y;P.vx[i]=vx;P.vy[i]=vy;P.a[i]=0;P.v[i]=vie;P.s[i]=s;P.k[i]=k;P.c[i]=c;P.l[i]=l2;P.ph[i]=R()*TAU;}
  function gerbe(x,y,ang,ouv,n,v0,c,l2,vie){v0*=G;for(let j=0;j<n;j++){const a=ang+(R()-.5)*ouv,v=v0*(.25+R()*.9),r=R();
    emet(x,y,Math.cos(a)*v,Math.sin(a)*v,(vie||1)*(.5+R()*.9),r<.18?1.6:.7+R()*.9,r<.16?1:r<.42?2:0,R()<.3?1:c,l2);}}
  /* ---------- chemins le long des VRAIS liens ---------- */
  function horsDe(pts,i,d){return pts.filter(q=>Math.hypot(q[0]-N[i][0],q[1]-N[i][1])>d);}
  function construireChemin(c,aExit){
    const raw=[],seg=[];const f=N[F];
    const ex=Math.cos(aExit),ey=Math.sin(aExit);
    let prem=null;
    for(let i=10;i>=c;i--){
      let pts=LK[i].slice().reverse();                                  // du nœud i+1 vers le nœud i
      pts=horsDe(pts,i+1,i+1===F?RF+16*G:RB(i+1)+18*G);
      pts=horsDe(pts,i,i>c?RB(i)+18*G:RB(i)+1);
      if(!pts.length){const a=N[i+1],b=N[i];pts=[[lerp(a[0],b[0],.5),lerp(a[1],b[1],.5)]];}
      if(i===10){prem=pts;
        const p3=pts[0],q=pts[Math.min(1,pts.length-1)];let ux=q[0]-p3[0],uy=q[1]-p3[1];const ul=Math.hypot(ux,uy)||1;ux/=ul;uy/=ul;
        if(pts.length<2){ux=N[10][0]-f[0];uy=N[10][1]-f[1];const u2=Math.hypot(ux,uy)||1;ux/=u2;uy/=u2;}
        const p0=[f[0]+ex*(RF+9*G),f[1]+ey*(RF+9*G)],p1=[p0[0]+ex*16*G,p0[1]+ey*16*G],p2=[p3[0]-ux*14*G,p3[1]-uy*14*G];
        for(let j=0;j<24;j++){const u=j/24,v=1-u;raw.push([v*v*v*p0[0]+3*v*v*u*p1[0]+3*v*u*u*p2[0]+u*u*u*p3[0],v*v*v*p0[1]+3*v*v*u*p1[1]+3*v*u*u*p2[1]+u*u*u*p3[1]]);seg.push(10);}
      }
      for(const q of pts){raw.push(q);seg.push(i);}
      if(i>c){                                                         // contourne le nœud i par un arc
        const b=N[i],rr=RB(i)+8*G,last=raw[raw.length-1];
        let nxt=horsDe(LK[i-1].slice().reverse(),i,RB(i)+18*G);nxt=nxt.length?nxt[0]:N[i-1];
        const a1=Math.atan2(last[1]-b[1],last[0]-b[0]),a2=Math.atan2(nxt[1]-b[1],nxt[0]-b[0]);let da=adiff(a2-a1);
        if(Math.abs(Math.abs(da)-Math.PI)<.25)da=Math.PI*(i%2?1:-1);
        const na=Math.max(3,Math.ceil(Math.abs(da)/.16));
        for(let j=0;j<=na;j++){const q=a1+da*j/na;raw.push([b[0]+Math.cos(q)*rr,b[1]+Math.sin(q)*rr]);seg.push(j<na/2?i:i-1);}
      }
    }
    {const b=N[c],last=raw[raw.length-1];let ax=b[0]-last[0],ay=b[1]-last[1];const al=Math.hypot(ax,ay)||1;ax/=al;ay/=al;raw.push([b[0]-ax*(RB(c)+1),b[1]-ay*(RB(c)+1)]);seg.push(c);}
    let X=[],Y=[],S=[];
    for(let j=0;j<raw.length-1;j++){const a=raw[j],b=raw[j+1],ll=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.ceil(ll/2));
      for(let k=0;k<n;k++){X.push(a[0]+(b[0]-a[0])*k/n);Y.push(a[1]+(b[1]-a[1])*k/n);S.push(seg[j]);}}
    X.push(raw[raw.length-1][0]);Y.push(raw[raw.length-1][1]);S.push(c);
    for(let it=0;it<3;it++){const X2=X.slice(),Y2=Y.slice(),w=6;
      for(let j=1;j<X.length-1;j++){let sx=0,sy=0,n=0;for(let k=-w;k<=w;k++){const q=clamp(j+k,0,X.length-1);sx+=X[q];sy+=Y[q];n++;}const fz=Math.min(1,j/8,(X.length-1-j)/8);X2[j]=lerp(X[j],sx/n,fz);Y2[j]=lerp(Y[j],sy/n,fz);}X=X2;Y=Y2;}
    const L=new Float32Array(X.length);for(let j=1;j<X.length;j++)L[j]=L[j-1]+Math.hypot(X[j]-X[j-1],Y[j]-Y[j-1]);
    const lent=new Float32Array(X.length);
    for(let j=0;j<X.length;j++){let m=1;for(let i=c+1;i<=10;i++){const d=Math.hypot(X[j]-N[i][0],Y[j]-N[i][1])-RB(i);m=Math.min(m,1-.38*gss(d-6*G,16*G));}lent[j]=m;}
    return{X:Float32Array.from(X),Y:Float32Array.from(Y),L,S,lent,tot:L[L.length-1],c};
  }
  function idx(ch,s){s=clamp(s,0,ch.tot);let lo=0,hi=ch.L.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(ch.L[m]<s)lo=m;else hi=m;}return lo;}
  const _p=[0,0,0,0];
  function surChemin(ch,s){const j=idx(ch,s),j2=Math.min(j+1,ch.X.length-1),ll=(ch.L[j2]-ch.L[j])||1,u=clamp((s-ch.L[j])/ll,0,1);
    _p[0]=lerp(ch.X[j],ch.X[j2],u);_p[1]=lerp(ch.Y[j],ch.Y[j2],u);
    const ja=Math.max(0,j-3),jb=Math.min(ch.X.length-1,j+4);let tx=ch.X[jb]-ch.X[ja],ty=ch.Y[jb]-ch.Y[ja];const tl=Math.hypot(tx,ty)||1;_p[2]=tx/tl;_p[3]=ty/tl;return _p;}
  function profil(ch,s){const j=idx(ch,s);return (.42+.58*sm(s/(120*G)))*(1-.55*sm(1-(ch.tot-s)/(80*G)))*ch.lent[j];}
  /* polyligne réelle entre deux nœuds voisins (contagion) */
  function lienEntre(a,b){const i=Math.min(a,b);let pts=LK[i].slice();if(a>b)pts.reverse();
    pts=horsDe(horsDe(pts,a,RB(a)+2),b,RB(b)+1);if(pts.length<2)pts=[N[a],N[b]];
    const L=[0];for(let j=1;j<pts.length;j++)L.push(L[j-1]+Math.hypot(pts[j][0]-pts[j-1][0],pts[j][1]-pts[j-1][1]));return{pts,L,tot:L[L.length-1]};}
  function surLien(lk,u){const s=u*lk.tot;let j=0;while(j<lk.L.length-2&&lk.L[j+1]<s)j++;const ll=(lk.L[j+1]-lk.L[j])||1,f=clamp((s-lk.L[j])/ll,0,1);
    return[lerp(lk.pts[j][0],lk.pts[j+1][0],f),lerp(lk.pts[j][1],lk.pts[j+1][1],f)];}
  /* ---------- membranes ---------- */
  function poke(i,id,ang,d,w){const b=B[i];let p=null;for(const q of b.pokes)if(q.id===id){p=q;break;}
    if(!p){if(b.pokes.length>5)return;p={id,a:ang,d:0,v:0,w,drive:true};b.pokes.push(p);}p.a=ang;p.w=w;p.tgt=d;p.drive=true;p.held=true;}
  function relache(i,id,kick){for(const q of B[i].pokes)if(q.id===id){q.drive=false;q.held=false;q.v+=kick||0;}}
  function majBulles(){
    for(let i=0;i<12;i++){const b=B[i];
      for(let k=b.pokes.length-1;k>=0;k--){const p=b.pokes[k];
        if(p.drive){p.d+=(p.tgt-p.d)*Math.min(1,H*14);p.v=0;if(!p.held){p.drive=false;}p.held=false;}
        else{p.v+=(-320*p.d-6.5*p.v)*H;p.d+=p.v*H;if(Math.abs(p.d)<.04&&Math.abs(p.v)<.3)b.pokes.splice(k,1);}}
      b.glint=Math.max(0,b.glint-H*1.6);b.wob*=Math.exp(-H*1.1);b.flash=Math.max(0,b.flash-H*2.2);b.pulse*=Math.exp(-H*5);
      if(b.colT>-1e8)b.lvl=(mode==='final'?.4:.5)*eo((T-b.colT)/3.4);
    }
  }
  function forme(i,rev){
    const b=B[i],n=NP(i),r0=RB(i)*rev,X=PX[i],Y=PY[i];
    const br=1+.022*Math.sin(T*1.25+i*1.7)+.07*b.pulse+(i===F?.012*Math.sin(T*3.1):0);
    const w=.012+.05*b.wob;
    for(let k=0;k<n;k++){const q=k/n*TAU;let r=r0*br*(1+w*Math.sin(2*q+T*.9+i)+w*.8*Math.sin(3*q-T*1.3+i*2)+w*.5*Math.sin(5*q+T*2.1));
      for(const p of b.pokes){const x=adiff(q-p.a);r+=p.d*(.74*gss(x,p.w)+.26*gss(x,p.w*.42));}
      X[k]=Math.cos(q)*r;Y[k]=Math.sin(q)*r;}
  }
  function trace(i){const X=PX[i],Y=PY[i],n=X.length;ctx.beginPath();ctx.moveTo((X[n-1]+X[0])/2,(Y[n-1]+Y[0])/2);
    for(let k=0;k<n;k++){const k2=k+1<n?k+1:0;ctx.quadraticCurveTo(X[k],Y[k],(X[k]+X[k2])/2,(Y[k]+Y[k2])/2);}ctx.closePath();}
  /* ---------- créatures ---------- */
  const E=[];let SEEDS=[];
  const _o=[0,0,0,0],_o2=[0,0,0,0],_w=[0,0];
  function orbite(i,ph,rho,om,t,out){const a=om*t+ph,rr=rho*(1+.18*Math.sin(t*.7+ph*3));
    out[0]=N[i][0]+Math.cos(a)*rr;out[1]=N[i][1]+Math.sin(a)*rr*.72+(i===F?2*G:RB(i)*.14);
    const vx=-Math.sin(a)*om,vy=Math.cos(a)*om*.72;const ll=Math.hypot(vx,vy)||1;out[2]=vx/ll;out[3]=vy/ll;return out;}
  const rhoAq=e=>(8+3.3*(e.j%5))*RF/35;
  function versMonde(ob,x,y,out){out[0]=2000+(x-180)/ob.k0;out[1]=2000+(y-235)/ob.k0;return out;}
  function animer(ob,energie,g,dt){
    versMonde(ob,ob.qx,ob.qy,_w);
    ob.m.place(0,_w[0],_w[1]);
    ob.m.reglage({vit:ob.vit||1});ob.m.vise(0,_w[0]+ob.hx*320,_w[1]+ob.hy*320,g);
    ob.m.update(dt,ob.flow,energie);
    if(ob.dec&&NIVQ[niv][3]){ob.geo=ob.m.geo();const p=ob.m.pos(0),v=ob.lp?Math.hypot(p[0]-ob.lp[0],p[1]-ob.lp[1])/dt:0;ob.lp=[p[0],p[1]];ob.dec.update(dt*(1+Math.min(4,v/90)),ob.flow,ob.geo);}
  }
  function preparer(ob,x,y,hx,hy,n){
    versMonde(ob,x,y,_w);const p=ob.m.pos(0),x0=p[0],y0=p[1];n=n||150;
    for(let k=0;k<n;k++){const u=Math.min(1,k/(n*.47));ob.m.place(0,lerp(x0,_w[0],u),lerp(y0,_w[1],u));ob.m.vise(0,_w[0]+hx*320,_w[1]+hy*320,2.6);ob.m.update(H,ob.flow,.4);
      if(ob.dec){ob.geo=ob.m.geo();ob.dec.update(H,ob.flow,ob.geo);}}
  }
  function creerCreatures(fin){
    E.length=0;
    CRE.forEach((c,j)=>{
      const m=M.create(c[0]);m.init(WW,WH,700+j*131,{quality:.8,n:1,slot:0});
      const e={m,nm:c[0],lab:c[1],te:c[2],cible:c[3],duree:c[4],kT0:c[5],kT:c[5]*G,aEx:Math.atan2(N[10][1]-N[F][1],N[10][0]-N[F][0])+c[6],j,
        etat:'aqua',s:0,k:c[5]*G*.3,qx:N[F][0],qy:N[F][1],hx:1,hy:0,flo:[0,0],dec:(c[0]==='cells'||c[0]==='filament')?M.decor():null,geo:null,
        hist:new Float32Array(80),hn:0,hi:0,tE:0,em:0,ph:j*.83,base:1,vit:1,clip:F};
      e.ch=construireChemin(e.cible,e.aEx);
      let t1=0;for(let s=0;s<e.ch.tot;s+=1)t1+=1/profil(e.ch,s);e.base=t1/e.duree;
      e.flow=()=>e.flo;e.k0=e.kT;
      E.push(e);
    });
    SEEDS=CONT.map((c,j)=>{const src=E.find(e=>e.cible===c[3]);const m=M.create(src.nm);m.init(WW,WH,1900+j*77,{quality:.6,n:1,slot:0});
      return{cible:c[0],src:c[1],tA:c[2],m,nm:src.nm,k1:src.kT0*.36,k:src.kT0*.36*G,qx:N[c[0]][0],qy:N[c[0]][1],hx:1,hy:0,flo:[0,0],dec:null,ph:j*2.1,fait:false,vit:1,j,flow:null};});
    for(const s of SEEDS){s.flow=()=>s.flo;s.k0=s.k;}
    if(fin){                                                            // état final : chacune dans son monde
      for(const e of E){e.etat='colon';e.clip=e.cible;e.k=e.kT*.6;orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);e.qx=_o[0];e.qy=_o[1];preparer(e,_o[0],_o[1],_o[2],_o[3],70);}
      for(const s of SEEDS){s.fait=true;s.tA=-10;orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);s.qx=_o[0];s.qy=_o[1];s.kk=s.k;preparer(s,_o[0],_o[1],_o[2],_o[3],70);}
    } else {
      for(const s of SEEDS)preparer(s,N[s.cible][0],N[s.cible][1],1,0);
      for(const e of E){const om=(e.j%2?-1:1)*(.42+.06*e.j);orbite(F,e.ph,rhoAq(e),om,1.95,_o);preparer(e,_o[0],_o[1],_o[2],_o[3]);}
    }
  }
  function piloter(e){
    const t=T;let qx,qy,hx,hy,k,v=0,clip=-1;
    const kAq=e.kT*.30,kIn=e.kT*.6;
    const om=(e.j%2?-1:1)*(.42+.06*e.j),rho=rhoAq(e);
    if(e.etat==='aqua'&&t>=e.te-1.5)e.etat='sortie';
    if(e.etat==='aqua'){orbite(F,e.ph,rho,om,t,_o);qx=_o[0];qy=_o[1];hx=_o[2];hy=_o[3];k=kAq;v=rho*Math.abs(om);clip=F;}
    else if(e.etat==='sortie'){
      const u=(t-(e.te-1.5))/1.5;orbite(F,e.ph,rho,om,t,_o);
      const ex=Math.cos(e.aEx),ey=Math.sin(e.aEx),f=N[F],g9=9*G;
      if(u<.62){const w=sm(u/.62);const tx=f[0]+ex*(RF-g9),ty=f[1]+ey*(RF-g9);qx=lerp(_o[0],tx,w);qy=lerp(_o[1],ty,w);
        const dx=tx-qx,dy=ty-qy;const ll=Math.hypot(dx,dy);if(ll>1){hx=dx/ll;hy=dy/ll;}else{hx=ex;hy=ey;}k=lerp(kAq,kAq*1.25,w);}
      else{const w=(u-.62)/.38,we=Math.pow(w,1.5);const rr=lerp(RF-g9,RF+g9,we);qx=f[0]+ex*rr;qy=f[1]+ey*rr;hx=ex;hy=ey;k=lerp(kAq*1.25,e.kT*.72,we);
        poke(F,'c'+e.j,e.aEx,Math.max(0,rr-RF+g9)*sm(w/.35)+.9*Math.sin(t*60)*w,.42-.14*w);
        qx+=Math.sin(t*47+e.j)*.5*w;qy+=Math.cos(t*43)*.5*w;}
      clip=F;v=30;
      if(t>=e.te){percee(e);}
    }
    else if(e.etat==='voyage'){
      const dt=t-e.te;const burst=150*G*Math.exp(-dt*3.2);
      const vv=e.base*profil(e.ch,e.s)+burst*(1-sm(e.s/(e.ch.tot*.6)));
      e.s+=vv*H;v=vv/G;
      const p=surChemin(e.ch,e.s);const amp=2.2*G*sm(e.s/(50*G))*sm((e.ch.tot-e.s)/(50*G));const nx=-p[3],ny=p[2];const fl=amp*Math.sin(e.s/G*.055+e.ph)+amp*.4*Math.sin(t*3.1+e.ph);
      qx=p[0]+nx*fl;qy=p[1]+ny*fl;
      const pa=surChemin(e.ch,e.s+10*G);hx=pa[2];hy=pa[3];
      k=lerp(e.kT*.72,e.kT,eo(dt/.7));
      const sg=e.ch.S[idx(e.ch,e.s)];if(sg<11){lien[sg]=1;lienRes[sg]=Math.max(lienRes[sg],.34);}
      for(let i=0;i<11;i++){if(i===e.cible)continue;const dx=qx-N[i][0],dy=qy-N[i][1],d=Math.hypot(dx,dy);
        if(d<RB(i)+16*G){poke(i,'p'+e.j,Math.atan2(dy,dx),-2.6*G*(1-clamp((d-RB(i)-4*G)/(12*G),0,1)),.5);B[i].glint=Math.max(B[i].glint,.55);B[i].wob=Math.max(B[i].wob,.35);}}
      e.em+=H*(26+v*.12);
      while(e.em>1){e.em--;const bx=qx-hx*9*k/.4+(R()-.5)*4,by=qy-hy*9*k/.4+(R()-.5)*4,r=R();
        emet(bx,by,-hx*10*G+(R()-.5)*14,-hy*10*G+(R()-.5)*14,.8+R()*1.1,r<.12?1.5:.6+R()*.8,r<.1?1:0,r<.35?1:r<.5?2:0,0);}
      if(e.s>=e.ch.tot-.5){e.etat='entree';e.tE=t;const q=surChemin(e.ch,e.ch.tot);e.ex=q[0];e.ey=q[1];e.ax=q[2];e.ay=q[3];e.ca=Math.atan2(e.ey-N[e.cible][1],e.ex-N[e.cible][0]);
        B[e.cible].glint=1;souffle=Math.max(souffle,.35);}
    }
    else if(e.etat==='entree'){
      const c=e.cible,u=t-e.tE,r=RB(c);
      if(u<.55){const w=sm(u/.55);const pen=r*.52*w;qx=e.ex+e.ax*pen;qy=e.ey+e.ay*pen;hx=e.ax;hy=e.ay;k=lerp(e.kT,e.kT*.66,w);
        poke(c,'e'+e.j,e.ca,-pen*.95,.42+.1*w);v=40;}
      else{
        if(!e.pop){entree(e);}
        const w=sm((u-.55)/1.05);orbite(c,e.ph,r*.36,(e.j%2?-1:1)*.5,t,_o);
        const sx=e.ex+e.ax*r*.52,sy=e.ey+e.ay*r*.52;qx=lerp(sx,_o[0],w);qy=lerp(sy,_o[1],w);
        hx=lerp(e.ax,_o[2],w);hy=lerp(e.ay,_o[3],w);const ll=Math.hypot(hx,hy)||1;hx/=ll;hy/=ll;k=lerp(e.kT*.66,kIn,eo((u-.55)/.8));clip=c;v=20;
        if(u>1.6)e.etat='colon';}
    }
    else{const c=e.cible;orbite(c,e.ph,RB(c)*.36,(e.j%2?-1:1)*.5,t,_o);qx=_o[0];qy=_o[1];hx=_o[2];hy=_o[3];k=kIn;clip=c;v=8;}
    e.qx=qx;e.qy=qy;e.hx=hx;e.hy=hy;e.k=k;e.clip=clip;
    const V=Math.min(40,v*.25);e.flo[0]=-hx*V;e.flo[1]=-hy*V;
    e.vit=e.etat==='voyage'?1.6:e.etat==='sortie'?1.5:1;
    if(e.etat==='voyage'){e.hist[e.hi*2]=qx;e.hist[e.hi*2+1]=qy;e.hi=(e.hi+1)%40;e.hn=Math.min(40,e.hn+1);}
    else if(e.hn>0)e.hn=Math.max(0,e.hn-1);
  }
  function percee(e){
    e.etat='voyage';e.s=0;
    const f=N[F],ex=Math.cos(e.aEx),ey=Math.sin(e.aEx),x=f[0]+ex*(RF+9*G),y=f[1]+ey*(RF+9*G);
    relache(F,'c'+e.j,-70);
    B[F].wob=1;B[F].flash=1;B[F].cicat.push({a:e.aEx,t:T,sd:e.j*7+3});
    gerbe(x,y,e.aEx,1.1,34,95,0,0,1.1);gerbe(x,y,e.aEx+Math.PI,2.2,14,50,1,1,.8);
    ANN.push({x,y,t:T,d:.8,r0:3,r1:34*G,c:CY,w:1.5},{x:f[0],y:f[1],t:T+.06,d:1.1,r0:RF+2,r1:RF+26*G,c:PER,w:.7});
    ECL.push({x,y,t:T,d:.55,s:70*G,g:S2.cy},{x,y,t:T,d:.25,s:34*G,g:S2.pe});
    RAYS.push({x,y,a:e.aEx,t:T,d:.5,sd:e.j});
    VAGUES.push({x:f[0],y:f[1],t:T,v:330*G,f:.9});
    souffle=1;flashEcran=.18;niveauF=Math.max(.5,niveauF-.05);
    legende(e.lab+'  →  '+NOMS[e.cible],1);
    try{Audio1.playSfx('colo_perce',1);}catch(_){}
  }
  function entree(e){
    e.pop=1;const c=e.cible,b=B[c];
    try{Audio1.playSfx('colo_entree',1,c);}catch(_){}
    relache(c,'e'+e.j,170);b.wob=1;b.flash=1;b.colT=T;b.glint=1;
    gerbe(e.ex,e.ey,e.ca,1.6,30,70,0,1,1);gerbe(N[c][0],N[c][1],0,TAU,22,34,4+c,1,1.2);
    ANN.push({x:N[c][0],y:N[c][1],t:T,d:1.1,r0:RB(c),r1:RB(c)+34*G,c:CY,w:1.4},{x:N[c][0],y:N[c][1],t:T+.12,d:.9,r0:RB(c)*.6,r1:RB(c)+8*G,c:COL[c],w:.7});
    ECL.push({x:N[c][0],y:N[c][1],t:T,d:.7,s:RB(c)*3.4,g:S2.cy});
    VAGUES.push({x:N[c][0],y:N[c][1],t:T,v:260*G,f:.5});
    souffle=Math.max(souffle,.6);compteur();
  }
  function majContagion(){
    for(const c of CONT){const tA=c[2],dur=1.5;
      for(let q=0;q<2;q++){const id=c[0]*10+q;let g=GRAINES.find(o2=>o2.id===id);
        if(!g&&T>=tA-dur){const lk=lienEntre(c[1][q],c[0]);const a=lk.pts[0],a2=lk.pts[Math.min(1,lk.pts.length-1)];
          g={id,lk,t0:tA-dur+q*.12,dur:dur-q*.12,x:a[0],y:a[1],lien:Math.min(c[0],c[1][q]),hist:[],fait:false};
          GRAINES.push(g);B[c[1][q]].pulse=1;gerbe(a[0],a[1],Math.atan2(a2[1]-a[1],a2[0]-a[0]),1.2,10,40,0,1,.8);}
        if(g&&!g.fait){const u=eo((T-g.t0)/g.dur),p=surLien(g.lk,u);g.x=p[0];g.y=p[1];lien[g.lien]=1;lienRes[g.lien]=Math.max(lienRes[g.lien],.34);
          g.hist.push(g.x,g.y);if(g.hist.length>36)g.hist.splice(0,2);
          if(R()<.7)emet(g.x+(R()-.5)*3,g.y+(R()-.5)*3,(R()-.5)*12,(R()-.5)*12,.7+R()*.6,.6+R()*.8,R()<.15?1:0,R()<.4?1:2,0);
          if(T>=g.t0+g.dur)g.fait=true;}}
      const s=SEEDS.find(o2=>o2.cible===c[0]);
      if(!s.fait&&T>=tA){s.fait=true;const b=B[c[0]];b.colT=T;b.wob=1;b.flash=1;b.glint=1;b.pokes.push({id:'z',a:-1.2,d:3*G,v:60,w:.6,drive:false});
        gerbe(N[c[0]][0],N[c[0]][1],0,TAU,30,48,0,1,1.1);ANN.push({x:N[c[0]][0],y:N[c[0]][1],t:T,d:1,r0:RB(c[0]),r1:RB(c[0])+30*G,c:CY,w:1.3});
        ECL.push({x:N[c[0]][0],y:N[c[0]][1],t:T,d:.6,s:60*G,g:S2.cy});souffle=Math.max(souffle,.4);VAGUES.push({x:N[c[0]][0],y:N[c[0]][1],t:T,v:240*G,f:.4});compteur();}
    }
  }
  function piloterSeed(s){if(!s.fait)return;const c=s.cible,u=T-s.tA;orbite(c,s.ph,RB(c)*.3,(s.j%2?1:-1)*.6,T,_o2);
    s.qx=_o2[0];s.qy=_o2[1];s.hx=_o2[2];s.hy=_o2[3];s.kk=lerp(s.k*.3,s.k,eo(u/1.2));s.flo[0]=0;s.flo[1]=0;}
  /* ---------- texte (DOM, au-dessus de l'en-tête de la carte) ---------- */
  function legende(t,fl){if(!leg||LEGT===t)return;LEGT=t;leg.style.opacity='0';leg.style.transform='translateY(4px)';
    setTimeout(()=>{if(detruit||LEGT!==t)return;leg.textContent=t;leg.classList.toggle('fl',!!fl);leg.style.opacity='1';leg.style.transform='none';},320);}
  function nCol(){let n=0;for(let i=0;i<11;i++)if(B[i].colT>-1e8)n++;return n;}
  function compteur(){if(!cpt)return;const n=nCol();cpt.firstChild.textContent=LG.col+'  '+n+' / 11';jau.style.width=(n/11*100).toFixed(1)+'%';}
  function scenario(){
    if(T<4.2)legende(LG.flu);
    else if(T<5.6)legende(LG.pousse);
    else if(T>=7.6&&T<8.9&&LEGT.indexOf('→')>=0)legende(LG.une);
    else if(T>=21&&T<26.9&&LEGT.indexOf('→')>=0&&T-19.1>2.2)legende(LG.touche);
    else if(T>=26.9&&T<29.6)legende(LG.cont);
    else if(T>=29.6){legende(LG.fin);if(!legende.fs){legende.fs=1;try{Audio1.playSfx('colo_fin',1);}catch(_){}}}
    if(cpt&&T>2.3&&cpt.style.opacity!=='1'){cpt.style.opacity='1';compteur();}
  }
  /* ---------- pas de simulation ---------- */
  function pas(){
    T+=H;
    scenario();
    for(let i=0;i<11;i++){lien[i]=Math.max(lienRes[i],lien[i]-H*.55);}
    if(T<2.2){lien[10]=1;lienRes[10]=.22;}
    for(const e of E){if(T<1.95)continue;piloter(e);animer(e,e.etat==='voyage'?.7:.45,2.6,H);}
    majContagion();
    for(const s of SEEDS){if(!s.fait)continue;piloterSeed(s);animer(s,.4,2.4,H);}
    if(T>=2.1&&!B[F].rev){B[F].rev=1;const f=N[F];
      ECL.push({x:f[0],y:f[1],t:T,d:1,s:190*G,g:S2.cy},{x:f[0],y:f[1],t:T,d:.4,s:70*G,g:S2.pe});
      ANN.push({x:f[0],y:f[1],t:T,d:1.4,r0:8,r1:120*G,c:CY,w:2},{x:f[0],y:f[1],t:T+.12,d:1.6,r0:RF,r1:RF+50*G,c:PER,w:1});
      gerbe(f[0],f[1],0,TAU,90,120,0,1,1.4);VAGUES.push({x:f[0],y:f[1],t:T,v:300*G,f:1});souffle=1;flashEcran=.22;B[F].wob=1;
      for(let i=0;i<11;i++)B[i].wob=Math.max(B[i].wob,.3);}
    for(const e of E){for(const db of (e.j===0?[1.75,1.3,.85,.45]:[1.25,.8,.42])){const tb=e.te-db;if(T>=tb&&T-H<tb){B[F].pulse=Math.max(B[F].pulse,e.j===0?.9:.7);B[F].glint=1;
      ECL.push({x:N[F][0],y:N[F][1],t:T,d:.45,s:RF*3.6,g:S2.cy});}}}
    let tens=0;for(const e of E)if(e.etat==='sortie'){const u=(T-(e.te-1.5))/1.5;tens=Math.max(tens,sm((u-.3)/.7));}
    assomb+=(tens*.2-assomb)*Math.min(1,H*4);
    communs(H);
    for(const v of VAGUES){const rr=(T-v.t)*v.v,a=v.f*Math.exp(-(T-v.t)*1.1);for(let i=0;i<12;i++){const d=Math.hypot(N[i][0]-v.x,N[i][1]-v.y);const g=a*gss(d-rr,26*G);if(g>B[i].glint)B[i].glint=g;}}
  }
  function communs(dt){
    majBulles();
    for(let i=0;i<pn;i++){P.a[i]+=dt;if(P.a[i]>=P.v[i]){pn--;for(const k in P)P[k][i]=P[k][pn];i--;continue;}
      const kk=P.k[i],dr=kk===2?.93:.965;P.vx[i]*=dr;P.vy[i]*=dr;if(kk===3){P.vy[i]-=dt*6;P.vx[i]+=Math.sin(P.a[i]*3+P.ph[i])*dt*8;}
      P.x[i]+=P.vx[i]*dt;P.y[i]+=P.vy[i]*dt;}
    for(let i=0;i<12;i++){const b=B[i];if(b.colT<-1e8||T-b.colT<2)continue;b.spT-=dt;
      if(b.spT<=0){b.spT=(mode==='final'?2.4:1.1)+R()*2.2;const a=-Math.PI/2+(R()-.5)*1.4,r=RB(i);emet(N[i][0]+Math.cos(a)*r,N[i][1]+Math.sin(a)*r,Math.cos(a)*8,Math.sin(a)*8-4,2.4+R()*1.6,1.1+R()*.8,3,R()<.5?0:2,1);}}
    souffle*=Math.exp(-dt*2.2);flashEcran=Math.max(0,flashEcran-dt*.9);
    for(let k=VAGUES.length-1;k>=0;k--)if(T-VAGUES[k].t>2.2)VAGUES.splice(k,1);
    for(let k=ANN.length-1;k>=0;k--)if(T-ANN[k].t>ANN[k].d)ANN.splice(k,1);
    for(let k=ECL.length-1;k>=0;k--)if(T-ECL[k].t>ECL[k].d)ECL.splice(k,1);
    for(let k=RAYS.length-1;k>=0;k--)if(T-RAYS[k].t>RAYS[k].d)RAYS.splice(k,1);
  }
  /* état final léger : créatures dans leur monde, spores, lueur cyan */
  function pasFinal(dt){
    T+=dt;
    for(const e of E){piloter(e);animer(e,.3,2.4,dt);}
    for(const s of SEEDS){piloterSeed(s);animer(s,.3,2.4,dt);}
    communs(dt);
  }
  /* séquence abrégée (mouvement réduit) : les mondes se colorent l'un après l'autre, sans voyage */
  const ORD=[10,7,1,9,4,0,5,2,3,6,8];
  function pasAbrege(dt){
    T+=dt;const u=T-T0;
    if(u<1.2)legende(LG.flu);else if(u<4.6)legende(LG.touche);else legende(LG.fin);
    if(cpt&&u>.6&&cpt.style.opacity!=='1'){cpt.style.opacity='1';compteur();}
    ORD.forEach((i,k)=>{if(B[i].colT<-1e8&&u>=1+k*.3){B[i].colT=T;compteur();}});
    majBulles();
  }
  /* ---------- rendu ---------- */
  function dessinerLiens(){
    ctx.lineCap='round';ctx.lineJoin='round';ctx.globalCompositeOperation='lighter';
    for(let i=0;i<11;i++){const lv=lien[i];if(lv<=.01)continue;const pts=LK[i];if(!pts||pts.length<2)continue;
      ctx.strokeStyle=GR.lien[i];ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let j=1;j<pts.length;j++)ctx.lineTo(pts[j][0],pts[j][1]);
      ctx.globalAlpha=lv*.22;ctx.lineWidth=5.5;ctx.stroke();ctx.globalAlpha=lv*.75;ctx.lineWidth=1.1;ctx.stroke();}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function colDe(i){const b=B[i];if(b.colT<-1e8)return 0;return mode==='final'&&b.colT<0?1:clamp((T-b.colT)/2.5,0,1);}
  function dessinerBulleFond(i,rev,A){
    const b=B[i],x=N[i][0],y=N[i][1],r=RB(i)*rev,col=colDe(i);
    ctx.save();ctx.translate(x,y);
    ctx.globalCompositeOperation='lighter';
    const fin=mode==='final';
    ctx.globalAlpha=A*clamp((fin?.1:.16)+.3*b.glint+.4*b.flash+.2*col+(i===F?(fin?.12:.3)+.4*b.pulse:0),0,1);
    const hs=r*2.44;ctx.drawImage(i===F||col>.5?S2.RCY:RINGW[i],-hs,-hs,hs*2,hs*2);
    ctx.globalCompositeOperation='source-over';ctx.globalAlpha=A;
    ctx.scale(rev,rev);
    trace(i);ctx.fillStyle=GR.body[i];ctx.fill();
    if(col>0||i===F){ctx.globalAlpha=A*(i===F?.5:col*.45);ctx.fillStyle=GR.cyb[i];ctx.fill();}
    if(NIVQ[niv][2]){ctx.save();ctx.clip();ctx.globalCompositeOperation='lighter';const R0b=RB(i);
      ctx.rotate(T*.18+i*1.3);ctx.lineWidth=R0b*.42;ctx.globalAlpha=.07*A;ctx.strokeStyle=GR.iri;ctx.beginPath();ctx.arc(0,0,R0b*.78,0,2.3);ctx.stroke();
      ctx.rotate(2.6-T*.07);ctx.globalAlpha=.05*A;ctx.beginPath();ctx.arc(R0b*.1,0,R0b*.62,0,1.8);ctx.stroke();ctx.restore();}
    ctx.restore();
    const lvl=i===F?niveauF*rev:b.lvl;
    if(lvl>.01){const R0b=RB(i);ctx.save();ctx.translate(x,y);ctx.scale(rev,rev);trace(i);ctx.clip();
      const yl=R0b-lvl*2*R0b,amp=((i===F?.9:.6)+2.6*Math.exp(-Math.max(0,T-b.colT)*.9)*(b.colT>=0?1:0)+1.6*b.wob)*G;
      const MY=(xx)=>yl+amp*Math.sin(xx/G*.15+T*1.8+i)+amp*.35*Math.sin(xx/G*.29-T*2.4);
      ctx.beginPath();ctx.moveTo(-R0b-3,R0b+3);for(let k=0;k<=18;k++){const xx=-R0b-3+(2*R0b+6)*k/18;ctx.lineTo(xx,MY(xx));}
      ctx.lineTo(R0b+3,R0b+3);ctx.closePath();ctx.fillStyle=GR.liq[i];const AL=A*(fin?.62:1);ctx.globalAlpha=AL*(i===F?1:clamp(lvl/.3,0,1));ctx.fill();
      ctx.globalCompositeOperation='lighter';ctx.beginPath();for(let k=0;k<=18;k++){const xx=-R0b-3+(2*R0b+6)*k/18,yy=MY(xx);k?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);}
      ctx.strokeStyle='rgba(170,240,245,.45)';ctx.lineWidth=.7;ctx.globalAlpha=AL;ctx.stroke();ctx.globalAlpha=.08*AL;ctx.lineWidth=3;ctx.stroke();
      ctx.fillStyle='rgba(200,250,250,.7)';
      for(let k=0;k<4;k++){const ph=((T*.32+k*.27+i*.13)%1),xx=Math.sin(k*2.4+i)*R0b*.55+Math.sin(T*2+k)*1.2,yy=lerp(R0b*.9,yl+2,ph);ctx.globalAlpha=.5*AL*Math.sin(ph*Math.PI);ctx.beginPath();ctx.arc(xx,yy,.7+.4*(k%2),0,TAU);ctx.fill();}
      ctx.restore();}
  }
  function dessinerBulleVerre(i,rev,A){
    const b=B[i],R0b=RB(i),col=colDe(i);
    ctx.save();ctx.translate(N[i][0],N[i][1]);ctx.scale(rev,rev);
    trace(i);
    ctx.globalAlpha=A;ctx.strokeStyle='rgba(2,8,14,.35)';ctx.lineWidth=2.2;ctx.stroke();
    ctx.save();ctx.rotate(T*.22+i*.9);ctx.strokeStyle=GR.iri;ctx.lineWidth=1.25;ctx.globalAlpha=A*clamp(.45+.4*b.glint+.4*b.flash,0,1);ctx.stroke();ctx.restore();
    ctx.globalAlpha=A;ctx.strokeStyle=i===F||col>0?'rgba(170,240,245,'+(.25+.35*Math.max(col,i===F?1:0))+')':rgba(COL[i],.35);ctx.lineWidth=.6;ctx.stroke();
    ctx.globalCompositeOperation='lighter';
    const g=.55+.45*b.glint;
    ctx.save();ctx.rotate(-.72);ctx.globalAlpha=.5*g*A;ctx.drawImage(S2.SPEC,-R0b*.42,-R0b*.78,R0b*.84,R0b*.36);ctx.restore();
    ctx.lineCap='round';ctx.strokeStyle='rgba(245,252,255,1)';ctx.globalAlpha=.55*g*A;ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(0,0,R0b*.8,Math.PI*1.1,Math.PI*1.38);ctx.stroke();
    ctx.globalAlpha=.22*g*A;ctx.lineWidth=.9;ctx.beginPath();ctx.arc(0,0,R0b*.8,Math.PI*1.44,Math.PI*1.5);ctx.stroke();
    ctx.globalAlpha=.2*g*A;ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,R0b*.84,Math.PI*.12,Math.PI*.32);ctx.stroke();
    if(b.glint>.05){ctx.globalAlpha=.9*b.glint*A;ctx.drawImage(S2.pe,-R0b*.55-5,-R0b*.52-5,10,10);}
    if(i===F){for(const e of E){if(e.etat!=='sortie')continue;const u=(T-(e.te-1.5))/1.5;if(u<.6)continue;const w=sm((u-.6)/.4),rr=RF+Math.max(0,(lerp(RF-9*G,RF+9*G,Math.pow((u-.62)/.38,1.5))-RF+9*G))*.95;
      const s=(10+26*w)*G;ctx.globalAlpha=.55*w;ctx.drawImage(S2.cy,Math.cos(e.aEx)*rr-s/2,Math.sin(e.aEx)*rr-s/2,s,s);ctx.globalAlpha=.6*w*w;ctx.drawImage(S2.pe,Math.cos(e.aEx)*rr-3,Math.sin(e.aEx)*rr-3,6,6);}
      for(const c of b.cicat){const u=T-c.t,a=.25+.75*Math.exp(-u*1.4);const r0=rng(c.sd);ctx.strokeStyle='rgba(200,250,252,1)';ctx.globalAlpha=a*.8*A;ctx.lineWidth=.7;ctx.beginPath();
        for(let k=0;k<3;k++){let q=c.a+(r0()-.5)*.12,rr=R0b+(r0()-.5)*2;ctx.moveTo(Math.cos(q)*rr,Math.sin(q)*rr);for(let s=0;s<3;s++){q+=(r0()-.5)*.22;rr+=(r0()-.6)*5;ctx.lineTo(Math.cos(q)*rr,Math.sin(q)*rr);}}ctx.stroke();
        if(u<1.2){ctx.globalAlpha=(1-u/1.2)*A;ctx.drawImage(S2.cy,Math.cos(c.a)*R0b-9,Math.sin(c.a)*R0b-9,18,18);}}}
    if(col>0){const br=.5+.5*Math.sin(T*1.6+i);ctx.strokeStyle='rgb(127,216,230)';ctx.globalAlpha=A*col*(.18+.16*br);ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,R0b+4.5+br,0,TAU);ctx.stroke();
      ctx.globalAlpha=A*col*.08;ctx.lineWidth=4;ctx.stroke();}
    if(b.flash>0){ctx.globalAlpha=b.flash*.5*A;ctx.drawImage(i===F||col>0?S2.cy:GLW[i],-R0b*1.4,-R0b*1.4,R0b*2.8,R0b*2.8);}
    ctx.restore();
  }
  function revF(){if(mode==='final'||mode==='abrege')return 1;if(T<2.1)return 0;return Math.max(.02,eback((T-2.1)/.75));}
  function dessinerCreature(ob,clip,alpha){
    if(alpha<=.01)return;
    ctx.save();
    if(clip>=0){const rv=clip===F?revF():1;ctx.translate(N[clip][0],N[clip][1]);ctx.scale(rv,rv);trace(clip);ctx.clip();ctx.scale(1/rv,1/rv);ctx.translate(-N[clip][0],-N[clip][1]);}
    const k=ob.kk||ob.k,p=ob.m.pos(0);
    ctx.translate(ob.qx,ob.qy);ctx.scale(k,k);ctx.translate(-p[0],-p[1]);
    ob.m.draw(ctx,alpha);
    if(ob.dec&&ob.geo&&NIVQ[niv][3])ob.dec.draw(ctx,ob.geo,.85*alpha);
    ctx.restore();
  }
  function sillage(e){
    if(e.hn<3||!NIVQ[niv][4])return;
    ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle='rgb(127,216,230)';
    const n=e.hn,fade=e.etat==='colon'?0:1;
    let px=e.hist[((e.hi-1+40)%40)*2],py=e.hist[((e.hi-1+40)%40)*2+1];
    for(let j=2;j<n;j++){const q=((e.hi-j+40)%40)*2,x=e.hist[q],y=e.hist[q+1],u=j/n;
      ctx.globalAlpha=.32*(1-u)*fade;ctx.lineWidth=(3.2*(1-u)+.3)*G;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(x,y);ctx.stroke();px=x;py=y;}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function particules(l2){
    ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
    for(let i=0;i<pn;i++){if(P.l[i]!==l2)continue;const u=P.a[i]/P.v[i],k=P.k[i];let a=(1-u)*(u<.08?u/.08:1);
      const x=P.x[i],y=P.y[i],s=P.s[i];ctx.fillStyle=PCOL[P.c[i]];
      if(k===0){a*=.55+.45*Math.sin(P.a[i]*14+P.ph[i]);ctx.globalAlpha=clamp(a,0,1);ctx.fillRect(x-s/2,y-s/2,s,s);}
      else if(k===1){ctx.globalAlpha=clamp(a*(.6+.4*Math.sin(P.a[i]*9+P.ph[i])),0,1);const L=s*2.6;ctx.strokeStyle=PCOL[P.c[i]];ctx.lineWidth=.55;ctx.beginPath();ctx.moveTo(x-L,y);ctx.lineTo(x+L,y);ctx.moveTo(x,y-L);ctx.lineTo(x,y+L);ctx.stroke();ctx.fillRect(x-.7,y-.7,1.4,1.4);}
      else if(k===2){ctx.globalAlpha=clamp(a,0,1);ctx.strokeStyle=PCOL[P.c[i]];ctx.lineWidth=s*.7;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-P.vx[i]*.05,y-P.vy[i]*.05);ctx.stroke();}
      else{const f=Math.sin(Math.PI*Math.min(1,u*1.3));ctx.globalAlpha=clamp(f*.5,0,1);ctx.drawImage(P.c[i]===2?S2.lu:S2.cy,x-s*3,y-s*3,s*6,s*6);ctx.globalAlpha=clamp(f*.9,0,1);ctx.fillRect(x-s*.4,y-s*.4,s*.8,s*.8);}}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function effets(){
    ctx.globalCompositeOperation='lighter';
    for(const a of ANN){const u=(T-a.t)/a.d;if(u<0)continue;const r=lerp(a.r0,a.r1,eo(u));ctx.strokeStyle=rgba(a.c,1);ctx.globalAlpha=(1-u)*(1-u)*.8;ctx.lineWidth=a.w*(1-u*.6);ctx.beginPath();ctx.arc(a.x,a.y,r,0,TAU);ctx.stroke();
      ctx.globalAlpha=(1-u)*(1-u)*.12;ctx.lineWidth=a.w*5;ctx.stroke();}
    for(const f of ECL){const u=(T-f.t)/f.d;const s=f.s*(.6+.4*eo(u));ctx.globalAlpha=(1-u)*(1-u);ctx.drawImage(f.g,f.x-s/2,f.y-s/2,s,s);}
    ctx.lineCap='round';
    for(const r of RAYS){const u=(T-r.t)/r.d,r0=rng(r.sd+11);ctx.strokeStyle='rgb(220,248,250)';
      for(let k=0;k<9;k++){const a=r.a+(r0()-.5)*1.5,L=(18+r0()*34)*G,d0=4+L*eo(u)*.6;ctx.globalAlpha=(1-u)*(.35+r0()*.4);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(r.x+Math.cos(a)*d0,r.y+Math.sin(a)*d0);ctx.lineTo(r.x+Math.cos(a)*(d0+L*(1-u*.5)),r.y+Math.sin(a)*(d0+L*(1-u*.5)));ctx.stroke();}}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  function dessinerAnnonceF(){
    if(T>1.5&&T<2.5){const u=(T-1.5)/.6,f=N[F],a=T<2.1?eo(u):1-(T-2.1)/.4;ctx.globalCompositeOperation='lighter';ctx.globalAlpha=clamp(a,0,1);
      const s=(8+40*eo(u))*G;ctx.drawImage(S2.cy,f[0]-s/2,f[1]-s/2,s,s);ctx.drawImage(S2.pe,f[0]-4,f[1]-4,8,8);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
  }
  function rendu(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,l,h);
    const fin=mode==='final',ab=mode==='abrege';
    const A=fin?(tFinal<0?.85:passeF?.85*clamp((T-tFinal)/.8,0,1):.85+.15*(1-clamp((T-tFinal)/2,0,1))):ab?sm((T-T0)/.6):sm((T-T0)/.9);
    if(assomb>.005){ctx.fillStyle='rgba(1,4,8,'+assomb+')';ctx.fillRect(0,0,l,h);}
    if(!fin&&!ab)dessinerLiens();
    particules(0);
    const rv=revF();
    for(let i=0;i<12;i++)forme(i,1);
    // pendant la séquence, seules les bulles touchées (et Fluides) prennent la membrane pleine ; les autres restent légères
    for(let i=0;i<11;i++)dessinerBulleFond(i,1,A*(fin||ab?Math.max(.15,colDe(i)):.55+.45*colDe(i)));
    if(rv>0)dessinerBulleFond(F,rv,A);
    if(!fin&&!ab)dessinerAnnonceF();
    const aq=clamp((T-2.2)/.8,0,1);
    if(!ab){for(const e of E){if(T<1.95)break;if(e.clip>=0)dessinerCreature(e,e.clip,(e.clip===F&&!fin?aq*1.2:1.2)*(fin?A/.85:1));}
      for(const s of SEEDS)if(s.fait)dessinerCreature(s,s.cible,clamp((T-s.tA)/.8,0,1)*(fin?A/.85:1));}
    else if(T-T0>4.4){const a=sm((T-T0-4.4)/.8);for(const e of E)dessinerCreature(e,e.cible,a);for(const s of SEEDS)dessinerCreature(s,s.cible,a);}
    for(let i=0;i<11;i++)dessinerBulleVerre(i,1,A*(fin||ab?Math.max(.3,colDe(i)):.6+.4*colDe(i)));
    if(rv>0)dessinerBulleVerre(F,rv,A);
    if(!fin&&!ab){
      for(const e of E)if(e.etat==='voyage'||e.etat==='entree'||(e.etat==='colon'&&e.hn>0))sillage(e);
      for(const g of GRAINES){if(g.fait&&T-g.t0-g.dur>.6)continue;const hh=g.hist,fa=g.fait?1-(T-g.t0-g.dur)/.6:1;ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle='rgb(127,216,230)';
        for(let j=2;j<hh.length;j+=2){const u=j/hh.length;ctx.globalAlpha=.5*u*fa;ctx.lineWidth=2.2*u*G;ctx.beginPath();ctx.moveTo(hh[j-2],hh[j-1]);ctx.lineTo(hh[j],hh[j+1]);ctx.stroke();}
        if(!g.fait){ctx.globalAlpha=1;ctx.drawImage(S2.cy,g.x-9*G,g.y-9*G,18*G,18*G);ctx.drawImage(S2.pe,g.x-3,g.y-3,6,6);}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
      for(const e of E){if(e.clip>=0||T<1.95)continue;
        const s=78*e.k;ctx.globalAlpha=.46;ctx.drawImage(S2.dark,e.qx-s,e.qy-s,s*2,s*2);
        ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.16;ctx.drawImage(S2.cy,e.qx-s*.7,e.qy-s*.7,s*1.4,s*1.4);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;
        dessinerCreature(e,-1,1.3);}
    }
    particules(1);
    effets();
    if(flashEcran>.005){ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(127,216,230,'+flashEcran*.4+')';ctx.fillRect(0,0,l,h);ctx.globalCompositeOperation='source-over';}
  }
  /* ---------- fin / passer ---------- */
  let fini=false;
  function annoncerFin(raison){if(fini)return;fini=true;try{if(o.fin)o.fin(raison);}catch(e){}}
  function nettoyerUI(){
    if(prise){prise.remove();prise=null;}
    if(bP){bP.remove();bP=null;}
    if(hud){const hd=hud;hud=null;hd.style.opacity='0';setTimeout(()=>hd.remove(),600);}
    if(sous)sous.style.opacity='';
  }
  function versFinal(raison){
    annoncerFin(raison);
    mode='final';nettoyerUI();
    for(let i=0;i<12;i++){const b=B[i];if(i<11&&b.colT<-1e8)b.colT=T-10;b.pokes.length=0;b.flash=0;}
    VAGUES.length=0;ANN.length=0;ECL.length=0;RAYS.length=0;GRAINES.length=0;assomb=0;flashEcran=0;
    for(const e of E){if(e.etat!=='colon'){e.etat='colon';e.hn=0;orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);preparer(e,_o[0],_o[1],_o[2],_o[3],40);}}
    for(const s of SEEDS){if(!s.fait){s.fait=true;s.tA=T-5;orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);preparer(s,_o[0],_o[1],_o[2],_o[3],40);}}
    tFinal=T;passeF=raison==='passe';
    if(sobre){rendu();arreterBoucle();}
  }
  function sauter(){if(mode==='final'||detruit)return;versFinal('passe');}
  /* ---------- boucle + gouverneur ---------- */
  const mes={n:0,s:0,fen:[],max:0,t0:0};let fige=false;
  function image(now){
    raf=0;if(detruit)return;
    if(!R0.isConnected){detruire();return;}
    try{
      const t0=performance.now();
      if(!regeo()){raf=racine.requestAnimationFrame(image);return;}
      const dt=Math.min(.1,Math.max(0,(now-tPrev)/1000));tPrev=now;
      if(mode==='sequence'){acc+=dt;let n=0;while(acc>=H&&n<4){pas();acc-=H;n++;}if(n===4)acc=0;if(T>=T_FIN)versFinal('fin');rendu();}
      else if(mode==='abrege'){pasAbrege(dt);rendu();if(T-T0>5.8)versFinal('fin');}
      else{nImg++;if(nImg%2===0){pasFinal(Math.min(1/15,dt*2||1/30));rendu();}else{if(raf===0)raf=racine.requestAnimationFrame(image);return;}}
      const ms=performance.now()-t0;mes.n++;mes.s+=ms;mes.max=Math.max(mes.max,ms);mes.fen.push(ms);
      if(!mes.t0)mes.t0=now;
      if(mes.fen.length>=45||(mes.fen.length>=8&&now-mes.t0>1500)){const moy=mes.fen.reduce((a,b)=>a+b,0)/mes.fen.length;mes.fen=[];mes.t0=now;
        if(moy>8&&niv<NIVQ.length-1){niv++;tailleCanvas();if(pn>NIVQ[niv][0])pn=NIVQ[niv][0];}}
    }catch(e){try{console.warn('QXCREA',e);}catch(e2){}annoncerFin('erreur');detruire();return;}
    if(!fige&&!detruit)raf=racine.requestAnimationFrame(image);
  }
  function arreterBoucle(){fige=true;if(raf){racine.cancelAnimationFrame(raf);raf=0;}}
  function surVis(){if(detruit)return;if(document.hidden){if(raf){racine.cancelAnimationFrame(raf);raf=0;}}else if(!raf&&!fige){tPrev=performance.now();raf=racine.requestAnimationFrame(image);}}
  function surTaille(){if(!detruit&&fige){setTimeout(()=>{if(!detruit&&regeo()){if(mode==='final')pasFinal(1/60);rendu();}},160);}}
  function detruire(){
    if(detruit)return;detruit=true;if(raf)racine.cancelAnimationFrame(raf);raf=0;
    document.removeEventListener('visibilitychange',surVis);racine.removeEventListener('resize',surTaille);
    nettoyerUI();if(hud)hud.remove();cv.remove();if(cur===ctl)cur=null;
  }
  /* ---------- démarrage ---------- */
  if(!regeo()){detruire();return null;}
  R=rng(20261120);
  if(mode==='final'){T=40;for(let i=0;i<11;i++)B[i].colT=-5;niveauF=.5;creerCreatures(true);}
  else creerCreatures(false);
  if(mode==='abrege'){niveauF=.5;for(const e of E){e.etat='colon';e.clip=e.cible;e.k=e.kT*.6;}for(const s of SEEDS){s.fait=true;s.tA=-10;s.kk=s.k;}
    for(const e of E){orbite(e.cible,e.ph,RB(e.cible)*.36,(e.j%2?-1:1)*.5,T,_o);e.qx=_o[0];e.qy=_o[1];preparer(e,_o[0],_o[1],_o[2],_o[3],60);}
    for(const s of SEEDS){orbite(s.cible,s.ph,RB(s.cible)*.3,(s.j%2?1:-1)*.6,T,_o);s.qx=_o[0];s.qy=_o[1];preparer(s,_o[0],_o[1],_o[2],_o[3],60);}}
  document.addEventListener('visibilitychange',surVis);racine.addEventListener('resize',surTaille);
  inst.surDetruire(detruire);
  if(mode==='final'&&sobre){rendu();fige=true;}
  else{tPrev=performance.now();raf=racine.requestAnimationFrame(image);}
  const ctl={
    stop:detruire,passer:sauter,
    get etat(){return detruit?'repos':mode;},
    stats(){return{ms:mes.n?mes.s/mes.n:0,max:mes.max,images:mes.n,niveau:niv,T,particules:pn,colonises:nCol(),dpr};},
    seek(t){if(mode!=='sequence')return T;while(T<t-1e-9&&mode==='sequence'){pas();if(T>=T_FIN)versFinal('fin');}rendu();return T;}   // test
  };
  return ctl;
}

racine.QXCREA={
  version:'R463',
  play(o){
    try{
      if(lsGet('qxcrea')==='0'){if(o&&o.fin)o.fin('coupe');return null;}
      if(!o||!o.inst||!o.inst.geo||!M||!document.createElement('canvas').getContext)return null;
      if(cur)cur.stop();
      cur=Scene(o);return cur;
    }catch(e){try{console.warn('QXCREA',e);}catch(e2){}if(cur){try{cur.stop();}catch(e3){}}cur=null;if(o&&o.fin)o.fin('erreur');return null;}
  },
  stop(){if(cur)cur.stop();cur=null;},
  get etat(){return cur?cur.etat:'repos';},
  stats(){return cur?cur.stats():null;},
  get scene(){return cur;}
};
})(window);
/* =====================================================================
   QXCREA.niveau (R463) — DÉCOR VIVANT des niveaux Fluides, après la libération (S.crea=1).
   Les créatures nagent derrière le jeu, sans aucun contact avec la bille ni la physique :
   rien n'est écrit dans l'état du jeu, aucun tirage du hasard du moteur (graines propres, mulberry32).
   Repère = unités de niveau (360 × 470). Chaque créature vit dans son propre monde (W/k × H/k)
   et est dessinée à l'échelle k. Le courant vient de FLUID.sample (lecture seule) + une dérive douce.
   API : QXCREA.niveau.dessiner(ctx, lv, env) · .vider() · .stats() · .actif
         env = { RM, S, ms (temps de la précédente image du jeu) }
   ===================================================================== */
(function (racine) {
'use strict';
const M = racine.QXMOTIFS;
if (!M || !racine.QXCREA) return;
const W = 360, H = 470, TAU = Math.PI * 2;
/* calibrage : échelle (unités de niveau par unité de créature), opacité de base */
const CAL = { cells: [.72, .82], filament: [.74, .8], systole: [.64, .72], culbute: [.64, .84], choeur: [.58, .7], cortege: [.64, .8], volte: [.64, .9], braise: [.6, .68] };
const NOMS = ['cells', 'filament', 'systole', 'culbute', 'choeur', 'cortege', 'volte', 'braise'];
/* poids = coût de dessin relatif (mesuré : braise ≈ 2,9 ms, chœur 1,9, cortège 1,2, systole 1,1, les autres < 0,2 sur le banc d'essai) */
const POIDS = { cells: .12, filament: .1, culbute: .15, volte: .15, systole: .6, cortege: .65, choeur: 1, braise: 1.4 };
/* paliers : budget de poids, poils/voiles, qualité (cells, filament) ; les plus lourdes s'effacent d'abord */
const PAL = [[2.2, 1, .8], [1.25, 0, .7], [.65, 0, .6], [.3, 0, .5]];
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const lisse = (a, b, x) => { const u = Math.max(0, Math.min(1, (x - a) / (b - a))); return u * u * (3 - 2 * u); };
function reduitOS() { try { return !!(racine.matchMedia && racine.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
let cur = null, verrou = -1;   // verrou : palier imposé (aperçu, tests) ; -1 = adaptatif
const mes = { n: 0, s: 0, max: 0 };

/* ───── R469 · IMPLANTATION + COMPORTEMENT des créatures du décor ─────
   IMPLANTATION : les créatures vivent SUR LE PARCOURS (départ → étoile → arrivée, abords des murs, traits du joueur),
   jamais dessus : zones interdites douces autour de la bille, de la coupe, de l'étoile et des murs (elles s'écartent
   et pâlissent) ; elles sont dessinées SOUS le jeu, donc ne cachent jamais rien.
   COMPORTEMENT : une petite machine à états par créature, déterministe (graine du niveau + temps accumulé, aucun Math.random) :
     derive (repos, respiration lente) → cherche (patrouille par impulsions, cap qui balaie, antennes qui tâtent)
     → tate (arrêt sur un lieu, antennes tendues, éclair) → appel (le chef gonfle et émet une onde + un signal)
     → echo (les autres répondent en retard, se tournent) → rejoint (rapprochement) → ronde (danse à deux, arcs de lueur).
   Événements du jeu : lancement (sursaut, toutes se tournent), suit (filature à distance de la bille), recul (la bille
   arrive trop vite : fuite + alerte relayée), inspecte (nouveau trait tracé), fete (victoire : ronde autour de la coupe,
   éclairs en chaîne), abattu (échec : la lumière tombe, elles coulent un peu).
   Tempéraments : contemplatif · actif · social · agressif (vitesse, accélération, audace, goût de l'appel).
   Rien n'est écrit dans l'état du jeu ; la physique ne voit jamais ces créatures. */
const BORD = 16, VSIG = 240;                     // marge du terrain ; vitesse d'un signal lumineux (unités/s)
const TEMP = {                                   // vmax, amax, rythme de nage (Hz), audace (distance de filature), appel (goût), couleur
  contemplatif: { v: 34, a: 70, hz: .9, dist: 92, appel: .35, col: 1 },
  actif:        { v: 62, a: 150, hz: 1.7, dist: 74, appel: .2, col: 0 },
  social:       { v: 48, a: 110, hz: 1.3, dist: 84, appel: .8, col: 1 },
  agressif:     { v: 78, a: 220, hz: 2.2, dist: 56, appel: .15, col: 2 }
};
const TEMP_DE = { cells: 'social', filament: 'actif', systole: 'contemplatif', culbute: 'actif', choeur: 'social', cortege: 'social', volte: 'agressif', braise: 'agressif' };
/* lueurs pré-rendues (une fois) : dessinées en « lighter », sans dégradé dans la boucle */
const LUM = ['110,238,196', '127,216,230', '232,248,252'];   // lueur (vert d'eau), aqua, perle
let SPR = null;
function sprites() {
  if (SPR) return SPR; SPR = [];
  for (const c of LUM) {
    const k = document.createElement('canvas'); k.width = k.height = 64; const g = k.getContext('2d');
    const r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    r.addColorStop(0, 'rgba(' + c + ',.9)'); r.addColorStop(.25, 'rgba(' + c + ',.42)'); r.addColorStop(.6, 'rgba(' + c + ',.1)'); r.addColorStop(1, 'rgba(' + c + ',0)');
    g.fillStyle = r; g.fillRect(0, 0, 64, 64); SPR.push(k);
  }
  return SPR;
}
function halo(ctx, i, x, y, R, a) { if (a <= .01 || R <= .5) return; ctx.globalAlpha = Math.min(1, a); ctx.drawImage(sprites()[i], x - R, y - R, R * 2, R * 2); }
const q = (v, p0, p1, p2) => (1 - v) * (1 - v) * p0 + 2 * (1 - v) * v * p1 + v * v * p2;   // point d'une courbe de Bézier quadratique
const wrapA = a => a - Math.round(a / TAU) * TAU;
function dSeg(px, py, s) {                       // distance point–segment, renvoie aussi la normale (dans _n)
  const ax = s[0], ay = s[1], bx = s[2], by = s[3], ex = bx - ax, ey = by - ay, l2 = ex * ex + ey * ey || 1;
  let u = ((px - ax) * ex + (py - ay) * ey) / l2; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const qx = ax + ex * u, qy = ay + ey * u, dx = px - qx, dy = py - qy, d = Math.hypot(dx, dy) || 1e-3;
  _n[0] = dx / d; _n[1] = dy / d; return d;
}
const _n = [0, 0];
function arrivee(lv) {
  if (lv.cup) return [lv.cup[0] + lv.cup[2] / 2, lv.cup[1] - 26];
  if (lv.zone) { const z = lv.zone; return [z[0] + z[2] / 2, z[1] + z[3] / 2]; }
  return [W / 2, H - 60];
}
function zonesCalmes(lv) {                       // [x, y, rayon interdit] : départ, arrivée, étoile (la lisibilité d'abord)
  const Z = [], A = arrivee(lv);
  if (lv.ball) Z.push([lv.ball[0], lv.ball[1], 30]);
  Z.push([A[0], A[1], lv.cup ? Math.max(40, lv.cup[2] * .45) : 46]);
  if (lv.star) Z.push([lv.star[0], lv.star[1], 30]);
  return Z;
}
/* LIEUX : points d'intérêt le long du parcours, décalés de côté (on longe le chemin, on ne s'y pose pas) */
function lieux(lv, Z, murs) {
  const L = [], A = lv.ball || [60, 60], F = arrivee(lv), chemin = [A];
  if (lv.star) chemin.push(lv.star); chemin.push(F);
  const ok = (x, y) => {
    if (x < BORD + 8 || x > W - BORD - 8 || y < BORD + 10 || y > H - BORD - 10) return false;
    for (const z of Z) if (Math.hypot(x - z[0], y - z[1]) < z[2] + 14) return false;
    for (const s of murs) if (dSeg(x, y, s) < 18) return false;
    return true;
  };
  const ajoute = (x, y, w) => { if (ok(x, y)) L.push([x, y, w]); };
  for (let j = 0; j + 1 < chemin.length; j++) {
    const a = chemin[j], b = chemin[j + 1], ex = b[0] - a[0], ey = b[1] - a[1], l = Math.hypot(ex, ey) || 1, nx = -ey / l, ny = ex / l;
    for (let f = .15; f < .95; f += .14) for (const s of [1, -1]) for (const o of [36, 58]) ajoute(a[0] + ex * f + nx * o * s, a[1] + ey * f + ny * o * s, 1);
  }
  for (const z of Z) for (let q = 0; q < 6; q++) { const an = q * TAU / 6 + .4; ajoute(z[0] + Math.cos(an) * (z[2] + 26), z[1] + Math.sin(an) * (z[2] + 26), 1.3); }   // les abords du départ, de l'étoile, de la coupe
  for (const s of murs) {                       // le bout des murs : là où la bille ricoche
    if (s[4] === 2) continue;
    for (const e of [[s[0], s[1]], [s[2], s[3]]]) for (let q = 0; q < 4; q++) { const an = q * TAU / 4 + .78; ajoute(e[0] + Math.cos(an) * 30, e[1] + Math.sin(an) * 30, .8); }
  }
  if (L.length < 4) for (let gx = 0; gx < 5; gx++) for (let gy = 0; gy < 6; gy++) ajoute(50 + gx * 65, 50 + gy * 72, .5);
  return L;
}
function choisir(lv) {                           // créatures, déterministe selon l'indice du niveau
  const idx = lv.idx || 0, r = rng(0x5EA0 + idx * 7919), noms = NOMS.slice();
  for (let i = noms.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)), x = noms[i]; noms[i] = noms[j]; noms[j] = x; }
  const ext = lv.wd !== 12 || !!lv.cr;           // mondes colonisés (et niveaux d'essai) : créatures légères seulement
  if (ext) for (let i = noms.length - 1; i >= 0; i--) if (POIDS[noms[i]] > .15) noms.splice(i, 1);
  const n = ext ? 2 : 2 + ((idx * 5 + Math.floor(r() * 3)) % 3);   // R469 : toujours au moins deux (elles se parlent)
  const choix = []; let pds = 0;
  for (const nom of noms) { if (choix.length >= n) break; if (pds + POIDS[nom] > PAL[0][0]) continue; choix.push(nom); pds += POIDS[nom]; }
  const E = [];
  for (let i = 0; i < choix.length; i++) {
    const nom = choix[i], cal = CAL[nom], tn = i === 0 ? 'social' : (TEMP_DE[nom] === 'social' && i > 0 ? (i % 2 ? 'contemplatif' : 'actif') : TEMP_DE[nom]);
    E.push({ nom, k: cal[0] * (ext ? 1.02 : 1.08) * (.94 + .12 * r()), a0: Math.min(1, cal[1] * (ext ? 1.05 : 1.15)), seed: (idx * 131 + i * 977 + 4243) >>> 0, rang: i,
      poids: POIDS[nom], m: null, dec: null, geo: null, flo: [0, 0], fld: [0, 0], ap: 0, tn, T: TEMP[tn], chef: i === 0,
      x: 0, y: 0, vx: 0, vy: 0, cap: r() * TAU, capV: 0, ph: r() * TAU, lum: .3, fl: 0, gon: 0, etat: 'derive', tE: 0, dur: 2,
      tx: 0, ty: 0, ax: 0, ay: 0, wp: 0, lieu: -1, autre: -1, ant: 0, antX: 0, antY: 0, mode: '', part: { on: false, x: 0, y: 0 },
      tr: new Float32Array(24), trN: 0, trT: 0, R: rng(0xC0FFEE ^ (idx * 7907 + i * 104729)) });
  }
  return E.sort((x, y) => x.poids - y.poids);
}
function monter(lv) {
  vider();
  const E = choisir(lv), Z = zonesCalmes(lv);
  const murs = []; for (const s of (lv.w || [])) if (s && s.length >= 4) murs.push(s);
  const LI = lieux(lv, Z, murs);
  const SIG = [], RG = []; for (let i = 0; i < 8; i++) SIG.push({ on: false, a: 0, b: 0, t0: 0, d: 1, kind: 0, cx: 0, cy: 0 }); for (let i = 0; i < 12; i++) RG.push({ on: false, x: 0, y: 0, t0: 0, d: 1, r0: 0, r1: 0, c: 0, a: 0 });
  cur = { idx: lv.idx, E, t: 0, tPrev: 0, pal: 0, ema: 0, emaJ: 0, nImg: 0, tDeg: 0, tRem: 0, Z, murs, LI, SIG, RG, fondu: 0,
    mode0: '', nStk: 0, tMode: 0, arr: arrivee(lv), cr: lv.cr || null, tAppel: 3 + (lv.idx || 0) % 3 };
  /* ancres : on répartit les créatures le long du parcours (échantillonnage du plus éloigné) */
  const pris = [];
  for (const e of E) {
    let best = -1, bs = -1;
    for (let j = 0; j < LI.length; j++) {
      let d = 1e9; for (const p of pris) d = Math.min(d, Math.hypot(LI[j][0] - LI[p][0], LI[j][1] - LI[p][1]));
      if (cur.cr) for (const c of cur.cr) d = Math.min(d, Math.hypot(LI[j][0] - c.x, LI[j][1] - c.y) - (c.r || c.rc || 30) - 30);   // loin des créatures actives
      const s = Math.min(d, 160) * LI[j][2] + e.R() * 25;
      if (s > bs) { bs = s; best = j; }
    }
    if (best < 0) { e.ax = 80 + e.rang * 90; e.ay = 140; } else { pris.push(best); e.ax = LI[best][0]; e.ay = LI[best][1]; e.lieu = best; }
    e.x = e.ax; e.y = e.ay; e.tx = e.ax; e.ty = e.ay; e.dur = 1 + e.rang * .9;
    e.m = M.create(e.nom);
    e.m.init(W / e.k, H / e.k, e.seed, { quality: PAL[0][2], n: 1, slot: e.rang % 2 });
    e.m.reglage({ mode: 'cont', vit: .7, part: e.part });
    e.m.place(0, e.x / e.k, e.y / e.k);
    if (e.nom === 'cells' || e.nom === 'filament') e.dec = M.decor();
    e.flow = () => { e.flo[0] = e.vx / e.k; e.flo[1] = e.vy / e.k; return e.flo; };           // le corps « sent » sa propre nage : il s'oriente et s'étire dans le sens du mouvement
    e.flowD = () => { e.fld[0] = -e.vx * .5 / e.k; e.fld[1] = -e.vy * .5 / e.k; return e.fld; };  // poils et voiles traînent derrière
    for (let s = 0; s < 24; s++) corps(e, 1 / 30, true);
  }
  try { if (lv.wd === 12 && racine.QXF2 && racine.QXF2.vivants) racine.QXF2.vivants(.45); } catch (er) {}
}
function vider() {
  if (!cur) return;
  cur = null;
  try { if (racine.QXF2 && racine.QXF2.vivants) racine.QXF2.vivants(1); } catch (er) {}
}
/* le corps (motif) suit la position comportementale : placé, orienté vers un point devant le cap, puis animé */
function corps(e, dt, prep) {
  const k = e.k, cv = e.cap + e.capV;
  e.m.place(0, e.x / k, e.y / k);
  e.m.vise(0, (e.x + Math.cos(cv) * 70) / k, (e.y + Math.sin(cv) * 70) / k, 1.1);
  const en = e.etat === 'derive' ? .15 : e.etat === 'abattu' ? .05 : (e.etat === 'tate' || e.etat === 'appel' || e.etat === 'fete' || e.etat === 'recul') ? 1 : .55;
  e.m.update(dt, e.flow, en);
  e.m.place(0, e.x / k, e.y / k);
  if (e.dec && (prep || PAL[cur.pal][1])) { e.geo = e.m.geo(); const sp = Math.hypot(e.vx, e.vy); e.dec.update(dt * (1 + Math.min(3, sp / 50)), e.flowD, e.geo); }
}
/* ── signaux et ondes (tableaux pré-alloués, aucun objet créé par image) ── */
function onde(x, y, r0, r1, d, c, a) {
  let s = null; for (const o of cur.RG) if (!o.on) { s = o; break; } if (!s) return;
  s.on = true; s.x = x; s.y = y; s.r0 = r0; s.r1 = r1; s.d = d; s.c = c; s.a = a; s.t0 = cur.t;
}
function signal(a, b, kind) {                    // une impulsion de lumière voyage de a vers b le long d'un arc ; à l'arrivée, b réagit
  let s = null; for (const o of cur.SIG) if (!o.on) { s = o; break; } if (!s) return;
  const A = cur.E[a], B = cur.E[b], d = Math.hypot(B.x - A.x, B.y - A.y);
  s.on = true; s.a = a; s.b = b; s.kind = kind; s.t0 = cur.t; s.d = Math.max(.25, d / VSIG);
  const nx = -(B.y - A.y) / (d || 1), ny = (B.x - A.x) / (d || 1), bo = (a < b ? 1 : -1) * Math.min(60, d * .3);
  s.cx = (A.x + B.x) / 2 + nx * bo; s.cy = (A.y + B.y) / 2 + ny * bo;
}
function emet(e, kind) {                         // e appelle (kind 0), répond (1) ou alerte (2)
  const i = cur.E.indexOf(e);
  e.fl = 1; e.gon = 1;
  onde(e.x, e.y, 8, kind === 2 ? 70 : 95, kind === 1 ? .8 : 1.1, e.T.col, kind === 1 ? .55 : .8);
  for (let j = 0; j < cur.E.length; j++) if (j !== i && cur.E[j].ap > .02) { if (kind === 1 && j !== e.autre) continue; signal(i, j, kind); }
}
function recoit(e, s) {
  const A = cur.E[s.a];
  e.fl = Math.max(e.fl, .8); e.gon = Math.max(e.gon, .6);
  if (e.etat === 'suit' || e.etat === 'recul' || e.etat === 'fete' || e.etat === 'abattu') { if (s.kind === 2) e.fl = 1; return; }
  if (s.kind === 0) { passe(e, 'echo', .35 + .25 * e.R()); e.autre = s.a; }
  else if (s.kind === 1) { if (e.etat === 'appel' || e.etat === 'derive' || e.etat === 'cherche') { passe(e, 'rejoint', 2.5); e.autre = s.a; } }
  else e.cap = Math.atan2(A.y - e.y, A.x - e.x);
}
function passe(e, etat, dur) { e.etat = etat; e.tE = 0; e.dur = dur; }
function prochainLieu(e) {                       // un lieu du parcours, pas trop près de l'actuel, ni de la bille
  const LI = cur.LI; if (!LI.length) { e.tx = e.ax; e.ty = e.ay; return; }
  let best = 0, bs = -1e9;
  for (let j = 0; j < LI.length; j++) {
    const d = Math.hypot(LI[j][0] - e.x, LI[j][1] - e.y), da = Math.hypot(LI[j][0] - e.ax, LI[j][1] - e.ay);
    let s = (d > 50 && d < 190 ? 1 : d < 45 ? -6 : 0) - da / 260 + e.R() * .9 + LI[j][2] * .3;
    for (const o of cur.E) if (o !== e) s -= Math.max(0, 1 - Math.hypot(LI[j][0] - o.tx, LI[j][1] - o.ty) / 70);
    if (s > bs) { bs = s; best = j; }
  }
  e.tx = LI[best][0]; e.ty = LI[best][1]; e.lieu = best;
}
/* ── événements du jeu (lus, jamais écrits) ── */
function evenements(S, b) {
  const m = S ? S.mode : '', run = m === 'run' || m === 'replay';
  if (m !== cur.mode0) {
    if (run && cur.mode0 !== 'run') for (const e of cur.E) { passe(e, 'alerte', .35 + e.rang * .12); e.fl = 1; e.gon = .8; if (b) e.cap = Math.atan2(b.y - e.y, b.x - e.x); }
    else if (m === 'success') { cur.E.forEach((e, i) => { passe(e, 'fete', 99); e.ph = i * 1.3; }); onde(cur.arr[0], cur.arr[1], 20, 120, 1.4, 2, .7); }
    else if (m === 'fail') for (const e of cur.E) { passe(e, 'abattu', 2.2); }
    else if (!run) for (const e of cur.E) if (e.etat === 'suit' || e.etat === 'recul' || e.etat === 'alerte' || e.etat === 'fete') passe(e, 'cherche', 6);
    cur.mode0 = m; cur.tMode = cur.t;
  }
  const st = S && S.strokes, n = st ? st.length : 0;
  if (n > cur.nStk && !run) {                    // un nouveau trait : la plus proche vient le tâter
    const s = st[n - 1], p = s && s.pts && s.pts[s.pts.length >> 1];
    if (p) {
      let e0 = null, dm = 1e9; for (const e of cur.E) { const d = Math.hypot(e.x - p[0], e.y - p[1]); if (d < dm) { dm = d; e0 = e; } }
      if (e0) {
        const q = s.pts[0], r = s.pts[s.pts.length - 1], ex = r[0] - q[0], ey = r[1] - q[1], l = Math.hypot(ex, ey) || 1;
        let nx = -ey / l, ny = ex / l; if (ny > 0) { nx = -nx; ny = -ny; }   // on se pose au-dessus du trait
        e0.tx = Math.max(BORD, Math.min(W - BORD, p[0] + nx * 26)); e0.ty = Math.max(BORD, Math.min(H - BORD, p[1] + ny * 26));
        passe(e0, 'inspecte', 3); e0.antX = p[0]; e0.antY = p[1];
      }
    }
  }
  cur.nStk = n;
}
/* ── la machine à états d'une créature : renvoie la vitesse voulue dans _v ── */
const _v = [0, 0];
function cerveau(e, i, dt, S, b, run) {
  const T = e.T, t = cur.t; e.tE += dt;
  let vd = 0, tx = e.tx, ty = e.ty, regard = null, hz = T.hz, lum = .3;
  e.capV = 0; e.ant = Math.max(0, e.ant - dt * 2);
  const avant = e.etat, tE0 = e.tE;
  switch (e.etat) {
    case 'derive': {                             // repos : lente dérive autour de l'ancre, respiration
      tx = e.ax + 22 * Math.sin(t * .5 + e.ph); ty = e.ay + 14 * Math.sin(t * .37 + e.ph * 1.7);
      vd = T.v * .22; hz = T.hz * .5; lum = .28 + .1 * Math.sin(t * 1.4 + e.ph);
      if (e.tE > e.dur) {
        cur.tAppel -= e.dur;
        if (e.chef && cur.E.length > 1 && cur.tAppel <= 0) { passe(e, 'appel', 1.1); cur.tAppel = 7 + 5 * e.R(); }
        else { passe(e, 'cherche', 7); e.wp = 2 + Math.floor(e.R() * 2); prochainLieu(e); }
      }
      break;
    }
    case 'cherche': {                            // patrouille : nage par impulsions vers un lieu, le cap balaie, les antennes tâtent
      vd = T.v; e.capV = .55 * Math.sin(t * 3.1 + e.ph); lum = .4; e.ant = Math.max(e.ant, .5);
      if (Math.hypot(tx - e.x, ty - e.y) < 16 || e.tE > e.dur) { passe(e, 'tate', .9 + .6 * e.R()); e.antX = tx + Math.cos(e.cap) * 30; e.antY = ty + Math.sin(e.cap) * 30; }
      break;
    }
    case 'tate': case 'inspecte': {              // arrêt : antennes tendues vers le lieu (ou le trait), petit éclair à mi-parcours
      const insp = e.etat === 'inspecte', d = Math.hypot(tx - e.x, ty - e.y);
      if (insp && d > 14 && e.tE < 1.6) { vd = T.v * 1.1; lum = .5; e.ant = .7; regard = 1; break; }
      vd = 0; e.ant = 1; regard = 1; lum = .5 + .3 * Math.sin(e.tE * 9);
      e.capV = .25 * Math.sin(e.tE * 7);
      if (e.tE > e.dur * .45 && e.tE - dt <= e.dur * .45) { e.fl = Math.max(e.fl, .7); onde(e.antX, e.antY, 3, 22, .5, e.T.col, .6); }
      if (e.tE > (insp ? 2.4 : e.dur)) {
        if (insp) { passe(e, 'derive', 1.5); break; }
        if (--e.wp > 0) { passe(e, 'cherche', 7); prochainLieu(e); }
        else if (e.R() < T.appel && cur.E.length > 1) passe(e, 'appel', 1);
        else { passe(e, 'derive', 2 + 3 * e.R()); e.ax = e.x; e.ay = e.y; }
      }
      break;
    }
    case 'appel': {                              // le chef se gonfle, la lumière monte… puis l'onde et le signal partent
      vd = 0; hz = 3; const u = e.tE / e.dur; lum = .4 + .6 * u; e.gon = Math.max(e.gon, u * .7);
      if (e.tE >= e.dur) { emet(e, 0); passe(e, 'attend', 2.6); }
      break;
    }
    case 'attend': { vd = 0; lum = .5; if (e.tE > e.dur) passe(e, 'derive', 2); break; }
    case 'echo': {                               // un signal est arrivé : elle se tourne, attend (écho), puis répond
      const A = cur.E[e.autre]; vd = 0; lum = .6; e.ant = 1;
      if (A) e.cap += wrapA(Math.atan2(A.y - e.y, A.x - e.x) - e.cap) * Math.min(1, dt * 8);
      if (e.tE > e.dur) { emet(e, 1); passe(e, 'rejoint', 3); }
      break;
    }
    case 'rejoint': {                            // rapprochement vers l'autre, puis ronde
      const A = cur.E[e.autre]; if (!A) { passe(e, 'derive', 2); break; }
      tx = A.x; ty = A.y; vd = T.v * 1.15; lum = .5; e.ant = .8;
      if (Math.hypot(A.x - e.x, A.y - e.y) < 62) { passe(e, 'ronde', 2.8); if (A.etat === 'attend' || A.etat === 'rejoint' || A.etat === 'derive') { passe(A, 'ronde', 2.8); A.autre = cur.E.indexOf(e); } }
      else if (e.tE > e.dur) passe(e, 'derive', 2);
      break;
    }
    case 'ronde': {                              // danse à deux autour du centre commun, impulsions synchrones
      const A = cur.E[e.autre]; if (!A) { passe(e, 'derive', 2); break; }
      const cx = (A.x + e.x) / 2, cy = (A.y + e.y) / 2, an = Math.atan2(e.y - cy, e.x - cx) + 1.6;
      tx = cx + Math.cos(an) * 34; ty = cy + Math.sin(an) * 34; vd = T.v * .9; hz = 2; lum = .55 + .35 * Math.max(0, Math.sin(t * 6));
      if (e.tE > e.dur) { passe(e, 'derive', 2.5 + 2 * e.R()); prochainLieu(e); e.ax = e.tx; e.ay = e.ty; }
      break;
    }
    case 'alerte': { vd = 0; lum = .9; regard = 2; if (e.tE > e.dur) passe(e, run ? 'suit' : 'derive', 2); break; }
    case 'suit': {                               // filature : derrière la bille, de côté, à distance ; s'écarte si elle fonce dessus
      if (!b) { passe(e, 'derive', 2); break; }
      const sp = Math.hypot(b.vx, b.vy), ux = sp > .3 ? b.vx / sp : 0, uy = sp > .3 ? b.vy / sp : 1, side = (i % 2 ? 1 : -1);
      const D = T.dist + 14 * Math.sin(t * 1.3 + e.ph);
      tx = b.x - ux * D * .75 - uy * side * D * .6; ty = b.y - uy * D * .75 + ux * side * D * .6;
      vd = T.v * 1.35; hz = T.hz * 1.4; lum = .55; regard = 2; e.ant = 1;
      const dx = e.x - b.x, dy = e.y - b.y, d = Math.hypot(dx, dy) || 1, ferme = -(b.vx * dx + b.vy * dy) / d;   // vitesse d'approche (unités/image)
      if (d < 70 && ferme > 2.2) { passe(e, 'recul', .8); e.fl = 1; e.tx = e.x + dx / d * 70 + (-dy / d) * 40 * side; e.ty = e.y + dy / d * 70 + (dx / d) * 40 * side; emet(e, 2); }
      else if (e.tn === 'agressif' && e.tE > 2.2 && d > 60) { passe(e, 'charge', .7); }
      break;
    }
    case 'charge': {                             // l'agressive fonce vers la bille… et vire au dernier moment
      if (!b) { passe(e, 'derive', 2); break; }
      tx = b.x; ty = b.y; vd = T.v * 1.8; hz = 4; lum = .8; regard = 2; e.ant = 1;
      if (Math.hypot(b.x - e.x, b.y - e.y) < 48 || e.tE > e.dur) { passe(e, 'recul', .6); const a = Math.atan2(e.y - b.y, e.x - b.x) + .9; e.tx = e.x + Math.cos(a) * 60; e.ty = e.y + Math.sin(a) * 60; e.fl = 1; }
      break;
    }
    case 'recul': { vd = T.v * 2; hz = 5; lum = .9; if (e.tE > e.dur) passe(e, run ? 'suit' : 'derive', 2); break; }
    case 'fete': {                               // victoire : ronde autour de la coupe, éclairs en chaîne
      const A = cur.arr, n = cur.E.length, an = t * .9 + i * TAU / n;
      tx = A[0] + Math.cos(an) * 66; ty = A[1] - 18 + Math.sin(an) * 40; vd = T.v * 1.2; hz = 2;
      const ph = (t * 1.6 - i / n) % 1; lum = .5 + .5 * (ph < .15 ? 1 - ph / .15 : 0);
      if (ph < dt * 1.6) { e.fl = 1; onde(e.x, e.y, 6, 40, .7, i % 3, .6); }
      break;
    }
    case 'abattu': { tx = e.x; ty = e.y + 30; vd = 10; hz = .4; lum = .12; if (e.tE > e.dur) { passe(e, 'derive', 2); e.ax = e.x; e.ay = e.y; } break; }
  }
  if (e.etat === avant && e.tE >= tE0) { e.tx = tx; e.ty = ty; }   // un changement d'état a déjà posé sa propre cible
  /* regard : vers la bille ou le lieu tâté ; sinon dans le sens de la nage */
  const sp = Math.hypot(e.vx, e.vy);
  let cible = sp > 10 ? Math.atan2(e.vy, e.vx) : e.cap;
  if (regard === 2 && b) cible = Math.atan2(b.y - e.y, b.x - e.x); else if (regard === 1) cible = Math.atan2(e.antY - e.y, e.antX - e.x);
  e.cap += wrapA(cible - e.cap) * Math.min(1, dt * (regard ? 7 : 4));
  e.lum += (lum - e.lum) * Math.min(1, dt * 4);
  /* nage par impulsions : la poussée bat avec la pulsation (même rythme que la lumière) */
  e.ph += dt * TAU * hz;
  const puls = Math.pow(Math.max(0, Math.sin(e.ph)), 2);
  e.puls = puls;
  const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy) || 1, fr = Math.min(1, d / 40);   // freinage à l'approche
  _v[0] = dx / d * vd * fr; _v[1] = dy / d * vd * fr;
  return .35 + 1.3 * puls;
}
/* ── intégration : inertie, poussée pulsée, zones interdites, murs, bords ── */
function bouge(e, dt, b, gain) {
  const T = e.T;
  let ax = (_v[0] - e.vx) * 3.2 * gain, ay = (_v[1] - e.vy) * 3.2 * gain;
  for (const z of cur.Z) { const dx = e.x - z[0], dy = e.y - z[1], d = Math.hypot(dx, dy) || 1, R = z[2] + 10; if (d < R) { const f = (R - d) * 9; ax += dx / d * f; ay += dy / d * f; } }
  if (b) { const dx = e.x - b.x, dy = e.y - b.y, d = Math.hypot(dx, dy) || 1, R = 40; if (d < R) { const f = (R - d) * 14; ax += dx / d * f; ay += dy / d * f; } }
  if (cur.cr) for (const c of cur.cr) { const dx = e.x - c.x, dy = e.y - c.y, d = Math.hypot(dx, dy) || 1, R = (c.r || c.rc || 30) + 28; if (d < R) { const f = (R - d) * 6; ax += dx / d * f; ay += dy / d * f; } }
  for (const s of cur.murs) { const d = dSeg(e.x, e.y, s); if (d < 22) { const f = (22 - d) * 10; ax += _n[0] * f; ay += _n[1] * f; } }
  for (const o of cur.E) if (o !== e) { const dx = e.x - o.x, dy = e.y - o.y, d = Math.hypot(dx, dy) || 1; if (d < 34) { ax += dx / d * (34 - d) * 6; ay += dy / d * (34 - d) * 6; } }
  const am = T.a * (.4 + gain), al = Math.hypot(ax, ay); if (al > am * 2.2) { ax *= am * 2.2 / al; ay *= am * 2.2 / al; }
  e.vx += ax * dt; e.vy += ay * dt;
  const vm = T.v * 2.1, sp = Math.hypot(e.vx, e.vy); if (sp > vm) { e.vx *= vm / sp; e.vy *= vm / sp; }
  e.vx *= 1 - Math.min(1, dt * .6); e.vy *= 1 - Math.min(1, dt * .6);
  e.x += e.vx * dt; e.y += e.vy * dt;
  if (e.x < BORD) { e.x = BORD; e.vx = Math.abs(e.vx) * .5; } if (e.x > W - BORD) { e.x = W - BORD; e.vx = -Math.abs(e.vx) * .5; }
  if (e.y < BORD) { e.y = BORD; e.vy = Math.abs(e.vy) * .5; } if (e.y > H - BORD) { e.y = H - BORD; e.vy = -Math.abs(e.vy) * .5; }
  e.fl = Math.max(0, e.fl - dt * 2.2); e.gon = Math.max(0, e.gon - dt * 1.6);
  e.trT += dt; if (e.trT > .05) { e.trT = 0; e.tr.copyWithin(2, 0, 22); e.tr[0] = e.x; e.tr[1] = e.y; if (e.trN < 12) e.trN++; }   // sillage : 12 positions
}
/* ── dessin des gestes (sous et sur le corps) ── */
function sillage(ctx, e, A) {
  const sp = Math.hypot(e.vx, e.vy); if (sp < 25 || e.trN < 3) return;
  const a = A * Math.min(1, (sp - 25) / 60) * .8, c = LUM[e.T.col];
  ctx.lineCap = 'round';
  for (let j = 1; j < e.trN; j++) {
    ctx.strokeStyle = 'rgba(' + c + ',' + (a * (1 - j / e.trN)).toFixed(3) + ')'; ctx.lineWidth = 3.2 * (1 - j / e.trN) + .4;
    ctx.beginPath(); ctx.moveTo(e.tr[j * 2 - 2], e.tr[j * 2 - 1]); ctx.lineTo(e.tr[j * 2], e.tr[j * 2 + 1]); ctx.stroke();
  }
}
function antennes(ctx, e, A, t, b) {             // deux antennes souples qui tâtent devant la créature
  const u = e.ant; if (u < .05) return;
  const cv = e.cap + e.capV * .6, hl = e.hl, hx = e.x + Math.cos(cv) * hl, hy = e.y + Math.sin(cv) * hl;
  let L = 16 + 16 * u; if (e.etat === 'tate' || e.etat === 'inspecte') L += 8 * Math.sin(e.tE * 11);
  if ((e.etat === 'suit' || e.etat === 'charge') && b) L += 6;
  ctx.strokeStyle = 'rgba(' + LUM[2] + ',' + Math.min(1, A * 1.1 * u).toFixed(3) + ')'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
  for (let s = -1; s <= 1; s += 2) {
    const sw = .42 * s + .3 * Math.sin(t * (e.etat === 'cherche' ? 5 : 3) + e.ph + s), a1 = cv + sw, a2 = cv + sw * .4 + .25 * Math.sin(t * 4.3 + s * 2 + e.ph);
    const mx = hx + Math.cos(a1) * L * .55, my = hy + Math.sin(a1) * L * .55, ex = mx + Math.cos(a2) * L * .55, ey = my + Math.sin(a2) * L * .55;
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.quadraticCurveTo(mx, my, ex, ey); ctx.stroke();
    halo(ctx, 0, ex, ey, 6 + 4 * u + 6 * e.fl, A * (.8 + .6 * e.fl));
  }
}
function dessinerSignaux(ctx, A0) {
  const t = cur.t;
  ctx.lineCap = 'round';
  for (const s of cur.SIG) {
    if (!s.on) continue;
    const u = (t - s.t0) / s.d, a = cur.E[s.a], b = cur.E[s.b];
    if (u >= 1) { s.on = false; recoit(b, s); onde(b.x, b.y, 4, 34, .6, s.kind === 2 ? 2 : b.T.col, .75); continue; }
    const c = LUM[s.kind === 0 ? 0 : s.kind === 1 ? 1 : 2];
    /* l'arc lumineux : un fil ténu qui se dessine, une tête brillante, une traîne */
    ctx.strokeStyle = 'rgba(' + c + ',' + (A0 * .32 * (1 - u * .5)).toFixed(3) + ')'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(a.x, a.y);
    for (let j = 1; j <= 10; j++) { const v = j / 10; ctx.lineTo(q(v, a.x, s.cx, b.x), q(v, a.y, s.cy, b.y)); }
    ctx.stroke();
    for (let j = 0; j < 6; j++) {
      const v0 = Math.max(0, u - j * .045), v1 = Math.max(0, u - (j + 1) * .045);
      ctx.strokeStyle = 'rgba(' + c + ',' + (A0 * (1 - j / 6)).toFixed(3) + ')'; ctx.lineWidth = 3.4 - j * .45;
      ctx.beginPath(); ctx.moveTo(q(v0, a.x, s.cx, b.x), q(v0, a.y, s.cy, b.y)); ctx.lineTo(q(v1, a.x, s.cx, b.x), q(v1, a.y, s.cy, b.y)); ctx.stroke();
    }
    halo(ctx, s.kind === 0 ? 0 : s.kind === 1 ? 1 : 2, q(u, a.x, s.cx, b.x), q(u, a.y, s.cy, b.y), 18, A0);
  }
  for (const o of cur.RG) {
    if (!o.on) continue;
    const u = (t - o.t0) / o.d; if (u >= 1) { o.on = false; continue; }
    const r = o.r0 + (o.r1 - o.r0) * (1 - (1 - u) * (1 - u));
    ctx.strokeStyle = 'rgba(' + LUM[o.c] + ',' + Math.min(1, A0 * o.a * 1.3 * (1 - u)).toFixed(3) + ')'; ctx.lineWidth = 1.4 + 3 * (1 - u);
    ctx.beginPath(); ctx.arc(o.x, o.y, r, 0, TAU); ctx.stroke();
  }
}
function liens(ctx, A0) {                        // ronde : un filament de lueur fugace relie les danseuses
  const t = cur.t;
  for (const e of cur.E) {
    if (e.etat !== 'ronde' || e.autre < 0) continue;
    const o = cur.E[e.autre]; if (!o || cur.E.indexOf(e) > e.autre) continue;
    const a = A0 * (.4 + .5 * Math.max(0, Math.sin(t * 6))), mx = (e.x + o.x) / 2 + 10 * Math.sin(t * 4), my = (e.y + o.y) / 2 + 10 * Math.cos(t * 3.3);
    ctx.strokeStyle = 'rgba(' + LUM[0] + ',' + a.toFixed(3) + ')'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.quadraticCurveTo(mx, my, o.x, o.y); ctx.stroke();
  }
}
function dessiner(ctx, lv, env) {
  if (!lv) { vider(); act = null; return; }
  if (!lv.cr) act = null;
  if (!cur || cur.idx !== lv.idx) monter(lv);
  const t0 = performance.now();
  let dt = cur.tPrev ? (t0 - cur.tPrev) / 1000 : 1 / 60; cur.tPrev = t0;
  if (dt > .05) dt = .05; if (dt < 0) dt = 0;
  const lent = !!(env && env.RM) || reduitOS();
  const dts = lent ? dt * .12 : dt;              // mouvement réduit : presque immobiles, sans sursaut
  cur.t += dts; cur.fondu = Math.min(1, cur.fondu + dt / 1.2);
  const P = PAL[cur.pal], S = env && env.S, b = S && S.ball, run = S && (S.mode === 'run' || S.mode === 'replay');
  const bv = run ? b : null;                     // la bille ne compte (filature, recul) que lorsqu'elle roule
  if (!lent) evenements(S, b);
  let pds = 0;
  for (let i = 0; i < cur.E.length; i++) {
    const e = cur.E[i];
    if (pds + e.poids > P[0] + 1e-6) { e.ap = 0; continue; } pds += e.poids;
    const g = cerveau(e, i, dts, S, bv, run);
    bouge(e, dts, bv || (b ? b : null), g);
    /* la bille (ou le lieu tâté) excite les cils / la trompe du motif : il la « regarde » */
    const k = e.k, pt = e.part;
    if (bv && Math.hypot(bv.x - e.x, bv.y - e.y) < 150) { pt.on = true; pt.x = bv.x / k; pt.y = bv.y / k; }
    else if (e.ant > .6) { pt.on = true; pt.x = e.antX / k; pt.y = e.antY / k; }
    else pt.on = false;
    const md = e.etat === 'recul' ? 'evite' : e.etat === 'charge' ? 'agr' : e.etat === 'suit' ? 'suit' : (e.etat === 'cherche' || e.etat === 'fete') ? 'actif' : 'cont';
    if (md !== e.mode) { e.mode = md; e.m.reglage({ mode: md }); }
    corps(e, dts, false);
    if (!e.hl) { const g0 = e.m.geo()[0]; e.hl = Math.max(8, Math.min(26, (g0.k === 'cell' ? g0.a : g0.r || 14) * k * .8)); }
    /* présence : nette, sauf tout près de ce qu'il faut lire (coupe, étoile, bille) */
    let f = 1;
    for (const z of cur.Z) f = Math.min(f, lisse(z[2] * .7, z[2] * 1.3, Math.hypot(e.x - z[0], e.y - z[1])));
    if (b) f = Math.min(f, lisse(24, 60, Math.hypot(e.x - b.x, e.y - b.y)));
    const cible = e.a0 * (.4 + .6 * f) * (e.etat === 'abattu' ? .55 : 1);
    e.ap += (cible - e.ap) * Math.min(1, dt * 3);
    const A = e.ap * cur.fondu;
    if (A < .01) continue;
    /* sous le corps : sillage + halo qui respire avec la nage */
    sillage(ctx, e, A);
    ctx.globalCompositeOperation = 'lighter';
    halo(ctx, e.T.col, e.x, e.y, e.hl * (2.2 + .6 * e.puls + 1.8 * e.fl + 1 * e.gon), A * (.22 + .45 * e.lum + .7 * e.fl));
    ctx.globalCompositeOperation = 'source-over';
    ctx.save();
    const q = 1 + .14 * e.gon + .04 * e.puls * (e.lum > .4 ? 1 : 0);       // gonflement : appel, signal reçu, sursaut
    ctx.translate(e.x, e.y); ctx.scale(k * q, k * q); ctx.translate(-e.x / k, -e.y / k);
    e.m.draw(ctx, A);
    if (e.dec && P[1] && e.geo) e.dec.draw(ctx, e.geo, .8 * A);
    ctx.restore();
    ctx.globalCompositeOperation = 'lighter';
    antennes(ctx, e, A, cur.t, bv);
    if (e.fl > .02) halo(ctx, 2, e.x, e.y, e.hl * (1 + e.fl), A * e.fl * .9);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.globalCompositeOperation = 'lighter';
  liens(ctx, cur.fondu);
  dessinerSignaux(ctx, cur.fondu);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  if (lv.cr) dessinerAct(ctx, lv, env);          // niveaux d'essai : la créature active par-dessus le décor (c'est elle qui agit)
  const ms = performance.now() - t0;
  mes.n++; mes.s += ms; if (ms > mes.max) mes.max = ms;
  cur.nImg++; if (cur.nImg > 6) cur.ema = cur.nImg < 9 ? ms : cur.ema * .92 + ms * .08;   // les premières images (caches, montage) ne comptent pas
  const mj = env && env.ms > 0 ? env.ms : 0; if (cur.nImg > 6) cur.emaJ = cur.nImg < 9 ? mj : cur.emaJ * .92 + mj * .08;
  if (cur.nImg > 10) {                           // qualité adaptative : notre coût (> 2,5 ms) ou l'image du jeu (> 8 ms)
    const now = t0;
    if (verrou >= 0) cur.pal = verrou;
    else if ((cur.ema > 2.5 || cur.emaJ > 8) && cur.pal < PAL.length - 1 && now - cur.tDeg > 1200) { cur.pal++; cur.tDeg = now; cur.ema *= .6; }
    else if (cur.pal > 0 && cur.ema < 1.2 && cur.emaJ < 5 && now - cur.tDeg > 10000 && now - cur.tRem > 10000) { cur.pal--; cur.tRem = now; cur.tDeg = now; }
  }
}
/* ───── R465 · CRÉATURES ACTIVES (prototype jouable) ─────
   lv.cr : voir fluides.js (physique). Ici : le dessin et les GESTES ANNONCÉS — rien n'agit sans avoir été montré.
   Les créatures sont placées sur la position exacte de la physique (FLUID.crPos, fonction de S.frames) : ce qu'on voit est ce qui agit.
   cils → cellule (cil-courant : chevrons dans le sens du cap) · gueule → systole (anneau, gonflement, flèche de crachat) · glu → filament (voile mauve). */
const AQ = 'rgba(127,216,230,', MV = 'rgba(182,154,232,', AM = 'rgba(255,196,120,', PE = 'rgba(232,248,252,';
const ACT_NOM = { cils: 'cells', gueule: 'systole', glu: 'filament' };
let act = null;
/* R469 : chaque créature active a des ÉTATS lisibles, tous déduits de S.frames et de l'état de la bille (b.cs, b.glu) :
   veille → alerte (la bille approche : elle se tourne, gonfle, la lumière monte) → action (battement / prise / englué)
   → relâche (crachat, apaisement). Le sillage de la bille est coloré là où une créature agit (rendu seul, jamais la physique). */
function monterAct(lv) {
  act = { idx: lv.idx, tPrev: 0, t: 0, E: [], tr: new Float32Array(240), tf: new Uint8Array(120), tn: 0, fr0: -1 };
  (lv.cr || []).forEach((c, i) => {
    const nom = ACT_NOM[c.t] || 'cells', cal = CAL[nom], k = cal[0] * (c.t === 'gueule' ? 1.6 : c.t === 'glu' ? 1.5 : 1.45);
    const m = M.create(nom);
    m.init(W / k, H / k, 9100 + (lv.idx || 0) * 31 + i * 7, { quality: .8, n: 1, slot: i % 2 });
    const part = { on: false, x: 0, y: 0 };
    m.reglage({ mode: 'cont', vit: .7, part });
    const e = { c, i, k, m, part, a0: cal[1], dec: (nom === 'cells' || nom === 'filament') ? M.decor() : null, geo: null, flo: [0, 0], al: 0, gon: 0, fl: 0, mode: 'cont' };
    e.flow = () => { e.flo[0] = 0; e.flo[1] = 0; return e.flo; };
    const P0 = racine.FLUID && racine.FLUID.crPos ? racine.FLUID.crPos(c, 0) : [c.x, c.y];
    m.place(0, P0[0] / k, P0[1] / k);
    for (let n = 0; n < 24; n++) { m.vise(0, P0[0] / k, P0[1] / k, .9); m.update(1 / 30, e.flow, .15); }
    act.E.push(e);
  });
}
function flecheAct(ctx, x, y, a, L, col, al, lw) {
  const ex = x + Math.cos(a) * L, ey = y + Math.sin(a) * L, h = 6 + lw * 2.5;
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 16, y + Math.sin(a) * 16); ctx.lineTo(ex, ey);
  ctx.moveTo(ex - Math.cos(a - .5) * h, ey - Math.sin(a - .5) * h); ctx.lineTo(ex, ey); ctx.lineTo(ex - Math.cos(a + .5) * h, ey - Math.sin(a + .5) * h);
  const co = ctx.globalCompositeOperation; ctx.globalCompositeOperation = 'source-over';   // liseré sombre : lisible aussi sur le fond clair de Fluides
  ctx.strokeStyle = 'rgba(4,10,18,' + (+al * .35).toFixed(3) + ')'; ctx.lineWidth = (lw || 2.2) + 2.5; ctx.stroke();
  ctx.globalCompositeOperation = co; ctx.strokeStyle = col + al + ')'; ctx.lineWidth = lw || 2.2; ctx.stroke();
}
function chevron(ctx, x, y, a, s) { ctx.moveTo(x - Math.cos(a - .65) * s, y - Math.sin(a - .65) * s); ctx.lineTo(x, y); ctx.lineTo(x - Math.cos(a + .65) * s, y - Math.sin(a + .65) * s); }
/* sillage de la bille, par segments marqués : 1 = dans les cils, 2 = recrachée, 3 = engluée */
function sillageAct(ctx, fr) {
  const n = act.tn; if (n < 2) return;
  const COL = [null, AQ, PE, MV];
  ctx.lineCap = 'round';
  for (let pass = 0; pass < 2; pass++) for (let j = 1; j < n; j++) {
    const f = act.tf[j]; if (!f) continue;
    const age = (n - j) / n, al = (pass ? .9 : .28) * (1 - age * .85);
    ctx.strokeStyle = COL[f] + al.toFixed(3) + ')'; ctx.lineWidth = pass ? 2.2 : 9;
    ctx.beginPath(); ctx.moveTo(act.tr[j * 2 - 2], act.tr[j * 2 - 1]); ctx.lineTo(act.tr[j * 2], act.tr[j * 2 + 1]); ctx.stroke();
  }
}
function dessinerAct(ctx, lv, env) {
  if (!act || act.idx !== lv.idx) monterAct(lv);
  const FL = racine.FLUID, S = env && env.S, b = S && S.ball, fr = S ? S.frames : 0, run = S && S.mode === 'run';
  const t0 = performance.now(); let dt = act.tPrev ? (t0 - act.tPrev) / 1000 : 1 / 60; act.tPrev = t0; if (dt > .05) dt = .05;
  const lent = (env && env.RM) || reduitOS();
  if (lent) dt *= .12;
  act.t += dt;
  const T = act.t;
  /* sillage : une position par image de physique ; on repart à zéro à chaque essai */
  if (!run || fr <= 1) { if (fr <= 1) act.tn = 0; }
  if (run && b && fr !== act.fr0) {
    act.fr0 = fr;
    let f = 0;
    for (const e of act.E) { const st = (b.cs && b.cs[e.i]) || {}; if (e.c.t === 'cils' && st.on > fr - 2) f = 1; else if (e.c.t === 'gueule' && st.out && fr >= st.out && fr - st.out < 45) f = 2; }
    if (b.glu > fr) f = 3;
    if (act.tn >= 120) { act.tr.copyWithin(0, 2); act.tf.copyWithin(0, 1); act.tn = 119; }
    act.tr[act.tn * 2] = b.x; act.tr[act.tn * 2 + 1] = b.y; act.tf[act.tn] = f; act.tn++;
  }
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  sillageAct(ctx, fr);
  ctx.globalCompositeOperation = 'source-over';
  for (const e of act.E) {
    const c = e.c, p = FL.crPos(c, fr), k = e.k;
    let st = (b && b.cs && b.cs[e.i]) || {};
    if (b && b.cs && fr <= 1) st = {};          // nouvel essai : l'état d'avant ne compte plus (la physique le remet à zéro)
    const x = p[0], y = p[1], d = b ? Math.hypot(b.x - x, b.y - y) : 1e9;
    const sp = b ? Math.hypot(b.vx, b.vy) : 0, appr = b && d > 1 ? -((b.x - x) * b.vx + (b.y - y) * b.vy) / d : 0;   // vitesse d'approche
    /* ÉTAT lisible : 0 veille · 1 alerte (elle approche) · 2 action · 3 relâche */
    let etat = 0;
    const R0 = c.t === 'gueule' ? (c.rc || 24) : c.r;
    if (run && d < R0 + 90 && appr > .3) etat = 1;
    if (c.t === 'cils' && st.on > fr - 3) etat = 2;
    if (c.t === 'gueule' && st.h > fr) etat = 2;
    if (c.t === 'glu' && b && b.glu > fr) etat = 2;
    if (c.t === 'gueule' && st.out && fr >= st.out && fr - st.out < 40) etat = 3;
    e.al += ((etat === 0 ? .25 : etat === 1 ? .7 : 1) - e.al) * Math.min(1, dt * 6);
    e.gon = Math.max(0, e.gon - dt * 1.8); e.fl = Math.max(0, e.fl - dt * 2.5);
    if (c.t === 'gueule' && st.in === fr) { e.fl = 1; e.gon = 1; }
    if (c.t === 'gueule' && st.out === fr) { e.fl = 1; e.gon = 1; }
    if (c.t === 'glu' && st.in === fr) { e.fl = 1; e.gon = .8; }
    /* le corps vit dans son propre monde ; il regarde la bille quand elle compte */
    const cur = e.m.pos(0), dx = x - cur[0] * k, dy = y - cur[1] * k;
    if (b && (run || etat) && d < 220) { e.part.on = true; e.part.x = (b.x - dx) / k; e.part.y = (b.y - dy) / k; } else e.part.on = false;
    const md = etat === 2 ? (c.t === 'gueule' ? 'agr' : 'actif') : etat === 1 ? 'suit' : 'cont';
    if (md !== e.mode) { e.mode = md; e.m.reglage({ mode: md }); }
    if (b && etat === 1) e.m.vise(0, (b.x - dx) / k, (b.y - dy) / k, .8); else e.m.vise(0, W / k / 2, H / k / 2, .25);
    e.m.update(dt, e.flow, etat ? 1 : .3);
    if (e.dec) { e.geo = e.m.geo(); e.dec.update(dt * (etat ? 2 : 1), e.flow, e.geo); }
    const cx2 = cur[0] * k + dx, cy2 = cur[1] * k + dy;   // = position exacte (la créature est dessinée décalée)
    /* — GESTES ANNONCÉS : calque sous la créature — */
    if (c.t === 'cils') {
      const a = (c.a || 0) * Math.PI / 180, r = c.r, on = etat === 2, I = e.al;
      ctx.globalCompositeOperation = 'lighter';
      halo(ctx, 1, x, y, r * 1.05, .35 + .45 * I);
      /* le COURANT : trois lignes de flux qui traversent la zone dans le sens du cap, chevrons qui défilent */
      const ca = Math.cos(a), sa = Math.sin(a), vit = on ? 1.4 : .45 + .5 * I;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (let l = -2; l <= 2; l++) {
        const off = l * r * .32, half = Math.sqrt(Math.max(0, r * r - off * off)) * .92;
        const bx0 = x - sa * off, by0 = y + ca * off;
        ctx.strokeStyle = AQ + (.12 + .2 * I).toFixed(3) + ')'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(bx0 - ca * half, by0 - sa * half); ctx.lineTo(bx0 + ca * half, by0 + sa * half); ctx.stroke();
        ctx.strokeStyle = AQ + (.45 + .55 * I).toFixed(3) + ')'; ctx.lineWidth = on ? 2.4 : 1.7; ctx.beginPath();
        for (let j = 0; j < 4; j++) {
          const u = ((T * vit + j / 4 + l * .13) % 1 + 1) % 1, s = -half + 2 * half * u, w = Math.sin(u * Math.PI);
          if (w > .15) chevron(ctx, bx0 + ca * s, by0 + sa * s, a, 4 + 4 * w * (on ? 1.4 : 1));
        }
        ctx.stroke();
      }
      /* l'arc de cap : grande flèche courbe qui longe le bord, vers le cap */
      ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = 'rgba(4,10,18,.22)'; ctx.lineWidth = 5 + 1.6 * I;
      ctx.beginPath(); ctx.arc(x, y, r + 7, a - .9, a); ctx.stroke(); ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = PE + (.4 + .5 * I).toFixed(3) + ')'; ctx.lineWidth = 2.4 + 1.6 * I;
      ctx.beginPath(); ctx.arc(x, y, r + 7, a - .9, a); ctx.stroke();
      const hx = x + Math.cos(a) * (r + 7), hy = y + Math.sin(a) * (r + 7);
      ctx.beginPath(); chevron(ctx, hx, hy, a + Math.PI / 2, 9); ctx.stroke();
      ctx.setLineDash([3, 6]); ctx.lineDashOffset = -T * 14 * vit; ctx.strokeStyle = AQ + (.5 + .4 * I).toFixed(3) + ')'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
      /* battement : la bille est saisie par le courant → étincelles le long du cap, onde du bord */
      if (on && b) {
        ctx.strokeStyle = PE + '.9)'; ctx.lineWidth = 1.6; ctx.beginPath();
        for (let j = 0; j < 5; j++) { const o = (j - 2) * 5, u = ((T * 3 + j * .23) % 1); const sx = b.x - ca * (8 + 22 * u) - sa * o, sy = b.y - sa * (8 + 22 * u) + ca * o; ctx.moveTo(sx, sy); ctx.lineTo(sx - ca * 7, sy - sa * 7); }
        ctx.stroke();
        halo(ctx, 1, b.x, b.y, 26, .9);
        const u = (T * 2) % 1; ctx.strokeStyle = AQ + (.7 * (1 - u)).toFixed(3) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r * (.4 + .6 * u), 0, TAU); ctx.stroke();
      }
      ctx.globalCompositeOperation = 'source-over';
    } else if (c.t === 'gueule') {
      const rc = c.rc || 24, hold = c.hold || 70, held = etat === 2, left = held ? st.h - fr : 0, a = (c.a || 0) * Math.PI / 180, I = e.al, v = c.v || 7;
      ctx.globalCompositeOperation = 'lighter';
      halo(ctx, held ? 2 : 1, x, y, rc * (2.4 + 1.2 * e.gon), .3 + .5 * I + .5 * e.fl);
      if (!held) {
        /* guet : l'anneau de capture respire ; quand la bille approche, la gueule s'ouvre vers elle */
        const br = 1 + (.06 + .1 * I) * Math.sin(T * (3 + 6 * I)), rr = rc * br;
        const prete = !st.cd || fr >= st.cd;
        ctx.setLineDash([4, 5]); ctx.lineDashOffset = -T * 16; ctx.strokeStyle = (prete ? AQ : PE) + (prete ? .55 + .45 * I : .25).toFixed(3) + ')'; ctx.lineWidth = 1.6 + 1.6 * I;
        ctx.beginPath(); ctx.arc(x, y, rr, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
        if (b && prete && I > .3) {              // mâchoires : deux arcs qui s'écartent du côté de la bille
          const ab = Math.atan2(b.y - y, b.x - x), ouv = .35 + .6 * I;
          ctx.strokeStyle = PE + (.5 + .5 * I).toFixed(3) + ')'; ctx.lineWidth = 3.2;
          ctx.beginPath(); ctx.arc(x, y, rr + 6, ab + ouv, ab + ouv + 1.1); ctx.stroke();
          ctx.beginPath(); ctx.arc(x, y, rr + 6, ab - ouv - 1.1, ab - ouv); ctx.stroke();
        }
        if (!prete) {                             // repos après un crachat : l'anneau se recharge (arc qui se remplit)
          const f = 1 - (st.cd - fr) / (c.cd || 90); ctx.strokeStyle = AQ + '.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, rc + 5, -Math.PI / 2, -Math.PI / 2 + TAU * f); ctx.stroke();
        }
        flecheAct(ctx, x, y, a, 18 + v * 3.5, PE, (.3 + .3 * I).toFixed(3), 2);   // le cap du crachat est lisible avant même d'être happé
      } else {
        /* prise : compte à rebours en quatre battements (arc qui se vide, crans), le corps palpite de plus en plus vite */
        const f = left / hold, q = 1 - f;
        ctx.strokeStyle = PE + '.95)'; ctx.lineWidth = 4; ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.arc(x, y, rc + 8, -Math.PI / 2, -Math.PI / 2 + TAU * f); ctx.stroke();
        ctx.strokeStyle = AQ + '.35)'; ctx.beginPath(); ctx.arc(x, y, rc + 8, -Math.PI / 2 + TAU * f, Math.PI * 1.5); ctx.stroke();
        ctx.strokeStyle = 'rgba(4,10,18,.9)'; ctx.lineWidth = 2; ctx.beginPath();
        for (let j = 0; j < 4; j++) { const an = -Math.PI / 2 + j * TAU / 4; ctx.moveTo(x + Math.cos(an) * (rc + 5), y + Math.sin(an) * (rc + 5)); ctx.lineTo(x + Math.cos(an) * (rc + 11), y + Math.sin(an) * (rc + 11)); }
        ctx.stroke(); ctx.lineCap = 'round';
        const bat = (q * 4) % 1; if (bat < .2) { ctx.strokeStyle = AQ + (.8 * (1 - bat / .2)).toFixed(3) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, rc + 12 + bat * 60, 0, TAU); ctx.stroke(); }
        e.gon = Math.max(e.gon, .25 + .35 * Math.max(0, Math.sin(T * (8 + 18 * q))));
        if (left < 30) {                         // annonce : la flèche se dresse, des chevrons filent sur le cap
          const u = 1 - left / 30;
          flecheAct(ctx, x, y, a, 20 + v * 7 * u, PE, (.5 + .5 * u).toFixed(3), 3.2);
          ctx.strokeStyle = AQ + (.8 * u).toFixed(3) + ')'; ctx.lineWidth = 2; ctx.beginPath();
          for (let j = 0; j < 4; j++) { const s = 30 + ((T * 90 + j * 22) % 88); chevron(ctx, x + Math.cos(a) * s, y + Math.sin(a) * s, a, 6); }
          ctx.stroke();
        }
      }
      if (etat === 3) {                          // CRACHAT : éclair sur le cap, double onde de choc
        const g = (fr - st.out) / 40, al = 1 - g;
        ctx.strokeStyle = PE + al.toFixed(3) + ')'; ctx.lineWidth = 2.6 * al + .6; ctx.beginPath(); ctx.moveTo(x, y);
        const ca = Math.cos(a), sa = Math.sin(a), L = 40 + 120 * Math.min(1, g * 3);
        for (let j = 1; j <= 7; j++) { const s = L * j / 7, z = (j % 2 ? 1 : -1) * (5 + 4 * ((j * 7) % 3)) * (j < 7 ? 1 : 0); ctx.lineTo(x + ca * s - sa * z, y + sa * s + ca * z); }
        ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = 'rgba(4,10,18,' + (.4 * al).toFixed(3) + ')'; ctx.lineWidth = 2.6 * al + 3.5; ctx.stroke();
        ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = PE + al.toFixed(3) + ')'; ctx.lineWidth = 2.6 * al + .6; ctx.stroke();
        halo(ctx, 2, x + ca * L * .5, y + sa * L * .5, L * .5, al * .8);
        for (const o of [0, 8]) { const u = Math.max(0, (fr - st.out - o) / 32); if (u > 0 && u < 1) { ctx.strokeStyle = PE + (.85 * (1 - u)).toFixed(3) + ')'; ctx.lineWidth = 3 * (1 - u) + .5; ctx.beginPath(); ctx.arc(x, y, rc * (.6 + u * 3), 0, TAU); ctx.stroke(); } }
      }
      if (st.in && fr >= st.in && fr - st.in < 18) {             // happée : l'anneau se referme d'un coup (onde vers l'intérieur) + éclats
        const u = (fr - st.in) / 18; ctx.strokeStyle = AQ + (1 - u).toFixed(3) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, rc * (2.2 - 1.6 * u), 0, TAU); ctx.stroke();
        ctx.strokeStyle = PE + (1 - u).toFixed(3) + ')'; ctx.lineWidth = 1.5; ctx.beginPath();
        for (let j = 0; j < 8; j++) { const an = j * TAU / 8 + .3, r1 = rc * (1 + u * 1.5); ctx.moveTo(x + Math.cos(an) * r1, y + Math.sin(an) * r1); ctx.lineTo(x + Math.cos(an) * (r1 + 8), y + Math.sin(an) * (r1 + 8)); }
        ctx.stroke();
      }
      ctx.globalCompositeOperation = 'source-over';
    } else if (c.t === 'glu') {
      const r = c.r, I = e.al, englue = etat === 2;
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = MV + (.1 + .12 * I).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(x, y, r * 1.08, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      const g = ctx.createRadialGradient(x, y, 0, x, y, r * 1.1); g.addColorStop(0, MV + '.55)'); g.addColorStop(.6, MV + '.3)'); g.addColorStop(1, MV + '0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 1.1, 0, TAU); ctx.fill();
      /* fils collants qui pendent et ondulent ; ils se tendent vers la bille quand elle approche */
      ctx.strokeStyle = MV + (.55 + .4 * I).toFixed(3) + ')'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
      ctx.beginPath();
      for (let j = 0; j < 7; j++) {
        const an = j * TAU / 7 + .2 * Math.sin(T * .8 + j), L = r * (.7 + .25 * Math.sin(T * 1.3 + j * 2)), x0 = x + Math.cos(an) * r * .35, y0 = y + Math.sin(an) * r * .35;
        let ex = x + Math.cos(an) * (r * .35 + L), ey = y + Math.sin(an) * (r * .35 + L) + 6;
        if (b && etat === 1) { const w = .35 * I; ex += (b.x - ex) * w; ey += (b.y - ey) * w; }
        ctx.moveTo(x0, y0); ctx.quadraticCurveTo((x0 + ex) / 2 + 6 * Math.sin(T * 2 + j), (y0 + ey) / 2 + 8, ex, ey);
      }
      ctx.stroke();
      for (let i = 0; i < 9; i++) {              // gouttes qui coulent : « ça colle »
        const u = (T * .3 + i * .137) % 1, ang = i * 2.399, rr = r * (.25 + .6 * ((i * .37) % 1));
        ctx.fillStyle = MV + (.95 * Math.sin(u * Math.PI)).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr + u * 18, 1.8 + .7 * (i % 3), 0, TAU); ctx.fill();
      }
      ctx.setLineDash([3, 5]); ctx.lineDashOffset = T * 6; ctx.strokeStyle = MV + (.6 + .4 * I).toFixed(3) + ')'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
      if (englue && b) {                          // ENGLUÉE : des fils s'étirent de la créature à la bille, s'amincissent, puis cassent
        const D = Math.hypot(b.x - x, b.y - y), tension = Math.min(1, D / 170), casse = D > 150;
        ctx.lineWidth = 2.6 * (1 - tension) + .7;
        for (let j = 0; j < 4; j++) {
          const o = (j - 1.5) * 7, nx = -(b.y - y) / (D || 1), ny = (b.x - x) / (D || 1), sag = 26 * (1 - tension) + 6;
          const mx = (x + b.x) / 2 + nx * o * 2, my = (y + b.y) / 2 + ny * o * 2 + sag;
          ctx.strokeStyle = MV + (.9 - .5 * tension).toFixed(3) + ')'; ctx.beginPath();
          if (!casse) { ctx.moveTo(x + nx * o, y + ny * o); ctx.quadraticCurveTo(mx, my, b.x + nx * o * .3, b.y + ny * o * .3); }
          else {                                  // cassés : deux bouts qui pendent
            const L = 22 + 6 * j; ctx.moveTo(b.x, b.y); ctx.quadraticCurveTo(b.x - (b.x - x) / D * L * .5, b.y + L * .4, b.x - (b.x - x) / D * L * .6 + o * .4, b.y + L);
            ctx.moveTo(x + nx * o, y + ny * o); ctx.quadraticCurveTo(x + (b.x - x) / D * L * .6, y + L * .5, x + (b.x - x) / D * L * .7, y + L * 1.1);
          }
          ctx.stroke();
        }
      }
      if (st.in && fr >= st.in && fr - st.in < 24) {            // contact : éclaboussure mauve
        const u = (fr - st.in) / 24; ctx.strokeStyle = MV + (1 - u).toFixed(3) + ')'; ctx.lineWidth = 3 * (1 - u) + .5;
        ctx.beginPath(); ctx.arc(b ? b.x : x, b ? b.y : y, 10 + u * 40, 0, TAU); ctx.stroke();
      }
    }
    /* — la créature : gonfle à l'alerte et à l'action — */
    const A = Math.min(1, e.a0 * (1.2 + .3 * e.al));
    ctx.save();
    const q = 1 + .1 * e.al * (etat ? 1 : 0) + .22 * e.gon * (c.t === 'gueule' && etat === 2 && st.h - fr < 30 ? -.6 : 1);
    ctx.translate(cx2, cy2); ctx.scale(k * q, k * q); ctx.translate(-cur[0], -cur[1]);
    e.m.draw(ctx, A);
    if (e.dec && e.geo) e.dec.draw(ctx, e.geo, A);
    ctx.restore();
    if (e.fl > .02) { ctx.globalCompositeOperation = 'lighter'; halo(ctx, 2, x, y, 30 + 40 * e.fl, e.fl); ctx.globalCompositeOperation = 'source-over'; }
  }
  /* — la particule engluée : voile mauve + jauge qui se vide + gouttes qui tombent — */
  if (b && b.glu > fr) {
    const left = (b.glu - fr), tot = (lv.cr[0] && lv.cr[0].dur) || 300, x = b.x, y = b.y;
    const g = ctx.createRadialGradient(x, y, 2, x, y, 24); g.addColorStop(0, MV + '.6)'); g.addColorStop(1, MV + '0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 24, 0, TAU); ctx.fill();
    ctx.strokeStyle = MV + '.95)'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(x, y, 14, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, left / tot)); ctx.stroke();
    for (let j = 0; j < 3; j++) { const u = (T * 1.2 + j / 3) % 1; ctx.fillStyle = MV + (.9 * (1 - u)).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(x + (j - 1) * 5, y + 12 + u * 22, 2.2 * (1 - u * .5), 0, TAU); ctx.fill(); }
  }
  ctx.restore();
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
function visibles() { let p = 0; return cur.E.filter(e => { if (p + e.poids > PAL[cur.pal][0] + 1e-6) return false; p += e.poids; return true; }); }
racine.QXCREA.dbg = () => act && act.E.map(e => [e.m.pos(0), e.k]);
racine.QXCREA.niveau = {
  dessiner(ctx, lv, env) { try { dessiner(ctx, lv, env); } catch (e) { try { ctx.restore(); } catch (e2) {} vider(); racine.QXCREA.niveau.panne = String(e && e.message || e); } },
  vider,
  get actif() { return !!cur; },
  pos() { return cur ? visibles().map(e => { const p = e.m.pos(0); return [+(p[0] * e.k).toFixed(2), +(p[1] * e.k).toFixed(2)]; }) : []; },
  stats() { return { ms: mes.n ? mes.s / mes.n : 0, max: mes.max, images: mes.n, palier: cur ? cur.pal : -1, ema: cur ? cur.ema : 0, emaJeu: cur ? cur.emaJ : 0,
    creatures: cur ? visibles().map(e => e.nom) : [], toutes: cur ? cur.E.map(e => e.nom) : [], idx: cur ? cur.idx : null }; },
  etats() { return cur ? cur.E.map(e => e.etat + ':' + e.tn + '@' + Math.round(e.x) + ',' + Math.round(e.y) + '>' + Math.round(e.tx) + ',' + Math.round(e.ty)) : []; },
  signaux() { return cur ? cur.SIG.filter(s => s.on).length : 0; },   // R469 : test
  lieux() { return cur ? cur.LI.map(p => [Math.round(p[0]), Math.round(p[1])]) : []; },   // R469 : test
  raz() { mes.n = 0; mes.s = 0; mes.max = 0; },
  palier(p) { verrou = p >= 0 && p < PAL.length ? p | 0 : -1; if (cur && verrou >= 0) cur.pal = verrou; return verrou; }
};
})(window);
