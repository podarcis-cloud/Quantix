/* =====================================================================
   QXPOOL v4 — pool unique des éléments animés de QUANTIX (tous les mondes).

   Un monde = une liste d'éléments du pool, décrite dans mondes.json
   (vivant.pool). Chaque élément est une fabrique enregistrée ici ; la
   bible POOL_ANIMES.md en donne la légitimité, la famille et les
   attributs normalisés. QXMOTIFS (cells, filament, top, snow, bubbles)
   reste intact : l'élément « motif » en est l'adaptateur.

   API
     QXPOOL.configurer(mondes)
     QXPOOL.definir(nom, { famille, plan, creer(sc, p) })
     const pool = QXPOOL.creer({ monde, l, h, zone, reussite, ancres, cadre, carte, graine })
        cadre = { versEcran(u, v) → [x, y], vImage(y) → 0..1, lI }   (fourni par QXFOND)
     pool.regler({ niveau, vie, qualite, sobre, courant })   // seul endroit qui alloue
     pool.update(dt, flow, energy, bille)     // flow(x, y) en coord. de terrain ; bille {x, y, vx, vy} en px de l'hôte, ou null
     pool.evenement('rebond', { x, y, nx, ny, v })
     pool.dessiner(ctx, t, 'arriere' | 'avant')
   Contrat d'un élément : { regler(k), update(dt), dessiner(ctx, t), evenement?(type, e), effectif?() }
     k = effectif relatif 0..1 (Vie × Qualité) ; rien n'est alloué hors de creer()/regler().
   Règle B5 : après chaque plan, le pool GOMME la zone de réussite. Aucun
   élément n'a à s'en soucier (ils l'évitent en plus par sc.calme).
   ===================================================================== */
(function (racine) {
  'use strict';
  const TAU = Math.PI * 2, NB_SEAUX = 6;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const melange = (a, b, f) => a + (b - a) * f;
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lisse = (a, b, x) => { const t = borne((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  /* ---------- Attributs normalisés (bible §2) : plafonds communs à tous les mondes ---------- */
  const NORME = {
    opaciteMax: { particules: 0.6, traces: 0.85, structures: 0.45, vivants: 0.5, reactifs: 0.9 },
    trait: 1.0,                 // épaisseur de référence du « trait fin lumineux » (px CSS)
    margeReussite: 12,          // marge autour de la zone de réussite (px CSS)
    retraitTerrain: 0.6         // atténuation au cœur du terrain (0 = aucune)
  };
  function aleatoire(graine) {
    let s = graine >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = Math.imul(s ^ (s >>> 15), s | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function toile(l, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(l)); c.height = Math.max(1, Math.round(h)); return c; }

  // Champs factices du banc : fractions du terrain → px (dans le jeu, l'hôte passe o.geo tiré du vrai niveau)
  function geoDuBanc(g, z) {
    const out = { puits: [], aimants: [], vents: [], murs: [], portails: [], detecteurs: [] };
    if (!g) return out;
    for (const k of ['puits', 'aimants', 'portails', 'detecteurs']) for (const q of (g[k] || [])) out[k].push({ x: z.x + q.x * z.l, y: z.y + q.y * z.h, r: q.r, f: q.f });
    for (const m of (g.murs || [])) out.murs.push({ x1: z.x + m[0] * z.l, y1: z.y + m[1] * z.h, x2: z.x + m[2] * z.l, y2: z.y + m[3] * z.h, glace: !!m[4] });   // murs = [x1, y1, x2, y2, glace?] en fractions
    return out;
  }
  function geoComplete(g) { for (const k of ['puits', 'aimants', 'vents', 'murs', 'portails', 'detecteurs']) if (!g[k]) g[k] = []; return g; }
  let MONDES = {};
  const FABRIQUES = {};

  /* ---------- Sprites partagés (grammaire commune : point, lueur, flou) ---------- */
  function lueurSprite(c, dur) {
    const s = toile(48, 48), g = s.getContext('2d'), r = g.createRadialGradient(24, 24, 0, 24, 24, 24);
    r.addColorStop(0, rgba(c, 1)); r.addColorStop(dur ? 0.10 : 0.2, rgba(c, dur ? 0.7 : 0.45)); r.addColorStop(dur ? 0.3 : 0.55, rgba(c, 0.12)); r.addColorStop(1, rgba(c, 0));
    g.fillStyle = r; g.fillRect(0, 0, 48, 48);
    return s;
  }
  function bokehSprite(c) {
    const s = toile(96, 96), g = s.getContext('2d'), r = g.createRadialGradient(48, 48, 0, 48, 48, 48);
    r.addColorStop(0, rgba(c, 0.5)); r.addColorStop(0.72, rgba(c, 0.6)); r.addColorStop(0.86, rgba(c, 0.95)); r.addColorStop(1, rgba(c, 0));
    g.fillStyle = r; g.fillRect(0, 0, 96, 96);
    return s;
  }
  function teinteDe(cfg, d, k) {
    const T = cfg.vivant.teintes;
    let i = 0;
    while (i < T.length - 2 && d > T[i + 1].d) i++;
    const A = T[i], B = T[i + 1], f = borne((d - A.d) / (B.d - A.d), 0, 1), ca = cfg.palette[A[k]], cb = cfg.palette[B[k]];
    return [0, 1, 2].map(j => Math.round(melange(ca[j], cb[j], f)));
  }
  const cacheSprites = {};
  function spritesDe(nom) {
    if (cacheSprites[nom]) return cacheSprites[nom];
    const cfg = MONDES[nom], sp = { fin: [], doux: [], bokeh: [], rgb: [], brut: [] };
    for (let k = 0; k < NB_SEAUX; k++) {
      const d = k / (NB_SEAUX - 1), a = teinteDe(cfg, d, 'a'), b = teinteDe(cfg, d, 'b');
      sp.fin.push([lueurSprite(a, true), lueurSprite(b, true)]); sp.doux.push([lueurSprite(a, false), lueurSprite(b, false)]);
      sp.bokeh.push(bokehSprite(a)); sp.rgb.push([rgba(a, 1), rgba(b, 1)]); sp.brut.push([a, b]);
    }
    return (cacheSprites[nom] = sp);
  }

  const cacheJetons = {};
  function spriteJeton(sc, jeton, dur) {             // lueur d'un jeton précis de la palette (ex. « or » du rebond) ; appelée dans creer() seulement
    if (jeton === 'or') jeton = 'blanc';              // fond11 : pas d'or dans le décor (ambre/or réservés au trait du joueur) — l'éclat du rebond est blanc
    const c = sc.cfg.palette[jeton] || [234, 246, 255], cle = c.join(',') + (dur ? 'd' : 's');
    return cacheJetons[cle] || (cacheJetons[cle] = lueurSprite(c, dur));
  }
  const rgbJeton = (sc, jeton) => rgba(sc.cfg.palette[jeton === 'or' ? 'blanc' : jeton] || [234, 246, 255], 1);

  /* =====================================================================
     creer() : la scène partagée + les éléments du niveau
     ===================================================================== */
  function creer(o) {
    const cfg = MONDES[o.monde], V = cfg.vivant, l = o.l, h = o.h, zone = o.zone || null, carte = !!o.carte;
    const sp = spritesDe(o.monde), cadre = o.cadre, but = o.reussite || null, butR = but ? but.r + NORME.margeReussite : 0;
    const retrait = (V.terrain && V.terrain.retrait) || NORME.retraitTerrain;
    const r = { niveau: 1, vie: 1, qualite: 1, sobre: false, courant: 1 };
    let flowBrut = null;
    const nul = [0, 0];
    const sc = {                                   // scène : tout ce qu'un élément a le droit de connaître
      l, h, zone, carte, sp, cfg, ancres: o.ancres || {}, cadre, NORME,
      ox: zone ? zone.x : 0, oy: zone ? zone.y : 0, courant: 1, energie: 0, t: 0, bille: null, niveau: 1,
      geo: geoComplete(o.geo || geoDuBanc(V.geo_banc, zone || { x: 0, y: 0, l, h })),   // champs du niveau (puits, aimants, vents), en px de l'hôte
      attenuation: o.attenuation === undefined ? 1 : o.attenuation,
      pal: j => cfg.palette[j],
      seau: y => Math.round(cadre.vImage(y) * (NB_SEAUX - 1)),
      flux(x, y) { return flowBrut ? flowBrut(x - sc.ox, y - sc.oy) : nul; },
      calme(x, y) {                                // 1 hors terrain → (1 − retrait) au cœur ; 0 dans la zone de réussite
        let c = sc.attenuation;
        if (zone) {
          c -= retrait * lisse(zone.x - 10, zone.x + 50, x) * (1 - lisse(zone.x + zone.l - 50, zone.x + zone.l + 10, x))
            * lisse(zone.y - 10, zone.y + 50, y) * (1 - lisse(zone.y + zone.h - 50, zone.y + zone.h + 10, y));
        }
        if (but) { const dx = x - but.x, dy = y - but.y; c *= lisse(butR, butR + 22, Math.sqrt(dx * dx + dy * dy)); }
        return c;
      },
      loinDuBut(x, y, rayon) {
        if (!but) return 1;
        const dx = x - but.x, dy = y - but.y;
        return lisse(butR + rayon, butR + rayon + 24, Math.sqrt(dx * dx + dy * dy));
      },
      point(ctx, img, x, y, taille, alpha) {       // lueur : le geste de dessin le plus partagé du pool
        if (alpha <= 0.004) return;
        ctx.globalAlpha = alpha > 1 ? 1 : alpha;
        ctx.drawImage(img, x - taille / 2, y - taille / 2, taille, taille);
      }
    };
    let elements = [], fige = false, gomme = null, ctxGomme = null;
    const calmeMouvement = () => false;   // fond10 : comme le jeu depuis R296, le réglage système « réduire les animations » est ignoré (seul « sobre » = réglage du jeu compte)

    function regler(nv) {
      const avant = r.niveau;
      for (const k in nv) if (k in r) r[k] = nv[k];
      fige = r.sobre || calmeMouvement();
      sc.courant = r.courant; sc.niveau = r.niveau;
      const vie = fige ? 0 : borne(r.vie, 0, 1.5) / 1.5, q = borne(r.qualite, 0.5, 1), kq = 0.4 + 0.6 * (q - 0.5) * 2;
      // Les éléments sont (re)composés à chaque changement de niveau : chaque niveau a sa variante (graine = monde + niveau)
      if (!elements.length || avant !== r.niveau || nv.recomposer) {
        elements = []; sc.occupes = [];          // places prises (placeCalme) : les objets du pool ne se chevauchent pas
        const liste = carte ? (V.pool_carte || V.pool.filter(p => p.carte)) : V.pool;
        liste.forEach((p, i) => {
          if (!carte && p.niveaux && !p.niveaux.includes(r.niveau)) return;
          const F = FABRIQUES[p.e];
          if (!F || (o.sauf && o.sauf.includes(p.e))) return;
          sc.alea = aleatoire((o.graine || 1) * 7919 + r.niveau * 131 + i * 977 + (cfg.graine || 0));
          elements.push({ p, F, inst: F.creer(sc, p), actif: true });
        });
      }
      for (const e of elements) {
        e.actif = !fige && (!e.p.vieMin || r.vie >= e.p.vieMin) && (!e.p.qualiteMin || q >= e.p.qualiteMin);
        e.inst.regler(e.actif ? vie * kq * (e.p.densite === undefined ? 1 : e.p.densite) : 0, { vie: r.vie, qualite: q });
      }
    }
    function update(dt, flow, energy, bille) {
      if (fige) return;
      flowBrut = flow; sc.energie = energy; sc.bille = bille || null; sc.t += dt;
      for (const e of elements) if (e.actif) e.inst.update(dt);
    }
    function evenement(type, ev) { if (!fige) for (const e of elements) if (e.actif && e.inst.evenement) e.inst.evenement(type, ev); }
    function dessiner(ctx, t, plan) {
      if (fige) return;
      let dessine = false;
      for (const e of elements) {
        if (!e.actif || (e.F.plan || 'arriere') !== plan) continue;
        e.inst.dessiner(ctx, t); dessine = true;
      }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      if (but && dessine) {                        // B5, appliquée une fois pour tout le pool
        const R = butR + 18;
        if (ctx !== ctxGomme) { ctxGomme = ctx; gomme = ctx.createRadialGradient(but.x, but.y, butR, but.x, but.y, R); gomme.addColorStop(0, 'rgba(0,0,0,1)'); gomme.addColorStop(1, 'rgba(0,0,0,0)'); }
        ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = gomme; ctx.fillRect(but.x - R, but.y - R, 2 * R, 2 * R);
        ctx.globalCompositeOperation = 'source-over';
      }
    }
    return {
      regler, update, evenement, dessiner,
      lueur(y, b) { return sp.doux[sc.seau(y)][b ? 1 : 0]; },
      get noms() { return elements.filter(e => e.actif).map(e => e.p.nom || e.p.e); },
      get effectif() { let n = 0; for (const e of elements) if (e.actif && e.inst.effectif) n += e.inst.effectif(); return n; }
    };
  }

  /* =====================================================================
     ÉLÉMENTS — famille « particules ambiantes »
     ===================================================================== */
  // poussiere : PARTAGÉ PAR TOUS LES MONDES. Points qui dérivent (chute > 0 : neige marine ; < 0 : braises),
  // portés par le flux, qui s'éveillent au passage du courant et S'ÉCARTENT de la bille.
  FABRIQUES.poussiere = { famille: 'particules', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, N = Math.round(p.max * sc.l * sc.h / (390 * 844));
    const x = new Float32Array(N), y = new Float32Array(N), ph = new Float32Array(N), ta = new Float32Array(N), vx = new Float32Array(N), vy = new Float32Array(N), ev = new Float32Array(N), ab = new Uint8Array(N), z = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      x[i] = A() * sc.l; y[i] = A() * sc.h; ph[i] = A() * TAU; z[i] = 0.3 + 0.7 * A();           // z = profondeur : parallaxe et taille
      ta[i] = melange(p.taille[0], p.taille[1], z[i] * z[i]); ab[i] = A() < 0.24 ? 1 : 0;
      vx[i] = (A() - 0.5) * p.derive; vy[i] = melange(p.chute[0], p.chute[1], A());
    }
    let n = 0;
    const alphaMax = Math.min(p.alpha, sc.NORME.opaciteMax.particules), ecart = p.ecart === undefined ? 44 : p.ecart, IMP = [];
    return {
      regler(k) { n = Math.round(N * k); }, effectif: () => n,
      evenement(type, e) {   // fond8 (option rebondAttire) : happée vers l'impact, puis relâchée — intensité ∝ v
        if (type !== 'rebond' || !p.rebondAttire) return;
        if (IMP.length >= 3) IMP.shift(); IMP.push({ x: e.x, y: e.y, age: 0, f: borne((e.v === undefined ? 300 : e.v) / 420, 0.25, 1.5) });
      },
      update(dt) {
        const k = p.flux * sc.courant, b = sc.bille;
        for (let j = IMP.length - 1; j >= 0; j--) { IMP[j].age += dt; if (IMP[j].age > 1.6) IMP.splice(j, 1); }
        for (let i = 0; i < n; i++) {
          const f = sc.flux(x[i], y[i]), vit = Math.hypot(f[0], f[1]);
          x[i] += (f[0] * k + vx[i]) * z[i] * dt; y[i] += (f[1] * k + vy[i]) * z[i] * dt;
          ev[i] += ((vit > p.eveil ? 1 : vit / p.eveil * 0.4) * (0.4 + 0.6 * sc.energie) - ev[i]) * Math.min(1, dt * 2.5);
          if (p.versPuits) for (const w of sc.geo.puits) {  // tombe vers les puits de potentiel (remonte des bosses)
            const dx = w.x - x[i], dy = w.y - y[i], d2 = dx * dx + dy * dy + 400, g = p.versPuits * w.f * w.r * w.r / d2 * dt / Math.sqrt(d2);
            x[i] += (dx - dy * (p.spirale || 0)) * g * 40; y[i] += (dy + dx * (p.spirale || 0)) * g * 40;   // spirale : composante tangentielle (chute en orbite)
          }
          for (let j = 0; j < IMP.length; j++) {        // impact : attraction (0–0,5 s) puis relâchement (0,5–1,6 s)
            const I = IMP[j], dx = I.x - x[i], dy = I.y - y[i], d = Math.sqrt(dx * dx + dy * dy) + 1, R = 150 * I.f;
            if (d < R) { const s0 = I.age < 0.5 ? 1 : -0.55 * (1 - (I.age - 0.5) / 1.1), g = s0 * I.f * (1 - d / R) * 140 * z[i] * dt; x[i] += dx / d * g; y[i] += dy / d * g; ev[i] = Math.min(1, ev[i] + dt * 2 * I.f); }
          }
          if (b) {                                     // la poussière s'écarte de la bille (règle de production n° 2)
            const dx = x[i] - b.x, dy = y[i] - b.y, dd = dx * dx + dy * dy;
            if (dd < ecart * ecart && dd > 1) { const d = Math.sqrt(dd), pousse = (1 - d / ecart) * 90 * z[i] * dt; x[i] += dx / d * pousse; y[i] += dy / d * pousse; ev[i] = Math.min(1, ev[i] + dt * 3); }
          }
          if (x[i] < -8) x[i] += sc.l + 16; else if (x[i] > sc.l + 8) x[i] -= sc.l + 16;
          if (y[i] < -8) y[i] += sc.h + 16; else if (y[i] > sc.h + 8) y[i] -= sc.h + 16;
        }
      },
      dessiner(ctx, t) {
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < n; i++) {
          const scn = 0.55 + 0.45 * Math.sin(t * (p.scintille || 1.3) + ph[i]);
          sc.point(ctx, sc.sp.fin[sc.seau(y[i])][ab[i]], x[i], y[i], ta[i] * (1 + 0.8 * ev[i]) * 4, (alphaMax * scn * (0.4 + 0.6 * z[i]) + p.alphaEveil * ev[i]) * sc.calme(x[i], y[i]));
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };
  // proches : flous d'avant-plan (profondeur de champ). Premier élément retiré quand la qualité baisse.
  FABRIQUES.proches = { famille: 'particules', plan: 'avant', creer(sc, p) {
    const A = sc.alea, L = [];
    for (let i = 0; i < p.max; i++) L.push({ x: A() * sc.l, y: A() * sc.h, t: melange(p.taille[0], p.taille[1], A()), ph: A() * TAU, vx: (A() - 0.5) * 9, vy: (A() - 0.5) * 6 + (p.chute || 0) });
    let n = 0;
    return {
      regler(k, q) { n = q.qualite < 0.8 ? 0 : Math.round(p.max * Math.min(1, k * 1.2)); }, effectif: () => n,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = L[i];
          q.x += q.vx * dt * (0.5 + sc.courant) - (b ? b.vx * 0.04 * dt : 0); q.y += q.vy * dt - (b ? b.vy * 0.04 * dt : 0);   // parallaxe : l'avant-plan glisse à contresens de la bille
          if (q.x < -q.t) q.x += sc.l + 2 * q.t; else if (q.x > sc.l + q.t) q.x -= sc.l + 2 * q.t;
          if (q.y < -q.t) q.y += sc.h + 2 * q.t; else if (q.y > sc.h + q.t) q.y -= sc.h + 2 * q.t;
        }
      },
      dessiner(ctx, t) {
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < n; i++) { const q = L[i]; sc.point(ctx, sc.sp.bokeh[sc.seau(q.y)], q.x, q.y, q.t, p.alpha * (0.6 + 0.4 * Math.sin(t * 0.3 + q.ph)) * (sc.calme(q.x, q.y) ** 2) * sc.loinDuBut(q.x, q.y, q.t * 0.5)); }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };

  /* =====================================================================
     ÉLÉMENTS — famille « structures »
     ===================================================================== */
  // voile_points : PARTAGÉ PAR TOUS LES MONDES (signature du jeu : nuage de points en volume, rotation au sens ambigu).
  // Formes : globe, tore, tetra, noeud, disque, reseau. Une forme par monde (bible §4).
  function formeVolume(genre, n, A) {
    const P = new Float32Array(n * 3), GA = 2.39996323;
    for (let i = 0; i < n; i++) {
      let x, y, z; const u = (i + 0.5) / n;
      if (genre === 'tore') { const a = i * GA, b = u * TAU * 9; x = (1 + 0.36 * Math.cos(b)) * Math.cos(a) * 0.74; y = 0.36 * Math.sin(b) * 0.74; z = (1 + 0.36 * Math.cos(b)) * Math.sin(a) * 0.74; }
      else if (genre === 'noeud') { const a = u * TAU, rr = 0.07 * (A() - 0.5); x = (Math.sin(a) + 2 * Math.sin(2 * a)) / 3 + rr; y = (Math.cos(a) - 2 * Math.cos(2 * a)) / 3 + rr; z = -Math.sin(3 * a) / 1.6 + rr; }
      else if (genre === 'tetra') {                    // arêtes d'un tétraèdre + sommets en grappes : la « molécule » de la chambre à bulles
        const S = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], ar = [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]][i % 6], f = A();
        const a = S[ar[0]], b = S[ar[1]], g = 0.05; x = (a[0] + (b[0] - a[0]) * f) * 0.58 + (A() - 0.5) * g; y = (a[1] + (b[1] - a[1]) * f) * 0.58 + (A() - 0.5) * g; z = (a[2] + (b[2] - a[2]) * f) * 0.58 + (A() - 0.5) * g;
      } else if (genre === 'disque') { const rr = Math.sqrt(u), a = i * GA; x = rr * Math.cos(a); y = (A() - 0.5) * 0.08; z = rr * Math.sin(a); }
      else if (genre === 'reseau') { const m = Math.round(Math.cbrt(n)); x = ((i % m) / (m - 1) - 0.5) * 1.5; y = ((Math.floor(i / m) % m) / (m - 1) - 0.5) * 1.5; z = (Math.floor(i / m / m) / (m - 1) - 0.5) * 1.5; }
      else { const th = Math.acos(1 - 2 * u), a = i * GA; x = Math.sin(th) * Math.cos(a); y = Math.cos(th); z = Math.sin(th) * Math.sin(a); }
      P[i * 3] = x; P[i * 3 + 1] = y; P[i * 3 + 2] = z;
    }
    return P;
  }
  FABRIQUES.voile_points = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, V = [];
    for (let i = 0; i < p.voiles.length; i++) {
      const d = p.voiles[i], n = d.points || 260;
      V.push({ P: formeVolume(d.forme, n, A), n, cx: borne(d.x + (A() - 0.5) * 0.3, 0.08, 0.92) * sc.l, cy: borne(d.y + (A() - 0.5) * 0.26, 0.06, 0.94) * sc.h,
        R: d.rayon * (0.8 + 0.5 * A()), a: d.alpha, vit: d.vitesse * (A() < 0.5 ? -1 : 1), ph: A() * TAU, incl: 0.5 + A() * 0.9, vx: 0, vy: 0 });
    }
    let k = 0;
    const aMax = sc.NORME.opaciteMax.structures;
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? V.reduce((s, v) => s + v.n, 0) : 0),
      update(dt) {
        const b = sc.bille;
        for (const v of V) {                           // dérive lente + recul devant la bille (jamais sur la trajectoire)
          const f = sc.flux(v.cx, v.cy);
          v.vx += (f[0] * 0.05 * sc.courant - v.vx) * dt; v.vy += (f[1] * 0.05 * sc.courant - v.vy) * dt;
          if (b) { const dx = v.cx - b.x, dy = v.cy - b.y, d = Math.hypot(dx, dy) || 1; if (d < v.R + 50) { v.vx += dx / d * 26 * dt; v.vy += dy / d * 26 * dt; } }
          v.cx = borne(v.cx + v.vx * dt, -v.R * 0.3, sc.l + v.R * 0.3); v.cy = borne(v.cy + v.vy * dt, -v.R * 0.3, sc.h + v.R * 0.3);
        }
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.globalCompositeOperation = 'lighter';
        for (const v of V) {
          const ry = t * v.vit + v.ph, rx = v.incl + Math.sin(t * 0.13 + v.ph) * 0.25, cy = Math.cos(ry), sy = Math.sin(ry), cx = Math.cos(rx), sx = Math.sin(rx);
          const s = sc.seau(v.cy), att = sc.calme(v.cx, v.cy) * sc.loinDuBut(v.cx, v.cy, v.R), pas = k < 0.55 ? 2 : 1;
          if (att <= 0.02) continue;
          for (let passe = 0; passe < 2; passe++) {
            ctx.fillStyle = sc.sp.rgb[s][passe];
            for (let i = passe; i < v.n; i += 2 * pas) {
              const X = v.P[i * 3], Y = v.P[i * 3 + 1], Z = v.P[i * 3 + 2];
              const x1 = X * cy + Z * sy, z1 = -X * sy + Z * cy, y1 = Y * cx - z1 * sx, z2 = Y * sx + z1 * cx, pr = 1 / (1 - z2 * 0.22), t2 = (0.9 + 0.7 * pr) * (z2 > 0 ? 1.15 : 0.85);
              ctx.globalAlpha = Math.min(aMax, v.a * (0.3 + 0.7 * (z2 + 1.3) / 2.3)) * att;
              ctx.fillRect(v.cx + x1 * v.R * pr - t2 / 2, v.cy + y1 * v.R * pr - t2 / 2, t2, t2);
            }
          }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };
  // ancres : PARTAGÉ. Lueurs accrochées aux éléments cuits dans l'image (tiges, traces, amas, cœurs) : le décor peint paraît vivant.
  FABRIQUES.ancres = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, an = sc.ancres, fils = [], pts = [];
    for (const cle of ['tiges', 'siphonophores', 'traces']) for (const uv of (an[cle] || [])) {
      const f = { x: new Float32Array(uv.length), y: new Float32Array(uv.length), s: -1, attente: A() * 6, duree: 4, vu: false, ab: A() < 0.3 ? 1 : 0 };
      for (let i = 0; i < uv.length; i++) { const e = sc.cadre.versEcran(uv[i][0], uv[i][1]); f.x[i] = e[0]; f.y[i] = e[1]; if (e[1] > -10 && e[1] < sc.h + 10 && e[0] > -10 && e[0] < sc.l + 10) f.vu = true; }
      if (f.vu) fils.push(f);
    }
    for (const cle of ['amas', 'meduses']) for (const a of (an[cle] || [])) {
      const e = sc.cadre.versEcran(a[0], a[1]);
      if (e[1] > -30 && e[1] < sc.h + 30 && e[0] > -30 && e[0] < sc.l + 30) pts.push({ x: e[0], y: e[1], r: a[2] * sc.cadre.lI, ph: A() * TAU, coeur: cle === 'meduses' });
    }
    let k = 0;
    return {
      regler(kk) { k = kk > 0 ? 1 : 0; }, effectif: () => k * (fils.length * 3 + pts.length * 4),
      update(dt) {
        for (const f of fils) {
          if (f.s < 0) { f.attente -= dt * (0.6 + 1.4 * sc.energie); if (f.attente <= 0) { f.s = 0; f.duree = melange(p.eclair[0], p.eclair[1], 0.5 + 0.5 * Math.sin(sc.t * 7 + f.x[0])) * 0.5; } }
          else { f.s += dt / f.duree; if (f.s >= 1) { f.s = -1; f.attente = melange(p.eclair[0], p.eclair[1], Math.abs(Math.sin(sc.t * 3.3 + f.y[0]))); } }
        }
      },
      dessiner(ctx, t) {
        if (!k) return;
        ctx.globalCompositeOperation = 'lighter';
        const kb = p.alpha || 1;
        for (const f of fils) {
          if (f.s < 0) continue;
          const n = f.x.length - 1, env = Math.sin(Math.PI * f.s);
          for (let q = 0; q < 3; q++) {
            const s = borne(f.s - q * 0.07, 0, 1) * n, j = Math.min(n - 1, Math.floor(s)), fr = s - j, x = f.x[j] + (f.x[j + 1] - f.x[j]) * fr, y = f.y[j] + (f.y[j + 1] - f.y[j]) * fr;
            sc.point(ctx, sc.sp.doux[sc.seau(y)][f.ab], x, y, 22 - q * 5, kb * env * (0.75 - q * 0.22) * sc.calme(x, y));
          }
        }
        for (const a of pts) {
          const s = sc.seau(a.y), c = sc.calme(a.x, a.y);
          if (a.coeur) { sc.point(ctx, sc.sp.doux[s][0], a.x, a.y - a.r * 0.3, a.r * 3.4, kb * (0.13 + 0.09 * Math.sin(t * 0.9 + a.ph)) * c); continue; }
          sc.point(ctx, sc.sp.doux[s][0], a.x, a.y, a.r * 3.2, kb * (0.10 + 0.07 * Math.sin(t * 0.5 + a.ph) + 0.1 * sc.energie) * c);
          for (let q = 0; q < 3; q++) { const an2 = a.ph + q * 2.1, e = Math.max(0, Math.sin(t * (0.7 + q * 0.23) + an2 * 3)) ** 4; sc.point(ctx, sc.sp.fin[s][q === 2 ? 1 : 0], a.x + Math.cos(an2) * a.r * 0.9, a.y + Math.sin(an2 * 1.7) * a.r * 0.4, 14, kb * e * 0.8 * c); }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };

  /* =====================================================================
     ÉLÉMENTS — famille « traces et trajectoires »
     ===================================================================== */
  // traces : trajectoire d'une particule chargée dans un champ (chambre à bulles) : naît au bord, s'enroule en spirale
  // qui se resserre à mesure qu'elle perd son énergie, laisse un chapelet de micro-bulles qui grossissent puis s'effacent.
  // Réactif : chaque REBOND de la bille lance une trace forte depuis le point d'impact ; « paires » = création de paires (V).
  // Même loi que le jeu actuel (visuals.js, spawnTrack) : a += q·k·3/v ; v ×= 0,985 par pas de 1/60 s.
  FABRIQUES.traces = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, MAXT = p.max || 9, NP = p.points || 110, T = [];
    for (let i = 0; i < MAXT; i++) T.push({ x: new Float32Array(NP), y: new Float32Array(NP), n: 0, tete: 0, px: 0, py: 0, a: 0, v: 0, q: 1, k: 0, age: 0, vie: 0, vif: false, ab: 0, acc: 0, actif: false });
    let k = 0, horloge = 1.2, tours = 0;
    const aMax = Math.min(p.alpha || 0.8, sc.NORME.opaciteMax.traces), frein = p.frein || 0.985;
    function lancer(x, y, ang, vit, vif, q) {
      let tr = null;
      for (const c of T) if (!c.actif) { tr = c; break; }
      if (!tr) { tr = T[0]; for (const c of T) if (!c.vif && c.age / c.vie > tr.age / tr.vie) tr = c; }    // on recycle la plus vieille des faibles
      tr.actif = true; tr.n = 0; tr.tete = 0; tr.px = x; tr.py = y; tr.a = ang; tr.v = vit; tr.q = q || (A() < 0.5 ? -1 : 1);
      tr.k = melange(p.courbure[0], p.courbure[1], A()); tr.age = 0; tr.vie = vif ? p.vie[1] : melange(p.vie[0], p.vie[1], A() * 0.7); tr.vif = !!vif; tr.ab = vif || A() < 0.3 ? 1 : 0; tr.acc = 0;
    }
    function duBord() {
      const cote = Math.floor(A() * 4), x = cote === 0 ? -6 : cote === 1 ? sc.l + 6 : A() * sc.l, y = cote === 2 ? sc.h + 6 : cote === 3 ? -6 : sc.h * (0.1 + 0.8 * A());
      const ang = Math.atan2(sc.h * (0.3 + 0.4 * A()) - y, sc.l * (0.25 + 0.5 * A()) - x) + (A() - 0.5) * 0.9, vit = melange(p.vitesse[0], p.vitesse[1], A());
      if (A() < (p.paires || 0)) {                     // création de paire : deux spirales opposées depuis un même point du champ
        const px = sc.l * (0.08 + 0.84 * A()), py = sc.h * (0.08 + 0.84 * A());
        if (sc.calme(px, py) > 0.7) { const a0 = A() * TAU; lancer(px, py, a0 - 0.22, vit * 0.9, false, 1); lancer(px, py, a0 + 0.22, vit * 0.9, false, -1); return; }
      }
      lancer(x, y, ang, vit, false, 0);
    }
    return {
      regler(kk) { k = kk; }, effectif: () => T.reduce((s, c) => s + (c.actif ? c.n : 0), 0),
      evenement(type, e) { if (type === 'rebond' && k > 0 && e.v > (p.seuilRebond || 60)) lancer(e.x, e.y, Math.atan2(e.ny, e.nx) + (A() - 0.5) * 0.7, p.vitesse[1] * (1 + Math.min(1, e.v / 500)), true, 0); },
      update(dt) {
        if (k <= 0) return;
        horloge -= dt * (0.5 + sc.energie) * (0.4 + 0.6 * k);
        if (horloge <= 0) { horloge = melange(p.periode[0], p.periode[1], A()); duBord(); }
        const pas = dt * 60;
        for (const tr of T) {
          if (!tr.actif) continue;
          tr.age += dt;
          if (tr.age >= tr.vie) { tr.actif = false; continue; }
          if (tr.v > 0.25) {
            tr.a += tr.q * tr.k * (3 / tr.v) * pas; tr.v *= Math.pow(frein, pas);
            const f = sc.flux(tr.px, tr.py);           // le fluide de la chambre entraîne un peu la particule
            tr.px += (Math.cos(tr.a) * tr.v * 60 + f[0] * 0.25 * sc.courant) * dt; tr.py += (Math.sin(tr.a) * tr.v * 60 + f[1] * 0.25 * sc.courant) * dt;
            tr.acc += tr.v * pas;
            if (tr.acc >= (p.pas || 3.2)) { tr.acc = 0; tr.x[tr.tete] = tr.px; tr.y[tr.tete] = tr.py; tr.tete = (tr.tete + 1) % NP; if (tr.n < NP) tr.n++; }
          }
        }
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.globalCompositeOperation = 'lighter';
        for (const tr of T) {
          if (!tr.actif || tr.n < 2) continue;
          const fd = Math.min(1, (tr.vie - tr.age) / 1.2) * Math.min(1, tr.age / 0.15), s = sc.seau(tr.py), deb = (tr.tete - tr.n + NP) % NP;
          const att = sc.calme(tr.px, tr.py) * 0.5 + 0.5;
          ctx.fillStyle = sc.sp.rgb[s][tr.ab];
          for (let bande = 0; bande < 3; bande++) {    // trois bandes d'opacité : la queue s'éteint, sans un remplissage par point
            const i0 = Math.floor(tr.n * bande / 3), i1 = Math.floor(tr.n * (bande + 1) / 3);
            ctx.globalAlpha = aMax * fd * (0.22 + 0.34 * bande) * (tr.vif ? 1 : 0.7) * att;
            ctx.beginPath();
            for (let i = i0; i < i1; i++) {
              const j = (deb + i) % NP, vieux = 1 - i / tr.n, r = (tr.vif ? 0.9 : 0.7) + vieux * (p.grossit || 1.1) + (i % 4 === 0 ? 0.5 : 0);   // micro-bulles : elles grossissent en vieillissant
              ctx.moveTo(tr.x[j] + r, tr.y[j]); ctx.arc(tr.x[j], tr.y[j], r, 0, TAU);
            }
            ctx.fill();
          }
          if (tr.v > 0.25) sc.point(ctx, sc.sp.doux[s][tr.ab], tr.px, tr.py, tr.vif ? 26 : 16, aMax * fd * (tr.vif ? 1 : 0.7) * sc.calme(tr.px, tr.py));
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };
  // emission : lignes d'émission (colorant injecté en un point fixe et emporté par l'écoulement) — la visualisation
  // classique de la mécanique des fluides. Les points naissent à la source, vieillissent, meurent ; la ligne répond au flux.
  FABRIQUES.emission = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NP = p.points || 46, L = [];
    const z = sc.zone || { x: 0, y: 0, l: sc.l, h: sc.h };
    for (let i = 0; i < p.max; i++) {
      const u = (i + 0.5) / p.max, bas = i % 2 === 0;
      L.push({ sx: z.x + z.l * (0.12 + 0.76 * ((u * 1.7 + A() * 0.2) % 1)), sy: bas ? z.y + z.h * (0.9 + 0.08 * A()) : z.y + z.h * (0.1 + 0.5 * A()),
        x: new Float32Array(NP), y: new Float32Array(NP), n: 0, tete: 0, acc: A() * 0.2, ab: i % 3 === 2 ? 1 : 0, ph: A() * TAU });
    }
    let n = 0;
    const aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.traces), cad = p.cadence || 0.11;
    return {
      regler(k) { n = Math.min(L.length, Math.round(L.length * k + 0.3)); }, effectif: () => n * NP,
      update(dt) {
        for (let q = 0; q < n; q++) {
          const e = L[q];
          for (let i = 0; i < e.n; i++) { const f = sc.flux(e.x[i], e.y[i]); e.x[i] += f[0] * sc.courant * dt * p.flux; e.y[i] += f[1] * sc.courant * dt * p.flux; }
          e.acc += dt;
          if (e.acc >= cad) { e.acc = 0; e.x[e.tete] = e.sx + Math.sin(sc.t * 0.7 + e.ph) * 3; e.y[e.tete] = e.sy; e.tete = (e.tete + 1) % NP; if (e.n < NP) e.n++; }
        }
      },
      dessiner(ctx) {
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        for (let q = 0; q < n; q++) {
          const e = L[q];
          if (e.n < 4) continue;
          ctx.strokeStyle = sc.sp.rgb[sc.seau(e.sy)][e.ab];
          for (let bande = 0; bande < 4; bande++) {    // du plus vieux (pâle, large : le colorant diffuse) au plus jeune (net)
            const i0 = Math.floor((e.n - 1) * bande / 4), i1 = Math.floor((e.n - 1) * (bande + 1) / 4);
            let j = (e.tete - e.n + i0 + NP * 2) % NP;
            ctx.globalAlpha = aMax * (p.fin ? 0.08 + 0.2 * bande : 0.16 + 0.28 * bande) * sc.calme(e.x[j], e.y[j]);
            ctx.lineWidth = sc.NORME.trait * (p.fin ? 1.2 - 0.17 * bande : 2.0 - 0.36 * bande);   // fin : filet de fumée (1,2 → 0,7 px)
            ctx.beginPath(); ctx.moveTo(e.x[j], e.y[j]);
            for (let i = i0 + 1; i <= i1; i++) { j = (e.tete - e.n + i + NP * 2) % NP; ctx.lineTo(e.x[j], e.y[j]); }
            ctx.stroke();
          }
          sc.point(ctx, sc.sp.doux[sc.seau(e.sy)][e.ab], e.sx, e.sy, p.fin ? 7 : 12, aMax * (p.fin ? 0.55 : 0.9) * sc.calme(e.sx, e.sy));
        }
        ctx.globalAlpha = 1;
      }
    };
  } };

  // filets (monde 5) : le vent rendu visible — filets de fumée très fins portés par l'écoulement, sur trois profondeurs
  // (lointain : long, lent, pâle ; moyen ; proche : court, vif, tête en grain). Queue en fondu, 1 px, jamais de flèche.
  // La bille les écarte (ils la contournent) ; le flux les courbe.
  FABRIQUES.filets = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, N = p.max || 64, M = 10, F = [], vent = p.vent || [26, -3], aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.traces);
    const VIT = [0.55, 1, 1.7], PAS = [0.1, 0.065, 0.04], LUM = [0.36, 0.6, 0.9];
    function naitre(q, partout) {
      const h = A(); q.cl = h < 0.3 ? 0 : h < 0.72 ? 1 : 2; q.x = A() * sc.l; q.y = A() * sc.h; q.vie = 3 + 4 * A(); q.age = partout ? A() * q.vie : 0;
      q.vit = VIT[q.cl] * (0.8 + 0.4 * A()); q.ph = A() * TAU; q.ab = A() < 0.22 ? 1 : 0; q.cnt = 0; q.acc = 0; q.a = 0;
    }
    for (let i = 0; i < N; i++) { const q = { hx: new Float32Array(M), hy: new Float32Array(M) }; naitre(q, true); F.push(q); }
    let n = 0;
    return {
      regler(k) { n = Math.min(N, Math.round(N * k)); }, effectif: () => n * M,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = F[i], f = sc.flux(q.x, q.y);
          q.age += dt;
          if (q.age > q.vie || q.x < -60 || q.x > sc.l + 60 || q.y < -60 || q.y > sc.h + 60) { naitre(q, false); continue; }
          q.acc += dt;
          if (q.acc >= PAS[q.cl]) { q.acc = 0; if (q.cnt === M) { q.hx.copyWithin(0, 1); q.hy.copyWithin(0, 1); q.cnt--; } q.hx[q.cnt] = q.x; q.hy[q.cnt] = q.y; q.cnt++; }
          q.x += (vent[0] + f[0] * (p.flux || 1) * sc.courant) * q.vit * dt; q.y += (vent[1] + f[1] * (p.flux || 1) * sc.courant + Math.sin(sc.t * 0.45 + q.ph) * 5) * q.vit * dt;
          if (b) { const dx = q.x - b.x, dy = q.y - b.y, d = Math.sqrt(dx * dx + dy * dy) + 0.01; if (d < 64) { const g = (64 - d) * dt * 2.2 / d; q.x += dx * g; q.y += dy * g; } }
          q.a = LUM[q.cl] * Math.sin(Math.PI * q.age / q.vie) ** 0.8 * (0.3 + 0.7 * sc.calme(q.x, q.y)) * sc.loinDuBut(q.x, q.y, 20);
        }
      },
      dessiner(ctx) {
        if (!n) return;
        ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = sc.NORME.trait * 0.8;
        const s = sc.seau(sc.h * 0.5);
        for (let ab = 0; ab < 2; ab++) {
          ctx.strokeStyle = sc.sp.rgb[s][ab];
          for (let nv = 0; nv < 5; nv++) {                // cinq niveaux d'opacité : la queue s'éteint, la tête est nette
            ctx.globalAlpha = aMax * (nv + 0.55) / 5; ctx.beginPath(); let vide = true;
            for (let i = 0; i < n; i++) {
              const q = F[i]; if (q.ab !== ab || q.cnt < 2 || q.a < 0.03) continue;
              for (let j = 0; j < q.cnt; j++) {
                const u = (j + 1) / q.cnt, v = Math.min(4, (q.a * u * u * 5) | 0); if (v !== nv || q.a * u * u < 0.02) continue;
                ctx.moveTo(q.hx[j], q.hy[j]); if (j + 1 < q.cnt) ctx.lineTo(q.hx[j + 1], q.hy[j + 1]); else ctx.lineTo(q.x, q.y); vide = false;
              }
            }
            if (!vide) ctx.stroke();
          }
        }
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < n; i++) { const q = F[i]; if (q.cl === 2 && q.a > 0.05) sc.point(ctx, sc.sp.fin[sc.seau(q.y)][q.ab], q.x, q.y, 4.5, aMax * q.a); }   // grain porté, en tête des filets proches
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    };
  } };

  /* =====================================================================
     ÉLÉMENTS — famille « réactifs » (à la bille, au flux, au champ)
     ===================================================================== */
  // sillage : allée de tourbillons de von Kármán derrière la bille. Un tourbillon se détache tous les « pas » px
  // parcourus, alternativement à gauche et à droite, de sens opposés ; il dérive, s'élargit, s'efface.
  function spriteTourbillon(col, sens, fin) {
    const s = toile(64, 64), g = s.getContext('2d');
    g.translate(32, 32); g.lineCap = 'round';
    for (let bras = 0; bras < 2; bras++) {
      for (let i = 0; i < 34; i++) {
        const u = i / 34, a0 = bras * Math.PI + sens * u * 5.2, a1 = bras * Math.PI + sens * (u + 1 / 34) * 5.2, r0 = 2 + u * 27, r1 = 2 + (u + 1 / 34) * 27;
        g.strokeStyle = rgba(col, (1 - u) * (fin ? (1 - u) * 0.8 : 0.9)); g.lineWidth = fin ? 0.9 - u * 0.45 : 1.5 - u * 0.8;
        g.beginPath(); g.moveTo(Math.cos(a0) * r0, Math.sin(a0) * r0); g.lineTo(Math.cos(a1) * r1, Math.sin(a1) * r1); g.stroke();
      }
    }
    return s;
  }
  FABRIQUES.sillage = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const N = p.max || 14, T = [], spr = {};
    for (let i = 0; i < N; i++) T.push({ x: 0, y: 0, vx: 0, vy: 0, age: 9, sens: 1, rot: 0, s: 0 });
    let k = 0, parcours = 0, cote = 1, suiv = 0;
    const aMax = Math.min(p.alpha || 0.6, sc.NORME.opaciteMax.reactifs), vieT = p.vie || 3.2;
    const sprite = (s, sens) => spr[s + '_' + sens] || (spr[s + '_' + sens] = spriteTourbillon(sc.sp.brut[s][sens > 0 ? 0 : 1], sens, p.fin));
    return {
      regler(kk) { k = kk; }, effectif: () => T.filter(q => q.age < vieT).length,
      update(dt) {
        const b = sc.bille;
        if (b && k > 0) {
          const v = Math.hypot(b.vx, b.vy);
          parcours += v * dt;
          if (v > (p.seuil || 40) && parcours > (p.pas || 34)) {
            parcours = 0; cote = -cote;
            const q = T[suiv]; suiv = (suiv + 1) % N;
            q.x = b.x - b.vy / v * cote * 9; q.y = b.y + b.vx / v * cote * 9; q.vx = b.vx * 0.12; q.vy = b.vy * 0.12; q.age = 0; q.sens = cote; q.rot = 0; q.s = sc.seau(q.y);
          }
        }
        for (const q of T) {
          if (q.age >= vieT) continue;
          const f = sc.flux(q.x, q.y);
          q.age += dt; q.vx += (f[0] * 0.3 * sc.courant - q.vx) * dt * 1.5; q.vy += (f[1] * 0.3 * sc.courant - q.vy) * dt * 1.5;
          q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.sens * dt * (4.5 - q.age);
        }
      },
      dessiner(ctx) {
        ctx.globalCompositeOperation = 'lighter';
        for (const q of T) {
          if (q.age >= vieT) continue;
          const u = q.age / vieT, t2 = (p.taille || 22) * (0.45 + 1.1 * Math.sqrt(u));
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot);
          ctx.globalAlpha = aMax * Math.sin(Math.PI * Math.min(1, u * 1.15)) ** 0.7 * (0.4 + 0.6 * sc.calme(q.x, q.y)) * sc.loinDuBut(q.x, q.y, t2 * 0.5);
          ctx.drawImage(sprite(q.s, q.sens), -t2 / 2, -t2 / 2, t2, t2);
          ctx.restore();
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };
  // chapelets : chapelets de bulles qui montent (liquide surchauffé de la chambre). Naissent en bas ou au point
  // d'un rebond, accélèrent, grossissent, éclatent en haut ; la bille les écarte.
  FABRIQUES.chapelets = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    if (p.mode === 'ions' && FABRIQUES.chapelets.ions) return FABRIQUES.chapelets.ions(sc, p);   // monde 6 : chapelets d'ions (phase 2)
    const A = sc.alea, N = p.max, M = p.bulles || 8, C = [];
    for (let i = 0; i < N; i++) C.push({ x: A() * sc.l, y: sc.h * A(), vy: 0, ph: A() * TAU, r: melange(p.rayon[0], p.rayon[1], A()), m: 3 + Math.floor(A() * (M - 2)), dx: 0, attente: A() * 3, eclat: 0, ab: A() < 0.25 ? 1 : 0, vit: melange(p.vitesse[0], p.vitesse[1], A()) });
    let n = 0;
    const aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.reactifs);
    function renaitre(c, x, y) { c.x = x === undefined ? sc.l * (0.04 + 0.92 * A()) : x; c.y = y === undefined ? sc.h + 20 + A() * 40 : y; c.vy = 0; c.dx = 0; c.eclat = 0; c.r = melange(p.rayon[0], p.rayon[1], A()); c.m = 3 + Math.floor(A() * (M - 2)); c.vit = melange(p.vitesse[0], p.vitesse[1], A()); }
    return {
      regler(k) { n = Math.round(N * k); }, effectif: () => n * M,
      evenement(type, e) { if (type === 'rebond' && n > 0) { const c = C[Math.floor(A() * n)]; renaitre(c, e.x + (A() - 0.5) * 16, e.y); c.attente = 0; } },
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const c = C[i];
          if (c.attente > 0) { c.attente -= dt; continue; }
          if (c.eclat > 0) { c.eclat += dt * 3; if (c.eclat >= 1) { renaitre(c); c.attente = melange(p.pause[0], p.pause[1], A()); } continue; }
          const f = sc.flux(c.x, c.y);
          c.vy += (c.vit - c.vy) * dt * 0.8; c.y -= c.vy * dt; c.x += f[0] * 0.3 * sc.courant * dt + c.dx * dt; c.dx *= 1 - Math.min(1, dt * 1.5);
          if (b) { const ex = c.x - b.x, ey = c.y - b.y, d = Math.hypot(ex, ey) || 1; if (d < 46) c.dx += ex / d * 160 * dt; }
          if (c.y < sc.h * (p.plafond || 0.04) + c.ph * 14) c.eclat = 0.01;
        }
      },
      dessiner(ctx, t) {
        ctx.lineWidth = sc.NORME.trait * 0.8;
        for (let i = 0; i < n; i++) {
          const c = C[i];
          if (c.attente > 0) continue;
          const s = sc.seau(c.y), haut = lisse(0, sc.h * 0.18, c.y);
          ctx.strokeStyle = sc.sp.rgb[s][c.ab];
          if (c.eclat > 0) {                           // éclatement : un anneau qui s'ouvre
            ctx.globalAlpha = aMax * (1 - c.eclat) * sc.calme(c.x, c.y);
            ctx.beginPath(); ctx.arc(c.x, c.y, c.r * (1.2 + 2.4 * c.eclat), 0, TAU); ctx.stroke(); continue;
          }
          ctx.globalAlpha = aMax * (0.5 + 0.5 * haut) * sc.calme(c.x, c.y);
          ctx.beginPath();
          let y = c.y;
          for (let j = 0; j < c.m; j++) {              // la plus grosse en tête, les suivantes de plus en plus petites et espacées
            const rr = c.r * (1 - j / (c.m + 1.5)), x = c.x + Math.sin(t * 1.9 + c.ph + j * 0.7) * (2.5 + j * 1.9) + Math.sin(t * 0.55 + c.ph * 1.7) * 5;   // fond11 : le chapelet ondule, il ne monte plus en ligne droite
            ctx.moveTo(x + rr, y); ctx.arc(x, y, rr, 0, TAU);
            y += rr * 2.1 + 2.5 + j * 1.4;
          }
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    };
  } };

  /* =====================================================================
     ÉLÉMENTS — famille « vivants » (monde des fluides seulement)
     ===================================================================== */
  // bancs : petits poissons en fuseau (sprite), cap commun, frétillement ; le banc s'ouvre devant la bille.
  function spritePoisson(col) {
    const s = toile(28, 12), g = s.getContext('2d');
    g.fillStyle = rgba(col, 0.9);
    g.beginPath(); g.moveTo(27, 6); g.quadraticCurveTo(17, 0.5, 8, 5); g.lineTo(1, 1.5); g.lineTo(3.5, 6); g.lineTo(1, 10.5); g.lineTo(8, 7); g.quadraticCurveTo(17, 11.5, 27, 6); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.55)'; g.beginPath(); g.ellipse(18, 5, 6, 1.1, 0, 0, TAU); g.fill();
    return s;
  }
  FABRIQUES.bancs = { famille: 'vivants', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, E = [], spr = {};
    for (let i = 0; i < p.max; i++) {
      const m = p.membres, e = { cx: A() * sc.l, cy: A() * sc.h, ph: A() * TAU, vit: melange(p.vitesse[0], p.vitesse[1], A()), ray: melange(p.rayon[0], p.rayon[1], A()), ux: 1, uy: 0, ouv: 0, a: new Float32Array(m), d: new Float32Array(m), ta: new Float32Array(m), ab: A() < 0.35 ? 1 : 0 };
      for (let j = 0; j < m; j++) { e.a[j] = A() * TAU; e.d[j] = 0.25 + 0.75 * Math.sqrt(A()); e.ta[j] = melange(p.taille[0], p.taille[1], A()); }
      E.push(e);
    }
    let n = 0;
    const aMax = Math.min(p.alpha, sc.NORME.opaciteMax.vivants);
    return {
      regler(k) { n = Math.min(E.length, Math.round(E.length * k + 0.3)); }, effectif: () => n * p.membres,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const e = E[i], f = sc.flux(e.cx, e.cy);
          e.ph += dt * e.vit;
          const cap = e.ph * 0.35 + i * 2.4 + Math.sin(e.ph * 0.9 + i) * 0.9;
          let vx = Math.cos(cap) * p.nage + f[0] * p.flux * sc.courant, vy = Math.sin(cap) * p.nage * 0.6 + f[1] * p.flux * sc.courant, peur = 0;
          if (b) { const dx = e.cx - b.x, dy = e.cy - b.y, d = Math.hypot(dx, dy) || 1; if (d < 90) { peur = 1 - d / 90; vx += dx / d * 70 * peur; vy += dy / d * 70 * peur; } }
          e.ouv += (peur - e.ouv) * Math.min(1, dt * 2);
          const nn = Math.hypot(vx, vy) || 1;
          e.ux += (vx / nn - e.ux) * Math.min(1, dt * 3); e.uy += (vy / nn - e.uy) * Math.min(1, dt * 3);
          e.cx += vx * dt; e.cy += vy * dt;
          if (e.cx < -50) e.cx += sc.l + 100; else if (e.cx > sc.l + 50) e.cx -= sc.l + 100;
          if (e.cy < -50) e.cy += sc.h + 100; else if (e.cy > sc.h + 50) e.cy -= sc.h + 100;
        }
      },
      dessiner(ctx, t) {
        for (let i = 0; i < n; i++) {
          const e = E[i], s = sc.seau(e.cy), img = spr[s + '_' + e.ab] || (spr[s + '_' + e.ab] = spritePoisson(sc.sp.brut[s][e.ab])), ang = Math.atan2(e.uy, e.ux), ray = e.ray * (1 + 1.4 * e.ouv);
          ctx.globalAlpha = aMax * sc.calme(e.cx, e.cy) * sc.loinDuBut(e.cx, e.cy, ray * 1.7);
          if (ctx.globalAlpha < 0.01) continue;
          for (let j = 0; j < e.a.length; j++) {
            const le = Math.cos(e.a[j]) * ray * e.d[j] * 1.7, la = Math.sin(e.a[j]) * ray * e.d[j] * (0.55 + 0.12 * Math.sin(t * 0.8 + j));
            const x = e.cx + e.ux * le - e.uy * la, y = e.cy + e.uy * le + e.ux * la, ta = e.ta[j];
            ctx.save(); ctx.translate(x, y); ctx.rotate(ang + Math.sin(t * 6 + j * 1.9) * 0.2);
            ctx.drawImage(img, -ta / 2, -ta * 0.215, ta, ta * 0.43);
            ctx.restore();
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // passants : méduses vivantes au trait, 8 poses de pulsation, nage par à-coups.
  const POSES = 8, POSE_L = 96, POSE_H = 176;
  function planchePassant(col, alea) {
    const c = toile(POSE_L * POSES, POSE_H), g = c.getContext('2d'), nt = 9, phases = [];
    for (let i = 0; i < nt + 4; i++) phases.push(alea() * TAU);
    g.lineCap = 'round'; g.lineJoin = 'round';
    for (let k = 0; k < POSES; k++) {
      const ph = k / POSES * TAU, ser = 0.5 - 0.5 * Math.cos(ph), r = 30 * (1 - 0.2 * ser), ht = 26 * (1 + 0.16 * ser);
      g.setTransform(1, 0, 0, 1, POSE_L * k + POSE_L / 2, 34);
      const dome = () => { g.beginPath(); g.moveTo(-r, 0); g.bezierCurveTo(-r, -ht * 1.3, r, -ht * 1.3, r, 0); };
      dome(); g.quadraticCurveTo(0, 9, -r, 0); g.fillStyle = rgba(col, 0.16); g.fill();
      g.beginPath(); g.ellipse(0, -ht * 0.42, r * 0.48, ht * 0.34, 0, 0, TAU); g.fillStyle = rgba(col, 0.22); g.fill();
      dome(); g.strokeStyle = rgba(col, 0.95); g.lineWidth = 1.3; g.stroke();
      g.beginPath(); g.ellipse(0, 0, r, 5, 0, 0, TAU); g.strokeStyle = rgba(col, 0.5); g.lineWidth = 0.9; g.stroke();
      g.lineWidth = 0.7; g.strokeStyle = rgba(col, 0.42);
      for (let i = 1; i < 7; i++) { const ex = r * Math.cos(Math.PI * i / 7); g.beginPath(); g.moveTo(0, -ht * 0.97); g.quadraticCurveTo(ex * 1.05, -ht * 0.8, ex, 2); g.stroke(); }
      for (let i = 0; i < nt; i++) {
        const x0 = r * 0.94 * Math.cos(Math.PI * (i + 0.5) / nt), L = 86 + 34 * Math.sin(phases[i] * 3);
        g.beginPath(); g.moveTo(x0, 2);
        for (let s = 1; s <= 12; s++) { const f = s / 12; g.lineTo(x0 * (1 - 0.3 * f) + Math.sin(f * 5 - ph + phases[i]) * 5 * f, 2 + f * L); }
        g.strokeStyle = rgba(col, 0.36); g.lineWidth = 0.7; g.stroke();
      }
      for (let i = 0; i < 4; i++) {
        const x0 = (i - 1.5) * 5;
        g.beginPath(); g.moveTo(x0, 0);
        for (let s = 1; s <= 10; s++) { const f = s / 10; g.lineTo(x0 + Math.sin(f * 7 - ph + phases[nt + i]) * 3.5 * (0.4 + f), f * 58); }
        g.strokeStyle = rgba(col, 0.6); g.lineWidth = 1.3; g.stroke();
      }
    }
    g.setTransform(1, 0, 0, 1, 0, 0);
    return c;
  }
  FABRIQUES.passants = { famille: 'vivants', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, L = [];
    for (let i = 0; i < p.max; i++) L.push({ x: A() * sc.l, y: A() * sc.h, cap: A() * TAU, ph: A(), t: melange(p.taille[0], p.taille[1], A()), vit: melange(p.vitesse[0], p.vitesse[1], A()), vir: (A() - 0.5) * 0.12 });
    const planche = planchePassant(sc.sp.brut[sc.seau(sc.h * 0.5)][0], aleatoire(77));
    let n = 0;
    const aMax = Math.min(p.alpha, sc.NORME.opaciteMax.vivants);
    return {
      regler(k, q) { n = q.qualite < 0.6 ? 0 : Math.min(L.length, Math.round(L.length * k + 0.2)); }, effectif: () => n,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = L[i], f = sc.flux(q.x, q.y);
          q.ph = (q.ph + dt * p.pouls) % 1;
          const elan = 0.35 + 0.65 * Math.max(0, Math.sin(q.ph * TAU));
          q.cap += q.vir * dt;
          if (b) { const dx = q.x - b.x, dy = q.y - b.y; if (dx * dx + dy * dy < 110 * 110) q.cap += Math.sign(Math.sin(Math.atan2(dx, -dy) - q.cap)) * dt * 0.9; }   // se détourne de la bille
          q.x += (Math.sin(q.cap) * q.vit * elan + f[0] * 0.15 * sc.courant) * dt; q.y += (-Math.cos(q.cap) * q.vit * elan + f[1] * 0.15 * sc.courant) * dt;
          const m = q.t * 2;
          if (q.x < -m) q.x += sc.l + 2 * m; else if (q.x > sc.l + m) q.x -= sc.l + 2 * m;
          if (q.y < -m) q.y += sc.h + 2 * m; else if (q.y > sc.h + m) q.y -= sc.h + 2 * m;
        }
      },
      dessiner(ctx) {
        for (let i = 0; i < n; i++) {
          const q = L[i], ech = q.t / POSE_L, pose = Math.floor(q.ph * POSES) % POSES;
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.cap);
          ctx.globalAlpha = aMax * sc.calme(q.x, q.y) * sc.loinDuBut(q.x, q.y, q.t * 1.6);
          ctx.drawImage(planche, pose * POSE_L, 0, POSE_L, POSE_H, -q.t / 2, -34 * ech, q.t, POSE_H * ech);
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // motif : adaptateur QXMOTIFS (API d'origine intacte : init / update(dt, flow, energy) / draw(ctx, alpha)).
  FABRIQUES.motif = { famille: 'vivants', plan: 'arriere', creer(sc, p) {
    const z = sc.zone, m = racine.QXMOTIFS && z ? racine.QXMOTIFS.create(p.nom) : null;
    let k = 0, densite = -1, brut = null;
    const flowTerrain = (x, y) => sc.flux(x + sc.ox, y + sc.oy);
    return {
      regler(kk, q) { k = kk > 0 ? 1 : 0; const d = p.qualite === undefined ? 1 : p.qualite; if (m && d !== densite) { densite = d; m.init(z.l, z.h, 1200 + sc.niveau * 31 + (p.graine || 0) * 77, { quality: d }); } },
      effectif: () => 0,
      update(dt) { if (m && k) m.update(dt, flowTerrain, sc.energie); },
      dessiner(ctx) { if (!m || !k) return; ctx.save(); ctx.translate(z.x, z.y); m.draw(ctx, p.alpha === undefined ? 0.7 : p.alpha); ctx.restore(); }
    };
  } };

  /* =====================================================================
     ÉLÉMENTS DU GROUPE A — mondes 3 (Chaîne), 5 (Soufflerie), 7 (Gravité), 8 (Magnétisme)
     ===================================================================== */
  // anneau (monde 3) : anneau de stockage qui encadre la scène. Quatre paquets à vitesse FIXE, six aimants de courbure
  // d'où partent des lignes de lumière tangentes parcourues d'impulsions, cavité RF (chaîne de bulbes) qui s'illumine
  // au passage d'un paquet et à chaque élan de la bille (événement « elan »).
  FABRIQUES.anneau = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const z = sc.zone || { x: 0, y: 0, l: sc.l, h: sc.h }, A = sc.alea;
    const cx = z.x + z.l / 2, cy = z.y + z.h * (p.cy || 0.52) + (A() - 0.5) * z.h * 0.06, rr = z.l * (p.ry || 0.31), sl = z.l * (p.rx || 0.478) - rr;
    const L1 = 2 * sl, La = Math.PI * rr, P = 2 * L1 + 2 * La, o = { x: 0, y: 0, tx: 0, ty: 0 };
    function en(u) {
      let d = ((u % 1) + 1) % 1 * P, a;
      if (d < L1) { o.x = cx - sl + d; o.y = cy - rr; o.tx = 1; o.ty = 0; return; }
      d -= L1; if (d < La) { a = -Math.PI / 2 + d / rr; o.x = cx + sl + Math.cos(a) * rr; o.y = cy + Math.sin(a) * rr; o.tx = -Math.sin(a); o.ty = Math.cos(a); return; }
      d -= La; if (d < L1) { o.x = cx + sl - d; o.y = cy + rr; o.tx = -1; o.ty = 0; return; }
      d -= L1; a = Math.PI / 2 + d / rr; o.x = cx - sl + Math.cos(a) * rr; o.y = cy + Math.sin(a) * rr; o.tx = -Math.sin(a); o.ty = Math.cos(a);
    }
    const aimants = [], uA = L1 / P, uArc = La / P;
    for (let k = 0; k < 6; k++) { const u = (k < 3 ? uA : 2 * uA + uArc) + uArc * (0.2 + 0.3 * (k % 3)); en(u); aimants.push({ x: o.x, y: o.y, tx: o.tx, ty: o.ty, ph: A() * TAU }); }
    const cav = p.cavite === undefined ? 0.08 : p.cavite, sens = A() < 0.5 ? 1 : -1;
    let k = 0, u0 = A(), eclat = 0;
    const aMax = sc.NORME.opaciteMax.structures, vit = p.vitesse || 0.07, lum = p.lumiere || 150;
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? 4 + 6 : 0),
      evenement(type) { if (type === 'elan' || type === 'rebond' || type === 'impact') eclat = 1; },
      update(dt) {
        u0 += vit * dt * sens; eclat = Math.max(0, eclat - dt * 1.6);
        for (let b = 0; b < 4; b++) { const du = Math.abs((((u0 + b / 4 - cav) % 1) + 1.5) % 1 - 0.5); if (du < 0.012) eclat = Math.max(eclat, 0.8); }
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        const s = sc.seau(cy), att = 0.55 + 0.45 * sc.calme(cx, cy);
        ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
        ctx.strokeStyle = sc.sp.rgb[s][0]; ctx.lineWidth = sc.NORME.trait;
        ctx.globalAlpha = aMax * 0.95 * att;
        ctx.beginPath(); ctx.moveTo(cx - sl, cy - rr); ctx.lineTo(cx + sl, cy - rr); ctx.arc(cx + sl, cy, rr, -Math.PI / 2, Math.PI / 2); ctx.lineTo(cx - sl, cy + rr); ctx.arc(cx - sl, cy, rr, Math.PI / 2, Math.PI * 1.5); ctx.stroke();
        ctx.globalAlpha = aMax * 0.22 * att; ctx.lineWidth = 0.7;
        ctx.beginPath(); ctx.moveTo(cx - sl, cy - rr + 5); ctx.lineTo(cx + sl, cy - rr + 5); ctx.arc(cx + sl, cy, rr - 5, -Math.PI / 2, Math.PI / 2); ctx.lineTo(cx - sl, cy + rr - 5); ctx.arc(cx - sl, cy, rr - 5, Math.PI / 2, Math.PI * 1.5); ctx.stroke();
        // aimants de courbure + lignes de lumière tangentes (impulsions)
        for (const m of aimants) {
          ctx.globalAlpha = aMax * 0.9 * att; ctx.lineWidth = 3; ctx.strokeStyle = sc.sp.rgb[s][1];
          ctx.beginPath(); ctx.moveTo(m.x - m.tx * 7, m.y - m.ty * 7); ctx.lineTo(m.x + m.tx * 7, m.y + m.ty * 7); ctx.stroke();
          ctx.lineWidth = 0.8; ctx.globalAlpha = aMax * 0.6 * att;
          ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x + m.tx * sens * lum, m.y + m.ty * sens * lum); ctx.stroke();
          const f = (t * 0.55 + m.ph) % 1, x = m.x + m.tx * sens * lum * f, y = m.y + m.ty * sens * lum * f;
          sc.point(ctx, sc.sp.doux[s][1], x, y, 16, 0.9 * (1 - f) * (0.4 + 0.6 * sc.calme(x, y)));
        }
        // cavité RF : chaîne de bulbes sur la ligne droite du haut
        en(cav); const qx = o.x, qy = o.y;
        ctx.strokeStyle = sc.sp.rgb[s][0]; ctx.lineWidth = sc.NORME.trait; ctx.globalAlpha = Math.min(0.9, aMax * (0.6 + 1.2 * eclat)) * att;
        ctx.beginPath();
        for (let i = -2; i <= 2; i++) { ctx.moveTo(qx + i * 11 + 5.5, qy); ctx.ellipse(qx + i * 11, qy, 5.5, 4 + 2.5 * eclat, 0, 0, TAU); }
        ctx.stroke();
        if (eclat > 0.02) sc.point(ctx, sc.sp.doux[s][0], qx, qy, 70, 0.5 * eclat * att);
        // paquets : vitesse fixe, petite traîne
        for (let b = 0; b < 4; b++) {
          for (let q = 0; q < 4; q++) { en(u0 + b / 4 - sens * q * 0.006); sc.point(ctx, sc.sp[q ? 'fin' : 'doux'][s][b % 2], o.x, o.y, q ? 13 - q * 2 : 26, (q ? 0.7 - q * 0.13 : 1) * (0.5 + 0.5 * sc.calme(o.x, o.y))); }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
    };
  } };
  // synchrotron (monde 3) : dès que la bille TOURNE vite, un rayon part en tangente à sa trajectoire (physique réelle de l'anneau, appliquée au joueur).
  FABRIQUES.synchrotron = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const N = p.max || 10, R = [];
    for (let i = 0; i < N; i++) R.push({ x: 0, y: 0, dx: 0, dy: 0, age: 9 });
    let k = 0, ang0 = null, repos = 0, suiv = 0;
    const vie = p.vie || 0.7, L = p.longueur || 150, aMax = Math.min(p.alpha || 0.8, sc.NORME.opaciteMax.reactifs);
    function emettre(x, y, dx, dy) { const q = R[suiv]; suiv = (suiv + 1) % N; q.x = x; q.y = y; q.dx = dx; q.dy = dy; q.age = 0; }
    return {
      regler(kk) { k = kk; }, effectif: () => R.filter(q => q.age < vie).length,
      evenement(type, e) { if ((type === 'rebond' || type === 'impact') && k > 0 && sc.bille) { const v = Math.hypot(sc.bille.vx, sc.bille.vy) || 1; emettre(e.x, e.y, sc.bille.vx / v, sc.bille.vy / v); } },
      update(dt) {
        for (const q of R) q.age += dt;
        const b = sc.bille; repos -= dt;
        if (!b || k <= 0 || dt <= 0) return;
        const v = Math.hypot(b.vx, b.vy);
        if (v < 20) { ang0 = null; return; }
        const ang = Math.atan2(b.vy, b.vx);
        if (ang0 !== null) {
          let d = ang - ang0; if (d > Math.PI) d -= TAU; else if (d < -Math.PI) d += TAU;
          if (Math.abs(d) / dt * v > (p.seuil || 260) && repos <= 0) { emettre(b.x, b.y, b.vx / v, b.vy / v); repos = p.cadence || 0.09; }
        }
        ang0 = ang;
      },
      dessiner(ctx) {
        ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
        for (const q of R) {
          if (q.age >= vie) continue;
          const u = q.age / vie, l0 = L * u * 0.5, l1 = L * (0.25 + 0.75 * u), s = sc.seau(q.y);
          ctx.strokeStyle = sc.sp.rgb[s][1]; ctx.globalAlpha = aMax * (1 - u) * (1 - u); ctx.lineWidth = 1.4 - u * 0.6;
          ctx.beginPath(); ctx.moveTo(q.x + q.dx * l0, q.y + q.dy * l0); ctx.lineTo(q.x + q.dx * l1, q.y + q.dy * l1); ctx.stroke();
          sc.point(ctx, sc.sp.fin[s][1], q.x + q.dx * l1, q.y + q.dy * l1, 10, aMax * (1 - u));
        }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    };
  } };
  // faisceau (monde 5) : expérience de Stern et Gerlach. Un faisceau de points traverse le fond, passe entre les pôles
  // d'un aimant non uniforme et se SCINDE en deux lobes qui marquent la plaque de deux taches. La bille écarte les points.
  FABRIQUES.faisceau = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, z = sc.zone || { x: 0, y: 0, l: sc.l, h: sc.h }, N = p.max || 96;
    const dir = A() < 0.5 ? 1 : -1, y0 = z.y + z.h * (0.16 + 0.68 * A()), pente = (A() - 0.5) * 0.16, x0 = dir > 0 ? -8 : sc.l + 8, x1 = dir > 0 ? sc.l * 0.93 : sc.l * 0.07;
    const us = p.aimant || 0.36, dev = (p.ecart || 44) * (0.8 + 0.5 * A());
    const u = new Float32Array(N), sy = new Float32Array(N), spin = new Int8Array(N), vt = new Float32Array(N), ex = new Float32Array(N), ey = new Float32Array(N);
    for (let i = 0; i < N; i++) { u[i] = A(); sy[i] = (A() + A() + A() - 1.5) * 3.2; spin[i] = A() < 0.5 ? -1 : 1; vt[i] = 0.13 + 0.07 * A(); }
    let n = 0;
    const aMax = Math.min(p.alpha || 0.7, sc.NORME.opaciteMax.traces);
    const X = v => x0 + (x1 - x0) * v, Y = (v, i) => y0 + pente * (X(v) - x0) + sy[i] * (1 + 1.5 * v) + (v > us ? spin[i] * dev * ((v - us) / (1 - us)) ** 2 : 0);
    return {
      regler(k) { n = Math.round(N * k); }, effectif: () => n,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          u[i] += vt[i] * dt * (0.6 + 0.9 * sc.energie); if (u[i] > 1) { u[i] -= 1; ex[i] = ey[i] = 0; }
          ex[i] *= 1 - Math.min(1, dt * 1.2); ey[i] *= 1 - Math.min(1, dt * 1.2);
          if (b) { const dx = X(u[i]) + ex[i] - b.x, dy = Y(u[i], i) + ey[i] - b.y, dd = dx * dx + dy * dy; if (dd < 1600 && dd > 1) { const d = Math.sqrt(dd), f = (1 - d / 40) * 140 * dt; ex[i] += dx / d * f; ey[i] += dy / d * f; } }
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        const s = sc.seau(y0), xa = X(us), ya = y0 + pente * (xa - x0), xp = X(1), yp = y0 + pente * (xp - x0);
        ctx.lineWidth = sc.NORME.trait * 0.9; ctx.lineCap = 'round'; ctx.strokeStyle = sc.sp.rgb[s][0];
        ctx.globalAlpha = 0.34 * sc.calme(xa, ya);                // aimant : pôle en coin (champ non uniforme) et pôle en gouttière
        ctx.beginPath(); ctx.moveTo(xa - 16, ya - 30); ctx.lineTo(xa, ya - 12); ctx.lineTo(xa + 16, ya - 30); ctx.moveTo(xa - 18, ya + 28); ctx.lineTo(xa - 18, ya + 16); ctx.quadraticCurveTo(xa, ya + 8, xa + 18, ya + 16); ctx.lineTo(xa + 18, ya + 28); ctx.stroke();
        ctx.globalAlpha = 0.3 * sc.calme(xp, yp);                 // plaque
        ctx.beginPath(); ctx.moveTo(xp, yp - dev * 1.7); ctx.lineTo(xp, yp + dev * 1.7); ctx.stroke();
        ctx.globalCompositeOperation = 'lighter';
        const pul = 0.8 + 0.2 * Math.sin(t * 2.1);
        sc.point(ctx, sc.sp.doux[s][0], xp, yp - dev, 34, 0.42 * pul * sc.calme(xp, yp - dev)); sc.point(ctx, sc.sp.doux[s][1], xp, yp + dev, 34, 0.42 * (1.8 - pul) * sc.calme(xp, yp + dev));
        for (let i = 0; i < n; i++) {
          const x = X(u[i]) + ex[i], y = Y(u[i], i) + ey[i], bord = Math.min(1, u[i] * 8) * Math.min(1, (1 - u[i]) * 10);
          sc.point(ctx, sc.sp.fin[s][u[i] > us && spin[i] > 0 ? 1 : 0], x, y, 9, aMax * bord * (0.35 + 0.65 * sc.calme(x, y)));
        }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    };
  } };
  // grille (monde 7) : la grille de l'espace SE CREUSE sous les puits (et se bombe sur les bosses) ; la bille est un petit puits mobile.
  // grille (monde 7) : la trame d'espace n'apparaît QUE là où la masse la courbe (autour des puits, sous la bille,
  // au front d'une onde) ; nulle ailleurs et autour du but. Chaque puits : entonnoir d'anneaux fins + arcs de lumière
  // défléchie. États : repos (respiration) / creusement sous la bille / onde qui part du puits au rebond.
  FABRIQUES.grille = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const nx = p.nx || 12, ny = p.ny || 18, n = (nx + 1) * (ny + 1), X = new Float32Array(n), Y = new Float32Array(n), PX = new Float32Array(n), PY = new Float32Array(n), WT = new Float32Array(n);
    for (let j = 0; j <= ny; j++) for (let i = 0; i <= nx; i++) { X[j * (nx + 1) + i] = sc.l * (i / nx * 1.1 - 0.05); Y[j * (nx + 1) + i] = sc.h * (j / ny * 1.06 - 0.03); }
    const NS = nx * (ny + 1) + ny * (nx + 1), SA = new Int16Array(NS), SB = new Int16Array(NS), NIV = [0, 1, 2, 3].map(() => new Int16Array(NS)), CN = [0, 0, 0, 0], AL = [0.2, 0.42, 0.7, 1];
    { let c = 0; for (let j = 0; j <= ny; j++) for (let i = 0; i < nx; i++) { SA[c] = j * (nx + 1) + i; SB[c++] = j * (nx + 1) + i + 1; } for (let j = 0; j < ny; j++) for (let i = 0; i <= nx; i++) { SA[c] = j * (nx + 1) + i; SB[c++] = (j + 1) * (nx + 1) + i; } }
    let k = 0, bx = -999, by = -999, bf = 0;
    const creux = p.creux || 0.5, aMax = Math.min(p.alpha || 0.3, sc.NORME.opaciteMax.structures), portee = p.portee || 2.2, zoneBut = p.zoneBut === undefined ? 60 : p.zoneBut;
    const col = rgbJeton(sc, p.jeton || 'violet'), colArc = rgbJeton(sc, p.jetonArc || 'cyan'), RG = [0.22, 0.38, 0.58, 0.82, 1.12], ON = [];
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? n + sc.geo.puits.length * 7 : 0),
      evenement(type, e) {
        if (type !== 'rebond' || k <= 0 || (e.v !== undefined && e.v < 40)) return;
        // fond8 : l'onde de choc part du point d'impact (plus du puits le plus proche) ; amplitude ∝ v
        const fv = borne((e.v === undefined ? 300 : e.v) / 420, 0.25, 1.6);
        if (ON.length >= 3) ON.shift();
        ON.push({ x: e.x, y: e.y, age: 0, vie: 2.6, port: Math.max(sc.l, sc.h) * 0.55, fv });
      },
      update(dt) {
        const b = sc.bille; if (b) { bx = b.x; by = b.y; bf += (1 - bf) * Math.min(1, dt * 3); } else bf *= 1 - Math.min(1, dt * 2);
        for (let i = ON.length - 1; i >= 0; i--) { ON[i].age += dt; if (ON[i].age > ON[i].vie) ON.splice(i, 1); }
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        const W = sc.geo.puits;
        for (let q = 0; q < n; q++) {
          let x = X[q], y = Y[q], wt = 0;
          for (let w = 0; w < W.length; w++) {
            const dx = W[w].x - X[q], dy = W[w].y - Y[q], d2 = dx * dx + dy * dy, r2 = W[w].r * W[w].r, g = W[w].f * creux * (1 + 0.07 * Math.sin(t * 0.9 + w)) * r2 / (d2 + r2);
            x += dx * g; y += dy * g;
            const u = d2 / (r2 * portee * portee); wt += Math.abs(W[w].f) / (1 + u * u);
          }
          let loc = 0;
          if (bf > 0.01) { const dx = bx - X[q], dy = by - Y[q], d2 = dx * dx + dy * dy, g = 0.42 * bf * 900 / (d2 + 900); x += dx * g; y += dy * g; loc += 0.22 * bf / (1 + d2 * d2 / 2.4e7); }
          for (let o = 0; o < ON.length; o++) {                                  // front d'onde : ride radiale + trame qui s'allume au passage
            const O = ON[o], dx = X[q] - O.x, dy = Y[q] - O.y, d = Math.sqrt(dx * dx + dy * dy) + 0.01, a = O.age / O.vie, u = (d - a * O.port) / 46;
            if (u > -1 && u < 1) { const c = Math.cos(u * Math.PI / 2), amp = c * c * (1 - a) * (1 - a) * (O.fv || 1), ride = 9 * amp * Math.sin(u * 5); x += dx / d * ride; y += dy / d * ride; loc += 0.45 * amp; }
          }
          wt = Math.min(1, wt + loc * (0.35 + 0.65 * sc.calme(X[q], Y[q]))) * sc.loinDuBut(X[q], Y[q], zoneBut);
          PX[q] = x; PY[q] = y; WT[q] = wt;
        }
        CN[0] = CN[1] = CN[2] = CN[3] = 0;
        for (let s = 0; s < NS; s++) { const w = (WT[SA[s]] + WT[SB[s]]) * 0.5; if (w < 0.1) continue; const v = w < 0.3 ? 0 : w < 0.55 ? 1 : w < 0.8 ? 2 : 3; NIV[v][CN[v]++] = s; }
        const att = 0.5 + 0.5 * sc.attenuation;
        ctx.strokeStyle = col; ctx.lineWidth = 0.8; ctx.lineCap = 'round';
        for (let v = 0; v < 4; v++) {
          if (!CN[v]) continue;
          ctx.globalAlpha = aMax * AL[v] * att; ctx.beginPath();
          for (let c = 0; c < CN[v]; c++) { const s = NIV[v][c]; ctx.moveTo(PX[SA[s]], PY[SA[s]]); ctx.lineTo(PX[SB[s]], PY[SB[s]]); }
          ctx.stroke();
        }
        for (let w = 0; w < W.length; w++) {                                     // entonnoirs (puits seulement) et arcs de déflexion
          const q = W[w], lb = sc.loinDuBut(q.x, q.y, q.r * 0.6) * att;
          if (q.f <= 0 || lb < 0.02) continue;
          ctx.strokeStyle = col; ctx.lineWidth = 0.8;
          for (let m = 0; m < RG.length; m++) {
            const rr = q.r * RG[m] * (1 + 0.035 * Math.sin(t * 0.8 - m * 0.9 + w));
            ctx.globalAlpha = aMax * (1 - 0.17 * m) * lb; ctx.beginPath(); ctx.ellipse(q.x, q.y + (1 - RG[m]) * q.r * 0.16, rr, rr * 0.88, 0, 0, 6.2832); ctx.stroke();
          }
          const a0 = t * 0.12 + w * 1.7, ra = q.r * 1.42;
          ctx.strokeStyle = colArc; ctx.globalAlpha = aMax * 0.75 * lb * (0.75 + 0.25 * Math.sin(t * 0.6 + w));
          ctx.beginPath(); ctx.arc(q.x, q.y, ra, a0, a0 + 1.05); ctx.stroke(); ctx.beginPath(); ctx.arc(q.x, q.y, ra, a0 + Math.PI + 0.2, a0 + Math.PI + 0.85); ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // ondes (monde 7) : ondes stationnaires dans chaque puits — trois niveaux d'énergie discrets (modes 1, 2, 3) qui vibrent.
  FABRIQUES.ondes = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    let k = 0, exc = 0, choc = 0;
    const aMax = Math.min(p.alpha || 0.4, sc.NORME.opaciteMax.structures);
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? sc.geo.puits.length * 3 : 0),
      evenement(type, e) { if (type === 'rebond' && k > 0) choc = Math.min(1.6, choc + borne((e.v === undefined ? 300 : e.v) / 450, 0.2, 1.2)); },   // fond8 : le rebond excite les modes (∝ v)
      update(dt) { const b = sc.bille; let pres = 0; if (b) for (const w of sc.geo.puits) if (Math.hypot(b.x - w.x, b.y - w.y) < w.r * 1.2) pres = 1; exc += (pres - exc) * Math.min(1, dt * 2); choc *= Math.exp(-dt * 1.4); },   // la bille dans un puits excite ses modes
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.lineWidth = sc.NORME.trait * 0.9; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const W = sc.geo.puits, nb = Math.min(W.length, p.max || 3);
        for (let q = 0; q < nb; q++) {
          const w = W[q], s = sc.seau(w.y), L = w.r * 1.5, att = 0.5 + 0.5 * sc.calme(w.x, w.y);
          for (let m = 1; m <= 3; m++) {
            const yb = w.y + (2 - m) * w.r * 0.42, amp = w.r * 0.13 * (1 + 0.8 * exc + 1.1 * choc) * Math.cos(t * (0.9 + 0.55 * m) * (1 + 0.6 * choc) + q);
            ctx.strokeStyle = sc.sp.rgb[s][m === 2 ? 1 : 0];
            ctx.globalAlpha = aMax * 0.3 * att; ctx.beginPath(); ctx.moveTo(w.x - L / 2, yb); ctx.lineTo(w.x + L / 2, yb); ctx.stroke();
            ctx.globalAlpha = Math.min(aMax, aMax * (0.7 + 0.3 * exc + 0.3 * choc)) * att; ctx.beginPath();
            for (let i = 0; i <= 28; i++) { const u = i / 28, x = w.x - L / 2 + L * u, y = yb + amp * Math.sin(m * Math.PI * u); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
            ctx.stroke();
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // Champ des aimants en un point (somme radiale simple ; la bille compte comme un petit aimant mobile)
  function champ(sc, x, y, out) {
    let bx = 0, by = 0;
    for (const m of sc.geo.aimants) { const dx = x - m.x, dy = y - m.y, d2 = dx * dx + dy * dy + 300, g = m.f * 9000 / (d2 * Math.sqrt(d2)); bx += dx * g; by += dy * g; }
    out[0] = bx; out[1] = by; return out;
  }
  // limaille (monde 8, refaite fond8 — plus d'aiguilles) : LIGNES DE CHAMP. Traits fins continus en courbes douces, tracés
  // en suivant le champ des aimants (légèrement tourné, pour des arcs plutôt que des rayons) ; des points glissent le long.
  // Bille proche : les lignes s'écartent doucement d'elle et s'éclairent. Aucune extrémité marquée (fondu aux deux bouts).
  FABRIQUES.limaille = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, pas = (p.pas || 30) * 1.7, cols = Math.ceil(sc.l / pas), ligs = Math.ceil(sc.h / pas), tmp = [0, 0], NP = 15, ST = 5.5;
    const aim = sc.geo.aimants.length > 0, rot = 0.55, LIG = [];
    const dir = (x, y, i) => {
      if (aim) { champ(sc, x, y, tmp); const a = Math.atan2(tmp[1], tmp[0]) + rot; return [Math.cos(a), Math.sin(a), Math.min(1, Math.hypot(tmp[0], tmp[1]) * 6)]; }
      const a = 0.9 * Math.sin(x * 0.011 + i) + 0.6 * Math.cos(y * 0.008); return [Math.cos(a), Math.sin(a), 0.4];
    };
    for (let j = 0; j < ligs; j++) for (let i = 0; i < cols; i++) {
      const x0 = (i + 0.2 + 0.6 * A()) * pas, y0 = (j + 0.2 + 0.6 * A()) * pas, PX = new Float32Array(NP), PY = new Float32Array(NP);
      let x = x0, y = y0, f = 0; const m = (NP - 1) / 2; PX[m] = x; PY[m] = y;
      for (let k = m + 1; k < NP; k++) { const d = dir(x, y, j); x += d[0] * ST; y += d[1] * ST; PX[k] = x; PY[k] = y; f += d[2]; }
      x = x0; y = y0;
      for (let k = m - 1; k >= 0; k--) { const d = dir(x, y, j); x -= d[0] * ST; y -= d[1] * ST; PX[k] = x; PY[k] = y; }
      LIG.push({ PX, PY, cx: x0, cy: y0, f: f / m, l: 0, ph: A(), ab: A() < 0.3 ? 1 : 0 });
    }
    let n = 0;
    const aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.reactifs) * 0.8, portee = p.portee || 78;
    const trace = (ctx, q, b, pousse) => {
      for (let k = 0; k < NP; k++) {
        let x = q.PX[k], y = q.PY[k];
        if (pousse && b) { const dx = x - b.x, dy = y - b.y, d = Math.hypot(dx, dy) || 1; if (d < portee) { const g = (1 - d / portee); x += dx / d * g * g * 16; y += dy / d * g * g * 16; } }
        if (k) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      }
    };
    return {
      regler(k) { n = Math.round(LIG.length * Math.min(1, k * 1.2)); }, effectif: () => n,
      update(dt) {
        const b = sc.bille, e = Math.min(1, dt * 3);
        for (let i = 0; i < n; i++) { const q = LIG[i]; let l = 0; if (b) { const d = Math.hypot(b.x - q.cx, b.y - q.cy); if (d < portee * 1.3) l = 1 - d / (portee * 1.3); } q.l += (l - q.l) * e; }
      },
      dessiner(ctx) {
        if (!n) return;
        const s = sc.seau(sc.h * 0.5), b = sc.bille, t = sc.t;
        ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = sc.NORME.trait * 0.6;
        // repos : un seul tracé, très pâle ; les lignes calmes seulement
        ctx.strokeStyle = sc.sp.rgb[s][0]; ctx.globalAlpha = aMax * 0.38 * (0.4 + 0.6 * sc.attenuation); ctx.beginPath();
        for (let i = 0; i < n; i++) { const q = LIG[i]; if (q.l > 0.08 || sc.calme(q.cx, q.cy) < 0.2) continue; trace(ctx, q, null, false); }
        ctx.stroke();
        // éveillées par la bille : écartées, plus claires
        ctx.strokeStyle = sc.sp.rgb[s][1]; ctx.lineWidth = sc.NORME.trait * 0.75;
        for (let i = 0; i < n; i++) { const q = LIG[i]; if (q.l <= 0.08) continue; ctx.globalAlpha = aMax * (0.38 + 0.9 * q.l); ctx.beginPath(); trace(ctx, q, b, true); ctx.stroke(); }
        // points qui glissent le long des lignes (sens du champ), fondus aux extrémités
        ctx.fillStyle = sc.sp.rgb[s][1];
        for (let i = 0; i < n; i += 2) {
          const q = LIG[i], u = (t * (0.05 + 0.08 * q.f) + q.ph) % 1, kf = u * (NP - 1), k = Math.floor(kf), r = kf - k;
          if (k >= NP - 1 || sc.calme(q.cx, q.cy) < 0.2) continue;
          const x = q.PX[k] + (q.PX[k + 1] - q.PX[k]) * r, y = q.PY[k] + (q.PY[k + 1] - q.PY[k]) * r, fade = Math.sin(Math.PI * u);
          ctx.globalAlpha = aMax * (0.7 + q.l) * fade; ctx.fillRect(x - 0.7, y - 0.7, 1.4, 1.4);
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // spin (monde 8, refait fond8 — plus de flèches) : ANNEAUX DE PRÉCESSION. Un anneau fin (le cône vu de biais) qui
  // précesse autour du champ local, un point qui en fait le tour, un second anneau plus petit et plus pâle (profondeur).
  // Près de la bille, l'anneau se referme (l'axe se redresse) et le point accélère.
  FABRIQUES.spin = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, T = [], tmp = [0, 0];
    for (let i = 0; i < (p.max || 7); i++) {
      let x = 0, y = 0;
      for (let e = 0; e < 30; e++) { x = sc.l * (0.08 + 0.84 * A()); y = sc.h * (0.08 + 0.84 * A()); if (sc.calme(x, y) > 0.75 || e > 20) break; }
      champ(sc, x, y, tmp);
      T.push({ x, y, phi: sc.geo.aimants.length ? Math.atan2(tmp[1], tmp[0]) + Math.PI / 2 : (A() - 0.5) * 0.8, w: 1.2 + Math.min(4, Math.hypot(tmp[0], tmp[1]) * 30) + A(), psi: A() * TAU, th: 0.5, L: melange(p.taille[0], p.taille[1], A()), ab: A() < 0.4 ? 1 : 0 });
    }
    let n = 0;
    const aMax = sc.NORME.opaciteMax.structures;
    return {
      regler(k) { n = Math.min(T.length, Math.round(T.length * k + 0.3)); }, effectif: () => n,
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) { const q = T[i]; let cible = 0.52; if (b && Math.hypot(b.x - q.x, b.y - q.y) < 90) cible = 0.1; q.th += (cible - q.th) * Math.min(1, dt * 2.5); q.psi += q.w * dt * (cible < 0.3 ? 2.2 : 1); }
      },
      dessiner(ctx) {
        for (let i = 0; i < n; i++) {
          const q = T[i], att = sc.calme(q.x, q.y) * sc.loinDuBut(q.x, q.y, q.L);
          if (att < 0.03) continue;
          const rx = q.L * Math.max(0.12, Math.sin(q.th)), hy = -q.L * Math.cos(q.th) * 0.6, ry = rx * 0.32;
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.phi + 0.18 * Math.sin(q.psi * 0.25));
          ctx.strokeStyle = sc.sp.rgb[sc.seau(q.y)][q.ab]; ctx.lineWidth = 0.7;
          ctx.globalAlpha = aMax * 0.55 * att; ctx.beginPath(); ctx.ellipse(0, hy, rx, ry, 0, 0, TAU); ctx.stroke();
          ctx.globalAlpha = aMax * 0.25 * att; ctx.beginPath(); ctx.ellipse(0, hy * 0.35, rx * 0.55, ry * 0.55, 0, 0, TAU); ctx.stroke();
          const px = Math.cos(q.psi) * rx, py = hy + Math.sin(q.psi) * ry, av = Math.sin(q.psi) > 0 ? 1 : 0.45;   // le point passe devant / derrière
          ctx.fillStyle = ctx.strokeStyle; ctx.globalAlpha = Math.min(0.9, aMax * 1.6) * att * av;
          ctx.beginPath(); ctx.arc(px, py, 1.3, 0, TAU); ctx.fill();
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
    };
  } };


  /* ===== fond8 — monde 7 (Gravité) : réponse au rebond et profondeur ===== */
  // anneaux de choc : anneaux fins concentriques qui naissent à l'impact, s'étendent et s'effacent (nombre et portée ∝ v)
  FABRIQUES.anneaux_choc = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const R = [], aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.reactifs), col = rgbJeton(sc, p.jeton || 'cyan'), col2 = rgbJeton(sc, p.jeton2 || 'blanc');
    let k = 0;
    return {
      regler(kk) { k = kk; }, effectif: () => R.length * 3,
      evenement(type, e) {
        if (type !== 'rebond' || k <= 0) return;
        const f = borne((e.v === undefined ? 300 : e.v) / 420, 0.25, 1.5);
        if (R.length > 6) R.splice(0, R.length - 6);
        R.push({ x: e.x, y: e.y, age: 0, f, n: 2 + Math.round(f * 2), vie: 1.4 + 0.8 * f });
      },
      update(dt) { for (let i = R.length - 1; i >= 0; i--) { R[i].age += dt; if (R[i].age > R[i].vie) R.splice(i, 1); } },
      dessiner(ctx) {
        if (k <= 0 || !R.length) return;
        ctx.lineWidth = sc.NORME.trait * 0.7;
        for (const r of R) {
          const a = r.age / r.vie;
          for (let j = 0; j < r.n; j++) {
            const u = a - j * 0.12; if (u <= 0) continue;
            const rr = (12 + 150 * r.f) * Math.sqrt(u), al = aMax * (1 - u) * (1 - u) * (0.9 - 0.18 * j) * Math.min(1, r.f) * k;
            if (al < 0.004) continue;
            ctx.strokeStyle = j ? col : col2; ctx.globalAlpha = al * sc.loinDuBut(r.x, r.y, rr);
            ctx.beginPath(); ctx.ellipse(r.x, r.y, rr, rr * 0.82, 0, 0, TAU); ctx.stroke();
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // orbites : nuage de points en spirale vers chaque puits (disque d'accrétion discret, incliné) ; le rebond fait s'évaser les orbites
  FABRIQUES.orbites = { famille: 'particules', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, W = sc.geo.puits.filter(w => w.f > 0), NP = p.points || 70, O = [];
    for (let w = 0; w < W.length; w++) for (let i = 0; i < NP; i++) O.push({ w, r: W[w].r * (0.3 + 0.9 * Math.sqrt(A())), a: A() * TAU, z: A(), ab: A() < 0.25 ? 1 : 0 });
    const aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.particules), incl = W.map(() => 0.32 + 0.25 * A()), rot = W.map(() => (A() - 0.5) * 0.9);
    let n = 0, choc = 0;
    return {
      regler(k) { n = Math.round(O.length * Math.min(1, k)); }, effectif: () => n,
      evenement(type, e) { if (type === 'rebond' && n) choc = Math.min(1.5, choc + borne((e.v === undefined ? 300 : e.v) / 420, 0.25, 1.2)); },
      update(dt) {
        choc *= Math.exp(-dt * 1.2);
        for (let i = 0; i < n; i++) {
          const o = O[i], w = W[o.w], v = (p.vitesse || 0.9) * Math.pow(w.r / o.r, 1.5);
          o.a += v * dt; o.r -= (p.chute || 3) * dt * (w.r / o.r);
          if (o.r < w.r * 0.18) o.r = w.r * (0.95 + 0.25 * A());
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        for (let i = 0; i < n; i++) {
          const o = O[i], w = W[o.w], r = o.r * (1 + 0.22 * choc * (0.5 + o.z)), ci = Math.cos(rot[o.w]), si = Math.sin(rot[o.w]);
          const lx = Math.cos(o.a) * r, ly = Math.sin(o.a) * r * incl[o.w], x = w.x + lx * ci - ly * si, y = w.y + lx * si + ly * ci;
          const devant = Math.sin(o.a) > 0 ? 1 : 0.5, pr = borne(1.25 - o.r / (w.r * 1.3), 0.35, 1);
          ctx.globalAlpha = aMax * pr * devant * (0.5 + 0.5 * o.z) * (1 + 0.4 * choc) * sc.loinDuBut(x, y, 8);
          ctx.fillStyle = sc.sp.rgb[sc.seau(y)][o.ab];
          const s = 0.8 + 1.1 * o.z * devant; ctx.fillRect(x - s / 2, y - s / 2, s, s);
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // lentille : arcs fins (anneau d'Einstein incomplet) derrière chaque puits ; ils respirent, et tremblent au rebond
  FABRIQUES.lentille = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, W = sc.geo.puits.filter(w => w.f > 0), ARC = [];
    for (let w = 0; w < W.length; w++) for (let j = 0; j < (p.arcs || 4); j++) ARC.push({ w, a: A() * TAU, l: 0.35 + 0.6 * A(), r: 1.6 + 0.9 * A(), e: 0.9 + 0.15 * A(), ph: A() * TAU });
    const aMax = Math.min(p.alpha || 0.3, sc.NORME.opaciteMax.structures), col = rgbJeton(sc, p.jeton || 'blanc');
    let k = 0, choc = 0;
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? ARC.length : 0),
      evenement(type, e) { if (type === 'rebond' && k > 0) choc = Math.min(1.4, choc + borne((e.v === undefined ? 300 : e.v) / 450, 0.2, 1)); },
      update(dt) { choc *= Math.exp(-dt * 2); },
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.strokeStyle = col; ctx.lineWidth = sc.NORME.trait * 0.7; ctx.lineCap = 'round';
        for (const q of ARC) {
          const w = W[q.w], rr = w.r * q.r * (1 + 0.03 * Math.sin(t * 0.5 + q.ph) + 0.05 * choc * Math.sin(t * 9 + q.ph)), a0 = q.a + t * 0.02;
          const al = aMax * (0.55 + 0.3 * Math.sin(t * 0.4 + q.ph)) * sc.loinDuBut(w.x, w.y, rr);
          ctx.lineWidth = 3; ctx.globalAlpha = al * 0.22; ctx.beginPath(); ctx.ellipse(w.x, w.y, rr, rr * q.e, 0, a0, a0 + q.l); ctx.stroke();   // halo doux (hors du plan net)
          ctx.lineWidth = sc.NORME.trait * 0.7; ctx.globalAlpha = al; ctx.beginPath(); ctx.ellipse(w.x, w.y, rr, rr * q.e, 0, a0, a0 + q.l); ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // étoiles lointaines : très petits points fixes, scintillement lent, parallaxe légère opposée à la bille (plan le plus lointain)
  FABRIQUES.etoiles = { famille: 'particules', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, N = p.max || 160, X = new Float32Array(N), Y = new Float32Array(N), Z = new Float32Array(N), PH = new Float32Array(N);
    for (let i = 0; i < N; i++) { X[i] = A() * sc.l; Y[i] = A() * sc.h; Z[i] = A(); PH[i] = A() * TAU; }
    const aMax = Math.min(p.alpha || 0.4, sc.NORME.opaciteMax.particules);
    let n = 0, px = 0, py = 0;
    return {
      regler(k) { n = Math.round(N * Math.min(1, k)); }, effectif: () => n,
      update(dt) { const b = sc.bille, tx = b ? (sc.l / 2 - b.x) * 0.02 : 0, ty = b ? (sc.h / 2 - b.y) * 0.012 : 0, e = Math.min(1, dt * 0.8); px += (tx - px) * e; py += (ty - py) * e; },
      dessiner(ctx, t) {
        const c0 = sc.sp.rgb[0][1];
        ctx.fillStyle = c0;
        for (let i = 0; i < n; i++) {
          const x = X[i] + px * (0.3 + Z[i]), y = Y[i] + py * (0.3 + Z[i]), s = 0.45 + 0.6 * Z[i];
          ctx.globalAlpha = aMax * (0.25 + 0.5 * Z[i]) * (0.6 + 0.4 * Math.sin(t * (0.3 + Z[i]) + PH[i]));
          ctx.fillRect(x, y, s, s);
        }
        ctx.globalAlpha = 1;
      }
    };
  } };

  /*__P2__*/
  // corral (monde 9) : corral quantique — un anneau d'atomes autour de chaque portail (sc.geo.portails, sinon placé
  // au calme), des ondes stationnaires concentriques qui respirent à l'intérieur. Bille proche : l'onde se décentre
  // vers elle, les atomes s'écartent ; rebond : le mode monte (plus d'anneaux) avec un éclat d'or puis redescend ;
  // flux : les atomes frémissent ; énergie : mode plus élevé, plus lumineux.
  FABRIQUES.corral = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NC = Math.max(1, Math.round(p.max || 3)), NA = p.atomes || 28, RR = p.rayon || [34, 50], ap = p.aplat || 0.72;
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.5, sc.NORME.opaciteMax.structures * 1.6), C = [];
    const sources = sc.geo.portails.map(q => [q.x, q.y]);
    for (let c = 0; c < NC; c++) {
      const R = melange(RR[0], RR[1], A()), pos = c < sources.length ? sources[c] : placeCalme(sc, A, 0.14, 30, R * 1.2);
      if (c < sources.length) (sc.occupes || (sc.occupes = [])).push([pos[0], pos[1], R * 1.2]);
      C.push({ x: pos[0], y: pos[1], R, ox: 0, oy: 0, mode: 0, saut: 0, ph: A() * TAU, w: 1.6 + 0.8 * A(), DX: new Float32Array(NA), DY: new Float32Array(NA), ab: c & 1 });
    }
    let n = 0;
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NC * Math.min(1, k * 1.25))) : 0; }, effectif: () => n * (NA + 6),
      evenement(type, e) { if (type === 'rebond') for (let c = 0; c < n; c++) if (Math.hypot(C[c].x - e.x, C[c].y - e.y) < 280) C[c].saut = 1; },
      update(dt) {
        const b = sc.bille;
        for (let c = 0; c < n; c++) {
          const q = C[c]; let tx = 0, ty = 0;
          if (b) { const dx = b.x - q.x, dy = b.y - q.y, d = Math.hypot(dx, dy) || 1; if (d < q.R * 3) { const g = (1 - d / (q.R * 3)) * q.R * 0.35; tx = dx / d * g; ty = dy / d * g * ap; } }
          q.ox += (tx - q.ox) * Math.min(1, dt * 3); q.oy += (ty - q.oy) * Math.min(1, dt * 3);
          q.saut *= 1 - Math.min(1, dt * 0.5);
          q.mode += (3 + 2 * sc.energie + 3 * q.saut - q.mode) * Math.min(1, dt * 2);
          const f = sc.flux(q.x, q.y), fr = Math.min(2.5, Math.hypot(f[0], f[1]) / 40) + sc.energie * 0.6;
          for (let i = 0; i < NA; i++) {
            const a = TAU * i / NA, ax = q.x + Math.cos(a) * q.R, ay = q.y + Math.sin(a) * q.R * ap;
            let px = Math.sin(sc.t * 9 + i * 2.1) * fr, py = Math.cos(sc.t * 7 + i * 1.3) * fr;
            if (b) { const ex = ax - b.x, ey = ay - b.y, d = Math.hypot(ex, ey) || 1; if (d < 40) { px += ex / d * (40 - d) * 0.5; py += ey / d * (40 - d) * 0.5; } }
            q.DX[i] += (px - q.DX[i]) * Math.min(1, dt * 6); q.DY[i] += (py - q.DY[i]) * Math.min(1, dt * 6);
          }
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        for (let c = 0; c < n; c++) {
          const q = C[c], s = sc.seau(q.y), att = (0.45 + 0.55 * sc.calme(q.x, q.y)) * sc.loinDuBut(q.x, q.y, q.R);
          if (att < 0.03) continue;
          const m = Math.max(2, q.mode), nb = Math.floor(m), resp = Math.cos(t * q.w + q.ph), I = resp * resp;
          ctx.lineWidth = sc.NORME.trait * 0.8;
          for (let par = 0; par < 2; par++) {                 // anneaux pairs / impairs : signes opposés de l'onde (deux teintes)
            ctx.strokeStyle = sc.sp.rgb[s][par ? 1 - q.ab : q.ab];
            ctx.globalAlpha = aMax * att * (0.25 + 0.75 * I) * (0.7 + 0.3 * sc.energie);
            ctx.beginPath();
            for (let kk = par; kk < nb; kk += 2) {
              const f = (kk + 0.75) / (m + 0.4), r = q.R * f, cx = q.x + q.ox * (1 - f), cy = q.y + q.oy * (1 - f), fade = kk === nb - 1 ? m - nb + 0.3 : 1;
              if (fade <= 0.05) continue;
              const lev = q.R * 0.16 * Math.cos(t * q.w + q.ph) * (par ? -1 : 1) * (1 - f * 0.6);   // relief : ventres soulevés, creux enfoncés
              ctx.moveTo(cx + r, cy - lev); ctx.ellipse(cx, cy - lev, r, r * ap, 0, 0, TAU);
            }
            ctx.stroke();
          }
          ctx.globalCompositeOperation = 'lighter';
          const spA = sc.sp.fin[s][q.ab];
          sc.point(ctx, sc.sp.doux[s][1 - q.ab], q.x + q.ox, q.y + q.oy, q.R * 0.5, aMax * att * (0.3 + 0.7 * I));
          for (let i = 0; i < NA; i++) {
            const a = TAU * i / NA, x = q.x + Math.cos(a) * q.R + q.DX[i], y = q.y + Math.sin(a) * q.R * ap + q.DY[i];
            const hz = 0.75 + 0.25 * Math.sin(i * 2.7 + q.ph);                 // chaque atome a sa hauteur (bosse) et un reflet
            sc.point(ctx, sc.sp.doux[s][q.ab], x, y - 2.5 * hz, 13 * hz, aMax * att * 0.35);
            sc.point(ctx, spA, x, y - 2.5 * hz, (6.5 + 2.5 * Math.sin(a)) * hz, aMax * att * (0.75 + 0.25 * Math.sin(a)));
            if (q.saut > 0.08 && ((i + Math.floor(t * 12)) % 4 === 0)) sc.point(ctx, or, x, y, 12, 0.8 * q.saut * att);
          }
          if (q.saut > 0.05) sc.point(ctx, or, q.x + q.ox, q.y + q.oy, 18, 0.7 * q.saut * att);
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // tunnel (monde 9) : effet tunnel. Des paquets d'onde filent vers les barrières (sc.geo.murs) ; au choc, une partie
  // revient, une trace exponentielle traverse la barrière et s'éteint, un petit paquet ressort de l'autre côté.
  // Bille proche d'un mur : SON onde fuit à travers (trace exponentielle) ; rebond : un paquet d'or part du point
  // de rebond ; flux : les paquets vont plus vite ; énergie : la transmission augmente.
  FABRIQUES.tunnel = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NP = Math.max(2, Math.round(p.max || 6)), murs = sc.geo.murs, NT = 14, M = 26;
    const or = spriteJeton(sc, 'or', true), orRgb = rgbJeton(sc, 'or'), aMax = Math.min(p.alpha || 0.7, sc.NORME.opaciteMax.traces), lam = p.onde || 9, sig = p.largeur || 20;
    const P = [], T = [];
    for (let i = 0; i < NP * 2; i++) P.push({ x: 0, y: 0, ux: 1, uy: 0, amp: 0, s: 0, D: 1e9, vie: 0, or: false, mur: -1 });
    for (let i = 0; i < NT; i++) T.push({ x: 0, y: 0, nx: 0, ny: 0, a: 0, vie: 0, or: false });
    let n = 0, it = 0, attente = 0, recharge = 0;
    function impact(x, y, ux, uy, sauf) {          // distance au premier mur sur le rayon (x, y) → (ux, uy)
      let best = 1e9, bi = -1;
      for (let i = 0; i < murs.length; i++) {
        if (i === sauf) continue;
        const m = murs[i], ex = m.x2 - m.x1, ey = m.y2 - m.y1, den = ux * ey - uy * ex;
        if (Math.abs(den) < 1e-6) continue;
        const wx = m.x1 - x, wy = m.y1 - y, tt = (wx * ey - wy * ex) / den, u = (wx * uy - wy * ux) / den;
        if (tt > 4 && u >= 0 && u <= 1 && tt < best) { best = tt; bi = i; }
      }
      return [best, bi];
    }
    function lancer(x, y, ux, uy, amp, estOr, sauf) {
      let q = null; for (const c of P) if (c.vie <= 0) { q = c; break; }
      if (!q) return;
      const h = impact(x, y, ux, uy, sauf);
      Object.assign(q, { x, y, ux, uy, amp, s: 0, D: h[0], mur: h[1], vie: 1, or: estOr });
    }
    function trace(x, y, nx, ny, a, estOr) { const q = T[it]; it = (it + 1) % NT; Object.assign(q, { x, y, nx, ny, a, vie: 1, or: estOr }); }
    function viser(x, y, estOr) {                   // vers un point d'un mur au hasard
      if (!murs.length) { const a = A() * TAU; lancer(x, y, Math.cos(a), Math.sin(a), 1, estOr, -1); return; }
      const m = murs[Math.floor(A() * murs.length)], u = 0.2 + 0.6 * A(), tx = m.x1 + (m.x2 - m.x1) * u, ty = m.y1 + (m.y2 - m.y1) * u, d = Math.hypot(tx - x, ty - y) || 1;
      lancer(x, y, (tx - x) / d, (ty - y) / d, 1, estOr, -1);
    }
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NP * Math.min(1, k * 1.25))) : 0; }, effectif: () => { let s = 0; for (const q of P) if (q.vie > 0) s += M; for (const q of T) if (q.vie > 0) s += M; return s; },
      evenement(type, e) { if (type === 'rebond' && n) viser(e.x, e.y - 6, true); },
      update(dt) {
        if (!n) return;
        let actifs = 0; for (const q of P) if (q.vie > 0) actifs++;
        attente -= dt * (1 + sc.energie);
        if (attente <= 0 && actifs < n) { attente = 0.8 + 1.2 * A(); const [x, y] = [sc.l * (0.1 + 0.8 * A()), sc.h * (0.1 + 0.8 * A())]; viser(x, y, false); }
        for (const q of P) {
          if (q.vie <= 0) continue;
          const f = sc.flux(q.x, q.y), v = (p.vitesse || 55) * (1 + Math.min(2, Math.hypot(f[0], f[1]) / 50));
          q.s += v * dt; q.vie -= dt * 0.18;
          if (q.s + sig * 0.6 >= q.D && q.mur >= 0) {        // choc sur la barrière
            const x = q.x + q.ux * q.D, y = q.y + q.uy * q.D, m = murs[q.mur], ex = m.x2 - m.x1, ey = m.y2 - m.y1, L = Math.hypot(ex, ey) || 1;
            let nx = -ey / L, ny = ex / L; if (nx * q.ux + ny * q.uy < 0) { nx = -nx; ny = -ny; }
            const tr = 0.25 + 0.4 * sc.energie, mur = q.mur;
            trace(x, y, nx, ny, q.amp, q.or);
            if (q.amp * tr > 0.12) lancer(x + nx * 5, y + ny * 5, q.ux, q.uy, q.amp * tr, q.or, mur);
            const dn = q.ux * nx + q.uy * ny, rx = q.ux - 2 * dn * nx, ry = q.uy - 2 * dn * ny;   // la part réfléchie repart
            const amp = q.amp * 0.7, estOr = q.or; q.vie = 0;
            if (amp > 0.2) lancer(x - nx * 3, y - ny * 3, rx, ry, amp, estOr, mur);
          }
          if (q.x + q.ux * q.s < -40 || q.x + q.ux * q.s > sc.l + 40 || q.y + q.uy * q.s < -40 || q.y + q.uy * q.s > sc.h + 40) q.vie = 0;
        }
        for (const q of T) if (q.vie > 0) q.vie -= dt * 0.75;
        const b = sc.bille; recharge -= dt;           // l'onde de la bille fuit à travers le mur le plus proche
        if (b && recharge <= 0) for (let i = 0; i < murs.length; i++) {
          const m = murs[i], ex = m.x2 - m.x1, ey = m.y2 - m.y1, L2 = ex * ex + ey * ey || 1, u = borne(((b.x - m.x1) * ex + (b.y - m.y1) * ey) / L2, 0, 1);
          const px = m.x1 + ex * u, py = m.y1 + ey * u, d = Math.hypot(b.x - px, b.y - py);
          if (d < 46 && d > 1) { trace(px, py, (px - b.x) / d, (py - b.y) / d, 1.1 * (1 - d / 46) + 0.3, false); recharge = 0.35; break; }
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const kk = TAU / lam;
        for (const q of P) {                              // paquets : sinusoïde sous enveloppe gaussienne
          if (q.vie <= 0) continue;
          const cx = q.x + q.ux * q.s, cy = q.y + q.uy * q.s, nx = -q.uy, ny = q.ux, att = (0.45 + 0.55 * sc.calme(cx, cy)) * Math.min(1, q.vie * 3, q.s / 20);
          ctx.strokeStyle = q.or ? orRgb : sc.sp.rgb[sc.seau(cy)][0]; ctx.lineWidth = sc.NORME.trait * 0.75; ctx.globalAlpha = (q.or ? 0.7 : aMax * 0.85) * att;
          ctx.beginPath();
          for (let j = 0; j <= M; j++) {
            const u = (j / M - 0.5) * sig * 3, d = q.s + u; if (d > q.D) break;
            const e = Math.exp(-(u / sig) * (u / sig) * 3) * q.amp * 4.2, y = e * Math.cos(kk * u - t * 9);
            const x = cx + q.ux * u + nx * y, yy = cy + q.uy * u + ny * y;
            if (j) ctx.lineTo(x, yy); else ctx.moveTo(x, yy);
          }
          ctx.stroke();
        }
        for (const q of T) {                              // traces exponentielles : l'onde traverse et s'éteint
          if (q.vie <= 0) continue;
          const tx = -q.ny, ty = q.nx, att = (0.5 + 0.5 * sc.calme(q.x, q.y)) * q.vie, s = sc.seau(q.y);
          ctx.strokeStyle = q.or ? orRgb : sc.sp.rgb[s][1]; ctx.lineWidth = sc.NORME.trait; ctx.globalAlpha = (q.or ? 0.85 : aMax) * att;
          ctx.beginPath();
          for (let j = 0; j <= M; j++) {
            const d = -8 + j * 2.2, env = d < 0 ? 1 : Math.exp(-d / 9), y = env * q.a * 7 * Math.cos(kk * d - t * 9);
            const x = q.x + q.nx * d + tx * y, yy = q.y + q.ny * d + ty * y;
            if (j) ctx.lineTo(x, yy); else ctx.moveTo(x, yy);
          }
          ctx.stroke();
          ctx.globalAlpha *= 0.45; ctx.beginPath();        // l'enveloppe exponentielle elle-même
          for (let j = 0; j <= 14; j++) { const d = j * 3.5, y = Math.exp(-d / 9) * q.a * 7; if (j) ctx.lineTo(q.x + q.nx * d + tx * y, q.y + q.ny * d + ty * y); else ctx.moveTo(q.x + q.nx * d + tx * y, q.y + q.ny * d + ty * y); }
          ctx.stroke();
          ctx.strokeStyle = q.or ? orRgb : sc.sp.rgb[s][0]; ctx.globalAlpha = 0.5 * att; ctx.lineWidth = sc.NORME.trait * 1.0;   // la barrière s'allume là où l'onde passe
          ctx.beginPath(); ctx.moveTo(q.x - tx * 14 * q.a, q.y - ty * 14 * q.a); ctx.lineTo(q.x + tx * 14 * q.a, q.y + ty * 14 * q.a); ctx.stroke();
          ctx.globalCompositeOperation = 'lighter'; sc.point(ctx, q.or ? or : sc.sp.fin[s][1], q.x, q.y, 14, 0.8 * att * q.a);
          for (let j = 1; j <= 4; j++) { const d = j * 7; sc.point(ctx, sc.sp.doux[s][1], q.x + q.nx * d, q.y + q.ny * d, 12, 0.5 * att * q.a * Math.exp(-d / 9)); }   // densité |ψ|² qui décroît
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // corde (monde 10) : cordes tendues qui vibrent sur leurs harmoniques 2, 3, 4 (le mode dominant change lentement),
  // enveloppe pâle du mode et nœuds marqués. Bille proche : elle PINCE la corde (somme de modes : deux bosses
  // partent et se réfléchissent aux chevilles) ; rebond : la corde la plus proche est frappée en or ; flux : la corde
  // se bombe ; énergie : les harmoniques élevées s'ajoutent.
  FABRIQUES.corde = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NS = Math.max(1, Math.round(p.max || 5)), LG = p.longueur || [110, 200], NM = 7, NP = 40;
    const or = spriteJeton(sc, 'or', true), orRgb = rgbJeton(sc, 'or'), aMax = Math.min(p.alpha || 0.6, sc.NORME.opaciteMax.traces), S = [];
    const NG = Math.max(1, Math.min(NS, p.groupes || 2)), parG = Math.ceil(NS / NG), ecart = p.ecart || 12;
    for (let g = 0; g < NG; g++) {                   // des jeux de cordes parallèles (harpe), pas des fils épars
      const L = melange(LG[0], LG[1], A()), [gx, gy] = placeCalme(sc, A, 0.12, 30, L * 0.55);
      const cote = gx < sc.l * 0.2 || gx > sc.l * 0.8, ang0 = (cote ? Math.PI / 2 : 0) + (A() - 0.5) * 0.9;   // fond11 : jeux moins systématiques (angle, écart, longueur et éventail variés)
      for (let i = 0; i < parG && S.length < NS; i++) {
        const ang = ang0 + (i - (parG - 1) / 2) * 0.035 + (A() - 0.5) * 0.04, ux = Math.cos(ang), uy = Math.sin(ang), o = (i - (parG - 1) / 2) * ecart * (0.8 + 0.5 * A()), Li = L * (1 - 0.1 * i - 0.14 * A()), dec = L * (0.065 * i + 0.06 * (A() - 0.5));
        S.push({ x: gx - uy * o + ux * dec, y: gy + ux * o + uy * dec, L: Li, ux, uy, ex: new Float32Array(NM + 1), ph: new Float32Array(NM + 1), base: 2 + ((g + i) % 3), tb: A() * 8, bow: 0, orx: 0, contact: 0, ab: i & 1, Y: new Float32Array(NP + 1) });
      }
    }
    let n = 0;
    function pincer(q, s0, f) { for (let m = 1; m <= NM; m++) { q.ex[m] = Math.min(1.6, q.ex[m] + f * Math.sin(m * Math.PI * s0) / (m * 0.9)); q.ph[m] = 0; } }
    function proj(q, x, y) { const dx = x - (q.x - q.ux * q.L / 2), dy = y - (q.y - q.uy * q.L / 2), s = (dx * q.ux + dy * q.uy) / q.L, d = -dx * q.uy + dy * q.ux; return [s, d]; }
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NS * Math.min(1, k * 1.25))) : 0; }, effectif: () => n * NP,
      evenement(type, e) {
        if (type !== 'rebond' || !n) return;
        let best = null, bd = 1e9; for (let i = 0; i < n; i++) { const d = Math.hypot(S[i].x - e.x, S[i].y - e.y); if (d < bd) { bd = d; best = S[i]; } }
        if (best) { const [s] = proj(best, e.x, e.y); pincer(best, borne(s, 0.15, 0.85), 1.2); best.orx = 1; }
      },
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = S[i];
          q.tb += dt; if (q.tb > 9) { q.tb = 0; q.base = 2 + ((q.base - 1) % 3); }        // 2 → 3 → 4 → 2…
          for (let m = 1; m <= NM; m++) { q.ex[m] *= 1 - Math.min(1, dt * (0.35 + 0.08 * m)); q.ph[m] += dt * m * 2.4; }
          q.orx *= 1 - Math.min(1, dt * 0.6);
          const f = sc.flux(q.x, q.y); q.bow += (borne((-q.uy * f[0] + q.ux * f[1]) * 0.03, -q.L * 0.03, q.L * 0.03) - q.bow) * Math.min(1, dt);
          if (b) {
            const [s, d] = proj(q, b.x, b.y);
            if (s > 0.04 && s < 0.96 && Math.abs(d) < 18) { if (q.contact <= 0) pincer(q, s, 0.7); q.contact = 0.5; }
          }
          q.contact -= dt;
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        for (let i = 0; i < n; i++) {
          const q = S[i], s0 = sc.seau(q.y), att = 0.4 + 0.6 * sc.calme(q.x, q.y), nx = -q.uy, ny = q.ux, x0 = q.x - q.ux * q.L / 2, y0 = q.y - q.uy * q.L / 2;
          const A0 = q.L * 0.035, fb = Math.min(1, q.tb / 1.5) * Math.min(1, (9 - q.tb) / 1.5);     // fondu entre deux modes dominants
          let exc = 0; for (let m = 1; m <= NM; m++) exc = Math.max(exc, q.ex[m]);
          for (let j = 0; j <= NP; j++) {
            const s = j / NP;
            let y = A0 * fb * Math.sin(q.base * Math.PI * s) * Math.cos(t * q.base * 1.3 + i) + q.bow * Math.sin(Math.PI * s);
            if (sc.energie > 0.4) y += A0 * (sc.energie - 0.4) * Math.sin(5 * Math.PI * s) * Math.cos(t * 6.5);
            for (let m = 1; m <= NM; m++) if (q.ex[m] > 0.01) y += A0 * 2.2 * q.ex[m] * Math.sin(m * Math.PI * s) * Math.cos(q.ph[m]);
            q.Y[j] = y;
          }
          // enveloppe du mode dominant (± A), très pâle
          ctx.strokeStyle = sc.sp.rgb[s0][1 - q.ab]; ctx.lineWidth = sc.NORME.trait * 0.6; ctx.globalAlpha = aMax * att * 0.22 * fb;
          ctx.beginPath();
          for (const sg of [-1, 1]) for (let j = 0; j <= NP; j += 2) { const s = j / NP, e = sg * A0 * Math.sin(q.base * Math.PI * s), x = x0 + q.ux * q.L * s + nx * e, y = y0 + q.uy * q.L * s + ny * e; if (j) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
          ctx.stroke();
          // la corde
          ctx.strokeStyle = sc.sp.rgb[s0][q.ab]; ctx.lineWidth = sc.NORME.trait * (1 + 0.5 * Math.min(1, exc)); ctx.globalAlpha = aMax * att * (0.7 + 0.3 * Math.min(1, exc + sc.energie));
          ctx.beginPath();
          for (let j = 0; j <= NP; j++) { const s = j / NP, x = x0 + q.ux * q.L * s + nx * q.Y[j], y = y0 + q.uy * q.L * s + ny * q.Y[j]; if (j) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
          ctx.stroke();
          if (q.orx > 0.05) { ctx.strokeStyle = orRgb; ctx.globalAlpha = 0.85 * q.orx * att; ctx.stroke(); }
          // chevilles (anneaux) et nœuds du mode (points), ventres allumés par l'énergie
          ctx.strokeStyle = sc.sp.rgb[s0][q.ab]; ctx.globalAlpha = aMax * att * 0.8; ctx.lineWidth = sc.NORME.trait * 0.8;
          ctx.beginPath(); ctx.moveTo(x0 + 2.6, y0); ctx.arc(x0, y0, 2.6, 0, TAU); const x1 = x0 + q.ux * q.L, y1 = y0 + q.uy * q.L; ctx.moveTo(x1 + 2.6, y1); ctx.arc(x1, y1, 2.6, 0, TAU); ctx.stroke();
          ctx.globalCompositeOperation = 'lighter';
          const sp = sc.sp.fin[s0][1 - q.ab];
          for (let k2 = 1; k2 < q.base; k2++) { const s = k2 / q.base, j = Math.round(s * NP); sc.point(ctx, sp, x0 + q.ux * q.L * s + nx * q.Y[j], y0 + q.uy * q.L * s + ny * q.Y[j], 7, aMax * att * fb); }
          const pul = (t * 0.35 + i * 0.37) % 1.6;                     // une étincelle parcourt la corde d'une cheville à l'autre
          if (pul < 1) { const j = Math.round(pul * NP); sc.point(ctx, sp, x0 + q.ux * q.L * pul + nx * q.Y[j], y0 + q.uy * q.L * pul + ny * q.Y[j], 9, aMax * att * Math.sin(Math.PI * pul) * 0.9); }
          for (let k2 = 0; k2 < q.base; k2++) { const s = (k2 + 0.5) / q.base, j = Math.round(s * NP); sc.point(ctx, sc.sp.doux[s0][1 - q.ab], x0 + q.ux * q.L * s, y0 + q.uy * q.L * s, 10 + A0 * 2.5, aMax * att * 0.22 * fb); }   // ventres : flou de bougé (pose longue)
          if (sc.energie > 0.3 || exc > 0.2) for (let k2 = 0; k2 < q.base; k2++) { const s = (k2 + 0.5) / q.base, j = Math.round(s * NP); sc.point(ctx, sc.sp.doux[s0][q.ab], x0 + q.ux * q.L * s + nx * q.Y[j], y0 + q.uy * q.L * s + ny * q.Y[j], 16, aMax * att * Math.min(1, sc.energie + exc) * 0.5); }
          if (q.orx > 0.05) { const j = NP >> 1; sc.point(ctx, or, x0 + q.ux * q.L * 0.5 + nx * q.Y[j], y0 + q.uy * q.L * 0.5 + ny * q.Y[j], 18, 0.7 * q.orx * att); }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // reseau_tourbillons (monde 4) : réseau d'Abrikosov d'un condensat en rotation (tourbillons quantifiés figés
  // dans un réseau triangulaire qui tourne d'un bloc). Repos : rotation lente ; bille : le réseau se déforme et
  // fond localement ; rebond : onde de choc d'or qui traverse le réseau ; flux : rotation plus vive ; énergie :
  // de nouveaux tourbillons naissent (en fondu) au bord du nuage.
  FABRIQUES.reseau_tourbillons = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NN = Math.max(1, p.nuages || 2), MAXV = Math.max(7, Math.round(p.max || 19)), RR = p.rayon || [55, 75];
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.45, sc.NORME.opaciteMax.structures * 1.6);
    const nuages = [];
    for (let c = 0; c < NN; c++) {
      const R = melange(RR[0], RR[1], A()), [x, y] = placeCalme(sc, A, 0.14, 30, R * 1.3), a = R / 2.4, V = [];
      for (let j = -4; j <= 4; j++) for (let i = -4; i <= 4; i++) {
        const u = (i + (j & 1) * 0.5) * a, v = j * a * 0.866, d = Math.hypot(u, v);
        if (d <= R * 1.7) V.push({ u, v, d, dx: 0, dy: 0, vx: 0, vy: 0, fonte: 0, vie: 0, flash: 0, spin: A() * TAU });
      }
      V.sort((m, q) => m.d - q.d);
      nuages.push({ x, y, R, a, V: V.slice(0, MAXV), th: A() * TAU, om: (0.12 + 0.1 * A()) * (A() < 0.5 ? -1 : 1) * (p.vitesse || 1), choc: -1, cx: 0, cy: 0, ab: c & 1 });
    }
    let k = 0;
    return {
      regler(kk) { k = kk; }, effectif: () => { let s = 0; for (const c of nuages) for (const v of c.V) if (v.vie > 0.05) s++; return s; },
      evenement(type, e) {
        if (type !== 'rebond' || k <= 0) return;
        for (const c of nuages) if (Math.hypot(c.x - e.x, c.y - e.y) < 260) { c.choc = 0; c.cx = e.x; c.cy = e.y; }
      },
      update(dt) {
        if (k <= 0) return;
        const b = sc.bille;
        for (const c of nuages) {
          const f = sc.flux(c.x, c.y), fm = Math.hypot(f[0], f[1]);
          c.th += c.om * dt * (1 + Math.min(4, fm / 35));
          if (c.choc >= 0) { c.choc += dt * 150; if (c.choc > 240) c.choc = -1; }
          const nActif = Math.round(c.V.length * Math.min(1, k * (0.55 + 0.45 * sc.energie + 0.15)));
          const co = Math.cos(c.th), si = Math.sin(c.th);
          for (let i = 0; i < c.V.length; i++) {
            const v = c.V[i], cible = i < nActif ? 1 : 0;
            v.vie += (cible - v.vie) * Math.min(1, dt * 1.6);
            v.spin += dt * (3 + 4 * sc.energie) * (c.om > 0 ? 1 : -1);
            const px = c.x + v.u * co - v.v * si + v.dx, py = c.y + v.u * si + v.v * co + v.dy;
            let fx = -v.dx * 6 - v.vx * 2.2, fy = -v.dy * 6 - v.vy * 2.2;   // ressort vers la place du réseau
            if (b) { const ex = px - b.x, ey = py - b.y, d = Math.hypot(ex, ey) || 1; if (d < 70) { const g = (1 - d / 70); fx += ex / d * 900 * g; fy += ey / d * 900 * g; v.fonte = Math.min(1, v.fonte + dt * 3 * g); } }
            if (c.choc >= 0) { const ex = px - c.cx, ey = py - c.cy, d = Math.hypot(ex, ey) || 1, w = Math.abs(d - c.choc); if (w < 16) { const g = (1 - w / 16) * (1 - c.choc / 240); fx += ex / d * 1400 * g; fy += ey / d * 1400 * g; v.flash = Math.max(v.flash, g); } }
            v.vx += fx * dt; v.vy += fy * dt; v.dx += v.vx * dt; v.dy += v.vy * dt;
            v.fonte = Math.max(0, v.fonte - dt * 0.35); v.flash *= 1 - Math.min(1, dt * 2.2);
          }
        }
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.lineCap = 'round';
        for (const c of nuages) {
          const s = sc.seau(c.y), att = 0.4 + 0.6 * sc.calme(c.x, c.y), co = Math.cos(c.th), si = Math.sin(c.th);
          // bord du nuage (le condensat) : anneau très pâle qui respire
          ctx.strokeStyle = sc.sp.rgb[s][c.ab]; ctx.lineWidth = sc.NORME.trait * 0.7;
          ctx.globalAlpha = aMax * 0.22 * att; ctx.beginPath(); ctx.arc(c.x, c.y, c.a * 0.55 + c.V[Math.max(0, Math.round(c.V.length * Math.min(1, k * (0.7 + 0.45 * sc.energie))) - 1)].d * (1.12 + 0.03 * Math.sin(t * 0.7)), 0, TAU); ctx.stroke();
          // tourbillons : deux arcs qui s'enroulent autour d'un cœur ; la fonte les ouvre et les éteint
          for (let passe = 0; passe < 2; passe++) {
            ctx.strokeStyle = sc.sp.rgb[s][passe ? 1 - c.ab : c.ab]; ctx.lineWidth = sc.NORME.trait * (passe ? 0.85 : 0.65);
            ctx.globalAlpha = aMax * att * (passe ? 0.75 : 0.42) * (0.75 + 0.25 * sc.energie);
            ctx.beginPath();
            for (const v of c.V) {
              if (v.vie < 0.03) continue;
              const px = c.x + v.u * co - v.v * si + v.dx, py = c.y + v.u * si + v.v * co + v.dy;
              const rv = c.a * (passe ? 0.2 : 0.34) * (0.4 + 0.6 * v.vie) * (1 + 1.2 * v.fonte), ouv = (passe ? 1.6 : 2.3) * (1 - 0.6 * v.fonte) * v.vie;
              const a0 = v.spin + passe * Math.PI;
              ctx.moveTo(px + rv * Math.cos(a0), py + rv * Math.sin(a0)); ctx.arc(px, py, rv, a0, a0 + ouv);
            }
            ctx.stroke();
          }
          // cœurs et éclats d'or du choc
          ctx.globalCompositeOperation = 'lighter';
          const sp = sc.sp.fin[s][1 - c.ab];
          for (const v of c.V) {
            if (v.vie < 0.03) continue;
            const px = c.x + v.u * co - v.v * si + v.dx, py = c.y + v.u * si + v.v * co + v.dy;
            sc.point(ctx, sp, px, py, 5 + 4 * sc.energie, aMax * att * v.vie * (0.5 + 0.5 * sc.energie) * (1 - v.fonte));
            if (v.flash > 0.04) sc.point(ctx, or, px, py, 16, 0.85 * v.flash * att);
          }
          ctx.globalCompositeOperation = 'source-over';
          if (c.choc >= 0) { ctx.strokeStyle = rgbJeton(sc, 'or'); ctx.globalAlpha = 0.4 * (1 - c.choc / 240) * att; ctx.lineWidth = sc.NORME.trait; ctx.beginPath(); ctx.arc(c.cx, c.cy, c.choc, 0, TAU); ctx.stroke(); }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // condensat (monde 4) : le pic du condensat de Bose et Einstein, en fil de fer au loin. Le nuage thermique se
  // contracte en un pic unique puis se relâche (respiration) ; la bille le réchauffe (le pic s'effondre) ; le rebond
  // le fait jaillir avec une crête d'or ; le flux le balance ; l'énergie l'affine.
  FABRIQUES.condensat = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NI = 10, NJ = 26, T = p.taille || 110, per = p.periode || 7;
    const [x0, y0] = p.x !== undefined ? [sc.l * p.x, sc.h * p.y] : placeCalme(sc, A, 0.2, 30, T);
    if (p.x !== undefined) (sc.occupes || (sc.occupes = [])).push([x0, y0 - T * 0.2, T * 0.9]);
    const or = spriteJeton(sc, 'or', true), orRgb = rgbJeton(sc, 'or'), aMax = Math.min(p.alpha || 0.4, sc.NORME.opaciteMax.structures);
    let k = 0, c = 0.3, chaud = 0, jet = 0, bal = 0, ph = A() * TAU;
    const Z = (x, y, cc) => { const r2 = x * x + y * y, sg = melange(0.3, 0.012, cc); return 0.2 * Math.exp(-r2 / 0.4) + melange(0.1, 1.05, cc) * Math.exp(-r2 / sg); };
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? NI * NJ * 2 : 0),
      evenement(type, e) { if (type === 'rebond' && k > 0) jet = 1; },
      update(dt) {
        if (k <= 0) return;
        ph += dt * TAU / per * (1 + 0.6 * sc.energie);
        const b = sc.bille; let h = 0;
        if (b) { const d = Math.hypot(b.x - x0, b.y - y0); h = d < T * 1.6 ? 1 - d / (T * 1.6) : 0; }
        chaud += (h - chaud) * Math.min(1, dt * 2); jet *= 1 - Math.min(1, dt * 0.9);
        const resp = Math.pow(0.5 + 0.5 * Math.sin(ph), 1.6);
        const cible = borne(resp * (0.75 + 0.25 * sc.energie) * (1 - 0.85 * chaud) + jet, 0, 1.15);
        c += (cible - c) * Math.min(1, dt * 3);
        const f = sc.flux(x0, y0); bal += (borne(f[0] * 0.15, -12, 12) - bal) * Math.min(1, dt);
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        const s = sc.seau(y0), att = (0.45 + 0.55 * sc.calme(x0, y0)) * sc.loinDuBut(x0, y0, T), cc = Math.min(1, c);
        if (att < 0.03) return;
        const P = (x, y) => { const z = Z(x, y, cc) * (c > 1 ? c : 1); return [x0 + (x - y * 0.55) * T + bal * z, y0 + (y * 0.3 + x * 0.06) * T - z * T * 0.7]; };
        ctx.lineWidth = sc.NORME.trait * 0.7; ctx.lineJoin = 'round';
        for (let dir = 0; dir < 2; dir++) {
          ctx.strokeStyle = sc.sp.rgb[s][dir]; ctx.globalAlpha = aMax * att * (dir ? 0.45 : 0.8);
          ctx.beginPath();
          for (let i = 0; i <= NI; i++) {
            const a = -1 + 2 * i / NI;
            for (let j = 0; j <= NJ; j++) { const bb = -1 + 2 * j / NJ, q = dir ? P(a, bb) : P(bb, a); if (j) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }
          }
          ctx.stroke();
        }
        const top = P(0, 0);
        ctx.globalCompositeOperation = 'lighter';
        sc.point(ctx, sc.sp.doux[s][1], top[0], top[1], 20 + 30 * cc, aMax * att * (0.3 + 0.9 * cc));
        if (jet > 0.05) {
          sc.point(ctx, or, top[0], top[1], 26, 0.9 * jet * att);
          ctx.strokeStyle = orRgb; ctx.globalAlpha = 0.8 * jet * att; ctx.lineWidth = sc.NORME.trait * 1.2; ctx.beginPath();
          for (let j = 0; j <= NJ; j++) { const q = P(-1 + 2 * j / NJ, 0); if (j) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }
          ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    };
  } };
  // givre (monde 4) : aiguilles de givre ABSTRAITES (fond10 : plus de fougère à 60°) qui poussent le long des surfaces de glace (sc.geo.murs, « glace »),
  // tiennent, se subliment, repoussent. Bille proche : le givre fond et scintille ; rebond : il se brise en éclats
  // d'or qui retombent ; flux : les fougères se couchent ; énergie : elles poussent plus vite et brillent.
  FABRIQUES.givre = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, murs = sc.geo.murs.filter(m => m.glace || p.tous), F = [], NE = 28;
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.6, sc.NORME.opaciteMax.reactifs), LG = p.longueur || [8, 20];
    let total = 0; for (const m of murs) total += Math.hypot(m.x2 - m.x1, m.y2 - m.y1);
    const NF = Math.round(p.max || 36);
    for (const m of murs) {
      const L = Math.hypot(m.x2 - m.x1, m.y2 - m.y1), nb = Math.max(2, Math.round(NF * L / (total || 1))), ux = (m.x2 - m.x1) / L, uy = (m.y2 - m.y1) / L;
      for (let i = 0; i < nb; i++) {
        const f = (i + 0.2 + 0.6 * A()) / nb, cote = A() < 0.72 ? -1 : 1;
        let nx = -uy * cote, ny = ux * cote; if (Math.abs(uy) > 0.9) { nx = (A() < 0.5 ? -1 : 1); ny = 0; }
        F.push({ x: m.x1 + (m.x2 - m.x1) * f, y: m.y1 + (m.y2 - m.y1) * f, a: Math.atan2(ny, nx) + (A() - 0.5) * 0.9, L: melange(LG[0], LG[1], A()), g: A() * 0.8, v: 0.06 + 0.06 * A(), tenue: 0, ph: A() * TAU, ab: A() < 0.3 ? 1 : 0, pli: 0 });
      }
    }
    const E = []; for (let i = 0; i < NE; i++) E.push({ x: 0, y: 0, vx: 0, vy: 0, v: 0 });
    let n = 0, ie = 0;
    return {
      regler(k) { n = Math.round(F.length * Math.min(1, k * 1.2)); }, effectif: () => n * 9,
      evenement(type, e) {
        if (type !== 'rebond' || !n) return;
        for (let i = 0; i < n; i++) {
          const q = F[i], d = Math.hypot(q.x - e.x, q.y - e.y);
          if (d < 90 && q.g > 0.15) {
            for (let j = 0; j < 2; j++) { const s = E[ie]; ie = (ie + 1) % NE; const r = q.L * q.g * A(); s.x = q.x + Math.cos(q.a) * r; s.y = q.y + Math.sin(q.a) * r; const an = q.a + (A() - 0.5) * 1.6, vv = 40 + 70 * A(); s.vx = Math.cos(an) * vv; s.vy = Math.sin(an) * vv - 40; s.v = 1; }
            q.g = 0; q.tenue = 0;
          }
        }
      },
      update(dt) {
        const b = sc.bille, vit = 1 + 2.5 * sc.energie;
        for (let i = 0; i < n; i++) {
          const q = F[i];
          if (q.tenue > 0) { q.tenue -= dt; if (q.tenue <= 0) q.tenue = -1; }
          else if (q.tenue < 0) { q.g -= dt * 0.12; if (q.g <= 0) { q.g = 0; q.tenue = 0; } }       // sublimation
          else { q.g += q.v * dt * vit; if (q.g >= 1) { q.g = 1; q.tenue = 4 + 6 * Math.abs(Math.sin(q.ph)); } }
          if (b) { const d = Math.hypot(b.x - q.x, b.y - q.y); if (d < 55) { q.g = Math.max(0, q.g - dt * 1.6 * (1 - d / 55)); q.tenue = 0; } }
          const f = sc.flux(q.x, q.y); q.pli += (borne((-Math.sin(q.a) * f[0] + Math.cos(q.a) * f[1]) * 0.006, -0.5, 0.5) - q.pli) * Math.min(1, dt * 2);
        }
        for (const s of E) if (s.v > 0) { s.vy += 160 * dt; s.x += s.vx * dt; s.y += s.vy * dt; s.v -= dt * 0.9; }
      },
      dessiner(ctx, t) {
        if (!n) return;
        ctx.lineCap = 'round';
        for (let passe = 0; passe < 2; passe++) {
          ctx.strokeStyle = sc.sp.rgb[sc.seau(sc.h * 0.5)][passe]; ctx.lineWidth = sc.NORME.trait * (passe ? 0.6 : 0.9);
          ctx.globalAlpha = aMax * (passe ? 0.55 : 0.75) * (0.7 + 0.3 * sc.energie);
          ctx.beginPath();
          for (let i = 0; i < n; i++) {
            const q = F[i]; if (q.g < 0.04 || q.ab !== passe) continue;
            const a = q.a + q.pli, L = q.L * q.g, ca = Math.cos(a), sa = Math.sin(a);
            ctx.moveTo(q.x, q.y); ctx.lineTo(q.x + ca * L, q.y + sa * L);
            for (let j = 1; j <= 4; j++) {
              const f = j / 5.2, bx = q.x + ca * L * f, by = q.y + sa * L * f, l2 = L * (1 - f) * 0.38, s = j & 1 ? 1 : -1, a2 = a + s * (0.22 + 0.07 * j) + q.pli;   // fond10 : aiguilles presque couchées (plus de ramure à 60°, aucune forme de flocon)
              ctx.moveTo(bx, by); ctx.lineTo(bx + Math.cos(a2) * l2, by + Math.sin(a2) * l2);
            }
          }
          ctx.stroke();
        }
        ctx.globalCompositeOperation = 'lighter';
        const sp = sc.sp.fin[sc.seau(sc.h * 0.5)][1];
        for (let i = 0; i < n; i++) {               // scintillement à la pointe des fougères mûres
          const q = F[i], gl = Math.sin(t * 2.3 + q.ph * 3);
          if (q.g > 0.6 && gl > 0.75) sc.point(ctx, sp, q.x + Math.cos(q.a + q.pli) * q.L * q.g, q.y + Math.sin(q.a + q.pli) * q.L * q.g, 9, aMax * (gl - 0.75) * 4 * (0.5 + 0.5 * sc.energie));
        }
        for (const s of E) if (s.v > 0) sc.point(ctx, or, s.x, s.y, 7, 0.9 * s.v);
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    };
  } };
  /* =====================================================================
     ÉLÉMENTS — phase 2 (mondes 1, 4, 6, 9, 10, 11). États lisibles : repos,
     bille proche, rebond (toujours en or), flux fort, énergie.
     ===================================================================== */
  // Place un objet hors du cœur du terrain (essais au hasard, le plus calme gagne)
  // et loin des objets déjà posés (sc.occupes, remis à zéro à chaque recomposition du niveau)
  function placeCalme(sc, A, marge, essais, rayon) {
    const R = rayon || 40, occ = sc.occupes || (sc.occupes = []);
    let bx = sc.l / 2, by = sc.h / 2, bc = -1;
    for (let e = 0; e < (essais || 30); e++) {
      const x = sc.l * (marge + (1 - 2 * marge) * A()), y = sc.h * (marge + (1 - 2 * marge) * A());
      let c = sc.calme(x, y) * sc.loinDuBut(x, y, R);
      for (const o of occ) { const d = Math.hypot(o[0] - x, o[1] - y); if (d < o[2] + R) c *= 0.15 + 0.85 * d / (o[2] + R); }
      if (c > bc + 0.02) { bc = c; bx = x; by = y; }
      if (c > 0.92) break;
    }
    occ.push([bx, by, R]);
    return [bx, by];
  }
  // helice (monde 1) : doubles hélices composées par niveau + une hélice fantôme. La bille OUVRE l'hélice
  // (les brins s'écartent, les barreaux cassent) et elle se referme lentement derrière elle ; le rebond lance
  // une impulsion d'or qui court le long des brins (réplication) ; le flux tord l'axe ; l'énergie allume les barreaux.
  FABRIQUES.helice = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NB = Math.max(1, Math.min(p.places ? p.places.length : 99, Math.round(p.max || 3))), N = 44, H = [], aMax = Math.min(p.alpha || 0.6, sc.NORME.opaciteMax.traces);
    const or = spriteJeton(sc, 'or', true), orRgb = rgbJeton(sc, 'or'), LG = p.longueur || [150, 260];
    for (let i = 0; i < NB + (p.fantome ? 1 : 0); i++) {
      const fant = i === NB;
      const L = fant ? sc.h * (p.fantomeL || 0.46) : melange(LG[0], LG[1], A()), pl = !fant && p.places && p.places[i];   // places : [x, y, angle] en fractions — hélices cantonnées en haut et en bas, hors de la trace
      const [x, y] = fant ? [sc.l * (0.36 + 0.28 * A()), sc.h * 0.47] : pl ? [sc.l * pl[0], sc.h * pl[1]] : placeCalme(sc, A, 0.12, 30, L * 0.3);
      if (pl) (sc.occupes || (sc.occupes = [])).push([x, y, L * 0.3]);
      const amp = L * (fant ? 0.12 : 0.1);
      const ang = fant ? Math.PI / 2 + (A() - 0.5) * 0.7 : pl ? pl[2] + (A() - 0.5) * 0.12 : (A() - 0.5) * 1.4 + (A() < 0.45 ? Math.PI / 2 : 0);
      H.push({ x, y, L, amp, ang, ux: Math.cos(ang), uy: Math.sin(ang), tours: L / (amp * (fant ? 4.2 : 3.8)), ph: A() * TAU, vit: (0.5 + 0.6 * A()) * (A() < 0.5 ? -1 : 1) * (fant ? 0.35 : 1) * (p.vitesse || 1),
        fant, ouv: new Float32Array(N + 1), puls: -1, bow: 0, eclat: 0, ab: A() < 0.5 ? 1 : 0,
        PA: new Float32Array((N + 1) * 2), PB: new Float32Array((N + 1) * 2), D: new Float32Array(N + 1) });
    }
    let n = 0;
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NB * Math.min(1, k * 1.3))) : 0; }, effectif: () => (n ? (n + (p.fantome ? 1 : 0)) * N * 2 : 0),
      evenement(type, e) {
        if (type !== 'rebond' || !n) return;
        let best = null, bd = 1e9;
        for (const q of H) { if (q.fant) continue; const d = Math.hypot(q.x - e.x, q.y - e.y); if (d < bd) { bd = d; best = q; } }
        if (best) { best.puls = 0; best.eclat = 1; }
        for (const q of H) if (q.fant) q.eclat = Math.max(q.eclat, 0.5);
      },
      update(dt) {
        const b = sc.bille, ray = p.ouverture || 70;
        for (let i = 0; i < H.length; i++) {
          const q = H[i]; if (!q.fant && i >= n) continue;
          const f = sc.flux(q.x, q.y), fm = Math.hypot(f[0], f[1]), perp = (-q.uy * f[0] + q.ux * f[1]);
          q.ph += q.vit * dt * (1 + Math.min(3, fm / 40) + 1.5 * sc.energie);
          q.bow += (borne(perp * 0.5, -q.L * 0.18, q.L * 0.18) - q.bow) * Math.min(1, dt * 1.2);
          if (q.puls >= 0) { q.puls += dt * 1.3; if (q.puls > 1.15) q.puls = -1; }
          q.eclat *= 1 - Math.min(1, dt * 0.7);
          for (let j = 0; j <= N; j++) {
            let o = q.ouv[j] - dt * (q.fant ? 0.3 : 0.45);   // se referme lentement (réparation)
            if (b) { const s = j / N - 0.5, px = q.x + q.ux * s * q.L, py = q.y + q.uy * s * q.L, d = Math.hypot(b.x - px, b.y - py); if (d < ray) o = Math.max(o, 1 - d / ray); }
            q.ouv[j] = o < 0 ? 0 : o;
          }
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        ctx.lineCap = 'round';
        for (let i = 0; i < H.length; i++) {
          const q = H[i]; if (!q.fant && i >= n) continue;
          const att = q.fant ? 0.2 * (0.6 + 0.4 * sc.attenuation) : (0.35 + 0.65 * sc.calme(q.x, q.y)), nx = -q.uy, ny = q.ux, s0 = sc.seau(q.y);
          for (let j = 0; j <= N; j++) {
            const s = j / N, bx = q.x + q.ux * (s - 0.5) * q.L + nx * q.bow * Math.sin(Math.PI * s), by = q.y + q.uy * (s - 0.5) * q.L + ny * q.bow * Math.sin(Math.PI * s);
            const a = s * q.tours * TAU + q.ph, ta = Math.min(1, s * 7, (1 - s) * 7), op = q.ouv[j];
            const o = Math.sin(a) * q.amp * ta * (1 + 0.6 * op), sep = op * q.amp * 1.6 * ta;
            q.PA[j * 2] = bx + nx * (o + sep); q.PA[j * 2 + 1] = by + ny * (o + sep);
            q.PB[j * 2] = bx - nx * (o + sep); q.PB[j * 2 + 1] = by - ny * (o + sep);
            q.D[j] = Math.cos(a);
          }
          // brins : arrière (pâle) puis avant (vif), deux tracés par brin
          ctx.strokeStyle = sc.sp.rgb[s0][q.ab];
          for (let passe = 0; passe < 2; passe++) {
            ctx.globalAlpha = aMax * att * (passe ? 0.95 : 0.28); ctx.lineWidth = q.fant ? sc.NORME.trait * (passe ? 3.4 : 2.4) : sc.NORME.trait * (passe ? 1.25 : 0.7);   // fantôme : trait large et pâle = présence floue
            for (let br = 0; br < 2; br++) {
              const P = br ? q.PB : q.PA, sg = br ? -1 : 1;
              ctx.beginPath(); let ouvert = false;
              for (let j = 0; j <= N; j++) {
                const devant = sg * q.D[j] >= 0;
                if (devant === (passe === 1)) { if (ouvert) ctx.lineTo(P[j * 2], P[j * 2 + 1]); else { ctx.moveTo(P[j * 2], P[j * 2 + 1]); ouvert = true; } }
                else if (ouvert) { ctx.lineTo(P[j * 2], P[j * 2 + 1]); ouvert = false; }
              }
              ctx.stroke();
            }
          }
          // lueur des brins de devant (sprites doux, un sur deux)
          ctx.globalCompositeOperation = 'lighter';
          const sd = sc.sp.doux[s0][q.ab];
          for (let j = 1; j < N; j += 2) {
            const g = aMax * att * 0.22 * (q.fant ? 0.6 : 1) * Math.min(1, j / 6, (N - j) / 6);
            if (q.D[j] > 0.2) sc.point(ctx, sd, q.PA[j * 2], q.PA[j * 2 + 1], q.fant ? 30 : 12, g * q.D[j]); else if (q.D[j] < -0.2) sc.point(ctx, sd, q.PB[j * 2], q.PB[j * 2 + 1], q.fant ? 30 : 12, -g * q.D[j]);
          }
          ctx.globalCompositeOperation = 'source-over';
          // bases : plus de barreaux tracés — deux points par palier (la paire de bases), qui s'allument l'un après l'autre
          // au passage d'une onde de lecture ; hélice ouverte : chaque base reste collée à son brin (fermeture éclair).
          if (!q.fant) {
            const lum = 0.35 + 0.65 * sc.energie + q.eclat * 0.5, sb = sc.sp.fin[s0][1 - q.ab], lect = (t * 0.22 + q.ph * 0.16) % 1.3 - 0.15;
            ctx.globalCompositeOperation = 'lighter';
            for (let j = 2; j < N - 1; j += 2) {
              const ax = q.PA[j * 2], ay = q.PA[j * 2 + 1], cx = q.PB[j * 2], cy = q.PB[j * 2 + 1], op = q.ouv[j];
              const kk = op < 0.25 ? 0.34 : 0.14, du = j / N - lect, feu = du > -0.02 && du < 0.14 ? 1 - du / 0.14 : 0;
              const al = Math.min(0.95, aMax * att * (0.34 * lum + 0.6 * feu)) * Math.min(1, j / 5, (N - j) / 5), ta = 4.6 + 3.4 * feu;
              sc.point(ctx, sb, ax + (cx - ax) * kk, ay + (cy - ay) * kk, ta, al); sc.point(ctx, sb, cx + (ax - cx) * kk, cy + (ay - cy) * kk, ta, al * (0.75 + 0.25 * q.D[j]));
            }
            ctx.globalCompositeOperation = 'source-over';
          }
          // bases allumées (énergie) et lueurs aux brins ouverts
          if (!q.fant) {
            ctx.globalCompositeOperation = 'lighter';
            const spr = sc.sp.fin[s0][1 - q.ab];
            for (let j = 3; j < N - 2; j += 3) {
              const g = Math.max(sc.energie - 0.35, 0) * 1.4 + q.ouv[j] * 0.9;
              if (g > 0.05) { sc.point(ctx, spr, q.PA[j * 2], q.PA[j * 2 + 1], 7 + 6 * g, aMax * att * g * 0.7); sc.point(ctx, spr, q.PB[j * 2], q.PB[j * 2 + 1], 7 + 6 * g, aMax * att * g * 0.7); }
            }
            // impulsion de réplication (rebond) : or
            if (q.puls >= 0) {
              const c = Math.min(N, Math.max(0, Math.round(q.puls * N)));
              ctx.strokeStyle = orRgb; ctx.lineWidth = sc.NORME.trait * 1.4;
              ctx.globalAlpha = 0.85 * (1 - Math.max(0, q.puls - 0.9) * 4) * att; ctx.beginPath();
              for (let j = Math.max(1, c - 6); j <= c; j++) { ctx.moveTo(q.PA[(j - 1) * 2], q.PA[(j - 1) * 2 + 1]); ctx.lineTo(q.PA[j * 2], q.PA[j * 2 + 1]); ctx.moveTo(q.PB[(j - 1) * 2], q.PB[(j - 1) * 2 + 1]); ctx.lineTo(q.PB[j * 2], q.PB[j * 2 + 1]); }
              ctx.stroke();
              sc.point(ctx, or, q.PA[c * 2], q.PA[c * 2 + 1], 18, 0.9 * att); sc.point(ctx, or, q.PB[c * 2], q.PB[c * 2 + 1], 18, 0.9 * att);
            }
            ctx.globalCompositeOperation = 'source-over';
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // chapelets, mode « ions » (monde 6) : chapelets d'ions piégés (piège de Paul linéaire), plus serrés au centre.
  // Tout bat sur une même mesure : mode du centre de masse + mode de respiration. Bille proche : répulsion de
  // Coulomb, la chaîne passe en zigzag ; rebond : un laser d'or balaie la chaîne la plus proche, les ions
  // s'allument l'un après l'autre (phonon) ; flux : la chaîne ondule ; énergie : zigzag et fluorescence.
  function chapeletsIons(sc, p) {
    const A = sc.alea, NC = Math.max(1, Math.round(p.max || 4)), IO = p.ions || [5, 11], LG = p.longueur || [90, 150], per = p.periode || 2.4;
    const or = spriteJeton(sc, 'or', true), orRgb = rgbJeton(sc, 'or'), aMax = Math.min(p.alpha || 0.7, sc.NORME.opaciteMax.reactifs);
    const C = [];
    for (let c = 0; c < NC; c++) {
      const L = melange(LG[0], LG[1], A()), [x, y] = placeCalme(sc, A, 0.12, 30, L * 0.45), m = Math.round(melange(IO[0], IO[1], A())), ang = (A() - 0.5) * 0.5 + (A() < 0.2 ? Math.PI / 2 : 0);
      const U = new Float32Array(m), Z = new Float32Array(m), VZ = new Float32Array(m), FL = new Float32Array(m);
      for (let i = 0; i < m; i++) { const u = m > 1 ? (i - (m - 1) / 2) / ((m - 1) / 2) : 0; U[i] = L / 2 * Math.sign(u) * Math.pow(Math.abs(u), 0.8); }
      C.push({ x, y, L, m, ux: Math.cos(ang), uy: Math.sin(ang), U, Z, VZ, FL, zig: 0, laser: -1, ondule: 0, ph: A() * 0.3, ab: c & 1 });
    }
    let n = 0;
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NC * Math.min(1, k * 1.25))) : 0; }, effectif: () => { let s = 0; for (let c = 0; c < n; c++) s += C[c].m * 2; return s; },
      evenement(type, e) {
        if (type !== 'rebond' || !n) return;
        let best = C[0], bd = 1e9; for (let c = 0; c < n; c++) { const d = Math.hypot(C[c].x - e.x, C[c].y - e.y); if (d < bd) { bd = d; best = C[c]; } }
        best.laser = 0;
      },
      update(dt) {
        const b = sc.bille;
        for (let c = 0; c < n; c++) {
          const q = C[c], nx = -q.uy, ny = q.ux, f = sc.flux(q.x, q.y);
          q.ondule += (borne((nx * f[0] + ny * f[1]) * 0.12, -10, 10) - q.ondule) * Math.min(1, dt * 1.5);
          let zc = sc.energie > 0.55 ? (sc.energie - 0.55) * 2.2 : 0;
          if (q.laser >= 0) { q.laser += dt * 0.9; if (q.laser > 1.6) q.laser = -1; }
          for (let i = 0; i < q.m; i++) {
            const px = q.x + q.ux * q.U[i], py = q.y + q.uy * q.U[i];
            let fz = -q.Z[i] * 30 - q.VZ[i] * 3;
            if (b) { const ex = px - b.x, ey = py - b.y, d = Math.hypot(ex, ey) || 1; if (d < 80) { const g = 1 - d / 80; fz += (ex * nx + ey * ny) / d * 900 * g; zc = Math.max(zc, g); } }
            q.VZ[i] += fz * dt; q.Z[i] += q.VZ[i] * dt;
            if (q.laser >= 0) { const s = q.laser * 1.4 - i / Math.max(1, q.m - 1) * 0.8; if (s > 0 && s < 0.25) q.FL[i] = 1; }
            q.FL[i] *= 1 - Math.min(1, dt * 1.8);
          }
          q.zig += (Math.min(1, zc) - q.zig) * Math.min(1, dt * 2.5);
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        const w = TAU / per;
        ctx.lineCap = 'round';
        for (let c = 0; c < n; c++) {
          const q = C[c], s = sc.seau(q.y), att = 0.45 + 0.55 * sc.calme(q.x, q.y), nx = -q.uy, ny = q.ux;
          const com = Math.sin(w * t + q.ph) * q.L * 0.035 * (1 + Math.min(2, Math.abs(q.ondule) / 4)), resp = 1 + 0.06 * Math.sin(w * 1.732 * t + q.ph);
          // axe du piège et deux électrodes (traits fins)
          ctx.strokeStyle = sc.sp.rgb[s][q.ab]; ctx.lineWidth = sc.NORME.trait * 0.7; ctx.globalAlpha = aMax * att * (0.16 + 0.2 * sc.energie);
          const e = 9, hl = q.L * 0.62;
          ctx.beginPath();
          for (const o of [-e, 0, e]) { ctx.moveTo(q.x - q.ux * hl + nx * o, q.y - q.uy * hl + ny * o); ctx.lineTo(q.x + q.ux * hl + nx * o, q.y + q.uy * hl + ny * o); }
          ctx.stroke();
          // ions : anneau fin + cœur net
          ctx.globalAlpha = aMax * att * 0.7; ctx.lineWidth = sc.NORME.trait * 0.8;
          ctx.beginPath();
          for (let i = 0; i < q.m; i++) {
            const u = q.U[i] * resp + com, z = q.Z[i] + (i & 1 ? 1 : -1) * 5.5 * q.zig + q.ondule * Math.sin(Math.PI * (i + 0.5) / q.m);
            const px = q.x + q.ux * u + nx * z, py = q.y + q.uy * u + ny * z;
            ctx.moveTo(px + 3.2, py); ctx.arc(px, py, 3.2, 0, TAU);
          }
          ctx.stroke();
          ctx.globalCompositeOperation = 'lighter';
          const sp = sc.sp.fin[s][1 - q.ab];
          for (let i = 0; i < q.m; i++) {
            const u = q.U[i] * resp + com, z = q.Z[i] + (i & 1 ? 1 : -1) * 5.5 * q.zig + q.ondule * Math.sin(Math.PI * (i + 0.5) / q.m);
            const px = q.x + q.ux * u + nx * z, py = q.y + q.uy * u + ny * z;
            sc.point(ctx, sp, px, py, 7 + 7 * sc.energie, aMax * att * (0.55 + 0.45 * sc.energie));
            if (q.FL[i] > 0.04) sc.point(ctx, or, px, py, 20, 0.9 * q.FL[i] * att);
          }
          ctx.globalCompositeOperation = 'source-over';
          if (q.laser >= 0 && q.laser < 1.2) {            // faisceau laser d'or le long de l'axe
            const a = Math.sin(Math.PI * Math.min(1, q.laser / 1.2));
            ctx.strokeStyle = orRgb; ctx.globalAlpha = 0.55 * a * att; ctx.lineWidth = sc.NORME.trait;
            ctx.beginPath(); ctx.moveTo(q.x - q.ux * q.L * 0.9, q.y - q.uy * q.L * 0.9); ctx.lineTo(q.x + q.ux * q.L * 0.9, q.y + q.uy * q.L * 0.9); ctx.stroke();
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  }
  FABRIQUES.chapelets.ions = chapeletsIons;
  // cadran (monde 6) : cadrans gradués dont l'aiguille avance par à-coups (échappement) et un balancier qui bat.
  // Bille proche : l'aiguille se tourne vers elle, les graduations proches s'allument ; rebond : toutes les aiguilles
  // sautent, la graduation touchée flashe en or ; flux : le balancier bat plus large ; énergie : la mesure s'accélère.
  FABRIQUES.cadran = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, ND = Math.max(1, Math.round(p.max || 3)), RR = p.rayon || [26, 44], bat = p.battement || 1;
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.45, sc.NORME.opaciteMax.structures * 1.5), D = [];
    for (let i = 0; i < ND; i++) {
      const r = melange(RR[0], RR[1], A()), [x, y] = placeCalme(sc, A, 0.1, 30, r * 1.25), ouv = A() < 0.5 ? TAU : 4.6, a0 = A() * TAU;
      D.push({ x, y, r, ouv, a0, pas: 0, frac: 1, aig: A() * TAU, vers: 0, bal: 0, flash: 0, gx: 0, gy: 0, ab: i & 1, sens: A() < 0.5 ? 1 : -1, amp: 0.5 });
    }
    let n = 0, mesure = 0;
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(ND * Math.min(1, k * 1.25))) : 0; }, effectif: () => n * 66,
      evenement(type, e) {
        if (type !== 'rebond' || !n) return;
        for (let i = 0; i < n; i++) { const q = D[i]; q.pas += 5; q.frac = 0; q.flash = 1; const a = q.aig + q.pas * TAU / 60; q.gx = q.x + Math.cos(a) * q.r; q.gy = q.y + Math.sin(a) * q.r; }
      },
      update(dt) {
        const b = sc.bille, v = (1 + 1.5 * sc.energie) / bat;
        mesure += dt * v;
        const coup = mesure >= 1; if (coup) mesure -= 1;
        for (let i = 0; i < n; i++) {
          const q = D[i];
          if (coup) { q.pas += 1; q.frac = 0; }
          q.frac = Math.min(1, q.frac + dt * 7);
          let cible = 0;
          if (b) { const d = Math.hypot(b.x - q.x, b.y - q.y); if (d < q.r * 3.5) { const ab = Math.atan2(b.y - q.y, b.x - q.x), cur = q.aig + q.pas * TAU / 60; cible = Math.atan2(Math.sin(ab - cur), Math.cos(ab - cur)) * (1 - d / (q.r * 3.5)); } }
          q.vers += (cible - q.vers) * Math.min(1, dt * 3);
          const f = sc.flux(q.x, q.y); q.amp += (0.5 + Math.min(1, Math.hypot(f[0], f[1]) / 60) - q.amp) * Math.min(1, dt);
          q.flash *= 1 - Math.min(1, dt * 1.5);
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        ctx.lineCap = 'round';
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = D[i], s = sc.seau(q.y), att = (0.4 + 0.6 * sc.calme(q.x, q.y)) * sc.loinDuBut(q.x, q.y, q.r);
          if (att < 0.03) continue;
          const lum = 0.6 + 0.4 * sc.energie;
          // graduations (60, une sur cinq plus longue) + arc
          ctx.strokeStyle = sc.sp.rgb[s][q.ab]; ctx.lineWidth = sc.NORME.trait * 0.7; ctx.globalAlpha = aMax * att * 0.75 * lum;
          ctx.beginPath(); ctx.arc(q.x, q.y, q.r, q.a0, q.a0 + q.ouv);
          for (let g = 0; g <= 60; g++) {
            const a = q.a0 + q.ouv * g / 60, r0 = q.r * (g % 5 ? 0.92 : 0.82);
            if (q.ouv < TAU || g < 60) { ctx.moveTo(q.x + Math.cos(a) * r0, q.y + Math.sin(a) * r0); ctx.lineTo(q.x + Math.cos(a) * q.r, q.y + Math.sin(a) * q.r); }
          }
          ctx.stroke();
          // graduations éveillées par la bille
          if (b) {
            const ab = Math.atan2(b.y - q.y, b.x - q.x), d = Math.hypot(b.x - q.x, b.y - q.y);
            if (d < q.r * 3) { ctx.strokeStyle = sc.sp.rgb[s][1 - q.ab]; ctx.globalAlpha = aMax * att * 1.4 * (1 - d / (q.r * 3)); ctx.lineWidth = sc.NORME.trait * 1.2; ctx.beginPath(); ctx.arc(q.x, q.y, q.r * 1.06, ab - 0.35, ab + 0.35); ctx.stroke(); }
          }
          // aiguille (échappement : saut amorti avec léger dépassement) et petite aiguille
          const e = q.frac < 1 ? 1 - Math.cos(q.frac * Math.PI * 2.5) * Math.exp(-q.frac * 4) : 1;
          const aa = q.aig + (q.pas - 1 + e) * TAU / 60 * q.sens + q.vers, ap = q.aig * 0.3 + q.pas * TAU / 720 * q.sens;
          ctx.strokeStyle = sc.sp.rgb[s][1 - q.ab]; ctx.globalAlpha = Math.min(0.9, aMax * att * 1.6); ctx.lineWidth = sc.NORME.trait * 1.1;
          ctx.beginPath(); ctx.moveTo(q.x - Math.cos(aa) * q.r * 0.18, q.y - Math.sin(aa) * q.r * 0.18); ctx.lineTo(q.x + Math.cos(aa) * q.r * 0.86, q.y + Math.sin(aa) * q.r * 0.86);
          ctx.moveTo(q.x, q.y); ctx.lineTo(q.x + Math.cos(ap) * q.r * 0.5, q.y + Math.sin(ap) * q.r * 0.5); ctx.stroke();
          // balancier (anneau à quatre rayons qui bat)
          const bx = q.x + q.r * 0.42 * Math.cos(q.a0 + q.ouv / 2 + Math.PI), by = q.y + q.r * 0.42 * Math.sin(q.a0 + q.ouv / 2 + Math.PI), br = q.r * 0.2, rot = Math.sin(t * TAU / (2 * bat) * (1 + 1.5 * sc.energie)) * q.amp * 2.2;
          ctx.globalAlpha = aMax * att * 0.7; ctx.lineWidth = sc.NORME.trait * 0.7; ctx.strokeStyle = sc.sp.rgb[s][q.ab];
          ctx.beginPath(); ctx.moveTo(bx + br, by); ctx.arc(bx, by, br, 0, TAU);
          for (let r = 0; r < 4; r++) { const a = rot + r * Math.PI / 2; ctx.moveTo(bx, by); ctx.lineTo(bx + Math.cos(a) * br, by + Math.sin(a) * br); }
          ctx.stroke();
          if (q.flash > 0.04) {
            ctx.globalCompositeOperation = 'lighter';
            sc.point(ctx, or, q.gx, q.gy, 22, 0.9 * q.flash * att);
            ctx.strokeStyle = rgbJeton(sc, 'or'); ctx.globalAlpha = 0.6 * q.flash * att; ctx.lineWidth = sc.NORME.trait; ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (1.02 + 0.25 * (1 - q.flash)), 0, TAU); ctx.stroke();
            ctx.globalCompositeOperation = 'source-over';
          }
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // impacts (monde 11) : fentes de Young, électron par électron (Tonomura 1989). Des impacts isolés tombent sur des
  // écrans et s'ACCUMULENT (toile hors champ, rien n'est retracé) : d'abord au hasard, puis ils dessinent des franges.
  // Bille devant un détecteur (sc.geo.detecteurs) : les franges s'effacent et les impacts forment deux bandes
  // simples ; rebond : une gerbe d'impacts d'or ; flux : les franges glissent (phase) et la cadence monte ;
  // énergie : cadence et éclat plus forts.
  FABRIQUES.impacts = { famille: 'traces', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, EC = p.ecrans || [[0.5, 0.12, 0.8], [0.5, 0.9, 0.8]], nf = p.franges || 7, NF = 44, K = 2, EP = 30;
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.7, sc.NORME.opaciteMax.traces), E = [];
    for (const e of EC) {
      const L = sc.l * e[2], c = toile(L * K, EP * K), g = c.getContext('2d');
      E.push({ x: sc.l * e[0], y: sc.h * e[1], L, c, g, acc: 0, n: 0, phase: 0, src: sc.h * (e[3] || 0) });   // e[3] : hauteur des fentes par rapport à l'écran (fraction de h, négatif = au-dessus)
    }
    const R = []; for (let i = 0; i < NF; i++) R.push({ e: 0, u: 0, v: 0, vie: 0, or: false, ph: i * 2.4 });
    const blanc = spriteJeton(sc, 'blanc', true), colTrajet = rgbJeton(sc, 'lilas');
    const cols = [sc.sp.rgb[0][0], sc.sp.rgb[0][1], sc.sp.rgb[NB_SEAUX - 1][0]];
    let k = 0, ir = 0, mesure = 0, efface = 0;
    function tirer(q) {                              // u ∈ [-1, 1] selon la loi du moment : franges, ou deux bandes si l'on mesure
      for (let essai = 0; essai < 12; essai++) {
        const u = A() * 2 - 1;
        const fr = Math.pow(Math.cos(Math.PI * nf * u / 2 + q.phase), 2) * Math.exp(-(u / 0.8) * (u / 0.8));
        const bd = Math.exp(-Math.pow((Math.abs(u) - 0.32) / 0.16, 2));
        if (A() < melange(fr, bd, mesure)) return u;
      }
      return A() * 2 - 1;
    }
    function frapper(i, estOr) {
      const q = E[i], u = tirer(q), v = (A() + A() + A() - 1.5) / 1.5;
      q.g.globalAlpha = 0.55 + 0.45 * A(); q.g.fillStyle = cols[(A() * 3) | 0];
      q.g.fillRect((u * 0.5 + 0.5) * q.L * K - K * 0.8, (v * 0.5 + 0.5) * EP * K - K * 1.05, K * 2.1, K * 2.1);
      q.n++;
      const f = R[ir]; ir = (ir + 1) % NF; f.e = i; f.u = u; f.v = v; f.vie = 1; f.or = estOr;
    }
    return {
      regler(kk) { k = kk; }, effectif: () => (k > 0 ? Math.round(E.reduce((s, q) => s + Math.min(q.n, 2000), 0)) : 0),
      evenement(type, e) { if (type === 'rebond' && k > 0) for (let j = 0; j < 10; j++) frapper((A() * E.length) | 0, true); },
      update(dt) {
        if (k <= 0) return;
        const b = sc.bille; let det = 0;
        if (b) for (const d of sc.geo.detecteurs) { const dd = Math.hypot(b.x - d.x, b.y - d.y); if (dd < (d.r || 30) * 2.2) det = 1; }
        mesure += (det - mesure) * Math.min(1, dt * (det ? 3 : 0.5));
        efface += dt;
        for (let i = 0; i < E.length; i++) {
          const q = E[i], f = sc.flux(q.x, q.y);
          q.phase += f[0] * 0.0009 * dt * 60;
          q.acc += dt * (p.max || 18) * k * (1 + 1.5 * sc.energie) * (1 + Math.min(1.5, Math.hypot(f[0], f[1]) / 60)) / E.length;
          while (q.acc >= 1) { q.acc -= 1; frapper(i, false); }
        }
        if (efface > 0.25) {                         // mémoire de l'écran : lente ; devant un détecteur, les franges s'effacent vite
          const a = Math.min(0.5, (0.012 + 0.22 * mesure) * efface * 4); efface = 0;
          for (const q of E) { q.g.globalCompositeOperation = 'destination-out'; q.g.globalAlpha = a; q.g.fillStyle = '#000'; q.g.fillRect(0, 0, q.c.width, q.c.height); q.g.globalCompositeOperation = 'source-over'; q.n *= 1 - a; }
        }
        for (const f of R) if (f.vie > 0) f.vie -= dt * (f.or ? 2.2 : 0.75);   // phosphore : éclat bref puis rémanence ~1,3 s (l'or du rebond reste bref)
      },
      dessiner(ctx, t) {
        if (k <= 0) return;
        ctx.lineCap = 'round';
        for (const q of E) {
          const att = 0.55 + 0.45 * sc.calme(q.x, q.y), x0 = q.x - q.L / 2, y0 = q.y - EP / 2;
          ctx.globalAlpha = aMax * att * (0.75 + 0.25 * sc.energie);
          ctx.drawImage(q.c, x0, y0, q.L, EP);
          ctx.strokeStyle = sc.sp.rgb[sc.seau(q.y)][1]; ctx.lineWidth = sc.NORME.trait * 0.6; ctx.globalAlpha = aMax * att * 0.22;
          ctx.beginPath(); ctx.moveTo(x0, q.y + EP / 2 + 3); ctx.lineTo(x0 + q.L, q.y + EP / 2 + 3); ctx.stroke();
        }
        ctx.globalCompositeOperation = 'lighter';
        ctx.strokeStyle = colTrajet; ctx.lineWidth = 0.6; ctx.globalAlpha = 0.055 * aMax; ctx.beginPath();
        for (const f of R) {                          // trajets fantômes : l'électron est passé par LES DEUX fentes (deux fils très pâles, juste après l'impact)
          if (f.vie <= 0.72 || f.or) continue;
          const q = E[f.e]; if (!q.src) continue;
          const x = q.x + f.u * q.L / 2, y = q.y + f.v * EP / 2, ys = q.y + q.src, e2 = q.L * 0.045;
          ctx.moveTo(q.x - e2, ys); ctx.lineTo(x, y); ctx.moveTo(q.x + e2, ys); ctx.lineTo(x, y);
        }
        ctx.stroke();
        for (const f of R) {                          // scintillation du phosphore : éclat blanc bref, puis rémanence qui tremble et s'éteint
          if (f.vie <= 0) continue;
          const q = E[f.e], x = q.x + f.u * q.L / 2, y = q.y + f.v * EP / 2;
          if (f.or) { sc.point(ctx, or, x, y, 16, 0.95 * f.vie); continue; }
          if (f.vie > 0.88) sc.point(ctx, blanc, x, y, 15, Math.min(1, (f.vie - 0.88) * 8) * 0.9);
          sc.point(ctx, sc.sp.fin[sc.seau(y)][1], x, y, 9, aMax * f.vie * f.vie * (0.7 + 0.3 * Math.sin(t * 23 + f.ph)));
        }
        ctx.globalCompositeOperation = 'source-over';
        for (const d of sc.geo.detecteurs) {          // détecteurs : anneau fin + arc qui balaie ; allumés quand on mesure
          const s = sc.seau(d.y), r = (d.r || 30) * 0.45;
          ctx.strokeStyle = sc.sp.rgb[s][mesure > 0.3 ? 1 : 0]; ctx.lineWidth = sc.NORME.trait * 0.8; ctx.globalAlpha = aMax * (0.35 + 0.6 * mesure) * sc.loinDuBut(d.x, d.y, r);
          ctx.beginPath(); ctx.arc(d.x, d.y, r, 0, TAU); ctx.moveTo(d.x + r * 1.5 * Math.cos(t * 2), d.y + r * 1.5 * Math.sin(t * 2)); ctx.arc(d.x, d.y, r * 1.5, t * 2, t * 2 + 1.2 + 2 * mesure); ctx.stroke();
          ctx.globalCompositeOperation = 'lighter'; sc.point(ctx, sc.sp.fin[s][1], d.x, d.y, 8 + 10 * mesure, aMax * (0.4 + 0.6 * mesure)); ctx.globalCompositeOperation = 'source-over';
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  // paires (monde 11) : paires intriquées — deux disques de points partagés en deux moitiés complémentaires (une courbe
  // en S), qui tournent ensemble. Bille proche de l'un : MESURE, les deux se retournent au même instant ; rebond :
  // éclat d'or des deux et du lien ; flux : rotation plus vive ; énergie : le lien s'allume.
  FABRIQUES.paires = { famille: 'reactifs', plan: 'arriere', creer(sc, p) {
    const A = sc.alea, NPR = Math.max(1, Math.round(p.max || 2)), NPT = 64, RR = p.rayon || [14, 20], GA = 2.39996323;
    const or = spriteJeton(sc, 'or', true), aMax = Math.min(p.alpha || 0.6, sc.NORME.opaciteMax.reactifs), Q = [];
    const U = new Float32Array(NPT), V = new Float32Array(NPT);
    for (let i = 0; i < NPT; i++) { const r = Math.sqrt((i + 0.5) / NPT), a = i * GA; U[i] = r * Math.cos(a); V[i] = r * Math.sin(a); }
    for (let i = 0; i < NPR; i++) {
      const r = melange(RR[0], RR[1], A()), a = placeCalme(sc, A, 0.12, 30, r * 2.2), b = placeCalme(sc, A, 0.12, 30, r * 2.2);
      Q.push({ a, b, r, th: A() * TAU, flip: 0, cible: 0, flash: 0, lien: 0, attente: 0 });
    }
    let n = 0;
    return {
      regler(k) { n = k > 0 ? Math.max(1, Math.round(NPR * Math.min(1, k * 1.25))) : 0; }, effectif: () => n * NPT * 2,
      evenement(type, e) { if (type === 'rebond') for (let i = 0; i < n; i++) { Q[i].flash = 1; Q[i].lien = 1; } },
      update(dt) {
        const b = sc.bille;
        for (let i = 0; i < n; i++) {
          const q = Q[i], f = sc.flux(q.a[0], q.a[1]);
          q.th += dt * (0.5 + Math.min(2, Math.hypot(f[0], f[1]) / 40));
          q.attente -= dt;
          if (b && q.attente <= 0) for (const c of [q.a, q.b]) if (Math.hypot(b.x - c[0], b.y - c[1]) < q.r * 2.4) { q.cible += Math.PI; q.lien = 1; q.attente = 1.2; break; }
          q.flip += (q.cible - q.flip) * Math.min(1, dt * 6);
          q.flash *= 1 - Math.min(1, dt * 1.4); q.lien *= 1 - Math.min(1, dt * 1.2);
        }
      },
      dessiner(ctx, t) {
        if (!n) return;
        for (let i = 0; i < n; i++) {
          const q = Q[i], th = q.th + q.flip, co = Math.cos(th), si = Math.sin(th);
          const lien = Math.max(q.lien, sc.energie * 0.6, 0.12);   // le fil reste visible à ~12 % : on voit que les deux sont liés
          if (lien > 0.03) {                           // le lien : pointillé entre les deux figures
            const s = sc.seau((q.a[1] + q.b[1]) / 2), dx = q.b[0] - q.a[0], dy = q.b[1] - q.a[1], L = Math.hypot(dx, dy) || 1, nb = Math.min(40, Math.floor(L / 9));
            ctx.globalCompositeOperation = 'lighter';
            for (let j = 1; j < nb; j++) { const u = j / nb; sc.point(ctx, q.flash > 0.05 ? or : sc.sp.fin[s][1], q.a[0] + dx * u, q.a[1] + dy * u, 5, aMax * 0.6 * lien * (0.5 + 0.5 * Math.sin(u * 20 - t * 6)) * sc.calme(q.a[0] + dx * u, q.a[1] + dy * u)); }
            ctx.globalCompositeOperation = 'source-over';
          }
          ctx.globalCompositeOperation = 'lighter';
          for (let m = 0; m < 2; m++) {
            const c = m ? q.b : q.a, s = sc.seau(c[1]), att = (0.45 + 0.55 * sc.calme(c[0], c[1])) * sc.loinDuBut(c[0], c[1], q.r), sA = sc.sp.fin[s][0], sB = sc.sp.fin[s][1];
            if (att < 0.03) continue;
            for (let j = 0; j < NPT; j++) {
              const x = U[j] * co - V[j] * si, y = U[j] * si + V[j] * co, moitie = (y + 0.55 * Math.sin(Math.PI * x)) > 0;   // courbe en S
              sc.point(ctx, (moitie !== (m === 1)) ? sA : sB, c[0] + x * q.r, c[1] + y * q.r, 5.5, aMax * att);
            }
            if (q.flash > 0.05) sc.point(ctx, or, c[0], c[1], q.r * 2.2, 0.6 * q.flash * att);
          }
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.globalAlpha = 1;
      }
    };
  } };
  /*__P2_FIN__*/
  racine.QXPOOL = {
    version: 4, NORME,
    configurer(mondes) { MONDES = mondes; },
    definir(nom, f) { FABRIQUES[nom] = f; },
    get elements() { return Object.keys(FABRIQUES).map(n => ({ nom: n, famille: FABRIQUES[n].famille, plan: FABRIQUES[n].plan })); },
    creer
  };
})(typeof window !== 'undefined' ? window : globalThis);
