/* ============================================================
   haptics.js — vibrations de Quantix (global QHAP), R229 — PROPOSITION, pas encore branché dans le jeu
   Un seul vocabulaire de motifs, trois moteurs selon l'appareil :
   1. application native (Capacitor Haptics, si un jour le jeu est empaqueté) : vraies intensités léger / moyen / lourd ;
   2. Android (navigator.vibrate) : durées et silences ;
   3. iPhone (Safari / WebKit, iOS 18+) : aucune API de vibration ; on fait basculer un interrupteur caché
      (<input type=checkbox switch>), qui produit le petit « tic » système. Une seule intensité : le relief vient
      du rythme (nombre de tics, espacement).
   Motif = suite de pulsations [délai depuis la précédente en ms, force 1 léger · 2 moyen · 3 lourd].
   ============================================================ */
var QHAP=(function(){
 var on=false,last={},iosEl=null,timers=[];
 var POOL={
  frole:   [[0,1]],                                   /* frôlement, contact rasant */
  tic:     [[0,1]],                                   /* petit rebond */
  rebond:  [[0,2]],                                   /* rebond franc */
  lourd:   [[0,3],[85,1]],                            /* impact lourd : choc sourd puis son écho */
  double:  [[0,3],[300,2],[190,1]],                   /* réception lourde puis deux rebonds qui s'éteignent */
  roule:   [[0,1],[60,1],[60,1],[60,1]],              /* roulement sur un rail, une marche */
  propulse:[[0,2],[110,1],[80,1],[55,1],[40,2]],      /* propulsion : s'emballe */
  portail: [[0,1],[34,1]],                            /* passage d'une faille, d'une couture */
  collision:[[0,3],[45,3]],                           /* deux corps qui se heurtent */
  crepite: [[0,1],[70,1],[40,1],[110,1],[35,1],[90,1]],/* électricité, trait qui se délite */
  annihile:[[0,2],[30,1],[30,1]],                     /* annihilation matière / antimatière */
  coeur:   [[0,2],[140,1],[700,2],[140,1]],           /* battement : charge, attente */
  aspire:  [[0,1],[160,1],[120,1],[90,1],[65,1],[45,1],[35,2],[30,3]],   /* aspiration du trou noir, de plus en plus serré */
  naissance:[[0,3],[220,1],[260,1]],                  /* l'atome naît */
  cliquet: [[0,1],[85,1],[85,2]],                      /* engrenage, marche qui s'enclenche */
  givre:   [[0,1],[26,1],[26,1]],                      /* grésil fin, la glace */
  houle:   [[0,1],[190,1],[170,2],[210,1]],            /* une vague, l'air qui monte */
  tension: [[0,1],[150,1],[120,1],[95,1],[75,1],[58,2],[45,2]],   /* charge qui monte avant le geste */
  envol:   [[0,2],[70,1]]                              /* arrachement, décollage */
 };
 /* durées Android par force */
 var DUR=[0,9,20,38];
 function now(){return (window.performance&&performance.now)?performance.now():Date.now();}
 function native(){var C=window.Capacitor;return C&&C.Plugins&&C.Plugins.Haptics?C.Plugins.Haptics:null;}
 function iosTick(){try{var lb=document.createElement('label'),ip=document.createElement('input');ip.type='checkbox';ip.setAttribute('switch','');   /* R231 : méthode éprouvée (élément neuf, caché, dans <head>, cliqué puis retiré) */
   lb.setAttribute('aria-hidden','true');lb.style.display='none';lb.appendChild(ip);document.head.appendChild(lb);lb.click();document.head.removeChild(lb);}catch(e){}}
 function pulse(f){var N=native();
  if(N){try{N.impact({style:f>=3?'HEAVY':f===2?'MEDIUM':'LIGHT'});}catch(e){}return;}
  if(navigator.vibrate){try{navigator.vibrate(DUR[f]||9);}catch(e){}return;}
  iosTick();if(f>=3)setTimeout(iosTick,28);}   /* iPhone : un lourd = deux tics serrés */
 function play(name,k){if(!on)return false;var P=POOL[name];if(!P)return false;var t=now();
  if(last[name]&&t-last[name]<90)return false;last[name]=t;   /* pas de mitraille */
  var N=native();
  if(!N&&navigator.vibrate){var seq=[],i;for(i=0;i<P.length;i++){if(i)seq.push(Math.max(0,P[i][0]-DUR[P[i-1][1]]));seq.push(Math.round(DUR[P[i][1]]*(k||1)));}try{navigator.vibrate(seq);}catch(e){}return true;}
  var acc=0;P.forEach(function(p){acc+=p[0];if(acc===0)pulse(p[1]);else timers.push(setTimeout(function(){pulse(p[1]);},acc));});
  if(timers.length>40)timers.splice(0,timers.length-40);return true;}
 /* traduction des évènements de la cinématique de fin (hero.js, ev5) */
 function ev(type,s){switch(type){
  case 'thud':return play('lourd');
  case 'hit':return play(s>=6?'rebond':s>=3.5?'rebond':'tic');
  case 'twang':return play('tic');
  case 'coll':return play('collision');
  case 'launch':case 'thrust':return play('propulse');
  case 'portal':case 'seam':case 'pass':case 'tunnel':return play('portail');
  case 'boost':return play('roule');
  case 'pulse':case 'vtx':return play('rebond');
  case 'absorb':return play('aspire');}
  return false;}
 function stop(){timers.forEach(clearTimeout);timers=[];try{if(navigator.vibrate)navigator.vibrate(0);}catch(e){}}
 function engine(){return native()?'natif':navigator.vibrate?'android':'iphone';}
 return {pool:POOL,play:play,ev:ev,stop:stop,engine:engine,set:function(v){on=!!v;if(!on)stop();},get on(){return on;}};
})();
window.QHAP=QHAP;
