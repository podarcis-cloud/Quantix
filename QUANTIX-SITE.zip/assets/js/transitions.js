/* R280 — transitions de niveau (validées dans le banc des rendus, R279)
   · absorb : à la réussite, la particule immobile est aspirée par l'arrivée (trou noir = l'anneau vert du jeu)
   · birth  : à l'ouverture d'un niveau, la particule est crachée par un trou discret, puis rattrapée (fronde) vers son départ
   Tout est dessiné dans le repère logique du jeu (360×480) par scene(c) ; aucun effet ne touche à la physique.
   API : QFX.absorbStart(zone) · QFX.birthStart(bx,by) · QFX.draw(c) → true si la particule est dessinée ici · QFX.skip() · QFX.cancel() · QFX.busy() */
(function(){
'use strict';
var PI=Math.PI,GW=360,GH=480,RB=10.5,BG='#05070D';
function rgba(h,a){var n=parseInt(h.slice(1),16);return 'rgba('+(n>>16)+','+((n>>8)&255)+','+(n&255)+','+a+')';}
function cl(x){return x<0?0:x>1?1:x;}function sm(x){x=cl(x);return x*x*(3-2*x);}
function mix(a,b,t){var A=parseInt(a.slice(1),16),B=parseInt(b.slice(1),16),r=Math.round((A>>16)+((B>>16)-(A>>16))*t),g=Math.round(((A>>8)&255)+(((B>>8)&255)-((A>>8)&255))*t),bl=Math.round((A&255)+((B&255)-(A&255))*t);return '#'+((1<<24)|(r<<16)|(g<<8)|bl).toString(16).slice(1);}
var seed=7;function rnd(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646;}
var DC=['#43D5F5','#8FE3FF','#A878FF','#8C7BFF','#A8C8E8','#9BEB4B','#C8FF8D'];
var SPR=null,NEB=null,WHT=null,fx=null,fc=null;
function spr(col){var o=document.createElement('canvas');o.width=o.height=32;var x=o.getContext('2d'),g=x.createRadialGradient(16,16,0,16,16,16);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.18,rgba(col,.9));g.addColorStop(.5,rgba(col,.22));g.addColorStop(1,rgba(col,0));x.fillStyle=g;x.fillRect(0,0,32,32);return o;}
function mkTex(n,sd,cc,thr,gain){var o=document.createElement('canvas');o.width=o.height=n;var x=o.getContext('2d'),d=x.createImageData(n,n);
 function rn(i,j,s){var h=Math.sin(i*127.1+j*311.7+s*74.7)*43758.5453;return h-Math.floor(h);}
 function vn(px,py,per,s){var i=Math.floor(px),j=Math.floor(py),fx_=px-i,fy=py-j;fx_=fx_*fx_*(3-2*fx_);fy=fy*fy*(3-2*fy);
  function r(a,b){return rn(((a%per)+per)%per,((b%per)+per)%per,s);}
  return (r(i,j)*(1-fx_)+r(i+1,j)*fx_)*(1-fy)+(r(i,j+1)*(1-fx_)+r(i+1,j+1)*fx_)*fy;}
 for(var y=0;y<n;y++)for(var xx=0;xx<n;xx++){var v=0,a=.5,f=3,per=3;for(var k=0;k<5;k++){v+=a*vn(xx/n*f,y/n*f,per,sd+k);a*=.5;f*=2;per*=2;}
  v=Math.max(0,(v-thr)*gain);var p=(y*n+xx)*4;d.data[p]=cc[0];d.data[p+1]=cc[1];d.data[p+2]=cc[2];d.data[p+3]=Math.min(255,v*255);}
 x.putImageData(d,0,0);return o;}
function prep(){   /* textures calculées une seule fois, à la première utilisation */
 if(SPR)return;SPR={};DC.concat(['#F1F4F6']).forEach(function(c){SPR[c]=spr(c);});
 NEB=[mkTex(128,5,[140,123,255],.30,1.9),mkTex(128,17,[67,213,245],.34,1.9),mkTex(128,41,[168,120,255],.32,1.8)];WHT=mkTex(128,71,[255,255,255],.30,1.5);
 fx=document.createElement('canvas');fc=fx.getContext('2d');}
function reduced(){try{if(typeof RM!=='undefined'&&RM)return true;}catch(e){}try{if(typeof OPT!=='undefined'&&OPT.rm)return true;}catch(e){}return false;}
function soft(){try{return !!(typeof OPT!=='undefined'&&OPT.lowfx)||QFX.light;}catch(e){return QFX.light;}}

/* ============ SORTIE : aspiration (B2, sans travelling) ============ */
var AB=null,BIRTH=null,last=0;
function snd(n,v){try{if(window.Audio1&&Audio1.playSfx)Audio1.playSfx(n,v);}catch(e){}}   /* R284 : sons calés sur l'animation (ils avancent avec elle, jamais avant) */
var A_DUR=4.2,A_T0=.8;   /* l'animation démarre « déjà en cours » : la bille est déjà arrêtée dans la zone */
function succion(t){return sm((t-.9)/.8)*(1-sm((t-3.3)/.8));}
function absorbStart(zone,bx,by,ba){
 if(reduced())return false;prep();
 var gx=zone[0]+zone[2]/2,gy=zone[1]+zone[3]/2,pr=Math.min(21,zone[3]/2-2);
 var RH=Math.max(8,pr-6.5),rx=bx-gx,ry=by-gy,R0=Math.max(8,Math.hypot(rx,ry));
 AB={s:{},t:A_T0,gx:gx,gy:gy,RH:RH,pr:pr,RX:rx,RY:ry,R0:R0,TH0:Math.atan2(ry,rx),a0:ba||0,light:soft(),hist:[],SP:[],burst:false,D:null};
 seed=7;var n=AB.light?110:300,a=[],i;
 for(i=0;i<n;i++)a.push({r:20+Math.pow(rnd(),.7)*88,a:rnd()*2*PI,c:DC[i%DC.length],z:.6+Math.pow(rnd(),2)*2,w:.6+rnd()*.8,ph:rnd()*6.28});
 AB.D=a;for(i=0;i<40;i++)stepDust(AB,.05,0);
 return true;}
function stepDust(A,dt,su){var D=A.D,RH=A.RH;for(var i=0;i<D.length;i++){var p=D[i];p.a+=dt*(330/Math.pow(p.r,1.5))*(1+su*.9);p.r-=dt*(.7+19*su)*(.5+22/p.r)*(.4+p.w*.6);if(p.r<RH*.95){p.r=78+rnd()*30;p.a=rnd()*2*PI;}}}
function ballA(A,t){
 var R0=A.R0,TH0=A.TH0,RX=A.RX,RY=A.RY;
 if(t<1.7){var j=t>.9?Math.sin((t-.9)*85)*.55*sm((t-.9)/.3)*(1-sm((t-1.5)/.2)):0;return {x:RX+j,y:RY-j*.5,th:TH0,s:1,u:0,roll:A.a0};}
 var u=cl((t-1.7)/1.6),r=R0*(1-Math.pow(u,1.9))+.3,th=TH0+2.0*2*PI*Math.pow(u,1.7);
 return {x:r*Math.cos(th),y:r*Math.sin(th),r:r,th:th,s:Math.pow(Math.max(r/R0,0),.75),u:u,roll:A.a0+(th-TH0)*2};}
function drawAbsorb(c,dt){
 var A=AB,t=A.t,K=c.getTransform().a,Wp=c.canvas.width,Hp=c.canvas.height,light=A.light,RH=A.RH,i,pk=0;
 var su=succion(t),ring=Math.sin(t*2.6)*1.3;
 if(!A.s.pull){A.s.pull=1;snd('absorb_pull');}
 if(t>3.15&&!A.s.burst){A.s.burst=1;snd('absorb_burst');snd('level_success');try{Audio1.buzz([22,40,12]);}catch(e){}}
 stepDust(A,dt,su);
 c.save();c.globalCompositeOperation='source-over';
 c.fillStyle=rgba(BG,.5*su);c.fillRect(0,0,GW,GH);   /* le niveau s'assombrit pour concentrer le regard */
 /* calque d'effets masqué en rond (toile, voiles, grains) */
 if(fx.width!==Wp||fx.height!==Hp){fx.width=Wp;fx.height=Hp;}
 fc.setTransform(1,0,0,1,0,0);fc.globalCompositeOperation='source-over';fc.clearRect(0,0,Wp,Hp);fc.setTransform(K,0,0,K,A.gx*K,A.gy*K);
 var m=1+3.2*su,Rv=104,dp=function(x,y){var d=Math.hypot(x,y)||1,k=Math.min(.6,m/(d*d+1500)*14);return [x-x*k,y-y*k];};
 if(false){fc.lineWidth=.9;   /* R281 : grille de fond retirée (demande de Simon) ; le champ de poussière reste déformé */
  for(var pass=0;pass<2;pass++)for(i=-Rv;i<=Rv;i+=14){fc.beginPath();var f=true;for(var j=-Rv;j<=Rv;j+=4){var px=pass?j:i,py=pass?i:j;if(Math.hypot(px,py)>Rv){f=true;continue;}var q=dp(px,py);f?(fc.moveTo(q[0],q[1]),f=false):fc.lineTo(q[0],q[1]);}
   fc.strokeStyle=rgba('#8C7BFF',.3+.35*su);fc.stroke();}}
 fc.globalCompositeOperation='lighter';
 var nb=light?2:5;
 for(i=0;i<nb;i++){var Rn=RH*1.6+i*17*(light?1.5:1),w=Rn*2,ang=t*(330/Math.pow(Rn,1.5))*(1+su*.9)*.35+i*1.7;
  fc.save();fc.beginPath();fc.arc(0,0,Rn,0,2*PI);fc.arc(0,0,Math.max(0,Rn-30),0,2*PI,true);fc.clip();fc.rotate(ang);fc.globalAlpha=.55*(.55+.45*su)*(1-i*.1);fc.drawImage(NEB[i%3],-Rn,-Rn,w,w);fc.restore();}
 fc.globalAlpha=1;
 for(i=0;i<A.D.length;i++){var p=A.D[i],x=Math.cos(p.a)*p.r,y=Math.sin(p.a)*p.r;if(!light){var qq=dp(x,y);x=qq[0];y=qq[1];}
  var heat=cl(1-(p.r-RH)/42),tw=.65+.35*Math.sin(t*3+p.ph),col=heat>.6?'#F1F4F6':p.c,sz=p.z*(1+heat*.6)*3.4,al=(.35+.8*heat)*tw*(.55+.45*su),sp2=Math.min(5,1+su*6*heat);
  fc.save();fc.translate(x,y);fc.rotate(p.a+PI/2);fc.globalAlpha=Math.min(1,al);fc.drawImage(SPR[col],-sz*sp2/2,-sz/2,sz*sp2,sz);fc.restore();}
 fc.globalAlpha=1;fc.setTransform(1,0,0,1,0,0);fc.globalCompositeOperation='destination-in';
 var mk=fc.createRadialGradient(A.gx*K,A.gy*K,22*K,A.gx*K,A.gy*K,Rv*K);mk.addColorStop(0,'rgba(0,0,0,1)');mk.addColorStop(1,'rgba(0,0,0,0)');fc.fillStyle=mk;fc.fillRect(0,0,Wp,Hp);
 c.save();c.setTransform(1,0,0,1,0,0);c.drawImage(fx,0,0);c.restore();
 c.translate(A.gx,A.gy);c.globalCompositeOperation='lighter';
 /* anneau vert qui s'allume */
 var pr=A.pr+ring;c.strokeStyle=rgba('#9BEB4B',.5*su);c.lineWidth=8.5;c.beginPath();c.arc(0,0,pr,0,2*PI);c.stroke();
 c.strokeStyle=rgba('#C8FF8D',.45*su);c.lineWidth=2;c.beginPath();c.arc(0,0,pr+5.5,0,2*PI);c.stroke();
 /* traînée */
 var b=ballA(A,t),col=b.u<.5?mix('#43D5F5','#F1F4F6',b.u*2):mix('#F1F4F6','#A878FF',(b.u-.5)*2),hist=A.hist;
 if(t>=1.7&&t<3.4)hist.push({x:b.x,y:b.y,l:1,s:b.s});
 for(i=hist.length-1;i>=0;i--){hist[i].l-=dt*1.6;if(hist[i].l<=0)hist.splice(i,1);}
 for(i=1;i<hist.length;i++){var h0=hist[i-1],h1=hist[i];c.strokeStyle=rgba('#8FE3FF',h1.l*.5);c.lineWidth=Math.max(.4,6*h1.s*h1.l);c.beginPath();c.moveTo(h0.x,h0.y);c.lineTo(h1.x,h1.y);c.stroke();}
 /* horizon : disque noir + trois anneaux fins */
 c.globalCompositeOperation='source-over';c.fillStyle='rgba(2,3,7,.99)';c.beginPath();c.arc(0,0,RH,0,2*PI);c.fill();
 c.globalCompositeOperation='lighter';
 var fin=t>3.3?Math.sin(cl((t-3.3)/.9)*PI):0,gl=.5+.5*su+fin*.6,off=[['#9BEB4B',-1.1],['#F1F4F6',0],['#43D5F5',1.1]];
 for(i=0;i<3;i++){c.strokeStyle=rgba(off[i][0],(i===1?.95:.6)*Math.min(1,gl));c.lineWidth=i===1?1.2:2.1;c.beginPath();c.arc(off[i][1]*.5,0,(RH+.6+i*.2)*(1+fin*.04)+off[i][1],0,2*PI);c.stroke();}
 /* cœur blanc texturé */
 var pw=.12+.25*sm((t-.2)/.8)+.55*sm((t-1.2)/1.9)+1.1*Math.pow(cl((t-2.9)/.55),1.6)*(1-sm((t-3.5)/.55)),rg=RH+2.5+6.5*Math.min(1.6,pw),slow=t*.45;
 var gg=c.createRadialGradient(0,0,RH,0,0,rg*1.7);gg.addColorStop(0,'rgba(255,255,255,'+Math.min(.7,.3*pw)+')');gg.addColorStop(.3,rgba('#C8FF8D',Math.min(.42,.15*pw)));gg.addColorStop(1,'rgba(255,255,255,0)');
 c.fillStyle=gg;c.beginPath();c.arc(0,0,rg*1.7,0,2*PI);c.arc(0,0,RH,0,2*PI,true);c.fill('evenodd');
 for(i=0;i<2;i++){var RR=rg*(1+i*.3);c.save();c.beginPath();c.arc(0,0,RR,0,2*PI);c.arc(0,0,RH*.95,0,2*PI,true);c.clip();c.rotate(slow*(i?-1:1.3)+i);c.globalAlpha=Math.min(.55,(.30+.16*Math.sin(t*5+i*2))*pw*(i?.6:1));c.drawImage(WHT,-RR,-RR,RR*2,RR*2);c.restore();}
 c.globalAlpha=1;
 /* la particule réelle, au-dessus des effets */
 if(b.s>.14&&t<3.2){c.save();c.translate(b.x,b.y);
  c.globalCompositeOperation='lighter';var hg=c.createRadialGradient(0,0,0,0,0,RB*b.s*2.6);hg.addColorStop(0,'rgba(143,227,255,'+(.45*Math.min(1,su*1.6+.1))+')');hg.addColorStop(1,'rgba(143,227,255,0)');c.fillStyle=hg;c.beginPath();c.arc(0,0,RB*b.s*2.6,0,2*PI);c.fill();c.globalCompositeOperation='source-over';
  if(b.u>0){var an=Math.atan2(Math.cos(b.th),-Math.sin(b.th));c.rotate(an);c.scale(1+b.u*1.0,1-b.u*.25);}
  if(window.VX&&VX.ball)VX.ball(c,0,0,b.roll,RB*b.s,b.u>.15?col:undefined);
  else{c.fillStyle='#F1F4F6';c.beginPath();c.arc(0,0,RB*b.s,0,2*PI);c.fill();}
  c.restore();}
 /* explosion verte : rayons effilés, étincelles, ondes */
 c.globalCompositeOperation='lighter';
 if(t>3.15&&!A.burst){A.burst=true;var SP=A.SP=[];for(i=0;i<(light?36:70);i++){var aa=rnd()*2*PI,vv=35+rnd()*95;SP.push({x:Math.cos(aa)*RH*1.25,y:Math.sin(aa)*RH*1.25,vx:Math.cos(aa)*vv,vy:Math.sin(aa)*vv,l:1,k:.7+rnd()*1.1,c:rnd()<.35?'#F1F4F6':rnd()<.5?'#C8FF8D':'#9BEB4B'});}}
 if(t>3.15){var e=cl((t-3.15)/1.05);pk=Math.exp(-Math.pow((t-3.28)/.2,2));
  for(i=0;i<24;i++){var an2=i*2.39996+.3+slow*.1,L=(i%3===0?72:i%3===1?44:26)*(.35+.65*pk)*(1+.15*Math.sin(t*9+i))*(1-.5*e),w0=(i%3===0?1.5:.8)*(.4+.6*pk),ca=Math.cos(an2),sa=Math.sin(an2),x0=ca*RH*1.2,y0=sa*RH*1.2;
   var rg2=c.createLinearGradient(x0,y0,ca*L,sa*L);rg2.addColorStop(0,'rgba(255,255,255,'+(.95*pk+.05)+')');rg2.addColorStop(.35,'rgba(200,255,141,'+(.7*pk)+')');rg2.addColorStop(1,'rgba(155,235,75,0)');
   c.fillStyle=rg2;c.beginPath();c.moveTo(x0-sa*w0,y0+ca*w0);c.lineTo(ca*L,sa*L);c.lineTo(x0+sa*w0,y0-ca*w0);c.closePath();c.fill();
   c.strokeStyle='rgba(255,255,255,'+(.55*pk)+')';c.lineWidth=.45;c.beginPath();c.moveTo(x0,y0);c.lineTo(ca*L*.8,sa*L*.8);c.stroke();}
  var SP2=A.SP;for(i=SP2.length-1;i>=0;i--){var q2=SP2[i];q2.vx*=1-1.9*dt;q2.vy*=1-1.9*dt;q2.x+=q2.vx*dt;q2.y+=q2.vy*dt;q2.l-=dt*1.15;if(q2.l<=0){SP2.splice(i,1);continue;}
   var sp3=Math.hypot(q2.vx,q2.vy),ln=Math.min(9,sp3*.07)*q2.k;c.strokeStyle=rgba(q2.c,Math.min(1,q2.l*1.2)*.9);c.lineWidth=.5+.7*q2.l*q2.k;c.lineCap='round';c.beginPath();c.moveTo(q2.x,q2.y);c.lineTo(q2.x-q2.vx/(sp3+1)*ln,q2.y-q2.vy/(sp3+1)*ln);c.stroke();}
  c.strokeStyle=rgba('#F1F4F6',(1-e)*.75);c.lineWidth=1.2*(1-e)+.3;c.beginPath();c.arc(0,0,RH+e*58,0,2*PI);c.stroke();
  c.strokeStyle=rgba('#9BEB4B',(1-e)*.55);c.lineWidth=3.2*(1-e)+.4;c.beginPath();c.arc(0,0,RH+e*40,0,2*PI);c.stroke();
  c.setLineDash([1,3.5]);c.lineDashOffset=-t*18;c.strokeStyle=rgba('#C8FF8D',(1-e)*.6);c.lineWidth=1;c.beginPath();c.arc(0,0,RH+e*84,0,2*PI);c.stroke();c.setLineDash([]);
  var fl=c.createRadialGradient(0,0,RH,0,0,RH+26*pk+4);fl.addColorStop(0,'rgba(255,255,255,'+(.8*pk)+')');fl.addColorStop(.4,'rgba(155,235,75,'+(.4*pk)+')');fl.addColorStop(1,'rgba(155,235,75,0)');c.fillStyle=fl;c.beginPath();c.arc(0,0,RH+26*pk+4,0,2*PI);c.arc(0,0,RH,0,2*PI,true);c.fill('evenodd');}
 c.restore();
 A.t+=dt;if(A.t>A_DUR)AB=null;}

/* ============ ENTRÉE : la fronde (A) ============ */
var B_DUR=3.5,TE=.55,DT=1/240;
function birthStart(bx,by){
 if(reduced())return false;prep();
 var S0=[bx,by],E0=[bx+(bx>180?-120:120),by+(by>300?-40:28)];
 E0[0]=Math.max(36,Math.min(GW-36,E0[0]));E0[1]=Math.max(44,Math.min(GH-44,E0[1]));
 var dx=S0[0]-E0[0],dy=S0[1]-E0[1],d=Math.hypot(dx,dy)||1,ux=dx/d,uy=dy/d,tx=S0[0]+uy*-70,ty=S0[1]-ux*-70,ax=tx-E0[0],ay=ty-E0[1],n=Math.hypot(ax,ay)||1;
 var x=E0[0],y=E0[1],vx=ax/n*300,vy=ay/n*300,t=0,rot=0,TRA=[];
 while(t<3.2){var rx=S0[0]-x,ry=S0[1]-y,r=Math.hypot(rx,ry)+1e-6,a=2e6*r/Math.pow(r*r+784,1.5),gm=1.6*(.15+(r<80?1:0));
  vx+=(rx/r*a-gm*vx)*DT;vy+=(ry/r*a-gm*vy)*DT;x+=vx*DT;y+=vy*DT;t+=DT;
  var k=sm((t-1.75)/.6),sp=Math.hypot(vx,vy);rot+=sp*DT/RB*(1-k)*.5;TRA.push([x+(S0[0]-x)*k,y+(S0[1]-y)*k,vx*(1-k),vy*(1-k),rot]);}
 seed=11;var D=[];for(var i=0;i<(soft()?12:26);i++)D.push({x:S0[0]+(rnd()-.5)*190,y:S0[1]+(rnd()-.5)*190,c:DC[i%5],z:.6+rnd()*1.3,ph:rnd()*6.28,w:.5+rnd()});
 BIRTH={s:{},t:0,S0:S0,E0:E0,TRA:TRA,D:D,ej:[],hist:[],SP:[],fired:0,clack:-9};return true;}
function bsparks(B,x,y,n,col,v0,life){for(var i=0;i<n;i++){var a=rnd()*2*PI,v=v0*(.4+rnd());B.SP.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:life||.5,L:life||.5,c:col[i%col.length]});}}
function drawBirth(c,dt){
 var B=BIRTH,t=B.t,S0=B.S0,E0=B.E0,i,idx=Math.min(B.TRA.length-1,Math.floor(Math.max(0,t-TE)/DT)),P=B.TRA[idx];
 var sn=B.s;if(t>=.12&&!sn.o){sn.o=1;snd('birth_open');}if(t>=TE&&!sn.sh){sn.sh=1;snd('birth_shot');}if(t>=1.05&&!sn.p){sn.p=1;snd('birth_pass');}
 c.save();
 /* niveau : fondu progressif depuis le trou (voile de la couleur du fond qui se retire) */
 if(t<1.6){var rr=t*430-120,a0=1-sm(t/.8),g=c.createRadialGradient(E0[0],E0[1],Math.max(0,rr),E0[0],E0[1],Math.max(1,rr+190));g.addColorStop(0,rgba(BG,a0));g.addColorStop(1,rgba(BG,1));c.fillStyle=g;c.globalCompositeOperation='source-over';c.fillRect(0,0,GW,GH);}
 /* puits décoratif très discret autour du départ */
 var well=sm((t-.3)/.5)*(1-sm((t-2.7)/.5)),Rv=92,st=18,m=1+1.4*well;
 c.globalCompositeOperation='lighter';
 if(false&&well>.01){c.lineWidth=.8;   /* R281 : grille retirée */var dp=function(x,y){var dx=x-S0[0],dy=y-S0[1],d=Math.hypot(dx,dy)||1,k=Math.min(.5,m/(d*d+3600)*30);return [x-dx*k,y-dy*k];};
  for(var pass=0;pass<2;pass++)for(i=-Rv;i<=Rv;i+=st){c.beginPath();var f=true;for(var j=-Rv;j<=Rv;j+=5){var px=S0[0]+(pass?j:i),py=S0[1]+(pass?i:j);if(Math.hypot(px-S0[0],py-S0[1])>Rv){f=true;continue;}var q=dp(px,py);f?(c.moveTo(q[0],q[1]),f=false):c.lineTo(q[0],q[1]);}
   c.strokeStyle=rgba('#8C7BFF',.16*well);c.stroke();}}
 for(i=0;i<B.D.length;i++){var p=B.D[i],dx2=S0[0]-p.x,dy2=S0[1]-p.y,d2=Math.hypot(dx2,dy2)+1;p.x+=dx2/d2*dt*(3+8*well)*p.w*(1+50/d2);p.y+=dy2/d2*dt*(3+8*well)*p.w*(1+50/d2);if(d2<14){p.x=S0[0]+(rnd()-.5)*190;p.y=S0[1]+(rnd()-.5)*190;}
  var al=(.16+.34*well)*(.6+.4*Math.sin(t*3+p.ph))*cl(1-(t-3.1)/.4)*sm(t*2),sz=p.z*3.4;c.globalAlpha=Math.min(1,al);c.drawImage(SPR[p.c],p.x-sz/2,p.y-sz/2,sz,sz);}
 c.globalAlpha=1;
 /* trou discret */
 var op=sm((t-.12)/.3)*(1-sm((t-.82)/.4)),Rh=7*op,pw=.25+1.0*Math.exp(-Math.pow((t-TE)/.1,2))+.3*op;
 if(t>.1&&t<.2){c.fillStyle='rgba(255,255,255,'+(1-(t-.1)/.1)+')';c.beginPath();c.arc(E0[0],E0[1],2.2,0,2*PI);c.fill();}
 if(Rh>.3&&op>0){c.globalCompositeOperation='source-over';c.fillStyle='rgba(2,3,7,'+(.99*op)+')';c.beginPath();c.arc(E0[0],E0[1],Rh,0,2*PI);c.fill();
  c.globalCompositeOperation='lighter';var off=[['#9BEB4B',-1],['#F1F4F6',0],['#43D5F5',1]];
  for(i=0;i<3;i++){c.strokeStyle=rgba(off[i][0],(i===1?.8:.5)*op);c.lineWidth=(i===1?1:1.6)*Math.max(.6,Rh/10);c.beginPath();c.arc(E0[0]+off[i][1]*.4,E0[1],Rh+.6+i*.15+off[i][1]*Rh/14,0,2*PI);c.stroke();}
  var g2=c.createRadialGradient(E0[0],E0[1],Rh,E0[0],E0[1],Rh*2.6),pp=Math.min(1.4,pw);g2.addColorStop(0,'rgba(255,255,255,'+(.5*pp*op)+')');g2.addColorStop(.4,rgba('#C8FF8D',.16*pp*op));g2.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=g2;c.beginPath();c.arc(E0[0],E0[1],Rh*2.6,0,2*PI);c.arc(E0[0],E0[1],Rh,0,2*PI,true);c.fill('evenodd');}
 /* tir */
 if(t>=TE&&!B.fired){B.fired=1;bsparks(B,E0[0],E0[1],14,['#F1F4F6','#C8FF8D','#9BEB4B','#8FE3FF'],180,.55);
  var base=Math.atan2(S0[1]-E0[1],S0[0]-E0[0]);for(i=0;i<16;i++){var aa=base+(rnd()-.5)*1.5,vv=60+rnd()*120;B.ej.push({x:E0[0],y:E0[1],vx:Math.cos(aa)*vv,vy:Math.sin(aa)*vv,l:1,c:DC[i%5],z:.8+rnd()*1.2});}}
 c.globalCompositeOperation='lighter';
 if(t>TE&&t<TE+.35){var e=(t-TE)/.35;c.strokeStyle=rgba('#F1F4F6',(1-e)*.7);c.lineWidth=1.3*(1-e)+.3;c.beginPath();c.arc(E0[0],E0[1],8+e*34,0,2*PI);c.stroke();}
 for(i=B.ej.length-1;i>=0;i--){var q2=B.ej[i];q2.vx*=1-2.2*dt;q2.vy*=1-2.2*dt;q2.x+=q2.vx*dt;q2.y+=q2.vy*dt;q2.l-=dt*1.1;if(q2.l<=0){B.ej.splice(i,1);continue;}var sz2=q2.z*3.6;c.globalAlpha=q2.l*.8;c.drawImage(SPR[q2.c],q2.x-sz2/2,q2.y-sz2/2,sz2,sz2);}
 c.globalAlpha=1;
 /* particule réelle : étirée dans le mouvement, écrasée à la pose */
 var landed=TE+2.4,bx=P[0],by=P[1],bs=.3+.7*sm((t-TE)/.4),bal=sm((t-TE)/.08),sq=0,dd=t-landed;
 if(dd>0&&dd<.14)sq=1-dd/.14;if(B.clack<0&&t>=landed){snd('birth_land');bsparks(B,S0[0],S0[1],10,['#8FE3FF','#F1F4F6','#9BEB4B'],90,.4);B.clack=landed;}
 if(t>=TE)B.hist.push({x:bx,y:by,l:1,s:bs,v:Math.hypot(P[2],P[3])});
 for(i=B.hist.length-1;i>=0;i--){B.hist[i].l-=dt*3;if(B.hist[i].l<=0)B.hist.splice(i,1);}
 c.lineCap='round';
 for(i=1;i<B.hist.length;i++){var h0=B.hist[i-1],h1=B.hist[i],sp=Math.min(1,h1.v/260);c.strokeStyle=rgba(i%2?'#F1F4F6':'#8FE3FF',h1.l*.5*(.25+.75*sp));c.lineWidth=Math.max(.4,9*h1.s*h1.l*(.35+.65*sp));c.beginPath();c.moveTo(h0.x,h0.y);c.lineTo(h1.x,h1.y);c.stroke();}
 if(t>=TE){var gl=Math.exp(-Math.pow((t-TE)/.14,2));if(gl>.02){var gg=c.createRadialGradient(bx,by,0,bx,by,RB*3);gg.addColorStop(0,'rgba(255,255,255,'+(.55*gl)+')');gg.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=gg;c.beginPath();c.arc(bx,by,RB*3,0,2*PI);c.fill();}
  var spd=Math.hypot(P[2],P[3]),st2=Math.min(.28,spd/1100),ang=Math.atan2(P[3],P[2]);
  c.save();c.translate(bx,by);c.globalCompositeOperation='source-over';c.globalAlpha=bal;
  if(sq>.01)c.scale(1+sq*.28,1-sq*.24);else if(spd>30){c.rotate(ang);c.scale(1+st2,1/(1+st2*.5));c.rotate(-ang);}
  if(window.VX&&VX.ball)VX.ball(c,0,0,P[4],RB*bs);else{c.fillStyle='#F1F4F6';c.beginPath();c.arc(0,0,RB*bs,0,2*PI);c.fill();}
  c.restore();c.globalAlpha=1;}
 c.globalCompositeOperation='lighter';
 for(i=B.SP.length-1;i>=0;i--){var s2=B.SP[i];s2.vx*=1-3*dt;s2.vy*=1-3*dt;s2.x+=s2.vx*dt;s2.y+=s2.vy*dt;s2.l-=dt;if(s2.l<=0){B.SP.splice(i,1);continue;}
  var spd2=Math.hypot(s2.vx,s2.vy)+1,ln=Math.min(10,spd2*.06);c.strokeStyle=rgba(s2.c,s2.l/s2.L*.9);c.lineWidth=.9;c.beginPath();c.moveTo(s2.x,s2.y);c.lineTo(s2.x-s2.vx/spd2*ln,s2.y-s2.vy/spd2*ln);c.stroke();}
 if(B.clack>0&&t-B.clack<.45){var e2=(t-B.clack)/.45;c.strokeStyle=rgba('#43D5F5',(1-e2)*.8);c.lineWidth=1.6;c.beginPath();c.arc(S0[0],S0[1],RB+e2*22,0,2*PI);c.stroke();}
 c.restore();
 B.t+=dt;if(B.t>B_DUR)BIRTH=null;}

var QFX=window.QFX={light:false,
 absorbStart:absorbStart,birthStart:birthStart,
 busy:function(){return !!(AB||BIRTH);},absorbing:function(){return !!AB;},birthing:function(){return !!BIRTH;},
 skip:function(){BIRTH=null;},cancel:function(){AB=null;BIRTH=null;},
 /* appelé à la place de drawBall : retourne true si la particule a été dessinée ici */
 draw:function(c){
  if(!AB&&!BIRTH){last=0;return false;}
  var now=performance.now(),dt=last?Math.min(.05,(now-last)/1000):.016;last=now;
  try{if(AB){drawAbsorb(c,dt);return true;}
   if(BIRTH){   /* R282 : l'entrée n'avance que lorsque le niveau est réellement visible (pas sous la carte du monde, la pause, le bilan…) */
    var hid=false;try{hid=!!document.querySelector('.veil.on');}catch(e){}
    if(hid&&BIRTH.t<=0&&(BIRTH.wait=(BIRTH.wait||0)+dt)<8){drawBirth(c,0);return true;}
    drawBirth(c,dt);return true;}}
  catch(e){AB=null;BIRTH=null;try{console.error('transitions:',e);}catch(x){}}
  return false;}};
})();
