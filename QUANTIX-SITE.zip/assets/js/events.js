/* R289 · events.js — journal d'événements de jeu (collecte pour la révision des niveaux et le suivi des joueurs).
   Principe : événements bruts datés (t = ms depuis le début de session), file en mémoire persistée localement (IndexedDB-less :
   localStorage 'quantix.ev.q') → rien n'est perdu hors connexion ; envoi par lots, idempotent, jamais bloquant.
   Aucun nom, e-mail, IP ni position. Refus du joueur (quantix.runs.consent2 = 'no') = rien n'est enregistré.
   Types : ss session · se fin de session · lv entrée niveau · sk trait · ed édition · tm mode d'outil · la lâcher · ct contact
           bx événement physique · rs issue d'essai · ab abandon · vw vue · ck tap sur bouton · er erreur script.
   API : QEV.ev(type,data) · QEV.pending() · QEV.take(n) / QEV.ack(n) (pour un transport) · QEV.sink = fn(batch)→Promise
         QEV.endpoint = URL d'ingestion (lots JSON par fetch keepalive / sendBeacon) · QEV.dump() · QEV.stamp() */
(function(){
 'use strict';
 if(typeof window==='undefined'||typeof BUS==='undefined'||typeof S==='undefined')return;
 var ENDPOINT='https://quantix-events.mydopeoff.workers.dev/';   /* ← adresse du Worker Cloudflare (R291) ; vide = aucun envoi réseau */
 var QK='quantix.ev.q',NK='quantix.ev.n',LK='quantix.ev.last',CK='quantix.runs.consent2',RID='quantix.rid',CAP=6000,BATCH=150,FLUSH=20000;
 var q=[],seq=0,t0=Date.now(),sid='',pid='',inflight=false,dirty=false,failN=0,nextTry=0,active=0,lastAct=Date.now(),vis=true;
 function ls(){try{return window.localStorage;}catch(e){return null;}}
 function get(k){var s=ls();try{return s&&s.getItem(k);}catch(e){return null;}}
 function put(k,v){var s=ls();try{if(s)s.setItem(k,v);}catch(e){}}
 function refused(){return get(CK)==='no';}
 function rnd(n){var v='';for(var i=0;i<n;i++)v+=Math.floor(Math.random()*16).toString(16);return v;}
 function build(){var e=document.getElementById('buildTag'),m=e&&/R\d+/.exec(e.textContent||'');return m?m[0]:'';}
 pid=get(RID)||'';if(!pid){pid=rnd(12);put(RID,pid);}
 sid=rnd(8);
 try{var o=JSON.parse(get(QK)||'[]');if(o&&o.length)q=o;}catch(e){}
 var nS=(parseInt(get(NK),10)||0)+1;put(NK,String(nS));
 try{var m=0;q.forEach(function(x){if(x.k>m&&x.s===sid)m=x.k;});}catch(e){}
 function persist(){dirty=false;if(q.length>CAP)q.splice(0,q.length-CAP);put(QK,JSON.stringify(q));}
 function soon(){if(dirty)return;dirty=true;setTimeout(persist,3000);}
 function r0(x){return Math.round(x);}
 function ev(y,d){
  if(refused())return;
  var e={s:sid,k:++seq,t:Date.now()-t0,y:y,l:(typeof S.li==='number'?S.li+1:0)};
  if(d!==undefined)e.d=d;q.push(e);soon();return e;}
 /* ---- contexte / session ---- */
 function stamp(){return {format:'quantix-events',v:1,pid:pid,build:build(),lang:(document.documentElement.lang||navigator.language||'').slice(0,5),
  w:window.innerWidth|0,h:window.innerHeight|0,dpr:+(window.devicePixelRatio||1).toFixed(2),rm:!!window.RM,
  ori:(window.innerWidth>window.innerHeight)?'l':'p',n:nS};}
 var prev=parseInt(get(LK),10)||0;
 ev('ss',{b:build(),n:nS,gap:prev?Math.round((Date.now()-prev)/36e5):null,w:window.innerWidth|0,h:window.innerHeight|0,dpr:+(window.devicePixelRatio||1).toFixed(2),
  lang:(document.documentElement.lang||navigator.language||'').slice(0,5),rm:window.RM?1:0,ori:(window.innerWidth>window.innerHeight)?'l':'p',
  ref:(function(){try{return /standalone|fullscreen/.test(['standalone','fullscreen'].filter(function(m){return window.matchMedia('(display-mode:'+m+')').matches;}).join())?'pwa':'web';}catch(e){return '';}})()});
 function tick(){var n=Date.now();if(vis&&n-lastAct<30000)active+=Math.min(1000,n-(tick.l||n));tick.l=n;}
 setInterval(tick,1000);
 ['pointerdown','keydown','touchstart'].forEach(function(k){document.addEventListener(k,function(){lastAct=Date.now();},true);});
 function bye(why){try{tick();}catch(e){}put(LK,String(Date.now()));
  ev('se',{why:why,act:Math.round(active/1000),dur:Math.round((Date.now()-t0)/1000),mode:S.mode,tryN:tryN,stk:(S.strokes||[]).length});persist();send(true);}
 document.addEventListener('visibilitychange',function(){vis=document.visibilityState!=='hidden';if(!vis)bye('hide');else ev('sr');});
 window.addEventListener('pagehide',function(){bye('pagehide');});
 window.addEventListener('error',function(e){var c=ev('er',{m:String(e&&e.message||'').slice(0,120),f:String(e&&e.filename||'').split('/').pop().slice(0,30),ln:e&&e.lineno|0});});
 /* ---- niveau ---- */
 var tryN=0,tPrep=Date.now(),lastEnd=0;
 var ll=window.loadLevel;
 if(typeof ll==='function')window.loadLevel=function(i){var r=ll.apply(this,arguments);try{tryN=0;tPrep=Date.now();contacts=0;ev('lv',{i:i+1,ink:r0(S.inkMax||0),zen:S.zen?1:0,demo:S.demo?1:0});}catch(e){}return r;};
 var rb=window.resetBall;
 if(typeof rb==='function')window.resetBall=function(){tPrep=Date.now();return rb.apply(this,arguments);};
 /* ---- vues et taps ---- */
 var sh=window.show;
 if(typeof sh==='function')window.show=function(v,on){try{if(v&&v.id&&!!on!==v.classList.contains('on'))ev('vw',{id:v.id,on:on?1:0});}catch(e){}return sh.apply(this,arguments);};
 document.addEventListener('click',function(e){try{var el=e.target;
  while(el&&el!==document.body){if(el.id==='cv')return;if(el.id||(el.dataset&&el.dataset.k)){ev('ck',{id:(el.id||el.dataset.k).slice(0,30)});return;}el=el.parentNode;}}catch(x){}},true);
 /* ---- dessin et édition (crochet interne de l'éditeur : cf. EDT.hook) ---- */
 var down=0,strokeI=0;
 var cv=document.getElementById('cv');
 if(cv){cv.addEventListener('pointerdown',function(){down=Date.now();},true);}
 function packS(s,max){var p=s.pts||[],n=p.length,st=Math.max(1,Math.ceil(n/max)),o=[],i;
  for(i=0;i<n;i+=st)o.push(r0(p[i][0]),r0(p[i][1]));if((n-1)%st)o.push(r0(p[n-1][0]),r0(p[n-1][1]));return o;}
 function onEdit(k,v,op){
  if(k==='mode'){ev('tm',{m:v});return;}
  if(v==='add'){var s=op&&op.s||(S.strokes&&S.strokes[S.strokes.length-1]);if(!s)return;
   ev('sk',{m:s.mat|0,len:r0(s.len||0),p:packS(s,40),dt:down?Date.now()-down:null,i:(S.strokes||[]).length,ink:r0(S.ink||0),tp:Date.now()-tPrep});return;}
  var d={o:v};
  if(v==='del'&&op&&op.items)d.n=op.items.length;
  if(v==='scl'&&op){d.a=r0(op.lenA||0);d.b=r0(op.lenB||0);}
  if(v==='mov'&&op&&op.before&&op.after&&op.before[0]&&op.after[0]){d.dx=r0(op.after[0][0]-op.before[0][0]);d.dy=r0(op.after[0][1]-op.before[0][1]);d.i=(S.strokes||[]).indexOf(op.s);}
  if(v==='clr'&&op&&op.list)d.n=op.list.length;
  d.ink=r0(S.ink||0);ev('ed',d);}
 var E=window.EDT;
 if(E&&E.hook)E.hook(function(k,v,op){try{onEdit(k,v,op);}catch(e){}});
 /* ---- essai ---- */
 var contacts=0,cur=null;
 BUS.on('ball.launch',function(){if(S.zen||S.demo||S.mode==='replay')return;tryN++;contacts=0;
  cur={t:Date.now()};ev('la',{n:tryN,tp:Date.now()-tPrep,ink:r0((S.inkMax||0)-(S.ink||0)),mx:r0(S.inkMax||0),ns:(S.strokes||[]).length,mat:(S.strokes||[]).map(function(s){return s.mat|0;}),g:(S.strokes||[]).slice(0,12).map(function(s){return {m:s.mat|0,l:r0(s.len||0),p:packS(s,24)};})});});
 BUS.on('ball.impact',function(e){if(!cur||contacts>=60)return;contacts++;ev('ct',[r0(e.x),r0(e.y),+(e.v||0).toFixed(1),e.mat|0,S.frames|0]);});
 ['star.collect','ball.portal','ball.boost','ball.tunnel','ball.rope','ball.wrap','rail.enter','rail.exit','quantum.measure','quantum.entangle','quantum.collapse','quantum.superposition','quantum.recombine','ball.enter_goal'].forEach(function(n){
  BUS.on(n,function(e){if(!cur)return;var d={e:n};if(e&&e.x!=null){d.x=r0(e.x);d.y=r0(e.y);}d.f=S.frames|0;ev('bx',d);});});
 function endTry(r,e){if(!cur)return;var c=cur;cur=null;var b=S.ball||{};
  ev('rs',{r:r,n:tryN,f:S.frames|0,x:r0((e&&e.x!=null)?e.x:b.x||0),y:r0((e&&e.y!=null)?e.y:b.y||0),ink:r0((S.inkMax||0)-(S.ink||0)),ns:(S.strokes||[]).length,
   star:S.gotStar?1:0,bp:packS({pts:(S.pathRec||[]).map(function(p){return p;})},90),ms:Date.now()-c.t});lastEnd=Date.now();}
 BUS.on('level.complete',function(){endTry('ok');});
 BUS.on('ball.fail',function(e){endTry((e&&e.reason)||'fail',e);});
 if(typeof rb==='function'){var rb2=window.resetBall;window.resetBall=function(){if(cur){var c=cur;cur=null;ev('ab',{n:tryN,ms:Date.now()-c.t});}return rb2.apply(this,arguments);};}
 /* ---- envoi par lots ---- */
 function take(n){return q.slice(0,n||BATCH);}
 function ack(n){q.splice(0,n);persist();}
 var last={t:0,ok:null,status:0,err:'',n:0};
 function note(ok,status,err,n){last={t:Date.now(),ok:ok,status:status||0,err:String(err||'').slice(0,80),n:n||0};}
 function fit(){var n=Math.min(BATCH,q.length),b,body;
  for(;;){b=q.slice(0,n);body=JSON.stringify({st:stamp(),ev:b});if(body.length<=48000||n<=5)return {batch:b,body:body};n=Math.max(5,Math.floor(n*0.6));}}
 function fail(status,err){inflight=false;failN++;nextTry=Date.now()+Math.min(120000,5000*Math.pow(2,failN));note(false,status,err);}
 function send(beacon){
  if(refused()||!q.length||inflight)return;
  if(QEV.sink){var sb=take(BATCH);inflight=true;Promise.resolve().then(function(){return QEV.sink(sb,stamp());}).then(function(){inflight=false;failN=0;note(true,200,'',sb.length);ack(sb.length);if(q.length)setTimeout(send,200);},function(e){fail(0,e&&e.message);});return;}
  if(!QEV.endpoint||get(CK)!=='yes')return;   /* envoi réseau : seulement après un Oui explicite */
  var f=fit(),batch=f.batch,body=f.body;
  if(beacon&&navigator.sendBeacon){try{if(navigator.sendBeacon(QEV.endpoint,new Blob([body],{type:'text/plain'}))){note(true,0,'beacon',batch.length);ack(batch.length);}}catch(e){}return;}
  if(Date.now()<nextTry||(navigator.onLine===false))return;
  inflight=true;
  fetch(QEV.endpoint,{method:'POST',body:body,headers:{'Content-Type':'text/plain'},mode:'cors'}).then(function(r){
   if(r&&r.ok){inflight=false;failN=0;note(true,r.status,'',batch.length);ack(batch.length);if(q.length)setTimeout(send,200);}
   else{var s=r?r.status:0;(r&&r.text?r.text():Promise.resolve('')).then(function(x){fail(s,x);},function(){fail(s,'');});}},
   function(e){fail(0,(e&&e.name||'')+' '+(e&&e.message||''));});}
 setInterval(function(){if(q.length&&Date.now()>=nextTry)send(false);},FLUSH);
 setTimeout(function(){send(false);},4000);   /* reprise des événements gardés d'une session précédente */
 window.addEventListener('online',function(){nextTry=0;send(false);});
 window.QEV={ev:ev,sink:null,endpoint:ENDPOINT,last:function(){return last;},pending:function(){return q.length;},take:take,ack:ack,stamp:stamp,flush:function(){send(false);},
  consent:function(){return get(CK);},dump:function(){return {format:'quantix-events',v:1,stamp:stamp(),events:q.slice()};},clear:function(){q=[];persist();}};
})();
