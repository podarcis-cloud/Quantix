/* R266 · runlog.js — journal des essais (collecte des parties de testeurs).
   Étape 1 : les essais restent dans localStorage ('quantix.runs.v1') ; le joueur peut les exporter (Paramètres).
   Étape 2 (R267) : envoi anonyme par e-mail via Web3Forms, SEULEMENT si le joueur a répondu Oui (choix unique, jamais pré-coché,
   modifiable dans Paramètres) ET si SHARE_KEY est renseignée ; une case par niveau permet de retirer la partie.
   Un essai = un lâcher (ball.launch) jusqu'à son issue (réussite, échec + raison) ou son abandon.
   Contenu : niveau, n° d'essai, traits (matière, longueur, points réduits), encre utilisée, durée de dessin, issue,
   taille d'écran, identifiant aléatoire. Jamais : nom, e-mail, adresse IP, position. Le Zen Lab et les démonstrations ne comptent pas. */
(function(){
 'use strict';
 var KEY='quantix.runs.v1',RID='quantix.rid',CK='quantix.runs.consent2',CAP=1500,MAXPTS=28;
 var SHARE_KEY='6badf49a-daeb-48ae-afe7-9f912038b9fd',SHARE_URL='https://api.web3forms.com/submit',GAP=90000,BATCH=40;   /* SHARE_KEY : clé d'accès Web3Forms (publique par nature) ; vide = aucun envoi, aucune question posée */
 if(typeof window==='undefined'||typeof BUS==='undefined'||typeof S==='undefined')return;
 var cur=null,tDraw=Date.now(),mem=null;
 /* R287 : usage des outils d'édition pendant la préparation d'un essai : o = opérations (add trait, del gomme, mov déplacer, scl échelle,
    clr tout effacer, und annuler), m = suite des modes d'outil choisis (draw/line/erase/move/scale), k = nb de changements de matière. */
 var tl={o:{},m:[]};
 function tlReset(){tl={o:{},m:[]};}
 function tlOp(k){tl.o[k]=(tl.o[k]||0)+1;}
 function tlWrap(){var E=window.EDT;if(!E||!E.hook)return;
  E.hook(function(k,v){if(k==='op')tlOp(v||'?');else if(k==='mode'&&tl.m[tl.m.length-1]!==v&&tl.m.length<20)tl.m.push(v);});}
 tlWrap();
 function ls(){try{return window.localStorage;}catch(e){return null;}}
 function load(){if(mem)return mem;var st=ls(),o=null;try{o=st&&JSON.parse(st.getItem(KEY)||'null');}catch(e){}
  mem=(o&&o.runs&&o.runs.length!==undefined)?o:{v:1,runs:[]};return mem;}
 function save(){var st=ls();if(!st)return;try{st.setItem(KEY,JSON.stringify(load()));}catch(e){
  try{var m=load();m.runs=m.runs.slice(Math.floor(m.runs.length/2));st.setItem(KEY,JSON.stringify(m));}catch(e2){}}}
 function rid(){var st=ls(),v=null;try{v=st&&st.getItem(RID);}catch(e){}
  if(!v){v='';for(var i=0;i<12;i++)v+=Math.floor(Math.random()*16).toString(16);try{if(st)st.setItem(RID,v);}catch(e){}}return v;}
 function build(){var e=document.getElementById('buildTag'),m=e&&/R\d+/.exec(e.textContent||'');return m?m[0]:'';}
 /* réduit un trait à ≤ MAXPTS points entiers [x,y,x,y,…] */
 function pack(s){var p=s.pts||[],n=p.length,st=Math.max(1,Math.ceil(n/MAXPTS)),o=[],i;
  for(i=0;i<n;i+=st)o.push(Math.round(p[i][0]),Math.round(p[i][1]));
  if((n-1)%st)o.push(Math.round(p[n-1][0]),Math.round(p[n-1][1]));
  return {m:s.mat||0,l:Math.round(s.len||0),p:o};}
 function packPath(pp){var n=(pp&&pp.length)||0,st=Math.max(1,Math.ceil(n/90)),o=[],i;for(i=0;i<n;i+=st)o.push(Math.round(pp[i][0]),Math.round(pp[i][1]));return o;}
 function strokes(){var a=(S.strokes||[]).map(pack);
  if(S.cur&&S.cur.length>1)a.push(pack({pts:S.cur,len:S.curLen,mat:S.tool}));return a;}
 function nth(li){var r=load().runs,n=1,i;for(i=0;i<r.length;i++)if(r[i].i===li)n++;return n;}
 function finish(res,extra){
  if(!cur)return;var c=cur;cur=null;
  c.r=res;c.f=S.frames|0;c.star=S.gotStar?1:0;
  if(res!=='abandon'){c.ink2=Math.round((S.inkMax||0)-(S.ink||0));   /* à l'abandon le niveau est déjà remis à zéro : pas d'état final */
   var e=strokes();if(JSON.stringify(e)!==JSON.stringify(c.s))c.s2=e;}   /* traits ajoutés pendant la chute */
  if(c.tl===undefined&&(Object.keys(tl.o).length||tl.m.length))c.tl=tl;   /* R287 */
  c.bp=packPath(S.pathRec);   /* R286 : trajectoire de la particule (≤ 90 points entiers [x,y,…], un point toutes les 3 images au départ) */
  if(extra)for(var k in extra)c[k]=extra[k];
  var m=load();m.runs.push(c);if(m.runs.length>CAP)m.runs.splice(0,m.runs.length-CAP);save();count();
  try{if(window.QRUNS&&typeof window.QRUNS.onrun==='function')window.QRUNS.onrun(c,stamp());}catch(e){}}   /* crochet : l'aperçu y branche l'enregistrement en base */
 var rb=window.resetBall;
 if(typeof rb==='function')var lastLi=-1;window.resetBall=function(){if(cur)finish('abandon');if(S.li!==lastLi){lastLi=S.li;tlReset();}tDraw=Date.now();return rb.apply(this,arguments);};
 BUS.on('ball.launch',function(){
  if(S.zen||S.demo||S.mode==='replay')return;
  if(cur)finish('abandon');
  cur={i:S.li,n:nth(S.li),t:new Date().toISOString().slice(0,16),td:Date.now()-tDraw,
   ink:Math.round((S.inkMax||0)-(S.ink||0)),mx:Math.round(S.inkMax||0),s:strokes()};
  if(Object.keys(tl.o).length||tl.m.length)cur.tl=tl;tlReset();});   /* R287 : outils utilisés avant ce lâcher */
 var won=false;
 BUS.on('level.complete',function(){if(cur){finish('ok');won=true;}});
 BUS.on('ball.fail',function(e){if(cur)finish((e&&e.reason)||'fail');});
 /* ---- Envoi anonyme (étape 2) ---- */
 var win=null,lastSend=0,sending=false;   /* win : {li} du dernier niveau réussi, en attente d'envoi */
 function consent(){var st=ls();try{return st&&st.getItem(CK);}catch(e){return null;}}
 function setConsent(v){var st=ls();try{if(st)st.setItem(CK,v);}catch(e){}}
 function enabled(){return !!SHARE_KEY;}
 function unsent(){return load().runs.filter(function(r){return !r.x;});}
 function flush(force){
  if(!enabled()||consent()!=='yes'||sending||!win)return;
  var chk=document.getElementById('shareChk');if(chk&&!chk.checked){   /* partie retirée par le joueur */
   unsent().forEach(function(r){r.x=2;});save();win=null;return;}
  if(!force&&Date.now()-lastSend<GAP)return;
  var u=unsent();if(!u.length){win=null;return;}
  var part=u.slice(0,BATCH),st=stamp();st.runs=part;sending=true;
  var mail=compose(part,st);
  function done(j){sending=false;if(j&&j.success){part.forEach(function(r){r.x=1;});save();lastSend=Date.now();if(unsent().length)win={};else win=null;}return !!(j&&j.success);}
  function plain(){return fetch(SHARE_URL,{method:'POST',keepalive:true,headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(mail.fields)}).then(function(r){return r.json();}).then(done);}
  try{   /* 1) avec le fichier .json en pièce jointe (selon l'offre du service) ; 2) sinon texte seul : le JSON est de toute façon dans le corps */
   var fd=new FormData();for(var k in mail.fields)fd.append(k,mail.fields[k]);
   fd.append('attachment',new File([mail.json],mail.name,{type:'application/json'}));
   fetch(SHARE_URL,{method:'POST',keepalive:true,headers:{Accept:'application/json'},body:fd}).then(function(r){return r.json();})
    .then(function(j){if(j&&j.success)return done(j);return plain();}).catch(function(){plain().catch(function(){sending=false;});});
  }catch(e){try{plain().catch(function(){sending=false;});}catch(e2){sending=false;}}}
 /* Mise en forme du mail : objet = niveau(x) concerné(s) ; corps = joueur, statistiques, détail par niveau, JSON complet */
 function compose(runs,st){
  var by={},ord=[],i,r;
  for(i=0;i<runs.length;i++){r=runs[i];if(!by[r.i]){by[r.i]=[];ord.push(r.i);}by[r.i].push(r);}
  function lab(li){var L=(typeof LEVELS!=='undefined'&&LEVELS[li])||{},w=(typeof WORLDS!=='undefined'&&WORLDS[(L.wd||1)-1])||{};
   return {num:li+1,nom:L.n||'?',monde:w.n||'?',pos:(li%12)+1};}
  function pct(a,b){return b?Math.round(100*a/b):0;}
  var lines=[],ok=0,ko=0,ab=0,inkP=[],td=[];
  ord.forEach(function(li){var a=by[li],l=lab(li),good=a.filter(function(x){return x.r==='ok';}),bad=a.filter(function(x){return x.r!=='ok'&&x.r!=='abandon';}),aba=a.filter(function(x){return x.r==='abandon';});
   ok+=good.length;ko+=bad.length;ab+=aba.length;
   var best=good.length?good.reduce(function(m,x){return (x.ink2||x.ink)<(m.ink2||m.ink)?x:m;}):null;
   a.forEach(function(x){var u=x.ink2!=null?x.ink2:x.ink;if(x.mx)inkP.push(pct(u,x.mx));if(x.td)td.push(x.td);});
   var raisons={};bad.forEach(function(x){raisons[x.r]=(raisons[x.r]||0)+1;});
   var rs=Object.keys(raisons).map(function(k){return k+' ×'+raisons[k];}).join(', ');
   lines.push('Niveau '+l.num+' « '+l.nom+' » (monde '+l.monde+', n° '+l.pos+') : '+a.length+' essai(s) — '+(good.length?'réussi':'non réussi')+
    (best?' ; encre du meilleur essai '+(best.ink2!=null?best.ink2:best.ink)+'/'+best.mx+' ('+pct(best.ink2!=null?best.ink2:best.ink,best.mx)+' %)':'')+
    (rs?' ; échecs : '+rs:'')+(aba.length?' ; abandons : '+aba.length:''));});
  var first=lab(ord[0]),subject;
  if(ord.length===1){var g=by[ord[0]].some(function(x){return x.r==='ok';});subject='Quantix '+st.build+' · Niveau '+first.num+' « '+first.nom+' » · '+(g?'réussi':'non réussi')+' · '+by[ord[0]].length+' essai(s)';}
  else subject='Quantix '+st.build+' · Niveaux '+ord.map(function(x){return x+1;}).join(', ')+' · '+runs.length+' essais';
  var avg=function(a){return a.length?Math.round(a.reduce(function(s,x){return s+x;},0)/a.length):0;};
  var joueur='Identifiant : '+st.id+'\nVersion : '+st.build+'\nLangue : '+st.lang+'\nÉcran : '+st.w+' × '+st.h+' (densité '+st.dpr+')\nEnvoyé : '+st.exported;
  var stats='Essais : '+runs.length+' (réussis '+ok+', échecs '+ko+', abandons '+ab+')\nNiveaux concernés : '+ord.length+'\nEncre utilisée en moyenne : '+avg(inkP)+' % du quota\nTemps de dessin moyen avant le lâcher : '+(Math.round(avg(td)/100)/10)+' s';
  var json=JSON.stringify(st),name='quantix-'+st.id+'-niveaux-'+ord.map(function(x){return x+1;}).join('_')+'.json';
  return {json:json,name:name,fields:{access_key:SHARE_KEY,subject:subject,from_name:'Quantix',message:lines.join('\n'),Joueur:joueur,Statistiques:stats,Donnees_JSON:json}};}
 /* Invite unique (une seule fois, à la 1re sortie du bilan) : fenêtre à part, hors de l'écran de fin de partie */
 function ask(then){
  var m=document.getElementById('shModal');
  if(!m){m=document.createElement('div');m.id='shModal';
   m.style.cssText='position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(5,7,13,.78);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)';
   document.body.appendChild(m);}
  m.innerHTML='<div style="max-width:340px;width:100%;box-sizing:border-box;padding:24px 22px;border:1px solid var(--border,#25405a);border-radius:22px;background:rgba(8,14,24,.96);text-align:center;color:#e8f1f7">'+
   '<div style="font-size:17px;font-weight:600;margin-bottom:10px">'+TR('shareQ')+'</div>'+
   '<div style="font-size:13px;line-height:1.55;opacity:.8;margin-bottom:20px">'+TR('shareQD')+'</div>'+
   '<button id="shYes" style="display:block;width:100%;padding:13px;border-radius:999px;border:1px solid var(--matter,#4DD7FF);background:rgba(77,215,255,.14);color:#e8f1f7;font-size:14px;letter-spacing:.04em;margin-bottom:10px">'+TR('shareYes')+'</button>'+
   '<button id="shNo" style="display:block;width:100%;padding:11px;border:none;background:none;color:#e8f1f7;opacity:.65;font-size:13px">'+TR('shareNo')+'</button></div>';
  m.style.display='flex';
  function done(v){setConsent(v);m.style.display='none';syncSw();shareUI();then&&then();}
  document.getElementById('shYes').onclick=function(){done('yes');};
  document.getElementById('shNo').onclick=function(){done('no');};}
 /* R290 : invite dès la fin du 1er essai (réussi ou non) : sans cela les joueurs qui partent tôt ne seraient jamais comptés */
 var asked=false;
 function askFirst(){if(asked||consent()||document.getElementById('shModal')&&document.getElementById('shModal').style.display==='flex')return;
  if(!enabled()&&!(window.QEV&&QEV.endpoint))return;asked=true;setTimeout(function(){if(!consent())ask();},900);}
 BUS.on('ball.fail',function(){askFirst();});
 BUS.on('level.complete',function(){setTimeout(askFirst,2600);});
 /* Panneau « Ce que collecte Quantix » (Paramètres) */
 function lastTxt(){var l=window.QEV&&QEV.last&&QEV.last();if(!l||!l.t)return TR('dataNone');var ago=Math.round((Date.now()-l.t)/1000);return (l.ok?'OK':'ERREUR '+(l.status||'')+' '+l.err)+' · '+(l.n||0)+' ev · '+ago+' s';}
 function dataPanel(){
  var m=document.getElementById('dtModal');
  if(!m){m=document.createElement('div');m.id='dtModal';
   m.style.cssText='position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(5,7,13,.8);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)';
   document.body.appendChild(m);}
  var n=window.QEV?QEV.pending():0,c=consent();
  m.innerHTML='<div style="max-width:360px;width:100%;max-height:86vh;overflow:auto;box-sizing:border-box;padding:22px 20px;border:1px solid var(--border,#25405a);border-radius:22px;background:rgba(8,14,24,.97);color:#e8f1f7">'+
   '<div style="font-size:17px;font-weight:600;margin-bottom:10px;text-align:center">'+TR('dataT')+'</div>'+
   '<div style="font-size:12.5px;line-height:1.6;opacity:.85">'+TR('dataBody')+'</div>'+
   '<div style="font-size:12px;opacity:.6;margin:14px 0 4px">'+TR('dataState')+' : <b>'+(c==='yes'?TR('dataOn'):c==='no'?TR('dataOff'):TR('dataUnset'))+'</b> · '+n+' '+TR('dataPend')+'</div>'+
   '<div style="font-size:11.5px;opacity:.55;margin-top:6px">'+TR('dataLast')+' : '+lastTxt()+'</div>'+
   '<button id="dtExp" style="display:block;width:100%;padding:10px;margin-top:10px;border-radius:999px;border:1px solid #6a7a8a;background:none;color:#e8f1f7;font-size:12.5px">'+TR('dataExp')+'</button>'+
   '<button id="dtClr" style="display:block;width:100%;padding:10px;margin-top:10px;border-radius:999px;border:1px solid #6a7a8a;background:none;color:#e8f1f7;font-size:12.5px">'+TR('dataClr')+'</button>'+
   '<button id="dtOk" style="display:block;width:100%;padding:12px;margin-top:10px;border-radius:999px;border:1px solid var(--matter,#4DD7FF);background:rgba(77,215,255,.14);color:#e8f1f7;font-size:14px">'+TR('dataClose')+'</button></div>';
  m.style.display='flex';
  document.getElementById('dtOk').onclick=function(){m.style.display='none';};
  document.getElementById('dtExp').onclick=function(){if(!window.QEV)return;var data=JSON.stringify(QEV.dump()),name='quantix-evenements-'+rid()+'.json';
   try{var f=new File([data],name,{type:'application/json'});if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:'Quantix'}).catch(function(){});return;}}catch(e){}
   try{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){document.body.removeChild(a);},500);}catch(e){}};
  document.getElementById('dtClr').onclick=function(){if(window.QEV)QEV.clear();load().runs.length=0;save();count();this.textContent=TR('dataDone');this.disabled=true;};}
 (function(){var b=document.getElementById('dataBtn');if(b)b.onclick=dataPanel;})();
 /* Dans le bilan : une seule ligne discrète, seulement après un Oui */
 function shareUI(){
  var v=document.getElementById('rShare');if(!v)return;
  if(!enabled()||!win||consent()!=='yes'){v.style.display='none';return;}
  v.style.display='flex';
  if(!document.getElementById('shareChk'))v.innerHTML='<input type="checkbox" id="shareChk" checked style="margin:0"><span>'+TR('shareChk')+'</span>';}
 (function mount(){var p=document.getElementById('vResult');if(!p)return;var st=p.querySelector('.stack');if(!st)return;
  var d=document.createElement('label');d.id='rShare';d.style.cssText='display:none;align-items:center;justify-content:center;gap:8px;margin:12px 0 0;font-size:11px;opacity:.6;letter-spacing:.04em';
  st.parentNode.insertBefore(d,st.nextSibling);
  /* 1re sortie du bilan sans réponse : on pose la question avant de continuer */
  p.addEventListener('click',function(e){
   var b=e.target&&e.target.closest&&e.target.closest('#rNext,#rContinue');
   if(!b||!enabled()||consent()||!win)return;
   e.stopImmediatePropagation();e.preventDefault();ask(function(){b.click();});},true);})();
 var onWin=function(){if(!enabled()||S.zen||S.demo)return;win={};setTimeout(shareUI,60);};
 BUS.on('level.complete',function(){if(won){won=false;onWin();}});   /* enregistré après le journal : finish('ok') a déjà eu lieu */
 BUS.on('ball.launch',function(){flush(false);if(!unsent().length)win=null;shareUI();});
 window.addEventListener('pagehide',function(){flush(true);});
 document.addEventListener('visibilitychange',function(){if(document.hidden)flush(true);});
 function syncSw(){var b=document.getElementById('oShare');if(b)b.setAttribute('aria-pressed',consent()==='yes'?'true':'false');}
 var row=document.getElementById('shareRow');
 if(row){row.style.display=enabled()?'':'none';
  if(typeof sw==='function'&&document.getElementById('oShare'))sw('oShare',consent()==='yes',function(v){setConsent(v?'yes':'no');shareUI();});}
 /* ---- Paramètres : export et effacement ---- */
 function stamp(){return {format:'quantix-runs',v:1,id:rid(),build:build(),lang:(typeof LANG!=='undefined'?LANG:''),
  w:window.innerWidth,h:window.innerHeight,dpr:window.devicePixelRatio||1,exported:new Date().toISOString().slice(0,16),runs:load().runs};}
 function count(){var e=document.getElementById('runsCount');if(e)e.textContent=load().runs.length+' '+TR('runsN');}
 function exportRuns(){
  var data=JSON.stringify(stamp()),name='quantix-parties-'+rid()+'.json';
  try{var f=new File([data],name,{type:'application/json'});
   if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:'Quantix'}).catch(function(){});return;}}catch(e){}
  try{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=name;
   document.body.appendChild(a);a.click();setTimeout(function(){document.body.removeChild(a);},500);}catch(e){}}
 function clearRuns(){var b=document.getElementById('runsClr');
  if(!b)return;if(!b._arm){b._arm=1;b.textContent=TR('runsSure');setTimeout(function(){b._arm=0;b.textContent=TR('runsClr');},3500);return;}
  b._arm=0;b.textContent=TR('runsClr');load().runs.length=0;save();count();}
 var be=document.getElementById('runsExp'),bc=document.getElementById('runsClr');
 if(be)be.onclick=exportRuns;if(bc)bc.onclick=clearRuns;
 count();
 window.QRUNS={ask:ask,consent:consent,onrun:null,get:function(){return stamp();},clear:function(){load().runs.length=0;save();count();},count:function(){return load().runs.length;}};
})();
