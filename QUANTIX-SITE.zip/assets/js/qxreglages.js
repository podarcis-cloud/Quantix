/* R454 — RÉGLAGES SANS CONSOLE (iPhone) : paramètres d'URL, persistants (localStorage) jusqu'au réglage inverse.
   ?decor=0  ancien décor (coupe-circuit 'qxfond2')      ?decor=1  le retire
   ?carte=0  ancienne carte des niveaux ('qxcarte')      ?carte=1
   ?hero=0   anciens fonds d'accueil ('qxhero')          ?hero=1
   ?lourd=0  éléments lourds du décor coupés ('qxlourd') ?lourd=1
   ?diag=1   ligne de diagnostic (touchez-la pour la masquer le temps de la session) ; ?diag=0 la retire
   Plusieurs à la fois : ?decor=1&lourd=0&diag=1 */
(function () {
  var M = { decor: 'qxfond2', carte: 'qxcarte', hero: 'qxhero', lourd: 'qxlourd' };
  try {
    var q = new URLSearchParams(location.search), k;
    for (k in M) if (q.has(k)) { if (q.get(k) === '0') localStorage.setItem(M[k], '0'); else localStorage.removeItem(M[k]); }
    if (q.has('diag')) { if (q.get('diag') === '0') localStorage.removeItem('qxdiag'); else localStorage.setItem('qxdiag', '1'); }
  } catch (e) {}
  /* QXRET (lecture seule) : sonde indépendante, une minuterie de 120 ms comme l'ordonnanceur musical ; son retard de réveil = signal
     de surcharge du fil principal pour le gouverneur du décor. sound.js n'est pas touché. */
  var QXRET = window.QXRET = (function () { var h = [], p = 0; setInterval(function () { var n = performance.now(); if (p && !document.hidden) { var r = n - p - 120; if (r > 1) { h.push([n, r]); if (h.length > 400) h.shift(); } } p = document.hidden ? 0 : n; }, 120);
    return { max: function (ms) { var n = performance.now(), m = 0, i; for (i = h.length - 1; i >= 0 && h[i][0] >= n - ms; i--) if (h[i][1] > m) m = h[i][1]; return m; } }; })();
  var on = false; try { on = localStorage.getItem('qxdiag') === '1' && sessionStorage.getItem('qxdiagMasque') !== '1'; } catch (e) {}
  var fi = 16.7, pire = 0, tp = 0;
  function coupes() { var r = [], k; try { for (k in M) if (localStorage.getItem(M[k]) === '0') r.push(k + '=0'); } catch (e) {} return r.join(' '); }
  function etat() {
    var d = window.QXF2 && QXF2.diag ? QXF2.diag() : null, c = window.QXCARTE && QXCARTE.instance && QXCARTE.instance.mesure ? QXCARTE.instance.mesure() : null, R = window.QXRET;
    return { msImage: fi, pireImage: pire, palier: d ? d.deg : null, raison: d ? d.raison : '', verrou: d ? d.verrou : false, decorJs: d ? d.ms : null,
      retardAudio10s: R ? R.max(10000) : null,
      carte: c ? { palier: c.palier, cadence: c.cadence, fi: c.fi, raf: c.raf } : null, coupes: coupes() };
  }
  window.QXDIAG = { etat: etat };
  if (!on) return;
  function boucle(t) { if (tp) { var d = t - tp; if (d < 1000) { fi = fi * 0.9 + d * 0.1; if (d > pire) pire = d; } } tp = t; requestAnimationFrame(boucle); }
  requestAnimationFrame(boucle);
  function poser() {
    var el = document.createElement('div'); el.id = 'qxdiag';
    el.style.cssText = 'position:fixed;left:4px;right:4px;top:calc(env(safe-area-inset-top,0px) + 2px);z-index:99999;font:10px/1.3 ui-monospace,Menlo,monospace;color:#cfe9ff;background:rgba(0,0,0,.62);padding:2px 6px;border-radius:6px;pointer-events:auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
    el.title = 'Touchez pour masquer (?diag=0 pour retirer)';
    el.addEventListener('click', function () { try { sessionStorage.setItem('qxdiagMasque', '1'); } catch (e) {} el.remove(); });
    document.body.appendChild(el);
    setInterval(function () {
      var e = etat(), b = (document.getElementById('buildTag') || {}).textContent || '';
      el.textContent = (b ? b.replace(/^.*?(R\d+).*$/, '$1') + ' · ' : '') + e.msImage.toFixed(1) + ' ms/img (pire ' + Math.round(e.pireImage) + ') · palier ' + (e.palier === null ? '–' : e.palier + (e.raison ? ' ' + e.raison : '') + (e.verrou ? ' ⊘' : ''))
        + ' · retard minuterie max ' + (e.retardAudio10s === null ? '–' : Math.round(e.retardAudio10s) + ' ms')
        + (e.carte ? ' · carte p' + e.carte.palier + ' ' + Math.round(e.carte.fi) + 'ms' + (e.carte.raf ? '' : ' ARRÊT') : '') + (e.coupes ? ' · ' + e.coupes : '');
      pire = 0;
    }, 1000);
  }
  if (document.body) poser(); else document.addEventListener('DOMContentLoaded', poser);
})();
