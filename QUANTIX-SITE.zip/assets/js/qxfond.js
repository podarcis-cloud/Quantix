/* =====================================================================
   QXFOND v4 — couches COMPOSÉES du fond de monde (DOM/CSS, zéro dessin JS).

   L'image cuite (outils/qxfond_gen.py) porte le lointain. Ici :
     plan du fond     image, travelling de niveau, dérive lente, parallaxe
     voile + lavis    profondeur du niveau (dégradés statiques)
     plan du courant  second voile cuit (RGBA) qui glisse sur le fond
     nappes, rayons   caustiques / reflets, faisceaux (animations CSS)
     terrain, réussite  voiles de lisibilité (B4, B5)
   Le canevas du jeu, transparent, passe par-dessus ; les éléments animés
   y sont dessinés par QXPOOL (src/qxpool.js).

   API
     QXFOND.configurer(mondes)
     const f = QXFOND.creer(hote, { monde, image, voile, l, h, carte, zone, reussite })
     f.regler({ profondeur, qualite, sobre })
     f.update(dt, bille)            // parallaxe ; bille {x, y} en px de l'hôte
     f.cadre                        // { versEcran(u, v), vImage(y), lI } → à passer à QXPOOL.creer
     f.detruire()
   Dégradation : qualite < 0,75 un demi-éventail de rayons ; < 0,7 une
   nappe ; < 0,6 plus de plan du courant. sobre / prefers-reduced-motion :
   tout est figé (image fixe complète).
   ===================================================================== */
(function (racine) {
  'use strict';
  const TAU = Math.PI * 2;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const melange = (a, b, f) => a + (b - a) * f;
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lisse = (a, b, x) => { const t = borne((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const T_MARGE = 12;                                        // marge autour de la zone de réussite (px CSS)
  const SEUILS = { nappe2: 0.7, rayons2: 0.75, courant: 0.6 };   // sous ce niveau de qualité, l'élément disparaît

  function aleatoire(graine) {                     // mulberry32, déterministe
    let s = graine >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = Math.imul(s ^ (s >>> 15), s | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function toile(l, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(l)); c.height = Math.max(1, Math.round(h));
    return c;
  }

  let MONDES = {};
  const CSS = `
.qxf{position:absolute;inset:0;overflow:hidden;contain:strict;pointer-events:none}
.qxf>*,.qxf-nappes>*,.qxf-rayons>*{position:absolute;pointer-events:none}
.qxf-plan{left:0;top:0;will-change:transform;transition:transform 1.6s cubic-bezier(.45,0,.2,1)}
.qxf-plan>*,.qxf-para>*{position:absolute;pointer-events:none}
.qxf-para{left:0;top:0;will-change:transform}
.qxf-base{background-size:100% 100%;will-change:transform;animation:qxf-derive var(--duree) ease-in-out infinite alternate}
.qxf-courant{background-size:100% 100%;will-change:transform;animation:qxf-courant var(--duree) ease-in-out infinite alternate}
@keyframes qxf-derive{from{transform:translate3d(calc(var(--amp) * -1),calc(var(--amp) * -.6),0) scale(1)}to{transform:translate3d(var(--amp),calc(var(--amp) * .6),0) scale(1.012)}}
@keyframes qxf-courant{from{transform:translate3d(calc(var(--ax) * -1),calc(var(--ay) * -1),0) rotate(-.5deg)}to{transform:translate3d(var(--ax),var(--ay),0) rotate(.5deg)}}
.qxf-voile,.qxf-lavis{inset:0;transition:opacity 1.2s}
.qxf-nappes{left:0;right:0;transition:opacity 1.2s,height 1.2s}
.qxf-nappes>canvas{left:0;height:100%;will-change:transform;animation:qxf-glisse var(--duree) linear infinite}
.qxf-rayons{inset:0;transition:opacity 1.2s}
.qxf-rayons>canvas{will-change:transform,opacity;animation:qxf-balance var(--duree) ease-in-out infinite alternate}
@keyframes qxf-glisse{from{transform:translate3d(0,0,0)}to{transform:translate3d(var(--pas),0,0)}}
@keyframes qxf-balance{from{transform:rotate(calc(var(--amp) * -1));opacity:var(--o1)}to{transform:rotate(var(--amp));opacity:var(--o2)}}
.qxf[data-fige="1"] *{animation-play-state:paused!important}`;
  function poserStyle() {
    if (document.getElementById('qxfond-css')) return;
    const s = document.createElement('style'); s.id = 'qxfond-css'; s.textContent = CSS;
    document.head.appendChild(s);
  }
  const calmeMouvement = () => false;   // fond10 : comme le jeu depuis R296, le réglage système « réduire les animations » est ignoré (seul « sobre » = réglage du jeu compte)

  /* ---------- Nappe périodique (Worley F2 − F1, domaine tordu) : caustiques, reflets de coulée ---------- */
  function tuileNappe(cote, graine, N, ca, cb) {
    const alea = aleatoire(graine), n = N.cellules, px = [], py = [];
    for (let i = 0; i < n; i++) { px.push(alea() * cote); py.push(alea() * cote); }
    const c = toile(cote, cote), g = c.getContext('2d');
    const img = g.createImageData(cote, cote), d = img.data;
    const largeur = N.finesse * cote / Math.sqrt(n), tors = N.torsion * cote;
    for (let y = 0; y < cote; y++) {
      for (let x = 0; x < cote; x++) {
        const wx = x + tors * Math.sin(TAU * (2 * y / cote) + 1.3), wy = y + tors * Math.sin(TAU * (2 * x / cote) + 0.4);
        let f1 = 1e9, f2 = 1e9;
        for (let i = 0; i < n; i++) {
          let dx = Math.abs(wx - px[i]) % cote, dy = Math.abs(wy - py[i]) % cote;   // distance torique : la tuile raccorde
          if (dx > cote / 2) dx = cote - dx;
          if (dy > cote / 2) dy = cote - dy;
          const dd = dx * dx + dy * dy;
          if (dd < f1) { f2 = f1; f1 = dd; } else if (dd < f2) f2 = dd;
        }
        const e = Math.sqrt(f2) - Math.sqrt(f1);
        const v = Math.exp(-(e * e) / (largeur * largeur)) * (0.45 + 0.55 * Math.sin(TAU * (x + 2 * y) / cote + 0.7) ** 2);
        const k = (y * cote + x) * 4, cc = v * v;
        d[k] = ca[0] + (cb[0] - ca[0]) * cc; d[k + 1] = ca[1] + (cb[1] - ca[1]) * cc; d[k + 2] = ca[2] + (cb[2] - ca[2]) * cc;
        d[k + 3] = 255 * v;
      }
    }
    g.putImageData(img, 0, 0);
    return c;
  }
  function bandeNappe(lPx, hPx, tuilePx, graine, N, cfg) {   // tuile répétée + fondu vertical cuit dans la toile
    const tuile = tuileNappe(tuilePx, graine, N, cfg.palette[N.jetons[0]], cfg.palette[N.jetons[1]]);
    const c = toile((Math.ceil(lPx / tuilePx) + 1) * tuilePx, hPx), g = c.getContext('2d');
    g.fillStyle = g.createPattern(tuile, 'repeat'); g.fillRect(0, 0, c.width, c.height);
    g.globalCompositeOperation = 'destination-in';
    const bas = N.ancre === 'bas', f = g.createLinearGradient(0, bas ? hPx : 0, 0, bas ? 0 : hPx);
    f.addColorStop(0, 'rgba(0,0,0,1)'); f.addColorStop(0.3, 'rgba(0,0,0,0.4)'); f.addColorStop(0.7, 'rgba(0,0,0,0.09)'); f.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = f; g.fillRect(0, 0, c.width, c.height);
    return c;
  }
  const DEBORD = { x: 0.15, y: 0.05 };                       // la toile des rayons déborde de l'hôte : le balancement ne montre jamais son bord
  function toileRayons(lH, hH, ech, R, cfg, pair, alea) {    // la moitié des rayons, peints une fois (lH, hH = hôte en px CSS)
    const c = toile(lH * (1 + 2 * DEBORD.x) * ech, hH * (1 + 2 * DEBORD.y) * ech), g = c.getContext('2d');
    const sx = (R.source[0] + DEBORD.x) * lH * ech, sy = (R.source[1] + DEBORD.y) * hH * ech, versHaut = R.source[1] > 0.5, L = R.longueur * hH * ech;
    g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < R.nb; i++) {
      const angle = (i / (R.nb - 1) - 0.5) * 2 * R.eventail + (alea() - 0.5) * 0.14;
      const larg = melange(R.largeur[0], R.largeur[1], alea()) * ech, dore = alea() < 0.4, force = 0.55 + 0.45 * alea();
      if ((i % 2 === 0) !== pair) continue;
      const col = cfg.palette[R.jetons[dore ? 1 : 0]];
      g.setTransform(1, 0, 0, 1, sx, sy);
      g.rotate(angle + (versHaut ? Math.PI : 0));
      // Fuseau : transparent sur les bords, s'éteint avec la distance
      const pas = 6;
      for (let y = 0; y < L; y += pas) {
        const f = y / L, a = (1 - f) * (1 - f) * force, w = larg * (0.25 + 0.75 * f);
        const o = g.createLinearGradient(-w, 0, w, 0);
        o.addColorStop(0, rgba(col, 0)); o.addColorStop(0.5, rgba(col, a)); o.addColorStop(1, rgba(col, 0));
        g.fillStyle = o; g.fillRect(-w, y, 2 * w, pas);
      }
    }
    return c;
  }

  /* =====================================================================
     creer()
     ===================================================================== */
  function creer(hote, o) {
    poserStyle();
    const cfg = MONDES[o.monde], V = cfg.vivant, carte = !!o.carte, zone = o.zone || null;
    const l = o.l, h = o.h, dpr = Math.min(2, racine.devicePixelRatio || 1);
    const ratio = o.ratio || cfg._ratio || 2340 / 1080;             // H / L de l'image
    // Cadrage : l'image couvre l'hôte ; en niveau, un zoom donne la marge du travelling vertical.
    // DEBORD : marge supplémentaire pour la dérive et la parallaxe (jamais de bord visible).
    const zoom = carte ? 1 : V.cadrage.zoom, D = V.dynamique || {};
    const lI = Math.max(l, h / ratio) * zoom, hI = lI * ratio, decX = (l - lI) / 2, marge = hI - h;
    const debF = (D.derive || 0) + (D.parallaxe || 0) + 2, kC = 1 + (D.courant ? D.courant.avance || 0.08 : 0);
    let decY = 0;
    const r = { profondeur: 0, qualite: 1, sobre: false };

    const racineDom = document.createElement('div'); racineDom.className = 'qxf';
    racineDom.style.background = rgba(cfg.palette[cfg.plancher || 'abysse'], 1);
    const el = (cls, parent) => { const d = document.createElement('div'); d.className = cls; (parent || racineDom).appendChild(d); return d; };
    // Plan du fond : travelling (transition CSS) > parallaxe (JS, 1 écriture par image) > dérive (animation CSS)
    const planFond = el('qxf-plan'), paraFond = el('qxf-para', planFond), base = el('qxf-base', paraFond);
    base.style.cssText = `left:${-debF}px;top:${-debF}px;width:${lI + 2 * debF}px;height:${hI + 2 * debF}px;background-image:url(${o.image});` +
      `--amp:${D.derive || 0}px;--duree:${D.periode || 37}s`;
    const voile = el('qxf-voile'), lavis = el('qxf-lavis');
    const P = V.profondeur;
    if (!carte) {
      const cv = cfg.palette[P.voile.jeton], haut = P.voile.sens !== 'bas';
      voile.style.background = `linear-gradient(${haut ? 180 : 0}deg,${rgba(cv, P.voile.fort)} 0%,${rgba(cv, P.voile.milieu)} 50%,${rgba(cv, P.voile.faible)} 100%)`;
      const cl = cfg.palette[P.lavis.jeton], cl2 = cfg.palette[P.lavis.jeton2 || P.lavis.jeton];
      lavis.style.background = `radial-gradient(120% 60% at 50% ${P.lavis.ancre === 'haut' ? -8 : 108}%,${rgba(cl2, 0.6)} 0%,${rgba(cl, 0.5)} 45%,${rgba(cl, 0)} 100%)`;
    }
    // Plan du courant : second voile cuit (filets, poussière) plus proche, qui glisse sur le fond — donne le sens de l'écoulement
    let planCourant = null, paraCourant = null, courant = null;
    const Cc = D.courant;
    if (Cc && o.voile) {
      planCourant = el('qxf-plan'); paraCourant = el('qxf-para', planCourant); courant = el('qxf-courant', paraCourant);
      const deb = Cc.amplitude + (Cc.parallaxe || 0) + 2;
      courant.style.cssText = `left:${(l - lI * kC) / 2 - deb}px;top:${-deb}px;width:${lI * kC + 2 * deb}px;height:${hI * kC + 2 * deb}px;background-image:url(${o.voile});` +
        `--ax:${Cc.amplitude * (Cc.sensX === undefined ? 0.5 : Cc.sensX)}px;--ay:${Cc.amplitude * (Cc.sensY === undefined ? 1 : Cc.sensY)}px;--duree:${Cc.periode}s;opacity:${carte ? Cc.alpha * 0.8 : Cc.alpha}`;
    }
    const N = V.nappes, nappes = el('qxf-nappes'), toilesNappe = [];
    if (N) {
      const hMax = Math.round(h * (carte ? N.etendue[0] * (N.carte || 0.5) : N.etendue[0]));
      nappes.style[N.ancre === 'bas' ? 'bottom' : 'top'] = '0'; nappes.style.height = hMax + 'px';
      N.echelles.forEach((e, i) => {
        const pas = Math.round(N.tuile * e), c = bandeNappe(l * dpr, hMax * dpr, pas * dpr, 4711 + i * 97, N, cfg);
        c.style.width = c.width / dpr + 'px';
        const vit = N.vitesses[i];
        c.style.setProperty('--pas', (vit > 0 ? -pas : pas) + 'px'); c.style.setProperty('--duree', (pas / Math.abs(vit)).toFixed(1) + 's');
        if (vit < 0) c.style.left = -pas + 'px';
        nappes.appendChild(c); toilesNappe.push(c);
      });
    }
    const R = V.rayons, rayons = el('qxf-rayons'), toilesRayons = [];
    if (R) {
      const aR = aleatoire(404);
      for (let k = 0; k < 2; k++) {
        const c = toileRayons(l, h, 0.5, R, cfg, k === 0, k === 0 ? aleatoire(404) : aR);
        c.style.left = -DEBORD.x * 100 + '%'; c.style.top = -DEBORD.y * 100 + '%';
        c.style.width = (1 + 2 * DEBORD.x) * 100 + '%'; c.style.height = (1 + 2 * DEBORD.y) * 100 + '%';
        c.style.transformOrigin = `${(R.source[0] + DEBORD.x) / (1 + 2 * DEBORD.x) * 100}% ${(R.source[1] + DEBORD.y) / (1 + 2 * DEBORD.y) * 100}%`;
        c.style.setProperty('--amp', R.balancement + 'deg'); c.style.setProperty('--duree', R.periodes[k] + 's');
        c.style.setProperty('--o1', k ? 0.55 : 1); c.style.setProperty('--o2', k ? 1 : 0.6);
        rayons.appendChild(c); toilesRayons.push(c);
      }
    }
    if (zone && V.terrain && V.terrain.force > 0) {
      const tv = el('qxf-terrain'), ct = cfg.palette[V.terrain.jeton], b = V.terrain.bord;
      tv.style.cssText = `left:${zone.x + b}px;top:${zone.y + b}px;width:${zone.l - 2 * b}px;height:${zone.h - 2 * b}px;border-radius:${b}px;` +
        `background:${rgba(ct, V.terrain.force)};box-shadow:0 0 ${b * 1.6}px ${b * 0.9}px ${rgba(ct, V.terrain.force)}`;
    }
    const but = o.reussite || null, butR = but ? but.r + T_MARGE : 0;
    if (but) {                                                        // B5 : le décor cuit s'efface sous la coupe
      const br = el('qxf-reussite'), ct = cfg.palette[(V.terrain && V.terrain.jeton) || cfg.plancher || 'abysse'], R2 = butR + 40;
      br.style.cssText = `left:${but.x - R2}px;top:${but.y - R2}px;width:${2 * R2}px;height:${2 * R2}px;border-radius:50%;` +
        `background:radial-gradient(closest-side,${rgba(ct, 0.72)} 0%,${rgba(ct, 0.66)} ${Math.round(butR / R2 * 70)}%,${rgba(ct, 0)} 100%)`;
    }
    hote.prepend(racineDom);

    let fige = false, px = 0, py = 0, cx = 0, cy = 0;
    function regler(nv) {
      for (const k in nv) if (k in r) r[k] = nv[k];
      const d = carte ? 0 : borne(r.profondeur, 0, 1);
      fige = r.sobre || calmeMouvement();
      const sens = V.cadrage.sens === -1 ? 1 - d : d;
      decY = carte ? 0 : -marge * sens;
      planFond.style.transform = `translate3d(${decX}px,${decY}px,0)`;
      if (planCourant) { planCourant.style.transform = `translate3d(0,${carte ? 0 : -(hI * kC - h) * sens}px,0)`; planCourant.style.display = r.qualite < SEUILS.courant ? 'none' : ''; }
      racineDom.dataset.fige = fige ? '1' : '0';
      if (!carte) { voile.style.opacity = Math.pow(d, P.voile.courbe); lavis.style.opacity = melange(P.lavis.force[0], P.lavis.force[1], d); }
      else { voile.style.opacity = 0; lavis.style.opacity = 0; }
      if (N) {
        nappes.style.opacity = melange(N.alpha[0], N.alpha[1], d) * (carte ? (N.alphaCarte || 0.6) : 1);
        if (!carte) nappes.style.height = Math.round(h * melange(N.etendue[0], N.etendue[1], d)) + 'px';
        if (toilesNappe[1]) toilesNappe[1].style.display = r.qualite < SEUILS.nappe2 ? 'none' : '';
      }
      if (R) {
        rayons.style.opacity = melange(R.alpha[0], R.alpha[1], Math.pow(d, 0.7)) * (carte ? (R.alphaCarte || 0.7) : 1);
        toilesRayons[1].style.display = r.qualite < SEUILS.rayons2 ? 'none' : '';
      }
    }
    // Parallaxe : les plans glissent à contresens de la bille (le fond peu, le courant davantage). Deux écritures de style par image.
    function update(dt, bille) {
      if (fige || !bille || !D.parallaxe) return;
      const tx = (bille.x / l - 0.5) * 2, ty = (bille.y / h - 0.5) * 2, k = Math.min(1, dt * 2.2);
      px += (tx - px) * k; py += (ty - py) * k;
      if (Math.abs(px - cx) + Math.abs(py - cy) < 0.004) return;       // rien de visible : aucune écriture
      cx = px; cy = py;
      paraFond.style.transform = `translate3d(${(-px * D.parallaxe).toFixed(2)}px,${(-py * D.parallaxe).toFixed(2)}px,0)`;
      if (paraCourant) paraCourant.style.transform = `translate3d(${(-px * Cc.parallaxe).toFixed(2)}px,${(-py * Cc.parallaxe).toFixed(2)}px,0)`;
    }
    regler({});
    return {
      regler, update,
      cadre: { versEcran: (u, v) => [decX + u * lI, decY + v * hI], vImage: y => borne((y - decY) / hI, 0, 1), lI },
      detruire() { racineDom.remove(); }
    };
  }

  racine.QXFOND = {
    version: 3,
    configurer(mondes) { MONDES = mondes; },
    get mondes() { return MONDES; },
    creer
  };
})(typeof window !== 'undefined' ? window : globalThis);
