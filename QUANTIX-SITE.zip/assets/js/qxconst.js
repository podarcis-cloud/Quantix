/* =====================================================================
   QXCONST v2 — CONSTELLATION des mondes (candidat R455).

   Couches (de bas en haut) :
     QXFOND (mode carte)  image cuite constellation-fond.webp : dégradé coloré PAR ZONES (une région par monde,
                          sa palette de décor, transitions fondues) ; dérive, parallaxe, plan du courant, nappes, rayons
     canevas statique     liens fins, voile sous les nœuds, mondes verrouillés (signature figée, estompée), anneau de progression
     canevas vivant       décor : poussières à 3 échelles teintées par la zone traversée, nébuleuses qui respirent, longs filaments,
                          scintillements, ondes ; VOCABULAIRE DE MOUVEMENT de chaque zone (AMB) ; nœuds-signatures (SIG) ;
                          éclats sur les liens, souffle du monde courant, animations de progression / complétion / déblocage
     DOM                  titre, sous-titre, un <button> ≥ 52 px par monde (numéro + nom + progression), Fermer

   RÈGLE GRAPHIQUE : aucun motif figuratif (ni flocon, ni rouage, ni nœud de corde, ni flèche) — uniquement points, aiguilles fines,
   arcs/anneaux, halos, filaments, particules. Pas d'or ni d'ambre (réservés au trait du joueur) ; Mécanique = acier + cuivre sombre.

   API
     QXCONST.actif()                     false si localStorage 'qxconst' = '0' (→ ancienne constellation)
     QXCONST.monter(hote, o) → instance  o = { plan, mondes:[{nom, fait, tot, maitrise, ouvert}], courant, choisir(w), fermer(), son(nom), sobre,
                                               textes:{titre, sous, fermer}, memoire, niveau (0–5), auto }
     instance.etats(mondes, courant)     nouveaux états, ANIMÉS par différence
     instance.mesure()                   { ms, images, qualite, niveau, dpr }
     instance.regler({ niveau | qualite, sobre })
     QXCONST.detruire()
   Gouverneur : au-delà de 6 ms JS / image (moyenne 90 images) → niveau suivant (6 niveaux : densité, DPR, traits, nébuleuses).
   ===================================================================== */
(function (racine) {
  'use strict';
  const TAU = Math.PI * 2, W0 = 1080, H0 = 2340, RATIO = H0 / W0;
  const NOMS = ['', 'atelier', 'fonderie', 'chaine', 'glacier', 'soufflerie', 'mecanique', 'gravite', 'magnetisme', 'faille', 'filaments', 'quantique'];
  const TEINTE = { atelier: 'cyan', fonderie: 'danger', chaine: 'lilas', glacier: 'glace', soufflerie: 'air', mecanique: 'acier', gravite: 'vert', magnetisme: 'rose', faille: 'violet', filaments: 'rose', quantique: 'lilas' };
  const SECONDE = { atelier: 'violet', fonderie: 'rose', chaine: 'cyan', glacier: 'cyan', soufflerie: 'argent', mecanique: 'cuivre', gravite: 'violet', magnetisme: 'cyan', faille: 'lilas', filaments: 'lilas', quantique: 'cyan' };
  const FIXE = { mecanique: { acier: [138, 158, 180], cuivre: [176, 104, 80] } };   // Mécanique : acier + cuivre sombre (le laiton, trop proche de l'or, est écarté)
  const SECOURS = { cyan: [77, 215, 255], danger: [255, 82, 82], lilas: [204, 178, 255], glace: [191, 234, 247], air: [168, 200, 232], vert: [155, 235, 75], rose: [255, 111, 181], violet: [166, 120, 255], argent: [206, 216, 228] };
  const NIV = [[1, 2, 1], [0.8, 2, 1], [0.65, 1.5, 0.7], [0.5, 1, 0.7], [0.35, 1, 0.4], [0.22, 1, 0.4]];   // gouverneur : [densité, DPR max du canevas vivant, qualité QXFOND] × 6 niveaux
  const PLAN0 = { 1: [0.30, 0.855, 1, 1], 2: [0.66, 0.8, 0.86, -1], 3: [0.8, 0.715, 1.12, -1], 4: [0.45, 0.635, 0.84, 1], 5: [0.19, 0.575, 1, 1], 6: [0.44, 0.495, 1.22, -1], 7: [0.79, 0.455, 0.92, -1], 8: [0.61, 0.36, 1.04, 1], 9: [0.23, 0.33, 0.9, 1], 10: [0.41, 0.225, 1.1, 1], 11: [0.71, 0.16, 1.3, -1] };
  const LIENS2 = [[1, 4], [3, 7], [5, 9], [6, 8], [8, 11], [2, 4]];
  const BL = [234, 246, 255], GRIS = [150, 168, 196], NUIT = [5, 7, 14];
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lisse = (x) => { x = borne(x, 0, 1); return x * x * (3 - 2 * x); };
  const sortie = (x) => 1 - Math.pow(1 - borne(x, 0, 1), 3);
  const frac = (x) => x - Math.floor(x);
  const hache = (n) => frac(Math.sin(n * 127.1 + 311.7) * 43758.5453);
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${borne(a, 0, 1).toFixed(3)})`;
  const mix = (a, b, f) => [0, 1, 2].map(k => Math.round(a[k] + (b[k] - a[k]) * f));
  const sprites = {}; let PG = 1; const LW = 1.3;   // PG : gain de taille des points (zones, nœuds) ; LW : épaisseur des traits
  function sprite(c) {
    if (c._s) return c._s; const k = c.join(','); if (sprites[k]) return (c._s = sprites[k]);
    const s = document.createElement('canvas'); s.width = s.height = 32; const g = s.getContext('2d');
    const r = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    r.addColorStop(0, rgba([255, 255, 255], 1)); r.addColorStop(0.18, rgba(c, 0.9)); r.addColorStop(0.5, rgba(c, 0.25)); r.addColorStop(1, rgba(c, 0));
    g.fillStyle = r; g.fillRect(0, 0, 32, 32); sprites[k] = c._s = s; return s;
  }
  function ls(k, v) { try { if (v === undefined) return racine.localStorage.getItem(k); racine.localStorage.setItem(k, v); } catch (e) { return null; } return null; }
  function actif() { return ls('qxconst') !== '0' && !!(racine.QXFOND && racine.QXCONST_DONNEES && document.createElement('canvas').getContext); }
  function couleur(nom, jeton) {
    if (FIXE[nom] && FIXE[nom][jeton]) return FIXE[nom][jeton];
    const f2 = racine.QXF2_DONNEES || {}, m = (f2.mondes || {})[nom];
    return (m && m.palette && m.palette[jeton]) || SECOURS[jeton] || BL;
  }

  /* ======================= NŒUDS-SIGNATURES (langue de QXCARTE, à l'échelle d'un monde) =======================
     g : contexte ; (x, y) centre ; R rayon ; t secondes ; c, c2 couleurs ; a alpha d'état ; q qualité. Traits ≤ 1 px, points. */
  function pt(g, x, y, r, c, a) { if (a <= 0.01) return; const s = sprite(c), rr = r * 2.2 * PG; g.globalAlpha = borne(a, 0, 1); g.drawImage(s, x - rr, y - rr, 2 * rr, 2 * rr); }
  function trait(g, c, a, w) { g.globalAlpha = borne(a, 0, 1); g.strokeStyle = rgba(c, 1); g.lineWidth = w * LW; }
  const SIG = {
    atelier(g, x, y, R, t, c, c2, a, q) {                                   // globe de points qui tourne (hélices de l'atelier)
      const n = Math.round(30 * q);
      for (let i = 0; i < n; i++) { const z = 1 - 2 * (i + 0.5) / n, an = i * 2.39996 + t * 0.35, rr = Math.sqrt(1 - z * z), d = Math.sin(an);
        pt(g, x + R * 0.82 * rr * Math.cos(an), y + R * 0.82 * z, 0.55 + 0.45 * (d * 0.5 + 0.5), i % 3 ? c : c2, a * (0.2 + 0.7 * (d * 0.5 + 0.5))); }
    },
    fonderie(g, x, y, R, t, c, c2, a) {                                     // bulles qui montent et éclatent, braises
      for (let j = 0; j < 4; j++) { const s = frac(t / 3.2 + j / 4), bx = x + R * 0.5 * Math.sin(j * 2.1 + s * 3), by = y + R * (0.7 - 1.5 * s), r = 1.5 + R * 0.22 * s;
        trait(g, c, a * 0.8 * Math.sin(s * Math.PI), 0.8); g.beginPath(); g.arc(bx, by, r, 0, TAU); g.stroke(); }
      for (let j = 0; j < 6; j++) { const s = frac(t * 0.22 + hache(j)), ang = hache(j + 4) * TAU; pt(g, x + Math.cos(ang) * R * 0.35 * (1 + s), y - R * 1.1 * s + R * 0.3, 0.8, c2, a * 0.7 * Math.sin(s * Math.PI)); }
    },
    chaine(g, x, y, R, t, c, c2, a) {                                       // deux anneaux fins inclinés, paquets de points qui circulent
      const rx = R * 0.95, ry = R * 0.42, rot = -0.35, co = Math.cos(rot), so = Math.sin(rot);
      trait(g, c, a * 0.55, 0.8); g.beginPath(); g.ellipse(x, y, rx, ry, rot, 0, TAU); g.stroke();
      trait(g, c2, a * 0.3, 0.6); g.beginPath(); g.ellipse(x, y, rx * 0.6, ry * 0.6, rot, t * 0.2, t * 0.2 + 4); g.stroke();
      for (let k = 0; k < 3; k++) for (let m = 0; m < 5; m++) { const u = k * TAU / 3 + t * 0.9 - m * 0.09, px = rx * Math.cos(u), py = ry * Math.sin(u);
        pt(g, x + px * co - py * so, y + px * so + py * co, m ? 0.7 : 1.2, m ? c : BL, a * (1 - m / 5)); }
    },
    glacier(g, x, y, R, t, c, c2, a) {                                      // abstrait : deux arcs fins contrarotatifs, aiguilles quasi parallèles qui miroitent, points qui scintillent (aucune symétrie de flocon)
      trait(g, c, a * 0.5, 0.7); g.beginPath(); g.arc(x, y, R * 0.86, t * 0.11, t * 0.11 + 2.3); g.stroke();
      trait(g, c2, a * 0.4, 0.6); g.beginPath(); g.arc(x, y, R * 0.6, -t * 0.16 + 2, -t * 0.16 + 3.9); g.stroke();
      for (let j = 0; j < 5; j++) { const hx = (hache(j * 3.3 + 1) - 0.5) * R * 1.3, hy = (hache(j * 7.7 + 2) - 0.5) * R * 1.3, Lg = R * (0.16 + 0.3 * hache(j + 9)), an = -0.62 + (hache(j * 2.1) - 0.5) * 0.3, v = Math.pow(0.5 + 0.5 * Math.sin(t * (0.6 + 0.5 * hache(j)) + j * 2.4), 3);
        trait(g, j % 2 ? c : BL, a * (0.12 + 0.6 * v), 0.6); g.beginPath(); g.moveTo(x + hx - Math.cos(an) * Lg, y + hy - Math.sin(an) * Lg); g.lineTo(x + hx + Math.cos(an) * Lg, y + hy + Math.sin(an) * Lg); g.stroke();
        pt(g, x + hx + Math.cos(an) * Lg, y + hy + Math.sin(an) * Lg, 0.7, BL, a * v * 0.9); }
      for (let j = 0; j < 7; j++) { const an = hache(j * 5.3 + 4) * TAU, r = R * (0.25 + 0.7 * hache(j * 1.9 + 6)); pt(g, x + Math.cos(an) * r, y + Math.sin(an) * r, 0.7, c2, a * (0.15 + 0.75 * Math.pow(0.5 + 0.5 * Math.sin(t * 1.7 + j * 1.3), 4))); }
    },
    soufflerie(g, x, y, R, t, c, c2, a) {                                   // filets d'air : traits fins presque parallèles qui ondulent, longueurs inégales, grains emportés
      for (let k = 0; k < 5; k++) { const y0 = (k - 2) * R * 0.34 + (hache(k * 3.1) - 0.5) * R * 0.12, x0 = -R * (0.55 + 0.45 * hache(k + 5)), x1 = R * (0.5 + 0.5 * hache(k * 2.3 + 1)), Y = (xx) => y0 + Math.sin(xx / R * 2.4 + t * 0.9 + k * 1.7) * R * 0.08;
        trait(g, c, a * (0.6 - Math.abs(k - 2) * 0.12), 0.7); g.beginPath();
        for (let j = 0; j <= 10; j++) { const xx = x0 + j * (x1 - x0) / 10; j ? g.lineTo(x + xx, y + Y(xx)) : g.moveTo(x + xx, y + Y(xx)); }
        g.stroke();
        const s = frac(t * 0.4 + k * 0.23), xx = x0 + s * (x1 - x0); pt(g, x + xx, y + Y(xx), 0.9, c2, a * Math.sin(s * Math.PI)); }
    },
    mecanique(g, x, y, R, t, c, c2, a) {                                    // cadence : arcs fins concentriques qui avancent par pas, en sens contraires ; points en orbite (aucune dent)
      const te = t * 0.7, pas = (Math.floor(te) + lisse(Math.min(1, frac(te) * 3.2))) * TAU / 12;
      const A = [[0.9, 1, 0, 1.5, c, 0.7], [0.9, 1, 2.7, 0.7, c, 0.45], [0.66, -1.5, 1, 2.1, c2, 0.6], [0.42, 2, 4, 1.2, c, 0.5]];
      for (const [r, s, d, ov, cc, al] of A) { const a0 = d + pas * s; trait(g, cc, a * al, 0.8); g.beginPath(); g.arc(x, y, R * r, a0, a0 + ov); g.stroke(); pt(g, x + Math.cos(a0 + ov) * R * r, y + Math.sin(a0 + ov) * R * r, 0.7, BL, a * 0.7); }
      for (let j = 0; j < 3; j++) { const an = -pas * 1.3 + j * 2.4 + hache(j) * 0.8; pt(g, x + Math.cos(an) * R * 0.24, y + Math.sin(an) * R * 0.24, 0.7, c2, a * 0.8); }
    },
    gravite(g, x, y, R, t, c, c2, a) {                                      // puits : anneaux qui se resserrent, point qui spirale
      for (let j = 0; j < 4; j++) { const s = frac(j / 4 - t * 0.12), r = R * (0.2 + 0.8 * s);
        trait(g, c, a * 0.6 * Math.sin(s * Math.PI), 0.7); g.beginPath(); g.ellipse(x, y, r, r * 0.5, -0.2, 0, TAU); g.stroke(); }
      const s = frac(t * 0.18), an = s * 9, r = R * 0.95 * (1 - s); pt(g, x + Math.cos(an) * r, y + Math.sin(an) * r * 0.5, 1.1, c2, a * 0.9 * Math.min(1, (1 - s) * 4));
    },
    magnetisme(g, x, y, R, t, c, c2, a) {                                   // lignes de champ du dipôle, points qui les parcourent
      for (let k = 1; k <= 3; k++) for (const s of [-1, 1]) {
        const K = R * (0.45 + k * 0.2); trait(g, c, a * (0.62 - k * 0.12), 0.7); g.beginPath();
        for (let j = 0; j <= 20; j++) { const th = 0.25 + j * (Math.PI - 0.5) / 20, r = K * Math.sin(th) ** 2; const px = s * r * Math.sin(th), py = -r * Math.cos(th); j ? g.lineTo(x + px, y + py) : g.moveTo(x + px, y + py); }
        g.stroke();
        const th = 0.25 + frac(t * 0.3 + k * 0.31 + (s > 0 ? 0 : 0.5)) * (Math.PI - 0.5), r = K * Math.sin(th) ** 2;
        pt(g, x + s * r * Math.sin(th), y - r * Math.cos(th), 0.8, c2, a * 0.8); }
      pt(g, x, y - R * 0.12, 0.9, BL, a * 0.6); pt(g, x, y + R * 0.12, 0.9, c, a * 0.6);
    },
    faille(g, x, y, R, t, c, c2, a, q) {                                    // enclos quantique : couronne de points, ondes stationnaires
      const n = Math.round(16 * q + 2);
      for (let j = 0; j < n; j++) { const an = j * TAU / n + t * 0.05; pt(g, x + Math.cos(an) * R * 0.9, y + Math.sin(an) * R * 0.9, 0.8, c, a * 0.8); }
      for (let j = 1; j <= 2; j++) { const r = R * (0.25 * j + 0.06 * Math.sin(t * 1.6 + j)); trait(g, c2, a * (0.45 + 0.25 * Math.sin(t * 1.6 + j * 2)), 0.7); g.beginPath(); g.arc(x, y, r, 0, TAU); g.stroke(); }
    },
    filaments(g, x, y, R, t, c, c2, a) {                                    // trois brins fins qui ondulent et se croisent, un point court sur chacun
      for (let k = 0; k < 3; k++) { const ph = t * (0.5 + 0.13 * k) + k * 2.1, rot = -0.5 + k * 0.42, co = Math.cos(rot), so = Math.sin(rot);
        const Pk = (u) => { const px = (u - 0.5) * 2 * R * 0.98, py = Math.sin(u * 5.2 + ph) * R * 0.3 * Math.sin(u * Math.PI) + (k - 1) * R * 0.2; return [x + px * co - py * so, y + px * so + py * co]; };
        trait(g, k === 1 ? c2 : c, a * (0.6 - k * 0.1), 0.8); g.beginPath();
        for (let j = 0; j <= 18; j++) { const p = Pk(j / 18); j ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }
        g.stroke(); const s = frac(t * 0.16 + k * 0.37), p = Pk(s); pt(g, p[0], p[1], 0.9, k ? c2 : BL, a * 0.85 * Math.sin(s * Math.PI)); }
    },
    quantique(g, x, y, R, t, c, c2, a) {                                    // franges d'interférence + état superposé (deux points)
      for (const s of [-1, 1]) for (let j = 1; j <= 3; j++) {
        const r = R * (0.38 + 0.2 * j), v = 0.5 + 0.5 * Math.cos(j * 2.2 - t * 1.4);
        trait(g, j % 2 ? c : c2, a * (0.2 + 0.5 * v), 0.7); g.beginPath(); g.arc(x, y, r, s > 0 ? -0.75 : Math.PI - 0.75, s > 0 ? 0.75 : Math.PI + 0.75); g.stroke(); }
      const an = t * 1.1; pt(g, x + Math.cos(an) * R * 0.22, y + Math.sin(an) * R * 0.22, 1.1, c, a * 0.9); pt(g, x - Math.cos(an) * R * 0.22, y - Math.sin(an) * R * 0.22, 1.1, c2, a * 0.9);
    }
  };

  /* ======================= VOCABULAIRE DE MOUVEMENT DES ZONES (repris des décors de monde ; uniquement points, traits fins, arcs, ondes) =======================
     (x, y) cœur de zone ; Z rayon de zone ; a alpha d'état ; q densité ; fil = traits autorisés (niveau < 4). */
  const hh = (i, k) => hache(i * 12.9898 + k * 78.233 + 0.5);
  const AMB = {
    atelier(g, x, y, Z, t, c, c2, a, q) {                                   // grains qui montent en hélice lente
      const n = Math.round(13 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * 0.035 * (0.6 + hh(i, 1)) + hh(i, 2)); pt(g, x + (hh(i, 3) - 0.5) * 1.9 * Z + Math.sin(s * 11 + i) * Z * 0.07, y + Z * (0.95 - 1.9 * s), 0.5 + 0.6 * hh(i, 4), i % 4 ? c : c2, a * 0.6 * Math.sin(s * Math.PI)); }
    },
    fonderie(g, x, y, Z, t, c, c2, a, q, fil) {                             // braises qui montent en vacillant, ondes de chaleur
      const n = Math.round(14 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * 0.07 * (0.6 + hh(i, 1)) + hh(i, 2)); pt(g, x + (hh(i, 3) - 0.5) * 1.7 * Z + Math.sin(s * 7 + i) * Z * 0.1 * s, y + Z * (0.9 - 1.8 * s), 0.5 + 0.7 * hh(i, 4), i % 3 ? c : c2, a * 0.7 * Math.sin(s * Math.PI) * (0.6 + 0.4 * Math.sin(t * 6 + i * 2.7))); }
      if (fil) for (let j = 0; j < 2; j++) { const s = frac(t * 0.05 + j * 0.5 + 0.2); trait(g, c, a * 0.2 * Math.sin(s * Math.PI), 0.7); g.beginPath(); g.arc(x + (j ? 0.3 : -0.25) * Z, y + Z * (1.1 - 1.5 * s), Z * 0.6, Math.PI * 1.25, Math.PI * 1.75); g.stroke(); }
    },
    chaine(g, x, y, Z, t, c, c2, a, q, fil) {                               // paquets de points qui filent sur une voie sinueuse
      const V = (u) => [x + (u - 0.5) * 2.1 * Z, y + Z * 0.5 + Math.sin(u * 4.4 + 1) * Z * 0.22 - u * Z * 0.3];
      if (fil) { trait(g, c, a * 0.13, 0.6); g.beginPath(); for (let j = 0; j <= 16; j++) { const p = V(j / 16); j ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.stroke(); }
      const n = Math.round(12 * q);
      for (let i = 0; i < n; i++) { const u = frac(t * 0.06 + Math.floor(i / 3) * 0.27 + (i % 3) * 0.022), p = V(u); pt(g, p[0], p[1], i % 3 ? 0.6 : 0.95, i % 3 ? c : c2, a * 0.75 * Math.sin(u * Math.PI)); }
    },
    glacier(g, x, y, Z, t, c, c2, a, q, fil) {                              // poussière fine qui descend, miroitements brefs (point + aiguille fine)
      const n = Math.round(10 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * 0.022 * (0.6 + hh(i, 1)) + hh(i, 2)); pt(g, x + (hh(i, 3) - 0.5) * 1.9 * Z + s * Z * 0.25, y + Z * (-0.95 + 1.9 * s), 0.45 + 0.4 * hh(i, 4), c, a * 0.55 * Math.sin(s * Math.PI)); }
      const m = Math.round(7 * q);
      for (let i = 0; i < m; i++) { const v = Math.pow(0.5 + 0.5 * Math.sin(t * (0.5 + 0.6 * hh(i, 5)) + hh(i, 6) * TAU), 10); if (v < 0.03) continue;
        const px = x + (hh(i, 7) - 0.5) * 1.8 * Z, py = y + (hh(i, 8) - 0.5) * 1.8 * Z, an = -0.62 + (hh(i, 9) - 0.5) * 0.3, Lg = (4 + 7 * hh(i, 10)) * v;
        pt(g, px, py, 1, BL, a * v); if (fil) { trait(g, c, a * 0.7 * v, 0.6); g.beginPath(); g.moveTo(px - Math.cos(an) * Lg, py - Math.sin(an) * Lg); g.lineTo(px + Math.cos(an) * Lg, py + Math.sin(an) * Lg); g.stroke(); } }
    },
    soufflerie(g, x, y, Z, t, c, c2, a, q, fil) {                           // filets d'air : traits fins qui filent de côté, grains emportés
      const n = Math.round(8 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * (0.07 + 0.08 * hh(i, 1)) + hh(i, 2)), px = x - Z * 1.05 + 2.1 * Z * s, py = y + (hh(i, 3) - 0.5) * 1.7 * Z + Math.sin(s * 6 + i) * 5, al = a * Math.sin(s * Math.PI);
        if (fil && i % 2) { const Lg = 12 + 20 * hh(i, 4); trait(g, c, al * 0.3, 0.6); g.beginPath(); g.moveTo(px, py); g.quadraticCurveTo(px - Lg * 0.5, py + 2, px - Lg, py + Math.sin(s * 6 + i - 0.6) * 3); g.stroke(); }
        else pt(g, px, py, 0.6, c2, al * 0.6); }
    },
    mecanique(g, x, y, Z, t, c, c2, a, q, fil) {                            // cadence : arcs lointains qui avancent par pas, grains sur orbites
      const te = t * 0.45, pas = (Math.floor(te) + lisse(Math.min(1, frac(te) * 3))) * TAU / 16;
      if (fil) for (let j = 0; j < 3; j++) { const r = Z * (0.5 + 0.22 * j), a0 = j * 2.3 + pas * (j % 2 ? -1 : 0.6); trait(g, j % 2 ? c2 : c, a * 0.16, 0.6); g.beginPath(); g.arc(x, y, r, a0, a0 + 0.7 + 0.5 * j); g.stroke(); }
      const n = Math.round(9 * q);
      for (let i = 0; i < n; i++) { const r = Z * (0.4 + 0.6 * hh(i, 1)), an = hh(i, 2) * TAU + pas * (i % 2 ? -1.4 : 1) * (0.5 + hh(i, 3)); pt(g, x + Math.cos(an) * r, y + Math.sin(an) * r, 0.6, i % 3 ? c : c2, a * 0.6); }
    },
    gravite(g, x, y, Z, t, c, c2, a, q) {                                   // grains qui tombent en spirale vers le cœur
      const n = Math.round(13 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * 0.04 * (0.6 + hh(i, 1)) + hh(i, 2)), r = Z * Math.pow(1 - s, 1.4), an = hh(i, 3) * TAU + s * 6; pt(g, x + Math.cos(an) * r, y + Math.sin(an) * r * 0.62, 0.5 + 0.5 * s, i % 3 ? c2 : c, a * 0.65 * Math.sin(s * Math.PI)); }
    },
    magnetisme(g, x, y, Z, t, c, c2, a, q) {                                // grains qui suivent de grandes boucles de champ
      const n = Math.round(12 * q);
      for (let i = 0; i < n; i++) { const K = Z * (0.6 + 0.55 * hh(i, 1)), th = 0.18 + frac(t * 0.05 * (0.6 + hh(i, 2)) + hh(i, 3)) * (Math.PI - 0.36), r = K * Math.sin(th) ** 2, sg = i % 2 ? 1 : -1; pt(g, x + sg * r * Math.sin(th), y - r * Math.cos(th), 0.6, i % 3 ? c : c2, a * 0.65 * Math.sin(th)); }
    },
    faille(g, x, y, Z, t, c, c2, a, q) {                                    // paires : un grain s'éteint ici, son jumeau s'allume en face
      const n = Math.round(8 * q);
      for (let i = 0; i < n; i++) { const s = frac(t * 0.09 * (0.6 + hh(i, 1)) + hh(i, 2)), an = hh(i, 3) * TAU, r = Z * (0.35 + 0.6 * hh(i, 4)), k = Math.sin(s * Math.PI) ** 2, ax = Math.cos(an) * r, ay = Math.sin(an) * r;
        pt(g, x + ax, y + ay, 0.8, c, a * 0.7 * (1 - k)); pt(g, x - ax * 0.8 + ay * 0.2, y - ay * 0.8 - ax * 0.2, 0.8, c2, a * 0.7 * k); }
    },
    filaments(g, x, y, Z, t, c, c2, a, q, fil) {                            // longs brins qui ondulent, grains qui glissent dessus
      for (let k = 0; k < 3; k++) { const Pk = (u) => [x + (u - 0.5) * 2.1 * Z, y + (k - 1) * Z * 0.52 + (u - 0.5) * Z * 0.3 * (k - 1.4) + Math.sin(u * 5 + t * (0.3 + 0.07 * k) + k * 2) * Z * 0.13 * Math.sin(u * Math.PI)];
        if (fil) { trait(g, k % 2 ? c2 : c, a * 0.2, 0.6); g.beginPath(); for (let j = 0; j <= 14; j++) { const p = Pk(j / 14); j ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.stroke(); }
        for (let m = 0; m < (q > 0.5 ? 2 : 1); m++) { const s = frac(t * 0.05 * (1 + 0.3 * k) + m * 0.5 + k * 0.3), p = Pk(s); pt(g, p[0], p[1], 0.7, m ? c : BL, a * 0.7 * Math.sin(s * Math.PI)); } }
    },
    quantique(g, x, y, Z, t, c, c2, a, q, fil) {                            // ondes fines issues de deux sources, grains qui clignotent entre deux places
      if (fil) for (const sg of [-1, 1]) for (let j = 0; j < 2; j++) { const s = frac(t * 0.07 + j * 0.5 + (sg > 0 ? 0.25 : 0)); trait(g, sg > 0 ? c : c2, a * 0.22 * (1 - s), 0.6); g.beginPath(); g.arc(x + sg * Z * 0.3, y, Z * 0.95 * s + 2, 0, TAU); g.stroke(); }
      const n = Math.round(9 * q);
      for (let i = 0; i < n; i++) { const ph = t * (0.5 + hh(i, 1)) + hh(i, 2) * 9, sd = hache(Math.floor(ph) * 3.7 + i) > 0.5 ? 1 : -1; pt(g, x + sd * hh(i, 3) * 0.9 * Z, y + (hh(i, 4) - 0.5) * 1.6 * Z, 0.7, i % 2 ? c : c2, a * 0.7 * Math.sin(frac(ph) * Math.PI)); }
    }
  };

  let cur = null;
  function monter(hote, o) {
    detruire(); poserStyle();
    const D = racine.QXCONST_DONNEES || {}, PLAN = o.plan || D.plan || PLAN0, N = 11;
    const reduit = () => !!o.sobre;
    let mondes = o.mondes.map(m => Object.assign({}, m)), courant = o.courant || 0;
    let detruit = false, raf = 0, tPrec = 0, qualite = o.qualite || 1, mes = { s: 0, n: 0, fen: [] }, anims = [], refus = null;
    let niveau = o.niveau != null ? borne(o.niveau | 0, 0, 5) : qualite >= 1 ? 0 : qualite > 0.6 ? 2 : 4; qualite = NIV[niveau][0];
    const C = [], C2 = [];
    for (let w = 1; w <= N; w++) { C[w] = couleur(NOMS[w], TEINTE[NOMS[w]]); C2[w] = couleur(NOMS[w], SECONDE[NOMS[w]]); }
    const CM = []; for (let w = 1; w <= N; w++) CM[w] = mix(C[w], BL, 0.35);

    hote.classList.add('qxk-on');
    const R0 = document.createElement('div'); R0.className = 'qxk'; R0.style.background = rgba(NUIT, 1);
    const plan = document.createElement('div'); plan.style.cssText = 'position:absolute;left:0;top:0';
    const cS = document.createElement('canvas'), cD = document.createElement('canvas');
    for (const c of [cS, cD]) c.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none';
    const calque = document.createElement('div'); calque.style.cssText = 'position:absolute;inset:0';
    const neb = document.createElement('div'); neb.className = 'qxk-neb';   // nébuleuses de zone : animées par le compositeur (CSS), coût JS nul
    const tete = document.createElement('div'); tete.className = 'qxk-tete';
    const tx = o.textes || {};
    tete.innerHTML = '<p class="qxk-k"></p><p class="qxk-s"></p>';
    tete.firstChild.textContent = tx.titre || 'Constellation';
    const pied = document.createElement('div'); pied.className = 'qxk-pied';
    const bF = document.createElement('button'); bF.type = 'button'; bF.className = 'qxk-fermer'; bF.setAttribute('aria-label', tx.fermer || 'Fermer');   // retour : glyphe fin dans le coin haut gauche (zone de sécurité), cible 44 px invisible
    bF.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3 5 8l5 5"/></svg>';
    bF.onclick = () => { if (o.fermer) o.fermer(); };
    pied.appendChild(bF);
    R0.append(plan, neb, cS, cD, calque, tete, pied); hote.appendChild(R0);

    let l = 0, h = 0, lI = 0, hI = 0, ox = 0, oy = 0, fond = null, dprS = 1, dprD = 1, P = [], liens = [], btn = [], surImg = true;
    function etat(w) { const m = mondes[w - 1]; if (!m || !m.ouvert) return 'lock'; if (m.tot && m.fait >= m.tot) return 'done'; return w === courant ? 'cur' : 'open'; }
    function sousTitre() { let f = 0, t = 0; mondes.forEach(m => { f += m.fait || 0; t += m.tot || 0; }); tete.lastChild.textContent = (tx.sous ? tx.sous + ' · ' : '') + f + ' / ' + t; }

    function disposer() {
      const r = hote.getBoundingClientRect(); l = Math.round(r.width); h = Math.round(r.height);
      if (l < 10 || h < 10) return false;
      lI = Math.max(l, h / RATIO); hI = lI * RATIO; ox = (l - lI) / 2; oy = (h - hI) / 2;
      plan.style.left = ox + 'px'; plan.style.top = oy + 'px'; plan.style.width = lI + 'px'; plan.style.height = hI + 'px';
      if (fond) { fond.detruire(); fond = null; }
      try {
        const M = Object.assign({}, racine.QXFOND.mondes || {}); M.constellation = D.fond; racine.QXFOND.configurer(M);
        fond = racine.QXFOND.creer(plan, { monde: 'constellation', image: D.image, voile: D.voile, l: lI, h: hI, carte: true });
        fond.regler({ profondeur: 0, qualite: NIV[niveau][2], sobre: reduit() });
      } catch (e) { plan.style.background = 'center/cover url(' + D.image + ')'; }
      const dpr = Math.min(2, racine.devicePixelRatio || 1); dprS = dpr; dprD = Math.min(dpr, NIV[niveau][1]);
      for (const [c, p] of [[cS, dprS], [cD, dprD]]) { c.width = Math.round(l * p); c.height = Math.round(h * p); c.style.width = l + 'px'; c.style.height = h + 'px'; }
      // place des mondes : sur l'image (alignés avec les nébuleuses cuites) si elle tient dans la zone utile ; sinon colonne centrée comprimée
      const haut = 92, bas = 40, utile = h - haut - bas, vs = Object.values(PLAN).map(p => p[1]), v0 = Math.min(...vs), v1 = Math.max(...vs);
      const ech = borne(Math.min(l, h * 0.56) / 390, 0.8, 1.35), surImage = oy + v0 * hI >= haut - 6 && oy + v1 * hI <= h - bas + 6 && lI <= l * 1.02;
      const Lc = Math.min(l, h * 0.56), xc = (l - Lc) / 2; surImg = surImage;
      P = [];
      for (let w = 1; w <= N; w++) {
        const p = PLAN[w], x = surImage ? ox + p[0] * lI : xc + p[0] * Lc, y = surImage ? oy + p[1] * hI : haut + (p[1] - v0) / (v1 - v0) * utile;
        P[w] = { x, y, R: Math.round(19 * p[2] * ech), Z: Math.round(86 * ech * (0.8 + 0.2 * p[2])), cote: p[3] };
      }
      neb.innerHTML = ''; neb.style.display = niveau < 4 ? '' : 'none';
      for (let w = 1; w <= N; w++) { const p = P[w], e = document.createElement('i'), r = Math.round(p.Z * 1.25), k = hache(w * 2.7);
        e.style.cssText = `left:${p.x - r}px;top:${p.y - r}px;width:${2 * r}px;height:${2 * r}px;background:radial-gradient(closest-side,${rgba(C[w], 0.36)},${rgba(C[w], 0.12)} 45%,${rgba(C[w], 0)});--dx:${Math.round((k - 0.5) * p.Z * 1.4)}px;--dy:${Math.round((hache(w * 4.1) - 0.5) * p.Z * 0.8)}px;animation-duration:${(6 + 7 * k).toFixed(1)}s;animation-delay:${(-k * 20).toFixed(1)}s` + (reduit() ? ';animation:none' : '');
        neb.appendChild(e); }
      liens = [];
      for (let w = 1; w < N; w++) liens[w] = courbe(P[w], P[w + 1], w);
      construireBoutons(); dessinerStatique(); return true;
    }
    function courbe(a, b, w) {                                                    // lien légèrement cintré, cintrage varié, extrémités au bord des nœuds
      const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L, f = (hache(w * 3.1) - 0.5) * 0.5 + (w % 2 ? 0.12 : -0.12);
      const cx = (a.x + b.x) / 2 + nx * L * f, cy = (a.y + b.y) / 2 + ny * L * f, pts = [];
      for (let j = 0; j <= 32; j++) { const s = j / 32, u = 1 - s; pts.push([u * u * a.x + 2 * u * s * cx + s * s * b.x, u * u * a.y + 2 * u * s * cy + s * s * b.y]); }
      const hors = (p, n) => Math.hypot(p[0] - n.x, p[1] - n.y) > n.R * 1.25;
      return pts.filter(p => hors(p, a) && hors(p, b));
    }
    function tracer(g, pts, part) {
      const n = part === undefined ? pts.length - 1 : part * (pts.length - 1); g.beginPath();
      for (let j = 0; j <= Math.floor(n); j++) j ? g.lineTo(pts[j][0], pts[j][1]) : g.moveTo(pts[j][0], pts[j][1]);
      const j = Math.floor(n), f = n - j; if (f > 0 && pts[j + 1]) g.lineTo(pts[j][0] + (pts[j + 1][0] - pts[j][0]) * f, pts[j][1] + (pts[j + 1][1] - pts[j][1]) * f);
    }
    function lienAllume(g, w, part, al) {
      const pts = liens[w]; if (!pts || pts.length < 2) return;
      const a = pts[0], b = pts[pts.length - 1], gr = g.createLinearGradient(a[0], a[1], b[0], b[1]);
      gr.addColorStop(0, rgba(C[w], 1)); gr.addColorStop(1, rgba(C[w + 1], 1));
      g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = gr;
      g.globalAlpha = 0.16 * al; g.lineWidth = 5; tracer(g, pts, part); g.stroke();
      g.globalAlpha = 0.85 * al; g.lineWidth = 1.2; tracer(g, pts, part); g.stroke();
      g.globalAlpha = 0.6 * al; g.strokeStyle = rgba(BL, 1); g.lineWidth = 0.5; tracer(g, pts, part); g.stroke();
    }
    function lienEteint(g, w, al) {                                               // pointillé de points fins
      const pts = liens[w]; if (!pts) return; const ouvert = etat(w) !== 'lock';
      g.globalAlpha = 1; g.fillStyle = rgba(ouvert ? C[w] : GRIS, (ouvert ? 0.5 : 0.28) * al);
      for (let j = 1; j < pts.length - 1; j += 2) g.fillRect(pts[j][0] - 0.6, pts[j][1] - 0.6, 1.2, 1.2);
    }
    /* anneau de progression : 1 point par niveau sur un anneau fin, arc partiel = part réussie (jamais de pastille pleine) */
    function anneau(g, w, part, al) {
      const p = P[w], m = mondes[w - 1], tot = m.tot || 12, rr = p.R + 7, c = C[w];
      g.globalAlpha = 0.22 * al; g.strokeStyle = rgba(BL, 1); g.lineWidth = 0.6; g.beginPath(); g.arc(p.x, p.y, rr, 0, TAU); g.stroke();
      if (part > 0) { g.globalAlpha = 0.9 * al; g.strokeStyle = rgba(c, 1); g.lineWidth = 1.3; g.beginPath(); g.arc(p.x, p.y, rr, -Math.PI / 2, -Math.PI / 2 + TAU * part); g.stroke(); }
      for (let j = 0; j < tot; j++) { const an = -Math.PI / 2 + (j + 0.5) * TAU / tot, on = j < part * tot - 0.01, x = p.x + Math.cos(an) * (rr + 4), y = p.y + Math.sin(an) * (rr + 4);
        g.globalAlpha = (on ? 0.95 : 0.3) * al; g.fillStyle = rgba(on ? (j < (m.maitrise || 0) ? BL : c) : BL, 1); g.beginPath(); g.arc(x, y, on ? 1.1 : 0.7, 0, TAU); g.fill(); }
    }
    function corps(g, w, e, al) {                                                 // voile sombre sous le nœud (contraste) ; terminé : éclairé de sa couleur
      const p = P[w], c = C[w];
      const o2 = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.R * 1.6); o2.addColorStop(0, rgba(NUIT, 0.58 * al)); o2.addColorStop(1, rgba(NUIT, 0));
      g.globalAlpha = 1; g.fillStyle = o2; g.fillRect(p.x - p.R * 2, p.y - p.R * 2, p.R * 4, p.R * 4);
      if (e === 'done') { const f = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.R * 2.2); f.addColorStop(0, rgba(c, 0.32 * al)); f.addColorStop(0.5, rgba(c, 0.1 * al)); f.addColorStop(1, rgba(c, 0)); g.fillStyle = f; g.fillRect(p.x - p.R * 2.3, p.y - p.R * 2.3, p.R * 4.6, p.R * 4.6); }
    }
    let prog = [];                                                                // part affichée de chaque anneau (animée)
    function dessinerStatique() {
      const g = cS.getContext('2d'); g.setTransform(dprS, 0, 0, dprS, 0, 0); g.clearRect(0, 0, l, h);
      g.globalAlpha = 1;
      if (!surImg) for (let w = 1; w <= N; w++) { const p = P[w], zc = (D.zones || {})[w] || C[w], r = p.Z * 2.2, f = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, r); f.addColorStop(0, rgba(zc, 0.55)); f.addColorStop(1, rgba(zc, 0)); g.fillStyle = f; g.fillRect(p.x - r, p.y - r, 2 * r, 2 * r); }   // écran hors format : zones peintes sous les nœuds déplacés
      for (const [a, b] of LIENS2) {                                              // constellation secondaire, très pâle
        const ok = etat(a) !== 'lock' && etat(b) !== 'lock'; g.globalAlpha = ok ? 0.16 : 0.07; g.strokeStyle = rgba(ok ? mix(C[a], C[b], 0.5) : GRIS, 1); g.lineWidth = 0.5;
        g.setLineDash([1, 5]); g.beginPath(); g.moveTo(P[a].x, P[a].y); g.lineTo(P[b].x, P[b].y); g.stroke(); g.setLineDash([]);
      }
      for (let w = 1; w < N; w++) { if (cache(w, 'lien')) { lienEteint(g, w, 1); continue; } if (etat(w) === 'done') lienAllume(g, w, undefined, 1); else lienEteint(g, w, 1); }
      for (let w = 1; w <= N; w++) {
        const e = cache(w, 'noeud') ? 'lock' : etat(w); corps(g, w, e, 1);
        if (e === 'lock') { SIG[NOMS[w]](g, P[w].x, P[w].y, P[w].R, 7 + w, GRIS, GRIS, 0.32, 0.6); const p = P[w]; g.globalAlpha = 0.3; g.setLineDash([2, 4]); g.strokeStyle = rgba(GRIS, 1); g.lineWidth = 0.6; g.beginPath(); g.arc(p.x, p.y, p.R + 7, 0, TAU); g.stroke(); g.setLineDash([]); }
        else if (!anims.some(a => a.w === w && a.type === 'prog')) anneau(g, w, prog[w], 1);
      }
      g.globalAlpha = 1;
    }
    function cache(w, quoi) { return anims.some(a => a.cache && a.cache[quoi] === w); }

    /* ---------- boutons : ≥ 52 px, numéro + nom + progression, texte DOM net et contrasté ---------- */
    function construireBoutons() {
      calque.innerHTML = ''; btn = [];
      for (let w = 1; w <= N; w++) {
        const p = P[w], b = document.createElement('button'), d = Math.max(52, p.R * 2 + 18); b.type = 'button'; b.className = 'qxk-m';
        b.style.cssText = `left:${p.x - d / 2}px;top:${p.y - d / 2}px;width:${d}px;height:${d}px`;
        b.innerHTML = `<span class="qxk-l ${p.cote > 0 ? 'd' : 'g'}" style="${p.cote > 0 ? 'left' : 'right'}:${Math.round(d / 2 + p.R + 13)}px"><i></i><b></b><em></em></span>`;
        b.onclick = (ev) => {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          if (etat(w) === 'lock') { if (o.son) o.son('ui_tap'); refus = { w, t: temps() }; boucle(); return; }
          if (o.choisir) o.choisir(w);
        };
        b.addEventListener('pointerdown', () => { b.classList.add('vise'); setTimeout(() => b.classList.remove('vise'), 1400); });
        calque.appendChild(b); btn[w] = b;
      }
      majBoutons();
    }
    function majBoutons() {
      for (let w = 1; w <= N; w++) {
        const b = btn[w]; if (!b) continue; const e = cache(w, 'noeud') ? 'lock' : etat(w), m = mondes[w - 1], lb = b.firstChild;
        b.className = 'qxk-m ' + e + (b.classList.contains('eveil') ? ' eveil' : '');
        lb.children[0].textContent = (w < 10 ? '0' : '') + w;
        lb.children[1].textContent = m.nom || NOMS[w];
        lb.children[2].textContent = e === 'lock' ? '' : (m.fait || 0) + ' / ' + (m.tot || 12);
        lb.style.setProperty('--c', rgba(C[w], 1));
        b.setAttribute('aria-label', (m.nom || '') + (e === 'lock' ? ', verrouillé' : ', ' + (m.fait || 0) + ' sur ' + (m.tot || 12) + (e === 'done' ? ', terminé' : e === 'cur' ? ', en cours' : '')));
        if (e === 'lock') b.setAttribute('aria-disabled', 'true'); else b.removeAttribute('aria-disabled');
      }
      sousTitre();
    }

    /* ---------- canevas vivant : décor (poussières à 3 échelles teintées par zone, nébuleuses, filaments, scintillements, ondes, vocabulaire de zone) ---------- */
    const POUSS = [];
    for (let i = 0; i < 220; i++) { const c = i % 15 === 14 ? 2 : i % 3 === 2 ? 1 : 0; POUSS.push({ c, u: hache(i * 1.7), v: hache(i * 2.3 + 1), ph: hache(i * 5.1) * TAU, vit: [4, 10, 20][c] * (0.6 + hache(i) * 0.8), k: hache(i * 7.9 + 3) }); }
    function zoneDe(x, y) { let b = 1, bd = 1e12; for (let w = 1; w <= N; w++) { const dx = x - P[w].x, dy = y - P[w].y, d = dx * dx + dy * dy; if (d < bd) { bd = d; b = w; } } return b; }
    function poussiere(g, t) {
      const lim = Math.round(220 * Math.max(0.3, qualite));
      for (let i = 0; i < lim; i++) {
        const p = POUSS[i]; if (p.c === 2 && niveau > 4) continue;
        const s = [0.7, 1.5, 9 + 7 * p.k][p.c], al = [0.6, 0.8, 0.11][p.c] * (0.45 + 0.55 * Math.sin(t * (0.9 + 1.5 * p.k) + p.ph));
        const x = ((p.u * (l + 40) + Math.sin(t * 0.09 + p.ph) * [14, 28, 50][p.c] + t * [1.2, 3, 7][p.c]) % (l + 40)) - 20, y = ((p.v * (h + 60) - t * p.vit) % (h + 60) + h + 60) % (h + 60) - 30;
        const w = p.c ? zoneDe(x, y) : 0;
        pt(g, x, y, s, p.c === 2 ? C[w] : p.c ? CM[w] : BL, al);
      }
    }
    const SCINT = []; for (let i = 0; i < 50; i++) SCINT.push([hache(i * 3.1 + 7), hache(i * 4.7 + 2), 0.6 + 1.6 * hache(i * 9.1), hache(i * 6.3) * TAU]);
    function decor(g, t) {
      const fil = niveau < 4, X1 = racine.__QXK_SANS || '';
      if (fil) for (let k = 0; k < 6; k++) {                                      // longs filaments qui traversent l'écran en ondulant
        const y0 = ((hache(k * 5.3 + 1) * (h + 200) - t * (5 + k * 2.3)) % (h + 200) + h + 200) % (h + 200) - 100;
        trait(g, CM[1 + (k * 4 + 2) % N], 0.3, 0.6); g.beginPath();
        for (let j = 0; j <= 22; j++) { const x = -20 + j * (l + 40) / 22, y = y0 + Math.sin(x * 0.008 + t * 0.25 + k * 2) * 60 + Math.sin(x * 0.023 - t * 0.2 + k) * 15 + (j - 11) * (k - 2.5) * 3; j ? g.lineTo(x, y) : g.moveTo(x, y); }
        g.stroke();
      }
      const ns = Math.round(50 * Math.max(0.3, qualite));
      for (let i = 0; i < ns; i++) { const s = SCINT[i], v = Math.pow(0.5 + 0.5 * Math.sin(t * s[2] + s[3]), 8); if (v > 0.03) pt(g, s[0] * l, s[1] * h, 1 + 1.6 * v, BL, 0.95 * v); }
      for (let w = 1; w <= N; w++) {                                              // vocabulaire de mouvement de chaque zone
        const p = P[w], e = cache(w, 'noeud') ? 'lock' : etat(w), al = e === 'lock' ? 0.5 : 1;
        if (X1.indexOf('z') < 0) { PG = 1.55; AMB[NOMS[w]](g, p.x, p.y, p.Z, t * 1.7 + w * 11.3, C[w], C2[w], al * 1.6, qualite * 2.3, fil); PG = 1; }
        if (fil && e !== 'lock') for (let j = 0; j < 2; j++) { const s = frac(t / (4.5 + 2.5 * hache(w)) + hache(w * 3.3) + j * 0.5); trait(g, C[w], 0.42 * (1 - s) * (1 - s), 0.6); g.beginPath(); g.arc(p.x, p.y, p.R + 8 + p.Z * 1.15 * s, 0, TAU); g.stroke(); }
      }
      if (niveau < 5) for (let e = 0; e < 2; e++) {                               // événements rares : traînées fines qui traversent une zone
        const T = 4.3 + e * 2.9, k = Math.floor(t / T + e * 0.5), u = frac(t / T + e * 0.5) * T / 1.3; if (u >= 1) continue;
        const x0 = hache(k * 7.1 + e) * l, y0 = (0.12 + 0.7 * hache(k * 3.3 + e * 5)) * h, an = (hache(k * 1.7 + e) - 0.5) * 1.6 + (hache(k * 9.1) > 0.5 ? 0 : Math.PI), Lg = 150 + 130 * hache(k * 2.9), s = sortie(u), q0 = Math.max(0, s - 0.28);
        const hx = x0 + Math.cos(an) * Lg * s, hy = y0 + Math.sin(an) * Lg * s * 0.6, qx = x0 + Math.cos(an) * Lg * q0, qy = y0 + Math.sin(an) * Lg * q0 * 0.6, w = zoneDe(hx, hy), al = Math.sin(u * Math.PI);
        const gr = g.createLinearGradient(qx, qy, hx, hy); gr.addColorStop(0, rgba(C[w], 0)); gr.addColorStop(1, rgba(CM[w], 0.9));
        g.globalAlpha = al; g.strokeStyle = gr; g.lineWidth = 1.1; g.beginPath(); g.moveTo(qx, qy); g.lineTo(hx, hy); g.stroke(); pt(g, hx, hy, 1.6, BL, al);
      }
      if (niveau < 5) {                                                           // événements rares : éclat (onde + grains) dans une zone ouverte
        const T = 2.7, k = Math.floor(t / T), u = frac(t / T) * T / 1.4, ouv = []; for (let w = 1; w <= N; w++) if (etat(w) !== 'lock') ouv.push(w);
        if (u < 1 && ouv.length) { const w = ouv[Math.floor(hache(k * 5.7) * ouv.length) % ouv.length], p = P[w], an0 = hache(k * 2.3) * TAU, d = p.Z * (0.35 + 0.5 * hache(k * 1.1)), cx = p.x + Math.cos(an0) * d, cy = p.y + Math.sin(an0) * d, s = sortie(u);
          trait(g, CM[w], 0.7 * (1 - u), 0.8); g.beginPath(); g.arc(cx, cy, 3 + 26 * s, 0, TAU); g.stroke();
          for (let j = 0; j < 9; j++) { const an = hache(k + j * 3.1) * TAU, rr = (8 + 34 * hache(j * 1.3 + k)) * s; pt(g, cx + Math.cos(an) * rr, cy + Math.sin(an) * rr, 0.9, j % 2 ? BL : C[w], 0.9 * (1 - u)); } }
      }
    }
    function eclats(g, t) {                                                       // éclats lents qui parcourent les liens allumés
      for (let w = 1; w < N; w++) {
        if (etat(w) !== 'done' || cache(w, 'lien')) continue; const pts = liens[w]; if (!pts || pts.length < 2) continue;
        const s = frac(t * 0.16 + w * 0.37), j = s * (pts.length - 1), a = pts[Math.floor(j)], b = pts[Math.min(pts.length - 1, Math.floor(j) + 1)], f = j % 1;
        pt(g, a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, 1.5, mix(C[w], C[w + 1], s), 0.85 * Math.sin(s * Math.PI));
      }
    }
    function noeuds(g, t) {
      for (let w = 1; w <= N; w++) {
        const e = cache(w, 'noeud') ? 'lock' : etat(w); if (e === 'lock') continue; const p = P[w];
        const al = e === 'open' ? 0.92 : 1;
        PG = 1.35; SIG[NOMS[w]](g, p.x, p.y, p.R, t + w * 3.7, C[w], C2[w], al, qualite); PG = 1;
        pt(g, p.x, p.y, p.R * 0.5, C[w], (e === 'open' ? 0.3 : 0.42) + 0.14 * Math.sin(t * 1.3 + w)); pt(g, p.x, p.y, 1.9, BL, 0.95);                          // cœur : un point, pas une pastille
        if (e === 'cur') {                                                         // courant : respire (anneau fin qui s'ouvre + lueur lente)
          const s = frac(t / 2.6); trait(g, C[w], 0.55 * (1 - s), 1); g.beginPath(); g.arc(p.x, p.y, p.R + 7 + 18 * sortie(s), 0, TAU); g.stroke();
          const lu = sprite(C[w]); g.globalAlpha = 0.12 + 0.07 * Math.sin(t * 1.5); g.drawImage(lu, p.x - p.R * 2.4, p.y - p.R * 2.4, p.R * 4.8, p.R * 4.8);
        }
        if (e === 'done') { const an = t * 0.5 + w; pt(g, p.x + Math.cos(an) * (p.R + 7), p.y + Math.sin(an) * (p.R + 7), 1.2, C[w], 0.8); }
      }
    }
    /* ---------- animations : progression (arc qui croît), complétion (anneaux fins qui s'étendent, trait vers le suivant), déblocage ---------- */
    const DUR = { prog: 1.1, fin: 1.6, trace: 1.2, eveil: 1.1 };
    function jouer(av, ap) {                                                      // av, ap : états avant / après ; file d'animations à la suite
      let t = temps() + 0.35;
      for (let w = 1; w <= N; w++) {
        const a = av[w - 1] || {}, b = ap[w - 1] || {};
        if (!b.ouvert) continue;
        const ouvert = !a.ouvert, f0 = a.ouvert ? (a.fait || 0) : 0, f1 = b.fait || 0, fini = f1 >= (b.tot || 12) && f0 < (b.tot || 12);
        if (ouvert && w > 1) {                                                     // déblocage : le trait vient du monde précédent, le nœud s'éveille
          anims.push({ type: 'trace', w: w - 1, t0: t, d: DUR.trace, cache: { lien: w - 1, noeud: w } });
          anims.push({ type: 'eveil', w, t0: t + DUR.trace * 0.85, d: DUR.eveil, cache: { noeud: w } }); t += DUR.trace + 0.4;
        }
        if (f1 > f0) { anims.push({ type: 'prog', w, t0: t, d: DUR.prog, de: f0 / (b.tot || 12), a: f1 / (b.tot || 12) }); t += DUR.prog * 0.6; }
        if (fini) { anims.push({ type: 'fin', w, t0: t, d: DUR.fin, cache: w < N ? { lien: w } : null }); t += DUR.fin * 0.5;
          if (w < N && b.ouvert && ap[w] && ap[w].ouvert && a.ouvert && av[w] && av[w].ouvert) { anims.push({ type: 'trace', w, t0: t, d: DUR.trace, cache: { lien: w } }); t += DUR.trace; } }
      }
      anims.forEach(a => { if (a.type === 'prog') prog[a.w] = a.de; });
    }
    function animer(g, t) {
      if (!anims.length) return; let change = false;
      for (const a of anims.slice()) {
        const u = (t - a.t0) / a.d, p = P[a.w];
        if (u < 0) { if (a.type === 'prog') { g.globalAlpha = 1; anneau(g, a.w, a.de, 1); } continue; }
        if (!a.parti) { a.parti = 1; const sn = a.type === 'fin' ? 'map_done' : a.type === 'eveil' || a.type === 'prog' ? 'map_next' : ''; if (o.son && sn) o.son(sn); if (a.type === 'eveil' && btn[a.w]) btn[a.w].classList.add('eveil'); }
        if (u >= 1) { anims.splice(anims.indexOf(a), 1); change = true; if (a.type === 'prog') prog[a.w] = a.a; if (btn[a.w]) btn[a.w].classList.remove('eveil'); continue; }
        if (a.type === 'prog') {
          const v = a.de + (a.a - a.de) * lisse(u); anneau(g, a.w, v, 1);
          const an = -Math.PI / 2 + TAU * v, rr = p.R + 7; pt(g, p.x + Math.cos(an) * rr, p.y + Math.sin(an) * rr, 2.6, BL, 0.9 * Math.sin(u * Math.PI)); pt(g, p.x + Math.cos(an) * rr, p.y + Math.sin(an) * rr, 7, C[a.w], 0.3 * Math.sin(u * Math.PI));
        } else if (a.type === 'fin') {                                             // trois anneaux fins qui s'étendent + éclair doux
          for (let j = 0; j < 3; j++) { const s = borne((u - j * 0.14) / 0.75, 0, 1); if (s > 0 && s < 1) { trait(g, j === 1 ? BL : C[a.w], 0.75 * (1 - s), 1.2 - j * 0.3); g.beginPath(); g.arc(p.x, p.y, p.R + 8 + p.R * 3.2 * sortie(s), 0, TAU); g.stroke(); } }
          if (u < 0.35) pt(g, p.x, p.y, p.R * 0.6, C[a.w], 0.55 * (1 - u / 0.35));
          for (let j = 0; j < 12; j++) { const an = j * TAU / 12 + a.w, r = p.R + 8 + p.R * 2 * sortie(u); pt(g, p.x + Math.cos(an) * r, p.y + Math.sin(an) * r, 0.9, C[a.w], 0.8 * (1 - u)); }
        } else if (a.type === 'trace') {                                           // le trait se trace vers le monde suivant, une tête de lumière le précède
          const s = lisse(u), pts = liens[a.w]; if (!pts || pts.length < 2) continue; lienAllume(g, a.w, s, 1);
          const j = Math.min(pts.length - 2, Math.floor(s * (pts.length - 1))), f = s * (pts.length - 1) - j, hx = pts[j][0] + (pts[j + 1][0] - pts[j][0]) * f, hy = pts[j][1] + (pts[j + 1][1] - pts[j][1]) * f;
          pt(g, hx, hy, 2.8, BL, 1); pt(g, hx, hy, 8, mix(C[a.w], C[a.w + 1], s), 0.35);
          for (let m = 1; m < 5; m++) pt(g, hx + (hache(m + t) - 0.5) * 22, hy + (hache(m * 3 + t) - 0.5) * 22, 0.8, C[a.w], 0.5 * (1 - m / 5));
        } else if (a.type === 'eveil') {                                           // éveil : anneau qui se referme, signature qui s'allume
          const s = sortie(u); SIG[NOMS[a.w]](g, p.x, p.y, p.R, t, C[a.w], C2[a.w], s, qualite);
          trait(g, C[a.w], 0.8 * (1 - s), 1); g.beginPath(); g.arc(p.x, p.y, p.R + 7 + p.R * 2.5 * (1 - s), 0, TAU); g.stroke();
          pt(g, p.x, p.y, p.R * 0.5, C[a.w], 0.4 * Math.sin(u * Math.PI));
        }
      }
      if (change) { majBoutons(); dessinerStatique(); }
    }
    function dessinerVivant(t) {
      const g = cD.getContext('2d'); g.setTransform(dprD, 0, 0, dprD, 0, 0); g.clearRect(0, 0, l, h);
      const X0 = racine.__QXK_SANS || ''; g.globalCompositeOperation = 'lighter'; if (X0.indexOf('p') < 0) { decor(g, t); poussiere(g, t); } eclats(g, t); if (X0.indexOf('n') < 0) noeuds(g, t);
      g.globalCompositeOperation = 'source-over';
      if (refus) { const s = (temps() - refus.t) / 0.5; if (s >= 1) refus = null; else { const p = P[refus.w]; trait(g, GRIS, 0.6 * (1 - s), 1); g.beginPath(); g.arc(p.x + Math.sin(s * 30) * 3 * (1 - s), p.y, p.R + 7, 0, TAU); g.stroke(); } }
      animer(g, t); g.globalAlpha = 1;
    }
    const t0 = (racine.performance ? performance.now() : Date.now()) / 1000 - 5;
    const temps = () => (racine.performance ? performance.now() : Date.now()) / 1000 - t0;
    function visible() { return !detruit && R0.isConnected && R0.getClientRects().length > 0 && !document.hidden; }
    let nVis = 0, attente = 0, pause = false, pendant = null;
    function image() {
      raf = 0; if (detruit) return;
      if (!l) { if (!disposer()) { if (++attente < 120) raf = racine.requestAnimationFrame(image); return; } if (pendant) { const pd = pendant; pendant = null; jouer(pd[0], pd[1]); dessinerStatique(); } }
      if ((++nVis % 20) === 0 && !visible()) { pause = true; return; }
      const t = temps(), dt = Math.min(0.05, Math.max(0.001, t - tPrec)); tPrec = t;
      const fige = reduit() && !anims.length && !refus, a0 = performance.now();
      if (fond && !fige) fond.update(dt, { x: l * (0.5 + 0.35 * Math.sin(t * 0.05)), y: h * (0.5 + 0.35 * Math.cos(t * 0.037)) });
      dessinerVivant(fige ? 12 : t);
      if (racine.__QXK_STRICT) cD.getContext('2d').getImageData(0, 0, 1, 1);
      const ms = performance.now() - a0; mes.s += ms; mes.n++; mes.fen.push(ms); if (mes.fen.length > 90) mes.fen.shift();
      if (o.auto !== false && !racine.__QXK_FIXE && mes.fen.length === 90 && niveau < 5) {              // gouverneur : 6 niveaux, un cran de moins au-delà de 6 ms / image
        const moy = mes.fen.reduce((x, y) => x + y, 0) / 90;
        if (moy > 6) { niveau++; qualite = NIV[niveau][0]; mes.fen = []; const d0 = dprD; dprD = Math.min(dprS, NIV[niveau][1]); if (d0 !== dprD) { cD.width = Math.round(l * dprD); cD.height = Math.round(h * dprD); } if (fond) fond.regler({ qualite: NIV[niveau][2] }); neb.style.display = niveau < 4 ? '' : 'none'; }
      }
      if (!fige) raf = racine.requestAnimationFrame(image);
    }
    function boucle() { if (!raf && !detruit) { pause = false; raf = racine.requestAnimationFrame(image); } }
    function surVisibilite() { if (!document.hidden && pause) boucle(); }
    function surTaille() { if (!detruit) { l = 0; boucle(); } }
    document.addEventListener('visibilitychange', surVisibilite); racine.addEventListener('resize', surTaille);
    function appliquer(nv, crt, anime) {
      const av = mondes; mondes = nv.map(m => Object.assign({}, m)); if (crt !== undefined) courant = crt;
      for (let w = 1; w <= N; w++) prog[w] = mondes[w - 1].ouvert ? (mondes[w - 1].fait || 0) / (mondes[w - 1].tot || 12) : 0;
      anims = [];
      if (anime && !reduit()) { if (l) jouer(av, mondes); else pendant = [av, mondes]; }
      else if (anime && o.son && av.some((a, i) => (a.fait || 0) < (mondes[i].fait || 0))) o.son('map_done');
      if (l) { majBoutons(); dessinerStatique(); }
      if (o.memoire !== false) ls(o.memoire || 'qxconst_vu', JSON.stringify(mondes.map(m => ({ o: m.ouvert ? 1 : 0, f: m.fait || 0, t: m.tot || 12 }))));
      boucle();
    }
    // à l'ouverture : animation de ce qui a changé depuis la dernière visite (progression réelle)
    let vu = null; if (o.memoire !== false) { try { vu = JSON.parse(ls(o.memoire || 'qxconst_vu') || 'null'); } catch (e) { vu = null; } }
    const inst = {
      etats(nv, crt) { appliquer(nv, crt, true); },
      mesure() { return { ms: mes.n ? mes.s / mes.n : 0, images: mes.n, qualite, niveau, dpr: dprD }; },
      regler(r) { if (r.niveau !== undefined) { niveau = borne(r.niveau | 0, 0, 5); qualite = NIV[niveau][0]; l = 0; } else if (r.qualite !== undefined) { niveau = r.qualite >= 1 ? 0 : r.qualite > 0.6 ? 2 : 4; qualite = NIV[niveau][0]; l = 0; } if (r.sobre !== undefined) o.sobre = r.sobre; mes = { s: 0, n: 0, fen: [] }; boucle(); },
      animations() { return anims.length; },
      detruire() {
        detruit = true; if (raf) racine.cancelAnimationFrame(raf); raf = 0;
        document.removeEventListener('visibilitychange', surVisibilite); racine.removeEventListener('resize', surTaille);
        if (fond) fond.detruire(); R0.remove(); hote.classList.remove('qxk-on');
      }
    };
    cur = inst;
    if (vu && vu.length === mondes.length) { const nv = mondes; mondes = vu.map(v => ({ ouvert: !!v.o, fait: v.f, tot: v.t })).map((m, i) => Object.assign({}, nv[i], m)); appliquer(nv, courant, true); }
    else appliquer(mondes, courant, false);
    if (disposer() && pendant) { const pd = pendant; pendant = null; jouer(pd[0], pd[1]); dessinerStatique(); }
    boucle();
    return inst;
  }
  function detruire() { if (cur) { const c = cur; cur = null; c.detruire(); } }

  let styleOk = false;
  function poserStyle() {
    if (styleOk) return; styleOk = true;
    const s = document.createElement('style');
    s.textContent = `
.qxk-on>.panel{display:none!important}
.qxk{position:absolute;inset:0;overflow:hidden;z-index:2;font-family:inherit;color:#EAF6FF}
.qxk-neb{position:absolute;inset:0;pointer-events:none}
.qxk-neb i{position:absolute;border-radius:50%;will-change:transform,opacity;animation:qxkNeb 20s ease-in-out infinite alternate}
@keyframes qxkNeb{from{transform:translate(calc(var(--dx)*-1),calc(var(--dy)*-1)) scale(.72);opacity:.35}to{transform:translate(var(--dx),var(--dy)) scale(1.3);opacity:1}}
.qxk-tete{position:absolute;left:0;right:0;top:0;padding:calc(env(safe-area-inset-top,0px) + 18px) 20px 26px;text-align:center;pointer-events:none;
  background:linear-gradient(180deg,rgba(5,7,14,.82),rgba(5,7,14,0))}
.qxk-k{margin:0;font-size:12px;font-weight:600;letter-spacing:.32em;text-transform:uppercase;color:#EAF6FF;text-shadow:0 0 12px rgba(166,120,255,.35)}
.qxk-s{margin:6px auto 0;max-width:300px;font-size:11.5px;line-height:1.45;color:rgba(214,226,240,.72)}
.qxk-pied{position:absolute;left:0;right:0;bottom:0;padding:24px 20px calc(env(safe-area-inset-bottom,0px) + 16px);display:flex;justify-content:center;
  background:linear-gradient(0deg,rgba(5,7,14,.85),rgba(5,7,14,0))}
.qxk-fermer{min-width:132px;min-height:44px;padding:0 22px;border-radius:999px;border:1px solid rgba(234,246,255,.22);background:rgba(10,14,26,.55);
  color:#EAF6FF;font:inherit;font-size:14px;letter-spacing:.04em;cursor:pointer;-webkit-tap-highlight-color:transparent;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.qxk-m{position:absolute;margin:0;padding:0;border:0;border-radius:50%;background:transparent;cursor:pointer;-webkit-tap-highlight-color:transparent;font:inherit;color:#EAF6FF}
.qxk-m.lock{cursor:default}
.qxk-m:focus-visible{outline:1px solid rgba(234,246,255,.8);outline-offset:-3px}
.qxk-l{position:absolute;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;white-space:nowrap;pointer-events:none;line-height:1.15;
  text-shadow:0 0 4px rgba(3,5,10,1),0 0 10px rgba(3,5,10,.9);transition:opacity .6s}
.qxk-l.d{align-items:flex-start;text-align:left}.qxk-l.g{align-items:flex-end;text-align:right}
.qxk-l i{font-style:normal;font-size:10px;letter-spacing:.2em;color:var(--c);opacity:.95;font-variant-numeric:tabular-nums}
.qxk-l b{font-size:13.5px;font-weight:600;letter-spacing:.06em}
.qxk-l em{font-style:normal;font-size:10.5px;color:rgba(214,226,240,.78);font-variant-numeric:tabular-nums;margin-top:1px}
.qxk-m.lock .qxk-l{opacity:.5}.qxk-m.lock .qxk-l i{color:#AFC0D6}
.qxk-m.done .qxk-l em{color:var(--c)}
.qxk-pied{left:0;right:auto;top:0;bottom:auto;padding:calc(env(safe-area-inset-top,0px) + 4px) 0 0 4px;display:block}
.qxk-fermer{min-width:0;width:44px;height:44px;min-height:44px;padding:0;border:0;border-radius:0;display:flex;align-items:center;justify-content:center;opacity:.75}
/* R455 b : texte très discret, accentué seulement au monde visé / courant */
.qxk-l{opacity:.34;text-shadow:0 0 6px rgba(3,5,10,.8);transition:opacity .35s}
.qxk-l i{font-size:7.5px;letter-spacing:.24em;opacity:.9}
.qxk-l b{font-size:9.5px;font-weight:300;letter-spacing:.16em;text-transform:uppercase}
.qxk-l em{font-size:7.5px;font-weight:300;margin-top:2px;letter-spacing:.08em}
.qxk-m.lock .qxk-l{opacity:.16}.qxk-m.cur .qxk-l{opacity:.6}
.qxk-m:not(.lock):hover .qxk-l,.qxk-m:not(.lock):active .qxk-l,.qxk-m:focus-visible .qxk-l,.qxk-m.vise .qxk-l{opacity:1}
.qxk-k{font-size:9.5px;font-weight:400;opacity:.5;text-shadow:none}.qxk-s{font-size:9px;opacity:.55}.qxk-tete,.qxk-pied{background:none}
.qxk-fermer{font-size:11px;font-weight:300;letter-spacing:.14em;background:transparent;border-color:rgba(234,246,255,.12);color:rgba(234,246,255,.6);backdrop-filter:none;-webkit-backdrop-filter:none}
.qxk-m.eveil .qxk-l{animation:qxkEveil 1s ease-out}
@keyframes qxkEveil{from{opacity:.1;transform:translateY(-50%) translateX(-4px)}to{opacity:1;transform:translateY(-50%)}}`;
    document.head.appendChild(s);
  }

  racine.QXCONST = { version: 2, actif, monter, detruire, PLAN: PLAN0, get instance() { return cur; } };
})(typeof window !== 'undefined' ? window : globalThis);
