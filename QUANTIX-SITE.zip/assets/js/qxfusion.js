/* Généré par outils/integrer_tout.py depuis src/qxfusion.js + src/fusion-atlas.js (SPEC, NOUV) + retours. */
/* =====================================================================
   QXFU — FUSION DES DÉCORS DANS LE JEU (fond10).
   Pour chaque monde : nouveaux éléments (QXPOOL, réglages par défaut de l'atlas fusion)
   + anciens éléments retenus par Simon (retours du 12 nov.), dessinés par le VRAI code
   du jeu d'origine (copie isolée QXANCIENS, rendreF) dans un calque « écran » posé
   au-dessus du décor cuit (dans .qxf) et sous le canevas du jeu.
   SPEC / NOUV / retours : recopiés tels quels de l'atlas fusion (fond8/src/fusion.js)
   par outils/integrer_tout.py — une seule source.
   Différences avec l'atlas (simulacre) : vraie géométrie du niveau (aimant principal,
   coupe), vraie bille, vrais rebonds (BUS), plateau = écran du jeu.
   ===================================================================== */
(function (racine) {
  'use strict';
  const RETOURS = [{"monde":"atelier","id":"neb","element":"nébuleuses","notes":"Garde nébuleuse","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"atelier","id":"dust","element":"poussières","notes":"Garde poussière","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"atelier","id":"helices","element":"hélices du niveau","notes":"Pas d'hélice , trop présent","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"atelier","id":"fantome","element":"hélice fantôme","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"atelier","id":"voiles","element":"voiles en volume (globe · globe · coquille double)","notes":"Garde uniquement les wire sphériques mais remaniées","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"fonderie","id":"neb","element":"nébuleuses","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"fonderie","id":"dust","element":"braises (poussière montante)","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"fonderie","id":"voiles","element":"voiles en volume (tétraèdre · tétraèdre · tétraèdre)","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"fonderie","id":"traces","element":"traces en spirale (chambre à bulles)","notes":"C'est un doublon je pense donc on garde le nouveau uniquement . Ou on garde mais très léger comme ces réglages par exemple","macros":{"dens":4,"lum":0.65,"tail":0.5,"vit":4},"etat":"rebond"},{"monde":"fonderie","id":"bulles","element":"bulles montantes","notes":"On ne garde pas","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"fonderie","id":"amb","element":"ambiance du moteur : braises qui montent","notes":"On garde","macros":{"dens":2,"lum":3.1,"tail":0.65,"vit":1.1},"etat":"repos"},{"monde":"chaine","id":"neb","element":"nébuleuses","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"chaine","id":"dust","element":"poussières","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"chaine","id":"voiles","element":"voiles en volume (tore · tore · tore)","notes":"Garde uniquement la partie en haut à droite ( plus large)","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"chaine","id":"anneau","element":"anneau de stockage","notes":"Utilise en fond du nouvel anneau pour donner du crédit et de la profondeur","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"chaine","id":"synchro","element":"rayon synchrotron","notes":"On ne garde pas","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"rebond"},{"monde":"chaine","id":"tore","element":"cellules du tore","notes":"On garde . Un peu plus lumineux, un peu plus grand","macros":{"dens":1,"lum":1.8,"tail":1.45,"vit":1},"etat":"repos"},{"monde":"chaine","id":"amb","element":"ambiance du moteur : graduations qui défilent","notes":"On garde","macros":{"dens":1,"lum":2.95,"tail":0.75,"vit":0.65},"etat":"repos"},{"monde":"glacier","id":"amb","element":"ambiance du moteur : neige qui tombe","notes":"On garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"glacier","id":"condensat","element":"condensat qui pulse","notes":"On garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"glacier","id":"tourbillons","element":"réseau de tourbillons","notes":"On supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"glacier","id":"young","element":"franges de Young","notes":"On garde moins rapide et à intégrer savamment","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"glacier","id":"voiles","element":"voiles en volume (globe · coquille double · globe)","notes":"On supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"glacier","id":"dust","element":"poussières","notes":"On garde subtilement","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"glacier","id":"neb","element":"nébuleuses","notes":"On garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"soufflerie","id":"neb","element":"nébuleuses","notes":"On garde partout","macros":{"dens":1,"lum":1,"tail":1.15,"vit":2.6},"etat":"repos"},{"monde":"soufflerie","id":"dust","element":"poussières","notes":"On garde","macros":{"dens":0.7,"lum":0.55,"tail":1.2,"vit":0.4},"etat":"bille"},{"monde":"soufflerie","id":"voiles","element":"voiles en volume (disque (galaxie) · coquille double · cylindre (solénoïde))","notes":"On garde mais indépendant les une des autres et à placer avec parcimonie","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"soufflerie","id":"helices","element":"hélices du niveau","notes":"On supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"soufflerie","id":"fantome","element":"hélice fantôme","notes":"On garde","macros":{"dens":1,"lum":1,"tail":1.5,"vit":0.45},"etat":"repos"},{"monde":"soufflerie","id":"amb","element":"ambiance du moteur : traits de vent","notes":"On garde","macros":{"dens":1,"lum":2.7,"tail":0.7,"vit":1},"etat":"repos"},{"monde":"mecanique","id":"neb","element":"nébuleuses","notes":"On garde","macros":{"dens":1,"lum":0.55,"tail":1,"vit":1.85},"etat":"repos"},{"monde":"mecanique","id":"dust","element":"poussières","notes":"Garde","macros":{"dens":4,"lum":0.7,"tail":0.95,"vit":0.95},"etat":"bille"},{"monde":"mecanique","id":"voiles","element":"voiles en volume (réseau · tore · réseau)","notes":"Garde le motif en haut à dérouté","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"mecanique","id":"mech","element":"mécanique décorative","notes":"On garde . A utiliser intelligemment avec les nouveaux \nCelui ci est génial ( came)","macros":{"dens":1,"lum":1.7,"tail":1,"vit":1},"etat":"bille"},{"monde":"mecanique","id":"helices","element":"hélices du niveau","notes":"On garde mais plus léger moins rapide plus grand","macros":{"dens":1,"lum":0.55,"tail":2.1,"vit":0.4},"etat":"repos"},{"monde":"mecanique","id":"fantome","element":"hélice fantôme","notes":"On garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"mecanique","id":"amb","element":"ambiance du moteur : roues dentées en filigrane","notes":"On garde","macros":{"dens":1,"lum":3,"tail":0.9,"vit":1},"etat":"repos"},{"monde":"gravite","id":"neb","element":"nébuleuses","notes":"Garde","macros":{"dens":1,"lum":0.75,"tail":1,"vit":1.8},"etat":"repos"},{"monde":"gravite","id":"dust","element":"poussières","notes":"Garde","macros":{"dens":0.35,"lum":1,"tail":0.65,"vit":1},"etat":"bille"},{"monde":"gravite","id":"voiles","element":"voiles en volume (disque (galaxie) · coquille double · disque (galaxie))","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"gravite","id":"helices","element":"hélices du niveau","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"gravite","id":"fantome","element":"hélice fantôme","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"gravite","id":"amb","element":"ambiance du moteur : poussière qui tombe","notes":"Garde","macros":{"dens":2.25,"lum":4,"tail":0.8,"vit":1.55},"etat":"repos"},{"monde":"magnetisme","id":"neb","element":"nébuleuses","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"magnetisme","id":"dust","element":"poussières","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"magnetisme","id":"soie","element":"soie (fils + grain)","notes":"Garde mais animée","macros":{"dens":1,"lum":0.2,"tail":1.1,"vit":1.7},"etat":"repos"},{"monde":"magnetisme","id":"ferro4","element":"ferrofluide WebGL (ferro4)","notes":"J'aimerais vraiment qu'on puisse l'inclure. Comme si elle apparaissait sur certaine niveau comme un événement qui décompose le réel et qu'on ne pourrait expliquer","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"magnetisme","id":"ferro3","element":"ferrofluide 2D (ferro3)","notes":"Garde en apparition douce","macros":{"dens":1,"lum":0.55,"tail":0.85,"vit":3.3},"etat":"repos"},{"monde":"magnetisme","id":"amb","element":"ambiance du moteur : ondes concentriques du champ","notes":"Garde","macros":{"dens":1,"lum":1.5,"tail":1.5,"vit":0.65},"etat":"repos"},{"monde":"magnetisme","id":"ferro1","element":"ferrofluide v1 (ferro)","notes":"Garde ultra leger","macros":{"dens":1,"lum":0.25,"tail":1.65,"vit":4},"etat":"repos"},{"monde":"magnetisme","id":"ferro2","element":"ferrofluide vectoriel (ferro2)","notes":"Garde ultra léger (0,25)","macros":{"dens":1,"lum":0.25,"tail":1.05,"vit":0.1},"etat":"repos"},{"monde":"faille","id":"neb","element":"nébuleuses","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"faille","id":"dust","element":"poussières","notes":"Garde très leger","macros":{"dens":1.55,"lum":0.6,"tail":0.8,"vit":2.35},"etat":"bille"},{"monde":"faille","id":"voiles","element":"voiles en volume (nœud de trèfle · tore · nœud de trèfle)","notes":"Garde mais en deux éléments distincts à utiliser avec parcimonie","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"faille","id":"helices","element":"hélice du niveau","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"faille","id":"amb","element":"ambiance du moteur : ligne de balayage + trame","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"filaments","id":"neb","element":"nébuleuses","notes":"Garde leger","macros":{"dens":1,"lum":0.5,"tail":0.6,"vit":3.65},"etat":"repos"},{"monde":"filaments","id":"dust","element":"poussières","notes":"Garde leger","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"bille"},{"monde":"filaments","id":"voiles","element":"voiles en volume (nœud de trèfle · cylindre (solénoïde) · nœud de trèfle)","notes":"Garde le grand à droite ( point) et remanié l'autre pour ne pas qu'il ressemble trop à celui du monde d'avant","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"filaments","id":"helices","element":"hélices du niveau","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"filaments","id":"fantome","element":"hélice fantôme","notes":"Supprime","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"filaments","id":"amb","element":"ambiance du moteur : grains en suspension","notes":"Garde","macros":{"dens":2.2,"lum":3.65,"tail":1,"vit":1},"etat":"repos"},{"monde":"quantique","id":"neb","element":"nébuleuses","notes":"Garde léger","macros":{"dens":1,"lum":0.55,"tail":1,"vit":2.55},"etat":"repos"},{"monde":"quantique","id":"dust","element":"poussières","notes":"Garde très leger","macros":{"dens":0.4,"lum":0.6,"tail":1,"vit":0.4},"etat":"bille"},{"monde":"quantique","id":"voiles","element":"voiles en volume (coquille double · tétraèdre · réseau)","notes":"Garde","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"quantique","id":"helices","element":"hélices du niveau","notes":"Garde mais à utiliser avec parcimonie et élégance","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"quantique","id":"fantome","element":"hélice fantôme","notes":"Avec parcimonie et élégance si nécessaire","macros":{"dens":1,"lum":1,"tail":1,"vit":1},"etat":"repos"},{"monde":"quantique","id":"amb","element":"ambiance du moteur : ondes concentriques du champ","notes":"Trop proche de l'autre niveau , à changer mais garder","macros":{"dens":1,"lum":3.3,"tail":1,"vit":1},"etat":"repos"}];
  const R = {}; for (const r of RETOURS) R[r.monde + '|' + r.id] = r;
  const A = (src, o) => Object.assign({ src, id: src, esp: 'jeu' }, o || {});
  const SPEC = {
    atelier: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }), A('fantome'),
      A('voiles', { id: 'armillaire', nom: 'sphères armillaires (voiles remaniées)', remanie: 1, interp: 'Seules les sphères en fil sont gardées, refaites en sphères armillaires : équateur, 2 parallèles, 3 méridiens, nœuds ; la grande (proche) en trait doux, les petites en trait net.' })],
    fonderie: [A('neb', { esp: 'page' }), A('dust', { esp: 'page', nom: 'braises (poussière montante)' }), A('voiles'),
      A('traces', { on: false, interp: 'Doublon des nouvelles traces : éteint par défaut ; allumé = très léger, à tes réglages.' }),
      A('amb', { esp: 'page' })],
    chaine: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }),
      A('voiles', { id: 'voile', v: { sel: 'hd', R: 1.25, a: 1.35 }, nom: 'voile tore (haut à droite)', interp: 'Seule la voile du haut à droite, 1,25 × plus large (au-delà, ses points se diluent hors de l\'écran) et un peu plus dense en lumière (× 1,35).' }),
      A('anneau', { pl: { px: 180, py: 250, bx: 195, by: 392, s: 0.8 }, m: { lum: 0.7 }, interp: 'Posé derrière le nouvel anneau : plus petit (× 0,8), remonté de 23 px, plus pâle (× 0,7) — un second anneau au loin, pour la profondeur.' }),
      A('tore', { pl: { px: 223.2, py: 144 }, interp: 'Plus lumineux et plus grand, agrandi autour de son propre centre.' }),
      A('amb', { esp: 'page' })],
    glacier: [A('amb', { esp: 'page' }), A('condensat'),
      A('young', { pl: { px: 180, py: 29, bx: 195, by: 66, s: 1.3 }, m: { vit: 0.45, lum: 0.85 }, remanie: 1, interp: 'Plus lentes (× 0,45). Intégrées : les deux sources remontent au-dessus du terrain (dans le ciel), fronts 1,3 × plus grands, un peu plus pâles ; les arcs descendent sur le jeu.' }),
      A('dust', { esp: 'page', m: { lum: 0.5, dens: 0.7 }, interp: 'Gardées subtilement : luminosité × 0,5, densité × 0,7.' }), A('neb', { esp: 'page' })],
    soufflerie: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }),
      A('voiles', { cle: 'voile-disque', id: 'voile', nom: 'voile disque (galaxie)', v: { sel: 'k:disk', cx: 0.25, cy: -0.16, R: 0.85 }, cyc: { T: 26, dec: 0 }, remanie: 1, interp: 'Voile seule, posée dans le ciel au-dessus du terrain ; apparaît et s\'efface (cycle 26 s, décalé des deux autres).' }),
      A('voiles', { cle: 'voile-coquille', id: 'voile', nom: 'voile coquille double', v: { sel: 'k:shell2', cx: 0.9, cy: 0.5, R: 0.75 }, cyc: { T: 26, dec: 0.33 }, remanie: 1, interp: 'Voile seule, au bord droit, plus petite ; cycle décalé d\'un tiers.' }),
      A('voiles', { cle: 'voile-cylindre', id: 'voile', nom: 'voile cylindre (solénoïde)', v: { sel: 'k:cyl', cx: 0.1, cy: 1.08, R: 0.9 }, cyc: { T: 26, dec: 0.66 }, remanie: 1, interp: 'Voile seule, sous le terrain à gauche ; cycle décalé de deux tiers. Jamais les trois ensemble.' }),
      A('fantome'), A('amb', { esp: 'page' })],
    mecanique: [A('neb', { esp: 'page' }), A('dust', { esp: 'page', k: 0.45, interp: 'Allègement : intensité 0,45 (ta densité ×4 reste).' }),
      A('voiles', { id: 'voile', v: { sel: 'hd' }, k: 0.7, nom: 'voile (motif en haut à droite)', interp: 'Seul le motif du haut à droite est gardé (intensité 0,7 : allègement).' }),
      A('mech', { nom: 'mécanique décorative (niveau)', cyc: { T: 28, dec: 0.5, min: 0 }, interp: 'Mécanismes posés par le niveau, à ta luminosité. Allègement : en alternance avec les cadrans (cycle 28 s) — une seule famille de mécanisme visible à la fois.' }),
      A('mech', { cle: 'came', nom: 'came (grande, en fond)', v: { mech: 'cam' }, pl: { px: 180, py: 240, bx: 312, by: 122, s: 1.7 }, m: { lum: 0.5, vit: 0.6 }, remanie: 1, interp: 'Ta came préférée, en grand et en fond (hors du terrain, coin haut droit, × 1,7, pâle, lente) : un plan lointain derrière les cadrans nouveaux.' }),
      A('helices', { on: false, interp: 'Allègement : éteintes par défaut (case pour les rallumer).' }), A('fantome', { on: false, interp: 'Allègement : éteinte par défaut.' }), A('amb', { esp: 'page', on: false, interp: 'Allègement : éteintes par défaut (même famille que les mécanismes).' })],
    gravite: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }), A('amb', { esp: 'page' })],
    magnetisme: [A('neb', { esp: 'page' }),
      A('soie', { remanie: 1, cad: 3, interp: 'Animée : les nappes de fils tanguent lentement et leur moiré glisse 4 × plus vite.', masque: 1 }),
      A('ferro4', { ev: 1, masque: 1, remanie: 1, centre: 1, interp: 'Événement rare : le ferrofluide surgit autour des aimants, s\'étend, « décompose » le décor (désaturé, déphasé) puis se retire. Ici toutes les 30 s (et bouton). Dans le jeu : certains niveaux seulement. Sans GPU : remplacé par le ferrofluide 2D.' }),
      A('ferro3', { masque: 1, cad: 3, centre: 1, cyc: { T: 22, dec: 0.5, min: 0 }, interp: 'Apparition douce : se lève et s\'efface (cycle 22 s). Centré, comme les autres ferrofluides, sur l\'aimant principal du nouveau décor.' }),
      A('amb', { esp: 'page' }),
      A('ferro1', { masque: 1, cad: 4, centre: 1, on: false, interp: 'Ultra léger (luminosité 0,25). Éteint par défaut (budget ms/image).' }), A('ferro2', { masque: 1, cad: 8, centre: 1, on: false, interp: 'Ultra léger (luminosité 0,25). Éteint par défaut (budget ms/image).' })],
    faille: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }),
      A('voiles', { cle: 'voile-noeud', id: 'voile', nom: 'voile nœud de trèfle', v: { sel: 'k:knot' }, cyc: { T: 30, dec: 0, min: 0.08 }, m: { lum: 0.85 }, remanie: 1, interp: 'Élément distinct, avec parcimonie : apparaît et s\'efface (30 s), en alternance avec le tore.' }),
      A('voiles', { cle: 'voile-tore', id: 'voile', nom: 'voile tore', v: { sel: 'k:torus' }, cyc: { T: 30, dec: 0.5, min: 0.08 }, m: { lum: 0.85 }, remanie: 1, interp: 'Élément distinct, en alternance avec le nœud.' }),
      A('amb', { esp: 'page' })],
    filaments: [A('neb', { esp: 'page' }), A('dust', { esp: 'page', m: { lum: 0.5 }, interp: 'Gardées légères : luminosité × 0,5.' }),
      A('voiles', { cle: 'voile-grand', id: 'voile', nom: 'voile (la grande, à droite)', v: { sel: 'grand' } }),
      A('voiles', { cle: 'voile-spire', id: 'voile', nom: 'spire de vortex (voile remaniée)', v: { sel: 'moyen', forme: 'spire', n: 460 }, remanie: 1, interp: 'L\'autre voile ne ressemble plus au nœud de la Faille : un ressort de points enroulé autour d\'un arc (filament tourbillonnaire).' }),
      A('amb', { esp: 'page' })],
    quantique: [A('neb', { esp: 'page' }), A('dust', { esp: 'page' }), A('voiles'),
      A('helices', { v: { max: 1, al: 0.7, sp: 0.6 }, interp: 'Avec parcimonie : une seule hélice, plus pâle (× 0,7), plus lente (× 0,6).' }),
      A('fantome', { on: false, m: { lum: 0.6 }, interp: '« Si nécessaire » : éteinte par défaut, pâle si allumée.' }),
      A('amb', { esp: 'page', v: { paquets: 1 }, nom: 'ambiance : paquets d\'onde (remaniée)', remanie: 1, interp: 'Plus de cercles concentriques (trop proches du Magnétisme) : deux paquets d\'onde traversent lentement le plateau et s\'étalent (dispersion) avant de renaître ailleurs, à deux échelles.' })],
    fluides: []
  };
  const NOUV = {   // défauts des nouveaux éléments (index du pool) : on, k0 (intensité), cyc (alternance)
    mecanique: { 0: { k0: 0.7 }, 2: { on: false }, 3: { cyc: { T: 28, dec: 0, min: 0 } }, 4: { k0: 0.6 } }
  };
  const NOMWD = { atelier: 1, fonderie: 2, chaine: 3, glacier: 4, soufflerie: 5, mecanique: 6, gravite: 7, magnetisme: 8, faille: 9, filaments: 10, quantique: 11, fluides: 12 };
  const OX = 15, OY = 165;   // l'ancien écran (360 × 480) posé sur le terrain du plateau de l'atlas : sert à relire les placements « pl »
  const lisse = x => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };

  /* ---------- éléments par monde (défauts de l'atlas : case et intensité d'origine) ---------- */
  const CACHE = {};
  function anciens(nom) {
    if (CACHE[nom]) return CACHE[nom];
    const L = [];
    for (const a of SPEC[nom] || []) {
      const r = R[nom + '|' + a.src] || null, m = Object.assign({ dens: 1, vit: 1, lum: 1, tail: 1 }, r ? r.macros : {});
      for (const k in a.m || {}) m[k] = (r && r.macros && r.macros[k] !== undefined && r.macros[k] !== 1) ? r.macros[k] : m[k] * a.m[k];
      if (a.on === false) continue;   // proposé mais éteint par défaut dans l'atlas → absent du jeu
      L.push({ cle: 'a:' + (a.cle || a.src), a, m, k0: a.k || 1, cv: null, cx: null });
    }
    return (CACHE[nom] = L);
  }

  /* ---------- pools recomposés (nouveaux éléments : intensité k0, éteints, alternance) — comme recomposer() de l'atlas ---------- */
  const R_DENS = /^(max|points|bulles|membres|nx|ny)$/, R_VIT = /^(vitesse|cadence|nage|pouls|derive|chute)$/, R_PER = /^periode$/,
    R_LUM = /^(alpha|alphaEveil|lumiere)$/, R_TAIL = /^(taille|rayon|longueur|ecart|portee|creux)$/;
  function transformer(o, m, mV) {
    if (Array.isArray(o)) return o.map(v => (v && typeof v === 'object') ? transformer(v, m, mV) : v);
    const r = {};
    for (const k in o) {
      const v = o[k], mul = f => (Array.isArray(v) ? v.map(x => x * f) : v * f);
      if (R_DENS.test(k) && typeof v === 'number') r[k] = Math.max(1, Math.round(v * m.dens * mV));
      else if (R_VIT.test(k) && (typeof v === 'number' || Array.isArray(v))) r[k] = mul(m.vit);
      else if (R_PER.test(k) && (typeof v === 'number' || Array.isArray(v))) r[k] = mul(1 / m.vit);
      else if (R_LUM.test(k) && typeof v === 'number') r[k] = (k === 'lumiere' && v > 1) ? v : Math.min(1, v * m.lum * (1 + 0.25 * (mV - 1)));
      else if (R_TAIL.test(k) && (typeof v === 'number' || Array.isArray(v))) r[k] = mul(m.tail);
      else if (v && typeof v === 'object') r[k] = transformer(v, m, mV);
      else r[k] = v;
    }
    return r;
  }
  /* BASE = QXF2_DONNEES.mondes ; vie = richesse (atlas : 2,4) → pool réglé à min(1,5 ; vie), densités × max(1, vie/1,5) */
  function configs(BASE, vie) {
    const out = {}, mV = Math.max(1, vie / 1.5);
    for (const nom of Object.keys(BASE)) {
      const P = BASE[nom].vivant.pool, N = NOUV[nom] || {}, alt = [];
      const pool = P.map((p0, i) => {
        const o = N[i] || {}, k = o.k0 || 1, on = o.on !== false;
        const q = transformer(p0, { dens: k > 1 ? 1 + (k - 1) * 0.6 : 1, vit: 1, lum: k, tail: 1 }, mV);
        const d0 = p0.densite === undefined ? 1 : p0.densite;
        q.densite = d0 * (on && !o.cyc ? 1 : 0);
        if (on && o.cyc) alt.push({ i, cyc: o.cyc, d0 });
        return q;
      });
      out[nom + '__fu'] = Object.assign({}, BASE[nom], { vivant: Object.assign({}, BASE[nom].vivant, { pool }) });
      if (alt.length) {
        const pool2 = pool.map((q, i) => { const a = alt.find(x => x.i === i); return Object.assign({}, q, { densite: a ? a.d0 : 0 }); });
        out[nom + '__fu2'] = Object.assign({}, BASE[nom], { vivant: Object.assign({}, BASE[nom].vivant, { pool: pool2 }) });
        out[nom + '__fu2'].__alt = alt.map(a => a.cyc);
      }
    }
    return out;
  }
  function enveloppeCyc(cyc, t) { const u = (((t / cyc.T) + cyc.dec) % 1), mn = cyc.min || 0; return mn + (1 - mn) * Math.pow(0.5 - 0.5 * Math.cos(u * 2 * Math.PI), 1.6); }

  /* ---------- contexte « à intensité » (copie de l'atlas) ---------- */
  function contexteAlpha(real) {
    const w = { mult: 1 }, proto = CanvasRenderingContext2D.prototype;
    let ga = 1, fs = null, ss = null; const pile = [];
    const ech = (v, r) => (typeof v === 'string' && r > 1.0001 && v.charCodeAt(3) === 97) ? v.replace(/,\s*([\d.e-]+)\)\s*$/, (x, al) => ',' + Math.min(1, parseFloat(al) * r) + ')') : v;
    const appliquer = () => {
      const voulu = ga * w.mult, eff = Math.min(1, voulu); real.globalAlpha = eff;
      const r = eff > 1e-6 ? voulu / eff : 1;
      if (fs !== null) real.fillStyle = ech(fs, r); if (ss !== null) real.strokeStyle = ech(ss, r);
    };
    for (const k of Object.getOwnPropertyNames(proto)) {
      if (k === 'constructor') continue;
      const d = Object.getOwnPropertyDescriptor(proto, k);
      if (typeof d.value === 'function') w[k] = d.value.bind(real);
      else if (d.get) Object.defineProperty(w, k, { get() { return real[k]; }, set(v) { real[k] = v; }, enumerable: true, configurable: true });
    }
    Object.defineProperty(w, 'globalAlpha', { get() { return ga; }, set(v) { ga = v; const voulu = ga * w.mult; if (w.mult > 1.0001 && (fs !== null || ss !== null)) appliquer(); else real.globalAlpha = Math.min(1, voulu); } });
    Object.defineProperty(w, 'fillStyle', { get() { return fs === null ? real.fillStyle : fs; }, set(v) { fs = v; if (w.mult > 1.0001) appliquer(); else real.fillStyle = v; } });
    Object.defineProperty(w, 'strokeStyle', { get() { return ss === null ? real.strokeStyle : ss; }, set(v) { ss = v; if (w.mult > 1.0001) appliquer(); else real.strokeStyle = v; } });
    w.save = () => { pile.push([ga, fs, ss]); real.save(); };
    w.restore = () => { const q = pile.pop(); if (q) { ga = q[0]; fs = q[1]; ss = q[2]; } real.restore(); };
    return w;
  }
  let masque = null;
  function masqueFondu() {   // bords fondus de l'ancien écran (ferrofluides, soie)
    if (masque) return masque;
    const w = 90, h = 120, F = 11, cv = document.createElement('canvas'); cv.width = w; cv.height = h; const x = cv.getContext('2d'), im = x.createImageData(w, h);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const d = Math.min(i + .5, w - i - .5, j + .5, h - j - .5) / F, u = lisse(d); im.data[(j * w + i) * 4 + 3] = Math.round(255 * u); }
    x.putImageData(im, 0, 0); return (masque = cv);
  }
  const gpuLogiciel = (function () {
    try {
      const gl = document.createElement('canvas').getContext('webgl2'); if (!gl) return true;
      const x = gl.getExtension('WEBGL_debug_renderer_info'), r = String(x ? gl.getParameter(x.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
      const lc = gl.getExtension('WEBGL_lose_context'); if (lc) lc.loseContext();
      return /swiftshader|llvmpipe|software|basic render/i.test(r);
    } catch (e) { return true; }
  })();

  /* ---------- instance (un niveau monté) ----------
     o = { nom, wd, n (rang 1–12 dans le monde), racine (div .qxf), l, h (hôte, px CSS), zone {x,y,l,h}, k (échelle jeu → px CSS),
           aimant [gx, gy] (coordonnées du jeu) | null, but {x,y,r} (px de l'hôte) | null, periodeEv (s) } */
  function creer(o) {
    const QA = racine.QXANCIENS, L0 = anciens(o.nom);
    if (!QA || !L0.length) return null;
    const dpr = Math.min(2, racine.devicePixelRatio || 1);
    const ca = document.createElement('canvas'); ca.className = 'qxfu';
    ca.width = Math.round(o.l * dpr); ca.height = Math.round(o.h * dpr);
    ca.style.cssText = 'position:absolute;left:0;top:0;width:' + o.l + 'px;height:' + o.h + 'px;mix-blend-mode:screen;pointer-events:none';
    o.racine.appendChild(ca);
    const fondEls = Array.from(o.racine.children).filter(x => x !== ca);
    const a = ca.getContext('2d'), envA = contexteAlpha(a);
    const st = { img: 0, clk: {}, dtc: {}, ev: { t0: -1, prochain: -1 }, filtre: '', fev: 0, res: 1, cadMul: 1, coupes: {}, fige: false, ms: 0, cout: {} };
    const f4 = !gpuLogiciel && !o.sansF4;
    const versHote = (gx, gy) => [o.zone.x + o.k * gx, o.zone.y + o.k * gy];
    function centreFerro(e) {
      const c = QA.centreF(e.a.id, o.wd, o.n, f4), m = o.aimant || [180, 250];
      return { px: c[0], py: c[1], gx: m[0], gy: m[1], s: 1 };
    }
    function enveloppe(e, t) {
      const A = e.a; let f = 1;
      if (A.cyc) f *= enveloppeCyc(A.cyc, t);
      if (A.ev) { const ev = st.ev; if (ev.t0 < 0) return 0; const u = t - ev.t0; f *= u < 0 ? 0 : u < 2 ? lisse(u / 2) : u < 6 ? 1 : u < 9 ? 1 - lisse((u - 6) / 3) : 0; }
      return f;
    }
    function rendre(dt, t, bille, sobre) {   // bille : { x, y, vx, vy } coordonnées du jeu, v en px/s
      if (sobre && st.fige) return;
      st.img++;
      const ballH = bille ? { x: o.zone.x + o.k * bille.x, y: o.zone.y + o.k * bille.y } : null;
      a.setTransform(1, 0, 0, 1, 0, 0); a.clearRect(0, 0, ca.width, ca.height);
      const ev = st.ev;
      if (ev.prochain < 0) ev.prochain = t + (o.premierEv || 12);   // premier événement 12 s après l'entrée dans le niveau
      if (o.wd === 8) { if (ev.t0 >= 0 && t - ev.t0 > 9.5) ev.t0 = -1; if (ev.t0 < 0 && t >= ev.prochain) { ev.t0 = t; ev.prochain = t + (o.periodeEv || 45); } }
      let fev = 0;
      for (const e of L0) {
        if (st.coupes[e.cle]) continue;
        let env = enveloppe(e, t); if (e.a.ev) fev = env;
        if (e.a.id === 'ferro3' && fev > 0) env *= 1 - fev;   // pendant l'événement, le ferrofluide de l'événement remplace le ferrofluide cyclique (même fluide, coût divisé)
        if (env <= 0.002) continue;
        const te0 = performance.now(), m = e.m, lum = m.lum * e.k0 * env, page = e.a.esp === 'page', id = e.a.id, cache = !!(e.a.masque || e.a.ev || e.a.cad);
        st.dtc[e.cle] = (st.dtc[e.cle] || 0) + dt;
        const cad = (e.a.cad || 1) * (cache ? st.cadMul : 1), aRendre = !cache || !e.cv || (st.img % cad === 0) || sobre;
        let T, ball = null, kt;
        if (page) {
          kt = m.tail; const cx = o.l / 2, cy = o.h / 2;
          T = id === 'neb' ? [kt * o.l / 360, kt * o.h / 480, cx * (1 - kt), cy * (1 - kt)] : [kt, kt, cx * (1 - kt), cy * (1 - kt)];
          if (id === 'dust' && ballH) ball = { x: cx + (ballH.x - cx) / kt, y: cy + (ballH.y - cy) / kt };
        } else {
          let px, py, gx, gy, s;
          if (e.a.centre) { const c = centreFerro(e); px = c.px; py = c.py; gx = c.gx; gy = c.gy; s = c.s; }
          else { const pl = e.a.pl || {}; px = pl.px === undefined ? 180 : pl.px; py = pl.py === undefined ? 240 : pl.py; gx = pl.bx === undefined ? px : pl.bx - OX; gy = pl.by === undefined ? py : pl.by - OY; s = pl.s || 1; }
          kt = s * m.tail;
          const Tg = [kt, kt, gx - px * kt, gy - py * kt];   // ancien écran → coordonnées du jeu (le jeu EST l'ancien écran, 360 × 480)
          T = [o.k * kt, o.k * kt, o.zone.x + o.k * Tg[2], o.zone.y + o.k * Tg[3]];
          if (bille) ball = { x: (bille.x - Tg[2]) / kt, y: (bille.y - Tg[3]) / kt, vx: bille.vx / 60, vy: bille.vy / 60 };
        }
        if (aRendre) {
          const dte = st.dtc[e.cle]; st.dtc[e.cle] = 0;
          st.clk[e.cle] = (st.clk[e.cle] || 600) + (sobre ? 0 : dte * 60 * m.vit);
          let cible, r = 1;
          if (cache) {   // calque propre (bords fondus, ouverture de l'événement, cadence réduite), résolution réduite si le budget l'exige
            r = st.res;
            const w = Math.max(2, Math.round(ca.width * r)), h = Math.max(2, Math.round(ca.height * r));
            if (!e.cv) { e.cv = document.createElement('canvas'); e.cx = e.cv.getContext('2d'); }
            if (e.cv.width !== w || e.cv.height !== h) { e.cv.width = w; e.cv.height = h; }
            cible = e.cx; cible.setTransform(1, 0, 0, 1, 0, 0); cible.clearRect(0, 0, w, h); cible.globalAlpha = 1;
          } else { cible = envA; envA.mult = lum; envA.globalAlpha = 1; envA.globalCompositeOperation = 'source-over'; }
          const d = dpr * r;
          cible.setTransform(d * T[0], 0, 0, d * T[1], d * T[2], d * T[3]);
          QA.rendreF(cible, { id, wd: o.wd, niveau: o.n, m, tick: st.clk[e.cle], ball, dt: sobre ? 0 : dte, L: o.l, H: o.h, v: e.a.v, f4 });
          if (cache && (e.a.masque || e.a.ev)) {
            const oc = e.cx; oc.globalCompositeOperation = 'destination-in'; oc.globalAlpha = 1; oc.imageSmoothingEnabled = true;
            if (e.a.ev) {   // l'événement s'ouvre depuis l'aimant principal, comme une déchirure qui s'élargit
              oc.setTransform(d, 0, 0, d, 0, 0);
              const C0 = versHote.apply(null, o.aimant || [180, 250]), rr = 40 + 520 * lisse(Math.min(1, (t - st.ev.t0) / 3)), g = oc.createRadialGradient(C0[0], C0[1], rr * 0.55, C0[0], C0[1], rr);
              g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)'); oc.fillStyle = g; oc.fillRect(0, 0, o.l, o.h);
            }
            oc.setTransform(d * T[0], 0, 0, d * T[1], d * T[2], d * T[3]);
            oc.drawImage(masqueFondu(), 0, 0, 360, 480);
            oc.globalCompositeOperation = 'source-over';
          }
          if (!cache) envA.mult = 1;
        }
        a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = 1; a.globalCompositeOperation = 'source-over';
        if (cache) {
          let reste = lum; a.globalCompositeOperation = 'lighter';
          while (reste > 0.005) { a.globalAlpha = Math.min(1, reste); a.drawImage(e.cv, 0, 0, ca.width, ca.height); reste -= 1; }
          a.globalCompositeOperation = 'source-over'; a.globalAlpha = 1;
        }
        st.cout[e.cle] = (st.cout[e.cle] || 0) * 0.9 + (performance.now() - te0) * 0.1;
      }
      // B5 : la zone de réussite reste vide (aucun ancien élément dans la coupe)
      if (o.but) {
        a.setTransform(dpr, 0, 0, dpr, 0, 0); a.globalCompositeOperation = 'destination-out';
        const g = a.createRadialGradient(o.but.x, o.but.y, o.but.r * 0.9, o.but.x, o.but.y, o.but.r * 1.7);
        g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)'); a.fillStyle = g;
        a.fillRect(o.but.x - o.but.r * 1.8, o.but.y - o.but.r * 1.8, o.but.r * 3.6, o.but.r * 3.6);
        a.globalCompositeOperation = 'source-over'; a.setTransform(1, 0, 0, 1, 0, 0);
      }
      // l'événement « décompose » le décor : désaturé, déphasé, contrasté le temps qu'il dure
      const f = o.wd === 8 ? fev : 0, filtre = f > 0.01 ? `saturate(${(1 - 0.75 * f).toFixed(3)}) hue-rotate(${(-38 * f).toFixed(1)}deg) contrast(${(1 + 0.3 * f).toFixed(3)})` : '';
      if (st.filtre !== filtre) { st.filtre = filtre; for (const x of fondEls) x.style.filter = filtre; }
      st.fev = f;
      if (sobre) st.fige = true;
    }
    return {
      rendre,
      rebond(e) { QA.rebond(e); },   // e en coordonnées du jeu, v en px par image (= BUS ball.bounce)
      evenement(t) { st.ev.t0 = t; },
      evActif: () => st.ev.t0 >= 0,
      /* dégradation (budget) : 1 = calques propres à demi-résolution, 2 = + cadence × 2, 3 = éléments lourds coupés */
      degrader(n) {
        st.res = n >= 1 ? 0.5 : 1; st.cadMul = n >= 2 ? 2 : 1;
        st.coupes = {}; if (n >= 3) for (const e of L0) if (e.a.masque || e.a.ev || e.a.cad) st.coupes[e.cle] = true;
      },
      info: () => ({ n: L0.length, noms: L0.map(e => e.cle), f4, gpuLogiciel, ev: st.ev.t0 >= 0, fev: st.fev, res: st.res, cadMul: st.cadMul, coupes: Object.keys(st.coupes), cout: Object.fromEntries(Object.entries(st.cout).map(([k, v]) => [k, +v.toFixed(2)])) }),
      detruire() { for (const x of fondEls) x.style.filter = ''; ca.remove(); for (const e of L0) { e.cv = null; e.cx = null; } }
    };
  }
  racine.QXFU = { creer, configs, anciens, enveloppeCyc, contexteAlpha, gpuLogiciel, NOMWD };
})(typeof window !== 'undefined' ? window : globalThis);
