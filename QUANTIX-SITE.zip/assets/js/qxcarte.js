/* =====================================================================
   QXCARTE v1 — panneau ANIMÉ du sélecteur de niveau (carte d'un monde).

   Couches (de bas en haut) :
     QXFOND (mode carte)  image dédiée selecteur-<monde>.webp : dérive,
                          parallaxe lente, plan du courant, nappes, rayons (CSS)
     canevas statique     chemin (spline des 12 nœuds, comme l'image cuite)
                          + corps des nœuds, style propre au monde ;
                          redessiné seulement quand un état change
     canevas vivant       poussière à 3 échelles, éléments signature animés
                          (points, traits fins, anneaux fins), éclats qui
                          parcourent le chemin allumé, souffle du nœud courant,
                          animations de validation et d'avancée
     boutons              un <button> 48 px par nœud : numéro, tap, aria

   API
     QXCARTE.actif(monde)                 false si localStorage 'qxcarte' = '0'
     QXCARTE.monter(hote, o) → instance   o = { monde (1–12 ou nom), etats:[{i, etat:'lock'|'open'|'cur'|'done', etoiles}],
                                                depuis (rang 0–11 du niveau qui vient d'être réussi, ou -1),
                                                choisir(i), son(nom), sobre, qualite, marges:{haut,bas} }
     instance.valider(k)                  joue la validation du rang k (aperçu)
     instance.etats(liste)                nouveaux états sans animation
     instance.mesure()                    { ms, images } coût moyen JS par image
     QXCARTE.detruire()
   o.sobre (réglage du jeu ; le réglage système est ignoré, comme le jeu) : tout est figé (un seul dessin), la
   validation pose directement l'état final. Pas de vies, minuteurs ni monnaie.
   ===================================================================== */
(function (racine) {
  'use strict';
  const TAU = Math.PI * 2, W0 = 1080, H0 = 2340, RATIO = H0 / W0;
  const NOMS = { 1: 'atelier', 2: 'fonderie', 3: 'chaine', 4: 'glacier', 5: 'soufflerie', 6: 'mecanique', 7: 'gravite', 8: 'magnetisme', 9: 'faille', 10: 'filaments', 11: 'quantique', 12: 'fluides' };
  const NUIT = [5, 7, 13];
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lisse = (x) => { x = borne(x, 0, 1); return x * x * (3 - 2 * x); };
  const sortie = (x) => 1 - Math.pow(1 - borne(x, 0, 1), 3);
  const frac = (x) => x - Math.floor(x);
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${borne(a, 0, 1).toFixed(3)})`;
  const hache = (n) => frac(Math.sin(n * 127.1 + 311.7) * 43758.5453);

  /* ---------- style propre à chaque monde : jetons, forme du nœud, parure du chemin ---------- */
  const STYLE = {
    atelier:    { accent: 'cyan',  second: 'lilas',  forme: 'globe',      chemin: 'perles' },
    fonderie:   { accent: 'rose',  second: 'braise', forme: 'bulle',      chemin: 'bulles' },
    chaine:     { accent: 'lilas', second: 'cyan',   forme: 'cavite',     chemin: 'faisceau' },
    glacier:    { accent: 'cyan',  second: 'givre',  forme: 'givre',      chemin: 'fissure' },
    soufflerie: { accent: 'glace', second: 'argent', forme: 'cylindre',   chemin: 'filet' },
    mecanique:  { accent: 'laiton', second: 'cyan',  forme: 'roue',       chemin: 'graduations' },
    gravite:    { accent: 'cyan',  second: 'vert',   forme: 'puits',      chemin: 'perles' },
    magnetisme: { accent: 'rose',  second: 'cyan',   forme: 'pole',       chemin: 'filet' },
    faille:     { accent: 'cyan',  second: 'lilas',  forme: 'corral',     chemin: 'perles' },
    filaments:  { accent: 'rose',  second: 'lilas',  forme: 'noeud',      chemin: 'corde' },
    quantique:  { accent: 'cyan',  second: 'violet', forme: 'franges',    chemin: 'perles' },
    fluides:    { accent: 'aqua',  second: 'perle',  forme: 'tourbillon', chemin: 'filet' }
  };

  let D = null, cur = null, sprites = {};
  function donnees() {
    if (D) return D;
    const d = racine.QXCARTE_DONNEES || {}, f2 = racine.QXF2_DONNEES || {};
    D = { mondes: Object.assign({}, f2.mondes || {}, d.mondes || {}), images: d.images || {}, voiles: Object.assign({}, f2.voiles || {}, d.voiles || {}) };
    return D;
  }
  function nomDe(m) { return typeof m === 'number' || /^\d+$/.test(m) ? NOMS[+m] : m; }
  function ls() { try { return racine.localStorage.getItem('qxcarte') !== '0'; } catch (e) { return true; } }
  function actif(m) { const n = nomDe(m), d = donnees(); return ls() && !!(n && d.mondes[n] && d.images[n] && racine.QXFOND && document.createElement('canvas').getContext); }
  const calme = () => false;   /* fond10 : comme le jeu depuis R296, le réglage système « réduire les animations » est ignoré ; seul o.sobre (réglage du jeu, RM) fige la carte */

  /* sprite de point lumineux (dégradé radial), mis en cache par teinte */
  function sprite(c) {
    const k = c.join(',');
    if (sprites[k]) return sprites[k];
    const s = document.createElement('canvas'); s.width = s.height = 32; const g = s.getContext('2d');
    const r = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    r.addColorStop(0, rgba([255, 255, 255], 1)); r.addColorStop(0.18, rgba(c, 0.9)); r.addColorStop(0.5, rgba(c, 0.25)); r.addColorStop(1, rgba(c, 0));
    g.fillStyle = r; g.fillRect(0, 0, 32, 32); sprites[k] = s; return s;
  }
  function spline(P, n) {                                   // Catmull-Rom, identique au générateur de l'image (24 pas / segment)
    const Q = [[2 * P[0][0] - P[1][0], 2 * P[0][1] - P[1][1]]].concat(P, [[2 * P[P.length - 1][0] - P[P.length - 2][0], 2 * P[P.length - 1][1] - P[P.length - 2][1]]]);
    const out = [];
    for (let i = 1; i < Q.length - 2; i++) {
      const p0 = Q[i - 1], p1 = Q[i], p2 = Q[i + 1], p3 = Q[i + 2];
      for (let j = 0; j < n; j++) {
        const t = j / n, t2 = t * t, t3 = t2 * t;
        out.push([0, 1].map(k => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)));
      }
    }
    out.push(P[P.length - 1].slice()); return out;
  }

  /* ======================= ÉLÉMENTS SIGNATURE (paramétriques, sans état) =======================
     Coordonnées en px de l'image 1080 × 2340 ; tailles de points en px CSS.
     Chaque fonction reçoit A (outils de dessin) et t (secondes) ; q = qualité 0..1 (effectifs). */
  const SIG = {
    atelier(A, t, q) {
      const hel = (x0, y0, x1, y1, amp, tours, ph, n, v, c1, c2, tl) => {
        const L = Math.hypot(x1 - x0, y1 - y0), ux = (x1 - x0) / L, uy = (y1 - y0) / L;
        for (let br = -1; br <= 1; br += 2) for (let i = 0; i < n; i++) {
          const s = frac(i / n + t * v), ang = s * tours * TAU + ph + t * 0.5, env = Math.min(1, s * 8, (1 - s) * 8), o = Math.sin(ang) * amp * br * env, d = Math.cos(ang) * br;
          A.point(x0 + ux * L * s - uy * o, y0 + uy * L * s + ux * o, tl * (0.6 + 0.6 * (d * 0.5 + 0.5)), br > 0 ? c1 : c2, 0.25 + 0.55 * (d * 0.5 + 0.5));
        }
      };
      hel(-108, 2293, 1188, 94, 190, 4.6, 0.6, Math.round(34 * q), 0.012, 'cyan', 'violet', 2.4);           // hélice géante (lointaine)
      const pt = [[0.62, 0.05, 0.96, 0.2, 34, 4.5, 0], [0.05, 0.9, 0.36, 0.97, 30, 4.2, 1], [0.9, 0.36, 0.97, 0.6, 26, 5.5, 2], [0.04, 0.34, 0.1, 0.5, 20, 4.5, 3], [0.66, 0.74, 0.9, 0.8, 22, 3.6, 4]];
      for (const h of pt) hel(h[0] * W0, h[1] * H0, h[2] * W0, h[3] * H0, h[4], h[5], h[6], Math.round(12 * q), 0.03, 'cyan', 'lilas', 1.6);
      for (const g of [[0.82, 0.3, 120, 70], [0.16, 0.72, 80, 46]]) {                                       // globes de points qui tournent
        const n = Math.round(g[3] * q);
        for (let i = 0; i < n; i++) { const z = 1 - 2 * (i + 0.5) / n, a = i * 2.39996 + t * 0.25, rad = Math.sqrt(1 - z * z), d = Math.sin(a);
          A.point(g[0] * W0 + g[2] * rad * Math.cos(a), g[1] * H0 + g[2] * z * 0.92, 0.9 + 0.8 * (d * 0.5 + 0.5), 'lilas', 0.15 + 0.5 * (d * 0.5 + 0.5)); }
      }
    },
    fonderie(A, t, q) {
      const ch = [[0.14, 0.95, 0.3, 0], [0.33, 0.9, 0.5, 2], [0.7, 0.93, 0.4, 4], [0.9, 0.86, 0.2, 1], [0.6, 0.6, 0.12, 3]];
      for (const c of ch) for (let j = 0; j < 3; j++) {                                                      // bulles qui montent, grossissent, éclatent
        const s = frac(t / 9 + j / 3 + c[3] * 0.13), x = c[0] * W0 + 46 * Math.sin(s * 6 + c[3]) * (0.3 + s), y = H0 * (c[1] + (c[2] - c[1]) * Math.pow(s, 1.6));
        if (s < 0.9) A.anneau(x, y, 3 + 17 * Math.pow(s, 1.5), 3 + 17 * Math.pow(s, 1.5), 0, 'rose', 0.25 + 0.5 * s, 1);
        else { const e = (s - 0.9) / 0.1; A.couronne(x, y - 26, 26 + 18 * e, 14, 'rose', 0.8 * (1 - e), 1.2, c[3]); }
      }
      const n = Math.round(30 * q);
      for (let k = 0; k < n; k++) {                                                                          // braises du panache central
        const o = (hache(k) - 0.5) * 2, s = frac(t * 0.045 + hache(k + 9)), ouv = 46 + 150 * Math.pow(s, 1.5) + 420 * Math.pow(Math.max(0, s - 0.74), 1.25) * 4;
        A.point(0.5 * W0 + o * ouv + 60 * Math.sin(s * 5.5 + 0.7) * s, H0 * (1 - 0.8 * s), 1.2 + hache(k + 3) * 1.4, k % 3 ? 'braise' : 'rebond', 0.7 * Math.sin(s * Math.PI));
      }
    },
    chaine(A, t, q) {
      const cx = 0.5 * W0, cy = 0.5 * H0, a = 930, b = 400, rot = Math.PI / 2 - 0.3, co = Math.cos(rot), so = Math.sin(rot);
      const P = (u) => [cx + a * Math.cos(u) * co - b * Math.sin(u) * so, cy + a * Math.cos(u) * so + b * Math.sin(u) * co];
      const tang = (u) => Math.atan2(-a * Math.sin(u) * so + b * Math.cos(u) * co, -a * Math.sin(u) * co - b * Math.cos(u) * so);
      const v = 0.16;
      for (let k = 0; k < 6; k++) {                                                                          // paquets qui circulent, avec traîne
        const u = k * TAU / 6 + 0.5 + t * v;
        for (let i = 0; i < 14 * q; i++) { const p = P(u - i * 0.01); A.point(p[0], p[1], 1.6, 'cyan', 0.55 * (1 - i / 14)); }
        for (let i = 0; i < 5; i++) { const p = P(u + (hache(k * 7 + i) - 0.5) * 0.02); A.point(p[0] + (hache(i + k) - 0.5) * 8, p[1] + (hache(i * 3 + k) - 0.5) * 8, 2.2, 'blanc', 0.9); }
        for (let f = 0; f < 7; f++) {                                                                        // éventail synchrotron : s'allume au passage
          const uf = f * TAU / 7 + 0.9, dd = Math.abs(((u - uf) % TAU + TAU + Math.PI) % TAU - Math.PI);
          if (dd < 0.12) { const p = P(uf), an = tang(uf), al = 0.55 * (1 - dd / 0.12);
            for (let j = -3; j <= 3; j++) A.trait(p[0], p[1], p[0] + 260 * Math.cos(an + j * 0.035), p[1] + 260 * Math.sin(an + j * 0.035), 'cyan', al * (1 - Math.abs(j) / 4), 0.8, true); }
        }
      }
      const dp = P(Math.PI * 0.985);                                                                         // détecteur : ondes de collision
      for (let j = 0; j < 3; j++) { const s = frac(t / 3.2 + j / 3); A.anneau(dp[0], dp[1], 34 + 120 * s, 34 + 120 * s, 0, 'violet', 0.5 * (1 - s), 1); }
    },
    glacier(A, t, q) {
      const vx = 0.76 * W0, vy = 0.56 * H0, vr = 150;
      for (let j = -6; j <= 6; j++) for (let i = -6; i <= 6; i++) {                                         // réseau de tourbillons : cœurs qui scintillent, arcs qui tournent
        const x = vx + (i + 0.5 * (j & 1)) * 44, y = vy + j * 38;
        if (Math.hypot(x - vx, y - vy) >= vr) continue;
        const ph = hache(i * 13 + j * 7) * TAU, s = 0.5 + 0.5 * Math.sin(t * 1.3 + ph);
        A.point(x, y, 1.2 + s, 'blanc', 0.25 + 0.6 * s);
        if (q > 0.5) A.arc(x, y, 11, t * 0.9 + ph, 1.4, 'cyan', 0.35, 0.8);
      }
      const px = 0.62 * W0, py = 0.115 * H0, m = 1 + 0.08 * Math.sin(t * 0.9);                               // pic du condensat qui respire
      for (let j = 6; j <= 9; j++) {
        const e = 1 - Math.abs(j - 7.5) / 8, pts = [];
        for (let x = -240; x <= 240; x += 12) pts.push([px + x, py + (j - 8) * 11 + x * 0.12 - 190 * Math.pow(e, 1.5) * m * Math.exp(-Math.pow(x / 62, 2)) - 26 * e * Math.exp(-Math.pow(x / 210, 2))]);
        A.ligne(pts, 'cyan', 0.18 + 0.12 * Math.sin(t * 0.9 + j), 0.8);
      }
      const n = Math.round(46 * q);
      for (let k = 0; k < n; k++) {                                                                          // éclats de givre sur la banquise (points, pas de flocons)
        const s = 0.5 + 0.5 * Math.sin(t * (0.8 + hache(k) * 1.4) + hache(k + 5) * TAU);
        const yy = 0.76 + 0.23 * hache(k + 2); A.point(W0 * (0.5 + (hache(k + 1) - 0.5) * (0.8 + 1.5 * (yy - 0.73))), H0 * yy, 0.8 + 1.6 * s * s, 'blanc', 0.7 * s * s);
      }
    },
    soufflerie(A, t, q, E) {                                                                                 // particules portées par l'écoulement autour du cylindre
      const cx = 0.52 * W0, cy = 0.7 * H0, Rc = 118;
      if (!E.p) { E.p = []; for (let i = 0; i < 90; i++) E.p.push([hache(i) * W0, hache(i + 50) * H0, 0, 0]); }
      const n = Math.round(90 * q);
      for (let i = 0; i < n; i++) {
        const p = E.p[i]; let X = cy - p[1], Y = p[0] - cx; const r2 = X * X + Y * Y + 1e-3;
        let u = 1 - Rc * Rc * (X * X - Y * Y) / (r2 * r2), v = -2 * Rc * Rc * X * Y / (r2 * r2);
        const dt = E.dt * 60, m = Math.hypot(u, v) + 1e-6; p[2] = p[0]; p[3] = p[1];
        p[0] += v / m * dt * 1.1 * (0.7 + m * 0.3); p[1] -= u / m * dt * 1.1 * (0.7 + m * 0.3);
        if (p[1] < -20 || p[0] < -20 || p[0] > W0 + 20 || r2 < Rc * Rc * 0.9) { p[0] = hache(i + t) * W0; p[1] = H0 + 10 * hache(i); p[2] = p[0]; p[3] = p[1]; continue; }
        A.trait(p[2], p[3] + 6, p[0], p[1], i % 4 ? 'argent' : 'blanc', 0.45, 0.8);
      }
      for (let k = 0; k < 8; k++) {                                                                          // allée de von Kármán : spirales qui tournent
        const X = Rc * 2.3 + k * 170, Y = k % 2 ? 58 : -58, sg = k % 2 ? 1 : -1, x = cx + Y, y = cy - X;
        for (let i = 0; i < 8; i++) { const a = sg * (t * 1.2 + i * 0.7), r = 6 + i * 4; A.point(x + r * Math.cos(a), y + r * Math.sin(a), 1.3, 'glace', 0.5 * (1 - i / 8) * (1 - k / 9)); }
      }
    },
    mecanique(A, t, q) {
      const R = [[0.72, 0.27, 150, 44, 0], [0.905, 0.345, 62, 18, 0.1], [0.7, 0.705, 110, 32, 0.2], [0.86, 0.765, 54, 16, 0.3], [0.17, 0.33, 84, 24, 0.1], [0.5, 0.9, 70, 20, 0], [0.36, 0.94, 40, 12, 0.2], [0.44, 0.1, 96, 28, 0.3], [0.6, 0.06, 44, 12, 0.1]];
      R.forEach((w, k) => {                                                                                  // rouages : éclats qui tournent sur les dents
        const sg = k % 2 ? -1 : 1, a = sg * t * 18 / w[2] + w[4];
        for (let j = 0; j < 3; j++) { const b = a + j * TAU / 3; A.point(w[0] * W0 + w[2] * Math.cos(b), w[1] * H0 + w[2] * Math.sin(b), 2, 'laiton', 0.75); }
        A.arc(w[0] * W0, w[1] * H0, w[2] * 0.22, a * 2, 1.2, 'creme', 0.45, 0.8);
      });
      const bx = 0.3 * W0, by = 0.6 * H0, ab = Math.sin(t * 2.2) * 1.1;                                     // balancier qui oscille
      A.arc(bx, by, 150, -Math.PI / 2 + ab - 0.06, 0.12, 'laiton', 0.7, 1.4); A.point(bx + 150 * Math.cos(-Math.PI / 2 + ab), by + 150 * Math.sin(-Math.PI / 2 + ab), 2.4, 'creme', 0.9);
      for (const c of [[0.28, 0.82, 330, 11, -0.12], [0.72, 0.5, 260, 9, 1.45], [0.25, 0.085, 220, 8, 0.1]]) {   // chapelets d'ions : mode de respiration
        for (let i = 0; i < c[3]; i++) { const s = (i / (c[3] - 1) - 0.5), o = s * c[2] * (1 + 0.04 * Math.sin(t * 2.6)) + 3 * Math.sin(t * 3.1 + i);
          A.point(c[0] * W0 + o * Math.cos(c[4]), c[1] * H0 + o * Math.sin(c[4]), 1.8, 'cyan', 0.75); }
      }
    },
    gravite(A, t, q) {
      const Wl = [[0.5, 0.47, 190], [0.17, 0.12, 100], [0.86, 0.82, 120], [0.1, 0.9, 70], [0.9, 0.2, 60]];
      for (const w of Wl) for (let j = 0; j < 2; j++) {                                                    // anneaux qui tombent dans le puits
        const s = frac(t / 6 + j / 2 + w[0]); A.anneau(w[0] * W0, w[1] * H0, w[2] * 1.7 * (1 - s) + 6, (w[2] * 1.7 * (1 - s) + 6) * 0.88, 0, 'violet', 0.35 * Math.sin(s * Math.PI), 1);
      }
      const cx = 0.5 * W0, cy = 0.47 * H0;
      for (let k = 0; k < 5; k++) for (let i = 0; i < 12 * q; i++) {                                       // grains en orbite spirale vers le puits central
        const s = frac(t * 0.03 + k / 5) - i * 0.004; if (s < 0) continue;
        const rad = 620 * Math.pow(1 - s, 1.6) + 26, an = 2.2 + s * 4.2 * TAU;
        A.point(cx + rad * Math.cos(an), cy + rad * 0.9 * Math.sin(an), i ? 1.2 : 2.2, i ? 'cyan' : 'blanc', (i ? 0.5 : 0.9) * (1 - i / 12) * Math.min(1, s * 12));
      }
    },
    magnetisme(A, t, q) {
      const cx = 0.5 * W0, cy = 0.5 * H0, ax = -Math.PI / 2 + 0.42, ca = Math.cos(ax), sa = Math.sin(ax);
      const n = Math.round(30 * q);
      for (let k = 0; k < n; k++) {                                                                          // charges qui glissent le long des lignes de champ
        const Lc = 170 * Math.pow(1.27, k % 14), sg = k & 1 ? 1 : -1, s = 0.04 + (Math.PI - 0.08) * frac(t * 0.05 * (1.6 - (k % 14) / 14) + hache(k));
        const r = Lc * Math.sin(s) ** 2, x = cx + r * (Math.cos(s) * ca - sg * Math.sin(s) * sa), y = cy + r * (Math.cos(s) * sa + sg * Math.sin(s) * ca);
        A.point(x, y, 1.6, k % 3 ? 'rose' : 'cyan', 0.65 * Math.sin(s));
      }
      for (let sg = -1; sg <= 1; sg += 2) {                                                                  // précession aux pôles
        const x = cx + sg * 62 * ca, y = cy + sg * 62 * sa;
        for (const e of [[150, 70, 26, 0.8], [260, 120, 40, 0.5]]) {
          const ex = x + sg * e[0] * ca, ey = y + sg * e[0] * sa, rr = ax + Math.PI / 2;
          for (let j = 0; j < 2; j++) { const a = t * e[3] * sg + j * Math.PI, px = e[1] * Math.cos(a), py = e[2] * Math.sin(a);
            A.point(ex + px * Math.cos(rr) - py * Math.sin(rr), ey + px * Math.sin(rr) + py * Math.cos(rr), 2.2, 'blanc', 0.85); }
        }
      }
    },
    faille(A, t, q) {
      const C = [[0.76, 0.2, 180, 48], [0.84, 0.76, 130, 36], [0.2, 0.86, 110, 32], [0.74, 0.5, 70, 20], [0.1, 0.12, 60, 18], [0.3, 0.6, 50, 14], [0.92, 0.94, 46, 14]];
      C.forEach((c, k) => {                                                                                  // corrals : onde stationnaire qui respire + atomes qui s'allument en ronde
        const x = c[0] * W0, y = c[1] * H0;
        for (let j = 1; j <= 3; j++) A.anneau(x, y, c[2] * j / 4, c[2] * j / 4, 0, 'cyan', 0.16 * (0.5 + 0.5 * Math.sin(t * 1.4 + j * 1.3 + k)), 1);
        const tour = frac(t / 5 + k * 0.17) * c[3];
        for (let i = 0; i < 4; i++) { const ia = Math.floor(tour) - i, a = ia * TAU / c[3]; A.point(x + c[2] * Math.cos(a), y + c[2] * Math.sin(a), 2, 'lilas', 0.8 * (1 - i / 4)); }
      });
      for (const b of [[0.33, 0.12, 520, 0.35], [0.5, 0.93, 420, -0.2], [0.12, 0.33, 300, 1.2]]) {            // paquet d'onde qui traverse la barrière (atténué)
        const s = frac(t / 6 + b[0]), L = b[2], ux = Math.cos(b[3]), uy = Math.sin(b[3]), x0 = b[0] * W0 - ux * L / 2, y0 = b[1] * H0 - uy * L / 2;
        for (let i = 0; i < 18 * q; i++) {
          const d = s * 1.3 - 0.15 + (i - 9) * 0.012, att = d > 0.5 ? 0.3 : 1; if (d < 0 || d > 1) continue;
          const o = Math.sin(i * 1.1 - t * 6) * 10 * Math.exp(-Math.pow((i - 9) / 5, 2));
          A.point(x0 + ux * L * d - uy * o, y0 + uy * L * d + ux * o, 1.5, 'cyan', 0.7 * att);
        }
      }
    },
    filaments(A, t, q) {
      const corde = (x0, y0, x1, y1, n, amp, c, al, w) => {
        const L = Math.hypot(x1 - x0, y1 - y0), ux = (x1 - x0) / L, uy = (y1 - y0) / L, k = Math.cos(t * (0.9 + n * 0.35)), pts = [];
        for (let i = 0; i <= 30; i++) { const s = i / 30, o = amp * Math.sin(n * Math.PI * s) * k; pts.push([x0 + ux * L * s - uy * o, y0 + uy * L * s + ux * o]); }
        A.ligne(pts, c, al, w);
      };
      for (const c of [[0.52, 0.06, 0.96, 0.1, 3, 26], [0.5, 0.085, 0.94, 0.125, 5, 18], [0.9, 0.24, 0.95, 0.52, 4, 22], [0.05, 0.76, 0.1, 0.96, 3, 20], [0.3, 0.9, 0.7, 0.96, 7, 16]])
        corde(c[0] * W0, c[1] * H0, c[2] * W0, c[3] * H0, c[4], c[5], 'rose', 0.4, 1);
      for (const c of [[-0.1, 0.92, 1.1, 0.5, 2, 150], [-0.1, 0.1, 1.1, 0.36, 3, 110]]) corde(c[0] * W0, c[1] * H0, c[2] * W0, c[3] * H0, c[4], c[5] * 0.6, 'violet', 0.12, 2);
      for (const b of [[0.74, 0.3, 130, 3, 0.16], [0.26, 0.56, 96, 4, 0.13], [0.8, 0.9, 80, 5, 0.1], [0.3, 0.1, 64, 2, 0.2], [0.93, 0.62, 50, 3, 0.16]]) {   // cordes fermées : le mode tourne
        const pts = [];
        for (let i = 0; i <= 48; i++) { const a = i * TAU / 48, r = b[2] * (1 + b[4] * Math.sin(b[3] * a + t * 0.6)); pts.push([b[0] * W0 + r * Math.cos(a), b[1] * H0 + r * Math.sin(a)]); }
        A.ligne(pts, 'lilas', 0.3, 1);
      }
    },
    quantique(A, t, q, E) {
      const sx = 0.5 * W0, sy = 0.045 * H0, yb = 0.27 * H0, e = 74;
      for (let j = 0; j < 3; j++) { const s = frac(t / 2.6 + j / 3), r = 20 + (yb - sy - 20) * s;            // fronts d'onde de la source jusqu'à la paroi
        A.arc(sx, sy, r, Math.PI * 0.12, Math.PI * 0.76, 'cyan', 0.45 * (1 - s * 0.6), 1); }
      for (let j = 0; j < 3; j++) { const s = frac(t / 2.6 + j / 3 + 0.5), r = 10 + 360 * s;               // arcs issus des deux fentes
        for (const xs of [sx - e, sx + e]) A.arc(xs, yb + 9, r, Math.PI * 0.1, Math.PI * 0.8, 'violet', 0.35 * (1 - s), 1); }
      if (!E.imp) {                                                                                          // écran : impacts tirés selon les franges (tirage par rejet, une fois)
        E.imp = []; let k = 0;
        while (E.imp.length < 70 && k < 5000) { k++; const x = hache(k * 3.1), I = Math.pow(Math.cos((x - 0.5) * 22), 2) * Math.exp(-Math.pow((x - 0.5) / 0.3, 2)); if (hache(k * 7.7) < I) E.imp.push(x); }
      }
      const ye = 0.925 * H0, n = Math.round(E.imp.length * q);
      for (let i = 0; i < n; i++) { const s = frac(t / 8 + i / n), al = s < 0.04 ? s / 0.04 : 1 - (s - 0.04) / 0.96;
        A.point(E.imp[i] * W0, ye + (hache(i + 17) - 0.5) * 30, s < 0.04 ? 2.6 : 1.4, s < 0.04 ? 'blanc' : 'cyan', 0.85 * al); }
      for (const p of [[0.1, 0.16, 0.9, 0.2], [0.08, 0.6, 0.93, 0.48]]) {                                   // paires intriquées : l'une s'allume quand l'autre s'éteint
        const s = 0.5 + 0.5 * Math.sin(t * 1.7 + p[1] * 9);
        A.point(p[0] * W0, p[1] * H0, 3, 'lilas', 0.2 + 0.6 * s); A.point(p[2] * W0, p[3] * H0, 3, 'cyan', 0.2 + 0.6 * (1 - s));
      }
    },
    fluides(A, t, q, E) {
      for (const v of [[0.7, 0.57, 60, 1], [0.2, 0.32, 46, -1], [0.42, 0.76, 38, 1]])                          // anneaux tourbillons
        for (let i = 0; i < 14; i++) { const a = v[3] * t * 0.8 + i * 0.55, r = v[2] * (0.2 + i / 14); A.point(v[0] * W0 + r * Math.cos(a), v[1] * H0 + r * Math.sin(a), 1.4, 'aqua', 0.6 * (1 - i / 16)); }
      const S = E.S, n = Math.round(40 * q);                                                                 // courant en S le long du chemin
      for (let k = 0; k < n; k++) { const s = frac(t * 0.012 + hache(k)), i = Math.floor(s * (S.length - 1)), p = S[i], p2 = S[Math.min(S.length - 1, i + 1)];
        const nx = -(p2[1] - p[1]), ny = p2[0] - p[0], m = Math.hypot(nx, ny) || 1, o = (hache(k + 4) - 0.5) * 120;
        A.point(p[0] + nx / m * o, p[1] + ny / m * o, 1.2, k % 4 ? 'perle' : 'aqua', 0.5 * Math.sin(s * Math.PI)); }
      for (const m of [[0.82, 0.4, 230], [0.08, 0.7, 170]]) A.lueur(m[0] * W0, m[1] * H0 - m[2] * 0.3, m[2] * 0.8, 'lueur', 0.10 + 0.06 * Math.sin(t * 1.1 + m[0] * 5));
    }
  };

  /* ======================= INSTANCE ======================= */
  function monter(hote, o) {
    detruire();
    const nom = nomDe(o.monde), d = donnees(), cfg = d.mondes[nom], st = STYLE[nom], pal = cfg.palette;
    const coul = (k) => pal[k] || (k === 'blanc' ? [234, 246, 255] : pal[st.accent]);
    const ACC = coul(st.accent), SEC = coul(st.second), BL = coul('blanc'), FOND = pal.nuit || pal.abysse || NUIT;
    const reduit = () => !!o.sobre || calme();
    let etats = o.etats.map(e => Object.assign({}, e)), detruit = false, raf = 0, t0 = 0, tPrec = 0, anim = null;
    let qualite = o.qualite || 1, mes = { s: 0, n: 0, fen: [] };
    const E = { dt: 1 / 60 };

    const racineDom = document.createElement('div'); racineDom.className = 'qxc';
    racineDom.style.cssText = 'position:absolute;inset:0;overflow:hidden;background:' + rgba(FOND, 1);
    const plan = document.createElement('div'); plan.style.cssText = 'position:absolute;left:0;top:0';
    const cS = document.createElement('canvas'), cD = document.createElement('canvas');
    for (const c of [cS, cD]) c.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none';
    const boutons = document.createElement('div'); boutons.style.cssText = 'position:absolute;inset:0';
    racineDom.append(plan, cS, cD, boutons); hote.appendChild(racineDom);
    poserStyle();

    let arriere = null, l = 0, h = 0, lI = 0, hI = 0, ox = 0, oy = 0, k = 1, R = 15, dprS = 1, dprD = 1, fond = null, S = [], P = [], btn = [];
    const X = (x) => ox + x * k, Y = (y) => oy + y * k;

    function disposer() {
      const r = hote.getBoundingClientRect(); l = Math.round(r.width); h = Math.round(r.height);
      if (l < 10 || h < 10) return false;
      const N = cfg.noeuds, vmin = Math.min(...N.map(p => p[1])), vmax = Math.max(...N.map(p => p[1]));
      const haut = (o.marges && o.marges.haut) || 78, bas = (o.marges && o.marges.bas) || 56, utile = h - haut - bas;                                                    // bandeaux du titre et du bas de l'écran
      lI = Math.max(l, h / RATIO); hI = lI * RATIO;
      if ((vmax - vmin) * hI + 2 * R > utile) { hI = (utile - 40) / (vmax - vmin); lI = hI / RATIO; }        // écran court : on réduit pour que les 12 nœuds tiennent
      ox = (l - lI) / 2; oy = borne(haut + utile / 2 - (vmin + vmax) / 2 * hI, Math.min(0, h - hI), Math.max(0, h - hI) / 2);
      if (hI <= h) oy = (h - hI) / 2;
      k = lI / W0; R = borne(lI * 0.04, 14, 22);
      if (lI < l - 1) {                                                                                      // image réduite : bords comblés par la même image, floutée et assombrie (tramée une fois)
        if (!arriere) { arriere = document.createElement('div'); racineDom.insertBefore(arriere, plan); }
        arriere.style.cssText = 'position:absolute;inset:-30px;background:center/cover url(' + d.images[nom] + ');filter:blur(22px) brightness(.55)';
      } else if (arriere) { arriere.remove(); arriere = null; }
      plan.style.left = ox + 'px'; plan.style.top = oy + 'px'; plan.style.width = lI + 'px'; plan.style.height = hI + 'px';
      if (fond) { fond.detruire(); fond = null; }
      try {
        const M = Object.assign({}, racine.QXFOND.mondes || {}); M[nom] = cfg; racine.QXFOND.configurer(M);
        fond = racine.QXFOND.creer(plan, { monde: nom, image: d.images[nom], voile: d.voiles[nom], l: lI, h: hI, carte: true });
        fond.regler({ profondeur: 0, qualite, sobre: reduit() });
      } catch (e) { plan.style.background = 'center/cover url(' + d.images[nom] + ')'; }
      const dpr = Math.min(2, racine.devicePixelRatio || 1); dprS = dpr; dprD = qualite < 0.75 ? 1 : dpr;
      for (const [c, p] of [[cS, dprS], [cD, dprD]]) { c.width = Math.round(l * p); c.height = Math.round(h * p); c.style.width = l + 'px'; c.style.height = h + 'px'; }
      S = spline(N.map(p => [p[0] * W0, p[1] * H0]), 24); P = N.map(p => [p[0] * W0, p[1] * H0]); E.S = S;
      construireBoutons(); dessinerStatique(); return true;
    }

    /* ---------- boutons (tap ≥ 48 px, numéros DOM nets et contrastés) ---------- */
    function construireBoutons() {
      boutons.innerHTML = ''; btn = [];
      P.forEach((p, i) => {
        const b = document.createElement('button'); b.className = 'qxc-n'; b.type = 'button';
        b.style.left = (X(p[0]) - 24) + 'px'; b.style.top = (Y(p[1]) - 24) + 'px'; b.style.fontSize = Math.round(R * 0.95) + 'px';
        b.innerHTML = '<span>' + (i + 1) + '</span>';
        b.onclick = (ev) => {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          const e = etats[i];
          if (!e || e.etat === 'lock') { if (o.son) o.son('ui_tap'); refus = { i, t: temps() }; boucle(); return; }
          if (o.choisir) o.choisir(e.i);
        };
        boutons.appendChild(b); btn.push(b);
      });
      majBoutons();
    }
    function majBoutons() {
      etats.forEach((e, i) => {
        const b = btn[i]; if (!b) return;
        b.className = 'qxc-n ' + e.etat;
        const et = e.etoiles || 0;
        b.setAttribute('aria-label', 'Niveau ' + (i + 1) + (e.etat === 'lock' ? ', verrouillé' : e.etat === 'done' ? ', réussi, ' + et + ' étoile' + (et > 1 ? 's' : '') + ' sur 3' : e.etat === 'cur' ? ', niveau suivant' : ', disponible'));
        if (e.etat === 'lock') b.setAttribute('aria-disabled', 'true'); else b.removeAttribute('aria-disabled');
      });
    }

    /* ---------- dessin statique : chemin + corps des nœuds ---------- */
    function seg(i) { return S.slice(i * 24, i * 24 + 25); }
    function tracer(g, pts, dpart) {
      g.beginPath(); const n = dpart === undefined ? pts.length - 1 : dpart;
      for (let j = 0; j <= Math.floor(n); j++) { const p = pts[j]; j ? g.lineTo(X(p[0]), Y(p[1])) : g.moveTo(X(p[0]), Y(p[1])); }
      if (dpart !== undefined && n % 1 && pts[Math.ceil(n)]) { const a = pts[Math.floor(n)], b = pts[Math.ceil(n)], f = n % 1; g.lineTo(X(a[0] + (b[0] - a[0]) * f), Y(a[1] + (b[1] - a[1]) * f)); }
    }
    function cheminAllume(g, pts, part) {                                                                  // trait de lumière : halo large + filet net
      g.lineCap = 'round'; g.lineJoin = 'round';
      tracer(g, pts, part); g.strokeStyle = rgba(ACC, 0.16); g.lineWidth = 6; g.stroke();
      tracer(g, pts, part); g.strokeStyle = rgba(ACC, 0.9); g.lineWidth = 1.6; g.stroke();
      tracer(g, pts, part); g.strokeStyle = rgba(BL, 0.75); g.lineWidth = 0.7; g.stroke();
    }
    function cheminEteint(g, pts) {                                                                        // pointillé fin, parure propre au monde
      const pas = st.chemin === 'graduations' ? 3 : 2;
      for (let j = 1; j < pts.length - 1; j += pas) {
        const p = pts[j], x = X(p[0]), y = Y(p[1]);
        if (st.chemin === 'graduations' || st.chemin === 'fissure') {
          const q = pts[j + 1], an = Math.atan2(q[1] - p[1], q[0] - p[0]) + Math.PI / 2, L = st.chemin === 'fissure' ? 2 : 3;
          g.beginPath(); g.moveTo(x - L * Math.cos(an), y - L * Math.sin(an)); g.lineTo(x + L * Math.cos(an), y + L * Math.sin(an));
          g.strokeStyle = rgba(SEC, 0.5); g.lineWidth = 0.8; g.stroke();
        } else if (st.chemin === 'bulles' && j % 4 === 1) {
          g.beginPath(); g.arc(x, y, 1.8, 0, TAU); g.strokeStyle = rgba(SEC, 0.5); g.lineWidth = 0.8; g.stroke();
        } else { g.fillStyle = rgba(BL, 0.42); g.fillRect(x - 0.7, y - 0.7, 1.4, 1.4); }
      }
    }
    function etat(i) { return etats[i] ? etats[i].etat : 'lock'; }
    function dessinerStatique(cache) {                                                                     // cache : { seg, noeud } à masquer pendant une animation
      const g = cS.getContext('2d'); g.setTransform(dprS, 0, 0, dprS, 0, 0); g.clearRect(0, 0, l, h);
      for (let i = 0; i < P.length - 1; i++) {
        const allume = etat(i) === 'done' && !(cache && cache.seg === i);
        if (allume) cheminAllume(g, seg(i)); else cheminEteint(g, seg(i));
      }
      for (let i = 0; i < P.length; i++) if (!(cache && cache.noeud === i)) corps(g, i, etat(i), 1);
    }
    /* corps d'un nœud : disque sombre (contraste du numéro) + parure propre au monde + anneau d'état */
    function corps(g, i, e, al) {
      const x = X(P[i][0]), y = Y(P[i][1]), lock = e === 'lock', done = e === 'done', c = lock ? [150, 170, 195] : ACC;
      const a = lock ? 0.5 * al : al;
      g.save(); g.globalAlpha = 1;
      const ombre = g.createRadialGradient(x, y, 0, x, y, R * 1.9); ombre.addColorStop(0, rgba(NUIT, 0.55 * al)); ombre.addColorStop(1, rgba(NUIT, 0));
      g.fillStyle = ombre; g.fillRect(x - R * 2, y - R * 2, R * 4, R * 4);
      if (done) { const f = g.createRadialGradient(x - R * 0.25, y - R * 0.3, 0, x, y, R); f.addColorStop(0, rgba(ACC, 0.62 * al)); f.addColorStop(0.6, rgba(ACC, 0.3 * al)); f.addColorStop(1, rgba(FOND, 0.85 * al)); g.fillStyle = rgba(FOND, 0.8 * al); g.beginPath(); g.arc(x, y, R, 0, TAU); g.fill(); g.fillStyle = f; }   // réussi : lumière du monde (jeton accent), pas d'or
      else g.fillStyle = rgba(lock ? [12, 16, 26] : FOND, (lock ? 0.62 : 0.78) * al);
      g.beginPath(); g.arc(x, y, R, 0, TAU); g.fill();
      parure(g, x, y, i, lock ? c : ACC, a * (lock ? 0.55 : 0.85), lock);                                // parure : matière du monde, même réussi
      g.beginPath(); g.arc(x, y, R, 0, TAU); g.lineWidth = e === 'cur' ? 2 : 1.2;
      if (lock) g.setLineDash([2, 3]);
      g.strokeStyle = rgba(done ? BL : c, (done ? 0.9 : lock ? 0.55 : 0.95) * al); g.stroke(); g.setLineDash([]);
      if (done) {                                                                                         // critères (0–3) = langue du bilan du jeu (resAnim) : zone vue de biais + 3 satellites
        g.beginPath(); g.ellipse(x, y + R * 0.62, R + 10, (R + 10) * 0.36, 0, 0, TAU); g.strokeStyle = rgba(ACC, 0.4 * al); g.lineWidth = 0.8; g.stroke();
        for (let s = 0; s < 3; s++) { const q = satellite(x, y, s), on = s < (etats[i].etoiles || 0);
          if (on) { const sp = sprite(ACC); g.globalAlpha = al; g.drawImage(sp, q[0] - 6, q[1] - 6, 12, 12); g.globalAlpha = 1; g.fillStyle = rgba(BL, al); g.beginPath(); g.arc(q[0], q[1], 1.5, 0, TAU); g.fill(); }
          else { g.fillStyle = rgba(BL, 0.22 * al); g.beginPath(); g.arc(q[0], q[1], 1.3, 0, TAU); g.fill(); } }
      }
      g.restore();
    }
    function satellite(x, y, s) { const a = Math.PI / 2 + (s - 1) * 2.094; return [x + (R + 10) * Math.cos(a), y + R * 0.62 + (R + 10) * 0.36 * Math.sin(a)]; }
    function parure(g, x, y, i, c, a, lock) {
      g.lineWidth = 0.8; g.strokeStyle = rgba(c, a); g.fillStyle = rgba(c, a);
      const pt = (px, py, r) => { g.beginPath(); g.arc(px, py, r, 0, TAU); g.fill(); };
      const R1 = R + 4;
      switch (st.forme) {
        case 'globe': for (let j = 0; j < 18; j++) { const z = 1 - 2 * (j + 0.5) / 18, q = j * 2.39996, rr = Math.sqrt(1 - z * z); if (Math.sin(q) > -0.2) pt(x + R1 * 1.05 * rr * Math.cos(q), y + R1 * 1.05 * z, 0.9); } break;
        case 'bulle': g.beginPath(); g.arc(x, y, R1, Math.PI * 1.1, Math.PI * 1.45); g.lineWidth = 1.4; g.stroke(); pt(x - R * 0.45, y - R * 0.5, 1.2); g.beginPath(); g.arc(x, y, R + 8, 0, TAU); g.lineWidth = 0.6; g.strokeStyle = rgba(c, a * 0.4); g.stroke(); break;
        case 'cavite': { const q = S[Math.min(S.length - 1, i * 24 + 1)], p0 = S[Math.max(0, i * 24 - 1)], an = Math.atan2(q[1] - p0[1], q[0] - p0[0]);
          for (const s of [-1, 1]) { g.beginPath(); g.ellipse(x + s * Math.cos(an) * (R + 5), y + s * Math.sin(an) * (R + 5), 3, R * 0.75, an, 0, TAU); g.stroke(); }
          g.beginPath(); g.ellipse(x, y, R + 9, R * 0.55, an, 0, TAU); g.strokeStyle = rgba(c, a * 0.45); g.stroke(); break; }
        case 'givre': for (let j = 0; j < 14; j++) { const an = j * TAU / 14 + hache(i * 31 + j) * 0.35, L = 2 + 7 * hache(i * 7 + j) ** 2; g.beginPath(); g.moveTo(x + (R + 2) * Math.cos(an), y + (R + 2) * Math.sin(an)); g.lineTo(x + (R + 2 + L) * Math.cos(an + 0.08), y + (R + 2 + L) * Math.sin(an + 0.08)); g.stroke(); if (L > 6) pt(x + (R + 3 + L) * Math.cos(an + 0.08), y + (R + 3 + L) * Math.sin(an + 0.08), 0.8); } break;
        case 'cylindre': for (const s of [-1, 1]) { g.beginPath(); g.moveTo(x + s * (R + 3), y + R * 1.8); g.bezierCurveTo(x + s * (R + 9), y + R * 0.6, x + s * (R + 9), y - R * 0.6, x + s * (R + 3), y - R * 1.8); g.stroke(); } break;
        case 'roue': for (let j = 0; j < 16; j++) { const an = j * TAU / 16; pt(x + (R + 4) * Math.cos(an), y + (R + 4) * Math.sin(an), 1.1); } break;
        case 'puits': for (let j = 1; j <= 3; j++) { g.beginPath(); g.ellipse(x, y, R + 4 * j, (R + 4 * j) * 0.88, 0, 0, TAU); g.strokeStyle = rgba(c, a * (1 - j * 0.25)); g.stroke(); } break;
        case 'pole': g.beginPath(); g.ellipse(x, y, R + 8, (R + 8) * 0.34, -0.5, 0, TAU); g.stroke(); break;
        case 'corral': for (let j = 0; j < 14; j++) { const an = j * TAU / 14; pt(x + (R + 5) * Math.cos(an), y + (R + 5) * Math.sin(an), 1.2); } break;
        case 'noeud': for (const s of [-1, 1]) { g.beginPath(); g.ellipse(x, y, R + 7, R * 0.6, s * 0.6, 0, TAU); g.stroke(); } break;
        case 'franges': for (const s of [-1, 1]) for (let j = 1; j <= 2; j++) { g.beginPath(); g.arc(x, y, R + 3 * j + 1, s > 0 ? -2.3 : 0.84, s > 0 ? -0.84 : 2.3); g.strokeStyle = rgba(c, a * (1.2 - j * 0.35)); g.stroke(); } break;
        case 'tourbillon': for (let j = 0; j < 12; j++) { const an = j * 0.62 + i, r = R + 2 + j * 0.8; pt(x + r * Math.cos(an), y + r * Math.sin(an), 0.9); } break;
      }
    }

    /* ---------- outils du canevas vivant (coordonnées image) ---------- */
    let gD = null;
    const A = {
      point(x, y, s, c, al) {
        if (al <= 0.01) return; const sx = X(x), sy = Y(y); if (sx < -10 || sy < -10 || sx > l + 10 || sy > h + 10) return;
        const sp = sprite(coul(c)), r = s * 2.2; gD.globalAlpha = borne(al, 0, 1); gD.drawImage(sp, sx - r, sy - r, 2 * r, 2 * r);
      },
      anneau(x, y, rx, ry, rot, c, al, w) { if (al <= 0.01) return; gD.globalAlpha = borne(al, 0, 1); gD.strokeStyle = rgba(coul(c), 1); gD.lineWidth = w; gD.beginPath(); gD.ellipse(X(x), Y(y), Math.max(0.1, rx * k), Math.max(0.1, ry * k), rot, 0, TAU); gD.stroke(); },
      arc(x, y, r, a0, da, c, al, w) { if (al <= 0.01) return; gD.globalAlpha = borne(al, 0, 1); gD.strokeStyle = rgba(coul(c), 1); gD.lineWidth = w; gD.beginPath(); gD.arc(X(x), Y(y), r * k, a0, a0 + da); gD.stroke(); },
      couronne(x, y, r, n, c, al, s, ph) { for (let i = 0; i < n; i++) { const a = ph + i * TAU / n; A.point(x + r * Math.cos(a), y + r * Math.sin(a), s, c, al); } },
      trait(x0, y0, x1, y1, c, al, w) { if (al <= 0.01) return; gD.globalAlpha = borne(al, 0, 1); gD.strokeStyle = rgba(coul(c), 1); gD.lineWidth = w; gD.beginPath(); gD.moveTo(X(x0), Y(y0)); gD.lineTo(X(x1), Y(y1)); gD.stroke(); },
      ligne(pts, c, al, w) { if (al <= 0.01) return; gD.globalAlpha = borne(al, 0, 1); gD.strokeStyle = rgba(coul(c), 1); gD.lineWidth = w; gD.beginPath(); pts.forEach((p, j) => j ? gD.lineTo(X(p[0]), Y(p[1])) : gD.moveTo(X(p[0]), Y(p[1]))); gD.stroke(); },
      lueur(x, y, r, c, al) { const sp = sprite(coul(c)), rr = r * k; gD.globalAlpha = borne(al, 0, 1); gD.drawImage(sp, X(x) - rr, Y(y) - rr, 2 * rr, 2 * rr); }
    };
    /* poussière à trois échelles : lointaine (fine, lente), moyenne, proche (bokeh large, très pâle, plus rapide) */
    const POUSS = [];
    for (let i = 0; i < 110; i++) { const c = i < 70 ? 0 : i < 102 ? 1 : 2; POUSS.push({ c, u: hache(i * 1.7), v: hache(i * 2.3 + 1), ph: hache(i * 5.1) * TAU, vit: [3, 7, 16][c] * (0.6 + hache(i) * 0.8) }); }
    function poussiere(t) {
      const lim = qualite < 0.75 ? 70 : 110;
      for (let i = 0; i < lim; i++) {
        const p = POUSS[i], s = [0.7, 1.4, 16][p.c], al = [0.45, 0.5, 0.06][p.c] * (0.55 + 0.45 * Math.sin(t * 0.9 + p.ph));
        const x = (p.u * l + Math.sin(t * 0.1 + p.ph) * 14 + (o.dx || 0) * [2, 5, 14][p.c]) % (l + 40), y = ((p.v * (h + 60) - t * p.vit) % (h + 60) + h + 60) % (h + 60) - 30;
        const sp = sprite(p.c === 2 ? SEC : p.c ? ACC : BL), r = s * 2.2; gD.globalAlpha = al; gD.drawImage(sp, x - r, y - r, 2 * r, 2 * r);
      }
    }
    /* chemin allumé : éclats qui y circulent (lents, espacés) */
    function eclatsChemin(t) {
      for (let i = 0; i < P.length - 1; i++) {
        if (etat(i) !== 'done' || (anim && anim.k === i)) continue;
        const s = frac(t * 0.22 + i * 0.37), pts = seg(i), j = s * 24, a = pts[Math.floor(j)], b = pts[Math.min(24, Math.floor(j) + 1)], f = j % 1;
        A.point(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, 1.8, 'blanc', 0.85 * Math.sin(s * Math.PI));
      }
    }
    /* nœud courant : souffle lent (anneau fin qui s'ouvre) + un point en orbite */
    function souffle(t) {
      for (let i = 0; i < P.length; i++) {
        if (etat(i) !== 'cur' || (anim && anim.k + 1 === i && temps() - anim.t0 < 1.9)) continue;
        const x = X(P[i][0]), y = Y(P[i][1]), s = frac(t / 2.4);
        gD.globalAlpha = 0.5 * (1 - s); gD.strokeStyle = rgba(ACC, 1); gD.lineWidth = 1; gD.beginPath(); gD.arc(x, y, R + 3 + 16 * sortie(s), 0, TAU); gD.stroke();
        const a = t * 1.4, sp = sprite(ACC); gD.globalAlpha = 0.9; gD.drawImage(sp, x + (R + 6) * Math.cos(a) - 4, y + (R + 6) * 0.45 * Math.sin(a) - 4, 8, 8);
        const lu = sprite(ACC); gD.globalAlpha = 0.16 + 0.08 * Math.sin(t * 1.6); gD.drawImage(lu, x - R * 2.6, y - R * 2.6, R * 5.2, R * 5.2);
      }
    }
    /* ---------- validation : le nœud se valide, le chemin se trace, le suivant s'éveille ---------- */
    const TV = { valide: 0.25, trace0: 0.75, trace1: 1.55, eveil: 1.55, fin: 2.3 };
    function valider(kk, final) {
      if (kk < 0 || kk >= P.length) return;
      const avant = final || etats.map(e => Object.assign({}, e));
      if (!final) { avant[kk].etat = 'done'; avant[kk].etoiles = Math.max(1, avant[kk].etoiles || 0); if (avant[kk + 1] && avant[kk + 1].etat === 'lock') avant[kk + 1].etat = 'cur'; }
      if (reduit()) { etats = avant; majBoutons(); dessinerStatique(); dessinerVivant(temps()); if (o.son) o.son('map_done'); return; }
      const dep = etats.map(e => Object.assign({}, e)); dep[kk].etat = 'cur'; const eveille = !!(dep[kk + 1] && avant[kk + 1].etat !== 'done'); if (eveille) dep[kk + 1].etat = 'lock';
      etats = dep; majBoutons(); dessinerStatique();
      anim = { k: kk, t0: temps(), fin: avant, phase: 0, eveille }; boucle();
    }
    function animer(t) {
      if (!anim) return;
      const a = anim, u = t - a.t0, kk = a.k, x = X(P[kk][0]), y = Y(P[kk][1]);
      if (a.phase === 0 && u >= TV.valide) {                                                              // 1. le nœud se valide
        a.phase = 1; etats[kk] = Object.assign({}, a.fin[kk]); majBoutons(); dessinerStatique({ seg: kk }); if (o.son) o.son('map_done');
      }
      if (a.phase >= 1) {
        const v = u - TV.valide;
        for (let j = 0; j < 2; j++) { const s = borne((v - j * 0.18) / 0.9, 0, 1); if (s > 0 && s < 1) { gD.globalAlpha = 0.8 * (1 - s); gD.strokeStyle = rgba(j ? ACC : BL, 1); gD.lineWidth = 1.4 - j * 0.5; gD.beginPath(); gD.arc(x, y, R + R * 2.4 * sortie(s), 0, TAU); gD.stroke(); } }
        if (v < 0.4) { gD.globalAlpha = 0.6 * (1 - v / 0.4); const sp = sprite(ACC); gD.drawImage(sp, x - R * 2.2, y - R * 2.2, R * 4.4, R * 4.4); }
        for (let s = 0; s < 3; s++) { const ts = v - 0.1 - s * 0.14; if (ts > 0 && ts < 0.35 && s < (a.fin[kk].etoiles || 0)) { const e = ts / 0.35; gD.globalAlpha = 1 - e; const sp = sprite(ACC), r = 5 + 8 * (1 - e), q = satellite(x, y, s); gD.drawImage(sp, q[0] - r, q[1] - r, 2 * r, 2 * r); } }
      }
      if (kk < P.length - 1) {
        if (u >= TV.trace0 && a.phase < 3) {                                                              // 2. le chemin se trace jusqu'au suivant
          const s = lisse((u - TV.trace0) / (TV.trace1 - TV.trace0)), pts = seg(kk), n = s * 24;
          gD.globalAlpha = 1; cheminAllume(gD, pts, n);
          const j = Math.min(23, Math.floor(n)), f = n - j, hx = pts[j][0] + (pts[j + 1][0] - pts[j][0]) * f, hy = pts[j][1] + (pts[j + 1][1] - pts[j][1]) * f;
          A.point(hx, hy, 3.4, 'blanc', 1); A.point(hx, hy, 9, st.accent, 0.35);
          for (let m = 1; m < 5; m++) A.point(hx + (hache(m + u) - 0.5) * 30, hy + (hache(m * 3 + u) - 0.5) * 30, 1, st.accent, 0.5 * (1 - m / 5));
          if (u >= TV.trace1) { a.phase = 3; dessinerStatique(a.eveille ? { noeud: kk + 1 } : null); }
        }
        if (u >= TV.eveil && a.eveille) {                                                                              // 3. le suivant s'éveille
          const s = borne((u - TV.eveil) / (TV.fin - TV.eveil), 0, 1), nx = X(P[kk + 1][0]), ny = Y(P[kk + 1][1]);
          if (!a.eveil) { a.eveil = 1; etats[kk + 1] = Object.assign({}, a.fin[kk + 1]); majBoutons(); if (btn[kk + 1]) { btn[kk + 1].classList.add('eveil'); } if (o.son) o.son('map_next'); }
          if (s < 1) { corps(gD, kk + 1, 'lock', 1 - sortie(s)); corps(gD, kk + 1, etats[kk + 1].etat, sortie(s));
            gD.globalAlpha = 0.7 * s * (1 - s) * 4 * 0.5; gD.strokeStyle = rgba(ACC, 1); gD.lineWidth = 1; gD.beginPath(); gD.arc(nx, ny, R + 3 * R * (1 - sortie(s)), 0, TAU); gD.stroke(); }
        }
      }
      if (u >= TV.fin) { etats = a.fin; anim = null; majBoutons(); dessinerStatique(); btn.forEach(b => b.classList.remove('eveil')); }
    }
    let refus = null;
    function dessinerVivant(t) {
      const g = cD.getContext('2d'); gD = g; g.setTransform(dprD, 0, 0, dprD, 0, 0); g.clearRect(0, 0, l, h);
      g.globalCompositeOperation = 'lighter';
      poussiere(t);
      if (SIG[nom]) SIG[nom](A, t, qualite, E);
      eclatsChemin(t);
      g.globalCompositeOperation = 'source-over';
      souffle(t);
      if (refus) { const s = (temps() - refus.t) / 0.5; if (s >= 1) refus = null; else { const x = X(P[refus.i][0]), y = Y(P[refus.i][1]); g.globalAlpha = 0.6 * (1 - s); g.strokeStyle = 'rgba(170,190,210,1)'; g.lineWidth = 1; g.beginPath(); g.arc(x + Math.sin(s * 30) * 2 * (1 - s), y, R + 2, 0, TAU); g.stroke(); } }
      animer(t);
      g.globalAlpha = 1;
    }
    const temps = () => (racine.performance ? performance.now() : Date.now()) / 1000 - t0;
    function visible() { return !detruit && racineDom.isConnected && hote.getClientRects().length > 0 && !document.hidden; }
    let nVis = 0, attente = 0, palC = 0, cadC = 1, nCad = 0, tVeille = 0;
    function veille() { clearTimeout(tVeille); tVeille = setTimeout(function () { if (detruit) return; attente = 0; nVis = 0; if (!l || visible()) { pause = false; boucle(); } else veille(); }, 400); }   // R454
    function image() {
      raf = 0; if (detruit) return;
      if (!l) { if (!disposer()) { if (++attente < 120) raf = racine.requestAnimationFrame(image); else veille(); return; } attente = 0; lancerPendant(); }   /* R454 : jamais d'abandon : veille */
      if ((++nVis % 20) === 0 && !visible()) { pause = true; veille(); return; }   /* R454 : cachée → veille (minuterie), plus de pause sans réveil */
      { const a1 = performance.now(), fiC = a1 - (mes.dern || a1); mes.dern = a1; if (fiC > 0 && fiC < 250) mes.fi = (mes.fi || 16.7) * 0.9 + fiC * 0.1; }   /* R454 : coût réel (toutes les images) */
      if (cadC > 1 && !anim && !refus && !reduit() && (++nCad % cadC) !== 0) { raf = racine.requestAnimationFrame(image); return; }   /* R454 : cadence réduite (la toile garde son image) */
      const t = temps(), dt = Math.min(0.05, Math.max(0.001, t - tPrec)); tPrec = t; E.dt = dt;
      const fige = reduit() && !anim && !refus;
      const a0 = performance.now();   /* R454 */
      o.dx = Math.sin(t * 0.07) * 0.6;
      if (fond && !fige) fond.update(dt, { x: l * (0.5 + 0.35 * Math.sin(t * 0.05)), y: h * (0.5 + 0.35 * Math.cos(t * 0.037)) });
      dessinerVivant(fige ? 12 : t);
      if (racine.__QXC_STRICT) gD.getImageData(0, 0, 1, 1);                                              // mesure stricte : force le tramage dans le temps mesuré
      const ms = performance.now() - a0; mes.s += ms; mes.n++; mes.fen.push(ms); if (mes.fen.length > 90) mes.fen.shift();
      /* R454 — gouverneur au coût réel (JS, intervalle entre images, retard de l'ordonnanceur audio). Paliers : 1 toile vivante en
         1× · 2 cadence 30 im/s · 3 cadence 20 im/s + une nappe. Jamais plus bas : la dérive (CSS), le courant, la poussière et
         le souffle du nœud courant restent animés (avant : qualité 0,4 → courant et nappes éteints = carte « figée »). */
      if (o.auto !== false && palC < 3 && mes.fen.length >= 45) {
        const moy = mes.fen.reduce((x, y) => x + y, 0) / mes.fen.length, ra = racine.QXRET ? racine.QXRET.max(1000) : 0;
        if (moy > 6 || (mes.fi || 0) > 40 || ra > 25) { palC++; mes.fen = []; mes.raison = moy > 6 ? 'js' : ra > 25 ? 'audio' : 'image';
          if (palC === 1 && dprD > 1) { dprD = 1; cD.width = Math.round(l * dprD); cD.height = Math.round(h * dprD); }
          cadC = palC >= 3 ? 3 : palC >= 2 ? 2 : 1; if (palC >= 3 && qualite > 0.7) { qualite = 0.7; if (fond) fond.regler({ qualite }); } }
      }
      if (!fige) raf = racine.requestAnimationFrame(image);
    }
    let pause = false, pendant = (o.depuis !== undefined && o.depuis >= 0) ? o.depuis : -1;
    function lancerPendant() { if (pendant < 0) return; const kk = pendant; pendant = -1; const fin = etats; etats = fin.map(e => Object.assign({}, e)); valider(kk, fin); }
    function boucle() { if (!raf && !detruit) { pause = false; raf = racine.requestAnimationFrame(image); } }
    function surVisibilite() { if (!document.hidden && pause) boucle(); }
    function surTaille() { if (detruit) return; l = 0; boucle(); }
    document.addEventListener('visibilitychange', surVisibilite); racine.addEventListener('resize', surTaille);
    const surRetour = () => { if (!detruit) { attente = 0; boucle(); } }; racine.addEventListener('pageshow', surRetour);   // R454 : retour de l'arrière-plan (iOS)
    t0 = (racine.performance ? performance.now() : Date.now()) / 1000 - 3;   // t0 décalé : le décor est déjà « en vie » à l'ouverture
    const inst = {
      valider(kk) { valider(kk); },
      etats(liste) { anim = null; etats = liste.map(e => Object.assign({}, e)); majBoutons(); dessinerStatique(); boucle(); },
      mesure() { return { ms: mes.n ? mes.s / mes.n : 0, images: mes.n, qualite, dpr: dprD, palier: palC, cadence: cadC, fi: mes.fi || 0, raison: mes.raison || '', raf: !!raf, pause }; },
      reveil() { boucle(); },
      regler(r) { if (r.qualite !== undefined) { qualite = r.qualite; l = 0; } if (r.sobre !== undefined) o.sobre = r.sobre; mes = { s: 0, n: 0, fen: [] }; boucle(); },
      detruire() {
        detruit = true; if (raf) racine.cancelAnimationFrame(raf); raf = 0; clearTimeout(tVeille); racine.removeEventListener('pageshow', surRetour);
        document.removeEventListener('visibilitychange', surVisibilite); racine.removeEventListener('resize', surTaille);
        if (fond) fond.detruire(); racineDom.remove();
      }
    };
    cur = inst;
    if (disposer()) lancerPendant();
    boucle();
    return inst;
  }
  function detruire() { if (cur) { cur.detruire(); cur = null; } }

  let styleOk = false;
  function poserStyle() {
    if (styleOk) return; styleOk = true;
    const s = document.createElement('style');
    s.textContent = `
.qxc-n{position:absolute;width:48px;height:48px;margin:0;padding:0;border:0;border-radius:50%;background:transparent;cursor:pointer;
  -webkit-tap-highlight-color:transparent;display:flex;align-items:center;justify-content:center;font-family:inherit;font-weight:600;
  font-variant-numeric:tabular-nums;letter-spacing:0;color:#F2F8FF;text-shadow:0 0 3px rgba(3,5,10,.95),0 0 1px rgba(3,5,10,1);transition:opacity .5s,color .5s}
.qxc-n span{pointer-events:none;line-height:1}
.qxc-n.lock{color:rgba(205,218,232,.62);cursor:default}
.qxc-n.done{color:#FFFFFF}
.qxc-n.cur{color:#FFFFFF;font-weight:700}
.qxc-n.eveil{animation:qxcEveil .75s ease-out}
.qxc-n:focus-visible{outline:2px solid rgba(234,246,255,.8);outline-offset:-4px}
@keyframes qxcEveil{from{opacity:.2;transform:scale(.85)}to{opacity:1;transform:none}}`;
    document.head.appendChild(s);
  }

  racine.QXCARTE = { version: 1, actif, monter, detruire, configurer(d) { racine.QXCARTE_DONNEES = d; D = null; }, NOMS, get instance() { return cur; } };
})(typeof window !== 'undefined' ? window : globalThis);
