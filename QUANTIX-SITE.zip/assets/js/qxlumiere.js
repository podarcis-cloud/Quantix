/* =====================================================================
   QXLUMIERE v4 (L1 « cinéma » + branchement L2) — ambiance lumineuse subaquatique (QUANTIX). Voir DOSSIER-OPTIQUE.md et DOSSIER-PARTICULES.md.
   L2 : matière en suspension et bulles dans qxmatiere.js (chargé APRÈS ce fichier) ; ici : FAM, STYLE, styleParticule, délégation.
   Sources multiples : (a) soleil réfracté en éventail, (b) trouées étroites, (c) dôme / fenêtre de Snell,
   (d) lueurs ponctuelles (bio, source au sol), (e) lumière réverbérée (sol, parois, dessous des murs).
   Exposition (adaptation de l'œil), météo de surface à inertie, ombres (nuage, bateau, banc, baleine), balayage, couplage au décor QXFOND.
   Éléments QXPOOL : lumiere_faisceaux (plan volume), lumiere_caustiques, lumiere_poussiere et lumiere_bulles (délégués à qxmatiere.js).
   lumiere_surface / lumiere_source = alias inertes (v1 : intégrés au plan volume).
   Contrat élément : { regler(k), update(dt), dessiner(ctx,t), evenement?(type,e), effectif?() } — rien n'est alloué dans dessiner().
   Coupe-circuit : localStorage qxlumiere = '0' (ou ?lumiere=0). Charte : jetons du monde, jetons chauds filtrés, zone de réussite vide.
   ===================================================================== */
(function (racine) {
  'use strict';
  const TAU = Math.PI * 2;
  const borne = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lisse = (a, b, x) => { const t = borne((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const melange = (a, b, f) => a + (b - a) * f;
  const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
  const toile = (l, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(l)); c.height = Math.max(1, Math.round(h)); return c; };
  function aleatoire(graine) {
    let s = graine >>> 0;
    return function () { s = (s + 0x6D2B79F5) >>> 0; let t = Math.imul(s ^ (s >>> 15), s | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const gauss = A => { let u = 0; for (let i = 0; i < 4; i++) u += A(); return (u - 2) * 1.732; };   // ≈ N(0,1)
  const INTERDITS = { or: 1, ambre: 1, braise: 1, rebond: 1, laiton: 1, bronze: 1, corde: 1, danger: 1, creme: 1, brun: 1 };   // charte : pas de doré/orangé
  const SECOURS = [150, 220, 235];
  const melBlanc = (c, f) => [c[0] + (255 - c[0]) * f, c[1] + (255 - c[1]) * f, c[2] + (255 - c[2]) * f];
  const mel3 = (a, b, f) => [melange(a[0], b[0], f), melange(a[1], b[1], f), melange(a[2], b[2], f)];

  /* ---------- Jetons (B7) : tout réglage est ici ---------- */
  const DEF = {
    actif: 1, intensite: 1, direction: 0.16, palier: 'standard',   // jeu : Standard par défaut (iPhone) ; Cinéma sur appareils puissants (détection simple ou QXLUMIERE.palier / ?palier= / localStorage qxlumpalier)
    gain: 1, lune: 0, rais: 1,                                         // R531 : exposition propre au monde (dramaturgie), appliquée à tout le plan volume
    teinte: { ombre: 'sarcelle', lumiere: 'perle', faisceau: 'aqua', caustique: 'aqua', matiere: 'surface', bio: 'lueur', crepuscule: 'lilas', nuit: 'indigo', froid: 'profond', frange: 'cyan', secours: 'cyan' },
    soleil: { n: 6, eventail: 0.42, ecart: [0.08, 0.92], largeur: [34, 120], alpha: 0.6, decroit: 2.1, resp: [9, 24], balance: 0.022 },
    trouees: { n: 2, x: [0.2, 0.8], y: [-0.02, 0.06], angle: [-0.05, 0.12], largeur: [18, 36], alpha: 0.64, decroit: 1.5 },
    dome: { alpha: 0.5, rayon: 0.95, brume: 0.2 },
    rev: { alpha: 0.4, tau: 2.6, sol: 0.93, parois: 0.3, murs: 0.62 },
    bio: { n: 9, alpha: 0.62, taille: [12, 32] },
    source: { actif: 0, x: 0.5, alpha: 0.4, n: 5, largeur: 60 },
    expo: { force: 1, tau: 3.5, sombreMax: 0.56, froidMax: 0.42, vitesseMax: 0.12 },
    // R531 : caustiques BAISSÉES (alpha 0,62 → 0,3, bandes plus étroites) et ALLÉGÉES (dessinées dans le plan volume, toile basse résolution, recomposition étalée)
    caustiques: { plafond: 0.2, sol: 0.18, alpha: 0.3, solides: 0.5, tuile: 120, tuileMou: 210, periode: [15, 22], vitesse: [5, -3.5], largeurSolide: 30, res: 0.34 },
    surface: { haut: 0.13, alpha: 0.42, profMax: 0.8 },
    toile: { sobre: 0.5, standard: 0.5 },                           // R531 : résolution du plan volume (px CSS) ; Cinéma = devicePixelRatio (≤ 2)
    // particules / bulles : réglages dans DEF.matiere (qxmatiere.js, L2)
    meteo: { actif: 1, auto: 1, rythme: 1, sens: 1, scene: 'eclaircies',
      poids: { eclaircies: 4, clair: 2, couvert: 2, houle: 1.4, brume: 1, crepuscule: 0.8, tempete: 0.6, nuit: 0.5 },
      ombres: { nuage: 4, bateau: 1.2, banc: 1, baleine: 0.6, balayage: 0.8, eclaircie: 1.5 } }
  };
  /* R531 — DRAMATURGIE : une configuration PAR MONDE (générique pour tous ses niveaux), du clair solaire (Atelier) à l'abysse bioluminescent (Quantique) ;
     Fluides (12) rejoue la descente entière, de la surface (niveau 1) au fond (niveau 12+), par la profondeur. Jamais d'or/ambre/orangé (INTERDITS). */
  const P0 = { eclaircies: 0, clair: 0, couvert: 0, houle: 0, brume: 0, crepuscule: 0, tempete: 0, nuit: 0 };
  const poids = o => Object.assign({}, P0, o);
  const CFG = {
    1: { gain: 1.12, direction: 0.2, teinte: { ombre: 'acier', lumiere: 'blanc', faisceau: 'cyan', caustique: 'cyan', matiere: 'acier', bio: 'cyan', crepuscule: 'lilas', nuit: 'indigo', froid: 'encre', frange: 'cyan', secours: 'cyan' },
      soleil: { n: 6, alpha: 0.66, largeur: [40, 130] }, trouees: { n: 2 }, dome: { alpha: 0.6 }, bio: { n: 3, alpha: 0.3 }, expo: { sombreMax: 0.3 },
      meteo: { scene: 'clair', poids: poids({ clair: 4, eclaircies: 3, houle: 0.6 }) } },
    2: { gain: 1.05, direction: -0.1, teinte: { ombre: 'prune', lumiere: 'rose', faisceau: 'rose', caustique: 'carmin', matiere: 'carmin', bio: 'rose', crepuscule: 'violet', nuit: 'nuit', froid: 'nuit', frange: 'violet', secours: 'violet' },
      soleil: { n: 3, alpha: 0.42, largeur: [30, 80] }, trouees: { n: 1, alpha: 0.5 }, dome: { alpha: 0.34 }, caustiques: { alpha: 0.24, plafond: 0.16, sol: 0.16 },
      bio: { n: 8, alpha: 0.56 }, source: { actif: 1, x: 0.44, alpha: 0.5, n: 6 }, expo: { sombreMax: 0.42 },
      meteo: { actif: 0.7, scene: 'brume', poids: poids({ brume: 4, couvert: 1.5, eclaircies: 1 }) } },   // chambre à bulles : lueur carmin et rose, jamais doré
    3: { gain: 1.08, direction: 0.1, teinte: { ombre: 'indigo', lumiere: 'blanc', faisceau: 'lilas', caustique: 'lilas', matiere: 'violet', bio: 'cyan', crepuscule: 'violet', nuit: 'encre', froid: 'encre', frange: 'cyan', secours: 'cyan' },
      soleil: { n: 5, alpha: 0.6 }, trouees: { n: 3, alpha: 0.66 }, bio: { n: 5, alpha: 0.42 }, expo: { sombreMax: 0.36 },
      meteo: { scene: 'eclaircies', poids: poids({ eclaircies: 4, clair: 1.5, houle: 1.4, couvert: 0.8 }), ombres: { nuage: 2, bateau: 1.4, banc: 1.6, baleine: 0.4, balayage: 1.6, eclaircie: 1.5 } } },
    4: { gain: 1.1, direction: 0.06, teinte: { ombre: 'givre', lumiere: 'blanc', faisceau: 'glace', caustique: 'glace', matiere: 'givre', bio: 'cyan', crepuscule: 'lilas', nuit: 'profond', froid: 'profond', frange: 'cyan', secours: 'cyan' },
      soleil: { n: 5, alpha: 0.58, largeur: [24, 90], decroit: 1.8 }, trouees: { n: 2, alpha: 0.7, largeur: [12, 26] }, dome: { alpha: 0.56 }, caustiques: { alpha: 0.26 },
      bio: { n: 4, alpha: 0.36 }, expo: { sombreMax: 0.38, froidMax: 0.5 },
      meteo: { scene: 'clair', poids: poids({ clair: 3, couvert: 2, brume: 1.5, eclaircies: 1.5 }) } },   // lumière froide, cristalline
    5: { gain: 1.06, direction: -0.14, teinte: { ombre: 'acier', lumiere: 'argent', faisceau: 'air', caustique: 'glace', matiere: 'air', bio: 'glace', crepuscule: 'violet', nuit: 'ardoise', froid: 'ardoise', frange: 'glace', secours: 'glace' },
      soleil: { n: 5, alpha: 0.56, balance: 0.05 }, trouees: { n: 2, alpha: 0.6 }, bio: { n: 4, alpha: 0.36 }, expo: { sombreMax: 0.42 },
      meteo: { scene: 'houle', rythme: 1.3, poids: poids({ houle: 4, tempete: 1.2, eclaircies: 1.5, couvert: 1 }), ombres: { nuage: 5, bateau: 0.6, banc: 1, baleine: 0.3, balayage: 1.4, eclaircie: 1 } } },   // vent : faisceaux qui balancent
    6: { gain: 1.1, direction: 0.12, teinte: { ombre: 'acier', lumiere: 'blanc', faisceau: 'acier', caustique: 'cyan', matiere: 'acier', bio: 'cyan', crepuscule: 'cyan', nuit: 'nuit', froid: 'nuit', frange: 'cyan', secours: 'cyan' },
      soleil: { n: 2, alpha: 0.4, largeur: [26, 60] }, trouees: { n: 4, alpha: 0.78, largeur: [10, 20], x: [0.12, 0.88] }, dome: { alpha: 0.34 }, caustiques: { alpha: 0.22 },
      bio: { n: 5, alpha: 0.4 }, expo: { sombreMax: 0.48 },
      meteo: { scene: 'couvert', poids: poids({ couvert: 4, brume: 1.5, eclaircies: 1 }), ombres: { nuage: 2, bateau: 1, banc: 0.6, baleine: 0.2, balayage: 2.4, eclaircie: 1 } } },   // atelier d'acier : rais étroits entre les pièces, jamais laiton
    7: { gain: 1.14, lune: 0.3, rais: 1.4, direction: 0.3, teinte: { ombre: 'indigo', lumiere: 'blanc', faisceau: 'violet', caustique: 'violet', matiere: 'indigo', bio: 'vert', crepuscule: 'violet', nuit: 'encre', froid: 'encre', frange: 'cyan', secours: 'violet' },
      soleil: { n: 4, alpha: 0.6, eventail: 0.6 }, trouees: { n: 2, alpha: 0.64 }, bio: { n: 8, alpha: 0.5 }, expo: { sombreMax: 0.5 },
      meteo: { scene: 'crepuscule', poids: poids({ crepuscule: 4, eclaircies: 1, nuit: 1, brume: 0.8 }) } },   // crépuscule, lucioles vertes
    8: { gain: 1.16, lune: 0.4, rais: 1.5, direction: -0.2, teinte: { ombre: 'prune', lumiere: 'lilas', faisceau: 'rose', caustique: 'lilas', matiere: 'prune', bio: 'rose', crepuscule: 'violet', nuit: 'encre', froid: 'encre', frange: 'cyan', secours: 'violet' },
      soleil: { n: 4, alpha: 0.56 }, trouees: { n: 2, alpha: 0.6 }, bio: { n: 10, alpha: 0.6 }, source: { actif: 1, x: 0.56, alpha: 0.36, n: 4 }, expo: { sombreMax: 0.5 },
      meteo: { scene: 'crepuscule', poids: poids({ crepuscule: 3, nuit: 2, brume: 1 }) } },
    9: { gain: 1.5, lune: 0.75, rais: 2.4, direction: 0.04, teinte: { ombre: 'indigo', lumiere: 'blanc', faisceau: 'lilas', caustique: 'cyan', matiere: 'prune', bio: 'cyan', crepuscule: 'violet', nuit: 'lilas', froid: 'encre', frange: 'cyan', secours: 'cyan' },
      soleil: { n: 3, eventail: 0.9, ecart: [0.3, 0.7], largeur: [30, 80], alpha: 0.7 }, trouees: { n: 3, x: [0.22, 0.78], largeur: [10, 22], alpha: 0.8 },
      dome: { alpha: 0.42 }, caustiques: { alpha: 0.26, plafond: 0.16 }, bio: { n: 14, alpha: 0.85, taille: [14, 38] },
      source: { actif: 1, x: 0.62, alpha: 0.56, n: 6, largeur: 70 }, expo: { sombreMax: 0.6, froidMax: 0.3 },
      meteo: { actif: 0.85, rythme: 0.8, scene: 'nuit', poids: poids({ nuit: 4, brume: 1.2, crepuscule: 1 }) } },   // la faille luit d'en bas : source au sol, rais lilas, bio cyan
    10: { gain: 1.4, lune: 0.5, rais: 2, direction: -0.06, teinte: { ombre: 'prune', lumiere: 'lilas', faisceau: 'mauve', caustique: 'lilas', matiere: 'mauve', bio: 'rose', crepuscule: 'violet', nuit: 'violet', froid: 'nuit', frange: 'lilas', secours: 'violet' },
      soleil: { n: 3, alpha: 0.5, largeur: [26, 70] }, trouees: { n: 2, alpha: 0.6 }, dome: { alpha: 0.36, brume: 0.3 }, caustiques: { alpha: 0.2 }, bio: { n: 14, alpha: 0.8 },
      expo: { sombreMax: 0.62 }, meteo: { scene: 'nuit', poids: poids({ nuit: 3, brume: 2.5, crepuscule: 0.8 }) } },
    11: { gain: 1.5, lune: 0.3, rais: 2, direction: 0, teinte: { ombre: 'indigo', lumiere: 'lilas', faisceau: 'violet', caustique: 'lilas', matiere: 'indigo', bio: 'cyan', crepuscule: 'violet', nuit: 'violet', froid: 'nuit', frange: 'cyan', secours: 'violet' },
      soleil: { n: 2, alpha: 0.38, largeur: [20, 50] }, trouees: { n: 1, alpha: 0.6, largeur: [8, 16] }, dome: { alpha: 0.3 }, caustiques: { alpha: 0.16, plafond: 0.12, sol: 0.12 },
      bio: { n: 18, alpha: 0.9, taille: [10, 34] }, expo: { sombreMax: 0.66 },
      meteo: { actif: 0.9, scene: 'nuit', poids: poids({ nuit: 5, brume: 1 }) } },   // abysse : presque plus de ciel, la vie éclaire
    12: { gain: 1.08, bio: { n: 12, alpha: 0.7 }, expo: { sombreMax: 0.5 },
      meteo: { scene: 'eclaircies', poids: poids({ eclaircies: 4, clair: 2, couvert: 1.5, houle: 1.4, brume: 1, crepuscule: 0.8, nuit: 0.5 }) } }   // le grand bassin : la descente entière par la profondeur
  };
  const ACTIFS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];   // R531 : tous les mondes à décor QXF2
  function fusion(a, b) {
    if (!b) return a;
    const o = Array.isArray(a) ? a.slice() : Object.assign({}, a);
    for (const k in b) o[k] = (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a && typeof a[k] === 'object') ? fusion(a[k], b[k]) : b[k];
    return o;
  }
  let VER = 1;
  const cfgDe = id => fusion(DEF, CFG[id]);
  function coul(P, jeton, repli) {
    const ok = j => P[j] && !INTERDITS[j];
    return ok(jeton) ? P[jeton] : ok(repli) ? P[repli] : ok('cyan') ? P.cyan : ok('blanc') ? P.blanc : SECOURS;
  }
  const coupe = () => { try { if (racine.localStorage.getItem('qxlumiere') === '0') return true; } catch (e) {} try { return /[?&]lumiere=0/.test(racine.location.search); } catch (e) { return false; } };

  /* ---------- Sprites (créés une fois, cache) ---------- */
  const CACHE = {};
  const memo = (cle, f) => CACHE[cle] || (CACHE[cle] = f());
  const vertical = (s, decroit) => lisse(0, 0.08, s) * Math.exp(-decroit * s) * (1 - lisse(0.72, 1, s));
  const DEMI = s => 0.5 + 0.5 * s;
  /* faisceau : profil gaussien + stries, décroissance exponentielle, TEINTE CUITE le long de l'axe (absorption : lumière → faisceau → ombre) */
  function spriteFaisceau(cH, cM, cB, flou, graine, decroit) {
    return memo('fx' + cH + cM + cB + flou + graine + decroit, () => {
      const W = 64, H = 256, c = toile(W, H), g = c.getContext('2d'), im = g.createImageData(W, H), d = im.data, A = aleatoire(graine);
      const st = []; for (let k = 0; k < 6; k++) st.push({ x: (A() - 0.5) * 1.6, w: 0.07 + 0.12 * A(), a: 0.12 + 0.3 * A() });
      for (let y = 0; y < H; y++) {
        const s = y / H, v = vertical(s, decroit), dm = DEMI(s), col = s < 0.3 ? mel3(cH, cM, s / 0.3) : mel3(cM, cB, (s - 0.3) / 0.7);
        for (let x = 0; x < W; x++) {
          const q = ((x + 0.5) / W * 2 - 1) / dm;
          let a = Math.exp(-q * q * 3.4 * (flou ? 0.5 : 1)) + 0.22 * Math.exp(-q * q * 0.7);
          let str = 0; for (let k = 0; k < 6; k++) { const z = (q - st[k].x) / st[k].w; str += st[k].a * Math.exp(-z * z); }
          a *= (0.72 + str * (flou ? 0.4 : 1)) * v;
          const i = (y * W + x) * 4; d[i] = col[0]; d[i + 1] = col[1]; d[i + 2] = col[2]; d[i + 3] = Math.min(255, a * 255);
        }
      }
      g.putImageData(im, 0, 0); return c;
    });
  }
  function radial(S, rgb, stops, sy) {
    const c = toile(S, S * (sy || 1)), g = c.getContext('2d'); g.scale(1, sy || 1); const r = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    for (const [o, a] of stops) r.addColorStop(o, rgba(rgb, a));
    g.fillStyle = r; g.fillRect(0, 0, S, S); return c;
  }
  function degradeV(rgb, stops) { const c = toile(4, 128), g = c.getContext('2d'), r = g.createLinearGradient(0, 0, 0, 128); for (const [o, a] of stops) r.addColorStop(o, rgba(rgb, a)); g.fillStyle = r; g.fillRect(0, 0, 4, 128); return c; }
  function degradeH(rgb, stops) { const c = toile(128, 4), g = c.getContext('2d'), r = g.createLinearGradient(0, 0, 128, 0); for (const [o, a] of stops) r.addColorStop(o, rgba(rgb, a)); g.fillStyle = r; g.fillRect(0, 0, 128, 4); return c; }

  /* ---------- Atlas de caustiques : réseau cellulaire périodique, 12 images, une image calculée par update ---------- */
  /* Atlas de caustiques PHYSIQUE : surface périodique (somme de vagues), rayons réfractés (Snell, petits angles) projetés sur un plan à la profondeur D,
     densité accumulée → réseau cellulaire vrai (lignes vives = nappes caustiques). 12 images en boucle, UNE image calculée par update.
     mou = plan plus profond + flou (les petites rides ont dépassé leur foyer : cellules plus grandes, plus douces). */
  const ATLAS = {};
  function atlasDe(rgb, N, S, mou) {
    const cle = rgb + '|' + N + '|' + S + '|' + (mou ? 1 : 0);
    if (ATLAS[cle]) return ATLAS[cle];
    const at = { N, S, images: [], patrons: [], pret: false, k: 0, ondes: [] }, Ar = aleatoire(4242 + (mou ? 99 : 0));
    const K = [[1, 0], [0, 1], [1, 1], [1, -1], [2, 1], [1, 2], [-2, 1], [2, -1], [3, 1], [1, 3], [-1, 3], [3, -2], [4, 1], [-1, 4], [2, 3], [-3, -2]];
    for (let j = 0; j < K.length; j++) { const kk = K[j], km = Math.hypot(kk[0], kk[1]); at.ondes.push({ kx: kk[0], ky: kk[1], a: (0.9 + 0.4 * Ar()) / Math.pow(km, 1.5), ph: Ar() * TAU, om: (Ar() < 0.5 ? -1 : 1) * Math.max(1, Math.round(Math.sqrt(km) * 1.3)) }); }
    const R = 2, NR = S * R, dens = new Float32Array(S * S), tmp = new Float32Array(S * S), Dp = (mou ? 0.95 : 0.82) * S / TAU / 3.2;
    // R531 : tables trigonométriques (cos(A+B) = cosA·cosB − sinA·sinB) → plus aucun Math.cos dans la boucle ; une image en 8 tranches
    const NW = at.ondes.length, TX = new Float32Array(NW * NR * 2), TY = new Float32Array(NW * 2);
    for (let j = 0; j < NW; j++) { const o = at.ondes[j]; for (let xx = 0; xx < NR; xx++) { const ph = TAU * o.kx * ((xx + 0.5) / R) / S; TX[(j * NR + xx) * 2] = Math.cos(ph); TX[(j * NR + xx) * 2 + 1] = Math.sin(ph); } }
    at.suivante = function () {
      if (at.k >= N) return true;
      const tau = TAU * at.k / N, W = at.ondes; if (!at.y) dens.fill(0);
      const yA = at.y | 0, t0 = racine.performance ? racine.performance.now() : 0; let yB = yA;   // R531 : rangées calculées dans un budget de 1,5 ms par image → pas de pic au montage
      for (let yy = yA; yy < NR; yy++) {
        if (yy > yA + 3 && racine.performance && racine.performance.now() - t0 > 1.5) break; yB = yy + 1;
        const y = (yy + 0.5) / R;
        for (let j = 0; j < NW; j++) { const o = W[j], ph = TAU * o.ky * y / S + o.ph + o.om * tau; TY[j * 2] = Math.cos(ph); TY[j * 2 + 1] = Math.sin(ph); }
        for (let xx = 0; xx < NR; xx++) {
        const x = (xx + 0.5) / R; let gx = 0, gy = 0;
        for (let j = 0; j < NW; j++) { const q = (j * NR + xx) * 2, c = W[j].a * (TX[q] * TY[j * 2] - TX[q + 1] * TY[j * 2 + 1]) * TAU / S; gx += c * W[j].kx; gy += c * W[j].ky; }
      let px = x + Dp * gx * S / TAU, py = y + Dp * gy * S / TAU;
        px = ((px % S) + S) % S; py = ((py % S) + S) % S;
        const ix = px | 0, iy = py | 0, fx = px - ix, fy = py - iy, ix1 = (ix + 1) % S, iy1 = (iy + 1) % S;
        dens[iy * S + ix] += (1 - fx) * (1 - fy); dens[iy * S + ix1] += fx * (1 - fy); dens[iy1 * S + ix] += (1 - fx) * fy; dens[iy1 * S + ix1] += fx * fy;
        }
      }
      at.y = yB; if (yB < NR) return false; at.y = 0;
      if (mou) for (let pass = 0; pass < 3; pass++) { for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { let v = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) v += dens[((y + dy + S) % S) * S + (x + dx + S) % S]; tmp[y * S + x] = v / 9; } dens.set(tmp); }
      const c = toile(S, S), g = c.getContext('2d'), im = g.createImageData(S, S), d = im.data, moy = R * R;
      for (let i = 0; i < S * S; i++) { const I = dens[i] / moy, a = mou ? 0.8 * Math.pow(borne((I - 0.72) / 1.7, 0, 1), 0.9) : Math.pow(borne((I - 0.8) / 2.6, 0, 1), 0.75); d[i * 4] = rgb[0]; d[i * 4 + 1] = rgb[1]; d[i * 4 + 2] = rgb[2]; d[i * 4 + 3] = a * 255; }
      g.putImageData(im, 0, 0); at.images.push(c); at.patrons.push(g.createPattern(c, 'repeat')); at.k++;
      if (at.k >= N) at.pret = true; return at.pret;
    };
    return (ATLAS[cle] = at);
  }

  /* =====================================================================
     MÉTÉO DE SURFACE : scènes (état de base, transitions lentes) + événements (ombres, balayage, éclaircie)
       S soleil · D diffusion/couverture · H houle · B brume · C crépuscule · N nuit
     ===================================================================== */
  const SCENES = {
    clair: { S: 1, D: 0.08, H: 0.25, B: 0, C: 0, N: 0, om: 0.2 },
    eclaircies: { S: 0.95, D: 0.28, H: 0.35, B: 0.04, C: 0, N: 0, om: 1 },
    couvert: { S: 0.6, D: 0.94, H: 0.3, B: 0.14, C: 0, N: 0, om: 0 },
    houle: { S: 0.95, D: 0.18, H: 0.95, B: 0.06, C: 0, N: 0, om: 0.3 },
    tempete: { S: 0.42, D: 0.86, H: 1, B: 0.22, C: 0, N: 0.1, om: 0.25 },
    crepuscule: { S: 0.8, D: 0.24, H: 0.2, B: 0.06, C: 1, N: 0, om: 0.2 },
    nuit: { S: 0.55, D: 0.35, H: 0.15, B: 0.05, C: 0.15, N: 1, om: 0 },
    brume: { S: 0.85, D: 0.5, H: 0.15, B: 1, C: 0, N: 0, om: 0.1 }
  };
  const ALIAS = { orage: 'tempete', soleil: 'clair' };
  const OMBRES = { nuage: { w: 220, a: 0.9, v: 30 }, bateau: { w: 70, a: 0.95, v: 12 }, banc: { w: 54, a: 0.5, v: 34 }, baleine: { w: 150, a: 0.92, v: 9 } };
  const TAU_V = { S: 3.5, D: 4.5, H: 5, B: 6, C: 9, N: 9 }, CLES = ['S', 'D', 'H', 'B', 'C', 'N'];
  function creerMeteo(L, C) {
    const Mt = C.meteo, A = aleatoire(9001 + L.id * 13 + L.niveau), amp = Mt.actif;
    const s0 = SCENES[Mt.scene] || SCENES.clair;
    const M = { cur: {}, cib: {}, scene: SCENES[Mt.scene] ? Mt.scene : 'clair', auto: !!Mt.auto, vitesse: 1, fige: false, t: 0, prochaineScene: 40 + 25 * A(), prochaineOmbre: 6 + 8 * A(), derniere: Mt.scene,
      om: [0, 1, 2].map(() => ({ on: 0, x: 0, v: 0, w: 0, a: 0, type: '' })), ecl: { on: 0, t0: 0, dur: 24 }, bal: { on: 0, t0: 0, dur: 16, sens: 1 }, tc: 0, ts: 0 };
    for (const k of CLES) { M.cur[k] = s0[k]; M.cib[k] = s0[k]; }
    M.choisirScene = function (nom) { nom = ALIAS[nom] || nom; if (!SCENES[nom]) return false; M.scene = nom; M.derniere = nom; return true; };
    M.declencher = function (type, opts) {
      if (OMBRES[type]) {
        const o = OMBRES[type], k = Math.max(0.5, L.W / 390); let j = 0; while (j < 2 && M.om[j].on) j++;
        const s = M.om[j], sens = (opts && opts.sens) || Mt.sens || 1, w = o.w * k * (0.8 + 0.4 * A());
        s.on = 1; s.type = type; s.w = w; s.a = o.a * amp; s.v = o.v * k * sens * (0.85 + 0.3 * A()); s.x = s.v > 0 ? -w * 1.8 : L.W + w * 1.8; M.derniere = type; return true;
      }
      if (type === 'eclaircie') { M.ecl.on = 1; M.ecl.t0 = M.t; M.derniere = type; return true; }
      if (type === 'balayage') { M.bal.on = 1; M.bal.t0 = M.t; M.bal.sens = A() < 0.5 ? 1 : -1; M.derniere = type; return true; }
      return M.choisirScene(type);
    };
    M.effacer = function () { for (const s of M.om) s.on = 0; M.ecl.on = 0; M.bal.on = 0; };
    M.maj = function (dt) {
      if (M.fige) return; dt *= M.vitesse; M.t += dt;
      const sc = SCENES[M.scene];
      if (M.auto) {
        if (M.t > M.prochaineScene) {        // enchaînement contemplatif des scènes (graine fixe)
          const P = Mt.poids; let tot = 0; for (const k in P) if (k !== M.scene && P[k] > 0) tot += P[k]; let r = A() * tot, ch = null;
          for (const k in P) { if (k === M.scene || !(P[k] > 0)) continue; r -= P[k]; if (r <= 0) { ch = k; break; } }
          if (ch) M.choisirScene(ch);   // R531 : poids nul = scène exclue du monde M.prochaineScene = M.t + (38 + 34 * A()) / Math.max(0.2, Mt.rythme);
        }
        if (M.t > M.prochaineOmbre) {        // ombres et éclaircies, fréquence selon la scène
          const P = Mt.ombres; let tot = 0; for (const k in P) tot += P[k]; let r = A() * tot, ch = 'nuage';
          for (const k in P) { r -= P[k]; if (r <= 0) { ch = k; break; } }
          if (sc.om > 0.05 || ch === 'baleine' || ch === 'banc') M.declencher(ch);
          M.prochaineOmbre = M.t + (9 + 16 * A()) / Math.max(0.15, sc.om) / Math.max(0.2, Mt.rythme);
        }
      }
      const c = M.cib;
      for (const k of CLES) c[k] = melange(SCENES.clair[k], sc[k], amp);
      if (M.ecl.on) { const u = (M.t - M.ecl.t0) / M.ecl.dur; if (u >= 1) M.ecl.on = 0; else { const e = lisse(0, 0.2, u) * (1 - lisse(0.6, 1, u)) * amp; c.S += 0.4 * e; c.D -= 0.4 * e; c.B -= 0.3 * e; } }
      c.S += 0.06 * Math.sin(TAU * M.t / 97) * amp; c.D += 0.05 * Math.sin(TAU * M.t / 131 + 1) * amp;
      for (const k of CLES) c[k] = borne(c[k], 0, k === 'S' ? 1.3 : 1);
      for (const s of M.om) { if (!s.on) continue; s.x += s.v * dt; if ((s.v > 0 && s.x > L.W + s.w * 2) || (s.v < 0 && s.x < -s.w * 2)) s.on = 0; }
      if (M.bal.on && M.t - M.bal.t0 > M.bal.dur) M.bal.on = 0;
      const ralenti = 1 + 1.5 * L.prof;
      for (const k of CLES) M.cur[k] += (c[k] - M.cur[k]) * (1 - Math.exp(-dt / (TAU_V[k] * ralenti)));
      M.tc += dt * (0.5 + 1.3 * M.cur.H); M.ts += dt * (0.6 + 1.6 * M.cur.H);
    };
    M.transmission = function (x) {           // ombres qui passent (bord doux, élargi par la profondeur)
      let tr = 1; const ef = 1 + 1.1 * L.prof;
      for (const s of M.om) if (s.on) { const g = (x - s.x) / (s.w * ef); tr *= 1 - s.a * Math.exp(-g * g); }
      return tr;
    };
    M.balayage = function (xn) {              // cascade de rayons qui balaye (gain 0,55 … 2)
      if (!M.bal.on) return 1; const u = (M.t - M.bal.t0) / M.bal.dur, env = lisse(0, 0.15, u) * (1 - lisse(0.8, 1, u));
      const p = M.bal.sens > 0 ? melange(-0.25, 1.25, u) : melange(1.25, -0.25, u), g = (xn - p) / 0.16;
      return 1 + env * (1.1 * Math.exp(-g * g) - 0.42);
    };
    return M;
  }

  /* =====================================================================
     SCÈNE LUMIÈRE (une par pool) — repère ÉCRAN (W×H) ; le terrain est décalé de (ox, oy)
     ===================================================================== */
  let ACTIVE = null, COUPLE = null;
  function scene(sc) {
    if (sc.lum && sc.lum.ver === VER && sc.lum.niveau === sc.niveau) return sc.lum;
    const C = cfgDe(sc.cfg.id), P = sc.cfg.palette, l = sc.l, h = sc.h;
    const cp = COUPLE && Math.abs(COUPLE.zone.l - l) < 2 && Math.abs(COUPLE.zone.h - h) < 2 ? COUPLE : null;
    const W = cp ? cp.W : l, H = cp ? cp.H : h, ox = cp ? cp.zone.x : 0, oy = cp ? cp.zone.y : 0;
    const L = { ver: VER, niveau: sc.niveau, id: sc.cfg.id, C, sc, l, h, W, H, ox, oy, cp, tMaj: -2, tPrev: 0, prof: borne((sc.niveau - 1) / 11, 0, 1), pal: PALIER_FORCE || C.palier };
    const A = aleatoire(sc.cfg.id * 31 + sc.niveau * 7 + 5);
    L.Ht = cp ? oy : 0; L.Hb = cp ? Math.min(H, oy + h) : H; const Hb = L.Hb;   // R531 : haut et bas de la scène jouée (écran) — le sol est le bas du terrain, pas le bas de l'écran
    const T = C.teinte;
    L.cOmbre = coul(P, T.ombre, T.secours); L.cLum = coul(P, T.lumiere, 'blanc'); L.cFais = coul(P, T.faisceau, T.secours); L.cCaust = coul(P, T.caustique, T.faisceau);
    L.cMat = coul(P, T.matiere, T.ombre); L.cBio = coul(P, T.bio, T.secours); L.cCre = coul(P, T.crepuscule, 'lilas'); L.cNuit = coul(P, T.nuit, T.ombre); L.cFroid = coul(P, T.froid, T.ombre);
    L.cFrange = coul(P, T.frange, T.secours); L.cFond = coul(P, sc.cfg.plancher || 'abysse', T.froid);
    const hautJ = melBlanc(L.cLum, 0.25), hautC = melBlanc(L.cCre, 0.3), hautN = melBlanc(L.cNuit, 0.55);
    // (a) soleil réfracté : éventail convergeant vers un point virtuel au-dessus de l'écran (perspective, ref4/ref6)
    const F = C.soleil, nS = Math.round(F.n), B = [];
    for (let i = 0; i < nS; i++) {
      const xn = melange(F.ecart[0], F.ecart[1], (i + 0.5 + (A() - 0.5) * 0.8) / Math.max(1, nS)), flou = A() < 0.45, Wd = melange(F.largeur[0], F.largeur[1], A() * A());
      B.push({ type: 'soleil', xn, sx: xn * W, sy: -0.03 * H, ang0: 0, ang: 0, dx: 0, dy: 1, W: Wd, We: Wd, L: 1.2 * H, gain: 0.4 + 0.6 * A(), flou, ph: A() * TAU, ph2: A() * TAU, ph3: A() * TAU,
        T1: melange(F.resp[0], F.resp[1], A()), T2: melange(F.resp[0], F.resp[1], A()) * 1.7, TB: 17 + 14 * A(), I: 0, rev: 0, react: 0, reactCible: 0, decroit: F.decroit, ix: 0, iy: 0,
        sp: [spriteFaisceau(hautJ, L.cFais, L.cOmbre, flou, 100 + i * 17, F.decroit), spriteFaisceau(hautC, L.cCre, L.cOmbre, flou, 100 + i * 17, F.decroit), spriteFaisceau(hautN, L.cNuit, L.cFroid, flou, 100 + i * 17, F.decroit)] });
    }
    // (b) trouées : faisceaux étroits et tranchants, autre angle, tache d'entrée et d'impact (ref1)
    const Tq = C.trouees, nT = Math.round(Tq.n);
    for (let i = 0; i < nT; i++) {
      const xn = melange(Tq.x[0], Tq.x[1], nT === 1 ? 0.35 + 0.3 * A() : (i + 0.2 + 0.6 * A()) / nT), Wd = melange(Tq.largeur[0], Tq.largeur[1], A());
      B.push({ type: 'trouee', xn, sx: xn * W, sy: melange(Tq.y[0], Tq.y[1], A()) * H, ang0: melange(Tq.angle[0], Tq.angle[1], A()), ang: 0, dx: 0, dy: 1, W: Wd, We: Wd, L: 0.8 * H, gain: 0.65 + 0.35 * A(), flou: true,
        ph: A() * TAU, ph2: A() * TAU, ph3: A() * TAU, T1: 13 + 12 * A(), T2: 29 + 10 * A(), TB: 23 + 9 * A(), I: 0, rev: 0, react: 0, reactCible: 0, decroit: Tq.decroit, ix: 0, iy: 0,
        sp: [spriteFaisceau(melBlanc(L.cLum, 0.45), melBlanc(L.cFais, 0.15), L.cOmbre, true, 300 + i * 23, Tq.decroit), spriteFaisceau(hautC, L.cCre, L.cOmbre, true, 300 + i * 23, Tq.decroit), spriteFaisceau(hautN, L.cNuit, L.cFroid, true, 300 + i * 23, Tq.decroit)] });
    }
    L.B = B; L.nS = nS; L.nVis = B.length;
    // (d) lueurs ponctuelles : bioluminescence (bas et côtés), source au sol optionnelle
    const Cb = C.bio; L.bio = [];
    for (let i = 0; i < Cb.n; i++) {
      let x = 0, y = 0; for (let k = 0; k < 8; k++) { x = (A() < 0.5 ? A() * 0.22 : 0.78 + A() * 0.22) * W; if (A() < 0.4) x = A() * W; y = L.Ht + (0.3 + 0.66 * A()) * (Hb - L.Ht); if (!cp || !cp.reussite || Math.hypot(x - cp.reussite.x, y - cp.reussite.y) > cp.reussite.r + 70) break; }
      L.bio.push({ x, y, r: melange(Cb.taille[0], Cb.taille[1], A()), ph: A() * TAU, T: 5 + 9 * A(), I: 0 });
    }
    const Cs = C.source; let xS = Cs.x * W; if (cp && cp.reussite) { const rr = cp.reussite, loin = xx => Math.abs(xx - rr.x) > rr.r + 90; if (!loin(xS)) xS = loin(W - xS) ? W - xS : (rr.x > W / 2 ? 0.22 : 0.78) * W; }   // R531 : la source au sol fuit la zone de réussite (B5)
    L.src = Cs.actif ? { x: xS, y: Hb * 0.985, n: Cs.n, R: [], I: 0 } : null;
    if (L.src) for (let i = 0; i < Cs.n; i++) L.src.R.push({ ang: (i - (Cs.n - 1) / 2) / Cs.n * 0.85 + (A() - 0.5) * 0.12, W: Cs.largeur * (0.5 + 0.8 * A()), L: H * (0.3 + 0.32 * A()), ph: A() * TAU, T: 9 + 12 * A(),
      sp: spriteFaisceau(melBlanc(L.cBio, 0.3), L.cBio, L.cOmbre, i % 2 === 0, 500 + i, 2.6) });
    L.spr = {
      fenetre: radial(256, melBlanc(L.cLum, 0.2), [[0, 0.9], [0.12, 0.6], [0.38, 0.22], [0.7, 0.06], [1, 0]], 0.5),
      fenetreC: radial(256, hautC, [[0, 0.8], [0.15, 0.45], [0.45, 0.14], [1, 0]], 0.5),
      fenetreN: radial(256, hautN, [[0, 0.7], [0.08, 0.35], [0.3, 0.08], [1, 0]], 0.5),
      dome: degradeV(L.cFais, [[0, 0.75], [0.35, 0.2], [1, 0]]), brume: degradeV(L.cOmbre, [[0, 0.5], [0.5, 0.75], [1, 0.4]]),
      revSol: radial(128, melBlanc(mel3(L.cMat, L.cFais, 0.45), 0.08), [[0, 0.9], [0.35, 0.45], [1, 0]], 0.42), revLum: radial(128, melBlanc(L.cFais, 0.3), [[0, 0.8], [0.2, 0.35], [1, 0]], 0.35),
      paroi: degradeH(L.cMat, [[0, 0.8], [0.4, 0.2], [1, 0]]), entree: radial(64, melBlanc(L.cLum, 0.6), [[0, 1], [0.15, 0.6], [0.45, 0.14], [1, 0]]),
      bio: radial(64, L.cBio, [[0, 0.95], [0.12, 0.6], [0.4, 0.16], [1, 0]]), bioC: radial(64, melBlanc(L.cBio, 0.6), [[0, 1], [0.3, 0.3], [1, 0]])
    };
    // plafond d'eau (ondulations fines, bande en haut de l'écran)
    { const Su = C.surface, Wt = 520, Ht = Math.max(8, Math.round(H * Su.haut)), c = toile(Wt, Ht), g = c.getContext('2d');
      for (let m = 0; m < 18; m++) {
        const yb = Ht * (1 - Math.pow(1 - (m + 0.5) / 18, 1.7)) * 0.95 + 2, amp = 1 + 4.5 * (m / 18), k1 = 2 + ((A() * 3) | 0), k2 = 5 + ((A() * 4) | 0), p1 = A() * TAU, p2 = A() * TAU;
        g.strokeStyle = rgba(melBlanc(L.cLum, 0.2), 0.14 + 0.55 * A() * (0.4 + 0.6 * m / 18)); g.lineWidth = 0.8 + 0.5 * A(); g.beginPath();
        for (let xx = 0; xx <= Wt; xx += 6) { const yy = yb + amp * Math.sin(TAU * k1 * xx / Wt + p1) + amp * 0.4 * Math.sin(TAU * k2 * xx / Wt + p2); xx ? g.lineTo(xx, yy) : g.moveTo(xx, yy); }
        g.stroke();
      }
      g.globalCompositeOperation = 'destination-in'; const gr = g.createLinearGradient(0, 0, 0, Ht); gr.addColorStop(0, 'rgba(0,0,0,0.2)'); gr.addColorStop(0.2, 'rgba(0,0,0,1)'); gr.addColorStop(0.75, 'rgba(0,0,0,0.6)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, Wt, Ht);
      L.surf = { c, Wt, Ht, fond: lisse(0, 1, 1 - L.prof / Su.profMax), NS: 40, x: new Float32Array(40), y: new Float32Array(40), ph: new Float32Array(40), fq: new Float32Array(40), sz: new Float32Array(40) };
      for (let i = 0; i < 40; i++) { L.surf.x[i] = A() * W; L.surf.y[i] = Ht * (0.12 + 0.85 * Math.sqrt(A())); L.surf.ph[i] = A() * TAU; L.surf.fq[i] = 0.08 + 0.3 * A(); L.surf.sz[i] = 1.5 + 2.5 * A(); } }

    L.M = creerMeteo(L, C);
    if (sc.lum && sc.lum.M) { const o = sc.lum.M, M = L.M; M.cur = o.cur; M.t = o.t; M.om = o.om; M.auto = o.auto; M.vitesse = o.vitesse; M.fige = o.fige; M.scene = o.scene; M.prochaineScene = o.prochaineScene; M.prochaineOmbre = o.prochaineOmbre; M.derniere = o.derniere; M.tc = o.tc; M.ts = o.ts; M.ecl = o.ecl; M.bal = o.bal; }
    // état d'éclairage dérivé (une fois par image)
    const E = L.E = { ciel: 1, direct: 1, diffus: 0.3, lum: 1, adapt: 0.85, G: 1, Gt: 1, Ga: 1, rev: 0.6, froid: 0, sombre: 0, trMoy: 1, bioVis: 0, sunX: W * 0.5, dir: 0, clair: 0.8 * 0.92 + 0.6 * 0.26, disp: 1 };
    if (sc.lum && sc.lum.E) { const o = sc.lum.E; E.adapt = o.adapt; E.Gt = o.Gt; E.rev = o.rev; }
    L.calcE = function (dt) {
      const cu = L.M.cur, Cx = C.expo;
      E.ciel = (1 - 0.8 * cu.N * (1 - (C.lune || 0))) * (1 - 0.42 * cu.C) * (0.35 + 0.65 * Math.min(1, cu.S));
      const pompe = 1 + 0.32 * cu.H * cu.H * Math.sin(TAU * L.M.t / 2.7) * (0.6 + 0.4 * Math.sin(TAU * L.M.t / 7.3));   // pompage de la houle (≤ 0,4 Hz)
      E.direct = E.ciel * cu.S * Math.pow(1 - cu.D, 1.4) * (1 - 0.35 * cu.B) * pompe;
      E.diffus = E.ciel * (0.22 + 0.5 * cu.D + 0.3 * cu.B) * 0.6;
      let tr = 0; for (let k = 0; k < 3; k++) tr += L.M.transmission(W * (0.2 + 0.3 * k)) / 3; E.trMoy = tr;
      E.lum = E.direct * (0.25 + 0.75 * tr) * 0.8 + E.diffus;
      if (dt > 0) {
        E.adapt += (E.lum - E.adapt) * (1 - Math.exp(-dt / Cx.tau));
        const Gc = borne(Math.pow((E.lum + 0.06) / (E.adapt + 0.06), 0.5 * Cx.force), 0.72, 1.3), vm = Cx.vitesseMax * dt;
        E.Gt += borne(Gc - E.Gt, -vm, vm);
        E.rev += ((E.direct * tr + 0.45 * E.diffus) - E.rev) * (1 - Math.exp(-dt / (C.rev.tau * (1 + 1.6 * L.prof))));
      }
      E.froid = borne(0.6 * cu.D + 0.8 * cu.N + 0.4 * cu.B + 0.25 * L.prof, 0, 1);
      E.Ga = borne(Math.pow(E.clair / Math.max(0.02, E.adapt), 0.4 * Cx.force), 1, 2.6); E.G = E.Gt * E.Ga;   // adaptation partielle : dans le noir, l'œil remonte les lumières restantes
      const ld = E.lum * E.Gt / E.clair; E.sombre = Cx.sombreMax * borne(1 - ld, 0, 1); E.disp = ld;
      E.bioVis = lisse(0.75, 0.15, ld) * 0.8 + 0.2;
      E.dir = C.direction + cu.C * 0.3 * (C.meteo.sens || 1);
      E.sunX = W * (0.5 + 0.9 * Math.sin(E.dir));
    };
    // faisceaux : respiration (houle), balancement, ombres, balayage, crépuscule
    L.majFaisceaux = function (t, dt) {
      const cu = L.M.cur, stat = L.statique, Fd = H * (0.2 + 0.9 * F.eventail), pX = E.sunX;
      for (let i = 0; i < B.length; i++) {
        const b = B[i], sol = b.type === 'soleil';
        if (sol) { b.sx = b.xn * W + (pX - W * 0.5) * 0.35; const a0 = Math.atan2(b.sx - pX, Fd); b.ang0 = a0 * 0.85 + E.dir * 0.5; }
        else b.sx = b.xn * W;
        b.We = b.W * (1 + 0.9 * cu.D + 0.6 * cu.B);
        const tr = L.M.transmission(b.sx), bal = L.M.balayage(b.sx / W);
        if (!stat) {
          const s1 = 0.5 + 0.5 * Math.sin(TAU * t / b.T1 + b.ph), s2 = 0.5 + 0.5 * Math.sin(TAU * t / b.T2 + b.ph2);
          b.ang = b.ang0 + (sol ? 0 : E.dir * 0.4) + C.soleil.balance * (1 + 2.2 * cu.H) * Math.sin(TAU * t / b.TB + b.ph3);
          const resp = (sol ? 0.5 + 0.5 * s1 : 0.7 + 0.3 * s1) * (0.82 + 0.18 * s2);
          const bt = sol ? E.direct : E.direct * 0.9 + 0.12 * E.ciel * (1 - cu.D);
          b.I = b.gain * resp * (1 + 0.15 * b.react) * C.intensite * (1 - 0.4 * L.prof) * bt * tr * bal * E.G;
        } else { b.ang = b.ang0; b.I = b.gain * 0.75 * C.intensite * (1 - 0.4 * L.prof) * E.direct; }
        b.dx = Math.sin(b.ang); b.dy = Math.cos(b.ang);
        b.rev += (b.I - b.rev) * (dt > 0 ? 1 - Math.exp(-dt / (C.rev.tau * (1 + 1.6 * L.prof))) : 1);
        b.react += (b.reactCible - b.react) * 0.03;
        const ySol = C.rev.sol * L.Hb; b.ix = b.sx + (ySol - b.sy) * b.dx / Math.max(0.3, b.dy); b.iy = ySol;   // impact au sol (écran)
      }
      for (const q of L.bio) q.I = C.bio.alpha * E.bioVis * (0.55 + 0.45 * Math.sin(TAU * t / q.T + q.ph));
      if (L.src) L.src.I = C.source.alpha * (0.55 + 0.45 * E.bioVis) * (0.85 + 0.15 * Math.sin(t * 0.4));
    };
    L.eclaire = function (x, y) {               // éclairement d'un point ÉCRAN par les faisceaux (même profil que le sprite)
      let s = 0; L.dsx = 0; L.dsy = 0;
      for (let i = 0; i < L.nVis; i++) {
        const b = B[i], rx = x - b.sx, ry = y - b.sy, u = rx * b.dx + ry * b.dy;
        if (u <= 0 || u > b.L) continue;
        const v = -rx * b.dy + ry * b.dx, sN = u / b.L, hw = b.We * 0.5 * DEMI(sN), q = v / hw;
        if (q > 2.4 || q < -2.4) continue;
        const w = b.I * Math.exp(-q * q * 3.4 * (b.flou ? 0.5 : 1)) * vertical(sN, b.decroit); s += w; L.dsx += w * b.dx; L.dsy += w * b.dy;
      }
      return s;
    };
    // grille du champ (repère TERRAIN, cellule 10 px), un quart des lignes par image : toutes les sources → i, direction, teinte
    const cell = 10; L.cell = cell; const gw = L.gw = Math.ceil(l / cell) + 1, gh = L.gh = Math.ceil(h / cell) + 1, NG = gw * gh;
    L.gdx = new Float32Array(NG); L.gdy = new Float32Array(NG); L.gidx = new Uint8Array(NG); L.champ = new Float32Array(NG);
    L.gr = new Float32Array(NG); L.gg = new Float32Array(NG); L.gb = new Float32Array(NG); L.grev = new Float32Array(NG); L.quart = 0;
    L.obst = new Float32Array(8 * 3);
    const cD = [0, 0, 0];
    L.majChamp = function () {
      const q = L.quart; L.quart = (q + 1) & 3; const cu = L.M.cur, cr = cu.C, nu = cu.N;
      for (let j = 0; j < 3; j++) cD[j] = melange(melange(L.cFais[j], L.cCre[j], cr), L.cNuit[j], nu);
      for (let gy = q; gy < gh; gy += 4) {
        const ys = gy * cell + oy, yn = ys / H, dome = E.diffus * Math.exp(-1.6 * yn) * 0.9, revS = E.rev * C.rev.alpha * 1.4 * lisse(0.55, 1, ys / L.Hb);
        for (let gx = 0; gx < gw; gx++) {
          const i = gy * gw + gx, xs = gx * cell + ox;
          const fb = L.eclaire(xs, ys); let ddx = L.dsx, ddy = L.dsy, wb = 0, bx = 0, by = 0;
          for (let k = 0; k < L.bio.length; k++) { const p = L.bio[k], dx = xs - p.x, dy = ys - p.y, d2 = dx * dx + dy * dy, R = p.r * 3.2; if (d2 < R * R) { const d = Math.sqrt(d2) + 1, w = p.I * (1 - d / R) * 1.4; wb += w; bx += w * dx / d; by += w * dy / d; } }
          if (L.src) { const dx = xs - L.src.x, dy = ys - L.src.y, d = Math.sqrt(dx * dx + dy * dy) + 1, R = H * 0.42; if (d < R && dy < 0) { const w = L.src.I * (1 - d / R) * (-dy / d); wb += w; bx += w * dx / d; by += w * dy / d; } }
          const tot = fb + dome + revS + wb + 1e-6;
          ddx += dome * 0.1 + bx; ddy += dome * 0.9 - revS + by;   // propagation : dôme vers le bas, réverbérée vers le haut, bio radiale
          const nn = 1 / Math.sqrt(ddx * ddx + ddy * ddy + 1e-9); L.gdx[i] = ddx * nn; L.gdy[i] = ddy * nn; L.gidx[i] = ((Math.round(Math.atan2(-L.gdy[i], -L.gdx[i]) / TAU * 8) + 8) & 7);
          const it = fb + dome * 0.6 + revS * 0.7 + wb; L.champ[i] = it > 1.4 ? 1.4 : it; L.grev[i] = revS;
          const fD = (fb + dome) / tot, fR = revS / tot, fB = wb / tot;
          L.gr[i] = cD[0] * fD + L.cMat[0] * fR + L.cBio[0] * fB; L.gg[i] = cD[1] * fD + L.cMat[1] * fR + L.cBio[1] * fB; L.gb[i] = cD[2] * fD + L.cMat[2] * fR + L.cBio[2] * fB;
        }
      }
    };
    L.maj = function (t) {
      if (L.tMaj === t) return; L.tMaj = t; const dt = Math.min(0.1, Math.max(0, t - L.tPrev)); L.tPrev = t;
      L.M.maj(dt); const dv = L.M.fige ? 0 : dt * L.M.vitesse; L.calcE(dv); L.majFaisceaux(L.M.t, dv); if (!L.statique || (L.nMaj = (L.nMaj || 0) + 1) % 8 === 0) L.majChamp();
      const b = sc.bille;
      for (let i = 0; i < B.length; i++) {
        let cible = 0; if (b) { const x = b.x + ox - B[i].sx, y = b.y + oy - B[i].sy, v = Math.abs(-x * B[i].dy + y * B[i].dx), u = x * B[i].dx + y * B[i].dy; if (u > 0 && v < B[i].We * 0.7) cible = 1 - v / (B[i].We * 0.7); }
        B[i].reactCible = cible;
      }
      if (L.cp) L.couplage(t);
    };
    // couplage décor (QXFOND) : exposition, froid, rayons/nappes CSS, ombres — écrit ≤ 10 Hz et seulement si changement
    const dern = { s: -1, f: -1, r: -1, n: -1, t: -9, o: [{ x: 0, a: -1 }, { x: 0, a: -1 }] }, AMB = { sombre: 0, froid: 0, rayons: 1, nappes: 1, ombres: [{ x: 0, w: 0, a: 0 }, { x: 0, w: 0, a: 0 }] };
    L.couplage = function (t, force) {
      const f = L.cp.fond; if (!f || !f.ambiance) return;
      const cu = L.M.cur, md = borne(E.direct * E.trMoy * E.Gt / 0.92, 0, 1.1);
      AMB.sombre = E.sombre; AMB.froid = C.expo.froidMax * E.froid; AMB.rayons = md * (1 - 0.6 * cu.C) * (1 - 0.7 * cu.N); AMB.nappes = borne(0.15 + 0.85 * md, 0, 1);
      let j = 0; for (const s of L.M.om) { if (!s.on || j > 1) continue; const o = AMB.ombres[j++]; o.x = s.x; o.w = s.w * (1 + 1.1 * L.prof) * 1.5; o.a = s.a * 0.7 * borne(E.direct / 0.5, 0, 1); }
      for (; j < 2; j++) AMB.ombres[j].a = 0;
      let ch = Math.abs(AMB.sombre - dern.s) > 0.004 || Math.abs(AMB.froid - dern.f) > 0.004 || Math.abs(AMB.rayons - dern.r) > 0.01 || Math.abs(AMB.nappes - dern.n) > 0.01;
      for (let k = 0; k < 2; k++) if (Math.abs(AMB.ombres[k].a - dern.o[k].a) > 0.005 || Math.abs(AMB.ombres[k].x - dern.o[k].x) > 0.5) ch = true;
      if (!force && (!ch || t - dern.t < 0.1)) return;
      dern.s = AMB.sombre; dern.f = AMB.froid; dern.r = AMB.rayons; dern.n = AMB.nappes; dern.t = t; for (let k = 0; k < 2; k++) { dern.o[k].a = AMB.ombres[k].a; dern.o[k].x = AMB.ombres[k].x; }
      f.ambiance(AMB);
    };
    L.calcE(0); L.majFaisceaux(0, 0); for (let q = 0; q < 4; q++) L.majChamp();
    L.echantillon = function (x, y) {
      let gx = x / cell, gy = y / cell; gx = gx < 0 ? 0 : gx > gw - 1.001 ? gw - 1.001 : gx; gy = gy < 0 ? 0 : gy > gh - 1.001 ? gh - 1.001 : gy;
      const ix = gx | 0, iy = gy | 0, fx = gx - ix, fy = gy - iy, i = iy * gw + ix, c = L.champ;
      return (c[i] * (1 - fx) + c[i + 1] * fx) * (1 - fy) + (c[i + gw] * (1 - fx) + c[i + gw + 1] * fx) * fy;
    };
    L.eclairer = function (x, y, out) {
      const o = out || ECL0; o.i = L.echantillon(x, y);
      let gx = (x / cell + 0.5) | 0, gy = (y / cell + 0.5) | 0; gx = gx < 0 ? 0 : gx >= gw ? gw - 1 : gx; gy = gy < 0 ? 0 : gy >= gh ? gh - 1 : gy; const j = gy * gw + gx;
      o.dx = L.gdx[j]; o.dy = L.gdy[j]; o.idx = L.gidx[j]; o.c = L.M.cur.C; o.rev = L.grev[j]; o.expo = E.G; o.froid = E.froid;
      const m = o.i > 1 ? 1 : o.i; o.r = melange(L.cOmbre[0], L.gr[j], m); o.g = melange(L.cOmbre[1], L.gg[j], m); o.b = melange(L.cOmbre[2], L.gb[j], m); return o;
    };
    L.calmeEcran = function (x, y, marge) { const r = cp && cp.reussite; if (!r) return sc.calme(x - ox, y - oy); const d = Math.hypot(x - r.x, y - r.y); return lisse(r.r + 12 + marge, r.r + 40 + marge, d); };
    // réverbération sous les murs (liseré doux, teinte matière) : préparée ici
    L.murRev = []; for (const w of (sc.geo ? sc.geo.murs : [])) { const mx = (w.x1 + w.x2) / 2, my = (w.y1 + w.y2) / 2; L.murRev.push({ x: mx, y: my, a: Math.atan2(w.y2 - w.y1, w.x2 - w.x1), L: Math.hypot(w.x2 - w.x1, w.y2 - w.y1), cal: sc.calme(mx, my + 8) * sc.loinDuBut(mx, my, 20) }); }
    sc.lum = L; ACTIVE = L; return L;
  }
  const NUL = [0, 0], CAPL = 0.8, ECL0 = { i: 0, dx: 0, dy: 1, idx: 0, c: 0, r: 0, g: 0, b: 0, rev: 0, expo: 1, froid: 0 }, ST0 = {};
  const PHASE = { alluvions: true, creatures: false, niveau: false };    // L2 : couche partagée active (banc, bille) ; L3 (créatures, moteurs de niveau) : éteint
  const inerte = { regler() {}, update() {}, dessiner() {}, effectif: () => 0 };
  let PALIER_FORCE = null;
  /* R531 — palier d'appareil : réglage manuel (?palier=… ou localStorage qxlumpalier) ; sinon Cinéma seulement sur appareil puissant
     (pointeur fin, ≥ 8 cœurs, pas de téléphone/tablette), Standard partout ailleurs (iPhone). */
  (function () {
    let m = null;
    try { const q = /[?&]palier=(sobre|standard|cinema)/.exec(racine.location.search); if (q) m = q[1]; } catch (e) {}
    try { const v = racine.localStorage.getItem('qxlumpalier'); if (!m && v && /^(sobre|standard|cinema)$/.test(v)) m = v; } catch (e) {}
    if (m) { PALIER_FORCE = m; return; }
    try {
      const fin = racine.matchMedia && racine.matchMedia('(pointer: fine)').matches, n = (racine.navigator && racine.navigator.hardwareConcurrency) || 4;
      const mob = /iPhone|iPad|iPod|Android|Mobile/i.test((racine.navigator && racine.navigator.userAgent) || '') || (racine.navigator && racine.navigator.maxTouchPoints > 1 && /Mac/.test(racine.navigator.platform || ''));
      DEF.palier = fin && n >= 8 && !mob ? 'cinema' : 'standard';
    } catch (e) { DEF.palier = 'standard'; }
  })();
  const RANG = { sobre: 0, standard: 1, cinema: 2 };
  function palierDe(L, k) { let p = PALIER_FORCE || L.C.palier; const pk = k < 0.35 ? 'sobre' : k < 0.75 ? 'standard' : 'cinema'; if (RANG[pk] < RANG[p]) p = pk; L.pal = p; return p; }

  /* =====================================================================
     PLAN VOLUME : dôme, fenêtre de Snell, plafond d'eau, brume, faisceaux (soleil + trouées), réverbération, bio, source au sol
     ===================================================================== */
  function dessinerVolume(L, ctx, k, t) {
    const C = L.C, E = L.E, cu = L.M.cur, W = L.W, H = L.H, S = L.spr, att = L.cp ? 1 : L.sc.attenuation, cr = cu.C, nu = cu.N, G = E.G * (C.gain || 1);
    const wJ = Math.max(0, 1 - cr - nu), wC = cr * (1 - nu), wN = nu;
    ctx.globalCompositeOperation = 'lighter';
    // (c) dôme + fenêtre de Snell (étalée et aplatie par la couverture)
    const fen = C.dome.alpha * E.ciel * G * att * (0.6 + 0.4 * E.trMoy), rw = W * C.dome.rayon * (1 + 0.9 * cu.D + 0.5 * cu.B), rh = rw * 0.5 * (1 + 0.3 * cu.D);
    if (fen > 0.004) {
      const fx = E.sunX, fy = -rh * 0.32;
      if (wJ > 0.01) { ctx.globalAlpha = Math.min(1, fen * wJ * (1 - 0.4 * cu.D)); ctx.drawImage(S.fenetre, fx - rw, fy - rh, 2 * rw, 2 * rh); }
      if (wC > 0.01) { ctx.globalAlpha = Math.min(1, fen * wC); ctx.drawImage(S.fenetreC, fx - rw, fy - rh, 2 * rw, 2 * rh); }
      if (wN > 0.01) { ctx.globalAlpha = Math.min(1, fen * wN * 1.4); ctx.drawImage(S.fenetreN, fx - rw * 0.5, fy - rh * 0.5, rw, rh); }
    }
    const aD = C.dome.alpha * E.diffus * G * att * 0.8; if (aD > 0.004) { ctx.globalAlpha = Math.min(1, aD); ctx.drawImage(S.dome, 0, 0, W, H * (0.45 + 0.25 * cu.D)); }
    // plafond d'eau : lignes fines qui glissent (2 copies) + éclats ; s'éteint avec la profondeur
    const Su = L.surf, aS = C.surface.alpha * Su.fond * att * Math.min(1, E.ciel * G) * (0.45 + 0.55 * E.trMoy) * (k > 0.3 ? 1 : 0);
    if (aS > 0.005) {
      const ts = L.M.ts, ag = 1 + 2.2 * cu.H;
      for (let j = 0; j < 2; j++) {
        const off = ((ts * (j ? -5 : 8)) % Su.Wt + Su.Wt) % Su.Wt, dy = Math.sin(ts * 0.21 + j * 2) * 1.6 * ag;
        ctx.globalAlpha = aS * (j ? 0.6 : 1);
        for (let xx = -off; xx < W; xx += Su.Wt) ctx.drawImage(Su.c, xx, dy, Su.Wt, Su.Ht);
      }
      for (let i = 0; i < Su.NS; i++) { const tw = Math.pow(Math.max(0, Math.sin(ts * Su.fq[i] * TAU + Su.ph[i])), 3), fx = Math.exp(-Math.pow((Su.x[i] - E.sunX) / (W * 0.45), 2)), al = aS * 1.6 * tw * (0.35 + 0.65 * fx); if (al < 0.01) continue; ctx.globalAlpha = al > 0.6 ? 0.6 : al; const s = Su.sz[i]; ctx.drawImage(S.entree, Su.x[i] - s, Su.y[i] - s, 2 * s, 2 * s); }
    }
    // brume : voile qui lève le noir (diffusion), plus fort en profondeur et par brume
    const aB = C.dome.brume * att * (0.25 * L.prof + 0.9 * cu.B + 0.25 * cu.D) * (0.4 + 0.6 * E.ciel);
    if (aB > 0.004) { ctx.globalAlpha = Math.min(0.5, aB); ctx.drawImage(S.brume, 0, 0, W, H); }
    // (a)(b) faisceaux : 3 teintes cuites (jour / crépuscule / nuit) en fondu
    const aF = Math.min(C.soleil.alpha, CAPL) * att * (k > 0.5 ? 1 : 0.6 + k * 0.8), aT = Math.min(C.trouees.alpha, CAPL) * att;
    for (let i = 0; i < L.nVis; i++) {
      const b = L.B[i], a = (b.type === 'soleil' ? aF : aT) * b.I * (C.gain || 1) * (C.rais || 1) * (1 - 0.5 * cu.D) * (1 + 0.8 * cu.B), Lb = b.L * (1 - 0.35 * cu.B); if (a < 0.004) continue;
      ctx.save(); ctx.translate(b.sx, b.sy); ctx.rotate(-b.ang);
      if (wJ > 0.01) { ctx.globalAlpha = Math.min(1, a * wJ); ctx.drawImage(b.sp[0], -b.We / 2, 0, b.We, Lb); }
      if (wC > 0.01) { ctx.globalAlpha = Math.min(1, a * wC); ctx.drawImage(b.sp[1], -b.We / 2, 0, b.We, Lb); }
      if (wN > 0.01) { ctx.globalAlpha = Math.min(1, a * wN * 1.3); ctx.drawImage(b.sp[2], -b.We / 2, 0, b.We, Lb); }
      ctx.restore();
      if (b.type === 'trouee' && b.sy > -4) { const e = Math.min(0.7, a * 1.4), r = b.W * 1.3; ctx.globalAlpha = e; ctx.drawImage(S.entree, b.sx - r, b.sy - r * 0.6, 2 * r, 1.2 * r); }
    }
    // (e) réverbération : taches au sol sous chaque faisceau (impact direct + rebond coloré par la matière, avec retard), parois latérales
    const Rv = C.rev, aR = Rv.alpha * att * G;
    for (let i = 0; i < L.nVis; i++) {
      const b = L.B[i]; if (b.ix < -b.We * 3 || b.ix > W + b.We * 3) continue;
      const cal = L.calmeEcran(b.ix, b.iy, 30); if (cal < 0.02) continue;
      const rl = b.rev * aR * 1.1 * cal, rw = b.We * 2.4 + 50,   /* R531 : flaque au sol plus discrète (elle faisait une barre éblouissante) */ ri = b.I * aR * 0.55 * cal * vertical(Math.min(0.99, (b.iy - b.sy) / b.L), b.decroit) * 6;
      if (rl > 0.004) { ctx.globalAlpha = Math.min(0.32, rl); ctx.drawImage(S.revSol, b.ix - rw, b.iy - rw * 0.42, 2 * rw, 0.84 * rw); }
      if (ri > 0.004) { const r2 = b.We * 1.2 + 14; ctx.globalAlpha = Math.min(0.3, ri * 0.6); ctx.drawImage(S.revLum, b.ix - r2, b.iy - r2 * 0.35, 2 * r2, 0.7 * r2); }
    }
    const aP = Rv.parois * E.rev * G * att * 0.9;
    if (aP > 0.004) { ctx.globalAlpha = Math.min(0.5, aP); ctx.drawImage(S.paroi, 0, H * 0.25, W * 0.16, H * 0.75); ctx.save(); ctx.translate(W, 0); ctx.scale(-1, 1); ctx.drawImage(S.paroi, 0, H * 0.25, W * 0.16, H * 0.75); ctx.restore(); }
    // (d) lueurs bio + source au sol (éventail qui monte, ref2)
    const gw0 = C.gain || 1; for (const q of L.bio) { const a = q.I * gw0 * att * L.calmeEcran(q.x, q.y, q.r); if (a < 0.006) continue; ctx.globalAlpha = Math.min(0.8, a); const r = q.r; ctx.drawImage(S.bio, q.x - r, q.y - r, 2 * r, 2 * r); ctx.globalAlpha = Math.min(0.75, a * 0.8); ctx.drawImage(S.bioC, q.x - r * 0.22, q.y - r * 0.22, r * 0.44, r * 0.44); }
    if (L.src && k > 0.3) {
      const s = L.src, cal = L.calmeEcran(s.x, s.y - 50, 0);
      if (cal > 0.05) {
        for (const r of s.R) { const a = s.I * gw0 * att * cal * (0.6 + 0.4 * Math.sin(TAU * t / r.T + r.ph)); ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(Math.PI - r.ang + 0.03 * Math.sin(t / 7 + r.ph)); ctx.globalAlpha = Math.min(0.75, a); ctx.drawImage(r.sp, -r.W / 2, 0, r.W, r.L); ctx.restore(); }
        ctx.globalAlpha = Math.min(0.7, s.I * 1.6 * cal); ctx.drawImage(S.bio, s.x - 34, s.y - 34, 68, 68); ctx.globalAlpha = Math.min(0.8, s.I * 1.8 * cal); ctx.drawImage(S.bioC, s.x - 7, s.y - 7, 14, 14);
      }
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
  function gommeEcran(L, c) {                   // B5 sur le plan couplé
    const r = L.cp.reussite; if (!r) return; const R0 = r.r + 12, R = R0 + 26;
    if (!L.cp.gomme) { L.cp.gomme = c.createRadialGradient(r.x, r.y, R0, r.x, r.y, R); L.cp.gomme.addColorStop(0, 'rgba(0,0,0,1)'); L.cp.gomme.addColorStop(1, 'rgba(0,0,0,0)'); }
    c.globalCompositeOperation = 'destination-out'; c.fillStyle = L.cp.gomme; c.fillRect(r.x - R, r.y - R, 2 * R, 2 * R); c.globalCompositeOperation = 'source-over';
  }
  function majToile(L, pal) {
    const cp = L.cp, dpr = Math.min(2, racine.devicePixelRatio || 1), Tl = L.C.toile || {}, s = pal === 'cinema' ? dpr : Math.min(dpr, Tl[pal] || 0.5);   // R531 : lumière douce → toile à demi-résolution (Standard), agrandie par le compositeur
    if (cp.s === s && cp.cv.width === Math.round(L.W * s)) return; cp.s = s; cp.cv.width = Math.round(L.W * s); cp.cv.height = Math.round(L.H * s); cp.gomme = null;
  }

  /* ÉLÉMENT — faisceaux / plan volume (toutes les sources) */
  const E = {};
  E.lumiere_faisceaux = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    if (coupe()) return inerte;
    const L = scene(sc); let k = 1, fixe = false, dessineFixe = false;
    return {
      regler(kk) { k = kk; const pal = palierDe(L, kk);
        L.nVis = pal === 'cinema' ? L.B.length : pal === 'standard' ? Math.min(L.nS, 4) + Math.min(L.B.length - L.nS, 1) : Math.min(L.nS, 3);
        if (pal === 'standard' && L.nVis < L.B.length && L.nS > 4) { const t = L.B.splice(4, L.nS - 4); L.B.push(...t); L.nS = 4; }   // les soleils en trop passent en fin de liste (non dessinés)
        L.statique = pal === 'sobre'; fixe = pal === 'sobre'; dessineFixe = false; if (L.cp) majToile(L, pal); },
      effectif: () => L.nVis,
      update() { L.maj(sc.t); },
      dessiner(ctx, t) {
        if (k <= 0.01) return;
        if (L.cp && L.cp.ctx) {                // plan couplé : toile plein écran sous le terrain
          if (fixe && dessineFixe && !L.caustNeuf) return;
          const c = L.cp.ctx, s = L.cp.s; c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, L.cp.cv.width, L.cp.cv.height); c.setTransform(s, 0, 0, s, 0, 0);
          dessinerVolume(L, c, k, t); if (L.caust) L.caust(c, L.ox, L.oy, t); gommeEcran(L, c); dessineFixe = true; L.caustNeuf = false;   // R531 : caustiques dans la MÊME toile (une seule toile, un seul effacement)
        } else dessinerVolume(L, ctx, k, t);
      }
    };
  } };

  /* =====================================================================
     ÉLÉMENT — caustiques : plafond (pondéré par la fenêtre de Snell), solides (murs, face haute), sol ; réseau NET en haut / MOU (plus grand, flou) en bas
     ===================================================================== */
  E.lumiere_caustiques = { famille: 'structures', plan: 'arriere', creer(sc, p) {
    if (coupe()) return inerte;
    const L = scene(sc), Cc = L.C.caustiques, N = 12, S = 96, l = L.l, h = L.h;
    const atN = atlasDe(melBlanc(L.cCaust, 0.35).map(Math.round), N, S, false), atM = atlasDe(L.cCaust, N, S, true);
    const res = L.pal === 'cinema' ? 0.7 : L.pal === 'standard' ? Cc.res : 0.3, Wr = Math.max(8, Math.round(l * res)), Hr = Math.max(8, Math.round(h * res));
    const scrN = toile(Wr, Hr), gN = scrN.getContext('2d'), scrM = toile(Wr, Hr), gM = scrM.getContext('2d');
    const aMax = Math.min(Cc.alpha * (p.alpha === undefined ? 1 : p.alpha), CAPL);
    const cell = 10, gw = Math.ceil(l / cell) + 1, gh = Math.ceil(h / cell) + 1, mur = sc.geo ? sc.geo.murs : [];
    const mN = toile(gw, gh), mM = toile(gw, gh), iN = mN.getContext('2d').createImageData(gw, gh), iM = mM.getContext('2d').createImageData(gw, gh);
    const hPl = L.Ht + Cc.plafond * (L.Hb - L.Ht), ySol = L.Hb - Cc.sol * (L.Hb - L.Ht);
    for (let gy = 0; gy < gh; gy++) for (let gx = 0; gx < gw; gx++) {
      const x = gx * cell, y = gy * cell, xs = x + L.ox, ys = y + L.oy, yn = ys / L.H, i = gy * gw + gx;
      const fen = 0.3 + 0.7 * Math.exp(-Math.pow((xs - L.E.sunX) / (L.W * 0.42), 2));
      let net = ys < hPl ? Math.pow(borne(1 - (ys - L.Ht) / (hPl - L.Ht), 0, 1), 1.1) * fen * (0.6 + 0.4 * Math.sin(xs * 0.012 + 1.3) * Math.sin(xs * 0.0071 + 0.4 + sc.niveau)) : 0;
      let ms = 0; for (let kk = 0; kk < mur.length; kk++) {
        const w = mur[kk], ex = w.x2 - w.x1, ey = w.y2 - w.y1, ll = ex * ex + ey * ey + 1e-6, tt = borne(((x - w.x1) * ex + (y - w.y1) * ey) / ll, 0, 1);
        const dx = x - (w.x1 + ex * tt), dy = y - (w.y1 + ey * tt), q = Math.sqrt(dx * dx + dy * dy) / Cc.largeurSolide;
        if (q < 2.2) ms = Math.max(ms, Math.exp(-q * q * 1.6) * (dy < 0 ? 1 : 0.55));   // face haute (vers la lumière) plus éclairée
      }
      const lit = borne(L.eclaire(xs, Math.min(ys, L.H * 0.85)) * 1.6 + 0.25, 0, 1);
      net = Math.max(net, ms * Cc.solides * (1 - lisse(0.35, 0.8, yn)) * (0.5 + 0.5 * lit));
      let mou = ys > ySol ? lisse(ySol, L.Hb * 0.99, ys) * (0.25 + 0.75 * lit) : 0;
      mou = Math.max(mou, ms * Cc.solides * 0.8 * lisse(0.3, 0.75, yn) * (0.45 + 0.55 * lit));
      const cal = sc.calme(x, y) * sc.loinDuBut(x, y, 10) * lisse(0, 20, y) * (1 - lisse(h - 40, h, y));   // pas de bord net en bas du terrain
      iN.data[i * 4 + 3] = borne(Math.pow(net * cal, 0.7) * 1.25 * 255, 0, 255); iM.data[i * 4 + 3] = borne(Math.pow(mou * cal, 0.75) * 1.15 * 255, 0, 255);
    }
    mN.getContext('2d').putImageData(iN, 0, 0); mM.getContext('2d').putImageData(iM, 0, 0);
    const bornes = id => { let y0 = gh, y1 = -1; for (let gy = 0; gy < gh; gy++) for (let gx = 0; gx < gw; gx++) if (id.data[(gy * gw + gx) * 4 + 3] > 3) { if (gy < y0) y0 = gy; y1 = gy; } return y1 < 0 ? [0, 0] : [Math.max(0, Math.floor((y0 - 1) * cell * res)), Math.min(Hr, Math.ceil((y1 + 1) * cell * res))]; };
    const bN = bornes(iN), bM = bornes(iM);   // lignes utiles : on ne recompose que la bande où le masque est non nul
    const bande = toile(64, 2), gb = bande.getContext('2d'), grb = gb.createLinearGradient(0, 0, 64, 0); grb.addColorStop(0, 'rgba(0,0,0,0)'); grb.addColorStop(0.5, 'rgba(0,0,0,1)'); grb.addColorStop(1, 'rgba(0,0,0,0)'); gb.fillStyle = grb; gb.fillRect(0, 0, 64, 2);
    const anneau = radial(96, [255, 255, 255], [[0, 0], [0.5, 0], [0.72, 1], [0.86, 0.5], [1, 0]]), loc = toile(96, 96), gl = loc.getContext('2d');
    /* R531 — coût : toiles basse résolution (res × terrain), UNE seule recomposée par image, en alternance (réseau net / réseau mou) : charge constante,
       aucun pic périodique ; recopie seulement des bandes utiles, dans la toile du plan volume (demi-résolution) quand elle existe. */
    let k = 1, couches = 1, nF = 0, fixe = false, pretN = false, pretM = false; const RIP = [{ x: 0, y: 0, age: 9 }, { x: 0, y: 0, age: 9 }]; let ir = 0;
    const cNuit = rgba(L.cNuit, 1), cCre = rgba(L.cCre, 1);
    function couche(g, at, i, t, alpha, T0, yb) {
      const per = Cc.periode[i], f = ((t / per) % 1 + 1) % 1 * N, i0 = f | 0, a = f - i0, i1 = (i0 + 1) % N;
      const ech = (T0 * (i ? 1.6 : 1) / S) * res, pas = S * ech, vit = Cc.vitesse[i];
      const ox = ((t * vit * res) % pas + pas) % pas, oy = ((t * 0.35 * vit * res * (i ? -1 : 1)) % pas + pas) % pas;
      for (let j = 0; j < 2; j++) {
        const al = (j ? a : 1 - a) * alpha; if (al < 0.06) continue;
        g.setTransform(ech, 0, 0, ech, ox - pas, oy - pas); g.globalAlpha = Math.min(1, al * (a < 0.06 || a > 0.94 ? 1.06 : 1)); g.fillStyle = at.patrons[j ? i1 : i0];
        g.fillRect((pas - ox) / ech, (yb[0] + pas - oy) / ech, Wr / ech, (yb[1] - yb[0]) / ech);
      }
      g.setTransform(1, 0, 0, 1, 0, 0);
    }
    function recomposer(g, at, masque, tc, T0, yb) {
      if (yb[1] <= yb[0]) return; const M = L.M; g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1; g.clearRect(0, yb[0], Wr, yb[1] - yb[0]); g.globalCompositeOperation = 'lighter';
      couche(g, at, 0, tc, 1, T0, yb); if (couches > 1) couche(g, at, 1, tc + 6, 0.3, T0, yb);
      g.globalCompositeOperation = 'destination-out';
      for (let j = 0; j < 3; j++) { const s = M.om[j]; if (!s.on) continue; const ww = s.w * (1 + 1.1 * L.prof) * 1.7; g.globalAlpha = Math.min(1, s.a * 0.9); g.drawImage(bande, (s.x - L.ox - ww) * res, yb[0], 2 * ww * res, yb[1] - yb[0]); }
      g.globalCompositeOperation = 'destination-in'; g.globalAlpha = 1; g.drawImage(masque, 0, yb[0] * gh / Hr, gw, (yb[1] - yb[0]) * gh / Hr, 0, yb[0], Wr, yb[1] - yb[0]);   // masque recopié sur la seule bande (pas de découpe)
      const cu = M.cur; if (cu.C + cu.N > 0.03) { g.globalCompositeOperation = 'source-atop'; g.globalAlpha = Math.min(0.85, cu.C * 0.7 + cu.N * 0.8); g.fillStyle = cu.N > cu.C ? cNuit : cCre; g.fillRect(0, yb[0], Wr, yb[1] - yb[0]); }
      g.globalCompositeOperation = 'source-over';
    }
    function peindre(ctx, ox, oy, t) {
      if (!atN.pret || !atM.pret || k <= 0.01) return;
      const M = L.M, E = L.E, cu = M.cur, tc = M.tc;
      const dir = E.direct * E.G, vN = lisse(0.03, 0.75, dir) * (1 - 0.6 * cu.D), vM = lisse(0.02, 0.6, dir + 0.3 * E.diffus) * (1 - 0.3 * cu.D);
      if (vN + vM < 0.01) return;
      if (!fixe || !pretN || !pretM) {           // une seule toile recomposée par image (alternance) ; les deux au premier passage
        const f = nF++ & 1;
        if (!pretN || (f === 0 && !fixe)) { recomposer(gN, atN, mN, tc, Cc.tuile, bN); pretN = true; }
        if (!pretM || (f === 1 && !fixe)) { recomposer(gM, atM, mM, tc * 0.7, Cc.tuileMou, bM); pretM = true; }
      }
      const a = aMax * sc.attenuation * (0.5 + 0.5 * k);
      ctx.globalCompositeOperation = 'lighter';
      if (vN > 0.01 && bN[1] > bN[0]) { ctx.globalAlpha = Math.min(1, a * vN * 2.8); ctx.drawImage(scrN, 0, bN[0], Wr, bN[1] - bN[0], ox, oy + bN[0] * l / Wr, l, (bN[1] - bN[0]) * l / Wr); }
      if (vM > 0.01 && bM[1] > bM[0]) { ctx.globalAlpha = Math.min(1, a * vM * 2); ctx.drawImage(scrM, 0, bM[0], Wr, bM[1] - bM[0], ox, oy + bM[0] * l / Wr, l, (bM[1] - bM[0]) * l / Wr); }
      for (let i = 0; i < 2; i++) {          // rebond : ondulation locale des caustiques (≤ 1,8 s)
        const r = RIP[i]; if (r.age > 1.8 || fixe) continue;
        const R = 30 + r.age * 62, f = Math.sin(Math.PI * Math.min(1, r.age / 1.8)) * 0.5 * sc.calme(r.x, r.y) * (vN + vM);
        if (f < 0.01) continue;
        gl.globalCompositeOperation = 'source-over'; gl.setTransform(1, 0, 0, 1, 0, 0); gl.clearRect(0, 0, 96, 96);
        const a0 = (((r.age * 0.9) % 1) * N) | 0, e2 = Cc.tuile / S * 0.75; gl.setTransform(e2, 0, 0, e2, 0, 0); gl.globalAlpha = 1; gl.fillStyle = atN.patrons[a0 % N]; gl.fillRect(0, 0, 96 / e2, 96 / e2); gl.setTransform(1, 0, 0, 1, 0, 0);
        gl.globalCompositeOperation = 'destination-in'; gl.drawImage(anneau, 0, 0, 96, 96);
        ctx.globalAlpha = Math.min(1, f * aMax); ctx.drawImage(loc, ox + r.x - R, oy + r.y - R, 2 * R, 2 * R);
      }
      // réverbération sur les solides : liseré doux sous les murs (rebond du sol), teinte matière
      const mr = L.C.rev.murs * E.rev * E.G * (L.C.gain || 1) * sc.attenuation;
      if (mr > 0.005) for (const m of L.murRev) { const a2 = mr * m.cal; if (a2 < 0.005) continue; ctx.save(); ctx.translate(ox + m.x, oy + m.y); ctx.rotate(m.a); ctx.globalAlpha = Math.min(0.5, a2); ctx.drawImage(L.spr.revSol, -m.L / 2 - 10, 1, m.L + 20, 20); ctx.restore(); }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
    if (L.cp) L.caust = peindre;
    return {
      regler(kk) { k = kk; const pal = palierDe(L, kk); couches = pal === 'cinema' ? 2 : 1; fixe = pal === 'sobre'; pretN = pretM = false; L.caustNeuf = true; },
      effectif: () => (k > 0.01 ? couches * 2 : 0),
      evenement(type, e) { if (type !== 'rebond') return; ir ^= 1; RIP[ir].x = e.x; RIP[ir].y = e.y; RIP[ir].age = 0; },
      update(dt) { L.maj(sc.t); if (!atN.pret) { if (atN.suivante()) L.caustNeuf = true; } else if (!atM.pret) { if (atM.suivante()) L.caustNeuf = true; } for (let i = 0; i < 2; i++) RIP[i].age += dt; },
      dessiner(ctx, t) { if (!L.cp || L.caust !== peindre) peindre(ctx, 0, 0, t); }   // plan couplé : dessinées par le plan volume (L.caust)
    };
  } };

  /* =====================================================================
     MATIÈRE EN SUSPENSION ET BULLES — L2 : moteur dans qxmatiere.js (un seul fichier de plus), branché ici.
     Familles publiques : 0 bulle · 1 microbulle / poussière de bulles · 2 phytoplancton · 3 neige marine · 4 détritus / fibres · 5 poussière fine · 6 minéraux / paillettes · 7 zooplancton · 8 alluvions
     ===================================================================== */
  const FAM = { bulle: 0, microbulle: 1, poussiere_bulles: 1, phytoplancton: 2, phyto: 2, neige: 3, neige_marine: 3, detritus: 4, fibre: 4, poussiere: 5,
    mineraux: 6, mineral: 6, eclat: 6, paillette: 6, zooplancton: 7, zoo: 7, alluvion: 8, alluvions: 8, sediment: 8 };
  /* STYLE (jetons) : réponse de chaque famille à la lumière — commune à tous les moteurs (ambiantes, créatures L3, labo).
     transm : corps translucide (transmission) · diff : diffusion de Tyndall (dans les faisceaux) · rim : liseré côté source · glint : éclat spéculaire
     refr : réfraction (point opposé / image renversée) · bio : aptitude à la bioluminescence · ombre : silhouette */
  const STYLE = {
    0: { transm: 0.3, diff: 0.6, rim: 1, glint: 1, refr: 0.8, bio: 0, ombre: 0.5 }, 1: { transm: 1, diff: 1.1, rim: 0, glint: 0.3, refr: 0, bio: 0, ombre: 0 },
    2: { transm: 0.55, diff: 0.9, rim: 0.85, glint: 0, refr: 0.9, bio: 1, ombre: 0.2 }, 3: { transm: 0.6, diff: 1, rim: 0.7, glint: 0.2, refr: 0.35, bio: 0.15, ombre: 0.25 },
    4: { transm: 0.45, diff: 0.85, rim: 0.95, glint: 0.6, refr: 0.2, bio: 0, ombre: 0.25 }, 5: { transm: 1, diff: 1.2, rim: 0, glint: 1, refr: 0, bio: 0, ombre: 0 },
    6: { transm: 0.45, diff: 0.7, rim: 1, glint: 1.2, refr: 0.1, bio: 0, ombre: 0.3 }, 7: { transm: 0.4, diff: 0.85, rim: 1, glint: 0.1, refr: 1, bio: 0.6, ombre: 0.25 },
    8: { transm: 0.5, diff: 1, rim: 0, glint: 0, refr: 0, bio: 0, ombre: 0.5 }
  };
  let MAT = null;                                  // fourni par qxmatiere.js (_noyau.brancher)
  /* Style d'une particule éclairée — même résultat pour tout moteur (ambiantes, créatures, labo). e = QXLUMIERE.eclairer(x, y).
     Champs v1 conservés (alphaLit, alphaOmbre, halo, refractR, limbe) + v2 : transm, diff, rim, glint, refr, bio (coefficients STYLE) ; rx/ry = vers la source. */
  function styleParticule(famille, e, out, react) {
    const f = typeof famille === 'string' ? FAM[famille] : famille, S = STYLE[f] || STYLE[3], o = out || ST0, i = e.i * (react === undefined ? 1 : react), ic = i > 1 ? 1 : i;
    o.fam = f; o.idx = e.idx; o.rx = -e.dx; o.ry = -e.dy; o.fx = e.dx; o.fy = e.dy; o.cr = e.r; o.cg = e.g; o.cb = e.b; o.c = e.c || 0;
    o.transm = S.transm; o.diff = S.diff; o.rim = S.rim; o.glint = S.glint; o.refr = S.refr; o.bio = S.bio;
    o.alphaLit = Math.min(1, S.diff * ic); o.alphaOmbre = S.ombre * (1 - 0.5 * ic); o.halo = S.rim * 0.6 * ic; o.refractR = S.refr * 0.2; o.limbe = f === 0 ? 0.55 : 0;
    return o;
  }
  E.lumiere_poussiere = { famille: 'particules', plan: 'arriere', creer(sc, p) { if (coupe() || !MAT) return inerte; return MAT.creerP(sc, p); } };   // matière qui flotte + alluvions (qxmatiere.js)
  E.lumiere_bulles = { famille: 'particules', plan: 'arriere', creer(sc, p) { if (coupe() || !MAT) return inerte; return MAT.creerB(sc, p); } };         // bulles (qxmatiere.js)
  E.lumiere_surface = { famille: 'structures', plan: 'arriere', creer() { return inerte; } };
  E.lumiere_source = { famille: 'structures', plan: 'arriere', creer() { return inerte; } };

  /* =====================================================================
     Enregistrement, liaison, API
     ===================================================================== */
  function enregistrer(Pl) { for (const n in E) Pl.definir(n, E[n]); }
  function installer(M, ids) {
    if (coupe()) return 0; let c = 0;
    for (const k in M) {
      const m = M[k], b = k.replace(/__fu$/, '');
      if (/__fu2$/.test(k) || !m || !m.vivant || !m.vivant.pool || m.vivant.pool.__lum) continue;
      if ((ids || ACTIFS).indexOf(m.id) < 0 || (b !== k && !M[b])) continue;
      const pool = m.vivant.pool.slice(); pool.unshift({ e: 'lumiere_faisceaux', nom: 'lumière (sources, volume)' }, { e: 'lumiere_caustiques', nom: 'caustiques' }, { e: 'lumiere_poussiere', nom: 'matière en suspension' }, { e: 'lumiere_bulles', nom: 'bulles' });
      pool.__lum = true; m.vivant.pool = pool; c++;
    }
    return c;
  }
  /* coupler({ hote, fond, W, H, zone:{x,y,l,h}, reussite:{x,y,r} (écran) }) : plan volume plein écran sous le terrain + exposition du décor QXFOND */
  function coupler(o) {
    if (coupe()) return null;
    if (COUPLE && COUPLE.cv && COUPLE.cv.parentNode) COUPLE.cv.remove();
    const cv = document.createElement('canvas'); cv.className = 'qxl-volume'; cv.style.cssText = 'position:absolute;left:0;top:0;width:' + o.W + 'px;height:' + o.H + 'px;pointer-events:none';
    cv.width = o.W; cv.height = o.H; if (o.apres && o.apres.after) o.apres.after(cv); else if (o.hote) o.hote.appendChild(cv);   // apres : juste au-dessus du décor QXFOND, sous le canevas du jeu
    COUPLE = { hote: o.hote, fond: o.fond, W: o.W, H: o.H, zone: o.zone, reussite: o.reussite || null, cv, ctx: cv.getContext('2d'), s: 1 }; VER++; return COUPLE;
  }
  function decoupler() { if (COUPLE && COUPLE.cv) COUPLE.cv.remove(); if (COUPLE && COUPLE.fond && COUPLE.fond.ambiance) COUPLE.fond.ambiance({ sombre: 0, froid: 0, rayons: 1, nappes: 1, ombres: [] }); COUPLE = null; VER++; }
  function monter(o) {
    const cfg = { id: o.id || 12, palette: o.palette }, base = aleatoire(o.graine || 7);
    const sc = { l: o.l, h: o.h, cfg, niveau: o.niveau || 1, alea: base, NORME: { opaciteMax: { particules: 0.6, structures: 0.45 } }, attenuation: o.attenuation === undefined ? 1 : o.attenuation, bille: null, courant: 1, t: 0,
      geo: o.geo || { murs: [], puits: [], aimants: [], vents: [] }, calme: o.calme || (() => 1), loinDuBut: () => 1, flux: o.flux || (() => NUL) };
    for (const kk of ['murs', 'puits', 'aimants', 'vents']) if (!sc.geo[kk]) sc.geo[kk] = [];
    const noms = o.elements || ['lumiere_faisceaux', 'lumiere_caustiques', 'lumiere_poussiere', 'lumiere_bulles'];
    const els = noms.map(n => E[n].creer(sc, o.params && o.params[n] || {}));
    return { sc, regler(k) { for (const e of els) e.regler(k); }, update(dt, bille, flux, geo) { sc.t += dt; sc.bille = bille || null; if (flux) sc.flux = flux; if (geo) sc.geo = geo; for (const e of els) e.update(dt); },
      dessiner(ctx, t) { for (const e of els) e.dessiner(ctx, t); }, evenement(ty, ev) { for (const e of els) if (e.evenement) e.evenement(ty, ev); },
      champ: (x, y) => sc.lum.echantillon(x, y), get effectif() { return els.reduce((s, e) => s + (e.effectif ? e.effectif() : 0), 0); } };
  }
  const SRC = [];
  const API = {
    version: 4, PHASE, CFG, DEF, ACTIFS, SCENES, ELEMENTS: E, FAMILLES: FAM, STYLE,
    champ(x, y) { return ACTIVE ? ACTIVE.echantillon(x, y) : 0; },
    eclairer(x, y, out) { return ACTIVE ? ACTIVE.eclairer(x, y, out) : (out || ECL0); },   // { i, dx, dy, idx, c, r, g, b, rev, expo, froid } — repère terrain ; objet réutilisé si out absent
    reverbere(x, y) { if (!ACTIVE) return 0; const L = ACTIVE, gx = borne((x / L.cell) | 0, 0, L.gw - 1), gy = borne((y / L.cell) | 0, 0, L.gh - 1); return L.grev[gy * L.gw + gx]; },
    sources() {                                 // sources vivantes (repère écran) : [{type, x, y, dx, dy, i, r, g, b}] — objets réutilisés
      if (!ACTIVE) return SRC; const L = ACTIVE; let n = 0;
      const put = (type, x, y, dx, dy, i, c) => { const o = SRC[n] || (SRC[n] = {}); o.type = type; o.x = x; o.y = y; o.dx = dx; o.dy = dy; o.i = i; o.r = c[0]; o.g = c[1]; o.b = c[2]; n++; };
      for (let j = 0; j < L.nVis; j++) { const b = L.B[j]; put(b.type, b.sx, b.sy, b.dx, b.dy, b.I, b.type === 'soleil' ? L.cFais : L.cLum); }
      put('dome', L.E.sunX, 0, 0, 1, L.E.diffus, L.cFais); put('reverbere', L.W / 2, L.H, 0, -1, L.E.rev * L.C.rev.alpha, L.cMat);
      for (const q of L.bio) put('bio', q.x, q.y, 0, 0, q.I, L.cBio); if (L.src) put('source', L.src.x, L.src.y, 0, -1, L.src.I, L.cBio);
      SRC.length = n; return SRC;
    },
    exposition() { return ACTIVE ? ACTIVE.E : null; },   // { ciel, direct, diffus, lum, G (gain d'exposition), rev, froid, sombre, bioVis, sunX, dir }
    styleParticule,
    teinte() { return ACTIVE ? ACTIVE.cLum : SECOURS; }, teinteOmbre() { return ACTIVE ? ACTIVE.cOmbre : SECOURS; },
    signaler(i, x, y, r) { if (PHASE.creatures && ACTIVE && i >= 0 && i < 8) { ACTIVE.obst[i * 3] = x; ACTIVE.obst[i * 3 + 1] = y; ACTIVE.obst[i * 3 + 2] = r; } },
    liberer(i) { if (ACTIVE && i >= 0 && i < 8) ACTIVE.obst[i * 3 + 2] = 0; },
    /* scènes : clair | eclaircies | couvert | houle | tempete (orage) | crepuscule | nuit | brume ; événements : nuage | bateau | banc | baleine | balayage | eclaircie ;
       pilotage : auto | manuel | fige | libre. opts.permanent = coupe le séquenceur */
    ambiance(nom, opts) {
      if (!ACTIVE) return false; const M = ACTIVE.M;
      if (nom === 'auto') { M.auto = true; return true; } if (nom === 'manuel') { M.auto = false; return true; } if (nom === 'fige') { M.fige = true; return true; } if (nom === 'libre') { M.fige = false; return true; }
      if (opts && opts.permanent) M.auto = false;
      if (nom === 'clair') M.effacer();
      return M.declencher(nom, opts);
    },
    meteo() { if (!ACTIVE) return null; const M = ACTIVE.M, c = M.cur; return { S: c.S, D: c.D, H: c.H, B: c.B, C: c.C, N: c.N, scene: M.scene, derniere: M.derniere, t: M.t, G: ACTIVE.E.G, lum: ACTIVE.E.lum }; },
    vitesseTemps(k) { if (ACTIVE) ACTIVE.M.vitesse = borne(k, 0, 40); },
    palier(p) { PALIER_FORCE = RANG[p] === undefined ? null : p; VER++; return PALIER_FORCE; },
    particules(o) { if (MAT) MAT.particules(o); }, bulles(o) { if (MAT) MAT.bulles(o); },
    bibliotheque() { return MAT ? MAT.bibliotheque() : { particules: null, bulles: null }; },
    dessinerSysteme(nom, ctx, t, force) { if (MAT) MAT.dessinerSysteme(nom, ctx, t, force); },
    lireSaut() { return MAT ? MAT.lireSaut() : 0; },
    maj() { VER++; },
    cfgDe, enregistrer, installer, monter, coupler, decoupler, coupe, _atlas: ATLAS, get _scene() { return ACTIVE; },
    /* noyau partagé avec qxmatiere.js (L2) : outils, scène lumière, paliers ; brancher() installe le moteur de matière */
    _noyau: { DEF, borne, lisse, melange, rgba, toile, aleatoire, gauss, melBlanc, mel3, radial, scene, palierDe, coupe, inerte, PHASE, STYLE, FAM, styleParticule, brancher(m) { MAT = m; } }
  };
  racine.QXLUMIERE = API;
  /* QXALLUVIONS : bouchon inerte, remplacé par qxmatiere.js (L2) — les appels des créatures (L3) ne cassent jamais */
  if (!racine.QXALLUVIONS) racine.QXALLUVIONS = { FAMILLES: FAM, emettre: () => 0, perturber() {}, stimuler() {}, update() {}, sillage() {}, instance: null, bulles: null };
  if (racine.QXPOOL) enregistrer(racine.QXPOOL);
})(typeof window !== 'undefined' ? window : globalThis);
