
/* ============================================================
   MONDE 12 · MÉCANIQUE DES FLUIDES — moteur de fluide (aperçu)
   Grille « stable fluids » (Stam) décalée (MAC) : advection semi-lagrangienne,
   confinement de vorticité, projection par Gauss-Seidel sur-relaxé. Maille fixe HS px, pas fixe = 1 image
   (1/60 s), aucun hasard → la même suite de traits donne la même course
   (référence, rejeu, scan). Les murs ET les traits du joueur sont des parois.
   La qualité adaptative ne touche QUE le rendu (traceurs, voiles) : la
   physique ne change jamais de résolution.
   lv.fl = {
     src:[[x,y,w,h,ux,uy]]      buse : vitesse imposée (px/image) sur les faces du rectangle, y compris
                               contre une paroi → apport de fluide (source de masse), qui sort par les bords ouverts
     vx:[[x,y,r,tour,aspi,cœur]] tourbillon : rotation + aspiration ; cœur = rayon létal (avale la balle)
     liq:[[x,y,w,h,rho,visc]]   bassin de liquide (surface en y)
     nn:[[x,y,w,h,vc]]          fluide non newtonien : solide au-delà de vc
     grille:[[x1,y1,x2,y2]]     paroi perméable : arrête la balle, pas le courant
     cd   traînée de la balle dans le courant      (défaut .05)
     bd   densité de la balle (eau = 1)            (défaut 1)
     lud  ludion : la balle se comprime en profondeur (densité × (1+lud·m/100))
     mg   effet Magnus                             (défaut 0)
     vort confinement de vorticité                 (défaut .06)
     visc viscosité numérique                      (défaut .002)
     open bords ouverts 'LRTB'                     (défaut 'LRTB')
     warm images de mise en régime avant le lâcher (défaut 140) }
   ============================================================ */
(function(){
/* Grille MAC décalée : u sur les faces verticales ((NX+1)×NY), v sur les faces horizontales (NX×(NY+1)),
   pression et colorant au centre des cellules. Le décalage conserve le débit (un conduit transporte tout
   ce qu'on y injecte), ce que la grille centrée ne fait pas. */
var HS=8,NX=45,NY=60,N=NX*NY,NU=(NX+1)*NY,NV=NX*(NY+1),ITER=20,SOR=1.8;
var u=new Float32Array(NU),v=new Float32Array(NV),u0=new Float32Array(NU),v0=new Float32Array(NV),
    fxU=new Uint8Array(NU),fxV=new Uint8Array(NV),okU=new Uint8Array(NU+NX+2),okV=new Uint8Array(NV+NX+1),fu=new Float32Array(NU),fv=new Float32Array(NV),
    p=new Float32Array(N+2*NX),act=new Int32Array(N),mL=new Float32Array(N),mR=new Float32Array(N),mU=new Float32Array(N),mD=new Float32Array(N),inv=new Float32Array(N),nAct=0,dv=new Float32Array(N),cu=new Float32Array(N),cv=new Float32Array(N),cw=new Float32Array(N),
    dye=new Float32Array(N),dye0=new Float32Array(N),sol=new Uint8Array(N),frc=new Uint8Array(N);
var F={lv:null,key:'',open:[1,1,1,1],ms:0,dms:0,q:2,qHold:0,frames:0,tr:null,img:null,cv:null};
var QT=[0,140,300,520];          /* traceurs par niveau de qualité (rendu seulement) */
var BUDGET=8;                    /* ms par image pour le fluide (calcul + rendu) */
function cfg(lv){var f=lv.fl;return {cd:f.cd==null?.05:f.cd,bd:f.bd||1,lud:f.lud||0,mg:f.mg||0,
 vort:f.vort==null?.06:f.vort,visc:f.visc==null?.002:f.visc,warm:f.warm==null?140:f.warm};}
function clamp(x,a,b){return x<a?a:x>b?b:x;}
function solC(i,j){return i<0||j<0||i>=NX||j>=NY?2:sol[j*NX+i];}   /* 2 = hors grille */

/* ── parois : murs, traits, pièces → cellules pleines ; injecteurs → faces imposées ── */
function raster(segs,lv){
 sol.fill(0);frc.fill(0);fxU.fill(0);fxV.fill(0);var i,j,k,s,lim=HS*.74;
 for(k=0;k<segs.length;k++){s=segs[k];if(s.grille)continue;   /* grille : arrête la balle, laisse passer le fluide */
  var x0=Math.min(s[0],s[2])-lim,x1=Math.max(s[0],s[2])+lim,y0=Math.min(s[1],s[3])-lim,y1=Math.max(s[1],s[3])+lim,
      dx=s[2]-s[0],dy=s[3]-s[1],l2=dx*dx+dy*dy;
  for(j=Math.max(0,Math.floor(y0/HS));j<=Math.min(NY-1,Math.floor(y1/HS));j++)
   for(i=Math.max(0,Math.floor(x0/HS));i<=Math.min(NX-1,Math.floor(x1/HS));i++){
    var cx=(i+.5)*HS,cy=(j+.5)*HS,t=l2>0?clamp(((cx-s[0])*dx+(cy-s[1])*dy)/l2,0,1):0,
        ex=s[0]+t*dx-cx,ey=s[1]+t*dy-cy;
    if(ex*ex+ey*ey<lim*lim)sol[j*NX+i]=1;}}
 var o=lv.fl.open==null?'LRTB':lv.fl.open;F.open=[o.indexOf('L')>=0,o.indexOf('R')>=0,o.indexOf('T')>=0,o.indexOf('B')>=0];
 /* faces bloquées : contre une cellule pleine, ou bord fermé */
 for(j=0;j<NY;j++)for(i=0;i<=NX;i++){var a=solC(i-1,j),b=solC(i,j),q=j*(NX+1)+i;
  if(a===1||b===1||(a===2&&!F.open[0])||(b===2&&!F.open[1])){fxU[q]=1;fu[q]=0;}}
 for(j=0;j<=NY;j++)for(i=0;i<NX;i++){var a2=solC(i,j-1),b2=solC(i,j),q2=j*NX+i;
  if(a2===1||b2===1||(a2===2&&!F.open[2])||(b2===2&&!F.open[3])){fxV[q2]=1;fv[q2]=0;}}
 /* faces noyées (dans une paroi) : exclues de l'échantillonnage → paroi glissante */
 for(j=0;j<NY;j++)for(i=0;i<=NX;i++){var c1=solC(i-1,j),c2=solC(i,j);okU[j*(NX+1)+i]=(c1===1&&c2!==0)||(c2===1&&c1!==0)?0:1;}
 for(j=0;j<=NY;j++)for(i=0;i<NX;i++){var c3=solC(i,j-1),c4=solC(i,j);okV[j*NX+i]=(c3===1&&c4!==0)||(c4===1&&c3!==0)?0:1;}
 var src=lv.fl.src||[];
 for(k=0;k<src.length;k++){s=src[k];
  for(j=0;j<NY;j++)for(i=0;i<=NX;i++){var X0=i*HS,Y0=(j+.5)*HS,q3=j*(NX+1)+i;if(X0>=s[0]&&X0<=s[0]+s[2]&&Y0>=s[1]&&Y0<=s[1]+s[3]&&(solC(i-1,j)===0||solC(i,j)===0)){fxU[q3]=2;fu[q3]=s[4];}}
  for(j=0;j<=NY;j++)for(i=0;i<NX;i++){var X1=(i+.5)*HS,Y1=j*HS,q4=j*NX+i;if(X1>=s[0]&&X1<=s[0]+s[2]&&Y1>=s[1]&&Y1<=s[1]+s[3]&&(solC(i,j-1)===0||solC(i,j)===0)){fxV[q4]=2;fv[q4]=s[5];}}
  for(j=0;j<NY;j++)for(i=0;i<NX;i++){var X2=(i+.5)*HS,Y2=(j+.5)*HS;if(X2>=s[0]&&X2<=s[0]+s[2]&&Y2>=s[1]&&Y2<=s[1]+s[3]&&!sol[j*NX+i])frc[j*NX+i]=1;}}
 prepProject();
}

/* ── échantillonnage bilinéaire (px → px/image) ; une face noyée entre deux cellules pleines ne compte pas ── */
function sU(a,x,y){var gx=clamp(x/HS,0,NX-.001),gy=clamp(y/HS-.5,0,NY-1.001),i=gx|0,j=gy|0,fx=gx-i,fy=gy-j,k=j*(NX+1)+i,W1=NX+1,
 w0=(1-fx)*(1-fy)*okU[k],w1=fx*(1-fy)*okU[k+1],w2=(1-fx)*fy*okU[k+W1],w3=fx*fy*okU[k+W1+1],ws=w0+w1+w2+w3;
 return ws>1e-6?(a[k]*w0+a[k+1]*w1+a[k+W1]*w2+a[k+W1+1]*w3)/ws:0;}
function sV(a,x,y){var gx=clamp(x/HS-.5,0,NX-1.001),gy=clamp(y/HS,0,NY-.001),i=gx|0,j=gy|0,fx=gx-i,fy=gy-j,k=j*NX+i,
 w0=(1-fx)*(1-fy)*okV[k],w1=fx*(1-fy)*okV[k+1],w2=(1-fx)*fy*okV[k+NX],w3=fx*fy*okV[k+NX+1],ws=w0+w1+w2+w3;
 return ws>1e-6?(a[k]*w0+a[k+1]*w1+a[k+NX]*w2+a[k+NX+1]*w3)/ws:0;}
function sC(a,x,y){var gx=clamp(x/HS-.5,0,NX-1.001),gy=clamp(y/HS-.5,0,NY-1.001),i=gx|0,j=gy|0,fx=gx-i,fy=gy-j,k=j*NX+i;
 return (a[k]*(1-fx)+a[k+1]*fx)*(1-fy)+(a[k+NX]*(1-fx)+a[k+NX+1]*fx)*fy;}
function advect(){var i,j,q,x,y;u0.set(u);v0.set(v);
 for(j=0;j<NY;j++)for(i=0;i<=NX;i++){q=j*(NX+1)+i;if(fxU[q])continue;x=i*HS;y=(j+.5)*HS;
  var ux=u0[q],vy=sV(v0,x,y);u[q]=sU(u0,x-ux,y-vy);}
 for(j=0;j<=NY;j++)for(i=0;i<NX;i++){q=j*NX+i;if(fxV[q])continue;x=(i+.5)*HS;y=j*HS;
  var ux2=sU(u0,x,y),vy2=v0[q];v[q]=sV(v0,x-ux2,y-vy2);}}
function centers(){for(var j=0;j<NY;j++)for(var i=0;i<NX;i++){var k=j*NX+i;
 if(sol[k]){cu[k]=0;cv[k]=0;continue;}cu[k]=.5*(u[j*(NX+1)+i]+u[j*(NX+1)+i+1]);cv[k]=.5*(v[k]+v[k+NX]);}}
function enforce(){for(var q=0;q<NU;q++)if(fxU[q])u[q]=fu[q];for(q=0;q<NV;q++)if(fxV[q])v[q]=fv[q];}
function swirl(lv){var a=lv.fl.vx||[],n,i,j,q;
 for(n=0;n<a.length;n++){var w=a[n],r=w[2],i0=Math.max(0,Math.floor((w[0]-r)/HS)),i1=Math.min(NX,Math.ceil((w[0]+r)/HS)),j0=Math.max(0,Math.floor((w[1]-r)/HS)),j1=Math.min(NY,Math.ceil((w[1]+r)/HS));
  for(j=j0;j<j1;j++)for(i=i0;i<=i1;i++){q=j*(NX+1)+i;if(fxU[q])continue;var t=tgt(w,i*HS,(j+.5)*HS);if(t)u[q]+=(t[0]-u[q])*.25;}
  for(j=j0;j<=j1;j++)for(i=i0;i<i1;i++){q=j*NX+i;if(fxV[q])continue;var t2=tgt(w,(i+.5)*HS,j*HS);if(t2)v[q]+=(t2[1]-v[q])*.25;}
  for(j=j0;j<j1;j++)for(i=i0;i<i1;i++){var dx=(i+.5)*HS-w[0],dy=(j+.5)*HS-w[1],d=Math.sqrt(dx*dx+dy*dy);if(d<r)dye[j*NX+i]=Math.min(1,dye[j*NX+i]+.02*(1-d/r));}}
 function tgt(w,x,y){var dx=x-w[0],dy=y-w[1],d=Math.sqrt(dx*dx+dy*dy)||1;if(d>w[2])return null;var fo=1-d/w[2];
  return [(-dy/d*w[3]-dx/d*w[4])*fo,(dx/d*w[3]-dy/d*w[4])*fo];}}
function confine(eps){if(!eps)return;var i,j,k;centers();
 for(j=1;j<NY-1;j++)for(i=1;i<NX-1;i++){k=j*NX+i;cw[k]=.5*((cv[k+1]-cv[k-1])-(cu[k+NX]-cu[k-NX]));}
 for(j=2;j<NY-2;j++)for(i=2;i<NX-2;i++){k=j*NX+i;if(sol[k])continue;
  var gx=.5*(Math.abs(cw[k+1])-Math.abs(cw[k-1])),gy=.5*(Math.abs(cw[k+NX])-Math.abs(cw[k-NX])),gl=Math.sqrt(gx*gx+gy*gy)+1e-5,
      ax=eps*(gy/gl)*cw[k]*.5,ay=-eps*(gx/gl)*cw[k]*.5,qu=j*(NX+1)+i;
  if(!fxU[qu])u[qu]+=ax;if(!fxU[qu+1])u[qu+1]+=ax;if(!fxV[k])v[k]+=ay;if(!fxV[k+NX])v[k+NX]+=ay;}}
function prepProject(){var i,j,k,W1=NX+1,n=0;   /* coefficients du solveur, recalculés seulement quand les parois changent */
 for(j=0;j<NY;j++)for(i=0;i<NX;i++){k=j*NX+i;if(sol[k])continue;
  var L1=!fxU[j*W1+i],R1=!fxU[j*W1+i+1],U1=!fxV[k],D1=!fxV[k+NX],c=L1+R1+U1+D1;if(!c)continue;
  act[n++]=k;mL[k]=L1&&i>0?1:0;mR[k]=R1&&i<NX-1?1:0;mU[k]=U1&&j>0?1:0;mD[k]=D1&&j<NY-1?1:0;inv[k]=1/c;}
 nAct=n;}
function project(){var i,j,k,a,W1=NX+1,P=p,o=NX;   /* P décalé de NX : les voisins hors grille lisent 0 sans test */
 for(j=0;j<NY;j++)for(i=0;i<NX;i++){k=j*NX+i;dv[k]=sol[k]?0:(u[j*W1+i+1]-u[j*W1+i]+v[k+NX]-v[k]);}
 for(var it=0;it<ITER;it++)for(a=0;a<nAct;a++){k=act[a];var q=k+o;
  P[q]+=SOR*((mL[k]*P[q-1]+mR[k]*P[q+1]+mU[k]*P[q-NX]+mD[k]*P[q+NX]-dv[k])*inv[k]-P[q]);}   /* Gauss-Seidel sur-relaxé, ordre fixe → déterministe ; bord ouvert : pression extérieure nulle */
 for(j=0;j<NY;j++)for(i=0;i<=NX;i++){var e=j*W1+i;if(fxU[e])continue;u[e]-=(i<NX?P[j*NX+i+o]:0)-(i>0?P[j*NX+i-1+o]:0);}
 for(j=0;j<=NY;j++)for(i=0;i<NX;i++){var e2=j*NX+i;if(fxV[e2])continue;v[e2]-=(j<NY?P[j*NX+i+o]:0)-(j>0?P[(j-1)*NX+i+o]:0);}}
function stepField(lv,b){var c=cfg(lv),k;   /* physique seule : le colorant (rendu) n'y entre pas */
 swirl(lv);enforce();advect();confine(c.vort);enforce();
 if(b){var bi=clamp((b.x/HS)|0,0,NX-1),bj=clamp((b.y/HS)|0,0,NY-1),q=bj*(NX+1)+bi;   /* la balle pousse le fluide (sillage visible) */
  if(!sol[bj*NX+bi]){if(!fxU[q])u[q]+=(b.vx-u[q])*.3;if(!fxU[q+1])u[q+1]+=(b.vx-u[q+1])*.3;if(!fxV[bj*NX+bi])v[bj*NX+bi]+=(b.vy-v[bj*NX+bi])*.3;if(!fxV[(bj+1)*NX+bi])v[(bj+1)*NX+bi]+=(b.vy-v[(bj+1)*NX+bi])*.3;}}
 project();
 var dm=1-c.visc;for(k=0;k<NU;k++)if(!fxU[k])u[k]*=dm;for(k=0;k<NV;k++)if(!fxV[k])v[k]*=dm;
 centers();
}
function dyeStep(){var k;for(k=0;k<N;k++)if(frc[k])dye[k]=1;   /* colorant : rendu seulement (adaptatif) */
 if(S.mode==='run'){var b=S.ball,bk=clamp((b.y/HS)|0,0,NY-1)*NX+clamp((b.x/HS)|0,0,NX-1);if(!sol[bk])dye[bk]=Math.min(1,dye[bk]+.06);}
 dye0.set(dye);for(var j=0;j<NY;j++)for(var i=0;i<NX;i++){k=j*NX+i;dye[k]=sol[k]?0:sC(dye0,(i+.5)*HS-cu[k],(j+.5)*HS-cv[k])*.992;}}
function velU(x,y){return sU(u,x,y);}function velV(x,y){return sV(v,x,y);}
function reset(lv){u.fill(0);v.fill(0);p.fill(0);cu.fill(0);cv.fill(0);if(F.lv!==lv)dye.fill(0);F.lv=lv;F.key='';F.wN=0;}
/* Mise en régime = reset + raster(traits posés) + warm pas sans balle. Elle se fait PENDANT le tracé (1 à 3 pas par image)
   et l'état atteint est mis de côté : au lâcher, on le reprend tel quel (même résultat qu'un calcul d'un bloc → déterministe). */
var SNU=new Float32Array(NU),SNV=new Float32Array(NV),SNP=new Float32Array(p.length);F.wN=0;F.snapKey='';
function segsPosed(){var c0=S.cur;S.cur=null;var a=allSegs();S.cur=c0;return a;}
function strokesKey(lv){var st=S.strokes,h=(lv.idx||0)+':'+st.length,i;for(i=0;i<st.length;i++){var q=st[i].pts;h+='|'+q.length;for(var k=0;k<q.length;k+=Math.max(1,q.length>>2))h+=','+(q[k][0]*10|0)+','+(q[k][1]*10|0);h+=','+(q[q.length-1][0]*10|0)+','+(q[q.length-1][1]*10|0);}return h;}
function warmTo(lv,n){var c=cfg(lv);while(F.wN<c.warm&&n-->0){stepField(lv,null);F.wN++;}
 if(F.wN>=c.warm&&F.snapKey!==F.key){SNU.set(u);SNV.set(v);SNP.set(p);F.snapKey=F.key;}}
function prime(lv){var key=strokesKey(lv);if(key!==F.key||F.lv!==lv){reset(lv);raster(segsPosed(),lv);F.key=key;F.snapKey='';}}
function launch(lv,b){var t0=perf();prime(lv);
 if(F.snapKey===F.key){u.set(SNU);v.set(SNV);p.set(SNP);centers();}
 else{reset(lv);raster(segsPosed(),lv);F.key=strokesKey(lv);warmTo(lv,1e9);}
 b.sp=0;F.launchMs=perf()-t0;}
function perf(){return (typeof performance!=='undefined'?performance.now():Date.now());}

/* ── appelé par physics() une fois par image ── */
F.frame=function(b,first){var lv=L();if(first||F.lv!==lv)launch(lv,b);var t0=perf();
 stepField(lv,b);b.sp=(b.sp||0)*.985;F.ms=F.ms*.95+(perf()-t0)*.05;};

/* ── appelé par fields() à chaque sous-pas : traînée, Archimède, Magnus, non newtonien ── */
F.force=function(b,sub,g){var lv=L(),fl=lv.fl,c=cfg(lv),i;
 var inD=b.x>=0&&b.x<=W&&b.y>=0&&b.y<=H,su=inD?velU(b.x,b.y):0,sv=inD?velV(b.x,b.y):0,k=c.cd,buoy=0,ext=0;   /* hors du cadre : plus de courant */
 var lq=fl.liq||[];
 for(i=0;i<lq.length;i++){var q=lq[i];
  if(b.x<q[0]||b.x>q[0]+q[2]||b.y+R<q[1]||b.y-R>q[1]+q[3])continue;
  var f=clamp((b.y+R-q[1])/(2*R),0,1),bd=c.bd*(1+c.lud*Math.max(0,b.y-q[1])/100);
  buoy+=q[4]*f/bd;ext+=q[5]*f;}
 b.vy-=g*S.gmul*buoy/sub;
 k=(k+ext)/sub;b.vx+=(su-b.vx)*k;b.vy+=(sv-b.vy)*k;
 if(c.mg&&b.sp){var rx=b.vx-su,ry=b.vy-sv,m=c.mg*b.sp/sub;b.vx-=m*ry;b.vy+=m*rx;}
 var vk=fl.vx||[];
 for(i=0;i<vk.length;i++)if(vk[i][5]&&(b.x-vk[i][0])*(b.x-vk[i][0])+(b.y-vk[i][1])*(b.y-vk[i][1])<vk[i][5]*vk[i][5])b.dead='spike';   /* cœur du tourbillon : avalé */
 var nn=fl.nn||[];
 for(i=0;i<nn.length;i++){var z=nn[i];
  if(b.x<z[0]||b.x>z[0]+z[2]||b.y+R<z[1]||b.y-R>z[1]+z[3])continue;
  var sp=Math.sqrt(b.vx*b.vx+b.vy*b.vy);
  if(sp>z[4]&&b.y<z[1]+R*.2&&b.vy>0){   /* choc rapide : la surface se raidit et renvoie */
   b.y=z[1]-R;b.vy=-b.vy*.62;b.vx*=.94;if(S.t>(F.nnCd||0)){F.nnCd=S.t+10;BUS.emit('ball.bounce',{x:b.x,y:z[1],nx:0,ny:-1,v:sp,mat:1});}}
  else{var kk=(.05+.03*sp)/sub;b.vx*=1-kk;b.vy*=1-kk;b.vy-=g*S.gmul*.8/sub;}}   /* lent : il s'enfonce, épaissi */
 if(lv.cr)crForce(b,sub,lv);   /* R465 : créatures actives (prototype) */
 return true;};

/* ── R465 · CRÉATURES ACTIVES (prototype) ──
   lv.cr = [{t:'cils'|'gueule'|'glu', x,y, ax,ay (balancement, unités), w (pulsation), ph, r (rayon d'action), ...}]
   Tout est fonction du numéro d'image S.frames (jamais du hasard ni de l'horloge) : solutions de référence et rejeux restent exacts.
   cils   : courant ciliaire — dans le rayon r, la direction de la vitesse tourne vers l'angle a (degrés, 0 = droite, 90 = bas) au taux k.
   gueule : happe la particule (rayon rc), la garde hold images, puis la recrache à l'angle a, vitesse v ; pause cd images ensuite.
   glu    : contact (rayon r) → engluée dur images : traînée forte, la particule s'alourdit ; passe d'elle-même. */
function crPos(e,t){var w=e.w||.02;return [e.x+(e.ax||0)*Math.sin(t*w+(e.ph||0)),e.y+(e.ay||0)*Math.sin(t*w*1.31+(e.ph||0)*1.7)];}
function crWrap(a){while(a>Math.PI)a-=2*Math.PI;while(a<-Math.PI)a+=2*Math.PI;return a;}
function crForce(b,sub,lv){var cr=lv.cr,t=S.frames,i,e,p,d;
 if(t<=1){if(!b.cs1){b.cs={};b.glu=0;b.cs1=1;}}else b.cs1=0;   /* nouveau départ : on repart de zéro (la bille est réutilisée d'un essai à l'autre) */
 var cs=b.cs||(b.cs={});
 for(i=0;i<cr.length;i++){e=cr[i];p=crPos(e,t);d=Math.hypot(b.x-p[0],b.y-p[1]);var st=cs[i]||(cs[i]={h:0,cd:0,sp:0});
  if(e.t==='cils'){
   if(d<e.r){var w=1-d/e.r,a=(e.a||0)*Math.PI/180,sp=Math.hypot(b.vx,b.vy),an=Math.atan2(b.vy,b.vx);
    if(sp<.4){b.vx+=Math.cos(a)*.05*w/sub;b.vy+=Math.sin(a)*.05*w/sub;}   /* presque à l'arrêt : une poussée douce */
    else{an+=crWrap(a-an)*(e.k||.08)*w/sub;b.vx=Math.cos(an)*sp;b.vy=Math.sin(an)*sp;}
    st.on=t;}
  }else if(e.t==='gueule'){
   if(st.h>t){b.x=p[0];b.y=p[1];b.vx=0;b.vy=0;}   /* tenue dans la créature */
   else if(st.h&&!st.sp){var a2=(e.a||0)*Math.PI/180;b.vx=Math.cos(a2)*(e.v||7);b.vy=Math.sin(a2)*(e.v||7);st.sp=1;st.h=0;st.cd=t+(e.cd||90);st.out=t;
    if(window.BUS)BUS.emit('creature.spit',{x:p[0],y:p[1]});}
   else if(!st.h&&d<(e.rc||24)&&t>=st.cd){st.h=t+(e.hold||70);st.sp=0;st.in=t;b.x=p[0];b.y=p[1];b.vx=0;b.vy=0;
    if(window.BUS)BUS.emit('creature.catch',{x:p[0],y:p[1]});}
  }else if(e.t==='glu'){
   if(d<e.r){if(!(b.glu>t))st.in=t;b.glu=t+(e.dur||220);}
  }}
 if(b.glu>t){var k=.05/sub;b.vx*=1-k;b.vy*=1-k;}   /* engluée : plus lente, plus lourde */
}
F.crPos=crPos;F.crState=function(b){return b&&b.cs||null;};

/* ── rendu ── */
var PAL=null;
function pal(){if(PAL)return PAL;PAL={};var cs=typeof getComputedStyle==='function'&&document.documentElement?getComputedStyle(document.documentElement):null;
 ['fl-fond','fl-voile','fl-lent','fl-vif','fl-liquide','fl-surface','fl-dense','fl-coeur'].forEach(function(n){
  var s=cs?cs.getPropertyValue('--'+n).trim():'';PAL[n]=s||'#8899aa';PAL[n+'_rgb']=rgb(PAL[n]);});return PAL;}
function rgb(h){h=h.replace('#','');if(h.length===3)h=h.split('').map(function(x){return x+x;}).join('');var n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255];}
function rgba(c,a){return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a.toFixed(3)+')';}
function hsh(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function tracers(n){if(!F.tr||F.tr.n!==n){F.tr={n:n,x:new Float32Array(n),y:new Float32Array(n),a:new Float32Array(n),s:0};
  for(var i=0;i<n;i++)respawn(i,i*7.13);}return F.tr;}
function respawn(i,seed){var t=F.tr,lv=F.lv,src=lv&&lv.fl.src||[];F.tr.s++;var r=hsh(seed+t.s*.37);
 if(src.length&&r<.45){var s=src[(hsh(seed*3+t.s)*src.length)|0];t.x[i]=s[0]+hsh(seed*5+t.s)*s[2];t.y[i]=s[1]+hsh(seed*7+t.s)*s[3];}
 else{t.x[i]=hsh(seed*11+t.s)*360;t.y[i]=hsh(seed*13+t.s)*480;}t.a[i]=0;}
F.draw=function(c,lv){if(!lv.fl)return;var t0=perf(),P=pal(),i,k;
 if(S.mode==='draw'){prime(lv);if(F.wN<cfg(lv).warm)warmTo(lv,3);else stepField(lv,null);}   /* aperçu vivant : le courant se recompose sous le doigt (mise en régime étalée) */
 else if(S.mode!=='run'&&F.snapKey===F.key)stepField(lv,null);
 if(RM?F.frames%4===0:F.q>=2||F.frames%2===0)dyeStep();F.frames++;
 /* fond propre au monde : abysse + voile */
 c.fillStyle=rgba(P['fl-fond_rgb'],.55);c.fillRect(0,0,W,H);
 /* voile de colorant (champ de vitesse suggéré) */
 if(!F.cv){F.cv=document.createElement('canvas');F.cv.width=NX;F.cv.height=NY;}
 var g2=F.cv.getContext&&F.cv.getContext('2d');
 if(g2&&g2.createImageData){if(!F.img)F.img=g2.createImageData(NX,NY);var d=F.img.data,a=P['fl-lent_rgb'],b2=P['fl-vif_rgb'];
  for(k=0;k<N;k++){var sp=Math.min(1,Math.sqrt(cu[k]*cu[k]+cv[k]*cv[k])/9),al=sol[k]?0:Math.min(1,dye[k]*.9+sp*.25);
   d[k*4]=a[0]+(b2[0]-a[0])*sp;d[k*4+1]=a[1]+(b2[1]-a[1])*sp;d[k*4+2]=a[2]+(b2[2]-a[2])*sp;d[k*4+3]=al*150;}
  g2.putImageData(F.img,0,0);c.save();c.globalCompositeOperation='lighter';c.imageSmoothingEnabled=true;c.globalAlpha=.85;c.drawImage(F.cv,0,0,W,H);c.restore();}
 /* liquides : couches translucides, surface qui respire */
 var lq=lv.fl.liq||[],tt=(S.tick||0)*.05;
 for(i=0;i<lq.length;i++){var q=lq[i],dense=q[4]>1.2,col=dense?P['fl-dense_rgb']:P['fl-liquide_rgb'];
  var gr=c.createLinearGradient(0,q[1],0,q[1]+q[3]);gr.addColorStop(0,rgba(col,.20));gr.addColorStop(1,rgba(col,.07));
  c.fillStyle=gr;c.beginPath();c.moveTo(q[0],q[1]+q[3]);
  for(var x=q[0];x<=q[0]+q[2];x+=6)c.lineTo(x,q[1]+Math.sin(x*.07+tt)*(RM?0:1.4)+Math.sin(x*.023-tt*.6)*(RM?0:1));
  c.lineTo(q[0]+q[2],q[1]+q[3]);c.closePath();c.fill();
  c.strokeStyle=rgba(P['fl-surface_rgb'],.5);c.lineWidth=1;c.beginPath();
  for(x=q[0];x<=q[0]+q[2];x+=6){var yy=q[1]+Math.sin(x*.07+tt)*(RM?0:1.4)+Math.sin(x*.023-tt*.6)*(RM?0:1);if(x===q[0])c.moveTo(x,yy);else c.lineTo(x,yy);}c.stroke();}
 /* ludion : ligne de bascule visible (au-dessus la bille flotte, en dessous elle coule) */
 if(lv.fl.lud){var cl=cfg(lv);for(i=0;i<lq.length;i++){var q2=lq[i],ys=q2[1]+100*(q2[4]/cl.bd-1)/cl.lud;
  if(ys>q2[1]&&ys<q2[1]+q2[3]){c.fillStyle='rgba(20,40,90,.16)';c.fillRect(q2[0],ys,q2[2],q2[1]+q2[3]-ys);
   c.save();c.strokeStyle='rgba(255,255,255,.85)';c.lineWidth=1.5;c.setLineDash([8,6]);c.beginPath();c.moveTo(q2[0],ys);c.lineTo(q2[0]+q2[2],ys);c.stroke();c.restore();
   c.fillStyle='rgba(255,255,255,.9)';c.font='bold 11px sans-serif';c.textAlign='left';c.fillText('▲ flotte',q2[0]+6,ys-5);c.fillText('▼ coule',q2[0]+6,ys+14);
   var bb=S.ball;if(bb&&bb.y>q2[1]){var sk=bb.y>ys;c.save();c.strokeStyle=sk?'#ff7a59':'#6fe3a4';c.lineWidth=3;c.beginPath();c.arc(bb.x,bb.y,15,0,6.283);c.stroke();
    c.fillStyle=c.strokeStyle;c.beginPath();if(sk){c.moveTo(bb.x-6,bb.y+22);c.lineTo(bb.x+6,bb.y+22);c.lineTo(bb.x,bb.y+30);}else{c.moveTo(bb.x-6,bb.y-22);c.lineTo(bb.x+6,bb.y-22);c.lineTo(bb.x,bb.y-30);}c.fill();c.restore();}}}}
 /* fluide non newtonien : grain serré, mat */
 var nn=lv.fl.nn||[];
 for(i=0;i<nn.length;i++){var z=nn[i];c.fillStyle=rgba(P['fl-dense_rgb'],.16);c.fillRect(z[0],z[1],z[2],z[3]);
  c.fillStyle=rgba(P['fl-surface_rgb'],.35);for(k=0;k<z[2]*z[3]/90;k++)c.fillRect(z[0]+hsh(k*1.7+i)*z[2],z[1]+hsh(k*2.3+i)*z[3],1.2,1.2);}
 /* grilles : pointillé fin (le courant traverse, la balle non) */
 var gl=lv.fl.grille||[];c.strokeStyle=rgba(P['fl-surface_rgb'],.7);c.lineWidth=1;c.setLineDash([1.5,3.5]);
 for(i=0;i<gl.length;i++){c.beginPath();c.moveTo(gl[i][0]-3,gl[i][1]);c.lineTo(gl[i][2]-3,gl[i][3]);c.moveTo(gl[i][0]+3,gl[i][1]);c.lineTo(gl[i][2]+3,gl[i][3]);c.stroke();}c.setLineDash([]);
 /* tourbillons : cœur sombre qui avale la lumière */
 var vx=lv.fl.vx||[];
 for(i=0;i<vx.length;i++){var w=vx[i],rg=c.createRadialGradient(w[0],w[1],0,w[0],w[1],w[2]*.5);
  rg.addColorStop(0,rgba(P['fl-coeur_rgb'],.85));rg.addColorStop(1,rgba(P['fl-coeur_rgb'],0));c.fillStyle=rg;c.beginPath();c.arc(w[0],w[1],w[2]*.5,0,7);c.fill();}
 /* traceurs : filaments portés par le courant */
 var n=RM?0:QT[F.q];
 if(n){var T=tracers(n);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  for(var bk=0;bk<3;bk++){c.strokeStyle=rgba(bk===2?P['fl-vif_rgb']:P['fl-voile_rgb'],[.18,.32,.55][bk]);c.lineWidth=[.8,1,1.2][bk];c.beginPath();
   for(i=bk;i<n;i+=3){var x0=T.x[i],y0=T.y[i],uu=velU(x0,y0),vv=velV(x0,y0),x1=x0+uu,y1=y0+vv;
    T.a[i]++;var gi=clamp((x1/HS)|0,0,NX-1),gj=clamp((y1/HS)|0,0,NY-1);
    if(x1<0||x1>W||y1<0||y1>H||sol[gj*NX+gi]||T.a[i]>240||(uu*uu+vv*vv<.01&&T.a[i]>40)){respawn(i,i+T.a[i]);continue;}
    c.moveTo(x0-uu*1.5,y0-vv*1.5);c.lineTo(x1,y1);T.x[i]=x1;T.y[i]=y1;}c.stroke();}
  c.restore();}
 /* qualité adaptative : coût mesuré (calcul + rendu), hystérésis */
 F.dms=F.dms*.95+(perf()-t0)*.05;var tot=F.dms+(S.mode==='run'?F.ms:F.dms*.3);
 if(tot>BUDGET&&F.q>0){if(++F.qHold>60){F.q--;F.qHold=0;}}else if(tot<BUDGET*.45&&F.q<QT.length-1){if(++F.qHold>240){F.q++;F.qHold=0;}}else F.qHold=0;
};
F.info=function(){return {h:HS,nx:NX,ny:NY,it:ITER,q:F.q,ms:+F.ms.toFixed(3),dms:+F.dms.toFixed(3),warm:+(F.launchMs||0).toFixed(1)};};
F.sample=function(x,y){return [velU(x,y),velV(x,y)];};
F.solidAt=function(x,y){return sol[clamp((y/HS)|0,0,NY-1)*NX+clamp((x/HS)|0,0,NX-1)];};
F.bench=function(n){var lv=L(),t0=perf();for(var i=0;i<n;i++)stepField(lv,null);return (perf()-t0)/n;};   /* banc : ms par pas de physique */
F.setQ=function(q){F.q=clamp(q,0,QT.length-1);F.qHold=-1e9;};
window.FLUID=F;if(typeof globalThis!=="undefined")globalThis.FLUID=F;   /* hors navigateur (bancs node) */
})();



/* ============================================================
   MONDE 12 · MÉCANIQUE DES FLUIDES (caché) — données séparées
   Ajouté après les 132 niveaux : leurs indices ne bougent pas.
   Se débloque quand tous les noyaux des mondes 1–11 sont pris
   (FLUIDES_OUVERT) ; dans l'aperçu, tout est ouvert.
   Champs propres : fl (voir fluides.js).
   ============================================================ */
WORLDS.push({n:'Fluides',el:'Courants, poussée, tourbillons',c:'#7FD8E6',
 bg:'#05080F',sf:'#0C1320',gr:'#18243A',wl:'#9FE6F0',fx:'none',cache:1});
if(typeof WORLDS_EN!=='undefined')WORLDS_EN.push(['Fluids','Currents, buoyancy, vortices']);
var FLUIDES_N0=LEVELS.length;
LEVELS.push(
/* 1 · ASCENDANCE — la traînée : un courant porte la balle ; un trait le dévie */
{wd:12,n:'Ascendance',optsol:[[[120,150],[180,90],[250,80]]],optmat:0,ink:190,pal:'S',ball:[180,330],cup:[262,132,92,'N'],star:[196,150],
 w:[[0,430,150,472,X_],[150,472,210,472,S_],[210,472,360,430,X_],[0,6,360,6,X_],[250,62,356,62,S_]],
 fl:{src:[[154,456,52,14,0,-12]],cd:.15,grille:[[354,62,354,132]]},
 tip:'Le courant porte ce que la pente ne peut pas.'},
/* 2 · ÉTRANGLEMENT — Venturi : là où le conduit se resserre, le courant accélère */
{wd:12,n:'Étranglement',optsol:[[[120,291],[133,196]]],optmat:0,ink:130,pal:'S',ball:[30,312],cup:[262,330,90,'N'],star:[180,276],
 w:[[0,190,360,190,S_],[0,330,360,330,S_],[150,330,180,290,S_],[180,290,210,330,S_],[2,190,2,330,S_]],nd:[[0,0,360,186],[0,334,360,146]],
 fl:{src:[[4,194,8,132,1.8,0]],cd:.15,grille:[[354,190,354,330]]},
 tip:'Resserre le passage : le courant s’y presse.'},
/* 3 · BULLE — Archimède à l'envers : sous l'eau, on guide par le dessous */
{wd:12,n:'Bulle',optsol:[[[149,405],[189,391],[289,386]]],optmat:0,ink:195,pal:'S',ball:[150,446],zone:[300,56,56,48],star:[250,392],
 w:[[0,470,360,470,S_],[2,250,2,470,S_],[358,40,358,470,S_],[296,200,296,384,S_],[296,40,296,120,S_]],
 fl:{liq:[[0,300,296,170,1,.08],[296,96,62,374,1,.08]],bd:.5,cd:.03},
 tip:'Elle monte. Donne-lui un plafond.'},
/* 4 · ABRI — sillage : derrière un obstacle, le courant s'apaise et revient */
{wd:12,n:'Abri',optsol:[[[151,177],[152,320]]],optmat:0,ink:170,pal:'S',ball:[206,30],cup:[178,470,72,'B'],star:[214,250],
 w:[[0,160,176,160,S_],[250,160,360,160,S_],[0,330,178,330,S_],[250,330,360,330,S_],[2,330,2,470,S_],[358,330,358,470,S_],[0,470,178,470,X_],[250,470,358,470,X_]],
 fl:{src:[[0,164,8,162,8,0]],cd:.15},
 tip:'Le vent emporte tout. Sauf à l’abri.'},
/* 5 · RASANT — couche de courant au ras du sol : la balle doit y être déposée, pas lancée */
{wd:12,n:'Rasant',optsol:[[[192,437],[125,371],[129,371]]],optmat:0,ink:140,pal:'S',ball:[30,135],cup:[230,470,120,'N'],star:[150,330],
 w:[[180,210,360,210,S_],[180,210,180,380,S_],[180,380,360,380,S_],[0,470,176,470,X_],[176,470,230,470,S_],[2,200,2,470,S_]],
 fl:{src:[[0,120,8,30,10,0]],cd:.15,grille:[[354,384,354,470]]},
 tip:'Le courant rase le sol. Dépose-la dedans.'},
/* 6 · MACHINE · ÉCLUSE — chute, cheminée soufflée, déversoir, bassin : le fluide fait tout le chemin */
{wd:12,n:'Écluse',optsol:[[[4,50],[60,110],[100,176]]],optmat:0,ink:200,pal:'S',ball:[30,30],zone:[252,206,100,52],star:[222,240],flow:[[30,48],[32,60],[42,69],[52,81],[64,94],[78,111],[94,132],[110,159],[125,189],[138,222],[150,260],[163,302],[177,346],[184,344],[199,346],[228,339],[224,327],[222,310],[221,289],[219,266],[218,242],[217,218],[217,194],[216,170],[215,145],[226,125],[244,118],[269,115],[297,119],[325,136],[338,152],[335,166],[335,180],[334,193],[334,207],[334,221],[334,235],[335,249],[335,260],[336,266],[337,268],[338,267],[338,266],[339,263],[340,258],[340,253],[340,248],[339,245],[339,244],[339,245]],mz:[[110,90,250,380]],
 w:[[80,190,110,226,S_],[190,180,160,210,S_],[110,226,166,370,A_],[160,210,200,330,S_],[200,150,200,330,S_],[244,150,244,470,S_],[166,370,244,352,S_],[356,100,356,470,S_],[244,470,356,470,S_],
    [196,150,212,112,S_],[212,112,250,96,S_],[250,96,300,104,S_],[300,104,340,124,S_]],
 fl:{src:[[202,290,40,12,0,-13]],liq:[[246,250,108,218,1,.08]],bd:.5,cd:.12,open:'R'},
 tip:'Fais entrer la balle. La machine s’occupe du reste.'},
/* 7 · ŒIL — tourbillon : tout tourne vers le centre ; une tangente libère */
{wd:12,n:'Œil',optsol:[[[230,296],[324,281]]],optmat:0,ink:130,pal:'S',ball:[180,30],cup:[10,470,90,'B'],star:[256,276],
 w:[[0,470,10,470,X_],[100,470,360,470,X_]],
 fl:{vx:[[180,250,160,10,.9,20]],cd:.15},
 tip:'Au centre, rien ne revient. Choisis ton côté.'},
/* 8 · LUDION — la pression comprime : assez profond, ce qui flottait coule */
{wd:12,n:'Ludion',optsol:[[[47,177],[132,136]]],optmat:0,ink:140,pal:'S',ball:[40,40],cup:[140,470,90,'B'],star:[186,300],
 w:[[0,110,120,140,S_],[0,470,140,470,S_],[230,470,360,470,S_],[2,200,2,470,S_],[358,200,358,470,S_]],
 fl:{liq:[[0,260,360,210,1,.2]],bd:.8,lud:.2,cd:.02},
 tip:'La balle flotte au-dessus de la ligne pointillée et coule en dessous : creuse-la vers le bas.'},
/* 9 · SABLES — fluide non newtonien : il cède au lent, résiste au rapide */
{wd:12,n:'Sables',optsol:[[[27,91],[52,241],[123,282]]],optmat:0,ink:290,pal:'S',ball:[30,40],cup:[300,380,56,'R'],star:[200,320],
 w:[[0,380,80,380,S_],[80,470,300,470,X_],[80,380,80,470,S_],[300,380,300,470,S_]],nd:[[110,0,250,380]],
 fl:{nn:[[80,380,220,90,6]],cd:.01},
 tip:'Lente, elle s’enlise. Vive, elle rebondit.'},
/* 10 · EFFET — Magnus : la balle qui tourne dérive dans le courant */
{wd:12,n:'Effet',optsol:[[[100,125],[150,150],[185,200]]],optmat:0,ink:200,pal:'S',ball:[50,95],cup:[290,330,70,'N'],star:[215,225],
 w:[[0,6,360,6,X_],[0,470,360,470,X_],[0,125,110,125,S_],[250,330,356,330,S_],[356,200,356,330,S_]],
 fl:{src:[[190,170,30,100,5,0]],cd:.12},
 tip:'Lance la balle dans le jet : il la pousse de côté.'},
/* 11 · CLOISON — pression : le courant sort par où c'est le plus facile */
{wd:12,n:'Cloison',optsol:[[[119,150],[127,294]]],optmat:0,ink:190,pal:'S',ball:[200,268],zone:[150,62,60,50],star:[180,170],
 w:[[150,58,150,140,S_],[210,58,210,140,S_],[100,140,150,140,S_],[210,140,260,140,S_],[100,140,100,200,S_],[100,240,100,300,S_],[260,140,260,300,S_],[140,300,260,300,S_],[0,200,96,200,X_],[40,340,200,340,X_],[0,470,360,470,X_]],
 fl:{src:[[240,256,16,40,-10,0]],cd:.15,grille:[[150,58,210,58]]},
 tip:'Ferme deux portes d’un seul trait.'},
/* 12 · MACHINE · CYCLE — rivière, chute, vent rasant, cheminée : un tour complet porté par le fluide */
{wd:12,n:'Cycle',optsol:[[[352,50],[240,80],[146,98]]],optmat:0,ink:260,pal:'S',ball:[330,30],zone:[12,42,44,64],star:[230,158],flow:[[168,80],[164,81],[159,82],[154,83],[148,84],[140,86],[132,94],[127,110],[125,131],[124,155],[127,170],[132,169],[139,171],[155,172],[177,172],[199,172],[222,172],[244,172],[267,172],[289,172],[311,172],[331,178],[340,190],[337,207],[336,230],[336,257],[335,287],[335,320],[335,355],[335,390],[334,426],[334,456],[325,450],[309,449],[290,452],[267,455],[243,456],[219,456],[193,456],[166,456],[140,456],[113,456],[88,456],[63,456],[41,453],[27,440],[27,420],[28,393],[28,361],[28,328],[29,293],[29,259],[30,225],[31,191],[32,156],[33,121],[35,86],[36,55],[37,57],[38,55],[39,55],[40,55],[41,55],[41,55],[40,55]],mz:[[0,110,360,370]],
 w:[[64,128,100,128,S_],[150,128,356,128,S_],[64,128,64,186,S_],[64,186,300,186,A_],[300,186,300,420,S_],[356,128,356,470,S_],
    [10,470,356,470,S_],[58,420,300,420,S_],[10,40,10,470,S_],[58,108,58,420,S_],[58,40,58,108,S_],[150,100,150,128,S_],[100,100,100,128,S_]],
 fl:{src:[[160,132,8,52,6,0],[306,444,40,24,-9,0],[14,446,40,16,0,-13]],cd:.15,open:'T',grille:[[10,40,58,40]]},
 tip:'Rien ne la pousse que ce qui coule.'}
);
/* ── R465 · PROTOTYPE « créatures actives » : 3 niveaux d'essai, hors jeu normal.
   Visibles seulement avec ?proto=1 dans l'adresse (mémorisé) ; ?proto=0 les retire. Ils suivent « Cycle ». ── */
var QXPROTO=false;
try{var qs=(typeof location!=='undefined'&&location.search)||'';if(/[?&]proto=1/.test(qs))localStorage.setItem('qxproto','1');if(/[?&]proto=0/.test(qs))localStorage.removeItem('qxproto');QXPROTO=localStorage.getItem('qxproto')==='1';}catch(e){QXPROTO=false;}
if(QXPROTO)LEVELS.push(
/* P1 · CILS — une paramécie bat des cils : dans son courant, la particule change de cap */
{wd:12,n:'Cils',optsol:[[[30,110],[90,140]]],optmat:0,ink:120,pal:'S',ball:[50,40],cup:[240,470,110,'R'],star:[210,150],
 w:[[180,250,180,470,S_],[0,470,176,470,X_]],
 cr:[{t:'cils',x:115,y:190,r:80,a:-28,k:.07}],
 fl:{cd:.02},
 tip:'Les cils tournent la particule vers leur cap. Place-la dans leur courant.'},
/* P2 · GUEULE — une systole happe, garde, puis recrache : le temps et l'angle sont ceux de la créature */
{wd:12,n:'Gueule',optsol:[[[40,110],[100,130]]],optmat:0,ink:120,pal:'S',ball:[50,40],cup:[250,470,100,'R'],star:[200,120],
 w:[[205,230,205,470,S_],[0,470,200,470,X_],[358,0,358,470,S_]],
 cr:[{t:'gueule',x:150,y:205,ay:20,w:.03,rc:26,hold:80,a:-48,v:6,cd:120}],
 fl:{cd:.02},
 tip:'Elle t’avale, te garde un instant, puis te recrache : lis son angle.'},
/* P3 · GLU — une voile collante : engluée, la particule perd sa vitesse et tombe dans le bassin au lieu de le survoler */
{wd:12,n:'Glu',optsol:[[[40,150],[150,260]]],optmat:0,ink:200,pal:'S',ball:[50,40],cup:[190,470,70,'N'],star:[205,330],
 w:[[0,470,186,470,X_],[264,470,356,470,X_],[358,0,358,470,S_],[0,0,0,470,S_]],
 cr:[{t:'glu',x:195,y:300,ax:14,w:.025,r:46,dur:300}],
 fl:{cd:.02},
 tip:'Trop vite, tu dépasses le bassin. Englué, tu tombes juste.'}
);
/* préparation (comme les 132) : murs + bassin d'arrivée */
(function(){
 for(var i=FLUIDES_N0;i<LEVELS.length;i++){var L=LEVELS[i];
  L.walls=(L.w||[]).slice();
  ((L.fl&&L.fl.grille)||[]).forEach(function(g){var s=[g[0],g[1],g[2],g[3],SOLID];s.grille=1;L.walls.push(s);});   /* paroi perméable */
  if(L.zone&&!L.cup){}else if(L.cup){var x=L.cup[0],y=L.cup[1],w=L.cup[2],s=L.cup[3];L.walls.push([x,y,x+w,y,SOLID]);
   if(s==='R'||s==='B')L.walls.push([x+w,y,x+w,y-56,SOLID]);if(s==='L'||s==='B')L.walls.push([x,y,x,y-56,SOLID]);L.zone=[x,y-48,w,48];}
  if(!L.eleg)L.eleg=.62;if(!L.pal)L.pal='S';L.idx=i;}
})();
function FLUIDES_OUVERT(best){for(var i=0;i<FLUIDES_N0;i++)if(LEVELS[i].star&&!((best[i]||0)>=3))return false;return true;}

/* R460 · textes anglais des 12 niveaux du monde caché (indices 132 à 143) */
(function(){if(typeof LV_EN_N==='undefined'||typeof LV_EN_T==='undefined')return;
var N=['Ascent','Throat','Bubble','Shelter','Skimming','Lock','Eye','Diver','Sands','Spin','Partition','Cycle'],
T=['The current carries what the slope cannot.','Narrow the passage: the current rushes through it.','It rises. Give it a ceiling.','The wind carries everything off. Except in shelter.','The current skims the ground. Drop the ball into it.','Get the ball in. The machine does the rest.','At the center, nothing comes back. Pick your side.','The ball floats above the dotted line and sinks below it: dig downward.','Slow, it bogs down. Fast, it bounces.','Throw the ball into the jet: it pushes it sideways.','Close two doors with a single stroke.','Nothing pushes it but what flows.'];
for(var i=0;i<12;i++){LV_EN_N[FLUIDES_N0+i]=N[i];LV_EN_T[FLUIDES_N0+i]=T[i];}})();
