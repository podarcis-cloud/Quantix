/* ============================================================
   0 · TOKENS
   ============================================================ */
var T={bg:'#0B0F14',surface:'#141A21',surface2:'#1B222B',grid:'#242D36',border:'#2E3945',
  text:'#F1F4F6',muted:'#8793A0',matter:'#43D5F5',goal:'#9BE84B',bounce:'#FFAA3C',
  boost:'#A878FF',danger:'#FF5252',reward:'#FFD85A',air:'#A8C8E8',ice:'#BFEAF7',rope:'#E8B98A',
  cyan:'#43D5F5',violet:'#A878FF',gold:'#FFD85A',pink:'#FF4D8D'};
var MOT={ui:140,materialize:220,impact:180,success:420};

var ICON={
 back:'<path d="M15 5.5 8.2 12 15 18.5"/>',
 pause:'<path d="M9.5 5.5v13M14.5 5.5v13"/>',
 undo:'<path d="M4.6 10.6h9.6a4.7 4.7 0 0 1 0 9.4H8.2"/><path d="m4.6 10.6 3.8-3.8M4.6 10.6l3.8 3.8"/>',
 pen:'<path d="M5 19.2l3.6-.9L18.2 8.7a1.9 1.9 0 0 0 0-2.7l-.2-.2a1.9 1.9 0 0 0-2.7 0L5.9 15.4z"/><path d="M13.8 7.4l2.8 2.8"/>',
 erase:'<path d="M4.6 19.6h14.8"/><path d="m7.2 16.6 7.4-7.4 3.8 3.8-7.4 7.4z"/>',
 slow:'<circle cx="12" cy="12" r="7.6"/><path d="M12 7.6V12l2.8 1.9"/>',
 target:'<circle cx="12" cy="12" r="7.4"/><circle cx="12" cy="12" r="2.6"/>',
 core:'<circle cx="12" cy="12" r="3"/><path d="M12 3.6v3M12 17.4v3M3.6 12h3M17.4 12h3"/><circle cx="12" cy="12" r="7.6" stroke-dasharray="2.4 3.2"/>',
 star:'<path d="m12 4.6 2.4 4.8 5.3.8-3.8 3.7.9 5.3-4.8-2.5-4.8 2.5.9-5.3-3.8-3.7 5.3-.8z"/>',
 lock:'<path d="M8 11V8.8a4 4 0 0 1 8 0V11"/><rect x="5.8" y="11" width="12.4" height="8.2" rx="2.2"/>',
 rewind:'<path d="M11 7.4 4.6 12 11 16.6zM19.4 7.4 13 12l6.4 4.6z"/>',
 grid:'<path d="M5 5.6h5.2v5.2H5zM13.8 5.6H19v5.2h-5.2zM5 14.2h5.2v5.2H5zM13.8 14.2H19v5.2h-5.2"/>',
 gear:'<circle cx="12" cy="12" r="3.1"/><circle cx="12" cy="12" r="7.4"/><path d="M12 2.8v1.8M12 19.4v1.8M21.2 12h-1.8M4.6 12H2.8"/>',
 spark:'<path d="M6 38 24 12l18 26"/>',
 line:'<circle cx="5.8" cy="18.2" r="2.3"/><circle cx="18.2" cy="5.8" r="2.3"/><path d="m7.5 16.5 9-9"/>',
 rub:'<path d="M7.4 20.2 3.9 16.7a1.9 1.9 0 0 1 0-2.7l8.6-8.6a1.9 1.9 0 0 1 2.7 0l4.9 4.9a1.9 1.9 0 0 1 0 2.7L12.6 20.2"/><path d="M20.4 20.2H7.4"/><path d="m7.6 10.4 6.9 6.9"/>',
 scale:'<path d="M4 20 20 4"/><path d="M14 4h6v6M10 20H4v-6"/>',
 magnet:'<path d="M6 4v8a6 6 0 0 0 12 0V4"/><path d="M6 8h4M14 8h4"/>',
 tone:'<circle cx="6.4" cy="12" r="2.3"/><path d="M10.6 8.9a4.4 4.4 0 0 1 0 6.2M13.9 6.1a8.4 8.4 0 0 1 0 11.8M17.2 3.4a12.2 12.2 0 0 1 0 17.2"/>',   /* R240 : Quantone — la particule qui sonne */
 move:'<path d="M12 3.8v16.4M3.8 12h16.4"/><path d="m9.4 6.4 2.6-2.6 2.6 2.6M9.4 17.6l2.6 2.6 2.6-2.6M6.4 9.4 3.8 12l2.6 2.6M17.6 9.4l2.6 2.6-2.6 2.6"/>',
 trash:'<path d="M5 7h14"/><path d="M9.6 7V5.2a1 1 0 0 1 1-1h2.8a1 1 0 0 1 1 1V7"/><path d="m6.8 7 .8 11.2a1.6 1.6 0 0 0 1.6 1.5h5.6a1.6 1.6 0 0 0 1.6-1.5L17.2 7"/><path d="M10.2 10.6v5.2M13.8 10.6v5.2"/>'};
function ico(n,s){return '<svg viewBox="0 0 24 24" width="'+(s||21)+'" height="'+(s||21)+'" fill="none" '+
 'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+ICON[n]+'</svg>';}

/* ============================================================
   2 · BUS
   ============================================================ */
var BUS={m:{},on:function(k,f){(this.m[k]=this.m[k]||[]).push(f);},
 emit:function(k,d){var a=this.m[k];if(!a)return;for(var i=0;i<a.length;i++)a[i](d||{});}};

window.__QXSAMPLES=true;
/* ══ VOIE 2 · échantillons WAV, indépendante de Web Audio ══
   Lecture par éléments <audio>. Si Web Audio est muet, celle-ci répond. */
var QXS={"ui_tap":"assets/audio/sfx/ui_tap.mp3","ui_confirm":"assets/audio/sfx/ui_confirm.mp3","draw_material":"assets/audio/sfx/draw_material.mp3","rope_set":"assets/audio/sfx/rope_set.mp3","ball_launch":"assets/audio/sfx/ball_launch.mp3","impact_solid":"assets/audio/sfx/impact_solid.mp3","impact_bounce":"assets/audio/sfx/impact_bounce.mp3","impact_ice":"assets/audio/sfx/impact_ice.mp3","rope_hit":"assets/audio/sfx/rope_hit.mp3","boost_whoosh":"assets/audio/sfx/boost_whoosh.mp3","portal":"assets/audio/sfx/portal.mp3","spike_hit":"assets/audio/sfx/spike_hit.mp3","star_collect":"assets/audio/sfx/star_collect.mp3","goal_enter":"assets/audio/sfx/goal_enter.mp3","level_success":"assets/audio/sfx/level_success.mp3","rewind":"assets/audio/sfx/rewind.mp3","level_fail":"assets/audio/sfx/level_fail.mp3"};
var QXV={"ui_tap":0.178,"ui_confirm":0.283,"draw_material":0.077,"rope_set":0.322,"ball_launch":0.321,"impact_solid":0.64,"impact_bounce":1,"impact_ice":0.281,"rope_hit":0.29,"boost_whoosh":0.21,"portal":0.374,"spike_hit":0.88,"star_collect":0.355,"goal_enter":0.412,"level_success":0.404,"rewind":0.314,"level_fail":0.417};
/* WKWebView refuse les URI data: pour les éléments média.
   On les convertit en URL de Blob, acceptées partout. */
function SRC(u){return (u.slice(0,5)==='data:')?blobURL(u):u;}
function blobURL(uri){
 try{
  var i=uri.indexOf(','), bin=atob(uri.slice(i+1));
  var u=new Uint8Array(bin.length);
  for(var k=0;k<bin.length;k++)u[k]=bin.charCodeAt(k);
  var mt=uri.slice(5,uri.indexOf(';'));
  return URL.createObjectURL(new Blob([u],{type:mt||'audio/mpeg'}));
 }catch(e){return uri;}
}
var Samp=(function(){
 var pool={},ready=false,lastErr='';
 function el(n){
  if(!pool[n]){
   try{var a=new Audio(SRC(QXS[n]));a.preload='auto';a.setAttribute('playsinline','');
    a.addEventListener('error',function(){
     var er=a.error;lastErr='chargement '+(er?('code '+er.code):'?');});
    a.volume=Math.max(.05,Math.min(1,QXV[n]||.5));pool[n]=a;}catch(e){lastErr=e.message;return null;}
  }
  return pool[n];
 }
 return {
  prime:function(){
   /* amorcer dans le geste : on lance et on coupe aussitôt */
   var a=el('ui_tap');if(!a)return;
   try{var p=a.play();
    if(p&&p.then)p.then(function(){a.pause();a.currentTime=0;ready=true;},
                        function(e){ready=false;lastErr=e&&e.name||'refus';});
    else{a.pause();ready=true;}
   }catch(e){lastErr=e.message;}
  },
  play:function(n,v){
   var a=el(n);if(!a)return false;
   try{ a.currentTime=0;
        a.volume=Math.max(.05,Math.min(1,(QXV[n]||.5)*(v===undefined?1:(.35+.65*v))));
        var p=a.play(); if(p&&p.catch)p.catch(function(e){lastErr=e&&e.name||'refus';});
        return true;
   }catch(e){lastErr=e.message;return false;}
  },
  ready:function(){return ready;},
  err:function(){return lastErr;}
 };
})();
/* ============================================================
   3 · AUDIO — banque produite par l'Atelier sonore
   ============================================================ */
/* AudioBank — généré par l’Atelier sonore.
   Remplace le bloc « 3 · AUDIO » de mur-et-balle.
   API identique : unlock, playSfx, playImpact, playMusicState,
   setMusic, setSfx, setHaptics, buzz. */
var Audio1=(function(){
var BANK={"ui_tap":{"type":"square","f0":760,"fr":0.9,"dur":0.05,"atk":0.006,"pun":0,"gain":0.055,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0,"nf":1200,"nr":1,"nq":1.2,"lp":16000,"vel":0},"ui_confirm":{"type":"triangle","f0":560,"fr":1,"dur":0.09,"atk":0.006,"pun":0,"gain":0.09,"vd":0,"vs":0,"arp":0.045,"ar":1.5,"ng":0,"nf":1200,"nr":1,"nq":1.2,"lp":16000,"vel":0},"draw_material":{"type":"sine","f0":300,"fr":1,"dur":0.07,"atk":0.006,"pun":0,"gain":0.016,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.05,"nf":1100,"nr":1.6,"nq":2.2,"lp":16000,"vel":0.6},"rope_set":{"type":"triangle","f0":330,"fr":0.45,"dur":0.22,"atk":0.006,"pun":0,"gain":0.1,"vd":0,"vs":0,"arp":0.045,"ar":0.5,"ng":0.045,"nf":820,"nr":0.42,"nq":1.7,"lp":16000,"vel":0},"ball_launch":{"type":"sine","f0":340,"fr":0.35,"dur":0.22,"atk":0.006,"pun":0,"gain":0.1,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.04,"nf":900,"nr":0.33,"nq":1.2,"lp":16000,"vel":0},"impact_solid":{"type":"sine","f0":220,"fr":0.5,"dur":0.16,"atk":0.006,"pun":0.55,"gain":0.025,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.4,"nf":1900,"nr":0.45,"nq":1.1,"lp":16000,"vel":0.8},"impact_bounce":{"type":"triangle","f0":260,"fr":2.1,"dur":0.2,"atk":0.006,"pun":0.35,"gain":0.15,"vd":0,"vs":0,"arp":0.022,"ar":2.6,"ng":0.03,"nf":1600,"nr":2.2,"nq":1.4,"lp":16000,"vel":0.75},"impact_ice":{"type":"sine","f0":880,"fr":1,"dur":0.08,"atk":0.006,"pun":0,"gain":0.085,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.03,"nf":3200,"nr":0.56,"nq":2.6,"lp":16000,"vel":0.6},"rope_hit":{"type":"triangle","f0":230,"fr":0.55,"dur":0.18,"atk":0.006,"pun":0,"gain":0.035,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.3,"nf":950,"nr":0.5,"nq":1.3,"lp":16000,"vel":0.7},"boost_whoosh":{"type":"sine","f0":330,"fr":2,"dur":0.26,"atk":0.006,"pun":0,"gain":0.06,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.09,"nf":420,"nr":6,"nq":1.5,"lp":16000,"vel":0},"portal":{"type":"sine","f0":330,"fr":3,"dur":0.3,"atk":0.006,"pun":0,"gain":0.1,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.055,"nf":2800,"nr":1.9,"nq":1.8,"lp":16000,"vel":0},"spike_hit":{"type":"square","f0":180,"fr":0.45,"dur":0.2,"atk":0.006,"pun":0.7,"gain":0.025,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.45,"nf":2400,"nr":0.28,"nq":1.2,"lp":16000,"vel":0},"star_collect":{"type":"sine","f0":1174,"fr":1,"dur":0.16,"atk":0.006,"pun":0,"gain":0.11,"vd":0,"vs":0,"arp":0.05,"ar":1.33,"ng":0,"nf":1200,"nr":1,"nq":1.2,"lp":16000,"vel":0},"goal_enter":{"type":"sine","f0":175,"fr":1,"dur":0.4,"atk":0.006,"pun":0,"gain":0.035,"vd":0,"vs":0,"arp":0.015,"ar":5,"ng":0.225,"nf":1500,"nr":1.5,"nq":1.4,"lp":16000,"vel":0},"level_success":{"type":"sine","f0":587,"fr":1,"dur":0.5,"atk":0.006,"pun":0,"gain":0.125,"vd":0,"vs":0,"arp":0.12,"ar":1.335,"ng":0,"nf":1200,"nr":1,"nq":1.2,"lp":16000,"vel":0},"rewind":{"type":"sine","f0":520,"fr":0.45,"dur":0.26,"atk":0.01,"pun":0,"gain":0.045,"vd":0,"vs":0,"arp":0,"ar":1.5,"ng":0.13,"nf":2400,"nr":0.2,"nq":1.4,"lp":16000,"vel":0},"level_fail":{"type":"sine","f0":196,"fr":0.55,"dur":0.34,"atk":0.006,"pun":0,"gain":0.03,"vd":0,"vs":0,"arp":0.09,"ar":0.75,"ng":0.35,"nf":700,"nr":0.45,"nq":1.3,"lp":16000,"vel":0}};
var WD=[{"n":"Atelier","el":"La ligne et la chute","root":53,"mode":"eolien","bpm":60,"wave":"sine","det":1.004,"cut":700,"dens":0.22},{"n":"Fonderie","el":"Rebond et sol létal","root":49,"mode":"phrygien","bpm":76,"wave":"sawtooth","det":1.012,"cut":430,"dens":0.52},{"n":"Chaîne","el":"Tapis d’élan","root":57,"mode":"dorien","bpm":96,"wave":"square","det":1.005,"cut":820,"dens":0.68},{"n":"Glacier","el":"Glace sans frottement","root":62,"mode":"lydien","bpm":48,"wave":"triangle","det":1.001,"cut":1350,"dens":0.16},{"n":"Soufflerie","el":"Colonnes d’air","root":55,"mode":"mixolydien","bpm":58,"wave":"sine","det":1.018,"cut":900,"dens":0.3},{"n":"Mécanique","el":"Pièces mobiles, rythme","root":50,"mode":"dorien","bpm":108,"wave":"square","det":1.002,"cut":520,"dens":0.78},{"n":"Gravité","el":"Champs de pesanteur","root":45,"mode":"eolien","bpm":44,"wave":"triangle","det":1.022,"cut":380,"dens":0.14},{"n":"Magnétisme","el":"Attracteurs","root":58,"mode":"phrygien","bpm":72,"wave":"sawtooth","det":1.009,"cut":680,"dens":0.44},{"n":"Faille","el":"Portails","root":60,"mode":"pentatonique","bpm":84,"wave":"sine","det":1.026,"cut":1150,"dens":0.36},{"n":"Filaments","el":"Cordes et corps mous","root":52,"mode":"dorien","bpm":54,"wave":"triangle","det":1.006,"cut":600,"dens":0.24},{"n":"Quantique","el":"Intrication, superposition, mesure","root":64,"mode":"lydien","bpm":88,"wave":"sine","det":1.015,"cut":1500,"dens":0.46}];
var MIX={"nappe":[1,1,1,1,0.7,0.6],"basse":[0,0.35,1,1,0,0],"arpège":[0,0,0.6,0.9,0.45,0],"texture":[0.3,0.5,0.4,0.9,0,0.2]};
var MODES={"eolien":[0,2,3,5,7,8,10],"dorien":[0,2,3,5,7,9,10],"phrygien":[0,1,3,5,7,8,10],"lydien":[0,2,4,6,7,9,11],"mixolydien":[0,2,4,5,7,9,10],"pentatonique":[0,3,5,7,10]};
var LAYERS=["nappe","basse","arpège","texture"];
var ST={menu:0,draw:1,run:2,tension:3,success:4,failure:5};
var ac=null,ma,mg,sg,nb,L={},pad=null,tm=null,beat=0,nx=0,wi=0,st=0,started=false;
var on={music:true,sfx:true,haptics:true},vol={mus:.5,sfx:1};
function init(){if(ac)return ac;var A=window.AudioContext||window.webkitAudioContext;if(!A)return null;
 ac=new A();ma=ac.createGain();ma.gain.setValueAtTime(0,ac.currentTime);ma.gain.linearRampToValueAtTime(.9,ac.currentTime+.18);ma.connect(ac.destination);   /* R416 : fondu d'entrée (plus de clic) */
 mg=ac.createGain();mg.gain.value=on.music?vol.mus:0;mg.connect(ma);
 sg=ac.createGain();sg.gain.value=on.sfx?vol.sfx:0;sg.connect(ma);
 var n=Math.floor(ac.sampleRate*1.5),b=ac.createBuffer(1,n,ac.sampleRate),d=b.getChannelData(0),i;
 for(i=0;i<n;i++)d[i]=Math.random()*2-1;nb=b;return ac;}
function shot(p,t0,vel){
 var v=(vel===undefined)?1:vel,amp=p.gain*(1-p.vel+p.vel*v);
 var dur=p.dur*(1-p.vel*.25+p.vel*.25*v),f0=p.f0*(1-p.vel*.18+p.vel*.18*v);
 function voice(f,at,g0,d){if(g0<=.0002)return;
  var o=ac.createOscillator(),g=ac.createGain();o.type=p.type;
  o.frequency.setValueAtTime(f,at);
  if(Math.abs(p.fr-1)>.01)o.frequency.exponentialRampToValueAtTime(Math.max(20,f*p.fr),at+d);
  if(p.vd>0&&p.vs>0){var lo=ac.createOscillator(),la=ac.createGain();
   lo.frequency.value=p.vs;la.gain.value=p.vd;lo.connect(la);la.connect(o.frequency);
   lo.start(at);lo.stop(at+d+.05);}
  var pk=g0*(1+p.pun*1.4);
  g.gain.setValueAtTime(.0001,at);g.gain.linearRampToValueAtTime(pk,at+Math.max(.004,p.atk));
  if(p.pun>0)g.gain.linearRampToValueAtTime(g0,at+Math.max(.006,p.atk)+d*.18);
  g.gain.exponentialRampToValueAtTime(.0005,at+d);
  o.connect(g);g.connect(sg);o.start(at);o.stop(at+d+.04);}
 voice(f0,t0,amp,dur);
 if(p.arp>0)voice(f0*p.ar,t0+p.arp,amp*.72,dur*.7);
 if(p.ng>.002){var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),g2=ac.createGain();
  s.buffer=nb;bp.type='bandpass';bp.Q.value=p.nq;bp.frequency.setValueAtTime(p.nf,t0);
  if(Math.abs(p.nr-1)>.01)bp.frequency.exponentialRampToValueAtTime(Math.max(60,p.nf*p.nr),t0+dur);
  g2.gain.setValueAtTime(.0001,t0);g2.gain.linearRampToValueAtTime(p.ng*(1-p.vel+p.vel*v),t0+Math.max(.004,p.atk));
  g2.gain.exponentialRampToValueAtTime(.0005,t0+dur);
  s.connect(bp);bp.connect(g2);g2.connect(sg);s.start(t0);s.stop(t0+dur+.04);}}
function midi(n){return 440*Math.pow(2,(n-69)/12);}
function deg(w,d,o){var s=MODES[w.mode];return midi(w.root+s[((d%s.length)+s.length)%s.length]+12*(Math.floor(d/s.length)+(o||0)));}
function pluck(dest,f,t,d,ty,g){var o=ac.createOscillator(),n=ac.createGain();
 o.type=ty;o.frequency.setValueAtTime(f,t);n.gain.setValueAtTime(.0001,t);
 n.gain.linearRampToValueAtTime(g,t+.012);n.gain.exponentialRampToValueAtTime(.0004,t+d);
 o.connect(n);n.connect(dest);o.start(t);o.stop(t+d+.05);}
function swell(dest,t,d,cut){var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),g=ac.createGain();
 s.buffer=nb;s.loop=true;bp.type='bandpass';bp.Q.value=.8;
 bp.frequency.setValueAtTime(cut*.6,t);bp.frequency.linearRampToValueAtTime(cut*1.3,t+d*.5);
 bp.frequency.linearRampToValueAtTime(cut*.6,t+d);
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.035,t+d*.35);
 g.gain.exponentialRampToValueAtTime(.0004,t+d);
 s.connect(bp);bp.connect(g);g.connect(dest);s.start(t);s.stop(t+d+.1);}
function build(){if(pad||!ac)return;var w=WD[wi],i;
 LAYERS.forEach(function(n){var g=ac.createGain();g.gain.value=0;g.connect(mg);L[n]=g;});
 var o1=ac.createOscillator(),o2=ac.createOscillator(),f=ac.createBiquadFilter();
 o1.type=w.wave;o2.type='sine';o1.frequency.value=deg(w,0,-1);o2.frequency.value=deg(w,0,-1)*w.det;
 f.type='lowpass';f.frequency.value=w.cut;
 var lo=ac.createOscillator(),la=ac.createGain();lo.frequency.value=.045;la.gain.value=w.cut*.3;
 lo.connect(la);la.connect(f.frequency);lo.start();
 o1.connect(f);o2.connect(f);f.connect(L['nappe']);o1.start();o2.start();
 pad=[o1,o2,lo];beat=0;nx=ac.currentTime+.1;tm=setInterval(tick,25);mix(1);}
function mix(t){if(!pad)return;LAYERS.forEach(function(n){
 L[n].gain.setTargetAtTime(MIX[n][st]*.22,ac.currentTime,t||.5);});}
function tick(){if(!pad)return;var w=WD[wi],spb=60/w.bpm;
 while(nx<ac.currentTime+.15){var t=nx,b=beat;
  if(b%2===0)pluck(L['basse'],deg(w,(b%8===0)?0:4,0),t,spb*.9,'triangle',.085);
  if(Math.random()<w.dens)pluck(L['arpège'],deg(w,2+Math.floor(Math.random()*5),1),t,spb*.55,w.wave,.045);
  if(b%8===0)swell(L['texture'],t,spb*6,w.cut*1.4);
  nx+=spb;beat++;}}
var silent=null,mediaOK=false,sessOK=false;
/* Safari 16.4+ : déclarer la lecture comme fonction centrale.
   Le commutateur silencieux cesse alors de s'appliquer. */
function session(){
 try{
  if(navigator.audioSession){navigator.audioSession.type='playback';sessOK=true;}
 }catch(e){sessOK=false;}
}
function kick(){try{
 if(!silent){silent=new Audio(SRC('assets/audio/silent.mp3'));
  silent.loop=true;silent.volume=.001;silent.preload='auto';
  silent.setAttribute('playsinline','');
  silent.setAttribute('x-webkit-airplay','deny');}
 var q=silent.play();
  if(q&&q.then)q.then(function(){mediaOK=true;},function(){mediaOK=false;});
  else mediaOK=true;
 }catch(e){mediaOK=false;}}
return{
 /* réessaie à chaque geste : une première tentative refusée ne doit pas
    condamner la session. kick() sort la sortie de la voie sonnerie sur iOS. */
 unlock:function(){
  session();
  try{Samp.prime();}catch(e){}
  if(!mediaOK)kick();
  var c=init();if(!c){return;}
  if(c.state==='suspended'){try{var r=c.resume();if(r&&r.catch)r.catch(function(){});}catch(e){}}
  if(!started){started=true;build();}},
 prime:function(){session();if(!mediaOK)kick();},   /* R433 : session iOS + boucle silencieuse SANS créer de second contexte audio */
 media:function(){return mediaOK;},
 sampReady:function(){return Samp.ready();},
 session:function(){return sessOK?'playback':(navigator.audioSession?'refusée':'non supportée');},
 sampErr:function(){return Samp.err();},
 state:function(){return ac?ac.state:((window.AudioContext||window.webkitAudioContext)?'inactif':'non supporté');},
 test:function(){if(ac&&BANK.ui_confirm)shot(BANK.ui_confirm,ac.currentTime+.01,1);},
 setWorld:function(i){if(!WD[i])i=0;if(i===wi)return;wi=i;
  if(pad){clearInterval(tm);var old=pad,og=L;pad=null;
   LAYERS.forEach(function(n){og[n].gain.setTargetAtTime(0,ac.currentTime,.25);});
   setTimeout(function(){try{old.forEach(function(o){o.stop();});}catch(e){}
    LAYERS.forEach(function(n){try{og[n].disconnect();}catch(e){}});},900);
   setTimeout(build,300);}},
 playSfx:function(n,v){
  if(!on.sfx)return;
  if(window.__QXSAMPLES&&Samp.play(n,v))return;
  if(!ac||!BANK[n])return;shot(BANK[n],ac.currentTime+.005,v);},
 playImpact:function(mat,vel){
  if(!on.sfx)return;var i=Math.min(1,vel/9);if(i<.08)return;
  if(window.__QXSAMPLES){
   var kk=mat===1?'impact_bounce':(mat===2?'spike_hit':(mat===4?'impact_ice':'impact_solid'));
   if(Samp.play(kk,i))return;}
  if(!ac)return;
  var k=mat===1?'impact_bounce':(mat===2?'spike_hit':(mat===4?'impact_ice':'impact_solid'));
  shot(BANK[k],ac.currentTime+.005,i);},
 playMusicState:function(s){if(ST[s]===undefined)return;st=ST[s];mix(s==='tension'?.4:.9);},
 setMusic:function(v){on.music=!!v;if(mg)mg.gain.value=on.music?vol.mus:0;},
 setSfx:function(v){on.sfx=!!v;if(sg)sg.gain.value=on.sfx?vol.sfx:0;},
 setMusicVol:function(v){vol.mus=v;on.music=v>0;if(mg)mg.gain.value=v;},
 setSfxVol:function(v){vol.sfx=v;on.sfx=v>0;if(sg)sg.gain.value=v;},
 world:function(){return wi;},
 params:function(){return WD[wi]||null;},
 tune:function(p){var w=WD[wi];if(!w)return;for(var k in p)w[k]=p[k];
  if(pad){var old=pad,og=L;pad=null;clearInterval(tm);
   LAYERS.forEach(function(n2){og[n2].gain.setTargetAtTime(0,ac.currentTime,.08);});
   setTimeout(function(){try{old.forEach(function(o){o.stop();});}catch(e2){}
    LAYERS.forEach(function(n2){try{og[n2].disconnect();}catch(e3){}});},300);
   setTimeout(build,140);}},
 setHaptics:function(v){on.haptics=v;},
 buzz:function(p){if(on.haptics&&navigator.vibrate)try{navigator.vibrate(p);}catch(e){}}
};})();

/* ============================================================
   4 · WORLD + PHYSICS
   ============================================================ */
var W=360,H=480,R=10.5,G=.40,REST=.34,FRIC=.995,PADE=1.52,BOOSTF=.62,VMAX=15.5;
var ROPE=5;
var COST={0:1,1:1.9,3:1.7,5:1.4};
var TOOLNAME={0:'structure',1:'rebond',3:'élan',5:'corde'};

var S={li:0,mode:'draw',strokes:[],cur:null,curLen:0,ink:0,inkMax:1,tool:SOLID,
 ball:{x:0,y:0,vx:0,vy:0,a:0},trail:[],pathRec:[],trace:[],rec:[],scrubI:0,reprises:0,
 inZone:0,still:0,frames:0,gotStar:false,t:0,tick:0,slow:false,squash:null,tension:false,
 zen:false,gmul:1,tmul:1,drop:null,
 branch:null,gtrail:[],superposed:false,collapsed:false,ent:[],timeScale:1,acc:0,
 best:[],bestMat:[],unlocked:0,seen:0};
(function(){for(var i=0;i<LEVELS.length;i++){S.best.push(0);S.bestMat.push(0);}})();
function L(){return S.zen?ZEN:LEVELS[S.li];}
function TH(){var lv=L();return WORLDS[(lv.wd||1)-1]||WORLDS[0];}
function wPos(i){var L0=LEVELS[i],k,n=0;for(k=0;k<i;k++)if(LEVELS[k].wd===L0.wd)n++;return n;}
function wFirst(w){for(var i=0;i<LEVELS.length;i++)if(LEVELS[i].wd===w)return i;return 0;}
function wStats(w){var r=worldRange(w),d=0,m=0,i;
 for(i=0;i<r.length;i++){if(S.best[r[i]])d++;if(S.best[r[i]]>=3)m++;}
 return {tot:r.length,done:d,mast:m,first:r[0]};}

function moverSeg(m){var q=S.t*m.spd+(m.ph||0),o=Math.sin(q)*m.amp,s=m.seg;   /* R140 : phase m.ph ; m.v = la pièce entraîne la balle (vitesse transmise) */
 if(m.v){var vv=Math.cos(q)*m.amp*m.spd;return [s[0]+m.ax*o,s[1]+m.ay*o,s[2]+m.ax*o,s[3]+m.ay*o,m.m||SOLID,0,0,m.ax*vv,m.ay*vv,m.grip||0];}   /* R162 : m.grip = adhérence (plateforme porteuse) */
 return [s[0]+m.ax*o,s[1]+m.ay*o,s[2]+m.ax*o,s[3]+m.ay*o,SOLID];}

function gateOpen(g){
 /* g=[x1,y1,x2,y2,pairIndex,phase] — phase 0 fermée au repos, 1 ouverte au repos */
 var p=S.ent[g[4]];if(!p)return false;
 var on=p.on,ee=(L().ent||[])[g[4]];
 if(ee&&ee[4]==='opp'){var gx=(g[0]+g[2])/2,gy=(g[1]+g[3])/2;if(Math.hypot(gx-ee[2],gy-ee[3])<Math.hypot(gx-ee[0],gy-ee[1]))on=!on;}   /* R243 : paire opposée réelle — une porte suit le spin du noyau le plus proche ; en « opp », le noyau B a toujours le spin contraire de A */
 return (g[5]===1)?!on:on;
}
function allSegs(){
 var lv=L(),a=lv.walls.slice(),i,k,st;
 if(lv.gate)for(i=0;i<lv.gate.length;i++){
  var g=lv.gate[i];
  if(!gateOpen(g))a.push([g[0],g[1],g[2],g[3],SOLID]);
 }
 if(lv.mov)for(i=0;i<lv.mov.length;i++)a.push(moverSeg(lv.mov[i]));
 var drawn=S.strokes.concat(S.cur?[{pts:S.cur,mat:S.tool}]:[]);
 for(i=0;i<drawn.length;i++){
  if(drawn[i].mat===ROPE)continue;
  st=drawn[i].pts;
  for(k=1;k<st.length;k++)a.push([st[k-1][0],st[k-1][1],st[k][0],st[k][1],drawn[i].mat,1]);}
 return a;
}
/* balle rigide contre corde : correction de position partagée,
   la balle encaisse un quart, la corde les trois quarts */
function collideRopes(b){
 var r,i,k,P=QP.p;
 for(r=0;r<QP.ropes.length;r++){
  var R0=QP.ropes[r];
  for(i=R0.i0;i<R0.i1;i++){
   var A=P[i],B=P[i+1];
   var dx=B.x-A.x,dy=B.y-A.y,l2=dx*dx+dy*dy,t=0;
   if(l2>0){t=((b.x-A.x)*dx+(b.y-A.y)*dy)/l2;t=t<0?0:t>1?1:t;}
   var cx=A.x+t*dx,cy=A.y+t*dy,nx=b.x-cx,ny=b.y-cy;
   var d=Math.sqrt(nx*nx+ny*ny),lim=R+3.4;
   if(d>=lim||d<1e-6)continue;
   nx/=d;ny/=d;
   var pen=lim-d;
   b.x+=nx*pen*.28;b.y+=ny*pen*.28;
   var wA=(1-t)*.72,wB=t*.72;
   if(!A.pin){A.x-=nx*pen*wA;A.y-=ny*pen*wA;}
   if(!B.pin){B.x-=nx*pen*wB;B.y-=ny*pen*wB;}
   var el=R0.str?(L().strE||.86):(R0.drv&&L().sling&&L().sling.e!=null)?L().sling.e:(L().elastic||0),cvx=0,cvy=0;   /* R145 : corde élastique — rebond relatif à la corde qui bouge */
   if(el){cvx=((A.x-A.px)*(1-t)+(B.x-B.px)*t);cvy=((A.y-A.py)*(1-t)+(B.y-B.py)*t);if(R0.dv){var wd=R0.drv.end===1?1-t:R0.drv.end===2?t:1;cvx+=R0.dv[0]*wd;cvy+=R0.dv[1]*wd;}}   /* R146 : + vitesse d'entraînement de la corde (par image) */
   var vn=(b.vx-cvx)*nx+(b.vy-cvy)*ny;
   if(vn<0){
    b.vx-=(el?1+el:1.2)*vn*nx;b.vy-=(el?1+el:1.2)*vn*ny;
    var tx=-ny,ty=nx,vt=(b.vx*tx+b.vy*ty)*.97,nv=b.vx*nx+b.vy*ny;
    b.vx=nx*nv+tx*vt;b.vy=ny*nv+ty*vt;
    b.a+=vt/R*.28;
    if(-vn>1.4)BUS.emit('ball.rope',{x:cx,y:cy,v:-vn,r:r});
   }
  }
 }
}
function matPhys(m){
 if(m===BOUNCEM)return[PADE,1];
 if(m===ICEM)return[.12,1];
 return[REST,FRIC];
}

/* ============================================================
   4b · QP — noyau à contraintes, modèle transposé de QuarkPhysics
   (erayzesen/QuarkPhysics, MIT) : dynamique basée sur les positions
   plutôt que sur les impulsions, masse-ressort, préservation d'aire,
   collision des corps mous par point-dans-polygone + rayons bissecteurs.
   Portage JavaScript indépendant, aucune ligne de la source C++.
   ============================================================ */
var QP={
 p:[],c:[],ropes:[],soft:null,iter:3,damp:.994,pr:2.6,
 clear:function(){this.p=[];this.c=[];this.ropes=[];this.soft=null;},
 add:function(x,y,pin){this.p.push({x:x,y:y,px:x,py:y,pin:!!pin});return this.p.length-1;},
 link:function(a,b,k){
  var A=this.p[a],B=this.p[b];
  this.c.push({t:0,a:a,b:b,r:Math.hypot(B.x-A.x,B.y-A.y),k:k===undefined?1:k});},
 area:function(idx,k){
  this.c.push({t:1,i:idx,r:polyArea(idx),k:k});}
};
function polyArea(idx){
 var a=0,n=idx.length,i,P=QP.p;
 for(i=0;i<n;i++){var A=P[idx[i]],B=P[idx[(i+1)%n]];a+=A.x*B.y-B.x*A.y;}
 return a/2;
}
function solveC(c){
 var P=QP.p,i;
 if(c.t===0){
  var A=P[c.a],B=P[c.b],dx=B.x-A.x,dy=B.y-A.y,d=Math.sqrt(dx*dx+dy*dy);
  if(d<1e-6)return;
  var diff=(d-c.r)/d*c.k*.5,mA=A.pin?0:(B.pin?1:.5),mB=B.pin?0:(A.pin?1:.5);
  A.x+=dx*diff*2*mA;A.y+=dy*diff*2*mA;
  B.x-=dx*diff*2*mB;B.y-=dy*diff*2*mB;
 }else{
  /* préservation d'aire : chaque sommet est poussé le long de sa bissectrice */
  var idx=c.i,n=idx.length,cur=polyArea(idx),err=(c.r-cur);
  if(Math.abs(err)<.01)return;
  var per=0;
  for(i=0;i<n;i++){var A2=P[idx[i]],B2=P[idx[(i+1)%n]];per+=Math.hypot(B2.x-A2.x,B2.y-A2.y);}
  if(per<1e-6)return;
  var off=err/per*c.k;
  for(i=0;i<n;i++){
   var pv=P[idx[(i-1+n)%n]],cu=P[idx[i]],nx2=P[idx[(i+1)%n]];
   var ex=nx2.x-pv.x,ey=nx2.y-pv.y,el=Math.hypot(ex,ey);
   if(el<1e-6)continue;
   cu.x+=(ey/el)*off;cu.y+=(-ex/el)*off;
  }
 }
}
function qpField(p,sub){
 var lv=L(),i,gx=0,gy=G;
 if(lv.grav)for(i=0;i<lv.grav.length;i++){
  var z=lv.grav[i];
  if(p.x>z[0]&&p.x<z[0]+z[2]&&p.y>z[1]&&p.y<z[1]+z[3]){gy=z[5];gx+=z[4];}}
 if(lv.wind)for(i=0;i<lv.wind.length;i++){
  var w=lv.wind[i];
  if(p.x>w[0]&&p.x<w[0]+w[2]&&p.y>w[1]&&p.y<w[1]+w[3]){gx+=w[4];gy+=w[5];}}
 if(lv.mag)for(i=0;i<lv.mag.length;i++){
  var m=lv.mag[i],dx=m[0]-p.x,dy=m[1]-p.y,d=Math.hypot(dx,dy);
  if(d<m[2]&&d>7){var k=magF(m,d);gx+=dx/d*k;gy+=dy/d*k;}}
 return [gx/sub,gy/sub];
}
/* force de l'aimant (R49, retour Simon : « l'aimant n'a presque aucune incidence ») : 1,7 fois plus forte,
   profil (1 − (d/r)²) qui reste fort jusqu'à mi-rayon au lieu de s'effondrer linéairement */
var MAGK=1.7;
function magF(m,d){var u=d/m[2];return m[3]*MAGK*(1-u*u);}
function staticSegs(){
 var lv=L(),a=lv.walls.slice(),i,k,st;
 if(lv.mov)for(i=0;i<lv.mov.length;i++)a.push(moverSeg(lv.mov[i]));
 for(i=0;i<S.strokes.length;i++){
  if(S.strokes[i].mat===ROPE)continue;
  st=S.strokes[i].pts;
  for(k=1;k<st.length;k++)a.push([st[k-1][0],st[k-1][1],st[k][0],st[k][1],S.strokes[i].mat,1]);}
 return a;
}
function qpCollide(){
 var segs=staticSegs(),P=QP.p,i,j,pr=QP.pr;
 for(i=0;i<P.length;i++){
  var p=P[i];if(p.pin)continue;
  for(j=0;j<segs.length;j++){
   var s=segs[j],th=s[5]?3.2:4;
   var dx=s[2]-s[0],dy=s[3]-s[1],l2=dx*dx+dy*dy,t=0;
   if(l2>0){t=((p.x-s[0])*dx+(p.y-s[1])*dy)/l2;t=t<0?0:t>1?1:t;}
   var cx=s[0]+t*dx,cy=s[1]+t*dy,nx=p.x-cx,ny=p.y-cy,d=Math.sqrt(nx*nx+ny*ny),lim=pr+th;
   if(d>=lim||d<1e-6)continue;
   if(s[4]===SPIKE&&QP.soft&&i>=QP.soft.i0){BUS.emit('ball.fail',{x:p.x,y:p.y,reason:'spike'});return;}
   nx/=d;ny/=d;
   p.x+=nx*(lim-d);p.y+=ny*(lim-d);
   var vx=p.x-p.px,vy=p.y-p.py,vn=vx*nx+vy*ny;
   if(vn<0){
    var e=s[4]===BOUNCEM?1.2:(s[4]===ICEM?.05:.22);
    var tx=-ny,ty=nx,vt=(vx*tx+vy*ty)*(s[4]===ICEM?1:.86);
    vx=nx*(-vn*e)+tx*vt;vy=ny*(-vn*e)+ty*vt;
    p.px=p.x-vx;p.py=p.y-vy;
   }
  }
 }
}
function qpDrive(tt){   /* R146 : corde entraînée (expérience de Melde, plateau vibrant) — les ancrages oscillent perpendiculairement à la corde */
 for(var r=0;r<QP.ropes.length;r++){var R0=QP.ropes[r],d=R0.drv;if(!d)continue;
  var nl=Math.hypot(d.ax,d.ay)||1,q=tt*d.spd+d.ph,o=Math.sin(q)*d.amp,dv=Math.cos(q)*d.amp*d.spd;
  if(d.wv){var u=((q/6.2832)%1+1)%1,k=d.wv;if(u<k){o=d.amp*u/k;dv=d.amp*d.spd/6.2832/k;}else{o=d.amp*(1-(u-k)/(1-k));dv=-d.amp*d.spd/6.2832/(1-k);}R0.u=u;}   /* fronde : tension lente (fraction wv du cycle), détente brusque */
  var ox=d.ax/nl*o,oy=d.ay/nl*o,a=QP.p[R0.i0],b=QP.p[R0.i1];R0.dv=[d.ax/nl*dv,d.ay/nl*dv];
  if(d.end!==2){a.px=a.x;a.py=a.y;a.x=d.A[0]+ox;a.y=d.A[1]+oy;}
  if(d.end!==1){b.px=b.x;b.py=b.y;b.x=d.B[0]+ox;b.y=d.B[1]+oy;}}
}
function qpStep(sub){
 var i,j,p;
 if(!QP.p.length)return;
 S.qk=(S.qk||0)+1;qpDrive(S.qk/sub);
 for(i=0;i<QP.p.length;i++){
  p=QP.p[i];if(p.pin)continue;
  var vx=(p.x-p.px)*QP.damp,vy=(p.y-p.py)*QP.damp;
  p.px=p.x;p.py=p.y;
  var f=qpField(p,sub);
  p.x+=vx+f[0];p.y+=vy+f[1];
 }
 for(j=0;j<QP.iter;j++)for(i=0;i<QP.c.length;i++)solveC(QP.c[i]);
 qpCollide();
}
/* construction : les cordes tracées et, si le niveau l'exige, la balle molle */
function qpBuild(){
 QP.clear();
 var i,k,lv=L();
 QP.iter=lv.ropeIter||3;QP.damp=lv.ropeDamp||.994;   /* R162 : raideur et amortissement des cordes réglables par niveau (trampoline) */
 for(i=0;i<S.strokes.length;i++){
  var st=S.strokes[i];
  if(st.mat!==ROPE)continue;
  var pts=resample(st.pts,13);
  if(pts.length<3)continue;
  var i0=QP.p.length;
  for(k=0;k<pts.length;k++)QP.add(pts[k][0],pts[k][1],k===0||k===pts.length-1);
  for(k=1;k<pts.length;k++)QP.link(i0+k-1,i0+k,1);
  for(k=2;k<pts.length;k++)QP.link(i0+k-2,i0+k,.28);
  var sl=lv.sling,inZ=function(q){return sl&&q[0]>=sl.z[0]&&q[0]<=sl.z[0]+sl.z[2]&&q[1]>=sl.z[1]&&q[1]<=sl.z[1]+sl.z[3];};
  QP.ropes.push({i0:i0,i1:QP.p.length-1,drv:(inZ(pts[0])&&inZ(pts[pts.length-1]))?{amp:sl.amp,spd:sl.spd,ph:sl.ph||0,end:0,wv:sl.wv||0,ax:sl.d[0],ay:sl.d[1],A:pts[0].slice(),B:pts[pts.length-1].slice()}:null});   /* R146 : élastique tendu entre les branches de la fronde — il suit leur mouvement */
 }
 if(lv.strings)for(i=0;i<lv.strings.length;i++){   /* R145 : cordes tendues du décor (harpe) — mêmes lois que la corde du joueur, ancrées aux deux bouts */
  var sg=lv.strings[i],sp2=resample([[sg[0],sg[1]],[sg[2],sg[3]]],12),j0=QP.p.length;
  for(k=0;k<sp2.length;k++)QP.add(sp2[k][0],sp2[k][1],k===0||k===sp2.length-1);
  for(k=1;k<sp2.length;k++)QP.link(j0+k-1,j0+k,1);
  for(k=2;k<sp2.length;k++)QP.link(j0+k-2,j0+k,.28);
  QP.ropes.push({i0:j0,i1:QP.p.length-1,str:1,drv:sg[4]?{amp:sg[4],spd:sg[5]||.2,ph:sg[6]||0,end:sg[7]||0,wv:sg[8]||0,ax:sg[9]!=null?sg[9]:sg[1]-sg[3],ay:sg[9]!=null?sg[10]:sg[2]-sg[0],A:[sg[0],sg[1]],B:[sg[2],sg[3]]}:null});
 }
 S.qk=0;S.coilOn={};S.kickOn={};S.recAt={};S.recOn={};
 var useShape=!!(S.zen&&S.useShape&&SHAPE&&SHAPE.length>=6);
 if(lv.softball||useShape){
  var n=useShape?SHAPE.length:10,rad=12.5,i0b=QP.p.length,idx=[],hn=Math.floor(n/2);
  for(k=0;k<n;k++){
   var ox,oy;
   if(useShape){ox=SHAPE[k][0]*rad;oy=SHAPE[k][1]*rad;}
   else{var a=k/n*Math.PI*2;ox=Math.cos(a)*rad;oy=Math.sin(a)*rad;}
   idx.push(QP.add(lv.ball[0]+ox,lv.ball[1]+oy,false));}
  for(k=0;k<n;k++)QP.link(idx[k],idx[(k+1)%n],.9);
  var sk=(typeof lv.softball==='number')?lv.softball:1;   /* R158 : souplesse réglable par niveau (1 = d'origine) — liens de flexion, diagonaux et aire */
  for(k=0;k<n;k++)QP.link(idx[k],idx[(k+2)%n],.45*sk);
  for(k=0;k<hn;k++)QP.link(idx[k],idx[(k+hn)%n],.30*sk);
  QP.area(idx,.8*sk);
  QP.soft={i0:i0b,idx:idx};
 }
}
function resample(pts,step){
 var out=[pts[0]],acc=0,i;
 for(i=1;i<pts.length;i++){
  var ax=pts[i-1][0],ay=pts[i-1][1],bx=pts[i][0],by=pts[i][1];
  var d=Math.hypot(bx-ax,by-ay);
  if(d<1e-6)continue;
  var pos=0;
  while(acc+d-pos>=step){
   pos+=step-acc;acc=0;
   out.push([ax+(bx-ax)*pos/d,ay+(by-ay)*pos/d]);
   if(out.length>30)return out;
  }
  acc+=d-pos;
 }
 out.push(pts[pts.length-1]);
 return out;
}
function softCentroid(){
 var s=QP.soft,i,x=0,y=0;
 for(i=0;i<s.idx.length;i++){x+=QP.p[s.idx[i]].x;y+=QP.p[s.idx[i]].y;}
 return [x/s.idx.length,y/s.idx.length];
}
/* état complet pour la reprise temporelle */
function qpSave(){
 var a=[],i,p;
 for(i=0;i<QP.p.length;i++){p=QP.p[i];a.push(p.x,p.y,p.px,p.py);}
 return a;
}
function qpLoad(a){
 var i,p;
 if(!a||a.length!==QP.p.length*4)return;
 for(i=0;i<QP.p.length;i++){p=QP.p[i];
  p.x=a[i*4];p.y=a[i*4+1];p.px=a[i*4+2];p.py=a[i*4+3];}
}


var boostCd=0,portCd=0;
function collide(b){
 var a=allSegs(),i;
 for(i=0;i<a.length;i++){
  var s=a[i],th=s[5]?3.2:4;
  var dx=s[2]-s[0],dy=s[3]-s[1],l2=dx*dx+dy*dy,p=0;
  if(l2>0){p=((b.x-s[0])*dx+(b.y-s[1])*dy)/l2;p=p<0?0:p>1?1:p;}
  var cx=s[0]+p*dx,cy=s[1]+p*dy,nx=b.x-cx,ny=b.y-cy;
  var d=Math.sqrt(nx*nx+ny*ny),lim=R+th;
  if(d>=lim)continue;
  if(s[4]===SPIKE){b.dead='spike';return;}
  if(d<1e-4){nx=0;ny=-1;d=1;}
  nx/=d;ny/=d;
  if(s[6]&&l2>0&&Math.abs(b.vx*dy-b.vy*dx)/Math.sqrt(l2)>s[6]){if(S.t>(S.tunCd||0)){S.tunCd=S.t+8;BUS.emit('ball.tunnel',{x:b.x,y:b.y});}continue;}   /* R129 : piste traversable quand la balle la coupe vite (croisement d'un looping) — normale du segment, pas du point le plus proche */
  b.x+=nx*(lim-d);b.y+=ny*(lim-d);
  var mvx=s[7]||0,mvy=s[8]||0;if(mvx||mvy){b.vx-=mvx;b.vy-=mvy;}
  var vn=b.vx*nx+b.vy*ny;
  if(vn<0){
   var ph=matPhys(s[4]),e=ph[0],f=ph[1];
   b.vx-=(1+e)*vn*nx;b.vy-=(1+e)*vn*ny;
   var tx=-ny,ty=nx,vt=(b.vx*tx+b.vy*ty)*f;if(s[9])vt*=1-s[9];   /* R162 : adhérence d'une pièce mobile — la balle suit la plateforme */
   var nv=b.vx*nx+b.vy*ny;
   if(s[4]===ICEM&&s[5]&&!s[6]&&-vn<Math.max(1.2,.34*Math.sqrt((b.vx+(1+e)*vn*nx)*(b.vx+(1+e)*vn*nx)+(b.vy+(1+e)*vn*ny)*(b.vy+(1+e)*vn*ny)))){var sp0=Math.sqrt((b.vx+(1+e)*vn*nx)*(b.vx+(1+e)*vn*nx)+(b.vy+(1+e)*vn*ny)*(b.vy+(1+e)*vn*ny)),vt0=b.vx*tx+b.vy*ty;   /* R162 : glissade sur une courbe de glace — vitesse seulement réorientée, sans perte (les jonctions entre segments ne freinent plus) */
    nv=0;vt=vt0>=0?sp0:-sp0;}
   b.vx=nx*nv+tx*vt;b.vy=ny*nv+ty*vt;
   b.a+=vt/R*.28;
   if(-vn>.9)BUS.emit(s[4]===BOUNCEM?'ball.bounce':'ball.impact',{x:cx,y:cy,nx:nx,ny:ny,v:-vn,mat:s[4]});
  }
  if(mvx||mvy){b.vx+=mvx;b.vy+=mvy;}
  if(s[4]===BOOSTM){
   var bl=Math.sqrt(l2)||1,ux=dx/bl,uy=dy/bl,al=b.vx*ux+b.vy*uy;
   if(s[10]===undefined){   /* ruban ordinaire : pousse tant que la balle va moins vite que 7,2 le long du ruban */
    if(al<7.2){b.vx+=ux*BOOSTF;b.vy+=uy*BOOSTF;
     if(S.t>boostCd){boostCd=S.t+22;BUS.emit('ball.boost',{x:b.x,y:b.y,ux:ux,uy:uy});}}
   }else{   /* R299 · ruban réglé (niveau seulement) : tend vers la vitesse cible s[10] — accélère en dessous, FREINE au-dessus (0 = frein) */
    var dv=s[10]-al,kk;
    if(dv>0){kk=dv<BOOSTF?dv:BOOSTF;b.vx+=ux*kk;b.vy+=uy*kk;if(kk>.2&&S.t>boostCd){boostCd=S.t+22;BUS.emit('ball.boost',{x:b.x,y:b.y,ux:ux,uy:uy});}}
    else if(dv<0){kk=-dv<BOOSTF?-dv:BOOSTF;b.vx-=ux*kk;b.vy-=uy*kk;}
   }
  }
 }
}

function fields(b,sub){
 var lv=L(),i,g=G,any=false;
 if(lv.grav)for(i=0;i<lv.grav.length;i++){
  var z=lv.grav[i];
  if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3]){g=z[5];b.vx+=z[4]/sub;any=true;}
 }
 if(lv.bf)for(i=0;i<lv.bf.length;i++){   /* R143 : champ magnétique uniforme (force de Lorentz) — la vitesse tourne sans changer de valeur ; bz[5]=1 : vide, sans pesanteur */
  var bz=lv.bf[i];
  if(b.x>bz[0]&&b.x<bz[0]+bz[2]&&b.y>bz[1]&&b.y<bz[1]+bz[3]){if(bz[5])g=0;var ba=bz[4]/sub,bc=Math.cos(ba),bs=Math.sin(ba),bvx=b.vx;b.vx=bvx*bc-b.vy*bs;b.vy=bvx*bs+b.vy*bc;any=true;}
 }
 if(lv.kick)for(i=0;i<lv.kick.length;i++){   /* R143 : fente accélératrice (cyclotron) — pousse la particule dans le sens de sa course ; vide, sans pesanteur */
  var kz=lv.kick[i];
  if(b.x>kz[0]&&b.x<kz[0]+kz[2]&&b.y>kz[1]&&b.y<kz[1]+kz[3]){g=0;var ks=Math.hypot(b.vx,b.vy)||1;if(ks<(kz[5]||14)){b.vx+=b.vx/ks*kz[4]/sub;b.vy+=b.vy/ks*kz[4]/sub;}(S.kickOn=S.kickOn||{})[i]=S.t;any=true;}
 }
 if(lv.coil)for(i=0;i<lv.coil.length;i++){   /* R147 : bobine de canon de Gauss — tire la particule vers son centre le long de l'axe, et la recentre ; coupée dès qu'elle est passée */
  var co=lv.coil[i],cn=Math.hypot(co[2],co[3])||1,cax=co[2]/cn,cay=co[3]/cn,rx=b.x-co[0],ry=b.y-co[1],al=rx*cax+ry*cay,lx=rx-al*cax,ly=ry-al*cay,ll=Math.hypot(lx,ly);
  if(al<0&&al>-co[4]&&ll<16){var cf=co[5]*(1+al/co[4]*.5)/sub;b.vx+=cax*cf-lx*.04/sub;b.vy+=cay*cf-ly*.04/sub;if(co[6])g=0;S.coilOn=S.coilOn||{};S.coilOn[i]=S.t;any=true;}
 }
 b.vy+=g*S.gmul/sub;
 if(lv.well)for(i=0;i<lv.well.length;i++){   /* R142 : puits de gravité (masse ponctuelle) — accélération m/d², adoucie au cœur */
  var wl=lv.well[i],wx=wl[0]-b.x,wy=wl[1]-b.y,wd2=Math.max(wx*wx+wy*wy,wl[3]*wl[3]),wd=Math.sqrt(wd2),wa=wl[2]/wd2;
  b.vx+=wx/wd*wa/sub;b.vy+=wy/wd*wa/sub;any=true;}
 if(lv.wind)for(i=0;i<lv.wind.length;i++){
  var w=lv.wind[i];
  if(b.x>w[0]&&b.x<w[0]+w[2]&&b.y>w[1]&&b.y<w[1]+w[3]){b.vx+=w[4]/sub;b.vy+=w[5]/sub;}
 }
 if(lv.mag)for(i=0;i<lv.mag.length;i++){
  var m=lv.mag[i],ddx=m[0]-b.x,ddy=m[1]-b.y,dd=Math.hypot(ddx,ddy);
  if(dd<m[2]&&dd>7){var k=magF(m,dd)/sub;b.vx+=ddx/dd*k;b.vy+=ddy/dd*k;}
 }
 if(lv.port&&S.t>portCd)for(i=0;i<lv.port.length;i++){
  var pp=lv.port[i];
  if(Math.hypot(b.x-pp[0],b.y-pp[1])<16){
   b.x=pp[2];b.y=pp[3];portCd=S.t+14;
   if(pp[5]){var pa=pp[4]*Math.PI/180,pv=Math.hypot(b.vx,b.vy);b.vx=pv*Math.cos(pa);b.vy=pv*Math.sin(pa);}   /* R144 : faille orientée — ce qui entre vite ressort vite, dans l'axe de la sortie (angle pp[4]) */
   else if(pp[4]){var pa2=pp[4]*Math.PI/180,pc=Math.cos(pa2),ps=Math.sin(pa2),pvx=b.vx;b.vx=pvx*pc-b.vy*ps;b.vy=pvx*ps+b.vy*pc;}
   BUS.emit('ball.portal',{x:pp[0],y:pp[1],tx:pp[2],ty:pp[3]});
  }
 }
 return any;
}

/* ══ SYSTÈME QUANTIQUE ══
   intrication : deux noyaux partagent un état. Toucher l'un bascule la paire,
   et les portes liées s'ouvrent ou se ferment ensemble ou en opposition.
   superposition : la particule se dédouble en deux branches simultanées.
   mesure : un détecteur effondre la superposition sur la branche mesurée. */
function quantum(b,sub){
 var lv=L(),i;
 /* R317 : fin d'une ouverture limitée (ent[6] = durée en images) */
 if(lv.ent)for(i=0;i<lv.ent.length;i++){var e0=lv.ent[i],s0=S.ent[i];if(e0[6]>0&&s0.on&&s0.off&&S.t>=s0.off){s0.on=false;s0.off=0;s0.pulse=1;s0.xf=S.tick||0;BUS.emit('quantum.entangle',{ax:e0[0],ay:e0[1],bx:e0[2],by:e0[3],from:-1,on:false});}}
 if(lv.ent)for(i=0;i<lv.ent.length;i++){
  var e=lv.ent[i],st=S.ent[i];
  var da=Math.hypot(b.x-e[0],b.y-e[1]),db=Math.hypot(b.x-e[2],b.y-e[3]);
  var near=(da<20)?0:((db<20)?1:-1);
  if(near>=0&&S.t>st.cd){
   st.cd=S.t+18;
   st.on=(e[4]==='same')?!st.on:!st.on;
   if(e[6]>0&&st.on){st.off=S.t+e[6];st.on0=S.t;}else st.off=0;st.tg=S.tick||0;
   st.pulse=1;st.from=near;
   BUS.emit('quantum.entangle',{ax:e[0],ay:e[1],bx:e[2],by:e[3],from:near,on:st.on});
  }
 }
 if(lv.sup&&!S.branch&&!S.collapsed)for(i=0;i<lv.sup.length;i++){
  var z=lv.sup[i];
  if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3]){
   var ang=(z[4]===undefined?0.42:z[4]);
   var c=Math.cos(ang),si=Math.sin(ang);
   S.branch={x:b.x,y:b.y,a:b.a,
    vx:b.vx*c-b.vy*si, vy:b.vx*si+b.vy*c};
   var ox=b.vx,oy=b.vy;
   b.vx=ox*c+oy*si; b.vy=-ox*si+oy*c;
   S.superposed=true;
   BUS.emit('quantum.superposition',{x:b.x,y:b.y});
   break;
  }
 }
 if(lv.rec&&S.branch)for(i=0;i<lv.rec.length;i++){   /* R243 : recombineur rec=[x,y,rayon,angle de sortie (degrés),(fenêtre)] — les deux copies qui le traversent presque ensemble fusionnent et sortent par la voie constructive ; une copie seule le traverse sans effet */
  var rc=lv.rec[i];
  if(Math.hypot(b.x-rc[0],b.y-rc[1])<rc[2]){
   var ra=S.recAt[i]||(S.recAt[i]={}),who=(b===S.branch)?1:0;ra[who]=S.t;
   if(ra[1-who]!=null&&S.t-ra[1-who]<=(rc[4]||14)){
    var o2=(b===S.branch)?S.ball:S.branch,rs=rc[5]||(Math.hypot(b.vx,b.vy)+Math.hypot(o2.vx,o2.vy))/2,raa=rc[3]*Math.PI/180;
    S.ball=b;b.x=rc[0];b.y=rc[1];b.vx=Math.cos(raa)*rs;b.vy=Math.sin(raa)*rs;
    S.branch=null;S.superposed=false;S.collapsed=true;S.recOn[i]=S.t;
    BUS.emit('quantum.recombine',{x:rc[0],y:rc[1]});
    return;}
  }
 }
 if(lv.det&&S.branch)for(i=0;i<lv.det.length;i++){
  var d=lv.det[i];
  if(Math.hypot(b.x-d[0],b.y-d[1])<d[2]){
   if(b===S.branch)S.ball=S.branch;   /* R156 : la particule MESURÉE devient la réelle (avant, c'était toujours la principale) */
   S.branch=null;S.superposed=false;S.collapsed=true;d._lk=S.t;   /* R317 : verrouillage du radar de mesure */
   if(d[3]!=null&&S.ent[d[3]]){var se=S.ent[d[3]],e3=lv.ent[d[3]];se.on=!se.on;if(e3[6]>0&&se.on){se.off=S.t+e3[6];se.on0=S.t;}else se.off=0;se.tg=S.tick||0;se.pulse=1;se.cd=S.t+18;BUS.emit('quantum.entangle',{ax:e3[0],ay:e3[1],bx:e3[2],by:e3[3],from:0,on:se.on});}   /* R156 : la mesure bascule une paire intriquée (det[3] = rang de la paire) */
   BUS.emit('quantum.measure',{x:d[0],y:d[1],bx:b.x,by:b.y});
   break;
  }
 }
}
function timeScaleAt(b){
 var lv=L(),i;
 if(lv.tdil)for(i=0;i<lv.tdil.length;i++){
  var z=lv.tdil[i];
  if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3])return z[4]||.45;
 }
 return 1;
}
/* intègre une branche : champs, déplacement, collisions */
function stepBranch(b,sub){
 var ts=timeScaleAt(b);
 fields(b,sub/ts);
 b.x+=b.vx/sub*ts;b.y+=b.vy/sub*ts;
 {var lw=L().wrap;if(lw&&b.y>lw[0]&&b.y<lw[1]){if(b.x<0){b.x+=360;BUS.emit('ball.wrap',{y:b.y});}else if(b.x>360){b.x-=360;BUS.emit('ball.wrap',{y:b.y});}}}   /* R144 : espace torique — les bords gauche et droit sont recousus */
 var sp=Math.sqrt(b.vx*b.vx+b.vy*b.vy);
 if(sp>VMAX){b.vx*=VMAX/sp;b.vy*=VMAX/sp;}
 collide(b);
 if(QP.ropes.length)collideRopes(b);
 pendHit(b);
 quantum(b,sub);
}
/* R161 : PENDULE ACTIF — pend=[px,py,L,spd,amp,ph,actif,rayon,restitution] ; la masse suit exactement le dessin
   (θ = amp·sin(t·spd+ph)) et frappe la particule en lui transmettant sa propre vitesse. pend[6] absent = simple décor. */
function pendHit(b){
 var P=L().pend;if(!P)return;var A=Array.isArray(P[0])?P:[P],i;
 for(i=0;i<A.length;i++){var p=A[i];if(!p[6])continue;
  var q=S.t*p[3]+(p[5]||0),th=p[4]*Math.sin(q),px=p[0]+Math.sin(th)*p[2],py=p[1]+Math.cos(th)*p[2],
   w=p[4]*p[3]*Math.cos(q),pvx=p[2]*w*Math.cos(th),pvy=-p[2]*w*Math.sin(th),rb=p[7]||12,
   dx=b.x-px,dy=b.y-py,d=Math.sqrt(dx*dx+dy*dy),lim=R+rb;
  if(d>=lim||d<1e-6)continue;
  var nx=dx/d,ny=dy/d;b.x=px+nx*lim;b.y=py+ny*lim;
  var vn=(b.vx-pvx)*nx+(b.vy-pvy)*ny;
  if(vn<0){var e=p[8]!=null?p[8]:.85;b.vx-=(1+e)*vn*nx;b.vy-=(1+e)*vn*ny;if(-vn>.9)BUS.emit('ball.impact',{x:px+nx*rb,y:py+ny*rb,nx:nx,ny:ny,v:-vn,mat:SOLID});}}
}
/* ══ RAIL GUIDÉ (R80) — CAHIER_DES_CHARGES_GENERATION §3.4 ══
   lv.rails = [{in:[x,y], r:rayon de capture, pts:[[x,y]…], v:[départ, milieu, fin], out:[vx,vy]}]
   Le relais (in) capte la particule ; elle suit une courbe lissée à vitesse imposée (déterministe : la sortie ne dépend
   jamais de l'entrée), puis le lanceur la rend à la physique avec la vitesse « out ». On ne peut rien tracer près du rail. */
function drawRails(c,lv){
 var t=S.t||0,on=S.ball&&S.ball.rail,acc=T.matter;
 lv._rb.forEach(function(rb,k){var P=rb.pts,i;c.save();c.lineCap=c.lineJoin='round';
  /* le rail : un tube de lumière, plus vif là où la particule est déjà passée */
  if(rb.r.look&&window.VX&&VX.curve){VX.curve(c,P,0,{noHang:1});   /* R148 : looping d'une machine — même langue que les courbes, sans relais doré */
   if(on&&S.ball.rail.k===k){var s0=S.ball.rail.s;c.globalCompositeOperation='lighter';c.strokeStyle='#EAFBFF';c.lineWidth=3;c.globalAlpha=.7;c.beginPath();
    for(i=0;i<P.length&&rb.cum[i]<=s0;i++){if(i)c.lineTo(P[i][0],P[i][1]);else c.moveTo(P[i][0],P[i][1]);}c.stroke();}
   c.restore();return;}
  c.strokeStyle='rgba(5,9,15,.75)';c.lineWidth=11;c.beginPath();c.moveTo(P[0][0],P[0][1]);for(i=1;i<P.length;i++)c.lineTo(P[i][0],P[i][1]);c.stroke();
  c.strokeStyle=acc;c.globalAlpha=.35;c.lineWidth=7;c.stroke();c.globalAlpha=.9;c.lineWidth=1.6;c.stroke();
  if(on&&S.ball.rail.k===k){var s=S.ball.rail.s;c.globalCompositeOperation='lighter';c.strokeStyle='#EAFBFF';c.lineWidth=3;c.globalAlpha=.8;c.beginPath();
   for(i=0;i<P.length&&rb.cum[i]<=s;i++){if(i)c.lineTo(P[i][0],P[i][1]);else c.moveTo(P[i][0],P[i][1]);}c.stroke();c.globalCompositeOperation='source-over';}
  /* traverses régulières (le rail est un objet, pas un trait) */
  c.globalAlpha=.5;c.strokeStyle=acc;c.lineWidth=1;for(i=6;i<P.length-1;i+=8){var dx=P[i+1][0]-P[i][0],dy=P[i+1][1]-P[i][1],l=Math.hypot(dx,dy)||1,nx=-dy/l*7,ny=dx/l*7;
   c.beginPath();c.moveTo(P[i][0]-nx,P[i][1]-ny);c.lineTo(P[i][0]+nx,P[i][1]+ny);c.stroke();}
  /* le relais : un entonnoir doré qui respire — distinct de la zone d'arrivée */
  var r=rb.r,pul=.5+.5*Math.sin(t*.08),rr=(r.r||16);c.globalAlpha=1;
  var g=c.createRadialGradient(r.in[0],r.in[1],0,r.in[0],r.in[1],rr*1.8);g.addColorStop(0,'rgba(255,216,90,.35)');g.addColorStop(1,'rgba(255,216,90,0)');
  c.fillStyle=g;c.beginPath();c.arc(r.in[0],r.in[1],rr*1.8,0,6.2832);c.fill();
  c.strokeStyle='#FFD85A';c.lineWidth=2;c.setLineDash([5,4]);c.lineDashOffset=-t*.4;c.beginPath();c.arc(r.in[0],r.in[1],rr+2*pul,0,6.2832);c.stroke();c.setLineDash([]);
  c.restore();});}
/* ══ ÉLÉMENTS COURBES (R82) ══ lv.curves = [{pts:[[x,y]…], m:matière}] : une courbe lissée (Catmull‑Rom) devient, pour la
   physique, une suite de segments courts jointifs ; pour l'œil, une seule pièce continue (VX.curve). */
function curveSample(P,step){var o=[],i,t;if(P.length<3)return P.map(function(p){return p.slice();});
 for(i=0;i<P.length-1;i++){var p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)],n=Math.max(2,Math.round(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/(step||9)));
  for(var j=0;j<n;j++){t=j/n;var t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
   .5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]);}}
 o.push(P[P.length-1].slice());return o;}
function curveExpand(lv){
 if(!lv.curves||lv._cv)return;lv._cv=[];
 for(var k=0;k<lv.curves.length;k++){var cv=lv.curves[k],S2=curveSample(cv.pts,cv.st||9);lv._cv.push({pts:S2,m:cv.m||0,pass:cv.pass||0,pz:cv.pz||null,v:cv.v});
  for(var i=1;i<S2.length;i++)lv.walls.push([S2[i-1][0],S2[i-1][1],S2[i][0],S2[i][1],cv.m||0,1,(cv.pass&&(!cv.pz||(Math.abs((S2[i-1][0]+S2[i][0])/2-cv.pz[0])<cv.pz[2]&&Math.abs((S2[i-1][1]+S2[i][1])/2-cv.pz[1])<cv.pz[3])))?cv.pass:0].concat(cv.v!==undefined?[0,0,0,cv.v]:[]));}}   /* R129 : cv.pass = seuil de traversée (looping) ; cv.pz = [cx,cy,demi-largeur,demi-hauteur] : zone où la courbe est traversable */
function railBuild(lv){
 lv._rb=(lv.rails||[]).map(function(r){var P=r.pts,o=[],i,t;
  for(i=0;i<P.length-1;i++){var p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)];
   for(t=0;t<1;t+=1/12){var t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
    .5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]);}}
  o.push(P[P.length-1].slice());var cum=[0];for(i=1;i<o.length;i++)cum.push(cum[i-1]+Math.hypot(o[i][0]-o[i-1][0],o[i][1]-o[i-1][1]));
  return {r:r,pts:o,cum:cum,L:cum[cum.length-1]};});
 if(!lv.nd)lv.nd=[];lv.nd._rail=lv._rb;}
function railAt(rb,s){var c=rb.cum,i=1;while(i<c.length-1&&c[i]<s)i++;var u=(s-c[i-1])/Math.max(1e-6,c[i]-c[i-1]),a=rb.pts[i-1],b2=rb.pts[i];return [a[0]+(b2[0]-a[0])*u,a[1]+(b2[1]-a[1])*u];}
function railStep(b,lv){
 var rb=lv._rb[b.rail.k],v=rb.r.v||[3,5,4],u=b.rail.s/rb.L,sp=u<.5?v[0]+(v[1]-v[0])*u*2:v[1]+(v[2]-v[1])*(u-.5)*2;
 var p0=railAt(rb,b.rail.s);b.rail.s=Math.min(rb.L,b.rail.s+sp);var p=railAt(rb,b.rail.s);
 b.vx=p[0]-p0[0];b.vy=p[1]-p0[1];b.x=p[0];b.y=p[1];b.a+=b.vx/R*.12;
 if(b.rail.s>=rb.L){var o=rb.r.out||[b.vx,b.vy];b.vx=o[0];b.vy=o[1];b.rail=null;b.railCool=24;BUS.emit('rail.exit',{x:b.x,y:b.y});}}
function railCatch(b,lv){
 if(b.railCool>0){b.railCool--;return;}
 for(var k=0;k<lv._rb.length;k++){var r=lv._rb[k].r;if(Math.hypot(b.x-r.in[0],b.y-r.in[1])<(r.r||16)&&(!r.vmin||Math.hypot(b.vx,b.vy)>=r.vmin)){b.rail={k:k,s:0};BUS.emit('rail.enter',{x:b.x,y:b.y});return;}}}
function physics(){
 if(S.mode!=='run')return;
 S.t++;S.frames++;
 if(S.late&&S.late.length){for(var li=0;li<S.late.length;li++){if(S.late[li].at===S.frames){S.late[li].st.birth=S.tick;S.strokes.push(S.late[li].st);qpBuild();}}}
 if(S.frames>=S.longAt&&!S.demo&&!S.zen){BUS.emit('ball.fail',{x:S.ball.x,y:S.ball.y,reason:'long'});return;}
 var lv=L(),b=S.ball,k,i;
 var soft=!!QP.soft;
 if(lv.rails&&!lv._rb)railBuild(lv);
 if(lv._rb&&!soft){if(b.rail){S.t++;railStep(b,lv);S.rec.push([b.x,b.y,b.vx,b.vy,b.a,S.gotStar?1:0,null]);return;}railCatch(b,lv);if(b.rail)return;}
 var prev=soft?softCentroid():null;
 for(k=0;k<5;k++){
  qpStep(5);
  if(S.mode!=='run')return;
  if(!soft){
   stepBranch(b,5);
   if(S.branch)stepBranch(S.branch,5);
   b=S.ball;
  }
 }
 if(soft){
  var c=softCentroid();
  b.vx=c[0]-prev[0];b.vy=c[1]-prev[1];b.x=c[0];b.y=c[1];b.a+=b.vx/R*.12;
 }else b.a+=b.vx/R*.12;
 if(S.branch)S.branch.a+=S.branch.vx/R*.12;

 /* une branche morte disparaît ; l'expérience ne tombe que si tout est mort */
 var outOf=function(p){return p.dead||p.y>H+70||p.x<-90||p.x>W+90;};
 if(S.branch&&outOf(S.branch)){
  BUS.emit('quantum.collapse',{x:S.branch.x,y:S.branch.y});
  S.branch=null;S.superposed=false;S.collapsed=true;
 }
 if(outOf(b)){
  if(S.branch){
   BUS.emit('quantum.collapse',{x:b.x,y:b.y});
   S.ball=S.branch;b=S.ball;S.branch=null;S.superposed=false;S.collapsed=true;
  }else{
   BUS.emit('ball.fail',{x:b.x,y:b.y,reason:b.dead==='spike'?'spike':'out'});
   return;
  }
 }

 S.rec.push([b.x,b.y,b.vx,b.vy,b.a,S.gotStar?1:0,QP.p.length?qpSave():null,
             S.branch?[S.branch.x,S.branch.y,S.branch.vx,S.branch.vy,S.branch.a]:null,
             S.ent.map(function(e){return e.on?1:0;})]);
 S.trail.push([b.x,b.y,Math.sqrt(b.vx*b.vx+b.vy*b.vy)]);
 if(S.trail.length>22)S.trail.shift();
 if(S.branch){S.gtrail.push([S.branch.x,S.branch.y]);if(S.gtrail.length>18)S.gtrail.shift();}
 else S.gtrail=[];
 if(S.frames%3===0)S.pathRec.push([b.x,b.y]);

 if(lv.star&&!S.gotStar){
  var branches=S.branch?[b,S.branch]:[b];
  for(i=0;i<branches.length;i++)
   if(Math.hypot(branches[i].x-lv.star[0],branches[i].y-lv.star[1])<R+10){
    S.gotStar=true;BUS.emit('star.collect',{x:lv.star[0],y:lv.star[1]});break;}
 }

 var near=false;
 for(i=0;i<lv.walls.length;i++)if(lv.walls[i][4]===SPIKE){
  var wq=lv.walls[i];
  if(Math.abs(b.y-wq[1])<70&&b.x>Math.min(wq[0],wq[2])-50&&b.x<Math.max(wq[0],wq[2])+50)near=true;}
 if(near!==S.tension){S.tension=near;Audio1.playMusicState(near?'tension':'run');}

 /* l'arrivée effondre la superposition sur la branche qui la touche */
 var z=lv.zone,list=S.branch?[b,S.branch]:[b],hit=null;
 for(i=0;i<list.length;i++){
  var p=list[i],v2=Math.sqrt(p.vx*p.vx+p.vy*p.vy);
  if(p.x>z[0]&&p.x<z[0]+z[2]&&p.y>z[1]&&p.y<z[1]+z[3]&&v2<2.2){hit=p;break;}
 }
 if(hit){
  if(S.branch&&hit!==b){S.ball=hit;b=hit;S.branch=null;S.superposed=false;S.collapsed=true;
   BUS.emit('quantum.measure',{x:hit.x,y:hit.y,bx:hit.x,by:hit.y});}
  else if(S.branch){S.branch=null;S.superposed=false;S.collapsed=true;}
  S.inZone++;
  if(S.inZone===1)BUS.emit('ball.enter_goal',{x:b.x,y:b.y});
  if(S.inZone>16)BUS.emit('level.complete',{});
 }else S.inZone=0;
 var sv=Math.sqrt(b.vx*b.vx+b.vy*b.vy);
 S.still=(sv<.09&&!S.branch)?S.still+1:0;
 if(S.still>140)BUS.emit('ball.fail',{x:b.x,y:b.y,reason:'stuck'});
}

/* ============================================================
   5 · FX
   ============================================================ */
var RM=false;   /* R296 : on ne reprend plus le réglage « réduire les animations » d'iOS d'office (il coupait le trou noir) ; seul l'interrupteur du jeu compte */
var FX={p:[],r:[],goalRing:null};
function spawn(x,y,vx,vy,life,size,col){
 if(RM)return;if(FX.p.length>210)FX.p.shift();
 FX.p.push({x:x,y:y,vx:vx,vy:vy,l:life,m:life,s:size,c:col});}
function ring(x,y,max,col,w){if(RM)return;FX.r.push({x:x,y:y,r:2,m:max,l:1,c:col,w:w||2});}
function burst(x,y,n,col,sp,nx,ny){
 for(var i=0;i<n;i++){
  var a=Math.random()*Math.PI*2,v=sp*(.35+Math.random());
  var vx=Math.cos(a)*v,vy=Math.sin(a)*v;
  if(nx!==undefined){vx=vx*.5+nx*v*.9;vy=vy*.5+ny*v*.9;}
  spawn(x,y,vx,vy,22+Math.random()*18,1+Math.random()*1.8,col);}}
function fxStep(){
 var i,p;
 for(i=FX.p.length-1;i>=0;i--){p=FX.p[i];
  p.x+=p.vx;p.y+=p.vy;p.vy+=.045;p.vx*=.985;p.vy*=.985;p.l--;
  if(p.l<=0)FX.p.splice(i,1);}
 for(i=FX.r.length-1;i>=0;i--){var r=FX.r[i];
  r.r+=(r.m-r.r)*.18;r.l-=.045;if(r.l<=0)FX.r.splice(i,1);}
 if(FX.goalRing){FX.goalRing.r+=(8-FX.goalRing.r)*.08;FX.goalRing.l-=.012;
  if(FX.goalRing.l<=0)FX.goalRing=null;}}

/* ============================================================
   6 · RENDER
   ============================================================ */
var cv=document.getElementById('cv'),ctx=cv.getContext('2d'),stage=document.getElementById('stage');
var scale=1,ptr=null,loupeOn=true,fitTries=0;

function resize(){
 var aw=stage.clientWidth-6,ah=stage.clientHeight-4;
 if(aw<60||ah<60){if(fitTries++<180)requestAnimationFrame(resize);return;}
 fitTries=0;
 var s=Math.min(aw/W,ah/H);
 if(!isFinite(s)||s<=0)return;
 scale=s;
 var d=Math.min(window.devicePixelRatio||1,2.25);
 cv.style.width=(W*scale)+'px';cv.style.height=(H*scale)+'px';
 cv.width=Math.max(1,Math.round(W*scale*d));
 cv.height=Math.max(1,Math.round(H*scale*d));
 ctx.setTransform(scale*d,0,0,scale*d,0,0);
}
if(window.ResizeObserver){try{new ResizeObserver(function(){fitTries=0;resize();}).observe(stage);}catch(e){}}

function matCol(m){
 if(m===BOUNCEM)return T.bounce;
 if(m===SPIKE)return T.danger;
 if(m===BOOSTM)return T.boost;
 if(m===ICEM)return T.ice;
 if(m===ROPE)return T.rope;
 return T.matter;
}
function drawSeg(c,s,fixed,mat){
 var col=(fixed&&s[4]===SOLID)?TH().wl:matCol(s[4]),i;
 var dx=s[2]-s[0],dy=s[3]-s[1],ln=Math.hypot(dx,dy)||1,ux=dx/ln,uy=dy/ln;
 var k=mat===undefined?1:mat;
 c.lineCap='round';c.lineJoin='round';
 c.globalAlpha=(fixed?.10:.2)*k;c.strokeStyle=col;c.lineWidth=fixed?13:12;
 c.beginPath();c.moveTo(s[0],s[1]);c.lineTo(s[2],s[3]);c.stroke();
 c.globalAlpha=1;c.lineWidth=(fixed?8:6.6)*(.55+.45*k);
 c.strokeStyle=k<1?'#9EEBFF':col;
 c.beginPath();c.moveTo(s[0],s[1]);c.lineTo(s[2],s[3]);c.stroke();
 if(s[4]===BOUNCEM){
  c.strokeStyle='#FFD08A';c.lineWidth=1.8;
  for(i=14;i<ln-6;i+=22){
   var x=s[0]+ux*i,y=s[1]+uy*i;
   c.beginPath();
   c.moveTo(x-uy*5.2-ux*5,y+ux*5.2-uy*5);
   c.quadraticCurveTo(x-uy*11,y+ux*11,x-uy*5.2+ux*5,y+ux*5.2+uy*5);
   c.stroke();}
 }else if(s[4]===BOOSTM){
  var vk=s[10]===undefined?1:Math.max(0,s[10])/7.2,brk=s[10]!==undefined&&s[10]<.6,sp=brk?15:Math.round(34-14*Math.min(1.4,vk));   /* R299 : le dessin dit la vitesse — chevrons serrés et vifs = rapide, larges et lents = lent, barres ambrées = frein */
  c.strokeStyle=(s[10]!==undefined&&window.VX&&VX.spdCol)?(function(a){return 'rgb('+a[0]+','+a[1]+','+a[2]+')';})(VX.spdCol(s[10])):(brk?T.rope:T.surface);c.lineWidth=2.2;
  var n=Math.floor(ln/sp),ph=(RM||brk)?0:(S.t*.9*(s[10]===undefined?1:vk)*(24/sp))%sp;
  for(i=0;i<n+1;i++){
   var q=(i*sp+ph)%ln,px=s[0]+ux*q,py=s[1]+uy*q;
   if(q<8||q>ln-8)continue;
   c.beginPath();
   if(brk){c.moveTo(px-uy*4.6,py+ux*4.6);c.lineTo(px+uy*4.6,py-ux*4.6);}
   else{c.moveTo(px-ux*4.5-uy*3.4,py-uy*4.5+ux*3.4);
   c.lineTo(px+ux*4.5,py+uy*4.5);
   c.lineTo(px-ux*4.5+uy*3.4,py-uy*4.5-ux*3.4);}
   c.stroke();}
 }else if(s[4]===SPIKE){
  c.strokeStyle=T.danger;c.lineWidth=2.2;
  for(i=7;i<ln;i+=13){
   var sx=s[0]+ux*i,sy=s[1]+uy*i;
   c.beginPath();c.moveTo(sx,sy);c.lineTo(sx-uy*8.5,sy+ux*8.5);c.stroke();}
 }else if(s[4]===ICEM){
  c.strokeStyle='#EAFAFF';c.lineWidth=1.4;c.globalAlpha=.8;
  for(i=10;i<ln-4;i+=15){
   var ix=s[0]+ux*i,iy=s[1]+uy*i;
   c.beginPath();c.moveTo(ix-uy*2.4,iy+ux*2.4);c.lineTo(ix+ux*6-uy*2.4,iy+uy*6+ux*2.4);c.stroke();}
  c.globalAlpha=1;
 }
}

/* décors de monde : chargés une fois, dessinés sous la grille */
function wimg(w){
 if(WIMG[w]!==undefined)return WIMG[w];
 if(!WART[w]){WIMG[w]=null;return null;}
 var im=new Image();
 im.onload=function(){im._ok=true;im._blur=preBlur(im,w);};
 im.onerror=function(){WIMG[w]=null;};
 im.src=WART[w];
 WIMG[w]=im;return im;
}
/* Le décor est flouté UNE FOIS dans un canvas hors écran, au format du terrain.
   Flouter à chaque frame coûterait trop cher, et le décor doit reculer derrière
   la grille, les piques et le tracé plutôt que les concurrencer. */
function preBlur(im,w){
 try{
  var wm=WMETA[w]||{},r=(wm.blur===undefined)?7:wm.blur;
  var iw=im.naturalWidth||im.width,ih=im.naturalHeight||im.height,ta=W/H,sw,sh,sx,sy;
  if(iw/ih>ta){sh=ih;sw=ih*ta;sx=(iw-sw)/2;sy=0;}
  else{sw=iw;sh=iw/ta;sx=0;sy=(ih-sh)*((wm.fy===undefined)?.5:wm.fy);}
  var oc=document.createElement('canvas');oc.width=W;oc.height=H;
  var c2=oc.getContext('2d');
  if(r>0&&('filter' in c2))c2.filter='blur('+r+'px)';
  c2.drawImage(im,sx,sy,sw,sh,-r*2,-r*2,W+r*4,H+r*4);
  if('filter' in c2)c2.filter='none';
  return oc;
 }catch(err){return null;}
}
function hexRGB(h){return parseInt(h.slice(1,3),16)+','+parseInt(h.slice(3,5),16)+','+parseInt(h.slice(5,7),16);}
var STARF=[];
(function(){var r=987654321;for(var i=0;i<64;i++){
 r=(r*1103515245+12345)&0x7fffffff;var a=(r%10000)/10000;
 r=(r*1103515245+12345)&0x7fffffff;var b=(r%10000)/10000;
 r=(r*1103515245+12345)&0x7fffffff;var d=(r%10000)/10000;
 STARF.push([a*W,b*H,.16+d*.4,.4+d*.9]);}})();
/* ambiance : une couche légère et propre à chaque monde */
var AMB=[];
(function(){var r=1234567;for(var i=0;i<30;i++){
 r=(r*1103515245+12345)&0x7fffffff;var a=(r%1000)/1000;
 r=(r*1103515245+12345)&0x7fffffff;var b=(r%1000)/1000;
 r=(r*1103515245+12345)&0x7fffffff;var d=(r%1000)/1000;
 AMB.push([a*W,b*H,.4+d*1.4,.3+d]);}})();
function ambient(c,th){
 if(RM||th.fx==='none')return;
 var t=S.tick,i,p;
 c.save();
 if(th.fx==='embers'||th.fx==='motes'||th.fx==='dust'||th.fx==='snow'){
  var up=th.fx==='embers',sp=th.fx==='snow'?.38:(up?-.42:-.16);
  c.fillStyle=th.c;
  for(i=0;i<AMB.length;i++){p=AMB[i];
   var y=((p[1]+t*sp*p[3])%(H+40)+H+40)%(H+40)-20;
   var x=p[0]+Math.sin((t*.006+i)*1.3)*9;
   c.globalAlpha=.05+ (i%5)*.012;
   c.beginPath();c.arc(x,y,p[2],0,6.2832);c.fill();}
 }else if(th.fx==='ticks'){
  c.strokeStyle=th.c;c.globalAlpha=.07;c.lineWidth=1.4;
  for(i=0;i<16;i++){var yy=((i*34+t*.9)%(H+30))-15;
   c.beginPath();c.moveTo(6+i*23,yy);c.lineTo(6+i*23,yy+11);c.stroke();}
 }else if(th.fx==='streaks'){
  c.strokeStyle=th.c;c.lineWidth=1.1;
  for(i=0;i<12;i++){var y2=22+i*38,x2=((t*1.5+i*90)%(W+120))-120;
   c.globalAlpha=.06;
   c.beginPath();c.moveTo(x2,y2);c.lineTo(x2+74,y2);c.stroke();}
 }else if(th.fx==='scan'){
  var sy=(t*1.1)%H;
  c.globalAlpha=.07;c.strokeStyle=th.c;c.lineWidth=1;
  for(i=0;i<H;i+=4){c.globalAlpha=.02;c.beginPath();c.moveTo(0,i);c.lineTo(W,i);c.stroke();}
  c.globalAlpha=.11;c.beginPath();c.moveTo(0,sy);c.lineTo(W,sy);c.stroke();
 }else if(th.fx==='field'){
  c.strokeStyle=th.c;c.lineWidth=1;
  for(i=0;i<5;i++){var rr=((t*.5+i*46)%230);
   c.globalAlpha=.055*(1-rr/230);
   c.beginPath();c.arc(W*.5,H*.5,rr,0,6.2832);c.stroke();}
 }else if(th.fx==='gear'){
  c.strokeStyle=th.c;c.globalAlpha=.05;c.lineWidth=2;
  for(i=0;i<3;i++){var cx3=[40,320,180][i],cy3=[70,410,250][i],rr3=[34,42,26][i];
   c.beginPath();c.arc(cx3,cy3,rr3,0,6.2832);c.stroke();
   for(var k3=0;k3<8;k3++){var a3=t*.004*(i%2?-1:1)+k3*.785;
    c.beginPath();c.moveTo(cx3+Math.cos(a3)*rr3,cy3+Math.sin(a3)*rr3);
    c.lineTo(cx3+Math.cos(a3)*(rr3+7),cy3+Math.sin(a3)*(rr3+7));c.stroke();}}
 }
 c.restore();c.globalAlpha=1;
}
function scene(c){
 var lv=L(),z=lv.zone,i,k,s;
 var th=TH();
 c.fillStyle='#080D15';c.fillRect(0,0,W,H);
 var bg=wimg(lv.wd),wm=WMETA[lv.wd];
 if(bg&&bg._ok&&bg._blur&&wm){
  c.globalAlpha=wm.field;c.drawImage(bg._blur,0,0,W,H);c.globalAlpha=1;
  c.fillStyle='rgba(5,7,13,'+wm.veil+')';c.fillRect(0,0,W,H);
 }else if(bg&&bg._ok&&wm){
  /* recadrage « cover » piloté par le point focal du monde, jamais centré à l'aveugle */
  var iw=bg.naturalWidth||bg.width,ih=bg.naturalHeight||bg.height,ta=W/H,sw,sh,sx,sy;
  if(iw/ih>ta){sh=ih;sw=ih*ta;sx=(iw-sw)/2;sy=0;}
  else{sw=iw;sh=iw/ta;sx=0;sy=(ih-sh)*wm.fy;}
  c.globalAlpha=wm.field;c.drawImage(bg,sx,sy,sw,sh,0,0,W,H);c.globalAlpha=1;
  c.fillStyle='rgba(5,7,13,'+wm.veil+')';c.fillRect(0,0,W,H);
 }
 var neb=c.createRadialGradient(W*.26,H*.16,10,W*.26,H*.16,W*.85);
 neb.addColorStop(0,'rgba(168,120,255,.20)');neb.addColorStop(1,'rgba(168,120,255,0)');
 if(!(bg&&bg._ok)){c.fillStyle=neb;c.fillRect(0,0,W,H);}
 var neb2=c.createRadialGradient(W*.82,H*.74,10,W*.82,H*.74,W*.8);
 neb2.addColorStop(0,'rgba(67,213,245,.14)');neb2.addColorStop(1,'rgba(67,213,245,0)');
 if(!(bg&&bg._ok)){c.fillStyle=neb2;c.fillRect(0,0,W,H);}
 var neb3=c.createRadialGradient(W*.5,H*.5,10,W*.5,H*.5,W*.6);
 neb3.addColorStop(0,'rgba('+hexRGB(th.c)+',.10)');neb3.addColorStop(1,'rgba('+hexRGB(th.c)+',0)');
 c.fillStyle=neb3;c.fillRect(0,0,W,H);
 for(i=0;i<STARF.length;i++){
  var sf=STARF[i];
  c.globalAlpha=sf[2]*(RM?1:(.65+.35*Math.sin(S.tick*.02+i)));
  c.fillStyle='#FFFFFF';
  c.beginPath();c.arc(sf[0],sf[1],sf[3],0,6.2832);c.fill();
 }
 c.globalAlpha=1;
 c.strokeStyle=th.gr;c.globalAlpha=(bg&&bg._ok)?.14:.55;c.lineWidth=1;c.beginPath();
 for(i=30;i<W;i+=30){c.moveTo(i,0);c.lineTo(i,H);}
 for(i=30;i<H;i+=30){c.moveTo(0,i);c.lineTo(W,i);}
 c.stroke();c.globalAlpha=1;
 ambient(c,th);
 if(window.VX)window.VX.back(c,lv);

 if(lv.rails){if(!lv._rb)railBuild(lv);drawRails(c,lv);}
 if(lv.nd&&window.VX){window.VX.nd(c,lv);if(S.ndg&&S.ndg.length&&window.VX.ndDust)window.VX.ndDust(c,S.ndg,S.tick);}   /* R168 : le sable du trait refusé fait partie du rendu de la zone (l'ancien hachurage ne s'affiche plus) */
 else if(lv.nd)for(i=0;i<lv.nd.length;i++){
  var r=lv.nd[i];
  c.save();c.beginPath();c.rect(r[0],r[1],r[2],r[3]);c.clip();
  c.strokeStyle=T.border;c.lineWidth=1.3;c.beginPath();
  for(k=-r[3];k<r[2];k+=11){c.moveTo(r[0]+k,r[1]+r[3]);c.lineTo(r[0]+k+r[3],r[1]);}
  c.stroke();c.restore();
  c.strokeStyle=T.border;c.lineWidth=1.3;c.strokeRect(r[0],r[1],r[2],r[3]);}

 if(lv.grav)for(i=0;i<lv.grav.length;i++){
  if(lv.grav[i][6]){if(window.VX&&VX.gzone)VX.gzone(c,lv.grav[i]);continue;}   /* R142 : zone « Relativité » : son propre bas, dessiné en lignes d'horizon */
  var gz=lv.grav[i],up=gz[5]<0,low=Math.abs(gz[5])<G;
  var gc=up?T.boost:(low?T.air:T.danger);
  c.globalAlpha=.09;c.fillStyle=gc;c.fillRect(gz[0],gz[1],gz[2],gz[3]);   /* R252 : zones plus lisibles */
  c.globalAlpha=.5;c.strokeStyle=gc;c.lineWidth=1.2;c.setLineDash([3,4]);
  c.strokeRect(gz[0],gz[1],gz[2],gz[3]);c.setLineDash([]);
  c.globalAlpha=.85;c.lineWidth=2;
  for(k=0;k<3;k++){
   var ax=gz[0]+gz[2]*(k+1)/4,ay=gz[1]+gz[3]*.5,dir=up?-1:1,L2=Math.min(16,Math.abs(gz[5])*40+7);
   c.beginPath();c.moveTo(ax,ay-L2*dir);c.lineTo(ax,ay+L2*dir);
   c.lineTo(ax-4,ay+(L2-5)*dir);c.moveTo(ax,ay+L2*dir);c.lineTo(ax+4,ay+(L2-5)*dir);c.stroke();}
  c.globalAlpha=1;}

 if(lv.vortex&&window.VX&&VX.vortex)VX.vortex(c,lv.vortex);
 if(lv.updraft&&window.VX&&VX.updraft)VX.updraft(c,lv.updraft);
 if(lv.mov&&window.VX&&VX.yoke)for(i=0;i<lv.mov.length;i++)if(lv.mov[i].ck)VX.yoke(c,lv.mov[i]);
 if(lv.pend&&window.VX&&VX.pendulum){if(Array.isArray(lv.pend[0]))lv.pend.forEach(function(pq){VX.pendulum(c,pq);});else VX.pendulum(c,lv.pend);}   /* R161 : plusieurs pendules */
 if(lv.well&&window.VX&&VX.well)for(i=0;i<lv.well.length;i++)VX.well(c,lv.well[i]);
 if(lv.bf&&window.VX&&VX.bfield)for(i=0;i<lv.bf.length;i++)VX.bfield(c,lv.bf[i]);
 if(lv.wrap&&window.VX&&VX.seam)VX.seam(c,lv.wrap);   /* R144 : coutures de l'espace torique */
 if(lv.spectro&&window.VX&&VX.spectro)VX.spectro(c,lv.spectro);   /* R147 : orbites de référence du spectromètre */
 if(lv.coil&&window.VX&&VX.coil)for(i=0;i<lv.coil.length;i++)VX.coil(c,lv.coil[i],S.coilOn&&S.coilOn[i]!=null?S.t-S.coilOn[i]:999);   /* R147 : bobines du canon de Gauss */
 if(lv.kick&&window.VX&&VX.kickgap)for(i=0;i<lv.kick.length;i++)VX.kickgap(c,lv.kick[i],S.kickOn&&S.kickOn[i]!=null?S.t-S.kickOn[i]:999);   /* R143 : fente accélératrice */   /* R143 : champ magnétique uniforme, notation ⊙ / ⊗ */   /* R142 : la toile de l'espace se creuse autour de la masse */   /* R140 : balancier et ancre d'échappement */   /* R140 : bielle à coulisse (Scotch yoke) sous chaque marche mobile */   /* R140 : colonne d'air en filets montants */   /* R139 : tourbillon dessiné en spirale, ses champs restent invisibles */
 if(lv.wind)for(i=0;i<lv.wind.length;i++){
  var w=lv.wind[i];if(w[6])continue;
  c.globalAlpha=.1;c.fillStyle=T.air;c.fillRect(w[0],w[1],w[2],w[3]);   /* R252 : vent plus lisible */
  c.globalAlpha=.45;c.strokeStyle=T.air;c.lineWidth=1.2;c.strokeRect(w[0],w[1],w[2],w[3]);
  c.globalAlpha=.85;c.lineWidth=2;
  var hor=Math.abs(w[4])>Math.abs(w[5]),ph=RM?0:(S.t*1.5)%36;
  if(hor){
   var sgn=w[4]>0?1:-1;
   for(k=0;k<w[2]/36+1;k++){
    var x2=w[4]>0?w[0]+((k*36+ph)%(w[2]+36))-18:w[0]+w[2]-((k*36+ph)%(w[2]+36))+18;
    if(x2<w[0]-4||x2>w[0]+w[2])continue;
    for(var y3=w[1]+19;y3<w[1]+w[3]-4;y3+=28){
     c.beginPath();c.moveTo(x2-6*sgn,y3-6);c.lineTo(x2,y3);c.lineTo(x2-6*sgn,y3+6);c.stroke();}}
  }else{
   var sg2=w[5]<0?1:-1;
   for(k=0;k<w[3]/36+1;k++){
    var y2=w[5]<0?w[1]+w[3]-((k*36+ph)%(w[3]+36)):w[1]+((k*36+ph)%(w[3]+36))-18;
    if(y2<w[1]-4||y2>w[1]+w[3])continue;
    for(var x3=w[0]+19;x3<w[0]+w[2]-4;x3+=28){
     c.beginPath();c.moveTo(x3-6,y2+6*sg2);c.lineTo(x3,y2);c.lineTo(x3+6,y2+6*sg2);c.stroke();}}}
  c.globalAlpha=1;}

 if(lv.mag)for(i=0;i<lv.mag.length;i++){
  /* aimant (R49) : champ lisible — halo, lignes de champ radiales parcourues de grains qui convergent vers le cœur,
     ondes qui se resserrent ; l'intensité suit la force réelle (m[3]) */
  var mg2=lv.mag[i],R2=mg2[2],rep=mg2[3]<0,st2=Math.min(1,Math.abs(mg2[3])/.5),tt=RM?0:S.t,j2,a2,u2;   /* R157 : m[3]<0 = répulseur (noyau) — cyan, grains et ondes qui partent du cœur */
  c.save();
  var gh=c.createRadialGradient(mg2[0],mg2[1],0,mg2[0],mg2[1],R2);
  gh.addColorStop(0,rep?'rgba(77,215,255,'+(.2+.16*st2).toFixed(3)+')':'rgba(255,77,141,'+(.22+.18*st2).toFixed(3)+')');gh.addColorStop(.45,rep?'rgba(120,170,255,.09)':'rgba(168,120,255,.10)');gh.addColorStop(1,'rgba(77,215,255,0)');
  c.fillStyle=gh;c.beginPath();c.arc(mg2[0],mg2[1],R2,0,6.2832);c.fill();
  c.globalCompositeOperation='lighter';
  for(j2=0;j2<16;j2++){a2=j2/16*6.2832+.2;
   c.strokeStyle='rgba(168,120,255,.22)';c.lineWidth=1;c.beginPath();
   c.moveTo(mg2[0]+Math.cos(a2)*R2,mg2[1]+Math.sin(a2)*R2);c.lineTo(mg2[0]+Math.cos(a2)*10,mg2[1]+Math.sin(a2)*10);c.stroke();
   for(var g2=0;g2<2;g2++){u2=((tt*.012*(.8+st2))+j2*.137+g2*.5)%1;if(!rep)u2=1-u2;u2=u2*u2;   /* les grains accélèrent en approchant */
    c.fillStyle=(rep?'rgba(190,240,255,':'rgba(255,180,220,')+(.35+.55*(1-u2)).toFixed(3)+')';var gx=mg2[0]+Math.cos(a2)*(10+u2*(R2-10)),gy=mg2[1]+Math.sin(a2)*(10+u2*(R2-10));
    c.beginPath();c.arc(gx,gy,1.2+1.2*(1-u2),0,6.2832);c.fill();}}
  for(j2=0;j2<3;j2++){u2=(tt*.008+j2/3)%1;if(!rep)u2=1-u2;
   c.strokeStyle=(rep?'rgba(77,215,255,':'rgba(255,77,141,')+(.5*(1-u2)).toFixed(3)+')';c.lineWidth=1.4;c.beginPath();c.arc(mg2[0],mg2[1],8+u2*(R2-8),0,6.2832);c.stroke();}
  c.strokeStyle=rep?'rgba(140,225,255,.55)':'rgba(255,140,190,.55)';c.lineWidth=1.2;c.setLineDash([4,5]);c.lineDashOffset=RM?0:(rep?S.t*.3:-S.t*.3);
  c.beginPath();c.arc(mg2[0],mg2[1],R2,0,6.2832);c.stroke();c.setLineDash([]);
  var gc=c.createRadialGradient(mg2[0],mg2[1],0,mg2[0],mg2[1],12);gc.addColorStop(0,rep?'#F0FBFF':'#FFF0F6');gc.addColorStop(.45,rep?'#4DD7FF':'#FF4D8D');gc.addColorStop(1,rep?'rgba(77,215,255,0)':'rgba(255,77,141,0)');
  c.fillStyle=gc;c.beginPath();c.arc(mg2[0],mg2[1],12,0,6.2832);c.fill();
  c.restore();}

 if(lv.port)for(i=0;i<lv.port.length;i++){
  if(window.VX&&VX.portal)continue;   /* R310/R312 : rendu unique des portails, dessiné après le vortex d'arrivée (au premier plan) */
  if(lv.port[i][5]&&window.VX&&VX.rift){VX.rift(c,lv.port[i]);continue;}   /* R144 : faille orientée — corral d'atomes et onde stationnaire */
  var pp=lv.port[i],sp=RM?0:S.t*.05;
  for(k=0;k<2;k++){
   var px2=k?pp[2]:pp[0],py2=k?pp[3]:pp[1],col=k?T.goal:T.matter;
   c.strokeStyle=col;c.globalAlpha=.85;c.lineWidth=2.4;
   c.beginPath();c.arc(px2,py2,13,sp+k*3,sp+k*3+4.4);c.stroke();
   c.globalAlpha=.45;c.lineWidth=1.4;
   c.beginPath();c.arc(px2,py2,8,-sp,-sp+3.6);c.stroke();
   c.globalAlpha=.18;c.fillStyle=col;
   c.beginPath();c.arc(px2,py2,13,0,6.2832);c.fill();c.globalAlpha=1;}
  c.strokeStyle=T.border;c.globalAlpha=.3;c.lineWidth=1;c.setLineDash([2,6]);
  c.beginPath();c.moveTo(pp[0],pp[1]);c.lineTo(pp[2],pp[3]);c.stroke();
  c.setLineDash([]);c.globalAlpha=1;}


 if(window.VX&&VX.qent){   /* R156 : éléments quantiques redessinés (visuals.js) */
  var tq=RM?0:S.t;
  if(lv.tdil)for(i=0;i<lv.tdil.length;i++)VX.qtdil(c,lv.tdil[i],tq);
  if(lv.sup)for(i=0;i<lv.sup.length;i++)VX.qsup(c,lv.sup[i],tq);
  if(lv.det)for(i=0;i<lv.det.length;i++)VX.qdet(c,lv.det[i],!!S.branch,tq,lv);
  if(lv.gate)for(i=0;i<lv.gate.length;i++)VX.qgate(c,lv.gate[i],gateOpen(lv.gate[i]),tq);
  if(lv.rec&&VX.qrec)for(i=0;i<lv.rec.length;i++)VX.qrec(c,lv.rec[i],tq,!!S.branch,S.recOn&&S.recOn[i]!=null?S.t-S.recOn[i]:999,(function(ra,w){if(!ra||!S.branch)return 0;var a0=ra[0]!=null?S.t-ra[0]:1e9,a1=ra[1]!=null?S.t-ra[1]:1e9,d=Math.min(a0,a1);return d<=w?1-d/w:0;})(S.recAt&&S.recAt[i],lv.rec[i][4]||14));   /* R243 : recombineur */
  VX.qent(c,lv,S);
 }else{
 /* dilatation temporelle */
 if(lv.tdil)for(i=0;i<lv.tdil.length;i++){
  var td=lv.tdil[i];
  c.globalAlpha=.05;c.fillStyle=T.gold;c.fillRect(td[0],td[1],td[2],td[3]);
  c.globalAlpha=.32;c.strokeStyle=T.gold;c.lineWidth=1;c.setLineDash([2,5]);
  c.strokeRect(td[0],td[1],td[2],td[3]);c.setLineDash([]);
  c.globalAlpha=.5;c.lineWidth=1.5;
  var tc=[td[0]+td[2]/2,td[1]+td[3]/2],rr2=13,aa=RM?0:S.t*.012;
  c.beginPath();c.arc(tc[0],tc[1],rr2,aa,aa+2.2);c.stroke();
  c.beginPath();c.arc(tc[0],tc[1],rr2*.55,-aa,-aa+2.2);c.stroke();
  c.globalAlpha=1;
 }
 /* zone de superposition */
 if(lv.sup)for(i=0;i<lv.sup.length;i++){
  var sz=lv.sup[i];
  c.globalAlpha=.06;c.fillStyle=T.violet;c.fillRect(sz[0],sz[1],sz[2],sz[3]);
  c.globalAlpha=.4;c.strokeStyle=T.violet;c.lineWidth=1.2;
  c.strokeRect(sz[0],sz[1],sz[2],sz[3]);
  c.globalAlpha=.28;
  c.strokeRect(sz[0]+3,sz[1]+3,sz[2]-6,sz[3]-6);
  c.globalAlpha=1;
 }
 /* détecteur de mesure */
 if(lv.det)for(i=0;i<lv.det.length;i++){
  var dt2=lv.det[i],dp=RM?0:Math.sin(S.t*.05)*1.5;
  c.globalAlpha=.07;c.fillStyle=T.cyan;
  c.beginPath();c.arc(dt2[0],dt2[1],dt2[2],0,6.2832);c.fill();
  c.globalAlpha=.75;c.strokeStyle=T.cyan;c.lineWidth=1.6;
  c.beginPath();c.arc(dt2[0],dt2[1],dt2[2]+dp,0,6.2832);c.stroke();
  c.lineWidth=1.2;c.globalAlpha=.55;
  c.beginPath();
  c.moveTo(dt2[0]-7,dt2[1]);c.lineTo(dt2[0]+7,dt2[1]);
  c.moveTo(dt2[0],dt2[1]-7);c.lineTo(dt2[0],dt2[1]+7);c.stroke();
  c.globalAlpha=1;
 }
 /* portes intriquées */
 if(lv.gate)for(i=0;i<lv.gate.length;i++){
  var g2=lv.gate[i],op=gateOpen(g2);
  if(op){
   c.globalAlpha=.3;c.strokeStyle=T.violet;c.lineWidth=1.4;c.setLineDash([3,6]);
   c.beginPath();c.moveTo(g2[0],g2[1]);c.lineTo(g2[2],g2[3]);c.stroke();
   c.setLineDash([]);c.globalAlpha=1;
  }else drawSeg(c,[g2[0],g2[1],g2[2],g2[3],SOLID],true);
 }
 /* paires intriquées */
 if(lv.ent)for(i=0;i<lv.ent.length;i++){
  var ee=lv.ent[i],es=S.ent[i]||{on:false,pulse:0};
  var mx=(ee[0]+ee[2])/2,my=(ee[1]+ee[3])/2;
  var bulge=Math.hypot(ee[2]-ee[0],ee[3]-ee[1])*.22;
  c.strokeStyle=T.violet;c.globalAlpha=es.on?.55:.22;c.lineWidth=es.on?2:1.2;
  c.beginPath();c.moveTo(ee[0],ee[1]);
  c.quadraticCurveTo(mx,my-bulge,ee[2],ee[3]);c.stroke();
  c.beginPath();c.moveTo(ee[0],ee[1]);
  c.quadraticCurveTo(mx,my+bulge,ee[2],ee[3]);c.stroke();
  c.globalAlpha=1;
  for(k=0;k<2;k++){
   var ex=k?ee[2]:ee[0],ey=k?ee[3]:ee[1];
   var col=k?T.violet:T.cyan,pr2=13+(es.pulse>0?es.pulse*7:0);
   c.globalAlpha=.16;c.fillStyle=col;
   c.beginPath();c.arc(ex,ey,pr2+7,0,6.2832);c.fill();
   c.globalAlpha=1;c.fillStyle=col;
   c.beginPath();c.arc(ex,ey,es.on?9:7,0,6.2832);c.fill();
   c.strokeStyle='rgba(255,255,255,.8)';c.lineWidth=1.2;
   c.beginPath();c.arc(ex,ey,es.on?9:7,0,6.2832);c.stroke();
   if(es.on){c.strokeStyle=col;c.globalAlpha=.6;c.lineWidth=1.4;
    c.beginPath();c.arc(ex,ey,pr2+3,0,6.2832);c.stroke();c.globalAlpha=1;}
  }
 }

 }
 var gx=z[0]+z[2]/2,gy=z[1]+z[3]/2;
 var pr=Math.min(21,z[3]/2-2)+(RM?0:Math.sin(S.t*.026)*1.3);
 c.globalAlpha=.05;c.fillStyle=T.goal;c.fillRect(z[0],z[1],z[2],z[3]);
 c.globalAlpha=.15;c.beginPath();c.arc(gx,gy,pr+7,0,6.2832);c.fill();c.globalAlpha=1;
 c.strokeStyle=T.goal;c.lineWidth=8.5;
 c.beginPath();c.arc(gx,gy,pr,0,6.2832);c.stroke();
 c.fillStyle=TH().bg;c.beginPath();c.arc(gx,gy,pr-6.5,0,6.2832);c.fill();
 c.strokeStyle='#C8FF8D';c.lineWidth=1.4;
 c.beginPath();c.arc(gx,gy,pr-6.5,0,6.2832);c.stroke();
 c.strokeStyle=T.goal;c.globalAlpha=.55;c.lineWidth=1.6;c.beginPath();
 c.moveTo(gx,gy-pr-11);c.lineTo(gx,gy-pr-5);
 c.moveTo(gx,gy+pr+5);c.lineTo(gx,gy+pr+11);
 c.moveTo(gx-pr-11,gy);c.lineTo(gx-pr-5,gy);
 c.moveTo(gx+pr+5,gy);c.lineTo(gx+pr+11,gy);
 c.stroke();c.globalAlpha=1;
 if(lv.port&&window.VX&&VX.portal)for(i=0;i<lv.port.length;i++)VX.portal(c,lv.port[i]);   /* R312 : portails devant le vortex d'arrivée */

 if(S.trace&&S.trace.length>1){
  c.strokeStyle='#EAF6FF';c.globalAlpha=.55;c.lineWidth=1.8;c.setLineDash([2,6]);
  c.beginPath();c.moveTo(S.trace[0][0],S.trace[0][1]);
  for(i=1;i<S.trace.length;i++)c.lineTo(S.trace[i][0],S.trace[i][1]);
  c.stroke();c.setLineDash([]);c.globalAlpha=1;}

 if(lv.mach&&window.VX&&VX.qmach)VX.qmach(c,lv,S,0);   /* R247 : machine de niveau (banc d'optique…), sous les murs */
 if(lv.flow&&window.VX&&VX.flow)VX.flow(c,lv.flow);   /* R130 : poussière d'étoile qui indique l'entrée de la machine */
 if(lv._cv&&window.VX&&VX.curve)for(i=0;i<lv._cv.length;i++)if(!(lv._cv[i].pass&&!lv._cv[i].pz))VX.curve(c,lv._cv[i].pts,lv._cv[i].m,lv._cv[i].v===undefined?undefined:{noHang:1,accent:VX.spdCol(lv._cv[i].v),speed:Math.max(0,lv._cv[i].v)/7.2});
 if(lv._cv&&window.VX&&VX.tunnel)for(i=0;i<lv._cv.length;i++)if(lv._cv[i].pass)VX.tunnel(c,lv._cv[i].pts,lv._cv[i].pz);   /* R130 : paroi tunnel */
 var fixed=lv.walls.filter(function(w){return !(w[5]===1&&window.VX&&VX.curve);});
 if(lv.mov)for(i=0;i<lv.mov.length;i++){var mv=lv.mov[i];
  if((mv.ck||mv.pl)&&window.VX&&VX.curve){var sa=moverSeg(mv),nx2=lv.mov[i+1],sb=(nx2&&!nx2.ck&&nx2.ph===mv.ph&&nx2.seg[0]===mv.seg[0])?moverSeg(nx2):null;   /* R140 : marche mobile = une seule pièce de lumière (jupe + dessus), sans capuchons */
   VX.curve(c,sb?[[sb[2],sb[3]],[sb[0],sb[1]+3],[sa[0]+3,sa[1]],[sa[2],sa[3]]]:[[sa[0],sa[1]],[sa[2],sa[3]]],0,{noHang:1,accent:[224,178,76]});if(sb)i++;continue;}
  fixed.push(moverSeg(mv));}
 if(window.VX)fixed=window.VX.fixed(c,fixed,lv);
 for(i=0;i<fixed.length;i++)drawSeg(c,fixed[i],true);
 if(lv.mach&&window.VX&&VX.qmach)VX.qmach(c,lv,S,1);
 if(lv._v2===undefined)lv._v2=lv.walls.some(function(w){return w[4]===BOOSTM&&w[10]!==undefined;});
 if(lv._v2&&window.VX&&VX.spdCol){   /* R300 : légende de vitesse des rubans (frein · lent · normal · rapide) */
  var lg=[['frein',0],['lent',2],['normal',7],['rapide',10]],lx=W-4;c.save();c.font='9px system-ui,sans-serif';c.textBaseline='middle';c.textAlign='right';
  for(var li=lg.length-1;li>=0;li--){var lc=VX.spdCol(lg[li][1]);c.fillStyle='rgba(235,240,250,.7)';c.fillText(lg[li][0],lx,469);lx-=c.measureText(lg[li][0]).width+4;
   c.fillStyle='rgb('+lc[0]+','+lc[1]+','+lc[2]+')';c.beginPath();c.arc(lx-3,469,3,0,6.2832);c.fill();lx-=13;}
  c.restore();}

 if(lv.star&&!S.gotStar&&window.VX)window.VX.core(c,lv);
 else if(lv.star&&!S.gotStar){
  var sx2=lv.star[0],sy2=lv.star[1],rr=9+(RM?0:Math.sin(S.t*.055)*1.1);
  c.globalAlpha=.16;c.fillStyle=T.reward;
  c.beginPath();c.arc(sx2,sy2,rr+7,0,6.2832);c.fill();c.globalAlpha=1;
  c.strokeStyle=T.reward;c.lineWidth=2;c.beginPath();
  for(i=0;i<5;i++){
   var a1=-Math.PI/2+i*2*Math.PI/5,a2=a1+Math.PI/5;
   c.lineTo(sx2+Math.cos(a1)*rr,sy2+Math.sin(a1)*rr);
   c.lineTo(sx2+Math.cos(a2)*rr*.45,sy2+Math.sin(a2)*rr*.45);}
  c.closePath();c.stroke();}

 var drawn=S.strokes.concat(S.cur?[{pts:S.cur,mat:S.tool,birth:0,live:1}]:[]);
 for(i=0;i<drawn.length;i++){
  s=drawn[i].pts;if(s.length<2)continue;
  if(drawn[i].mat===ROPE&&!drawn[i].live)continue;
  var age=(S.tick-(drawn[i].birth||0))*16.7,mt=RM?1:Math.min(1,age/MOT.materialize);
  if(window.VX&&window.VX.stroke(c,s,drawn[i].mat,mt))continue;
  for(k=1;k<s.length;k++)
   drawSeg(c,[s[k-1][0],s[k-1][1],s[k][0],s[k][1],drawn[i].mat],false,mt);}
 drawRopes(c);
 if(L().fork&&window.VX&&VX.fork)VX.fork(c,L(),QP);   /* R146 : diapason-fronde */
 if(QP.soft&&!(window.QFX&&QFX.busy()))drawSoft(c);   /* R338 : la balle molle laisse la place à l'entrée/sortie animées */

 for(i=0;i<FX.p.length;i++){
  var p=FX.p[i];c.globalAlpha=Math.max(0,p.l/p.m)*.8;c.fillStyle=p.c;
  c.beginPath();c.arc(p.x,p.y,p.s,0,6.2832);c.fill();}
 for(i=0;i<FX.r.length;i++){
  var rg=FX.r[i];c.globalAlpha=Math.max(0,rg.l)*.55;c.strokeStyle=rg.c;c.lineWidth=rg.w;
  c.beginPath();c.arc(rg.x,rg.y,rg.r,0,6.2832);c.stroke();}
 c.globalAlpha=1;

 for(i=0;i<S.trail.length;i++){
  var tp=S.trail[i],f=i/S.trail.length;
  c.globalAlpha=f*.3*Math.min(1,tp[2]/4+.25);c.fillStyle=T.matter;
  c.beginPath();c.arc(tp[0],tp[1],R*(.22+f*.42),0,6.2832);c.fill();}
 c.globalAlpha=1;

 if(S.branch){
  for(i=0;i<S.gtrail.length;i++){
   c.globalAlpha=i/S.gtrail.length*.22;c.fillStyle=T.violet;
   c.beginPath();c.arc(S.gtrail[i][0],S.gtrail[i][1],R*.4,0,6.2832);c.fill();}
  c.globalAlpha=1;
  c.save();c.globalAlpha=.72;
  drawBall(c,S.branch.x,S.branch.y,S.branch.a,R*.94,T.violet);
  c.restore();
  /* frange d'interférence entre les deux branches */
  c.strokeStyle=T.violet;c.globalAlpha=.22;c.lineWidth=1;c.setLineDash([2,5]);
  c.beginPath();c.moveTo(S.ball.x,S.ball.y);c.lineTo(S.branch.x,S.branch.y);c.stroke();
  c.setLineDash([]);c.globalAlpha=1;
 }
 if(!(window.QFX&&QFX.draw(c))&&!QP.soft&&!S.absHide)drawBall(c,S.ball.x,S.ball.y,S.ball.a,R);   /* R287 : entrée/sortie animées (transitions.js) */

 if(FX.goalRing){
  c.globalAlpha=Math.max(0,FX.goalRing.l);c.strokeStyle=T.goal;c.lineWidth=3;
  c.beginPath();c.arc(FX.goalRing.x,FX.goalRing.y,FX.goalRing.r,0,6.2832);c.stroke();
  c.globalAlpha=1;}

 if(S.mode==='draw'&&!S.strokes.length&&!S.cur){
  c.strokeStyle=T.muted;c.globalAlpha=.4;c.lineWidth=1.4;c.setLineDash([3,6]);
  c.beginPath();c.arc(S.ball.x,S.ball.y,R+10,0,6.2832);c.stroke();
  c.setLineDash([]);c.globalAlpha=1;}

 if(S.mode==='rewound'){
  c.strokeStyle=T.reward;c.globalAlpha=.5;c.lineWidth=1.2;c.setLineDash([2,4]);
  c.beginPath();c.arc(S.ball.x,S.ball.y,R+12,0,6.2832);c.stroke();
  c.setLineDash([]);c.globalAlpha=1;}
 if(window.EDT)EDT.draw(c);
 if(S.finT!=null&&window.VX&&VX.finale)VX.finale(c,(S.tick||0)-S.finT,TR('finTitle'),TR('finSub'),L().cup);   /* R156 : apothéose — le dernier niveau se termine en fête */
}

function drawBall(c,x,y,ang,r,tint){
 if(window.VX){window.VX.ball(c,x,y,ang,r,tint);return;}
 var sx=1,sy=1,rot=ang;
 if(S.squash&&S.squash.t>0){
  var k=S.squash.t*S.squash.amt;
  sx=1+k;sy=1-k;rot=Math.atan2(S.squash.ny,S.squash.nx)+Math.PI/2;}
 c.save();c.translate(x,y);
 var HUE=tint||T.matter;
 if(!RM){
  var bl=c.createRadialGradient(0,0,r*.6,0,0,r*2.6);
  bl.addColorStop(0,'rgba('+hexRGB(HUE)+',.34)');
  bl.addColorStop(.5,'rgba('+hexRGB(HUE)+',.12)');
  bl.addColorStop(1,'rgba('+hexRGB(HUE)+',0)');
  c.fillStyle=bl;c.beginPath();c.arc(0,0,r*2.6,0,6.2832);c.fill();c.globalAlpha=1;}
 c.rotate(rot);c.scale(sx,sy);c.rotate(-rot);
 var g=c.createRadialGradient(-r*.34,-r*.4,r*.12,0,0,r);
 g.addColorStop(0,'#FFFFFF');g.addColorStop(.22,tint?'#E2CCFF':'#8EEFFF');
 g.addColorStop(.7,HUE);g.addColorStop(1,tint?'#6A28D8':'#1599C5');
 c.fillStyle=g;c.beginPath();c.arc(0,0,r,0,6.2832);c.fill();
 c.strokeStyle='rgba(185,247,255,.55)';c.lineWidth=1.4;
 c.beginPath();c.arc(0,0,r-.6,0,6.2832);c.stroke();
 c.rotate(ang);
 if(!tint&&SKIN_IMG&&SKIN_IMG._ok){
  c.save();c.beginPath();c.arc(0,0,r-.4,0,6.2832);c.clip();
  c.drawImage(SKIN_IMG,-r,-r,r*2,r*2);c.restore();
 }else{
  c.strokeStyle='rgba(8,40,52,.5)';c.lineWidth=1.8;
  c.beginPath();c.moveTo(-r*.5,0);c.lineTo(r*.5,0);c.stroke();
 }
 c.restore();
}

/* corde : chaînette lissée + ancrages */
function drawRopes(c){
 var r,i,P=QP.p;
 for(r=0;r<QP.ropes.length;r++){
  var R0=QP.ropes[r],n=R0.i1-R0.i0+1;
  if(n<2)continue;
  if((R0.str||L().elastic)&&window.VX&&VX.harp){VX.harp(c,P,R0.i0,R0.i1,R0,r);continue;}   /* R145 : corde de harpe */
  c.lineCap='round';c.lineJoin='round';
  c.globalAlpha=.18;c.strokeStyle=T.rope;c.lineWidth=11;
  c.beginPath();c.moveTo(P[R0.i0].x,P[R0.i0].y);
  for(i=R0.i0+1;i<=R0.i1;i++){
   var a=P[i-1],b=P[i];
   c.quadraticCurveTo(a.x,a.y,(a.x+b.x)/2,(a.y+b.y)/2);}
  c.lineTo(P[R0.i1].x,P[R0.i1].y);c.stroke();
  c.globalAlpha=1;c.lineWidth=4.6;c.strokeStyle=T.rope;c.stroke();
  c.fillStyle=T.rope;
  c.beginPath();c.arc(P[R0.i0].x,P[R0.i0].y,4,0,6.2832);c.fill();
  c.beginPath();c.arc(P[R0.i1].x,P[R0.i1].y,4,0,6.2832);c.fill();
  c.strokeStyle='#F6DCC2';c.lineWidth=1.1;c.globalAlpha=.5;
  for(i=R0.i0;i<=R0.i1;i++){
   c.beginPath();c.arc(P[i].x,P[i].y,2.4,0,6.2832);c.stroke();}
  c.globalAlpha=1;
 }
}
/* balle molle : contour fermé lissé, dégradé conservé */
function drawSoft(c){
 var idx=QP.soft.idx,n=idx.length,P=QP.p,i;
 var ct=softCentroid();
 if(window.VX&&VX.softball){var pp=[];for(i=0;i<n;i++)pp.push(P[idx[i]]);VX.softball(c,pp,ct,S.ball&&S.ball.a);return;}   /* R158 : rendu particule */
 c.beginPath();
 var m0=[(P[idx[n-1]].x+P[idx[0]].x)/2,(P[idx[n-1]].y+P[idx[0]].y)/2];
 c.moveTo(m0[0],m0[1]);
 for(i=0;i<n;i++){
  var a=P[idx[i]],b=P[idx[(i+1)%n]];
  c.quadraticCurveTo(a.x,a.y,(a.x+b.x)/2,(a.y+b.y)/2);}
 c.closePath();
 if(!RM){c.save();c.globalAlpha=.16;c.fillStyle=T.matter;
  c.translate(ct[0],ct[1]);c.scale(1.7,1.7);c.translate(-ct[0],-ct[1]);
  c.fill();c.restore();}
 var g=c.createRadialGradient(ct[0]-5,ct[1]-6,2,ct[0],ct[1],16);
 g.addColorStop(0,'#F4FFFF');g.addColorStop(.24,'#8EEFFF');
 g.addColorStop(.72,T.matter);g.addColorStop(1,'#1599C5');
 c.fillStyle=g;c.fill();
 c.strokeStyle='rgba(185,247,255,.6)';c.lineWidth=1.4;c.stroke();
}

function loupe(){
 if(!ptr||!loupeOn)return;
 var Z=2.3,r=50,m=13;
 var lx=(ptr[0]<W*.5)?W-r-m:r+m,ly=r+m;
 ctx.save();ctx.beginPath();ctx.arc(lx,ly,r,0,6.2832);ctx.clip();
 ctx.fillStyle=TH().sf;ctx.fill();
 ctx.translate(lx,ly);ctx.scale(Z,Z);ctx.translate(-ptr[0],-ptr[1]);
 window.__LOUPE=1;scene(ctx);window.__LOUPE=0;ctx.restore();
 ctx.strokeStyle=T.border;ctx.lineWidth=1.4;
 ctx.beginPath();ctx.arc(lx,ly,r,0,6.2832);ctx.stroke();
 ctx.strokeStyle=T.matter;ctx.globalAlpha=.7;ctx.lineWidth=1;
 ctx.beginPath();ctx.moveTo(lx-10,ly);ctx.lineTo(lx-5,ly);ctx.moveTo(lx+5,ly);ctx.lineTo(lx+10,ly);   /* réticule ouvert : le centre reste libre */
 ctx.moveTo(lx,ly-10);ctx.lineTo(lx,ly-5);ctx.moveTo(lx,ly+5);ctx.lineTo(lx,ly+10);ctx.stroke();ctx.globalAlpha=1;
}

/* ============================================================
   7 · RÉACTIONS
   ============================================================ */
BUS.on('ball.launch',function(){if(!S.zen&&S.mode!=='replay')JR.l++;Audio1.playSfx('ball_launch');Audio1.playMusicState('run');if(S.mode!=='replay'){HINT.n++;hintCheck();}});
/* R191 : l'astuce du niveau est cachée ; elle n'apparaît, en hologramme discret, qu'après 3 lâchers sans réussite ou 45 s passées sur le niveau */
var HINT={n:0,t0:0};
function hintReset(){HINT.n=0;HINT.done=0;HINT.t0=performance.now();if(tip)tip.classList.remove('holo');}
function hintShow(){return;   /* R194 : astuces retirées (demande de Simon) */
 if(!tip||!tip.textContent)return;tip.classList.add('holo');HINT.on=S.tick;HINT.done=1;}
function hintCheck(){if(!tip)return;if(tip.classList.contains('holo')){if(S.tick-HINT.on>720)tip.classList.remove('holo');return;}if(!HINT.done&&tip.textContent&&(HINT.n>=3||performance.now()-HINT.t0>45000))hintShow();}   /* R192 : affichée 12 s dans l'en-tête, à la place du titre ; un toucher sur le titre la rappelle */
BUS.on('ball.impact',function(e){
 S.squash={t:1,amt:Math.min(.34,e.v/26),nx:e.nx,ny:e.ny};
 burst(e.x,e.y,Math.min(7,2+Math.round(e.v/2)),matCol(e.mat),e.v*.13,e.nx,e.ny);
 Audio1.playImpact(e.mat,e.v);
 if(e.v>3)Audio1.buzz(Math.round(Math.min(12,4+e.v)));});
BUS.on('ball.bounce',function(e){
 S.squash={t:1,amt:Math.min(.45,e.v/18),nx:e.nx,ny:e.ny};
 ring(e.x,e.y,30,T.bounce,2.4);burst(e.x,e.y,10,T.bounce,e.v*.18,e.nx,e.ny);
 Audio1.playImpact(BOUNCEM,e.v);Audio1.buzz(16);});
BUS.on('ball.rope',function(e){burst(e.x,e.y,5,T.rope,e.v*.11);Audio1.playSfx('rope_hit',Math.min(1,e.v/8));Audio1.buzz(8);});
BUS.on('ball.boost',function(e){burst(e.x,e.y,8,T.boost,2.2,e.ux,e.uy);Audio1.playSfx('boost_whoosh');});
BUS.on('ball.portal',function(e){
 ring(e.x,e.y,26,T.matter,2.2);ring(e.tx,e.ty,26,T.goal,2.2);
 burst(e.tx,e.ty,12,T.goal,2.2);Audio1.playSfx('portal');Audio1.buzz(12);});
BUS.on('quantum.entangle',function(e){
 ring(e.ax,e.ay,40,T.cyan,2.4);ring(e.bx,e.by,40,T.violet,2.4);
 burst(e.from?e.bx:e.ax,e.from?e.by:e.ay,10,T.cyan,2.4);
 burst(e.from?e.ax:e.bx,e.from?e.ay:e.by,10,T.violet,2.4);
 Audio1.playSfx('ent_link');setTimeout(function(){Audio1.playSfx('gate',.8);},180);Audio1.buzz([10,40,14]);});
BUS.on('quantum.superposition',function(e){
 ring(e.x,e.y,34,T.violet,2.2);burst(e.x,e.y,14,T.violet,2.6);
 Audio1.playSfx('sup_split');Audio1.buzz(12);});
BUS.on('quantum.measure',function(e){
 ring(e.x,e.y,44,T.cyan,2.6);burst(e.bx,e.by,16,T.cyan,2.4);
 Audio1.playSfx('det_measure');Audio1.buzz(16);});
BUS.on('quantum.collapse',function(e){
 burst(e.x,e.y,12,T.violet,1.8);Audio1.playSfx('collapse',.7);});
BUS.on('star.collect',function(e){
 ring(e.x,e.y,34,T.reward,2.2);burst(e.x,e.y,16,T.reward,2.6);
 Audio1.playSfx('star_collect');Audio1.buzz(10);});
BUS.on('ball.enter_goal',function(e){FX.goalRing={x:e.x,y:e.y,r:36,l:1};Audio1.playSfx('goal_enter');});

/* ============================================================
   8 · UI
   ============================================================ */
var $=function(i){return document.getElementById(i);};

/* ══ SAUVEGARDE ══ quantix.save.v1
   Tolérante : mode privé, quota plein, stockage désactivé — on continue sans. */
var SAVE=(function(){
 var KEY='quantix.save.v1', ok=true, pending=0;
 function store(){try{return window.localStorage;}catch(e){ok=false;return null;}}
 return {
  available:function(){return ok&&!!store();},
  read:function(){
   var s=store();if(!s)return null;
   try{var raw=s.getItem(KEY);if(!raw)return null;
    var d=JSON.parse(raw);
    return (d&&d.v===1)?d:null;
   }catch(e){ok=false;return null;}
  },
  write:function(d){
   var s=store();if(!s)return false;
   try{s.setItem(KEY,JSON.stringify(d));return true;}
   catch(e){ok=false;return false;}
  },
  clear:function(){var s=store();if(s)try{s.removeItem(KEY);}catch(e){}},
  /* écriture différée : on ne touche pas au disque à chaque frame */
  queue:function(build){
   if(pending)clearTimeout(pending);
   pending=setTimeout(function(){pending=0;SAVE.write(build());},300);
  }
 };
})();
function saveState(){
 return {v:1,t:Date.now(),
  best:S.best,bestMat:S.bestMat,unlocked:S.unlocked,seen:S.seen,jr:JR,
  lang:LANG,tuto:(window.TUTO?TUTO.state():null),
  skinS:PEDIT.strokes,shape:SHAPE,
  opt:{mus:OPT.mus,sfx:OPT.sfx,hap:OPT.hap,rm:OPT.rm,loupe:OPT.loupe,
   musVol:OPT.musVol,sfxVol:OPT.sfxVol,samples:!!window.__QXSAMPLES}};
}
function persist(){SAVE.queue(saveState);}
/* R208 · JOURNAL DU PARCOURS (sauvegardé avec la progression) : temps de jeu, lâchers, échecs, réussites, traits, matière
   engagée dans les réussites (unités d'encre), reprises. Affiché dans le bilan final. Le Zen Lab ne compte pas. */
var JR={t:0,l:0,f:0,w:0,s:0,m:0,r:0};
function jrFmt(ms){var mn=Math.round(ms/60000);return mn<60?mn+' '+TR('jr_min'):Math.floor(mn/60)+' '+TR('jr_h')+' '+String(mn%60).padStart(2,'0');}
function jrHTML(){var st=0,sol=0,full=0,i;for(i=0;i<LEVELS.length;i++){var b=S.best[i]||0;st+=b;if(b>0)sol++;if(b>=3)full++;}
 var row=function(v,k){return '<span><b>'+v+'</b><i>'+TR(k)+'</i></span>';},nf=function(x){x=Math.round(x);try{return x.toLocaleString(LANG==='en'?'en-US':'fr-FR');}catch(e){return String(x);}};
 return row(st+' / '+LEVELS.length*3,'jr_stars')+row(sol+' / '+LEVELS.length,'jr_solved')+row(full,'jr_full')+row(nf(JR.m),'jr_matter')+row(jrFmt(JR.t),'jr_time')+row(nf(JR.l),'jr_launch')+row(nf(JR.f),'jr_fail')+row(nf(JR.s),'jr_strokes')+row(nf(JR.r),'jr_rew');}
var OPT={mus:true,sfx:true,hap:true,rm:false,loupe:true,musVol:.5,sfxVol:1};
function restore(){
 var d=SAVE.read();if(!d)return false;
 if(d.best&&d.best.length===S.best.length)S.best=d.best;
 if(d.bestMat&&d.bestMat.length===S.bestMat.length)S.bestMat=d.bestMat;
 if(d.jr)for(var jk in JR)JR[jk]=+d.jr[jk]||0;
 if(typeof d.unlocked==='number')S.unlocked=Math.min(d.unlocked,LEVELS.length-1);
 if(typeof d.seen==='number')S.seen=Math.min(d.seen,LEVELS.length-1);
 if(d.lang==='en'||d.lang==='fr')LANG=d.lang;
 if(d.skinS&&d.skinS.length)PEDIT.strokes=d.skinS;
 if(d.shape&&d.shape.length>=6)SHAPE=d.shape;
 if(window.TUTO)TUTO.load(d.tuto,S.seen);
 if(d.opt){
  OPT.mus=d.opt.mus!==false;OPT.sfx=d.opt.sfx!==false;OPT.hap=d.opt.hap!==false;
  OPT.rm=!!d.opt.rm;OPT.loupe=d.opt.loupe!==false;
  if(typeof d.opt.musVol==='number')OPT.musVol=d.opt.musVol;
  if(typeof d.opt.sfxVol==='number')OPT.sfxVol=d.opt.sfxVol;
  if(typeof d.opt.samples==='boolean')window.__QXSAMPLES=d.opt.samples;
 }
 return true;
}
var app=$('app'),bar=$('bar'),tip=$('tip'),scrub=$('scrub'),scrubRow=$('scrubRow'),scrubLab=$('scrubLab');
var PFC=null;
function pfLayout(){try{var g=$('game');if(!PFC){var ft0=g.querySelector('footer');PFC={ft:ft0,en:g.querySelector('.energy'),co:['tl','tr','bl','br'].map(function(k){var e=document.createElement('i');e.className='pcorner '+k;g.appendChild(e);return e;}),k:''};}
 var gr=g.getBoundingClientRect(),r=cv.getBoundingClientRect(),fh=Math.round(PFC.ft.getBoundingClientRect().height),x=Math.round(r.left-gr.left),y=Math.round(r.top-gr.top),key=fh+':'+x+':'+y+':'+Math.round(r.width)+':'+Math.round(r.height);if(key===PFC.k)return;PFC.k=key;
 g.style.setProperty('--pfh',fh+'px');var co=PFC.co;co[0].style.cssText='left:'+(x-5)+'px;top:'+(y-5)+'px';co[1].style.cssText='left:'+(x+r.width-5)+'px;top:'+(y-5)+'px';
 co[2].style.cssText='left:'+(x-5)+'px;top:'+(y+r.height-5)+'px';co[3].style.cssText='left:'+(x+r.width-5)+'px;top:'+(y+r.height-5)+'px';
 PFC.en.style.left=(x+14)+'px';PFC.en.style.width=(r.width-28)+'px';PFC.en.style.top=(y+8)+'px';}catch(ep){}}   /* R194 : plein cadre (ex-prototype studio/proto-plein-cadre.js) */
try{var ghd=$('game').querySelector('header');ghd.appendChild(tip);ghd.querySelector('.exp').addEventListener('click',function(){if(tip.classList.contains('holo'))tip.classList.remove('holo');else if(HINT.done)hintShow();});}catch(eh){}   /* R192 : l'astuce vit dans l'en-tête — elle ne couvre jamais le terrain */
var bPlay=$('bPlay'),bUndo=$('bUndo'),bClear=$('bClear'),bSlow=$('bSlow'),palRow=$('palRow');
var vResult=$('vResult'),vLevels=$('vLevels'),vPause=$('vPause'),vSet=$('vSet'),vEdit=$('vEdit'),vWorld=$('vWorld');

$('gBack').innerHTML=ico('back',19);$('gPause').innerHTML=ico('pause',19);
bUndo.innerHTML=ico('undo',19);bClear.innerHTML=ico('trash',19);bSlow.innerHTML=ico('slow',19);
if(window.EDT)EDT.init();
$('hLevI').innerHTML=ico('star',13);$('hEditI').innerHTML=ico('pen',13);$('hZenI').innerHTML=ico('core',13);
$('hDropI').innerHTML=ico('target',13);$('hSetI').innerHTML=ico('gear',13);

$('c1').firstElementChild.innerHTML=ico('target',17);
$('c2').firstElementChild.innerHTML=ico('core',17);
$('c3').firstElementChild.innerHTML=ico('star',17);

function show(v,on){v.classList.toggle('on',!!on);
 if(v===vLevels||v===vWorld){try{Audio1.playMusicState(on||app.dataset.screen==='home'?'menu':'draw');}catch(e){}}}   /* R154 : constellation et page du monde = musique de menu, sans souffle */

/* R305 : icône du noyau — contours d'Enneper (2 boucles : bord + intérieure) en trait blanc simple, halo bleuté ; même rotation que le noyau (6 s) */
var CI={ln:null,raf:0};
function coreIcoBuild(){var MX=0,i,j,q,en=function(r,th){return [r*Math.cos(th)-r*r*r/3*Math.cos(3*th),-r*Math.sin(th)-r*r*r/3*Math.sin(3*th),r*r*Math.cos(2*th)];};
 for(i=0;i<=40;i++)for(j=0;j<=72;j++){q=en(1.55*i/40,j/72*6.2832);MX=Math.max(MX,Math.hypot(q[0],q[1],q[2]));}
 CI.ln=[1.05,1.55].map(function(r){var a=[];for(var k=0;k<=72;k++){q=en(r,k/72*6.2832);a.push([q[0]/MX,q[1]/MX,q[2]/MX]);}return a;});}
function coreIcoFrame(){var cv=$('coreIco'),bt=$('rRetry');if(!cv||!bt||bt.style.display==='none'){CI.raf=0;return;}
 if(!cv.offsetParent){CI.raf=requestAnimationFrame(coreIcoFrame);return;}   /* R307 : vue pas encore affichée → on attend (avant, la boucle s'arrêtait et l'icône restait vide) */
 if(!CI.ln)coreIcoBuild();
 var c=cv.getContext('2d'),W=cv.width,t=(typeof OPT!=='undefined'&&OPT.rm)?0:performance.now(),a=t*.001047,pu=.5+.5*Math.sin(t*.006),
  ax=[1,.35,.15],l=Math.hypot(ax[0],ax[1],ax[2]);ax=[ax[0]/l,ax[1]/l,ax[2]/l];
 var ca=Math.cos(a),sa=Math.sin(a),k1=1-ca,X=ax[0],Y=ax[1],Z=ax[2],
  m00=ca+X*X*k1,m01=X*Y*k1-Z*sa,m02=X*Z*k1+Y*sa,m10=Y*X*k1+Z*sa,m11=ca+Y*Y*k1,m12=Y*Z*k1-X*sa,sc=W*.42,i,k,p;
 c.clearRect(0,0,W,W);c.save();c.translate(W/2,W/2);
 var gr=c.createRadialGradient(0,0,0,0,0,W*.5);gr.addColorStop(0,'rgba(120,200,255,'+(.16+.08*pu)+')');gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(-W/2,-W/2,W,W);
 c.lineCap='round';c.lineJoin='round';c.lineWidth=W*.036;c.strokeStyle='#fff';c.shadowColor='rgba(110,190,255,.95)';c.shadowBlur=W*.12;
 for(i=0;i<CI.ln.length;i++){c.beginPath();for(k=0;k<CI.ln[i].length;k++){p=CI.ln[i][k];
  var px=(m00*p[0]+m01*p[1]+m02*p[2])*sc,py=(m10*p[0]+m11*p[1]+m12*p[2])*sc;if(k)c.lineTo(px,py);else c.moveTo(px,py);}c.stroke();}
 c.restore();CI.raf=requestAnimationFrame(coreIcoFrame);}
function coreIcoStart(){if(!CI.raf)CI.raf=requestAnimationFrame(coreIcoFrame);}
function applyLang(){
 var els=document.querySelectorAll?document.querySelectorAll('[data-t]'):[],i;
 for(i=0;i<els.length;i++){
  var k=els[i].getAttribute('data-t');
  if(DICT[LANG]&&DICT[LANG][k]!==undefined)els[i].textContent=TR(k);
 }
 var lv=L();
 if(S.zen){$('expName').textContent=TR('zenTitle');$('expSub').textContent=TR('zenSub');}
 else{
  $('expName').textContent=LN(S.li);
  $('expSub').textContent=WN(lv.wd-1)+' · '+(wPos(S.li)+1)+' / 12';
  tip.textContent=LT(S.li);
 }
 bPlay.textContent=(S.mode==='draw')?TR('release'):(S.mode==='rewound'?TR('resumeHere'):TR('relaunch'));
 $('hContName').textContent=S.seen>0?TR('continueQ'):TR('play');$('hContSub').textContent=WN(LEVELS[S.seen].wd-1)+' · '+(wPos(S.seen)+1)+' / 12 · '+LN(S.seen);
 $('hChap').textContent=WN(LEVELS[S.seen].wd-1);
 $('c1').lastElementChild.lastElementChild.textContent=TR('objectiveD');
 $('c2').lastElementChild.lastElementChild.textContent=TR('coreD');
 buildPal();auLine();
}
function goto(scr){
 app.dataset.screen=scr;fitTries=0;if(scr!=='game'&&$('vFin')){show($('vFin'),false);finStop();}
 requestAnimationFrame(function(){if(scr==='game')resize();else{hResize();paintHome();}});
 Audio1.playMusicState(scr==='home'?'menu':'draw');
}

function loadLevel(i){
 S.li=i;S.finT=null;var lv=L();
 S.ink=S.inkMax=lv.ink;S.strokes=[];S.cur=null;S.trace=[];S.ndg=[];S.ndgCur=null;
 curveExpand(lv);
 if(lv.mz){if(!lv.nd)lv.nd=[];lv.nd._mz=lv.mz;}   /* zone de machine : non traçable, mais invisible (la machine reste un décor physique) */
 S.tool=lv.pal.indexOf('S')>=0?SOLID:(lv.pal.indexOf('B')>=0?BOUNCEM:(lv.pal.indexOf('C')>=0?ROPE:BOOSTM));
 if(i>S.seen)S.seen=i;
 $('expName').textContent=LN(i);
 $('expSub').textContent=WN(lv.wd-1)+' · '+(wPos(i)+1)+' / 12';
 app.style.setProperty('--accent',WORLDS[lv.wd-1].c);
 Audio1.setWorld(lv.wd-1);
 tip.textContent=LT(i)||'';hintReset();
 buildPal();paintEnergy();paintGStars();resetBall();
 if(!S.zen&&window.QFX)QFX.birthStart(lv.ball[0],lv.ball[1]);   /* R287 : la particule est crachée puis rattrapée */
 if(window.EDT)EDT.onLoad();
 if(window.TUTO)TUTO.onLoad(i);
}
function resetBall(){
 var lv=L(),b=S.ball;
 b.x=lv.ball[0];b.y=lv.ball[1];b.vx=0;b.vy=0;b.a=0;
 S.trail=[];S.pathRec=[];S.rec=[];S.scrubI=0;S.reprises=0;
 S.inZone=0;S.still=0;S.frames=0;S.gotStar=false;S.t=0;
 S.squash=null;S.tension=false;FX.p=[];FX.r=[];FX.goalRing=null;
 S.absTok=(S.absTok||0)+1;S.absHide=false;bPlay.disabled=false;if(window.QFX)QFX.cancel();
 S.late=null;S.branch=null;S.gtrail=[];S.superposed=false;S.collapsed=false;S.demo=false;S.longAt=LONGRUN;
 S.ent=(lv.ent||[]).map(function(e){return {on:e[5]===1,cd:0,pulse:0,from:-1,off:0,on0:0,tg:null,xf:null};});(lv.det||[]).forEach(function(d){d._lk=null;});(lv.gate||[]).forEach(function(g){g._o=null;});
 delete b.dead;
 portCd=0;boostCd=0;qpBuild();
 S.mode='draw';bPlay.textContent='Lâcher la balle';
 show(vResult,false);if($('vFin'))show($('vFin'),false);finStop();undoSync();
 paintScrub();Audio1.playMusicState('draw');
}
function paintGStars(){
 var g=$('gStars');if(!g)return;
 var n=S.best[S.li]||0,c=g.querySelectorAll?g.querySelectorAll('i'):null,i;
 if(!c||!c.length)return;
 for(i=0;i<c.length&&i<3;i++)c[i].className=(i<n?'on':'');
}
function paintEnergy(){
 /* R261 · règle de l'encre : sans aucun trait posé (ni en cours), la jauge est pleine. Toute perte d'encre sans trait est un bug : on rend l'encre et on le note (S.inkFix). */
 if(!S.zen&&!S.cur&&!(S.strokes&&S.strokes.length)&&!(S.ink>=S.inkMax)){S.inkFix=(S.inkFix||0)+1;try{console.warn('encre rendue (aucun trait) niveau',S.li+1,S.ink,'/',S.inkMax);}catch(e){}S.ink=S.inkMax;}
 if(!(S.inkMax>2)){try{console.error('niveau sans encre',S.li+1,S.inkMax);}catch(e){}}
 var r=Math.max(0,S.ink/S.inkMax);
 bar.style.width=(r*100)+'%';
 bar.className='bar'+(r<.15?' low':'');
}
function buildPal(){
 var p=L().pal,h='',map={S:SOLID,B:BOUNCEM,A:BOOSTM,C:ROPE},i;
 if(p.length<2){palRow.style.display='none';return;}
 palRow.style.display='flex';
 for(i=0;i<p.length;i++){
  var m=map[p.charAt(i)];
  h+='<button class="chip'+(m===S.tool?' on':'')+'" data-m="'+m+'" '+
     'style="--c:'+matCol(m)+'">'+TOOLNAME[m]+'<em>×'+COST[m]+'</em></button>';
 }
 palRow.innerHTML=h;
 var cs=palRow.querySelectorAll('.chip');
 for(i=0;i<cs.length;i++)cs[i].onclick=function(){
  S.tool=+this.dataset.m;buildPal();Audio1.playSfx('ui_tap');};
}
function paintScrub(){
 var n=S.rec.length;
 if(n<10||S.mode==='run'){scrubRow.style.display='none';return;}
 scrubRow.style.display='flex';
 scrub.max=n-1;
 if(+scrub.value>n-1)scrub.value=n-1;
 scrubLab.textContent=(S.scrubI/60).toFixed(1)+' s';
}
function scrubTo(i){
 if(!S.rec.length)return;
 i=Math.max(0,Math.min(S.rec.length-1,i));
 var f=S.rec[i],b=S.ball;
 b.x=f[0];b.y=f[1];b.vx=f[2];b.vy=f[3];b.a=f[4];
 S.gotStar=!!f[5];S.t=i;S.scrubI=i;S.mode='rewound';
 if(f[6])qpLoad(f[6]);
 S.branch=f[7]?{x:f[7][0],y:f[7][1],vx:f[7][2],vy:f[7][3],a:f[7][4]}:null;
 S.superposed=!!S.branch;
 if(f[8])for(var q=0;q<S.ent.length;q++)S.ent[q].on=!!f[8][q];
 S.gtrail=[];
 S.trail=[];
 for(var k=Math.max(0,i-22);k<=i;k++)S.trail.push([S.rec[k][0],S.rec[k][1],Math.hypot(S.rec[k][2],S.rec[k][3])]);
 S.pathRec=[];
 for(var j=0;j<=i;j+=3)S.pathRec.push([S.rec[j][0],S.rec[j][1]]);
 FX.p=[];FX.r=[];FX.goalRing=null;S.inZone=0;S.still=0;S.squash=null;
 bPlay.textContent='Reprendre ici';
 scrubLab.textContent=(i/60).toFixed(1)+' s';
 show(vResult,false);
}
scrub.addEventListener('input',function(){Audio1.unlock();scrubTo(+this.value);});
$('zG').oninput=function(){S.gmul=+this.value;$('zGv').textContent=(+this.value).toFixed(2)+'×';};
$('zT').oninput=function(){S.tmul=+this.value;$('zTv').textContent=(+this.value).toFixed(2)+'×';};
scrub.addEventListener('change',function(){Audio1.playSfx('rewind');});

function criteria(a,b,c){
 $('c1').classList.toggle('hit',a);$('c2').classList.toggle('hit',b);$('c3').classList.toggle('hit',c);
 var ps=$('vpips').children||[],v=[a,b,c],k;for(k=0;k<ps.length;k++){ps[k].classList.toggle('on',!!v[k]);ps[k].style.animationDelay=(.25+k*.22)+'s';}
 var em=$('vResult').querySelector?$('vResult').querySelector('.rstar'):null;if(em){em.classList.toggle('lose',!a);resEmb(em,a,[a,b,c]);}}
/* emblème animé de l'écran de résultat (R52) : la particule du jeu (même nuage de points que la balle).
   Réussite : elle tourne et s'enfonce dans l'anneau vert de la zone, aspirée comme par un trou noir, en laissant une traînée.
   Échec : elle se défait en éclats rouges qui dérivent autour d'un anneau pointillé. */
var resEmbRaf=0;
var resKind='win';
function resEmb(el,ok,cr){
 if(!el.getContext){var cv2=document.createElement('canvas');cv2.className='rstar remb';el.parentNode.replaceChild(cv2,el);el=cv2;}
 if(window.VX&&VX.resAnim){   /* R192 : en-tête animé du bilan (visuals.js resAnim) — l'issue se lit dans l'image */
  var dq=Math.min(2,window.devicePixelRatio||1),RW=300,RH=150,cq=el.getContext('2d'),tq0=performance.now(),kq=resKind;el.width=RW*dq;el.height=RH*dq;cancelAnimationFrame(resEmbRaf);
  (function rq(now){if(!vResult.classList.contains('on')&&now-tq0>1500)return;cq.setTransform(dq,0,0,dq,0,0);cq.clearRect(0,0,RW,RH);try{VX.resAnim(cq,kq,RM?2.4:(now-tq0)/1000,RW,RH,cr);}catch(e){}resEmbRaf=requestAnimationFrame(rq);})(tq0);return;}
 el.classList.toggle('lose',!ok);var dpr=Math.min(2,window.devicePixelRatio||1),W2=120,H2=84;el.width=W2*dpr;el.height=H2*dpr;
 var c=el.getContext('2d'),t0=performance.now(),parts=[],k;
 for(k=0;k<26;k++)parts.push({a:Math.random()*6.28,r:18+Math.random()*26,s:.4+Math.random(),z:Math.random()});
 cancelAnimationFrame(resEmbRaf);
 (function loop(now){
  if(!vResult.classList.contains('on')&&now-t0>1500)return;   /* le panneau s'ouvre juste après : on attend un peu avant de conclure qu'il est fermé */
  var t=(now-t0)/1000,cx=W2/2,cy=H2/2,i;c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,W2,H2);
  c.save();c.globalCompositeOperation='lighter';
  var col=ok?T.goal:T.danger,sw=RM?0:t;
  /* anneaux elliptiques (la zone vue de biais) */
  for(i=0;i<3;i++){var rr=34-i*8+(ok?Math.sin(sw*2+i)*1.2:0);c.strokeStyle=col;c.globalAlpha=ok?(.55-i*.13):(.35-i*.08);c.lineWidth=ok?1.6:1.2;
   if(!ok)c.setLineDash([3,4]);c.beginPath();c.ellipse(cx,cy+6,rr,rr*.34,0,0,6.2832);c.stroke();c.setLineDash([]);}
  /* poussière : aspirée en spirale (réussite) ou dispersée (échec) */
  for(i=0;i<parts.length;i++){var p=parts[i],u=ok?((sw*.35*p.s+p.z)%1):Math.min(1,sw*.25*p.s+p.z*.2);
   var rad=ok?p.r*(1-u):p.r*(.3+u*1.2),ang=p.a+(ok?u*7:u*1.5),px=cx+Math.cos(ang)*rad,py=cy+6+Math.sin(ang)*rad*.34-(ok?0:u*8);
   c.globalAlpha=ok?(.2+.7*u):(.7*(1-u));c.fillStyle=ok?(i%3?T.matter:T.reward):T.danger;c.beginPath();c.arc(px,py,ok?1.1+u:1.3,0,6.2832);c.fill();}
  c.restore();
  /* la particule */
  var bob=ok?Math.sin(sw*1.6)*3:0,sc=ok?(.92+.08*Math.sin(sw*1.6)):Math.max(.25,1-sw*.35);
  c.save();c.globalAlpha=ok?1:Math.max(.15,1-sw*.3);
  try{drawBall(c,cx,cy-8+bob,sw*.8,11*sc,ok?null:T.danger);}catch(e){}
  c.restore();
  resEmbRaf=requestAnimationFrame(loop);})(t0);}

BUS.on('level.complete',function(){
 if(S.mode!=='run')return;
 if(S.demo){
  S.mode='success';S.demo=false;resKind='sol';
  FX.goalRing={x:S.ball.x,y:S.ball.y,r:40,l:1};ring(S.ball.x,S.ball.y,46,T.goal,2.6);
  Audio1.playSfx('level_success');
  $('rTitle').textContent=TR('solTitle');$('rSub').textContent=TR('solSub');
  criteria(true,S.gotStar,true);
  $('c3').lastElementChild.lastElementChild.textContent=TR('solSub');
  $('rStats').innerHTML='';
  $('rNext').textContent=TR('solTry');$('rNext').dataset.act='solclear';
  $('rScrub').style.display='none';$('rRetry').style.display='none';$('rReplay').style.display='';$('rSolution').style.display='none';
  setTimeout(function(){show(vResult,true);},MOT.success);
  return;
 }
 S.mode='success';
 var abs=!S.zen&&S.li<LEVELS.length-1&&window.QFX&&QFX.absorbStart(L().zone,S.ball.x,S.ball.y,S.ball.a),tk=S.absTok;   /* R287 : aspiration par l'arrivée */
 if(abs){S.absHide=true;bPlay.disabled=true;}   /* R296 : « Relancer » grisé pendant l'aspiration */   /* R287 : le son de réussite et la vibration partent à l'éclat (transitions.js) */
 function openRes(){bPlay.disabled=false;if(S.mode==='success'&&tk===S.absTok)show(vResult,true);}
 var lv=L(),used=1-S.ink/S.inkMax,pure=S.reprises===0;JR.w++;JR.m+=Math.max(0,S.inkMax-S.ink);
 var n=1+(S.gotStar?1:0)+(pure?1:0);
 if(n>S.best[S.li])S.best[S.li]=n;
 paintGStars();
 var pct=Math.round(used*100);
 if(!S.bestMat[S.li]||pct<S.bestMat[S.li])S.bestMat[S.li]=pct;
 if(S.li+1>S.unlocked)S.unlocked=Math.min(S.li+1,LEVELS.length-1);
 persist();
 FX.goalRing={x:S.ball.x,y:S.ball.y,r:40,l:1};
 ring(S.ball.x,S.ball.y,46,T.goal,2.6);
 Audio1.playMusicState('success');if(!abs){Audio1.playSfx('level_success');Audio1.buzz([14,60,24]);}
 var last=S.li>=LEVELS.length-1;resKind=last?'complete':'win';
 $('rTitle').textContent=last?TR('complete'):TR('succeeded');
 $('rSub').textContent=last?TR('completeSub'):lv.n;
 if(last){S.finT=S.tick||0;try{Audio1.playSfx('level_success');}catch(e){}}
 criteria(true,S.gotStar,pure);
 $('rRetry').style.display=(lv.star&&!S.gotStar)?'':'none';if(lv.star&&!S.gotStar)coreIcoStart();   /* R302 : noyau manqué → rejouer le niveau d'un geste */
 $('c3').lastElementChild.lastElementChild.textContent=
   pure?TR('oneShot'):S.reprises+' '+TR(S.reprises>1?'usedRewinds':'usedRewind');   /* R201 : plus de français en dur */
 $('rStats').innerHTML='<span><b>'+pct+' %</b><i>'+TR('r_matter')+'</i></span><span><b>'+(S.frames/60).toFixed(1)+' s</b><i>'+TR('r_time')+'</i></span>';   /* R192 : deux mesures, rien de plus */
 $('vResult').classList.toggle('jfinal',last);if(last){$('rStats').innerHTML=jrHTML();persist();}   /* R208 : bilan final = le parcours entier */
 $('rNext').textContent=last?TR('restartAll'):TR('next');
 $('rNext').dataset.act=last?'restart':'next';
 $('rScrub').style.display='none';
 resultExtras();
 if(last){app.classList.add('fin');setTimeout(finCine,abs?3300:1500);}   /* R202 : prélude dans le niveau, puis la scène « Retour à l'équilibre » en plein écran */
 else setTimeout(openRes,abs?3000:MOT.success);   /* R201 : la naissance d'abord, puis le générique holographique, le bilan sur demande */
});
BUS.on('rail.enter',function(e){try{Audio1.playSfx('rail_in');}catch(x){}});
BUS.on('rail.exit',function(e){try{Audio1.playSfx('rail_out');}catch(x){}});
BUS.on('ball.fail',function(e){
 if(S.mode!=='run')return;
 if(S.zen){burst(e.x,e.y,10,T.violet,2);resetBall();return;}
 JR.f++;S.mode='fail';S.trace=S.pathRec.slice();
 burst(e.x,e.y,14,e.reason==='spike'?T.danger:T.muted,2.4);
 Audio1.playMusicState('failure');
 Audio1.playSfx(e.reason==='spike'?'spike_hit':'level_fail');
 Audio1.buzz(26);
 var msg={spike:[TR('failSpike'),TR('failSpikeD')],
          stuck:[TR('failStuck'),TR('failStuckD')],
          out:[TR('failOut'),TR('failOutD')],
          long:[TR('failLong'),TR('failLongD')]}[e.reason];
 resKind=e.reason;$('rTitle').textContent=msg[0];
 $('rSub').textContent=msg[1];
 criteria(false,S.gotStar,false);
 $('c3').lastElementChild.lastElementChild.textContent=TR('failMastery');
 $('rStats').innerHTML='';   /* R192 : l'en-tête animé suffit (demande de Simon) */
 $('vResult').classList.remove('jfinal');
 $('rNext').textContent=TR('retryLevel');$('rNext').dataset.act='retry';
 $('rScrub').style.display='';$('rRetry').style.display='none';
 resultExtras();
 $('rContinue').style.display=e.reason==='long'?'':'none';
 setTimeout(function(){show(vResult,true);paintScrub();},300);
});

$('rNext').onclick=function(){
 Audio1.playSfx('ui_confirm');show(vResult,false);
 var a=this.dataset.act;
 if(a==='retry')resetBall();
 else if(a==='solclear')clearAll();
 else if(a==='restart')loadLevel(0);
 else if(S.zen)resetBall();
 else advance(S.li);
};
$('rRetry').onclick=function(){Audio1.playSfx('ui_confirm');show(vResult,false);loadLevel(S.li);};
$('rScrub').onclick=function(){
 Audio1.playSfx('rewind');show(vResult,false);
 paintScrub();scrub.value=Math.max(0,S.rec.length-40);scrubTo(+scrub.value);
};

/* Revoir ma partie : relit S.rec image par image, sans physique ni événement. */
/* vol trop long (rebond sans fin) : 20 s à 60 images/s, puis Recommencer ou Continuer */
var LONGRUN=1200;
function resultExtras(){
 $('rContinue').style.display='none';
 $('rReplay').style.display=S.rec.length>10?'':'none';
 $('rSolution').style.display=L().optsol?'':'none';}
function replayStep(){
 if(S.replayI>=S.rec.length){S.mode=S.replayEnd;show(vResult,true);return;}
 var f=S.rec[S.replayI++],b=S.ball;
 b.x=f[0];b.y=f[1];b.vx=f[2];b.vy=f[3];b.a=f[4];S.gotStar=!!f[5];
 if(f[6])qpLoad(f[6]);
 S.trail.push([b.x,b.y,Math.hypot(b.vx,b.vy)]);if(S.trail.length>22)S.trail.shift();}
$('rContinue').onclick=function(){
 Audio1.playSfx('ui_confirm');show(vResult,false);S.mode='run';S.longAt=S.frames+LONGRUN;};
/* R201 · générique holographique de fin : remerciements, crédits, lien de soutien (KOFI vide = bouton masqué) */
var KOFI='';
/* R202 · scène de fin plein écran : QHERO.epilogue (hero.js) ; le texte vient quand la particule est à l'état fondamental */
function finCine(){if(S.finT==null||app.dataset.screen!=='game'||!app.classList.contains('fin'))return;var cv=$('finCv');if(!cv||!window.QHERO||!QHERO.epilogue){finShow();return;}
 var dpr=Math.min(2,window.devicePixelRatio||1),w=app.clientWidth,h=app.clientHeight,cx=cv.getContext('2d'),shown=false;cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);
 QHERO.epReset();app.classList.add('fincv');try{if(window.QFINS){QFINS.set(OPT.mus!==false);if(OPT.mus!==false){QFINS.unlock();QFINS.vol(Math.min(1,.35+OPT.musVol*1.3));Audio1.setMusicVol(0);}}if(window.QHAP)QHAP.set(OPT.hap!==false);}catch(e){}   /* R234 : bande son de la fin, la musique du monde se tait ; vibrations de la fin (hero.js vib5) */var SOL=[];for(var si=0;si<LEVELS.length;si++)if(S.best[si]>0)SOL.push(Math.max(0,(LEVELS[si].wd||1)-1));   /* R203 : un point par expérience réussie, à la couleur de son monde */
 (function fl(){if(!app.classList.contains('fincv'))return;cx.setTransform(dpr,0,0,dpr,0,0);var r=null;try{r=QHERO.epilogue(cx,w,h,performance.now(),{solved:SOL,title:TR('fin_title')});}catch(e){console.error('épilogue:',e);}
  if(window.QFINS&&r)QFINS.sync(r.t,true,1);
  if(!shown&&(!r||r.ground)){shown=true;finShow();}requestAnimationFrame(fl);})();}
function finStop(){try{if(window.QFINS&&app.classList.contains('fincv')){QFINS.stop();Audio1.setMusicVol(OPT.mus!==false?OPT.musVol:0);}}catch(e){}app.classList.remove('fin');app.classList.remove('fincv');try{if(window.QHERO&&QHERO.reset)QHERO.reset();}catch(e){}}
function finShow(){var v=$('vFin');if(!v)return show(vResult,true);var a=$('finKofi');if(a){if(KOFI){a.href=KOFI;a.style.display='';}else a.style.display='none';}show(v,true);}
if($('finRes'))$('finRes').onclick=function(){show($('vFin'),false);finStop();show(vResult,true);};
$('rReplay').onclick=function(){
 Audio1.playSfx('ui_tap');show(vResult,false);
 S.replayEnd=S.mode;S.replayI=0;S.trail=[];S.gotStar=false;FX.p=[];FX.r=[];FX.goalRing=null;
 S.mode='replay';tip.textContent=TR('replayTip');};
/* Voir la solution optimale : trace optsol, lâche la balle, n'enregistre rien. */
$('rSolution').onclick=function(){
 var lv=L();if(!lv.optsol)return;
 Audio1.playSfx('ui_confirm');show(vResult,false);
 S.strokes=[];var used=0,late=[];
 for(var i=0;i<lv.optsol.length;i++){var p=lv.optsol[i],len=0;
  for(var k=1;k<p.length;k++)len+=Math.hypot(p[k][0]-p[k-1][0],p[k][1]-p[k-1][1]);
  var om=(lv.optmats&&lv.optmats[i]!==undefined)?lv.optmats[i]:(lv.optmat||0);   /* R300 : matière propre à chaque trait de la solution */
  used+=len*(COST[om]||1);var st={pts:p.map(function(q){return[q[0],q[1]];}),len:len,birth:S.tick,mat:om};
  if(lv.optat&&lv.optat[i]>0)late.push({at:lv.optat[i],st:st});else S.strokes.push(st);}   /* R301 : trait tracé pendant la course */
 S.cur=null;S.ink=Math.max(0,S.inkMax-used);paintEnergy();qpBuild();resetBall();
 S.late=late;S.demo=true;S.mode='run';bPlay.textContent='Relancer';
 tip.textContent=TR('solDemo');BUS.emit('ball.launch',{});};

bPlay.onclick=function(){
 Audio1.unlock();
 if(window.QFX)QFX.skip();   /* R287 : lâcher la balle termine l'entrée */
 if(S.mode==='draw'){
  S.mode='run';bPlay.textContent='Relancer';
  BUS.emit('ball.launch',{});
  tip.textContent='Tu peux encore déposer de la matière pendant la chute.';
  paintScrub();
 }else if(S.mode==='rewound'){
  if(S.scrubI<S.rec.length-1){S.reprises++;JR.r++;}
  S.rec.length=S.scrubI+1;
  S.mode='run';bPlay.textContent='Relancer';
  Audio1.playSfx('ball_launch');Audio1.playMusicState('run');
  paintScrub();
 }else resetBall();
};
function undoSync(){if(window.EDT)EDT.sync();else bUndo.disabled=!S.strokes.length;}
function clearAll(keep){
 if(keep&&window.EDT)EDT.pushClear();
 S.strokes=[];S.cur=null;S.ink=S.inkMax;paintEnergy();resetBall();tip.textContent=L().tip||'';
 if(window.EDT)EDT.afterClear(keep);}
bClear.onclick=function(){Audio1.unlock();Audio1.playSfx('ui_tap');clearAll(true);};
bUndo.onclick=function(){
 Audio1.unlock();
 if(window.EDT&&EDT.undo())return;
 if(!S.strokes.length)return;
 var s=S.strokes.pop(),pts=s.pts,i;
 S.ink=Math.min(S.inkMax,S.ink+s.len);paintEnergy();
 for(i=0;i<pts.length;i+=2)spawn(pts[i][0],pts[i][1],(W-24-pts[i][0])*.012,(14-pts[i][1])*.012,36,1.6,T.matter);
 qpBuild();Audio1.playSfx('ui_tap');undoSync();
 if(S.mode==='run'||S.mode==='fail'||S.mode==='success')resetBall();
};
bSlow.onclick=function(){
 S.slow=!S.slow;bSlow.classList.toggle('on',S.slow);
 bSlow.setAttribute('aria-pressed',S.slow?'true':'false');Audio1.playSfx('ui_tap');};
$('gPause').onclick=function(){
 Audio1.playSfx('ui_tap');
 $('pSub').textContent=S.zen?'Zen Lab · laboratoire libre':(L().n+' · monde '+L().wd+' — '+TH().n);show(vPause,true);};
$('gBack').onclick=function(){
 Audio1.playSfx('ui_tap');
 if(S.zen){S.zen=false;S.useShape=false;S.gmul=1;S.tmul=1;$('zenRow').style.display='none';loadLevel(S.li);goto('home');return;}
 openWorld(L().wd);   /* R136 : le retour ramène à la page illustrée du monde */
};
$('pResume').onclick=function(){show(vPause,false);};
$('pRestart').onclick=function(){show(vPause,false);if(S.zen){S.strokes=[];S.cur=null;resetBall();}else clearAll();};
$('pLevels').onclick=function(){show(vPause,false);openMap(S.zen?0:L().wd);};
$('pSet').onclick=function(){show(vPause,false);show(vSet,true);auRefresh();};
$('pHome').onclick=function(){show(vPause,false);goto('home');};

/* --- carte : dix mondes, puis douze expériences --- */
var mapW=0;
function openMap(w){mapW=(w===undefined)?0:w;drawMap();show(vLevels,true);}
function drawMap(){
 var h='',i,k;
 if(!mapW){
  $('mapTitleTop').textContent=TR('worlds');
  $('mapTitle').textContent='';
  $('mapSub').textContent=TR('mapWorldsSub');
  var POS=(typeof CPOS!=='undefined')?CPOS.map(function(p){return [p[0]*100,p[1]*100];})
        :[[13,72],[27,45],[44,64],[57,33],[72,52],[86,26],[90,63],[74,82],[55,88],[33,84],[50,58]];
  var sv='<svg viewBox="0 0 100 100" preserveAspectRatio="none">';
  for(i=1;i<POS.length;i++){
   var p0=POS[i-1],p1=POS[i],op=wStats(i).first<=S.unlocked;
   sv+='<line x1="'+p0[0]+'" y1="'+p0[1]+'" x2="'+p1[0]+'" y2="'+p1[1]+
       '" stroke="'+(op?WORLDS[i-1].c:'#253443')+'" stroke-opacity="'+(op?.42:.55)+
       '" stroke-width="1" vector-effect="non-scaling-stroke"/>';
  }
  sv+='<line x1="'+POS[9][0]+'" y1="'+POS[9][1]+'" x2="'+POS[10][0]+'" y2="'+POS[10][1]+
      '" stroke="#A878FF" stroke-opacity=".4" stroke-dasharray="2 3" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>';
  var bgs=(typeof CONSTEL!=='undefined')?' class="lit" style="background-image:url('+CONSTEL+')"':'';
  h='<div id="starmap"'+bgs+'>'+sv;
  for(i=1;i<=WORLDS.length;i++){
   var w=WORLDS[i-1],st=wStats(i),lock=st.first>S.unlocked,pp=POS[i-1];
   var cls='star'+(lock?'':' open')+(st.done?' done':'')+(st.mast>=6?' mast':'');
   h+='<button class="'+cls+'" data-w="'+i+'" style="--c:'+w.c+';left:'+pp[0]+'%;top:'+pp[1]+'%" '+
      (lock?'disabled aria-label="Monde verrouillé"':'aria-label="'+w.n+', '+st.done+' sur '+st.tot+'"')+
      '><span class="halo"></span><span class="core"></span>'+
      '<span class="nm">'+(lock?'—':WN(i-1))+'</span></button>';
  }
  h+='</div>';
  $('mapBody').innerHTML=h;
  var ws=$('mapBody').querySelectorAll('.star');
  for(i=0;i<ws.length;i++)ws[i].onclick=function(){
   Audio1.playSfx('ui_tap');openWorld(+this.dataset.w);};
  $('mapBack').style.display='none';
  return;
 }
 var wd=WORLDS[mapW-1],rg=worldRange(mapW);
 $('mapTitle').textContent=(LANG==='en'?'World ':'Monde ')+mapW+' — '+WN(mapW-1);
 $('mapSub').textContent=WE(mapW-1);
 if(WART[mapW])h+='<div class="wbanner" style="background-image:'+
   'linear-gradient(180deg,rgba(8,12,19,.30),rgba(8,12,19,.92)),url('+WART[mapW]+');background-position:center,center '+Math.round(((WMETA[mapW]||{}).fy||.5)*100)+'%"></div>';
 h+='<div class="lvgrid">';
 for(k=0;k<rg.length;k++){
  var idx=rg[k],lock=idx>S.unlocked,pips='';
  for(i=0;i<3;i++)pips+='<i class="'+(i<S.best[idx]?'on':'')+'"></i>';
  h+='<button class="cell'+(lock?' lock':(S.best[idx]?' done':' open'))+'" data-i="'+idx+'" '+
     (lock?'disabled aria-label="Verrouillé"':'aria-label="'+LEVELS[idx].n+'"')+
     ' style="--c:'+wd.c+'">'+(lock?ico('lock',15):(k+1))+
     '<div class="pips">'+pips+'</div></button>';
 }
 h+='</div>';
 $('mapBody').innerHTML=h;
 var cs=$('mapBody').querySelectorAll('.cell');
 for(i=0;i<cs.length;i++)cs[i].onclick=function(){
  Audio1.playSfx('ui_confirm');show(vLevels,false);goto('game');loadLevel(+this.dataset.i);};
 $('mapBack').style.display='';
}
/* ══ CARTE DE MONDE ══
   L'image du monde est la carte. Les niveaux forment une constellation vectorielle
   posée DANS LE REPÈRE DE L'IMAGE (SVG, viewBox = dimensions de l'image) :
   les ronds restent collés à la composition quelle que soit la taille d'écran.
   Validé : clair et lumineux. À valider : sombre. */
var curW=1,advT=0,advFn=null;
function genNodes(){var a=[],i;for(i=0;i<12;i++){var t=i/11;a.push([.5+.27*Math.sin(t*Math.PI*2.2),.86-.66*t]);}return a;}
function wState(idx,firstOpen){
 if(S.best[idx]>0)return 'done';
 if(idx>S.unlocked)return 'lock';
 return idx===firstOpen?'cur':'open';
}
function openWorld(w,opt){
 opt=opt||{};curW=w;
 var wm=WMETA[w],art=!!(WART[w]&&wm&&wm.nodes);
 var iw=art?wm.iw:420,ih=art?wm.ih:747,nodes=art?wm.nodes:genNodes();
 var rg=worldRange(w),col=WORLDS[w-1].c,i,firstOpen=-1;
 for(i=0;i<rg.length;i++)if(rg[i]<=S.unlocked&&!S.best[rg[i]]){firstOpen=rg[i];break;}
 var fy=art?wm.fy:.5,par='xMidY'+(fy<.42?'Min':(fy>.58?'Max':'Mid'))+' slice';
 var P=nodes.map(function(p){return [p[0]*iw,p[1]*ih];});
 /* tailles proportionnelles à l'image : un rond doit garder la même
    taille apparente que l'illustration fasse 340 ou 900 pixels de large */
 var NR=iw*0.030, HR=NR*2.3, FS=iw*0.027, LW=iw*0.0026, LWD=iw*0.0032;
 var h='<svg class="wsvg" viewBox="0 0 '+iw+' '+ih+'" preserveAspectRatio="'+par+'" style="--wc:'+col+'">';
 if(art)h+='<image href="'+WART[w]+'" x="0" y="0" width="'+iw+'" height="'+ih+'" preserveAspectRatio="xMidYMid slice"/>';
 else h+='<defs><radialGradient id="wg" cx="50%" cy="38%" r="70%"><stop offset="0" stop-color="'+col+'" stop-opacity=".35"/>'+
        '<stop offset="1" stop-color="#05070D" stop-opacity="1"/></radialGradient></defs><rect width="'+iw+'" height="'+ih+'" fill="url(#wg)"/>';
 /* dégradés partagés : sphère de verre des nœuds (ouvert / réussi / verrouillé) */
 h+='<defs><radialGradient id="ngO" cx="40%" cy="34%" r="72%"><stop offset="0" stop-color="#EAF9FF" stop-opacity=".92"/>'+
    '<stop offset=".45" stop-color="'+col+'" stop-opacity=".42"/><stop offset="1" stop-color="'+col+'" stop-opacity=".08"/></radialGradient>'+
    '<radialGradient id="ngD" cx="40%" cy="34%" r="72%"><stop offset="0" stop-color="#FFFBEA" stop-opacity=".95"/><stop offset=".45" stop-color="#FFD85A" stop-opacity=".34"/>'+
    '<stop offset="1" stop-color="#FFD85A" stop-opacity=".04"/></radialGradient>'+
    '<radialGradient id="ngL" cx="40%" cy="35%" r="72%"><stop offset="0" stop-color="#9AA9BA" stop-opacity=".38"/><stop offset="1" stop-color="#0B1220" stop-opacity=".22"/></radialGradient>'+
    '<radialGradient id="nbk" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#05090F" stop-opacity=".62"/><stop offset=".7" stop-color="#05090F" stop-opacity=".32"/><stop offset="1" stop-color="#05090F" stop-opacity="0"/></radialGradient><radialGradient id="nhal" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="'+col+'" stop-opacity=".5"/><stop offset=".55" stop-color="'+col+'" stop-opacity=".14"/><stop offset="1" stop-color="'+col+'" stop-opacity="0"/></radialGradient></defs>';
 /* voile de charte posé sur l'illustration : ombres nuit en haut et en bas, lisibilité des nœuds */
 if(art)h+='<defs><linearGradient id="wveil" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#05070D" stop-opacity=".55"/>'+
    '<stop offset=".3" stop-color="#05070D" stop-opacity=".05"/><stop offset=".75" stop-color="#05070D" stop-opacity=".12"/>'+
    '<stop offset="1" stop-color="#05070D" stop-opacity=".7"/></linearGradient></defs><rect width="'+iw+'" height="'+ih+'" fill="url(#wveil)"/>';
 for(i=0;i<P.length-1;i++){
  var st=S.best[rg[i]]>0?'done':'dim',xy='x1="'+P[i][0].toFixed(1)+'" y1="'+P[i][1].toFixed(1)+'" x2="'+P[i+1][0].toFixed(1)+'" y2="'+P[i+1][1].toFixed(1)+'"';
  h+='<line class="wlg '+st+'" style="stroke-width:'+(LWD*3.4).toFixed(2)+'" '+xy+'/>';
  h+='<line class="wl '+st+'" id="wl'+i+'" style="stroke-width:'+(st==='done'?LWD:LW).toFixed(2)+'" '+xy+'/>';
  h+='<line class="wlf '+st+'" style="stroke-width:'+(LW*.9).toFixed(2)+';stroke-dasharray:'+(iw*.012).toFixed(1)+' '+(iw*.03).toFixed(1)+'" '+xy+'/>';
  if(st==='done')h+='<circle class="wph" r="'+(NR*.085).toFixed(1)+'"><animateMotion dur="'+(1.8+i%3*.4)+'s" repeatCount="indefinite" '+
     'path="M'+P[i][0].toFixed(1)+','+P[i][1].toFixed(1)+' L'+P[i+1][0].toFixed(1)+','+P[i+1][1].toFixed(1)+'"/></circle>';
 }
 for(i=0;i<P.length;i++){
  var ws=wState(rg[i],firstOpen);
  var dots='',k2;for(k2=0;k2<16;k2++){var yy=1-2*(k2+.5)/16,rr=Math.sqrt(1-yy*yy),aa=k2*2.39996;
   dots+='<circle class="nd" cx="'+(Math.cos(aa)*rr*NR*.78).toFixed(1)+'" cy="'+(yy*NR*.78).toFixed(1)+'" r="'+(NR*.04).toFixed(2)+'"/>';}
  var tilt=-28+(i%3)*14,dur=(7+i%4*1.5).toFixed(1);
  h+='<g class="wn '+ws+'" id="wn'+i+'" data-i="'+rg[i]+'" transform="translate('+P[i][0].toFixed(1)+','+P[i][1].toFixed(1)+')">'+
     '<circle class="bk" r="'+(NR*1.32).toFixed(1)+'"/><circle class="halo" r="'+HR.toFixed(1)+'" style="animation-delay:-'+(i*.83).toFixed(2)+'s"/>'+
     '<g transform="rotate('+tilt+')"><g class="orb"><animateTransform attributeName="transform" type="rotate" from="0" to="'+(i%2?-360:360)+'" dur="'+dur+'s" repeatCount="indefinite"/>'+
     '<ellipse class="ring" rx="'+(NR*1.95).toFixed(1)+'" ry="'+(NR*.6).toFixed(1)+'" style="stroke-width:'+(NR*.028).toFixed(2)+'"/>'+
     '<circle class="el" cx="'+(NR*1.95).toFixed(1)+'" r="'+(NR*.075).toFixed(1)+'"/></g></g>'+
     '<circle class="core" r="'+NR.toFixed(1)+'" style="stroke-width:'+(NR*.035).toFixed(2)+'"/>'+
     '<g class="cloud"><animateTransform attributeName="transform" type="rotate" from="0" to="360" dur="14s" repeatCount="indefinite"/>'+dots+'</g>'+
     '<text y="'+(FS*.06).toFixed(1)+'" style="font-size:'+FS.toFixed(1)+'px">'+(i+1)+'</text></g>';
 }
 h+='</svg>';
 $('wMap').innerHTML=h;
 var st2=wStats(w),stars=0;for(i=0;i<rg.length;i++)stars+=S.best[rg[i]]||0;
 $('wNum').textContent=(LANG==='en'?'WORLD ':'MONDE ')+(w<10?'0':'')+w;
 $('wName').textContent=WN(w-1);
 $('wEl').textContent=WE(w-1);
 $('wStat').textContent=st2.done+' / '+st2.tot+'  ·  '+stars+' ★';
 $('wHint').textContent=TR(opt.from!==undefined?'mapNext':'mapPick');
 app.style.setProperty('--accent',col);
 /* ouvrir un niveau en touchant son rond */
 var gs=$('wMap').querySelectorAll?$('wMap').querySelectorAll('.wn'):[];
 for(i=0;i<gs.length;i++)gs[i].onclick=function(ev){
  if(ev&&ev.stopPropagation)ev.stopPropagation();
  var idx=+this.getAttribute('data-i');
  if(idx>S.unlocked){Audio1.playSfx('ui_tap');return;}
  cancelAdvance();Audio1.unlock();Audio1.playSfx('ui_confirm');
  show(vWorld,false);S.zen=false;goto('game');loadLevel(idx);
 };
 show(vLevels,false);show(vWorld,true);
 /* après une réussite : le rond s'allume, la ligne se trace vers le suivant */
 if(opt.from!==undefined){
  var k=rg.indexOf(opt.from);
  if(k>=0){
   var n0=$('wMap').querySelector?$('wMap').querySelector('#wn'+k):null,
       l0=$('wMap').querySelector?$('wMap').querySelector('#wl'+k):null,
       n1=$('wMap').querySelector?$('wMap').querySelector('#wn'+(k+1)):null;
   if(n0){n0.setAttribute('class','wn cur');}
   if(l0){var L0=Math.hypot(P[k+1][0]-P[k][0],P[k+1][1]-P[k][1]);
    l0.setAttribute('class','wl done');l0.style.strokeDasharray=L0;l0.style.strokeDashoffset=L0;}
   if(n1)n1.setAttribute('class','wn lock');
   setTimeout(function(){if(n0)n0.setAttribute('class','wn done pop');Audio1.playSfx('map_done');},380);
   setTimeout(function(){if(l0){l0.style.transition='stroke-dashoffset .7s ease-out';l0.style.strokeDashoffset=0;}},760);
   setTimeout(function(){if(n1){n1.setAttribute('class','wn cur pop');Audio1.playSfx('map_next');}},1420);
  }
 }
}
function cancelAdvance(){if(advT){clearTimeout(advT);advT=0;}advFn=null;}
/* après chaque niveau : la carte, l'animation, puis le niveau suivant */
function advance(li){
 var w=LEVELS[li].wd,nx=li+1;
 openWorld(w,{from:li});
 cancelAdvance();
 if(nx>=LEVELS.length)return;
 var same=LEVELS[nx].wd===w;
 advFn=function(){
  cancelAdvance();
  if(!vWorld.classList.contains('on'))return;
  if(same){show(vWorld,false);goto('game');loadLevel(nx);}
  else openWorld(LEVELS[nx].wd);   /* monde suivant : sa carte sert d'introduction */
 };
 advT=setTimeout(advFn,2600);
}
$('wBack').innerHTML=ico('back',19);
$('wBack').onclick=function(ev){if(ev&&ev.stopPropagation)ev.stopPropagation();
 cancelAdvance();Audio1.playSfx('ui_tap');show(vWorld,false);openMap(0);};
/* toucher la carte pendant l'animation passe directement à la suite */
$('wMap').onclick=function(){if(advFn)advFn();};
$('mapBack').onclick=function(){Audio1.playSfx('ui_tap');mapW=0;drawMap();};
$('lvClose').onclick=function(){show(vLevels,false);show(vWorld,false);goto('home');};   /* R145 : fermer la constellation ramène à l'accueil */

/* --- accueil --- */
function auTxt(){
 var ses=Audio1.session?Audio1.session():'?';
 var tag=(ses==='playback')?' · session playback':' · session '+ses;
 if(window.__QXSAMPLES)
  return [Audio1.sampReady&&Audio1.sampReady()?('voie échantillons active'+tag):
   ('voie échantillons — '+(Audio1.sampErr&&Audio1.sampErr()||'en attente d’un appui')+tag),
   Audio1.sampReady&&Audio1.sampReady()?'#9BEB4B':'#FFAA3C'];
 var st=Audio1.state?Audio1.state():'inconnu';
 var md=Audio1.media?Audio1.media():true;
 if(st!=='running'){
  var fr={suspended:'audio bloqué par le navigateur',
   inactif:'audio en attente d’un appui','non supporté':'audio non supporté'};
  return [fr[st]||st,'#FFAA3C'];
 }
 if(!md)return ['voie synthèse'+tag+' · sortie sonnerie','#FFAA3C'];
 return ['actif, voie média'+tag,'#9BEB4B'];
}
function auLine(){
 var e=$('auHome');if(!e)return;e.style.display='none';return;   /* R154 : ligne de diagnostic du son retirée de l'accueil (demande de Simon) */
 var r=auTxt();e.textContent='◈ '+r[0];e.style.color=r[1];
}
function paintHome(){
 auLine();
 var done=0,mast=0,i;
 for(i=0;i<LEVELS.length;i++){if(S.best[i])done++;if(S.best[i]>=3)mast++;}
 $('hDone').textContent=done+' / '+LEVELS.length;
 $('hMast').textContent=mast;
 $('hChap').textContent=WN(LEVELS[S.seen].wd-1);
 $('hContName').textContent=S.seen>0?TR('continueQ'):TR('play');
 $('hContSub').textContent=WN(LEVELS[S.seen].wd-1)+' · '+(wPos(S.seen)+1)+' / 12 · '+LN(S.seen);   /* R188 : bouton Visière — titre court, parcours en sous-ligne */
}
$('hCont').onclick=function(){Audio1.unlock();setTimeout(auLine,400);Audio1.playSfx('ui_confirm');goto('game');loadLevel(S.seen);};

$('hLev').onclick=function(){Audio1.unlock();Audio1.playSfx('ui_tap');openMap(0);};
function soon(title,body){
 $('mapTitleTop').textContent=title;$('mapSub').textContent=body;
 $('mapBody').innerHTML='<p class="note" style="margin:18px 0 4px">Ce mode n’est pas encore construit. '+
  'Il est annoncé ici parce qu’il fait partie de la direction du projet, pas parce qu’il est jouable.</p>';
 $('mapBack').style.display='';show(vLevels,true);}
$('hZen').onclick=function(){
 Audio1.unlock();Audio1.playSfx('ui_confirm');
 S.zen=true;S.gmul=1;S.tmul=1;
 goto('game');
 $('expName').textContent=TR('zenTitle');
 $('expSub').textContent=TR('zenSub');
 app.style.setProperty('--accent','#A678FF');
 $('zenRow').style.display='flex';
 S.ink=S.inkMax=ZEN.ink;S.strokes=[];S.cur=null;S.trace=[];
 S.tool=SOLID;buildPal();paintEnergy();resetBall();
 if(window.EDT)EDT.onLoad();
 tip.textContent=ZEN.tip;
};
var DROPS=[
 ['Aucune reprise','Résous d’un seul jet, sans revenir dans le temps.'],
 ['Sobriété','Utilise moins de la moitié de la matière disponible.'],
 ['Le noyau','Récupère le noyau en plus d’atteindre la zone.'],
 ['Trait unique','Un seul dépôt de matière, sans lever le doigt.']
];
function dropSeed(d){var x=(d*1103515245+12345)&0x7fffffff;return (x>>7)&0x7fffffff;}
$('hDrop').onclick=function(){
 Audio1.unlock();Audio1.playSfx('ui_tap');
 var day=Math.floor(Date.now()/864e5),sd=dropSeed(day);
 var idx=sd%LEVELS.length, cst=DROPS[sd%DROPS.length];
 S.drop={day:day,idx:idx,cst:cst};
 $('mapTitleTop').textContent=TR('dropTitle')+(day-20300);
 $('mapTitle').textContent=LN(idx);
 $('mapSub').textContent=WN(LEVELS[idx].wd-1)+' · '+(LANG==='en'?'experiment ':'expérience ')+(idx+1);
 $('mapBody').innerHTML=
  '<div class="world a1" style="--c:#A678FF;margin-top:6px">'+
  '<span class="wnum">◈</span><span class="wtxt"><b>'+cst[0]+'</b><em>'+cst[1]+'</em></span></div>'+
  '<p class="note" style="margin:12px 0 0">La même expérience et la même contrainte pour tout le monde aujourd’hui. '+
  'La graine vient de la date : elle change demain.</p>'+
  '<button class="pill solid" id="dropGo" style="margin-top:16px">Tenter</button>';
 $('mapBack').style.display='none';
 show(vLevels,true);
 $('dropGo').onclick=function(){
  Audio1.playSfx('ui_confirm');show(vLevels,false);
  S.zen=false;$('zenRow').style.display='none';
  goto('game');loadLevel(idx);
  tip.textContent='Quantum Drop — '+cst[0]+' : '+cst[1];
 };
};
$('hSet').onclick=function(){Audio1.unlock();Audio1.playSfx('ui_tap');show(vSet,true);auRefresh();};
$('auHome').style.cursor='pointer';
$('auHome').onclick=function(){
 window.__QXSAMPLES=!window.__QXSAMPLES;
 Audio1.unlock();Audio1.playSfx('ui_confirm');
 setTimeout(function(){auLine();$('auHome').textContent+=window.__QXSAMPLES?'  (touche pour revenir à la synthèse)':'  (touche pour essayer les échantillons)';},450);
};
$('setClose').onclick=function(){show(vSet,false);};

/* ══ ATELIER SONORE ══ mode caché : cinq appuis sur le tampon de version.
   Règle l'ambiance du monde courant à chaud et recopie les valeurs. */
var vLab=$('vLab'),labTaps=0,labT=0;
var LABP=[['bpm','tempo',40,120,1,' bpm'],['root','fondamentale',36,64,1,''],
          ['cut','filtre',200,2000,10,' Hz'],['det','désaccord',1,1.03,.001,'×'],
          ['dens','densité',0,1,.02,'']];
var LABMODES=['eolien','dorien','phrygien','lydien','mixolydien','pentatonique'];
function labDraw(){
 var p=Audio1.params&&Audio1.params();
 if(!p){$('labP').innerHTML='<p class="note">Touche l’écran une fois pour activer l’audio, puis rouvre.</p>';return;}
 var h='',i;
 for(i=0;i<LABP.length;i++){var d=LABP[i];
  h+='<label class="labrow"><span>'+d[1]+'</span><input type="range" data-k="'+d[0]+'" min="'+d[2]+
     '" max="'+d[3]+'" step="'+d[4]+'" value="'+p[d[0]]+'"><b id="lb_'+d[0]+'">'+p[d[0]]+d[5]+'</b></label>';}
 $('labP').innerHTML=h;
 $('labWorld').textContent=WN(Audio1.world())+' · '+p.mode+' · '+p.bpm+' bpm';
 $('labMode').textContent=p.mode;
 $('labNote').textContent=TR('labHint');
 var ins=$('labP').querySelectorAll('input');
 for(i=0;i<ins.length;i++)ins[i].oninput=function(){
  var k=this.dataset.k,v=+this.value,d2;
  for(var j=0;j<LABP.length;j++)if(LABP[j][0]===k)d2=LABP[j];
  $('lb_'+k).textContent=(d2[4]<1?v.toFixed(3):v)+d2[5];
  var o={};o[k]=v;Audio1.tune(o);
 };
}
function openLab(){Audio1.unlock();show(vLab,true);setTimeout(labDraw,120);}
$('labMode').onclick=function(){
 var p=Audio1.params&&Audio1.params();if(!p)return;
 var i=LABMODES.indexOf(p.mode);
 Audio1.tune({mode:LABMODES[(i+1)%LABMODES.length]});labDraw();};
$('labCopy').onclick=function(){
 var p=Audio1.params&&Audio1.params();if(!p)return;
 var t=JSON.stringify(p);
 try{console.log('QUANTIX · ambiance monde '+(Audio1.world()+1)+' :',t);}catch(e){}
 try{navigator.clipboard&&navigator.clipboard.writeText(t);}catch(e){}
 $('labNote').textContent=t;};
$('labClose').onclick=function(){show(vLab,false);};
if($('buildTag'))$('buildTag').onclick=function(){
 clearTimeout(labT);labTaps++;
 labT=setTimeout(function(){labTaps=0;},1200);
 if(labTaps>=5){labTaps=0;Audio1.playSfx('ui_confirm');openLab();}
};

/* ══ ATELIER DE PARTICULE ══
   Motif : cosmétique, visible partout, sans effet physique.
   Forme : devient un corps mou dans le Zen Lab uniquement — la campagne
   reste calibrée pour un disque de rayon 10,5. */
var SKIN_IMG=null,SHAPE=null;
var PEDIT={mode:'skin',strokes:[],cur:null,col:'#4DD7FF',outline:null};
var PCOL=['#4DD7FF','#A678FF','#9BEB4B','#FFD85A','#FFAA3C','#FF5252','#F1F4F6','#05070D'];
function skinBuild(){
 SKIN_IMG=null;
 if(!PEDIT.strokes.length)return;
 try{
  var oc=document.createElement('canvas');oc.width=96;oc.height=96;
  var c=oc.getContext('2d');
  c.save();c.beginPath();c.arc(48,48,48,0,6.2832);c.clip();
  edStrokes(c,48,48,48,PEDIT.strokes,null);c.restore();
  var im=new Image();im.onload=function(){im._ok=true;};im.src=oc.toDataURL('image/png');
  SKIN_IMG=im;
 }catch(e){SKIN_IMG=null;}
}
function edStrokes(c,cx,cy,RR,list,cur){
 var all=list.concat(cur?[cur]:[]),i,k;
 c.lineCap='round';c.lineJoin='round';
 for(i=0;i<all.length;i++){var st=all[i];if(!st.p.length)continue;
  c.strokeStyle=st.c;c.lineWidth=RR*.17;c.beginPath();
  c.moveTo(cx+st.p[0][0]*RR,cy+st.p[0][1]*RR);
  for(k=1;k<st.p.length;k++)c.lineTo(cx+st.p[k][0]*RR,cy+st.p[k][1]*RR);
  if(st.p.length===1)c.lineTo(cx+st.p[0][0]*RR+.5,cy+st.p[0][1]*RR);
  c.stroke();}
}
function edResample(pts,n){
 var P=pts.concat([pts[0]]),Ls=[0],tot=0,i,j=0,out=[];
 for(i=1;i<P.length;i++){tot+=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);Ls.push(tot);}
 if(tot<1e-6)return null;
 for(i=0;i<n;i++){var d=tot*i/n;
  while(j<Ls.length-2&&Ls[j+1]<d)j++;
  var sg=(Ls[j+1]-Ls[j])||1,t=(d-Ls[j])/sg;
  out.push([P[j][0]+(P[j+1][0]-P[j][0])*t,P[j][1]+(P[j+1][1]-P[j][1])*t]);}
 return out;
}
/* recentre et ramène à l'aire du disque de référence : même masse apparente */
function edNormalize(pts){
 if(!pts||pts.length<6)return null;
 var cx=0,cy=0,i,a=0,mx=0;
 for(i=0;i<pts.length;i++){cx+=pts[i][0];cy+=pts[i][1];}
 cx/=pts.length;cy/=pts.length;
 for(i=0;i<pts.length;i++){var p=pts[i],q=pts[(i+1)%pts.length];
  a+=(p[0]-cx)*(q[1]-cy)-(q[0]-cx)*(p[1]-cy);}
 a=Math.abs(a/2);
 if(a<.30)return null;
 var k=Math.sqrt(Math.PI/a),out=pts.map(function(p){return [(p[0]-cx)*k,(p[1]-cy)*k];});
 for(i=0;i<out.length;i++)mx=Math.max(mx,Math.hypot(out[i][0],out[i][1]));
 if(mx>2.2){var f=2.2/mx;out=out.map(function(p){return [p[0]*f,p[1]*f];});}
 return out.map(function(p){return [Math.round(p[0]*1000)/1000,Math.round(p[1]*1000)/1000];});
}
function edDraw(){
 var cv2=$('edCv');if(!cv2)return;
 var c=cv2.getContext('2d'),W2=cv2.width,H2=cv2.height,cx=W2/2,cy=H2/2,RR=W2*.38,i,g;
 c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,W2,H2);
 c.fillStyle='#0A1018';c.fillRect(0,0,W2,H2);
 c.strokeStyle='#17202C';c.lineWidth=1;c.beginPath();
 for(g=0;g<=W2;g+=W2/12){c.moveTo(g,0);c.lineTo(g,H2);c.moveTo(0,g);c.lineTo(W2,g);}
 c.stroke();
 if(PEDIT.mode==='skin'){
  var gr=c.createRadialGradient(cx-RR*.34,cy-RR*.4,RR*.12,cx,cy,RR);
  gr.addColorStop(0,'#FFFFFF');gr.addColorStop(.22,'#8EEFFF');
  gr.addColorStop(.7,'#4DD7FF');gr.addColorStop(1,'#1599C5');
  c.fillStyle=gr;c.beginPath();c.arc(cx,cy,RR,0,6.2832);c.fill();
  c.save();c.beginPath();c.arc(cx,cy,RR,0,6.2832);c.clip();
  edStrokes(c,cx,cy,RR,PEDIT.strokes,PEDIT.cur);c.restore();
  c.strokeStyle='rgba(185,247,255,.55)';c.lineWidth=2;
  c.beginPath();c.arc(cx,cy,RR,0,6.2832);c.stroke();
 }else{
  c.strokeStyle='rgba(77,215,255,.35)';c.setLineDash([6,8]);c.lineWidth=2;
  c.beginPath();c.arc(cx,cy,RR,0,6.2832);c.stroke();c.setLineDash([]);
  var pts=PEDIT.outline||PEDIT.cur;
  if(pts&&pts.length>1){
   c.strokeStyle='#A678FF';c.lineWidth=5;c.lineCap='round';c.lineJoin='round';
   c.beginPath();c.moveTo(cx+pts[0][0]*RR,cy+pts[0][1]*RR);
   for(i=1;i<pts.length;i++)c.lineTo(cx+pts[i][0]*RR,cy+pts[i][1]*RR);
   if(PEDIT.outline){c.closePath();c.fillStyle='rgba(166,120,255,.18)';c.fill();}
   c.stroke();
   if(PEDIT.outline){c.fillStyle='#F1F4F6';
    for(i=0;i<pts.length;i++){c.beginPath();c.arc(cx+pts[i][0]*RR,cy+pts[i][1]*RR,4,0,6.2832);c.fill();}}
  }
 }
}
function edNote(k){$('edNote').textContent=TR(k);}
function edPal(){
 var h='',i;
 if(PEDIT.mode!=='skin'){$('edPal').innerHTML='';return;}
 for(i=0;i<PCOL.length;i++)
  h+='<button class="edc'+(PCOL[i]===PEDIT.col?' on':'')+'" data-c="'+PCOL[i]+'" style="background:'+PCOL[i]+'" aria-label="'+PCOL[i]+'"></button>';
 $('edPal').innerHTML=h;
 var bs=$('edPal').querySelectorAll('.edc');
 for(i=0;i<bs.length;i++)bs[i].onclick=function(){PEDIT.col=this.dataset.c;edPal();Audio1.playSfx('ui_tap');};
}
function edMode(m){
 PEDIT.mode=m;PEDIT.cur=null;
 $('edTabSkin').classList.toggle('on',m==='skin');
 $('edTabShape').classList.toggle('on',m==='shape');
 if(m==='shape'&&SHAPE&&!PEDIT.outline)PEDIT.outline=SHAPE.map(function(p){return [p[0],p[1]];});
 edPal();edNote(m==='skin'?'edHintSkin':'edHintShape');edDraw();
}
function openEditor(m){
 show(vEdit,true);
 var cv2=$('edCv');
 if(cv2&&!cv2._wired){
  cv2._wired=true;
  var P=function(e){var r=cv2.getBoundingClientRect();
   return [((e.clientX-r.left)/r.width*2-1)/.76,((e.clientY-r.top)/r.height*2-1)/.76];};
  cv2.addEventListener('pointerdown',function(e){
   cv2.setPointerCapture(e.pointerId);e.preventDefault();
   var p=P(e);
   if(PEDIT.mode==='skin')PEDIT.cur={c:PEDIT.col,p:[p]};
   else{PEDIT.outline=null;PEDIT.cur=[p];}
   edDraw();});
  cv2.addEventListener('pointermove',function(e){
   if(!PEDIT.cur)return;e.preventDefault();
   var p=P(e),arr=PEDIT.mode==='skin'?PEDIT.cur.p:PEDIT.cur,l=arr[arr.length-1];
   if(Math.hypot(p[0]-l[0],p[1]-l[1])<.025)return;
   arr.push([Math.round(p[0]*1000)/1000,Math.round(p[1]*1000)/1000]);edDraw();});
  var up=function(){
   if(!PEDIT.cur)return;
   if(PEDIT.mode==='skin'){if(PEDIT.strokes.length<80)PEDIT.strokes.push(PEDIT.cur);}
   else{
    if(PEDIT.cur.length<8){edNote('edTooShort');PEDIT.outline=null;}
    else{PEDIT.outline=edResample(PEDIT.cur,14);edNote('edClosed');}
   }
   PEDIT.cur=null;edDraw();};
  cv2.addEventListener('pointerup',up);cv2.addEventListener('pointercancel',up);
 }
 edMode(m||PEDIT.mode);
}
$('edTabSkin').onclick=function(){edMode('skin');Audio1.playSfx('ui_tap');};
$('edTabShape').onclick=function(){edMode('shape');Audio1.playSfx('ui_tap');};
$('edClear').onclick=function(){
 if(PEDIT.mode==='skin')PEDIT.strokes=[];else PEDIT.outline=null;
 edNote(PEDIT.mode==='skin'?'edHintSkin':'edHintShape');edDraw();Audio1.playSfx('ui_tap');};
$('edSave').onclick=function(){
 if(PEDIT.mode==='skin'){skinBuild();edNote('edSaved');}
 else{
  var sh=edNormalize(PEDIT.outline);
  if(!sh){edNote('edTooSmall');return;}
  SHAPE=sh;edNote('edSaved');
  if(S.zen&&S.useShape){qpBuild();resetBall();}
 }
 persist();Audio1.playSfx('ui_confirm');};
$('edClose').onclick=function(){show(vEdit,false);};
$('hEdit').onclick=function(){Audio1.unlock();Audio1.playSfx('ui_tap');openEditor('skin');};
$('zShape').onclick=function(){
 if(!SHAPE){openEditor('shape');return;}
 S.useShape=!S.useShape;
 $('zShape').classList.toggle('on',S.useShape);
 S.strokes=[];S.cur=null;resetBall();Audio1.playSfx('ui_tap');};
$('lang').onclick=function(){
 LANG=(LANG==='fr')?'en':'fr';
 $('lang').textContent=LANG==='fr'?'Français':'English';
 document.documentElement.lang=LANG;
 applyLang();persist();Audio1.playSfx('ui_tap');
};
$('wipe').onclick=function(){
 if($('wipe').dataset.armed==='1'){
  SAVE.clear();
  for(var i=0;i<S.best.length;i++){S.best[i]=0;S.bestMat[i]=0;}
  S.unlocked=0;S.seen=0;if(window.TUTO)TUTO.reset();
  $('wipe').dataset.armed='0';$('wipe').textContent='Effacer';
  paintHome();paintGStars();show(vSet,false);
 }else{
  $('wipe').dataset.armed='1';$('wipe').textContent='Confirmer';
  setTimeout(function(){if($('wipe').dataset.armed==='1'){
   $('wipe').dataset.armed='0';$('wipe').textContent='Effacer';}},4000);
 }
};
function isWebView(){
 var u=navigator.userAgent||'';
 /* Safari expose « Version/x » ; une WKWebView intégrée, non. */
 return /iPhone|iPad|iPod/.test(u) && !/Version\//.test(u);
}
function auDetails(){
 var L=[];
 L.push(['moteur', window.__QXSAMPLES?'échantillons WAV':'synthèse Web Audio']);
 L.push(['contexte', Audio1.state?Audio1.state():'?']);
 L.push(['session iOS', Audio1.session?Audio1.session():'?']);
 L.push(['boucle silencieuse', Audio1.media&&Audio1.media()?'acceptée':'refusée']);
 L.push(['échantillons', Audio1.sampReady&&Audio1.sampReady()?'prêts':(Audio1.sampErr&&Audio1.sampErr()||'en attente')]);
 L.push(['navigateur', isWebView()?'vue web intégrée (appli)':'Safari']);
 return L;
}
function auRefresh(){
 var r=auTxt();
 $('auState').textContent=r[0];
 var box=$('auDetail');
 if(box)box.innerHTML=auDetails().map(function(p){
  return '<span style="display:flex;justify-content:space-between;gap:10px;padding:3px 0">'+
   '<em style="font-style:normal;color:var(--muted)">'+p[0]+'</em><b style="font-weight:500">'+p[1]+'</b></span>';
 }).join('')+(isWebView()?'<p style="margin:10px 0 0;color:var(--bounce);line-height:1.5">'+
  'Tu es dans la vue web de l’application. C’est l’application hôte qui fixe la catégorie audio du système, '+
  'pas la page : aucun contournement web ne peut passer outre le mode silencieux ici. '+
  'Ouvre le fichier dans Safari pour tester le comportement réel.</p>':'');
 $('auState').style.color=r[1];
 auLine();
}
$('auTest').onclick=function(){Audio1.unlock();Audio1.test();setTimeout(auRefresh,450);};

function sw(id,init,fn){
 var b=$(id);b.setAttribute('aria-pressed',init?'true':'false');
 b.onclick=function(){
  var v=b.getAttribute('aria-pressed')!=='true';
  b.setAttribute('aria-pressed',v?'true':'false');Audio1.playSfx('ui_tap');fn(v);};
}
/* volumes plutôt qu'interrupteurs : zéro vaut coupé */
function volSlider(id,out,get,set,fmt){
 var s=$(id),o=$(out);if(!s)return;
 s.value=Math.round(get()*100);o.textContent=s.value+' %';
 s.oninput=function(){var v=(+this.value)/100;o.textContent=this.value+' %';set(v);};
 s.onchange=function(){persist();Audio1.unlock();};
}
volSlider('vMus','vMusV',function(){return OPT.musVol;},function(v){OPT.musVol=v;OPT.mus=v>0;Audio1.setMusicVol(v);});
volSlider('vSfx','vSfxV',function(){return OPT.sfxVol;},function(v){OPT.sfxVol=v;OPT.sfx=v>0;Audio1.setSfxVol(v);Audio1.playSfx('ui_tap');});
sw('oHap',OPT.hap,function(v){OPT.hap=v;Audio1.setHaptics(v);persist();});
sw('oRm',!!OPT.rm,function(v){OPT.rm=v;RM=v;if(v){FX.p=[];FX.r=[];}persist();});
sw('oLoupe',OPT.loupe,function(v){OPT.loupe=v;loupeOn=v;persist();});
Audio1.setMusicVol(OPT.mus?OPT.musVol:0);Audio1.setSfxVol(OPT.sfx?OPT.sfxVol:0);Audio1.setHaptics(OPT.hap);
if(OPT.rm)RM=true; loupeOn=OPT.loupe;

/* ============================================================
   9 · INPUT
   ============================================================ */
function inRects(rs,x,y){
 if(!rs)return false;
 if(rs._mz)for(var z=0;z<rs._mz.length;z++){var m=rs._mz[z];if(x>m[0]&&x<m[0]+m[2]&&y>m[1]&&y<m[1]+m[3])return true;}
 if(rs._rail)for(var q=0;q<rs._rail.length;q++){var P=rs._rail[q].pts;for(var j=0;j<P.length;j+=2)if(Math.abs(P[j][0]-x)<20&&Math.abs(P[j][1]-y)<20&&Math.hypot(P[j][0]-x,P[j][1]-y)<20)return true;}
 for(var i=0;i<rs.length;i++){var r=rs[i];
  if(x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3])return true;}
 return false;}
function pt(e){var r=cv.getBoundingClientRect();return[(e.clientX-r.left)/scale,(e.clientY-r.top)/scale];}
var drawSnd=0;

cv.addEventListener('pointerdown',function(e){
 Audio1.unlock();
 if(window.EDT&&EDT.active()){EDT.down(e);return;}
 if(S.ink<=2||S.mode==='success'||S.mode==='fail')return;
 var p=pt(e);
 if(inRects(L().nd,p[0],p[1])){S.ndHit={x:p[0],y:p[1],t:S.t};cv.setPointerCapture(e.pointerId);S.ndgCur={pts:[[p[0],p[1],S.tick]],col:matCol(S.tool)};(S.ndg=S.ndg||[]).push(S.ndgCur);e.preventDefault();return;}   /* R166 : le trait tenté dans la zone s'y montre puis se délite (VX.ndDust) */
 cv.setPointerCapture(e.pointerId);
 S.cur=[p];S.curLen=0;ptr=p;e.preventDefault();
});
cv.addEventListener('pointermove',function(e){
 if(window.EDT&&EDT.active()){EDT.move(e);return;}
 if(!S.cur&&!S.ndgCur)return;e.preventDefault();
 var p=pt(e);ptr=p;
 if(S.ndgCur){var gq=S.ndgCur.pts[S.ndgCur.pts.length-1];if(inRects(L().nd,p[0],p[1])){if(Math.hypot(p[0]-gq[0],p[1]-gq[1])>=4)S.ndgCur.pts.push([p[0],p[1],S.tick]);S.ndHit={x:p[0],y:p[1],t:S.t};return;}
  S.ndgCur.pts.push([p[0],p[1],S.tick]);S.ndgCur.done=1;S.ndgCur=null;if(S.ink<=2)return;S.cur=[p];S.curLen=0;return;}   /* sortie de la zone : le trait reprend */
 if(S.ink<=0)return;
 if(inRects(L().nd,p[0],p[1])){var lq=S.cur[S.cur.length-1];S.ndHit={x:p[0],y:p[1],t:S.t};endStroke();S.ndgCur={pts:[[lq[0],lq[1],S.tick],[p[0],p[1],S.tick]],col:matCol(S.tool)};(S.ndg=S.ndg||[]).push(S.ndgCur);return;}
 var l=S.cur[S.cur.length-1],d=Math.hypot(p[0]-l[0],p[1]-l[1]);
 if(d<5)return;
 var c=COST[S.tool],cost=d*c;
 if(S.zen){S.cur.push(p);spawn(p[0],p[1],0,0,16,1.1,matCol(S.tool));return;}
 if(cost>=S.ink){var k=S.ink/cost;
  S.cur.push([l[0]+(p[0]-l[0])*k,l[1]+(p[1]-l[1])*k]);S.curLen+=S.ink;S.ink=0;}
 else{S.ink-=cost;S.curLen+=cost;S.cur.push(p);}
 spawn(p[0],p[1],(Math.random()-.5)*.3,(Math.random()-.5)*.3,16,1.1,matCol(S.tool));
 if(S.tick>drawSnd){drawSnd=S.tick+6;Audio1.playSfx('draw_material',Math.min(1,d/18));}
 paintEnergy();
});
function endStroke(){
 if(S.cur){
  if(S.cur.length>1){
   S.strokes.push({pts:S.cur,len:S.curLen,birth:S.tick,mat:S.tool});if(!S.zen)JR.s++;
   if(window.EDT)EDT.rec({t:'add',s:S.strokes[S.strokes.length-1]});
   if(S.tool===ROPE)qpBuild();
   Audio1.playSfx(S.tool===ROPE?'rope_set':'ui_tap');}
  S.cur=null;S.curLen=0;}
 ptr=null;undoSync();}
cv.addEventListener('pointerup',function(e){if(window.EDT&&EDT.active()){EDT.up(e,false);return;}if(S.ndgCur){S.ndgCur.done=1;S.ndgCur=null;}endStroke();});
cv.addEventListener('pointercancel',function(e){if(window.EDT&&EDT.active()){EDT.up(e,true);return;}endStroke();});
stage.addEventListener('touchmove',function(e){e.preventDefault();},{passive:false});

/* ============================================================
   10 · ACCUEIL — simulation d'ambiance
   ============================================================ */
var hcv=$('hcv'),hx=hcv.getContext('2d');
var hb={x:60,y:40,vx:.7,vy:0},hw=[],hT=0,hLabY=0;
function hResize(){
 var w=hcv.clientWidth,h=hcv.clientHeight,d=Math.min(window.devicePixelRatio||1,2);
 if(w<10||h<10)return;
 hcv.width=Math.round(w*d);hcv.height=Math.round(h*d);
 hx.setTransform(d,0,0,d,0,0);
 hw=[[w*.04,h*.30,w*.56,h*.44],[w*.44,h*.62,w*.99,h*.50]];hLabY=0;
}
function hStep(){
 if(app.dataset.screen!=='home')return;
 hT++;
 var w=hcv.clientWidth,h=hcv.clientHeight,i;
 if(w<10)return;
 if(window.QHERO){try{if(!hLabY){var qs=document.querySelector('#home .qsig');hLabY=qs?Math.round(qs.getBoundingClientRect().bottom-hcv.getBoundingClientRect().top+24):Math.round(h*.3);}QHERO.frame(hx,w,h,performance.now(),{labelY:hLabY,labelC:1});return;}catch(eq){}}   /* R188 : héros « L'odyssée » (hero.js) ; l'ancienne simulation reste en secours */
 hb.vy+=.16;hb.x+=hb.vx;hb.y+=hb.vy;
 for(i=0;i<hw.length;i++){
  var s=hw[i],dx=s[2]-s[0],dy=s[3]-s[1],l2=dx*dx+dy*dy;
  var t=l2?Math.max(0,Math.min(1,((hb.x-s[0])*dx+(hb.y-s[1])*dy)/l2)):0;
  var cx=s[0]+t*dx,cy=s[1]+t*dy,nx=hb.x-cx,ny=hb.y-cy,d=Math.hypot(nx,ny);
  if(d<13&&d>0){nx/=d;ny/=d;hb.x+=nx*(13-d);hb.y+=ny*(13-d);
   var vn=hb.vx*nx+hb.vy*ny;
   if(vn<0){hb.vx-=1.3*vn*nx;hb.vy-=1.3*vn*ny;}}}
 if(hb.y>h+40||hb.x>w+40){hb.x=w*.06;hb.y=-20;hb.vx=.75;hb.vy=0;}
 hx.clearRect(0,0,w,h);
 if(window.VX)window.VX.hero(hx,w,h);
 hx.strokeStyle=T.grid;hx.lineWidth=1;hx.beginPath();
 for(i=30;i<w;i+=30){hx.moveTo(i,0);hx.lineTo(i,h);}
 for(i=30;i<h;i+=30){hx.moveTo(0,i);hx.lineTo(w,i);}
 hx.stroke();
 hx.lineCap='round';
 for(i=0;i<hw.length;i++){
  var q=hw[i];
  if(window.VX){window.VX.heroWall(hx,q);continue;}
  hx.globalAlpha=.16;hx.strokeStyle=T.matter;hx.lineWidth=14;
  hx.beginPath();hx.moveTo(q[0],q[1]);hx.lineTo(q[2],q[3]);hx.stroke();
  hx.globalAlpha=1;hx.lineWidth=7;
  hx.beginPath();hx.moveTo(q[0],q[1]);hx.lineTo(q[2],q[3]);hx.stroke();}
 var sv=S.squash;S.squash=null;
 drawBall(hx,hb.x,hb.y,hT*.03,11);
 S.squash=sv;
}

/* ============================================================
   11 · LOOP
   ============================================================ */
var lastT=0;
function loop(now){
 if(window.__QTOPEN){lastT=0;requestAnimationFrame(loop);return;}   /* Quantone ouvert : le jeu ne calcule ni ne dessine rien */
 S.tick++;
 var t=now||0;
 if(!lastT)lastT=t;
 var dt=Math.min(.1,(t-lastT)/1000);lastT=t;
 if(app.dataset.screen==='game'){
  if(!S.zen&&!(document&&document.hidden))JR.t+=dt*1000;
  pfLayout();   /* R194 : plein cadre — coins, fil d'énergie, hauteur du pied */
  /* horloge fixe 60 Hz : le ralenti ralentit le temps simulé,
     il ne saute pas de frames de rendu. */
  S.acc+=dt*(S.slow?.4:1)*S.tmul;
  var guard=0;
  while(S.acc>=1/60&&guard++<4){if(S.mode==='replay')replayStep();else physics();S.acc-=1/60;}
  if(S.mode!=='run')S.t++;
  if(S.squash){S.squash.t-=.09;if(S.squash.t<=0)S.squash=null;}
  fxStep();
  if(window.TUTO){try{TUTO.tick();}catch(e0){}}
  for(var qi=0;qi<S.ent.length;qi++)if(S.ent[qi].pulse>0)S.ent[qi].pulse-=.045;
  try{
   ctx.clearRect(0,0,W,H);
   scene(ctx);loupe();if(window.TUTO)TUTO.draw(ctx);
  }catch(err){
   if(!S.renderErr){S.renderErr=String(err&&err.message||err);
    try{console.error('rendu:',err);}catch(e2){}
    var tp=$('tip');if(tp)tp.textContent='Anomalie de rendu : '+S.renderErr;}
  }
 }else{hStep();if(window.TUTO){try{TUTO.tick();}catch(e0){}}}
 requestAnimationFrame(loop);
}
window.addEventListener('resize',function(){resize();hResize();});
window.addEventListener('orientationchange',function(){setTimeout(function(){resize();hResize();},140);});
/* R115 — QUANTONE DANS LE JEU : plein écran par‑dessus le jeu ; la musique du jeu se tait pendant ce temps.
   Chargé une seule fois (l'état de Quantone est conservé entre deux ouvertures). Aperçu autonome : source embarquée (QT_SRC). */
(function(){var ov=$('qtOv'),fr=$('qtF'),loaded=false,QTS=[];if(!ov)return;
 function openQt(){try{Audio1.setMusicVol(0);}catch(e){}   /* R432 : plus d'Audio1.unlock() ici — il jouait ui_tap.mp3 puis le coupait (clic) et démarrait toute la chaîne audio du jeu pour la suspendre aussitôt */
  var snd=false;try{snd=Audio1.playOpen&&Audio1.playOpen();}catch(e){}   /* R433 : son d'ouverture, partagé avec l'ouverture du jeu */
  window.__QTOPEN=true;setTimeout(function(){if(ov.hidden)return;QTS=[];try{(window.__ACS||[]).forEach(function(c){if(c.state==='running'){c.suspend();QTS.push(c);}});}catch(e){}
   try{[].forEach.call(document.querySelectorAll('audio,video'),function(a){if(!a.paused&&!a.loop){a.pause();}});}catch(e){}},snd?2800:150);   /* R261 : le jeu (vent, boucles, musique, dessin) s'arrête complètement pendant Quantone */
  if(!loaded){loaded=true;if(window.QT_SRC)fr.srcdoc=window.QT_SRC;else fr.src='studio/quantone.html?v=R447';}
  ov.hidden=false;ov.style.display='flex';}
 function closeQt(){ov.style.display='none';ov.hidden=true;try{var f=fr.contentWindow;if(f&&f.document){var b=f.document.getElementById('bPlay');if(f.QTSTOP)f.QTSTOP();else if(b&&/Arr|Stop/.test(b.textContent))b.click();}}catch(e){}
  window.__QTOPEN=false;try{QTS.forEach(function(c){try{c.resume();}catch(e){}});QTS=[];}catch(e){}
  try{if(OPT.mus!==false)Audio1.setMusicVol(OPT.musVol!==undefined?OPT.musVol:.5);Audio1.playSfx('ui_tap');}catch(e){}}
 $('hSnd').onclick=openQt;if($('sStudio'))$('sStudio').onclick=openQt;(function(){var x=$('qtX'),tm=0,txt='';x.onclick=function(){if(tm){clearTimeout(tm);tm=0;x.textContent=txt;x.style.borderColor='';x.style.color='';closeQt();return;}   /* R356 : deux touches pour fermer (on le touchait par mégarde en refermant un menu) */
  txt=x.textContent;x.textContent=(document.documentElement.lang==='en'?'Close?':'Fermer ?');x.style.borderColor='#FF5A78';x.style.color='#FFD2DA';tm=setTimeout(function(){tm=0;x.textContent=txt;x.style.borderColor='';x.style.color='';},2200);};})();
 try{$('hSndI').innerHTML=ico('tone',13);}catch(e){}
 window.QTOV={open:openQt,close:closeQt};})();
/* R116 — HAUTEUR RÉELLE : dans la visionneuse d'artefacts (iPhone), le jeu tourne dans un cadre plus petit que l'écran ;
   100svh vaut la hauteur de l'écran entier et le bas (Lâcher, carte du monde) était rogné. On cale #app sur la hauteur
   visible du document lui‑même (la plus petite des mesures disponibles), à chaque changement. */
(function(){var app=document.getElementById('app');if(!app)return;
 function fitApp(){var h=[window.innerHeight,document.documentElement.clientHeight];
  if(window.visualViewport&&visualViewport.height)h.push(Math.round(visualViewport.height));
  h=h.filter(function(v){return v>200;});if(!h.length)return;
  var v=Math.min.apply(null,h);document.documentElement.style.setProperty('--appH',v+'px');}
 fitApp();window.addEventListener('resize',fitApp);window.addEventListener('orientationchange',function(){setTimeout(fitApp,250);});
 if(window.visualViewport)visualViewport.addEventListener('resize',fitApp);
 setTimeout(fitApp,300);setTimeout(fitApp,1200);window.QFIT=fitApp;})();
try{console.log('QUANTIX build R447 · '+LEVELS.length+' niveaux · '+WORLDS.length+' mondes');}catch(e){}
var restored=restore();
if(LANG==='en')document.documentElement.lang='en';
skinBuild();
resize();hResize();loadLevel(restored?S.seen:0);paintHome();applyLang();goto('home');loop();
try{console.log('sauvegarde : '+(SAVE.available()?(restored?'restaurée':'vierge'):'indisponible'));}catch(e){}

/* crochet de débogage, utilisé par les outils de tools/ */
if(typeof globalThis!=='undefined')globalThis.__X={S:S,QP:QP,WART:WART,WMETA:WMETA,DICT:DICT,LEVELS:LEVELS,WORLDS:WORLDS,ZEN:ZEN,physics:physics,loadLevel:loadLevel,qpBuild:qpBuild,openWorld:openWorld,advance:advance,worldRange:worldRange,polyArea:polyArea,softCentroid:softCentroid,edNormalize:edNormalize,edResample:edResample,SAVE:SAVE,OPT:OPT,saveState:saveState,restore:restore,Audio1:Audio1};
