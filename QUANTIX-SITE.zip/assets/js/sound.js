/* ══ SON ÉTHÉRÉ ══ (R40)
   Remplace la musique et les bruitages d'Audio1 (engine.js) par une synthèse douce, sans échantillon :
   - un THÈME de cinq notes (pentatonique de mi mineur, comme les bandes son de référence), joué par une voix
     de verre (sinus + partiel à 2,76), repris et varié par monde ;
   - des NAPPES : accord à trois voix désaccordées, filtre passe-bas qui respire, grave très doux ;
   - des BRUITAGES « guimauve » : attaque lente (10 à 25 ms), hauteur prise dans l'échelle du monde,
     souffle filtré pour les glissements, envoi dans une réverbération longue générée (≈ 3,5 s).
   Musique et bruitages partagent la même échelle et la même réverbération : ils se répondent.
   L'API d'Audio1 est conservée (unlock, playSfx, playImpact, playMusicState, setWorld, set*Vol…).
   Chargé APRÈS engine.js. Aucun texte visible. */
(function(){
if(typeof Audio1==='undefined')return;
var A0={};for(var k in Audio1)A0[k]=Audio1[k];

/* ── mondes : même motif, autre couleur ── */
var PENTA=[0,3,5,7,10];                       /* mi sol la si ré — degrés de la pentatonique mineure */
var WORLDS=[
 {root:52,scale:[0,3,5,7,10],cut:1200,tempo:17,bright:.55,chords:[[0,7,14],[-4,3,11],[3,10,14],[-2,5,12]]},   /* 1 Atelier : mi mineur */
 {root:57,scale:[0,2,3,7,9],cut:950,tempo:20,bright:.45,chords:[[0,7,15],[-2,5,14],[3,10,15],[-5,2,10]]},     /* 2 Fonderie : la dorien, plus chaud */
 {root:55,scale:[0,2,4,7,9],cut:1300,tempo:15,bright:.6,chords:[[0,7,16],[-3,4,12],[5,9,16],[2,7,14]]},       /* 3 Chaîne : sol majeur pentatonique, élan */
 {root:64,scale:[0,2,7,9,14],cut:1700,tempo:22,bright:.8,chords:[[0,7,14],[5,12,19],[-5,2,9],[0,7,19]]},       /* 4 Glacier : quintes ouvertes, cristallin */
 {root:50,scale:[0,3,5,7,10],cut:1100,tempo:18,bright:.5,chords:[[0,7,14],[-4,3,10],[5,10,15],[-2,5,12]]},
 {root:53,scale:[0,2,5,7,9],cut:1000,tempo:16,bright:.5,chords:[[0,7,14],[-3,4,12],[2,9,14],[-5,2,9]]},
 {root:48,scale:[0,3,5,7,10],cut:1000,tempo:20,bright:.45,chords:[[0,7,15],[-4,3,10],[3,10,15],[-2,5,12]]},
 {root:56,scale:[0,2,4,7,9],cut:1300,tempo:18,bright:.6,chords:[[0,7,16],[-3,4,12],[5,9,16],[2,7,14]]},
 {root:51,scale:[0,3,5,7,10],cut:1150,tempo:19,bright:.55,chords:[[0,7,14],[-4,3,11],[3,10,14],[-2,5,12]]},
 {root:54,scale:[0,2,3,7,9],cut:1050,tempo:21,bright:.5,chords:[[0,7,15],[-2,5,14],[3,10,15],[-5,2,10]]},
 {root:52,scale:[0,2,7,9,14],cut:1500,tempo:24,bright:.7,chords:[[0,7,14],[5,12,19],[-5,2,9],[0,7,19]]}];
/* motif (degrés d'échelle) et ses variantes : l'ordre des phrases fait le chant */
var MOTIF=[[0,2,4,3,1],[0,2,4,5,4],[4,3,2,1,0],[2,4,5,7,4],[0,1,2,4,2]];
var ST={menu:0,draw:1,run:2,tension:3,success:4,failure:5};

var ac=null,master,comp,rev,revIn,mus,sfx,dry,wi=0,st=1,started=false,chordI=0,next=0,timer=0,phrase=0,lastImp=0;
var vol={mus:(typeof OPT!=='undefined'&&OPT.mus!==false)?(OPT.musVol!==undefined?OPT.musVol:.5):0,
         sfx:(typeof OPT!=='undefined'&&OPT.sfx!==false)?(OPT.sfxVol!==undefined?OPT.sfxVol:1):0};
var noiseBuf=null;

function mtof(n){return 440*Math.pow(2,(n-69)/12);}
/* PLAFOND (retour Simon : tintements trop aigus) : une note au-dessus du plafond est repliée d'une octave, autant de fois
   qu'il faut — même nom de note, registre doux. Plafond par défaut ≈ si 5 (990 Hz) ; Glacier un peu plus haut (cristallin). */
var CEIL=[523,523,523,622,523,523,523,523,523,523,587];
function cap(f){var c=CEIL[wi]||523;while(f>c)f/=2;return f;}
var LV=0;  /* niveau courant : il colore le préréglage du monde (R47) */
function lvVar(){var n=LV%12;return {tr:[0,2,-2,0,3,-3,0,2,5,-2,0,-5][n],tempo:1+[0,-.06,.05,.03,-.04,.08,0,-.05,.04,-.08,.06,0][n],
 rot:n%5,inv:(n%4===3)};}
function W(){var b=WORLDS[wi]||WORLDS[0],v=lvVar();return {root:b.root+v.tr,scale:b.scale,cut:b.cut,tempo:b.tempo,bright:b.bright,chords:b.chords.slice(v.rot%b.chords.length).concat(b.chords.slice(0,v.rot%b.chords.length))};}
function note(d,oct){var w=W(),s=w.scale,n=s.length,i=((d%n)+n)%n;return cap(mtof(w.root+s[i]+12*(Math.floor(d/n)+(oct||0))));}

/* réverbération : réponse impulsionnelle générée (bruit stéréo, décroissance exponentielle, aigus amortis) */
function impulse(c,sec,decay){
 var n=Math.floor(c.sampleRate*sec),b=c.createBuffer(2,n,c.sampleRate),ch,i,d,lp;
 for(ch=0;ch<2;ch++){d=b.getChannelData(ch);lp=0;
  for(i=0;i<n;i++){var t=i/n,x=(Math.random()*2-1)*Math.pow(1-t,decay);lp+= (x-lp)*(.18+.5*(1-t));d[i]=lp;}}
 return b;}
function graph(c){
 ac=c;master=c.createGain();master.gain.value=.85;
 comp=c.createDynamicsCompressor();comp.threshold.value=-20;comp.knee.value=18;comp.ratio.value=3;comp.attack.value=.02;comp.release.value=.3;
 var shelf=c.createBiquadFilter();shelf.type='highshelf';shelf.frequency.value=1500;shelf.gain.value=-9;
 var tame=c.createBiquadFilter();tame.type='lowpass';tame.frequency.value=3500;tame.Q.value=.5;
 var lim=c.createDynamicsCompressor();lim.threshold.value=-6;lim.knee.value=0;lim.ratio.value=20;lim.attack.value=.002;lim.release.value=.15;
 master.connect(shelf);shelf.connect(tame);tame.connect(comp);comp.connect(lim);lim.connect(c.destination);   /* limiteur : plus d'écrêtage */
 rev=c.createConvolver();rev.buffer=impulse(c,2.4,2.9);
 var rlp=c.createBiquadFilter();rlp.type='lowpass';rlp.frequency.value=3200;
 revIn=c.createGain();revIn.gain.value=1;revIn.connect(rlp);rlp.connect(rev);
 var rOut=c.createGain();rOut.gain.value=.36;rev.connect(rOut);rOut.connect(master);
 mus=c.createGain();mus.gain.value=vol.mus;dry=c.createGain();dry.gain.value=1;
 sfx=c.createGain();sfx.gain.value=vol.sfx*.8;
 mus.connect(master);sfx.connect(master);
 if(c.constructor.name!=='OfflineAudioContext')try{musChain(c);}catch(e){}
 var n=Math.floor(c.sampleRate*2),nb=c.createBuffer(1,n,c.sampleRate),nd=nb.getChannelData(0),i,pk=0;
 for(i=0;i<n;i++){var w=Math.random()*2-1;pk=.97*pk+.03*w;nd[i]=pk*6;}   /* bruit « rose-ish », pas de sifflement */
 noiseBuf=nb;}
function send(node,bus,wet){node.connect(bus);var s=ac.createGain();s.gain.value=wet;node.connect(s);s.connect(revIn);}

/* ── voix ── */
function glass(bus,f,t,dur,g,wet){ /* verre / cloche douce : fondamentale + partiel inharmonique discret */
 var o=ac.createOscillator(),o2=ac.createOscillator(),e=ac.createGain(),e2=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain();
 o.type='sine';o2.type='sine';f=cap(f);o.frequency.value=f;o2.frequency.value=f*1.004;
 lp.type='lowpass';lp.frequency.value=Math.min(1400,f*1.8);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.07);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 e2.gain.setValueAtTime(.0001,t);e2.gain.linearRampToValueAtTime(g*.06*W().bright,t+.09);e2.gain.exponentialRampToValueAtTime(.0001,t+dur*.35);
 o.connect(e);o2.connect(e2);e.connect(lp);e2.connect(lp);lp.connect(out);send(out,bus,wet===undefined?.5:wet);
 o.start(t);o2.start(t);o.stop(t+dur+.05);o2.stop(t+dur+.05);}
function mallow(bus,f,t,dur,g,wet,glide){ /* « guimauve » : triangle filtré, attaque lente, léger glissement de hauteur */
 var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain();
 o.type='triangle';o.frequency.setValueAtTime(f*(glide||1),t);o.frequency.exponentialRampToValueAtTime(f,t+Math.min(.08,dur*.5));
 lp.type='lowpass';lp.frequency.setValueAtTime(f*3.2,t);lp.frequency.exponentialRampToValueAtTime(Math.max(120,f*1.3),t+dur);lp.Q.value=.3;
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.022);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 o.connect(lp);lp.connect(e);e.connect(out);send(out,bus,wet===undefined?.4:wet);o.start(t);o.stop(t+dur+.05);}
function breath(bus,t,dur,f0,f1,g,wet,q){ /* souffle filtré qui glisse de f0 à f1 */
 var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain(),out=ac.createGain();
 s.buffer=noiseBuf;s.loop=true;bp.type='bandpass';bp.Q.value=q||1.4;
 bp.frequency.setValueAtTime(f0,t);bp.frequency.exponentialRampToValueAtTime(f1,t+dur);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+dur*.35);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 s.connect(bp);bp.connect(e);e.connect(out);send(out,bus,wet===undefined?.5:wet);s.start(t,Math.random()*1.5);s.stop(t+dur+.05);}

/* ── musique (R41) ── retour Simon : nappe trop présente, oscillation « sirène » (glissement de hauteur entre accords).
   Désormais : les accords ne glissent JAMAIS — chaque accord naît (attaque 2,5 s) pendant que le précédent s'éteint ;
   filtre fixe, trémolo lent et léger ; écho ping-pong filtré + réverbération.
   FIL CONDUCTEUR : le même motif de cinq notes (MOTIF) traverse tous les mondes, transformé par la physique du monde.
   1 Atelier (la ligne et la chute) : motif en verre, lent, qui retombe ; nappe claire et rare.
   2 Fonderie (rebond, chambre à bulles) : motif en rebond (les intervalles de temps rétrécissent), voix chaude,
     bulles qui éclosent dans les aigus, écho court et chaud.
   3 Chaîne (élan, anneau de stockage, paquets) : motif en PAQUETS de trois notes qui circulent, pulsation régulière,
     écho ping-pong rythmé, le son tourne de gauche à droite.
   4 Glacier (glace, condensat, vitesse conservée) : motif très aigu, notes tenues longtemps (rien ne freine),
     accords figés qui ne changent presque pas, scintillement d'octave, réverbération et écho longs. */
var MIX=[ /* nappe, thème, texture, grave — par état de jeu */
 [.45,.9,.6,.5],[.4,.75,.5,.5],[.36,.55,.8,.55],[.3,.35,.9,.6],[.5,1,.5,.5],[.3,.25,.2,.35]];
var lay={},padNow=[],dly=null,trem=null,pan=null,bar0=0;
function mkDelay(){
 var dl=ac.createDelay(2),dr=ac.createDelay(2),fl=ac.createGain(),fr=ac.createGain(),lpl=ac.createBiquadFilter(),lpr=ac.createBiquadFilter(),
  mg=ac.createChannelMerger(2),inG=ac.createGain(),out=ac.createGain();
 lpl.type=lpr.type='lowpass';lpl.frequency.value=lpr.frequency.value=2400;
 inG.connect(dl);dl.connect(lpl);lpl.connect(fl);fl.connect(dr);dr.connect(lpr);lpr.connect(fr);fr.connect(dl);
 lpl.connect(mg,0,0);lpr.connect(mg,0,1);mg.connect(out);out.connect(mus);var rs=ac.createGain();rs.gain.value=.5;out.connect(rs);rs.connect(revIn);
 out.gain.value=.34;return {inp:inG,dl:dl,dr:dr,fl:fl,fr:fr,out:out};}
function setDelay(t){var s=STY[wi]||STY[0],now=ac.currentTime;
 dly.dl.delayTime.setTargetAtTime(s.dt,t||now,.3);dly.dr.delayTime.setTargetAtTime(s.dt*1.5,t||now,.3);
 dly.fl.gain.setTargetAtTime(s.fb,t||now,.3);dly.fr.gain.setTargetAtTime(s.fb,t||now,.3);}
function tosend(node,bus,wet,dwet){node.connect(bus);var r=ac.createGain();r.gain.value=wet;node.connect(r);r.connect(revIn);
 if(dwet){var d=ac.createGain();d.gain.value=dwet;node.connect(d);d.connect(dly.inp);}}
function voice(f,t,dur,g,type,bus,wet,dwet,atk){ /* voix tenue sans glissement */
 var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain();
 o.type=type||'sine';o.frequency.value=f;lp.type='lowpass';lp.frequency.value=Math.min(1500,f*2);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+(atk||.02));e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 o.connect(lp);lp.connect(e);e.connect(out);tosend(out,bus,wet,dwet);o.start(t);o.stop(t+dur+.1);}
function bell(f,t,dur,g,wet,dwet,bus){ /* verre : fondamentale + partiel discret */
 f=cap(f);voice(f,t,dur,g*.8,'sine',bus||lay.theme,wet,dwet,.09);voice(f*1.004,t,dur,g*.35,'triangle',bus||lay.theme,wet,dwet,.12);}
function padChord(ci,t,len){ /* accord : naît en 2,5 s, tient, s'éteint en 3 s ; aucun glissement */
 if(styleOf().noPad)return;
 var w=W(),ch=w.chords[ci%w.chords.length],s=STY[wi]||STY[0],i,k;
 for(i=0;i<3;i++)for(k=0;k<2;k++){
  var f=cap(mtof(w.root+ch[i]+s.padOct*12))*(k?1.003:.997);
  var o=ac.createOscillator(),e=ac.createGain();o.type=k?'sine':s.padWave;o.frequency.value=f;
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(s.padG*(k?1:.7),t+2.5);
  e.gain.setValueAtTime(s.padG*(k?1:.7),t+len);e.gain.linearRampToValueAtTime(.0001,t+len+3);
  o.connect(e);e.connect(trem);o.start(t);o.stop(t+len+3.2);}
 voice(mtof(w.root-12+ch[0]),t,len+3,.05,'sine',lay.sub,.1,0,2.5);}
function buildMusic(){
 ['pad','theme','tex','sub'].forEach(function(n){lay[n]=ac.createGain();lay[n].gain.value=0;lay[n].connect(mus);});
 dly=mkDelay();
 var pf=ac.createBiquadFilter();pf.type='lowpass';pf.frequency.value=1400;pf.Q.value=.4;
 trem=ac.createGain();trem.gain.value=.85;pan=ac.createStereoPanner?ac.createStereoPanner():null;
 trem.connect(pf);if(pan){pf.connect(pan);pan.connect(lay.pad);}else pf.connect(lay.pad);
 var ps=ac.createGain();ps.gain.value=.6;pf.connect(ps);ps.connect(revIn);
 var tl=ac.createOscillator(),tg=ac.createGain();tl.frequency.value=.12;tg.gain.value=.1;tl.connect(tg);tg.connect(trem.gain);tl.start();
 if(pan){var pl=ac.createOscillator(),pg=ac.createGain();pl.frequency.value=.03;pg.gain.value=.35;pl.connect(pg);pg.connect(pan.pan);pl.start();}
 lay._pf=pf;lay._tl=tl;setDelay();applyStyle();
 mixTo(2);next=ac.currentTime+.3;chordI=0;phrase=0;timer=setInterval(function(){tickAt(ac.currentTime+.6);},120);}
function applyStyle(){var s=STY[wi]||STY[0],t=ac.currentTime;lay._pf.frequency.setTargetAtTime(s.cut,t,2);lay._tl.frequency.setTargetAtTime(s.trem,t,1);setDelay();}
function mixTo(tc){var m=MIX[st]||MIX[1];['pad','theme','tex','sub'].forEach(function(n,i){lay[n].gain.setTargetAtTime(m[i]*1.3,ac.currentTime,tc||1.2);});}
/* ── MFX (R107) : fonctions musicales de la vidéo de référence (« Math functions that go even harder », 10 fonctions) —
   les mêmes que dans Quantone (studio/quantone.html, panneau « Fonctions musicales »). Le monde 1 en utilise quatre :
   pendules(x0,x1,N) : onde de pendules yₖ = cos(2π·Nₖ·x/16) — instants (en temps) où chaque pendule passe le milieu ;
   ressort(f,t,g)    : basse ronde dont la hauteur rebondit y = 1,3·e^(−2,4t)·cos(6πt) demi‑tons (masse sur un ressort) ;
   FIB4              : Fₙ mod 4 = 0,1,1,2,3,1 — période 6 contre une mesure de 8 (reste = note de l'accord) ;
   begaie(f,t,dur,n,g): le dernier temps redéclenché n = 2^k fois, enveloppe e^(−13·t'). */
var MFX={FIB4:[0,1,1,2,3,1],
 pendules:function(x0,x1,N){var o=[],m=Math.ceil(x0*N/16-.25),x=16*(m+.25)/N;while(x<x1){if(x>=x0)o.push(x);m++;x=16*(m+.25)/N;}return o;},
 ressort:function(f,t,g){var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter(),D=1.6,n=96,a=new Float32Array(n),i;
  for(i=0;i<n;i++){var s=i/(n-1)*D;a[i]=f*Math.pow(2,1.3*Math.exp(-2.4*s)*Math.cos(6*Math.PI*s)/12);}
  o.type='sine';o.frequency.setValueCurveAtTime(a,t,D);lp.type='lowpass';lp.frequency.value=300;
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.01);e.gain.exponentialRampToValueAtTime(.0001,t+D);
  o.connect(lp);lp.connect(e);tosend(e,lay.sub,.12,0);o.start(t);o.stop(t+D+.05);},
 begaie:function(f,t,dur,n,g){var i;for(i=0;i<n;i++){var tt=t+i*dur/n,o=ac.createOscillator(),e=ac.createGain();o.type='sine';o.frequency.value=f;
  e.gain.setValueAtTime(.0001,tt);e.gain.linearRampToValueAtTime(g*(1-i/(n*1.6)),tt+.005);e.gain.setTargetAtTime(.0001,tt+.005,1/13);
  o.connect(e);tosend(e,lay.tex,.45,.25);o.start(tt);o.stop(tt+.5);}}};
/* ── W1 (R112) : le monde 1 composé avec les instruments et les fonctions de Quantone ─────────────────────────────
   Une mesure ≈ 7,5 s (8 temps). Chaque niveau déroule un cycle de 16 mesures en quatre sections qui respirent :
     A ÉVEIL      cloche FM « Verre » (le MOTIF, peu de notes), gouttes, souffle — presque rien
     B MÉCANIQUE  onde de pendules (notes du motif au passage du milieu), basse « ressort amorti » sur le premier temps
     C ATELIER    basse ressort 3‑3‑2, arpège Kalimba en Fibonacci mod 4 (6 contre 8), rythmes « Minimal » très doux
                  (charleston = rangée du triangle de Pascal mod 2), ligne Acide « Doux » à glissés, cloche passée au flanger, bulles
     D RESPIRATION nappe seule, une cloche grave longue, gouttes ; bégaiement sur le dernier temps avant le retour en A
   Le monde se construit niveau après niveau (n = rang dans le monde) : 1 cloche + nappe → 3 basse → 4 pendules → 5 gouttes/souffle →
   6 Kalimba → 7 rythmes et bulles → 8 acide → 9 flanger → 10 bégaiement → 11 montée sans fin (avant C) → 12 « L'établi » : tout,
   basse en cycle des quintes. Au deuxième cycle (après ~2 min) un contre‑chant inversé s'ajoute en A. Gains bas : rien ne sature. */
var W1={
 fm:function(f,t,dur,g,ratio,idx,bus,wet,dwet){var o=ac.createOscillator(),m=ac.createOscillator(),mg=ac.createGain(),e=ac.createGain();o.frequency.value=f;m.frequency.value=f*ratio;
  mg.gain.setValueAtTime(f*idx*3,t);mg.gain.exponentialRampToValueAtTime(Math.max(.1,f*idx*.12),t+dur*.6);m.connect(mg);mg.connect(o.frequency);
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.008);e.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(e);tosend(e,bus||lay.theme,wet===undefined?.55:wet,dwet===undefined?.3:dwet);
  o.start(t);m.start(t);o.stop(t+dur+.05);m.stop(t+dur+.05);},
 nz:function(t,dur,type,f0,f1,q,g,bus,wet){var s=ac.createBufferSource(),fl=ac.createBiquadFilter(),a=ac.createGain();s.buffer=noiseBuf;s.loop=true;fl.type=type;fl.Q.value=q;fl.frequency.setValueAtTime(f0,t);
  if(f1)fl.frequency.exponentialRampToValueAtTime(f1,t+dur);a.gain.setValueAtTime(.0001,t);a.gain.linearRampToValueAtTime(g,t+Math.min(dur*.5,.6));a.gain.exponentialRampToValueAtTime(.0001,t+dur);
  s.connect(fl);fl.connect(a);tosend(a,bus||lay.tex,wet===undefined?.5:wet,0);s.start(t,Math.random());s.stop(t+dur+.05);},
 goutte:function(f,t,g){var o=ac.createOscillator(),e=ac.createGain();o.frequency.setValueAtTime(f*1.5,t);o.frequency.exponentialRampToValueAtTime(f,t+.025);
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.003);e.gain.exponentialRampToValueAtTime(.0001,t+.16);o.connect(e);tosend(e,lay.tex,.65,.45);o.start(t);o.stop(t+.2);},
 bulles:function(f,t,g){for(var i=0;i<3;i++){var o=ac.createOscillator(),e=ac.createGain(),t0=t+i*.07;o.frequency.setValueAtTime(f*(.8+i*.15),t0);o.frequency.linearRampToValueAtTime(f*(1.8+i*.2),t0+.08);
  e.gain.setValueAtTime(.0001,t0);e.gain.linearRampToValueAtTime(g,t0+.005);e.gain.exponentialRampToValueAtTime(.0001,t0+.09);o.connect(e);tosend(e,lay.tex,.5,.3);o.start(t0);o.stop(t0+.12);}},
 kick:function(t,g){var o=ac.createOscillator(),e=ac.createGain();o.frequency.setValueAtTime(220,t);o.frequency.exponentialRampToValueAtTime(52,t+.07);
  e.gain.setValueAtTime(g,t);e.gain.exponentialRampToValueAtTime(.0001,t+.45);o.connect(e);tosend(e,lay.sub,.05,0);o.start(t);o.stop(t+.5);},
 hat:function(t,g,open){W1.nz(t,open?.35:.06,'highpass',7200,0,.7,g,lay.tex,.3);},
 acid:function(f,t,dur,g,from){var o=ac.createOscillator(),f1=ac.createBiquadFilter(),f2=ac.createBiquadFilter(),e=ac.createGain();o.type='sawtooth';
  if(from){o.frequency.setValueAtTime(from,t);o.frequency.exponentialRampToValueAtTime(f,t+.07);}else o.frequency.value=f;
  f1.type=f2.type='lowpass';f1.Q.value=7;f2.Q.value=.7;[f1,f2].forEach(function(x){x.frequency.setValueAtTime(1400,t);x.frequency.exponentialRampToValueAtTime(380,t+.35);});
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.004);e.gain.setValueAtTime(g,t+dur*.8);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
  o.connect(f1);f1.connect(f2);f2.connect(e);tosend(e,lay.tex,.15,.4);o.start(t);o.stop(t+dur+.05);},
 flBus:function(){if(lay._fl)return lay._fl;var i=ac.createGain(),d=ac.createDelay(.05),fb=ac.createGain(),wet=ac.createGain(),lf=ac.createOscillator(),dep=ac.createGain();
  d.delayTime.value=.0045;lf.frequency.value=.22;dep.gain.value=.003;fb.gain.value=.55;wet.gain.value=.6;lf.connect(dep);dep.connect(d.delayTime);lf.start();
  i.connect(lay.theme);i.connect(d);d.connect(fb);fb.connect(d);d.connect(wet);wet.connect(lay.theme);return lay._fl=i;},
 riser:function(t,len,g){var fb=mtof(W().root+12),k;for(k=0;k<4;k++){var o=ac.createOscillator(),e=ac.createGain(),j;o.type='sine';
  for(j=0;j<=8;j++){var x=j,u=((x+8)/16+k/4)%1,y=4*u-2,tt=t+j*len/8;if(j===0||((((x-1)+8)/16+k/4)%1)<u){if(j===0){o.frequency.setValueAtTime(fb*Math.pow(2,y),tt);e.gain.setValueAtTime(g*Math.exp(-y*y),tt);}
    else{o.frequency.linearRampToValueAtTime(fb*Math.pow(2,y),tt);e.gain.linearRampToValueAtTime(g*Math.exp(-y*y),tt);}}else{o.frequency.setValueAtTime(fb*Math.pow(2,y),tt);e.gain.setValueAtTime(g*Math.exp(-y*y),tt);}}
  e.gain.linearRampToValueAtTime(0,t+len+.3);o.connect(e);tosend(e,lay.tex,.6,.25);o.start(t);o.stop(t+len+.4);}},
 rnd:function(b,k){var x=Math.sin((LV+1)*12.9898+b*78.233+k*37.719)*43758.5453;return x-Math.floor(x);},
 bar:function(t,b,ph,len){
  var v=lvVar(),n=LV%12,w=W(),ch=w.chords[b%w.chords.length],bt=len/8,sec=Math.floor(b/4)%4,cyc=Math.floor(b/16),m=MOTIF[(ph+v.rot)%MOTIF.length],k,i;
  if(v.inv)m=m.slice().reverse();var R=W1.rnd,root=w.root-12+ch[0];
  if(n===11&&sec===2)root=w.root-12+[0,7,2,9][b%4]-(b%4>1?12:0);           /* finale : basse en cycle des quintes */
  if(sec===0){ /* A — ÉVEIL */
   var pos=[0,1,2,3,5],cnt=2+Math.min(3,Math.floor(n/3));for(k=0;k<cnt;k++)W1.fm(note(m[k],1),t+.3+pos[k]*bt,2.6,.03,2,.3);
   if(cyc>0)for(k=0;k<3;k++)W1.fm(note(m[4-k],2),t+(4+k*1.5)*bt,2,.012,3.5,.6,lay.tex,.6,.4);
   if(n>=4&&b%4===0)W1.nz(t,len*.9,'bandpass',300,2600,2.5,.012,lay.pad,.7);
   if(n>=4&&R(b,1)<.7)W1.goutte(note(m[2],2),t+(2+R(b,2)*5)*bt,.02);}
  else if(sec===1){ /* B — MÉCANIQUE */
   if(n>=3){var x0=(b%2)*8;for(k=0;k<6;k++){var dk=m[k%5]+(k===5?5:0);MFX.pendules(x0,x0+8,3+k).forEach(function(x){W1.fm(note(dk,1),t+(x-x0)*bt,1.8,.016,2,.25,lay.theme,.6,.3);});}}
   else for(k=0;k<5;k++)W1.fm(note(m[k],1),t+.3+k*1.4*bt,2.4,.028,2,.3);
   if(n>=2)MFX.ressort(mtof(root),t,.07);
   if(n>=4&&R(b,3)<.5)W1.goutte(note(m[1],2),t+(1+R(b,4)*6)*bt,.018);}
  else if(sec===2){ /* C — ATELIER EN MARCHE */
   if(n>=2)[0,3,6].forEach(function(q){MFX.ressort(mtof(root),t+q*bt,.065);});
   if(n>=5)for(i=0;i<8;i++){var fi=MFX.FIB4[(b*8+i)%6],tn=ch[fi%3]+(fi===3?12:0);W1.fm(cap(mtof(w.root+tn+12)),t+i*bt,.7,.011,5.4,.35,lay.tex,.4,.25);}
   if(n>=6){W1.kick(t,.09);W1.kick(t+4*bt,.07);var row=b%8;for(i=0;i<8;i++)if((i&row)===i)W1.hat(t+(i+.5)*bt,.018,i===7);}
   if(n>=6&&R(b,5)<.5)W1.bulles(note(m[3],2),t+(3+R(b,6)*4)*bt,.012);
   if(n>=7){var pf=0;for(k=0;k<4;k++){var fa=mtof(w.root-12+[0,3,7,5][(k+b)%4]+ch[0]);W1.acid(fa,t+(1+k)*bt,bt*.9,.018,k%2?pf:0);pf=fa;}}
   var bus=n>=8?W1.flBus():lay.theme;if(b%2===0)for(k=0;k<3;k++)W1.fm(note(m[k*2%5],1),t+(.5+k*2.5)*bt,2.2,.022,2,.3,bus,.55,.35);}
  else{ /* D — RESPIRATION */
   W1.fm(note(m[0],0),t+.5,len*.9,.03,3.5,.5,lay.theme,.7,.2);
   if(n>=4)for(k=0;k<2;k++)if(R(b,7+k)<.6)W1.goutte(note(m[k+2],2),t+(1+R(b,9+k)*6)*bt,.016);
   if(n>=9&&b%16===15)MFX.begaie(note(m[4],1),t+7*bt,bt,Math.pow(2,1+cyc%4),.026);}
  if(n>=10&&b%16===7)W1.riser(t,len,.016);}};
/* ── W1N (R113) : MONDE 1 — refonte DEPUIS ZÉRO. Bruitisme organique qui respire ; la texture naît des formules. ─────────
   Point de départ : le préréglage Quantone de Simon (8 oct.) — fa♯ lydien, grave appuyé et médium creusé, flanger profond,
   rythmes lo‑fi, gouttes, nappe sinus à attaque lente et filtre résonant, basse « triton + ressort amorti ».
   Aucune mélodie au premier plan : la matière de l'atelier (air, bois, frottement, crépitement) devient musique.
   FORMULES → TEXTURES
   · Souffle      B(t) = ((1 − cos 2πt/T)/2)^1,6, T ≈ 1,5 mesure ; une seconde respiration à T·φ (φ = nombre d'or) : jamais alignées.
   · Marée        M(u) = sin²(πu) sur 16 mesures : elle règle la densité de tout et fait ÉMERGER des notes du bruit (Q des filtres).
   · Chœur d'air  bruit rose → 4 filtres passe‑bande sur les degrés de fa♯ lydien ; Q = 3 + M·25 : bruit à marée basse, accord à marée haute.
   · Crépitement  processus de Poisson (λ ∝ souffle × marée), amplitudes de Pareto (u^−1/1,5) : quelques gros craquements, beaucoup de petits.
   · Grains       carte logistique xₙ₊₁ = r·xₙ(1 − xₙ), r de 3,62 (niveau 1) à 3,92 (niveau 12) : du presque régulier au chaos ;
                  x choisit hauteur, place et panoramique de grains de bruit accordés.
   · Bois         modes d'une poutre libre (Euler‑Bernoulli) 1 : 2,756 : 5,404 ; rythme euclidien E(k,8) (Bjorklund), k suit la marée.
   · Frottement   bruit dans un résonateur en peigne (retard 1/f, réinjection 0,9) ; f fait une marche brownienne ;
                  à partir du niveau 7 la hauteur rebondit en ressort amorti 1,3·e^(−2,4t)·cos(6πt).
   · Basse        sinus « triton » f₀·(√2)^s avec rebond de ressort (le préréglage de Simon), seulement à marée haute.
   · Nappe        trois sinus à attaque lente, filtre résonant qui s'ouvre et se referme, notes ordonnées par Fibonacci mod 4.
   · Vent         montée sans fin (Shepard) sur bruit filtré : yₖ = 4((x+8)/16 + k/4 mod 1) − 2, volume e^(−yₖ²).
   · Bégaiement   fin de cycle : un craquement redéclenché 2^k fois.
   Tout passe par un flanger lent et profond (comme le réglage de Simon) puis la réverbération.
   Le monde se construit niveau par niveau (n = rang 0…11) :
   0 souffle + chœur d'air · 1 crépitement · 2 grains logistiques · 3 bois euclidien · 4 frottement · 5 notes qui émergent + gouttes ·
   6 basse triton‑ressort · 7 nappe sinus · 8 bois en onde de pendules · 9 vent sans fin · 10 bégaiement · 11 tout, chaos maximal. */
var W1N={PHI:(1+Math.sqrt(5))/2,LYD:[0,2,4,6,7,9,11],ROOT:54,
 init:function(){if(lay._n)return lay._n;var N={x:.37,walk:0,last:0},c=ac;
  function src(off){var s=c.createBufferSource();s.buffer=noiseBuf;s.loop=true;s.start(c.currentTime,off);return s;}
  /* flanger lent et profond : toutes les textures y passent */
  N.fl=c.createGain();var dry=c.createGain(),d=c.createDelay(.05),fb=c.createGain(),wet=c.createGain(),lf=c.createOscillator(),dep=c.createGain();
  dry.gain.value=.65;d.delayTime.value=.006;fb.gain.value=.68;wet.gain.value=.75;lf.frequency.value=.13;dep.gain.value=.004;N.dep=dep;
  lf.connect(dep);dep.connect(d.delayTime);lf.start();N.fl.connect(dry);dry.connect(lay.tex);N.fl.connect(d);d.connect(fb);fb.connect(d);d.connect(wet);wet.connect(lay.tex);
  var fr=c.createGain();fr.gain.value=.5;wet.connect(fr);fr.connect(revIn);
  /* grondement (la pièce) */
  var s1=src(.1),lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=95;lp.Q.value=.8;N.gR=c.createGain();N.gR.gain.value=0;s1.connect(lp);lp.connect(N.gR);N.gR.connect(lay.sub);
  /* chœur d'air : 4 filtres passe‑bande */
  var s2=src(.7),cs=c.createGain();cs.gain.value=1;cs.connect(lay.pad);var rs=c.createGain();rs.gain.value=.55;cs.connect(rs);rs.connect(revIn);N.bp=[];N.gc=[];
  for(var k=0;k<4;k++){var bp=c.createBiquadFilter(),g=c.createGain(),p=c.createStereoPanner?c.createStereoPanner():null;bp.type='bandpass';bp.Q.value=3;bp.frequency.value=300+k*120;g.gain.value=0;
   s2.connect(bp);bp.connect(g);if(p){p.pan.value=[-.6,.6,-.25,.25][k];g.connect(p);p.connect(cs);}else g.connect(cs);N.bp.push(bp);N.gc.push(g);}
  /* frottement : peigne */
  var s3=src(1.3),bpS=c.createBiquadFilter();bpS.type='bandpass';bpS.frequency.value=1100;bpS.Q.value=.8;N.gS=c.createGain();N.gS.gain.value=0;
  var oS=c.createGain();oS.gain.value=1.6;N.rz=[];s3.connect(bpS);bpS.connect(N.gS);
  [[1,45,1],[2,38,.6],[3,30,.35]].forEach(function(h){var f=c.createBiquadFilter(),g=c.createGain();f.type='bandpass';f.frequency.value=220*h[0];f.Q.value=h[1];g.gain.value=h[2];N.gS.connect(f);f.connect(g);g.connect(oS);N.rz.push(f);});
  oS.connect(N.fl);
  return lay._n=N;},
 hush:function(tc){var N=lay._n;if(!N||!ac)return;var t=ac.currentTime;N.gR.gain.cancelScheduledValues(t);N.gR.gain.setTargetAtTime(0,t,tc||.4);N.gS.gain.cancelScheduledValues(t);N.gS.gain.setTargetAtTime(0,t,tc||.4);   /* R154 : le souffle du monde 1 se tait hors de son monde et dans les menus */
  for(var k=0;k<4;k++){N.gc[k].gain.cancelScheduledValues(t);N.gc[k].gain.setTargetAtTime(0,t,tc||.4);}},
 B:function(ta,T,ph){var v=Math.max(0,.5-.5*Math.cos(2*Math.PI*ta/T+(ph||0)));return Math.pow(v,1.6);},
 hz:function(deg,oct){var L=W1N.LYD,n=L.length,i=((deg%n)+n)%n;return mtof(W1N.ROOT+lvVar().tr+L[i]+12*(Math.floor(deg/n)+(oct||0)));},
 logi:function(N,r){N.x=r*N.x*(1-N.x);if(N.x<.001||N.x>.999)N.x=.37;return N.x;},
 euclid:function(k,n,rot){var o=[],i;for(i=0;i<n;i++)o.push(Math.floor((i+rot)*k/n)!==Math.floor((i+rot-1)*k/n));return o;},
 burst:function(t,dur,type,f,q,g,dest,pan){var s=ac.createBufferSource(),fl=ac.createBiquadFilter(),a=ac.createGain();s.buffer=noiseBuf;fl.type=type;fl.frequency.value=f;fl.Q.value=q;
  a.gain.setValueAtTime(.0001,t);a.gain.linearRampToValueAtTime(g,t+Math.min(.004,dur*.2));a.gain.exponentialRampToValueAtTime(.0001,t+dur);s.connect(fl);fl.connect(a);
  var last=a;if(pan&&ac.createStereoPanner){var p=ac.createStereoPanner();p.pan.value=pan;a.connect(p);last=p;}last.connect(dest);s.start(t,Math.random()*1.5);s.stop(t+dur+.05);},
 grain:function(t,f,len,g,pan,dest){var s=ac.createBufferSource(),fl=ac.createBiquadFilter(),a=ac.createGain();s.buffer=noiseBuf;fl.type='bandpass';fl.frequency.value=f;fl.Q.value=22;
  a.gain.setValueAtTime(0,t);a.gain.linearRampToValueAtTime(g,t+len*.5);a.gain.linearRampToValueAtTime(0,t+len);s.connect(fl);fl.connect(a);
  var last=a;if(ac.createStereoPanner){var p=ac.createStereoPanner();p.pan.value=pan;a.connect(p);last=p;}last.connect(dest);s.start(t,Math.random()*1.5);s.stop(t+len+.05);},
 wood:function(t,f,g,pan,dest){[[1,32,1],[2.756,26,.45],[5.404,20,.18]].forEach(function(m){W1N.burst(t,.35/m[0]+.08,'bandpass',f*m[0],m[1],g*m[2]*6,dest,pan);});},
 drop:function(t,f,g){var o=ac.createOscillator(),e=ac.createGain();o.frequency.setValueAtTime(f*1.5,t);o.frequency.exponentialRampToValueAtTime(f,t+.025);
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.003);e.gain.exponentialRampToValueAtTime(.0001,t+.17);o.connect(e);tosend(e,lay.tex,.7,.45);o.start(t);o.stop(t+.2);},
 swell:function(t,f,dur,g){var e=ac.createGain(),lp=ac.createBiquadFilter(),i;lp.type='lowpass';lp.Q.value=6.7;lp.frequency.setValueAtTime(380,t);lp.frequency.linearRampToValueAtTime(1700,t+dur*.45);lp.frequency.linearRampToValueAtTime(500,t+dur);
  for(i=0;i<3;i++){var o=ac.createOscillator();o.frequency.value=f*(i===2?2:1)*(1+(i-1)*.0015);o.connect(lp);o.start(t);o.stop(t+dur+1.7);}
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+1.1);e.gain.setValueAtTime(g,t+dur);e.gain.exponentialRampToValueAtTime(.0001,t+dur+1.6);lp.connect(e);tosend(e,lay.pad,.6,.45);},
 tritone:function(t,f,g,from){var o=ac.createOscillator(),e=ac.createGain(),D=1.5,n=64,a=new Float32Array(n),i;
  for(i=0;i<n;i++){var s=i/(n-1)*D,base=from?f+(from-f)*Math.exp(-s/.07):f;a[i]=base*Math.pow(2,1.3*Math.exp(-2.4*s)*Math.cos(6*Math.PI*s)/12);}
  o.frequency.setValueCurveAtTime(a,t,D);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.01);e.gain.exponentialRampToValueAtTime(.0001,t+D);o.connect(e);tosend(e,lay.sub,.08,0);o.start(t);o.stop(t+D+.05);},
 bar:function(t,b,ph,len){
  if(st===0){W1N.hush(.5);return;}   /* R154 : rien dans les menus */
  var N=W1N.init(),n=LV%12,bt=len/8,u=(b%8)/8,   /* R118 : cycle de 8 mesures (retour Simon : trop lent) */
   M=Math.pow(Math.sin(Math.PI*u),2),dens=.35+.65*n/11,T=len*1.5,i,k,j,R=Math.random,
   r=3.62+.3*n/11,c=ac;
  /* souffle et marée : grondement + chœur d'air, points toutes les 1/16 de mesure */
  var degs=[0,4,7,9].map(function(d,q){return d+[0,1,1,2,3,1][(b+q)%6];}),Q=3+M*(n>=5?25:6);
  for(k=0;k<4;k++){N.bp[k].frequency.setTargetAtTime(W1N.hz(degs[k],k<2?0:1),t,1.2);N.bp[k].Q.setTargetAtTime(Q,t,2);}
  for(j=0;j<=16;j++){var ta=t+j*len/16,B1=W1N.B(ta,T),B2=W1N.B(ta,T*W1N.PHI,1.3);
   N.gR.gain.linearRampToValueAtTime(.085*B1*(.3+.7*M),ta);   /* R118 : plus de fond permanent — la respiration descend jusqu'au silence */
   for(k=0;k<4;k++)N.gc[k].gain.linearRampToValueAtTime((k%2?B2:B1)*(.035+.05*M)*(1+Q/14)*(k<2?1:.7),ta);}
  N.dep.gain.setTargetAtTime(.002+.0035*n/11,t,2);
  /* crépitement : Poisson × Pareto */
  if(n>=1){var lam=(1.5+7*M)*dens,cnt=0,tt=0;while(true){tt+=-Math.log(1-R())/lam*len/8*1.0;if(tt>len)break;var ta2=t+tt,Bc=W1N.B(ta2,T);if(R()>.35+.65*Bc)continue;
    var g=Math.min(.09,.012*Math.pow(1-R(),-1/1.5));W1N.burst(ta2,.004+R()*.01,'highpass',2200+R()*3000,.7,g,N.fl,R()*1.6-.8);if(++cnt>14)break;}}
  /* grains logistiques */
  if(n>=2){var ng=Math.round(2+7*M*dens);for(i=0;i<ng;i++){var x=W1N.logi(N,r),x2=W1N.logi(N,r);W1N.grain(t+x2*len,W1N.hz(Math.floor(x*10),1),.06+x*.16,.05+.04*M,x*1.6-.8,N.fl);}}
  /* bois euclidien (ou onde de pendules au niveau 9+, en milieu de cycle) */
  if(true){var kk=Math.max(2,Math.min(6,Math.round(2+(n>=2?1:0)+(n>=3?1:0)+M*2*dens+(n>=6?1:0))));   /* R118 : pulsation légère dès le niveau 1, groove discret au 3–4 */
   if(n>=8&&M>.5){var x0=(b%2)*8;[3,4,5].forEach(function(Np,q){MFX.pendules(x0,x0+8,Np).forEach(function(x){W1N.wood(t+(x-x0)*bt,W1N.hz(q*2-7,0),.03,(q-1)*.5,N.fl);});});}
   else{var E=W1N.euclid(kk,8,b%8);for(i=0;i<8;i++)if(E[i]&&R()<.85)W1N.wood(t+i*bt+(R()-.5)*.03,W1N.hz((i*3+b)%5-7,0),.028+.02*M,(i%3-1)*.4,N.fl);}}
  /* frottement : peigne, hauteur en marche brownienne (+ rebond de ressort au niveau 7+) */
  if(n>=4&&R()<.35+.5*M){N.walk=Math.max(-5,Math.min(5,N.walk+(R()<.5?-1:1)));var fS=W1N.hz(N.walk,0),t0=t+R()*len*.4,du=2+R()*3;
   if(t0>(N.dEnd||0))N.rz.forEach(function(F,h){try{if(n>=6){var a=new Float32Array(48);for(i=0;i<48;i++){var s=i/47*du;a[i]=fS*(h+1)*Math.pow(2,1.3*Math.exp(-2.4*s)*Math.cos(6*Math.PI*s)/12);}F.frequency.setValueCurveAtTime(a,t0,du);}
     else F.frequency.setTargetAtTime(fS*(h+1),t0,.05);}catch(e){}});N.dEnd=t0+du;
   N.gS.gain.setTargetAtTime(.05+.05*M,t0,du*.25);N.gS.gain.setTargetAtTime(0,t0+du*.6,du*.2);}
  /* gouttes */
  if(n>=5){var nd=Math.round(R()*2*dens+M);for(i=0;i<nd;i++)W1N.drop(t+R()*len,W1N.hz(Math.floor(R()*7),2),.014);}
  /* basse triton + ressort, à marée haute */
  if(n>=6&&M>.45){var s0=b%2,f0=W1N.hz(0,-2)*Math.pow(Math.SQRT2,s0);[0,3,6].forEach(function(q,qi){if(qi<2||n>=10)W1N.tritone(t+q*bt,f0,.07,qi===0&&N.last?N.last:0);});N.last=f0;}
  /* nappe sinus lente (Fibonacci mod 4 sur les notes) */
  if(n>=7&&b%2===0){var fd=[0,2,4,6][MFX.FIB4[Math.floor(b/2)%6]];W1N.swell(t+R()*.5,W1N.hz(fd,0),len*1.4,.012+.008*M);}
  /* vent sans fin (Shepard sur bruit) */
  if(n>=9&&M>.55){var fb2=W1N.hz(0,1);for(k=0;k<3;k++){var s5=c.createBufferSource(),bp5=c.createBiquadFilter(),g5=c.createGain();s5.buffer=noiseBuf;s5.loop=true;bp5.type='bandpass';bp5.Q.value=7;
    var py=null;for(j=0;j<=8;j++){var xx=(b%2)*8+j,y=4*((((xx+8)/16+k/3)%1))-2,tj=t+j*bt;if(py===null||y<py){bp5.frequency.setValueAtTime(fb2*Math.pow(2,y),tj);g5.gain.setValueAtTime(.05*Math.exp(-y*y),tj);}
     else{bp5.frequency.linearRampToValueAtTime(fb2*Math.pow(2,y),tj);g5.gain.linearRampToValueAtTime(.05*Math.exp(-y*y),tj);}py=y;}
    g5.gain.linearRampToValueAtTime(0,t+len+.2);s5.connect(bp5);bp5.connect(g5);g5.connect(N.fl);s5.start(t,R());s5.stop(t+len+.3);}}
  /* bégaiement de fin de cycle */
  if(n>=10&&b%16===15){var nr=Math.pow(2,1+Math.floor(b/16)%4);for(i=0;i<nr;i++)W1N.burst(t+7*bt+i*bt/nr,.012,'bandpass',1800,3,.05*(1-i/(nr*1.5)),N.fl,i%2?.4:-.4);}
 }};
/* ── styles des mondes : chaque bar() écrit une mesure de musique à partir du temps t ── */
/* ── TXN (R319) : musique générative des mondes 2 et suivants — textures échantillonnées jouées de façon occasionnelle, rythme
   qui s'installe avec le rang du niveau, flux polymétriques sans boucle. Les échantillons sont des mp3 mono (assets/audio/<jeu>/),
   découpés en 8 tranches de 0,5 s ; aucun n'est rejoué avant un délai aléatoire (jamais de motif qui revient à l'identique). ── */
var TXN={buf:{},req:{},bus:null,S:{}};
TXN.init=function(){if(TXN.bus&&TXN.bus.ctx===ac)return TXN.bus;TXN.buf={};TXN.req={};TXN.S={};
 var b=ac.createGain(),flt=ac.createBiquadFilter(),hp=ac.createBiquadFilter(),sd=ac.createGain();flt.type='lowpass';flt.frequency.value=9000;flt.Q.value=.7;hp.type='highpass';hp.frequency.value=70;b.gain.value=1;b.connect(flt);flt.connect(hp);hp.connect(mus);b.flt=flt;
 sd.gain.value=.5;hp.connect(sd);sd.connect(revIn);b.ctx=ac;TXN.bus=b;return b;};
TXN.load=function(set,n){var k=set+n;if(TXN.buf[k]||TXN.req[k]||!ac)return;TXN.req[k]=1;
 try{fetch((window.QXA&&QXA[set+'/'+n])||('assets/audio/'+set+'/'+n+'.mp3')).then(function(r){return r.arrayBuffer();}).then(function(a){
  var ok=function(bf){TXN.buf[k]=bf;},no=function(){TXN.req[k]=0;};var pr=ac.decodeAudioData(a,ok,no);if(pr&&pr.catch)pr.catch(no);}).catch(function(){TXN.req[k]=0;});}catch(e){TXN.req[k]=0;}};
TXN.slice=function(set,n,sl,t,g,pan,rate,tl){var bf=TXN.buf[set+n];if(!bf||!isFinite(sl)||!isFinite(t)||!budget(t,.9))return;
 var src=ac.createBufferSource(),e=ac.createGain(),p=ac.createStereoPanner?ac.createStereoPanner():null,L=bf.duration/8,d=L/(rate||1);
 src.buffer=bf;src.playbackRate.value=rate||1;e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.006);e.gain.setValueAtTime(g,t+Math.max(.02,d-.05));e.gain.linearRampToValueAtTime(.0001,t+d);
 src.connect(e);var o=e;if(p){p.pan.value=pan||0;e.connect(p);o=p;}o.connect(TXN.bus);if(tl){var gg=ac.createGain();gg.gain.value=tl;o.connect(gg);gg.connect(tail());}
 src.start(t,sl*L,L+.02);src.stop(t+d+.05);};
TXN.kick=function(t,g,f0){var o=ac.createOscillator(),e=ac.createGain();o.type='sine';o.frequency.setValueAtTime(f0*2.1,t);o.frequency.exponentialRampToValueAtTime(f0,t+.08);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.006);e.gain.exponentialRampToValueAtTime(.0001,t+.5);o.connect(e);e.connect(TXN.bus);o.start(t);o.stop(t+.55);};
TXN.tick=function(t,g,f,q,dur){var n=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain();n.buffer=noiseBuf;bp.type='bandpass';bp.frequency.value=f;bp.Q.value=q||4;
 e.gain.setValueAtTime(g,t);e.gain.exponentialRampToValueAtTime(.0001,t+(dur||.05));n.connect(bp);bp.connect(e);e.connect(TXN.bus);n.start(t,Math.random()*2);n.stop(t+(dur||.05)+.03);};
TXN.bar=function(t,b,ph,len,C){
 var N=TXN.init(),n=LV%12,u=Math.pow(n/11,.8),brk=Math.max(0,Math.min(1,(n-4)/6)),full=n>=5?1:0,R=Math.random,S=TXN.S[C.set]||(TXN.S[C.set]={next:{},last:{},bar:0,ns:0,si:0,mute:{},len:{},off:{},bell:0,lv:-1,fill:0}),k;
 if(st===0){S.ns=0;return;}
 C.tex.forEach(function(x){TXN.load(x.set||C.set,x.n);});C.rows.concat(C.fill||[],C.stut?C.stut.src:[]).forEach(function(x){if(x.k!=='kick'&&x.k!=='tick')TXN.load(x.set||C.set,x.k);});
 if(C.base){(C.base.all?['q'+(n+1),'q'+Math.min(12,n+2)]:['q1','q6','q12']).forEach(function(x){TXN.load(C.base.set||'w2',x);});}
 S.bar++;if(S.lv!==n){S.lv=n;S.t0=t;}N.gain.setTargetAtTime(C.level[0]+(C.level[1]-C.level[0])*u,t,.5);
 /* dès le 6e niveau : le filtre de bus voyage (sons « dansants mais texturés ») */
 if(N.flt)N.flt.frequency.setTargetAtTime(full&&!(C.base&&C.base.faith)?(900+R()*(1-.5*R())*8200):9000,t,.35);
 /* socle : extraits des rendus Quantone (monde 2 n1/n6/n12) ; le niveau choisit la version, début aléatoire, fondu croisé */
 if(C.base&&C.base.faith){ /* fidélité : le rendu Quantone du niveau est joué tel quel, en continu (fondus croisés de 2 s sur la même matière), sans filtre ni nappe */
  var fn=C.base.all?'q'+(n+1):(n<4?'q1':n<8?'q6':'q12'),fb=TXN.buf[C.base.set+fn];if(!fb){TXN.load(C.base.set,fn);TXN.wait=1;}
  if(fb&&budget(t,1)&&(TXN.ck!==C.base.set+fn||t+len>=(S.bEnd||0)-2.2)){var ch=TXN.ck!==C.base.set+fn,xf=(ch&&TXN.cs&&TXN.cs!==C.base.set)?7:2,t0=ch?t:Math.max(t,S.bEnd-2.2),du=Math.min(22,fb.duration-.5),of=ch?((S.bOff||0)%Math.max(1,fb.duration-du)):(S.bOff||0),ge2=ac.createGain(),sr3=ac.createBufferSource(),g2=C.base.g*(1-.03*Math.max(0,n-5));
   if(of+du>fb.duration-.2)of=0;
   if(ch&&TXN.cg){try{TXN.cg.gain.cancelScheduledValues(t);TXN.cg.gain.setValueAtTime(TXN.cg.gain.value,t);TXN.cg.gain.linearRampToValueAtTime(.0001,t+(xf>2?xf+1:2.5));}catch(e){}}
   sr3.buffer=fb;ge2.gain.setValueAtTime(.0001,t0);ge2.gain.linearRampToValueAtTime(g2,t0+xf);ge2.gain.setValueAtTime(g2,t0+du-2);ge2.gain.linearRampToValueAtTime(.0001,t0+du);
   sr3.connect(ge2);ge2.connect(TXN.bus);sr3.start(t0,of,du+.1);sr3.stop(t0+du+.1);S.bn=fn;TXN.ck=C.base.set+fn;TXN.cs=C.base.set;TXN.cg=ge2;S.bG=ge2;S.bEnd=t0+du;S.bOff=of+du-2;}
 }else if(C.base&&t>=(S.bEnd||0)-2.2){var bn=n<4?'q1':n<8?'q6':'q12',bb=TXN.buf[(C.base.set||'w2')+bn];if(bb&&budget(t,1)){var dur=12+R()*8,off=R()*(bb.duration-dur-1),rt=C.base.rate*(.97+.06*R()),sr2=ac.createBufferSource(),ge=ac.createGain(),gg=C.base.g*(.65+.35*u),t0=Math.max(t,S.bEnd?S.bEnd-2.2:t);
  sr2.buffer=bb;sr2.playbackRate.value=rt;ge.gain.setValueAtTime(.0001,t0);ge.gain.linearRampToValueAtTime(gg,t0+2);ge.gain.setValueAtTime(gg,t0+dur-2);ge.gain.linearRampToValueAtTime(.0001,t0+dur);sr2.connect(ge);ge.connect(TXN.bus);sr2.start(t0,off,dur*rt+.1);sr2.stop(t0+dur+.1);S.bEnd=t0+dur;}}
 C.tex.forEach(function(x){if(n<x.from)return;var nx=S.next[x.n];if(nx===undefined)nx=S.next[x.n]=t+R()*x.gap[1]*.4;
  if(t+len<nx)return;var cnt=1+(R()<.3?1:0)+(x.cl&&R()<.4?x.cl:0),tt=Math.max(t,nx);
  for(k=0;k<cnt;k++){var sl;do{sl=Math.floor(R()*8);}while(sl===S.last[x.n]);S.last[x.n]=sl;
   TXN.slice(x.set||C.set,x.n,sl,tt+k*(.12+R()*.5),x.g*(.75+.5*R())*(1+.4*u),(R()*2-1)*.8,x.rate?x.rate[0]+R()*(x.rate[1]-x.rate[0]):1,.25);}
  S.next[x.n]=t+len*.4+x.gap[0]+R()*(x.gap[1]-x.gap[0])*(1.5-1.05*u);});
 if(n>=C.rhy){
  /* tous les 3-6 mesures : absences, longueurs de cycle et décalages changent → le beat se brise de plus en plus (IDM) */
  if(S.bar%4===1||S.bar<2)C.rows.forEach(function(x,j){S.len[j]=(brk>0&&x.k!=='kick'&&R()<brk*.7)?[12,14,15,10,9,13][Math.floor(R()*6)]:16;S.off[j]=brk>0&&R()<brk*.6?Math.floor(R()*5):0;});
  C.rows.forEach(function(x,j){if(S.mute[j]>0)S.mute[j]--;else if(n>=x.from&&R()<.2*(1-.6*u)+.08*brk)S.mute[j]=1+Math.floor(R()*3);});
  S.fill=(brk>0&&S.bar%4===3&&R()<.45+.4*brk)?1:0;
  if(!S.ns||S.ns<t-1)S.ns=t;
  while(S.ns<t+len){var tt=S.ns,cyc=S.si%16,tj=tt;S.si++;S.ns+=C.step*(S.si%2?1+C.swing:1-C.swing);
   C.rows.forEach(function(x,j){if(n<x.from||S.mute[j]>0)return;var L=S.len[j]||16,pos=(S.si+(S.off[j]||0))%L,
    hit=x.s.indexOf(pos)>=0&&R()<x.pr;if(!hit&&x.ghost&&R()<x.ghost*(.3+u+brk))hit=true;if(x.drift&&(S.si%x.drift)===0&&R()<.6)hit=true;
    if(!hit)return;var g=x.g*(.6+.5*u)*(.8+.4*R());tj=tt+(R()-.5)*.01;
    if(x.k==='kick')TXN.kick(tj,g,x.hz||C.kickHz);else if(x.k==='tick')TXN.tick(tj,g,x.f*(.92+.16*R()),x.q,x.d);
    else TXN.slice(x.set||C.set,x.k,x.i!=null?x.i:Math.floor(R()*8),tj,g,x.pan||0,x.rate?x.rate[0]+R()*(x.rate[1]-x.rate[0]):1,full&&R()<.12?.35:0);});
   /* bégaiement (fin de cycle) : le dernier élan est redéclenché 2, 4 ou 8 fois, de plus en plus faible */
   if(C.stut&&n>=C.stut.from&&cyc>=12&&R()<C.stut.p*(.4+.6*brk)){var rp=[2,4,8][Math.floor(R()*3)],src=C.stut.src[Math.floor(R()*C.stut.src.length)],sl3=src.i!=null?src.i:Math.floor(R()*8),pn=R()*1.4-.7;
    for(k=0;k<rp;k++)TXN.slice(src.set||C.set,src.k,sl3,tt+k*C.step/rp*(rp>2?1:1),src.g*(1-k/(rp*1.3)),pn,(src.rate?src.rate[0]+R()*(src.rate[1]-src.rate[0]):1)*(1+k*.02),.3);}
   /* relances : rafale aléatoire de caisse claire / charleys en fin de mesure */
   if(S.fill&&cyc>=8&&C.fill&&R()<.35+.5*(cyc-8)/8){var f=C.fill[Math.floor(R()*C.fill.length)];TXN.slice(f.set||C.set,f.k,f.i!=null?f.i:Math.floor(R()*8),tt+R()*C.step,f.g*(.6+.6*R()),(R()*2-1)*.6,f.rate?f.rate[0]+R()*(f.rate[1]-f.rate[0]):1,.2);}}}
 /* notes : cloches isolées, phrase en rebond rare, basse, arpège de Fibonacci dès le 6e niveau */
 if(C.bell){var m=MOTIF[ph%MOTIF.length],bn=Math.floor(R()*2+.5+u);for(k=0;k<bn;k++)bell(note(m[Math.floor(R()*5)],C.bell.oct||1),t+R()*len*.9,2.2,C.bell.g*(.7+.6*R()),.6,.35,N);
  if(n>=C.bell.from&&t>=(S.bell||0)){var dt=C.bell.dt,t2=t+R()*len*.4;for(k=0;k<C.bell.n;k++){bell(note(m[k%5],C.bell.oct||1),t2,1.8,C.bell.g*1.3,.55,.3,N);t2+=dt;dt*=C.bell.rb;}S.bell=t+len*(2+R()*4);}}
 if(C.bass&&n>=C.bass.from){var bn2=1+(R()<.5+.4*u?1:0)+(full&&R()<.5?1:0);for(k=0;k<bn2;k++)voice(note(Math.floor(R()*5)-3,C.bass.oct),t+Math.floor(R()*8)*len/8,len*.3,C.bass.g*(.7+.6*u),'triangle',lay.theme,.2,.1,.02);}
 if(full&&C.arp&&R()<.55){var FB=[0,1,1,2,0,2,1,3],a0=Math.floor(R()*3),ts=t+R()*len*.4,nn=6+Math.floor(R()*6);for(k=0;k<nn;k++)if(R()<.8)bell(note(FB[(k+a0)%8]*(C.arp.mul||1)+(C.arp.base||0),C.arp.oct||1),ts+k*C.step*(R()<.2?2:1),.5,C.arp.g*(.7+.5*R()),.4,.3,N);}};
var CFG1={base:{set:'w1',g:1.5,rate:1,faith:1,all:1},set:'w1',level:[1.4,1.4],kickHz:50,rhy:99,step:.4,swing:0,tex:[],rows:[]};
var CFG2={base:{set:'w2',g:1.5,rate:1,faith:1,all:1},set:'w2',level:[1.4,1.4],kickHz:50,rhy:99,step:.4,swing:0,tex:[],rows:[]};
var CFG3={base:{set:'w3',g:1.5,rate:1,faith:1,all:1},set:'w3',level:[1.4,1.4],kickHz:50,rhy:99,step:.4,swing:0,tex:[],rows:[]};
var CFG4={base:{set:'w4',g:1.5,rate:1,faith:1,all:1},set:'w4',level:[1.4,1.4],kickHz:46,rhy:99,step:.42,swing:.1,
 tex:[],rows:[]};
var CFG5={base:{set:'w5',g:1.5,rate:1,faith:1,all:1},set:'w5',level:[1.4,1.4],kickHz:46,rhy:99,step:.38,swing:.06,
 tex:[],rows:[]};
var STY=[
 {name:'atelier',noPad:true,padWave:'sine',padOct:0,padG:0,fill:0,cut:1800,trem:.05,dt:.66,fb:.42,bar:7.5,chordEvery:1,
  play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,CFG1);}},
 {name:'fonderie',padWave:'triangle',padOct:-1,padG:0,fill:0,cut:900,trem:.12,dt:.5,fb:.3,bar:8,chordEvery:2,
  play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,CFG2);}},
 {name:'chaine',padWave:'sine',padOct:0,padG:0,fill:0,cut:1500,trem:.1,dt:.375,fb:.3,bar:6,chordEvery:2,
  play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,CFG3);}},
 {name:'glacier',padWave:'sine',padOct:0,padG:0,fill:0,cut:1600,trem:.07,dt:.62,fb:.22,bar:8.4,chordEvery:2,
  play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,CFG4);}},
 {name:'soufflerie',padWave:'sine',padOct:0,padG:0,fill:0,cut:1700,trem:.06,dt:.56,fb:.24,bar:8,chordEvery:2,
  play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,CFG5);}}];
(function(){var N=['mecanique','gravite','magnetisme','faille','filaments','quantique'];
 N.forEach(function(nm,k){var w=6+k,cf={base:{set:'w'+w,g:1.5,rate:1,faith:1,all:1},set:'w'+w,level:[1.4,1.4],kickHz:46,rhy:99,step:.4,swing:.06,tex:[],rows:[]};
  STY.push({name:nm,padWave:'sine',padOct:0,padG:0,fill:0,cut:1700,trem:.06,dt:.56,fb:.24,bar:8,chordEvery:2,play:function(t,b,ph){TXN.bar(t,b,ph,this.bar/lvVar().tempo,cf);}});});})();
function styleOf(){return STY[Math.min(wi,STY.length-1)]||STY[0];}   /* mondes 5 à 11 : repris des quatre premiers en attendant leur propre style */
function tickAt(horizon){
 var s=styleOf(),w=W();
 while(next<horizon){var t=next,len=s.bar/lvVar().tempo;
  if(chordI%s.chordEvery===0)padChord(Math.floor(chordI/s.chordEvery),t,Math.max(1,len*s.chordEvery*(s.fill||.7)-3));
  s.play(t,chordI,phrase);if(chordI%2===1)phrase++;
  chordI++;next+=TXN.wait?(TXN.wait=0,.4):len;}}   /* R338 : buffer pas encore décodé → on réessaie dans 0,4 s au lieu d'attendre une mesure (c'était la source des blancs) */
function stopMusic(){clearInterval(timer);timer=0;['pad','theme','tex','sub'].forEach(function(n){if(lay[n])lay[n].gain.setTargetAtTime(0,ac.currentTime,.25);});}

/* ══ BIBLE SONORE (R54) — réalisation de docs/AUDIT_R52.md §1.5–1.6 ══
   Principes : effets secs et proches (la musique est large et lointaine) ; rien au‑dessus de ~1 kHz en hauteur ;
   chaque son a une « seconde vie » — une queue très basse qui part dans l'espace (bus TAIL : écho lent filtré, large) ;
   un élément continu = UNE boucle dont on module le volume ; chaque monde a sa MATIÈRE (table MAT) reprise par ses chocs. */
function now(){return ac.currentTime+.005;}
var duckT=0;
function duck(){if(!mus||!ac||ac.constructor.name==='OfflineAudioContext')return;var t=ac.currentTime;if(t-duckT<.08)return;duckT=t;
 if(mus.gain.cancelAndHoldAtTime)mus.gain.cancelAndHoldAtTime(t);else{var v0=mus.gain.value;mus.gain.cancelScheduledValues(t);mus.gain.setValueAtTime(v0,t);}
 mus.gain.setTargetAtTime(vol.mus*.62,t,.05);mus.gain.setTargetAtTime(vol.mus,t+.3,.3);}
var ENDS=[],RR=0,wow=null,TAIL=null;
function budget(t,dur){ENDS=ENDS.filter(function(e){return e>t;});if(ENDS.length>=12)return false;ENDS.push(t+dur);return true;}
function wowOf(o){if(!wow){wow=ac.createGain();wow.gain.value=6;var l=ac.createOscillator();l.frequency.value=.55;l.connect(wow);l.start();}try{wow.connect(o.detune);}catch(e){}}
function tail(){ /* la « seconde vie » : écho lent, très filtré, large, qui part loin */
 if(TAIL&&TAIL.ctx===ac)return TAIL.inp;
 var inp=ac.createGain(),dl=ac.createDelay(2),fb=ac.createGain(),lp=ac.createBiquadFilter(),out=ac.createGain(),p=ac.createStereoPanner?ac.createStereoPanner():null;
 dl.delayTime.value=.62;fb.gain.value=.42;lp.type='lowpass';lp.frequency.value=650;out.gain.value=.5;
 inp.connect(dl);dl.connect(lp);lp.connect(fb);fb.connect(dl);lp.connect(out);
 if(p){var l=ac.createOscillator(),lg=ac.createGain();l.frequency.value=.07;lg.gain.value=.8;l.connect(lg);lg.connect(p.pan);l.start();out.connect(p);p.connect(sfx);}else out.connect(sfx);
 var r=ac.createGain();r.gain.value=.5;out.connect(r);r.connect(revIn);
 TAIL={ctx:ac,inp:inp};return inp;}
function outFx(node,wet,tl){node.connect(sfx);var r=ac.createGain();r.gain.value=wet*.45;node.connect(r);r.connect(revIn);
 if(tl){var g=ac.createGain();g.gain.value=tl;node.connect(g);g.connect(tail());}duck();}

/* ── matières par monde (§1.5) : partiels, déclin, filtre, souffle du marteau, battement ── */
var MAT=[
 {n:'atelier',  p:[[1,1],[2.013,.3],[3.97,.08]],d:.55,lp:4,th:.5,beat:0},          /* bois clair et verre */
 {n:'fonderie', p:[[1,1],[2.76,.35],[5.4,.12]],d:.9,lp:3,th:.35,beat:0},           /* plaque de métal chaud */
 {n:'chaine',   p:[[1,1],[2,.2]],d:.25,lp:5,th:.8,beat:0,pulse:1},                  /* impulsion électrique */
 {n:'glacier',  p:[[1,1],[2,.25],[3,.12]],d:1.1,lp:3.2,th:.15,beat:3},              /* cristal */
 {n:'soufflerie',p:[[1,1],[3,.15]],d:.6,lp:2.5,th:.3,beat:0,air:1},                 /* tube */
 {n:'mecanique',p:[[1,1],[5.95,.18],[9.1,.05]],d:.7,lp:4,th:.6,beat:0},            /* lame de boîte à musique */
 {n:'gravite',  p:[[1,1],[2.4,.4],[4.1,.15]],d:1.6,lp:2,th:.25,beat:1.5,low:1},     /* gong grave */
 {n:'magnetisme',p:[[1,1],[1.5,.3]],d:.8,lp:2.5,th:.3,beat:5},                      /* fer, bourdon */
 {n:'faille',   p:[[1,1],[2.01,.4]],d:.7,lp:3,th:.3,beat:0,comb:1},                 /* radio, déphasage */
 {n:'filaments',p:[[1,1]],d:.9,lp:6,th:.2,beat:0,pluck:1},                          /* corde pincée */
 {n:'quantique',p:[[1,1],[2,.2]],d:1,lp:3,th:.2,beat:4}];                           /* interférences */
function M(){return MAT[wi]||MAT[0];}
function struck(f,t,g,dur,m){ /* choc d'un objet de la matière du monde */
 m=m||M();dur=dur||m.d;if(!budget(t,dur))return;f=cap(f);if(m.low)f=Math.max(70,f/2);
 var e=ac.createGain(),lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(1700,f*m.lp),t);lp.frequency.exponentialRampToValueAtTime(Math.max(160,f*1.1),t+dur);
 if(m.pluck){ /* corde pincée : excitation de bruit très accordée + fondamentale et octave qui s'éteignent vite */
  var n=ac.createBufferSource(),bp=ac.createBiquadFilter(),ex=ac.createGain();n.buffer=noiseBuf;bp.type='bandpass';bp.frequency.value=f;bp.Q.value=14;
  ex.gain.setValueAtTime(2.5,t);ex.gain.exponentialRampToValueAtTime(.001,t+.06);n.connect(bp);bp.connect(ex);ex.connect(lp);n.start(t,Math.random());n.stop(t+.08);
  [[1,1,'triangle'],[2,.25,'sine']].forEach(function(q){var o=ac.createOscillator(),og=ac.createGain();o.type=q[2];o.frequency.value=f*q[0];og.gain.value=q[1];o.connect(og);og.connect(lp);o.start(t);o.stop(t+dur+.05);});}
 else m.p.forEach(function(q,k){var o=ac.createOscillator(),og=ac.createGain();o.frequency.value=f*q[0]*(k&&m.beat?1+m.beat*.002:1);og.gain.value=q[1];
  if(m.beat&&k===0){var o2=ac.createOscillator(),o2g=ac.createGain();o2.frequency.value=f+m.beat;o2g.gain.value=.5;o2.connect(o2g);o2g.connect(lp);o2.start(t);o2.stop(t+dur+.05);}
  wowOf(o);o.connect(og);og.connect(lp);o.start(t);o.stop(t+dur+.05);});
 var attack=m.pulse?.004:.012;
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+attack);e.gain.exponentialRampToValueAtTime(g*.3,t+dur*.25);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 var last=lp;if(m.comb){var cd=ac.createDelay(.05),cg=ac.createGain();cd.delayTime.value=.0071;cg.gain.value=.6;lp.connect(cd);cd.connect(cg);cg.connect(e);}
 last.connect(e);outFx(e,.2,.12);
 if(m.th){var nn=ac.createBufferSource(),nl=ac.createBiquadFilter(),ng=ac.createGain();nn.buffer=noiseBuf;nl.type=m.air?'bandpass':'lowpass';nl.frequency.value=m.air?f*2:420;nl.Q.value=m.air?3:.7;
  ng.gain.setValueAtTime(g*m.th,t);ng.gain.exponentialRampToValueAtTime(.0001,t+(m.air?.15:.04));nn.connect(nl);nl.connect(ng);ng.connect(sfx);nn.start(t,Math.random());nn.stop(t+.2);}}
function fmBell(f,t,dur,g,ratio,index,wet,tl){
 if(!budget(t,dur))return;f=cap(f);
 var car=ac.createOscillator(),mod=ac.createOscillator(),mg=ac.createGain(),e=ac.createGain(),lp=ac.createBiquadFilter();
 car.frequency.value=f;mod.frequency.value=f*(ratio||2);wowOf(car);
 mg.gain.setValueAtTime(f*(index||1.2),t);mg.gain.exponentialRampToValueAtTime(f*.02,t+Math.min(dur*.35,.5));
 mod.connect(mg);mg.connect(car.frequency);lp.type='lowpass';lp.frequency.value=Math.min(1800,f*3);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.03);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 car.connect(lp);lp.connect(e);outFx(e,wet===undefined?.25:wet,tl===undefined?.15:tl);car.start(t);mod.start(t);car.stop(t+dur+.05);mod.stop(t+dur+.05);}
function grains(t,n,f,g,spread,rev){for(var k=0;k<n;k++){var tt=t+(rev?(n-1-k):k)*(spread||.035)*(.7+Math.random()*.6);
  var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain(),p=ac.createStereoPanner?ac.createStereoPanner():null;
  s.buffer=noiseBuf;bp.type='bandpass';bp.Q.value=6;bp.frequency.value=f*(.8+Math.random()*.5);
  e.gain.setValueAtTime(.0001,tt);e.gain.linearRampToValueAtTime(g*(rev?(k+1)/n:1-k/(n+1)),tt+.004);e.gain.exponentialRampToValueAtTime(.0001,tt+.03);
  s.connect(bp);bp.connect(e);if(p){p.pan.value=Math.random()*1.2-.6;e.connect(p);outFx(p,.12);}else outFx(e,.12);s.start(tt,Math.random()*1.5);s.stop(tt+.05);}}
function sweep(t,dur,f0,f1,g,q,tl){var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain();s.buffer=noiseBuf;s.loop=true;
 bp.type='bandpass';bp.Q.value=q||2.2;bp.frequency.setValueAtTime(f0,t);bp.frequency.exponentialRampToValueAtTime(f1,t+dur);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+dur*.4);e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 s.connect(bp);bp.connect(e);outFx(e,.2,tl||0);s.start(t,Math.random());s.stop(t+dur+.05);}
function glide(f0,f1,t,dur,g,type,tl){if(!budget(t,dur))return;var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter();o.type=type||'sine';
 o.frequency.setValueAtTime(cap(f0),t);o.frequency.exponentialRampToValueAtTime(cap(f1),t+dur);lp.type='lowpass';lp.frequency.value=1200;
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.03);e.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(lp);lp.connect(e);outFx(e,.25,tl||.1);o.start(t);o.stop(t+dur+.05);}
function sparkle(t,dur,n,g,lo,hi){ /* pétillement cosmique : des grains très brefs et très bas, dispersés dans le temps et l'espace */
 for(var k=0;k<n;k++){var tt=t+Math.random()*dur,s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain(),p=ac.createStereoPanner?ac.createStereoPanner():null;
  s.buffer=noiseBuf;bp.type='bandpass';bp.Q.value=10;bp.frequency.value=(lo||1700)+Math.random()*((hi||3000)-(lo||1700));
  var gg=g*(.4+Math.random()*.6);e.gain.setValueAtTime(.0001,tt);e.gain.linearRampToValueAtTime(gg,tt+.003);e.gain.exponentialRampToValueAtTime(.0001,tt+.05+Math.random()*.05);
  s.connect(bp);bp.connect(e);if(p){p.pan.value=Math.random()*1.6-.8;e.connect(p);outFx(p,.45,.25);}else outFx(e,.45,.25);s.start(tt,Math.random()*1.5);s.stop(tt+.12);}}
function soft(f,t,dur,g,atk){ /* note ronde : sinus + octave très discrète, attaque lente, filtrée — pour l'interface et la carte */
 if(!budget(t,dur))return;f=cap(f);var o=ac.createOscillator(),o2=ac.createOscillator(),e=ac.createGain(),g2=ac.createGain(),lp=ac.createBiquadFilter();
 o.type='sine';o2.type='sine';o.frequency.value=f;o2.frequency.value=f*2;g2.gain.value=.12;lp.type='lowpass';lp.frequency.value=Math.min(1100,f*2.2);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+(atk||.03));e.gain.exponentialRampToValueAtTime(.0001,t+dur);
 o.connect(lp);o2.connect(g2);g2.connect(lp);lp.connect(e);outFx(e,.18,.08);o.start(t);o2.start(t);o.stop(t+dur+.05);o2.stop(t+dur+.05);}
function tapeStop(f,t,g){if(!budget(t,1.6))return;f=cap(f);var o=ac.createOscillator(),o2=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter();
 o.type='triangle';[o,o2].forEach(function(x,i){x.frequency.setValueAtTime(f*(i?1.005:1),t);x.frequency.exponentialRampToValueAtTime(f*.84,t+1.4);});
 lp.type='lowpass';lp.frequency.setValueAtTime(1200,t);lp.frequency.exponentialRampToValueAtTime(260,t+1.4);
 e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.04);e.gain.exponentialRampToValueAtTime(.0001,t+1.5);
 o.connect(lp);o2.connect(lp);lp.connect(e);outFx(e,.3,.1);o.start(t);o2.start(t);o.stop(t+1.6);o2.stop(t+1.6);}
function blackHole(t,v){if(!budget(t,1.3))return;var d=1.05;
 var s=ac.createBufferSource(),bp=ac.createBiquadFilter(),e=ac.createGain();s.buffer=noiseBuf;s.loop=true;
 bp.type='bandpass';bp.Q.value=1.6;bp.frequency.setValueAtTime(2200,t);bp.frequency.exponentialRampToValueAtTime(140,t+d);
 e.gain.setValueAtTime(.0001,t);e.gain.exponentialRampToValueAtTime(.08*v,t+d*.85);e.gain.linearRampToValueAtTime(.0001,t+d+.04);
 s.connect(bp);bp.connect(e);e.connect(sfx);s.start(t,Math.random());s.stop(t+d+.1);
 var o=ac.createOscillator(),og=ac.createGain();o.type='sine';o.frequency.setValueAtTime(190,t);o.frequency.exponentialRampToValueAtTime(34,t+d);
 og.gain.setValueAtTime(.0001,t);og.gain.exponentialRampToValueAtTime(.11*v,t+d*.8);og.gain.linearRampToValueAtTime(.0001,t+d+.05);o.connect(og);og.connect(sfx);o.start(t);o.stop(t+d+.1);
 fmBell(note(0,-1),t+d+.02,2.2,.016*v,1.5,.5,.4,.35);duck();}

/* ── événements déclenchés (§1.6) ── */
var SFX={
 ui_tap:function(t,v){soft(note(4,0),t,.18,.014*v,.012);},                                                  /* goutte feutrée, grave et brève */
 ui_confirm:function(t,v){soft(note(2,0),t,.5,.018*v,.03);soft(note(4,0),t+.07,.6,.015*v,.04);},
 map_done:function(t,v){soft(note(4,0),t,1,.016*v,.06);soft(note(0,1),t+.12,1.2,.012*v,.08);},          /* carte : un niveau s'éteint en douceur */
 rail_in:function(t,v){[0,2,4,5].forEach(function(d,i){soft(note(d,0),t+i*.09,.7,.012*v,.03);});sparkle(t,.4,6,.008*v);},   /* la machine s'éveille : arpège qui monte */
 rail_out:function(t,v){soft(note(4,1),t,.9,.012*v,.02);sparkle(t,.3,5,.008*v);},
 map_next:function(t,v){soft(note(2,0),t,.9,.014*v,.08);},                                              /* carte : le suivant s'allume */
 draw_material:function(t,v){drawLoop(v);},                                                       /* crissement continu (boucle) */
 rope_set:function(t,v){struck(note(0,0),t,.04*v,.9,MAT[9]);},
 ball_launch:function(t,v){sweep(t,.42,300,1100,.03*v,1.4);glide(110,165,t+.05,.7,.05*v,'sine',.2);},  /* inspiration avant le saut */
 boost_whoosh:function(t,v){for(var k=0;k<4;k++)struck(note(k,0),t+k*(.11-k*.02),.022*v,.18,MAT[2]);},  /* courroie qui accélère */
 portal:function(t,v){sweep(t,.35,1600,300,.04*v,2);fmBell(note(2,0),t+.32,1.2,.02*v,1.5,.8,.3,.5);},    /* bulle aspirée puis recrachée */
 ent_link:function(t,v){fmBell(note(4,0),t,1.2,.022*v,2,.5,.3,.4);fmBell(note(4,0)*1.003,t+.012,1.2,.022*v,2,.5,.3,.4);}, /* deux notes jumelles */
 gate:function(t,v){sweep(t,.5,500,1400,.02*v,4);fmBell(note(3,0),t+.1,.9,.016*v,2,.6);},              /* lame de verre qui coulisse */
 sup_split:function(t,v){glide(note(2,0),note(2,0)*1.012,t,1.2,.03*v,'sine',.3);glide(note(2,0),note(2,0)*.988,t,1.2,.03*v,'sine',.3);}, /* le son se dédouble */
 det_measure:function(t,v){grains(t,1,900,.03*v);duck();},                                        /* déclic de mesure puis silence */
 collapse:function(t,v){glide(note(4,0),note(0,0),t,.5,.025*v,'triangle',.2);},
 star_collect:function(t,v){[0,2,4].forEach(function(d,i){fmBell(note(d+2,0),t+i*.09,1.3,.018*v,2,.25,.25,.3);});},   /* rapport 2 (harmonique) : plus d'éclat métallique */  /* trois étoiles de verre */
 goal_enter:function(t,v){blackHole(t,v*.5);sparkle(t+.9,.5,6,.008*v);},
 level_success:function(t,v){[0,2,4].forEach(function(d,i){soft(note(d,0),t+.1+i*.16,1.8,.009*v,.12);});sparkle(t+.15,1.6,22,.012*v);},   /* accord qui s'ouvre lentement + poussière d'étoiles */
 level_fail:function(t,v){tapeStop(note(2,0),t,.045*v);tapeStop(note(0,0),t+.18,.035*v);},
 spike_hit:function(t,v){glide(note(1,-1),note(0,-1)*.9,t,.5,.06*v,'triangle',.05);grains(t,2,600,.02*v,.02);},  /* piqûre étouffée */
 rewind:function(t,v){grains(t,6,1600,.014*v,.03,true);sweep(t,.5,2000,500,.014*v);},
 rope_hit:function(t,v){struck(note(1,0),t,.03*v,.8,MAT[9]);},
 impact_ice:function(t,v){fmBell(note(4,1),t,.8,.018*v,3.5,.5,.3);},
 /* R284 — entrée et sortie de la particule (transitions.js) : un seul registre, grave et feutré, poussière qui pétille */
 absorb_pull:function(t,v){v*=.75;   /* l'arrivée aspire : bourdon qui descend et gonfle (assez haut pour un haut-parleur de téléphone), souffle qui se resserre, poussière attirée */
  if(budget(t,2.5)){var o=ac.createOscillator(),e=ac.createGain(),lp=ac.createBiquadFilter();o.type='triangle';o.frequency.setValueAtTime(cap(150),t);o.frequency.exponentialRampToValueAtTime(cap(62),t+2.3);lp.type='lowpass';lp.frequency.value=900;
   e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(.11*v,t+1.5);e.gain.linearRampToValueAtTime(.0001,t+2.4);o.connect(lp);lp.connect(e);outFx(e,.15,.1);o.start(t);o.stop(t+2.5);}
  sweep(t,2.3,1500,160,.045*v,1.8);sparkle(t+.15,1.8,22,.012*v,900,2600);},
 absorb_burst:function(t,v){v*=.75;   /* l'éclat vert : un battement, deux cloches de verre, poussière d'étoiles */
  glide(190,70,t,.32,.11*v,'triangle',.1);fmBell(note(4,1),t+.02,1.9,.035*v,2,.45,.4,.4);fmBell(note(2,2),t+.06,1.5,.024*v,2,.4,.4,.4);
  sweep(t,.5,1400,5200,.03*v,2.5);sparkle(t,1.2,22,.02*v,1800,4600);duck();},
 birth_open:function(t,v){v*=.75;   /* le trou s'ouvre : tic, puis inspiration montante */
  grains(t,1,2600,.03*v);sweep(t+.05,.45,300,1900,.04*v,2.2);glide(110,170,t+.05,.45,.06*v,'triangle',.15);},
 birth_shot:function(t,v){v*=.75;   /* le tir : souffle qui s'ouvre, battement, une cloche, grains éjectés */
  sweep(t,.32,500,3000,.065*v,1.6);glide(230,90,t,.3,.1*v,'triangle',.2);fmBell(note(4,1),t+.03,.9,.03*v,2,.4,.3,.4);sparkle(t,.5,10,.016*v,1700,3800);},
 birth_pass:function(t,v){v*=.75;sweep(t,.38,1100,360,.035*v,2);},   /* la fronde repasse tout près du départ */
 birth_land:function(t,v){v*=.75;   /* la pose : petit « clac » rond, grains, matérialisation */
  glide(150,85,t,.18,.07*v,'triangle',.1);fmBell(note(2,1),t,.9,.03*v,2.5,.35,.3,.3);grains(t,3,2000,.025*v,.03);}};
function impact(mat,i,t){
 /* R62 — retour Simon : « chaque touche de balle est trop bruyante ; plus cosmique, discret mais pétillant ».
    Chocs 2,5 fois plus bas, plus courts, et une pincée de grains qui pétillent ; la matière du monde reste reconnaissable. */
 RR=(RR+1+(Math.random()<.4?1:0))%5;var d=RR+(mat===1?2:0),g=.004+.009*i;
 if(mat===1){fmBell(note(d,0),t,.35+i*.2,g,2,.4+.6*i,.2);}
 else if(mat===2)SFX.spike_hit(t,.4+.4*i);
 else if(mat===4)fmBell(note(d+2,0),t,.5,g*.8,2,.3,.25);
 else if(mat===5)struck(note(d,0),t,g,.5,MAT[9]);
 else if(mat===3)struck(note(d,0),t,g,.15,MAT[2]);
 else if(QS&&QS.soft)struck(note(d,0),t,g*.8,.2,{p:[[1,1]],d:.2,lp:1.5,th:.1,beat:2});
 else struck(note(d,0),t,g,.3);
 sparkle(t,.06+.06*i,1+Math.round(2*i),.004+.006*i);}

/* ── boucles continues : un seul son par élément, modulé à chaque instant par l'état du jeu ── */
var LOOPS={},drawEnv=0,QS=null;
function mkLoop(name,build){if(LOOPS[name]&&LOOPS[name].ctx===ac)return LOOPS[name];var g=ac.createGain();g.gain.value=0;var o=build(g);g.connect(sfx);LOOPS[name]={ctx:ac,g:g,o:o};return LOOPS[name];}
function noiseLoop(g,type,f,q){var s=ac.createBufferSource(),b=ac.createBiquadFilter();s.buffer=noiseBuf;s.loop=true;b.type=type;b.frequency.value=f;b.Q.value=q;s.connect(b);b.connect(g);s.start();return {s:s,f:b};}
function setG(L,v,tc){var t=ac.currentTime;L.g.gain.setTargetAtTime(v,t,tc||.12);}
function drawLoop(v){drawEnv=Math.max(drawEnv,.4+.6*v);}
function segDist(px,py,s){var ax=s[2]-s[0],ay=s[3]-s[1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((px-s[0])*ax+(py-s[1])*ay)/l)):0;return Math.hypot(px-s[0]-u*ax,py-s[1]-u*ay);}
function loopTick(){
 if(!ac||ac.state!=='running'||ac.constructor.name==='OfflineAudioContext'||typeof S==='undefined'||typeof L!=='function')return;
 var run=S.mode==='run'&&!S.zen||S.mode==='run',lv;try{lv=L();}catch(e){return;}var b=S.ball,i,k;
 QS={soft:!!lv.softball};
 /* tracé : crissement doux de pointe sur verre */
 var dl=mkLoop('draw',function(g){return noiseLoop(g,'bandpass',2100,5);});drawEnv*=.75;setG(dl,vol.sfx>0?drawEnv*.018:0,.05);
 if(!run||!b){['wind','grav','mag','mov','ice','sup'].forEach(function(n){if(LOOPS[n])setG(LOOPS[n],0,.08);});if(musF)musF.frequency.setTargetAtTime(20000,ac.currentTime,.3);return;}
 var spd=Math.hypot(b.vx||0,b.vy||0);
 /* vent : souffle dans un tube, panoramique qui suit la balle */
 var inW=0;(lv.wind||[]).forEach(function(z){if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3])inW=1;});
 if(lv.wind&&lv.wind.length){var wl=mkLoop('wind',function(g){var p=ac.createStereoPanner?ac.createStereoPanner():null,n=noiseLoop(p||g,'bandpass',520,7);if(p)p.connect(g);return {n:n,p:p};});
  setG(wl,inW*.05+.006,.25);if(wl.o.p)wl.o.p.pan.setTargetAtTime((b.x/180-1)*.8,ac.currentTime,.1);}
 /* gravité locale : sinus grave qui glisse selon le sens de la gravité */
 var gz=null;(lv.grav||[]).forEach(function(z){if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3])gz=z;});
 if(lv.grav&&lv.grav.length){var gl=mkLoop('grav',function(g){var o=ac.createOscillator(),lp=ac.createBiquadFilter();o.type='sine';o.frequency.value=90;lp.type='lowpass';lp.frequency.value=400;o.connect(lp);lp.connect(g);o.start();return o;});
  setG(gl,gz?.06:0,.3);if(gz)gl.o.frequency.setTargetAtTime(gz[5]<0?150:(Math.abs(gz[5])<.2?70:55),ac.currentTime,.6);}
 /* aimant : bourdon de deux sinus qui battent, battement plus rapide en approchant */
 if(lv.mag&&lv.mag.length){var md=1e9,mr=1;lv.mag.forEach(function(m){var d=Math.hypot(b.x-m[0],b.y-m[1]);if(d/m[2]<md/mr){md=d;mr=m[2];}});var u=Math.max(0,1-md/(mr*1.3));
  var ml=mkLoop('mag',function(g){var a=ac.createOscillator(),c=ac.createOscillator(),lp=ac.createBiquadFilter();a.frequency.value=98;c.frequency.value=99.5;lp.type='lowpass';lp.frequency.value=500;a.connect(lp);c.connect(lp);lp.connect(g);a.start();c.start();return {c:c};});
  setG(ml,u*u*.07,.1);ml.o.c.frequency.setTargetAtTime(98+1.5+u*7,ac.currentTime,.15);}
 /* parois mobiles : soufflet lent, plus présent quand la balle est près d'une paroi */
 if(lv.mov&&lv.mov.length){var near=1e9;try{lv.mov.forEach(function(m,j){var s=moverSeg(m,S.t);near=Math.min(near,segDist(b.x,b.y,s));});}catch(e){near=200;}
  var vl=mkLoop('mov',function(g){return noiseLoop(g,'lowpass',380,.7);});setG(vl,.012+Math.max(0,1-near/120)*.04,.2);}
 /* glace : frottement de verre mouillé tant que la balle glisse dessus */
 var onIce=0;(lv.w||[]).forEach(function(s){if(s[4]===4&&segDist(b.x,b.y,s)<R+3)onIce=1;});
 var il=mkLoop('ice',function(g){var o=ac.createOscillator(),o2=ac.createOscillator(),lp=ac.createBiquadFilter();o.frequency.value=cap(note(4,1));o2.frequency.value=cap(note(4,1))+2.5;lp.type='lowpass';lp.frequency.value=900;o.connect(lp);o2.connect(lp);lp.connect(g);o.start();o2.start();return o;});
 setG(il,onIce*Math.min(1,spd/6)*.03,.08);
 /* superposition : un double désaccordé de la musique tant que la balle est dédoublée */
 if(chorus)chorus.gain.setTargetAtTime(S.superposed?.5:0,ac.currentTime,.3);
 /* dilatation du temps : musique voilée dans la zone */
 var inT=0;(lv.tdil||[]).forEach(function(z){if(b.x>z[0]&&b.x<z[0]+z[2]&&b.y>z[1]&&b.y<z[1]+z[3])inT=1;});
 if(musF)musF.frequency.setTargetAtTime(inT?650:20000,ac.currentTime,.25);}
var musF=null,chorus=null;
function musChain(c){ /* musique → filtre (dilatation) → sortie ; double désaccordé (superposition) */
 musF=c.createBiquadFilter();musF.type='lowpass';musF.frequency.value=20000;musF.Q.value=.5;
 chorus=c.createGain();chorus.gain.value=0;var cd=c.createDelay(.05),lfo=c.createOscillator(),lg=c.createGain();cd.delayTime.value=.018;lfo.frequency.value=.35;lg.gain.value=.006;lfo.connect(lg);lg.connect(cd.delayTime);lfo.start();
 mus.disconnect();mus.connect(musF);musF.connect(master);mus.connect(cd);cd.connect(chorus);chorus.connect(master);}
setInterval(loopTick,60);

/* ── remplacement de l'API ── */
function ensure(){
 if(ac)return ac;
 var C=window.AudioContext||window.webkitAudioContext;if(!C)return null;
 try{graph(new C());}catch(e){ac=null;return null;}
 return ac;}
Audio1.unlock=function(){
 try{A0.setMusicVol(0);}catch(e){}           /* l'ancienne musique reste muette */
 try{if(navigator.audioSession)navigator.audioSession.type='playback';}catch(e){}
 try{A0.unlock();}catch(e){}                 /* iOS : session audio et boucle silencieuse */
 var c=ensure();if(!c)return;
 if(c.state==='suspended'){try{var r=c.resume();if(r&&r.catch)r.catch(function(){});}catch(e){}}
 if(!started){started=true;buildMusic();}};
Audio1.playSfx=function(n,v){if(!ac||vol.sfx<=0)return;var f=SFX[n]||SFX.ui_tap;f(now(),v===undefined?1:Math.max(.3,Math.min(1,v)));};
Audio1.playImpact=function(mat,vel){if(!ac||vol.sfx<=0)return;var i=Math.min(1,vel/9);if(i<.1)return;
 var t=ac.currentTime;if(t-lastImp<.09)return;lastImp=t;impact(mat,i,t+.005);};
Audio1.playMusicState=function(s){if(ST[s]===undefined)return;st=ST[s];if(ac&&lay.pad)mixTo(s==='tension'?.8:1.6);if(s==='menu')W1N.hush(.5);try{if(TXN.bus&&TXN.bus.ctx===ac)TXN.bus.gain.setTargetAtTime(s==='menu'?.68:1,ac.currentTime,.6);}catch(e){}};
Audio1.setWorld=function(i){if(!WORLDS[i])i=0;var li=(typeof S!=='undefined'&&S.li)||0;if(i===wi&&li===LV)return;wi=i;LV=li;
 if(ac&&lay._pf){applyStyle();chordI=0;phrase=0;}if(wi!==0)W1N.hush(.6);
 try{if(ac&&timer&&TXN.bus&&TXN.bus.ctx===ac){var ss='w'+(wi+1),nn=LV%12;TXN.load(ss,'q'+(nn+1));TXN.load(ss,'q'+Math.min(12,nn+2));next=ac.currentTime+.05;}}catch(e){}};   /* R338 : le rendu du nouveau niveau est chargé et lancé tout de suite (fondu long entre mondes) */
Audio1.setMusicVol=function(v){vol.mus=v;if(mus)mus.gain.setTargetAtTime(v,ac.currentTime,.1);try{A0.setMusicVol(0);}catch(e){}};
Audio1.setSfxVol=function(v){vol.sfx=v;if(sfx)sfx.gain.setTargetAtTime(v*.8,ac.currentTime,.05);};
Audio1.ctx=function(){return ensure();};   /* R234 : contexte partagé avec la bande son de la fin (fin-sound.js) */
Audio1.setMusic=function(on){Audio1.setMusicVol(on?(vol.mus||.5):0);};
Audio1.setSfx=function(on){Audio1.setSfxVol(on?(vol.sfx||1):0);};
Audio1.test=function(){Audio1.playSfx('ui_confirm');};
Audio1.state=function(){return ac?ac.state:'inactif';};
Audio1.sampReady=function(){return true;};Audio1.sampErr=function(){return '';};
Audio1.world=function(){return wi;};
/* rendu hors ligne pour les tests (spectre mesurable sans écouter) */
Audio1._render=function(sec,scene,cb,world){
 var C=window.OfflineAudioContext||window.webkitOfflineAudioContext;if(!C){cb(null);return;}
 var keep={ac:ac,started:started,timer:timer,wi:wi,lay:lay,dly:dly,trem:trem,wow:wow,mus:mus,sfx:sfx,master:master,revIn:revIn,rev:rev,comp:comp,noiseBuf:noiseBuf,TAIL:TAIL,ENDS:ENDS};wow=null;ENDS=[];TAIL=null;var c=new C(2,Math.floor(44100*sec),44100);
 graph(c);if(world!==undefined)wi=world;mus.gain.value=vol.mus||.5;sfx.gain.value=vol.sfx||1;
 lay={};buildMusic();clearInterval(timer);next=.3;chordI=0;phrase=0;
 ['pad','theme','tex','sub'].forEach(function(n,i){lay[n].gain.cancelScheduledValues(0);lay[n].gain.value=(MIX[st]||MIX[1])[i]*1.3;});
 tickAt(sec);scene(c);
 c.startRendering().then(function(b){ac=keep.ac;started=keep.started;wi=keep.wi;lay=keep.lay;dly=keep.dly;trem=keep.trem;wow=keep.wow;
  mus=keep.mus;sfx=keep.sfx;master=keep.master;revIn=keep.revIn;rev=keep.rev;comp=keep.comp;noiseBuf=keep.noiseBuf;TAIL=keep.TAIL;ENDS=keep.ENDS;cb(b);});};   /* on rend la main au contexte vivant : plus d'erreur « autre contexte » */
Audio1._covers=function(){return {mat0:1,mat1:1,mat2:1,mat3:1,mat4:1,mat5:1,soft:1,wind:'boucle',grav:'boucle',mag:'boucle',mov:'boucle',ice:'boucle',
 port:SFX.portal?1:0,ent:SFX.ent_link?1:0,gate:SFX.gate?1:0,sup:SFX.sup_split?1:0,det:SFX.det_measure?1:0,tdil:'filtre',star:SFX.star_collect?1:0,goal:SFX.goal_enter?1:0};};
Audio1._loops=function(){var o={};for(var n in LOOPS)o[n]=+LOOPS[n].g.gain.value.toFixed(4);o.musF=musF?Math.round(musF.frequency.value):null;o.chorus=chorus?+chorus.gain.value.toFixed(3):null;return o;};
Audio1._world=function(i){wi=i;};
Audio1._level=function(n){LV=n;};
Audio1._sfxAt=function(n,t,v){(SFX[n]||SFX.ui_tap)(t,v||1);};
Audio1._impactAt=function(m,i,t){impact(m,i,t);};
Audio1._state=function(s){st=ST[s];};
})();
/* R319 : tout le son se coupe quand le jeu passe en arrière-plan (onglet masqué, app réduite, écran verrouillé) et reprend au retour */
(function(){var media=[],held=[],mheld=[];
 try{var P=HTMLMediaElement.prototype,pl=P.play;P.play=function(){if(media.indexOf(this)<0)media.push(this);return pl.apply(this,arguments);};}catch(e){}
 function away(){held=[];mheld=[];(window.__ACS||[]).forEach(function(c){try{if(c.state==='running'){held.push(c);c.suspend();}}catch(e){}});
  media.forEach(function(m){try{if(!m.paused){mheld.push(m);m.pause();}}catch(e){}});}
 function back(){if(window.__QTOPEN)return;held.forEach(function(c){try{c.resume();}catch(e){}});mheld.forEach(function(m){try{var r=m.play();if(r&&r.catch)r.catch(function(){});}catch(e){}});held=[];mheld=[];}
 document.addEventListener('visibilitychange',function(){if(document.hidden)away();else back();});
 window.addEventListener('pagehide',away);window.addEventListener('pageshow',function(e){if(e.persisted)back();});
})();
