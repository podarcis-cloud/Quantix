/* ══ DIDACTICIEL ══ (R37, refonte R38)
   1. Première partie guidée dans le niveau 1 : le joueur fait les gestes lui-même.
   2. Fiche d'élément à la première rencontre : le jeu compare les éléments du niveau
      chargé à la liste « déjà vus » de la sauvegarde. Aucun code par monde.
   3. « Aide du niveau » (pause) et « Explications » (paramètres) pour tout revoir.
   Tout le texte visible vit dans i18n.js (clés ti_*, tt_*, td_*, tuto*).
   Chargé AVANT engine.js ; n'utilise les globaux du moteur (S, LEVELS, W, TR…) qu'à l'exécution. */
var TUTO=(function(){
 var st={intro:false,seen:{}},pend=null,mode=null,T0=0,pendT=0;
 var ci=0,cids=[],fromCodex=false,isRev=false,step=0,failed=false,dId=null,dT=0,dOn=false,dCtx=null,dDir=[1,0],dGm=0;
 var DW=232,DH=104;

 function $$(id){return document.getElementById(id);}
 function vx(){return (typeof window!=='undefined'&&window.VX)||null;}
 function hasArr(a){return !!(a&&a.length);}
 function matIn(lv,m){var w=lv.w||[],i;for(i=0;i<w.length;i++)if(w[i][4]===m)return true;return false;}
 function palHas(lv,ch){return (lv.pal||'S').indexOf(ch)>=0;}

 /* ── catalogue : l'ordre est l'ordre d'enseignement quand plusieurs éléments arrivent ensemble.
    cat : base | tool | mat | elem (libellé de la fiche). Les outils n'ont pas de niveau : ils sont
    proposés une fois, au premier niveau après le didacticiel d'ouverture. ── */
 var TOOLS=['tdraw','tline','terase','tmove'];
 var TOOLMODE={tdraw:'draw',tline:'line',terase:'erase',tmove:'move'};
 function no(){return false;}
 var CAT=[
  {id:'basics',cat:'base',col:'#4DD7FF',has:no},
  {id:'tools', cat:'tool',col:'#4DD7FF',has:no},   /* R186 : les quatre outils présentés en une seule fiche */
  {id:'tdraw', cat:'tool',col:'#4DD7FF',has:no},
  {id:'tline', cat:'tool',col:'#4DD7FF',has:no},
  {id:'terase',cat:'tool',col:'#FF5252',has:no},
  {id:'tmove', cat:'tool',col:'#A878FF',has:no},
  {id:'nd',    cat:'elem',col:'#FF5252',has:function(lv){return hasArr(lv.nd);}},
  {id:'spike', cat:'elem',col:'#FF5252',has:function(lv){return matIn(lv,2);}},
  {id:'bounce',cat:'elem',col:'#FFAA3C',has:function(lv){return matIn(lv,1);}},
  {id:'palB',  cat:'mat', col:'#FFAA3C',has:function(lv){return palHas(lv,'B');}},
  {id:'boost', cat:'elem',col:'#A878FF',has:function(lv){return matIn(lv,3);}},
  {id:'tunnel',cat:'elem',col:'#A9BCEB',has:function(lv){return (lv.curves||[]).some(function(k){return k.pass;});}},
  {id:'palA',  cat:'mat', col:'#A878FF',has:function(lv){return palHas(lv,'A');}},
  {id:'ice',   cat:'elem',col:'#BFEAF7',has:function(lv){return matIn(lv,4);}},
  {id:'palC',  cat:'mat', col:'#E8B98A',has:function(lv){return palHas(lv,'C');}},
  {id:'wind',  cat:'elem',col:'#A8C8E8',has:function(lv){return hasArr(lv.wind);}},
  {id:'grav',  cat:'elem',col:'#A878FF',has:function(lv){return hasArr(lv.grav);}},
  {id:'mag',   cat:'elem',col:'#FF4D8D',has:function(lv){return hasArr(lv.mag);}},
  {id:'port',  cat:'elem',col:'#4DD7FF',has:function(lv){return hasArr(lv.port);}},
  {id:'mov',   cat:'elem',col:'#43D5F5',has:function(lv){return hasArr(lv.mov);}},
  {id:'ent',   cat:'elem',col:'#FFD85A',has:function(lv){return hasArr(lv.ent)||hasArr(lv.gate);}},
  {id:'sup',   cat:'elem',col:'#A878FF',has:function(lv){return hasArr(lv.sup);}},
  {id:'det',   cat:'elem',col:'#FFD85A',has:function(lv){return hasArr(lv.det);}},
  {id:'tdil',  cat:'elem',col:'#4DD7FF',has:function(lv){return hasArr(lv.tdil);}},
  {id:'rec',   cat:'elem',col:'#BE8CFF',has:function(lv){return hasArr(lv.rec);}},
  {id:'soft',  cat:'elem',col:'#43D5F5',has:function(lv){return !!lv.softball;}}
 ];
 function entry(id){for(var i=0;i<CAT.length;i++)if(CAT[i].id===id)return CAT[i];return CAT[0];}
 function colOf(id){return entry(id).col;}
 function elemsOf(lv){var o=[],i;if(!lv)return o;for(i=0;i<CAT.length;i++)if(CAT[i].has(lv))o.push(CAT[i].id);return o;}

 /* ── état persistant ── */
 function state(){return {v:1,i:st.intro?1:0,s:Object.keys(st.seen)};}
 function load(d,seenLv){
  st={intro:false,seen:{}};
  var j,k,e;
  if(d&&d.v===1){st.intro=!!d.i;for(k=0;k<(d.s||[]).length;k++)st.seen[d.s[k]]=1;}
  else if(seenLv>0){ /* joueur d'avant le didacticiel : ce qu'il a déjà traversé n'est pas réexpliqué */
   st.intro=true;
   for(j=0;j<seenLv&&j<LEVELS.length;j++){e=elemsOf(LEVELS[j]);for(k=0;k<e.length;k++)mark(e[k]);}
  }
 }
 function reset(){st={intro:false,seen:{}};pend=null;hide();}
 function save(){try{if(typeof persist==='function')persist();}catch(e){}}

 /* ── déclenchement ── */
 /* R202 · RÈGLES DES FICHES (une seule source de vérité) :
    1. Une fiche ne s'ouvre qu'à l'ARRIVÉE dans un niveau, avant le premier lâcher, 1,8 s après l'apparition du niveau.
    2. Elle ne présente que les notions de CE niveau jamais expliquées (mémoire « seen », sauvegardée avec la progression).
    3. Niveau déjà réussi (on y revient, on le rejoue) : aucune fiche, ses notions sont tenues pour connues.
    4. Deux fiches au plus par arrivée (saut direct dans un monde avancé) ; le reste attend le niveau suivant ou le Codex.
    5. La fiche en attente est abandonnée dès que le joueur lâche la particule, réussit, échoue ou quitte le niveau.
    La mémoire suit la sauvegarde du jeu : effacer les données du site = tout réexpliquer (c'est voulu). */
 function onLoad(i){
  pend=null;
  if(mode&&!fromCodex)hide();
  if(typeof S==='undefined'||S.zen)return;
  if(S.best&&S.best[i]>0){var ek=elemsOf(LEVELS[i]);for(var q=0;q<ek.length;q++)mark(ek[q]);if(i===0)mark('basics');save();return;}   /* règle 3 */
  if(!st.intro&&i===0){var e1=['basics'].concat(elemsOf(LEVELS[0]).filter(function(id){return !st.seen[id];}));pend={li:0,kind:'cards',ids:e1};pendT=Date.now();return;}   /* R195 : plus de partie guidée — le niveau 1 s'ouvre sur des fiches comme les autres (même design, même animation) */
  var ids=[],k;
  if(st.intro&&TOOLS.some(function(t){return !st.seen[t];}))ids.push('tools');   /* R186 : une fiche pour les quatre outils (audit : 5 fiches d'affilée au niveau 2) */
  var el0=elemsOf(LEVELS[i]).filter(function(id){return !st.seen[id];});if(el0.length)ids=[];   /* R194 : une notion à la fois — les outils attendent un niveau sans élément nouveau */
  ids=ids.concat(el0);
  ids=ids.filter(function(id,n){return !(PAIR[id]&&ids.indexOf(PAIR[id])>=0&&ids.indexOf(PAIR[id])<n);});
  if(ids.length>2)ids=ids.slice(0,2);   /* règle 4 */
  if(ids.length){pend={li:i,kind:'cards',ids:ids};pendT=Date.now();}
 }
 function busy(){return !!(document.querySelector&&document.querySelector('.veil.on'));}
 function tick(){
  T0++;
  var scr=$$('app').dataset.screen;
  if(scr!=='game'){if(mode&&!fromCodex)hide();return;}
  if(mode==='intro'){tickIntro();return;}
  if(mode==='card'){pulseTarget();return;}
  if(pend&&(pend.li!==S.li||(S.mode!=='draw'))){pend=null;return;}   /* règle 5 */
  if(!pend||S.zen||busy()||Date.now()-pendT<1800)return;   /* R186 : laisser le niveau apparaître avant la fiche */
  if(pend.kind==='intro')startIntro();
  else{var ids=pend.ids;pend=null;openCards(ids,false,false);}
 }

 /* ── première partie guidée ── */
 function rich(el,txt){ /* « *mot* » → mot mis en valeur ; la 1re phrase, quand il y en a plusieurs, est la phrase d'ambiance (italique). Nœuds seulement, jamais de HTML brut. */
  while(el.firstChild)el.removeChild(el.firstChild);
  var s0=String(txt),cut=s0.search(/[.:!?] (?=[A-ZÀ-ÖØ-Þ*])/),wrap=el;
  if(cut>0&&cut<s0.length-12){
   var amb=document.createElement('span');amb.className='amb';el.appendChild(amb);
   var head=s0.slice(0,cut+1);s0=s0.slice(cut+2);
   var hp=head.split('*'),hi,hn;for(hi=0;hi<hp.length;hi++){if(!hp[hi])continue;if(hi%2){hn=document.createElement('em');hn.textContent=hp[hi];amb.appendChild(hn);}else amb.appendChild(document.createTextNode(hp[hi]));}
   el.appendChild(document.createElement('br'));}
  var parts=String(s0).split('*'),i,n;
  for(i=0;i<parts.length;i++){
   if(!parts[i])continue;
   if(i%2){n=document.createElement('em');n.textContent=parts[i];el.appendChild(n);}
   else el.appendChild(document.createTextNode(parts[i]));}
 }
 var introCard=false;
 var T0s=0;
 function startIntro(){step=0;failed=false;metrics();   /* R194 : plus de fiche qui recouvre le terrain au niveau 1 — la consigne Visière seule, le terrain reste lisible et jouable */
  cids=[];ci=0;fromCodex=false;isRev=false;introCard=false;mode='intro';T0s=T0;coach('ti_see',false,0);}
var curKey=null;
 function coach(key,withNext,pip){
  curKey=key;$$('tcoachH').textContent=TR(key+'_h');rich($$('tcoachT'),TR(key));
  $$('tcoachOk').style.visibility=withNext?'visible':'hidden';$$('tcoachOk').disabled=!withNext;
  var ps=$$('tcPips').children,i;
  for(i=0;i<ps.length;i++)ps[i].classList.toggle('on',i<=pip);
  var cpb=(typeof LEVELS!=='undefined'&&LEVELS[S.li])?LEVELS[S.li].cup:null,cx0=cpb?cpb[0]+cpb[2]/2:180;
  $$('tcoach').classList.toggle('side-l',cx0>=180);$$('tcoach').classList.toggle('side-r',cx0<180);   /* la bulle se pose du côté opposé au bassin */
  $$('tcoach').classList.remove('idle');$$('tcoach').classList.add('on');frStart();
  try{requestAnimationFrame(placeCoach);}catch(e){}
 }
 /* R120 — la consigne se pose dans le coin du terrain le plus libre (murs, courbes, pointes, bassin, balle, trait de solution) :
    elle ne recouvre plus l'endroit où le joueur doit tracer */
 function placeCoach(){
  var c=$$('tcoach'),cvE=document.getElementById('cv'),lv=(typeof LEVELS!=='undefined')?LEVELS[S.li]:null;
  if(!c||!cvE||!lv||!c.offsetParent)return;
  var pr=c.offsetParent.getBoundingClientRect(),r=cvE.getBoundingClientRect(),k=r.width/360,cw=c.offsetWidth,ch=c.offsetHeight,m=8;
  var tfh=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--tfh'))||0,yMax=Math.min(r.bottom,pr.bottom-tfh)-m-ch;
  var pts=[],add=function(x,y,wt){pts.push([r.left+x*k,r.top+y*k,wt||1]);},seg=function(x1,y1,x2,y2,wt){var n=Math.max(2,Math.ceil(Math.hypot(x2-x1,y2-y1)/12)),j;for(j=0;j<=n;j++)add(x1+(x2-x1)*j/n,y1+(y2-y1)*j/n,wt);};
  (lv.w||[]).forEach(function(w){seg(w[0],w[1],w[2],w[3],1);});
  (lv.curves||[]).forEach(function(cu){for(var j=1;j<cu.pts.length;j++)seg(cu.pts[j-1][0],cu.pts[j-1][1],cu.pts[j][0],cu.pts[j][1],1);});
  (lv.optsol||[]).forEach(function(sl){for(var j=1;j<sl.length;j++)seg(sl[j-1][0],sl[j-1][1],sl[j][0],sl[j][1],4);});
  if(lv.cup){var q=lv.cup;seg(q[0],q[1]-50,q[0]+q[2],q[1]-50,3);seg(q[0],q[1],q[0]+q[2],q[1],3);}
  if(lv.star)add(lv.star[0],lv.star[1],20);if(lv.ball){add(lv.ball[0],lv.ball[1],30);add(lv.ball[0]+40,lv.ball[1]-20,12);   /* R194 : jamais sur la particule, son étiquette ou le noyau */
  add(lv.ball[0],lv.ball[1],6);seg(lv.ball[0],lv.ball[1],lv.ball[0],lv.ball[1]+120,2);}
  var cand=[[r.left+(r.width-cw)/2,r.top+m],[r.left+m,r.top+m],[r.right-m-cw,r.top+m],[r.left+m,yMax],[r.right-m-cw,yMax],[r.left+(r.width-cw)/2,yMax]],best=null,bs=1e9,i;   /* R194 : toujours dans le terrain, jamais sur l'en-tête */
  for(i=0;i<cand.length;i++){var x0=cand[i][0],y0=cand[i][1],sc=(i===0?-1:i>=3?-.5:0);
   pts.forEach(function(p){if(p[0]>x0-6&&p[0]<x0+cw+6&&p[1]>y0-6&&p[1]<y0+ch+6)sc+=p[2];});
   if(sc<bs){bs=sc;best=cand[i];}}
  c.style.left=Math.round(best[0]-pr.left)+'px';c.style.top=Math.round(best[1]-pr.top)+'px';c.style.right='auto';c.style.bottom='auto';
 }
 /* R116 — gabarit unique : le bandeau garde TOUJOURS la même hauteur (celle du plus long message), le terrain ne change plus de taille d'un message à l'autre */
 function fitCoach(){
  var c=$$('tcoach'),p=$$('tcoachT'),ks=['ti_see','ti_draw','ti_release','ti_adjust'],i,mx=0,was=c.classList.contains('on');
  c.classList.add('on','measure');
  for(i=0;i<ks.length;i++){rich(p,TR(ks[i]));mx=Math.max(mx,c.offsetHeight);}
  c.classList.remove('measure');if(!was)c.classList.remove('on');
  if(curKey)rich(p,TR(curKey));
  c.style.setProperty('--tcH',(mx+1)+'px');
 }
 /* R116 — la fiche ne couvre jamais la barre du bas (Lâcher, outils) : on mesure sa hauteur */
 function metrics(){
  var g=$$('game'),f=g&&g.querySelector('footer');if(!g||!f)return;
  var a=g.getBoundingClientRect(),b=f.getBoundingClientRect();
  document.documentElement.style.setProperty('--tfh',Math.max(0,Math.round(a.bottom-b.top))+'px');   /* la fiche est hors de #game : variable posée à la racine */
 }
 function fitCard(){
  var c=$$('tcard'),fr=c.querySelector('canvas.tfr');c.classList.remove('tight');metrics();if(fr)fr.style.display='none';
  var avail=(c.offsetParent?c.offsetParent.clientHeight:innerHeight)-(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--tfh'))||0)-80;   /* R186 : la Visière déborde volontairement (voile) : on compare à la place disponible */
  if(c.offsetHeight>avail)c.classList.add('tight');if(fr)fr.style.display='';
  c.scrollTop=0;
 }
 function toStep(n){
  step=n;
  if(n===1)coach('ti_draw',false,1);
  else if(n===2)coach('ti_release',false,2);
  else if(n===6)coach('ti_adjust',false,3);
  else $$('tcoach').classList.remove('on');
 }
 function tickIntro(){
  if(S.li!==0||S.zen){hide();return;}
  if(S.mode==='success'){finishIntro();return;}
  var bp=$$('bPlay');
  if(bp)bp.classList.toggle('tpulse',step===2);
  $$('tcoach').classList.toggle('ghost',!!S.cur);
  if(step===0){if(S.cur||S.strokes.length||T0-T0s>480)toStep(1);return;}   /* R194 : le repérage cède la place dès que le joueur trace, ou après 8 s */
  if(step===1){if(S.mode!=='draw'){toStep(3);return;}if(S.strokes.length&&!S.cur)toStep(2);}
  else if(step===2){if(S.mode!=='draw'){toStep(3);return;}if(!S.strokes.length)toStep(1);}
  else if(step===3){if(S.mode==='fail')failed=true;else if(S.mode==='draw'&&failed)toStep(6);}
  else if(step===6){if(S.mode!=='draw')toStep(3);}
 }
 function finishIntro(){st.intro=true;pend=null;var e0=elemsOf(LEVELS[0]);for(var q=0;q<e0.length;q++)mark(e0[q]);save();hide();}   /* R194 : les pointes du niveau 1 sont nommées pendant l'ouverture ; pas de fiche « ancien rendu » plus tard */

 /* ── fiches d'élément ── */
 function openCards(ids,codex,review){
  cids=ids.slice();ci=0;fromCodex=!!codex;isRev=!!(review||codex);mode='card';showCard();
 }
 function focusOf(id,lv){
  var o=[],i,a;
  function rect(r){o.push({t:'r',x:r[0],y:r[1],w:r[2],h:r[3]});}
  function circ(x,y,r){o.push({t:'c',x:x,y:y,r:r});}
  function seg(x1,y1,x2,y2){o.push({t:'s',x1:x1,y1:y1,x2:x2,y2:y2});}
  var m={spike:2,bounce:1,boost:3,ice:4};
  if(id==='nd'||id==='wind'||id==='grav'||id==='sup'||id==='tdil'){a=lv[id]||[];for(i=0;i<a.length;i++)rect(a[i]);}
  else if(m[id]!==undefined){a=lv.w||[];for(i=0;i<a.length;i++)if(a[i][4]===m[id])seg(a[i][0],a[i][1],a[i][2],a[i][3]);}
  else if(id==='mag'){a=lv.mag||[];for(i=0;i<a.length;i++)circ(a[i][0],a[i][1],Math.min(a[i][2],60));}
  else if(id==='port'){a=lv.port||[];for(i=0;i<a.length;i++){circ(a[i][0],a[i][1],20);circ(a[i][2],a[i][3],20);}}
  else if(id==='mov'){a=lv.mov||[];for(i=0;i<a.length;i++)seg(a[i].seg[0],a[i].seg[1],a[i].seg[2],a[i].seg[3]);}
  else if(id==='ent'){a=lv.ent||[];for(i=0;i<a.length;i++){if(a[i][0]>-500)circ(a[i][0],a[i][1],22);if(a[i][2]>-500)circ(a[i][2],a[i][3],22);}
   a=lv.gate||[];for(i=0;i<a.length;i++)seg(a[i][0],a[i][1],a[i][2],a[i][3]);}
  else if(id==='det'){a=lv.det||[];for(i=0;i<a.length;i++)circ(a[i][0],a[i][1],a[i][2]);}
  else if(id==='rec'){a=lv.rec||[];for(i=0;i<a.length;i++)circ(a[i][0],a[i][1],a[i][2]+6);}
  else if(id==='soft')circ(lv.ball[0],lv.ball[1],24);
  else if(id==='tunnel'){a=lv.curves||[];for(i=0;i<a.length;i++)if(a[i].pass){if(a[i].pz)rect([a[i].pz[0]-a[i].pz[2],a[i].pz[1]-a[i].pz[3],2*a[i].pz[2],2*a[i].pz[3]]);else for(var q=1;q<a[i].pts.length;q++)seg(a[i].pts[q-1][0],a[i].pts[q-1][1],a[i].pts[q][0],a[i].pts[q][1]);}}
  return o;
 }
 function avgY(sh){var i,s=0,n=0;for(i=0;i<sh.length;i++){var q=sh[i];s+=(q.t==='r')?q.y+q.h/2:(q.t==='s'?(q.y1+q.y2)/2:q.y);n++;}return n?s/n:0;}

 /* R116 — cadre des fiches et de la bulle dans la langue des murs (CAHIER §22–§24) : quatre rails de lumière (VX.curve)
    qui se rencontrent aux coins en jonctions en L (lentille de verre sombre + cœur‑atome, VX.joints), teintés par l'élément. */
 var frOn=false;
 function hexRGB(h){h=String(h||'').trim().replace('#','');if(h.length===3)h=h.replace(/./g,'$&$&');var n=parseInt(h.slice(0,6),16);return (h.length<6||isNaN(n))?[77,215,255]:[n>>16&255,n>>8&255,n&255];}
 function tok(cs,n,d){var v=parseFloat(cs.getPropertyValue(n));return isNaN(v)?d:v;}
 function drawFrame(el){ /* règles : docs/DIDACTICIEL_DESIGN.md §4–§5 — toutes les valeurs viennent des jetons --tu-* */
  if(!window.VX||!VX.joints)return;
  var cv=el.querySelector('canvas.tfr');
  if(!cv){cv=document.createElement('canvas');cv.className='tfr';cv.setAttribute('aria-hidden','true');el.insertBefore(cv,el.firstChild);}
  var w=el.clientWidth,h=el.clientHeight,dpr=Math.min(window.devicePixelRatio||1,2);if(w<40||h<40)return;
  if(cv.width!==Math.round(w*dpr)||cv.height!==Math.round(h*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);cv.style.width=w+'px';cv.style.height=h+'px';}
  cv.style.top=el.scrollTop+'px';
  var cs=getComputedStyle(el),A=hexRGB(cs.getPropertyValue('--tu-ink')),m=tok(cs,'--tu-inset',6),k=tok(cs,'--tu-node',.55),
      la=tok(cs,'--tu-line',.42),ha=tok(cs,'--tu-halo',.1),per=tok(cs,'--tu-photon',12000),
      rm=(typeof OPT!=='undefined'&&OPT.rm)||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
  var c=cv.getContext('2d'),x0=m,y0=m,x1=w-m,y1=h-m,col=function(a){return 'rgba('+A[0]+','+A[1]+','+A[2]+','+a+')';};
  c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);c.lineCap='round';
  /* filets */
  c.beginPath();c.moveTo(x0,y0);c.lineTo(x1,y0);c.lineTo(x1,y1);c.lineTo(x0,y1);c.closePath();
  c.strokeStyle=col(ha);c.lineWidth=3;c.stroke();c.strokeStyle=col(la);c.lineWidth=1;c.stroke();
  /* photon : un tour en --tu-photon ms, traîne à la couleur de l'interface */
  if(!rm){var P=2*(x1-x0)+2*(y1-y0),at=function(d){d=((d%P)+P)%P;var u=x1-x0,v=y1-y0;
     if(d<u)return [x0+d,y0];d-=u;if(d<v)return [x1,y0+d];d-=v;if(d<u)return [x1-d,y1];d-=u;return [x0,y1-d];},
    hd=(Date.now()%per)/per*P,q,i,n=14,tl=Math.min(60,P*.12);
   c.globalCompositeOperation='lighter';
   for(i=n;i>=0;i--){q=at(hd-tl*i/n);c.fillStyle=col(.5*(1-i/n));c.beginPath();c.arc(q[0],q[1],1.4*(1-i/n)+.4,0,6.2832);c.fill();}
   q=at(hd);var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],7);g.addColorStop(0,'rgba(241,244,246,.95)');g.addColorStop(.35,col(.55));g.addColorStop(1,col(0));
   c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],7,0,6.2832);c.fill();c.globalCompositeOperation='source-over';}
  /* jonctions : le code même des murs (VX.joints), à l'échelle --tu-node, sur un cadre fermé (aucune perle) */
  var key=w+'x'+h+':'+A.join(',')+':'+k+':'+m;
  if(!el._flv||el._flv.k!==key){var X0=x0/k,Y0=y0/k,X1=x1/k,Y1=y1/k;el._flv={k:key,w:[[X0,Y0,X1,Y0,0],[X1,Y0,X1,Y1,0],[X1,Y1,X0,Y1,0],[X0,Y1,X0,Y0,0]],cup:null,jA:A};}
  c.save();c.scale(k,k);VX.joints(c,el._flv.w,el._flv);c.restore();
 }
 function frLoop(){var any=false,ids=['tcard','tcoach'],k,e;
  for(k=0;k<ids.length;k++){e=$$(ids[k]);if(e&&e.classList.contains('on')){any=true;try{drawFrame(e);}catch(x){}}}
  if(any)requestAnimationFrame(frLoop);else frOn=false;}
 function frStart(){}   /* R186 : la Visière n'a plus de cadre dessiné (frLoop/drawFrame gardés pour revenir en arrière) */
 /* ── R186 — VISIÈRE ADAPTATIVE (docs/AUDIT_DIDACTICIEL.md) : la fiche se place là où elle cache le moins l'élément,
    passe en format compact si besoin, règle son voile d'après les pixels du niveau (contraste 4,5 : 1), allume un projecteur
    sur l'élément (ou la barre d'outils) et trace son contour avec sa vraie dimension. ── */
 function vsFocus(id){
  var e=entry(id),out=[],r,k,i,lv,el;
  if(e.cat==='tool'||e.cat==='mat'){el=$$(e.cat==='tool'?'dock':'palRow');if(el&&el.offsetParent){r=el.getBoundingClientRect();if(r.width)out.push({t:'r',x:r.left,y:r.top,w:r.width,h:r.height});}return out;}
  var cv=document.getElementById('cv');if(!cv||typeof LEVELS==='undefined'||id==='basics')return out;
  lv=LEVELS[S.li];r=cv.getBoundingClientRect();k=r.width/360;
  var sh=focusOf(id,lv),uni=(id==='nd'&&sh.length>1);
  if(uni){var bx0=1e9,by0=1e9,bx1=-1e9,by1=-1e9;sh.forEach(function(q){bx0=Math.min(bx0,q.x);by0=Math.min(by0,q.y);bx1=Math.max(bx1,q.x+q.w);by1=Math.max(by1,q.y+q.h);});
   ndEdges(sh).forEach(function(g,n){out.push({t:'s',x1:r.left+g[0]*k,y1:r.top+g[1]*k,x2:r.left+g[2]*k,y2:r.top+g[3]*k,u:n?null:Math.round(bx1-bx0)+' × '+Math.round(by1-by0)+' u',edge:1});});}   /* R194 : zones accolées = une seule zone, comme en jeu */
  for(i=0;i<sh.length;i++){var q=sh[i];
   if(q.t==='r'){out.push({t:'r',x:r.left+q.x*k,y:r.top+q.y*k,w:q.w*k,h:q.h*k,u:Math.round(q.w)+' × '+Math.round(q.h)+' u',nol:uni?1:0});}
   else if(q.t==='c'){var rr=(id==='mag'&&lv.mag&&lv.mag[i])?lv.mag[i][2]:q.r;out.push({t:'c',x:r.left+q.x*k,y:r.top+q.y*k,r:q.r*k,u:'r '+Math.round(rr)+' u'});
    if(rr>q.r)out.push({t:'c',x:r.left+q.x*k,y:r.top+q.y*k,r:rr*k,faint:1});}
   else out.push({t:'s',x1:r.left+q.x1*k,y1:r.top+q.y1*k,x2:r.left+q.x2*k,y2:r.top+q.y2*k,u:Math.round(Math.hypot(q.x2-q.x1,q.y2-q.y1))+' u'});}
  return out;
 }
 function ndEdges(rs){var o=[],i,j,e,st2=2;function inAny(x,y){for(var q=0;q<rs.length;q++){var a=rs[q];if(x>a.x&&x<a.x+a.w&&y>a.y&&y<a.y+a.h)return true;}return false;}
  for(i=0;i<rs.length;i++){var a=rs[i],E=[[a.x,a.y,a.x+a.w,a.y,0,-1],[a.x+a.w,a.y,a.x+a.w,a.y+a.h,1,0],[a.x+a.w,a.y+a.h,a.x,a.y+a.h,0,1],[a.x,a.y+a.h,a.x,a.y,-1,0]];
   for(e=0;e<4;e++){var g=E[e],L2=Math.hypot(g[2]-g[0],g[3]-g[1]),n=Math.max(1,Math.round(L2/st2)),run=-1;
    for(j=0;j<=n;j++){var f=j/n,x=g[0]+(g[2]-g[0])*f,y=g[1]+(g[3]-g[1])*f,ex=j<n&&!inAny(x+(g[2]-g[0])/n*.5+g[4]*1.5,y+(g[3]-g[1])/n*.5+g[5]*1.5);
     if(ex&&run<0)run=j;if((!ex||j===n)&&run>=0){var f0=run/n,f1=(ex&&j===n?n:j)/n;o.push([g[0]+(g[2]-g[0])*f0,g[1]+(g[3]-g[1])*f0,g[0]+(g[2]-g[0])*f1,g[1]+(g[3]-g[1])*f1]);run=-1;}}}}
  return o;}
 function vsBox(s){return s.t==='r'?[s.x,s.y,s.x+s.w,s.y+s.h]:s.t==='c'?[s.x-s.r,s.y-s.r,s.x+s.r,s.y+s.r]:[Math.min(s.x1,s.x2)-4,Math.min(s.y1,s.y2)-5,Math.max(s.x1,s.x2)+4,Math.max(s.y1,s.y2)+5];}
 function vsCover(F,y0,y1,x0,x1){var tot=0,hid=0,i;for(i=0;i<F.length;i++){if(F[i].faint)continue;var b=vsBox(F[i]),ar=(b[2]-b[0])*(b[3]-b[1]);tot+=ar;
   hid+=Math.max(0,Math.min(b[2],x1)-Math.max(b[0],x0))*Math.max(0,Math.min(b[3],y1)-Math.max(b[1],y0));}return tot?hid/tot:0;}
 function vsLin(v){v/=255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);}
 function vsVeil(x0,y0,x1,y1){
  try{var cv=document.getElementById('cv'),r=cv.getBoundingClientRect(),sx=cv.width/r.width,sy=cv.height/r.height;
   var a=Math.max(x0,r.left),b=Math.max(y0,r.top),c2=Math.min(x1,r.right),d=Math.min(y1,r.bottom);if(c2-a<4||d-b<4)return .7;
   var px=cv.getContext('2d').getImageData(Math.round((a-r.left)*sx),Math.round((b-r.top)*sy),Math.round((c2-a)*sx),Math.round((d-b)*sy)).data,L=[],i;
   for(i=0;i<px.length;i+=4*7)L.push(.2126*vsLin(px[i])+.7152*vsLin(px[i+1])+.0722*vsLin(px[i+2]));
   L.sort(function(p,q){return p-q;});var p95=L[Math.floor(L.length*.95)]||0,LT=.2126*vsLin(0xB4)+.7152*vsLin(0xC2)+.0722*vsLin(0xD0);
   var need=p95>0?Math.max(0,1-((LT+.05)/4.5-.05)/p95):0;return Math.min(.88,Math.max(.55,need+.08));}catch(x){return .78;}
 }
 function vsSpot(F){
  var sh=$$('tshield');if(!sh)return;var cv=sh.querySelector('canvas');if(!cv){cv=document.createElement('canvas');cv.setAttribute('aria-hidden','true');sh.appendChild(cv);}
  var R=sh.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),i;if(!R.width)return;
  cv.width=Math.round(R.width*dpr);cv.height=Math.round(R.height*dpr);var c=cv.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);
  c.fillStyle='rgba(5,7,13,.62)';c.fillRect(0,0,R.width,R.height);c.globalCompositeOperation='destination-out';
  for(i=0;i<F.length;i++){var b=vsBox(F[i]),cx=(b[0]+b[2])/2-R.left,cy=(b[1]+b[3])/2-R.top,rx=(b[2]-b[0])/2+26,ry=(b[3]-b[1])/2+26,g;
   c.save();c.translate(cx,cy);c.scale(rx/100,ry/100);g=c.createRadialGradient(0,0,0,0,0,100);
   g.addColorStop(0,'rgba(0,0,0,'+(F[i].faint?.4:1)+')');g.addColorStop(.72,'rgba(0,0,0,'+(F[i].faint?.32:.96)+')');g.addColorStop(1,'rgba(0,0,0,0)');
   c.fillStyle=g;c.beginPath();c.arc(0,0,100,0,6.2832);c.fill();c.restore();}
  c.globalCompositeOperation='source-over';
 }
 function vsOutline(id,F,cr){
  var NS='http://www.w3.org/2000/svg',sv=$$('tout'),card=$$('tcard');
  if(!sv){sv=document.createElementNS(NS,'svg');sv.id='tout';sv.setAttribute('class','tout');sv.setAttribute('aria-hidden','true');card.parentNode.insertBefore(sv,card.nextSibling);}
  var R=sv.getBoundingClientRect(),col=entry(id).col,h='',i,lab='',ox=-R.left,oy=-R.top;
  sv.setAttribute('viewBox','0 0 '+Math.round(R.width)+' '+Math.round(R.height));
  function sh(s,a){return s.t==='r'?'<rect x="'+(s.x+ox)+'" y="'+(s.y+oy)+'" width="'+s.w+'" height="'+s.h+'" rx="4" '+a+'/>':s.t==='c'?'<circle cx="'+(s.x+ox)+'" cy="'+(s.y+oy)+'" r="'+s.r+'" '+a+'/>':'<line x1="'+(s.x1+ox)+'" y1="'+(s.y1+oy)+'" x2="'+(s.x2+ox)+'" y2="'+(s.y2+oy)+'" '+a+'/>';}
  for(i=0;i<F.length;i++){if(F[i].nol)continue;if(F[i].faint){h+=sh(F[i],'class="mv" fill="none" stroke="'+col+'" stroke-opacity=".45" stroke-width=".8"');continue;}
   h+=sh(F[i],'class="dr" pathLength="100" fill="none" stroke="#F1F4F6" stroke-width="1.4"')+sh(F[i],'class="mv" fill="none" stroke="'+col+'" stroke-width="1.1"');}
  var f0=null;for(i=0;i<F.length;i++)if(!F[i].faint&&!F[i].nol){f0=F[i];break;}
  if(f0){var b=vsBox(f0),lx=Math.max(8,b[0]+ox),ly=b[1]+oy-7;if(ly<12||(b[1]-7>cr.top&&b[1]-7<cr.bottom))ly=b[3]+oy+12;
   var t=(entry(id).cat==='tool'?TR('cat_tools'):TR('tt_'+id)).toUpperCase()+(f0.u?' · '+f0.u:'');
   lab='<text x="'+lx+'" y="'+ly+'" fill="'+col+'">'+t.replace(/[<>&]/g,'')+'</text>';}
  sv.innerHTML='<defs><mask id="toutM"><rect x="0" y="0" width="'+Math.round(R.width)+'" height="'+Math.round(R.height)+'" fill="#fff"/><rect x="'+(cr.left+ox)+'" y="'+(cr.top+oy)+'" width="'+cr.width+'" height="'+cr.height+'" fill="#555"/></mask></defs><g mask="url(#toutM)">'+h+'</g>'+lab;
  sv.classList.remove('on');void sv.getBoundingClientRect();sv.classList.add('on');
 }
 function vsPlace(id,pos0){
  var card=$$('tcard'),app=$$('app'),par=card.offsetParent;
  card.classList.remove('compact');card.style.top='';card.style.bottom='';
  if(fromCodex||!par||!app||app.dataset.screen!=='game'||typeof S==='undefined'){card.classList.add(pos0);card.classList.toggle('htop',pos0==='top');return;}
  var pr=par.getBoundingClientRect(),F=vsFocus(id),fig=entry(id).cat!=='tool'&&!card.classList.contains('nofig'),tries=[],fm,j,y0,y1,best;
  var tfh=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--tfh'))||0,cl=card.getBoundingClientRect();
  var fmts=fig?['','compact']:[''];
  for(j=0;j<fmts.length;j++){card.classList.toggle('compact',fmts[j]==='compact');var hh=card.offsetHeight;
   y0=pr.top+64;tries.push({f:fmts[j],pos:'top',y0:y0,y1:y0+hh,cov:vsCover(F,y0,y0+hh,cl.left,cl.right)});
   y1=pr.bottom-tfh-8;tries.push({f:fmts[j],pos:'bot',y0:y1-hh,y1:y1,cov:vsCover(F,y1-hh,y1,cl.left,cl.right)});}
  tries.sort(function(a,b){var A=a.cov>.1,B=b.cov>.1;if(A&&B)return (a.cov-b.cov)||((a.f==='compact')-(b.f==='compact'));
   return (A-B)||((a.f==='compact')-(b.f==='compact'))||(a.cov-b.cov)||((a.pos!==pos0)-(b.pos!==pos0));});
  best=tries[0];card.classList.toggle('compact',best.f==='compact');card.classList.toggle('htop',best.pos==='top');   /* R196 : le projecteur se place du côté du bord le plus proche */
  card.style.top=Math.round(best.y0-pr.top)+'px';card.style.bottom='auto';
  card.style.setProperty('--va',vsVeil(cl.left,best.y0,cl.right,best.y1).toFixed(2));
  vsSpot(F);vsOutline(id,F,{left:cl.left,top:best.y0,width:cl.width,height:best.y1-best.y0,bottom:best.y1});
  var hu=$$('thud'),f1=F.filter(function(q){return !q.faint&&!q.nol&&q.u;})[0];if(hu)hu.textContent=f1?(TR('tt_'+id)+' · '+f1.u).toUpperCase():'';   /* R196 : relevé holographique (unités du jeu) */
 }
 var vsT=0;
 function vsClose(){
  var c=$$('tcard'),sh=$$('tshield'),sv=$$('tout');clearTimeout(vsT);
  c.classList.remove('vin');c.classList.add('out');if(sh)sh.classList.add('out');if(sv)sv.classList.remove('on');
  vsT=setTimeout(function(){c.classList.remove('out');if(sh)sh.classList.remove('out');},700);
 }
 function showCard(){
  var id=cids[ci],card=$$('tcard'),e=entry(id),pos='bot',k,d,was=card.classList.contains('on');clearTimeout(vsT);card.classList.remove('out','vin');
  if(introCard){var cp0=LEVELS[S.li].cup;pos=(cp0&&cp0[1]>H*.5)?'top':'bot';}
  else if(!fromCodex){
   if(e.cat==='tool'||e.cat==='mat')pos='top';     /* la palette et le dock sont en bas : on les laisse visibles */
   else{var y=avgY(focusOf(id,LEVELS[S.li]));if(y>H*.5)pos='top';}}
  card.classList.remove('top','bot','swp');void card.offsetWidth;
  card.classList.add('on');card.classList.toggle('nofig',id==='tools');if(was)card.classList.add('swp');else card.classList.add('vin');var sh0=$$('tshield');if(sh0)sh0.classList.remove('out');
  card.style.setProperty('--tc',e.col);
  $$('tshield').classList.add('on');
  $$('tk').textContent=introCard?TR('ti_mission'):(isRev?'':TR('tutoNew')+' · ')+TR(id==='tools'?'cat_tools':'cat_'+e.cat);
  var dots=$$('tdots');while(dots.firstChild)dots.removeChild(dots.firstChild);
  if(introCard)for(k=0;k<4;k++){d=document.createElement('i');if(k===0)d.className='on';dots.appendChild(d);}   /* ouverture = étape 1 sur 4, comme la consigne */
  else if(cids.length>1)for(k=0;k<cids.length;k++){d=document.createElement('i');if(k===ci)d.className='on';dots.appendChild(d);}
  $$('tt').textContent=TR('tt_'+id);
  rich($$('tb'),introCard?TR('ti_see'):TR('td_'+id));
  if(id==='tools'){var tb=$$('tb'),ul=document.createElement('ul'),ti;ul.className='ttools';   /* R186 : liste des outils (nœuds, jamais de HTML brut) */
   while(tb.firstChild)tb.removeChild(tb.firstChild);
   for(ti=0;ti<TOOLS.length;ti++){var li=document.createElement('li'),bb=document.createElement('b'),sp=document.createElement('span');bb.textContent=TR('tt_'+TOOLS[ti]);sp.textContent=TR('ts_'+TOOLS[ti]);li.appendChild(bb);li.appendChild(sp);ul.appendChild(li);}
   tb.appendChild(ul);}
  $$('tok').textContent=(introCard||ci<cids.length-1)?TR('tutoNext'):TR('tutoOk');
  $$('tskip').style.display=(introCard||ci<cids.length-1)?'':'none';
  dId=id;dT=0;dDir=[1,0];dGm=0;
  if(!fromCodex){var lv2=LEVELS[S.li],z;
   if(id==='wind'&&lv2.wind&&lv2.wind[0]){z=lv2.wind[0];var n=Math.hypot(z[4],z[5])||1;dDir=[z[4]/n,z[5]/n];}
   if(id==='grav'&&lv2.grav&&lv2.grav[0]){z=lv2.grav[0];dGm=(z[5]<0)?0:(Math.abs(z[5])<G?1:2);}}
  if(!dOn){dOn=true;requestAnimationFrame(demoLoop);}
  fitCard();frStart();vsPlace(id,pos);
 }
 var PAIR={boost:'palA',palA:'boost',bounce:'palB',palB:'bounce'};  /* élément fixe et matière du joueur : une seule notion */
 function mark(id){st.seen[id]=1;if(id==='basics')st.intro=true;   /* R195 : l'ouverture est faite quand « Les bases » est lue */
 if(PAIR[id])st.seen[PAIR[id]]=1;if(id==='tools')for(var t=0;t<TOOLS.length;t++)st.seen[TOOLS[t]]=1;}
 function nextCard(){
  if(introCard){introCard=false;dOn=false;$$('tcard').classList.remove('on');$$('tshield').classList.remove('on');mode='intro';toStep(1);return;}
  if(!fromCodex)mark(cids[ci]);
  if(ci<cids.length-1){ci++;showCard();return;}
  if(!fromCodex)save();
  hide();
 }
 function skipCards(){
  if(introCard){introCard=false;finishIntro();return;}
  var k;if(!fromCodex){for(k=ci;k<cids.length;k++)mark(cids[k]);save();}
  hide();
 }
 function hide(){
  var vsA=mode==='card'&&!fromCodex&&$$('tcard').classList.contains('on');
  mode=null;introCard=false;fromCodex=false;isRev=false;dOn=false;
  var a=['tcard','tshield','tcoach'],i,e;
  for(i=0;i<a.length;i++){e=$$(a[i]);if(e)e.classList.remove('on');}
  e=$$('bPlay');if(e)e.classList.remove('tpulse');
  clearPulse();
  if(vsA)vsClose();else{e=$$('tout');if(e)e.classList.remove('on');}
 }
 function clearPulse(){
  var i,cs=document.querySelectorAll?document.querySelectorAll('#palRow .chip, #dock .dk'):[];
  for(i=0;i<cs.length;i++)cs[i].classList.remove('tpulse');
  var a=['palRow','dock'],e;for(i=0;i<a.length;i++){e=$$(a[i]);if(e)e.classList.remove('tlift');}
 }
 function pulseTarget(){ /* fait ressortir, au-dessus du voile, la puce ou l'outil dont parle la fiche */
  if(fromCodex)return;
  var id=cids[ci],e=entry(id),i,cs;
  if(e.cat==='mat'){
   var want=(id==='palB')?BOUNCEM:(id==='palA')?BOOSTM:ROPE;
   $$('palRow').classList.add('tlift');
   cs=document.querySelectorAll('#palRow .chip');
   for(i=0;i<cs.length;i++)cs[i].classList.toggle('tpulse',+cs[i].dataset.m===want);
  }else if(e.cat==='tool'){
   $$('dock').classList.add('tlift');
   cs=document.querySelectorAll('#dock .dk');
   for(i=0;i<cs.length;i++)cs[i].classList.toggle('tpulse',cs[i].getAttribute('data-m')===TOOLMODE[id]);
  }else clearPulse();
 }

 /* ── aide du niveau et explications ── */
 function help(){
  if(typeof S==='undefined')return;
  var ids=S.zen?[]:elemsOf(LEVELS[S.li]);
  if(!ids.length)ids=['basics'];
  openCards(ids,false,true);
 }
 function codexOpen(){
  var box=$$('cxList'),i,c,h='';
  function row(c){
   var ok=(c.id==='basics'||c.cat==='tool')||!!st.seen[c.id];
   return '<button class="cx'+(ok?'':' lock')+'" data-id="'+c.id+'" style="--tc:'+c.col+'"'+(ok?'':' disabled')+
    '><i></i><span>'+(ok?TR('tt_'+c.id):TR('tutoLocked'))+'</span></button>';}
  h+=row(CAT[0]);
  h+='<p class="cxh">'+TR('cx_h_tools')+'</p>';
  for(i=0;i<CAT.length;i++)if(CAT[i].cat==='tool'&&CAT[i].id!=='tools')h+=row(CAT[i]);
  h+='<p class="cxh">'+TR('cx_h_elems')+'</p>';
  for(i=0;i<CAT.length;i++){c=CAT[i];if(c.cat==='elem'||c.cat==='mat')h+=row(c);}
  box.innerHTML=h;
  var bs=box.querySelectorAll('.cx');
  for(i=0;i<bs.length;i++)bs[i].onclick=function(){openCards([this.getAttribute('data-id')],true,true);};
  $$('vCodex').classList.add('on');
 }

 /* ── dessin sur le terrain (coordonnées du jeu) ── */
 function rr(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
 function pulse(){return (typeof OPT!=='undefined'&&OPT.rm)?.5:.5+.5*Math.sin(T0*.09);}
 function cl(v,a,b){return v<a?a:(v>b?b:v);}
 function ringShapes(c,sh,col){
  var p=pulse(),i,q;
  c.save();c.strokeStyle=col;c.fillStyle=col;c.lineWidth=2;c.lineCap='round';
  for(i=0;i<sh.length;i++){
   q=sh[i];c.globalAlpha=.4+.5*p;c.setLineDash([7,5]);
   if(q.t==='r'){rr(c,q.x-3-p*3,q.y-3-p*3,q.w+6+p*6,q.h+6+p*6,8);c.stroke();c.globalAlpha=.07;c.setLineDash([]);c.fill();}
   else if(q.t==='c'){c.beginPath();c.arc(q.x,q.y,q.r+4+p*5,0,6.2832);c.stroke();}
   else{c.setLineDash([]);c.globalAlpha=.16+.16*p;c.lineWidth=16;c.beginPath();c.moveTo(q.x1,q.y1);c.lineTo(q.x2,q.y2);c.stroke();}
  }
  c.restore();
 }
 function tag(c,x,y,tx,ty,txt,col){ /* étiquette + trait de repère vers la cible */
  c.save();
  c.font='600 10px "JetBrains Mono",ui-monospace,Menlo,Consolas,monospace';
  try{c.letterSpacing='1.3px';}catch(e){}
  var s=txt.toUpperCase(),w=c.measureText(s).width+20;
  x=cl(x,w/2+4,W-w/2-4);y=cl(y,14,H-14);
  c.strokeStyle=col;c.fillStyle=col;c.lineWidth=1.2;c.globalAlpha=.8;
  c.beginPath();c.moveTo(x,y);c.lineTo(tx,ty);c.stroke();
  c.beginPath();c.arc(tx,ty,2.6,0,6.2832);c.fill();
  c.globalAlpha=1;
  c.fillStyle='rgba(5,9,15,.95)';rr(c,x-w/2,y-10,w,20,10);c.fill();
  c.strokeStyle=col;c.lineWidth=1.2;c.stroke();
  c.fillStyle='#EAF6FF';c.textAlign='center';c.textBaseline='middle';c.fillText(s,x+.7,y+.5);
  c.restore();
 }
 function toward(cx,cy,r,x,y){var d=Math.hypot(x-cx,y-cy)||1;return [cx+(x-cx)/d*r,cy+(y-cy)/d*r];}
 function partial(pts,u){ /* polyligne tronquée à la fraction u de sa longueur */
  var tot=0,seg=[],i,d,out=[[pts[0][0],pts[0][1]]],x=pts[0][0],y=pts[0][1],f;
  for(i=1;i<pts.length;i++){seg.push(Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]));tot+=seg[i-1];}
  d=cl(u,0,1)*tot;
  for(i=1;i<pts.length;i++){
   if(d>=seg[i-1]){out.push([pts[i][0],pts[i][1]]);d-=seg[i-1];x=pts[i][0];y=pts[i][1];}
   else{f=seg[i-1]?d/seg[i-1]:0;x=pts[i-1][0]+(pts[i][0]-pts[i-1][0])*f;y=pts[i-1][1]+(pts[i][1]-pts[i-1][1])*f;out.push([x,y]);break;}}
  return {pts:out,x:x,y:y};
 }
 function drawIntro(c){
  var lv=LEVELS[0];
  if(step===0){
   var b=lv.ball,cp=lv.cup,s=lv.star,cx=cp[0]+cp[2]/2,cy=cp[1]-22,e;
   ringShapes(c,[{t:'c',x:b[0],y:b[1],r:R+6},{t:'r',x:cp[0]-2,y:cp[1]-46,w:cp[2]+4,h:50}],'#4DD7FF');
   e=toward(b[0],b[1],R+10,b[0]+70,b[1]-26);tag(c,b[0]+72,b[1]-26,e[0],e[1],TR('ti_ball'),'#4DD7FF');
   e=toward(cx,cy,30,cx,cy-72);tag(c,cx,cy-72,e[0],e[1],TR('ti_goal'),'#9BE84B');
   var spk=(lv.w||[]).filter(function(w){return w[4]===2;});if(spk.length){var sw0=spk[0],smx=(sw0[0]+sw0[2])/2,smy=(sw0[1]+sw0[3])/2;e=toward(smx,smy,8,smx+40,smy-40);tag(c,smx+46,smy-44,e[0],e[1],TR('tt_spike'),'#FF5252');}   /* R194 : les pointes sont nommées sur le terrain dès l'ouverture */
   if(s){ringShapes(c,[{t:'c',x:s[0],y:s[1],r:14}],'#FFD85A');
    e=toward(s[0],s[1],20,s[0]+62,s[1]-34);tag(c,s[0]+62,s[1]-34,e[0],e[1],TR('ti_core'),'#FFD85A');}
  }else if(step===1&&!S.cur){
   var pts=(lv.optsol&&lv.optsol[0])||[[lv.ball[0],lv.ball[1]+90],[lv.ball[0]-30,lv.ball[1]+70]];
   var k=T0%210,u=k/130,pr=partial(pts,u>1?1:u);
   c.save();
   if(pr.pts.length>1){c.globalAlpha=.9;if(!(vx()&&vx().stroke(c,pr.pts,0,1))){c.strokeStyle='#4DD7FF';c.lineWidth=4;c.lineCap='round';c.beginPath();c.moveTo(pr.pts[0][0],pr.pts[0][1]);c.lineTo(pr.x,pr.y);c.stroke();}}
   c.globalAlpha=1;dfinger(c,pr.x,pr.y,k<14?k/14:0);
   c.restore();
  }
 }
 function draw(c){
  if(mode==='intro'||introCard)drawIntro(c);
  /* R186 : le repère d'une fiche est le projecteur + le contour (vsPlace), plus les anneaux sur le terrain */
 }

 /* ── mini-démos : le rendu est celui du jeu (VX.stroke, drawBall, drawSeg) ; les mouvements sont illustratifs,
    ce n'est pas la physique du moteur ── */
 function c01(u){return u<0?0:(u>1?1:u);}
 function lerp(a,b,u){return a+(b-a)*u;}
 function ease(u){u=c01(u);return u*u*(3-2*u);}
 function hexA(hex,a){return a>=1?hex:hex+('0'+Math.round(c01(a)*255).toString(16)).slice(-2);}
 function press(p,p0){var d=p-p0;return (d>=0&&d<.05)?d/.05:0;}
 function dball(c,x,y,tint,a,s){   /* R197 : particule fine de la proposition A (halo, cœur blanc) — plus le rendu épais du jeu */
  c.save();if(a!==undefined)c.globalAlpha=a;if(s){c.translate(x,y);c.scale(s[0],s[1]);x=0;y=0;}
  var g=c.createRadialGradient(x,y,0,x,y,6.5);g.addColorStop(0,'rgba(241,244,246,.98)');g.addColorStop(.32,tint?hexA(tint,.75):'rgba(160,190,255,.75)');g.addColorStop(1,'rgba(77,215,255,0)');
  c.fillStyle=g;c.beginPath();c.arc(x,y,6.5,0,6.2832);c.fill();c.restore();
 }
 function glow(c,x,y,r,col,a){var g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,hexA(col,a));g.addColorStop(1,hexA(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();}
 function trailOf(c,fn,p,n,dp,col){
  var i,q;
  for(i=n;i>=1;i--){q=fn(c01(p-i*dp));c.globalAlpha=(1-i/(n+1))*.4;c.fillStyle=col;c.beginPath();c.arc(q[0],q[1],7.5*(.3+.4*(1-i/(n+1))),0,6.2832);c.fill();}
  c.globalAlpha=1;
 }
 var FCOL={0:'#4DD7FF',1:'#FFAA3C',2:'#FF5470',3:'#A678FF',4:'#BFEAF7',5:'#E8B98A'};
 function neon(c,pts,mat){   /* R197 : trait fin et lumineux (proposition A) */
  if(pts.length<2)return;var i,col=FCOL[mat||0]||FCOL[0];c.save();c.lineCap='round';c.lineJoin='round';
  function path(){c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);}
  path();c.strokeStyle=hexA(col,.16);c.lineWidth=3.4;c.stroke();
  path();c.strokeStyle=hexA(col,.92);c.lineWidth=1.15;c.shadowColor=col;c.shadowBlur=5;c.stroke();c.shadowBlur=0;
  if(mat===2){c.strokeStyle=hexA(col,.7);c.lineWidth=.7;c.beginPath();for(i=1;i<pts.length;i++){var ax=pts[i-1][0],ay=pts[i-1][1],bx=pts[i][0],by=pts[i][1],L=Math.hypot(bx-ax,by-ay)||1,n=Math.floor(L/5),nx=(by-ay)/L,ny=-(bx-ax)/L;if(ny>0){nx=-nx;ny=-ny;}for(var j=0;j<n;j++){var f=(j+.5)/n;c.moveTo(ax+(bx-ax)*(j/n),ay+(by-ay)*(j/n));c.lineTo(ax+(bx-ax)*f+nx*3.2,ay+(by-ay)*f+ny*3.2);c.lineTo(ax+(bx-ax)*((j+1)/n),ay+(by-ay)*((j+1)/n));}}c.stroke();}
  c.restore();
 }
 function wall(c,mat,x1,y1,x2,y2){neon(c,[[x1,y1],[x2,y2]],mat);}
 function zone(c,x,y,w,h,col){   /* R197 : zone fine — voile léger, tirets fins, paires qui naissent et s'annihilent (proposition A) */
  c.save();c.fillStyle=hexA(col,.07);c.fillRect(x,y,w,h);
  c.strokeStyle=hexA(col,.65);c.lineWidth=.8;c.setLineDash([3,3]);c.lineDashOffset=-T0*.25;c.strokeRect(x+.5,y+.5,w-1,h-1);c.setLineDash([]);
  for(var k=0;k<4;k++){var per=70+k*17,u=((T0+k*31)%per)/per,hx=Math.sin(k*91.7+Math.floor((T0+k*31)/per)*12.9)*.5+.5,hy=Math.sin(k*47.3+Math.floor((T0+k*31)/per)*7.7)*.5+.5,px=x+w*(.15+.7*hx),py=y+h*(.15+.7*hy),sp=Math.sin(Math.PI*u)*5,an=k*1.3;
   c.fillStyle='rgba(255,84,112,'+(.85*(1-u*.3))+')';c.beginPath();c.arc(px-Math.cos(an)*sp,py-Math.sin(an)*sp,.9,0,6.2832);c.fill();
   c.fillStyle='rgba(110,226,255,'+(.85*(1-u*.3))+')';c.beginPath();c.arc(px+Math.cos(an)*sp,py+Math.sin(an)*sp,.9,0,6.2832);c.fill();
   if(u>.92){c.strokeStyle='rgba(241,244,246,'+(.6*(1-(u-.92)/.08))+')';c.lineWidth=.5;c.beginPath();c.arc(px,py,1+(u-.92)*60,0,6.2832);c.stroke();}}
  c.restore();
 }
 function cup(c,x,y,w){   /* R197 : bassin fin */
  var g=c.createLinearGradient(0,y-20,0,y);g.addColorStop(0,'rgba(155,235,75,0)');g.addColorStop(1,'rgba(155,235,75,.16)');
  c.fillStyle=g;c.fillRect(x,y-20,w,20);
  c.save();c.strokeStyle='rgba(155,235,75,.9)';c.lineWidth=1.1;c.shadowColor='#9BEB4B';c.shadowBlur=5;
  c.beginPath();c.moveTo(x,y-16);c.lineTo(x,y);c.lineTo(x+w,y);c.lineTo(x+w,y-16);c.stroke();c.restore();
 }
 function chip(c,x,y,w,txt,col,on){
  c.save();rr(c,x,y,w,20,10);c.fillStyle=on?hexA(col,.16):'rgba(255,255,255,.03)';c.fill();
  c.strokeStyle=on?col:'rgba(255,255,255,.18)';c.lineWidth=1.2;if(on){c.shadowColor=col;c.shadowBlur=8;}c.stroke();c.shadowBlur=0;
  c.font='600 8.5px "JetBrains Mono",ui-monospace,Menlo,monospace';c.fillStyle=on?col:'#8A97A6';c.textAlign='center';c.textBaseline='middle';
  c.fillText(String(txt).toUpperCase(),x+w/2,y+10.5);c.restore();
 }
 function dpill(c,x,y,txt,col){
  c.save();c.font='600 9px "JetBrains Mono",ui-monospace,Menlo,monospace';
  var w=(c.measureText(txt).width||30)+12;
  c.fillStyle='rgba(5,9,15,.95)';rr(c,x-w/2,y-8,w,16,8);c.fill();c.strokeStyle=col;c.lineWidth=1;c.stroke();
  c.fillStyle='#EAF6FF';c.textAlign='center';c.textBaseline='middle';c.fillText(txt,x,y+.5);c.restore();
 }
 function dfinger(c,x,y,pr){ /* doigt fantôme ; pr = 0..1 : onde au moment de l'appui */
  var r=11,g;c.save();
  if(pr>0){c.globalAlpha=(1-pr)*.55;c.strokeStyle='#fff';c.lineWidth=1.5;c.beginPath();c.arc(x,y,r+pr*17,0,6.2832);c.stroke();}
  c.globalAlpha=1;g=c.createRadialGradient(x,y,0,x,y,r*1.6);
  g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(.6,'rgba(255,255,255,.16)');g.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=g;c.beginPath();c.arc(x,y,r*1.6,0,6.2832);c.fill();
  c.strokeStyle='rgba(255,255,255,.92)';c.lineWidth=1.4;c.beginPath();c.arc(x,y,r*.6,0,6.2832);c.stroke();
  c.restore();
 }
 function dsel(c,pts,hAng){ /* cadre de sélection et poignées, comme dans l'éditeur */
  var cx=(pts[0][0]+pts[1][0])/2,cy=(pts[0][1]+pts[1][1])/2,col=T.matter;
  var x0=Math.min(pts[0][0],pts[1][0])-9,y0=Math.min(pts[0][1],pts[1][1])-9,x1=Math.max(pts[0][0],pts[1][0])+9,y1=Math.max(pts[0][1],pts[1][1])+9;
  var hx=cx+Math.cos(hAng)*34,hy=cy+Math.sin(hAng)*34;
  c.save();c.strokeStyle=col;c.globalAlpha=.75;c.lineWidth=1;c.setLineDash([4,4]);rr(c,x0,y0,x1-x0,y1-y0,6);c.stroke();
  c.beginPath();c.moveTo(cx,cy);c.lineTo(hx,hy);c.globalAlpha=.5;c.stroke();c.setLineDash([]);c.globalAlpha=1;
  c.fillStyle='rgba(5,9,15,.96)';c.strokeStyle=col;c.lineWidth=1.4;c.shadowColor=col;c.shadowBlur=8;
  c.beginPath();c.arc(hx,hy,9,0,6.2832);c.fill();c.stroke();
  c.beginPath();c.arc(cx,cy,8,0,6.2832);c.fill();c.stroke();c.shadowBlur=0;
  c.strokeStyle='#EAFBFF';c.lineWidth=1.3;c.beginPath();c.arc(hx,hy,3.8,-.4,4.3);c.stroke();
  c.beginPath();c.moveTo(cx-4,cy);c.lineTo(cx+4,cy);c.moveTo(cx,cy-4);c.lineTo(cx,cy+4);c.stroke();
  c.restore();
 }
 function rot(pts,c0,a,dx,dy){var co=Math.cos(a),si=Math.sin(a),o=[],i,x,y;
  for(i=0;i<pts.length;i++){x=pts[i][0]-c0[0];y=pts[i][1]-c0[1];o.push([c0[0]+x*co-y*si+dx,c0[1]+x*si+y*co+dy]);}return o;}

 /* R141 — LECTEUR DE SCÈNES : chaque fiche d'élément physique est une expérience décrite en données
    (tools/tuto-scenes-src.js) et simulée par le vrai moteur (tools/tutoscenes.js → window.TSC). Même déroulé pour toutes :
    le doigt trace le geste, la bille part, elle suit la trajectoire calculée, puis une pause. Rien n'est chorégraphié à la main. */
 function sfield(c,r,col,t){var ax=r[4],ay=r[5],L=Math.hypot(ax,ay)||1,ux=ax/L,uy=ay/L,k,j;
  if(Math.abs(uy)>Math.abs(ux)&&uy<0&&vx()&&vx().updraft){vx().updraft(c,[r[0],r[1],r[2],r[3]]);return;}
  c.save();c.beginPath();c.rect(r[0],r[1],r[2],r[3]);c.clip();c.lineCap='round';   /* filets d'air qui filent dans le sens du courant */
  for(k=0;k<14;k++){var h=Math.sin(k*12.9898)*43758.5453,jj=h-Math.floor(h),off=(k+.5)/14,span=Math.abs(ux)>Math.abs(uy)?r[2]:r[3],Lw=18+22*jj,ph2=((t*(1+jj)*.9+jj*400)%(span+Lw))-Lw;
   var px=Math.abs(ux)>Math.abs(uy)?(ux>0?r[0]+ph2:r[0]+r[2]-ph2):r[0]+r[2]*off,py=Math.abs(ux)>Math.abs(uy)?r[1]+r[3]*off:(uy>0?r[1]+ph2:r[1]+r[3]-ph2);
   c.strokeStyle=hexA(col,.18+.3*jj);c.lineWidth=.8+jj;c.beginPath();c.moveTo(px,py);c.quadraticCurveTo(px+ux*Lw/2-uy*3,py+uy*Lw/2+ux*3,px+ux*Lw,py+uy*Lw);c.stroke();}
  c.restore();}
 function scene(c,s,t){
  var D0=s.stroke?64:22,N=s.tr.length,HOLD=46,per=D0+N+HOLD,k=t%per,run=Math.max(0,k-D0),i,col;
  (s.nd||[]).forEach(function(r){zone(c,r[0],r[1],r[2],r[3],T.danger);});
  (s.wind||[]).forEach(function(r){sfield(c,r,'#A8C8E8',t);});
  (s.grav||[]).forEach(function(r){sfield(c,r,'#A878FF',t);});
  (s.mag||[]).forEach(function(m){for(i=0;i<3;i++){var u=((t*.012+i/3)%1);c.save();c.strokeStyle='#FF4D8D';c.globalAlpha=.45*(1-u);c.lineWidth=1.2;c.beginPath();c.arc(m[0],m[1],m[2]*(1-u),0,6.2832);c.stroke();c.restore();}
   glow(c,m[0],m[1],14,'#FF4D8D',.7);});
  (s.port||[]).forEach(function(p){[[p[0],p[1],'#4DD7FF'],[p[2],p[3],'#FFD85A']].forEach(function(q){c.save();c.strokeStyle=q[2];c.lineWidth=2;c.shadowColor=q[2];c.shadowBlur=8;c.beginPath();c.arc(q[0],q[1],12,0,6.2832);c.stroke();c.restore();glow(c,q[0],q[1],12,q[2],.35);});});
  (s.cv||[]).forEach(function(q){if(q.pass){c.save();c.setLineDash([2,3]);neon(c,q.pts,4);c.restore();}else neon(c,q.pts,q.m||0);});   /* R197 : courbes fines */
  (s.w||[]).forEach(function(q){wall(c,q[4],q[0],q[1],q[2],q[3]);});
  (s.mov||[]).forEach(function(m){var o=Math.sin((s.t0+run)*m.spd+(m.ph||0))*m.amp;wall(c,0,m.seg[0]+m.ax*o,m.seg[1]+m.ay*o,m.seg[2]+m.ax*o,m.seg[3]+m.ay*o);});
  if(s.cup)cup(c,s.cup[0],s.cup[1],s.cup[2]);
  if(s.stroke){if(k<D0){var pr=partial(s.stroke.pts,ease(k/(D0-8)));if(pr.pts.length>1)neon(c,pr.pts,s.stroke.mat);if(k<D0-6)dfinger(c,pr.x,pr.y,press(k/D0,0));}else neon(c,s.stroke.pts,s.stroke.mat);}
  var b=k<D0?s.ball:s.tr[Math.min(run,N-1)];
  for(i=6;i>=1&&k>=D0;i--){var q2=s.tr[Math.max(0,Math.min(run-i*2,N-1))];c.globalAlpha=(1-i/7)*.3;c.fillStyle=colOf(dId||'basics');c.beginPath();c.arc(q2[0],q2[1],5*(1-i/8),0,6.2832);c.fill();}
  c.globalAlpha=1;dball(c,b[0],b[1]);}
 var NDD={g:[],pairs:[],last:-1,cyc:-1};
 function ndDemo(c,t){   /* R199 — démonstration de la proposition A : zone où des paires naissent et s'annihilent ; un trait tenté
   y entre, la partie qui franchit le bord tremble puis se délite en sable fin ; la particule contourne la zone. t en images. */
  var w=DW,h=DH,ms=t*16.7,dt=NDD.last<0?16.7:Math.max(0,Math.min(50,ms-NDD.last));NDD.last=ms;
  var zx=w*.56,zy=h*.08,zw=w-zx-8,zh=h*.52,i,k;
  c.save();c.fillStyle='rgba(255,84,112,.07)';c.fillRect(zx,zy,zw,zh);
  c.strokeStyle='rgba(255,84,112,.65)';c.lineWidth=.8;c.setLineDash([3,3]);c.lineDashOffset=-ms*.02;c.strokeRect(zx+.5,zy+.5,zw-1,zh-1);c.setLineDash([]);
  if(Math.random()<dt*.0022&&NDD.pairs.length<4)NDD.pairs.push({x:zx+zw*(.2+.6*Math.random()),y:zy+zh*(.2+.6*Math.random()),a:Math.random()*6.28,L:900+Math.random()*700,age:0,s:3+Math.random()*6,hh:.3+.7*Math.random()});
  for(k=NDD.pairs.length-1;k>=0;k--){var p=NDD.pairs[k];p.age+=dt;var u=p.age/p.L;if(u>=1){NDD.pairs.splice(k,1);continue;}
   for(var sg=-1;sg<=1;sg+=2){for(var q=0;q<6;q++){var uu=Math.max(0,u-q*.025),ss=Math.sin(Math.PI*uu)*p.s;
     c.fillStyle=(sg<0?'rgba(255,84,112,':'rgba(110,226,255,')+((1-q/6)*.85*p.hh).toFixed(3)+')';c.beginPath();c.arc(p.x+Math.cos(p.a)*ss*sg,p.y+Math.sin(p.a)*ss*sg,q?.55:.95,0,6.2832);c.fill();}}
   if(u>.94){c.strokeStyle='rgba(241,244,246,'+(.6*(1-(u-.94)/.06))+')';c.lineWidth=.5;c.beginPath();c.arc(p.x,p.y,1+(u-.94)*80,0,6.2832);c.stroke();}}
  var cyc=5200,ph=(ms%cyc)/cyc,cn=Math.floor(ms/cyc),sx=w*.1,sy=zy+zh*.66,ex=zx+zw*.6,ey=zy+zh*.3,cut=Math.min(1,(zx-sx)/(ex-sx));
  c.lineCap='round';
  if(ph<.34){var g=Math.min(1,ph/.22),g1=Math.min(g,cut);
   c.strokeStyle='rgba(77,215,255,.9)';c.lineWidth=1.2;c.shadowColor='#4DD7FF';c.shadowBlur=5;c.beginPath();c.moveTo(sx,sy);c.lineTo(sx+(ex-sx)*g1,sy+(ey-sy)*g1);c.stroke();c.shadowBlur=0;
   if(g>cut){var jt=1.4;c.strokeStyle='rgba(255,84,112,'+(.6+.3*Math.random())+')';c.lineWidth=1;c.beginPath();c.moveTo(sx+(ex-sx)*cut,sy+(ey-sy)*cut);
    for(i=1;i<=6;i++){var f=cut+(g-cut)*i/6;c.lineTo(sx+(ex-sx)*f+(Math.random()-.5)*jt,sy+(ey-sy)*f+(Math.random()-.5)*jt);}c.stroke();}
   if(ph>.24&&NDD.cyc!==cn){NDD.cyc=cn;for(i=0;i<34;i++){var gg=cut+(1-cut)*Math.random();NDD.g.push({x:sx+(ex-sx)*gg,y:sy+(ey-sy)*gg,vx:(Math.random()-.5)*.012,vy:.003+Math.random()*.01,l:1,r:.3+Math.random()*.45,c:Math.random()<.55?'241,244,246':(Math.random()<.6?'255,140,170':'255,214,150')});}}}
  else{c.strokeStyle='rgba(77,215,255,'+(ph<.42?.9:Math.max(.25,.9-(ph-.42)*1.4))+')';c.lineWidth=1.2;c.beginPath();c.moveTo(sx,sy);c.lineTo(sx+(ex-sx)*cut,sy+(ey-sy)*cut);c.stroke();
   if(ph<.5){var bx0=sx+(ex-sx)*cut,by0=sy+(ey-sy)*cut,fl=(ph-.34)/.16;c.strokeStyle='rgba(255,84,112,'+(.7*(1-fl))+')';c.lineWidth=.6;c.beginPath();c.arc(bx0,by0,1.5+fl*6,0,6.2832);c.stroke();}}
  for(k=NDD.g.length-1;k>=0;k--){var gr=NDD.g[k];gr.x+=gr.vx*dt;gr.y+=gr.vy*dt;gr.vy+=.000012*dt;gr.l-=dt/1600;if(gr.l<=0){NDD.g.splice(k,1);continue;}
   c.fillStyle='rgba('+gr.c+','+(.85*gr.l).toFixed(3)+')';c.beginPath();c.arc(gr.x,gr.y,gr.r,0,6.2832);c.fill();}
  var bp=((ms+1800)%6400)/6400,bx,by;
  if(bp<.5){bx=w*.06+(zx-w*.1)*bp*2;by=h*.86-Math.sin(bp*2*Math.PI)*h*.05;}else{var a2=(bp-.5)*2;bx=zx-w*.04+(w-zx)*a2;by=zy+zh+(h*.88-zy-zh)*(1-Math.sin(a2*Math.PI))*.6+h*.1;}
  c.restore();dball(c,bx,by);
 }
 function demo(c,id,t){
  if(id==='nd'){ndDemo(c,t);return;}   /* R199 : la zone interdite a sa propre démonstration — le trait y entre et se délite en sable */
  if(typeof window!=='undefined'&&window.TSC&&window.TSC[id]){scene(c,window.TSC[id],t);return;}
  var p=(t%300)/300,i,q,x,y,u,pr,path,col=colOf(id),pk=.5+.5*Math.sin(t*.16);
  c.lineJoin='round';c.lineCap='round';
  switch(id){
  case 'basics':{
   var L0=[[44,30],[112,54]];
   cup(c,146,92,66);
   if(p<.3){pr=partial(L0,ease(p/.26));neon(c,pr.pts);if(p<.27)dfinger(c,pr.x,pr.y,press(p,0));}
   else{neon(c,L0);path=[[64,2],[78,36],[112,47],[134,60],[176,84]];
    q=c01((p-.34)/.56);pr=partial(path,q*.55+q*q*.45);dball(c,pr.x,pr.y);}
   break;}
  case 'tdraw':{
   var wave=[];for(i=0;i<=18;i++){u=i/18;wave.push([22+u*188,58+Math.sin(u*Math.PI*1.7)*20-u*10]);}
   if(p<.48){pr=partial(wave,ease(p/.44));neon(c,pr.pts);if(p<.46)dfinger(c,pr.x,pr.y,press(p,0));}
   else{neon(c,wave);pr=partial(wave,c01((p-.52)/.4));dball(c,pr.x,pr.y-9);}
   break;}
  case 'tline':{
   var A=[28,26],B=[190,72],E=[[190,72],[214,94]];
   neon(c,E);
   if(p<.5){q=ease(p/.44);var cx2=lerp(A[0],B[0],q),cy2=lerp(A[1],B[1],q);
    neon(c,[A,[cx2,cy2]]);if(p<.47)dfinger(c,cx2,cy2,press(p,0));
    dpill(c,(A[0]+cx2)/2,(A[1]+cy2)/2-14,'−12 %','#4DD7FF');
    if(q>.85){c.save();c.strokeStyle='#EAFBFF';c.lineWidth=1.6;c.beginPath();c.arc(B[0],B[1],7,0,6.2832);c.stroke();
     c.strokeStyle=T.matter;c.globalAlpha=.6;c.beginPath();c.arc(B[0],B[1],10+pk*3,0,6.2832);c.stroke();c.restore();}}
   else{neon(c,[A,B]);pr=partial([A,B],c01((p-.56)/.38));dball(c,pr.x,pr.y-8.5);}
   break;}
  case 'terase':{
   var L1=[[26,76],[104,50]],L2=[[124,38],[206,78]],mid=[165,58];
   neon(c,L1);
   if(p<.3){neon(c,L2);dfinger(c,lerp(200,mid[0],ease(p/.2)),lerp(96,mid[1],ease(p/.2)),press(p,.2));}
   else if(p<.5){neon(c,L2);c.save();c.lineCap='round';c.strokeStyle='rgba(255,82,82,.28)';c.lineWidth=13;c.beginPath();c.moveTo(L2[0][0],L2[0][1]);c.lineTo(L2[1][0],L2[1][1]);c.stroke();
    c.setLineDash([4,5]);c.lineDashOffset=-t*.6;c.strokeStyle=T.danger;c.lineWidth=2;c.stroke();c.restore();dfinger(c,mid[0],mid[1],0);}
   else if(p<.8){u=(p-.5)/.3;c.globalAlpha=1-u;neon(c,L2);c.globalAlpha=1;
    for(i=0;i<9;i++){x=lerp(L2[0][0],L2[1][0],i/8);y=lerp(L2[0][1],L2[1][1],i/8);
     c.globalAlpha=(1-u)*.8;c.fillStyle=T.danger;c.beginPath();c.arc(x+(i%3-1)*10*u,y-u*(8+(i%4)*5),1.8,0,6.2832);c.fill();}
    c.globalAlpha=1;dpill(c,mid[0],mid[1]-16-u*10,'+18 %',T.goal);}
   break;}
  case 'tmove':{
   var A0=[52,74],B0=[108,74],C0=[80,74],pts,hA=-Math.PI/2,th=0,dxy=[0,0],fx,fy,txt=null;
   if(p<.32){q=ease(p/.28);dxy=[64*q,-28*q];pts=rot([A0,B0],C0,0,dxy[0],dxy[1]);fx=C0[0]+dxy[0];fy=C0[1]+dxy[1];}
   else{dxy=[64,-28];q=ease((p-.4)/.36);th=-q*Math.PI*.22;pts=rot([A0,B0],C0,th,dxy[0],dxy[1]);hA=-Math.PI/2+th;
    fx=C0[0]+dxy[0]+Math.cos(hA)*34;fy=C0[1]+dxy[1]+Math.sin(hA)*34;if(p>.4&&p<.78)txt=Math.round(th*180/Math.PI)+'°';}
   neon(c,pts);dsel(c,pts,hA);
   if(p<.3)dfinger(c,fx,fy,press(p,0));else if(p<.8)dfinger(c,fx,fy,press(p,.38));
   if(txt)dpill(c,C0[0]+dxy[0],C0[1]+dxy[1]-40,txt,'#4DD7FF');
   break;}
  case 'nd':{
   if(vx()&&vx().nd)vx().nd(c,{nd:[[126,4,74,96]]});
   c.save();c.strokeStyle=T.danger;c.globalAlpha=.6;c.lineWidth=1.2;c.setLineDash([4,4]);c.strokeRect(126.5,4.5,73,95);c.restore();
   q=ease(p/.62);x=lerp(22,168,q);var xe=Math.min(x,124),ye=60+(xe-22)*.06;
   neon(c,[[22,60],[xe,ye]]);if(p<.7)dfinger(c,x,60+(x-22)*.06,press(p,0));
   if(x>124){c.save();c.strokeStyle=T.danger;c.lineWidth=2.2;c.globalAlpha=.6+.4*pk;
    c.beginPath();c.moveTo(121,ye-5);c.lineTo(131,ye+5);c.moveTo(131,ye-5);c.lineTo(121,ye+5);c.stroke();c.restore();}
   break;}
  case 'spike':{
   wall(c,2,46,92,186,92);
   q=c01(p/.5);
   if(p<.5)dball(c,116,lerp(6,78,q*q));
   else{u=(p-.5)/.4;c.save();c.strokeStyle=T.danger;c.globalAlpha=Math.max(0,1-u);c.lineWidth=2;c.beginPath();c.arc(116,82,6+u*26,0,6.2832);c.stroke();c.restore();
    if(u<.35)dball(c,116,78,undefined,1-u/.35);}
   break;}
  case 'bounce':{
   c.save();c.strokeStyle='rgba(255,255,255,.25)';c.setLineDash([3,4]);c.lineWidth=1;c.beginPath();c.moveTo(70,30);c.lineTo(162,30);c.stroke();c.restore();
   wall(c,1,56,94,176,94);
   if(p<.34)y=lerp(30,80,Math.pow(p/.34,2));
   else if(p<.86){u=(p-.34)/.52;y=80-72*(1-Math.pow(2*u-1,2));}
   else y=80;
   dball(c,116,y);
   break;}
  case 'boost':{
   wall(c,3,14,90,218,90);
   var fb=function(v){return [lerp(14,214,Math.pow(v,1.7)),81];};q=c01(p/.9);pr=fb(q);
   trailOf(c,fb,q,7,.028,'#A878FF');dball(c,pr[0],pr[1]);
   break;}
  case 'tunnel':{
   if(window.VX&&window.VX.tunnel)window.VX.tunnel(c,[[14,70],[218,70]],null);
   if(p<.45){q=c01(p/.3);dball(c,62,lerp(16,59,q*q));}else dball(c,62,59,undefined,Math.max(0,1-(p-.45)*4));
   if(p>.4){u=c01((p-.4)/.45);var ff=function(v){return [168,lerp(6,108,v*v)];};pr=ff(u);trailOf(c,ff,u,7,.03,'#A9BCEB');dball(c,pr[0],pr[1]);
    if(u>.5&&u<.8){c.save();c.strokeStyle='#A9BCEB';c.globalAlpha=(.8-u)*3;c.lineWidth=1.2;c.beginPath();c.arc(168,70,6+(u-.5)*60,0,6.2832);c.stroke();c.restore();}}
   break;}
  case 'ice':{
   wall(c,4,14,58,218,88);
   var fi=function(v){var xx=lerp(20,210,Math.pow(v,1.35));return [xx,58+(xx-14)*.147-9];};q=c01(p/.9);pr=fi(q);
   trailOf(c,fi,q,8,.03,'#BFEAF7');dball(c,pr[0],pr[1]);
   break;}
  case 'palB':case 'palA':case 'palC':{
   var mat=(id==='palB')?1:(id==='palA')?3:5,nmk=(id==='palB')?'mat_bounce':(id==='palA')?'mat_boost':'mat_rope',cc=(id==='palB')?'#FFAA3C':(id==='palA')?'#A878FF':'#E8B98A';
   var on=p>.26;
   chip(c,16,80,64,TR('mat_structure'),'#43D5F5',!on);chip(c,88,80,64,TR(nmk),cc,on);
   if(p<.26){u=ease(p/.22);dfinger(c,lerp(150,120,u),lerp(40,90,u),press(p,.2));}
   else if(p<.7){pr=partial([[46,22],[188,42]],ease((p-.3)/.36));
    if(mat===5){c.save();c.strokeStyle=cc;c.lineWidth=3;c.shadowColor=cc;c.shadowBlur=8;c.beginPath();c.moveTo(46,22);
     c.quadraticCurveTo((46+pr.x)/2,(22+pr.y)/2+14*c01((p-.3)/.2),pr.x,pr.y);c.stroke();c.restore();}
    else if(pr.pts.length>1)neon(c,pr.pts,mat);
    if(p<.68)dfinger(c,pr.x,pr.y,press(p,.3));}
   else{if(mat===5){c.save();c.strokeStyle=cc;c.lineWidth=3;c.shadowColor=cc;c.shadowBlur=8;c.beginPath();c.moveTo(46,22);c.quadraticCurveTo(117,44,188,42);c.stroke();c.restore();}
    else neon(c,[[46,22],[188,42]],mat);}
   break;}
  case 'wind':{
   zone(c,20,12,192,80,'#A8C8E8');
   var wx=dDir[0],wy=dDir[1];
   for(i=0;i<12;i++){var sx=30+((i*53)%170),sy=20+((i*29)%64),s2=(t*.9+i*17)%70,a2=Math.sin(s2/70*Math.PI);
    c.save();c.strokeStyle='#A8C8E8';c.globalAlpha=.55*a2;c.lineWidth=1.4;c.beginPath();
    c.moveTo(sx+wx*s2,sy+wy*s2);c.lineTo(sx+wx*(s2+16),sy+wy*(s2+16));c.stroke();c.restore();}
   dball(c,lerp(70,162,ease(p))*(Math.abs(wx)>.3?1:0)+(Math.abs(wx)>.3?0:116)+wx*0,lerp(52,52,0)+wy*(ease(p)-.5)*60);
   break;}
  case 'grav':{
   zone(c,60,8,112,88,'#A878FF');
   var sg=(dGm===0)?-1:1;
   for(i=0;i<3;i++){y=(t*.5+i*30)%90;var yy=(sg>0)?8+y:96-y;c.save();c.strokeStyle='#A878FF';c.globalAlpha=.4;c.lineWidth=1.6;
    for(var k2=0;k2<3;k2++){var xx=82+k2*34;c.beginPath();c.moveTo(xx-6,yy-3*sg);c.lineTo(xx,yy+3*sg);c.lineTo(xx+6,yy-3*sg);c.stroke();}c.restore();}
   if(dGm===0)y=lerp(92,12,ease(p));else if(dGm===1)y=10+80*p*.8;else y=10+80*Math.pow(p,2.6);
   dball(c,116,y);
   break;}
  case 'mag':{
   glow(c,116,52,44,'#FF4D8D',.3);
   for(i=0;i<3;i++){u=((t*.012+i/3)%1);c.save();c.strokeStyle='#FF4D8D';c.globalAlpha=(u)*.5;c.lineWidth=1.3;c.beginPath();c.arc(116,52,46*(1-u)+6,0,6.2832);c.stroke();c.restore();}
   c.fillStyle='#FF4D8D';c.beginPath();c.arc(116,52,5,0,6.2832);c.fill();
   q=ease(p/.85);x=lerp(20,110,q)+Math.sin(q*3)*0;y=lerp(14,49,q*q)+(1-q)*20*Math.sin(q*Math.PI);
   dball(c,x,y);
   break;}
  case 'port':{
   glow(c,46,52,26,'#4DD7FF',.35);glow(c,188,52,26,'#9BEB4B',.35);
   c.save();c.lineWidth=2.6;c.strokeStyle='#4DD7FF';c.beginPath();c.ellipse(46,52,8,20,0,0,6.2832);c.stroke();
   c.strokeStyle='#9BEB4B';c.beginPath();c.ellipse(188,52,8,20,0,0,6.2832);c.stroke();c.restore();
   if(p<.4)dball(c,lerp(4,44,ease(p/.4)),52);
   else{u=(p-.4)/.45;if(u<1)dball(c,lerp(190,232,ease(u)),52);
    if(p<.5){c.save();c.strokeStyle='#9BEB4B';c.globalAlpha=1-(p-.4)/.1;c.lineWidth=2;c.beginPath();c.arc(188,52,8+(p-.4)*220,0,6.2832);c.stroke();c.restore();}}
   break;}
  case 'mov':{
   y=52+Math.sin(t*.05)*28;
   c.save();c.strokeStyle='rgba(255,255,255,.2)';c.setLineDash([3,4]);c.lineWidth=1;
   c.beginPath();c.moveTo(86,24);c.lineTo(146,24);c.moveTo(86,80);c.lineTo(146,80);c.stroke();c.restore();
   wall(c,0,86,y,146,y);
   c.save();c.strokeStyle='#43D5F5';c.globalAlpha=.6;c.lineWidth=1.6;
   c.beginPath();c.moveTo(166,40);c.lineTo(166,66);c.moveTo(161,45);c.lineTo(166,39);c.lineTo(171,45);c.moveTo(161,61);c.lineTo(166,67);c.lineTo(171,61);c.stroke();c.restore();
   break;}
  case 'ent':{
   var open=p>.26;
   c.save();c.strokeStyle='#FFD85A';c.globalAlpha=.4;c.lineWidth=1.2;c.setLineDash([3,5]);c.beginPath();c.moveTo(48,48);c.quadraticCurveTo(80,14,108,46);c.stroke();c.restore();
   if(vx()&&vx().core){vx().core(c,{star:[40,52],wd:1});}c.save();c.strokeStyle='#FFD85A';c.globalAlpha=.9;c.lineWidth=1.4;c.beginPath();c.arc(116,52,9,0,6.2832);c.stroke();c.restore();
   if(!open)wall(c,0,116,20,116,84);
   else{c.save();c.strokeStyle='#FFD85A';c.globalAlpha=.3;c.setLineDash([3,4]);c.beginPath();c.moveTo(116,20);c.lineTo(116,84);c.stroke();c.restore();}
   if(p>.24&&p<.4){c.save();c.strokeStyle='#FFD85A';c.globalAlpha=1-(p-.24)/.16;c.lineWidth=2;c.beginPath();c.arc(40,52,10+(p-.24)*160,0,6.2832);c.stroke();c.restore();}
   dball(c,lerp(6,226,ease(p/.95)*.85+p*.15),52);
   break;}
  case 'sup':{
   zone(c,70,8,52,88,'#A878FF');
   x=lerp(10,222,ease(p/.92));
   var sp=c01((x-70)/50)*17;
   dball(c,x,52+sp*(x>122?1:.4)*0+(x>70?-sp:0));
   if(x>70)dball(c,x,52+sp,'#A878FF',.62);
   break;}
  case 'det':{
   c.save();c.strokeStyle='#FFD85A';c.lineWidth=1.6;c.globalAlpha=.75;c.setLineDash([4,4]);c.lineDashOffset=-t*.3;c.beginPath();c.arc(140,52,22,0,6.2832);c.stroke();c.restore();
   glow(c,140,52,26,'#FFD85A',.18);
   x=lerp(30,214,ease(p/.9));
   dball(c,x,52);
   if(x<128)dball(c,x,52+16,'#A878FF',.6);
   else if(x<160){u=(x-128)/32;dball(c,x,52+16,'#A878FF',.6*(1-u));}
   if(x>128&&x<150){c.save();c.strokeStyle='#FFD85A';c.globalAlpha=1-(x-128)/22;c.lineWidth=2;c.beginPath();c.arc(x,52,10+(x-128),0,6.2832);c.stroke();c.restore();}
   break;}
  case 'rec':{   /* R243 : deux versions convergent vers la lame, une seule en ressort par la voie claire */
   if(vx()&&vx().qrec)vx().qrec(c,[150,52,20,0],t,p<.5,p>=.5?(p-.5)*120:999);
   q=c01(p/.5);
   if(p<.5){dball(c,lerp(20,150,q),lerp(14,52,q));dball(c,lerp(20,150,q),lerp(90,52,q),'#A878FF',.62);}
   else dball(c,lerp(150,226,c01((p-.5)/.45)),52);
   break;}
  case 'tdil':{
   zone(c,72,10,88,84,'#4DD7FF');
   var ft=function(v){var xx=(v<.3)?lerp(8,72,v/.3):(v<.75)?lerp(72,160,(v-.3)/.45):lerp(160,226,(v-.75)/.25);return [xx,52];};
   q=c01(p/.95);pr=ft(q);trailOf(c,ft,q,10,.016,'#4DD7FF');dball(c,pr[0],pr[1]);
   c.save();c.translate(116,26);c.strokeStyle='#4DD7FF';c.globalAlpha=.7;c.lineWidth=1.4;c.beginPath();c.arc(0,0,9,0,6.2832);c.stroke();
   c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(t*.02)*6,Math.sin(t*.02)*6);c.moveTo(0,0);c.lineTo(0,-5);c.stroke();c.restore();
   break;}
  case 'soft':{
   wall(c,0,40,94,192,94);
   var yy2,sq=0;
   if(p<.4){yy2=lerp(14,84,Math.pow(p/.4,2));}
   else if(p<.55){u=(p-.4)/.15;sq=Math.sin(u*Math.PI)*.38;yy2=84+sq*7;}
   else{u=(p-.55)/.4;yy2=84-60*(1-Math.pow(2*u-1,2))*.7;}
   dball(c,116,yy2,undefined,1,[1+sq,1-sq]);
   break;}
  default:
   dball(c,116,52);
  }
 }
 function demoLoop(){
  if(!dOn)return;
  var cv2=$$('tdemo');
  if(cv2){
   if(!dCtx||dCtx.canvas!==cv2)dCtx=cv2.getContext('2d');
   var cw=cv2.clientWidth||300,chh=cv2.clientHeight||Math.round(cw*DH/DW),dpr=Math.min(2,window.devicePixelRatio||1);
   if(cv2.width!==Math.round(cw*dpr)||cv2.height!==Math.round(chh*dpr)){cv2.width=Math.round(cw*dpr);cv2.height=Math.round(chh*dpr);}
   var k=cv2.width/DW,ty=(cv2.height-DH*k)/2;
   dCtx.setTransform(k,0,0,k,0,ty);dCtx.clearRect(0,-ty/k,DW,cv2.height/k);
   (function(c,t){var hz=DH*.14,i,j,y;c.save();c.strokeStyle='rgba(77,215,255,.10)';c.lineWidth=.45;   /* R197 : sol holographique en perspective (proposition A) */
    for(i=-8;i<=8;i++){c.beginPath();c.moveTo(DW/2+i*DW*.06,hz);c.lineTo(DW/2+i*DW*.32,DH);c.stroke();}
    c.globalAlpha=.6;for(j=0;j<6;j++){y=hz+(DH-hz)*Math.pow(((j+(t*.004)%1)/6),1.7);c.beginPath();c.moveTo(0,y);c.lineTo(DW,y);c.stroke();}c.restore();})(dCtx,dT);
   demo(dCtx,dId,dT);
  }
  dT+=(typeof OPT!=='undefined'&&OPT.rm)?0:1;
  requestAnimationFrame(demoLoop);
 }

 /* ── branchement des boutons (le HTML est statique dans index.html) ── */
 function init(){
  if(typeof document==='undefined'||!$$('tcard'))return;
  window.addEventListener('resize',function(){metrics();if(mode==='card')fitCard();});
  $$('tok').onclick=function(){nextCard();};
  $$('tskip').onclick=function(){skipCards();};
  $$('tcoachOk').onclick=function(){if(mode==='intro'&&step===0)toStep(1);};
  $$('tcoachSkip').onclick=function(){if(mode==='intro')finishIntro();};
  var ph=$$('pHelp');if(ph)ph.onclick=function(){$$('vPause').classList.remove('on');help();};
  var sc=$$('sCodex');if(sc)sc.onclick=function(){$$('vSet').classList.remove('on');codexOpen();};
  var si=$$('sIntro');if(si)si.onclick=function(){$$('vSet').classList.remove('on');st.intro=false;save();try{goto('game');loadLevel(0);}catch(x){}};   /* R116 : rejouer l'introduction */
  var cc=$$('cxClose');if(cc)cc.onclick=function(){$$('vCodex').classList.remove('on');};
 }
 init();

 return {editorReady:function(){return st.intro;},state:state,load:load,reset:reset,onLoad:onLoad,tick:tick,draw:draw,help:help,codex:codexOpen,
         _cat:CAT,_elemsOf:elemsOf,_seen:function(){return st.seen;},_intro:function(){return st.intro;},
         _demo:demo,_focus:focusOf,_tools:TOOLS,_pend:function(){return pend;}};
})();
if(typeof window!=='undefined')window.TUTO=TUTO;
