/* ===== ETAGE 7A DEBUT ===== R506 · Monde 7 (7) — étage 7 des créatures actives, première créature : CULBUTE
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage6.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans culbute : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : ajouté à window.QXE6 (table de dessin déjà appelée par qxcrea.js dessinerAct) sous la clé 'culbute'.
   Tout ce qui agit sur la bille est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1
   (assurée par crForce d'origine : b.cs = {}).

   culbute (Ver × Paramécie, « rotation instable, axe qui bascule ») : un fuseau cilié épais qui dérive lentement (x ± ax, y ± ay,
          pulsation w, phase ph) en basculant sans cesse sur lui-même (attente active : jamais immobile).
          Au contact (rayon r) il prend la bille au bout de son axe et FAIT LA CULBUTE : il la fait tourner autour de lui de rot degrés
          (signe = sens ; 180 par défaut) en dur images, pesanteur suspendue, puis la relâche avec SA vitesse d'arrivée tournée du même
          angle (bornée vmin..vmax). Pause cd.
          Effet neuf : un PIVOT VIVANT — il change le CAP de la particule (demi-tour, quart de tour) sans lui prendre son élan. */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e7a) return;
F.e7a = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap(), D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'culbute'); CACHE.set(cr, v); } return v; }
function segD(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let u = l > 1e-9 ? ((px - ax) * dx + (py - ay) * dy) / l : 0; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const x = ax + dx * u - px, y = ay + dy * u - py; return Math.sqrt(x * x + y * y); }
const sm = u => (u = u < 0 ? 0 : u > 1 ? 1 : u, u * u * (3 - 2 * u));
function culPos(e, t) { const w = e.w || .008, ph = e.ph || 0; return [e.x + (e.ax || 0) * Math.sin(t * w + ph), e.y + (e.ay || 0) * Math.sin(t * w * .73 + ph * 1.3)]; }
function culAng(e, st, t) { const s = sm((t - st.in) / (e.dur || 70)); return st.a + st.sg * st.rot * s; }   // angle de portage (rad)
F.crPos = function (e, t) { return e.t === 'culbute' ? culPos(e, t) : oPos(e, t); };
F.e7Pos = culPos; F.e7Ang = culAng;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  let ax = b.cpx == null ? b.x : b.cpx, ay = b.cpy == null ? b.y : b.cpy;
  oForce(b, sub, lv, g);                                // autres créatures + remise à zéro (frames<=1)
  if ((ax - b.x) * (ax - b.x) + (ay - b.y) * (ay - b.y) > 900) { ax = b.x; ay = b.y; }
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'culbute') continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0, sp: 0 }), q = culPos(e, t);
    if (st.h) {
      const dur = e.dur || 70, q1 = culPos(e, t + 1), a0 = culAng(e, st, t), a1 = culAng(e, st, t + 1);
      if (t - st.in >= dur) {                           // relâche : vitesse d'arrivée tournée de rot
        const c = Math.cos(st.sg * st.rot), s = Math.sin(st.sg * st.rot);
        let vx = st.vx * c - st.vy * s, vy = st.vx * s + st.vy * c; const v = Math.hypot(vx, vy);
        const vm = Math.max(e.vmin || 3, Math.min(e.vmax || 9, v));
        if (v < 1e-3) { vx = -Math.sin(a0) * st.sg; vy = Math.cos(a0) * st.sg; } else { vx /= v; vy /= v; }
        b.vx = vx * vm; b.vy = vy * vm; st.h = 0; st.out = t; st.cd = t + (e.cd || 90);
        if (racine.BUS) BUS.emit('creature.spit', { x: b.x, y: b.y });
      } else {
        const k = Math.min(1, (t - st.in) / 14), R = st.R0 + (st.R - st.R0) * k;
        b.x = q[0] + R * Math.cos(a0); b.y = q[1] + R * Math.sin(a0);
        b.vx = q1[0] + R * Math.cos(a1) - b.x; b.vy = q1[1] + R * Math.sin(a1) - b.y - gg / sub;
      }
    } else if (t >= st.cd && segD(q[0], q[1], ax, ay, b.x, b.y) < (e.r || 26)) {
      st.h = 1; st.in = t; st.vx = b.vx; st.vy = b.vy; st.a = Math.atan2(b.y - q[1], b.x - q[0]);
      st.R0 = Math.max(4, Math.hypot(b.x - q[0], b.y - q[1])); st.R = e.R || 24; st.rot = Math.abs(e.rot == null ? 180 : e.rot) * D2R;
      st.sg = (e.rot != null && e.rot < 0) ? -1 : 1;
      if (racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
    }
  }
  b.cpx = b.x; b.cpy = b.y;
};

/* ───────────── RENDU : atlas pré-calculé (fuseau cilié épais, lumière, nervures, soies) ─────────────
   NA images d'une onde complète menée par la tête (corps + soies métachronales), dessinées une fois ; en jeu : drawImage tourné,
   « vrille » (roulis) rendue par un léger écrasement (jamais sous 0,7 : le corps reste épais) et le reflet qui glisse. */
const NA = 24, AW = 132, AH = 72, DPR = 2, L = 104, HW = 19;
let ATL = null, GLOW = null;
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function atlas() {
  if (ATL) return ATL;
  const c = cv(AW * DPR * NA, AH * DPR), g = c.getContext('2d'), N = 40;
  for (let f = 0; f < NA; f++) {
    const ph = f / NA * Math.PI * 2; g.save(); g.translate((f * AW + AW / 2) * DPR, AH / 2 * DPR); g.scale(DPR, DPR); g.lineCap = 'round'; g.lineJoin = 'round';
    const X = [], Y = [], Wd = [], NX = [], NY = [];
    for (let k = 0; k <= N; k++) { const u = k / N, x = L / 2 - u * L, env = .15 + .85 * u;   // u=0 tête (x>0) → queue
      X.push(x); Y.push(6.5 * env * Math.sin(ph - u * 5.4) - 3 * env * Math.sin(ph - .6));
      Wd.push(HW * Math.pow(Math.sin(Math.PI * Math.min(1, .06 + u * .97)), .62) * (1 - .3 * u) + 1.2); }
    for (let k = 0; k <= N; k++) { const a = Math.max(0, k - 1), b = Math.min(N, k + 1), tx = X[b] - X[a], ty = Y[b] - Y[a], l = Math.hypot(tx, ty) || 1; NX.push(-ty / l); NY.push(tx / l); }
    /* soies : frange tout autour, onde métachronale de la tête vers la queue */
    g.beginPath();
    for (let k = 1; k < N; k++) for (const sd of [-1, 1]) {
      const bx = X[k] + NX[k] * Wd[k] * sd, by = Y[k] + NY[k] * Wd[k] * sd, p = ph * 2 - k * .55, Ls = 6.5 + 1.5 * Math.sin(k * 1.7), sw = 3.2 * Math.sin(p);
      const tx = -NY[k] * sd, ty = NX[k] * sd;   // tangente vers la queue
      g.moveTo(bx, by); g.quadraticCurveTo(bx + NX[k] * sd * Ls * .55 + tx * sw * .3, by + NY[k] * sd * Ls * .55 + ty * sw * .3, bx + NX[k] * sd * Ls + tx * (sw + 2.4), by + NY[k] * sd * Ls + ty * (sw + 2.4)); }
    g.strokeStyle = 'rgba(190,236,255,.55)'; g.lineWidth = .7; g.stroke();
    /* corps : contour unique, volume (dégradé de cylindre : bords sombres, bande claire haute), rim */
    const path = () => { g.beginPath(); g.moveTo(X[0] + 3, Y[0]); for (let k = 0; k <= N; k++) g.lineTo(X[k] + NX[k] * Wd[k], Y[k] + NY[k] * Wd[k]);
      g.quadraticCurveTo(X[N] - 5, Y[N], X[N] - NX[N] * Wd[N], Y[N] - NY[N] * Wd[N]); for (let k = N; k >= 0; k--) g.lineTo(X[k] - NX[k] * Wd[k], Y[k] - NY[k] * Wd[k]); g.closePath(); };
    path(); const gr = g.createLinearGradient(0, -HW - 4, 0, HW + 4);
    gr.addColorStop(0, 'rgba(40,70,120,.55)'); gr.addColorStop(.28, 'rgba(176,226,255,.62)'); gr.addColorStop(.42, 'rgba(226,246,255,.7)');
    gr.addColorStop(.62, 'rgba(130,170,240,.5)'); gr.addColorStop(1, 'rgba(36,40,96,.62)'); g.fillStyle = gr; g.fill();
    g.save(); g.clip();
    /* nervures longitudinales + anneaux transverses (épaisseur) */
    g.lineWidth = .6; for (const fz of [-.62, -.3, .05, .38, .7]) { g.beginPath(); for (let k = 2; k < N - 1; k++) { const x = X[k] + NX[k] * Wd[k] * fz, y = Y[k] + NY[k] * Wd[k] * fz; k > 2 ? g.lineTo(x, y) : g.moveTo(x, y); }
      g.strokeStyle = fz < 0 ? 'rgba(240,252,255,.42)' : 'rgba(170,150,240,.38)'; g.stroke(); }
    g.beginPath(); for (let k = 3; k < N - 1; k += 3) { g.moveTo(X[k] + NX[k] * Wd[k], Y[k] + NY[k] * Wd[k]); g.quadraticCurveTo(X[k] + 2.2, Y[k], X[k] - NX[k] * Wd[k], Y[k] - NY[k] * Wd[k]); }
    g.strokeStyle = 'rgba(210,235,255,.22)'; g.lineWidth = .8; g.stroke();
    /* vacuoles (paramécie) vues par transparence, et noyau lumineux */
    const vk = 12, vp = .5 + .5 * Math.sin(ph); g.fillStyle = 'rgba(150,255,226,' + (.32 + .25 * vp) + ')'; g.beginPath(); g.ellipse(X[vk], Y[vk] - 2, 5 + 2 * vp, 4 + 1.5 * vp, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(196,170,255,.45)'; g.beginPath(); g.ellipse(X[26], Y[26] + 1.5, 4.5, 3.4, 0, 0, 7); g.fill();
    g.restore();
    path(); g.strokeStyle = 'rgba(236,250,255,.85)'; g.lineWidth = 1.05; g.stroke();
    /* reflet haut (lumière) */
    g.beginPath(); for (let k = 3; k < N - 6; k++) { const x = X[k] - NX[k] * Wd[k] * .62, y = Y[k] - NY[k] * Wd[k] * .62; k > 3 ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.6; g.stroke();
    /* tête : bouche (sillon oral) et deux points oculaires */
    g.fillStyle = 'rgba(236,250,255,.9)'; g.beginPath(); g.arc(X[2] - 1, Y[2] - 4, .9, 0, 7); g.arc(X[2] - 1, Y[2] + 4, .9, 0, 7); g.fill();
    g.restore();
  }
  ATL = c; return c;
}
function glow() {
  if (GLOW) return GLOW; const s = 128, c = cv(s, s), g = c.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  r.addColorStop(0, 'rgba(150,215,255,.55)'); r.addColorStop(.45, 'rgba(120,150,255,.18)'); r.addColorStop(1, 'rgba(90,110,220,0)'); g.fillStyle = r; g.fillRect(0, 0, s, s); return (GLOW = c);
}
function dessinerCulbute(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const A = atlas(), G = glow(), c = e.c, s0 = c.s || 1;
  st = run ? (st || {}) : {};
  const held = run && st.h && b;
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, q = culPos(c, t);
  /* bascule permanente (attente active) ; pendant la culbute : l'axe suit la bille, raccord sans à-coup */
  if (e.ang7 == null) e.ang7 = (c.ph || 0) * 1.7;
  if (held) { const a = culAng(c, st, fr); if (e.off7 == null || e.in7 !== st.in) { e.in7 = st.in; e.off7 = e.ang7 - a; e.off7 -= Math.round(e.off7 / (Math.PI * 2)) * Math.PI * 2; }
    const tgt = a + e.off7 * Math.max(0, 1 - (fr - st.in) / 20); e.ang7 += (tgt - e.ang7) * Math.min(1, dt * 9); }
  else { e.off7 = null; e.ang7 += dt * (c.spin || .32) * (1 + .35 * Math.sin(T * .23 + (c.ph || 0))); }
  e.ph7 = ((e.ph7 || 0) + dt * (held ? 1.1 : .55)) % 1;           // onde du corps (≈ 2 s au repos)
  const roll = .78 + .22 * Math.cos(T * .41 + (c.ph || 0)), fi = Math.floor(e.ph7 * NA) % NA;
  const near = b && run ? Math.max(0, 1 - Math.hypot(b.x - q[0], b.y - q[1]) / 120) : 0, lum = held ? 1 : .35 + .4 * near;
  e.lum7 = (e.lum7 == null ? lum : e.lum7 + (lum - e.lum7) * Math.min(1, dt * 4));
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const gs = (70 + 26 * e.lum7) * s0; ctx.globalAlpha = .45 + .4 * e.lum7; ctx.drawImage(G, q[0] - gs / 2, q[1] - gs / 2, gs, gs);
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.translate(q[0], q[1]); ctx.rotate(e.ang7); ctx.scale(s0, s0 * roll);
  ctx.drawImage(A, fi * AW * DPR, 0, AW * DPR, AH * DPR, -AW / 2, -AH / 2, AW, AH);
  ctx.restore();
  if (held) {   // la bille tenue au bout de l'axe : petite lueur partagée
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .55; ctx.drawImage(G, b.x - 14, b.y - 14, 28, 28); ctx.restore();
  }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).culbute = dessinerCulbute;
racine.QXE7A = { culbute: dessinerCulbute, atlas };
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 7A FIN ===== */
