/* ===== ETAGE 6 DEBUT ===== R485 · Monde 6 (Mécanique) — étage 6 des créatures actives
   Fichier propre à l'étage 6 (aucune ligne des créatures existantes n'est touchée) :
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos (chargé juste après fluides.js). Pour tout niveau sans créature de l'étage 6,
     l'enveloppe appelle l'original et s'arrête là : trajectoires strictement inchangées.
   · RENDU : window.QXE6.dessiner(...) appelé par qxcrea.js (dessinerAct) pour les types 'coque' et 'amphi'.
   Tout ce qui agit sur la bille est fonction de S.frames et de la bille (jamais du hasard ni de l'horloge) : solutions et rejeux exacts.

   coque (ANÉMONE-FLEUR, vidéo V5) : un pied lisse ancré en (x,y), long de L, incliné de a0 (degrés, -90 = vers le haut), qui ondule
          (sw radians, pulsation w, phase ph — la colonie ondule en phase propagée). Au bout, le disque à franges.
          Quand la bille approche (rayon att), la tige se penche VERS elle (disque déplacé de bm px au plus).
          Au contact du disque (rayon r) le disque se replie en COQUE (cœur) sur la bille ; la colonne S'ALLONGE (de L à L2, piston vivant)
          et porte la bille jusqu'au prochain TEMPS de la colonie (battement toutes les per images, décalage off ; au moins hmin images
          de prise) ; alors la coque se rouvre en entonnoir et la relâche doucement, vitesse v dans la direction ra (degrés ; par défaut
          l'axe de la tige). Pause cd ; la colonne se rétracte.
          Effet neuf : un PISTON-ÉCHAPPEMENT vivant — il élève la bille (ce qu'aucun trait ne fait) et la rend au temps de la colonie,
          quel que soit le moment où elle est arrivée.
   amphi (AMPHIPODE, vidéo V6) : il nage en aller-retour sur sa route (x ± ax, y), près du fond. Quand la bille approche (rayon att),
          il nage à sa rencontre (décalage om px au plus) et glisse SOUS elle. Au contact de son dos (rayon r) il la porte dans son arc :
          la pesanteur ne compte plus, la bille file TOUT DROIT, à l'horizontale, dans le sens où elle allait, à sa propre vitesse
          (bornée vmin..vmax ; presque arrêtée : dans le sens sens, ou son propre cap), sur dist px — puis il la lâche avec cette vitesse (elle retombe en parabole). Bloquée par un mur : lâchée.
          Effet neuf : un PONT VIVANT (rail) — il prolonge la course du joueur par-dessus le vide, sans la changer de sens. */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e6) return;
F.e6 = 1;
const oForce = F.crForce, oPos = F.crPos, MIENS = { coque: 1, amphi: 1 }, CACHE = new WeakMap();
const D2R = Math.PI / 180;
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => MIENS[c.t]); CACHE.set(cr, v); } return v; }   // clé = le tableau lv.cr (les bancs le remplacent)
function segD(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let u = l > 1e-9 ? ((px - ax) * dx + (py - ay) * dy) / l : 0; u = u < 0 ? 0 : u > 1 ? 1 : u;
  const x = ax + dx * u - px, y = ay + dy * u - py; return Math.sqrt(x * x + y * y); }
const tri = u => Math.asin(.985 * Math.sin(u)) / 1.3967;
/* ── anémone : angle de la tige, sommet (disque) ── */
function coqueAng(e, t) { return (e.a0 == null ? -90 : e.a0) * D2R + (e.sw == null ? .12 : e.sw) * Math.sin(t * (e.w || .03) + (e.ph || 0)); }
function coqueBase(e, t) { const a = coqueAng(e, t), L = e.L || 70; return [e.x + L * Math.cos(a), e.y + L * Math.sin(a)]; }
function coqueRel(e, t0) {   // premier temps de la colonie après au moins hmin images de prise
  const per = e.per || 90, off = e.off || 0, t1 = t0 + (e.hmin || 30); return t1 + ((per - ((t1 + off) % per)) % per);
}
function coqueExt(e, t, st) {   // allongement de la colonne (0..1) : monte pendant la prise, se rétracte après la relâche
  if (!st) return 0;
  if (st.h) { const t0 = e.xr ? Math.max(st.in + 3, st.rel - e.xr) : st.in + 3, a = Math.min(1, Math.max(0, (t - t0) / Math.max(8, st.rel - t0 - 3))); return a * a * (3 - 2 * a); }   // xr : la colonne ne monte que dans les xr dernières images (attend que la voie soit libre)
  if (st.out != null && t >= st.out && t - st.out < 50) { const a = 1 - (t - st.out) / 50; return a * a * (3 - 2 * a); }
  return 0;
}
function coquePli(e, t, st) {   // affaissement de la tige à la prise (0 → 1 → 0 en 14 images) : elle encaisse l'élan
  if (!st || !st.h) return 0; const k = (t - st.in) / 14; return k >= 1 ? 0 : Math.sin(Math.PI * k);
}
function coqueTete(e, t, st) {
  const a = coqueAng(e, t), L = (e.L || 70) + ((e.L2 || e.L || 70) - (e.L || 70)) * coqueExt(e, t, st);
  let x = e.x + L * Math.cos(a) + (st && st.ox || 0), y = e.y + L * Math.sin(a) + (st && st.oy || 0);
  if (st && st.h) { const k = coquePli(e, t, st), bm = Math.min(e.pm || 10, (st.vin || 0) * 2); x += st.ux * bm * k; y += st.uy * bm * k; }
  return [x, y];
}
/* ── amphipode : route, cap ── */
function amphiRoute(e, t) { const u = t * (e.w || .012) + (e.ph || 0); return [e.x + (e.ax || 0) * tri(u), e.y + (e.ay || 0) * tri(u) + 2 * Math.sin(u * 3.1)]; }
function amphiCap(e, t) { const u = t * (e.w || .012) + (e.ph || 0); return (e.ax || 0) * Math.cos(u) >= 0 ? 1 : -1; }
function amphiCorps(e, t, st, b) {   // position du corps (centre) : sur sa route + rencontre ; pendant le portage, sous la bille
  if (st && st.h && b) {   // R496 : pendant le jet, le corps reste dans son couloir (la particule vole au-dessus de lui)
    if (st.tq && st.ya != null && t < st.in + st.tnf) { const s = Math.min(1, Math.max(0, (t - st.in - st.t0) / (st.t1 - st.t0))); return [b.x, st.ya + (st.y0 - st.ya) * s + (e.lift || 12)]; }
    return [b.x, b.y + (e.lift || 12)]; }
  const p = amphiRoute(e, t); return [p[0] + (st && st.eox || 0), p[1] + (st && st.eoy || 0)];
}
F.crPos = function (e, t) { if (e.t === 'coque') return coqueBase(e, t); if (e.t === 'amphi') return amphiRoute(e, t); return oPos(e, t); };
F.e6Rel = coqueRel; F.e6Ext = coqueExt; F.e6Tete = coqueTete; F.e6Ang = coqueAng; F.e6Pli = coquePli; F.e6Corps = amphiCorps; F.e6Cap = amphiCap; F.e6Route = amphiRoute;

F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  let ax = b.cpx == null ? b.x : b.cpx, ay = b.cpy == null ? b.y : b.cpy;
  oForce(b, sub, lv, g);                                // les autres créatures du niveau + remise à zéro (frames<=1) + cpx
  if ((ax - b.x) * (ax - b.x) + (ay - b.y) * (ay - b.y) > 900) { ax = b.x; ay = b.y; }
  const t = S.frames, cs = b.cs || (b.cs = {}), gg = (g == null ? .4 : g) * S.gmul, cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (!MIENS[e.t]) continue;
    const st = cs[i] || (cs[i] = { h: 0, cd: 0, sp: 0 });
    if (e.t === 'coque') forceCoque(b, sub, e, st, t, gg, ax, ay);
    else forceAmphi(b, sub, e, st, t, gg, ax, ay);
  }
  b.cpx = b.x; b.cpy = b.y;
};
function forceCoque(b, sub, e, st, t, gg, ax, ay) {
  if (st.af !== t) {                                    // une fois par image : la tige se penche vers la bille qui approche
    st.af = t;
    const p = coqueBase(e, t); let tx = 0, ty = 0;
    if (!st.h && t >= st.cd) { const dx = b.x - p[0], dy = b.y - p[1], dd = Math.hypot(dx, dy);
      if (dd <= (e.att || 0)) { const m = e.bm || 18; tx = dd > m ? dx * m / dd : dx; ty = dd > m ? dy * m / dd : dy; } }
    const k = (tx || ty) ? (e.ka || .14) : .05; st.ox = (st.ox || 0) + (tx - (st.ox || 0)) * k; st.oy = (st.oy || 0) + (ty - (st.oy || 0)) * k;
  }
  if (st.h) {
    const q = coqueTete(e, t, st);
    if (t >= st.rel) {                                  // le temps de la colonie : la coque se rouvre et la relâche
      const p0 = [e.x, e.y], ux = q[0] - p0[0], uy = q[1] - p0[1], ul = Math.hypot(ux, uy) || 1;
      let dx = ux / ul, dy = uy / ul; if (e.ra != null) { dx = Math.cos(e.ra * D2R); dy = Math.sin(e.ra * D2R); }
      const v = e.v == null ? 1.2 : e.v;
      b.x = q[0]; b.y = q[1]; b.vx = dx * v; b.vy = dy * v;
      st.h = 0; st.out = t; st.cd = t + (e.cd || 60); st.ox = 0; st.oy = 0; st.dx = dx; st.dy = dy;
      if (racine.BUS) racine.BUS.emit('creature.spit', { x: b.x, y: b.y });
    } else { b.x = q[0]; b.y = q[1]; b.vx = 0; b.vy = -gg / sub; }
  } else if (t >= st.cd) {
    const q = coqueTete(e, t, st);
    if (segD(q[0], q[1], ax, ay, b.x, b.y) < (e.r || 20)) {
      const v = Math.hypot(b.vx, b.vy); st.h = 1; st.in = t; st.rel = coqueRel(e, t); st.vin = v; st.ux = v > .01 ? b.vx / v : 0; st.uy = v > .01 ? b.vy / v : 1;
      const q2 = coqueTete(e, t, st); b.x = q2[0]; b.y = q2[1]; b.vx = 0; b.vy = -gg / sub;
      if (racine.BUS) racine.BUS.emit('creature.catch', { x: b.x, y: b.y });
    }
  }
}
/* R496 · DEMI-TOUR EN PORTAGE = JET. Quand il doit se retourner pour porter la particule (sens de portage ≠ son cap), il la JETTE :
   elle décolle quand le corps commence sa demi-boucle sous elle (p = .06), passe son apogée (jet px au-dessus du dos) pendant la
   rotation de 180°, et retombe sur le dos retourné (p = .9), en avançant dans le nouveau sens (kx × vitesse de portage) ;
   le portage reprend alors à pleine vitesse (au moins apres px avant de la lâcher). Durée du demi-tour : tq images (1 s) — le rendu
   lit la même horloge (S.frames) : jet et rotation sont synchrones. Sans demi-tour : portage inchangé. */
function amphiJetY(st, tau) { const s = (tau - st.t0) / (st.t1 - st.t0); return st.ya + (st.y0 - st.ya) * s - st.H * 4 * s * (1 - s); }
function forceAmphi(b, sub, e, st, t, gg, ax, ay) {
  const lift = e.lift || 12;
  if (st.af !== t) {
    st.af = t;
    if (st.h) {                                         // portage : contrôle une fois par image (distance parcourue, blocage)
      const vol = st.tq && st.ks / sub < st.t1, kx = vol ? (e.kx == null ? .2 : e.kx) : 1;
      st.stk = Math.abs(b.x - st.lx) < (vol ? .5 * kx * st.spd : .25) ? (st.stk || 0) + 1 : 0; st.lx = b.x;
      const ecart = vol && st.ya != null && Math.abs(b.y - st.ye) > 6;   // le jet heurte quelque chose : il la lâche telle quelle
      const fin = vol ? (ecart || st.stk >= 4) : (Math.abs(b.x - st.sx) >= (e.dist || 120) && (!st.tq || Math.abs(b.x - st.ld) >= (e.apres || 24))) || st.stk >= 4 || t - st.in > (e.dur || 400);
      if (fin) {
        if (!ecart) { b.vx = st.dir * st.spd * kx * (st.stk >= 4 ? 0 : 1); b.vy = 0; }
        st.h = 0; st.out = t; st.cd = t + (e.cd || 90);
        const r0 = amphiRoute(e, t); st.eox = b.x - r0[0]; st.eoy = (vol && st.ya != null ? st.y0 : b.y) + lift - r0[1];
        if (racine.BUS) racine.BUS.emit('creature.spit', { x: b.x, y: b.y });
        return;
      }
    } else {                                            // il nage à la rencontre de la bille qui approche
      const r0 = amphiRoute(e, t); let tx = 0, ty = 0;
      if (t >= st.cd) { const dx = b.x - r0[0], dy = b.y + lift - r0[1], dd = Math.hypot(dx - (st.eox || 0), dy - (st.eoy || 0));
        if (dd <= (e.att || 0)) { const m = e.om || 24, l = Math.hypot(dx, dy); tx = l > m ? dx * m / l : dx; ty = l > m ? dy * m / l : dy; } }
      const k = (tx || ty) ? (e.ka || .14) : .05; st.eox = (st.eox || 0) + (tx - (st.eox || 0)) * k; st.eoy = (st.eoy || 0) + (ty - (st.eoy || 0)) * k;
    }
  }
  if (st.h) {
    if (st.tq) {
      st.ks++; const tau = st.ks / sub;
      if (tau < st.t1) {                                // demi-tour : posée puis jetée, elle avance lentement dans le nouveau sens
        b.vx = st.dir * st.spd * (e.kx == null ? .2 : e.kx);
        if (tau <= st.t0) { b.vy = (st.y0 - b.y) * .12 - gg / sub; return; }
        if (st.ya == null) st.ya = b.y;
        st.ye = amphiJetY(st, tau); b.vy = (st.ye - b.y) * sub - gg / sub; return;
      }
      if (st.ld == null) { st.ld = b.x; b.y = st.y0; }  // réception sur le dos retourné
    }
    b.vx = st.dir * st.spd; b.vy = (st.y0 - b.y) * .12 - gg / sub; return;
  }
  if (t < st.cd) return;
  const c = amphiCorps(e, t, st, null), qx = c[0], qy = c[1] - lift;
  if (segD(qx, qy, ax, ay, b.x, b.y) < (e.r || 18)) {
    const v = Math.hypot(b.vx, b.vy); st.h = 1; st.in = t; st.vin = v; st.stk = 0; st.lx = b.x; st.sx = b.x;
    st.dir = Math.abs(b.vx) > (e.vs || .35) ? (b.vx > 0 ? 1 : -1) : (e.sens || amphiCap(e, t));
    st.spd = Math.min(e.vmax || 6, Math.max(e.vmin || 2.5, Math.abs(b.vx) * (e.m || 1)));
    st.y0 = Math.min(b.y, qy) - (e.up || 3);
    st.tq = e.jet === 0 || st.dir === amphiCap(e, t) ? 0 : 1; st.ks = 0; st.ya = null; st.ld = null;   // R496 : demi-tour nécessaire → jet
    if (st.tq) { st.tnf = e.tq || 60; st.t0 = .06 * st.tnf; st.t1 = .9 * st.tnf; st.H = e.jet || 24; }
    if (racine.BUS) racine.BUS.emit('creature.catch', { x: b.x, y: b.y });
  }
}
})(window);

/* ── RENDU R490 (appelé par qxcrea.js, couche des créatures actives) ── REPASSE GRAPHIQUE
   Même silhouette, mêmes proportions, même mouvement et même jeu qu'en R488 ; le dessin reprend le langage des figurants (banc v5) :
   membranes translucides en plusieurs couches (halo flou + liseré fin + membrane intérieure), dégradés cachés, nervures doublées,
   viscères et perles bioluminescentes vues par transparence, poils fins doublés (flou + net), points de lumière aux extrémités.
   PERF : le raffinement vient du CACHE —
   · AMPHIPODE : atlas de 32 images clés d'un cycle complet de nage (corps en arc, plaques, pattes en lamelles, pléopodes frangés,
     éventail caudal, viscères), pré-rendu à la demande (une image clé au plus par appel), deux résolutions (porteur / banc).
     En direct : antennes (deux passes + perles + pointes lumineuses), pulsation qui court le long du tube digestif, bulles.
   · ANÉMONE : disque/coque pré-rendu pour 17 degrés de fermeture (dégradé, membrane double, sillons, disque oral, pli, voile).
     En direct : tige en ruban à plusieurs couches (halo, chair, cœur lumineux, fibres, velours), couronne de tentacules en deux
     rangs (chemins groupés) et leurs pointes lumineuses, lueurs qui voyagent.
   Palette froide : bleu glacé, cyan, lilas, menthe, blanc. Rien n'agit sur la bille (rendu seul, aucun tirage du moteur). */
(function (racine) {
'use strict';
const TAU = Math.PI * 2;
const COL = {
  coque: { c1: [140, 196, 255], c2: [234, 244, 255], c3: [8, 20, 54], ac: [198, 172, 255], a2: [140, 255, 214] },
  amphi: { c1: [172, 226, 255], c2: [242, 250, 255], c3: [8, 24, 48], ac: [150, 255, 222], a2: [200, 180, 255] }
};
const rgb = c => 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
const rgba = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
const cl = v => v < 0 ? 0 : v > 1 ? 1 : v, lerp = (a, b, k) => a + (b - a) * k, ss = v => { v = cl(v); return v * v * (3 - 2 * v); };
const hs = n => { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };
function toile(w, h) { const k = document.createElement('canvas'); k.width = Math.max(2, Math.ceil(w)); k.height = Math.max(2, Math.ceil(h)); return k; }
function teintes(e, H, t) {
  if (e.e6 === 2) return; const C = COL[t]; e.e6 = 2;
  e.K1 = rgb(C.c1); e.K2 = rgb(C.c2); e.K3 = rgb(C.c3); e.KA = rgb(C.ac); e.KB = rgb(C.a2);
  e.SG = H.sprite('e6' + t, C.c1, 'g'); e.SP = H.sprite('e6' + t, C.c1, 'p'); e.SA = H.sprite('e6' + t + 'a', C.ac, 'p'); e.SB = H.sprite('e6' + t + 'b', C.a2, 'p'); e.SO = H.sprite('', C.c1, 'o');
  e.SW = H.sprite('e6' + t + 'w', C.c2, 'p');
}
/* petites bulles et poussière (déterministes en T, légères) */
function bulles(ctx, e, x, y, T, n, h, a) {
  ctx.beginPath();
  for (let i = 0; i < n; i++) { const u = ((T * (.18 + .05 * hs(i)) + hs(i * 3.1)) % 1), bx = x + (hs(i * 7.7) - .5) * 14 + Math.sin(T * 1.7 + i * 2) * 2.5 * u, by = y - u * h, r = .7 + 1.1 * hs(i * 5.3);
    ctx.moveTo(bx + r, by); ctx.arc(bx, by, r, 0, TAU); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = a; ctx.lineWidth = .6; ctx.stroke();
  for (let i = 0; i < 3; i++) { const u = ((T * .11 + hs(i * 9.3)) % 1), px = x + (hs(i * 4.1) - .5) * 26 + 3 * Math.sin(T * .8 + i), py = y - u * h * .8;   // poussière lumineuse
    ctx.globalAlpha = a * .8 * Math.sin(Math.PI * u); ctx.drawImage(e.SP, px - 1.6, py - 1.6, 3.2, 3.2); }
}
/* point lumineux pré-rendu (pour les atlas : cœur blanc + halo coloré) */
function point(g, im, x, y, R, a) { if (a <= .01) return; g.globalAlpha = a; g.drawImage(im, x - R, y - R, 2 * R, 2 * R); }
/* trois passes d'un même tracé : halo large, liseré moyen, fil fin (bord doux et lumineux, jamais un contour dur) */
function trois(g, c1, c2, w, a) {
  g.strokeStyle = c1; g.globalAlpha = .07 * a; g.lineWidth = 3.6 * w; g.stroke();
  g.strokeStyle = c2; g.globalAlpha = .15 * a; g.lineWidth = 1.4 * w; g.stroke();
  g.globalAlpha = .5 * a; g.lineWidth = .55 * w; g.stroke();
}

/* ═══ ANÉMONE-FLEUR ═══ */
const NS = 12, PX = new Float32Array(NS + 1), PY = new Float32Array(NS + 1), NX = new Float32Array(NS + 1), NY = new Float32Array(NS + 1);
function ruban(ctx, wd, fac) {
  ctx.beginPath();
  for (let pass = 0; pass < 2; pass++) for (let j = 0; j <= NS; j++) {
    const i = pass ? NS - j : j, w = wd(i / NS) * fac * (pass ? -1 : 1), qx = PX[i] + NX[i] * w, qy = PY[i] + NY[i] * w;
    j || pass ? ctx.lineTo(qx, qy) : ctx.moveTo(qx, qy);
  }
  ctx.closePath();
}
/* couches de la tige (halo, chair, bord diffus, cœur, fibres, velours, stries) : dessinées UNE fois, droites, dans une texture */
function couchesTige(ctx, K, wd, s, w0, thin, T, ph, AC, prin) {
  /* 1. halo doux autour de la tige (lumière diffuse dans l'eau) */
  ctx.globalCompositeOperation = 'lighter';
  if (prin) { ctx.beginPath(); ctx.moveTo(PX[0], PY[0]); for (let i = 1; i <= NS; i++) ctx.lineTo(PX[i], PY[i]);
    ctx.strokeStyle = K.K1; ctx.globalAlpha = .035 + .03 * AC; ctx.lineWidth = 3.4 * s * w0 * thin; ctx.stroke(); }
  /* 2. chair translucide : sombre (absorbe le décor) puis teinte froide */
  ruban(ctx, wd, 1);
  ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = K.K3; ctx.globalAlpha = .46; ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = K.K1; ctx.globalAlpha = .12; ctx.fill();
  /* bord diffus : halo large + liseré fin, faible (pas de contour net) */
  ctx.strokeStyle = K.K1; ctx.globalAlpha = .08; ctx.lineWidth = 2.6 * Math.max(.75, s); ctx.stroke();
  ctx.strokeStyle = K.K2; ctx.globalAlpha = .3; ctx.lineWidth = .55 * Math.max(.75, s); ctx.stroke();
  /* 3. cœur lumineux (velours épais) : un second ruban plus étroit, puis un troisième encore plus fin */
  ruban(ctx, wd, .52); ctx.fillStyle = K.K1; ctx.globalAlpha = .12 + .05 * AC; ctx.fill();
  if (prin) { ruban(ctx, wd, .2); ctx.fillStyle = K.K2; ctx.globalAlpha = .1 + .06 * AC; ctx.fill(); }
  /* 4. fibres longitudinales (nervures) + velours de cils courts sur les bords */
  if (prin) { ctx.beginPath();
  for (let k = -1; k <= 1; k += 2) { for (let i = 1; i < NS; i++) { const t = i / NS, w = wd(t) * .62 * k; i === 1 ? ctx.moveTo(PX[i] + NX[i] * w, PY[i] + NY[i] * w) : ctx.lineTo(PX[i] + NX[i] * w, PY[i] + NY[i] * w); } }
  ctx.strokeStyle = K.K2; ctx.globalAlpha = .13; ctx.lineWidth = .45; ctx.stroke(); }
  if (prin) { ctx.beginPath();
    for (let i = 1; i < NS; i++) for (let k = -1; k <= 1; k += 2) for (let m = 0; m < 1; m++) { const t = (i + m * .5 + .25 * hs(i * 3 + k)) / NS, i2 = Math.min(NS - 1, i + m), w = wd(t) * k * .92, sw = Math.sin(T * 2.6 - t * 10 + ph + k + m) * .8,
      bx = PX[i2] + NX[i2] * w, by = PY[i2] + NY[i2] * w, ln = 1 + 1.6 * hs(i * 7.1 + m + k), dx = PX[i2 + 1] - PX[i2], dy = PY[i2 + 1] - PY[i2], dl = Math.hypot(dx, dy) || 1;
      ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + NX[i2] * k * ln * .6, by + NY[i2] * k * ln * .6, bx + NX[i2] * k * ln + dx / dl * ln * (.8 + sw), by + NY[i2] * k * ln + dy / dl * ln * (.8 + sw)); }
    ctx.strokeStyle = K.K2; ctx.globalAlpha = .06; ctx.lineWidth = .3; ctx.stroke(); }
  /* anneaux de croissance : stries transversales très pâles */
  if (prin) { ctx.beginPath(); for (let i = 2; i < NS - 1; i++) { const w = wd(i / NS) * .85; ctx.moveTo(PX[i] + NX[i] * w, PY[i] + NY[i] * w); ctx.quadraticCurveTo(PX[i] + (PX[i + 1] - PX[i]) * .3, PY[i] + (PY[i + 1] - PY[i]) * .3, PX[i] - NX[i] * w, PY[i] - NY[i] * w); }
  ctx.strokeStyle = K.K2; ctx.globalAlpha = .07; ctx.lineWidth = .5; ctx.stroke(); }
  ctx.globalCompositeOperation = 'source-over';
}
const TLT = 170, TW0 = 3.4, TPX = 2.6, THW = 6.2;   // texture : tige droite de 170 unités, largeur de base 3,4, demi-largeur utile 13
let TEX = null;
function texTige() {
  if (TEX) return TEX;
  const C = COL.coque, K = { K1: rgb(C.c1), K2: rgb(C.c2), K3: rgb(C.c3), KA: rgb(C.ac) };
  const cv = toile(2 * THW * TPX, (TLT + 4) * TPX), g = cv.getContext('2d');
  g.setTransform(TPX, 0, 0, TPX, THW * TPX, 2 * TPX); g.lineCap = 'round'; g.lineJoin = 'round';
  for (let i = 0; i <= NS; i++) { PX[i] = 0; PY[i] = TLT * (1 - i / NS); NX[i] = 1; NY[i] = 0; }
  const wd = t => TW0 * (.68 + 1.1 * Math.pow(1 - t, 6) + .1 * Math.sin(t * 6.5) + .62 * ss((t - .8) / .2));
  couchesTige(g, K, wd, 1, TW0, 1, 0, 0, 0, true);
  const fm = g.createLinearGradient(-THW, 0, THW, 0);   // bords de la texture fondus : aucune arête de tranche visible
  fm.addColorStop(0, 'rgba(0,0,0,0)'); fm.addColorStop(.16, 'rgba(0,0,0,1)'); fm.addColorStop(.84, 'rgba(0,0,0,1)'); fm.addColorStop(1, 'rgba(0,0,0,0)');
  g.globalCompositeOperation = 'destination-in'; g.globalAlpha = 1; g.fillStyle = fm; g.fillRect(-THW, -2, 2 * THW, TLT + 4); g.globalCompositeOperation = 'source-over';
  return (TEX = cv);
}
function tige(ctx, e, fx, fy, a0, hx, hy, w0, s, T, ph, onde, AC) {   // ruban à plusieurs couches du pied au disque ; renvoie l'angle de sortie
  const L = Math.hypot(hx - fx, hy - fy) || 1, a = Math.atan2(hy - fy, hx - fx);
  const al = a0 + .45 * (a - a0) + .05 * Math.sin(T * .9 + ph), ah = a + .35 * (a - a0) + .06 * Math.sin(T * .9 + ph - 1.3);   // retard : le bas suit moins
  const sS = L * .07 * Math.sin(T * .7 + ph), c1x = fx + Math.cos(al) * L * .42 - Math.sin(al) * sS, c1y = fy + Math.sin(al) * L * .42 + Math.cos(al) * sS, c2x = hx - Math.cos(ah) * L * .34 + Math.sin(ah) * sS, c2y = hy - Math.sin(ah) * L * .34 - Math.cos(ah) * sS;   // légère S qui respire
  for (let i = 0; i <= NS; i++) { const t = i / NS, u = 1 - t;
    PX[i] = u * u * u * fx + 3 * u * u * t * c1x + 3 * u * t * t * c2x + t * t * t * hx; PY[i] = u * u * u * fy + 3 * u * u * t * c1y + 3 * u * t * t * c2y + t * t * t * hy; }
  for (let i = 0; i <= NS; i++) { const i0 = Math.max(0, i - 1), i1 = Math.min(NS, i + 1), tx = PX[i1] - PX[i0], ty = PY[i1] - PY[i0], tl = Math.hypot(tx, ty) || 1; NX[i] = -ty / tl; NY[i] = tx / tl; }
  const thin = Math.sqrt(Math.min(1.4, (e.L0 || L) / L));
  const wd = t => s * w0 * thin * (.68 + 1.1 * Math.pow(1 - t, 6) + .1 * Math.sin(t * 6.5 + ph) + .62 * ss((t - .8) / .2) + .07 * Math.sin(T * 2.2 - t * 9 + ph));   // pied évasé (ventouse), col fin, évasement sous le disque
  /* 1-4. couches pré-rendues (texture droite) posées tranche par tranche le long de la courbe : un seul passage de pixels */
  const prin = s > .8, TX = texTige(), kx = s * w0 * thin / TW0, sh = TX.height / (TLT + 4);
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = prin ? 1 : .9;
  const M = ctx.getTransform(), st2 = prin ? 2 : 3;   // tranches : 6 pour la principale, 4 pour la colonie (courbure douce : raccords invisibles)
  for (let i = 0; i < NS; i += st2) {
    const dx = PX[i + st2] - PX[i], dy = PY[i + st2] - PY[i], dl = Math.hypot(dx, dy) || 1e-3, y0 = (2 + TLT * (1 - (i + st2) / NS)) * sh, hgt = TLT * st2 / NS * sh;
    const cs = -dy / dl, sn = dx / dl;   // repère de la tranche = repère courant × translation × rotation (sans save/restore)
    ctx.setTransform(M.a * cs + M.c * sn, M.b * cs + M.d * sn, M.c * cs - M.a * sn, M.d * cs - M.b * sn, M.a * PX[i] + M.c * PY[i] + M.e, M.b * PX[i] + M.d * PY[i] + M.f);
    ctx.drawImage(TX, 0, y0, TX.width, hgt, -THW * kx, -dl - .25, 2 * THW * kx, dl + .5);
  }
  ctx.setTransform(M);
  ctx.globalCompositeOperation = 'lighter';

  /* 5. moelle (canal lumineux) + perles internes qui montent lentement + la pulsation de la colonie */
  ctx.beginPath(); ctx.moveTo(PX[1], PY[1]); for (let i = 2; i < NS; i++) ctx.lineTo(PX[i], PY[i]);
  if (prin) { ctx.strokeStyle = e.KA; ctx.globalAlpha = .1; ctx.lineWidth = 2.6 * s; ctx.stroke(); }
  ctx.strokeStyle = e.KA; ctx.globalAlpha = .26 + .3 * AC; ctx.lineWidth = .8 * s; ctx.stroke();   // la prise rallume la moelle
  const nb = prin ? 2 : 1;
  for (let j = 0; j < nb; j++) { const u = ((T * .09 + j / nb + ph * .1) % 1), f = u * NS, i = Math.min(NS - 1, f | 0), r = f - i, x = PX[i] + (PX[i + 1] - PX[i]) * r, y = PY[i] + (PY[i + 1] - PY[i]) * r;
    ctx.globalAlpha = (.35 + .2 * AC) * Math.sin(Math.PI * u); ctx.drawImage(e.SA, x - 2.4 * s, y - 2.4 * s, 4.8 * s, 4.8 * s); }
  if (onde) { const u = onde % 1, f = Math.min(NS - .01, u * NS), i = f | 0, r = f - i, x = PX[i] + (PX[i + 1] - PX[i]) * r, y = PY[i] + (PY[i + 1] - PY[i]) * r;
    ctx.globalAlpha = .9; ctx.drawImage(e.SB, x - 6 * s, y - 6 * s, 12 * s, 12 * s); if (prin) { ctx.globalAlpha = .25; ctx.drawImage(e.SB, x - 13 * s, y - 13 * s, 26 * s, 26 * s); } }
  /* 6. ventouse : petit disque basal lumineux */
  if (prin) { ctx.globalAlpha = .3; ctx.drawImage(e.SP, fx - 5 * s, fy - 3 * s, 10 * s, 6 * s); }
  ctx.globalCompositeOperation = 'source-over';
  return Math.atan2(hy - c2y, hx - c2x);
}
/* géométrie du disque (k : fermeture 0 entonnoir → 1 cœur ; f : évasement), repère local (le disque pointe vers -y) */
const DG = { P1x: 0, P1y: 0, My: 0, A1x: 0, A1y: 0, A2x: 0, A2y: 0, Qx: 0, Qy: 0 };
function geoDisque(R, k, f) {
  DG.P1x = lerp(-R, -.3 * R, k); DG.P1y = lerp(-3 - 3 * f, -1.12 * R, k); DG.My = lerp(-7.5 - 5 * f, -.74 * R, k);
  DG.A1x = lerp(-.55 * R, -1.05 * R, k); DG.A1y = lerp(2.5, -.05 * R, k); DG.A2x = lerp(-1.05 * R, -1.02 * R, k); DG.A2y = lerp(-.5, -1.25 * R, k); DG.Qx = lerp(-.58 * R, -.12 * R, k); DG.Qy = lerp(-7 - 5 * f, -1.2 * R, k);
}
function cheminDisque(g, sc, cy) {   // sc : membrane intérieure (homothétie vers cy)
  const D = DG, Y = v => cy + (v - cy) * sc;
  g.beginPath(); g.moveTo(0, Y(2.5)); g.bezierCurveTo(D.A1x * sc, Y(D.A1y), D.A2x * sc, Y(D.A2y), D.P1x * sc, Y(D.P1y)); g.quadraticCurveTo(D.Qx * sc, Y(D.Qy), 0, Y(D.My));
  g.quadraticCurveTo(-D.Qx * sc, Y(D.Qy), -D.P1x * sc, Y(D.P1y)); g.bezierCurveTo(-D.A2x * sc, Y(D.A2y), -D.A1x * sc, Y(D.A1y), 0, Y(2.5)); g.closePath();
}
/* atlas du disque : 17 degrés de fermeture, rayon de base 19, f = 0 */
const DNK = 16, DR = 19, DBX = -27, DBY = -31, DBW = 54, DBH = 41, DPX = 3.4;
let DAT = null;
function disqueCle(k, C) {
  const cv = toile(DBW * DPX, DBH * DPX), g = cv.getContext('2d'), R = DR;
  g.setTransform(DPX, 0, 0, DPX, -DBX * DPX, -DBY * DPX); g.lineCap = 'round'; g.lineJoin = 'round';
  geoDisque(R, k, 0); const D = DG, cy = lerp(-2, -.55 * R, k);
  /* chair : sombre translucide avec halo flou (ombre portée lumineuse, pré-rendue) */
  cheminDisque(g, 1, cy); g.save(); g.shadowColor = rgba(C.c1, .55); g.shadowBlur = 7 * DPX; g.fillStyle = rgba(C.c3, .5); g.fill(); g.restore();
  /* volume : dégradé radial décentré (reflet), en « lighter » */
  g.globalCompositeOperation = 'lighter';
  const gr = g.createRadialGradient(-.2 * R, cy - .25 * R * (1 - .5 * k) - 2, 0, 0, cy, 1.15 * R);
  gr.addColorStop(0, rgba(C.c2, .32)); gr.addColorStop(.35, rgba(C.c1, .2)); gr.addColorStop(.8, rgba(C.c1, .07)); gr.addColorStop(1, rgba(C.c1, .12));
  cheminDisque(g, 1, cy); g.fillStyle = gr; g.fill();
  g.save(); cheminDisque(g, 1, cy); g.clip();
  /* granulations internes (zooxanthelles froides) */
  for (let i = 0; i < 26; i++) { const x = (hs(i * 3.7) - .5) * 1.7 * R * lerp(1, .7, k), y = cy + (hs(i * 5.9) - .5) * lerp(9, 1.2 * R, k), r = .35 + .5 * hs(i * 1.3);
    g.beginPath(); g.arc(x, y, r, 0, TAU); g.fillStyle = rgba(i % 3 ? C.c2 : C.ac, .16 + .14 * hs(i)); g.fill(); }
  /* sillons rayonnants (nervures) : deux passes (flou + net) */
  g.beginPath();
  for (let j = 0; j < 11; j++) { const u = (j + .5) / 11, x2 = lerp(D.P1x, -D.P1x, u), y2 = lerp(lerp(-4, D.My * .9, k), lerp(-4, D.P1y * .9, k), Math.abs(u - .5) * 2);
    g.moveTo(lerp(0, x2 * .15, k), lerp(1, -.15 * R, k)); g.quadraticCurveTo(x2 * .6, lerp(y2 * .45, y2 * .7, k), x2, y2); }
  g.strokeStyle = rgba(C.ac, 1); g.globalAlpha = .08; g.lineWidth = 2; g.stroke(); g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .26; g.lineWidth = .4; g.stroke();
  g.restore();
  /* disque oral (ouvert) : coupelle lilas à anneau, bouche en fente */
  if (k < .7) { const o = 1 - k / .7, ey = -4.6;
    const go = g.createRadialGradient(0, ey, 0, 0, ey, R * .62); go.addColorStop(0, rgba(C.ac, .42 * o)); go.addColorStop(.6, rgba(C.ac, .14 * o)); go.addColorStop(1, rgba(C.ac, 0));
    g.globalAlpha = 1; g.beginPath(); g.ellipse(0, ey, R * .62 * (1 - .6 * k), 3 * (1 - .6 * k), 0, 0, TAU); g.fillStyle = go; g.fill();
    g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .3 * o; g.lineWidth = .5; g.stroke();
    g.beginPath(); g.ellipse(0, ey, 2.4, .7, 0, 0, TAU); g.fillStyle = rgba(C.c2, .55 * o); g.fill(); }
  /* coque fermée : pli central (deux passes), voile translucide entre les lobes */
  if (k > .3) { const kk = ss((k - .3) / .7);
    g.beginPath(); g.moveTo(0, D.My + .5); g.bezierCurveTo(1.4, D.My + .3 * R, -1.2, -.35 * R, .3, -.08 * R);
    g.strokeStyle = rgba(C.c1, 1); g.globalAlpha = .12 * kk; g.lineWidth = 2.6; g.stroke(); g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .45 * kk; g.lineWidth = .5; g.stroke();
    g.beginPath(); g.moveTo(D.P1x * .8, D.P1y + 1); g.quadraticCurveTo(0, D.My - 4 * kk, -D.P1x * .8, D.P1y + 1); g.quadraticCurveTo(0, D.My + 1, D.P1x * .8, D.P1y + 1);
    g.fillStyle = rgba(C.c2, 1); g.globalAlpha = .1 * kk; g.fill(); g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .25 * kk; g.lineWidth = .4; g.stroke();
    for (let s2 = -1; s2 <= 1; s2 += 2) { g.beginPath(); g.ellipse(s2 * .5 * R * .62, -.62 * R, .28 * R, .34 * R, s2 * .3, 0, TAU);   // nervures des lobes
      g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .12 * kk; g.lineWidth = .45; g.stroke(); } }
  /* membrane intérieure + bord en trois passes */
  cheminDisque(g, .82, cy); g.strokeStyle = rgba(C.c2, 1); g.globalAlpha = .2; g.lineWidth = .45; g.stroke();
  cheminDisque(g, 1, cy); trois(g, rgba(C.c1, 1), rgba(C.c2, 1), 1, 1.1);
  /* photophores du bord : perles le long de la lèvre */
  const SPd = DAT.SP;
  for (let i = 0; i < 9; i++) { const u = (i + .5) / 9, x = lerp(D.P1x, -D.P1x, u), y = lerp(D.P1y, D.My, 1 - Math.abs(u - .5) * 2) - .6;
    point(g, SPd, x, y, 1.6, .55); }
  g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
  return cv;
}
function atlasDisque(C, H) {
  if (!DAT) { DAT = { C, SP: H.sprite('e6coqw', C.c2, 'p'), f: [], n: 0 }; }
  if (DAT.n <= DNK) { for (let k = 0; k < 2 && DAT.n <= DNK; k++, DAT.n++) if (!DAT.f[DAT.n]) DAT.f[DAT.n] = disqueCle(DAT.n / DNK, C); }   // pré-remplissage : deux degrés par image au début du niveau
  return DAT;
}
function disque(ctx, e, hx, hy, ang, R, k, f, ap, T, ph, q, bat, AC) {   // k : fermeture (0 entonnoir → 1 cœur) · f : évasement · ap : tentacules tendus
  ctx.save(); ctx.translate(hx, hy); ctx.rotate(ang + Math.PI / 2);
  geoDisque(R, k, f); const D = DG;
  /* couronne : deux rangs de tentacules fins (arrière : plus pâle et plus long ; avant : net), onde de phase le long du bord */
  const N = q ? 30 : 14, N2 = q ? 16 : 9, kt = 1 - .45 * k;
  for (let row = q ? 0 : 1; row < 2; row++) {
    const n = row ? N : N2; ctx.beginPath();
    const TX = e.tip || (e.tip = new Float32Array(64));
    for (let i = 0; i < n; i++) {
      const u = (i + (row ? 0 : .5)) / (n - (row ? 1 : 0)); let x, y, nx, ny;
      if (u < .5) { const t = u * 2, a = 1 - t; x = a * a * D.P1x + 2 * a * t * D.Qx + t * t * 0; y = a * a * D.P1y + 2 * a * t * D.Qy + t * t * D.My; nx = -(1 - t) * .9 - .1; ny = -1; }
      else { const t = (u - .5) * 2, a = 1 - t; x = a * a * 0 + 2 * a * t * -D.Qx + t * t * -D.P1x; y = a * a * D.My + 2 * a * t * D.Qy + t * t * D.P1y; nx = t * .9 + .1; ny = -1; }
      nx = lerp(nx * 1.15, nx * .35, k) * (row ? 1 : 1.25); const nl = Math.hypot(nx, ny); nx /= nl; ny /= nl;
      const L = (5.4 + 2.8 * hs(i * 2.3 + ph + row * 7) + 3.2 * ap) * (R / 17) * kt * (row ? 1 : 1.3), ph2 = T * 2.1 - u * 7.5 + ph + (row ? 0 : 1.1), sw = Math.sin(ph2) * (2.4 - k) + Math.sin(T * 3.3 + i) * .6, tx = -ny, ty = nx;
      const ex = x + nx * L + tx * sw, ey = y + ny * L + ty * sw;
      ctx.moveTo(x, y); ctx.bezierCurveTo(x + nx * L * .35 + tx * sw * .1, y + ny * L * .35 + ty * sw * .1, x + nx * L * .7 + tx * sw * .55, y + ny * L * .7 + ty * sw * .55, ex, ey);
      if (row) { TX[2 * i] = ex; TX[2 * i + 1] = ey; }
    }
    ctx.globalCompositeOperation = 'lighter';
    if (row && q) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .07 + .04 * AC; ctx.lineWidth = 1.7; ctx.stroke(); }   // halo des tentacules : rang avant de la principale
    ctx.strokeStyle = e.K2; ctx.globalAlpha = (row ? .5 : .24) + .2 * ap + .05 * AC; ctx.lineWidth = row ? (q ? .55 : .5) : .4; ctx.stroke();
  }
  /* calice : la tige s'évase et se fond dans le dessous du disque (une seule silhouette, aucun raccord visible) */
  { const wn = (q ? 3.2 : 2.4) * (R / 19), bx = lerp(D.A1x * .78, -.3 * R, k), by = lerp(D.A1y * .5 - .5, 1, k), nk = 9 * (R / 19);
    ctx.beginPath(); ctx.moveTo(-wn, nk); ctx.bezierCurveTo(-wn * 1.1, nk * .45, bx * .55, by + 2.2, bx, by); ctx.quadraticCurveTo(0, by + 3.6 - 2 * k, -bx, by);
    ctx.bezierCurveTo(-bx * .55, by + 2.2, wn * 1.1, nk * .45, wn, nk); ctx.closePath();
    ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = e.KC || (e.KC = 'rgb(44,68,120)'); ctx.globalAlpha = .5 + .1 * AC; ctx.fill();   // chair du calice (teinte pré-mélangée : un seul remplissage)
    ctx.globalCompositeOperation = 'lighter'; if (q) { ctx.strokeStyle = e.K1; ctx.globalAlpha = .06; ctx.lineWidth = 2.4; ctx.stroke(); }
    if (q) { ctx.beginPath(); for (let j = -2; j <= 2; j++) { ctx.moveTo(j * wn * .3, nk); ctx.quadraticCurveTo(j * wn * .35, by + 4, j * bx * -.3, by + 1); }   // fibres qui montent dans le disque
    ctx.strokeStyle = e.K2; ctx.globalAlpha = .12; ctx.lineWidth = .4; ctx.stroke(); } }
  /* corps du disque : image clé pré-rendue (17 degrés de fermeture) */
  const A = DAT, kf = cl(k) * DNK, ki = Math.min(DNK - 1, kf | 0), fr2 = kf - ki, im = A.f[ki] || (A.f[ki] = disqueCle(ki / DNK, A.C)), sc = R / DR, sy = sc * (1 + .07 * f * (1 - k));
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.drawImage(im, DBX * sc, DBY * sy, DBW * sc, DBH * sy);
  if (q && fr2 > .02) { const im2 = A.f[ki + 1] || (A.f[ki + 1] = disqueCle((ki + 1) / DNK, A.C)); ctx.globalAlpha = fr2; ctx.drawImage(im2, DBX * sc, DBY * sy, DBW * sc, DBH * sy); }   // fondu entre deux degrés : déformation continue
  if (q && bat > .05) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .3 * bat; ctx.drawImage(im, DBX * sc, DBY * sy, DBW * sc, DBH * sy); }   // le battement / la prise rallument la coque
  /* pointes lumineuses des tentacules (rang avant, une sur deux) + photophores en onde */
  ctx.globalCompositeOperation = 'lighter';
  const TX = e.tip, rT = q ? 1.1 : .8, st3 = q ? 2 : 3;   // pointes lumineuses : un seul chemin (halo + cœur), onde portée par l'alpha global
  for (let pass = 0; pass < 2; pass++) { ctx.beginPath(); const r = pass ? rT * .45 : rT;
    for (let i = 1; i < N; i += st3) { ctx.moveTo(TX[2 * i] + r, TX[2 * i + 1]); ctx.arc(TX[2 * i], TX[2 * i + 1], r, 0, TAU); }
    ctx.fillStyle = pass ? e.K2 : e.KB; ctx.globalAlpha = (pass ? .55 : .22) * (.7 + .3 * Math.sin(T * 2.4 + ph) + .3 * bat + .2 * AC) * (q ? 1 : .7); ctx.fill(); }
  if (q) for (let i = 0; i < 5; i++) { const u = (i + .5) / 5, x = lerp(D.P1x, -D.P1x, u), y = lerp(D.P1y, D.My, 1 - Math.abs(u - .5) * 2) - 4 * (R / 17), v = .5 + .5 * Math.sin(T * 2.4 - u * 6 + ph);
    ctx.globalAlpha = (.2 + .45 * v + .3 * bat) * (q ? 1 : .6); ctx.drawImage(e.SB, x - 3, y - 3, 6, 6); }
  ctx.restore();
}
function batKo(c, fr) { const per = c.per || 90, u = ((fr + (c.off || 0)) % per + per) % per; return u < 18 ? Math.sin(Math.PI * u / 18) : 0; }   // temps de la colonie (0..1)
function dessinerCoque(ctx, e, x, y, etat, st, b, T, dt, fr, run, H) {
  teintes(e, H, 'coque'); atlasDisque(COL.coque, H);
  const FL = racine.FLUID, c = e.c, s0 = c.s || 1, R = 19 * s0;
  st = run ? st : {};
  const hd = FL.e6Tete(c, fr, st), hx = hd[0], hy = hd[1];
  e.L0 = c.L || 70;
  /* fermeture : vite à la prise, réouverture en entonnoir après la relâche ; battement de colonie */
  let kc = 0, fun = 0;
  if (run && st.h) kc = ss((fr - st.in) / 6);
  else if (run && st.out != null && fr >= st.out && fr - st.out < 18) { kc = 1 - ss((fr - st.out) / 7); fun = Math.sin(Math.PI * (fr - st.out) / 18); }
  const bat = run ? batKo(c, fr) : .5 + .5 * Math.sin(T * 1.3);
  kc = Math.max(kc, .22 * bat * (st.h ? 0 : 1));
  e.kS = e.kS == null ? kc : e.kS + (kc - e.kS) * Math.min(1, dt * 14);
  const d = b ? Math.hypot(b.x - hx, b.y - hy) : 1e9, ap = cl(1 - (d - (c.r || 20)) / ((c.att || 60) + 30)) * (st.h ? 0 : 1);
  e.apS = (e.apS || 0) + (ap - (e.apS || 0)) * Math.min(1, dt * 5);
  const AC = run && st.h ? 1 : 0; e.acS = (e.acS || 0) + (AC - (e.acS || 0)) * Math.min(1, dt * (AC ? 10 : 2));
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* colonie : plus petites et plus pâles (profondeur), ondulent en phase propagée, se ferment à demi au temps (vague qui court d'un individu à l'autre) */
  const n = c.col || 0;
  for (let j = 0; j < n; j++) {
    const sg = j % 2 ? 1 : -1, dx = sg * (30 + 30 * Math.floor(j / 2) + 5 * hs(j + 1)), sc = .5 + .14 * hs(j * 3.3), ph = 1 + j * .9;
    const fx = c.x + dx, fy = c.y, L = (c.L || 70) * (.55 + .2 * hs(j * 5.1)), a = -Math.PI / 2 + (c.sw || .1) * 1.4 * Math.sin(T * .95 - ph * .8) + .08 * sg;
    const hx2 = fx + L * Math.cos(a), hy2 = fy + L * Math.sin(a), bj = run ? batKo(c, fr - 5 * (j + 1)) : .5 + .5 * Math.sin(T * 1.3 - j * .7);
    H.ombre(ctx, e, fx, fy - 2, 12 * sc, 5, 0, .4);
    if (bj > .05) H.spr(ctx, e.SG, hx2, hy2 - 3, 20 * sc, .18 * bj);   // la voisine ne s'allume qu'à son temps
    e.L0 = L; const an = tige(ctx, e, fx, fy, -Math.PI / 2, hx2, hy2, 2.6, sc, T, ph, (T * .3 + ph) % 2.2, 0);
    disque(ctx, e, hx2, hy2, an, R * sc, .45 * bj, 0, 0, T, ph, 0, bj, 0);
  }
  e.L0 = c.L || 70;
  H.ombre(ctx, e, c.x, c.y - 2, 18 * s0, 7, 0, .55);
  H.spr(ctx, e.SG, hx, hy - 4, 30 * s0 + 10 * e.acS, .12 + .16 * e.acS + .12 * bat);
  /* R488 : coque fermée glissée sous la particule (elle se loge dans l'échancrure du cœur, les lobes l'enserrent de part et d'autre) */
  const ul = Math.hypot(hx - c.x, hy - c.y) || 1, sh = 11 * s0 * e.kS, hx3 = hx - (hx - c.x) / ul * sh, hy3 = hy - (hy - c.y) / ul * sh;
  const ang = tige(ctx, e, c.x, c.y, (c.a0 == null ? -90 : c.a0) * Math.PI / 180, hx3, hy3, 3.4, s0, T, e.ph, (T * .35 + e.ph) % 1.6, e.acS);
  disque(ctx, e, hx3, hy3, ang, R * (1 + .08 * e.apS), e.kS, fun + .4 * e.apS, e.apS, T, e.ph, 1, bat, e.acS);
  bulles(ctx, e, hx, hy - 10, T, 5, 46, .35);
  if (e.acS > .02) { ctx.globalCompositeOperation = 'lighter';   // la coque garde la particule : lueur lilas qui respire + anneau doux
    H.spr(ctx, e.SB, hx, hy - R * .4, R * 1.1, (.2 + .1 * Math.sin(T * 6)) * e.acS); H.spr(ctx, e.SG, hx, hy - R * .3, R * 2.2, .1 * e.acS); }
  ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}

/* ═══ AMPHIPODE ═══ atlas d'images clés du cycle de nage (repère créature : tête vers +x, dos vers -y) */
const NK = 32, BX = -42, BY = -25, BW = 75, BH = 48;
const ATL = { g: null, p: null };   // g : porteur (3,2 px/unité) · p : banc (1,4 px/unité)
const cyA = (u, W) => -7.5 * (1 - (u / 22) * (u / 22)) + (.75 + .45 * (22 - u) / 44) * Math.sin(W + u * .16);   // R490 : la tête mène, l'onde court vers la queue et s'amplifie   // dos en arc, onde de nage (identique à R488)
const dthA = u => 8.8 * Math.sqrt(Math.max(0, 1 - ((u - 2) / 23.5) * ((u - 2) / 23.5))), vthA = u => 6 * Math.sqrt(Math.max(0, 1 - ((u - 1) / 22.5) * ((u - 1) / 22.5)));
function amphiCle(ph, C, pxu, fin) {
  const cv = toile(BW * pxu, BH * pxu), g = cv.getContext('2d');
  g.setTransform(pxu, 0, 0, pxu, -BX * pxu, -BY * pxu); g.lineCap = 'round'; g.lineJoin = 'round';
  const W = TAU * ph, om = TAU * 2 * ph, cy = u => cyA(u, W), top = u => cy(u) - dthA(u), bot = u => cy(u) + vthA(u), mid = u => (top(u) + bot(u)) / 2;
  const K1 = rgba(C.c1, 1), K2 = rgba(C.c2, 1), K3 = rgba(C.c3, 1), KA = rgba(C.ac, 1), KB = rgba(C.a2, 1);
  const SPW = DOT.w, SPA = DOT.a, SPB = DOT.b, U0 = -21, U1 = 22;
  /* contour : dos, tête arrondie, ventre ; sc < 1 : membrane intérieure (homothétie vers la ligne médiane) */
  function corps(sc) {
    g.beginPath();
    for (let i = 0; i <= 26; i++) { const u = U0 + (U1 - U0) * i / 26, m = mid(u), y = m + (top(u) - m) * sc; i ? g.lineTo(u, y) : g.moveTo(u, y); }
    const hm = mid(U1); g.bezierCurveTo(U1 + 2.2 * sc, hm + (top(U1) - hm) * sc, U1 + 3 * sc, hm + .4, U1 + 2 * sc, hm + (bot(U1) - hm) * sc + .3);
    for (let i = 26; i >= 0; i--) { const u = U0 + (U1 - U0) * i / 26, m = mid(u); g.lineTo(u, m + (bot(u) - m) * sc); }
    const rm = mid(U0); g.quadraticCurveTo(U0 - 1.6 * sc, rm, U0, rm + (top(U0) - rm) * sc); g.closePath();
  }
  /* une lamelle (patte / pléopode / uropode) : feuille effilée translucide, bord doux, soies au bout, pointe lumineuse */
  function lamelle(bx, by, an, L, w, bend, soies, a, pointe) {
    const ca = Math.cos(an), sa = Math.sin(an), tx = bx + ca * L, ty = by + sa * L, mx = bx + ca * L * .5 - sa * bend, my = by + sa * L * .5 + ca * bend;
    g.beginPath(); g.moveTo(bx - sa * w, by + ca * w); g.quadraticCurveTo(mx - sa * w * .9, my + ca * w * .9, tx, ty); g.quadraticCurveTo(mx + sa * w * .7, my - ca * w * .7, bx + sa * w, by - ca * w); g.closePath();
    g.fillStyle = K3; g.globalAlpha = .22 * a; g.fill();
    g.fillStyle = K1; g.globalAlpha = .1 * a; g.fill();
    g.globalCompositeOperation = 'lighter'; trois(g, K1, K2, .8, .5 * a);
    g.beginPath(); g.moveTo(bx, by); g.quadraticCurveTo(mx, my, tx, ty); g.strokeStyle = KA; g.globalAlpha = .22 * a; g.lineWidth = .35; g.stroke();   // nervure axiale
    if (soies && !fin) { g.beginPath();
      for (let s = 0; s < soies; s++) { const u = .45 + .55 * s / Math.max(1, soies - 1), px = bx + (tx - bx) * u + (mx - (bx + tx) / 2) * 4 * u * (1 - u), py = by + (ty - by) * u + (my - (by + ty) / 2) * 4 * u * (1 - u), ln = 1.6 + 2.2 * u, dr = -.9 - .5 * Math.sin(W + s);
        g.moveTo(px, py); g.quadraticCurveTo(px + sa * ln * .5 + ca * .4, py - ca * ln * .5 + sa * .4, px + sa * ln + ca * dr, py - ca * ln + sa * dr); }
      g.strokeStyle = K1; g.globalAlpha = .06 * a; g.lineWidth = 1.1; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .26 * a; g.lineWidth = .25; g.stroke(); }
    if (pointe) point(g, SPA, tx, ty, 1.3, .35 * a * pointe);
    g.globalCompositeOperation = 'source-over';
  }
  /* pattes (péréiopodes) : 7 paires sous le thorax, onde métachronale ; pléopodes : 3 paires frangées sous le pléon */
  function pattes(far) {
    const a = far ? .35 : .9, dph = far ? .9 : 0, dx = far ? 1.3 : 0;
    for (let i = 0; i < 7; i++) {
      const u = 17 - i * 3.3 + dx, p = om - i * .78 + dph, base = Math.PI / 2 + .5 - i * .1 + .4 * Math.sin(p), L = (fin ? 7 : 8) + 1.4 * Math.sin(i * 1.9) + (i > 3 ? 1.5 : 0) - (i < 2 ? 1.6 : 0);
      lamelle(u, bot(u) - 1.8, base, L + 1, 1.05 - .05 * i, 1.6 * Math.cos(p) + .8, i > 3 ? 2 : 0, a * (i % 2 ? .8 : 1), i % 2 ? 0 : 1);
    }
    for (let i = 0; i < 3; i++) {
      const u = -6 - i * 4.4 + dx, p = om * 1 - (i + 7) * .78 + dph, an = Math.PI / 2 + .9 + .5 * Math.sin(p);
      lamelle(u, bot(u) - 1.6, an, 7.4, 1.7, 1.8 * Math.cos(p), 4, a * .75, .5);
      if (!far) lamelle(u - .6, bot(u - .6) - .4, an + .3, 5.2, 1.3, 1.4 * Math.cos(p), 0, a * .5, 0);
    }
  }
  /* éventail caudal : trois paires d'uropodes lancéolés frangés + telson fendu (plus de queue de poisson) */
  function eventail(far) {
    const r0 = U0 + .5, ry = mid(U0) + .3, sp = .32 + .08 * Math.sin(W + 2.4), a = far ? .5 : .95;
    for (let j = 0; j < 3; j++) for (let s = -1; s <= 1; s += 2) {
      if (far !== (s < 0)) continue;
      const an = Math.PI + s * (sp * (j + .6) * .55) + .05 * Math.sin(W + j), L = 7.5 - 1.2 * j;
      lamelle(r0 + 1.5 + j * 1.4, ry + s * .3 - j * .2, an, L + 1.5, 1.5 - .2 * j, s * .8, j ? 0 : 4, a * (1 - .2 * j), j ? 0 : .6);
    }
    if (!far) { g.beginPath(); g.moveTo(r0 + 1, ry - 1.4); g.bezierCurveTo(r0 - 2, ry - 1.6, r0 - 4.4, ry - .9, r0 - 4.3, ry - .2); g.quadraticCurveTo(r0 - 3.4, ry + .15, r0 - 4.3, ry + .6); g.bezierCurveTo(r0 - 4.4, ry + 1.3, r0 - 2, ry + 1.6, r0 + 1, ry + 1.4); g.closePath();
      g.fillStyle = K1; g.globalAlpha = .18; g.fill(); trois(g, K1, K2, .7, .8); }
  }
  /* 0. côté lointain (plus pâle, décalé), puis côté proche : les racines passent SOUS la chair translucide (jonctions fondues) */
  eventail(true); pattes(true); pattes(false); eventail(false);
  /* 1. chair : sombre translucide + halo flou pré-rendu */
  corps(1); g.save(); g.shadowColor = rgba(C.c1, .5); g.shadowBlur = 6 * pxu; g.fillStyle = rgba(C.c3, .56); g.fill(); g.restore();
  /* 2. volume : dégradé dos clair → ventre sombre + reflet décentré vers la tête */
  g.globalCompositeOperation = 'lighter';
  const lg = g.createLinearGradient(0, -16, 0, 2); lg.addColorStop(0, rgba(C.c1, .3)); lg.addColorStop(.5, rgba(C.c1, .13)); lg.addColorStop(1, rgba(C.c1, .05));
  corps(1); g.fillStyle = lg; g.fill();
  const rg = g.createRadialGradient(9, -12, 0, 9, -12, 16); rg.addColorStop(0, rgba(C.c2, .2)); rg.addColorStop(1, rgba(C.c2, 0)); g.fillStyle = rg; g.fill();
  g.save(); corps(1); g.clip();
  /* 3. segments : sillons doux (deux passes) + bande de lumière derrière chaque sillon (plaques) */
  const SEG = [19.5, 16.2, 13, 9.9, 6.8, 3.7, .6, -2.6, -6, -9.6, -13.2, -16.6];
  g.beginPath(); for (const u of SEG) { g.moveTo(u + 1, top(u) - .5); g.quadraticCurveTo(u - 1.3, mid(u), u + .4, bot(u) + .5); }
  g.strokeStyle = K1; g.globalAlpha = .07; g.lineWidth = 2.2; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .13; g.lineWidth = .35; g.stroke();
  g.beginPath(); for (const u of SEG) { g.moveTo(u - .9, top(u - .9) + .6); g.quadraticCurveTo(u - 2.8, mid(u) - 1, u - 1.8, mid(u) + 1); }
  g.strokeStyle = K2; g.globalAlpha = .08; g.lineWidth = 1.6; g.stroke();
  /* 4. viscères par transparence : tube digestif (trois passes) et ses perles, cœur dorsal lilas, œufs/glandes, granulations */
  g.beginPath(); for (let i = 0; i <= 30; i++) { const u = 18 - i * 37 / 30, y = mid(u) + (bot(u) - top(u)) * (.06 + .05 * Math.sin(u * .55 + W)); i ? g.lineTo(u, y) : g.moveTo(u, y); }
  g.strokeStyle = KA; g.globalAlpha = .1; g.lineWidth = 3.4; g.stroke(); g.globalAlpha = .26; g.lineWidth = 1.3; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .3; g.lineWidth = .35; g.stroke();
  g.beginPath(); for (let i = 0; i <= 12; i++) { const u = 13 - i * 22 / 12, y = top(u) + (bot(u) - top(u)) * .2; i ? g.lineTo(u, y) : g.moveTo(u, y); }
  g.strokeStyle = KB; g.globalAlpha = .12; g.lineWidth = 2; g.stroke(); g.globalAlpha = .35; g.lineWidth = .45; g.stroke();
  for (let i = 0; i < 9; i++) { const u = 15 - i * 4.1, y = mid(u) + (bot(u) - top(u)) * .06; point(g, SPA, u, y, 1.5 + .6 * hs(i), .35 + .25 * hs(i * 2)); }
  for (let i = 0; i < 4; i++) { const u = 11 - i * 3.6, y = mid(u) + (bot(u) - top(u)) * .27; point(g, SPB, u, y, 1.8, .4); }
  if (!fin) for (let i = 0; i < 30; i++) { const u = U0 + 2 + hs(i * 3.1) * 38, y = top(u) + (bot(u) - top(u)) * (.15 + .7 * hs(i * 7.3)); g.beginPath(); g.arc(u, y, .25 + .3 * hs(i), 0, TAU); g.fillStyle = i % 4 ? K2 : KA; g.globalAlpha = .12 + .12 * hs(i * 1.7); g.fill(); }
  g.restore();
  /* 5. plaques coxales : boucliers translucides qui pendent sous le thorax */
  for (let i = 0; i < 5; i++) { const u = 17.5 - i * 3.3, b0 = bot(u), d = 3.4 - .3 * i;
    g.beginPath(); g.moveTo(u + 1.7, bot(u + 1.7) - 1.2); g.quadraticCurveTo(u + 1.9, b0 + d, u, b0 + d * .9); g.quadraticCurveTo(u - 1.9, b0 + d * .8, u - 1.7, bot(u - 1.7) - 1.2);
    g.fillStyle = K1; g.globalAlpha = .07; g.fill(); g.strokeStyle = K1; g.globalAlpha = .06; g.lineWidth = 2; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .13; g.lineWidth = .35; g.stroke(); }
  /* 6. membrane intérieure + bord en trois passes (doux) + reflet du dos */
  corps(.8); g.strokeStyle = K2; g.globalAlpha = .17; g.lineWidth = .4; g.stroke();
  corps(1); trois(g, K1, K2, 1, .6);
  g.beginPath(); for (let i = 1; i < 25; i++) { const u = U0 + (U1 - U0) * i / 26, y = top(u) + 1.2; i === 1 ? g.moveTo(u, y) : g.lineTo(u, y); }
  g.strokeStyle = K2; g.globalAlpha = .07; g.lineWidth = 1.8; g.stroke(); g.globalAlpha = .18; g.lineWidth = .45; g.stroke();
  /* 7. tête : œil composé (rein sombre, ommatidies, reflet), pièces buccales */
  const ex = 17.6, ey = cy(17.6) - 3.2;
  g.beginPath(); g.ellipse(ex, ey, 2.3, 1.7, -.4, 0, TAU); g.fillStyle = 'rgba(4,10,30,.6)'; g.fill(); g.strokeStyle = K1; g.globalAlpha = .12; g.lineWidth = 1.2; g.stroke();
  for (let i = 0; i < 6; i++) { const a2 = i * TAU / 6; g.beginPath(); g.arc(ex + Math.cos(a2) * 1.2, ey + Math.sin(a2) * .85, .3, 0, TAU); g.fillStyle = KA; g.globalAlpha = .35; g.fill(); }
  point(g, SPW, ex + .7, ey - .5, 1, .9);
  lamelle(22.5, bot(22) - 1, Math.PI / 2 + .3 + .15 * Math.sin(om), 3, .8, .4, 0, .8, 0);
  /* 8. côté proche : pattes et éventail (net, plus lumineux) ; soies dorsales du pléon */
  if (!fin) { g.beginPath(); for (let i = 0; i < 5; i++) { const u = -9 - i * 2.4, y = top(u); g.moveTo(u, y); g.quadraticCurveTo(u - 1, y - 1.4, u - 2.6 - .5 * Math.sin(W + i), y - 2); }
    g.globalCompositeOperation = 'lighter'; g.strokeStyle = K2; g.globalAlpha = .3; g.lineWidth = .3; g.stroke(); g.globalCompositeOperation = 'source-over'; }
  g.globalAlpha = 1;
  return cv;
}
const DOT = { w: null, a: null, b: null };
function atlasAmphi(H) {
  if (!ATL.g) { const C = COL.amphi; DOT.w = H.sprite('e6amw', C.c2, 'p'); DOT.a = H.sprite('e6ama', C.ac, 'p'); DOT.b = H.sprite('e6amb', C.a2, 'p');
    ATL.g = { pxu: 3.2, f: new Array(NK), fin: false, n: 0 }; ATL.p = { pxu: 1.4, f: new Array(NK), fin: true, n: 0 }; }
  for (const A of [ATL.g, ATL.p]) if (A.n < NK) { for (let k = 0; k < 2 && A.n < NK; k++, A.n++) if (!A.f[A.n]) A.f[A.n] = amphiCle(A.n / NK, COL.amphi, A.pxu, A.fin); }   // pré-remplissage : l'atlas est complet en 16 images
}
let budget = 0;   // images clés construites dans l'appel courant (au plus 2 : le premier cycle se remplit en douceur)
function cle(A, ph) {
  let i = Math.floor(((ph % 1) + 1) % 1 * NK) % NK;
  if (A.f[i]) return A.f[i];
  if (budget < 3) { budget++; return (A.f[i] = amphiCle(i / NK, COL.amphi, A.pxu, A.fin)); }
  for (let k = 1; k < NK; k++) { const j = (i - k + NK) % NK; if (A.f[j]) return A.f[j]; }   // la plus proche déjà prête
  budget++; return (A.f[i] = amphiCle(i / NK, COL.amphi, A.pxu, A.fin));
}
/* R493 · VIRAGE « IMMELMANN » DE L'AMPHIPODE (prototype isolé /tmp/fond47/t/galerie/virage) : un vrai demi-tour de nageur,
   toujours en vue latérale, jamais en tranche ni en miroir.
   Modèle 3D léger : le corps est une suite de sections ELLIPTIQUES (hauteur = profil de la nage, largeur LAT × hauteur), les 7 paires
   de péréiopodes, 3 paires de pléopodes, les uropodes et le telson sont attachés en 3D (côté droit / gauche), l'œil composé existe
   des deux côtés. Pose = roulis psi (vrille autour de l'axe du corps), courbure kap (demi-boucle), étirement, coup de queue.
   1) demi-boucle : la tête monte et passe PAR-DESSUS (rotation dans le plan de 180°, corps arqué le long de la boucle) ;
   2) vrille de 180° autour de l'axe en même temps que la POUSSÉE : le corps s'étire, pléopodes et uropodes fouettent, le corps
      file dans la nouvelle direction (sillage, poussière de bulles) et redescend dans son couloir, dos en haut.
   Pattes, soies, pléopodes, uropodes et antennes SUIVENT : réponse d'un ressort amorti aux vitesses angulaires (retard, dépassement,
   enroulement en spirale autour du corps pendant la vrille).
   Coût : la pose ne dépend que de p (0..1) → atlas de NT images clés (pré-rendu en différé après l'atlas de nage, 1 image par appel) ;
   la rotation dans le plan et le déplacement sont appliqués au blit (éclairage pré-tourné) ; antennes, pulsation, sillage et bulles
   en direct. Aucun coût hors virage. La physique (fluides.js / crForce) n'est pas touchée. */
let AM = 1, AML = 1, NOANT = 0;
const U0T = -21, Y0 = -7, LAT = .7;
const TB = { X: -46, Y: -44, W: 88, H: 74 };
const PK = (function () { const a = []; for (let i = 0; i < 13; i++) a.push(.46 * i / 13); for (let i = 0; i < 21; i++) a.push(.46 + .44 * i / 21); for (let i = 0; i < 6; i++) a.push(.9 + .1 * i / 5); return a; })();
const NT = PK.length, TATL = { g: null, p: null };
const sm5 = v => { v = cl(v); return v * v * v * (v * (v * 6 - 15) + 10); };
const rotT = p => { const a1 = Math.sin(Math.PI * cl((p - .02) / .14)), eA = sm5((p - .05) / .45);
  return -Math.PI * eA + .13 * a1 - .2 * Math.sin(Math.PI * cl((p - .58) / .42)); };
const psiT = p => Math.PI * sm5((p - .46) / .44);
/* réponse visco-élastique (ressort amorti) des appendices aux vitesses angulaires : tables en p (temps de référence 1,5 s) */
const NL = 240, LR = new Float32Array(NL + 1), LP = new Float32Array(NL + 1);
(function () { const Dt = 1.5 / NL, Kk = Math.pow(TAU * 1.9, 2), Cc = 2 * .32 * Math.sqrt(Kk);
  let a = 0, va = 0, b = 0, vb = 0;
  for (let i = 0; i <= NL; i++) { const p = i / NL, h = .5 / NL, wr = (rotT(p + h) - rotT(p - h)) / (2 * h) / 1.5, wp = (psiT(p + h) - psiT(p - h)) / (2 * h) / 1.5;
    va += (Kk * (-.075 * wr - a) - Cc * va) * Dt; a += va * Dt; vb += (Kk * (-.07 * wp - b) - Cc * vb) * Dt; b += vb * Dt; LR[i] = a; LP[i] = b; } })();
const lagT = (Tb, p) => { const f = cl(p) * NL, i = Math.min(NL - 1, f | 0); return lerp(Tb[i], Tb[i + 1], f - i); };
function poseTour(p) {
  const q = (p - .46) / .44, qc = cl(q), pk = q <= 0 ? 0 : q < .16 ? ss(q / .16) : 1 - ss((q - .16) / .84);
  const a1 = Math.sin(Math.PI * cl((p - .02) / .14)), gat = ss((p - .36) / .08) * (1 - ss((p - .47) / .05));
  return { p, pk, q: qc, r: rotT(p), psi: psiT(p), eA: sm5((p - .05) / .45), eo: 1 - Math.pow(1 - cl((p - .5) / .45), 3), dn: ss((p - .55) / .45),
    kap: .045 * Math.sin(Math.PI * cl((p - .03) / .5)) - .01 * pk, str: 1 - .05 * a1 - .07 * gat + .15 * pk, flk: pk * Math.sin(TAU * qc * 3),
    tk: ss((p - .03) / .14) * (1 - ss((p - .8) / .18)), wav: 1 - .85 * ss(p / .1) * (1 - ss((p - .86) / .14)),
    om: TAU * (1.5 * p + 4 * sm5(q)), sp: .32 + .5 * pk + .1 * ss((p - .1) / .2) * (1 - ss((p - .5) / .1)), lr: lagT(LR, p), lp: lagT(LP, p) };
}
function decalTour(P, R, D) {   // déplacement visuel (unités corps, sens de départ) : demi-boucle vers le haut, puis poussée et retour au couloir
  if (P.p <= .5) { const th = Math.PI * P.eA; return [R * Math.sin(th) + D * P.eA, -R * (1 - Math.cos(th))]; }
  return [D * (1 - P.eo), -2 * R * (1 - P.dn)];
}
/* projection : (u, v, z) du repère corps → (QX, QY) dans le plan, QZ = profondeur (+ vers l'œil) */
let QX = 0, QY = 0, QZ = 0, Qc = 1, Qs = 0, Qk = 0, QR = 0, Qst = 1, Qfl = 0, Qwv = 1, QW = 0;
function poserQ(P) { Qc = Math.cos(P.psi); Qs = Math.sin(P.psi); Qk = P.kap; QR = Math.abs(Qk) > 1e-5 ? 1 / Qk : 0; Qst = P.str; Qfl = P.flk; Qwv = P.wav; QW = TAU * P.p; }
const cyT = u => -7.5 * (1 - (u / 22) * (u / 22)) + Qwv * (.75 + .45 * (22 - u) / 44) * Math.sin(QW + u * .16) + (u < -4 ? Qfl * 4.5 * ((-u - 4) / 18) * ((-u - 4) / 18) : 0);
function plier(x, y) { if (!QR) { QX = x; QY = y; return; } const th = x * Qk, rr = QR + (y - Y0); QX = rr * Math.sin(th); QY = Y0 - QR + rr * Math.cos(th); }
function proj(u, v, z, dpsi) { let c = Qc, s = Qs;
  if (dpsi) { const ps = Math.atan2(Qs, Qc) - dpsi; c = Math.cos(ps); s = Math.sin(ps); }
  const y1 = Y0 + (v - Y0) * c - z * s; QZ = (v - Y0) * s + z * c; plier(u * Qst, y1); }
function amphiTourCle(p, C, pxu, fin) {
  const P = poseTour(p); poserQ(P);
  const cv = toile(TB.W * pxu, TB.H * pxu), g = cv.getContext('2d');
  g.setTransform(pxu, 0, 0, pxu, -TB.X * pxu, -TB.Y * pxu); g.lineCap = 'round'; g.lineJoin = 'round';
  const W = QW, om = P.om, cs = Qc, sn = Qs, ST = Qst, top = u => cyT(u) - dthA(u), bot = u => cyT(u) + vthA(u), mid = u => (top(u) + bot(u)) / 2, ha = u => (dthA(u) + vthA(u)) / 2;
  const K1 = rgba(C.c1, 1), K2 = rgba(C.c2, 1), K3 = rgba(C.c3, 1), KA = rgba(C.ac, 1), KB = rgba(C.a2, 1), SPW = DOT.w, SPA = DOT.a, SPB = DOT.b, U0 = -21, U1 = 22;
  const vis = z => ss((z + .2) / .4);   // côté tourné vers l'œil (0 caché → 1 visible), z en unités de demi-largeur
  /* silhouette : section elliptique projetée (demi-hauteur apparente = √(a²cos² + b²sin²)), puis courbure */
  function sec(u, sc) { const m = mid(u), a = ha(u), b = LAT * a; return [Y0 + (m - Y0) * cs, Math.sqrt(a * a * cs * cs + b * b * sn * sn) * sc]; }
  function corps(sc) {
    g.beginPath();
    for (let i = 0; i <= 26; i++) { const u = U0 + (U1 - U0) * i / 26, s2 = sec(u, sc); plier(u * ST, s2[0] - s2[1]); i ? g.lineTo(QX, QY) : g.moveTo(QX, QY); }
    const h1 = sec(U1, sc), xh = U1 * ST; let ax, ay, bx2, by2;
    plier(xh + 2.2 * sc, h1[0] - h1[1]); ax = QX; ay = QY; plier(xh + 3 * sc, h1[0] + .4 * cs); bx2 = QX; by2 = QY; plier(xh + 2 * sc, h1[0] + h1[1] + .3 * cs); g.bezierCurveTo(ax, ay, bx2, by2, QX, QY);
    for (let i = 26; i >= 0; i--) { const u = U0 + (U1 - U0) * i / 26, s2 = sec(u, sc); plier(u * ST, s2[0] + s2[1]); g.lineTo(QX, QY); }
    const h0 = sec(U0, sc); plier(U0 * ST - 1.6 * sc, h0[0]); ax = QX; ay = QY; plier(U0 * ST, h0[0] - h0[1]); g.quadraticCurveTo(ax, ay, QX, QY); g.closePath();
  }
  /* appendice 3D : base B, direction (dx,dy,dz), longueur L, flexion bend ; il suit le corps avec retard (dans le plan : lr ; en vrille : lp, en spirale) */
  function app(u, v, z, an, dz, L, bend, w, soies, a, pointe, kl) {
    const lr = P.lr * kl, ca = Math.cos(an + lr), sa = Math.sin(an + lr), cm = Math.cos(an + lr * .45), sm = Math.sin(an + lr * .45);
    proj(u, v, z, 0); const bx = QX, by = QY, bz = QZ;
    proj(u + cm * L * .5 - sm * bend, v + sm * L * .5 + cm * bend, z + dz * L * .5, P.lp * kl * .5); const mx = QX, my = QY;
    proj(u + ca * L, v + sa * L, z + dz * L, P.lp * kl); const tx = QX, ty = QY;
    lam3(bx, by, mx, my, tx, ty, w, soies, a, pointe, lr); return bz;
  }
  function lam3(bx, by, mx, my, tx, ty, w, soies, a, pointe, lr) {
    if (a <= .01) return;
    const an = Math.atan2(ty - by, tx - bx), ca = Math.cos(an), sa = Math.sin(an);
    g.beginPath(); g.moveTo(bx - sa * w, by + ca * w); g.quadraticCurveTo(mx - sa * w * .9, my + ca * w * .9, tx, ty); g.quadraticCurveTo(mx + sa * w * .7, my - ca * w * .7, bx + sa * w, by - ca * w); g.closePath();
    g.fillStyle = K3; g.globalAlpha = .22 * a; g.fill();
    g.fillStyle = K1; g.globalAlpha = .1 * a; g.fill();
    g.globalCompositeOperation = 'lighter'; trois(g, K1, K2, .8, .5 * a);
    g.beginPath(); g.moveTo(bx, by); g.quadraticCurveTo(mx, my, tx, ty); g.strokeStyle = KA; g.globalAlpha = .22 * a; g.lineWidth = .35; g.stroke();
    if (soies && !fin) { g.beginPath();
      for (let s = 0; s < soies; s++) { const u = .45 + .55 * s / Math.max(1, soies - 1), px = bx + (tx - bx) * u + (mx - (bx + tx) / 2) * 4 * u * (1 - u), py = by + (ty - by) * u + (my - (by + ty) / 2) * 4 * u * (1 - u), ln = 1.6 + 2.2 * u, dr = -.9 - .5 * Math.sin(W + s) - 3 * lr * u;
        g.moveTo(px, py); g.quadraticCurveTo(px + sa * ln * .5 + ca * .4, py - ca * ln * .5 + sa * .4, px + sa * ln + ca * dr, py - ca * ln + sa * dr); }
      g.strokeStyle = K1; g.globalAlpha = .06 * a; g.lineWidth = 1.1; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .26 * a; g.lineWidth = .25; g.stroke(); }
    if (pointe) point(g, SPA, tx, ty, 1.3, .35 * a * pointe);
    g.globalCompositeOperation = 'source-over';
  }
  const dep = (zb, u) => { const b = LAT * ha(u); return ss((zb / b + .6) / 1.2); };   // 0 : côté lointain · 1 : côté proche
  /* pattes (7 paires) et pléopodes (3 paires frangées) d'un côté ; ka : part de ce passage (sous / sur la chair) */
  function pattes(side, ka) {
    const far = side < 0, dph = far ? .9 : 0, dx = far ? 1.3 : 0;
    for (let i = 0; i < 7; i++) {
      const u = 17 - i * 3.3 + dx, ph = om - i * .78 + dph, bv = bot(u) - 1.8, bz = side * .5 * LAT * ha(u);
      const an = lerp(Math.PI / 2 + .5 - i * .1 + .4 * Math.sin(ph), Math.PI - .22 + .03 * i, P.tk);
      const L = ((fin ? 7 : 8) + 1.4 * Math.sin(i * 1.9) + (i > 3 ? 1.5 : 0) - (i < 2 ? 1.6 : 0) + 1) * (1 - .34 * P.tk);
      proj(u, bv, bz, 0); const a = ka * lerp(.35, .9, dep(QZ, u)) * (i % 2 ? .8 : 1);
      app(u, bv, bz, an, side * (.42 + .2 * P.tk), L, (1.6 * Math.cos(ph) + .8) * (1 - .6 * P.tk), 1.05 - .05 * i, i > 3 ? 2 : 0, a, i % 2 ? 0 : 1, 1 + .12 * i);
    }
    for (let i = 0; i < 3; i++) {
      const u = -6 - i * 4.4 + dx, ph = om - (i + 7) * .78 + dph, an = Math.PI / 2 + .9 + (.5 + .35 * P.pk) * Math.sin(ph), bv = bot(u) - 1.6, bz = side * .4 * LAT * ha(u);
      proj(u, bv, bz, 0); const d = dep(QZ, u), a = ka * lerp(.35, .9, d);
      app(u, bv, bz, an, side * .35, 7.4 + 1.2 * P.pk, 1.8 * Math.cos(ph), 1.7, 4, a * .75 / .9, .5, 1.6);
      app(u - .6, bot(u - .6) - .4, bz, an + .3, side * .3, 5.2, 1.4 * Math.cos(ph), 1.3, 0, ka * .5 * ss((d - .55) / .3), 0, 1.8);
    }
  }
  /* éventail caudal en 3D : les uropodes s'ouvrent en V incliné (jamais à plat), le telson fendu a une épaisseur */
  function eventail(ka, quel) {
    const r0 = U0 + .5, ry = mid(U0) + .3, sp = P.sp + .08 * Math.sin(W + 2.4), wh = .3 * P.pk * Math.sin(om * 1.5);
    for (let j = 0; j < 3; j++) for (let s = -1; s <= 1; s += 2) {
      const sg = s * (sp * (j + .6) * .55), an = Math.PI + sg + .05 * Math.sin(W + j) + s * wh, L = 7.5 - 1.2 * j + 1.5, bz = s * .6;
      proj(r0 + 1.5 + j * 1.4, ry + s * .3 - j * .2, bz, 0); const near = QZ > 0;
      if ((quel > 0) !== near) continue;
      const a = ka * lerp(.5, .95, ss((QZ + 1.2) / 2.4)) * (1 - .2 * j);
      app(r0 + 1.5 + j * 1.4, ry + s * .3 - j * .2, bz, an, s * (.2 + .9 * Math.abs(Math.sin(sg))), L, s * .8, 1.5 - .2 * j, j ? 0 : 4, a, j ? 0 : .6, 2.2);
    }
    if (quel > 0) { const T0 = [[1, -1.4], [-2, -1.6], [-4.4, -.9], [-4.3, -.2], [-3.4, .15], [-4.3, .6], [-4.4, 1.3], [-2, 1.6], [1, 1.4]], Pt = [];
      for (const t of T0) { proj(r0 + t[0], ry + t[1], t[1] * .8, 0); Pt.push(QX, QY); }
      g.beginPath(); g.moveTo(Pt[0], Pt[1]); g.bezierCurveTo(Pt[2], Pt[3], Pt[4], Pt[5], Pt[6], Pt[7]); g.quadraticCurveTo(Pt[8], Pt[9], Pt[10], Pt[11]); g.bezierCurveTo(Pt[12], Pt[13], Pt[14], Pt[15], Pt[16], Pt[17]); g.closePath();
      g.fillStyle = K1; g.globalAlpha = .18 * ka; g.fill(); trois(g, K1, K2, .7, .8 * ka); }
  }
  /* 0. appendices sous la chair (comme la nage) ; quand le ventre se tourne vers l'œil, ils passent progressivement devant */
  const kt = ss((sn - .3) / .45), sA = cs >= 0 ? -1 : 1;
  eventail(1 - kt * .6, -1); pattes(sA, 1 - kt); pattes(-sA, 1 - kt); eventail(1 - kt, 1);
  /* 1. chair */
  corps(1); g.save(); g.shadowColor = rgba(C.c1, .5); g.shadowBlur = 6 * pxu; g.fillStyle = rgba(C.c3, .56); g.fill(); g.restore();
  /* 2. volume : la lumière vient toujours d'en haut de l'écran (direction pré-tournée de -r) */
  g.globalCompositeOperation = 'lighter';
  const ux = -Math.sin(P.r), uy = -Math.cos(P.r);
  const lg = g.createLinearGradient(ux * 9, Y0 + uy * 9, -ux * 9, Y0 - uy * 9); lg.addColorStop(0, rgba(C.c1, .3)); lg.addColorStop(.5, rgba(C.c1, .13)); lg.addColorStop(1, rgba(C.c1, .05));
  corps(1); g.fillStyle = lg; g.fill();
  proj(9, -12, 0, 0); const rg = g.createRadialGradient(QX, QY, 0, QX, QY, 16); rg.addColorStop(0, rgba(C.c2, .2)); rg.addColorStop(1, rgba(C.c2, 0)); g.fillStyle = rg; g.fill();
  g.save(); corps(1); g.clip();
  /* 3. segments : anneaux 3D (seule la moitié tournée vers l'œil est tracée) */
  const SEG = [19.5, 16.2, 13, 9.9, 6.8, 3.7, .6, -2.6, -6, -9.6, -13.2, -16.6];
  const anneau = (u, f, e0, e1) => { const m = mid(u), a = ha(u) * 1.06, b = LAT * a; let on = false;
    for (let j = 0; j <= 20; j++) { const ph = TAU * j / 20, eta = -Math.cos(ph); if (eta < e0 || eta > e1) { on = false; continue; }
      proj(u + f(eta), m + a * eta, b * Math.sin(ph), 0); if (QZ < -.05 * b) { on = false; continue; } on ? g.lineTo(QX, QY) : g.moveTo(QX, QY); on = true; } };
  g.beginPath(); for (const u of SEG) anneau(u, e => -.3 - .3 * e + e * e, -1, 1);
  g.strokeStyle = K1; g.globalAlpha = .07; g.lineWidth = 2.2; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .13; g.lineWidth = .35; g.stroke();
  g.beginPath(); for (const u of SEG) anneau(u, e => -1.6 - .9 * Math.sin(Math.PI * (e + .9) / 1.1), -.92, .15);
  g.strokeStyle = K2; g.globalAlpha = .08; g.lineWidth = 1.6; g.stroke();
  /* 4. viscères (au centre du volume) */
  g.beginPath(); for (let i = 0; i <= 30; i++) { const u = 18 - i * 37 / 30; proj(u, mid(u) + 2 * ha(u) * (.06 + .05 * Math.sin(u * .55 + W)), 0, 0); i ? g.lineTo(QX, QY) : g.moveTo(QX, QY); }
  g.strokeStyle = KA; g.globalAlpha = .1; g.lineWidth = 3.4; g.stroke(); g.globalAlpha = .26; g.lineWidth = 1.3; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .3; g.lineWidth = .35; g.stroke();
  g.beginPath(); for (let i = 0; i <= 12; i++) { const u = 13 - i * 22 / 12; proj(u, top(u) + 2 * ha(u) * .2, 0, 0); i ? g.lineTo(QX, QY) : g.moveTo(QX, QY); }
  g.strokeStyle = KB; g.globalAlpha = .12; g.lineWidth = 2; g.stroke(); g.globalAlpha = .35; g.lineWidth = .45; g.stroke();
  for (let i = 0; i < 9; i++) { const u = 15 - i * 4.1; proj(u, mid(u) + 2 * ha(u) * .06, 0, 0); point(g, SPA, QX, QY, 1.5 + .6 * hs(i), .35 + .25 * hs(i * 2)); }
  for (let i = 0; i < 4; i++) { const u = 11 - i * 3.6; proj(u, mid(u) + 2 * ha(u) * .27, 0, 0); point(g, SPB, QX, QY, 1.8, .4); }
  if (!fin) for (let i = 0; i < 30; i++) { const u = U0 + 2 + hs(i * 3.1) * 38; proj(u, top(u) + 2 * ha(u) * (.15 + .7 * hs(i * 7.3)), LAT * ha(u) * (hs(i * 5.9) - .5) * 1.2, 0);
    g.beginPath(); g.arc(QX, QY, .25 + .3 * hs(i), 0, TAU); g.fillStyle = i % 4 ? K2 : KA; g.globalAlpha = .12 + .12 * hs(i * 1.7); g.fill(); }
  g.restore();
  /* 5. plaques coxales des deux côtés (le côté caché s'efface) */
  for (let s = -1; s <= 1; s += 2) for (let i = 0; i < 5; i++) { const u = 17.5 - i * 3.3, b0 = bot(u), d = 3.4 - .3 * i, zb = s * .55 * LAT * ha(u), zt = s * (.55 * LAT * ha(u) + .4 * d);
    proj(u, b0 + d * .9, zt, 0); const k = vis(QZ / (LAT * ha(u))); if (k < .02) continue; const tx = QX, ty = QY;
    proj(u + 1.7, bot(u + 1.7) - 1.2, zb, 0); const ax = QX, ay = QY; proj(u + 1.9, b0 + d, zt, 0); const c1x = QX, c1y = QY;
    proj(u - 1.9, b0 + d * .8, zt, 0); const c2x = QX, c2y = QY; proj(u - 1.7, bot(u - 1.7) - 1.2, zb, 0);
    g.beginPath(); g.moveTo(ax, ay); g.quadraticCurveTo(c1x, c1y, tx, ty); g.quadraticCurveTo(c2x, c2y, QX, QY);
    g.fillStyle = K1; g.globalAlpha = .07 * k; g.fill(); g.strokeStyle = K1; g.globalAlpha = .06 * k; g.lineWidth = 2; g.stroke(); g.strokeStyle = K2; g.globalAlpha = .13 * k; g.lineWidth = .35; g.stroke(); }
  /* 6. membrane intérieure + bord doux + reflet du dos (s'efface quand le dos se détourne) */
  corps(.8); g.strokeStyle = K2; g.globalAlpha = .17; g.lineWidth = .4; g.stroke();
  corps(1); trois(g, K1, K2, 1, .6);
  g.beginPath(); for (let i = 1; i < 25; i++) { const u = U0 + (U1 - U0) * i / 26; proj(u, top(u) + 1.2, 0, 0); i === 1 ? g.moveTo(QX, QY) : g.lineTo(QX, QY); }
  const kd = 1 - .75 * sn; g.strokeStyle = K2; g.globalAlpha = .07 * kd; g.lineWidth = 1.8; g.stroke(); g.globalAlpha = .18 * kd; g.lineWidth = .45; g.stroke();
  /* 7. tête : un œil composé de chaque côté, pièces buccales en V */
  for (let s = -1; s <= 1; s += 2) { const ey = cyT(17.6) - 3.2, bz = s * .62 * LAT * ha(17.6); proj(17.6, ey, bz, 0); const k = vis(QZ / (LAT * ha(17.6))); if (k < .02) continue;
    const ex = QX, ey2 = QY, sy = .55 + .45 * Math.abs(cs);
    g.save(); g.translate(ex, ey2); g.scale(1, sy); g.beginPath(); g.ellipse(0, 0, 2.3, 1.7, -.4 * (cs >= 0 ? 1 : -1), 0, TAU); g.restore();
    g.fillStyle = 'rgba(4,10,30,.6)'; g.globalAlpha = k; g.fill(); g.strokeStyle = K1; g.globalAlpha = .12 * k; g.lineWidth = 1.2; g.stroke();
    for (let i = 0; i < 6; i++) { const a2 = i * TAU / 6; g.beginPath(); g.arc(ex + Math.cos(a2) * 1.2, ey2 + Math.sin(a2) * .85 * sy, .3, 0, TAU); g.fillStyle = KA; g.globalAlpha = .35 * k; g.fill(); }
    point(g, SPW, ex + .7, ey2 - .5 * (cs >= 0 ? 1 : -1), 1, .9 * k); }
  for (let s = -1; s <= 1; s += 2) app(22.5, bot(22) - 1, s * .4, Math.PI / 2 + .3 + .15 * Math.sin(om), s * .25, 3, .4, .8, 0, .8 * (s > 0 ? 1 : .6), 0, .6);
  /* 8. appendices devant la chair quand le ventre fait face ; soies dorsales du pléon (traînent pendant la boucle) */
  if (kt > .01) { eventail(kt * .5, -1); pattes(sA, kt * .7); pattes(-sA, kt * .7); eventail(kt * .8, 1); }
  if (!fin) { g.beginPath(); for (let i = 0; i < 5; i++) { const u = -9 - i * 2.4, y = top(u), dr = -.5 * Math.sin(W + i) - 2.5 * P.lr;
      proj(u, y, 0, 0); g.moveTo(QX, QY); proj(u - 1, y - 1.4, 0, P.lp * .5); const cx2 = QX, cy2 = QY; proj(u - 2.6 + dr, y - 2 + .8 * P.lr, 0, P.lp); g.quadraticCurveTo(cx2, cy2, QX, QY); }
    g.globalCompositeOperation = 'lighter'; g.strokeStyle = K2; g.globalAlpha = .3 * (1 - .6 * sn); g.lineWidth = .3; g.stroke(); g.globalCompositeOperation = 'source-over'; }
  g.globalAlpha = 1;
  if (racine.QX_DBG_TB) { g.strokeStyle = '#f00'; g.lineWidth = .5; g.strokeRect(TB.X + .3, TB.Y + .3, TB.W - .6, TB.H - .6); }
  return cv;
}
let tbud = 0;
function cleT(A, i) {
  if (A.f[i]) return A.f[i];
  if (tbud < 1) { tbud++; return (A.f[i] = amphiTourCle(PK[i], COL.amphi, A.pxu, A.fin)); }
  for (let k = 1; k < NT; k++) { if (A.f[i - k]) return A.f[i - k]; if (A.f[i + k]) return A.f[i + k]; }
  tbud++; return (A.f[i] = amphiTourCle(PK[i], COL.amphi, A.pxu, A.fin));
}
function atlasTour(banc) {   // pré-rendu en différé : une image clé par appel, seulement quand l'atlas de nage est complet (atlas réduit : seulement s'il y a un banc)
  if (!TATL.g) { TATL.g = { pxu: 3.2, f: new Array(NT), fin: false, n: 0 }; TATL.p = { pxu: 1.4, f: new Array(NT), fin: true, n: 0 }; }
  if (ATL.g.n < NK || ATL.p.n < NK) return;
  for (const A of banc ? [TATL.g, TATL.p] : [TATL.g]) if (A.n < NT) { if (!A.f[A.n]) A.f[A.n] = amphiTourCle(PK[A.n], COL.amphi, A.pxu, A.fin); A.n++; return; }
}
function virage(o, cap, dt, D) {   // état du demi-tour : -1 hors virage, sinon p (0..1)
  const c = cap < 0 ? -1 : 1;
  if (o.f == null) { o.f = c; o.p = -1; }
  if (o.p < 0) { if (c !== o.f) { o.p = 0; o.fr = o.f; o.to = c; } }
  else { o.p += dt / D; if (o.p >= 1) { o.p = -1; o.f = o.to; } }
  return o.p;
}
/* un virage dessiné : sx = sens de DÉPART ; P, o : pose et déplacement (unités corps) */
function tourAmphi(ctx, e, x, y, sx, s, tilt, T, P, o, AC, q, drag, ph) {
  const A = q ? TATL.g : TATL.p, p = P.p; let i = 0; while (i < NT - 2 && PK[i + 1] <= p) i++;
  const f2 = cl((p - PK[i]) / (PK[i + 1] - PK[i])), a0 = Math.min(1, 2 * (1 - f2)), a1 = Math.min(1, 2 * f2);
  ctx.save(); ctx.translate(x, y); ctx.rotate(tilt); ctx.scale(sx * s, s); ctx.translate(o[0], o[1] + Y0); ctx.rotate(P.r); ctx.translate(0, -Y0);
  ctx.globalCompositeOperation = 'source-over'; const ga = AM * (q ? 1 : .78);
  if (a0 > .01) { ctx.globalAlpha = ga * a0; ctx.drawImage(cleT(A, i), TB.X, TB.Y, TB.W, TB.H); }   // deux poses voisines, sans creux de transparence
  if (a1 > .01) { ctx.globalAlpha = ga * a1; ctx.drawImage(cleT(A, i + 1), TB.X, TB.Y, TB.W, TB.H); }
  if (AC > .02) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = AM * .35 * AC; ctx.drawImage(cleT(A, f2 < .5 ? i : i + 1), TB.X, TB.Y, TB.W, TB.H); }
  ctx.globalCompositeOperation = 'lighter'; poserQ(P);
  const Wn = TAU * (((ph % 1) + 1) % 1), cyL = u => cyT(u) - Qwv * (.75 + .45 * (22 - u) / 44) * (Math.sin(QW + u * .16) - Math.sin(Wn + u * .16));   // même onde que la nage : raccord exact
  /* pulsation le long du tube digestif */
  const gu = ((T * (.45 + .4 * AC) + ph * 3) % 1), gx = lerp(16, -19, gu); proj(gx, (cyL(gx) - dthA(gx) + cyL(gx) + vthA(gx)) / 2 + .4, 0, 0); const gg = Math.sin(Math.PI * gu);
  ctx.globalAlpha = AML * (.5 + .4 * AC) * gg * (q ? 1 : .7); ctx.drawImage(e.SA, QX - 4, QY - 3.5, 8, 7);
  if (q) { ctx.globalAlpha = AML * (.18 + .2 * AC) * gg; ctx.drawImage(e.SA, QX - 10, QY - 7, 20, 14); }
  /* antennes en 3D : la paire s'ouvre en V pendant la vrille, traîne derrière la rotation (ressort amorti) puis la rattrape */
  const L1 = q ? 38 : 26, E = e.ant6 || (e.ant6 = new Float32Array(16)), lr = P.lr, lp = P.lp;
  ctx.beginPath();
  for (let k2 = 0; k2 < 2; k2++) { const sd = k2 ? -1 : 1, bx = 22, by = cyL(22) - 2.6 - k2, L = L1 - 4 * k2;
    const a = -2.45 + .14 * k2 + .1 * Math.sin(T * 1.6 + k2 * 1.7 + ph * 6) - .03 * drag - .6 * Math.sin(Math.PI * cl(P.p / .6)) - .3 * P.pk + .5 * lr, a2 = a - .3 * lr, fo = Math.sin(Math.PI * cl(P.p / .7));
    proj(bx, by, sd * .9, 0); const x0 = QX, y0 = QY; E[8 * k2 + 6] = x0; E[8 * k2 + 7] = y0;
    proj(bx + 8 - 4 * fo, by - 9 + 5.5 * fo + 4 * lr, sd * 1.6, lp * .4); E[8 * k2] = QX; E[8 * k2 + 1] = QY;
    proj(bx + Math.cos(a2 + .5) * L * .55, by + Math.sin(a2 + .5) * L * .55 - 4, sd * (2.4 + .12 * L), lp * .5); E[8 * k2 + 2] = QX; E[8 * k2 + 3] = QY;
    proj(bx + Math.cos(a) * L, by + Math.sin(a) * L + 2 * Math.sin(T * 2.3 + k2), sd * (2 + .2 * L), lp * .8); E[8 * k2 + 4] = QX; E[8 * k2 + 5] = QY;
    ctx.moveTo(x0, y0); ctx.bezierCurveTo(E[8 * k2], E[8 * k2 + 1], E[8 * k2 + 2], E[8 * k2 + 3], E[8 * k2 + 4], E[8 * k2 + 5]); }
  for (let k2 = 0; k2 < 2; k2++) { const sd = k2 ? -1 : 1, bx = 23, by = cyL(22) + .5; proj(bx, by, sd * .5, 0); ctx.moveTo(QX, QY);
    proj(bx + 7, by + 1 + k2 * 2 + 4 * lr, sd * 1.5, lp * .5); const cx2 = QX, cy2 = QY; proj(bx + 13 + k2 * 2 - 3 * Math.abs(lr), by + 3 + 2 * Math.sin(T * 2.8 + k2) + 9 * lr, sd * 3.5, lp); ctx.quadraticCurveTo(cx2, cy2, QX, QY); }
  const ka = 1 - .55 * ss((Math.sin(P.psi) - .35) / .5);   // dos détourné : les antennes passent derrière la chair translucide
  if (q) { ctx.strokeStyle = e.K1; ctx.globalAlpha = AML * ka * (.05 + .05 * AC); ctx.lineWidth = 1.3; ctx.stroke(); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = AML * ka * (q ? .42 : .34); ctx.lineWidth = q ? .45 : .5; ctx.stroke();
  if (q) {
    ctx.beginPath(); for (let k2 = 0; k2 < 2; k2++) { const bx = E[8 * k2 + 6], by = E[8 * k2 + 7]; ctx.moveTo(bx, by); ctx.quadraticCurveTo((bx + E[8 * k2]) / 2 + 1, (by + E[8 * k2 + 1]) / 2 - 1, E[8 * k2] * .4 + bx * .6, E[8 * k2 + 1] * .5 + by * .5); }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = AML * .1; ctx.lineWidth = 1.6; ctx.stroke();
    for (let k2 = 0; k2 < 2; k2++) { const bx = E[8 * k2 + 6], by = E[8 * k2 + 7];
      for (let j = 1; j <= 6; j++) { const t = .25 + j * .115, u = 1 - t, px = u * u * u * bx + 3 * u * u * t * E[8 * k2] + 3 * u * t * t * E[8 * k2 + 2] + t * t * t * E[8 * k2 + 4], py = u * u * u * by + 3 * u * u * t * E[8 * k2 + 1] + 3 * u * t * t * E[8 * k2 + 3] + t * t * t * E[8 * k2 + 5];
        const v = .5 + .5 * Math.sin(T * 3 - j * .9 + k2); ctx.globalAlpha = AML * ((.18 + .3 * v) * (1 - .4 * k2) + .2 * AC); ctx.drawImage(e.SW, px - 1, py - 1, 2, 2); }
      ctx.globalAlpha = AML * (.55 + .35 * AC); ctx.drawImage(e.SW, E[8 * k2 + 4] - 1.8, E[8 * k2 + 5] - 1.8, 3.6, 3.6); }
  }
  /* poussée : sillage d'eau arraché derrière l'éventail et poussière de bulles qui se détache des pléopodes (s'élève, se disperse, s'éteint) */
  const ux = -Math.sin(P.r), uy = -Math.cos(P.r);   // le haut de l'écran, dans le repère du corps
  if (P.pk > .03) { proj(U0T - 3, cyT(-21) - 1, 0, 0); const tx = QX, ty = QY, wk = P.pk;
    for (let k2 = 0; k2 < 3; k2++) { const off = (k2 - 1) * 2.6;
      for (let sgm = 0; sgm < 3; sgm++) { ctx.beginPath();
        for (let j = 0; j <= 8; j++) { const d = (sgm * 8 + j) / 24, L = (12 + 18 * wk) * d, ond = (.5 + 1.8 * d) * Math.sin(T * 7 - d * 4.5 + k2 * 2.1);
          const xx = tx - L, yy = ty + off * (1 + 1.4 * d) + ond + uy * 3 * d * d; j ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); }
        const fa = AML * wk * (1 - sgm / 3) * (q ? 1 : .6); ctx.strokeStyle = e.KA; ctx.globalAlpha = .08 * fa; ctx.lineWidth = 2; ctx.stroke(); ctx.strokeStyle = e.K2; ctx.globalAlpha = .22 * fa; ctx.lineWidth = .4; ctx.stroke(); } } }
  if (p > .48 && p < .995) { ctx.beginPath(); const nB = q ? 14 : 5; let gl = 0;
    for (let i2 = 0; i2 < nB; i2++) { const b0 = .48 + .32 * hs(i2 * 2.3), age = (p - b0) / (.18 + .12 * hs(i2 * 5.1)); if (age <= 0 || age >= 1) continue;
      const u = -4 - 16 * hs(i2 * 7.7); proj(u, cyT(u) + 4, (hs(i2 * 3.3) - .5) * 5, 0);
      const r = .3 + .55 * hs(i2 * 9.1), back = (4 + 9 * hs(i2)) * Math.sqrt(age), up = (3 + 9 * hs(i2 * 4.4)) * age * age, wob = 1.2 * Math.sin(age * 7 + i2);
      const bx = QX - back + ux * up + wob * .3, by = QY + uy * up + wob * .2;
      ctx.moveTo(bx + r, by); ctx.arc(bx, by, r, 0, TAU);
      if (q && i2 % 3 === 0) { ctx.globalAlpha = AML * .3 * Math.sin(Math.PI * age); ctx.drawImage(e.SP, bx - 1.3, by - 1.3, 2.6, 2.6); gl++; } }
    ctx.strokeStyle = e.K2; ctx.globalAlpha = AML * .3 * Math.sin(Math.PI * cl((p - .48) / .52)); ctx.lineWidth = .3; ctx.stroke(); }
  ctx.restore();
}
function corpsAmphi(ctx, e, x, y, sx, s, tilt, T, ph, AC, q, drag) {
  const A = q ? ATL.g : ATL.p, pf = (((ph % 1) + 1) % 1) * NK, i0 = pf | 0, fr2 = pf - i0, f = cle(A, i0 / NK + 1e-6), W = TAU * pf / NK, cy = u => cyA(u, W);
  ctx.save(); ctx.translate(x, y); ctx.rotate(tilt); ctx.scale(sx * s, s);
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = AM * (q ? 1 : .78);
  ctx.drawImage(f, BX, BY, BW, BH);
  if (q && fr2 > .04) { ctx.globalAlpha = AM * fr2; ctx.drawImage(cle(A, ((i0 + 1) % NK) / NK + 1e-6), BX, BY, BW, BH); }   // fondu entre deux images clés : mouvement continu
  if (AC > .02) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = AM * .35 * AC; ctx.drawImage(f, BX, BY, BW, BH); }   // la prise rallume tout le corps
  if (NOANT) { ctx.restore(); return; }
  ctx.globalCompositeOperation = 'lighter';
  /* pulsation bioluminescente qui court le long du tube digestif (tête → queue), plus vive en portage */
  const gu = ((T * (.45 + .4 * AC) + ph * 3) % 1), gx = lerp(16, -19, gu), gy = (cy(gx) - dthA(gx) + cy(gx) + vthA(gx)) / 2 + .4, ga = Math.sin(Math.PI * gu);
  ctx.globalAlpha = AM * (.5 + .4 * AC) * ga * (q ? 1 : .7); ctx.drawImage(e.SA, gx - 4, gy - 3.5, 8, 7);
  if (q) { ctx.globalAlpha = AM * (.18 + .2 * AC) * ga; ctx.drawImage(e.SA, gx - 10, gy - 7, 20, 14); }
  /* antennes : grande paire couchée vers l'arrière (retard visco-élastique), petite paire vers l'avant ; deux passes + perles + pointes */
  const L1 = q ? 38 : 26, E = e.ant6 || (e.ant6 = new Float32Array(16));
  ctx.beginPath();
  for (let k2 = 0; k2 < 2; k2++) { const bx = 22, by = cy(22) - 2.6 - k2, a = -2.45 + .14 * k2 + .1 * Math.sin(T * 1.6 + k2 * 1.7 + ph * 6) - .03 * drag, L = L1 - 4 * k2;
    const c1x = bx + 8, c1y = by - 9, c2x = bx + Math.cos(a + .5) * L * .55, c2y = by + Math.sin(a + .5) * L * .55 - 4, ex = bx + Math.cos(a) * L, ey = by + Math.sin(a) * L + 2 * Math.sin(T * 2.3 + k2);
    ctx.moveTo(bx, by); ctx.bezierCurveTo(c1x, c1y, c2x, c2y, ex, ey);
    E[8 * k2] = c1x; E[8 * k2 + 1] = c1y; E[8 * k2 + 2] = c2x; E[8 * k2 + 3] = c2y; E[8 * k2 + 4] = ex; E[8 * k2 + 5] = ey; E[8 * k2 + 6] = bx; E[8 * k2 + 7] = by; }
  for (let k2 = 0; k2 < 2; k2++) { const bx = 23, by = cy(22) + .5; ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + 7, by + 1 + k2 * 2, bx + 13 + k2 * 2, by + 3 + 2 * Math.sin(T * 2.8 + k2)); }
  if (q) { ctx.strokeStyle = e.K1; ctx.globalAlpha = AM * (.05 + .05 * AC); ctx.lineWidth = 1.3; ctx.stroke(); }
  ctx.strokeStyle = e.K2; ctx.globalAlpha = AM * (q ? .42 : .34); ctx.lineWidth = q ? .45 : .5; ctx.stroke();
  if (q) {   // base épaisse (pédoncule), perles des articles du flagelle, pointe lumineuse
    ctx.beginPath(); for (let k2 = 0; k2 < 2; k2++) { const bx = E[8 * k2 + 6], by = E[8 * k2 + 7]; ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + 3, by - 3.6, E[8 * k2] * .4 + bx * .6, E[8 * k2 + 1] * .5 + by * .5); }
    ctx.strokeStyle = e.K1; ctx.globalAlpha = AM * .1; ctx.lineWidth = 1.6; ctx.stroke();
    for (let k2 = 0; k2 < 2; k2++) { const bx = E[8 * k2 + 6], by = E[8 * k2 + 7];
      for (let j = 1; j <= 6; j++) { const t = .25 + j * .115, u = 1 - t, px = u * u * u * bx + 3 * u * u * t * E[8 * k2] + 3 * u * t * t * E[8 * k2 + 2] + t * t * t * E[8 * k2 + 4], py = u * u * u * by + 3 * u * u * t * E[8 * k2 + 1] + 3 * u * t * t * E[8 * k2 + 3] + t * t * t * E[8 * k2 + 5];
        const v = .5 + .5 * Math.sin(T * 3 - j * .9 + k2); ctx.globalAlpha = AM * ((.18 + .3 * v) * (1 - .4 * k2) + .2 * AC); ctx.drawImage(e.SW, px - 1, py - 1, 2, 2); }
      ctx.globalAlpha = AM * (.55 + .35 * AC); ctx.drawImage(e.SW, E[8 * k2 + 4] - 1.8, E[8 * k2 + 5] - 1.8, 3.6, 3.6); }
  }
  ctx.restore();
}
/* nage normale, ou virage avec entrée/sortie fondues sur 7 % (même silhouette : la jonction ne se voit pas) */
function nageur(ctx, e, x, y, TV, pv, s, tilt, T, ph, AC, q, drag, Rl, Dl) {
  if (pv < 0) { corpsAmphi(ctx, e, x, y, TV.f, s, tilt, T, ph, AC, q, drag); return; }
  const k = ss(pv / .07) * (1 - ss((pv - .93) / .07)), P = poseTour(pv), o = decalTour(P, Rl, Dl), am = AM;
  if (k < .99) { AM = am * Math.min(1, 2 * (1 - k)); NOANT = 1; corpsAmphi(ctx, e, x, y, pv < .5 ? TV.fr : TV.to, s, tilt, T, ph, AC, q, drag); NOANT = 0; }
  AM = am * Math.min(1, 2 * k); AML = am; tourAmphi(ctx, e, x, y, TV.fr, s, tilt, T, P, o, AC, q, drag, ph); AM = am; AML = 1;
  return o;
}
function dessinerAmphi(ctx, e, x, y, etat, st, b, T, dt, fr, run, H) {
  teintes(e, H, 'amphi'); atlasAmphi(H); atlasTour(e.c.banc); budget = 0; tbud = 0;
  const FL = racine.FLUID, c = e.c, s0 = c.s || 1.25;   // R488 : +25 %
  st = run ? st : {};
  const held = run && st.h && b;
  const p = FL.e6Corps(c, fr, st, held ? b : null), py = p[1] + 10.5 + 16.3 * s0 - 3 - (c.lift || 12);   // le dos (arc) juste sous la particule portée
  let px = p[0];
  const cap = held ? st.dir : FL.e6Cap(c, run ? Math.max(fr, 12) : 12);   // R496 : au départ, déjà tourné vers où il va (pas de demi-tour à l'arrêt)
  const TV = e.tv || (e.tv = {}), jet = held && st.tq && fr - st.in < st.tnf;
  if (!run) { TV.f = cap < 0 ? -1 : 1; TV.p = -1; }
  if (jet) { TV.p = Math.max(0, Math.min(.999, (fr - st.in) / st.tnf)); TV.fr = -st.dir; TV.to = st.dir; TV.f = TV.fr; TV.jt = 1; }   // R496 : jet = même horloge que la physique
  else if (TV.jt) { TV.jt = 0; TV.p = -1; TV.f = held ? st.dir : TV.to; }
  const pv = jet ? TV.p : virage(TV, cap, dt, held ? 1 : 1.75), sx = pv < 0 ? TV.f : pv < .5 ? TV.fr : TV.to;
  const vy = e.py0 == null ? 0 : (py - e.py0) / Math.max(dt * 60, .3); e.py0 = py;
  e.vyS = (e.vyS || 0) + (vy - (e.vyS || 0)) * Math.min(1, dt * 4);
  const AC0 = held ? 1 : e.ac; e.acS = (e.acS || 0) + (AC0 - (e.acS || 0)) * Math.min(1, dt * (held ? 10 : 2)); const AC = e.acS, bob = held ? 0 : 1.4 * Math.sin(e.tl * .9 + e.ph);
  /* R496 : avant le lâcher, il nage déjà (sur place, coups de pléopodes vers son cap) ; au lâcher il rejoint sa route sans à-coup */
  if (!run) e.sg = sx * (6 * Math.sin(T * 1.6 + e.ph) + 2 * Math.sin(T * 3.2 + e.ph)); else if (e.sg) e.sg *= Math.exp(-dt * 2.5);
  px += e.sg || 0;
  e.phA = ((e.phA || 0) + dt * (.5 + .45 * Math.max(AC, run ? 0 : .5))) % 1;   // cycle de nage (≈ 2 s au repos, plus vif en portage)
  const tilt = Math.max(-.3, Math.min(.3, e.vyS * .08 * (sx > 0 ? 1 : -1))) + .04 * Math.sin(e.tl * .7 + e.ph);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  /* banc de figurants : plus petits et plus pâles (profondeur), suivent la route avec retard, en quinconce ; même virage (atlas réduit) */
  const n = c.banc || 0;
  for (let j = 0; j < n; j++) {
    const lag = 28 * (j + 1), q = FL.e6Route(c, fr - lag), cj = FL.e6Cap(c, fr - lag), oy = (j % 2 ? -1 : 1) * (14 + 8 * j) - 6, sc = .42 + .1 * hs(j * 4.4);
    const tt = T + j * 1.7, fx = q[0] - cj * (18 + 6 * j) + 4 * Math.sin(tt * .7), fy = q[1] + oy + 3 * Math.sin(tt * .9 + j);
    const fT = e.fT || (e.fT = []), o2 = fT[j] || (fT[j] = {}), pj = virage(o2, cj, dt, 1.65);
    nageur(ctx, e, fx, fy, o2, pj, sc, .05 * Math.sin(tt), tt, e.phA + .29 * (j + 1), 0, 0, 0, 11, 12);
  }
  let ox = 0, oy = 0;
  if (pv >= 0) { const o = decalTour(poseTour(pv), held ? 3 : 11, held ? 4 : 12); ox = TV.fr * s0 * o[0]; oy = s0 * o[1]; }
  H.ombre(ctx, e, px + ox, py + 10 * s0, 26 * s0, 9, 0, .5);
  ctx.globalCompositeOperation = 'lighter';
  H.spr(ctx, e.SG, px + ox, py + oy, 32 * s0 + 10 * AC, .12 + .16 * AC);
  ctx.globalCompositeOperation = 'source-over';
  nageur(ctx, e, px, py + bob, TV, pv, s0, tilt, T, e.phA, AC, 1, held ? -3 * st.spd : -(e.vit || 0) * 2, held ? 3 : 11, held ? 4 : 12);
  if (held) { const vv = st.spd || 3; ctx.globalCompositeOperation = 'lighter'; ctx.beginPath();   // sillage : filets d'eau derrière le porteur
    for (let k2 = 0; k2 < 3; k2++) { const yy = py - 4 + k2 * 5, x0 = px - st.dir * 24, L = 10 + 5 * vv + 4 * Math.sin(T * 5 + k2); ctx.moveTo(x0, yy); ctx.quadraticCurveTo(x0 - st.dir * L * .5, yy + 2 * Math.sin(T * 6 + k2), x0 - st.dir * L, yy); }
    ctx.strokeStyle = e.KA; ctx.globalAlpha = .1; ctx.lineWidth = 2.4; ctx.stroke(); ctx.globalAlpha = .35; ctx.lineWidth = .7; ctx.stroke();
    H.spr(ctx, e.SA, b.x, b.y + 6, 16, .25 + .1 * Math.sin(T * 5)); }   // la particule portée éclaire le dos
  bulles(ctx, e, px + ox - sx * 8, py + oy + 6, T * 1.3, 4, 38, .3);
  ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
racine.QXE6 = { coque: dessinerCoque, amphi: dessinerAmphi, _tour: { pose: poseTour, PK: PK, cle: amphiTourCle } };
})(window);
/* ===== ETAGE 6 FIN ===== */
