/* ============================================================
   visuals.js — rendu R33 (direction validée sur les aperçus)
   Portée privée : un seul nom global exposé, VX (évite toute collision
   avec les identifiants courts d'engine.js — handbook §9.1).
   Règle : la surface visible d'un mur est EXACTEMENT sa ligne de collision ;
   toute la structure décorative est dessinée derrière.
   Couleurs : jetons du handbook §6 et leurs nuances uniquement.
   ============================================================ */
(function(){
'use strict';
var VW=360,VH=480;
var C={matter:[77,215,255],boost:[166,120,255],reward:[255,216,90],goal:[155,235,75],danger:[255,82,82],
       bounce:[255,170,60],white:[234,246,255],pink:[242,160,200],ember:[176,72,28]};
function rgba(c,a){return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';}
function mix(a,b,s){return [a[0]+(b[0]-a[0])*s|0,a[1]+(b[1]-a[1])*s|0,a[2]+(b[2]-a[2])*s|0];}
function rnd(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function now(){return (typeof S!=='undefined'&&S.tick)||0;}
var PAL_W={1:[C.matter,C.boost],2:[C.bounce,C.ember,C.danger,C.reward],3:[C.boost,C.matter],4:[C.white,C.matter],
  5:[C.white,C.boost],6:[C.reward,C.matter],7:[C.goal,C.matter],8:[C.boost,C.matter],9:[C.matter,C.boost],
  10:[C.pink,C.boost],11:[C.boost,C.matter,C.reward]};

/* ---------- géométrie d'un segment : normale « derrière » la surface ---------- */
function geom(s){var dx=s[2]-s[0],dy=s[3]-s[1],len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,nx=-uy,ny=ux;
 if(Math.abs(ny)<.2){nx=s[0]<VW/2?-1:1;ny=0;}else if(ny<0){nx=-nx;ny=-ny;}
 return {len:len,ux:ux,uy:uy,nx:nx,ny:ny};}

/* ============================ DÉCOR PAR NIVEAU ============================ */
var D={key:-1,neb:[],hel:[],ghost:null,dust:[],tracks:[],bubbles:[],embers:[],pal:[C.matter,C.boost],wd:1,busOn:false,
 ring:null,rays:[],flash:[],pv:null};
function veil(seed,pal,keys){var cv=document.createElement('canvas');cv.width=VW;cv.height=VH;var g=cv.getContext('2d');
 g.globalCompositeOperation='lighter';
 function blob(x,y,r,col,a){var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,a));gr.addColorStop(.55,rgba(col,a*.35));gr.addColorStop(1,rgba(col,0));g.fillStyle=gr;g.fillRect(0,0,VW,VH);}
 var i;for(i=0;i<keys.length;i++)blob(keys[i][0],keys[i][1],keys[i][2],keys[i][3],keys[i][4]);
 for(i=0;i<8;i++)blob(rnd(seed+i)*VW,rnd(seed+i*3.1)*VH,60+rnd(seed+i*7.7)*140,pal[i%pal.length],.04+rnd(seed+i*1.9)*.07);
 for(i=0;i<22;i++){var x=rnd(seed*2+i)*VW,y=rnd(seed*3+i)*VH,r=20+rnd(seed*5+i)*50,col=pal[i%pal.length];
  var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,.05));gr.addColorStop(1,rgba(col,0));
  g.save();g.translate(x,y);g.rotate(rnd(i)*3);g.scale(2.7,.35);g.translate(-x,-y);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r);g.restore();}
 return cv;}

function compose(lv){
 var seed=(lv.idx||0)*17+3,wd=lv.wd||1,pal=PAL_W[wd]||PAL_W[1],i,k,s;D.wd=wd;D.pal=pal;D.key=lv.idx;
 var z=lv.zone||[0,0,1,1];
 var sx=0,sy=0;for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];var dx=s[2]-s[0],dy=s[3]-s[1],a=Math.atan2(dy,dx)*2,l=Math.hypot(dx,dy);sx+=Math.cos(a)*l;sy+=Math.sin(a)*l;}
 var dom=(sx||sy)?Math.atan2(sy,sx)/2:Math.PI/2;
 var occ=[];for(i=0;i<lv.walls.length;i++){s=lv.walls[i];var n=Math.ceil(Math.hypot(s[2]-s[0],s[3]-s[1])/8);for(k=0;k<=n;k++)occ.push([s[0]+(s[2]-s[0])*k/n,s[1]+(s[3]-s[1])*k/n]);}
 for(var x=z[0];x<=z[0]+z[2];x+=10)for(var y=z[1];y<=z[1]+z[3];y+=12)occ.push([x,y]);
 if(lv.port)lv.port.forEach(function(q){[[q[0],q[1]],[q[2],q[3]]].forEach(function(m){for(var r=0;r<=44;r+=11){var nn=r?10:1;for(var a=0;a<nn;a++)occ.push([m[0]+Math.cos(a/nn*6.2832)*r,m[1]+Math.sin(a/nn*6.2832)*r]);}});for(var u=0;u<=10;u++)occ.push([q[0]+(q[2]-q[0])*u/10,q[1]+(q[3]-q[1])*u/10]);});   /* R311 : le décor reste loin des portails et de leur liaison */
 if(lv.star)occ.push(lv.star);for(y=lv.ball[1]-10;y<lv.ball[1]+140;y+=10)occ.push([lv.ball[0],y]);
 function far(x,y){var m=1e9;for(var j=0;j<occ.length;j++){var d=(occ[j][0]-x)*(occ[j][0]-x)+(occ[j][1]-y)*(occ[j][1]-y);if(d<m)m=d;}return Math.sqrt(m);}
 D.hel=[];var atomLv=(lv.bf||[]).some(function(q){return q&&q[6]==='atom';});
 if(!atomLv&&wd!==2&&wd!==4&&wd!==8)for(var h=0;h<(wd===9?1:3);h++){var best=null;   /* R311 : Faille = une seule hélice (décor moins systématique) */
  for(k=0;k<300;k++){var cx=20+rnd(seed+h*991+k)*320,cy=50+rnd(seed+h*577+k*1.3)*410;
   var ang=dom+[0,0,.3,-.3,Math.PI/2][Math.floor(rnd(seed+k*2.2)*5)],len=110+rnd(seed+k*3.7)*150;
   var x0=cx-Math.cos(ang)*len/2,y0=cy-Math.sin(ang)*len/2,x1=cx+Math.cos(ang)*len/2,y1=cy+Math.sin(ang)*len/2,clear=1e9;
   for(var q=0;q<=10;q++){var px=x0+(x1-x0)*q/10,py=y0+(y1-y0)*q/10;if(px<-40||px>VW+40||py<-40||py>VH+40){clear=0;break;}clear=Math.min(clear,far(px,py));}
   if(clear<30)continue;var sc=len*Math.min(clear,60);if(!best||sc>best.sc)best={x0:x0,y0:y0,x1:x1,y1:y1,sc:sc,clear:clear};}
  if(!best)break;
  D.hel.push({x0:best.x0,y0:best.y0,x1:best.x1,y1:best.y1,amp:Math.min(12,best.clear-16),turns:1.4+Math.hypot(best.x1-best.x0,best.y1-best.y0)/90,
   sp:(h%2?-1:1)*(.022+rnd(seed+h)*.014),a:pal[h%pal.length],b:pal[(h+1)%pal.length],al:.55-h*.1});
  for(q=0;q<=10;q++)occ.push([best.x0+(best.x1-best.x0)*q/10,best.y0+(best.y1-best.y0)*q/10]);}
 D.ghost=(!atomLv&&wd!==2&&wd!==4&&wd!==8&&wd!==9)?{x0:180-Math.cos(dom)*260,y0:240-Math.sin(dom)*260,x1:180+Math.cos(dom)*260,y1:240+Math.sin(dom)*260}:null;
 var keys=[[lv.ball[0],lv.ball[1],110,pal[0],.13],[z[0]+z[2]/2,z[1]+24,120,C.goal,.10]];
 if(wd===2)for(i=0;i<lv.walls.length;i++){s=lv.walls[i];if(s[4]===1)keys.push([(s[0]+s[2])/2,(s[1]+s[3])/2+10,90,C.bounce,.16]);}
 D.neb=[veil(seed,pal,keys),veil(seed+31,pal.slice().reverse(),[])];
 D.dust=[];for(i=0;i<(wd===2?90:150);i++){var zz=.25+rnd(seed+i*2.3)*.75;
  D.dust.push({x:rnd(seed+i)*VW,y:rnd(seed+i*1.7)*VH,z:zz,ph:rnd(i*4.1)*6.28,vx:Math.cos(dom)*(.06+rnd(seed+i*6.1)*.12),vy:(wd===2?-.3-zz*.5:(Math.abs(Math.sin(dom))+.15)*.06),
   col:wd===2?(zz>.7?C.reward:C.bounce):[C.white,C.white,C.white].concat(pal)[i%(3+pal.length)]});}
 D.ring=null;D.rays=[];D.flash=[];D.pv=null;
 D.mech=[];if(wd===6){   /* R153 — MÉCANIQUE DÉCORATIVE : trains d'engrenages, bielle‑manivelle, échappement à ancre, posés là où le jeu laisse de la place */
  if(lv.mov)for(i=0;i<lv.mov.length;i++){var sg0=lv.mov[i].seg;for(k=0;k<=6;k++)occ.push([sg0[0]+(sg0[2]-sg0[0])*k/6,sg0[1]+(sg0[3]-sg0[1])*k/6]);}
  if(lv.pend)for(i=0;i<lv.pend.length;i++)occ.push([lv.pend[i][0],lv.pend[i][1]+lv.pend[i][2]]);
  var types=['train','crank','escape','train','cam'],nm=0;
  for(k=0;k<500&&nm<4;k++){var mx=24+rnd(seed*3+k*1.7)*312,my=40+rnd(seed*5+k*2.3)*400,ty=types[(Math.floor(rnd(seed+k*.7)*5)+nm)%5],kz=1.35+rnd(seed+k*9.1)*.45,RR=(ty==='train'?52:ty==='escape'?46:40)*kz;
   if(far(mx,my)<RR+6)continue;var ok2=true;for(var q2=0;q2<D.mech.length;q2++)if(Math.hypot(D.mech[q2].x-mx,D.mech[q2].y-my)<D.mech[q2].R+RR+10)ok2=false;if(!ok2)continue;
   D.mech.push({t:ty,x:mx,y:my,R:RR,k:kz,s:.6+rnd(seed+k*4.1)*.5,ph:rnd(seed+k*6.1)*6.28,d:rnd(seed+k*8.3)<.5?-1:1});nm++;}}
 if(wd===3){/* anneau de stockage : 2 lignes droites + 2 arcs, aimants de courbure, cavité RF, lignes de lumière tangentes */
  var rx=172,ry=112,cx0=180,cy0=250,rr=ry,sl=rx-rr,mags=[],k2;
  for(k2=0;k2<6;k2++){var side=k2<3?1:-1,ang2=(k2%3-1)*.75;mags.push({side:side,ang:ang2});}
  D.ring={cx:cx0,cy:cy0,r:rr,sl:sl,mags:mags,bunches:[0,.25,.5,.75],cav:.08};
  D.hel=[];D.ghost=null;}
 D.tracks=[];D.bubbles=[];if(wd===2)for(i=0;i<50;i++)D.bubbles.push({x:rnd(seed+i)*VW,y:rnd(seed+i*2.2)*VH,r:.6+rnd(seed+i*3.3)*1.8,sp:.15+rnd(seed+i*4.4)*.35,ph:rnd(i)*6.28});
}
function spawnTrack(x,y,ang,sp,strong){D.tracks.push({pts:[[x,y]],x:x,y:y,a:ang,v:sp,q:Math.random()<.5?-1:1,k:.018+Math.random()*.03,age:0,life:strong?260:190,col:strong?C.reward:(Math.random()<.5?C.bounce:C.white)});}

function ringAt(R,u){var L1=2*R.sl,La=Math.PI*R.r,P=2*L1+2*La,d=((u%1)+1)%1*P,x,y,tx,ty;
 if(d<L1){x=R.cx-R.sl+d;y=R.cy-R.r;tx=1;ty=0;}
 else if(d<L1+La){var a=-Math.PI/2+(d-L1)/R.r;x=R.cx+R.sl+Math.cos(a)*R.r;y=R.cy+Math.sin(a)*R.r;tx=-Math.sin(a);ty=Math.cos(a);}
 else if(d<2*L1+La){x=R.cx+R.sl-(d-L1-La);y=R.cy+R.r;tx=-1;ty=0;}
 else{var a2=Math.PI/2+(d-2*L1-La)/R.r;x=R.cx-R.sl+Math.cos(a2)*R.r;y=R.cy+Math.sin(a2)*R.r;tx=-Math.sin(a2);ty=Math.cos(a2);}
 return {x:x,y:y,tx:tx,ty:ty};}
function magAt(R,m){var a=m.ang;if(m.side>0)return {x:R.cx+R.sl+Math.cos(a)*R.r,y:R.cy+Math.sin(a)*R.r,tx:-Math.sin(a),ty:Math.cos(a)};
 return {x:R.cx-R.sl-Math.cos(a)*R.r,y:R.cy-Math.sin(a)*R.r,tx:Math.sin(a),ty:-Math.cos(a)};}
function drawRing(c){var R=D.ring,t=now(),i,k;c.save();c.globalCompositeOperation='lighter';
 // tube de l'anneau
 c.strokeStyle=rgba(C.boost,.08);c.lineWidth=7;c.beginPath();for(k=0;k<=120;k++){var q=ringAt(R,k/120);if(k)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.stroke();
 c.strokeStyle=rgba(C.boost,.2);c.lineWidth=1;c.stroke();
 // lignes de lumière tangentes (éventail synchrotron) depuis chaque aimant de courbure, parcourues d'impulsions
 for(i=0;i<R.mags.length;i++){var m=magAt(R,R.mags[i]),L=260;
  var gr=c.createLinearGradient(m.x,m.y,m.x+m.tx*L,m.y+m.ty*L);gr.addColorStop(0,rgba(C.matter,.22));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=1.2;c.beginPath();c.moveTo(m.x,m.y);c.lineTo(m.x+m.tx*L,m.y+m.ty*L);c.stroke();
  var pp=((t*1.6+i*37)%L);c.fillStyle=rgba(C.white,.55*(1-pp/L));c.fillRect(m.x+m.tx*pp-1.5,m.y+m.ty*pp-1.5,3,3);
  c.save();c.translate(m.x,m.y);c.rotate(Math.atan2(m.ty,m.tx));c.fillStyle=rgba(C.boost,.3);c.fillRect(-7,-4,14,8);c.strokeStyle=rgba(C.white,.2);c.lineWidth=.8;c.strokeRect(-7,-4,14,8);c.restore();}
 // cavité RF de l'anneau (chaîne de bulbes sur la ligne droite du haut)
 for(k=0;k<5;k++){var cq=ringAt(R,R.cav+k*.012);c.strokeStyle=rgba(C.reward,.35);c.lineWidth=1;c.beginPath();c.ellipse(cq.x,cq.y,4.5,6.5,0,0,6.2832);c.stroke();}
 // paquets de particules : vitesse FIXE (la cavité maintient l'énergie), flash au passage de la cavité
 for(i=0;i<R.bunches.length;i++){var u=(R.bunches[i]+t*.0022)%1,b=ringAt(R,u),inCav=u>R.cav-.01&&u<R.cav+.07;
  for(k=0;k<7;k++){var bk=ringAt(R,u-k*.004);c.fillStyle=rgba(k?C.boost:C.white,(inCav?.9:.5)*(1-k/7));c.beginPath();c.arc(bk.x,bk.y,k?1.4:2.2,0,6.2832);c.fill();}
  if(inCav){var g3=c.createRadialGradient(b.x,b.y,0,b.x,b.y,12);g3.addColorStop(0,rgba(C.reward,.5));g3.addColorStop(1,rgba(C.reward,0));c.fillStyle=g3;c.fillRect(b.x-12,b.y-12,24,24);}}
 c.restore();}
/* lumière synchrotron de la balle : quand elle tourne vite, un rayon part en tangente */
function synchro(c){var b=(typeof S!=='undefined'&&S.ball)?S.ball:null,t=now(),i;if(!b)return;
 var sp=Math.hypot(b.vx,b.vy),ang=Math.atan2(b.vy,b.vx);
 if(D.pv&&sp>3.5&&typeof S!=='undefined'&&S.mode==='run'){var da=Math.abs(((ang-D.pv.a+Math.PI*3)%(Math.PI*2))-Math.PI);
  if(da*sp>.22&&D.rays.length<18)D.rays.push({x:b.x,y:b.y,a:D.pv.a,l:55+sp*11,life:1,w:Math.max(1.6,Math.min(3.5,da*sp*1.4))});}
 D.pv={a:ang};
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.rays.length;i++){var r=D.rays[i],ex=r.x+Math.cos(r.a)*r.l,ey=r.y+Math.sin(r.a)*r.l,gr=c.createLinearGradient(r.x,r.y,ex,ey);
  gr.addColorStop(0,rgba(C.white,.95*r.life));gr.addColorStop(.3,rgba(C.boost,.6*r.life));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=r.w;c.lineCap='round';c.beginPath();c.moveTo(r.x,r.y);c.lineTo(ex,ey);c.stroke();r.life-=.03;}
 D.rays=D.rays.filter(function(q){return q.life>0;});
 for(i=0;i<D.flash.length;i++)D.flash[i].life-=.05;D.flash=D.flash.filter(function(q){return q.life>0;});
 c.restore();}
function helix(c,x0,y0,x1,y1,amp,turns,sp,cA,cB,al,N){
 var t=now(),dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len,pts=[],i;N=N||56;
 for(i=0;i<=N;i++){var s=i/N,ang=s*turns*6.2832+t*sp,bx=x0+dx*s,by=y0+dy*s,o=Math.sin(ang)*amp;
  pts.push({s:s,ang:ang,a:[bx+nx*o,by+ny*o],b:[bx-nx*o,by-ny*o],da:Math.cos(ang),db:-Math.cos(ang)});}
 function fade(s){return Math.min(1,s*6,(1-s)*6);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<=N;i+=3){var p=pts[i],f=(.35+.65*Math.abs(Math.sin(p.ang)))*fade(p.s);c.strokeStyle=rgba(mix(cA,cB,p.s),al*.45*f);c.lineWidth=1;
  c.beginPath();c.moveTo(p.a[0],p.a[1]);c.lineTo(p.b[0],p.b[1]);c.stroke();}
 var keys=['a','b'];for(var kk=0;kk<2;kk++){var key=keys[kk],dk=key==='a'?'da':'db';
  for(i=1;i<=N;i++){p=pts[i];var q=pts[i-1],d=(p[dk]+1)/2,col=mix(cA,cB,p.s),ff=fade(p.s);
   c.strokeStyle=rgba(col,al*(.08+.18*d)*ff);c.lineWidth=4+d*4;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();
   c.strokeStyle=rgba(col,al*(.25+.75*d)*ff);c.lineWidth=.8+d*1.6;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();}}
 c.restore();}

/* ============================ VOILES DE POINTS (R38) ============================
   Plusieurs couches translucides de nuages de points en rotation 3D, superposées : la transparence
   cumulée donne la profondeur (références : vidéos d'illusions bistables). Une volumétrie par monde ;
   le monde 4 y ajoute les franges de deux sources (fentes de Young), un réseau de tourbillons et un
   condensat qui se contracte en pic. Tout est calculé point par point, sans image. */
var VL={wd:-1,layers:[]};
function vlShape(kind,n,seed){
 var out=[],i,x,y,z,r,a,th,ph,q,GA=2.39996323;
 if(kind==='globe'){ /* six grands cercles d'orientations différentes : un globe fait de fils de points */
  var m=Math.round(n/6),ci,cj,u,ax,ay,az,px,py,pz,ca,sa;
  for(ci=0;ci<6;ci++){ax=ci*1.0472;ay=(ci%3)*.9+.3;
   for(cj=0;cj<m;cj++){u=cj/m*6.2832;px=Math.cos(u);py=Math.sin(u);pz=0;
    ca=Math.cos(ax);sa=Math.sin(ax);var y2=py*ca-pz*sa,z2=py*sa+pz*ca;
    ca=Math.cos(ay);sa=Math.sin(ay);out.push([px*ca+z2*sa,y2,-px*sa+z2*ca]);}}
  out.ring=m;return out;}
 if(kind==='disk'){for(i=0;i<n;i++){var u=rnd(seed+i*1.9),arm=i%3,rr=Math.sqrt(u),aa=arm*2.0944+rr*4.2+(rnd(seed+i*2.3)-.5)*.5;out.push([Math.cos(aa)*rr,Math.sin(aa)*rr,(rnd(seed+i*3.1)-.5)*.12*(1-rr)]);}return out;}   /* R153 : galaxie spirale */
 if(kind==='knot'){for(i=0;i<n;i++){var tt=i/n*6.2832,k3=Math.cos(3*tt)*.45+1;out.push([k3*Math.cos(2*tt)*.62,k3*Math.sin(2*tt)*.62,Math.sin(3*tt)*.4]);}return out;}   /* nœud de trèfle */
 if(kind==='lattice'){var m3=Math.max(3,Math.round(Math.cbrt(n)));for(var a1=0;a1<m3;a1++)for(var b1=0;b1<m3;b1++)for(var c1=0;c1<m3;c1++)out.push([a1/(m3-1)*1.4-.7,b1/(m3-1)*1.4-.7,c1/(m3-1)*1.4-.7]);return out;}   /* réseau cristallin */
 if(kind==='cyl'){for(i=0;i<n;i++){var tc=i/n,ac=tc*6.2832*7;out.push([Math.cos(ac)*.55,tc*2-1,Math.sin(ac)*.55]);}return out;}   /* solénoïde */
 for(i=0;i<n;i++){
  if(kind==='torus'){th=rnd(seed+i*1.7)*6.2832;ph=rnd(seed+i*2.9+5)*6.2832;
   x=(1+.34*Math.cos(ph))*Math.cos(th);y=(1+.34*Math.cos(ph))*Math.sin(th);z=.34*Math.sin(ph);out.push([x*.72,y*.72,z*.72]);continue;}
  z=1-2*(i+.5)/n;r=Math.sqrt(1-z*z);a=i*GA;x=Math.cos(a)*r;y=Math.sin(a)*r;
  if(kind==='tetra'){q=1+1.5*x*y*z;x*=q;y*=q;z*=q;}
  else if(kind==='shell2'){q=(i%2)?1:.62;x*=q;y*=q;z*=q;}
  out.push([x,y,z]);}
 return out;}
/* R147 — TEXTURE FINE (demande de Simon : plus petite échelle, plus de transparences, finesse, aucune sphère) :
   trois nappes de fils de soie très fins dont les angles diffèrent un peu — leur superposition fait naître un moiré qui
   glisse lentement ; un grain d'étoiles qui suit les mêmes ondes ; chaque fil a sa propre transparence. */
function vlSilk(wd){var L=VL.layers=[],pal=PAL_W[wd]||PAL_W[1],A=pal[0],B=pal[1]||pal[0],Cc=pal[2]||A,i;
 /* R148 : cinq échelles (maille de 4 à 24 u), cinq opacités — plus dense, plus profond */
 var defs=[[-.42,4.2,.085,.005,A,.08,.35],[-.30,6.5,.05,-.0035,B,.11,.45],[.95,9.5,.032,.003,Cc,.09,.55],[.18,15,.022,-.0022,A,.075,.7],[-1.2,24,.014,.0016,B,.06,.9]];
 for(i=0;i<defs.length;i++){var d=defs[i];L.push({silk:1,rot:d[0]+((wd*.37)%.3),gap:d[1],k:d[2],sp:d[3],c1:d[4],a:d[5],lw:d[6],ph:i*2.1+wd});}
 var g=[];for(i=0;i<900;i++)g.push([rnd(wd*13+i*1.3)*VW,rnd(wd*7+i*2.1)*VH,rnd(i*3.7+wd)]);
 L.push({grain:g,c1:B,c2:A,a:.5});VL.wd=wd;}
function vlSilkDraw(c,l,t){var ca=Math.cos(l.rot),sa=Math.sin(l.rot),D2=Math.hypot(VW,VH),n=Math.ceil(D2/l.gap)+2,j,x,b,st=l.gap<6?12:9;
 c.lineWidth=l.lw||.55;c.strokeStyle=rgba(l.c1,1);
 for(var bk=0;bk<3;bk++){c.globalAlpha=l.a*(.35+.45*bk);c.beginPath();
  for(j=0;j<n;j++){var ph=l.ph+j*1.618;if(((Math.sin(ph*3.1)+1)*1.5|0)!==bk)continue;   /* trois familles de transparence */
   b=-D2/2+j*l.gap;var first=true;
   for(x=-D2/2;x<=D2/2;x+=st){var w=b+Math.sin(x*l.k+ph+t*l.sp)*l.gap*.9+Math.sin(x*l.k*2.3-t*l.sp*1.7+j*.4)*l.gap*.35,
     px=VW/2+x*ca-w*sa,py=VH/2+x*sa+w*ca;if(first){c.moveTo(px,py);first=false;}else c.lineTo(px,py);}}
  c.stroke();}}
function vlGrainDraw(c,l,t){var i,g;
 for(i=0;i<l.grain.length;i++){g=l.grain[i];var x=(g[0]+t*(.04+g[2]*.08))%VW,y=g[1]+Math.sin(x*.03+g[2]*6+t*.004)*6,
   tw=.5+.5*Math.sin(t*(.02+g[2]*.05)+g[2]*40),sz=.45+g[2]*.9;
  c.globalAlpha=l.a*tw*(.15+.6*g[2]);c.fillStyle=rgba(g[2]>.6?l.c1:l.c2,1);c.fillRect(x,y,sz,sz);}}
/* R148 — MYCÉLIUM DE LUMIÈRE : un réseau de capillaires qui pousse depuis les bords (marche au hasard, embranchements) ;
   dessiné une fois dans un calque, très pâle ; des éclats cosmiques le parcourent, se divisent aux fourches et laissent
   derrière eux une traînée qui s'éteint — l'influx qui court dans un mycélium. */
var MY=null;
function myBuild(wd){var segs=[],tips=[],i,sd=wd*101+7,n=0;
 for(i=0;i<5;i++){var e=i%4,x0=e===0?0:e===1?VW:rnd(sd+i)*VW,y0=e===2?0:e===3?VH:rnd(sd+i*3)*VH,a0=Math.atan2(VH/2-y0,VW/2-x0)+(rnd(sd+i*5)-.5);
  tips.push({x:x0,y:y0,a:a0,p:-1,d:0});}
 while(tips.length&&segs.length<1400){var tp=tips.shift();n++;var st=7+rnd(sd+n*1.3)*5,na=tp.a+(rnd(sd+n*2.7)-.5)*.38,x1=tp.x+Math.cos(na)*st,y1=tp.y+Math.sin(na)*st;
  if(x1<-6||x1>VW+6||y1<-6||y1>VH+6||tp.d>140)continue;
  var id=segs.length;segs.push({x0:tp.x,y0:tp.y,x1:x1,y1:y1,p:tp.p,ch:[],g:0,w:Math.max(.25,.9-tp.d*.006)});if(tp.p>=0)segs[tp.p].ch.push(id);
  tips.push({x:x1,y:y1,a:na,p:id,d:tp.d+1});
  if(rnd(sd+n*4.1)<.05)tips.push({x:x1,y:y1,a:na+(rnd(sd+n*5.3)<.5?-1:1)*(.5+rnd(sd+n*6.7)*.5),p:id,d:tp.d+1});}
 var cv=null;try{cv=document.createElement('canvas');cv.width=VW*2;cv.height=VH*2;var g=cv.getContext('2d');g.scale(2,2);g.lineCap='round';
  for(i=0;i<segs.length;i++){var sg=segs[i];g.strokeStyle='rgba(255,255,255,'+(.04+.05*sg.w).toFixed(3)+')';g.lineWidth=sg.w*.42;g.beginPath();g.moveTo(sg.x0,sg.y0);g.lineTo(sg.x1,sg.y1);g.stroke();}}catch(e){cv=null;}
 var roots=[];for(i=0;i<segs.length;i++)if(segs[i].p<0)roots.push(i);
 MY={wd:wd,segs:segs,cv:cv,roots:roots,sp:[],pal:PAL_W[wd]||PAL_W[1]};}
function myDraw(c,t){if(!MY||MY.wd!==D.wd)myBuild(D.wd);var M=MY,i,k,sg;
 if(M.cv){c.globalAlpha=.9;c.drawImage(M.cv,0,0,VW,VH);}
 if(Math.random()<.03&&M.sp.length<9)M.sp.push({s:M.roots[(Math.random()*M.roots.length)|0],u:0,v:.14+Math.random()*.1,c:C.white,n:0,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null});   /* R149 : éclats rares, un sur cinq vire au chaud */   /* un nouvel éclat part d'une racine */
 for(i=M.sp.length-1;i>=0;i--){var p=M.sp[i];p.u+=p.v;sg=M.segs[p.s];sg.g=.7;var wf=p.warm?Math.min(1,p.n/45):0;sg.c=p.warm?[255+(p.warm[0]-255)*wf|0,255+(p.warm[1]-255)*wf|0,255+(p.warm[2]-255)*wf|0]:[200,232,255];p.cc=sg.c;
  if(p.u>=1){p.u=0;p.n++;if(!sg.ch.length){M.sp.splice(i,1);continue;}p.s=sg.ch[0];if(sg.ch.length>1&&M.sp.length<10&&Math.random()<.5)M.sp.push({s:sg.ch[1],u:0,v:p.v*.9,c:p.c,n:p.n,warm:p.warm});}}
 c.lineCap='round';
 for(i=0;i<M.segs.length;i++){sg=M.segs[i];if(sg.g<.02)continue;c.strokeStyle=rgba(sg.c||C.white,1);c.globalAlpha=sg.g*.42;c.lineWidth=sg.w*.6+sg.g*.6;c.beginPath();c.moveTo(sg.x0,sg.y0);c.lineTo(sg.x1,sg.y1);c.stroke();sg.g*=.93;}
 for(i=0;i<M.sp.length;i++){var q=M.sp[i];sg=M.segs[q.s];var x=sg.x0+(sg.x1-sg.x0)*q.u,y=sg.y0+(sg.y1-sg.y0)*q.u,gr=c.createRadialGradient(x,y,0,x,y,5);
  gr.addColorStop(0,rgba(q.cc||C.white,.8));gr.addColorStop(1,rgba(q.cc||C.white,0));c.globalAlpha=1;c.fillStyle=gr;c.fillRect(x-5,y-5,10,10);}
 c.globalAlpha=1;}
function vlBuild(wd,key){
 MY=null;VL.key=key;if(wd===8)return vlSilk(wd);   /* R153 : voiles en volume rétablis dans chaque monde ; la soie ne reste qu'au Magnétisme */
 var L=VL.layers=[],pal=PAL_W[wd]||PAL_W[1],A=pal[0],B=pal[1]||pal[0];
 var kinds={1:['globe','globe','shell2'],2:['tetra','tetra','tetra'],3:['torus','torus','torus'],4:['globe','shell2','globe'],
  5:['disk','shell2','cyl'],6:['lattice','torus','lattice'],7:['disk','shell2','disk'],9:['knot','torus','knot'],10:['knot','cyl','knot'],11:['shell2','tetra','lattice']}[wd]||['globe','shell2','globe'];
 var defs=[[.76,.28,190,.30,.0026,300],[.16,.72,74,.40,-.0046,420],[.60,.90,34,.5,.0067,240]],K=(key||0)+1,ord=[0,1,2];
 if(rnd(K*7.7)<.5)ord=[1,0,2];   /* R153 : chaque niveau compose ses voiles autrement (position, taille, ordre) */
 for(var i=0;i<defs.length;i++){var d=defs[i],jx=(rnd(K*3.1+i)-.5)*.34,jy=(rnd(K*5.3+i)-.5)*.3,js=.75+rnd(K*9.7+i)*.5;
  L.push({pts:vlShape(kinds[ord[i]],d[5],wd*31+i*7),cx:Math.max(.1,Math.min(.9,d[0]+jx))*VW,cy:Math.max(.1,Math.min(.92,d[1]+jy))*VH,R:d[2]*js,a:d[3],sp:d[4]*(rnd(K*2.9+i)<.5?-1:1),ph:i*1.7+K,c1:i%2?B:A,c2:i%2?A:B,tilt:.5+i*.35+rnd(K+i)*.6});}
 VL.wd=wd;}
function vlDrawLayer(c,l,t,sc,alphaMul){
 var ry=t*l.sp+l.ph,rx=l.tilt+Math.sin(t*.0021+l.ph)*.25,cy_=Math.cos(ry),sy=Math.sin(ry),cx_=Math.cos(rx),sx=Math.sin(rx),i,p,x,y,z,x1,z1,y1,z2,pr,al,s;
 if(l.pts.ring){ /* fils : chaque grand cercle est tracé en trait fin, face avant plus lumineuse que la face arrière */
  var m=l.pts.ring,rg,k,q,pp,xx,yy,zz,px_,py_,fr,last;
  c.lineWidth=.8;c.lineJoin='round';
  for(var ps=0;ps<2;ps++){
   c.strokeStyle=rgba(ps?l.c1:l.c2,1);c.globalAlpha=Math.min(1,l.a*alphaMul*(ps?1.5:.8));c.beginPath();
   for(rg=0;rg<6;rg++){last=false;
    for(k=0;k<=m;k++){q=l.pts[rg*m+(k%m)];xx=q[0]*sc;yy=q[1]*sc;zz=q[2]*sc;
     x1=xx*cy_+zz*sy;z1=-xx*sy+zz*cy_;y1=yy*cx_-z1*sx;z2=yy*sx+z1*cx_;
     fr=(z2>0)===(ps===1);
     if(fr){pr=1/(1-z2*.22);px_=l.cx+x1*l.R*pr;py_=l.cy+y1*l.R*pr;if(last)c.lineTo(px_,py_);else c.moveTo(px_,py_);last=true;}else last=false;}}
   c.stroke();}
  return;}
 for(var pass=0;pass<2;pass++){
  c.fillStyle=rgba(pass?l.c1:l.c2,1);
  for(i=0;i<l.pts.length;i++){
   p=l.pts[i];x=p[0]*sc;y=p[1]*sc;z=p[2]*sc;
   x1=x*cy_+z*sy;z1=-x*sy+z*cy_;y1=y*cx_-z1*sx;z2=y*sx+z1*cx_;
   if((z2>0)!==(pass===1))continue;
   pr=1/(1-z2*.22);al=l.a*alphaMul*(.35+.65*(z2+1.3)/2.3);
   s=(1.15+.85*pr)*(z2>0?1.2:.9);
   c.globalAlpha=al;c.fillRect(l.cx+x1*l.R*pr-s/2,l.cy+y1*l.R*pr-s/2,s,s);}}
}
function vlYoung(c,t){
 var src=[[VW*.28,VH*.06],[VW*.72,VH*.06]],k,j,r,al;
 c.save();c.lineWidth=.9;c.setLineDash([1.2,5.5]);
 for(j=0;j<2;j++){
  c.strokeStyle=rgba(j?C.matter:C.white,1);
  for(k=0;k<15;k++){r=(k*17+t*.32)%255;al=(1-r/255)*.42*Math.min(1,r/14);
   if(al<=.004)continue;c.globalAlpha=al;c.beginPath();c.arc(src[j][0],src[j][1],r,.15,Math.PI-.15);c.stroke();}}
 c.restore();}
function vlVortices(c,t){
 var cs=[[.30,.42,1.5],[.66,.32,.7],[.80,.62,1.05],[.18,.80,.6],[.56,.88,.85]],i,k,a,rr,n=16;
 c.save();
 for(i=0;i<cs.length;i++){
  var x0=cs[i][0]*VW,y0=cs[i][1]*VH,dir=(i%2)?-1:1,sp=t*.011*dir/(cs[i][2]*.8)+i,sz=cs[i][2];
  for(k=0;k<n*3;k++){
   var arm=k%3,u=(k/3|0)/n;a=sp+arm*2.0944+u*3.6*dir;rr=(3+u*22)*sz;
   c.globalAlpha=.4*(1-u*.8);c.fillStyle=rgba(u<.5?C.white:C.matter,1);
   c.fillRect(x0+Math.cos(a)*rr-.6,y0+Math.sin(a)*rr*.86-.6,1.5,1.5);}}
 c.restore();}
function vlCondensate(c,t){
 var ph=.5+.5*Math.sin(t*.0105),x=VW*.80,y=VH*.14,g;
 c.save();
 g=c.createRadialGradient(x,y,0,x,y,44+22*(1-ph));
 g.addColorStop(0,rgba(C.white,.05+.34*ph));g.addColorStop(.35,rgba(C.matter,.05+.13*ph));g.addColorStop(1,rgba(C.matter,0));
 c.fillStyle=g;c.fillRect(x-70,y-70,140,140);
 for(var k=0;k<46;k++){var a=k*2.39996+t*.004,r=(6+ (k*7)%44)*(1-.5*ph*(1-k/60));
  c.globalAlpha=.16+.3*ph*(1-k/60);c.fillStyle=rgba(C.white,1);c.fillRect(x+Math.cos(a)*r-.5,y+Math.sin(a)*r*.8-.5,1.2,1.2);}
 c.restore();}
function veils(c){
 if(VL.wd!==D.wd||VL.key!==D.key)vlBuild(D.wd,D.key);
 var t=now(),i,cond=(D.wd===4),mul=cond?1.15:1;
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<VL.layers.length;i++){
  var sc=1;if(cond&&i===0)sc=1-.16*(.5+.5*Math.sin(t*.0105));   /* le condensat respire : le nuage se resserre */
  var ly=VL.layers[i];if(ly.silk){if(!((FF_NOSILK||F3_ON)&&D.wd===8))vlSilkDraw(c,ly,t);continue;}   /* R170 : pas de fils droits sur le ferrofluide */if(ly.grain){vlGrainDraw(c,ly,t);continue;}
  vlDrawLayer(c,ly,t,sc,mul);}
 /* R153 : le réseau capillaire n'est plus dessiné (régression R148) — le Magnétisme a ses flux dans les veines */
 if(cond){vlYoung(c,t);vlVortices(c,t);vlCondensate(c,t);}
 c.globalAlpha=1;c.restore();}

/* ============================ MOTIFS R47 ============================
   torusCells : anneau de cellules en fil de fer, chacune semée de points qui scintillent, qui tourne lentement en 3D
   (vidéo de référence « quatrième dimension »). Placé dans la Chaîne (monde 3) : c'est l'anneau de stockage du synchrotron,
   découpé en aimants.
   ferro : texture de ferrofluide (vidéo de référence) — labyrinthe de domaines produit par une réaction‑diffusion
   (Gray‑Scott, régime « labyrinthe ») sur une petite grille, qui s'organise autour d'un aimant. Placé dans Magnétisme
   (monde 8). Calcul : 64 × 86 cellules, 3 itérations par image. */
var TC=null;
function tcBuild(){var N=16,cells=[],i,k;
 for(i=0;i<N;i++){var pts=[];for(k=0;k<9;k++)pts.push([rnd(i*13+k*3.1),rnd(i*7+k*5.3+1),rnd(i*3+k*2.7+2),rnd(i+k*11.3)]);cells.push(pts);}
 TC={N:N,cells:cells};}
function torusCells(c,cx,cy,Rm,rm,alpha){
 if(!TC)tcBuild();var t=now(),N=TC.N,ax=.95+Math.sin(t*.0009)*.25,az=t*.0016,ay=Math.sin(t*.0006)*.35;
 var cxa=Math.cos(ax),sxa=Math.sin(ax),cza=Math.cos(az),sza=Math.sin(az),cya=Math.cos(ay),sya=Math.sin(ay);
 function P(th,ph,h){ /* th : angle autour de l'anneau ; ph : position dans l'épaisseur (−1 intérieur, +1 extérieur) ; h : hauteur */
  var r=Rm+ph*rm,x=Math.cos(th)*r,y=Math.sin(th)*r,z=h*rm*.9;
  var x1=x*cza-y*sza,y1=x*sza+y*cza;            /* rotation propre de l'anneau */
  var y2=y1*cxa-z*sxa,z2=y1*sxa+z*cxa;          /* inclinaison */
  var x3=x1*cya+z2*sya,z3=-x1*sya+z2*cya;
  var pr=1/(1-z3/(Rm*4));return [cx+x3*pr,cy+y2*pr,z3];}
 c.save();c.globalCompositeOperation='lighter';c.lineWidth=.8;
 var i,k,a0,a1,q;
 for(i=0;i<N;i++){a0=i/N*6.2832;a1=(i+1)/N*6.2832;var gap=.035;
  var cs=[P(a0+gap,-1,-1),P(a1-gap,-1,-1),P(a1-gap,1,-1),P(a0+gap,1,-1),P(a0+gap,-1,1),P(a1-gap,-1,1),P(a1-gap,1,1),P(a0+gap,1,1)];
  var depth=(cs[0][2]+cs[6][2])/2,fa=alpha*(.45+.55*(depth/(Rm+rm)+1)/2);
  c.strokeStyle=rgba(C.white,fa);c.beginPath();
  [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){c.moveTo(cs[e[0]][0],cs[e[0]][1]);c.lineTo(cs[e[1]][0],cs[e[1]][1]);});
  c.stroke();
  var pts=TC.cells[i];
  for(k=0;k<pts.length;k++){var p=pts[k],tw=.5+.5*Math.sin(t*.004+p[3]*20);
   q=P(a0+gap+(a1-a0-2*gap)*p[0],p[1]*2-1,p[2]*2-1);
   c.fillStyle=rgba(k%3?C.white:C.boost,fa*(.6+1.2*tw));c.fillRect(q[0]-.7,q[1]-.7,1.4+tw*.6,1.4+tw*.6);}}
 c.restore();}
var FF=null;
function ffInit(){var w=96,h=128,n=w*h,U=new Float32Array(n),V=new Float32Array(n),i;
 for(i=0;i<n;i++){U[i]=1;V[i]=0;}
 for(i=0;i<260;i++){var a=rnd(i*3.3)*6.2832,r=rnd(i*7.1)*34,x=Math.round(w/2+Math.cos(a)*r),y=Math.round(h*.6+Math.sin(a)*r);
  for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var j=(y+dy)*w+x+dx;if(j>=0&&j<n){U[j]=.5;V[j]=.25;}}}
 var cv=document.createElement('canvas');cv.width=w;cv.height=h;
 FF={w:w,h:h,U:U,V:V,U2:new Float32Array(n),V2:new Float32Array(n),cv:cv,cx:cv.getContext('2d'),img:null,t:0};
 FF.img=FF.cx.createImageData(w,h);
 for(i=0;i<1600;i++)ffStep();}
function ffStep(){ /* Gray-Scott, régime labyrinthe ; l'« aimant » (centre bas) nourrit davantage la réaction */
 var w=FF.w,h=FF.h,U=FF.U,V=FF.V,U2=FF.U2,V2=FF.V2,x,y,i,mx=w/2,my=h*.6;
 for(y=1;y<h-1;y++)for(x=1;x<w-1;x++){i=y*w+x;
  var u=U[i],v=V[i],lu=U[i-1]+U[i+1]+U[i-w]+U[i+w]-4*u,lv=V[i-1]+V[i+1]+V[i-w]+V[i+w]-4*v,uvv=u*v*v;
  var d=Math.min(1,Math.hypot(x-mx,(y-my)*.9)/48),F=.029+.012*d*d,K=.057+.008*d*d;   /* labyrinthe près de l'aimant, s'éteint au loin */
  U2[i]=u+(.16*lu-uvv+F*(1-u));V2[i]=v+(.08*lv+uvv-(F+K)*v);}
 FF.U=U2;FF.U2=U;FF.V=V2;FF.V2=V;}
/* ============================ MAGNÉTISME — FERROFLUIDE DE LUMIÈRE (R170, refait de zéro) ============================
   Référence : vidéo de Simon (fsaver_87960.mp4) — ferrofluide sous un aimant : labyrinthe de veines lisses et connectées,
   cellules serrées au cœur, doigts étirés vers l'extérieur, gouttelettes détachées en bordure, une traîne derrière la goutte.
   Consignes (docs/TEXTURE_MAGNETISME.md) : discret comme les niveaux 6 et 12 ; aucun trait ni contour (la matière est de la
   lumière, pas un dessin) ; jamais pixelisé ; même densité sur les 12 niveaux ; la texture recule près des pièces sans
   disparaître ; pas de bille qui flotte ; un flux d'énergie qui parcourt les veines.
   Méthode : le champ des veines est calculé une fois par niveau à la résolution du jeu (1 u), en distance F2 − F1 dans une
   métrique étirée (cellules rondes au cœur, doigts radiaux en bordure), bords adoucis (pas d'escalier) ; un halo est tiré
   du même calque par réduction puis agrandissement (flou sans filtre, compatible iPhone). Deux états voisins du fluide
   (A, B) se fondent lentement l'un dans l'autre ; quelques impulsions de lumière glissent le long des crêtes. */
var F3=null;
function f3Foyers(lv){var k=(lv&&lv.idx)||0,a=rnd(k*3.1+1)*6.2832,
  F=[{x:.30+.40*rnd(k*7.7+2),y:.28+.42*rnd(k*5.3+3),R:150,ta:a},
     {x:.12+.76*rnd(k*2.9+4),y:.62+.30*rnd(k*4.1+5),R:105,ta:a+2.2},
     {x:.10+.80*rnd(k*6.7+6),y:.06+.22*rnd(k*8.3+7),R:72,ta:a+4.1}];
 F.forEach(function(f){f.x*=VW;f.y*=VH;f.tx=Math.cos(f.ta);f.ty=Math.sin(f.ta);});return F;}
function f3Seeds(F,j){var s=[],k,i;
 for(k=0;k<F.length;k++){var f=F[k],n=Math.round(f.R*1.55);
  for(i=0;i<n;i++){var u=rnd(k*131+i*7.31+j*.17),r=Math.pow(u,.62)*f.R*1.05,a=rnd(k*71+i*3.97)*6.2832;
   var x=f.x+Math.cos(a)*r,y=f.y+Math.sin(a)*r;
   if(r>f.R*.55){var tl=Math.max(0,-(Math.cos(a)*f.tx+Math.sin(a)*f.ty));x-=f.tx*tl*r*.45;y-=f.ty*tl*r*.45;}   /* traîne derrière la goutte */
   if(j){x+=Math.sin(i*.7+k)*2.4;y+=Math.cos(i*.9+k*2)*2.4;}   /* état B : le fluide a légèrement respiré */
   s.push([x,y]);}}
 return s;}
function f3Layer(lv,F,j,clr){var W3=VW,H3=VH,S3=f3Seeds(F,j),BK=22,bw=Math.ceil(W3/BK)+2,bh=Math.ceil(H3/BK)+2,bu=[],i,k,x,y;
 for(i=0;i<bw*bh;i++)bu.push([]);
 for(i=0;i<S3.length;i++){var bx=Math.floor(S3[i][0]/BK)+1,by=Math.floor(S3[i][1]/BK)+1;if(bx>=0&&by>=0&&bx<bw&&by<bh)bu[by*bw+bx].push(S3[i]);}
 var cv=document.createElement('canvas');cv.width=W3;cv.height=H3;var cx=cv.getContext('2d'),im=cx.createImageData(W3,H3),D3=im.data,V3=new Float32Array(W3*H3);
 var cols=[C.matter,C.boost,C.pink];
 for(y=0;y<H3;y++)for(x=0;x<W3;x++){
  var rho=0,kb=0,db=1e9;for(k=0;k<F.length;k++){var dx=x-F[k].x,dy=y-F[k].y,d=Math.sqrt(dx*dx+dy*dy)/F[k].R,e=Math.exp(-d*d*2.2);if(e>rho){rho=e;kb=k;db=d;}}
  if(rho<.02)continue;
  var fk=F[kb],ux=x-fk.x,uy=y-fk.y,ul=Math.sqrt(ux*ux+uy*uy)||1;ux/=ul;uy/=ul;
  var sr=1-.78*Math.min(1,Math.max(0,(db-.22)/.55));        /* au‑delà du cœur, les cellules s'étirent en doigts radiaux */
  var f1=1e9,f2=1e9,cbx=Math.floor(x/BK)+1,cby=Math.floor(y/BK)+1;
  for(var oy=-2;oy<=2;oy++)for(var ox=-2;ox<=2;ox++){var bx2=cbx+ox,by2=cby+oy;if(bx2<0||by2<0||bx2>=bw||by2>=bh)continue;var Bq=bu[by2*bw+bx2];
   for(i=0;i<Bq.length;i++){var vx=x-Bq[i][0],vy=y-Bq[i][1],pr=vx*ux+vy*uy,pt=-vx*uy+vy*ux,d2=sr*pr*pr+pt*pt;if(d2<f1){f2=f1;f1=d2;}else if(d2<f2)f2=d2;}}
  if(f2>=1e9)continue;
  var ev=Math.sqrt(f2)-Math.sqrt(f1),wv=.9+1.9*rho,vein=Math.min(1,Math.max(0,(wv-ev)/2.2+.5));vein=vein*vein*(3-2*vein);   /* bord adouci sur ~1 u */
  var nz=rnd(Math.floor(x/9)*17.3+Math.floor(y/9)*31.7+j*3),keep=Math.min(1,Math.max(0,(rho+.22*(nz-.5)-.12)/.16));   /* en bordure, le réseau se rompt en fragments */
  var fill=.07*rho*Math.min(1,ev/6);                       /* un voile très léger dans les cellules du cœur : de la profondeur, pas un trait */
  var a=(vein*keep*.95+fill)*rho*(clr?clr[(y>>2)*Math.ceil(W3/4)+(x>>2)]:1);if(a<.004)continue;
  var tq=Math.min(1,db/1.05),c0,c1,mix;if(tq<.5){c0=cols[0];c1=cols[1];mix=tq/.5;}else{c0=cols[1];c1=cols[2];mix=(tq-.5)/.5;}
  var o=(y*W3+x)*4;D3[o]=c0[0]+(c1[0]-c0[0])*mix;D3[o+1]=c0[1]+(c1[1]-c0[1])*mix;D3[o+2]=c0[2]+(c1[2]-c0[2])*mix;D3[o+3]=Math.min(255,a*255);
  V3[y*W3+x]=vein*keep*rho;}
 cx.putImageData(im,0,0);
 /* gouttelettes détachées en bordure, dessinées en disques lissés */
 for(k=0;k<F.length;k++){var f=F[k],n=Math.round(f.R*.5);for(i=0;i<n;i++){var a2=rnd(k*19+i*5.7+j)*6.2832,r2=f.R*(.78+.42*rnd(k*23+i*3.3)),
   px=f.x+Math.cos(a2)*r2,py=f.y+Math.sin(a2)*r2,tl=Math.max(0,-(Math.cos(a2)*f.tx+Math.sin(a2)*f.ty));px-=f.tx*tl*r2*.35;py-=f.ty*tl*r2*.35;
   var rr=.5+1.3*rnd(k*29+i*1.9),cl=clr?clr[(Math.max(0,Math.min(H3-1,py|0))>>2)*Math.ceil(W3/4)+(Math.max(0,Math.min(W3-1,px|0))>>2)]:1;
   cx.fillStyle=rgba(rnd(i*4.4+k)<.5?C.boost:C.pink,.55*cl);cx.beginPath();cx.arc(px,py,rr,0,6.2832);cx.fill();}}
 /* halo : réduction ×4 puis agrandissement lissé = flou doux, sans ctx.filter */
 var sm=document.createElement('canvas');sm.width=W3>>2;sm.height=H3>>2;var sx=sm.getContext('2d');sx.imageSmoothingEnabled=true;sx.drawImage(cv,0,0,sm.width,sm.height);
 var gl=document.createElement('canvas');gl.width=W3;gl.height=H3;var gx=gl.getContext('2d');gx.imageSmoothingEnabled=true;gx.drawImage(sm,0,0,W3,H3);
 return {img:cv,glow:gl,V:V3};}
function f3Build(lv){var F=f3Foyers(lv),W4=Math.ceil(VW/4),H4=Math.ceil(VH/4),clr=new Float32Array(W4*H4),i,j;
 for(j=0;j<H4;j++)for(i=0;i<W4;i++)clr[j*W4+i]=ffClear(lv,i*4+2,j*4+2);
 F3={key:lv&&lv.idx,F:F,clr:clr,A:f3Layer(lv,F,0,clr),B:null,bRow:0,P:[],t0:now()};}
function f3Pulse(){var A=F3.A.V,W3=VW,H3=VH,i;
 for(var tries=0;tries<40;tries++){var x=(rnd(now()*.13+tries*7.1)*W3)|0,y=(rnd(now()*.29+tries*3.7)*H3)|0;if(A[y*W3+x]>.35){var a=rnd(tries+now())*6.2832;
   F3.P.push({x:x,y:y,dx:Math.cos(a),dy:Math.sin(a),tr:[],life:0,L:70+rnd(now()*.7)*90,warm:rnd(now()*.31)<.2});return;}}}
function ferro3(c,lv){
 if(!F3||F3.key!==(lv&&lv.idx))f3Build(lv);
 var rm=(typeof OPT!=='undefined'&&OPT.rm),t=now(),k;
 if(!F3.B&&!rm)F3.B=f3Layer(lv,F3.F,1,F3.clr);
 var w=rm||!F3.B?0:.5+.5*Math.sin(t*.0045),br=rm?1:.88+.12*Math.sin(t*.0021+1.3),ox=rm?0:Math.sin(t*.0017)*1.2,oy=rm?0:Math.cos(t*.0013)*1.2;
 c.save();c.globalCompositeOperation='lighter';c.imageSmoothingEnabled=true;
 var L2=[[F3.A,1-w]];if(F3.B&&w>0)L2.push([F3.B,w]);
 for(k=0;k<L2.length;k++){var ly=L2[k][0],m=L2[k][1]*br;
  c.globalAlpha=.38*m;c.drawImage(ly.glow,ox-2,oy-2,VW+4,VH+4);   /* halo */
  c.globalAlpha=.26*m;c.drawImage(ly.img,ox,oy,VW,VH);}            /* veines */
 /* flux d'énergie : une impulsion glisse le long d'une crête, choisit la suite la plus lumineuse, laisse une traînée */
 if(!rm){if(F3.P.length<4&&rnd(t*.37)<.03)f3Pulse();var A=F3.A.V,W3=VW;
  for(k=F3.P.length-1;k>=0;k--){var p=F3.P[k];p.life++;
   var best=-1,bx=0,by=0,bdx=0,bdy=0;for(var q=0;q<12;q++){var aa=Math.atan2(p.dy,p.dx)+(q-5.5)*.16,nx=p.x+Math.cos(aa)*1.6,ny=p.y+Math.sin(aa)*1.6,ix=nx|0,iy=ny|0;
    if(ix<0||iy<0||ix>=VW||iy>=VH)continue;var v=A[iy*W3+ix];if(v>best){best=v;bx=nx;by=ny;bdx=Math.cos(aa);bdy=Math.sin(aa);}}
   if(best<.18||p.life>p.L){F3.P.splice(k,1);continue;}
   p.tr.push([p.x,p.y]);if(p.tr.length>22)p.tr.shift();p.x=bx;p.y=by;p.dx=p.dx*.6+bdx*.4;p.dy=p.dy*.6+bdy*.4;
   var fa=Math.sin(Math.PI*p.life/p.L),col=p.warm?WARM[k%3]:C.white;
   for(q=0;q<p.tr.length;q++){var tq=(q+1)/p.tr.length;c.globalAlpha=1;c.fillStyle=rgba(col,.22*tq*tq*fa);c.beginPath();c.arc(p.tr[q][0]+ox,p.tr[q][1]+oy,.9+1.1*tq,0,6.2832);c.fill();}
   c.fillStyle=rgba(col,.45*fa);c.beginPath();c.arc(p.x+ox,p.y+oy,2.4,0,6.2832);c.fill();}}
 c.restore();}

/* ============================ MAGNÉTISME — FERROFLUIDE VIVANT (R171, repris de zéro) ============================
   Ce n'est plus un dessin de cellules : c'est une SIMULATION. Un ferrofluide sous un aimant forme un labyrinthe parce que
   deux forces s'opposent (instabilité de Rosensweig) ; le modèle de réaction‑diffusion de Gray‑Scott reproduit exactement
   ces motifs : vers et labyrinthe au cœur, gouttes qui se détachent en bordure, rien au loin. Il tourne sur la carte
   graphique (WebGL 2) à 192 × 256, plusieurs pas par image ; le rendu lit le champ en interpolé puis le seuille en douceur
   à la résolution de l'écran : aucun pixel, aucun trait — des corps de fluide lumineux avec un reflet sur leur bord.
   Deux aimants dérivent lentement (Lissajous) : le labyrinthe les suit, se tord, s'étire en doigts et laisse une traîne
   de gouttes qui s'éteignent, comme dans la vidéo de Simon (fsaver_87960.mp4). Un léger tourbillon autour de chaque aimant
   fait couler la matière. Sans WebGL 2 : repli sur le rendu R170 (ferro3), fixe. */
var F4=null;
/* R173 — trois nappes de ferrofluide à trois échelles (fine, moyenne, large), qui se mêlent avec leurs propres opacités et
   luminosités. La nappe fine vit autour des aimants (aspirée, couronne autour des répulseurs) ; les nappes moyenne et large
   couvrent tout le fond par plaques qui dérivent (bruit lent) et sont, elles aussi, tirées par les aimants. La VITESSE de la
   matière varie au hasard d'une région à l'autre et d'un moment à l'autre, s'accélère en approchant d'un aimant et ralentit
   près d'un répulseur (pas de temps local de la réaction‑diffusion). */
var F4_VS='#version 300 es\nin vec2 p;out vec2 v_uv;void main(){v_uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
var F4_NOISE='float hh(vec2 q){return fract(sin(dot(q,vec2(127.1,311.7)))*43758.5453);}\n'+
 'float vn(vec2 q){vec2 i=floor(q),f=fract(q);f=f*f*(3.-2.*f);return mix(mix(hh(i),hh(i+vec2(1,0)),f.x),mix(hh(i+vec2(0,1)),hh(i+vec2(1,1)),f.x),f.y);}\n'+
 'float fbm(vec2 q){return .62*vn(q)+.28*vn(q*2.03+7.1)+.10*vn(q*4.1+3.3);}\n';
var F4_SIM='#version 300 es\nprecision highp float;uniform sampler2D s;uniform vec2 px;uniform vec4 mg[6];uniform int nm;uniform float t;uniform float seed;uniform float amb;uniform float nsc;uniform float tm;uniform float ls;in vec2 v_uv;out vec4 o;\n'+F4_NOISE+
 'float h(vec2 q){return fract(sin(dot(q,vec2(127.1,311.7))+seed)*43758.5453);}\n'+
 'void main(){vec2 uv=v_uv;float a=0.,sup=0.,dd=9.,near=0.;vec2 adv=vec2(0.);\n'+
 ' for(int i=0;i<6;i++){if(i>=nm)break;vec4 m=mg[i];vec2 d=(uv-m.xy)*vec2(.75,1.);float l=length(d)+1e-4,r=l/m.z;vec2 n=d/l;\n'+
 '  if(m.w>0.){float w=exp(-r*r*1.7)*m.w;a=max(a,w);dd=min(dd,r);near=max(near,exp(-r*r*.8)*m.w);adv+=-n*w*.06*m.w+vec2(-n.y,n.x)*w*.02;}\n'+
 '  else{float q=-m.w;sup=max(sup,exp(-r*r*3.)*q);float ring=exp(-pow((r-.95)/.24,2.))*q*.9;a=max(a,ring);dd=min(dd,abs(r-.95)+.3);adv+=n*ring*.06*q;near=near-exp(-r*r*.9)*q*.7;}}\n'+
 ' a*=1.-sup;\n'+
 ' if(amb>.5){float f=fbm(uv*vec2(.75,1.)*nsc+vec2(ls,ls*.7)+vec2(tm*.011,-tm*.007));float aa=smoothstep(.42,.70,f)*.78;a=max(aa*(1.-sup),a*.7);dd=min(dd,1.6-f);}\n'+
 ' float sp=mix(.35,1.25,fbm(uv*2.1+vec2(ls*1.3+tm*.021,tm*.013)));sp*=clamp(1.+.9*near,.3,1.9);sp=clamp(sp,.15,1.45);\n'+   /* vitesse aléatoire, plus vive près d un aimant, plus lente près d un répulseur */
 ' vec2 q=uv-adv*px*sp;\n'+
 ' vec2 c=texture(s,q).rg;vec2 e=texture(s,q+vec2(px.x,0.)).rg,w=texture(s,q-vec2(px.x,0.)).rg,n=texture(s,q+vec2(0.,px.y)).rg,so=texture(s,q-vec2(0.,px.y)).rg;\n'+
 ' vec2 ne=texture(s,q+px).rg,nw=texture(s,q+vec2(-px.x,px.y)).rg,se=texture(s,q+vec2(px.x,-px.y)).rg,sw2=texture(s,q-px).rg;\n'+
 ' vec2 L=.2*(e+w+n+so)+.05*(ne+nw+se+sw2)-c;float k1=smoothstep(.10,.30,a),k2=smoothstep(.35,.60,a);\n'+
 ' float F=mix(mix(.010,.030,k1),.029,k2),K=mix(mix(.075,.0625,k1),.057,k2);float u=c.r,v=c.g,r=u*v*v;\n'+
 ' u+=sp*(.62*L.r-r+F*(1.-u));v+=sp*(.31*L.g+r-(F+K)*v);\n'+
 ' if(a>.5&&v<.02&&h(floor(uv/px/4.)+t)>.9993){u=0.;v=1.;}\n'+
 ' o=vec4(clamp(u,0.,1.),clamp(v,0.,1.),a,min(dd,4.));}';
var F4_DRAW='#version 300 es\nprecision highp float;uniform sampler2D s;uniform sampler2D mk;uniform vec2 px;uniform float al;uniform float tt;uniform float tm;uniform float lum;uniform float dro;uniform float hue;uniform float ls;in vec2 v_uv;out vec4 o;\n'+F4_NOISE+
 'vec2 h2(vec2 q){return fract(sin(vec2(dot(q,vec2(127.1,311.7)),dot(q,vec2(269.5,183.3))))*43758.5453);}\n'+
 'float drops(vec2 uv,float sc,float rmin,float rmax,float tw){vec2 P=vec2(uv.x*.75,uv.y)*sc,id=floor(P);float best=0.;\n'+
 ' for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec2 c=id+vec2(float(i),float(j)),hp=h2(c);vec2 p=c+.2+.6*hp+.12*vec2(sin(tw*.6+hp.x*6.3),cos(tw*.5+hp.y*6.3));\n'+
 '  vec2 pu=vec2(p.x/.75,p.y)/sc;vec4 S=texture(s,pu);float zone=smoothstep(.04,.16,S.b)*(1.-smoothstep(.30,.50,S.b));\n'+
 '  float free=1.-smoothstep(.04,.14,S.g);vec2 o4=vec2(.012,.009);float nb=(texture(s,pu+vec2(o4.x,0.)).g+texture(s,pu-vec2(o4.x,0.)).g+texture(s,pu+vec2(0.,o4.y)).g+texture(s,pu-vec2(0.,o4.y)).g)*.25;\n'+
 '  float ex=step(h2(c+7.3).x,zone*.9*smoothstep(.03,.12,nb))*free;\n'+
 '  float rr=mix(rmin,rmax,pow(h2(c+3.1).y,1.6));float d=length(P-p);best=max(best,ex*smoothstep(rr,rr*.62,d));}\n'+
 ' return best;}\n'+
 'void main(){vec2 uv=v_uv;vec4 S=texture(s,uv);float v=S.g;float body=smoothstep(.19,.31,v);\n'+
 ' if(dro>.5){float dr=max(drops(uv,52.,.10,.36,tt),drops(uv,104.,.20,.50,tt*1.3));body=max(body,dr);}\n'+
 ' float gx=texture(s,uv+vec2(px.x,0.)).g-texture(s,uv-vec2(px.x,0.)).g,gy=texture(s,uv+vec2(0.,px.y)).g-texture(s,uv-vec2(0.,px.y)).g;\n'+
 ' float rim=smoothstep(.02,.12,length(vec2(gx,gy)))*(1.-body*.55);float hl=smoothstep(.0,.5,-gx*.7+gy*.7)*body;\n'+
 ' float g=0.;for(int i=0;i<8;i++){float an=float(i)*.785;g+=texture(s,uv+vec2(cos(an),sin(an))*px*3.5).g;}g=smoothstep(.06,.32,g/8.);\n'+
 ' float dd=S.a+hue;vec3 cy=vec3(.30,.84,1.),vi=vec3(.65,.47,1.),pk=vec3(.95,.63,.78);vec3 col=dd<.5?mix(cy,vi,dd/.5):mix(vi,pk,clamp((dd-.5)/.6,0.,1.));\n'+
 ' float lv=lum*(.45+1.1*fbm(uv*vec2(2.2,2.9)+vec2(ls+tm*.017,-tm*.012)));\n'+   /* luminosité et opacité qui varient d une région à l autre */
 ' float op=.35+.9*fbm(uv*vec2(1.6,2.1)+vec2(-tm*.009+ls*2.,tm*.014));\n'+
 ' float mask=texture(mk,vec2(uv.x,1.-uv.y)).r;\n'+
 ' float a=(body*.42+rim*.30+g*.10)*mask*al*op;vec3 c=(col*(body*.42+g*.10)+mix(col,vec3(1.),.55)*(rim*.30+hl*.18))*lv;\n'+
 ' o=vec4(c*mask*al*op,a);}';
function f4Prog(gl,fs){function sh(tp,src){var x=gl.createShader(tp);gl.shaderSource(x,src);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(x);return x;}
 var p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,F4_VS));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,fs));gl.bindAttribLocation(p,0,'p');gl.linkProgram(p);
 if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw gl.getProgramInfoLog(p);return p;}
function f4Tex(gl,w,h,data){var t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,w,h,0,gl.RGBA,gl.FLOAT,data);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t;}
/* nappes : [largeur, hauteur, ambiante ?, échelle du bruit, pas par image, opacité, luminosité, gouttes ?, décalage de teinte] */
var F4_LAYERS=[[100,134,1,1.6,5,.38,.5,0,.35],[160,214,1,2.6,7,.7,.8,0,.15],[240,320,0,0,12,1,1,1,0]];
function f4Init(){if(F4)return F4.ok;F4={ok:false};
 try{var cv=document.createElement('canvas');cv.width=540;cv.height=720;var gl=cv.getContext('webgl2',{premultipliedAlpha:true,alpha:true,antialias:false});
  if(!gl||!(gl.getExtension('EXT_color_buffer_float')||gl.getExtension('EXT_color_buffer_half_float')))return false;
  var vb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
  var LY=F4_LAYERS.map(function(d,k){var T=[f4Tex(gl,d[0],d[1],null),f4Tex(gl,d[0],d[1],null)],FB=T.map(function(t){var f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,t,0);return f;});
   return {SW:d[0],SH:d[1],amb:d[2],nsc:d[3],st:d[4],op:d[5],lum:d[6],dro:d[7],hue:d[8],ls:k*17.3+3.1,T:T,FB:FB,cur:0};});
  if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)return false;
  var mk=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,mk);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  F4={ok:true,cv:cv,gl:gl,LY:LY,mk:mk,key:null,sim:f4Prog(gl,F4_SIM),draw:f4Prog(gl,F4_DRAW),t:0};}catch(e){F4={ok:false};}
 return F4.ok;}
function f4Src(lv,t){var o=[],k=(lv&&lv.idx)||0;   /* sources : les aimants et bobines du niveau, avec leur force ; y en coordonnées GL */
 function sf(q){return Math.max(.5,Math.min(1.2,.35+.5*Math.sqrt(Math.abs(q))));}
 (lv&&lv.mag||[]).forEach(function(m){var g=sf(m[3]);o.push([m[0]/VW,1-m[1]/VH,Math.max(70,Math.min(200,m[2]*1.35))/VH*(.85+.25*g),m[3]<0?-g:g]);});
 (lv&&lv.coil||[]).forEach(function(cl){o.push([cl[0]/VW,1-cl[1]/VH,Math.max(60,cl[4]*1.8)/VH,Math.max(.5,Math.min(.9,.5+.3*(cl[5]||1)))]);});
 if(!o.some(function(q){return q[3]>0;})){var a=rnd(k*3.3+1)*6.2832,c0=[.32+.36*rnd(k*7.1+2),.30+.40*rnd(k*5.7+3)],c1=[.15+.70*rnd(k*2.3+4),.68+.22*rnd(k*4.9+5)];
  o.push([c0[0]+.13*Math.sin(t*.0017+a),1-(c0[1]+.08*Math.sin(t*.0023+a*1.3)),.30,.8]);o.push([c1[0]+.10*Math.sin(t*.0021+a*2.1),1-(c1[1]+.05*Math.cos(t*.0013+a)),.19,.65]);}   /* sans aimant : deux foyers qui dérivent */
 return o.slice(0,6);}
function f4Uni(p,M){var gl=F4.gl,f=new Float32Array(24);for(var i=0;i<M.length;i++)for(var j=0;j<4;j++)f[i*4+j]=M[i][j];
 gl.uniform4fv(gl.getUniformLocation(p,'mg'),f);gl.uniform1i(gl.getUniformLocation(p,'nm'),M.length);}
function f4Reset(lv){var gl=F4.gl,M=f4Src(lv,now()),x,y,i;
 F4.LY.forEach(function(Y,li){var SW=Y.SW,SH=Y.SH,d=new Float32Array(SW*SH*4);
  for(y=0;y<SH;y++)for(x=0;x<SW;x++){i=(y*SW+x)*4;d[i]=1;d[i+1]=0;d[i+3]=1;var bx=Math.floor(x/4),by=Math.floor(y/4),hit=Y.amb&&rnd(bx*.53+by*1.37+li*9)>.88;   /* germes : blocs de 4 × 4 */
   for(var k=0;k<M.length&&!hit;k++){var dx=(bx*4/SW-M[k][0])*.75,dy=(by*4/SH-M[k][1]),r0=Math.hypot(dx,dy)/M[k][2];if((M[k][3]>0?r0<.6:Math.abs(r0-.95)<.2)&&rnd(bx*.37+by*1.91+k+li)>.86)hit=true;}
   if(hit){d[i]=0;d[i+1]=1;}}
  gl.bindTexture(gl.TEXTURE_2D,Y.T[0]);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,SW,SH,0,gl.RGBA,gl.FLOAT,d);
  gl.bindTexture(gl.TEXTURE_2D,Y.T[1]);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,SW,SH,0,gl.RGBA,gl.FLOAT,d);Y.cur=0;});
 var W4=90,H4=120,m8=new Uint8Array(W4*H4);var cp=lv&&lv.cup;for(y=0;y<H4;y++)for(x=0;x<W4;x++){var fx=x*4+2,fy=y*4+2,cf=1;
  if(cp){var ddx=Math.max(cp[0]-16-fx,0,fx-(cp[0]+cp[2]+16)),ddy=Math.max(cp[1]-78-fy,0,fy-(cp[1]+18)),dd=Math.hypot(ddx,ddy);cf=Math.min(1,dd/16);cf=cf*cf*(3-2*cf);}   /* rien dans la zone de réussite (R88), bord fondu */
  m8[y*W4+x]=Math.round(255*ffClear(lv,fx,fy)*cf);}
 gl.bindTexture(gl.TEXTURE_2D,F4.mk);gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);gl.texImage2D(gl.TEXTURE_2D,0,gl.R8,W4,H4,0,gl.RED,gl.UNSIGNED_BYTE,m8);
 F4.key=lv&&lv.idx;F4.t=0;F4.LY.forEach(function(Y){f4Steps(lv,Y,Math.round(Y.st*130));});}
function f4Steps(lv,Y,n){var gl=F4.gl,p=F4.sim;gl.useProgram(p);gl.viewport(0,0,Y.SW,Y.SH);
 gl.uniform2f(gl.getUniformLocation(p,'px'),1/Y.SW,1/Y.SH);gl.uniform1i(gl.getUniformLocation(p,'s'),0);gl.uniform1f(gl.getUniformLocation(p,'seed'),rnd(F4.t*.01)*100);
 gl.uniform1f(gl.getUniformLocation(p,'amb'),Y.amb);gl.uniform1f(gl.getUniformLocation(p,'nsc'),Y.nsc);gl.uniform1f(gl.getUniformLocation(p,'ls'),Y.ls);gl.uniform1f(gl.getUniformLocation(p,'tm'),now()/60);
 f4Uni(p,f4Src(lv,now()));for(var i=0;i<n;i++){F4.t++;gl.uniform1f(gl.getUniformLocation(p,'t'),F4.t%997);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,Y.T[Y.cur]);gl.bindFramebuffer(gl.FRAMEBUFFER,Y.FB[1-Y.cur]);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);Y.cur=1-Y.cur;}}
function ferro4(c,lv){
 if(!f4Init()){ferro3(c,lv);return;}
 var gl=F4.gl,rm=(typeof OPT!=='undefined'&&OPT.rm);
 if(F4.key!==(lv&&lv.idx))f4Reset(lv);
 if(!rm)F4.LY.forEach(function(Y){f4Steps(lv,Y,Y.st);});
 var p=F4.draw;gl.useProgram(p);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,F4.cv.width,F4.cv.height);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
 gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
 gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,F4.mk);gl.uniform1i(gl.getUniformLocation(p,'mk'),1);gl.uniform1i(gl.getUniformLocation(p,'s'),0);
 gl.uniform1f(gl.getUniformLocation(p,'tt'),(now()*.016)%1000);gl.uniform1f(gl.getUniformLocation(p,'tm'),now()/60);
 F4.LY.forEach(function(Y){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,Y.T[Y.cur]);
  gl.uniform2f(gl.getUniformLocation(p,'px'),1/Y.SW,1/Y.SH);gl.uniform1f(gl.getUniformLocation(p,'al'),Y.op);gl.uniform1f(gl.getUniformLocation(p,'lum'),Y.lum);
  gl.uniform1f(gl.getUniformLocation(p,'dro'),Y.dro);gl.uniform1f(gl.getUniformLocation(p,'hue'),Y.hue);gl.uniform1f(gl.getUniformLocation(p,'ls'),Y.ls);
  gl.drawArrays(gl.TRIANGLE_STRIP,0,4);});
 gl.disable(gl.BLEND);
 c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(F4.cv,0,0,VW,VH);c.restore();}

function ffClear(lv,fx,fy){ /* la texture s'efface autour de ce qui se lit en jouant : murs, départ, bassin, noyau */
 var d=1e9,i,w=lv&&lv.w||[];
 for(i=0;i<w.length;i++){var s0=w[i],ax=s0[2]-s0[0],ay=s0[3]-s0[1],l2=ax*ax+ay*ay,u=l2?Math.max(0,Math.min(1,((fx-s0[0])*ax+(fy-s0[1])*ay)/l2)):0;
  d=Math.min(d,Math.hypot(fx-s0[0]-u*ax,fy-s0[1]-u*ay));}
 if(lv&&lv.ball)d=Math.min(d,Math.hypot(fx-lv.ball[0],fy-lv.ball[1])-14);
 if(lv&&lv.star)d=Math.min(d,Math.hypot(fx-lv.star[0],fy-lv.star[1])-10);
 if(lv&&lv.cup){var cp=lv.cup,dx=Math.max(cp[0]-fx,0,fx-(cp[0]+cp[2])),dy=Math.max(cp[1]-60-fy,0,fy-cp[1]-6);d=Math.min(d,Math.hypot(dx,dy));}
 return Math.max(.35,Math.min(1,(d-6)/22));}   /* R152 : on n'efface plus que près des pièces, et jamais tout à fait — même texture d'un niveau à l'autre */
function ferro(c,lv){
 /* R49 (retour Simon : « trop grossier, plusieurs couleurs ») : les parois des domaines sont tracées en VECTEUR
    (carrés de marche sur l'iso‑valeur), donc nettes à toute taille, et colorées selon la distance à l'aimant :
    cyan au cœur, violet, puis rose au bord — comme les reflets de la vidéo. Contour recalculé une image sur trois. */
 if(!FF)ffInit();
 var rm=(typeof OPT!=='undefined'&&OPT.rm);
 if(!rm){ffStep();ffStep();}
 FF.t++;
 if(!FF.lay||FF.t%6===0){
  if(!FF.lay){FF.lay=document.createElement('canvas');FF.lay.width=VW*2;FF.lay.height=VH*2;FF.lc=FF.lay.getContext('2d');}
  var w=FF.w,h=FF.h,V=FF.V,sx=VW*2/(w-1),sy=VH*2/(h-1),iso=.2,x,y,lc=FF.lc,mx=(w-1)/2,my=(h-1)*.6,maxd=Math.hypot(mx,my);
  if(!FF.clr||FF.clrKey!==(lv&&lv.idx)){FF.clr=new Float32Array(w*h);FF.clrKey=lv&&lv.idx;for(var cy2=0;cy2<h;cy2++)for(var cx2=0;cx2<w;cx2++)FF.clr[cy2*w+cx2]=ffClear(lv,cx2*VW/(w-1),cy2*VH/(h-1));}
  lc.clearRect(0,0,FF.lay.width,FF.lay.height);lc.lineCap='round';
  var bands=[[C.matter,[]],[C.boost,[]],[C.pink||[255,77,141],[]]];
  function lerp(a,b){return (iso-a)/((b-a)||1e-6);}
  for(y=0;y<h-1;y++)for(x=0;x<w-1;x++){
   var a0=V[y*w+x],a1=V[y*w+x+1],a2=V[(y+1)*w+x+1],a3=V[(y+1)*w+x],k=(a0>iso?1:0)|(a1>iso?2:0)|(a2>iso?4:0)|(a3>iso?8:0);
   if(k===0||k===15)continue;
   var e=[[x+lerp(a0,a1),y],[x+1,y+lerp(a1,a2)],[x+lerp(a3,a2),y+1],[x,y+lerp(a0,a3)]];
   var segs={1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],5:[[3,0],[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[0,2]],10:[[0,1],[2,3]],11:[[1,2]],12:[[1,3]],13:[[0,1]],14:[[3,0]]}[k];
   var dn=Math.hypot(x-mx,(y-my)*.9)/maxd,bi=dn<.28?0:(dn<.5?1:2),fade=Math.max(0,1-dn*1.35);
   var fx=x*VW/(w-1),fy=y*VH/(h-1),ft=FF.t*.004,mk=.5+.5*Math.sin(fx*.031+ft)*Math.sin(fy*.026-ft*.7)+.25*Math.sin((fx+fy)*.012+ft*1.3);
   fade*=Math.max(0,Math.min(1,mk*1.5-.35))*(FF.clr?FF.clr[y*w+x]:1);   /* trous de transparence qui dérivent + dégagement du parcours */
   if(fade<=.02)continue;
   for(var q=0;q<segs.length;q++)bands[bi][1].push(e[segs[q][0]][0]*sx,e[segs[q][0]][1]*sy,e[segs[q][1]][0]*sx,e[segs[q][1]][1]*sy,fade);}
  for(var bnd=0;bnd<3;bnd++){var col=bands[bnd][0],L=bands[bnd][1];
   for(var pass=0;pass<2;pass++){lc.lineWidth=pass?1.6:5;lc.strokeStyle=rgba(col,pass?.85:.12);lc.beginPath();
    for(var i=0;i<L.length;i+=5){lc.globalAlpha=L[i+4];lc.moveTo(L[i],L[i+1]);lc.lineTo(L[i+2],L[i+3]);}
    lc.globalAlpha=1;lc.stroke();}}}
 c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(FF.lay,0,0,VW,VH);c.globalAlpha=1;
 /* poussière animée : grains qui dérivent au hasard, transparence aléatoire et changeante */
 if(!FF.dust){FF.dust=[];for(var di=0;di<80;di++)FF.dust.push({x:rnd(di*1.7)*VW,y:rnd(di*2.9+3)*VH,vx:(rnd(di*5.1)-.5)*.25,vy:(rnd(di*3.3)-.5)*.25,ph:rnd(di*7.7)*6.28,r:.5+rnd(di*9.1)*1.3,c:di%3});}
 var tn=now(),cols=[C.matter,C.boost,C.pink];
 for(var dj=0;dj<FF.dust.length;dj++){var q=FF.dust[dj];
  if(!rm){q.vx+=(Math.random()-.5)*.03;q.vy+=(Math.random()-.5)*.03;q.vx*=.98;q.vy*=.98;q.x=(q.x+q.vx+VW)%VW;q.y=(q.y+q.vy+VH)%VH;}
  var al=.08+.45*Math.pow(.5+.5*Math.sin(tn*.0017*(1+q.r)+q.ph),3);
  c.fillStyle=rgba(cols[q.c],al);c.beginPath();c.arc(q.x,q.y,q.r,0,6.2832);c.fill();}
 /* l'aimant : reflet circulaire, comme la goutte de la vidéo */
 var ax=VW/2,ay=VH*.6,g=c.createRadialGradient(ax,ay,0,ax,ay,40);g.addColorStop(0,rgba(C.white,.05));g.addColorStop(.85,rgba(C.boost,.07));g.addColorStop(1,rgba(C.boost,0));
 c.fillStyle=g;c.beginPath();c.arc(ax,ay,40,0,6.2832);c.fill();
 c.strokeStyle=rgba(C.white,.18);c.lineWidth=1.2;c.beginPath();c.arc(ax,ay,30,0,6.2832);c.stroke();
 c.restore();}

/* ============================ FERROFLUIDE v2 (R52) ============================
   D'après la vidéo de référence : près de la goutte, un réseau de CELLULES ; plus loin, des filaments étirés dans le sens
   du champ ; en bordure, des gouttelettes. Tout bouge vite et de façon organique : la goutte (l'aimant) dérive, les germes
   des cellules la suivent avec retard, ce qui étire le réseau derrière elle.
   Rendu : parois des cellules = iso‑contour de (F2 − F1) d'un diagramme de Voronoï (carrés de marche) ; relief par ombre
   portée + liseré clair ; trois couleurs selon la distance ; poussière émise le long des parois ; transparence par
   endroits et dégagement du parcours (ffClear). */
var FV=null;
/* R149 — LABYRINTHE DE FERROFLUIDE (référence : vidéo de Simon) en plusieurs plages de tailles et d'échelles différentes :
   une grande plage à cellules moyennes, une plage dense à cellules fines, une plage lâche à grandes cellules, deux petites
   plages ; chaque plage dérive lentement et s'étire en doigts derrière elle. Plus de goutte au centre. */
function fvInit(){var s=[],i,k,P=[[.30,.30,175,95,.7],[.74,.62,140,150,1.1],[.30,.86,150,34,.5],[.86,.16,90,40,.9],[.08,.62,80,26,.8]];
 for(k=0;k<P.length;k++)for(i=0;i<P[k][3];i++){var r=Math.sqrt(rnd(k*97+i*3.7))*P[k][2],a=rnd(k*53+i*9.1)*6.2832;s.push({r:r,a:a,x:0,y:0,p:k,ph:rnd(k*7+i*1.3)*6.28,sp:.4+rnd(k*11+i*5.9)*.8});}
 var gw=96,gh=128,pz=P.map(function(q,k){return {bx:q[0]*VW,by:q[1]*VH,R:q[2],w:q[4],x:q[0]*VW,y:q[1]*VH,vx:0,vy:0};});
 FV={s:s,P:pz,gw:gw,gh:gh,E:new Float32Array(gw*gh),t:0,mx:VW/2,my:VH*.58,vx:0,vy:0,dust:[],segs:[],lay:null,clr:null,key:null,sk:[],hash:null};}
/* éclats le long des parois du labyrinthe : rares, fins ; ils passent d'une paroi à la suivante par les extrémités
   communes ; un sur cinq finit dans les rouges, orangés et pourpres. */
var WARM=[[255,96,72],[255,150,70],[214,70,255]];
function fvSparks(c){var F=FV,i;if(!F.hash||!F.segs.length)return;
 if(Math.random()<.05&&F.sk.length<8){var g=F.segs[(Math.random()*F.segs.length)|0];if(g[4]>.3)F.sk.push({x:g[0],y:g[1],dx:g[2]-g[0],dy:g[3]-g[1],tr:[],n:0,L:30+Math.random()*60,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null});}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=F.sk.length-1;i>=0;i--){var p=F.sk[i];
  for(var st=0;st<1;st++){var key=Math.round(p.x/3)+','+Math.round(p.y/3),L=F.hash[key],best=null,bd=-2,dl=Math.hypot(p.dx,p.dy)||1;
   if(L)for(var k=0;k<L.length;k++){var g2=F.segs[L[k]>>1],e=L[k]&1,ex=e?g2[0]:g2[2],ey=e?g2[1]:g2[3],sx=e?g2[2]:g2[0],sy=e?g2[3]:g2[1],vx=ex-sx,vy=ey-sy,vl=Math.hypot(vx,vy)||1,dot=(vx*p.dx+vy*p.dy)/(vl*dl);
    if(Math.hypot(ex-p.x,ey-p.y)<.6)continue;if(dot>bd){bd=dot;best=[ex,ey,vx,vy];}}
   if(!best||bd<-.2){p.n=p.L;break;}p.tr.push([p.x,p.y]);if(p.tr.length>14)p.tr.shift();p.x=best[0];p.y=best[1];p.dx=best[2];p.dy=best[3];p.n++;}
  if(p.n>=p.L){F.sk.splice(i,1);continue;}
  var f=p.n/p.L,env=Math.sin(Math.PI*f),col=p.warm?[255+(p.warm[0]-255)*f|0,255+(p.warm[1]-255)*f|0,255+(p.warm[2]-255)*f|0]:[200,236,255];
  if(p.tr.length>1){c.strokeStyle=rgba(col,.35*env);c.lineWidth=.9;c.beginPath();c.moveTo(p.tr[0][0],p.tr[0][1]);for(var q=1;q<p.tr.length;q++)c.lineTo(p.tr[q][0],p.tr[q][1]);c.lineTo(p.x,p.y);c.stroke();}
  var gr=c.createRadialGradient(p.x,p.y,0,p.x,p.y,4);gr.addColorStop(0,rgba(col,.85*env));gr.addColorStop(1,rgba(col,0));c.fillStyle=gr;c.fillRect(p.x-5,p.y-5,10,10);}
 c.restore();}
/* R151 — FLUX D'ÉNERGIE dans les veines : une impulsion naît sur une veine, avance de case en case le long de la crête,
   se divise aux carrefours (réseau neuronal / mycélium) ; chaque case parcourue s'illumine puis s'éteint lentement.
   Une impulsion sur cinq glisse vers les rouges, orangés et pourpres au fil de sa course. */
function fvFlow(c){var F=FV,gw=F.gw,gh=F.gh,R=F.rg,i,k;if(!R)return;
 if(!F.vt||F.vt.length!==gw*gh){F.vt=new Uint32Array(gw*gh);F.pu=[];F.gh2=[];}
 var T0=F.t,sx=VW/(gw-1),sy=VH/(gh-1),N=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]];
 if(Math.random()<.035&&F.pu.length<6){for(var tr=0;tr<40;tr++){var id=(Math.random()*gw*gh)|0;if(R[id]){F.pu.push({id:id,n:0,L:110+Math.random()*120,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null,dx:0,dy:0,tr:[]});break;}}}
 function colOf(p){var f=Math.min(1,p.n/p.L);return p.warm?[255+(p.warm[0]-255)*f|0,255+(p.warm[1]-255)*f|0,255+(p.warm[2]-255)*f|0]:[150+70*f|0,215+20*f|0,255];}
 for(k=F.pu.length-1;k>=0;k--){var p=F.pu[k],x=p.id%gw,y=(p.id/gw)|0,opts=[];
  for(i=0;i<8;i++){var nx=x+N[i][0],ny=y+N[i][1];if(nx<0||ny<0||nx>=gw||ny>=gh)continue;var nid=ny*gw+nx;if(!R[nid]||nid===p.prev)continue;var fresh=T0-F.vt[nid]>=60;opts.push([nid,N[i][0],N[i][1],N[i][0]*p.dx+N[i][1]*p.dy-(fresh?0:3)-F.E[nid]*.25]);}
  if(!opts.length||p.n>p.L){F.gh2.push({tr:p.tr,a:1,c:p.c});F.pu.splice(k,1);continue;}
  opts.sort(function(a,b){return b[3]-a[3];});var o=opts[0];
  if(opts.length>3&&F.pu.length<16&&p.n>8&&Math.random()<.07){var o2=opts[opts.length-1];if(Math.abs(o2[1]-o[1])+Math.abs(o2[2]-o[2])>1)F.pu.push({id:o2[0],n:p.n,L:p.L*.85,warm:p.warm,dx:o2[1],dy:o2[2],tr:[[x*sx,y*sy]]});}   /* ramification */
  p.prev=p.id;p.id=o[0];p.dx=o[1];p.dy=o[2];p.n++;F.vt[p.id]=T0;p.tr.push([(p.id%gw)*sx,((p.id/gw)|0)*sy]);if(p.tr.length>34)p.tr.shift();p.c=colOf(p);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 function trail(tr0,col,a){if(tr0.length<2)return;var tr=tr0.map(function(q,m){var A=tr0[Math.max(0,m-1)],B=tr0[Math.min(tr0.length-1,m+1)];return [(A[0]+q[0]*2+B[0])/4,(A[1]+q[1]*2+B[1])/4];});for(var m=1;m<tr.length;m++){var f=m/tr.length;c.strokeStyle=rgba(col,a*f*.75);c.lineWidth=.6+f*1.1;c.beginPath();c.moveTo(tr[m-1][0],tr[m-1][1]);c.lineTo(tr[m][0],tr[m][1]);c.stroke();}}
 for(i=F.gh2.length-1;i>=0;i--){var gq=F.gh2[i];gq.a-=.04;if(gq.a<=0){F.gh2.splice(i,1);continue;}if(gq.tr.length>1)gq.tr.shift();trail(gq.tr,gq.c||[200,230,255],gq.a);}
 for(i=0;i<F.pu.length;i++){var q=F.pu[i],cq=q.c||[200,230,255];trail(q.tr,cq,1);q.tr.c=cq;
  var hx=q.tr.length?q.tr[q.tr.length-1][0]:0,hy=q.tr.length?q.tr[q.tr.length-1][1]:0,gr=c.createRadialGradient(hx,hy,0,hx,hy,5);gr.addColorStop(0,rgba(cq,.9));gr.addColorStop(1,rgba(cq,0));c.fillStyle=gr;c.fillRect(hx-5,hy-5,10,10);}
 c.restore();}
var FF_SOFT=false,FF_NOSILK=false,F3_ON=true;   /* R172 : ferrofluide vivant validé par Simon, actif dans le jeu */
function ferroMode(v){F3_ON=!!v;}
function ffSoft(v,ns){FF_SOFT=!!v;FF_NOSILK=!!ns;}
function ferro2(c,lv){
 if(!FV)fvInit();var rm=(typeof OPT!=='undefined'&&OPT.rm),t=now()*.001,i,j,k;FV.t++;
 /* la goutte dérive (trajectoire organique, ~9 s par boucle) */
 for(k=0;k<FV.P.length;k++){var pp=FV.P[k],w=pp.w,nx=pp.bx+Math.sin(t*.35*w+k)*34+Math.sin(t*.9*w+k*2)*8,ny=pp.by+Math.cos(t*.27*w+k*1.7)*26+Math.sin(t*.7*w)*6;if(rm){nx=pp.bx;ny=pp.by;}
  pp.vx=nx-pp.x;pp.vy=ny-pp.y;pp.x=nx;pp.y=ny;}
 for(i=0;i<FV.s.length;i++){var q=FV.s[i],P0=FV.P[q.p],vs=Math.hypot(P0.vx,P0.vy),ux=vs?P0.vx/vs:1,uy=vs?P0.vy/vs:0,str=Math.min(1.6,vs*2.2);
  q.a+=rm?0:.003*q.sp*Math.sin(t*.9+q.ph);q.r+=rm?0:Math.sin(t*2.2*q.sp+q.ph)*.25;
  var px=Math.cos(q.a)*q.r,py=Math.sin(q.a)*q.r,along=px*ux+py*uy;
  if(along<0){px-=ux*along*str*.9;py-=uy*along*str*.9;}          /* étirement derrière la plage : doigts */
  q.x+= (P0.x+px-q.x)*(q.x?0.18:1);q.y+=(P0.y+py-q.y)*(q.y?0.18:1);}
 if(!FV.lay||FV.t%4===0){
  var gw=FV.gw,gh=FV.gh,E=FV.E,sx=VW/(gw-1),sy=VH/(gh-1),S=FV.s;
  if(FV.key!==(lv&&lv.idx)){FV.key=lv&&lv.idx;FV.clr=new Float32Array(gw*gh);for(j=0;j<gh;j++)for(i=0;i<gw;i++)FV.clr[j*gw+i]=ffClear(lv,i*sx,j*sy);}
  var BK=36,bw=Math.ceil(VW/BK)+1,bh=Math.ceil(VH/BK)+1,bu=[];for(k=0;k<bw*bh;k++)bu.push([]);   /* R149 : graines rangées par cases — 2 plus proches en temps court */
  for(k=0;k<S.length;k++){var bx=Math.max(0,Math.min(bw-1,(S[k].x/BK)|0)),by=Math.max(0,Math.min(bh-1,(S[k].y/BK)|0));bu[by*bw+bx].push(S[k]);}
  if(!FV.img){FV.img=document.createElement('canvas');FV.img.width=gw;FV.img.height=gh;FV.ic=FV.img.getContext('2d');FV.id=FV.ic.createImageData(gw,gh);}
  var ID=FV.id.data,cl3=[C.matter,C.boost,C.pink];
  for(j=0;j<gh;j++)for(i=0;i<gw;i++){var x=i*sx,y=j*sy,f1=1e9,f2=1e9,cx=(x/BK)|0,cy=(y/BK)|0;
   for(var oy=-2;oy<=2;oy++)for(var ox=-2;ox<=2;ox++){var bx2=cx+ox,by2=cy+oy;if(bx2<0||by2<0||bx2>=bw||by2>=bh)continue;var Bq=bu[by2*bw+bx2];
    for(k=0;k<Bq.length;k++){var dx=x-Bq[k].x,dy=y-Bq[k].y,d=dx*dx+dy*dy;if(d<f1){f2=f1;f1=d;}else if(d<f2)f2=d;}}
   var ev=f2<1e9?Math.sqrt(f2)-Math.sqrt(f1):99;E[j*gw+i]=ev;
   var fr2=0,dmin=9;for(var pk2=0;pk2<FV.P.length;pk2++){var Pr=FV.P[pk2],dq2=Math.hypot(x-Pr.x,y-Pr.y)/Pr.R;fr2=Math.max(fr2,1-dq2);if(dq2<dmin)dmin=dq2;}
   var vv=Math.max(0,1-ev/3.2)*Math.max(0,fr2)*(FV.clr?FV.clr[j*gw+i]:1),cc=cl3[dmin<.45?0:dmin<.8?1:2],o=(j*gw+i)*4;   /* veines : bande où les deux graines les plus proches sont à égale distance */
   ID[o]=cc[0];ID[o+1]=cc[1];ID[o+2]=cc[2];ID[o+3]=Math.min(255,vv*230)|0;
   if(!FV.rg||FV.rg.length!==gw*gh)FV.rg=new Uint8Array(gw*gh);FV.rg[j*gw+i]=(ev<2.8&&vv>.06)?1:0;}
  FV.ic.putImageData(FV.id,0,0);
  if(!FV.lay){FV.lay=document.createElement('canvas');FV.lay.width=VW*2;FV.lay.height=VH*2;FV.lc=FV.lay.getContext('2d');
   FV.lay2=document.createElement('canvas');FV.lay2.width=VW*2;FV.lay2.height=VH*2;FV.lc2=FV.lay2.getContext('2d');}
  var lc=FV.lc,lc2=FV.lc2,iso=4.2,segs=[];lc.setTransform(2,0,0,2,0,0);lc.clearRect(0,0,VW,VH);lc.lineCap='round';lc2.setTransform(2,0,0,2,0,0);lc2.clearRect(0,0,VW,VH);lc2.lineCap='round';
  function lp(a,b){return (iso-a)/((b-a)||1e-6);}
  var TB={1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],5:[[3,0],[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[0,2]],10:[[0,1],[2,3]],11:[[1,2]],12:[[1,3]],13:[[0,1]],14:[[3,0]]};
  for(j=0;j<gh-1;j++)for(i=0;i<gw-1;i++){
   var a0=E[j*gw+i],a1=E[j*gw+i+1],a2=E[(j+1)*gw+i+1],a3=E[(j+1)*gw+i],m=(a0<iso?1:0)|(a1<iso?2:0)|(a2<iso?4:0)|(a3<iso?8:0);
   if(m===0||m===15)continue;
   var cx0=i*sx,cy0=j*sy,dm=1e9,fr=0;for(var pk=0;pk<FV.P.length;pk++){var Pq=FV.P[pk],dq=Math.hypot(cx0-Pq.x,cy0-Pq.y)/Pq.R;if(dq<dm){dm=dq;}fr=Math.max(fr,1-dq);}var fade=Math.max(0,fr)*(FV.clr[j*gw+i]);dm*=110;
   var mk=.55+.45*Math.sin(cx0*.035+t*.8)*Math.sin(cy0*.03-t*.6);fade*=Math.max(.35,Math.min(1,mk*1.4));
   if(fade<.04)continue;
   var e=[[i+lp(a0,a1),j],[i+1,j+lp(a1,a2)],[i+lp(a3,a2),j+1],[i,j+lp(a0,a3)]],L=TB[m];
   for(var z=0;z<L.length;z++)segs.push([e[L[z][0]][0]*sx,e[L[z][0]][1]*sy,e[L[z][1]][0]*sx,e[L[z][1]][1]*sy,fade,dm<55?0:(dm<110?1:2)]);}
  FV.segs=segs;var hs={};for(var hi=0;hi<segs.length;hi++){var g0=segs[hi];[[g0[0],g0[1]],[g0[2],g0[3]]].forEach(function(pt,e){var key=Math.round(pt[0]/3)+','+Math.round(pt[1]/3);(hs[key]=hs[key]||[]).push(hi*2+e);});}FV.hash=hs;   /* R149 : extrémités indexées — les éclats suivent les parois */
  var cols=[C.matter,C.boost,C.pink];
  /* relief : ombre portée sombre, puis le trait coloré, puis un liseré clair décalé vers la lumière */
  /* ombre sur un calque (fusion normale), couleur et liseré sur un second calque (fusion additive) : relief + éclat */
  [[1.2,1.4,'rgba(2,4,10,.55)',2.6,lc],[0,0,null,1.1,lc2],[-.5,-.6,'rgba(255,255,255,.55)',.45,lc2]].forEach(function(P){var X2=P[4];
   for(var b=0;b<3;b++){X2.strokeStyle=P[2]||rgba(cols[b],1);X2.lineWidth=P[3];X2.beginPath();
    for(var n=0;n<segs.length;n++){var g=segs[n];if(g[5]!==b)continue;X2.globalAlpha=g[4];X2.moveTo(g[0]+P[0],g[1]+P[1]);X2.lineTo(g[2]+P[0],g[3]+P[1]);}
    X2.stroke();}X2.globalAlpha=1;});}
 c.save();if(FV.img&&!FF_SOFT){c.globalCompositeOperation='lighter';c.globalAlpha=.36;c.imageSmoothingEnabled=true;c.drawImage(FV.img,0,0,VW,VH);c.globalCompositeOperation='source-over';}   /* veines douces */
 if(!FF_SOFT){c.globalAlpha=.4;c.drawImage(FV.lay,0,0,VW,VH);c.globalCompositeOperation='lighter';c.globalAlpha=.36;c.drawImage(FV.lay2,0,0,VW,VH);}   /* R150 : discret, comme sur les niveaux 6 et 12 */
 else if(FV.img){c.globalCompositeOperation='lighter';try{c.filter='blur(3.5px)';c.globalAlpha=.30;c.drawImage(FV.img,0,0,VW,VH);c.filter='blur(11px)';c.globalAlpha=.30;c.drawImage(FV.img,0,0,VW,VH);c.filter='none';}catch(e){}c.globalCompositeOperation='source-over';}   /* R169 (à valider) : texture douce — aucun contour tracé, seulement les veines fondues et leur halo */
 c.globalAlpha=1;
 /* gouttelettes en bordure */

 /* poussière : émise abondamment le long des parois, elle file dans le sens du champ et s'éteint */
 if(false){for(k=0;k<4;k++){var sg=FV.segs[Math.floor(Math.random()*FV.segs.length)];if(Math.random()>sg[4])continue;
   var ox=sg[0]-FV.mx,oy=sg[1]-FV.my,od=Math.hypot(ox,oy)||1;
   FV.dust.push({x:sg[0],y:sg[1],vx:ox/od*(.25+Math.random()*.5)+(Math.random()-.5)*.3,vy:oy/od*(.25+Math.random()*.5)+(Math.random()-.5)*.3,l:0,L:40+Math.random()*70,c:sg[5],r:.5+Math.random()*1.1});}
  if(FV.dust.length>320)FV.dust.splice(0,FV.dust.length-320);}
 var cols2=[C.matter,C.boost,C.pink];
 if(!rm)fvFlow(c);   /* R151 : l'énergie parcourt les veines du labyrinthe et s'y ramifie */
 for(i=FV.dust.length-1;i>=0;i--){var p=FV.dust[i];p.l++;if(p.l>p.L){FV.dust.splice(i,1);continue;}
  p.x+=p.vx;p.y+=p.vy;p.vx*=.985;p.vy*=.985;var al=Math.sin(Math.PI*p.l/p.L)*.6;
  c.fillStyle=rgba(cols2[p.c],al);c.fillRect(p.x-p.r/2,p.y-p.r/2,p.r,p.r);}
 c.restore();}

/* ══ R153 — MÉCANIQUE DÉCORATIVE (monde 6) : la même langue que les pièces mobiles du niveau 6 (bielle, ancre, cuivre doré),
   en retrait — traits fins, transparence, mouvement lent et continu. ══ */
function gearP(c,x,y,r,n,a){var i,k=n*2;c.beginPath();for(i=0;i<=k*2;i++){var u=i/(k*2)*6.2832+a,rr=(Math.floor(i/2)%2)?r:r-r*.16;var px=x+Math.cos(u)*rr,py=y+Math.sin(u)*rr;if(i)c.lineTo(px,py);else c.moveTo(px,py);}c.closePath();}
function gear(c,x,y,r,n,a,al){var G=[224,178,76],Wc=[255,236,190],i;c.fillStyle=rgba(G,al*.06);gearP(c,x,y,r,n,a);c.fill();c.strokeStyle=rgba(G,al*.55);c.lineWidth=1;c.stroke();
 c.strokeStyle=rgba(G,al*.3);c.beginPath();c.arc(x,y,r*.62,0,6.2832);c.stroke();
 for(i=0;i<5;i++){var u=a+i*1.2566;c.beginPath();c.moveTo(x+Math.cos(u)*r*.18,y+Math.sin(u)*r*.18);c.lineTo(x+Math.cos(u)*r*.6,y+Math.sin(u)*r*.6);c.stroke();}
 c.fillStyle=rgba(Wc,al*.7);c.beginPath();c.arc(x,y,2.2,0,6.2832);c.fill();}
function mechDeco(c){var t=now(),G=[224,178,76],Wc=[255,236,190],i;c.save();c.lineCap='round';c.lineJoin='round';
 for(i=0;i<D.mech.length;i++){var m=D.mech[i],x=m.x,y=m.y,w=t*.012*m.s*m.d+m.ph,al=.95;c.save();c.translate(x,y);c.scale(m.k||1,m.k||1);c.translate(-x,-y);
  if(m.t==='train'){var r1=20,r2=13,n1=14,n2=9,ang=m.ph,x2=x+Math.cos(ang)*(r1+r2-2),y2=y+Math.sin(ang)*(r1+r2-2),r3=9,x3=x2+Math.cos(ang+1.3)*(r2+r3-1.5),y3=y2+Math.sin(ang+1.3)*(r2+r3-1.5);
   gear(c,x,y,r1,n1,w,al);gear(c,x2,y2,r2,n2,-w*n1/n2+Math.PI/n2,al);gear(c,x3,y3,r3,6,w*n1/6,al*.9);}
  else if(m.t==='crank'){var cr=12,ax=x-14,ay=y,px=ax+Math.cos(w)*cr,py=ay+Math.sin(w)*cr,Lr=34,sx2=px+Math.sqrt(Math.max(1,Lr*Lr-(py-ay)*(py-ay))),sy2=ay;
   gear(c,ax,ay,cr+5,12,w,al*.8);c.strokeStyle=rgba(G,al*.35);c.lineWidth=7;c.beginPath();c.moveTo(ax+cr+12,ay);c.lineTo(ax+cr+Lr+26,ay);c.stroke();   /* glissière */
   c.strokeStyle=rgba(Wc,al*.7);c.lineWidth=1.6;c.beginPath();c.moveTo(px,py);c.lineTo(sx2,sy2);c.stroke();   /* bielle */
   c.fillStyle=rgba(G,al*.45);c.fillRect(sx2-6,sy2-5,12,10);c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1;c.strokeRect(sx2-6,sy2-5,12,10);
   c.fillStyle=rgba(Wc,al*.85);c.beginPath();c.arc(px,py,2,0,6.2832);c.fill();}
  else if(m.t==='escape'){var tick=Math.floor(t*.025*m.s),fr=(t*.025*m.s)%1,ea=(tick+Math.min(1,fr*4))*(6.2832/15),sw=Math.sin(t*.025*m.s*Math.PI)*.35;
   gear(c,x,y+8,16,15,ea*m.d,al);var Lp=38,ax2=x,ay2=y-18;   /* roue d'échappement et ancre */
   c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1.2;c.beginPath();c.moveTo(ax2,ay2);c.lineTo(ax2+Math.sin(sw)*Lp,ay2+Math.cos(sw)*Lp);c.stroke();
   c.strokeStyle=rgba(G,al*.7);c.lineWidth=2;c.beginPath();c.moveTo(ax2+Math.sin(sw+.7)*14,ay2+Math.cos(sw+.7)*14);c.quadraticCurveTo(ax2,ay2-6,ax2+Math.sin(sw-.7)*14,ay2+Math.cos(sw-.7)*14);c.stroke();
   var bx=ax2+Math.sin(sw)*Lp,by=ay2+Math.cos(sw)*Lp,g1=c.createRadialGradient(bx,by,0,bx,by,7);g1.addColorStop(0,rgba(Wc,al*.8));g1.addColorStop(1,rgba(G,0));c.fillStyle=g1;c.beginPath();c.arc(bx,by,7,0,6.2832);c.fill();}
  else if(m.t==='cam'){var cx3=x,cy3=y+10,ca=w;c.strokeStyle=rgba(G,al*.55);c.lineWidth=1;c.beginPath();
   for(var k=0;k<=40;k++){var u=k/40*6.2832,rr=13+7*Math.max(0,Math.cos(u)),X=cx3+Math.cos(u+ca)*rr,Y=cy3+Math.sin(u+ca)*rr;if(k)c.lineTo(X,Y);else c.moveTo(X,Y);}c.stroke();
   var lift=0;for(var k2=0;k2<40;k2++){var u2=k2/40*6.2832;if(Math.abs(Math.sin(u2+ca)+1)<.08){lift=7*Math.max(0,Math.cos(u2));}}
   var top=cy3-13-7*Math.max(0,Math.cos(-Math.PI/2-ca));c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1.4;c.beginPath();c.moveTo(cx3,top);c.lineTo(cx3,top-26);c.stroke();
   c.strokeStyle=rgba(G,al*.3);c.lineWidth=5;c.beginPath();c.moveTo(cx3-8,cy3-40);c.lineTo(cx3+8,cy3-40);c.stroke();
   c.fillStyle=rgba(Wc,al*.7);c.beginPath();c.arc(cx3,top,2.2,0,6.2832);c.fill();c.beginPath();c.arc(cx3,cy3,2,0,6.2832);c.fill();}
  c.restore();}
 c.restore();}
/* ══ R156 — ÉLÉMENTS QUANTIQUES REDESSINÉS (Simon : « pas mal de confusion ») ══
   Une seule langue, l'optique quantique ; chaque paire intriquée a SA couleur, et tout ce qu'elle commande porte cette couleur :
   · qubit : petite sphère de Bloch (équateur, méridien) + flèche de spin ↑/↓ = l'état ; anneau pointillé = rayon de contact ;
   · lien : double hélice de lumière entre les deux qubits, signe « = » (même état) ou « ≠ » (états opposés) au milieu ;
     une onde parcourt le lien au moment du basculement ;
   · porte : barrière de champ (hachures qui ondulent) quand elle est fermée, deux bornes et un fantôme pointillé quand elle
     est ouverte ; un fil fin la relie au qubit qui la commande ;
   · séparatrice (superposition) : cristal en losange à lame semi‑réfléchissante, franges d'interférence dans la zone ;
   · détecteur : diaphragme à six lames qui s'ouvre quand une superposition existe (il attend une mesure), s'éteint sinon ;
   · ralentisseur : cadran doré, aiguilles lentes, anneaux qui battent au ralenti. */
var QCOL=[[90,220,255],[190,140,255],[255,128,196],[120,255,190]],QEV=[];
function qon(){if(!QEV.on&&window.BUS){QEV.on=1;BUS.on('quantum.entangle',function(e){QEV.push({t:now(),e:e});});}}
function qubit(c,x,y,col,up,act,t,pul){var r=10;c.save();c.globalCompositeOperation='lighter';
 var g=c.createRadialGradient(x,y,0,x,y,r*2.4);g.addColorStop(0,rgba(col,.35+.3*pul));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r*2.4,0,6.2832);c.fill();
 c.strokeStyle=rgba(col,.85);c.lineWidth=1.3;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
 c.strokeStyle=rgba(col,.45);c.lineWidth=.8;c.beginPath();c.ellipse(x,y,r,r*.32,0,0,6.2832);c.stroke();c.beginPath();c.ellipse(x,y,r*.32*Math.abs(Math.cos(t*.02))+1,r,0,0,6.2832);c.stroke();
 var d=up?-1:1;c.strokeStyle=rgba([255,255,255],.95);c.lineWidth=1.8;c.beginPath();c.moveTo(x,y-d*6);c.lineTo(x,y+d*7);c.stroke();
 c.beginPath();c.moveTo(x-3.5,y+d*3.5);c.lineTo(x,y+d*7.5);c.lineTo(x+3.5,y+d*3.5);c.stroke();
 c.setLineDash([2,4]);c.lineDashOffset=-t*.3;c.strokeStyle=rgba(col,.35+.2*act);c.lineWidth=1;c.beginPath();c.arc(x,y,20,0,6.2832);c.stroke();c.setLineDash([]);   /* rayon de contact */
 if(pul>0){c.strokeStyle=rgba(col,pul*.8);c.lineWidth=1.5;c.beginPath();c.arc(x,y,r+(1-pul)*30,0,6.2832);c.stroke();}
 c.restore();}
function qent(c,lv,S0){qon();var t=now(),i,k;if(!lv.ent)return;
 for(i=0;i<lv.ent.length;i++){var e=lv.ent[i],st=(S0.ent&&S0.ent[i])||{on:false,pulse:0},col=QCOL[i%QCOL.length],opp=e[4]==='opp',pul=st.pulse||0;
  var ax=e[0],ay=e[1],bx=e[2],by=e[3],dx=bx-ax,dy=by-ay,L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;
  /* fils vers les portes commandées */
  (lv.gate||[]).forEach(function(g){if(g[4]!==i)return;var gx=(g[0]+g[2])/2,gy=(g[1]+g[3])/2,na=Math.hypot(gx-ax,gy-ay)<Math.hypot(gx-bx,gy-by),sx=na?ax:bx,sy=na?ay:by;
   c.save();c.setLineDash([1.5,5]);c.lineDashOffset=-t*.4;c.strokeStyle=rgba(col,.32);c.lineWidth=1;c.beginPath();c.moveTo(sx,sy);c.quadraticCurveTo((sx+gx)/2+(gy-sy)*.15,(sy+gy)/2-(gx-sx)*.15,gx,gy);c.stroke();c.restore();});
  /* lien : double hélice ; l'onde de basculement court de la source vers l'autre qubit */
  var wave=-1;for(k=QEV.length-1;k>=0;k--){var q=QEV[k];if(t-q.t>40){QEV.splice(k,1);continue;}if(Math.abs(q.e.ax-ax)<1&&Math.abs(q.e.ay-ay)<1){var f0=(t-q.t)/40;wave=q.e.from?1-f0:f0;}}
  c.save();c.globalCompositeOperation='lighter';
  for(var h=0;h<2;h++){c.beginPath();for(k=0;k<=40;k++){var u=k/40,o=Math.sin(u*Math.PI*6+t*.05+h*Math.PI)*4*Math.sin(u*Math.PI),x=ax+dx*u+nx*o,y=ay+dy*u+ny*o;if(k)c.lineTo(x,y);else c.moveTo(x,y);}
   c.strokeStyle=rgba(col,(st.on?.5:.28));c.lineWidth=1;c.stroke();}
  if(wave>=0){var wx=ax+dx*wave,wy=ay+dy*wave,gw=c.createRadialGradient(wx,wy,0,wx,wy,12);gw.addColorStop(0,rgba([255,255,255],.9));gw.addColorStop(1,rgba(col,0));c.fillStyle=gw;c.beginPath();c.arc(wx,wy,12,0,6.2832);c.fill();}
  var mx=ax+dx/2,my=ay+dy/2;c.fillStyle='rgba(5,9,15,.75)';c.beginPath();c.arc(mx,my,7,0,6.2832);c.fill();c.strokeStyle=rgba(col,.8);c.lineWidth=1.2;c.beginPath();
  c.moveTo(mx-3.5,my-1.8);c.lineTo(mx+3.5,my-1.8);c.moveTo(mx-3.5,my+1.8);c.lineTo(mx+3.5,my+1.8);if(opp){c.moveTo(mx+2.5,my-4.5);c.lineTo(mx-2.5,my+4.5);}c.stroke();
  c.restore();
  qubit(c,ax,ay,col,st.on,1,t,pul);qubit(c,bx,by,col,opp?!st.on:st.on,1,t,pul);}}
function qgate(c,g,open,t){var col=QCOL[(g[4]||0)%QCOL.length],dx=g[2]-g[0],dy=g[3]-g[1],L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,nx=-uy,ny=ux,k;c.save();c.lineCap='round';
 if(!open){c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.22);c.lineWidth=10;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();
  c.strokeStyle=rgba(col,.75);c.lineWidth=1;c.beginPath();for(k=4;k<L-2;k+=5){var w=Math.sin(k*.4+t*.12)*1.5,px=g[0]+ux*k,py=g[1]+uy*k;c.moveTo(px+nx*(-5)+ux*w,py+ny*(-5)+uy*w);c.lineTo(px+nx*5-ux*w,py+ny*5-uy*w);}c.stroke();   /* barrière de champ */
  c.strokeStyle=rgba([235,250,255],.9);c.lineWidth=1.4;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();}
 else{   /* R249 : porte ouverte lisible — deux jambages, battants rentrés, seuil en pointillés de la couleur de sa paire */
  c.setLineDash([5,5]);c.lineDashOffset=-t*.3;c.strokeStyle=rgba([235,240,255],.7);c.lineWidth=1.8;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();c.setLineDash([]);
  [[g[0],g[1],1],[g[2],g[3],-1]].forEach(function(q){c.strokeStyle=rgba(col,.95);c.lineWidth=3.4;c.beginPath();c.moveTo(q[0]+nx*10,q[1]+ny*10);c.lineTo(q[0]-nx*10,q[1]-ny*10);c.stroke();c.strokeStyle='rgba(255,255,255,.85)';c.lineWidth=1.2;c.stroke();
   c.strokeStyle=rgba(col,.7);c.lineWidth=3;c.beginPath();c.moveTo(q[0],q[1]);c.lineTo(q[0]+ux*7*q[2],q[1]+uy*7*q[2]);c.stroke();});
  c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.22);c.lineWidth=14;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();c.globalCompositeOperation='source-over';}
 [[g[0],g[1]],[g[2],g[3]]].forEach(function(p){c.fillStyle=rgba(col,open?.5:.9);c.beginPath();c.arc(p[0],p[1],3.2,0,6.2832);c.fill();c.strokeStyle=rgba([255,255,255],.7);c.lineWidth=.8;c.stroke();});
 c.restore();}
function qsup(c,z,t){var col=QCOL[1],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,k;c.save();
 var g=c.createRadialGradient(cx,cy,0,cx,cy,Math.max(z[2],z[3])*.7);g.addColorStop(0,rgba(col,.14));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.16);c.lineWidth=1;   /* franges */
 for(k=-z[2];k<z[2]+z[3];k+=7){var o=(t*.25)%7;c.beginPath();c.moveTo(z[0]+k+o,z[1]);c.lineTo(z[0]+k+o-z[3]*.6,z[1]+z[3]);c.stroke();}
 c.restore();c.save();c.globalCompositeOperation='lighter';
 var R=12;c.strokeStyle=rgba(col,.9);c.lineWidth=1.3;c.beginPath();c.moveTo(cx,cy-R);c.lineTo(cx+R,cy);c.lineTo(cx,cy+R);c.lineTo(cx-R,cy);c.closePath();c.stroke();
 c.fillStyle=rgba(col,.18);c.fill();c.strokeStyle=rgba([255,255,255],.85);c.beginPath();c.moveTo(cx-R*.7,cy+R*.7*.0);c.lineTo(cx+R*.7,cy);c.stroke();   /* lame semi‑réfléchissante */
 var a=z[4]===undefined?.42:z[4];[-1,1].forEach(function(sg){var aa=Math.PI/2+sg*a;c.strokeStyle=rgba(col,.55);c.lineWidth=1;c.setLineDash([3,4]);c.lineDashOffset=-t*.4;c.beginPath();c.moveTo(cx,cy+R);c.lineTo(cx+Math.cos(aa)*R*2.6,cy+R+Math.sin(aa)*R*2.6);c.stroke();c.setLineDash([]);});
 c.strokeStyle=rgba(col,.35);c.lineWidth=1;c.beginPath();c.roundRect?c.roundRect(z[0]+.5,z[1]+.5,z[2]-1,z[3]-1,8):c.rect(z[0],z[1],z[2],z[3]);c.stroke();
 c.restore();}
function qdet(c,d,armed,t,lv){var col=d[3]!=null?QCOL[d[3]%QCOL.length]:QCOL[0],x=d[0],y=d[1],r=d[2],k,op=armed?.55+.15*Math.sin(t*.1):.18;c.save();c.globalCompositeOperation='lighter';
 var g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(col,armed?.22:.06));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();
 c.strokeStyle=rgba(col,armed?.85:.4);c.lineWidth=1.3;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
 for(k=0;k<24;k++){var a=k/24*6.2832;c.globalAlpha=(k%6===0)?1:.5;c.beginPath();c.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r);c.lineTo(x+Math.cos(a)*(r-(k%6===0?5:2.5)),y+Math.sin(a)*(r-(k%6===0?5:2.5)));c.stroke();}c.globalAlpha=1;
 var ap=r*op,rot=t*.01;c.strokeStyle=rgba(col,armed?.75:.35);c.lineWidth=1;   /* diaphragme */
 for(k=0;k<6;k++){var a1=rot+k*1.0472;c.beginPath();c.moveTo(x+Math.cos(a1)*ap,y+Math.sin(a1)*ap);c.lineTo(x+Math.cos(a1+1.0472+.5)*(r-6),y+Math.sin(a1+1.0472+.5)*(r-6));c.stroke();}
 c.beginPath();for(k=0;k<=6;k++){var a2=rot+k*1.0472;if(k)c.lineTo(x+Math.cos(a2)*ap,y+Math.sin(a2)*ap);else c.moveTo(x+Math.cos(a2)*ap,y+Math.sin(a2)*ap);}c.stroke();
 c.fillStyle=rgba([255,255,255],armed?.9:.4);c.beginPath();c.arc(x,y,2,0,6.2832);c.fill();
 if(lv&&d[3]!=null&&lv.ent&&lv.ent[d[3]]){var e=lv.ent[d[3]],na=Math.hypot(e[0]-x,e[1]-y)<Math.hypot(e[2]-x,e[3]-y),ex=na?e[0]:e[2],ey=na?e[1]:e[3];   /* fil de commande : la mesure bascule cette paire */
  c.setLineDash([1.5,5]);c.lineDashOffset=-t*.4;c.strokeStyle=rgba(col,.4);c.lineWidth=1;c.beginPath();c.moveTo(x,y);c.lineTo(ex,ey);c.stroke();c.setLineDash([]);}
 c.restore();}
/* R243 — RECOMBINEUR (lame séparatrice de sortie) rc=[x,y,r,angle°] : anneau discret, lame semi-argentée en diagonale,
   voie de sortie claire marquée par des chevrons ; armé quand deux copies existent (la lame miroite) ; à la fusion, éclair
   et franges d'interférence qui s'éteignent. Violet de la superposition + blanc. */
function qrec(c,rc,t,armed,age,wait){var V=[190,140,255],Wc=[236,240,255],cx=rc[0],cy=rc[1],r=rc[2],a=rc[3]*Math.PI/180,ux=Math.cos(a),uy=Math.sin(a),on=age<28?1-age/28:0,k;
 c.save();c.lineCap='round';
 var g=c.createRadialGradient(cx,cy,0,cx,cy,r*1.5);g.addColorStop(0,rgba(V,.22+.3*on));g.addColorStop(.7,rgba(V,.08));g.addColorStop(1,rgba(V,0));c.fillStyle=g;c.beginPath();c.arc(cx,cy,r*1.5,0,6.2832);c.fill();
 /* R249 : corps lisible — disque de verre sombre, anneau plein, deux demi-anneaux (cyan / violet) qui se rejoignent : « deux deviennent un » */
 var gd=c.createRadialGradient(cx-r*.3,cy-r*.3,0,cx,cy,r);gd.addColorStop(0,'rgba(40,34,70,.75)');gd.addColorStop(1,'rgba(10,10,24,.85)');c.fillStyle=gd;c.beginPath();c.arc(cx,cy,r*.82,0,6.2832);c.fill();
 c.strokeStyle=rgba(Wc,.55+.35*on);c.lineWidth=2;c.beginPath();c.arc(cx,cy,r,0,6.2832);c.stroke();
 var rr0=t*.01;c.lineWidth=3.2;c.strokeStyle=rgba([110,226,255],.85);c.beginPath();c.arc(cx,cy,r+4,rr0+.25,rr0+2.9);c.stroke();
 c.strokeStyle=rgba(V,.9);c.beginPath();c.arc(cx,cy,r+4,rr0+3.39,rr0+6.03);c.stroke();
 c.strokeStyle=rgba(V,.35+.3*on);c.lineWidth=1;c.setLineDash([2,4]);c.lineDashOffset=-t*.2;c.beginPath();c.arc(cx,cy,r*.82,0,6.2832);c.stroke();c.setLineDash([]);
 /* lame à 45° de la voie de sortie */
 var la=a+Math.PI/4,lx=Math.cos(la)*r*.78,ly=Math.sin(la)*r*.78,sh=armed?.5+.5*Math.sin(t*.12):0;
 var gl=c.createLinearGradient(cx-lx,cy-ly,cx+lx,cy+ly);gl.addColorStop(0,rgba(Wc,.25));gl.addColorStop(.5,rgba(Wc,.65+.3*sh));gl.addColorStop(1,rgba(Wc,.25));
 c.strokeStyle=gl;c.lineWidth=2.4;c.beginPath();c.moveTo(cx-lx,cy-ly);c.lineTo(cx+lx,cy+ly);c.stroke();
 c.strokeStyle=rgba(V,.8);c.lineWidth=.8;c.beginPath();c.moveTo(cx-lx+uy*1.6,cy-ly-ux*1.6);c.lineTo(cx+lx+uy*1.6,cy+ly-ux*1.6);c.stroke();
 /* R248 : une version est arrivée — l'anneau se vide pendant qu'elle attend sa jumelle */
 if(wait>0){c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(Wc,.85);c.lineWidth=3;c.beginPath();c.arc(cx,cy,r+5,-1.5708,-1.5708+6.2832*wait);c.stroke();
  c.strokeStyle=rgba(V,.35);c.lineWidth=1;c.beginPath();c.arc(cx,cy,r+5,0,6.2832);c.stroke();c.restore();}
 /* R248 : rc[5] = lancement — l'arc que suivra la particule recombinée, visible d'avance */
 if(rc[5]){var vx=ux*rc[5],vy=uy*rc[5],x=cx,y=cy,n,al3=.5+.35*(armed?.5+.5*Math.sin(t*.1):0)+.5*on;c.save();c.globalCompositeOperation='lighter';
  for(n=0;n<90;n++){vy+=.40;x+=vx;y+=vy;if(x<4||x>356||y>476)break;if(n%3===0){var fd=1-n/150;c.fillStyle=rgba(n%6?V:Wc,al3*fd);c.beginPath();c.arc(x,y,n%6?1.8:2.6,0,6.2832);c.fill();}}
  c.restore();}
 /* voie constructive */
 c.globalCompositeOperation='lighter';
 for(k=0;k<3;k++){var d=r+6+k*7+((t*.25)%7),al=(.25+.5*on)*(1-k*.25);c.strokeStyle=rgba(Wc,al);c.lineWidth=1.4;var px=cx+ux*d,py=cy+uy*d;
  c.beginPath();c.moveTo(px-ux*4-uy*4,py-uy*4+ux*4);c.lineTo(px,py);c.lineTo(px-ux*4+uy*4,py-uy*4-ux*4);c.stroke();}
 /* franges à la fusion */
 if(on>0){for(k=-3;k<=3;k++){var fx=cx+ux*(r*.4+(1-on)*30),fy=cy+uy*(r*.4+(1-on)*30),ox=-uy*k*5,oy=ux*k*5,al2=on*(k%2?0.25:0.7)*(1-Math.abs(k)/4);
  c.strokeStyle=rgba(k%2?V:Wc,al2);c.lineWidth=1.6;c.beginPath();c.moveTo(fx+ox-ux*6,fy+oy-uy*6);c.lineTo(fx+ox+ux*6,fy+oy+uy*6);c.stroke();}
  c.strokeStyle=rgba(Wc,.7*on);c.lineWidth=2;c.beginPath();c.arc(cx,cy,r*(.6+(1-on)*.9),0,6.2832);c.stroke();}
 c.restore();}
/* R247 · MACHINE « mz » (Monde 11 – niveau 6, L'interféromètre) — banc d'optique : plaque gravée et vissée, bras de verre
   qui s'allument au passage d'une version, miroirs argentés aux coudes, cube séparateur, collimateur de source et écran
   de franges (ondes superposées = franges ; une seule version = tache). layer 0 sous les murs, 1 par-dessus. */
var MACHS={eL:0,eR:0,fr:0,t:-1};
function qmachArm(c,m){var P=[[135,143],[93,231],[93,305],[154,395],[182,375],[127,295],[127,239],[180,200]],k;c.beginPath();
 for(k=0;k<P.length;k++){var x=m?360-P[k][0]:P[k][0];if(k)c.lineTo(x,P[k][1]);else c.moveTo(x,P[k][1]);}c.closePath();}
function qmach(c,lv,S,layer){if(lv.mach!=='mz')return;var t=S.t||0,C=[110,226,255],V=[190,140,255],Wc=[236,242,255],k,i;
 c.save();
 if(!layer){
  if(t<MACHS.t){MACHS.eL=MACHS.eR=MACHS.fr=0;}MACHS.t=t;
  var bs=[S.ball,S.branch],inL=0,inR=0;
  for(i=0;i<2;i++){var b=bs[i];if(!b)continue;qmachArm(c,0);if(c.isPointInPath(b.x,b.y))inL=1;qmachArm(c,1);if(c.isPointInPath(b.x,b.y))inR=1;}
  MACHS.eL+=((inL?1:0)-MACHS.eL)*(inL?.25:.04);MACHS.eR+=((inR?1:0)-MACHS.eR)*(inR?.25:.04);
  MACHS.fr+=((S.branch?1:0)-MACHS.fr)*.06;
  /* plaque du banc */
  var g=c.createLinearGradient(0,128,0,420);g.addColorStop(0,'rgba(20,28,46,.86)');g.addColorStop(1,'rgba(9,13,24,.9)');c.fillStyle=g;
  c.beginPath();c.roundRect?c.roundRect(58,128,244,292,14):c.rect(58,128,244,292);c.fill();
  c.strokeStyle='rgba(150,175,215,.20)';c.lineWidth=1;c.stroke();
  c.strokeStyle='rgba(150,175,215,.08)';c.beginPath();c.roundRect?c.roundRect(63,133,234,282,11):c.rect(63,133,234,282);c.stroke();
  /* graduations */
  c.strokeStyle='rgba(170,195,230,.22)';c.lineWidth=.8;c.beginPath();
  for(k=0;k<=26;k++){var gy=142+k*10,l=k%5?3:7;c.moveTo(63,gy);c.lineTo(63+l,gy);c.moveTo(297,gy);c.lineTo(297-l,gy);}c.stroke();
  /* vis */
  [[70,140],[290,140],[70,408],[290,408]].forEach(function(p,j){var r2=c.createRadialGradient(p[0]-1,p[1]-1,0,p[0],p[1],4);r2.addColorStop(0,'rgba(220,230,250,.55)');r2.addColorStop(1,'rgba(90,105,135,.35)');
   c.fillStyle=r2;c.beginPath();c.arc(p[0],p[1],3.6,0,6.2832);c.fill();c.strokeStyle='rgba(10,14,24,.8)';c.lineWidth=1;var a=.6+j*.9;c.beginPath();c.moveTo(p[0]-Math.cos(a)*2.6,p[1]-Math.sin(a)*2.6);c.lineTo(p[0]+Math.cos(a)*2.6,p[1]+Math.sin(a)*2.6);c.stroke();});
  /* bras de verre */
  [[0,MACHS.eL],[1,MACHS.eR]].forEach(function(q){var m=q[0],e=q[1],x0=m?267:93,x1=m?233:127;
   var gg=c.createLinearGradient(x0,0,x1,0);gg.addColorStop(0,rgba(C,.10+.30*e));gg.addColorStop(.5,rgba(Wc,.04+.18*e));gg.addColorStop(1,rgba(C,.08+.26*e));
   c.fillStyle=gg;qmachArm(c,m);c.fill();
   /* l'onde qui court le long du bras */
   c.save();qmachArm(c,m);c.clip();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(C,.10+.35*e+.12*MACHS.fr);c.lineWidth=1.2;
   var M=[[158,172],[110,235],[110,300],[168,385]];c.setLineDash([6,10]);c.lineDashOffset=-t*.9;c.beginPath();
   for(k=0;k<M.length;k++){var mx=m?360-M[k][0]:M[k][0];if(k)c.lineTo(mx,M[k][1]);else c.moveTo(mx,M[k][1]);}c.stroke();c.setLineDash([]);c.restore();});
  /* écran de franges */
  var sx=66,sy=338,sw=34,sh=54;c.fillStyle='rgba(4,7,14,.92)';c.beginPath();c.roundRect?c.roundRect(sx,sy,sw,sh,4):c.rect(sx,sy,sw,sh);c.fill();
  c.strokeStyle='rgba(150,175,215,.30)';c.lineWidth=1;c.stroke();
  c.save();c.beginPath();c.rect(sx+2,sy+2,sw-4,sh-4);c.clip();c.globalCompositeOperation='lighter';
  for(k=0;k<sw-4;k++){var u=(k-(sw-4)/2)/((sw-4)/2),env=Math.exp(-u*u*2.2),fr=MACHS.fr*Math.pow(Math.cos(u*7.5+Math.sin(t*.03)*.4),2)+(1-MACHS.fr)*.55,al=env*fr*(.35+.4*Math.max(MACHS.eL,MACHS.eR,MACHS.fr));
   c.fillStyle=rgba(MACHS.fr>.5?V:C,al);c.fillRect(sx+2+k,sy+2,1,sh-4);}
  c.fillStyle='rgba(236,242,255,.10)';for(k=0;k<sh-4;k+=3)c.fillRect(sx+2,sy+2+k,sw-4,1);c.restore();
  c.strokeStyle='rgba(150,175,215,.35)';c.lineWidth=.8;c.beginPath();c.moveTo(sx+sw,sy+sh*.5);c.lineTo(sx+sw+12,sy+sh*.5);c.lineTo(sx+sw+22,sy+sh*.5+30);c.stroke();
 }else{
  /* miroirs aux coudes extérieurs */
  [[93,231,1],[93,305,-1],[267,231,1],[267,305,-1]].forEach(function(p){var x=p[0],y=p[1],sd=x<180?-1:1,ax=sd*.7,ay=p[2]*.7*-1;
   var nx=-ay,ny=ax,L2=12;c.save();c.translate(x+sd*10,y+p[2]*-6);
   c.strokeStyle='rgba(60,72,98,.9)';c.lineWidth=4;c.beginPath();c.moveTo(-nx*L2,-ny*L2);c.lineTo(nx*L2,ny*L2);c.stroke();
   var gl=c.createLinearGradient(-nx*L2,-ny*L2,nx*L2,ny*L2),s=(Math.sin(t*.02+x*.05+y*.03)+1)/2;gl.addColorStop(0,'rgba(200,215,240,.6)');gl.addColorStop(Math.max(.05,Math.min(.95,s)),'rgba(255,255,255,1)');gl.addColorStop(1,'rgba(200,215,240,.6)');
   c.strokeStyle=gl;c.lineWidth=2;c.beginPath();c.moveTo(-nx*L2,-ny*L2);c.lineTo(nx*L2,ny*L2);c.stroke();
   c.strokeStyle='rgba(150,175,215,.45)';c.lineWidth=1;c.beginPath();c.moveTo(sd*2,0);c.lineTo(sd*9,0);c.moveTo(sd*9,-4);c.lineTo(sd*9,4);c.stroke();c.restore();});
  /* cube séparateur */
  var z=(lv.sup||[])[0];if(z){var cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,h=17;c.strokeStyle='rgba(200,220,255,.55)';c.lineWidth=1;c.strokeRect(cx-h,cy-h,2*h,2*h);
   c.strokeStyle='rgba(200,220,255,.18)';c.strokeRect(cx-h+4,cy-h-4,2*h,2*h);c.beginPath();c.moveTo(cx-h,cy-h);c.lineTo(cx-h+4,cy-h-4);c.moveTo(cx+h,cy-h);c.lineTo(cx+h+4,cy-h-4);c.moveTo(cx+h,cy+h);c.lineTo(cx+h+4,cy+h-4);c.stroke();
   c.strokeStyle=rgba(Wc,.5+.3*Math.sin(t*.05));c.lineWidth=1.4;c.beginPath();c.moveTo(cx-h+2,cy+h-2);c.lineTo(cx+h-2,cy-h+2);c.stroke();}
  /* collimateur de la source */
  var bx=lv.ball[0];c.strokeStyle='rgba(150,175,215,.40)';c.lineWidth=1.2;c.beginPath();c.moveTo(bx-11,6);c.lineTo(bx-11,58);c.moveTo(bx+11,6);c.lineTo(bx+11,58);c.stroke();
  c.fillStyle='rgba(60,72,98,.9)';c.fillRect(bx-15,56,8,4);c.fillRect(bx+7,56,8,4);
  c.globalCompositeOperation='lighter';var ag=c.createRadialGradient(bx,62,0,bx,62,12);ag.addColorStop(0,rgba(C,.35+.2*Math.sin(t*.08)));ag.addColorStop(1,rgba(C,0));c.fillStyle=ag;c.beginPath();c.arc(bx,62,12,0,6.2832);c.fill();
 }
 c.restore();}
function qtdil(c,z,t){var G=[255,206,110],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,R=Math.min(z[2],z[3])*.5,k;c.save();
 var g=c.createRadialGradient(cx,cy,0,cx,cy,Math.max(z[2],z[3])*.75);g.addColorStop(0,rgba(G,.13));g.addColorStop(1,rgba(G,.02));c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 c.globalCompositeOperation='lighter';for(k=0;k<3;k++){var ph=((t*.004+k/3)%1);c.strokeStyle=rgba(G,.3*(1-ph));c.lineWidth=1;c.beginPath();c.arc(cx,cy,R*(.3+ph*.9),0,6.2832);c.stroke();}   /* battement ralenti */
 c.strokeStyle=rgba(G,.55);c.lineWidth=1;c.beginPath();c.arc(cx,cy,14,0,6.2832);c.stroke();for(k=0;k<12;k++){var a=k*.5236;c.beginPath();c.moveTo(cx+Math.cos(a)*11,cy+Math.sin(a)*11);c.lineTo(cx+Math.cos(a)*14,cy+Math.sin(a)*14);c.stroke();}
 c.strokeStyle=rgba([255,240,210],.9);c.lineWidth=1.4;c.beginPath();c.moveTo(cx,cy);c.lineTo(cx+Math.cos(t*.006-1.57)*10,cy+Math.sin(t*.006-1.57)*10);c.moveTo(cx,cy);c.lineTo(cx+Math.cos(t*.0005)*6.5,cy+Math.sin(t*.0005)*6.5);c.stroke();
 c.setLineDash([2,5]);c.strokeStyle=rgba(G,.35);c.beginPath();c.roundRect?c.roundRect(z[0]+.5,z[1]+.5,z[2]-1,z[3]-1,10):c.rect(z[0],z[1],z[2],z[3]);c.stroke();c.setLineDash([]);
 c.restore();}
/* ══ R156 — APOTHÉOSE : fin du dernier niveau ══ Une onde part du bassin ; une gerbe par monde traversé (onze feux, chacun aux
   couleurs de son monde) ; les onze mondes s'allument en constellation et se relient ; le message de fin se lève lentement. */
var FIN=null;
/* R202 · PRÉLUDE DE FIN — le niveau s'assombrit, le bassin se charge et s'élève en lumière ; la scène cinématique
   (« Retour à l'équilibre ») est l'épilogue de hero.js, joué en plein écran par engine.js. */
function finale(c,age,title,sub,cup){var bx=cup?cup[0]+cup[2]/2:180,by=cup?cup[1]-18:440,u=Math.max(0,Math.min(1,age/80)),k;
 c.save();c.fillStyle='rgba(5,7,13,'+(.85*u).toFixed(3)+')';c.fillRect(-80,-80,520,640);c.globalCompositeOperation='lighter';
 var r=8+40*u,g=c.createRadialGradient(bx,by,0,bx,by,r);g.addColorStop(0,'rgba(241,244,246,'+(.85*u).toFixed(3)+')');g.addColorStop(.35,'rgba(155,235,75,'+(.3*u).toFixed(3)+')');g.addColorStop(1,'rgba(77,215,255,0)');
 c.fillStyle=g;c.beginPath();c.arc(bx,by,r,0,6.2832);c.fill();
 for(k=0;k<3;k++){var ra=((age-k*12)%48+48)%48/48;c.strokeStyle='rgba(155,235,75,'+(.5*(1-ra)*u).toFixed(3)+')';c.lineWidth=1.2;c.beginPath();c.ellipse(bx,by,10+ra*60,(10+ra*60)*.4,0,0,6.2832);c.stroke();}
 c.restore();
}
function back(c,lv){
 if(!D.busOn&&typeof BUS!=='undefined'){D.busOn=true;
  BUS.on('ball.bounce',function(e){if(D.wd===2&&e.v>1.5)spawnTrack(e.x,e.y,Math.atan2(-e.ny,-e.nx)+Math.PI,3+e.v*.15,true);});
  BUS.on('ball.boost',function(e){D.flash.push({x:e.x,y:e.y,life:1});});
  BUS.on('ball.impact',impactFx);BUS.on('ball.bounce',impactFx);
  BUS.on('ball.tunnel',function(e){TUN.push({x:e.x,y:e.y,l:1});});}
 if(D.key!==lv.idx)compose(lv);
 var t=now(),i,b=(typeof S!=='undefined'&&S.ball)?S.ball:{x:-99,y:-99};
 c.save();c.globalCompositeOperation='screen';
 c.globalAlpha=.8+.18*Math.sin(t*.012);c.drawImage(D.neb[0],Math.sin(t*.0022)*12-8,Math.cos(t*.0017)*9-6,VW+16,VH+12);
 c.globalAlpha=.5+.2*Math.sin(t*.009+1.3);c.drawImage(D.neb[1],-Math.sin(t*.0015)*16-12,Math.sin(t*.0021)*11-10,VW+24,VH+20);c.restore();
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.dust.length;i++){var d=D.dust[i];d.x+=d.vx*d.z;d.y+=d.vy*d.z;
  var dx=d.x-b.x,dy=d.y-b.y,dd=dx*dx+dy*dy;if(dd<1600&&dd>1){var r=Math.sqrt(dd),f=(1-r/40)*.9*d.z;d.x+=dx/r*f;d.y+=dy/r*f;}
  if(d.y<-4)d.y=VH+4;if(d.y>VH+4)d.y=-4;if(d.x<-4)d.x=VW+4;if(d.x>VW+4)d.x=-4;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),a=(.12+.5*d.z)*tw,sz=.5+d.z*1.3;c.fillStyle=rgba(d.col,a);c.fillRect(d.x-sz/2,d.y-sz/2,sz,sz);}
 c.restore();
 /* R88 : aucun motif de décor dans la zone de réussite (ni voiles, ni anneaux, ni hélices) — on les masque autour du bassin */
 if(D.wd===8&&F3_ON)ferro4(c,lv);   /* R171 : avant le masque rectangulaire — le ferrofluide s'efface en douceur autour du bassin (masque f4Reset) */
 var cpz=lv.cup;c.save();if(cpz){c.beginPath();c.rect(-20,-20,VW+40,VH+40);c.rect(cpz[0]-16,cpz[1]-78,cpz[2]+32,96);c.clip('evenodd');}
 veils(c);
 if(D.wd===3)torusCells(c,VW*.62,VH*.30,78,11,.2);
 if(D.wd===8&&!F3_ON)ferro2(c,lv);
 if(D.mech&&D.mech.length)mechDeco(c);
 if(D.wd===3){drawRing(c);synchro(c);}
 else if(D.wd===2){
  if(t%70===0){var side=Math.floor(rnd(t)*3),x=side===0?-5:side===1?VW+5:rnd(t*1.7)*VW,y=side===2?VH+5:VH*.3+rnd(t*2.3)*VH*.6;
   spawnTrack(x,y,Math.atan2(VH*.5-y,VW*.5-x)+(rnd(t*3)-.5),2.2+rnd(t*4)*1.6,false);}
  c.save();c.globalCompositeOperation='lighter';
  for(i=0;i<D.tracks.length;i++){var tr=D.tracks[i];tr.age++;
   if(tr.v>.25){tr.a+=tr.q*tr.k*(3/tr.v);tr.v*=.985;tr.x+=Math.cos(tr.a)*tr.v;tr.y+=Math.sin(tr.a)*tr.v;if(tr.age%2===0)tr.pts.push([tr.x,tr.y]);if(tr.pts.length>140)tr.pts.shift();}
   var fd=Math.min(1,(tr.life-tr.age)/60)*Math.min(1,tr.age/6);
   for(var k=0;k<tr.pts.length;k++){c.fillStyle=rgba(tr.col,fd*(.25+.65*k/tr.pts.length)*.8);c.beginPath();c.arc(tr.pts[k][0],tr.pts[k][1],.7+(k%3===0?.6:0),0,6.2832);c.fill();}}
  D.tracks=D.tracks.filter(function(q){return q.age<q.life;});
  for(i=0;i<D.bubbles.length;i++){var bb=D.bubbles[i];bb.y-=bb.sp;bb.x+=Math.sin(t*.04+bb.ph)*.25;if(bb.y<-5){bb.y=VH+5;bb.x=rnd(t+bb.ph*99)*VW;}
   c.strokeStyle=rgba(C.white,.2);c.lineWidth=.7;c.beginPath();c.arc(bb.x,bb.y,bb.r,0,6.2832);c.stroke();}
  c.restore();
 }else{
  if(D.ghost)helix(c,D.ghost.x0,D.ghost.y0,D.ghost.x1,D.ghost.y1,30,2,.011,D.pal[0],D.pal[D.pal.length-1],.14,80);
  for(i=0;i<D.hel.length;i++){var h=D.hel[i];helix(c,h.x0,h.y0,h.x1,h.y1,h.amp,h.turns,h.sp,h.a,h.b,h.al);}
 }
 c.restore();
}

/* ============================ ZONES INTERDITES ============================ */
/* R163 — ZONE INTERDITE = PRINCIPE D'EXCLUSION DE PAULI : la région est déjà pleine, chaque place y est occupée par une paire
   d'états (spin haut / spin bas) ; rien ne peut s'y loger, ni la particule ni la matière tracée. Réseau hexagonal de paires
   qui respirent en rose-rouge, voile léger plus dense vers les bords, liseré lumineux parcouru d'une pulsation lente ;
   quand le joueur insiste, une onde de refus traverse le réseau depuis le point touché (S.ndHit). */
var NDR=[255,84,112],NDW=[255,190,205];
function ndIn(lv,x,y,skip){for(var j=0;j<lv.nd.length;j++){if(j===skip)continue;var q=lv.nd[j];if(x>=q[0]-.5&&x<=q[0]+q[2]+.5&&y>=q[1]-.5&&y<=q[1]+q[3]+.5)return true;}return false;}
function ndPauli(c,lv){var t=now(),tt=(typeof S!=='undefined'&&S.t)||t,hit=(typeof S!=='undefined'&&S.ndHit)||null,ha=hit?(tt-hit.t):1e9;
 for(var i=0;i<lv.nd.length;i++){var r=lv.nd[i],x0=r[0],y0=r[1],w=r[2],h=r[3];
  /* côtés exposés (un côté collé à une autre zone n'est ni bordé ni renforcé) */
  var exT=!ndIn(lv,x0+w/2,y0-2,i),exB=!ndIn(lv,x0+w/2,y0+h+2,i),exL=!ndIn(lv,x0-2,y0+h/2,i),exR=!ndIn(lv,x0+w+2,y0+h/2,i);
  c.save();c.beginPath();c.rect(x0,y0,w,h);c.clip();
  var gz=c.createLinearGradient(x0,y0,x0,y0+h);gz.addColorStop(0,rgba(NDR,.075));gz.addColorStop(.5,rgba(NDR,.035));gz.addColorStop(1,rgba(NDR,.075));
  c.fillStyle=gz;c.fillRect(x0,y0,w,h);
  var sp=22,rh=sp*.866,row=0,a,dx,dy,ed,k;c.globalCompositeOperation='lighter';
  for(var y=y0+rh*.5;y<y0+h;y+=rh,row++)for(var x=x0+(row%2?sp*.5:0)+sp*.25;x<x0+w;x+=sp){
   ed=Math.min(exL?x-x0:999,exR?x0+w-x:999,exT?y-y0:999,exB?y0+h-y:999);var edge=Math.max(.35,1-ed/60);
   var ph=Math.sin(tt*.035+x*.07+y*.11)*.5+.5,swp=Math.max(0,Math.sin((x+y)*.014-tt*.022));a=(.16+.20*ph+.22*swp*swp*swp)*edge;   /* onde lumineuse lente qui balaie le réseau */
   if(ha<70){var dd=Math.hypot(x-hit.x,y-hit.y),wv=ha*3.2;a+=Math.max(0,1-Math.abs(dd-wv)/18)*.6*(1-ha/70);}
   var sw=Math.sin(tt*.05+x*.13+y*.05)*1.4;   /* les deux spins tournent l'un autour de l'autre, en sens opposés */
   c.strokeStyle=rgba(NDR,a*.35);c.lineWidth=.9;c.beginPath();c.moveTo(x+sw,y-2.5);c.lineTo(x-sw,y+2.5);c.stroke();
   c.fillStyle=rgba(NDR,a);c.beginPath();c.arc(x+sw,y-2.6,1.8,0,6.2832);c.fill();c.fillStyle=rgba(NDW,a*.85);c.beginPath();c.arc(x-sw,y+2.6,1.8,0,6.2832);c.fill();}
  c.globalCompositeOperation='source-over';c.restore();
  /* liseré : trait fin lumineux + pulsation qui fait le tour */
  c.save();c.lineWidth=1;c.strokeStyle=rgba(NDR,.42);c.shadowColor=rgba(NDR,.6);c.shadowBlur=6;
  c.beginPath();if(exT){c.moveTo(x0,y0+.5);c.lineTo(x0+w,y0+.5);}if(exR){c.moveTo(x0+w-.5,y0);c.lineTo(x0+w-.5,y0+h);}if(exB){c.moveTo(x0,y0+h-.5);c.lineTo(x0+w,y0+h-.5);}if(exL){c.moveTo(x0+.5,y0);c.lineTo(x0+.5,y0+h);}c.stroke();c.shadowBlur=0;
  var per=2*(w+h),pos=((tt*1.1+i*137)%per),seg=46;c.lineWidth=1.8;c.lineCap='round';
  for(k=0;k<2;k++){var p0=(pos+k*per/2)%per;c.strokeStyle=rgba(NDW,.55);c.beginPath();
   for(var u=0;u<=seg;u+=4){var q=(p0+u)%per,px,py;if(q<w){px=x0+q;py=y0;}else if(q<w+h){px=x0+w;py=y0+q-w;}else if(q<2*w+h){px=x0+w-(q-w-h);py=y0+h;}else{px=x0;py=y0+h-(q-2*w-h);}
    var side=q<w?exT:q<w+h?exR:q<2*w+h?exB:exL;if(u&&side)c.lineTo(px,py);else c.moveTo(px,py);}c.globalAlpha=.9;c.stroke();c.globalAlpha=1;}
  c.restore();}
 if(hit&&ha<24){c.save();c.strokeStyle=rgba(NDW,(1-ha/24)*.7);c.lineWidth=1.2;c.beginPath();c.arc(hit.x,hit.y,6+ha*1.4,0,6.2832);c.stroke();c.restore();}}

/* R165 (essai) — ZONE INTERDITE = FLUCTUATIONS QUANTIQUES DU VIDE. Le vide y bouillonne : il emprunte de l'énergie pour faire
   naître des paires particule / antiparticule qui s'écartent puis se rejoignent et s'annihilent (ΔE·Δt ≥ ħ/2 : plus la paire
   est énergique, plus elle s'écarte et plus elle vit peu). Naissances tirées au hasard par cellule (Poisson éclairci, sans
   état : hachage de la cellule et de l'époque). Bord : seuls les côtés exposés, tracés par un bruit qui vibre (barrière
   incertaine). Refus d'un trait (S.ndHit) : une antiparticule jaillit de la zone, fonce sur la pointe du trait, et
   l'annihilation émet deux photons dos à dos (e⁺e⁻ → 2γ) et une onde de choc. ND_MODE='pauli' rétablit le rendu R163. */
var ND_MODE='vide',NDA=[255,236,244],NDC=[110,226,255];
function ndH(a,b,k){var s=Math.sin(a*127.1+b*311.7+k*74.7)*43758.5453;return s-Math.floor(s);}
/* R298 · Nervures : texture animée sous les zones interdites (rouge subtil). 10 images-clés précalculées (assets/img/nervures.webp, bruit 3D périodique) qui se fondent en boucle ;
   aucun bruit n'est calculé sur l'appareil. Masque (fondu depuis les bords exposés) calculé une fois par niveau. Coupée si « mouvement réduit », ou si le coût moyen dépasse 9 ms/trame. */
var NV={img:null,V:[],ok:false,off:false,fx:null,fc:null,cb:null,cbx:null,pat:{},lv:null,msk:null,bb:null,fr:0,ms:0,n:0};
(function(){try{var im=new Image();im.onload=function(){try{var n=10,w=im.width/n,h=im.height,i;for(i=0;i<n;i++){var cv=document.createElement('canvas');cv.width=w;cv.height=h;cv.getContext('2d').drawImage(im,i*w,0,w,h,0,0,w,h);NV.V.push(cv);}
  NV.fx=document.createElement('canvas');NV.fx.width=540;NV.fx.height=720;NV.fc=NV.fx.getContext('2d');NV.cb=document.createElement('canvas');NV.cbx=NV.cb.getContext('2d');NV.ok=true;}catch(e){NV.off=true;}};
  im.onerror=function(){NV.off=true;};im.src='assets/img/nervures.webp?v=R298';}catch(e){NV.off=true;}})();
window.NVS=NV;
function nvSm(t){return t*t*t*(t*(t*6-15)+10);}
function nvIn(lv,x,y){for(var i=0;i<lv.nd.length;i++){var r=lv.nd[i];if(x>r[0]&&x<r[0]+r[2]&&y>r[1]&&y<r[1]+r[3])return true;}return false;}
function nvMask(lv){   /* distance aux bords exposés → opacité : plus vivant près des bords, fondu net sur la frontière */
 var W=360,H=480,D=new Float32Array(W*H),INF=1e4,i,x,y,E=[];for(i=0;i<D.length;i++)D[i]=INF;
 lv.nd.forEach(function(r){var x0=r[0],y0=r[1],w=r[2],h=r[3],s;
  for(s=0;s<w;s+=6){if(!nvIn(lv,x0+s+3,y0-2)&&y0>1)E.push([x0+s,y0,x0+s+6,y0,0,-1]);if(!nvIn(lv,x0+s+3,y0+h+2)&&y0+h<479)E.push([x0+s,y0+h,x0+s+6,y0+h,0,1]);}
  for(s=0;s<h;s+=6){if(!nvIn(lv,x0-2,y0+s+3)&&x0>1)E.push([x0,y0+s,x0,y0+s+6,-1,0]);if(!nvIn(lv,x0+w+2,y0+s+3)&&x0+w<359)E.push([x0+w,y0+s,x0+w,y0+s+6,1,0]);}});
 E.forEach(function(e){var n=Math.max(1,Math.ceil(Math.hypot(e[2]-e[0],e[3]-e[1])));for(var k=0;k<=n;k++){var px=Math.round(e[0]+(e[2]-e[0])*k/n-(e[4]>0?1:0)),py=Math.round(e[1]+(e[3]-e[1])*k/n-(e[5]>0?1:0));if(px>=0&&px<W&&py>=0&&py<H)D[py*W+px]=0;}});
 for(y=0;y<H;y++)for(x=0;x<W;x++){i=y*W+x;if(x>0)D[i]=Math.min(D[i],D[i-1]+1);if(y>0)D[i]=Math.min(D[i],D[i-W]+1);if(x>0&&y>0)D[i]=Math.min(D[i],D[i-W-1]+1.41);if(x<W-1&&y>0)D[i]=Math.min(D[i],D[i-W+1]+1.41);}
 for(y=H-1;y>=0;y--)for(x=W-1;x>=0;x--){i=y*W+x;if(x<W-1)D[i]=Math.min(D[i],D[i+1]+1);if(y<H-1)D[i]=Math.min(D[i],D[i+W]+1);if(x<W-1&&y<H-1)D[i]=Math.min(D[i],D[i+W+1]+1.41);if(x>0&&y<H-1)D[i]=Math.min(D[i],D[i+W-1]+1.41);}
 var cv=document.createElement('canvas');cv.width=W;cv.height=H;var cx=cv.getContext('2d'),im=cx.createImageData(W,H);
 for(y=0;y<H;y++)for(x=0;x<W;x++){i=y*W+x;var d=D[i],al=nvIn(lv,x+.5,y+.5)?(.62+.38*Math.exp(-d/48))*Math.min(1,.25+d/5):0;im.data[i*4]=255;im.data[i*4+1]=255;im.data[i*4+2]=255;im.data[i*4+3]=Math.round(255*al);}
 cx.putImageData(im,0,0);
 var x0=1e4,y0=1e4,x1=-1,y1=-1;lv.nd.forEach(function(r){x0=Math.min(x0,r[0]);y0=Math.min(y0,r[1]);x1=Math.max(x1,r[0]+r[2]);y1=Math.max(y1,r[1]+r[3]);});
 NV.lv=lv;NV.msk=cv;NV.bb=[Math.max(0,x0-2),Math.max(0,y0-2),Math.min(360,x1+2),Math.min(480,y1+2)];}
function nvPass(k,al,sc,rot,dx,dy,t){var fc=NV.fc,KF=10,p=((t/170)+k)%KF,i=Math.floor(p),w=nvSm(p-i),i2=(i+1)%KF;
 [[i,1-w],[i2,w]].forEach(function(pr){if(pr[1]<.004)return;var cv=NV.V[pr[0]];fc.save();fc.setTransform(1.5,0,0,1.5,0,0);fc.globalAlpha=al*pr[1];fc.translate(180,240);fc.rotate(rot);fc.translate(dx*t,dy*t);
  var s0=360/cv.width;fc.scale(sc*s0,sc*s0);fc.fillStyle=NV.pat[pr[0]]||(NV.pat[pr[0]]=fc.createPattern(cv,'repeat'));var R=900/Math.min(sc,1);fc.fillRect(-R,-R,R*2,R*2);fc.restore();});}
function nvDraw(c,lv){
 if(NV.off||!NV.ok||!lv.nd||!lv.nd.length||(typeof OPT!=='undefined'&&OPT.rm))return;
 var t0=performance.now();
 try{
  if(NV.lv!==lv){nvMask(lv);NV.st=-99;}
  var t=((typeof S!=='undefined'&&S.tick)||0)*1.9,fc=NV.fc,bb=NV.bb;
  /* 1 · contraste du décor, seulement derrière les zones (copie du cadre → masque → « overlay ») */
  var cw=c.canvas.width,ch=c.canvas.height,kx=cw/360,ky=ch/480,sx=Math.floor(bb[0]*kx),sy=Math.floor(bb[1]*ky),sw=Math.ceil((bb[2]-bb[0])*kx),sh=Math.ceil((bb[3]-bb[1])*ky);
  if(sw>0&&sh>0){var cb=NV.cb,cx=NV.cbx,hw=Math.max(1,sw>>1),hh=Math.max(1,sh>>1);   /* le décor derrière est quasi fixe : couche recalculée toutes les 15 trames, en demi-résolution */
   if(cb.width!==hw||cb.height!==hh){cb.width=hw;cb.height=hh;NV.st=-99;}
   if(NV.fr-NV.st>=15||NV.fr<NV.st){NV.st=NV.fr;cx.globalCompositeOperation='source-over';cx.clearRect(0,0,hw,hh);cx.drawImage(c.canvas,sx,sy,sw,sh,0,0,hw,hh);
    cx.globalCompositeOperation='destination-in';cx.drawImage(NV.msk,bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1],0,0,hw,hh);}
   c.save();c.setTransform(1,0,0,1,0,0);c.globalCompositeOperation='overlay';c.globalAlpha=.5;c.drawImage(cb,0,0,hw,hh,sx,sy,sw,sh);c.restore();}
  /* 2 · nervures : un rafraîchissement toutes les 2 trames suffit, le mouvement est lent */
  if((NV.fr++&1)===0||!NV.fresh){NV.fresh=1;fc.setTransform(1,0,0,1,0,0);fc.globalCompositeOperation='source-over';fc.clearRect(0,0,540,720);fc.globalCompositeOperation='lighter';
   nvPass(0,.44*(.72+.28*Math.sin(t*.03)),1.25,.12,.085,.035,t);nvPass(5,.20*(.72+.28*Math.sin(t*.025+2)),.82,.55,-.065,.050,t);
   fc.globalCompositeOperation='destination-in';fc.setTransform(1.5,0,0,1.5,0,0);fc.drawImage(NV.msk,0,0);fc.globalCompositeOperation='source-over';}
  c.save();c.globalAlpha=1;c.drawImage(NV.fx,0,0,360,480);c.restore();
 }catch(e){NV.off=true;return;}
 NV.ms+=performance.now()-t0;if(++NV.n>=90){if(NV.ms/NV.n>12)NV.off=true;NV.ms=0;NV.n=0;}}
function nd(c,lv){nvDraw(c,lv);if(ND_MODE==='pauli')return ndPauli(c,lv);ndVac(c,lv);}
function ndVac(c,lv){var tt=(typeof S!=='undefined'&&S.t)||now(),hit=(typeof S!=='undefined'&&S.ndHit)||null,ha=hit?(tt-hit.t):1e9,i,k;
 for(i=0;i<lv.nd.length;i++){var r=lv.nd[i],x0=r[0],y0=r[1],w=r[2],h=r[3];
  var exT=!ndIn(lv,x0+w/2,y0-2,i),exB=!ndIn(lv,x0+w/2,y0+h+2,i),exL=!ndIn(lv,x0-2,y0+h/2,i),exR=!ndIn(lv,x0+w+2,y0+h/2,i);
  exT=exT&&y0>1;exL=exL&&x0>1;exR=exR&&x0+w<359;exB=exB&&y0+h<479;   /* un côté posé sur le cadre n'a pas de frontière à montrer */
  c.save();c.beginPath();c.rect(x0,y0,w,h);c.clip();
  c.fillStyle=rgba(NDR,.045);c.fillRect(x0,y0,w,h);
  /* lueur intérieure le long des parties exposées : on lit la forme sans la cerner d'un trait dur */
  var gl=14,SD=[[x0,y0,1,0,w,0,1],[x0+w,y0,0,1,h,-1,0],[x0,y0+h,1,0,w,0,-1],[x0,y0,0,1,h,1,0]],sd,s0,ox,oy;
  function exAt(sd,q){var px=sd[0]+sd[2]*q,py=sd[1]+sd[3]*q,ox=px-sd[5]*2.5,oy=py-sd[6]*2.5;return ox>1&&ox<359&&oy>1&&oy<479&&!ndIn(lv,ox,oy,i);}
  for(k=0;k<4;k++){sd=SD[k];var gr=c.createLinearGradient(sd[0],sd[1],sd[0]+sd[5]*gl,sd[1]+sd[6]*gl);gr.addColorStop(0,rgba(NDR,.14));gr.addColorStop(1,rgba(NDR,0));c.fillStyle=gr;
   for(s0=0;s0<sd[4];s0+=12){var ln=Math.min(12,sd[4]-s0);if(!exAt(sd,s0+ln/2))continue;
    var ax0=sd[0]+sd[2]*s0,ay0=sd[1]+sd[3]*s0;c.fillRect(Math.min(ax0,ax0+sd[5]*gl+sd[2]*ln),Math.min(ay0,ay0+sd[6]*gl+sd[3]*ln),sd[2]*ln+Math.abs(sd[5])*gl,sd[3]*ln+Math.abs(sd[6])*gl);}}
  c.globalCompositeOperation='lighter';
  var cs=26,ix,iy;
  for(ix=Math.floor(x0/cs);ix*cs<x0+w;ix++)for(iy=Math.floor(y0/cs);iy*cs<y0+h;iy++){
   var P=96+64*ndH(ix,iy,1),off=P*ndH(ix,iy,2),ep=Math.floor((tt+off)/P),f=(tt+off)-ep*P;
   if(ndH(ix+ep*.37,iy,3)>.38)continue;   /* R174 : moitié moins de paires — une zone morte, pas une fourmilière */                                    /* naissances au hasard (Poisson éclairci) */
   var e=.25+.75*ndH(ix,iy+ep*.53,4),life=34+40*(1-e),st=ndH(ix,iy,5+ep%7)*(P-life-44),u=(f-st)/life;
   if(u<0||u>1+44/life)continue;
   var bx=ix*cs+5+16*ndH(ix,iy,6+ep%5),by=iy*cs+5+16*ndH(ix,iy,7+ep%3);
   if(bx<x0-2||bx>x0+w+2||by<y0-2||by>y0+h+2)continue;
   var ed=Math.min(exL?bx-x0:999,exR?x0+w-bx:999,exT?by-y0:999,exB?y0+h-by:999),edge=Math.max(.6,1-ed/90);
   if(ha<70){var dd=Math.hypot(bx-hit.x,by-hit.y),wv=ha*3.2;edge+=Math.max(0,1-Math.abs(dd-wv)/20)*(1-ha/70)*1.2;}
   var sd0=ix*13.1+iy*7.7+ep*3.3,th=6.2832*ndH(ix,iy,8+ep%9),R0=4+9*e,
       mx=(ndH(sd0,1,1)-.5)*14,my=(ndH(sd0,2,1)-.5)*14;                      /* point de rencontre : la paire dérive avant de se rejoindre */
   var sc=.5+.75*ndH(sd0,13,4),opv=.25+.75*Math.pow(ndH(sd0,17,5),1.5);   /* R174 : chaque paire a sa taille et son opacité */
   var pz=function(sgn,v){var q0=sgn>0?0:7,en=Math.sin(Math.PI*Math.pow(Math.max(0,Math.min(1,v)),.7)),            /* s'écarter puis revenir… */
       a1=th+(sgn>0?0:Math.PI)+2.4*(ndH(sd0,q0+3,2)-.5)*Math.sin(v*(2+3*ndH(sd0,q0+4,2))*Math.PI),   /* …par une route imprévisible */
       wb=en*(3+5*ndH(sd0,q0+5,2)),fx=(1.5+3*ndH(sd0,q0+6,2))*Math.PI,fy=(1.5+3*ndH(sd0,q0+7,2))*Math.PI;
       return [bx+mx*v+Math.cos(a1)*R0*en+wb*Math.sin(v*fx+q0),by+my*v+Math.sin(a1)*R0*en+wb*Math.cos(v*fy+q0)];};
   var glw=function(sgn,uE,k0){if(k0<.004)return;var col=sgn>0?NDR:NDC,m,p0=pz(sgn,Math.max(0,uE-.55)),p1;c.lineWidth=4.5*sc;c.lineCap='round';   /* R175 : lueur laissée derrière le passage, qui s'éteint plus lentement que la particule */
    for(m=1;m<=11;m++){p1=pz(sgn,Math.max(0,uE-.55+m*.05));c.strokeStyle=rgba(col,k0*Math.pow(m/11,1.3));c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke();p0=p1;}};
   var aB=(.4+.42*e)*edge*opv;
   if(u<=1){glw(-1,u,aB*.09*Math.min(1,u*5));glw(1,u,aB*.09*Math.min(1,u*5));var tr,kk,al=Math.min(1,u*7,(1-u)*5+.45)*aB;
    for(var sgn=-1;sgn<=1;sgn+=2){var col=sgn>0?NDR:NDC,q0=sgn>0?0:7;
     var pos=function(v){return pz(sgn,v);};
     /* R168 — l'éclair et sa queue : la tête brille, le corps brisé suit la route réellement parcourue et s'efface vers
        l'arrière, enveloppé d'une lueur légère ; longueur propre à chaque particule (0,7 à 1,6 ×) */
     var Lt=(10+12*e)*(.7+.9*ndH(sd0,q0+20,3))*sc,fl=Math.floor(tt/3),TP=[pos(u)],acc=0,du=.010,pv=TP[0];
     for(kk=1;kk<18&&acc<Lt&&u-kk*du>-.02;kk++){var qq=pos(u-kk*du);acc+=Math.hypot(qq[0]-pv[0],qq[1]-pv[1]);TP.push(qq);pv=qq;}
     var nT=TP.length-1;c.lineCap='round';c.lineJoin='round';
     if(nT>0){var JT=[TP[0]];for(kk=1;kk<=nT;kk++){var ax2=TP[kk][0]-TP[kk-1][0],ay2=TP[kk][1]-TP[kk-1][1],al2=Math.hypot(ax2,ay2)||1,jj=(ndH(sd0+kk,fl,q0+9)-.5)*2.6*Math.min(1,kk/2);
       JT.push([TP[kk][0]-ay2/al2*jj,TP[kk][1]+ax2/al2*jj]);}
      for(kk=1;kk<=nT;kk++){var f0=1-(kk-1)/nT,f1=1-kk/nT,fa=Math.pow((f0+f1)/2,1.4);
       c.strokeStyle=rgba(col,al*.07*fa);c.lineWidth=3*sc;c.beginPath();c.moveTo(TP[kk-1][0],TP[kk-1][1]);c.lineTo(TP[kk][0],TP[kk][1]);c.stroke();   /* lueur de la traînée */
       c.strokeStyle=rgba(col,al*.8*fa);c.lineWidth=(.3+.6*fa)*sc;c.beginPath();c.moveTo(JT[kk-1][0],JT[kk-1][1]);c.lineTo(JT[kk][0],JT[kk][1]);c.stroke();}}
     c.fillStyle=rgba(col,al*.12);c.beginPath();c.arc(TP[0][0],TP[0][1],(2+.8*e)*sc,0,6.2832);c.fill();
     c.fillStyle=rgba(NDA,al*.85);c.beginPath();c.arc(TP[0][0],TP[0][1],(.6+.35*e)*sc,0,6.2832);c.fill();}}
   else{var v=(u-1)*life/44,fr=1-v,cxm=bx+mx,cym=by+my;                     /* annihilation : délitement en poussière d'étoile */
    glw(-1,1,aB*.09*Math.pow(fr,.55));glw(1,1,aB*.09*Math.pow(fr,.55));
    if(v<.28){var sv=1-v/.28,fl2=Math.floor(tt/2);c.lineWidth=.55;c.lineCap='round';c.lineJoin='round';   /* R175 : choc électrique délicat — quelques arcs brisés qui crépitent */
     for(kk=0;kk<4;kk++){var an=6.2832*ndH(sd0,kk,fl2%13+30),ln=(4+6*ndH(sd0+kk,fl2,31))*sc,sx=cxm,sy=cym;c.strokeStyle=kk%2?rgba(NDA,.55*sv*opv*edge):rgba(kk%4?NDC:NDR,.45*sv*opv*edge);c.beginPath();c.moveTo(sx,sy);
      for(var zz=1;zz<=3;zz++){var dv=(ndH(sd0+kk*7,fl2+zz,32)-.5)*1.4;sx=cxm+Math.cos(an+dv*.6)*ln*zz/3;sy=cym+Math.sin(an+dv*.6)*ln*zz/3;sx+=Math.cos(an+1.57)*dv*1.6;sy+=Math.sin(an+1.57)*dv*1.6;c.lineTo(sx,sy);}c.stroke();}
     c.strokeStyle=rgba(NDA,.22*sv*opv*edge);c.lineWidth=.6;c.beginPath();c.arc(cxm,cym,(2+9*(1-sv))*sc,0,6.2832);c.stroke();}
    if(v<.14){var gg=c.createRadialGradient(cxm,cym,0,cxm,cym,4.5*sc);gg.addColorStop(0,'rgba(255,255,255,'+(.4*opv*(1-v/.14))+')');gg.addColorStop(1,rgba(NDR,0));c.fillStyle=gg;c.beginPath();c.arc(cxm,cym,4.5*sc,0,6.2832);c.fill();}
    for(kk=0;kk<6;kk++){var da=6.2832*ndH(sd0,kk,11)+v*1.5,dr=(2+8*ndH(sd0,kk,12))*sc*(1-v)*(1-v),   /* R174 : la poussière s'effondre sur elle-même, en tournant */tw=.55+.45*Math.sin(tt*.35+kk*2.1),
      dpx=cxm+Math.cos(da)*dr,dpy=cym+Math.sin(da)*dr;
     c.fillStyle=rgba(kk%3===0?NDR:kk%3===1?NDC:NDA,fr*.5*tw*edge*opv);c.fillRect(dpx-.45*sc,dpy-.45*sc,.9*sc+.3,.9*sc+.3);}}}
  c.globalCompositeOperation='source-over';c.restore();
  /* frontière incertaine : bruit qui vibre, seulement là où la zone touche l'espace libre */
  c.save();c.lineWidth=1.1;c.lineJoin='round';c.shadowColor=rgba(NDR,.7);c.shadowBlur=5;
  for(k=0;k<4;k++){sd=SD[k];c.beginPath();var on=false;
   for(var q=0;q<=sd[4];q+=5){if(!exAt(sd,Math.min(q,sd[4]-.5))){on=false;continue;}var g=q+(k*97),n=1.3*Math.sin(g*.21+tt*.11)+.8*Math.sin(g*.53-tt*.17)+.5*Math.sin(g*1.3+tt*.31),
     px=sd[0]+sd[2]*q+sd[5]*(1.6+n),py=sd[1]+sd[3]*q+sd[6]*(1.6+n);if(on)c.lineTo(px,py);else c.moveTo(px,py);on=true;}
   c.strokeStyle=rgba(NDR,.38+.12*Math.sin(tt*.07+k));c.stroke();}
  c.restore();}
 /* annihilation au point refusé : l'antiparticule jaillit, rejoint la pointe du trait ; deux photons dos à dos et une onde */
 if(hit&&ha<40){var r0=null;for(i=0;i<lv.nd.length;i++){var q=lv.nd[i];if(hit.x>=q[0]-2&&hit.x<=q[0]+q[2]+2&&hit.y>=q[1]-2&&hit.y<=q[1]+q[3]+2){r0=q;break;}}
  var dx=r0?(r0[0]+r0[2]/2-hit.x):0,dy=r0?(r0[1]+r0[3]/2-hit.y):1,dl=Math.hypot(dx,dy)||1;dx/=dl;dy/=dl;
  c.save();c.globalCompositeOperation='lighter';
  if(ha<6){var m=ha/6,ax=hit.x+dx*22*(1-m*m),ay=hit.y+dy*22*(1-m*m);c.fillStyle=rgba(NDA,.9);c.beginPath();c.arc(ax,ay,2.4,0,6.2832);c.fill();
   c.strokeStyle=rgba(NDA,.4);c.lineWidth=1;c.beginPath();c.moveTo(ax,ay);c.lineTo(ax+dx*8,ay+dy*8);c.stroke();}
  else{var v2=(ha-6)/34,fr2=1-v2,gx=-dy,gy=dx,L2=8+70*v2;
   var g2=c.createRadialGradient(hit.x,hit.y,0,hit.x,hit.y,12);g2.addColorStop(0,'rgba(255,255,255,'+(.8*fr2*fr2)+')');g2.addColorStop(1,rgba(NDR,0));
   c.fillStyle=g2;c.beginPath();c.arc(hit.x,hit.y,12,0,6.2832);c.fill();
   c.strokeStyle='rgba(255,246,250,'+(.75*fr2)+')';c.lineWidth=1.4;c.lineCap='round';
   c.beginPath();c.moveTo(hit.x+gx*(L2-12),hit.y+gy*(L2-12));c.lineTo(hit.x+gx*L2,hit.y+gy*L2);c.moveTo(hit.x-gx*(L2-12),hit.y-gy*(L2-12));c.lineTo(hit.x-gx*L2,hit.y-gy*L2);c.stroke();
   c.strokeStyle=rgba(NDR,.55*fr2);c.lineWidth=1;c.beginPath();c.arc(hit.x,hit.y,4+30*v2,0,6.2832);c.stroke();}
  c.restore();}}

/* R166 — trait tenté dans une zone de vide : la matière s'y montre un instant, ne peut pas rester stable, se délite et
   tombe en sable cosmique avant de disparaître. G = [{pts:[[x,y,tick]…],col}] (S.ndg) ; chaque segment vit selon sa date. */
function ndHex(cl){if(Array.isArray(cl))return cl;var m=/^#?([0-9a-f]{6})$/i.exec(cl||'');if(!m)return [169,226,255];var n=parseInt(m[1],16);return [n>>16,(n>>8)&255,n&255];}
function ndDust(c,G,tk){var i,j,k,HOLD=20,FALL=84;
 for(i=G.length-1;i>=0;i--){var g=G[i],P=g.pts;if(P.length&&tk-P[P.length-1][2]>HOLD+FALL+12&&g.done)G.splice(i,1);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<G.length;i++){var g=G[i],P=g.pts,col=ndHex(g.col);
  for(j=1;j<P.length;j++){var A=P[j-1],B=P[j],a=tk-B[2],L2=Math.hypot(B[0]-A[0],B[1]-A[1]);if(L2<.5)continue;
   if(a<HOLD){var jt=a*.35,fl=.7+.3*Math.sin(tk*1.7+j);                                   /* instable : tremble et vacille */
    c.strokeStyle=rgba(col,.18*fl);c.lineWidth=4.5;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();   /* halo du trait instable (R199 : plus fin) */
    c.strokeStyle=rgba(col,.9*fl);c.lineWidth=1.6;c.beginPath();
    c.moveTo(A[0]+(ndH(j,tk,1)-.5)*jt,A[1]+(ndH(j,tk,2)-.5)*jt);c.lineTo(B[0]+(ndH(j,tk,3)-.5)*jt,B[1]+(ndH(j,tk,4)-.5)*jt);c.stroke();
    if(a>HOLD-3){c.strokeStyle='rgba(255,255,255,'+(.5*(a-HOLD+3)/3)+')';c.lineWidth=1.2;c.stroke();}continue;}
   var b=a-HOLD;if(b>FALL+12)continue;var n=Math.max(2,Math.round(L2*(g.dn||1)/1.3)),gz=g.sz||1;   /* R228 : densité et taille réglables (fin du jeu), défaut inchangé */
   for(k=0;k<n;k++){var s=(k+ndH(j,k,5))/n,gx=A[0]+(B[0]-A[0])*s,gy=A[1]+(B[1]-A[1])*s,dl=10*ndH(j,k,6),t2=Math.max(0,b-dl),
     vx=(ndH(j,k,7)-.5)*.5,vy=-.35*ndH(j,k,8),fd=Math.max(0,1-Math.max(0,b-dl*.3)/FALL),tw=.6+.4*Math.sin(tk*.4+k*1.9+j);
    if(fd<=0)continue;
    var px=gx+vx*t2+Math.sin(t2*.09+k)*1.2,py=gy+vy*t2+.022*t2*t2,sz=(1.2+1.4*ndH(j,k,9))*(.55+.45*fd);
    var cc=ndH(j,k,10)<.55?NDA:ndH(j,k,10)<.8?col:[255,214,150];                    /* sable cosmique : blanc d'étoile, couleur du trait, or pâle */
    var rr=(.28+.3*ndH(j,k,9)*(.55+.45*fd))*gz;c.fillStyle=rgba(cc,fd*.95*tw);c.beginPath();c.arc(px,py,rr,0,6.2832);c.fill();   /* R199 : grains ronds et fins (fini les carrés pixelisés) */
    if(k%4===0){c.fillStyle=rgba(cc,fd*.18*tw);c.beginPath();c.arc(px,py,rr*3.2,0,6.2832);c.fill();}
    if(k%3===0){c.fillStyle=rgba(cc,fd*.2*tw);c.beginPath();c.arc(px,py,2.6*gz,0,6.2832);c.fill();}}}}
 c.restore();}

/* ============================ STRUCTURES ============================ */
function beam(c,s,accent){var g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,'#3A5068');gr.addColorStop(1,'#18222E');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.strokeStyle='rgba(169,200,232,.95)';c.lineWidth=1.4;c.beginPath();var ns=Math.max(2,Math.round(g.len/13));
 for(var i=0;i<=ns;i++){q=i/ns*g.len;var off=(i%2?Dp-2.5:2.5),x=A[0]+g.ux*q+g.nx*off,y=A[1]+g.uy*q+g.ny*off;if(i)c.lineTo(x,y);else c.moveTo(x,y);}c.stroke();
 c.strokeStyle='rgba(191,212,228,.8)';c.beginPath();c.moveTo(A2[0]-g.nx*1.5,A2[1]-g.ny*1.5);c.lineTo(B2[0]-g.nx*1.5,B2[1]-g.ny*1.5);c.stroke();
 c.fillStyle='#9FB3C4';for(q=10;q<g.len-6;q+=34){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.5,A[1]+g.uy*q+g.ny*Dp*.5,1.5,0,6.2832);c.fill();}
 c.lineCap='round';c.strokeStyle=accent||'#A9C3D6';c.lineWidth=3.4;c.shadowColor=accent||'rgba(169,195,214,.6)';c.shadowBlur=accent?10:5;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle='rgba(241,244,246,.75)';c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function plate(c,s){var t=now(),g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],heat=.6+.4*Math.sin(t*.05+s[0]*.02),q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,rgba(C.bounce,.9));gr.addColorStop(.35,'#6A2C12');gr.addColorStop(1,'#1A0C08');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.save();c.clip();c.strokeStyle=rgba(C.bounce,.28*heat);c.lineWidth=2;
 for(q=((t*.4)%14)-14;q<g.len+14;q+=14){var x=A[0]+g.ux*q,y=A[1]+g.uy*q;c.beginPath();c.moveTo(x,y);c.lineTo(x+g.nx*Dp+g.ux*5,y+g.ny*Dp+g.uy*5);c.stroke();}c.restore();
 c.fillStyle=rgba(C.reward,.9);for(q=10;q<g.len-6;q+=30){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.6,A[1]+g.uy*q+g.ny*Dp*.6,1.6,0,6.2832);c.fill();}
 c.lineCap='round';c.shadowColor=rgba(C.bounce,1);c.shadowBlur=10+8*heat;c.strokeStyle=rgba(C.bounce,1);c.lineWidth=3.6;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.85);c.lineWidth=1.1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function boostPad(c,s){var t=now(),g=geom(s),A=[s[0],s[1]],dx=s[2]-s[0],dy=s[3]-s[1],len=g.len,ux=dx/len,uy=dy/len,Dp=11,i;
 var fl=0;for(i=0;i<D.flash.length;i++){var f=D.flash[i],pr=((f.x-A[0])*ux+(f.y-A[1])*uy);var pd=Math.abs((f.x-A[0])*g.nx+(f.y-A[1])*g.ny);if(pr>-15&&pr<len+15&&pd<25)fl=Math.max(fl,f.life);}
 c.save();
 // longeron sombre derrière la surface
 var gr=c.createLinearGradient(A[0],A[1],A[0]+g.nx*Dp,A[1]+g.ny*Dp);gr.addColorStop(0,'#3B2A5E');gr.addColorStop(1,'#140E22');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.lineTo(s[2]+g.nx*Dp,s[3]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 // chaîne de cellules (cavité RF) : une onde les parcourt dans le sens de la poussée
 var nc=Math.max(2,Math.floor(len/11)),step=len/nc,ang=Math.atan2(uy,ux);
 for(i=0;i<nc;i++){var q=(i+.5)*step,x=A[0]+ux*q+g.nx*Dp*.5,y=A[1]+uy*q+g.ny*Dp*.5,wave=.5+.5*Math.sin(i*.9-t*.22),e=Math.max(wave*.8,fl);
  c.save();c.translate(x,y);c.rotate(ang);
  var g2=c.createRadialGradient(0,0,0,0,0,6);g2.addColorStop(0,rgba(C.white,.25+.55*e));g2.addColorStop(.5,rgba(C.boost,.35+.5*e));g2.addColorStop(1,rgba(C.boost,.05));
  c.fillStyle=g2;c.beginPath();c.ellipse(0,0,step*.46,5,0,0,6.2832);c.fill();
  c.strokeStyle=rgba(C.boost,.6+.4*e);c.lineWidth=.9;c.stroke();
  c.strokeStyle=rgba(C.white,.35+.5*e);c.lineWidth=1;c.beginPath();c.moveTo(-1.5,-2.2);c.lineTo(1.5,0);c.lineTo(-1.5,2.2);c.stroke();   // chevron = sens de la poussée
  c.restore();}
 // surface de roulement exactement sur la ligne de collision
 c.lineCap='round';c.shadowColor=rgba(C.boost,1);c.shadowBlur=10+14*fl;c.strokeStyle=rgba(C.boost,1);c.lineWidth=3.4;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.8);c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(s[2]-g.nx,s[3]-g.ny);c.stroke();
 c.restore();}
function spikes(c,s){var g=geom(s),Dp=7,A=[s[0],s[1]],B=[s[2],s[3]],i=0;
 c.save();c.fillStyle='#1B0F14';c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B[0]+g.nx*Dp,B[1]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 c.strokeStyle='rgba(255,82,82,.35)';c.lineWidth=1;c.stroke();c.shadowColor='#FF5252';c.shadowBlur=8;
 for(var q=4;q<g.len-3;q+=8.5,i++){var hh=7+rnd(i+s[0])*7,w=3+rnd(i*3+s[1])*1.6,x=A[0]+g.ux*q,y=A[1]+g.uy*q,tx=x-g.nx*hh,ty=y-g.ny*hh;
  var gr=c.createLinearGradient(x,y,tx,ty);gr.addColorStop(0,'#5A1418');gr.addColorStop(1,'#FF7A7A');
  c.fillStyle=gr;c.beginPath();c.moveTo(x-g.ux*w,y-g.uy*w);c.lineTo(tx,ty);c.lineTo(x+g.ux*w,y+g.uy*w);c.closePath();c.fill();}
 c.restore();}

function isCupWall(lv,s){if(!lv.cup)return false;var x=lv.cup[0],y=lv.cup[1],w=lv.cup[2];
 return (s[1]===y&&s[3]===y&&s[0]===x&&s[2]===x+w)||((s[0]===x||s[0]===x+w)&&s[1]===y&&s[2]===s[0]&&s[3]===y-56);}

function cupGlow(c,lv){var z=lv.zone,t=now(),pul=.5+.5*Math.sin(t*.05);if(!z)return;
 c.save();var gr=c.createLinearGradient(0,z[1],0,z[1]+z[3]);gr.addColorStop(0,'rgba(155,235,75,0)');gr.addColorStop(1,'rgba(155,235,75,'+(.16+.08*pul)+')');
 c.fillStyle=gr;c.fillRect(z[0],z[1],z[2],z[3]);c.strokeStyle='rgba(200,255,141,.55)';c.lineWidth=1.4;c.beginPath();
 for(var x=z[0]+2;x<=z[0]+z[2]-2;x+=3){var y=z[1]+z[3]-9+Math.sin(x*.12+t*.08)*1.6;if(x===z[0]+2)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();
 for(var i=0;i<5;i++){var px=z[0]+8+rnd(i)*(z[2]-16),py=z[1]+z[3]-((t*.4+rnd(i+9)*60)%44);c.fillStyle='rgba(155,235,75,.5)';c.beginPath();c.arc(px,py,1.2,0,6.2832);c.fill();}
 c.restore();}

function supports(c,lv){var deg={},i,s,k,p,j;
 for(i=0;i<lv.walls.length;i++){s=lv.walls[i];if(s[5]===1)continue;   /* les pièces courbes n'ont pas de jointures visibles */
  var e=[[s[0],s[1]],[s[2],s[3]]];for(j=0;j<2;j++){k=Math.round(e[j][0])+','+Math.round(e[j][1]);deg[k]=(deg[k]||0)+1;}}
 for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];if(s[4]!==0)continue;var g=geom(s),ends=[[s[0],s[1]],[s[2],s[3]]];
  for(j=0;j<2;j++){p=ends[j];if(p[0]<8||p[0]>VW-8)continue;k=Math.round(p[0])+','+Math.round(p[1]);
   if(p[1]<300){c.strokeStyle='rgba(138,151,166,.22)';c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]-2);c.lineTo(p[0],0);c.stroke();
    c.fillStyle='#8A97A6';c.beginPath();c.arc(p[0],p[1]-3,2,0,6.2832);c.fill();}
   else if(p[1]<455&&deg[k]<2){var x0=p[0]-3.5,y0=p[1]+g.ny*10,gp=c.createLinearGradient(0,y0,0,VH);gp.addColorStop(0,rgba(C.matter,.30));gp.addColorStop(1,rgba(C.matter,0));
    c.strokeStyle=gp;c.lineWidth=.8;c.beginPath();c.moveTo(x0,y0);c.lineTo(x0,VH);c.moveTo(x0+7,y0);c.lineTo(x0+7,VH);
    for(var y=y0,n=0;y<VH;y+=12,n++){c.moveTo(n%2?x0:x0+7,y);c.lineTo(n%2?x0+7:x0,y+12);}c.stroke();}}}   /* pylône : une colonne de lumière qui s'éteint vers le bas */
 /* les jonctions sont dessinées par la bibliothèque de connecteurs (joints) */}

/* murs fixes : renvoie la liste des segments que le rendu d'origine doit encore dessiner (élan, glace…) */
/* R300 — code couleur de vitesse des rubans : ambre = frein (0), turquoise = lent (≈2), violet = standard (7), blanc‑cyan = rapide (≥10) */
function spdCol(v){return v<.6?[255,176,60]:v<4?[40,215,190]:v<8.5?C.boost:[205,246,255];}
function fixed(c,segs,lv){var rest=[],i,s;cupGlow(c,lv);supports(c,lv);
 for(i=0;i<segs.length;i++){s=segs[i];
  if(s[4]===2)spikes(c,s);else if(s[4]===1)curve(c,[[s[0],s[1]],[s[2],s[3]]],1,{noHang:1});else if(s[4]===3)curve(c,[[s[0],s[1]],[s[2],s[3]]],3,s[10]===undefined?{noHang:1}:{noHang:1,accent:spdCol(s[10]),speed:Math.max(0,s[10])/7.2});
  else if(s[4]===0){if(isCupWall(lv,s))curve(c,[[s[0],s[1]],[s[2],s[3]]],0,{noHang:1,accent:C.goal});else curve(c,[[s[0],s[1]],[s[2],s[3]]],0,{noHang:1});}
  else if(s[4]===4)curve(c,[[s[0],s[1]],[s[2],s[3]]],4,{noHang:1});else rest.push(s);}
 joints(c,segs,lv);
 drawImpacts(c);
 return rest;}

/* ══ JONCTION ADAPTATIVE UNIVERSELLE (R87) ══
   Toute rencontre de pièces — bouts qui se touchent (L, Y, étoile), bout posé sur le corps d'une autre (T), pièces qui se
   CROISENT (X) — devient un NŒUD. Un nœud est décrit par ses BRAS (une direction par pièce qui en part ; une pièce qui
   traverse donne deux bras opposés). Le dessin s'adapte à n'importe quel nombre de bras et d'angles :
   · chaque bras reçoit un MANCHON (bague serrée sur la pièce, deux anneaux, un boulon) ;
   · le cœur est la ENVELOPPE CONVEXE des manchons : une plaque d'acier qui épouse exactement la géométrie de la rencontre
     (ombre portée, dégradé, liseré, gorge intérieure) ;
   · au centre, un moyeu boulonné ; pour un croisement, deux traits de soudure marquent l'assemblage.
   Bouts libres : EMBOUT ; bouts contre un bord de l'écran : PLATINE murale. Les nœuds des pièces fixes sont calculés une
   fois par niveau (cache), les parois mobiles n'en ont pas. */
/* ══ CHOCS (R90) — petite bibliothèque d'animations d'impact, graduée par la force du choc (vitesse normale v) ══
   · effleurement (v < 1,6)  : trois grains de lumière ;
   · choc léger   (1,6–3)    : gerbe de poussière lumineuse très fine le long de la surface + micro‑éclat ;
   · choc moyen   (3–5)      : gerbe plus dense + 1 à 2 arcs électriques qui crépitent + anneau de choc ;
   · choc fort    (> 5)      : gerbe dense et longue + 3 à 4 arcs + onde de choc + éclat en étoile.
   Couleur : la matière touchée (rebond = ambre, tapis = violet, glace = givre, sinon cyan) mêlée de blanc. */
var IMP={dust:[],arcs:[],rings:[],stars:[]};
function impactFx(e){if(!e||!(e.v>.9))return;var v=e.v,m=e.mat,A=m===1?C.bounce:m===3?C.boost:m===4?[214,243,255]:C.matter,
 tx=-e.ny,ty=e.nx,lvl=v<1.6?0:v<3?1:v<5?2:3,n=[3,9,16,26][lvl],i;
 for(i=0;i<n;i++){var side=Math.random()<.5?-1:1,sp=(.6+Math.random()*1.4)*(.5+v*.35),spread=Math.random()*.9,
  vx=(tx*side*(1-spread)+e.nx*spread)*sp,vy=(ty*side*(1-spread)+e.ny*spread)*sp,life=22+Math.random()*(14+lvl*12);
  IMP.dust.push({x:e.x,y:e.y,vx:vx,vy:vy,life:life,max:life,col:Math.random()<.45?C.white:A,sz:.6+Math.random()*.9});}
 if(lvl>=2){var na=lvl===2?1+(Math.random()<.5?1:0):3+(Math.random()<.5?1:0);
  for(i=0;i<na;i++){var ang=Math.atan2(e.ny,e.nx)+(Math.random()-.5)*2.2;IMP.arcs.push({x:e.x,y:e.y,ang:ang,len:8+v*(2.6+Math.random()*1.8),life:11+lvl*3,max:11+lvl*3,col:A});}
  IMP.rings.push({x:e.x,y:e.y,r:3,vr:.9+v*.18,life:20+lvl*6,max:20+lvl*6,col:A});}
 if(lvl>=1)IMP.stars.push({x:e.x,y:e.y,s:3+v*(lvl>=3?2.2:1),life:9+lvl*3,max:9+lvl*3,col:A,a:Math.random()*.6});
 while(IMP.dust.length>260)IMP.dust.shift();}
function drawImpacts(c){if(!IMP.dust.length&&!IMP.arcs.length&&!IMP.rings.length&&!IMP.stars.length)return;var i,k;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<IMP.dust.length;i++){var d=IMP.dust[i];d.x+=d.vx;d.y+=d.vy;d.vx*=.94;d.vy=d.vy*.94+.025;d.life--;var a=d.life/d.max;
  c.fillStyle=rgba(d.col,.9*a);c.fillRect(d.x-d.sz/2,d.y-d.sz/2,d.sz,d.sz);
  if(a>.6){c.strokeStyle=rgba(d.col,.35*a);c.lineWidth=d.sz*.8;c.beginPath();c.moveTo(d.x,d.y);c.lineTo(d.x-d.vx*2.2,d.y-d.vy*2.2);c.stroke();}}
 IMP.dust=IMP.dust.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.arcs.length;i++){var r=IMP.arcs[i],a2=r.life/r.max,segs=5+Math.floor(r.len/6),x=r.x,y=r.y;r.life--;   /* éclair : ligne brisée re‑tirée à chaque image */
  c.strokeStyle=rgba(r.col,.35*a2);c.lineWidth=2.6;c.beginPath();c.moveTo(x,y);var pts=[[x,y]];
  for(k=1;k<=segs;k++){var f=k/segs,jit=(Math.random()-.5)*5*(1-f*.4),px=r.x+Math.cos(r.ang)*r.len*f-Math.sin(r.ang)*jit,py=r.y+Math.sin(r.ang)*r.len*f+Math.cos(r.ang)*jit;pts.push([px,py]);c.lineTo(px,py);}
  c.stroke();c.strokeStyle=rgba(C.white,.85*a2);c.lineWidth=.8;c.beginPath();pts.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();
  if(Math.random()<.5&&segs>4){var b0=pts[Math.floor(segs/2)],ba=r.ang+(Math.random()<.5?-.9:.9);c.strokeStyle=rgba(r.col,.6*a2);c.lineWidth=.6;c.beginPath();c.moveTo(b0[0],b0[1]);
   c.lineTo(b0[0]+Math.cos(ba)*r.len*.35,b0[1]+Math.sin(ba)*r.len*.35);c.stroke();}}
 IMP.arcs=IMP.arcs.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.rings.length;i++){var g=IMP.rings[i],a3=g.life/g.max;g.r+=g.vr;g.vr*=.94;g.life--;c.strokeStyle=rgba(g.col,.55*a3);c.lineWidth=1.2*a3+.3;c.beginPath();c.arc(g.x,g.y,g.r,0,6.2832);c.stroke();}
 IMP.rings=IMP.rings.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.stars.length;i++){var st=IMP.stars[i],a4=st.life/st.max,L2=st.s*(.6+a4*.6);st.life--;c.save();c.translate(st.x,st.y);c.rotate(st.a);
  var sg=c.createRadialGradient(0,0,0,0,0,L2*.7);sg.addColorStop(0,rgba(C.white,.9*a4));sg.addColorStop(1,rgba(st.col,0));c.fillStyle=sg;c.beginPath();c.arc(0,0,L2*.7,0,6.2832);c.fill();
  c.strokeStyle=rgba(C.white,.8*a4);c.lineWidth=.8;c.beginPath();c.moveTo(-L2,0);c.lineTo(L2,0);c.moveTo(0,-L2*.6);c.lineTo(0,L2*.6);c.stroke();c.restore();}
 IMP.stars=IMP.stars.filter(function(q){return q.life>0;});
 c.restore();}
function jointPal(m){return m===4?['#6FA6BF','#173040','rgba(214,243,255,.9)']:m===3?['#5A4488','#1B1230',rgba(C.boost,.9)]:m===1?['#8A4A2A','#2A120A',rgba(C.bounce,.9)]:['#5E7891','#1A2532','rgba(205,224,240,.95)'];}
function bolt(c,x,y,r){var g=c.createRadialGradient(x-r*.35,y-r*.35,0,x,y,r);g.addColorStop(0,'#F2F7FB');g.addColorStop(.55,'#93A9BC');g.addColorStop(1,'#2E3D4B');
 c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();c.strokeStyle='rgba(10,16,22,.6)';c.lineWidth=.6;c.beginPath();c.moveTo(x-r*.5,y);c.lineTo(x+r*.5,y);c.stroke();}
function metal(c,x0,y0,x1,y1,P){var g=c.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,P[0]);g.addColorStop(1,P[1]);return g;}
function jointsBuild(lv,segs){
 var P=[],E=[],i,j,k,a,b2;
 function piece(pts,m,pz){P.push({pts:pts,m:m,pz:pz||null});}
 for(i=0;i<segs.length;i++){var s=segs[i];if(s[5]===1||s[4]===2||isCupWall(lv,s))continue;piece([[s[0],s[1]],[s[2],s[3]]],s[4]);}
 var por=[];if(lv._cv)for(i=0;i<lv._cv.length;i++){if(lv._cv[i].pass&&!lv._cv[i].pz)por.push(lv._cv[i].pts);else piece(lv._cv[i].pts,lv._cv[i].m,lv._cv[i].pass?lv._cv[i].pz:null);}   /* R133 : la matière poreuse n'a ni nœud ni jonction */
 function nearPor(x,y){for(var q=0;q<por.length;q++)for(var r=0;r<por[q].length;r++)if(Math.hypot(por[q][r][0]-x,por[q][r][1]-y)<12)return true;return false;}
 var nodes=[];
 function addArm(x,y,dx,dy,m){var l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
  for(var q=0;q<nodes.length;q++){var n=nodes[q];if(Math.hypot(n.x-x,n.y-y)<9){
    for(var r=0;r<n.arms.length;r++)if(n.arms[r][0]*dx+n.arms[r][1]*dy>Math.cos(16*Math.PI/180))return;
    n.arms.push([dx,dy]);n.x=(n.x*n.k+x)/(n.k+1);n.y=(n.y*n.k+y)/(n.k+1);n.k++;if(n.m!==0&&m===0)n.m=0;return;}}
  nodes.push({x:x,y:y,k:1,m:m,arms:[[dx,dy]]});}
 /* bouts de pièces */
 P.forEach(function(p,pi){var A=p.pts;[[A[0],A[1]],[A[A.length-1],A[A.length-2]]].forEach(function(e){E.push({x:e[0][0],y:e[0][1],dx:e[1][0]-e[0][0],dy:e[1][1]-e[0][1],m:p.m,pi:pi});});});
 /* chaque bout : rejoint‑il un autre bout, ou le corps d'une autre pièce ? */
 E.forEach(function(e){var hit=false;
  E.forEach(function(f){if(f!==e&&f.pi!==e.pi&&Math.hypot(f.x-e.x,f.y-e.y)<9)hit=true;});
  P.forEach(function(p,pi){if(pi===e.pi)return;var A=p.pts;for(var q=1;q<A.length;q++){var ax=A[q][0]-A[q-1][0],ay=A[q][1]-A[q-1][1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((e.x-A[q-1][0])*ax+(e.y-A[q-1][1])*ay)/l)):0;
    var gl=(q-1+u)/(A.length-1);if(gl<.03||gl>.97)continue;
    if(Math.hypot(e.x-A[q-1][0]-u*ax,e.y-A[q-1][1]-u*ay)<8){addArm(e.x,e.y,ax,ay,p.m);addArm(e.x,e.y,-ax,-ay,p.m);hit=true;break;}}});
  e.joined=hit;if(hit)addArm(e.x,e.y,e.dx,e.dy,e.m);});
 /* croisements : intersections de corps à corps */
 for(i=0;i<P.length;i++)for(j=i+1;j<P.length;j++){var A1=P[i].pts,A2=P[j].pts;
  for(a=1;a<A1.length;a++)for(b2=1;b2<A2.length;b2++){var p1=A1[a-1],p2=A1[a],p3=A2[b2-1],p4=A2[b2],d=(p2[0]-p1[0])*(p4[1]-p3[1])-(p2[1]-p1[1])*(p4[0]-p3[0]);if(Math.abs(d)<1e-9)continue;
   var t1=((p3[0]-p1[0])*(p4[1]-p3[1])-(p3[1]-p1[1])*(p4[0]-p3[0]))/d,t2=((p3[0]-p1[0])*(p2[1]-p1[1])-(p3[1]-p1[1])*(p2[0]-p1[0]))/d;
   if(t1<0||t1>1||t2<0||t2>1)continue;var g1=(a-1+t1)/(A1.length-1),g2=(b2-1+t2)/(A2.length-1);if(g1<.03||g1>.97||g2<.03||g2>.97)continue;
   var x=p1[0]+(p2[0]-p1[0])*t1,y=p1[1]+(p2[1]-p1[1])*t1;if([P[i].pz,P[j].pz].some(function(z){return z&&Math.abs(x-z[0])<z[2]&&Math.abs(y-z[1])<z[3];}))continue;   /* R133 : croisement poreux, sans nœud */
   var ux=p2[0]-p1[0],uy=p2[1]-p1[1],vx=p4[0]-p3[0],vy=p4[1]-p3[1];
   addArm(x,y,ux,uy,P[i].m);addArm(x,y,-ux,-uy,P[i].m);addArm(x,y,vx,vy,P[j].m);addArm(x,y,-vx,-vy,P[j].m);nodes[nodes.length-1].cross=1;}}
 return {nodes:nodes,ends:E.filter(function(e){return !e.joined&&!nearPor(e.x,e.y);})};}
function hull(pts){pts=pts.slice().sort(function(a,b){return a[0]-b[0]||a[1]-b[1];});function cr(o,a,b){return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);}
 var lo=[],up=[],i;for(i=0;i<pts.length;i++){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],pts[i])<=0)lo.pop();lo.push(pts[i]);}
 for(i=pts.length-1;i>=0;i--){while(up.length>=2&&cr(up[up.length-2],up[up.length-1],pts[i])<=0)up.pop();up.push(pts[i]);}up.pop();lo.pop();return lo.concat(up);}
function joints(c,segs,lv){
 var key=segs.length+':'+(lv._cv?lv._cv.length:0)+':'+(lv.w?lv.w.length:0);
 if(!lv._jn||lv._jnKey!==key){lv._jn=jointsBuild(lv,segs);lv._jnKey=key;}
 var J=lv._jn,i,k;c.save();c.lineJoin=c.lineCap='round';
 var t=now(),Wc=C.white;
 J.nodes.forEach(function(n){if(n.arms.length<2)return;var A=lv.jA||(n.m===4?[214,243,255]:n.m===3?C.boost:n.m===1?C.bounce:C.matter),L=10,W=6.5,pts=[];
  n.arms.forEach(function(a){var nx=-a[1],ny=a[0];[[L,W],[L,-W],[2,W],[2,-W]].forEach(function(q){pts.push([n.x+a[0]*q[0]+nx*q[1],n.y+a[1]*q[0]+ny*q[1]]);});});
  var H=hull(pts);if(H.length<3)return;
  /* lentille : l'enveloppe des bras devient un verre de lumière (dégradé radial, liseré lumineux) */
  var lg=c.createRadialGradient(n.x,n.y,0,n.x,n.y,15);lg.addColorStop(0,rgba(A,.42));lg.addColorStop(.6,'rgba(12,20,36,.78)');lg.addColorStop(1,'rgba(8,12,24,.7)');
  c.fillStyle=lg;c.beginPath();c.moveTo(H[0][0],H[0][1]);for(k=1;k<H.length;k++)c.lineTo(H[k][0],H[k][1]);c.closePath();c.fill();
  c.globalCompositeOperation='lighter';c.strokeStyle=rgba(A,.22);c.lineWidth=4;c.stroke();c.strokeStyle=rgba(A,.8);c.lineWidth=.9;c.stroke();c.globalCompositeOperation='source-over';
  /* bagues de lumière sur chaque bras */
  n.arms.forEach(function(a){var nx=-a[1],ny=a[0],cx2=n.x+a[0]*(L-1.6),cy2=n.y+a[1]*(L-1.6);c.strokeStyle=rgba(Wc,.65);c.lineWidth=1;
   c.beginPath();c.moveTo(cx2+nx*W*.9,cy2+ny*W*.9);c.lineTo(cx2-nx*W*.9,cy2-ny*W*.9);c.stroke();});
  /* cœur : un petit atome — noyau blanc, halo, orbite elliptique qui tourne lentement */
  c.globalCompositeOperation='lighter';var hg=c.createRadialGradient(n.x,n.y,0,n.x,n.y,9);hg.addColorStop(0,rgba(Wc,.95));hg.addColorStop(.25,rgba(A,.7));hg.addColorStop(1,rgba(A,0));
  c.fillStyle=hg;c.beginPath();c.arc(n.x,n.y,9,0,6.2832);c.fill();
  var pr=((t*.008+n.x*.013+n.y*.007)%1);c.strokeStyle=rgba(A,.45*(1-pr));c.lineWidth=.8;c.beginPath();c.arc(n.x,n.y,5+pr*16,0,6.2832);c.stroke();   /* onde qui s'échappe */
  var ro=t*.02+n.x*.01;c.save();c.translate(n.x,n.y);c.rotate(ro);c.strokeStyle=rgba(A,.75);c.lineWidth=.8;c.beginPath();c.ellipse(0,0,6.5,2.4,0,0,6.2832);c.stroke();
  c.rotate(Math.PI/2.4);c.strokeStyle=rgba(Wc,.35);c.beginPath();c.ellipse(0,0,6.5,2.4,0,0,6.2832);c.stroke();
  var ea=t*.08;c.fillStyle=rgba(Wc,.95);c.beginPath();c.arc(Math.cos(ea)*6.5,Math.sin(ea)*2.4,1,0,6.2832);c.fill();c.restore();
  c.globalCompositeOperation='source-over';var Wc2=Wc;});
 J.ends.forEach(function(e){var A=lv.jA||(e.m===4?[214,243,255]:e.m===3?C.boost:e.m===1?C.bounce:C.matter);
  if(e.x<7||e.x>VW-7||e.y<7){ /* ancrage au bord : arc de lumière plaqué au bord, deux points d'ancrage */
   var px=e.x<7?0:e.x>VW-7?VW:e.x,py=e.y<7?0:e.y,vert=!(e.y<7);c.globalCompositeOperation='lighter';
   c.strokeStyle=rgba(A,.25);c.lineWidth=5;c.beginPath();if(vert){c.moveTo(px,py-11);c.lineTo(px,py+11);}else{c.moveTo(px-11,py);c.lineTo(px+11,py);}c.stroke();
   c.strokeStyle=rgba(Wc,.85);c.lineWidth=1.2;c.stroke();
   [-8,8].forEach(function(o){var ax=vert?px+(px<VW/2?2:-2):px+o,ay=vert?py+o:py+2;c.fillStyle=rgba(Wc,.9);c.beginPath();c.arc(ax,ay,1.3,0,6.2832);c.fill();});
   c.globalCompositeOperation='source-over';return;}
  /* bout libre : une perle de lumière */
  var pu=.85+.15*Math.sin(t*.06+e.x*.1);c.globalCompositeOperation='lighter';var pg=c.createRadialGradient(e.x,e.y,0,e.x,e.y,7*pu);pg.addColorStop(0,rgba(Wc,.95));pg.addColorStop(.3,rgba(A,.65));pg.addColorStop(1,rgba(A,0));
  c.fillStyle=pg;c.beginPath();c.arc(e.x,e.y,7*pu,0,6.2832);c.fill();c.globalCompositeOperation='source-over';
  c.strokeStyle=rgba(A,.8);c.lineWidth=.8;c.beginPath();c.arc(e.x,e.y,3.6,0,6.2832);c.stroke();});
 c.restore();}

/* trait du joueur : ruban d'énergie (structure) ou plaque (rebond). Renvoie false si non géré. */
function stroke(c,pts,mat,k){if(mat===1||mat===3){if(pts.length<2)return true;c.save();c.globalAlpha=k===undefined?1:k;curve(c,pts,mat,{noHang:1});c.restore();return true;}   /* R155 : le tracé rebond / accélérateur du joueur parle la même langue que les pièces du niveau (fines, lumineuses) */
 if(mat!==0)return false;var t=now();c.save();c.globalAlpha=k===undefined?1:k;c.lineCap='round';c.lineJoin='round';
 function path(){c.beginPath();for(var j=0;j<pts.length;j++){if(j)c.lineTo(pts[j][0],pts[j][1]);else c.moveTo(pts[j][0],pts[j][1]);}}
 c.shadowColor='#4DD7FF';c.shadowBlur=18;c.strokeStyle='rgba(77,215,255,.9)';c.lineWidth=5.5;path();c.stroke();
 c.shadowBlur=0;c.strokeStyle='#E8FBFF';c.lineWidth=1.6;path();c.stroke();
 c.setLineDash([3,11]);c.lineDashOffset=-t*.9;c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=2.6;path();c.stroke();c.setLineDash([]);
 c.restore();return true;}

/* ============================ NUAGES DE POINTS ============================ */
/* Références : illusions bistables (nuages de points en rotation 3D, sans indice
   de profondeur — le sens de rotation est ambigu : métaphore de la superposition). */
var SPH=[],CAP=[],RING=[],i;
for(i=0;i<150;i++){var yy=1-2*(i+.5)/150,rr=Math.sqrt(1-yy*yy),aa=i*2.39996;SPH.push([Math.cos(aa)*rr,yy,Math.sin(aa)*rr]);}
for(i=0;i<170;i++){var u=i/170,a2=i*2.39996,y2=u*2-1,cap=.55,x2,z2;
 if(Math.abs(y2)<cap){x2=Math.cos(a2);z2=Math.sin(a2);}else{var kq=(Math.abs(y2)-cap)/(1-cap),hq=Math.sqrt(Math.max(0,1-kq*kq));x2=Math.cos(a2)*hq;z2=Math.sin(a2)*hq;y2=(y2<0?-1:1)*(cap+kq*.55);}
 CAP.push([x2*.62,y2,z2*.62]);}
for(i=0;i<80;i++){var a3=i/80*6.2832;RING.push([Math.cos(a3),0,Math.sin(a3)]);}
function rot(p,ax,ay,az){var x=p[0],y=p[1],z=p[2],c1=Math.cos(ay),s1=Math.sin(ay),t;t=x*c1+z*s1;z=-x*s1+z*c1;x=t;
 c1=Math.cos(ax);s1=Math.sin(ax);t=y*c1-z*s1;z=y*s1+z*c1;y=t;if(az){c1=Math.cos(az);s1=Math.sin(az);t=x*c1-y*s1;y=x*s1+y*c1;x=t;}return [x,y,z];}
function cloud(c,pts,R,ax,ay,az,colf,sz){for(var j=0;j<pts.length;j++){var q=rot(pts[j],ax,ay,az);c.fillStyle=colf(pts[j]);c.fillRect(q[0]*R-sz/2,q[1]*R-sz/2,sz,sz);}}
function sphereCol(p){var f=(p[1]+1)/2;return rgba(f>.5?mix(C.pink,C.boost,(1-f)*2):mix(C.boost,C.matter,(.5-f)*2),.9);}

/* noyau : sphère bistable + anneau (Fonderie : capsule orange-or) */
function core(c,lv){
 /* NOYAU (R58) — d'après la vidéo fournie par Simon (fsaver_04673) : SURFACE D'ENNEPER en nuage de points très fin,
    projection orthogonale (rotation bistable), un tour en 6 s, axe incliné. Couleurs de la charte du noyau (or → ambre →
    rose → blanc chaud), pas l'arc‑en‑ciel de la vidéo. Taille ≈ 2 fois la particule : on ne peut plus les confondre
    (la particule reste la petite sphère cyan‑blanc cerclée de blanc). */
 if(!ENN)ennBuild();
 var st=lv.star,pulse=.5+.5*Math.sin(now()*.006),i,p;c.save();c.translate(st[0],st[1]);
 var gr=c.createRadialGradient(0,0,0,0,0,30);gr.addColorStop(0,rgba(C.reward,.16+.06*pulse));gr.addColorStop(.6,rgba([255,170,60],.05));gr.addColorStop(1,'rgba(0,0,0,0)');
 c.fillStyle=gr;c.fillRect(-30,-30,60,60);
 var a=((typeof OPT!=="undefined"&&OPT.rm)?0:(typeof performance!=='undefined'?performance.now():0)*.001047),ax=[1,.35,.15],l=Math.hypot(ax[0],ax[1],ax[2]);ax=[ax[0]/l,ax[1]/l,ax[2]/l];
 var ca=Math.cos(a),sa=Math.sin(a),k1=1-ca,X=ax[0],Y=ax[1],Z=ax[2],
  m00=ca+X*X*k1,m01=X*Y*k1-Z*sa,m10=Y*X*k1+Z*sa,m11=ca+Y*Y*k1,m02=X*Z*k1+Y*sa,m12=Y*Z*k1-X*sa,sc=21,ps=.95;
 c.globalCompositeOperation='lighter';
 for(i=0;i<ENN.length;i++){p=ENN[i];c.fillStyle=ENNC[p[3]]+'.5)';
  c.fillRect((m00*p[0]+m01*p[1]+m02*p[2])*sc-ps/2,(m10*p[0]+m11*p[1]+m12*p[2])*sc-ps/2,ps,ps);}
 c.restore();}

/* nuage d'Enneper (R57, utilisé par le noyau depuis R58) */
/* balle (R57) — d'après la vidéo de référence fournie par Simon (fsaver_04673) : analyse image par image —
   la forme est une SURFACE D'ENNEPER (surface minimale : un carré aux côtés creusés d'où sortent quatre lobes qui se
   replient) rendue en nuage de points très fin, sans contour, en projection orthogonale (d'où l'illusion bistable : on ne
   sait pas dans quel sens elle tourne). Couleur : teinte arc‑en‑ciel qui suit l'angle autour de la surface (saturation
   ≈ 0,6, points peu lumineux qui s'additionnent : les plis s'allument). Rotation régulière : un tour en 6 s, axe incliné.
   Collision inchangée (cercle de rayon R) : le dessin est mis à l'échelle pour rester proche de ce cercle. */
var ENN=null,ENNC=null;
function ennBuild(){var n=900,pts=[],i,mx=0,r,th,x,y,z;
 var seed=0,wmax=1.55*Math.pow(1+1.55*1.55,2);for(i=0;i<n;i++){ /* tirage uniforme SUR la surface : l'aire d'Enneper croît comme r(1+r²)² — le centre reste clairsemé comme dans la vidéo */
  do{seed++;r=rnd(seed*1.37+.5)*1.55;}while(rnd(seed*4.13+2.2)*wmax>r*Math.pow(1+r*r,2)&&seed<n*60);
  th=rnd(i*2.91+7.1)*6.2832;
  x=r*Math.cos(th)-r*r*r/3*Math.cos(3*th);y=-r*Math.sin(th)-r*r*r/3*Math.sin(3*th);z=r*r*Math.cos(2*th);
  pts.push([x,y,z,Math.floor((((th/6.2832)+.6)%1)*24)]);mx=Math.max(mx,Math.hypot(x,y,z));}
 for(i=0;i<n;i++){pts[i][0]/=mx;pts[i][1]/=mx;pts[i][2]/=mx;}
 ENN=pts;ENNC=[];
 /* palette du jeu, pas l'arc‑en‑ciel de la vidéo : or du noyau (reward) → ambre (bounce) → rose (pink) → blanc chaud, en boucle */
 var stops=[C.reward,[255,170,60],C.pink,[255,240,214],C.reward];
 for(i=0;i<24;i++){var u=i/24*4,k=Math.floor(u),f=u-k,A=stops[k],B=stops[k+1];
  ENNC.push('rgba('+Math.round(A[0]+(B[0]-A[0])*f)+','+Math.round(A[1]+(B[1]-A[1])*f)+','+Math.round(A[2]+(B[2]-A[2])*f)+',');}}
/* balle : particule en nuage de points (sphère bistable), cœur lumineux, contour net pour rester lisible */
function ball(c,x,y,ang,r,tint){var t=now();c.save();c.translate(x,y);
 var tc=tint?hex(tint):null;
 var gr=c.createRadialGradient(0,0,0,0,0,r*2.1);gr.addColorStop(0,rgba(tc||C.matter,.35));gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(-r*2.1,-r*2.1,r*4.2,r*4.2);
 gr=c.createRadialGradient(-r*.25,-r*.3,0,0,0,r);gr.addColorStop(0,'rgba(255,255,255,.55)');gr.addColorStop(.5,rgba(tc||C.boost,.28));gr.addColorStop(1,rgba(tc||C.matter,.12));
 c.fillStyle=gr;c.beginPath();c.arc(0,0,r,0,6.2832);c.fill();
 c.globalCompositeOperation='lighter';
 cloud(c,SPH,r*.96,.45,(ang||0)+t*.01,0,tc?function(){return rgba(tc,.9);}:sphereCol,1.25);
 c.globalCompositeOperation='source-over';c.strokeStyle=rgba(tc||C.white,.7);c.lineWidth=1;c.beginPath();c.arc(0,0,r,0,6.2832);c.stroke();
 c.restore();}
/* R158 : balle molle au style des particules — halo, nuage de points en rotation étiré selon la déformation réelle
   (axes principaux du contour), découpé par le contour, liseré fin */
function softball(c,P,ct,ang){var t=now(),n=P.length,i,mx=0,my=0,sxx=0,syy=0,sxy=0,r0=0;
 for(i=0;i<n;i++){var dx=P[i].x-ct[0],dy=P[i].y-ct[1];sxx+=dx*dx;syy+=dy*dy;sxy+=dx*dy;r0+=Math.hypot(dx,dy);}
 sxx/=n;syy/=n;sxy/=n;r0/=n;var th=.5*Math.atan2(2*sxy,sxx-syy),tr=(sxx+syy)/2,dd=Math.sqrt(Math.max(0,(sxx-syy)*(sxx-syy)/4+sxy*sxy)),
  ea=Math.sqrt(tr+dd),eb=Math.sqrt(Math.max(1,tr-dd)),k=r0/Math.max(1,Math.sqrt(ea*eb)),fa=ea*k/r0,fb=eb*k/r0;
 function path(){c.beginPath();var m0=[(P[n-1].x+P[0].x)/2,(P[n-1].y+P[0].y)/2];c.moveTo(m0[0],m0[1]);
  for(var j=0;j<n;j++){var a=P[j],b=P[(j+1)%n];c.quadraticCurveTo(a.x,a.y,(a.x+b.x)/2,(a.y+b.y)/2);}c.closePath();}
 c.save();var gr=c.createRadialGradient(ct[0],ct[1],0,ct[0],ct[1],r0*2.2);gr.addColorStop(0,rgba(C.matter,.32));gr.addColorStop(1,'rgba(0,0,0,0)');
 c.fillStyle=gr;c.fillRect(ct[0]-r0*2.2,ct[1]-r0*2.2,r0*4.4,r0*4.4);
 path();gr=c.createRadialGradient(ct[0]-r0*.25,ct[1]-r0*.3,0,ct[0],ct[1],r0*1.1);gr.addColorStop(0,'rgba(255,255,255,.5)');gr.addColorStop(.5,rgba(C.boost,.26));gr.addColorStop(1,rgba(C.matter,.12));
 c.fillStyle=gr;c.fill();c.save();c.clip();c.translate(ct[0],ct[1]);c.rotate(th);c.scale(fa,fb);c.rotate(-th);
 c.globalCompositeOperation='lighter';cloud(c,SPH,r0*.98,.45,(ang||0)+t*.01,0,sphereCol,1.25);c.restore();
 path();c.strokeStyle=rgba(C.white,.65);c.lineWidth=1;c.stroke();c.restore();}
function hex(h){if(typeof h!=='string'||h.charAt(0)!=='#')return C.boost;return [parseInt(h.substr(1,2),16),parseInt(h.substr(3,2),16),parseInt(h.substr(5,2),16)];}

/* ============================ ACCUEIL ============================ */
var HD=null;
function hero(c,w,h){var t=now();
 if(!HD||HD.w!==w||HD.h!==h){HD={w:w,h:h,dust:[]};for(var j=0;j<90;j++)HD.dust.push({x:rnd(j)*w,y:rnd(j*1.7)*h,z:.3+rnd(j*2.3)*.7,ph:rnd(j*4.1)*6.28,col:[C.white,C.white,C.matter,C.boost][j%4]});}
 c.fillStyle='#070B14';c.fillRect(0,0,w,h);
 c.save();c.globalCompositeOperation='lighter';
 var b1=[[w*.2,h*.5,w*.55,C.boost,.16],[w*.78,h*.45,w*.45,C.matter,.14],[w*.55,h*.9,w*.4,C.reward,.06]];
 for(var i=0;i<b1.length;i++){var q=b1[i],x=q[0]+Math.sin(t*.004+i)*10,gr=c.createRadialGradient(x,q[1],0,x,q[1],q[2]);
  gr.addColorStop(0,rgba(q[3],q[4]*(.85+.15*Math.sin(t*.01+i))));gr.addColorStop(1,rgba(q[3],0));c.fillStyle=gr;c.fillRect(0,0,w,h);}
 for(i=0;i<HD.dust.length;i++){var d=HD.dust[i];d.x+=.08*d.z;d.y-=.03*d.z;if(d.x>w+3)d.x=-3;if(d.y<-3)d.y=h+3;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),s=.5+d.z*1.2;c.fillStyle=rgba(d.col,(.15+.5*d.z)*tw);c.fillRect(d.x,d.y,s,s);}
 c.restore();
 helix(c,-10,h*.78,w*.62,h*.18,11,3.2,.028,C.matter,C.boost,.55,70);
 var cx=w*.8,cy=h*.5,R=Math.min(h*.36,w*.16);
 c.save();c.translate(cx,cy);c.globalCompositeOperation='lighter';
 var g2=c.createRadialGradient(0,0,0,0,0,R*1.6);g2.addColorStop(0,rgba(C.boost,.22));g2.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g2;c.fillRect(-R*1.6,-R*1.6,R*3.2,R*3.2);
 cloud(c,SPH,R,.35,t*.012,0,sphereCol,1.6);
 cloud(c,RING,R*1.45,1.2+Math.sin(t*.003)*.15,-t*.009,0,function(p){return rgba(mix(C.reward,C.goal,(p[0]+1)/2),.7);},1.4);
 c.restore();}
function heroWall(c,q){stroke(c,[[q[0],q[1]],[q[2],q[3]]],0,1);}

/* pièce courbe (R82) : même langage que les poutres, plaques, tapis et glace droits — une bande avec sa profondeur (12 u),
   sa surface lumineuse, ses détails (treillis, cellules, reflets), mais continue et sans jointures */
/* ══ PIÈCE COURBE (R85) — finition « piste de montagnes russes » ══
   Construite à abscisse curviligne constante. Couches, de l'arrière vers l'avant :
   1. ombre portée douce sur le décor ;           2. suspentes fines vers le haut (comme les poutres droites) ;
   3. corps : âme en dégradé + membrure basse ;    4. traverses perpendiculaires et treillis de Warren, rivets aux nœuds ;
   5. rail de roulement en tube (trois passes : ombre, teinte, reflet) ; 6. lampes le long du rail qui s'allument au passage
   de la particule et une lueur lente qui parcourt la piste ; 7. platines d'about boulonnées aux extrémités.
   Glace : bloc translucide, givre intérieur, scintillements. Tapis : galets qui tournent dans le sens de poussée. */
function curve(c,P,mat,opt){opt=opt||{};if(P.length<2)return;var t=now(),Dp=12,i,k,N=[],Bt=[],cum=[0];
 for(i=1;i<P.length;i++)cum.push(cum[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));var Ltot=cum[cum.length-1];
 for(i=0;i<P.length;i++){var a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;N.push([-dy/l,dx/l]);}
 var sx=0,sy=0;for(i=0;i<N.length;i++){sx+=N[i][0];sy+=N[i][1];}var flip=(sy<0||(Math.abs(sy)<.2*N.length&&sx*(P[0][0]-VW/2)<0))?-1:1;
 for(i=0;i<N.length;i++){N[i][0]*=flip;N[i][1]*=flip;Bt.push([P[i][0]+N[i][0]*Dp,P[i][1]+N[i][1]*Dp]);}
 function at(s,off){s=Math.max(0,Math.min(Ltot,s));var j=1;while(j<cum.length-1&&cum[j]<s)j++;var u=(s-cum[j-1])/Math.max(1e-6,cum[j]-cum[j-1]),
  x=P[j-1][0]+(P[j][0]-P[j-1][0])*u,y=P[j-1][1]+(P[j][1]-P[j-1][1])*u,nx=N[j-1][0]+(N[j][0]-N[j-1][0])*u,ny=N[j-1][1]+(N[j][1]-N[j-1][1])*u,nl=Math.hypot(nx,ny)||1;
  return [x+nx/nl*off,y+ny/nl*off,nx/nl,ny/nl];}
 function line(off,from,to,step){c.beginPath();for(var s=from;s<=to+.01;s+=step){var q=at(s,off);if(s===from)c.moveTo(q[0],q[1]);else c.lineTo(q[0],q[1]);}}
 var ice=mat===4,belt=mat===3,hot=mat===1;
 /* R88 — langue « quantique onirique » : la pièce n'est plus de l'acier mais de la LUMIÈRE TENUE — un rail de photons,
    une âme translucide qui s'éteint en profondeur, un réseau fin comme une constellation, des nœuds qui scintillent. */
 var A=opt.accent||(ice?[214,243,255]:belt?C.boost:hot?C.bounce:C.matter),Wc=C.white;
 var bx=-999,by=-999;try{if(typeof S!=='undefined'&&S.ball){bx=S.ball.x;by=S.ball.y;}}catch(e){}
 c.save();c.lineJoin=c.lineCap='round';
 /* suspentes : fils de lumière très fins */
 if(!opt.noHang){c.strokeStyle=rgba(A,.10);c.lineWidth=.8;for(var sh=Math.min(40,Ltot/2);sh<Ltot;sh+=90){var h=at(sh,0);if(h[3]<-.3)continue;c.beginPath();c.moveTo(h[0],h[1]-3);c.lineTo(h[0],0);c.stroke();}}
 /* âme translucide : la couleur de la matière près du rail, qui s'éteint vers la profondeur */
 var mid=Math.floor(P.length/2),gr=c.createLinearGradient(P[mid][0],P[mid][1],Bt[mid][0],Bt[mid][1]);
 gr.addColorStop(0,rgba(A,ice?.30:.22));gr.addColorStop(.55,'rgba(10,16,30,.55)');gr.addColorStop(1,'rgba(5,7,13,.25)');
 c.fillStyle=gr;c.beginPath();c.moveTo(P[0][0],P[0][1]);for(i=1;i<P.length;i++)c.lineTo(P[i][0],P[i][1]);for(i=Bt.length-1;i>=0;i--)c.lineTo(Bt[i][0],Bt[i][1]);c.closePath();c.fill();
 /* membrure de profondeur : un filet */
 c.strokeStyle=rgba(A,.28);c.lineWidth=.8;line(Dp-.6,0,Ltot,3);c.stroke();
 if(belt){ /* tapis : anneaux de champ qui défilent dans le sens de poussée */
  var ofs=(t*.6*(opt.speed==null?1:opt.speed))%12;for(var sg=ofs+4;sg<Ltot-3;sg+=12){var q3=at(sg,Dp*.5);c.strokeStyle=rgba(A,.7);c.lineWidth=1;c.beginPath();c.arc(q3[0],q3[1],3.6,0,6.2832);c.stroke();
   c.fillStyle=rgba(Wc,.5);c.beginPath();c.arc(q3[0],q3[1],1,0,6.2832);c.fill();}}
 else{ /* réseau en constellation : treillis fin + nœuds‑étoiles qui scintillent (glace : givre intérieur à la place) */
  var n=Math.max(2,Math.round(Ltot/14));
  if(!ice){c.strokeStyle=rgba(A,.30);c.lineWidth=.75;c.beginPath();for(k=0;k<=n;k++){var q2=at(k/n*Ltot,k%2?Dp-1.8:2.4);if(k)c.lineTo(q2[0],q2[1]);else c.moveTo(q2[0],q2[1]);}c.stroke();}
  else{c.strokeStyle=rgba(A,.13);c.lineWidth=.7;for(var g=3;g<Dp;g+=2.8){line(g,0,Ltot,4);c.stroke();}}
  c.globalCompositeOperation='lighter';
  for(k=0;k<=n;k++){var st=at(k/n*Ltot,k%2?Dp-1.8:2.4),tw=.35+.65*Math.max(0,Math.sin(t*.07+k*1.7));c.fillStyle=rgba(k%3?A:Wc,.35+.5*tw);
   c.beginPath();c.arc(st[0],st[1],.7+tw*.7,0,6.2832);c.fill();}
  c.globalCompositeOperation='source-over';}
 /* rail de photons : halo, couleur, cœur blanc */
 var br=.75+.25*Math.sin(t*.035+Ltot*.07);c.globalCompositeOperation='lighter';c.strokeStyle=rgba(A,.16*br);c.lineWidth=9;line(0,0,Ltot,2.5);c.stroke();
 c.strokeStyle=rgba(A,.55);c.lineWidth=3.6;line(0,0,Ltot,2.5);c.stroke();c.globalCompositeOperation='source-over';
 c.strokeStyle=rgba(Wc,.92);c.lineWidth=1.3;line(-.2,0,Ltot,2.5);c.stroke();
 /* R89 — petites animations : rebond = ondes qui battent sur la face ; tapis = éclair quand il pousse ; toutes = poussières
    de lumière qui se détachent du rail et montent doucement */
 if(hot){c.globalCompositeOperation='lighter';for(var so=8;so<Ltot-4;so+=14){var qo=at(so,0),ph=(t*.05+so*.21)%1,dd=Math.hypot(qo[0]-bx,qo[1]-by),k2=Math.max(ph<.5?ph*2:2-ph*2,dd<40?1-dd/40:0);
   c.strokeStyle=rgba(A,.15+.55*k2);c.lineWidth=1;c.beginPath();c.arc(qo[0]-qo[2]*2,qo[1]-qo[3]*2,3+2.5*k2,Math.atan2(-qo[3],-qo[2])-1,Math.atan2(-qo[3],-qo[2])+1);c.stroke();}c.globalCompositeOperation='source-over';}
 if(belt&&typeof D!=='undefined'&&D.flash)for(var fi=0;fi<D.flash.length;fi++){var fq=D.flash[fi];for(var sb=0;sb<Ltot;sb+=6){var qb=at(sb,0);if(Math.hypot(qb[0]-fq.x,qb[1]-fq.y)<22){
   c.globalCompositeOperation='lighter';c.strokeStyle=rgba(Wc,.5*fq.life);c.lineWidth=2.4;line(0,Math.max(0,sb-18),Math.min(Ltot,sb+18),3);c.stroke();c.globalCompositeOperation='source-over';break;}}}
 c.globalCompositeOperation='lighter';
 for(var mo=0;mo<Math.max(2,Ltot/34);mo++){var sm=((mo*61.7+Ltot)%Ltot),life=((t*.012+mo*.37)%1),qm=at(sm,0),rise=life*16;
  c.fillStyle=rgba(mo%2?A:Wc,.55*(1-life)*Math.min(1,life*5));c.beginPath();c.arc(qm[0]-qm[2]*rise+Math.sin(t*.03+mo)*1.5,qm[1]-qm[3]*rise,.9,0,6.2832);c.fill();}
 c.globalCompositeOperation='source-over';
 /* photons qui circulent le long du rail ; ils s'éveillent quand la particule approche */
 c.globalCompositeOperation='lighter';var fl=(t*.9)%26;
 for(var sl=fl;sl<Ltot;sl+=26){var lp=at(sl,0),d=Math.hypot(lp[0]-bx,lp[1]-by),e=Math.max(.25,1-d/60);
  var gl=c.createRadialGradient(lp[0],lp[1],0,lp[0],lp[1],3+5*e);gl.addColorStop(0,rgba(Wc,.85*e));gl.addColorStop(.4,rgba(A,.5*e));gl.addColorStop(1,rgba(A,0));
  c.fillStyle=gl;c.beginPath();c.arc(lp[0],lp[1],3+5*e,0,6.2832);c.fill();}
 c.globalCompositeOperation='source-over';
 /* 7. les extrémités sont traitées par la bibliothèque de connecteurs (joints) */
 c.restore();}
/* ══ R130 — PAROI TUNNEL (effet tunnel) ══ couleur propre (air #A9BCEB) ; deux rangées d'atomes qui glissent l'une dans l'autre
   (imbrication moléculaire) sur un voile pâle ; au passage d'une particule rapide, les atomes s'écartent et une onde se propage. */
var TUN=[];
function tunnel(c,P,pz){var t=now(),A=[169,188,235],Wc=[236,244,255],i,k,Q=[];
 for(i=0;i<P.length;i++){var q=P[i];if(!pz||(Math.abs(q[0]-pz[0])<pz[2]&&Math.abs(q[1]-pz[1])<pz[3]))Q.push(q);else if(Q.length>1)break;}
 if(Q.length<2)return;var cum=[0];for(i=1;i<Q.length;i++)cum.push(cum[i-1]+Math.hypot(Q[i][0]-Q[i-1][0],Q[i][1]-Q[i-1][1]));var L0=cum[cum.length-1];
 function at(d){d=Math.max(0,Math.min(L0,d));var j=1;while(j<Q.length-1&&cum[j]<d)j++;var u=(d-cum[j-1])/((cum[j]-cum[j-1])||1),x=Q[j-1][0]+(Q[j][0]-Q[j-1][0])*u,y=Q[j-1][1]+(Q[j][1]-Q[j-1][1])*u,dx=Q[j][0]-Q[j-1][0],dy=Q[j][1]-Q[j-1][1],l=Math.hypot(dx,dy)||1;return [x,y,-dy/l,dx/l];}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.shadowColor=rgba(A,.9);c.shadowBlur=14;c.strokeStyle=rgba(A,.16);c.lineWidth=20;c.beginPath();c.moveTo(Q[0][0],Q[0][1]);for(i=1;i<Q.length;i++)c.lineTo(Q[i][0],Q[i][1]);c.stroke();c.shadowBlur=0;   /* voile */
 for(k=0;k<2;k++){c.strokeStyle=rgba(k?Wc:A,.7);c.lineWidth=1.1;c.beginPath();for(var hd=0;hd<=L0;hd+=1.5){var hp=at(hd),ho=Math.sin(hd*.45-t*.08+k*Math.PI)*5*Math.min(1,Math.min(hd,L0-hd)/8);if(hd===0)c.moveTo(hp[0]+hp[2]*ho,hp[1]+hp[3]*ho);else c.lineTo(hp[0]+hp[2]*ho,hp[1]+hp[3]*ho);}c.stroke();}   /* deux brins imbriqués */
 for(k=0;k<2;k++){var ep=at(k?L0:0);c.strokeStyle=rgba(Wc,.6);c.lineWidth=1.4;c.beginPath();c.moveTo(ep[0]-ep[2]*9,ep[1]-ep[3]*9);c.lineTo(ep[0]+ep[2]*9,ep[1]+ep[3]*9);c.stroke();}   /* bornes de la zone */
 c.setLineDash([2,5]);c.lineDashOffset=-t*.25;c.strokeStyle=rgba(Wc,.55);c.lineWidth=1.2;c.stroke();c.setLineDash([]);
 for(k=-1;k<=1;k+=2)for(var d=0;d<L0;d+=7){var ph=(d+k*t*.12)%7,dd=d+(ph<0?ph+7:ph),p=at(dd),off=k*3.6+Math.sin(t*.05+dd*.3)*.8,x=p[0]+p[2]*off,y=p[1]+p[3]*off,push=0;
  for(var e=0;e<TUN.length;e++){var g=TUN[e],r=Math.hypot(x-g.x,y-g.y);if(r<26){push+=(26-r)/26*9*g.l;var ang=Math.atan2(y-g.y,x-g.x);x+=Math.cos(ang)*push;y+=Math.sin(ang)*push;}}
  var fade=Math.min(1,Math.min(dd,L0-dd)/10);c.fillStyle=rgba(k<0?A:Wc,(.75)*fade);c.beginPath();c.arc(x,y,k<0?1.6:1.2,0,6.2832);c.fill();}
 for(i=TUN.length-1;i>=0;i--){var g=TUN[i];c.strokeStyle=rgba(A,.5*g.l);c.lineWidth=1;c.beginPath();c.arc(g.x,g.y,8+(1-g.l)*30,0,6.2832);c.stroke();g.l-=.03;if(g.l<=0)TUN.splice(i,1);}
 c.restore();}
/* ══ R130 — POUSSIÈRE D'ÉTOILE QUI MONTRE LE CHEMIN ══ un filet de grains très fins dérive le long de lv.flow (vers l'entrée de
   la machine) ; discret, il naît et s'éteint en douceur. */
function flow(c,path){if(!path||path.length<2)return;var t=now(),i,F=path._f;
 if(!F){var cum=[0],tn=[],hot=[];for(i=1;i<path.length;i++)cum.push(cum[i-1]+Math.hypot(path[i][0]-path[i-1][0],path[i][1]-path[i-1][1]));
  for(i=1;i<path.length-1;i++){var a1=Math.atan2(path[i][1]-path[i-1][1],path[i][0]-path[i-1][0]),a2=Math.atan2(path[i+1][1]-path[i][1],path[i+1][0]-path[i][0]),da=Math.abs(((a2-a1+9.4248)%6.2832)-3.1416);
   if(da>.42&&(!hot.length||cum[i]-hot[hot.length-1]>40))hot.push(cum[i]);}   /* virages serrés : là où des grains décrochent */
  F=path._f={cum:cum,L0:cum[cum.length-1],hot:hot};}
 var cum=F.cum,L0=F.L0;
 function at(d){d=Math.max(0,Math.min(L0,d));var j=1;while(j<path.length-1&&cum[j]<d)j++;var sl=(cum[j]-cum[j-1])||1,u=(d-cum[j-1])/sl,dx=(path[j][0]-path[j-1][0])/sl,dy=(path[j][1]-path[j-1][1])/sl;
  return [path[j-1][0]+dx*sl*u,path[j-1][1]+dy*sl*u,dx,dy];}
 var n=Math.max(50,Math.min(280,Math.round(L0/4.2)));
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(var k=0;k<n;k++){var h1=Math.sin(k*12.9898)*43758.5453,j1=h1-Math.floor(h1),h2=Math.sin(k*78.233)*12543.17,j2=h2-Math.floor(h2),h3=Math.sin(k*39.425)*24634.63,j3=h3-Math.floor(h3),h4=Math.sin(k*93.989)*15731.71,j4=h4-Math.floor(h4);
  var sp=.35+j1*j1*1.6,span=L0+70,d=(t*sp+j2*span)%span,p,a=Math.min(1,d/34,Math.max(0,(L0-d)/34)),off=Math.sin(t*.025+k*1.3)*(1.2+j3*3.6),x,y,tx,ty;
  var fug=(k%5===0&&F.hot.length)?F.hot[(k/5|0)%F.hot.length]:-1;
  if(fug>=0&&d>fug){var e=d-fug;p=at(fug);tx=p[2];ty=p[3];var sg=(j3<.5)?1:-1;   /* le grain décroche de son orbite : il file tout droit et s'écarte doucement */
   x=p[0]+tx*e+(-ty)*sg*e*e*.004;y=p[1]+ty*e+tx*sg*e*e*.004;a=Math.min(1,fug/34)*Math.max(0,1-e/60);}
  else{if(d>L0)continue;p=at(d);tx=p[2];ty=p[3];x=p[0]-ty*off;y=p[1]+tx*off;}
  if(a<=0)continue;var al=a*(.12+.6*j4*j4)*(.7+.3*Math.sin(t*.05+k*2.1)),col=k%3?[214,236,255]:(k%7?[169,188,235]:[255,226,170]);
  if(sp>1.25){c.strokeStyle=rgba(col,al*.7);c.lineWidth=.7+j3*.6;c.beginPath();c.moveTo(x-tx*sp*4,y-ty*sp*4);c.lineTo(x,y);c.stroke();}   /* les plus rapides laissent un fil */
  c.fillStyle=rgba(col,al);c.beginPath();c.arc(x,y,.35+j3*j3*2.1,0,6.2832);c.fill();
  if(j3>.93){c.fillStyle=rgba(col,al*.18);c.beginPath();c.arc(x,y,4+j3*3,0,6.2832);c.fill();}}   /* quelques grains plus gros portent un halo */
 c.restore();}
/* ══ R139 — TOURBILLON ══ des filets d'air courbes tournent autour de l'œil (v=[cx,cy,R,sens]) : la colonne d'air devient cyclone. */
function vortex(c,v){var t=now(),cx=v[0],cy=v[1],R=v[2],sg=v[3]||1,i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.strokeStyle=rgba([168,200,232],.07);c.lineWidth=R*.5;c.beginPath();c.arc(cx,cy,R*.72,0,6.2832);c.stroke();
 for(k=0;k<26;k++){var h=Math.sin(k*12.9898)*43758.5453,j=h-Math.floor(h),r=R*(.3+.68*j),sp=.012+.02*(1-j),a0=sg*t*sp+k*2.39996,len=.5+.7*j;
  c.strokeStyle=rgba(k%4?[168,200,232]:[214,236,255],.16+.3*j);c.lineWidth=.8+1.4*j;c.beginPath();
  if(sg>0)c.arc(cx,cy,r,a0,a0+len);else c.arc(cx,cy,r,-a0-len,-a0);c.stroke();
  var ae=sg>0?a0+len:-a0-len,ex=cx+r*Math.cos(ae),ey=cy+r*Math.sin(ae);c.fillStyle=rgba([234,246,255],.35+.4*j);c.beginPath();c.arc(ex,ey,1+j*1.2,0,6.2832);c.fill();}
 c.restore();}
/* ══ R140 — COURANT ASCENDANT ══ u=[x,y,w,h] : des filets d'air ondulent et montent, plus denses au cœur, sans cadre. */
function updraft(c,u){var t=now(),x0=u[0],y0=u[1],W=u[2],H=u[3],k,s;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 var gr=c.createLinearGradient(x0,0,x0+W,0);gr.addColorStop(0,rgba([168,200,232],0));gr.addColorStop(.5,rgba([168,200,232],.11));gr.addColorStop(1,rgba([168,200,232],0));
 c.fillStyle=gr;c.fillRect(x0,y0,W,H);
 for(k=0;k<18;k++){var h=Math.sin(k*12.9898)*43758.5453,j=h-Math.floor(h),fx=x0+W*(k+.5)/18,edge=Math.sin(Math.PI*(k+.5)/18),sp=1.1+1.6*j,L=40+60*j,ph=(t*sp+j*H*3)%(H+L);
  for(s=0;s<2;s++){var yb=y0+H-((ph+s*(H+L)/2)%(H+L)),i;c.strokeStyle=rgba(k%3?[168,200,232]:[214,236,255],(.18+.3*j)*edge);c.lineWidth=.9+1.2*j;c.beginPath();
   for(i=0;i<=8;i++){var yy=yb+L*i/8;if(yy<y0||yy>y0+H)continue;var xx=fx+Math.sin(yy*.035+t*.03+k)*(3+4*j);if(i===0||yy-L/8<y0)c.moveTo(xx,yy);else c.lineTo(xx,yy);}c.stroke();}}
 for(k=0;k<30;k++){var h2=Math.sin(k*78.233)*12543.17,q=h2-Math.floor(h2),px=x0+W*q,py=y0+H-((t*(1.4+q*2)+q*H*5)%H),ed=Math.sin(Math.PI*q);
  c.fillStyle=rgba([234,246,255],.18+.3*q*ed);c.beginPath();c.arc(px+Math.sin(t*.04+k)*3,py,.6+q*1.1,0,6.2832);c.fill();}
 c.restore();}
/* ══ R140 — BIELLE À COULISSE ══ m.ck=[dy] : un disque tourne sous la pièce, son maneton glisse dans un coulisseau horizontal
   relié à la pièce par une tige : le mouvement sinusoïdal du moteur devient visible et exact. */
function yoke(c,m){var q=S.t*m.spd+(m.ph||0),s=m.seg,am=m.amp,o=Math.sin(q)*am,G=[224,178,76],Wc=[255,236,190],
 mx=(s[0]+s[2])/2,my=(s[1]+s[3])/2+o,cx=mx,cy=(s[1]+s[3])/2+(m.ck[0]||am+26),px=cx+Math.cos(q)*am,py=cy+Math.sin(q)*am;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.strokeStyle=rgba(G,.22);c.lineWidth=1;c.beginPath();c.arc(cx,cy,am,0,6.2832);c.stroke();          /* trajectoire du maneton */
 c.strokeStyle=rgba(G,.5);c.lineWidth=1.2;for(var k=0;k<3;k++){var a=q+k*2.0944;c.beginPath();c.moveTo(cx,cy);c.lineTo(cx+Math.cos(a)*am*.86,cy+Math.sin(a)*am*.86);c.stroke();}   /* rayons du disque */
 c.fillStyle=rgba(G,.5);c.beginPath();c.arc(cx,cy,2.6,0,6.2832);c.fill();
 c.strokeStyle=rgba(G,.55);c.lineWidth=2.2;c.beginPath();c.moveTo(cx-am-5,py);c.lineTo(cx+am+5,py);c.stroke();   /* coulisseau */
 c.strokeStyle=rgba(Wc,.35);c.lineWidth=1.4;c.beginPath();c.moveTo(mx,py);c.lineTo(mx,my+3);c.stroke();          /* tige */
 c.fillStyle=rgba(Wc,.85);c.shadowColor=rgba(G,.9);c.shadowBlur=8;c.beginPath();c.arc(px,py,3,0,6.2832);c.fill();   /* maneton */
 c.restore();}
/* ══ R140 — BALANCIER ══ p=[x,y,longueur,vitesse,amplitude(rad),phase] : le pendule bat la mesure de l'échappement ;
   l'ancre bascule avec lui et ses deux palettes répondent à celles qui ouvrent et ferment les paliers. */
function pendulum(c,p){var q=S.t*p[3]+(p[5]||0),th=p[4]*Math.sin(q),G=[224,178,76],Wc=[255,236,190],x=p[0],y=p[1],Lp=p[2],
 bx=x+Math.sin(th)*Lp,by=y+Math.cos(th)*Lp;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 c.strokeStyle=rgba(G,.16);c.lineWidth=1;c.beginPath();c.arc(x,y,Lp,Math.PI/2-p[4],Math.PI/2+p[4]);c.stroke();   /* arc de battement */
 c.strokeStyle=rgba(Wc,.55);c.lineWidth=1.6;c.beginPath();c.moveTo(x,y);c.lineTo(bx,by);c.stroke();
 var ax=Math.sin(th+.9)*26,ay=Math.cos(th+.9)*26,ax2=Math.sin(th-.9)*26,ay2=Math.cos(th-.9)*26;   /* ancre */
 c.strokeStyle=rgba(G,.75);c.lineWidth=2.4;c.beginPath();c.moveTo(x+ax,y+ay);c.quadraticCurveTo(x,y-8,x+ax2,y+ay2);c.stroke();
 c.fillStyle=rgba(G,.8);[[ax,ay],[ax2,ay2]].forEach(function(e){c.beginPath();c.arc(x+e[0],y+e[1],2.6,0,6.2832);c.fill();});
 c.fillStyle=rgba(Wc,.9);c.beginPath();c.arc(x,y,3,0,6.2832);c.fill();
 var gr=c.createRadialGradient(bx,by,1,bx,by,13);gr.addColorStop(0,rgba(Wc,.9));gr.addColorStop(.5,rgba(G,.55));gr.addColorStop(1,rgba(G,0));
 c.fillStyle=gr;c.beginPath();c.arc(bx,by,13,0,6.2832);c.fill();
 if(p[6]){var rb=p[7]||12;c.strokeStyle=rgba(Wc,.85);c.lineWidth=1.6;c.beginPath();c.arc(bx,by,rb,0,6.2832);c.stroke();   /* R161 : masse active — anneau plein, reflet */
  c.fillStyle=rgba(G,.35);c.beginPath();c.arc(bx,by,rb-1,0,6.2832);c.fill();c.fillStyle=rgba(Wc,.7);c.beginPath();c.arc(bx-rb*.3,by-rb*.35,rb*.28,0,6.2832);c.fill();}
 c.restore();}
/* ══ R142 — PUITS DE GRAVITÉ ══ w=[x,y,m,r] : la toile de l'espace-temps se creuse vers la masse (grille déformée, courbes de
   niveau qui respirent) ; plus on approche, plus les mailles plongent. Violet du monde Gravité. */
function well(c,w){var t=now(),x0=w[0],y0=w[1],m=w[2],V=[140,123,255],Rv=190,st=20,i,j;
 function dp(x,y){var dx=x-x0,dy=y-y0,d=Math.hypot(dx,dy)||1,k=Math.min(.55,m/(d*d+4200)*26);return [x-dx*k,y-dy*k,d];}
 c.save();c.lineWidth=.8;
 for(var pass=0;pass<2;pass++)for(i=-Rv;i<=Rv;i+=st){c.beginPath();var first=true;
  for(j=-Rv;j<=Rv;j+=6){var px=pass?x0+j:x0+i,py=pass?y0+i:y0+j,d0=Math.hypot(px-x0,py-y0);if(d0>Rv){first=true;continue;}
   var q=dp(px,py);if(first){c.moveTo(q[0],q[1]);first=false;}else c.lineTo(q[0],q[1]);}
  c.strokeStyle=rgba(V,.34);c.stroke();}
 for(i=1;i<=4;i++){var r=w[3]+i*26+Math.sin(t*.03-i)*2;c.strokeStyle=rgba(V,.22-.04*i);c.lineWidth=1;c.beginPath();c.arc(x0,y0,r*.8,0,6.2832);c.stroke();}   /* niveaux d'énergie */
 var g=c.createRadialGradient(x0,y0,2,x0,y0,w[3]*1.4);g.addColorStop(0,'rgba(255,255,255,.75)');g.addColorStop(.35,rgba(V,.55));g.addColorStop(1,rgba(V,0));
 c.globalCompositeOperation='lighter';c.fillStyle=g;c.beginPath();c.arc(x0,y0,w[3]*1.4,0,6.2832);c.fill();c.restore();}
/* ══ R142 — ZONE À SON PROPRE BAS (Escher, « Relativité ») ══ z=[x,y,w,h,gx,gy,1] : des lignes d'horizon perpendiculaires à
   la pesanteur locale glissent lentement vers son « bas », et une flèche de fil à plomb l'indique. */
function gzone(c,z){var t=now(),V=[140,123,255],gx=z[4],gy=z[5],L=Math.hypot(gx,gy)||1,ux=gx/L,uy=gy/L,k;
 c.save();c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.fillStyle=rgba(V,.13);c.fillRect(z[0],z[1],z[2],z[3]);
 var eg=c.createLinearGradient(z[0]+z[2]/2-ux*z[2]/2,z[1]+z[3]/2-uy*z[3]/2,z[0]+z[2]/2+ux*z[2]/2,z[1]+z[3]/2+uy*z[3]/2);eg.addColorStop(0,rgba(V,0));eg.addColorStop(1,rgba(V,.22));c.fillStyle=eg;c.fillRect(z[0],z[1],z[2],z[3]);   /* le « bas » local s'éclaire */
 var span=Math.abs(ux)*z[2]+Math.abs(uy)*z[3],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,sp=22;
 for(k=-span/2-sp;k<span/2+sp;k+=sp){var o=k+((t*.25)%sp),px=cx+ux*o,py=cy+uy*o;c.strokeStyle=rgba([196,186,255],.32+.25*Math.cos(o/span*Math.PI));c.lineWidth=1.3;
  c.beginPath();c.moveTo(px-uy*400,py+ux*400);c.lineTo(px+uy*400,py-ux*400);c.stroke();}
 c.restore();c.save();c.strokeStyle=rgba([196,186,255],.55);c.lineWidth=1.4;c.setLineDash([6,5]);c.lineDashOffset=-t*.3;c.strokeRect(z[0]+.7,z[1]+.7,z[2]-1.4,z[3]-1.4);c.setLineDash([]);var ax=cx-ux*22,ay=cy-uy*22,bx=cx+ux*22,by=cy+uy*22;c.strokeStyle=rgba([214,206,255],.85);c.lineWidth=2;c.lineCap='round';   /* fil à plomb */
 c.beginPath();c.moveTo(ax,ay);c.lineTo(bx,by);c.moveTo(bx-ux*6-uy*5,by-uy*6+ux*5);c.lineTo(bx,by);c.lineTo(bx-ux*6+uy*5,by-uy*6-ux*5);c.stroke();
 c.fillStyle=rgba(V,.7);c.beginPath();c.arc(bx+ux*3,by+uy*3,2.6,0,6.2832);c.fill();c.restore();}
/* ══ R143 — CHAMP MAGNÉTIQUE UNIFORME ══ z=[x,y,w,h,B] : la notation des physiciens — ⊙ (le champ sort de l'écran, B>0) ou ⊗
   (il y entre) — en trame régulière qui respire ; une onde de précession parcourt la trame. Rose du monde Magnétisme. */
function bfield(c,z){var t=now(),P=[255,111,181],sp=26,i,j,nx=Math.floor(z[2]/sp),ny=Math.floor(z[3]/sp),ox=z[0]+(z[2]-nx*sp)/2+sp/2,oy=z[1]+(z[3]-ny*sp)/2+sp/2;
 if(z[6]==='atom'){   /* R156 : la chambre de l'apothéose — un atome : halo, orbitales qui tournent, noyau ; pas de grille */
  var ax=z[0]+z[2]/2,ay=z[1]+z[3]/2,Rm=Math.max(z[2],z[3])*.55,V=[178,130,255],Cy=[90,220,255];c.save();
  var g0=c.createRadialGradient(ax,ay,0,ax,ay,Rm);g0.addColorStop(0,rgba(V,.16));g0.addColorStop(.6,rgba(Cy,.05));g0.addColorStop(1,rgba(V,0));c.fillStyle=g0;c.fillRect(z[0]-20,z[1]-20,z[2]+40,z[3]+40);
  c.globalCompositeOperation='lighter';for(i=0;i<3;i++){var ro=t*.004*(i%2?-1:1)+i*1.047;c.strokeStyle=rgba(i%2?Cy:V,.22);c.lineWidth=1;c.setLineDash([2,6]);c.lineDashOffset=-t*.3;c.beginPath();c.ellipse(ax,ay,Rm*.78,Rm*.26,ro,0,6.2832);c.stroke();c.setLineDash([]);
   var u=t*.03*(i%2?-1:1)+i*2.1,ex=Math.cos(u)*Rm*.78,ey=Math.sin(u)*Rm*.26,px=ax+ex*Math.cos(ro)-ey*Math.sin(ro),py=ay+ex*Math.sin(ro)+ey*Math.cos(ro);c.fillStyle=rgba([255,255,255],.7);c.beginPath();c.arc(px,py,1.5,0,6.2832);c.fill();}
  for(i=0;i<36;i++){var a1=i*2.39996,rr=Math.sqrt((i+.5)/36)*10,pu=.6+.4*Math.sin(t*.05+i);c.fillStyle=rgba(i%3?[255,206,110]:[255,240,220],.55*pu);c.fillRect(ax+Math.cos(a1+t*.01)*rr-.8,ay+Math.sin(a1+t*.01)*rr-.8,1.6,1.6);}
  var g1=c.createRadialGradient(ax,ay,0,ax,ay,18);g1.addColorStop(0,rgba([255,236,200],.35));g1.addColorStop(1,rgba([255,206,110],0));c.fillStyle=g1;c.beginPath();c.arc(ax,ay,18,0,6.2832);c.fill();
  c.restore();return;}
 c.save();
 /* R150 : la zone se lit — voile teinté qui respire, bande de lumière qui la balaie, liseré en pointillé et coins marqués */
 var br=.5+.5*Math.sin(t*.03),gf=c.createLinearGradient(z[0],z[1],z[0],z[1]+z[3]);gf.addColorStop(0,rgba(P,.08+.03*br));gf.addColorStop(.5,rgba(P,.14+.04*br));gf.addColorStop(1,rgba(P,.08+.03*br));
 c.fillStyle=gf;c.fillRect(z[0],z[1],z[2],z[3]);
 var sw=((t*.6)%(z[2]+z[3]+120))-60;c.save();c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.globalCompositeOperation='lighter';
 var gs=c.createLinearGradient(z[0]+sw-40,z[1],z[0]+sw+40,z[1]+40);gs.addColorStop(0,rgba(P,0));gs.addColorStop(.5,rgba(P,.12));gs.addColorStop(1,rgba(P,0));c.fillStyle=gs;c.fillRect(z[0],z[1],z[2],z[3]);c.restore();
 c.strokeStyle=rgba(P,.45+.2*br);c.lineWidth=1.2;c.setLineDash([6,5]);c.lineDashOffset=-t*.3;c.strokeRect(z[0]+1,z[1]+1,z[2]-2,z[3]-2);c.setLineDash([]);
 c.strokeStyle=rgba([255,200,230],.8);c.lineWidth=2;var cc=12,cs=[[z[0],z[1],1,1],[z[0]+z[2],z[1],-1,1],[z[0],z[1]+z[3],1,-1],[z[0]+z[2],z[1]+z[3],-1,-1]];
 for(i=0;i<4;i++){var q=cs[i];c.beginPath();c.moveTo(q[0]+q[2]*cc,q[1]+q[3]*1);c.lineTo(q[0]+q[2]*1,q[1]+q[3]*1);c.lineTo(q[0]+q[2]*1,q[1]+q[3]*cc);c.stroke();}
 c.lineWidth=1;
 for(i=0;i<nx;i++)for(j=0;j<ny;j++){var x=ox+i*sp,y=oy+j*sp,e=Math.min(i+1,nx-i,j+1,ny-j),fade=Math.min(1,e/1.6),w=.5+.5*Math.sin(t*.04-(i+j)*.5),a=(.3+.32*w)*fade,r=3.6+.9*w;
  c.strokeStyle=rgba(P,a);c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
  if(z[4]>0){c.fillStyle=rgba(P,a*1.6);c.beginPath();c.arc(x,y,1.1,0,6.2832);c.fill();}
  else{c.beginPath();c.moveTo(x-r*.7,y-r*.7);c.lineTo(x+r*.7,y+r*.7);c.moveTo(x+r*.7,y-r*.7);c.lineTo(x-r*.7,y+r*.7);c.stroke();}}
 c.restore();}
/* ══ R143 — FENTE ACCÉLÉRATRICE (cyclotron) ══ z=[x,y,w,h,a] : une tension alternative bat entre les deux « D » —
   des éclairs fins montent et descendent dans la fente, au rythme de la radiofréquence. */
/* R147 — BOBINE (canon de Gauss, monde Magnétisme) : spires de cuivre-violet vues de biais autour de l'axe ; au passage de la
   particule, la bobine s'allume (cyan), ses lignes de champ se referment en boucles et une flèche pousse vers l'avant. */
function coil(c,co,age){var t=now(),V=[168,120,255],Cy=[90,220,255],Wc=[236,248,255],n=Math.hypot(co[2],co[3])||1,ax=co[2]/n,ay=co[3]/n,px=-ay,py=ax,R=15,on=age<22?1-age/22:0,k,i;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 /* lignes de champ : boucles qui sortent d'un bout et rentrent par l'autre */
 for(k=1;k<=3;k++){var lw=R*(1+k*.55),lh=8+k*7,al=(.05+.22*on)*(1-k*.22);c.strokeStyle=rgba(on>.05?Cy:V,al);c.lineWidth=.7;
  for(var sd=-1;sd<=1;sd+=2){c.beginPath();for(i=0;i<=24;i++){var u=i/24*Math.PI,xa=Math.cos(u)*lh,xp=sd*(R*.6+Math.sin(u)*lw*.55);
    var X=co[0]+ax*xa+px*xp,Y=co[1]+ay*xa+py*xp;if(i)c.lineTo(X,Y);else c.moveTo(X,Y);}c.stroke();}}
 /* spires */
 for(k=-3;k<=3;k++){var o=k*2.6,cx=co[0]+ax*o,cy=co[1]+ay*o,ph=t*.05+k;
  c.strokeStyle=rgba(on>.05?Wc:V,.22+.5*on);c.lineWidth=on>.05?1.3:.9;c.beginPath();
  c.ellipse(cx,cy,R,4.2,Math.atan2(py,px),0,6.2832);c.stroke();}
 c.strokeStyle=rgba(V,.16+.3*on);c.lineWidth=7;c.beginPath();c.ellipse(co[0],co[1],R+1,6,Math.atan2(py,px),0,6.2832);c.stroke();
 /* bornes et courant qui circule */
 for(k=0;k<2;k++){var sg=k?1:-1,bx=co[0]+px*R*sg,by=co[1]+py*R*sg,g=c.createRadialGradient(bx,by,0,bx,by,5+on*6);g.addColorStop(0,rgba(on>.05?Cy:V,.8));g.addColorStop(1,rgba(V,0));c.fillStyle=g;c.beginPath();c.arc(bx,by,5+on*6,0,6.2832);c.fill();}
 var u2=(t*.12)%6.2832;c.fillStyle=rgba(Wc,.35+.6*on);c.beginPath();c.arc(co[0]+px*Math.cos(u2)*R+ax*Math.sin(u2)*1.5,co[1]+py*Math.cos(u2)*R+ay*Math.sin(u2)*1.5,1.3,0,6.2832);c.fill();
 if(on>.05){c.strokeStyle=rgba(Cy,.8*on);c.lineWidth=1.6;var tx=co[0]+ax*18,ty=co[1]+ay*18;c.beginPath();c.moveTo(co[0]-ax*6,co[1]-ay*6);c.lineTo(tx,ty);c.moveTo(tx,ty);c.lineTo(tx-ax*5+px*3.5,ty-ay*5+py*3.5);c.moveTo(tx,ty);c.lineTo(tx-ax*5-px*3.5,ty-ay*5-py*3.5);c.stroke();}
 c.restore();}
/* R147 — SPECTROMÈTRE (Aston, 1919) : demi-cercles de référence en pointillé fin (un par vitesse possible) qui naissent de la
   fente et retombent sur la plaque ; la plaque porte une graduation et des raies lumineuses aux points de chute. */
function spectro(c,sp){var t=now(),V=[168,120,255],Cy=[90,220,255],Wc=[236,248,255],i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<sp.rs.length;i++){var r=sp.rs[i],cx=sp.x-r,ph=(t*.012+i*.7)%1;c.setLineDash([1.5,5]);c.lineDashOffset=-t*.3;c.strokeStyle=rgba(i===sp.hi?Cy:Wc,i===sp.hi?.5:.32);c.lineWidth=1;
  c.beginPath();c.arc(cx,sp.y,r,Math.PI,0,false);c.stroke();c.setLineDash([]);
  var a=Math.PI+ph*Math.PI,px=cx+Math.cos(a)*r,py=sp.y+Math.sin(a)*r;c.fillStyle=rgba(Wc,.5*(1-Math.abs(ph-.5)*1.2));c.beginPath();c.arc(px,py,1.4,0,6.2832);c.fill();   /* une particule fantôme parcourt chaque orbite */
  var lx=sp.x-2*r;c.strokeStyle=rgba(i===sp.hi?Cy:V,.45);c.lineWidth=1.4;c.beginPath();c.moveTo(lx,sp.p-2);c.lineTo(lx,sp.p-9);c.stroke();}   /* raie sur la plaque */
 c.strokeStyle=rgba(Wc,.25);c.lineWidth=.7;for(k=sp.p0;k<=sp.p1;k+=8){c.beginPath();c.moveTo(k,sp.p+3);c.lineTo(k,sp.p+(k%40===0?9:6));c.stroke();}   /* graduation */
 c.restore();}
function kickgap(c,z,age){if(z[6])return kickMag(c,z,age==null?999:age);var t=now(),P=[255,111,181],Wc=[255,230,245],k;c.save();c.globalCompositeOperation='lighter';
 var ph=.5+.5*Math.sin(t*.12),g=c.createLinearGradient(z[0],0,z[0]+z[2],0);g.addColorStop(0,rgba(P,0));g.addColorStop(.5,rgba(P,.10+.18*ph));g.addColorStop(1,rgba(P,0));
 c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 for(k=0;k<5;k++){var y=z[1]+((t*1.6*(k%2?1:-1)+k*z[3]/5)%z[3]+z[3])%z[3];c.strokeStyle=rgba(Wc,.35+.4*ph);c.lineWidth=1;c.beginPath();
  c.moveTo(z[0]+2,y);c.lineTo(z[0]+z[2]/2,y+(k%2?5:-5));c.lineTo(z[0]+z[2]-2,y);c.stroke();}
 c.restore();}
/* ══ R239 — POUSSOIR MAGNÉTIQUE ══ z=[x,y,w,h,force,vmax,sens] (sens 1 = vers la droite, -1 = vers la gauche) : un aimant en fer à
   cheval enjambe la piste, pôles de part et d'autre ; au repos, des chevrons glissent lentement dans le sens de la poussée ; quand la
   particule passe, l'aimant s'allume et une onde part vers l'avant. Couleurs du Magnétisme (cyan, violet). */
function kickMag(c,z,age){var t=now(),Cy=[90,220,255],Vi=[168,120,255],Wc=[236,248,255],d=z[6]>0?1:-1,x0=z[0],y0=z[1],w=z[2],h=z[3],
 cx=x0+w/2,on=age<26?1-age/26:0,k,i;c.save();c.lineCap='round';c.lineJoin='round';
 /* fer à cheval : deux jambes de part et d'autre de la fente, arche au-dessus */
 var top=y0-14,L=x0-3,Rr=x0+w+3;c.lineWidth=5;
 var gb=c.createLinearGradient(L,0,Rr,0);gb.addColorStop(0,rgba(d>0?Vi:Cy,.55+.4*on));gb.addColorStop(1,rgba(d>0?Cy:Vi,.55+.4*on));
 c.strokeStyle=gb;c.beginPath();c.moveTo(L,y0+h*.55);c.lineTo(L,top+w/2);c.arc(cx,top+w/2,(Rr-L)/2,Math.PI,0);c.lineTo(Rr,y0+h*.55);c.stroke();
 c.lineWidth=1;c.strokeStyle=rgba(Wc,.35+.5*on);c.stroke();
 c.globalCompositeOperation='lighter';
 /* pôles (bouts des jambes) */
 for(k=0;k<2;k++){var px=k?Rr:L,col=(k?d>0:d<0)?Cy:Vi;c.fillStyle=rgba(col,.35+.6*on);c.beginPath();c.arc(px,y0+h*.55,3.2+2*on,0,6.2832);c.fill();}
 /* lignes de champ : arcs qui bombent vers l'avant */
 for(k=1;k<=3;k++){var bulge=d*(6+k*7)*(1+.6*on),al=(.10+.35*on)*(1-k*.2);c.strokeStyle=rgba(Cy,al);c.lineWidth=.8;
  c.beginPath();c.moveTo(cx,y0+3);c.quadraticCurveTo(cx+bulge*1.6,y0+h*.5,cx,y0+h-2);c.stroke();}
 /* chevrons qui glissent dans le sens de la poussée */
 var sp=.35+2.2*on;for(k=0;k<3;k++){var u=((t*sp*.02+k/3)%1),xx=cx+d*(u*w*1.6-w*.3),a=(1-u)*(.22+.6*on),yy=y0+h*.62;
  c.strokeStyle=rgba(Wc,a);c.lineWidth=1.6;c.beginPath();c.moveTo(xx-d*4,yy-5);c.lineTo(xx,yy);c.lineTo(xx-d*4,yy+5);c.stroke();}
 /* onde de poussée au passage */
 if(on>0){var r=6+(1-on)*34;c.strokeStyle=rgba(Cy,.55*on);c.lineWidth=2;c.beginPath();c.arc(cx,y0+h*.6,r,-Math.PI/2.4,Math.PI/2.4,false);
  if(d<0){c.beginPath();c.arc(cx,y0+h*.6,r,Math.PI-Math.PI/2.4,Math.PI+Math.PI/2.4,false);}c.stroke();}
 c.restore();}
/* ══ R144 — FAILLE ORIENTÉE ══ p=[ax,ay,bx,by,angle,1] : chaque bouche est un « corral quantique » — un anneau d'atomes où une onde
   stationnaire vibre (le microscope à effet tunnel les a photographiés) ; la sortie dit sa direction par des chevrons. Vert Faille. */
function rift(c,p){var t=now(),Gc=[92,232,168],Wc=[220,255,240],k,j;
 for(j=0;j<2;j++){var x=j?p[2]:p[0],y=j?p[3]:p[1];c.save();c.globalCompositeOperation='lighter';
  for(k=1;k<=4;k++){var r=k*4.2,a=.5+.5*Math.cos(t*.08-k*1.3);c.strokeStyle=rgba(Gc,.10+.22*a);c.lineWidth=1.2;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();}   /* onde stationnaire */
  for(k=0;k<14;k++){var an=k/14*6.2832+(j?0:t*.004),ax=x+Math.cos(an)*20,ay=y+Math.sin(an)*20;var gr=c.createRadialGradient(ax,ay,0,ax,ay,4);gr.addColorStop(0,rgba(Wc,.9));gr.addColorStop(1,rgba(Gc,0));c.fillStyle=gr;c.beginPath();c.arc(ax,ay,4,0,6.2832);c.fill();}   /* atomes du corral */
  if(j){var pa=p[4]*Math.PI/180,ux=Math.cos(pa),uy=Math.sin(pa);for(k=0;k<3;k++){var o=26+k*10+((t*.6)%10),cx=x+ux*o,cy=y+uy*o;c.strokeStyle=rgba(Gc,.6-.17*k);c.lineWidth=1.6;c.beginPath();c.moveTo(cx-ux*5-uy*5,cy-uy*5+ux*5);c.lineTo(cx,cy);c.lineTo(cx-ux*5+uy*5,cy-uy*5-ux*5);c.stroke();}}
  c.restore();}
 c.save();c.strokeStyle=rgba(Gc,.22);c.setLineDash([2,6]);c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(p[2],p[3]);c.stroke();c.restore();}
/* ══ R144 — COUTURE TORIQUE ══ w=[y0,y1] : les bords gauche et droit sont un seul et même lieu ; deux coutures identiques battent
   à l'unisson et, quand la particule passe, l'éclair part d'un bord et arrive à l'autre. */
var SEAMF=[],SEAMON=false;
function seam(c,w){if(!SEAMON&&window.BUS){SEAMON=true;BUS.on('ball.wrap',function(e){SEAMF.push({y:e.y,l:1});});}var t=now(),Gc=[92,232,168],Wc=[220,255,240],k,i;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(k=0;k<2;k++){var x=k?358.5:1.5,g=c.createLinearGradient(k?360:0,0,k?344:16,0);g.addColorStop(0,rgba(Gc,.30));g.addColorStop(1,rgba(Gc,0));c.fillStyle=g;c.fillRect(k?344:0,w[0],16,w[1]-w[0]);
  for(i=0;i<(w[1]-w[0])/18;i++){var y=w[0]+((i*18+t*.5)%(w[1]-w[0]));c.strokeStyle=rgba(Wc,.35+.25*Math.sin(i*1.7));c.lineWidth=1.4;c.beginPath();c.moveTo(x,y);c.lineTo(x+(k?-5:5),y+5);c.stroke();}}
 for(i=SEAMF.length-1;i>=0;i--){var f=SEAMF[i];for(k=0;k<2;k++){var gg=c.createRadialGradient(k?360:0,f.y,0,k?360:0,f.y,40*(1.4-f.l));gg.addColorStop(0,rgba(Wc,.7*f.l));gg.addColorStop(1,rgba(Gc,0));c.fillStyle=gg;c.beginPath();c.arc(k?360:0,f.y,40*(1.4-f.l),0,6.2832);c.fill();}f.l-=.04;if(f.l<=0)SEAMF.splice(i,1);}
 c.restore();}
/* ══ R145 — CORDE DE HARPE ══ la corde élastique est dessinée comme une corde vibrante : le fil, son reflet par rapport à la
   corde au repos (l'enveloppe d'une onde stationnaire), un frémissement en mode 2 au repos, et deux chevilles. Or rosé Filaments. */
var HITS={},HARPON=false,SNAPS=[];
/* R146 — CORDES VIBRANTES (monde 10, « les modes de vibration ») : une corde frappée chante sur le mode dont le ventre est au point
   d'impact (n = 1/(2·min(u,1-u))) ; nœuds marqués, onde stationnaire qui s'éteint. Corde entraînée : fronde (tension → détente). */
function harp(c,P,i0,i1,R0,r){
 if(!HARPON&&window.BUS){HARPON=true;BUS.on('ball.rope',function(e){if(e.r==null||!window.QP)return;var R1=QP.ropes[e.r];if(!R1)return;var A=QP.p[R1.i0],B=QP.p[R1.i1],dx=B.x-A.x,dy=B.y-A.y,l2=dx*dx+dy*dy||1,u=((e.x-A.x)*dx+(e.y-A.y)*dy)/l2;u=u<.04?.04:u>.96?.96:u;
  var n=Math.max(1,Math.min(5,Math.round(1/(2*Math.min(u,1-u)))));HITS[e.r]={t:now(),n:n,a:Math.min(9,2+e.v*.9)};});}
 var t=now(),G=[232,150,190],Wc=[255,236,244],V=[178,130,255],A=P[i0],B=P[i1],dx=B.x-A.x,dy=B.y-A.y,L2=Math.hypot(dx,dy)||1,ux=dx/L2,uy=dy/L2,i,
  h=HITS[r],age=h?t-h.t:999,amp=h&&age<150?h.a*Math.exp(-age/40):0,n=h?h.n:1,idle=Math.sin(t*.09)*1.1,ten=R0&&R0.drv&&R0.u!=null&&R0.u<R0.drv.wv?R0.u/R0.drv.wv:0;
 function pt(i,mir){var p=P[i],u=((p.x-A.x)*ux+(p.y-A.y)*uy),v=((p.x-A.x)*-uy+(p.y-A.y)*ux),f=u/L2,sh=Math.sin(Math.PI*2*f)*idle+Math.sin(Math.PI*n*f)*Math.cos(age*.55)*amp;v=(mir?-v:v)+(mir?-sh:sh);return [A.x+ux*u-uy*v,A.y+uy*u+ux*v];}
 c.save();c.lineCap='round';c.lineJoin='round';c.globalCompositeOperation='lighter';
 if(amp>.4){c.beginPath();for(i=i0;i<=i1;i++){var q=pt(i,1);if(i===i0)c.moveTo(q[0],q[1]);else c.lineTo(q[0],q[1]);}c.strokeStyle=rgba(V,.35*Math.min(1,amp/4));c.lineWidth=1.1;c.stroke();   /* enveloppe miroir : le fuseau de l'onde stationnaire */
  c.fillStyle=rgba(Wc,.8*Math.min(1,amp/3));for(var k=1;k<n;k++){var f=k/n;c.beginPath();c.arc(A.x+dx*f,A.y+dy*f,1.7,0,6.2832);c.fill();}}   /* nœuds */
 c.beginPath();for(i=i0;i<=i1;i++){var q2=pt(i,0);if(i===i0)c.moveTo(q2[0],q2[1]);else c.lineTo(q2[0],q2[1]);}
 c.strokeStyle=rgba(G,.22+ten*.3);c.lineWidth=6+ten*4;c.stroke();c.strokeStyle=rgba(Wc,.85);c.lineWidth=1.8+amp*.08;c.stroke();
 [A,B].forEach(function(p){var g=c.createRadialGradient(p.x,p.y,0,p.x,p.y,7);g.addColorStop(0,rgba(Wc,.95));g.addColorStop(1,rgba(G,0));c.fillStyle=g;c.beginPath();c.arc(p.x,p.y,7,0,6.2832);c.fill();});
 c.restore();}
/* fronde : lv.fork={tips:[[x,y],[x,y]],base:[x,y],att:[[corde,0|1],…]} — un diapason lumineux (expérience de Melde) dont les
   branches tiennent les élastiques ; l'élastique s'étire et rougit pendant la tension, éclair et onde de choc à la détente. */
function fork(c,lv,QPv){var FF=lv.fork;if(!FF||!QPv)return;if(!FF.length)FF=[FF];for(var fi=0;fi<FF.length;fi++)fork1(c,FF[fi],QPv,fi);}
function fork1(c,F,QPv,fi){var t=now(),G=[232,150,190],Wc=[255,236,244],V=[178,130,255],Ho=[255,196,150],i,
 str=QPv.ropes.filter(function(r){return F.player?(r.drv&&!r.str):r.str;});
 var R0=F.player?str[0]:str[(F.att&&F.att[0])?F.att[0][0]:0],d=R0&&R0.drv,u=R0&&R0.u!=null?R0.u:0,k=d?d.wv:1,ten=u<k?u/k:0,tp=F.tips,b=F.base,jx=(tp[0][0]+tp[1][0])/2,jy=F.j?F.j-18:Math.max(tp[0][1],tp[1][1])+46;
 if(F.player&&R0)F.att=[[0,0],[0,1]];
 if(R0){if(R0.lu!=null&&R0.lu<k&&u>=k){var mi=(R0.i0+R0.i1)>>1;SNAPS.push({t:t,x:QPv.p[F.player?mi:R0.i1].x,y:QPv.p[F.player?mi:R0.i1].y});}R0.lu=u;}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 /* diapason : manche, fourche en U, branches */
 c.strokeStyle=rgba(V,.18);c.lineWidth=9;c.beginPath();c.moveTo(b[0],b[1]);c.lineTo(jx,jy+18);c.stroke();
 for(var m=0;m<2;m++){c.strokeStyle=m?rgba(Wc,.32):rgba(V,.14);c.lineWidth=m?1.1:6;c.beginPath();c.moveTo(b[0],b[1]);c.lineTo(jx,jy+18);
  c.moveTo(tp[0][0],tp[0][1]);c.bezierCurveTo(tp[0][0],jy+8,jx-(jx-tp[0][0])*.4,jy+18,jx,jy+18);c.bezierCurveTo(jx+(tp[1][0]-jx)*.4,jy+18,tp[1][0],jy+8,tp[1][0],tp[1][1]);c.stroke();}
 /* résonance du diapason : anneaux qui partent des pointes */
 for(i=0;i<2;i++){var rr=((t*.6+i*9)%26);c.strokeStyle=rgba(V,.3*(1-rr/26));c.lineWidth=1;c.beginPath();c.arc(tp[i][0],tp[i][1],4+rr,0,6.2832);c.stroke();}
 /* élastiques : des pointes aux coins de la poche */
 if(F.player&&!R0){var pu=.35+.25*Math.sin(t*.08);c.strokeStyle=rgba(Wc,pu);c.lineWidth=1.2;c.setLineDash([3,5]);c.lineDashOffset=-t*.4;c.beginPath();c.moveTo(tp[0][0],tp[0][1]);c.quadraticCurveTo(jx,(tp[0][1]+tp[1][1])/2+34,tp[1][0],tp[1][1]);c.stroke();c.setLineDash([]);}   /* fronde vide : la poche à tendre, en pointillé */
 (F.player&&!R0?[]:(F.att||[])).forEach(function(a,ix){var R1=str[a[0]];if(!R1)return;var p=QPv.p[a[1]?R1.i1:R1.i0],q=tp[ix],len=Math.hypot(p.x-q[0],p.y-q[1]),col=[G[0]+(Ho[0]-G[0])*ten|0,G[1]+(Ho[1]-G[1])*ten|0,G[2]+(Ho[2]-G[2])*ten|0];
  var nx=-(p.y-q[1])/(len||1),ny=(p.x-q[0])/(len||1),wob=Math.sin(t*1.3)*(u>=k?4:u<.1?4*(1-u/.1):0);
  c.strokeStyle=rgba(col,.22+ten*.35);c.lineWidth=7-ten*3;c.beginPath();c.moveTo(q[0],q[1]);c.quadraticCurveTo((q[0]+p.x)/2+nx*wob,(q[1]+p.y)/2+ny*wob,p.x,p.y);c.stroke();
  c.strokeStyle=rgba(Wc,.8);c.lineWidth=1.4;c.setLineDash([2+ten*6,3]);c.lineDashOffset=-t*.6;c.stroke();c.setLineDash([]);
  var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],8);g.addColorStop(0,rgba(Wc,.95));g.addColorStop(1,rgba(V,0));c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],8,0,6.2832);c.fill();});
 /* détente : éclair et onde de choc */
 for(i=SNAPS.length-1;i>=0;i--){var sn=SNAPS[i],ag=t-sn.t;if(ag>34||ag<0){SNAPS.splice(i,1);continue;}var f=ag/34;
  c.strokeStyle=rgba(Wc,.7*(1-f));c.lineWidth=2.4*(1-f)+.5;c.beginPath();c.arc(sn.x,sn.y,8+f*70,0,6.2832);c.stroke();
  c.strokeStyle=rgba(G,.45*(1-f));c.lineWidth=1;c.beginPath();c.arc(sn.x,sn.y,4+f*44,0,6.2832);c.stroke();
  if(ag<6){var g2=c.createRadialGradient(sn.x,sn.y,0,sn.x,sn.y,30);g2.addColorStop(0,rgba(Wc,.8*(1-ag/6)));g2.addColorStop(1,rgba(G,0));c.fillStyle=g2;c.beginPath();c.arc(sn.x,sn.y,30,0,6.2832);c.fill();}}
 c.restore();}
/* ══ R192 — EN-TÊTE ANIMÉ DU BILAN : l'issue se lit dans l'image, sans titre ══
   kind : 'win' | 'complete' | 'sol' | 'out' | 'spike' | 'stuck' | 'long' ; cr = [zone, noyau, maîtrise] ; t en secondes.
   win      — la particule descend en spirale dans la zone vue de biais ; ondes, gerbe, colonne de lumière ; un satellite d'or par critère.
   sol      — géodésique : l'espace se courbe (grille), le chemin le plus court s'allume, la particule le suit.
   out      — hors champ : elle franchit le bord du terrain (repères de coin) ; le bord s'illumine, elle se défait en paquet d'ondes.
   spike    — annihilation sur les pointes : éclats, deux photons dos à dos, braises.
   stuck    — puits de potentiel : oscillation amortie, niveaux d'énergie qui s'éteignent, état fondamental qui respire.
   long     — boucle sans fin : lemniscate parcourue, cadran de vingt secondes qui s'égrène. */
var RA={k:null,p:[]};
function resAnim(c,kind,t,W,H,cr){var i,k,u,x,y,cx=W/2,G=C.goal,M=C.matter,R2=C.reward,D=C.danger,V=C.boost,Wt=C.white||[241,244,246];
 if(RA.k!==kind){RA.k=kind;RA.p=[];}
 function ln(P,col,a,w){c.strokeStyle=rgba(col,a);c.lineWidth=w;c.beginPath();for(var j=0;j<P.length;j++){if(j)c.lineTo(P[j][0],P[j][1]);else c.moveTo(P[j][0],P[j][1]);}c.stroke();}
 function glow(x0,y0,r,col,a){var g=c.createRadialGradient(x0,y0,0,x0,y0,r);g.addColorStop(0,rgba(Wt,a));g.addColorStop(.3,rgba(col,a*.6));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x0,y0,r,0,6.2832);c.fill();}
 function trail(f,t0,t1,n,col,w){var P=[];for(var j=0;j<=n;j++){var tt=t0+(t1-t0)*j/n;if(tt<0)continue;P.push(f(tt));}if(P.length<2)return;for(var j2=1;j2<P.length;j2++){var a=j2/P.length;c.strokeStyle=rgba(col,a*.7);c.lineWidth=w*a;c.beginPath();c.moveTo(P[j2-1][0],P[j2-1][1]);c.lineTo(P[j2][0],P[j2][1]);c.stroke();}}
 function corners(x0,y0,x1,y1,col,a){var s=9;c.strokeStyle=rgba(col,a);c.lineWidth=1;c.beginPath();
  c.moveTo(x0,y0+s);c.lineTo(x0,y0);c.lineTo(x0+s,y0);c.moveTo(x1-s,y0);c.lineTo(x1,y0);c.lineTo(x1,y0+s);c.moveTo(x1,y1-s);c.lineTo(x1,y1);c.lineTo(x1-s,y1);c.moveTo(x0+s,y1);c.lineTo(x0,y1);c.lineTo(x0,y1-s);c.stroke();}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 if(kind==='win'||kind==='complete'){   /* R193 : capture plus forte — hélice lumineuse, éclosion, rayons, triple onde, gerbe, couronne d'orbites, constellation des critères */
  var zy=H*.66,ti=1.05,PAL=kind==='complete'?[M,V,G,R2,D,[143,227,255],[232,185,138]]:[M,G,R2,Wt],
   fall=function(tt){var v=Math.min(1,tt/ti),e=1-Math.pow(1-v,2.4),r=W*.34*(1-e),a=-2.4+e*3.6*Math.PI;return [cx+Math.cos(a)*r,(H*.06)+(zy-H*.06-8)*e+Math.sin(a)*r*.3];};
  var tb=t-ti,pulse=tb>0?Math.max(0,1-tb/.5):0,amb=tb>0?Math.min(1,tb/.8):0;
  for(i=0;i<4;i++){var rr=W*(.27-i*.06)*(1+.05*pulse),col=i===0&&amb>0?[155+100*amb*.6|0,235,75+15*amb|0]:G;c.setLineDash(i%2?[]:[2,5]);c.lineDashOffset=(i%2?1:-1)*t*16;
   c.strokeStyle=rgba(col,(.5-i*.09)+.3*pulse);c.lineWidth=(i?1.1:1.5)+pulse*1.5;c.beginPath();c.ellipse(cx,zy,rr,rr*.27,0,0,6.2832);c.stroke();}c.setLineDash([]);
  if(t<ti){trail(fall,t-.6,t,36,M,4.2);for(k=0;k<8;k++){var fp=fall(Math.max(0,t-k*.05));c.fillStyle=rgba(k%2?Wt:M,.5*(1-k/8));c.fillRect(fp[0]+Math.sin(k*3+t*9)*5,fp[1]+Math.cos(k*2+t*7)*3,1.4,1.4);}}
  if(tb>0){
   if(tb<.7)glow(cx,zy-6,W*.28*(1-Math.pow(1-tb/.7,3))+8,G,.9*(1-tb/.7));   /* éclosion */
   var ra=Math.min(1,tb/.35),rf=Math.max(0,1-(tb-.35)/1.6);if(rf>0){for(k=0;k<16;k++){var an=k/16*6.2832+t*.35,l1=12,l2=12+ra*W*(k%2?.24:.36);c.strokeStyle=rgba(k%4?G:R2,.5*rf);c.lineWidth=k%2?1:1.6;c.beginPath();c.moveTo(cx+Math.cos(an)*l1,zy-6+Math.sin(an)*l1*.55);c.lineTo(cx+Math.cos(an)*l2,zy-6+Math.sin(an)*l2*.55);c.stroke();}}
   for(i=0;i<3;i++){var q=tb*.9-i*.18;if(q>0&&q<1){c.strokeStyle=rgba(i===1?R2:i?G:Wt,.85*(1-q));c.lineWidth=2.4*(1-q)+.4;var re=W*.05+q*W*.48;c.beginPath();c.ellipse(cx,zy,re,re*.27,0,0,6.2832);c.stroke();}}
   if(!RA.p.length)for(k=0;k<90;k++){var an2=-Math.PI*(.08+.84*Math.random()),sp=50+Math.random()*120;RA.p.push({vx:Math.cos(an2)*sp,vy:Math.sin(an2)*sp,col:PAL[k%PAL.length],s:.8+Math.random()*1.3});}
   for(k=0;k<RA.p.length;k++){var pp=RA.p[k],tt2=Math.min(tb,2.2);x=cx+pp.vx*tt2;y=zy+pp.vy*tt2+70*tt2*tt2;var al=Math.max(0,1-tb/2.2);if(al>0&&y<H){c.strokeStyle=rgba(pp.col,al);c.lineWidth=pp.s;c.beginPath();c.moveTo(x,y);c.lineTo(x-pp.vx*.025,y-(pp.vy+140*tt2)*.025);c.stroke();}}
   var g2=c.createLinearGradient(0,zy,0,0);g2.addColorStop(0,rgba(G,.28*amb));g2.addColorStop(.6,rgba(G,.08*amb));g2.addColorStop(1,rgba(G,0));c.fillStyle=g2;c.beginPath();c.moveTo(cx-W*.12,zy);c.lineTo(cx-W*.035,0);c.lineTo(cx+W*.035,0);c.lineTo(cx+W*.12,zy);c.fill();
   for(k=0;k<22;k++){var yy=zy-((tb*30+k*11)%zy);c.fillStyle=rgba(k%4?G:R2,.6*(yy/zy)*amb);c.fillRect(cx-W*.06+((k*37)%(W*.12)),yy,1.3,1.3);}
   for(i=0;i<3;i++){var orr=26+i*13,oa=amb*(.35-i*.08);c.setLineDash([1,4]);c.lineDashOffset=t*(i%2?-10:10);c.strokeStyle=rgba(i?M:R2,oa);c.lineWidth=1;c.beginPath();c.ellipse(cx,zy-10,orr,orr*.42,-.25+i*.25,0,6.2832);c.stroke();}c.setLineDash([]);
   var sats=[];for(k=0;k<3;k++){var sa=tb*1.6+k*2.094,on=cr?!!cr[k]:true,sx=cx+Math.cos(sa)*34,sy=zy-12+Math.sin(sa)*12;sats.push([sx,sy,on]);}
   c.strokeStyle=rgba(R2,.35*amb);c.lineWidth=.8;c.beginPath();for(k=0;k<=3;k++){var s2=sats[k%3];if(!s2[2])continue;if(k)c.lineTo(s2[0],s2[1]);else c.moveTo(s2[0],s2[1]);}c.stroke();
   for(k=0;k<3;k++){if(sats[k][2]){glow(sats[k][0],sats[k][1],9*amb+2,k?R2:G,.95);}else{c.fillStyle=rgba(Wt,.18*amb);c.beginPath();c.arc(sats[k][0],sats[k][1],1.6,0,6.2832);c.fill();}}
   glow(cx,zy-10,30+4*Math.sin(t*2.4),G,.4*amb+.1);}
  var bp=t<ti?fall(t):[cx,zy-10+Math.sin(t*2.2)*2];c.restore();c.save();try{ball(c,bp[0],bp[1],t*.9,9*(1+.25*pulse),null);}catch(e){}c.restore();return;}
 if(kind==='sol'){var x0=W*.12,y0=H*.22,x1=W*.86,y1=H*.72;
  for(i=0;i<=8;i++){var P=[],P2=[];for(k=0;k<=24;k++){var f=k/24,gx=W*.06+f*W*.88,gy=H*.1+i*H*.1,d=Math.exp(-Math.pow((gx-cx)/(W*.25),2))*14;P.push([gx,gy+d]);var hx=W*.06+i*W*.11,hy=H*.08+f*H*.84;P2.push([hx+Math.exp(-Math.pow((hy-H*.55)/(H*.3),2))*(cx-hx)*.12,hy]);}ln(P,V,.12,1);ln(P2,V,.12,1);}
  var geo=function(f){return [x0+(x1-x0)*f,y0+(y1-y0)*f*f+Math.sin(f*Math.PI)*(-10)];},lit=Math.min(1,t/1.2),GP=[];for(k=0;k<=40*lit;k++)GP.push(geo(k/40));ln(GP,M,.25,6);ln(GP,Wt,.9,1.2);
  c.strokeStyle=rgba(G,.8);c.lineWidth=1.3;c.beginPath();c.ellipse(x1,y1+8,16,4.5,0,0,6.2832);c.stroke();glow(x0,y0,10,M,.5);
  var pf=((t*.45)%1.2);if(pf<=1){var bq=geo(pf);trail(function(tt){return geo(Math.max(0,tt));},pf-.25,pf,16,M,3);c.restore();c.save();try{ball(c,bq[0],bq[1],t,8,null);}catch(e){}}c.restore();return;}
 if(kind==='out'){var fx0=W*.14,fy0=H*.14,fx1=W*.6,fy1=H*.86,cyc=3.4,tc=t%cyc,cross=1.0,path=function(tt){var f=tt/cross;return [W*.28+(fx1-W*.28)*f+ (tt>cross?(tt-cross)*W*.12:0),H*.62-Math.sin(Math.min(f,1.6)*1.4)*H*.32+(tt>cross?(tt-cross)*8:0)];};
  corners(fx0,fy0,fx1,fy1,M,.6);c.setLineDash([2,6]);c.strokeStyle=rgba(M,.18);c.lineWidth=1;c.strokeRect(fx0,fy0,fx1-fx0,fy1-fy0);c.setLineDash([]);
  var ce=path(cross);if(tc>cross){var fl=Math.max(0,1-(tc-cross)/1.1);c.strokeStyle=rgba(Wt,.9*fl);c.lineWidth=2;c.beginPath();c.moveTo(fx1,ce[1]-22*fl-6);c.lineTo(fx1,ce[1]+22*fl+6);c.stroke();glow(fx1,ce[1],26*fl+4,D,.45*fl);
   for(k=0;k<3;k++){var ar=Math.min(1,(tc-cross)*1.4)-k*.15;if(ar>0){c.strokeStyle=rgba(V,.55*(1-ar));c.lineWidth=1;c.beginPath();var pq=path(Math.min(tc,cross+1.6));c.arc(pq[0],pq[1],6+ar*W*.16,-1.1,1.1);c.stroke();}}
   var pq2=path(Math.min(tc,cross+1.6)),spread=Math.min(1,(tc-cross)/1.6);for(k=0;k<34;k++){var a3=k*2.39996,r3=Math.sqrt(k/34)*(4+spread*26);c.fillStyle=rgba(k%3?V:M,.8*(1-spread*.85));c.fillRect(pq2[0]+Math.cos(a3)*r3,pq2[1]+Math.sin(a3)*r3*.7,1.3,1.3);}}
  if(tc<cross+.35){trail(path,tc-.5,Math.min(tc,cross+.35),22,M,3);var bq2=path(Math.min(tc,cross+.35));c.restore();c.save();c.globalAlpha=tc<cross?1:Math.max(0,1-(tc-cross)/.35);try{ball(c,bq2[0],bq2[1],t,8,null);}catch(e){}}c.restore();return;}
 if(kind==='spike'){var sy0=H*.8,cyc2=3.2,tc2=t%cyc2,hit=.75,SP=[];for(k=0;k<=18;k++)SP.push([W*.18+k*W*.64/18,sy0-(k%2?10:0)]);ln(SP,D,.35,5);ln(SP,[255,170,170],.9,1.2);
  if(tc2<hit){var fy=H*.08+(sy0-12-H*.08)*Math.pow(tc2/hit,2);trail(function(tt){return [cx,H*.08+(sy0-12-H*.08)*Math.pow(Math.max(0,tt)/hit,2)];},tc2-.25,tc2,14,M,3);c.restore();c.save();try{ball(c,cx,fy,t,8,null);}catch(e){}c.restore();return;}
  var tb2=tc2-hit;if(tb2<.5)glow(cx,sy0-10,40*(1-tb2*2)+6,D,.8*(1-tb2*2));
  var ph=Math.min(1,tb2/.5);c.strokeStyle=rgba(Wt,.85*(1-ph));c.lineWidth=1.4;c.beginPath();c.moveTo(cx-6-ph*W*.4,sy0-12);c.lineTo(cx-6,sy0-12);c.moveTo(cx+6,sy0-12);c.lineTo(cx+6+ph*W*.4,sy0-12);c.stroke();
  for(k=0;k<22;k++){var a4=-Math.PI*(.05+.9*((k*.618)%1)),v4=50+(k%5)*22,xx=cx+Math.cos(a4)*v4*tb2,yy2=sy0-12+Math.sin(a4)*v4*tb2+70*tb2*tb2,al4=Math.max(0,1-tb2/1.4);if(al4>0){c.fillStyle=rgba(k%2?D:[255,170,60],al4);c.fillRect(xx-1,yy2-1,2,2);}}
  for(k=0;k<9;k++){var ex=W*.22+k*W*.07,ea=.25+.25*Math.sin(t*3+k);c.fillStyle=rgba([255,140,60],ea*Math.min(1,tb2*2));c.fillRect(ex,sy0-2-((t*10+k*7)%14),1.2,1.2);}c.restore();return;}
 if(kind==='stuck'){var wy=H*.82,A0=W*.3,cyc3=4.2,tc3=t%cyc3,amp=A0*Math.exp(-tc3/1.1),curve=function(xx){var f=(xx-cx)/(W*.32);return wy-H*.6*f*f;},WP=[];for(k=0;k<=40;k++){var xx2=cx-W*.32+k*W*.64/40;WP.push([xx2,curve(xx2)]);}
  ln(WP,R2,.25,5);ln(WP,[255,230,170],.85,1.2);
  for(k=1;k<=3;k++){var lv=wy-H*.6*Math.pow(k*.28,2),on2=amp/A0>k*.28?1:.15,hw=k*.28*W*.32;c.setLineDash([3,4]);c.strokeStyle=rgba(R2,.5*on2);c.lineWidth=1;c.beginPath();c.moveTo(cx-hw,lv);c.lineTo(cx+hw,lv);c.stroke();c.setLineDash([]);}
  var bx2=cx+amp*Math.cos(tc3*4.6),by2=curve(bx2)-9;if(amp<6){var br=(Math.sin(t*2)+1)/2;c.strokeStyle=rgba(R2,.35+.3*br);c.lineWidth=1;c.beginPath();c.ellipse(cx,wy-4,14+br*6,(14+br*6)*.3,0,0,6.2832);c.stroke();}
  trail(function(tt){var a5=A0*Math.exp(-Math.max(0,tt)/1.1),xx3=cx+a5*Math.cos(Math.max(0,tt)*4.6);return [xx3,curve(xx3)-9];},tc3-.3,tc3,14,R2,3);c.restore();c.save();try{ball(c,bx2,by2,t,8,null);}catch(e){}c.restore();return;}
 if(kind==='long'){var lc=function(tt){var a6=tt*1.9;return [cx+W*.26*Math.sin(a6),H*.48+H*.26*Math.sin(a6)*Math.cos(a6)];},LP=[];for(k=0;k<=80;k++)LP.push(lc(k/80*3.3069));ln(LP,V,.18,1);
  for(k=0;k<20;k++){var a7=-Math.PI/2+k/20*6.2832,on3=k<=Math.floor((t*2)%21);c.strokeStyle=rgba(on3?V:Wt,on3?.8:.15);c.lineWidth=1.2;c.beginPath();c.moveTo(cx+Math.cos(a7)*H*.44,H*.48+Math.sin(a7)*H*.44);c.lineTo(cx+Math.cos(a7)*H*.4,H*.48+Math.sin(a7)*H*.4);c.stroke();}
  trail(lc,t-.6,t,30,V,3);var lb=lc(t);c.restore();c.save();try{ball(c,lb[0],lb[1],t,8,null);}catch(e){}c.restore();return;}
 c.restore();}
/* R206 : décors du jeu réutilisés par l'épilogue (hero.js) — mêmes dessins, mêmes animations */
function mechList(c,list){var o=D.mech;D.mech=list;try{mechDeco(c);}finally{D.mech=o;}}
/* ══ R310 — PORTAIL UNIFIÉ ══ p=[ax,ay,bx,by,angle,flag] : une seule grammaire pour toutes les failles. L'ENTRÉE (bleu d'origine) aspire : cercles qui se
   contractent en accélérant, filets courbes et grains qui convergent de partout. La SORTIE (vert Faille) souffle : jet dans l'axe (angle si faille orientée,
   sinon rayonnement tout autour), grains qui ralentissent en s'écartant, filets qui ondulent, ondes étirées. Même langage que la poussière des machines. */
function hsh(k,s){var h=Math.sin(k*s)*43758.5453;return h-Math.floor(h);}
function pgrain(c,x,y,r,col,al,sq){if(al<=.01)return;c.fillStyle=rgba(col,al);if(sq){var s=Math.max(1,Math.round(r*2));c.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,s,s);}else{c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();}}
function portalIn(c,x,y,R,t){var BL=[77,215,255],BP=[200,238,255],i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 var cg=c.createRadialGradient(x,y,0,x,y,R*1.4);cg.addColorStop(0,rgba(BL,.13));cg.addColorStop(1,rgba(BL,0));c.fillStyle=cg;c.beginPath();c.arc(x,y,R*1.4,0,6.2832);c.fill();
 for(k=0;k<14;k++){var j=hsh(k,78.233),th=k/14*6.2832+hsh(k,39.425)*.5,sp=.0009+.0012*hsh(k,39.425),L=26+44*hsh(k,93.989),ph=((t*sp+hsh(k,12.9898))%1);
  c.strokeStyle=rgba(k%3?BL:BP,.16+.3*hsh(k,93.989));c.lineWidth=.8+1.2*hsh(k,93.989);c.beginPath();
  for(i=0;i<=8;i++){var u=i/8,d=R*2.0*(1-ph)-u*L*.6+L*.3;if(d<3||d>R*2.1)continue;var a=th+(d/R)*.55*(j>.5?1:-1)+Math.sin(d*.09+t*.004+k)*.05,px=x+Math.cos(a)*d,py=y+Math.sin(a)*d;if(i===0||d>R*2.0)c.moveTo(px,py);else c.lineTo(px,py);}c.stroke();}
 for(i=0;i<120;i++){var j1=hsh(i,12.9898),j2=hsh(i,78.233),j3=hsh(i,39.425),j4=hsh(i,93.989),sp=.00018*(.5+j1*1.1),f=((t*sp+j2)%1+1)%1,d=R*2.2*Math.pow(1-f,1.55)+1,th=j3*6.2832+f*.9*(j1>.5?1:-1),
   al=Math.sin(Math.min(1,f*5)*1.5708)*Math.min(1,(1-f)*5)*(.2+.6*j4*j4)*(.75+.25*Math.sin(t*.03+i)),px=x+Math.cos(th)*d,py=y+Math.sin(th)*d,col=i%3?[190,236,255]:(i%7?BL:[255,236,190]);
  if(j1>.72){var f0=Math.max(0,f-.03),d0=R*2.2*Math.pow(1-f0,1.55)+1,t0=j3*6.2832+f0*.9*(j1>.5?1:-1);c.strokeStyle=rgba(col,al*.6);c.lineWidth=.6+j3*.5;c.beginPath();c.moveTo(x+Math.cos(t0)*d0,y+Math.sin(t0)*d0);c.lineTo(px,py);c.stroke();}
  pgrain(c,px,py,.4+j3*j3*1.9,col,al,j3<.1);
  if(j3>.93){c.fillStyle=rgba(col,al*.2);c.beginPath();c.arc(px,py,4+j3*3,0,6.2832);c.fill();}}
 for(k=0;k<2;k++){var f2=((t*.00042+k/2)%1),r2=R*.26+R*.7*Math.pow(1-f2,1.35);c.strokeStyle=rgba(BL,.55*Math.sin(f2*3.1416));c.lineWidth=1.2;c.beginPath();c.arc(x,y,r2,0,6.2832);c.stroke();}
 var g=c.createRadialGradient(x,y,0,x,y,R*.4);g.addColorStop(0,'rgba(240,250,255,.85)');g.addColorStop(.4,rgba(BL,.38));g.addColorStop(1,rgba(BL,0));c.fillStyle=g;c.beginPath();c.arc(x,y,R*.4,0,6.2832);c.fill();
 c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=.8;c.beginPath();c.arc(x,y,R*.22,0,6.2832);c.stroke();c.restore();}
function portalOut(c,x,y,R,t,ang){var GR=[92,232,168],WH=[234,246,255],dir=ang!=null,ux=dir?Math.cos(ang):1,uy=dir?Math.sin(ang):0,nx=-uy,ny=ux,i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 var cx0=x+ux*R*.9,cy0=y+uy*R*.9,cg=c.createRadialGradient(cx0,cy0,0,cx0,cy0,R*1.5);cg.addColorStop(0,rgba(GR,.13));cg.addColorStop(1,rgba(GR,0));c.fillStyle=cg;c.beginPath();c.arc(cx0,cy0,R*1.5,0,6.2832);c.fill();
 for(k=0;k<9;k++){var j=hsh(k,78.233),lat=(j-.5)*2,sp=.0009+.0012*hsh(k,39.425),L=26+44*hsh(k,93.989),ph=((t*sp+hsh(k,12.9898))%1),rad=hsh(k,53.7)*6.2832;
  c.strokeStyle=rgba(k%3?GR:WH,.14+.30*(dir?1-Math.abs(lat):.6));c.lineWidth=.8+1.2*(dir?1-Math.abs(lat):.6);c.beginPath();
  for(i=0;i<=8;i++){var u=i/8,d=ph*R*2.1+u*L-L*.3;if(d<4)continue;var px,py;
   if(dir){var spread=lat*(6+d*.26),und=Math.sin(d*.09+t*.004+k)*2.4*(d/R);px=x+ux*d+nx*(spread+und);py=y+uy*d+ny*(spread+und);}
   else{var a=rad+Math.sin(d*.09+t*.004+k)*.06;px=x+Math.cos(a)*d;py=y+Math.sin(a)*d;}
   if(i===0||d-L/8<4)c.moveTo(px,py);else c.lineTo(px,py);}c.stroke();}
 for(i=0;i<130;i++){var j1=hsh(i,12.9898),j2=hsh(i,78.233),j3=hsh(i,39.425),j4=hsh(i,93.989),sp=.00018*(.5+j1*1.1),f=((t*sp+j2)%1+1)%1,d=R*2.2*(1-Math.pow(1-f,1.8)),
   al=Math.pow(1-f,.8)*Math.min(1,f*9)*(.2+.6*j4*j4)*(.75+.25*Math.sin(t*.03+i)),col=i%3?[214,255,236]:(i%7?GR:[255,236,190]),px,py,tx,ty;
  if(dir){var lat=(j3-.5)*(.25+f*1.15);px=x+ux*d+nx*lat*d*.55;py=y+uy*d+ny*lat*d*.55+f*f*7*j1;tx=ux;ty=uy;}else{var a=j3*6.2832;px=x+Math.cos(a)*d;py=y+Math.sin(a)*d;tx=Math.cos(a);ty=Math.sin(a);}
  if(j1>.72){c.strokeStyle=rgba(col,al*.6);c.lineWidth=.6+j3*.5;c.beginPath();c.moveTo(px-tx*(4+j1*8)*(1-f),py-ty*(4+j1*8)*(1-f));c.lineTo(px,py);c.stroke();}
  pgrain(c,px,py,.4+j3*j3*1.9,col,al,j3<.12);
  if(j3>.93){c.fillStyle=rgba(col,al*.2);c.beginPath();c.arc(px,py,4+j3*3,0,6.2832);c.fill();}}
 for(k=0;k<3;k++){var f2=((t*.0004+k/3)%1);c.strokeStyle=rgba(GR,.5*(1-f2));c.lineWidth=1.2;c.beginPath();
  if(dir)c.ellipse(x+ux*f2*R*.7,y+uy*f2*R*.7,R*.26+f2*R*.5,(R*.26+f2*R*.5)*.7,ang,0,6.2832);else c.arc(x,y,R*.26+f2*R*.6,0,6.2832);c.stroke();}
 var g=c.createRadialGradient(x,y,0,x,y,R*.4);g.addColorStop(0,'rgba(240,255,248,.85)');g.addColorStop(.4,rgba(GR,.35));g.addColorStop(1,rgba(GR,0));c.fillStyle=g;c.beginPath();c.arc(x,y,R*.4,0,6.2832);c.fill();
 c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=.8;c.beginPath();c.arc(x,y,R*.22,0,6.2832);c.stroke();c.restore();}
function portal(c,p){var t=now()*11.7,R=42;c.save();c.strokeStyle='rgba(120,200,215,.10)';c.setLineDash([2,6]);c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(p[2],p[3]);c.stroke();c.restore();
 portalIn(c,p[0],p[1],R,t);portalOut(c,p[2],p[3],R,t,p[6]!=null?p[6]*Math.PI/180:(p[5]?p[4]*Math.PI/180:null));}
window.VX={portal:portal,spdCol:spdCol,spikes:spikes,mech:mechList,helix:helix,torusCells:torusCells,ndDust:ndDust,ndPauli:ndPauli,ferro2:ferro2,ffSoft:ffSoft,ferroMode:ferroMode,softball:softball,finale:finale,qent:qent,qgate:qgate,qsup:qsup,qdet:qdet,qtdil:qtdil,qrec:qrec,qmach:qmach,harp:harp,fork:fork,coil:coil,spectro:spectro,seam:seam,rift:rift,kickgap:kickgap,bfield:bfield,gzone:gzone,well:well,pendulum:pendulum,yoke:yoke,updraft:updraft,vortex:vortex,back:back,tunnel:tunnel,flow:flow,nd:nd,fixed:fixed,stroke:stroke,core:core,ball:ball,hero:hero,heroWall:heroWall,curve:curve,joints:joints,impact:impactFx,impacts:drawImpacts,resAnim:resAnim};   /* R116 : joints exporté — le cadre des fiches du didacticiel parle la langue des murs */
})();
