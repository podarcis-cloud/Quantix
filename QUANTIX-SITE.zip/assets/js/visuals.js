/* ============================================================
   visuals.js — rendu R33 (direction validée sur les aperçus)
   Portée privée : un seul nom global exposé, VX (évite toute collision
   avec les identifiants courts d'engine.js — handbook §9.1).
   Règle : la surface visible d'un mur est EXACTEMENT sa ligne de collision ;
   toute la structure décorative est dessinée derrière.
   Couleurs : jetons du handbook §6 et leurs nuances uniquement.
   ============================================================ */
(function(){
'use strict';
var VW=360,VH=480;
var C={matter:[77,215,255],boost:[166,120,255],reward:[255,216,90],goal:[155,235,75],danger:[255,82,82],
       bounce:[255,170,60],white:[234,246,255],pink:[242,160,200],ember:[176,72,28]};
function rgba(c,a){return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';}
function mix(a,b,s){return [a[0]+(b[0]-a[0])*s|0,a[1]+(b[1]-a[1])*s|0,a[2]+(b[2]-a[2])*s|0];}
function rnd(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function now(){return (typeof S!=='undefined'&&S.tick)||0;}
var PAL_W={1:[C.matter,C.boost],2:[C.bounce,C.ember,C.danger,C.reward],3:[C.boost,C.matter],4:[C.white,C.matter],
  5:[C.white,C.boost],6:[C.reward,C.matter],7:[C.goal,C.matter],8:[C.boost,C.matter],9:[C.matter,C.boost],
  10:[C.pink,C.boost],11:[C.boost,C.matter,C.reward]};

/* ---------- géométrie d'un segment : normale « derrière » la surface ---------- */
function geom(s){var dx=s[2]-s[0],dy=s[3]-s[1],len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,nx=-uy,ny=ux;
 if(Math.abs(ny)<.2){nx=s[0]<VW/2?-1:1;ny=0;}else if(ny<0){nx=-nx;ny=-ny;}
 return {len:len,ux:ux,uy:uy,nx:nx,ny:ny};}

/* ============================ DÉCOR PAR NIVEAU ============================ */
var D={key:-1,neb:[],hel:[],ghost:null,dust:[],tracks:[],bubbles:[],embers:[],pal:[C.matter,C.boost],wd:1,busOn:false,
 ring:null,rays:[],flash:[],pv:null};
function veil(seed,pal,keys){var cv=document.createElement('canvas');cv.width=VW;cv.height=VH;var g=cv.getContext('2d');
 g.globalCompositeOperation='lighter';
 function blob(x,y,r,col,a){var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,a));gr.addColorStop(.55,rgba(col,a*.35));gr.addColorStop(1,rgba(col,0));g.fillStyle=gr;g.fillRect(0,0,VW,VH);}
 var i;for(i=0;i<keys.length;i++)blob(keys[i][0],keys[i][1],keys[i][2],keys[i][3],keys[i][4]);
 for(i=0;i<8;i++)blob(rnd(seed+i)*VW,rnd(seed+i*3.1)*VH,60+rnd(seed+i*7.7)*140,pal[i%pal.length],.04+rnd(seed+i*1.9)*.07);
 for(i=0;i<22;i++){var x=rnd(seed*2+i)*VW,y=rnd(seed*3+i)*VH,r=20+rnd(seed*5+i)*50,col=pal[i%pal.length];
  var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(col,.05));gr.addColorStop(1,rgba(col,0));
  g.save();g.translate(x,y);g.rotate(rnd(i)*3);g.scale(2.7,.35);g.translate(-x,-y);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r);g.restore();}
 return cv;}

function compose(lv){
 var seed=(lv.idx||0)*17+3,wd=lv.wd||1,pal=PAL_W[wd]||PAL_W[1],i,k,s;D.wd=wd;D.pal=pal;D.key=lv.idx;
 var z=lv.zone||[0,0,1,1];
 var sx=0,sy=0;for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];var dx=s[2]-s[0],dy=s[3]-s[1],a=Math.atan2(dy,dx)*2,l=Math.hypot(dx,dy);sx+=Math.cos(a)*l;sy+=Math.sin(a)*l;}
 var dom=(sx||sy)?Math.atan2(sy,sx)/2:Math.PI/2;
 var occ=[];for(i=0;i<lv.walls.length;i++){s=lv.walls[i];var n=Math.ceil(Math.hypot(s[2]-s[0],s[3]-s[1])/8);for(k=0;k<=n;k++)occ.push([s[0]+(s[2]-s[0])*k/n,s[1]+(s[3]-s[1])*k/n]);}
 for(var x=z[0];x<=z[0]+z[2];x+=10)for(var y=z[1];y<=z[1]+z[3];y+=12)occ.push([x,y]);
 if(lv.star)occ.push(lv.star);for(y=lv.ball[1]-10;y<lv.ball[1]+140;y+=10)occ.push([lv.ball[0],y]);
 function far(x,y){var m=1e9;for(var j=0;j<occ.length;j++){var d=(occ[j][0]-x)*(occ[j][0]-x)+(occ[j][1]-y)*(occ[j][1]-y);if(d<m)m=d;}return Math.sqrt(m);}
 D.hel=[];var atomLv=(lv.bf||[]).some(function(q){return q&&q[6]==='atom';});
 if(!atomLv&&wd!==2&&wd!==4&&wd!==8)for(var h=0;h<3;h++){var best=null;
  for(k=0;k<300;k++){var cx=20+rnd(seed+h*991+k)*320,cy=50+rnd(seed+h*577+k*1.3)*410;
   var ang=dom+[0,0,.3,-.3,Math.PI/2][Math.floor(rnd(seed+k*2.2)*5)],len=110+rnd(seed+k*3.7)*150;
   var x0=cx-Math.cos(ang)*len/2,y0=cy-Math.sin(ang)*len/2,x1=cx+Math.cos(ang)*len/2,y1=cy+Math.sin(ang)*len/2,clear=1e9;
   for(var q=0;q<=10;q++){var px=x0+(x1-x0)*q/10,py=y0+(y1-y0)*q/10;if(px<-40||px>VW+40||py<-40||py>VH+40){clear=0;break;}clear=Math.min(clear,far(px,py));}
   if(clear<30)continue;var sc=len*Math.min(clear,60);if(!best||sc>best.sc)best={x0:x0,y0:y0,x1:x1,y1:y1,sc:sc,clear:clear};}
  if(!best)break;
  D.hel.push({x0:best.x0,y0:best.y0,x1:best.x1,y1:best.y1,amp:Math.min(12,best.clear-16),turns:1.4+Math.hypot(best.x1-best.x0,best.y1-best.y0)/90,
   sp:(h%2?-1:1)*(.022+rnd(seed+h)*.014),a:pal[h%pal.length],b:pal[(h+1)%pal.length],al:.55-h*.1});
  for(q=0;q<=10;q++)occ.push([best.x0+(best.x1-best.x0)*q/10,best.y0+(best.y1-best.y0)*q/10]);}
 D.ghost=(!atomLv&&wd!==2&&wd!==4&&wd!==8)?{x0:180-Math.cos(dom)*260,y0:240-Math.sin(dom)*260,x1:180+Math.cos(dom)*260,y1:240+Math.sin(dom)*260}:null;
 var keys=[[lv.ball[0],lv.ball[1],110,pal[0],.13],[z[0]+z[2]/2,z[1]+24,120,C.goal,.10]];
 if(wd===2)for(i=0;i<lv.walls.length;i++){s=lv.walls[i];if(s[4]===1)keys.push([(s[0]+s[2])/2,(s[1]+s[3])/2+10,90,C.bounce,.16]);}
 D.neb=[veil(seed,pal,keys),veil(seed+31,pal.slice().reverse(),[])];
 D.dust=[];for(i=0;i<(wd===2?90:150);i++){var zz=.25+rnd(seed+i*2.3)*.75;
  D.dust.push({x:rnd(seed+i)*VW,y:rnd(seed+i*1.7)*VH,z:zz,ph:rnd(i*4.1)*6.28,vx:Math.cos(dom)*(.06+rnd(seed+i*6.1)*.12),vy:(wd===2?-.3-zz*.5:(Math.abs(Math.sin(dom))+.15)*.06),
   col:wd===2?(zz>.7?C.reward:C.bounce):[C.white,C.white,C.white].concat(pal)[i%(3+pal.length)]});}
 D.ring=null;D.rays=[];D.flash=[];D.pv=null;
 D.mech=[];if(wd===6){   /* R153 — MÉCANIQUE DÉCORATIVE : trains d'engrenages, bielle‑manivelle, échappement à ancre, posés là où le jeu laisse de la place */
  if(lv.mov)for(i=0;i<lv.mov.length;i++){var sg0=lv.mov[i].seg;for(k=0;k<=6;k++)occ.push([sg0[0]+(sg0[2]-sg0[0])*k/6,sg0[1]+(sg0[3]-sg0[1])*k/6]);}
  if(lv.pend)for(i=0;i<lv.pend.length;i++)occ.push([lv.pend[i][0],lv.pend[i][1]+lv.pend[i][2]]);
  var types=['train','crank','escape','train','cam'],nm=0;
  for(k=0;k<500&&nm<4;k++){var mx=24+rnd(seed*3+k*1.7)*312,my=40+rnd(seed*5+k*2.3)*400,ty=types[(Math.floor(rnd(seed+k*.7)*5)+nm)%5],kz=1.35+rnd(seed+k*9.1)*.45,RR=(ty==='train'?52:ty==='escape'?46:40)*kz;
   if(far(mx,my)<RR+6)continue;var ok2=true;for(var q2=0;q2<D.mech.length;q2++)if(Math.hypot(D.mech[q2].x-mx,D.mech[q2].y-my)<D.mech[q2].R+RR+10)ok2=false;if(!ok2)continue;
   D.mech.push({t:ty,x:mx,y:my,R:RR,k:kz,s:.6+rnd(seed+k*4.1)*.5,ph:rnd(seed+k*6.1)*6.28,d:rnd(seed+k*8.3)<.5?-1:1});nm++;}}
 if(wd===3){/* anneau de stockage : 2 lignes droites + 2 arcs, aimants de courbure, cavité RF, lignes de lumière tangentes */
  var rx=172,ry=112,cx0=180,cy0=250,rr=ry,sl=rx-rr,mags=[],k2;
  for(k2=0;k2<6;k2++){var side=k2<3?1:-1,ang2=(k2%3-1)*.75;mags.push({side:side,ang:ang2});}
  D.ring={cx:cx0,cy:cy0,r:rr,sl:sl,mags:mags,bunches:[0,.25,.5,.75],cav:.08};
  D.hel=[];D.ghost=null;}
 D.tracks=[];D.bubbles=[];if(wd===2)for(i=0;i<50;i++)D.bubbles.push({x:rnd(seed+i)*VW,y:rnd(seed+i*2.2)*VH,r:.6+rnd(seed+i*3.3)*1.8,sp:.15+rnd(seed+i*4.4)*.35,ph:rnd(i)*6.28});
}
function spawnTrack(x,y,ang,sp,strong){D.tracks.push({pts:[[x,y]],x:x,y:y,a:ang,v:sp,q:Math.random()<.5?-1:1,k:.018+Math.random()*.03,age:0,life:strong?260:190,col:strong?C.reward:(Math.random()<.5?C.bounce:C.white)});}

function ringAt(R,u){var L1=2*R.sl,La=Math.PI*R.r,P=2*L1+2*La,d=((u%1)+1)%1*P,x,y,tx,ty;
 if(d<L1){x=R.cx-R.sl+d;y=R.cy-R.r;tx=1;ty=0;}
 else if(d<L1+La){var a=-Math.PI/2+(d-L1)/R.r;x=R.cx+R.sl+Math.cos(a)*R.r;y=R.cy+Math.sin(a)*R.r;tx=-Math.sin(a);ty=Math.cos(a);}
 else if(d<2*L1+La){x=R.cx+R.sl-(d-L1-La);y=R.cy+R.r;tx=-1;ty=0;}
 else{var a2=Math.PI/2+(d-2*L1-La)/R.r;x=R.cx-R.sl+Math.cos(a2)*R.r;y=R.cy+Math.sin(a2)*R.r;tx=-Math.sin(a2);ty=Math.cos(a2);}
 return {x:x,y:y,tx:tx,ty:ty};}
function magAt(R,m){var a=m.ang;if(m.side>0)return {x:R.cx+R.sl+Math.cos(a)*R.r,y:R.cy+Math.sin(a)*R.r,tx:-Math.sin(a),ty:Math.cos(a)};
 return {x:R.cx-R.sl-Math.cos(a)*R.r,y:R.cy-Math.sin(a)*R.r,tx:Math.sin(a),ty:-Math.cos(a)};}
function drawRing(c){var R=D.ring,t=now(),i,k;c.save();c.globalCompositeOperation='lighter';
 // tube de l'anneau
 c.strokeStyle=rgba(C.boost,.08);c.lineWidth=7;c.beginPath();for(k=0;k<=120;k++){var q=ringAt(R,k/120);if(k)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.stroke();
 c.strokeStyle=rgba(C.boost,.2);c.lineWidth=1;c.stroke();
 // lignes de lumière tangentes (éventail synchrotron) depuis chaque aimant de courbure, parcourues d'impulsions
 for(i=0;i<R.mags.length;i++){var m=magAt(R,R.mags[i]),L=260;
  var gr=c.createLinearGradient(m.x,m.y,m.x+m.tx*L,m.y+m.ty*L);gr.addColorStop(0,rgba(C.matter,.22));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=1.2;c.beginPath();c.moveTo(m.x,m.y);c.lineTo(m.x+m.tx*L,m.y+m.ty*L);c.stroke();
  var pp=((t*1.6+i*37)%L);c.fillStyle=rgba(C.white,.55*(1-pp/L));c.fillRect(m.x+m.tx*pp-1.5,m.y+m.ty*pp-1.5,3,3);
  c.save();c.translate(m.x,m.y);c.rotate(Math.atan2(m.ty,m.tx));c.fillStyle=rgba(C.boost,.3);c.fillRect(-7,-4,14,8);c.strokeStyle=rgba(C.white,.2);c.lineWidth=.8;c.strokeRect(-7,-4,14,8);c.restore();}
 // cavité RF de l'anneau (chaîne de bulbes sur la ligne droite du haut)
 for(k=0;k<5;k++){var cq=ringAt(R,R.cav+k*.012);c.strokeStyle=rgba(C.reward,.35);c.lineWidth=1;c.beginPath();c.ellipse(cq.x,cq.y,4.5,6.5,0,0,6.2832);c.stroke();}
 // paquets de particules : vitesse FIXE (la cavité maintient l'énergie), flash au passage de la cavité
 for(i=0;i<R.bunches.length;i++){var u=(R.bunches[i]+t*.0022)%1,b=ringAt(R,u),inCav=u>R.cav-.01&&u<R.cav+.07;
  for(k=0;k<7;k++){var bk=ringAt(R,u-k*.004);c.fillStyle=rgba(k?C.boost:C.white,(inCav?.9:.5)*(1-k/7));c.beginPath();c.arc(bk.x,bk.y,k?1.4:2.2,0,6.2832);c.fill();}
  if(inCav){var g3=c.createRadialGradient(b.x,b.y,0,b.x,b.y,12);g3.addColorStop(0,rgba(C.reward,.5));g3.addColorStop(1,rgba(C.reward,0));c.fillStyle=g3;c.fillRect(b.x-12,b.y-12,24,24);}}
 c.restore();}
/* lumière synchrotron de la balle : quand elle tourne vite, un rayon part en tangente */
function synchro(c){var b=(typeof S!=='undefined'&&S.ball)?S.ball:null,t=now(),i;if(!b)return;
 var sp=Math.hypot(b.vx,b.vy),ang=Math.atan2(b.vy,b.vx);
 if(D.pv&&sp>3.5&&typeof S!=='undefined'&&S.mode==='run'){var da=Math.abs(((ang-D.pv.a+Math.PI*3)%(Math.PI*2))-Math.PI);
  if(da*sp>.22&&D.rays.length<18)D.rays.push({x:b.x,y:b.y,a:D.pv.a,l:55+sp*11,life:1,w:Math.max(1.6,Math.min(3.5,da*sp*1.4))});}
 D.pv={a:ang};
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.rays.length;i++){var r=D.rays[i],ex=r.x+Math.cos(r.a)*r.l,ey=r.y+Math.sin(r.a)*r.l,gr=c.createLinearGradient(r.x,r.y,ex,ey);
  gr.addColorStop(0,rgba(C.white,.95*r.life));gr.addColorStop(.3,rgba(C.boost,.6*r.life));gr.addColorStop(1,rgba(C.matter,0));
  c.strokeStyle=gr;c.lineWidth=r.w;c.lineCap='round';c.beginPath();c.moveTo(r.x,r.y);c.lineTo(ex,ey);c.stroke();r.life-=.03;}
 D.rays=D.rays.filter(function(q){return q.life>0;});
 for(i=0;i<D.flash.length;i++)D.flash[i].life-=.05;D.flash=D.flash.filter(function(q){return q.life>0;});
 c.restore();}
function helix(c,x0,y0,x1,y1,amp,turns,sp,cA,cB,al,N){
 var t=now(),dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len,pts=[],i;N=N||56;
 for(i=0;i<=N;i++){var s=i/N,ang=s*turns*6.2832+t*sp,bx=x0+dx*s,by=y0+dy*s,o=Math.sin(ang)*amp;
  pts.push({s:s,ang:ang,a:[bx+nx*o,by+ny*o],b:[bx-nx*o,by-ny*o],da:Math.cos(ang),db:-Math.cos(ang)});}
 function fade(s){return Math.min(1,s*6,(1-s)*6);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<=N;i+=3){var p=pts[i],f=(.35+.65*Math.abs(Math.sin(p.ang)))*fade(p.s);c.strokeStyle=rgba(mix(cA,cB,p.s),al*.45*f);c.lineWidth=1;
  c.beginPath();c.moveTo(p.a[0],p.a[1]);c.lineTo(p.b[0],p.b[1]);c.stroke();}
 var keys=['a','b'];for(var kk=0;kk<2;kk++){var key=keys[kk],dk=key==='a'?'da':'db';
  for(i=1;i<=N;i++){p=pts[i];var q=pts[i-1],d=(p[dk]+1)/2,col=mix(cA,cB,p.s),ff=fade(p.s);
   c.strokeStyle=rgba(col,al*(.08+.18*d)*ff);c.lineWidth=4+d*4;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();
   c.strokeStyle=rgba(col,al*(.25+.75*d)*ff);c.lineWidth=.8+d*1.6;c.beginPath();c.moveTo(q[key][0],q[key][1]);c.lineTo(p[key][0],p[key][1]);c.stroke();}}
 c.restore();}

/* ============================ VOILES DE POINTS (R38) ============================
   Plusieurs couches translucides de nuages de points en rotation 3D, superposées : la transparence
   cumulée donne la profondeur (références : vidéos d'illusions bistables). Une volumétrie par monde ;
   le monde 4 y ajoute les franges de deux sources (fentes de Young), un réseau de tourbillons et un
   condensat qui se contracte en pic. Tout est calculé point par point, sans image. */
var VL={wd:-1,layers:[]};
function vlShape(kind,n,seed){
 var out=[],i,x,y,z,r,a,th,ph,q,GA=2.39996323;
 if(kind==='globe'){ /* six grands cercles d'orientations différentes : un globe fait de fils de points */
  var m=Math.round(n/6),ci,cj,u,ax,ay,az,px,py,pz,ca,sa;
  for(ci=0;ci<6;ci++){ax=ci*1.0472;ay=(ci%3)*.9+.3;
   for(cj=0;cj<m;cj++){u=cj/m*6.2832;px=Math.cos(u);py=Math.sin(u);pz=0;
    ca=Math.cos(ax);sa=Math.sin(ax);var y2=py*ca-pz*sa,z2=py*sa+pz*ca;
    ca=Math.cos(ay);sa=Math.sin(ay);out.push([px*ca+z2*sa,y2,-px*sa+z2*ca]);}}
  out.ring=m;return out;}
 if(kind==='disk'){for(i=0;i<n;i++){var u=rnd(seed+i*1.9),arm=i%3,rr=Math.sqrt(u),aa=arm*2.0944+rr*4.2+(rnd(seed+i*2.3)-.5)*.5;out.push([Math.cos(aa)*rr,Math.sin(aa)*rr,(rnd(seed+i*3.1)-.5)*.12*(1-rr)]);}return out;}   /* R153 : galaxie spirale */
 if(kind==='knot'){for(i=0;i<n;i++){var tt=i/n*6.2832,k3=Math.cos(3*tt)*.45+1;out.push([k3*Math.cos(2*tt)*.62,k3*Math.sin(2*tt)*.62,Math.sin(3*tt)*.4]);}return out;}   /* nœud de trèfle */
 if(kind==='lattice'){var m3=Math.max(3,Math.round(Math.cbrt(n)));for(var a1=0;a1<m3;a1++)for(var b1=0;b1<m3;b1++)for(var c1=0;c1<m3;c1++)out.push([a1/(m3-1)*1.4-.7,b1/(m3-1)*1.4-.7,c1/(m3-1)*1.4-.7]);return out;}   /* réseau cristallin */
 if(kind==='cyl'){for(i=0;i<n;i++){var tc=i/n,ac=tc*6.2832*7;out.push([Math.cos(ac)*.55,tc*2-1,Math.sin(ac)*.55]);}return out;}   /* solénoïde */
 for(i=0;i<n;i++){
  if(kind==='torus'){th=rnd(seed+i*1.7)*6.2832;ph=rnd(seed+i*2.9+5)*6.2832;
   x=(1+.34*Math.cos(ph))*Math.cos(th);y=(1+.34*Math.cos(ph))*Math.sin(th);z=.34*Math.sin(ph);out.push([x*.72,y*.72,z*.72]);continue;}
  z=1-2*(i+.5)/n;r=Math.sqrt(1-z*z);a=i*GA;x=Math.cos(a)*r;y=Math.sin(a)*r;
  if(kind==='tetra'){q=1+1.5*x*y*z;x*=q;y*=q;z*=q;}
  else if(kind==='shell2'){q=(i%2)?1:.62;x*=q;y*=q;z*=q;}
  out.push([x,y,z]);}
 return out;}
/* R147 — TEXTURE FINE (demande de Simon : plus petite échelle, plus de transparences, finesse, aucune sphère) :
   trois nappes de fils de soie très fins dont les angles diffèrent un peu — leur superposition fait naître un moiré qui
   glisse lentement ; un grain d'étoiles qui suit les mêmes ondes ; chaque fil a sa propre transparence. */
function vlSilk(wd){var L=VL.layers=[],pal=PAL_W[wd]||PAL_W[1],A=pal[0],B=pal[1]||pal[0],Cc=pal[2]||A,i;
 /* R148 : cinq échelles (maille de 4 à 24 u), cinq opacités — plus dense, plus profond */
 var defs=[[-.42,4.2,.085,.005,A,.08,.35],[-.30,6.5,.05,-.0035,B,.11,.45],[.95,9.5,.032,.003,Cc,.09,.55],[.18,15,.022,-.0022,A,.075,.7],[-1.2,24,.014,.0016,B,.06,.9]];
 for(i=0;i<defs.length;i++){var d=defs[i];L.push({silk:1,rot:d[0]+((wd*.37)%.3),gap:d[1],k:d[2],sp:d[3],c1:d[4],a:d[5],lw:d[6],ph:i*2.1+wd});}
 var g=[];for(i=0;i<900;i++)g.push([rnd(wd*13+i*1.3)*VW,rnd(wd*7+i*2.1)*VH,rnd(i*3.7+wd)]);
 L.push({grain:g,c1:B,c2:A,a:.5});VL.wd=wd;}
function vlSilkDraw(c,l,t){var ca=Math.cos(l.rot),sa=Math.sin(l.rot),D2=Math.hypot(VW,VH),n=Math.ceil(D2/l.gap)+2,j,x,b,st=l.gap<6?12:9;
 c.lineWidth=l.lw||.55;c.strokeStyle=rgba(l.c1,1);
 for(var bk=0;bk<3;bk++){c.globalAlpha=l.a*(.35+.45*bk);c.beginPath();
  for(j=0;j<n;j++){var ph=l.ph+j*1.618;if(((Math.sin(ph*3.1)+1)*1.5|0)!==bk)continue;   /* trois familles de transparence */
   b=-D2/2+j*l.gap;var first=true;
   for(x=-D2/2;x<=D2/2;x+=st){var w=b+Math.sin(x*l.k+ph+t*l.sp)*l.gap*.9+Math.sin(x*l.k*2.3-t*l.sp*1.7+j*.4)*l.gap*.35,
     px=VW/2+x*ca-w*sa,py=VH/2+x*sa+w*ca;if(first){c.moveTo(px,py);first=false;}else c.lineTo(px,py);}}
  c.stroke();}}
function vlGrainDraw(c,l,t){var i,g;
 for(i=0;i<l.grain.length;i++){g=l.grain[i];var x=(g[0]+t*(.04+g[2]*.08))%VW,y=g[1]+Math.sin(x*.03+g[2]*6+t*.004)*6,
   tw=.5+.5*Math.sin(t*(.02+g[2]*.05)+g[2]*40),sz=.45+g[2]*.9;
  c.globalAlpha=l.a*tw*(.15+.6*g[2]);c.fillStyle=rgba(g[2]>.6?l.c1:l.c2,1);c.fillRect(x,y,sz,sz);}}
/* R148 — MYCÉLIUM DE LUMIÈRE : un réseau de capillaires qui pousse depuis les bords (marche au hasard, embranchements) ;
   dessiné une fois dans un calque, très pâle ; des éclats cosmiques le parcourent, se divisent aux fourches et laissent
   derrière eux une traînée qui s'éteint — l'influx qui court dans un mycélium. */
var MY=null;
function myBuild(wd){var segs=[],tips=[],i,sd=wd*101+7,n=0;
 for(i=0;i<5;i++){var e=i%4,x0=e===0?0:e===1?VW:rnd(sd+i)*VW,y0=e===2?0:e===3?VH:rnd(sd+i*3)*VH,a0=Math.atan2(VH/2-y0,VW/2-x0)+(rnd(sd+i*5)-.5);
  tips.push({x:x0,y:y0,a:a0,p:-1,d:0});}
 while(tips.length&&segs.length<1400){var tp=tips.shift();n++;var st=7+rnd(sd+n*1.3)*5,na=tp.a+(rnd(sd+n*2.7)-.5)*.38,x1=tp.x+Math.cos(na)*st,y1=tp.y+Math.sin(na)*st;
  if(x1<-6||x1>VW+6||y1<-6||y1>VH+6||tp.d>140)continue;
  var id=segs.length;segs.push({x0:tp.x,y0:tp.y,x1:x1,y1:y1,p:tp.p,ch:[],g:0,w:Math.max(.25,.9-tp.d*.006)});if(tp.p>=0)segs[tp.p].ch.push(id);
  tips.push({x:x1,y:y1,a:na,p:id,d:tp.d+1});
  if(rnd(sd+n*4.1)<.05)tips.push({x:x1,y:y1,a:na+(rnd(sd+n*5.3)<.5?-1:1)*(.5+rnd(sd+n*6.7)*.5),p:id,d:tp.d+1});}
 var cv=null;try{cv=document.createElement('canvas');cv.width=VW*2;cv.height=VH*2;var g=cv.getContext('2d');g.scale(2,2);g.lineCap='round';
  for(i=0;i<segs.length;i++){var sg=segs[i];g.strokeStyle='rgba(255,255,255,'+(.04+.05*sg.w).toFixed(3)+')';g.lineWidth=sg.w*.42;g.beginPath();g.moveTo(sg.x0,sg.y0);g.lineTo(sg.x1,sg.y1);g.stroke();}}catch(e){cv=null;}
 var roots=[];for(i=0;i<segs.length;i++)if(segs[i].p<0)roots.push(i);
 MY={wd:wd,segs:segs,cv:cv,roots:roots,sp:[],pal:PAL_W[wd]||PAL_W[1]};}
function myDraw(c,t){if(!MY||MY.wd!==D.wd)myBuild(D.wd);var M=MY,i,k,sg;
 if(M.cv){c.globalAlpha=.9;c.drawImage(M.cv,0,0,VW,VH);}
 if(Math.random()<.03&&M.sp.length<9)M.sp.push({s:M.roots[(Math.random()*M.roots.length)|0],u:0,v:.14+Math.random()*.1,c:C.white,n:0,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null});   /* R149 : éclats rares, un sur cinq vire au chaud */   /* un nouvel éclat part d'une racine */
 for(i=M.sp.length-1;i>=0;i--){var p=M.sp[i];p.u+=p.v;sg=M.segs[p.s];sg.g=.7;var wf=p.warm?Math.min(1,p.n/45):0;sg.c=p.warm?[255+(p.warm[0]-255)*wf|0,255+(p.warm[1]-255)*wf|0,255+(p.warm[2]-255)*wf|0]:[200,232,255];p.cc=sg.c;
  if(p.u>=1){p.u=0;p.n++;if(!sg.ch.length){M.sp.splice(i,1);continue;}p.s=sg.ch[0];if(sg.ch.length>1&&M.sp.length<10&&Math.random()<.5)M.sp.push({s:sg.ch[1],u:0,v:p.v*.9,c:p.c,n:p.n,warm:p.warm});}}
 c.lineCap='round';
 for(i=0;i<M.segs.length;i++){sg=M.segs[i];if(sg.g<.02)continue;c.strokeStyle=rgba(sg.c||C.white,1);c.globalAlpha=sg.g*.42;c.lineWidth=sg.w*.6+sg.g*.6;c.beginPath();c.moveTo(sg.x0,sg.y0);c.lineTo(sg.x1,sg.y1);c.stroke();sg.g*=.93;}
 for(i=0;i<M.sp.length;i++){var q=M.sp[i];sg=M.segs[q.s];var x=sg.x0+(sg.x1-sg.x0)*q.u,y=sg.y0+(sg.y1-sg.y0)*q.u,gr=c.createRadialGradient(x,y,0,x,y,5);
  gr.addColorStop(0,rgba(q.cc||C.white,.8));gr.addColorStop(1,rgba(q.cc||C.white,0));c.globalAlpha=1;c.fillStyle=gr;c.fillRect(x-5,y-5,10,10);}
 c.globalAlpha=1;}
function vlBuild(wd,key){
 MY=null;VL.key=key;if(wd===8)return vlSilk(wd);   /* R153 : voiles en volume rétablis dans chaque monde ; la soie ne reste qu'au Magnétisme */
 var L=VL.layers=[],pal=PAL_W[wd]||PAL_W[1],A=pal[0],B=pal[1]||pal[0];
 var kinds={1:['globe','globe','shell2'],2:['tetra','tetra','tetra'],3:['torus','torus','torus'],4:['globe','shell2','globe'],
  5:['disk','shell2','cyl'],6:['lattice','torus','lattice'],7:['disk','shell2','disk'],9:['knot','torus','knot'],10:['knot','cyl','knot'],11:['shell2','tetra','lattice']}[wd]||['globe','shell2','globe'];
 var defs=[[.76,.28,190,.30,.0026,300],[.16,.72,74,.40,-.0046,420],[.60,.90,34,.5,.0067,240]],K=(key||0)+1,ord=[0,1,2];
 if(rnd(K*7.7)<.5)ord=[1,0,2];   /* R153 : chaque niveau compose ses voiles autrement (position, taille, ordre) */
 for(var i=0;i<defs.length;i++){var d=defs[i],jx=(rnd(K*3.1+i)-.5)*.34,jy=(rnd(K*5.3+i)-.5)*.3,js=.75+rnd(K*9.7+i)*.5;
  L.push({pts:vlShape(kinds[ord[i]],d[5],wd*31+i*7),cx:Math.max(.1,Math.min(.9,d[0]+jx))*VW,cy:Math.max(.1,Math.min(.92,d[1]+jy))*VH,R:d[2]*js,a:d[3],sp:d[4]*(rnd(K*2.9+i)<.5?-1:1),ph:i*1.7+K,c1:i%2?B:A,c2:i%2?A:B,tilt:.5+i*.35+rnd(K+i)*.6});}
 VL.wd=wd;}
function vlDrawLayer(c,l,t,sc,alphaMul){
 var ry=t*l.sp+l.ph,rx=l.tilt+Math.sin(t*.0021+l.ph)*.25,cy_=Math.cos(ry),sy=Math.sin(ry),cx_=Math.cos(rx),sx=Math.sin(rx),i,p,x,y,z,x1,z1,y1,z2,pr,al,s;
 if(l.pts.ring){ /* fils : chaque grand cercle est tracé en trait fin, face avant plus lumineuse que la face arrière */
  var m=l.pts.ring,rg,k,q,pp,xx,yy,zz,px_,py_,fr,last;
  c.lineWidth=.8;c.lineJoin='round';
  for(var ps=0;ps<2;ps++){
   c.strokeStyle=rgba(ps?l.c1:l.c2,1);c.globalAlpha=Math.min(1,l.a*alphaMul*(ps?1.5:.8));c.beginPath();
   for(rg=0;rg<6;rg++){last=false;
    for(k=0;k<=m;k++){q=l.pts[rg*m+(k%m)];xx=q[0]*sc;yy=q[1]*sc;zz=q[2]*sc;
     x1=xx*cy_+zz*sy;z1=-xx*sy+zz*cy_;y1=yy*cx_-z1*sx;z2=yy*sx+z1*cx_;
     fr=(z2>0)===(ps===1);
     if(fr){pr=1/(1-z2*.22);px_=l.cx+x1*l.R*pr;py_=l.cy+y1*l.R*pr;if(last)c.lineTo(px_,py_);else c.moveTo(px_,py_);last=true;}else last=false;}}
   c.stroke();}
  return;}
 for(var pass=0;pass<2;pass++){
  c.fillStyle=rgba(pass?l.c1:l.c2,1);
  for(i=0;i<l.pts.length;i++){
   p=l.pts[i];x=p[0]*sc;y=p[1]*sc;z=p[2]*sc;
   x1=x*cy_+z*sy;z1=-x*sy+z*cy_;y1=y*cx_-z1*sx;z2=y*sx+z1*cx_;
   if((z2>0)!==(pass===1))continue;
   pr=1/(1-z2*.22);al=l.a*alphaMul*(.35+.65*(z2+1.3)/2.3);
   s=(1.15+.85*pr)*(z2>0?1.2:.9);
   c.globalAlpha=al;c.fillRect(l.cx+x1*l.R*pr-s/2,l.cy+y1*l.R*pr-s/2,s,s);}}
}
function vlYoung(c,t){
 var src=[[VW*.28,VH*.06],[VW*.72,VH*.06]],k,j,r,al;
 c.save();c.lineWidth=.9;c.setLineDash([1.2,5.5]);
 for(j=0;j<2;j++){
  c.strokeStyle=rgba(j?C.matter:C.white,1);
  for(k=0;k<15;k++){r=(k*17+t*.32)%255;al=(1-r/255)*.42*Math.min(1,r/14);
   if(al<=.004)continue;c.globalAlpha=al;c.beginPath();c.arc(src[j][0],src[j][1],r,.15,Math.PI-.15);c.stroke();}}
 c.restore();}
function vlVortices(c,t){
 var cs=[[.30,.42,1.5],[.66,.32,.7],[.80,.62,1.05],[.18,.80,.6],[.56,.88,.85]],i,k,a,rr,n=16;
 c.save();
 for(i=0;i<cs.length;i++){
  var x0=cs[i][0]*VW,y0=cs[i][1]*VH,dir=(i%2)?-1:1,sp=t*.011*dir/(cs[i][2]*.8)+i,sz=cs[i][2];
  for(k=0;k<n*3;k++){
   var arm=k%3,u=(k/3|0)/n;a=sp+arm*2.0944+u*3.6*dir;rr=(3+u*22)*sz;
   c.globalAlpha=.4*(1-u*.8);c.fillStyle=rgba(u<.5?C.white:C.matter,1);
   c.fillRect(x0+Math.cos(a)*rr-.6,y0+Math.sin(a)*rr*.86-.6,1.5,1.5);}}
 c.restore();}
function vlCondensate(c,t){
 var ph=.5+.5*Math.sin(t*.0105),x=VW*.80,y=VH*.14,g;
 c.save();
 g=c.createRadialGradient(x,y,0,x,y,44+22*(1-ph));
 g.addColorStop(0,rgba(C.white,.05+.34*ph));g.addColorStop(.35,rgba(C.matter,.05+.13*ph));g.addColorStop(1,rgba(C.matter,0));
 c.fillStyle=g;c.fillRect(x-70,y-70,140,140);
 for(var k=0;k<46;k++){var a=k*2.39996+t*.004,r=(6+ (k*7)%44)*(1-.5*ph*(1-k/60));
  c.globalAlpha=.16+.3*ph*(1-k/60);c.fillStyle=rgba(C.white,1);c.fillRect(x+Math.cos(a)*r-.5,y+Math.sin(a)*r*.8-.5,1.2,1.2);}
 c.restore();}
function veils(c){
 if(VL.wd!==D.wd||VL.key!==D.key)vlBuild(D.wd,D.key);
 var t=now(),i,cond=(D.wd===4),mul=cond?1.15:1;
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<VL.layers.length;i++){
  var sc=1;if(cond&&i===0)sc=1-.16*(.5+.5*Math.sin(t*.0105));   /* le condensat respire : le nuage se resserre */
  var ly=VL.layers[i];if(ly.silk){vlSilkDraw(c,ly,t);continue;}if(ly.grain){vlGrainDraw(c,ly,t);continue;}
  vlDrawLayer(c,ly,t,sc,mul);}
 /* R153 : le réseau capillaire n'est plus dessiné (régression R148) — le Magnétisme a ses flux dans les veines */
 if(cond){vlYoung(c,t);vlVortices(c,t);vlCondensate(c,t);}
 c.globalAlpha=1;c.restore();}

/* ============================ MOTIFS R47 ============================
   torusCells : anneau de cellules en fil de fer, chacune semée de points qui scintillent, qui tourne lentement en 3D
   (vidéo de référence « quatrième dimension »). Placé dans la Chaîne (monde 3) : c'est l'anneau de stockage du synchrotron,
   découpé en aimants.
   ferro : texture de ferrofluide (vidéo de référence) — labyrinthe de domaines produit par une réaction‑diffusion
   (Gray‑Scott, régime « labyrinthe ») sur une petite grille, qui s'organise autour d'un aimant. Placé dans Magnétisme
   (monde 8). Calcul : 64 × 86 cellules, 3 itérations par image. */
var TC=null;
function tcBuild(){var N=16,cells=[],i,k;
 for(i=0;i<N;i++){var pts=[];for(k=0;k<9;k++)pts.push([rnd(i*13+k*3.1),rnd(i*7+k*5.3+1),rnd(i*3+k*2.7+2),rnd(i+k*11.3)]);cells.push(pts);}
 TC={N:N,cells:cells};}
function torusCells(c,cx,cy,Rm,rm,alpha){
 if(!TC)tcBuild();var t=now(),N=TC.N,ax=.95+Math.sin(t*.0009)*.25,az=t*.0016,ay=Math.sin(t*.0006)*.35;
 var cxa=Math.cos(ax),sxa=Math.sin(ax),cza=Math.cos(az),sza=Math.sin(az),cya=Math.cos(ay),sya=Math.sin(ay);
 function P(th,ph,h){ /* th : angle autour de l'anneau ; ph : position dans l'épaisseur (−1 intérieur, +1 extérieur) ; h : hauteur */
  var r=Rm+ph*rm,x=Math.cos(th)*r,y=Math.sin(th)*r,z=h*rm*.9;
  var x1=x*cza-y*sza,y1=x*sza+y*cza;            /* rotation propre de l'anneau */
  var y2=y1*cxa-z*sxa,z2=y1*sxa+z*cxa;          /* inclinaison */
  var x3=x1*cya+z2*sya,z3=-x1*sya+z2*cya;
  var pr=1/(1-z3/(Rm*4));return [cx+x3*pr,cy+y2*pr,z3];}
 c.save();c.globalCompositeOperation='lighter';c.lineWidth=.8;
 var i,k,a0,a1,q;
 for(i=0;i<N;i++){a0=i/N*6.2832;a1=(i+1)/N*6.2832;var gap=.035;
  var cs=[P(a0+gap,-1,-1),P(a1-gap,-1,-1),P(a1-gap,1,-1),P(a0+gap,1,-1),P(a0+gap,-1,1),P(a1-gap,-1,1),P(a1-gap,1,1),P(a0+gap,1,1)];
  var depth=(cs[0][2]+cs[6][2])/2,fa=alpha*(.45+.55*(depth/(Rm+rm)+1)/2);
  c.strokeStyle=rgba(C.white,fa);c.beginPath();
  [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){c.moveTo(cs[e[0]][0],cs[e[0]][1]);c.lineTo(cs[e[1]][0],cs[e[1]][1]);});
  c.stroke();
  var pts=TC.cells[i];
  for(k=0;k<pts.length;k++){var p=pts[k],tw=.5+.5*Math.sin(t*.004+p[3]*20);
   q=P(a0+gap+(a1-a0-2*gap)*p[0],p[1]*2-1,p[2]*2-1);
   c.fillStyle=rgba(k%3?C.white:C.boost,fa*(.6+1.2*tw));c.fillRect(q[0]-.7,q[1]-.7,1.4+tw*.6,1.4+tw*.6);}}
 c.restore();}
var FF=null;
function ffInit(){var w=96,h=128,n=w*h,U=new Float32Array(n),V=new Float32Array(n),i;
 for(i=0;i<n;i++){U[i]=1;V[i]=0;}
 for(i=0;i<260;i++){var a=rnd(i*3.3)*6.2832,r=rnd(i*7.1)*34,x=Math.round(w/2+Math.cos(a)*r),y=Math.round(h*.6+Math.sin(a)*r);
  for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var j=(y+dy)*w+x+dx;if(j>=0&&j<n){U[j]=.5;V[j]=.25;}}}
 var cv=document.createElement('canvas');cv.width=w;cv.height=h;
 FF={w:w,h:h,U:U,V:V,U2:new Float32Array(n),V2:new Float32Array(n),cv:cv,cx:cv.getContext('2d'),img:null,t:0};
 FF.img=FF.cx.createImageData(w,h);
 for(i=0;i<1600;i++)ffStep();}
function ffStep(){ /* Gray-Scott, régime labyrinthe ; l'« aimant » (centre bas) nourrit davantage la réaction */
 var w=FF.w,h=FF.h,U=FF.U,V=FF.V,U2=FF.U2,V2=FF.V2,x,y,i,mx=w/2,my=h*.6;
 for(y=1;y<h-1;y++)for(x=1;x<w-1;x++){i=y*w+x;
  var u=U[i],v=V[i],lu=U[i-1]+U[i+1]+U[i-w]+U[i+w]-4*u,lv=V[i-1]+V[i+1]+V[i-w]+V[i+w]-4*v,uvv=u*v*v;
  var d=Math.min(1,Math.hypot(x-mx,(y-my)*.9)/48),F=.029+.012*d*d,K=.057+.008*d*d;   /* labyrinthe près de l'aimant, s'éteint au loin */
  U2[i]=u+(.16*lu-uvv+F*(1-u));V2[i]=v+(.08*lv+uvv-(F+K)*v);}
 FF.U=U2;FF.U2=U;FF.V=V2;FF.V2=V;}
function ffClear(lv,fx,fy){ /* la texture s'efface autour de ce qui se lit en jouant : murs, départ, bassin, noyau */
 var d=1e9,i,w=lv&&lv.w||[];
 for(i=0;i<w.length;i++){var s0=w[i],ax=s0[2]-s0[0],ay=s0[3]-s0[1],l2=ax*ax+ay*ay,u=l2?Math.max(0,Math.min(1,((fx-s0[0])*ax+(fy-s0[1])*ay)/l2)):0;
  d=Math.min(d,Math.hypot(fx-s0[0]-u*ax,fy-s0[1]-u*ay));}
 if(lv&&lv.ball)d=Math.min(d,Math.hypot(fx-lv.ball[0],fy-lv.ball[1])-14);
 if(lv&&lv.star)d=Math.min(d,Math.hypot(fx-lv.star[0],fy-lv.star[1])-10);
 if(lv&&lv.cup){var cp=lv.cup,dx=Math.max(cp[0]-fx,0,fx-(cp[0]+cp[2])),dy=Math.max(cp[1]-60-fy,0,fy-cp[1]-6);d=Math.min(d,Math.hypot(dx,dy));}
 return Math.max(.35,Math.min(1,(d-6)/22));}   /* R152 : on n'efface plus que près des pièces, et jamais tout à fait — même texture d'un niveau à l'autre */
function ferro(c,lv){
 /* R49 (retour Simon : « trop grossier, plusieurs couleurs ») : les parois des domaines sont tracées en VECTEUR
    (carrés de marche sur l'iso‑valeur), donc nettes à toute taille, et colorées selon la distance à l'aimant :
    cyan au cœur, violet, puis rose au bord — comme les reflets de la vidéo. Contour recalculé une image sur trois. */
 if(!FF)ffInit();
 var rm=(typeof OPT!=='undefined'&&OPT.rm);
 if(!rm){ffStep();ffStep();}
 FF.t++;
 if(!FF.lay||FF.t%6===0){
  if(!FF.lay){FF.lay=document.createElement('canvas');FF.lay.width=VW*2;FF.lay.height=VH*2;FF.lc=FF.lay.getContext('2d');}
  var w=FF.w,h=FF.h,V=FF.V,sx=VW*2/(w-1),sy=VH*2/(h-1),iso=.2,x,y,lc=FF.lc,mx=(w-1)/2,my=(h-1)*.6,maxd=Math.hypot(mx,my);
  if(!FF.clr||FF.clrKey!==(lv&&lv.idx)){FF.clr=new Float32Array(w*h);FF.clrKey=lv&&lv.idx;for(var cy2=0;cy2<h;cy2++)for(var cx2=0;cx2<w;cx2++)FF.clr[cy2*w+cx2]=ffClear(lv,cx2*VW/(w-1),cy2*VH/(h-1));}
  lc.clearRect(0,0,FF.lay.width,FF.lay.height);lc.lineCap='round';
  var bands=[[C.matter,[]],[C.boost,[]],[C.pink||[255,77,141],[]]];
  function lerp(a,b){return (iso-a)/((b-a)||1e-6);}
  for(y=0;y<h-1;y++)for(x=0;x<w-1;x++){
   var a0=V[y*w+x],a1=V[y*w+x+1],a2=V[(y+1)*w+x+1],a3=V[(y+1)*w+x],k=(a0>iso?1:0)|(a1>iso?2:0)|(a2>iso?4:0)|(a3>iso?8:0);
   if(k===0||k===15)continue;
   var e=[[x+lerp(a0,a1),y],[x+1,y+lerp(a1,a2)],[x+lerp(a3,a2),y+1],[x,y+lerp(a0,a3)]];
   var segs={1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],5:[[3,0],[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[0,2]],10:[[0,1],[2,3]],11:[[1,2]],12:[[1,3]],13:[[0,1]],14:[[3,0]]}[k];
   var dn=Math.hypot(x-mx,(y-my)*.9)/maxd,bi=dn<.28?0:(dn<.5?1:2),fade=Math.max(0,1-dn*1.35);
   var fx=x*VW/(w-1),fy=y*VH/(h-1),ft=FF.t*.004,mk=.5+.5*Math.sin(fx*.031+ft)*Math.sin(fy*.026-ft*.7)+.25*Math.sin((fx+fy)*.012+ft*1.3);
   fade*=Math.max(0,Math.min(1,mk*1.5-.35))*(FF.clr?FF.clr[y*w+x]:1);   /* trous de transparence qui dérivent + dégagement du parcours */
   if(fade<=.02)continue;
   for(var q=0;q<segs.length;q++)bands[bi][1].push(e[segs[q][0]][0]*sx,e[segs[q][0]][1]*sy,e[segs[q][1]][0]*sx,e[segs[q][1]][1]*sy,fade);}
  for(var bnd=0;bnd<3;bnd++){var col=bands[bnd][0],L=bands[bnd][1];
   for(var pass=0;pass<2;pass++){lc.lineWidth=pass?1.6:5;lc.strokeStyle=rgba(col,pass?.85:.12);lc.beginPath();
    for(var i=0;i<L.length;i+=5){lc.globalAlpha=L[i+4];lc.moveTo(L[i],L[i+1]);lc.lineTo(L[i+2],L[i+3]);}
    lc.globalAlpha=1;lc.stroke();}}}
 c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.6;c.drawImage(FF.lay,0,0,VW,VH);c.globalAlpha=1;
 /* poussière animée : grains qui dérivent au hasard, transparence aléatoire et changeante */
 if(!FF.dust){FF.dust=[];for(var di=0;di<80;di++)FF.dust.push({x:rnd(di*1.7)*VW,y:rnd(di*2.9+3)*VH,vx:(rnd(di*5.1)-.5)*.25,vy:(rnd(di*3.3)-.5)*.25,ph:rnd(di*7.7)*6.28,r:.5+rnd(di*9.1)*1.3,c:di%3});}
 var tn=now(),cols=[C.matter,C.boost,C.pink];
 for(var dj=0;dj<FF.dust.length;dj++){var q=FF.dust[dj];
  if(!rm){q.vx+=(Math.random()-.5)*.03;q.vy+=(Math.random()-.5)*.03;q.vx*=.98;q.vy*=.98;q.x=(q.x+q.vx+VW)%VW;q.y=(q.y+q.vy+VH)%VH;}
  var al=.08+.45*Math.pow(.5+.5*Math.sin(tn*.0017*(1+q.r)+q.ph),3);
  c.fillStyle=rgba(cols[q.c],al);c.beginPath();c.arc(q.x,q.y,q.r,0,6.2832);c.fill();}
 /* l'aimant : reflet circulaire, comme la goutte de la vidéo */
 var ax=VW/2,ay=VH*.6,g=c.createRadialGradient(ax,ay,0,ax,ay,40);g.addColorStop(0,rgba(C.white,.05));g.addColorStop(.85,rgba(C.boost,.07));g.addColorStop(1,rgba(C.boost,0));
 c.fillStyle=g;c.beginPath();c.arc(ax,ay,40,0,6.2832);c.fill();
 c.strokeStyle=rgba(C.white,.18);c.lineWidth=1.2;c.beginPath();c.arc(ax,ay,30,0,6.2832);c.stroke();
 c.restore();}

/* ============================ FERROFLUIDE v2 (R52) ============================
   D'après la vidéo de référence : près de la goutte, un réseau de CELLULES ; plus loin, des filaments étirés dans le sens
   du champ ; en bordure, des gouttelettes. Tout bouge vite et de façon organique : la goutte (l'aimant) dérive, les germes
   des cellules la suivent avec retard, ce qui étire le réseau derrière elle.
   Rendu : parois des cellules = iso‑contour de (F2 − F1) d'un diagramme de Voronoï (carrés de marche) ; relief par ombre
   portée + liseré clair ; trois couleurs selon la distance ; poussière émise le long des parois ; transparence par
   endroits et dégagement du parcours (ffClear). */
var FV=null;
/* R149 — LABYRINTHE DE FERROFLUIDE (référence : vidéo de Simon) en plusieurs plages de tailles et d'échelles différentes :
   une grande plage à cellules moyennes, une plage dense à cellules fines, une plage lâche à grandes cellules, deux petites
   plages ; chaque plage dérive lentement et s'étire en doigts derrière elle. Plus de goutte au centre. */
function fvInit(){var s=[],i,k,P=[[.30,.30,175,95,.7],[.74,.62,140,150,1.1],[.30,.86,150,34,.5],[.86,.16,90,40,.9],[.08,.62,80,26,.8]];
 for(k=0;k<P.length;k++)for(i=0;i<P[k][3];i++){var r=Math.sqrt(rnd(k*97+i*3.7))*P[k][2],a=rnd(k*53+i*9.1)*6.2832;s.push({r:r,a:a,x:0,y:0,p:k,ph:rnd(k*7+i*1.3)*6.28,sp:.4+rnd(k*11+i*5.9)*.8});}
 var gw=96,gh=128,pz=P.map(function(q,k){return {bx:q[0]*VW,by:q[1]*VH,R:q[2],w:q[4],x:q[0]*VW,y:q[1]*VH,vx:0,vy:0};});
 FV={s:s,P:pz,gw:gw,gh:gh,E:new Float32Array(gw*gh),t:0,mx:VW/2,my:VH*.58,vx:0,vy:0,dust:[],segs:[],lay:null,clr:null,key:null,sk:[],hash:null};}
/* éclats le long des parois du labyrinthe : rares, fins ; ils passent d'une paroi à la suivante par les extrémités
   communes ; un sur cinq finit dans les rouges, orangés et pourpres. */
var WARM=[[255,96,72],[255,150,70],[214,70,255]];
function fvSparks(c){var F=FV,i;if(!F.hash||!F.segs.length)return;
 if(Math.random()<.05&&F.sk.length<8){var g=F.segs[(Math.random()*F.segs.length)|0];if(g[4]>.3)F.sk.push({x:g[0],y:g[1],dx:g[2]-g[0],dy:g[3]-g[1],tr:[],n:0,L:30+Math.random()*60,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null});}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=F.sk.length-1;i>=0;i--){var p=F.sk[i];
  for(var st=0;st<1;st++){var key=Math.round(p.x/3)+','+Math.round(p.y/3),L=F.hash[key],best=null,bd=-2,dl=Math.hypot(p.dx,p.dy)||1;
   if(L)for(var k=0;k<L.length;k++){var g2=F.segs[L[k]>>1],e=L[k]&1,ex=e?g2[0]:g2[2],ey=e?g2[1]:g2[3],sx=e?g2[2]:g2[0],sy=e?g2[3]:g2[1],vx=ex-sx,vy=ey-sy,vl=Math.hypot(vx,vy)||1,dot=(vx*p.dx+vy*p.dy)/(vl*dl);
    if(Math.hypot(ex-p.x,ey-p.y)<.6)continue;if(dot>bd){bd=dot;best=[ex,ey,vx,vy];}}
   if(!best||bd<-.2){p.n=p.L;break;}p.tr.push([p.x,p.y]);if(p.tr.length>14)p.tr.shift();p.x=best[0];p.y=best[1];p.dx=best[2];p.dy=best[3];p.n++;}
  if(p.n>=p.L){F.sk.splice(i,1);continue;}
  var f=p.n/p.L,env=Math.sin(Math.PI*f),col=p.warm?[255+(p.warm[0]-255)*f|0,255+(p.warm[1]-255)*f|0,255+(p.warm[2]-255)*f|0]:[200,236,255];
  if(p.tr.length>1){c.strokeStyle=rgba(col,.35*env);c.lineWidth=.9;c.beginPath();c.moveTo(p.tr[0][0],p.tr[0][1]);for(var q=1;q<p.tr.length;q++)c.lineTo(p.tr[q][0],p.tr[q][1]);c.lineTo(p.x,p.y);c.stroke();}
  var gr=c.createRadialGradient(p.x,p.y,0,p.x,p.y,4);gr.addColorStop(0,rgba(col,.85*env));gr.addColorStop(1,rgba(col,0));c.fillStyle=gr;c.fillRect(p.x-5,p.y-5,10,10);}
 c.restore();}
/* R151 — FLUX D'ÉNERGIE dans les veines : une impulsion naît sur une veine, avance de case en case le long de la crête,
   se divise aux carrefours (réseau neuronal / mycélium) ; chaque case parcourue s'illumine puis s'éteint lentement.
   Une impulsion sur cinq glisse vers les rouges, orangés et pourpres au fil de sa course. */
function fvFlow(c){var F=FV,gw=F.gw,gh=F.gh,R=F.rg,i,k;if(!R)return;
 if(!F.vt||F.vt.length!==gw*gh){F.vt=new Uint32Array(gw*gh);F.pu=[];F.gh2=[];}
 var T0=F.t,sx=VW/(gw-1),sy=VH/(gh-1),N=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]];
 if(Math.random()<.035&&F.pu.length<6){for(var tr=0;tr<40;tr++){var id=(Math.random()*gw*gh)|0;if(R[id]){F.pu.push({id:id,n:0,L:110+Math.random()*120,warm:Math.random()<.2?WARM[(Math.random()*3)|0]:null,dx:0,dy:0,tr:[]});break;}}}
 function colOf(p){var f=Math.min(1,p.n/p.L);return p.warm?[255+(p.warm[0]-255)*f|0,255+(p.warm[1]-255)*f|0,255+(p.warm[2]-255)*f|0]:[150+70*f|0,215+20*f|0,255];}
 for(k=F.pu.length-1;k>=0;k--){var p=F.pu[k],x=p.id%gw,y=(p.id/gw)|0,opts=[];
  for(i=0;i<8;i++){var nx=x+N[i][0],ny=y+N[i][1];if(nx<0||ny<0||nx>=gw||ny>=gh)continue;var nid=ny*gw+nx;if(!R[nid]||nid===p.prev)continue;var fresh=T0-F.vt[nid]>=60;opts.push([nid,N[i][0],N[i][1],N[i][0]*p.dx+N[i][1]*p.dy-(fresh?0:3)-F.E[nid]*.25]);}
  if(!opts.length||p.n>p.L){F.gh2.push({tr:p.tr,a:1,c:p.c});F.pu.splice(k,1);continue;}
  opts.sort(function(a,b){return b[3]-a[3];});var o=opts[0];
  if(opts.length>3&&F.pu.length<16&&p.n>8&&Math.random()<.07){var o2=opts[opts.length-1];if(Math.abs(o2[1]-o[1])+Math.abs(o2[2]-o[2])>1)F.pu.push({id:o2[0],n:p.n,L:p.L*.85,warm:p.warm,dx:o2[1],dy:o2[2],tr:[[x*sx,y*sy]]});}   /* ramification */
  p.prev=p.id;p.id=o[0];p.dx=o[1];p.dy=o[2];p.n++;F.vt[p.id]=T0;p.tr.push([(p.id%gw)*sx,((p.id/gw)|0)*sy]);if(p.tr.length>34)p.tr.shift();p.c=colOf(p);}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 function trail(tr0,col,a){if(tr0.length<2)return;var tr=tr0.map(function(q,m){var A=tr0[Math.max(0,m-1)],B=tr0[Math.min(tr0.length-1,m+1)];return [(A[0]+q[0]*2+B[0])/4,(A[1]+q[1]*2+B[1])/4];});for(var m=1;m<tr.length;m++){var f=m/tr.length;c.strokeStyle=rgba(col,a*f*.75);c.lineWidth=.6+f*1.1;c.beginPath();c.moveTo(tr[m-1][0],tr[m-1][1]);c.lineTo(tr[m][0],tr[m][1]);c.stroke();}}
 for(i=F.gh2.length-1;i>=0;i--){var gq=F.gh2[i];gq.a-=.04;if(gq.a<=0){F.gh2.splice(i,1);continue;}if(gq.tr.length>1)gq.tr.shift();trail(gq.tr,gq.c||[200,230,255],gq.a);}
 for(i=0;i<F.pu.length;i++){var q=F.pu[i],cq=q.c||[200,230,255];trail(q.tr,cq,1);q.tr.c=cq;
  var hx=q.tr.length?q.tr[q.tr.length-1][0]:0,hy=q.tr.length?q.tr[q.tr.length-1][1]:0,gr=c.createRadialGradient(hx,hy,0,hx,hy,5);gr.addColorStop(0,rgba(cq,.9));gr.addColorStop(1,rgba(cq,0));c.fillStyle=gr;c.fillRect(hx-5,hy-5,10,10);}
 c.restore();}
function ferro2(c,lv){
 if(!FV)fvInit();var rm=(typeof OPT!=='undefined'&&OPT.rm),t=now()*.001,i,j,k;FV.t++;
 /* la goutte dérive (trajectoire organique, ~9 s par boucle) */
 for(k=0;k<FV.P.length;k++){var pp=FV.P[k],w=pp.w,nx=pp.bx+Math.sin(t*.35*w+k)*34+Math.sin(t*.9*w+k*2)*8,ny=pp.by+Math.cos(t*.27*w+k*1.7)*26+Math.sin(t*.7*w)*6;if(rm){nx=pp.bx;ny=pp.by;}
  pp.vx=nx-pp.x;pp.vy=ny-pp.y;pp.x=nx;pp.y=ny;}
 for(i=0;i<FV.s.length;i++){var q=FV.s[i],P0=FV.P[q.p],vs=Math.hypot(P0.vx,P0.vy),ux=vs?P0.vx/vs:1,uy=vs?P0.vy/vs:0,str=Math.min(1.6,vs*2.2);
  q.a+=rm?0:.003*q.sp*Math.sin(t*.9+q.ph);q.r+=rm?0:Math.sin(t*2.2*q.sp+q.ph)*.25;
  var px=Math.cos(q.a)*q.r,py=Math.sin(q.a)*q.r,along=px*ux+py*uy;
  if(along<0){px-=ux*along*str*.9;py-=uy*along*str*.9;}          /* étirement derrière la plage : doigts */
  q.x+= (P0.x+px-q.x)*(q.x?0.18:1);q.y+=(P0.y+py-q.y)*(q.y?0.18:1);}
 if(!FV.lay||FV.t%4===0){
  var gw=FV.gw,gh=FV.gh,E=FV.E,sx=VW/(gw-1),sy=VH/(gh-1),S=FV.s;
  if(FV.key!==(lv&&lv.idx)){FV.key=lv&&lv.idx;FV.clr=new Float32Array(gw*gh);for(j=0;j<gh;j++)for(i=0;i<gw;i++)FV.clr[j*gw+i]=ffClear(lv,i*sx,j*sy);}
  var BK=36,bw=Math.ceil(VW/BK)+1,bh=Math.ceil(VH/BK)+1,bu=[];for(k=0;k<bw*bh;k++)bu.push([]);   /* R149 : graines rangées par cases — 2 plus proches en temps court */
  for(k=0;k<S.length;k++){var bx=Math.max(0,Math.min(bw-1,(S[k].x/BK)|0)),by=Math.max(0,Math.min(bh-1,(S[k].y/BK)|0));bu[by*bw+bx].push(S[k]);}
  if(!FV.img){FV.img=document.createElement('canvas');FV.img.width=gw;FV.img.height=gh;FV.ic=FV.img.getContext('2d');FV.id=FV.ic.createImageData(gw,gh);}
  var ID=FV.id.data,cl3=[C.matter,C.boost,C.pink];
  for(j=0;j<gh;j++)for(i=0;i<gw;i++){var x=i*sx,y=j*sy,f1=1e9,f2=1e9,cx=(x/BK)|0,cy=(y/BK)|0;
   for(var oy=-2;oy<=2;oy++)for(var ox=-2;ox<=2;ox++){var bx2=cx+ox,by2=cy+oy;if(bx2<0||by2<0||bx2>=bw||by2>=bh)continue;var Bq=bu[by2*bw+bx2];
    for(k=0;k<Bq.length;k++){var dx=x-Bq[k].x,dy=y-Bq[k].y,d=dx*dx+dy*dy;if(d<f1){f2=f1;f1=d;}else if(d<f2)f2=d;}}
   var ev=f2<1e9?Math.sqrt(f2)-Math.sqrt(f1):99;E[j*gw+i]=ev;
   var fr2=0,dmin=9;for(var pk2=0;pk2<FV.P.length;pk2++){var Pr=FV.P[pk2],dq2=Math.hypot(x-Pr.x,y-Pr.y)/Pr.R;fr2=Math.max(fr2,1-dq2);if(dq2<dmin)dmin=dq2;}
   var vv=Math.max(0,1-ev/3.2)*Math.max(0,fr2)*(FV.clr?FV.clr[j*gw+i]:1),cc=cl3[dmin<.45?0:dmin<.8?1:2],o=(j*gw+i)*4;   /* veines : bande où les deux graines les plus proches sont à égale distance */
   ID[o]=cc[0];ID[o+1]=cc[1];ID[o+2]=cc[2];ID[o+3]=Math.min(255,vv*230)|0;
   if(!FV.rg||FV.rg.length!==gw*gh)FV.rg=new Uint8Array(gw*gh);FV.rg[j*gw+i]=(ev<2.8&&vv>.06)?1:0;}
  FV.ic.putImageData(FV.id,0,0);
  if(!FV.lay){FV.lay=document.createElement('canvas');FV.lay.width=VW*2;FV.lay.height=VH*2;FV.lc=FV.lay.getContext('2d');
   FV.lay2=document.createElement('canvas');FV.lay2.width=VW*2;FV.lay2.height=VH*2;FV.lc2=FV.lay2.getContext('2d');}
  var lc=FV.lc,lc2=FV.lc2,iso=4.2,segs=[];lc.setTransform(2,0,0,2,0,0);lc.clearRect(0,0,VW,VH);lc.lineCap='round';lc2.setTransform(2,0,0,2,0,0);lc2.clearRect(0,0,VW,VH);lc2.lineCap='round';
  function lp(a,b){return (iso-a)/((b-a)||1e-6);}
  var TB={1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],5:[[3,0],[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[0,2]],10:[[0,1],[2,3]],11:[[1,2]],12:[[1,3]],13:[[0,1]],14:[[3,0]]};
  for(j=0;j<gh-1;j++)for(i=0;i<gw-1;i++){
   var a0=E[j*gw+i],a1=E[j*gw+i+1],a2=E[(j+1)*gw+i+1],a3=E[(j+1)*gw+i],m=(a0<iso?1:0)|(a1<iso?2:0)|(a2<iso?4:0)|(a3<iso?8:0);
   if(m===0||m===15)continue;
   var cx0=i*sx,cy0=j*sy,dm=1e9,fr=0;for(var pk=0;pk<FV.P.length;pk++){var Pq=FV.P[pk],dq=Math.hypot(cx0-Pq.x,cy0-Pq.y)/Pq.R;if(dq<dm){dm=dq;}fr=Math.max(fr,1-dq);}var fade=Math.max(0,fr)*(FV.clr[j*gw+i]);dm*=110;
   var mk=.55+.45*Math.sin(cx0*.035+t*.8)*Math.sin(cy0*.03-t*.6);fade*=Math.max(.35,Math.min(1,mk*1.4));
   if(fade<.04)continue;
   var e=[[i+lp(a0,a1),j],[i+1,j+lp(a1,a2)],[i+lp(a3,a2),j+1],[i,j+lp(a0,a3)]],L=TB[m];
   for(var z=0;z<L.length;z++)segs.push([e[L[z][0]][0]*sx,e[L[z][0]][1]*sy,e[L[z][1]][0]*sx,e[L[z][1]][1]*sy,fade,dm<55?0:(dm<110?1:2)]);}
  FV.segs=segs;var hs={};for(var hi=0;hi<segs.length;hi++){var g0=segs[hi];[[g0[0],g0[1]],[g0[2],g0[3]]].forEach(function(pt,e){var key=Math.round(pt[0]/3)+','+Math.round(pt[1]/3);(hs[key]=hs[key]||[]).push(hi*2+e);});}FV.hash=hs;   /* R149 : extrémités indexées — les éclats suivent les parois */
  var cols=[C.matter,C.boost,C.pink];
  /* relief : ombre portée sombre, puis le trait coloré, puis un liseré clair décalé vers la lumière */
  /* ombre sur un calque (fusion normale), couleur et liseré sur un second calque (fusion additive) : relief + éclat */
  [[1.2,1.4,'rgba(2,4,10,.55)',2.6,lc],[0,0,null,1.1,lc2],[-.5,-.6,'rgba(255,255,255,.55)',.45,lc2]].forEach(function(P){var X2=P[4];
   for(var b=0;b<3;b++){X2.strokeStyle=P[2]||rgba(cols[b],1);X2.lineWidth=P[3];X2.beginPath();
    for(var n=0;n<segs.length;n++){var g=segs[n];if(g[5]!==b)continue;X2.globalAlpha=g[4];X2.moveTo(g[0]+P[0],g[1]+P[1]);X2.lineTo(g[2]+P[0],g[3]+P[1]);}
    X2.stroke();}X2.globalAlpha=1;});}
 c.save();if(FV.img){c.globalCompositeOperation='lighter';c.globalAlpha=.36;c.imageSmoothingEnabled=true;c.drawImage(FV.img,0,0,VW,VH);c.globalCompositeOperation='source-over';}   /* veines douces */
 c.globalAlpha=.4;c.drawImage(FV.lay,0,0,VW,VH);c.globalCompositeOperation='lighter';c.globalAlpha=.36;c.drawImage(FV.lay2,0,0,VW,VH);   /* R150 : discret, comme sur les niveaux 6 et 12 */c.globalAlpha=1;
 /* gouttelettes en bordure */

 /* poussière : émise abondamment le long des parois, elle file dans le sens du champ et s'éteint */
 if(false){for(k=0;k<4;k++){var sg=FV.segs[Math.floor(Math.random()*FV.segs.length)];if(Math.random()>sg[4])continue;
   var ox=sg[0]-FV.mx,oy=sg[1]-FV.my,od=Math.hypot(ox,oy)||1;
   FV.dust.push({x:sg[0],y:sg[1],vx:ox/od*(.25+Math.random()*.5)+(Math.random()-.5)*.3,vy:oy/od*(.25+Math.random()*.5)+(Math.random()-.5)*.3,l:0,L:40+Math.random()*70,c:sg[5],r:.5+Math.random()*1.1});}
  if(FV.dust.length>320)FV.dust.splice(0,FV.dust.length-320);}
 var cols2=[C.matter,C.boost,C.pink];
 if(!rm)fvFlow(c);   /* R151 : l'énergie parcourt les veines du labyrinthe et s'y ramifie */
 for(i=FV.dust.length-1;i>=0;i--){var p=FV.dust[i];p.l++;if(p.l>p.L){FV.dust.splice(i,1);continue;}
  p.x+=p.vx;p.y+=p.vy;p.vx*=.985;p.vy*=.985;var al=Math.sin(Math.PI*p.l/p.L)*.6;
  c.fillStyle=rgba(cols2[p.c],al);c.fillRect(p.x-p.r/2,p.y-p.r/2,p.r,p.r);}
 c.restore();}

/* ══ R153 — MÉCANIQUE DÉCORATIVE (monde 6) : la même langue que les pièces mobiles du niveau 6 (bielle, ancre, cuivre doré),
   en retrait — traits fins, transparence, mouvement lent et continu. ══ */
function gearP(c,x,y,r,n,a){var i,k=n*2;c.beginPath();for(i=0;i<=k*2;i++){var u=i/(k*2)*6.2832+a,rr=(Math.floor(i/2)%2)?r:r-r*.16;var px=x+Math.cos(u)*rr,py=y+Math.sin(u)*rr;if(i)c.lineTo(px,py);else c.moveTo(px,py);}c.closePath();}
function gear(c,x,y,r,n,a,al){var G=[224,178,76],Wc=[255,236,190],i;c.fillStyle=rgba(G,al*.06);gearP(c,x,y,r,n,a);c.fill();c.strokeStyle=rgba(G,al*.55);c.lineWidth=1;c.stroke();
 c.strokeStyle=rgba(G,al*.3);c.beginPath();c.arc(x,y,r*.62,0,6.2832);c.stroke();
 for(i=0;i<5;i++){var u=a+i*1.2566;c.beginPath();c.moveTo(x+Math.cos(u)*r*.18,y+Math.sin(u)*r*.18);c.lineTo(x+Math.cos(u)*r*.6,y+Math.sin(u)*r*.6);c.stroke();}
 c.fillStyle=rgba(Wc,al*.7);c.beginPath();c.arc(x,y,2.2,0,6.2832);c.fill();}
function mechDeco(c){var t=now(),G=[224,178,76],Wc=[255,236,190],i;c.save();c.lineCap='round';c.lineJoin='round';
 for(i=0;i<D.mech.length;i++){var m=D.mech[i],x=m.x,y=m.y,w=t*.012*m.s*m.d+m.ph,al=.95;c.save();c.translate(x,y);c.scale(m.k||1,m.k||1);c.translate(-x,-y);
  if(m.t==='train'){var r1=20,r2=13,n1=14,n2=9,ang=m.ph,x2=x+Math.cos(ang)*(r1+r2-2),y2=y+Math.sin(ang)*(r1+r2-2),r3=9,x3=x2+Math.cos(ang+1.3)*(r2+r3-1.5),y3=y2+Math.sin(ang+1.3)*(r2+r3-1.5);
   gear(c,x,y,r1,n1,w,al);gear(c,x2,y2,r2,n2,-w*n1/n2+Math.PI/n2,al);gear(c,x3,y3,r3,6,w*n1/6,al*.9);}
  else if(m.t==='crank'){var cr=12,ax=x-14,ay=y,px=ax+Math.cos(w)*cr,py=ay+Math.sin(w)*cr,Lr=34,sx2=px+Math.sqrt(Math.max(1,Lr*Lr-(py-ay)*(py-ay))),sy2=ay;
   gear(c,ax,ay,cr+5,12,w,al*.8);c.strokeStyle=rgba(G,al*.35);c.lineWidth=7;c.beginPath();c.moveTo(ax+cr+12,ay);c.lineTo(ax+cr+Lr+26,ay);c.stroke();   /* glissière */
   c.strokeStyle=rgba(Wc,al*.7);c.lineWidth=1.6;c.beginPath();c.moveTo(px,py);c.lineTo(sx2,sy2);c.stroke();   /* bielle */
   c.fillStyle=rgba(G,al*.45);c.fillRect(sx2-6,sy2-5,12,10);c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1;c.strokeRect(sx2-6,sy2-5,12,10);
   c.fillStyle=rgba(Wc,al*.85);c.beginPath();c.arc(px,py,2,0,6.2832);c.fill();}
  else if(m.t==='escape'){var tick=Math.floor(t*.025*m.s),fr=(t*.025*m.s)%1,ea=(tick+Math.min(1,fr*4))*(6.2832/15),sw=Math.sin(t*.025*m.s*Math.PI)*.35;
   gear(c,x,y+8,16,15,ea*m.d,al);var Lp=38,ax2=x,ay2=y-18;   /* roue d'échappement et ancre */
   c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1.2;c.beginPath();c.moveTo(ax2,ay2);c.lineTo(ax2+Math.sin(sw)*Lp,ay2+Math.cos(sw)*Lp);c.stroke();
   c.strokeStyle=rgba(G,al*.7);c.lineWidth=2;c.beginPath();c.moveTo(ax2+Math.sin(sw+.7)*14,ay2+Math.cos(sw+.7)*14);c.quadraticCurveTo(ax2,ay2-6,ax2+Math.sin(sw-.7)*14,ay2+Math.cos(sw-.7)*14);c.stroke();
   var bx=ax2+Math.sin(sw)*Lp,by=ay2+Math.cos(sw)*Lp,g1=c.createRadialGradient(bx,by,0,bx,by,7);g1.addColorStop(0,rgba(Wc,al*.8));g1.addColorStop(1,rgba(G,0));c.fillStyle=g1;c.beginPath();c.arc(bx,by,7,0,6.2832);c.fill();}
  else if(m.t==='cam'){var cx3=x,cy3=y+10,ca=w;c.strokeStyle=rgba(G,al*.55);c.lineWidth=1;c.beginPath();
   for(var k=0;k<=40;k++){var u=k/40*6.2832,rr=13+7*Math.max(0,Math.cos(u)),X=cx3+Math.cos(u+ca)*rr,Y=cy3+Math.sin(u+ca)*rr;if(k)c.lineTo(X,Y);else c.moveTo(X,Y);}c.stroke();
   var lift=0;for(var k2=0;k2<40;k2++){var u2=k2/40*6.2832;if(Math.abs(Math.sin(u2+ca)+1)<.08){lift=7*Math.max(0,Math.cos(u2));}}
   var top=cy3-13-7*Math.max(0,Math.cos(-Math.PI/2-ca));c.strokeStyle=rgba(Wc,al*.6);c.lineWidth=1.4;c.beginPath();c.moveTo(cx3,top);c.lineTo(cx3,top-26);c.stroke();
   c.strokeStyle=rgba(G,al*.3);c.lineWidth=5;c.beginPath();c.moveTo(cx3-8,cy3-40);c.lineTo(cx3+8,cy3-40);c.stroke();
   c.fillStyle=rgba(Wc,al*.7);c.beginPath();c.arc(cx3,top,2.2,0,6.2832);c.fill();c.beginPath();c.arc(cx3,cy3,2,0,6.2832);c.fill();}
  c.restore();}
 c.restore();}
/* ══ R156 — ÉLÉMENTS QUANTIQUES REDESSINÉS (Simon : « pas mal de confusion ») ══
   Une seule langue, l'optique quantique ; chaque paire intriquée a SA couleur, et tout ce qu'elle commande porte cette couleur :
   · qubit : petite sphère de Bloch (équateur, méridien) + flèche de spin ↑/↓ = l'état ; anneau pointillé = rayon de contact ;
   · lien : double hélice de lumière entre les deux qubits, signe « = » (même état) ou « ≠ » (états opposés) au milieu ;
     une onde parcourt le lien au moment du basculement ;
   · porte : barrière de champ (hachures qui ondulent) quand elle est fermée, deux bornes et un fantôme pointillé quand elle
     est ouverte ; un fil fin la relie au qubit qui la commande ;
   · séparatrice (superposition) : cristal en losange à lame semi‑réfléchissante, franges d'interférence dans la zone ;
   · détecteur : diaphragme à six lames qui s'ouvre quand une superposition existe (il attend une mesure), s'éteint sinon ;
   · ralentisseur : cadran doré, aiguilles lentes, anneaux qui battent au ralenti. */
var QCOL=[[90,220,255],[190,140,255],[255,128,196],[120,255,190]],QEV=[];
function qon(){if(!QEV.on&&window.BUS){QEV.on=1;BUS.on('quantum.entangle',function(e){QEV.push({t:now(),e:e});});}}
function qubit(c,x,y,col,up,act,t,pul){var r=10;c.save();c.globalCompositeOperation='lighter';
 var g=c.createRadialGradient(x,y,0,x,y,r*2.4);g.addColorStop(0,rgba(col,.35+.3*pul));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r*2.4,0,6.2832);c.fill();
 c.strokeStyle=rgba(col,.85);c.lineWidth=1.3;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
 c.strokeStyle=rgba(col,.45);c.lineWidth=.8;c.beginPath();c.ellipse(x,y,r,r*.32,0,0,6.2832);c.stroke();c.beginPath();c.ellipse(x,y,r*.32*Math.abs(Math.cos(t*.02))+1,r,0,0,6.2832);c.stroke();
 var d=up?-1:1;c.strokeStyle=rgba([255,255,255],.95);c.lineWidth=1.8;c.beginPath();c.moveTo(x,y-d*6);c.lineTo(x,y+d*7);c.stroke();
 c.beginPath();c.moveTo(x-3.5,y+d*3.5);c.lineTo(x,y+d*7.5);c.lineTo(x+3.5,y+d*3.5);c.stroke();
 c.setLineDash([2,4]);c.lineDashOffset=-t*.3;c.strokeStyle=rgba(col,.35+.2*act);c.lineWidth=1;c.beginPath();c.arc(x,y,20,0,6.2832);c.stroke();c.setLineDash([]);   /* rayon de contact */
 if(pul>0){c.strokeStyle=rgba(col,pul*.8);c.lineWidth=1.5;c.beginPath();c.arc(x,y,r+(1-pul)*30,0,6.2832);c.stroke();}
 c.restore();}
function qent(c,lv,S0){qon();var t=now(),i,k;if(!lv.ent)return;
 for(i=0;i<lv.ent.length;i++){var e=lv.ent[i],st=(S0.ent&&S0.ent[i])||{on:false,pulse:0},col=QCOL[i%QCOL.length],opp=e[4]==='opp',pul=st.pulse||0;
  var ax=e[0],ay=e[1],bx=e[2],by=e[3],dx=bx-ax,dy=by-ay,L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;
  /* fils vers les portes commandées */
  (lv.gate||[]).forEach(function(g){if(g[4]!==i)return;var gx=(g[0]+g[2])/2,gy=(g[1]+g[3])/2,na=Math.hypot(gx-ax,gy-ay)<Math.hypot(gx-bx,gy-by),sx=na?ax:bx,sy=na?ay:by;
   c.save();c.setLineDash([1.5,5]);c.lineDashOffset=-t*.4;c.strokeStyle=rgba(col,.32);c.lineWidth=1;c.beginPath();c.moveTo(sx,sy);c.quadraticCurveTo((sx+gx)/2+(gy-sy)*.15,(sy+gy)/2-(gx-sx)*.15,gx,gy);c.stroke();c.restore();});
  /* lien : double hélice ; l'onde de basculement court de la source vers l'autre qubit */
  var wave=-1;for(k=QEV.length-1;k>=0;k--){var q=QEV[k];if(t-q.t>40){QEV.splice(k,1);continue;}if(Math.abs(q.e.ax-ax)<1&&Math.abs(q.e.ay-ay)<1){var f0=(t-q.t)/40;wave=q.e.from?1-f0:f0;}}
  c.save();c.globalCompositeOperation='lighter';
  for(var h=0;h<2;h++){c.beginPath();for(k=0;k<=40;k++){var u=k/40,o=Math.sin(u*Math.PI*6+t*.05+h*Math.PI)*4*Math.sin(u*Math.PI),x=ax+dx*u+nx*o,y=ay+dy*u+ny*o;if(k)c.lineTo(x,y);else c.moveTo(x,y);}
   c.strokeStyle=rgba(col,(st.on?.5:.28));c.lineWidth=1;c.stroke();}
  if(wave>=0){var wx=ax+dx*wave,wy=ay+dy*wave,gw=c.createRadialGradient(wx,wy,0,wx,wy,12);gw.addColorStop(0,rgba([255,255,255],.9));gw.addColorStop(1,rgba(col,0));c.fillStyle=gw;c.beginPath();c.arc(wx,wy,12,0,6.2832);c.fill();}
  var mx=ax+dx/2,my=ay+dy/2;c.fillStyle='rgba(5,9,15,.75)';c.beginPath();c.arc(mx,my,7,0,6.2832);c.fill();c.strokeStyle=rgba(col,.8);c.lineWidth=1.2;c.beginPath();
  c.moveTo(mx-3.5,my-1.8);c.lineTo(mx+3.5,my-1.8);c.moveTo(mx-3.5,my+1.8);c.lineTo(mx+3.5,my+1.8);if(opp){c.moveTo(mx+2.5,my-4.5);c.lineTo(mx-2.5,my+4.5);}c.stroke();
  c.restore();
  qubit(c,ax,ay,col,st.on,1,t,pul);qubit(c,bx,by,col,opp?!st.on:st.on,1,t,pul);}}
function qgate(c,g,open,t){var col=QCOL[(g[4]||0)%QCOL.length],dx=g[2]-g[0],dy=g[3]-g[1],L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,nx=-uy,ny=ux,k;c.save();c.lineCap='round';
 if(!open){c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.22);c.lineWidth=10;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();
  c.strokeStyle=rgba(col,.75);c.lineWidth=1;c.beginPath();for(k=4;k<L-2;k+=5){var w=Math.sin(k*.4+t*.12)*1.5,px=g[0]+ux*k,py=g[1]+uy*k;c.moveTo(px+nx*(-5)+ux*w,py+ny*(-5)+uy*w);c.lineTo(px+nx*5-ux*w,py+ny*5-uy*w);}c.stroke();   /* barrière de champ */
  c.strokeStyle=rgba([235,250,255],.9);c.lineWidth=1.4;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();}
 else{c.setLineDash([2,6]);c.strokeStyle=rgba(col,.3);c.lineWidth=1;c.beginPath();c.moveTo(g[0],g[1]);c.lineTo(g[2],g[3]);c.stroke();c.setLineDash([]);}
 [[g[0],g[1]],[g[2],g[3]]].forEach(function(p){c.fillStyle=rgba(col,open?.5:.9);c.beginPath();c.arc(p[0],p[1],3.2,0,6.2832);c.fill();c.strokeStyle=rgba([255,255,255],.7);c.lineWidth=.8;c.stroke();});
 c.restore();}
function qsup(c,z,t){var col=QCOL[1],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,k;c.save();
 var g=c.createRadialGradient(cx,cy,0,cx,cy,Math.max(z[2],z[3])*.7);g.addColorStop(0,rgba(col,.14));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.16);c.lineWidth=1;   /* franges */
 for(k=-z[2];k<z[2]+z[3];k+=7){var o=(t*.25)%7;c.beginPath();c.moveTo(z[0]+k+o,z[1]);c.lineTo(z[0]+k+o-z[3]*.6,z[1]+z[3]);c.stroke();}
 c.restore();c.save();c.globalCompositeOperation='lighter';
 var R=12;c.strokeStyle=rgba(col,.9);c.lineWidth=1.3;c.beginPath();c.moveTo(cx,cy-R);c.lineTo(cx+R,cy);c.lineTo(cx,cy+R);c.lineTo(cx-R,cy);c.closePath();c.stroke();
 c.fillStyle=rgba(col,.18);c.fill();c.strokeStyle=rgba([255,255,255],.85);c.beginPath();c.moveTo(cx-R*.7,cy+R*.7*.0);c.lineTo(cx+R*.7,cy);c.stroke();   /* lame semi‑réfléchissante */
 var a=z[4]===undefined?.42:z[4];[-1,1].forEach(function(sg){var aa=Math.PI/2+sg*a;c.strokeStyle=rgba(col,.55);c.lineWidth=1;c.setLineDash([3,4]);c.lineDashOffset=-t*.4;c.beginPath();c.moveTo(cx,cy+R);c.lineTo(cx+Math.cos(aa)*R*2.6,cy+R+Math.sin(aa)*R*2.6);c.stroke();c.setLineDash([]);});
 c.strokeStyle=rgba(col,.35);c.lineWidth=1;c.beginPath();c.roundRect?c.roundRect(z[0]+.5,z[1]+.5,z[2]-1,z[3]-1,8):c.rect(z[0],z[1],z[2],z[3]);c.stroke();
 c.restore();}
function qdet(c,d,armed,t,lv){var col=d[3]!=null?QCOL[d[3]%QCOL.length]:QCOL[0],x=d[0],y=d[1],r=d[2],k,op=armed?.55+.15*Math.sin(t*.1):.18;c.save();c.globalCompositeOperation='lighter';
 var g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(col,armed?.22:.06));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();
 c.strokeStyle=rgba(col,armed?.85:.4);c.lineWidth=1.3;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
 for(k=0;k<24;k++){var a=k/24*6.2832;c.globalAlpha=(k%6===0)?1:.5;c.beginPath();c.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r);c.lineTo(x+Math.cos(a)*(r-(k%6===0?5:2.5)),y+Math.sin(a)*(r-(k%6===0?5:2.5)));c.stroke();}c.globalAlpha=1;
 var ap=r*op,rot=t*.01;c.strokeStyle=rgba(col,armed?.75:.35);c.lineWidth=1;   /* diaphragme */
 for(k=0;k<6;k++){var a1=rot+k*1.0472;c.beginPath();c.moveTo(x+Math.cos(a1)*ap,y+Math.sin(a1)*ap);c.lineTo(x+Math.cos(a1+1.0472+.5)*(r-6),y+Math.sin(a1+1.0472+.5)*(r-6));c.stroke();}
 c.beginPath();for(k=0;k<=6;k++){var a2=rot+k*1.0472;if(k)c.lineTo(x+Math.cos(a2)*ap,y+Math.sin(a2)*ap);else c.moveTo(x+Math.cos(a2)*ap,y+Math.sin(a2)*ap);}c.stroke();
 c.fillStyle=rgba([255,255,255],armed?.9:.4);c.beginPath();c.arc(x,y,2,0,6.2832);c.fill();
 if(lv&&d[3]!=null&&lv.ent&&lv.ent[d[3]]){var e=lv.ent[d[3]],na=Math.hypot(e[0]-x,e[1]-y)<Math.hypot(e[2]-x,e[3]-y),ex=na?e[0]:e[2],ey=na?e[1]:e[3];   /* fil de commande : la mesure bascule cette paire */
  c.setLineDash([1.5,5]);c.lineDashOffset=-t*.4;c.strokeStyle=rgba(col,.4);c.lineWidth=1;c.beginPath();c.moveTo(x,y);c.lineTo(ex,ey);c.stroke();c.setLineDash([]);}
 c.restore();}
function qtdil(c,z,t){var G=[255,206,110],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,R=Math.min(z[2],z[3])*.5,k;c.save();
 var g=c.createRadialGradient(cx,cy,0,cx,cy,Math.max(z[2],z[3])*.75);g.addColorStop(0,rgba(G,.13));g.addColorStop(1,rgba(G,.02));c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 c.globalCompositeOperation='lighter';for(k=0;k<3;k++){var ph=((t*.004+k/3)%1);c.strokeStyle=rgba(G,.3*(1-ph));c.lineWidth=1;c.beginPath();c.arc(cx,cy,R*(.3+ph*.9),0,6.2832);c.stroke();}   /* battement ralenti */
 c.strokeStyle=rgba(G,.55);c.lineWidth=1;c.beginPath();c.arc(cx,cy,14,0,6.2832);c.stroke();for(k=0;k<12;k++){var a=k*.5236;c.beginPath();c.moveTo(cx+Math.cos(a)*11,cy+Math.sin(a)*11);c.lineTo(cx+Math.cos(a)*14,cy+Math.sin(a)*14);c.stroke();}
 c.strokeStyle=rgba([255,240,210],.9);c.lineWidth=1.4;c.beginPath();c.moveTo(cx,cy);c.lineTo(cx+Math.cos(t*.006-1.57)*10,cy+Math.sin(t*.006-1.57)*10);c.moveTo(cx,cy);c.lineTo(cx+Math.cos(t*.0005)*6.5,cy+Math.sin(t*.0005)*6.5);c.stroke();
 c.setLineDash([2,5]);c.strokeStyle=rgba(G,.35);c.beginPath();c.roundRect?c.roundRect(z[0]+.5,z[1]+.5,z[2]-1,z[3]-1,10):c.rect(z[0],z[1],z[2],z[3]);c.stroke();c.setLineDash([]);
 c.restore();}
/* ══ R156 — APOTHÉOSE : fin du dernier niveau ══ Une onde part du bassin ; une gerbe par monde traversé (onze feux, chacun aux
   couleurs de son monde) ; les onze mondes s'allument en constellation et se relient ; le message de fin se lève lentement. */
var FIN=null;
function finale(c,age,title,sub,cup){var i,k,t=age;if(!FIN||age<FIN.last){FIN={p:[],r:[],last:0,fired:0};}FIN.last=age;
 var cx=cup?cup[0]+cup[2]/2:180,cy=cup?cup[1]-24:400;
 /* fusées : une par monde */
 while(FIN.fired<11&&age>=12+FIN.fired*20){var w=FIN.fired+1,pal=PAL_W[w]||PAL_W[1],tx=50+((FIN.fired*137)%260),ty=70+((FIN.fired*83)%170);FIN.r.push({x:cx,y:cy,tx:tx,ty:ty,l:0,pal:pal});FIN.fired++;}
 c.save();c.globalCompositeOperation='lighter';
 for(i=FIN.r.length-1;i>=0;i--){var r=FIN.r[i];r.l+=1/26;var e=1-Math.pow(1-Math.min(1,r.l),2),x=cx+(r.tx-cx)*e,y=cy+(r.ty-cy)*e;
  c.fillStyle=rgba(C.white,.9);c.beginPath();c.arc(x,y,1.6,0,6.2832);c.fill();c.strokeStyle=rgba(r.pal[0],.45);c.lineWidth=1.2;c.beginPath();c.moveTo(x,y);c.lineTo(x-(r.tx-cx)*.06,y-(r.ty-cy)*.06);c.stroke();
  if(r.l>=1){for(k=0;k<64;k++){var a=k/64*6.2832+Math.random()*.1,sp=1.2+Math.random()*2.6;FIN.p.push({x:r.tx,y:r.ty,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,l:1,c:r.pal[k%r.pal.length],tr:[]});}FIN.r.splice(i,1);}}
 for(i=FIN.p.length-1;i>=0;i--){var q=FIN.p[i];q.tr.push([q.x,q.y]);if(q.tr.length>6)q.tr.shift();q.vx*=.985;q.vy=q.vy*.985+.035;q.x+=q.vx;q.y+=q.vy;q.l-=.011;if(q.l<=0){FIN.p.splice(i,1);continue;}
  c.strokeStyle=rgba(q.c,q.l*.55);c.lineWidth=1.1;c.beginPath();c.moveTo(q.tr[0][0],q.tr[0][1]);c.lineTo(q.x,q.y);c.stroke();c.fillStyle=rgba(C.white,q.l*.8);c.fillRect(q.x-.7,q.y-.7,1.4,1.4);}
 /* onde du bassin */
 for(k=0;k<3;k++){var ra=(age-k*14);if(ra>0&&ra<90){c.strokeStyle=rgba(C.goal,.5*(1-ra/90));c.lineWidth=2*(1-ra/90)+.4;c.beginPath();c.arc(cx,cy,ra*3,0,6.2832);c.stroke();}}
 /* constellation des onze mondes */
 var on=Math.max(0,Math.min(11,Math.floor((age-70)/12))),R=118,ox=180,oy=200,pts=[];
 for(k=0;k<11;k++){var aa=-Math.PI/2+k/11*6.2832;pts.push([ox+Math.cos(aa)*R,oy+Math.sin(aa)*R*.82]);}
 c.lineWidth=.8;for(k=1;k<on;k++){c.strokeStyle=rgba((PAL_W[k+1]||PAL_W[1])[0],.35);c.beginPath();c.moveTo(pts[k-1][0],pts[k-1][1]);c.lineTo(pts[k][0],pts[k][1]);c.stroke();}
 if(on>=11){var cl=Math.min(1,(age-202)/30);c.strokeStyle=rgba(C.white,.3*cl);c.beginPath();c.moveTo(pts[10][0],pts[10][1]);c.lineTo(pts[0][0],pts[0][1]);c.stroke();}
 for(k=0;k<on;k++){var col=(PAL_W[k+1]||PAL_W[1])[0],tw=.75+.25*Math.sin(age*.12+k),g=c.createRadialGradient(pts[k][0],pts[k][1],0,pts[k][0],pts[k][1],14);
  g.addColorStop(0,rgba(C.white,.95*tw));g.addColorStop(.3,rgba(col,.6*tw));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(pts[k][0],pts[k][1],14,0,6.2832);c.fill();}
 c.restore();
 /* message */
 var ta=Math.max(0,Math.min(1,(age-150)/45));if(ta>0){c.save();c.textAlign='center';c.textBaseline='middle';
  c.fillStyle='rgba(5,7,13,'+(.45*ta).toFixed(3)+')';c.fillRect(0,oy-34,360,72);
  c.shadowColor='rgba(255,216,90,.9)';c.shadowBlur=18*ta;c.fillStyle='rgba(255,246,222,'+ta.toFixed(3)+')';c.font='600 28px "Space Grotesk", system-ui, sans-serif';
  if(c.letterSpacing!==undefined)c.letterSpacing='4px';c.fillText(title,180,oy-8+(1-ta)*10);c.shadowBlur=0;
  var tb=Math.max(0,Math.min(1,(age-200)/45));c.fillStyle='rgba(220,236,255,'+(.9*tb).toFixed(3)+')';c.font='500 11.5px "Space Grotesk", system-ui, sans-serif';if(c.letterSpacing!==undefined)c.letterSpacing='1px';
  c.fillText(sub,180,oy+22,340);c.restore();}
}
function back(c,lv){
 if(!D.busOn&&typeof BUS!=='undefined'){D.busOn=true;
  BUS.on('ball.bounce',function(e){if(D.wd===2&&e.v>1.5)spawnTrack(e.x,e.y,Math.atan2(-e.ny,-e.nx)+Math.PI,3+e.v*.15,true);});
  BUS.on('ball.boost',function(e){D.flash.push({x:e.x,y:e.y,life:1});});
  BUS.on('ball.impact',impactFx);BUS.on('ball.bounce',impactFx);
  BUS.on('ball.tunnel',function(e){TUN.push({x:e.x,y:e.y,l:1});});}
 if(D.key!==lv.idx)compose(lv);
 var t=now(),i,b=(typeof S!=='undefined'&&S.ball)?S.ball:{x:-99,y:-99};
 c.save();c.globalCompositeOperation='screen';
 c.globalAlpha=.8+.18*Math.sin(t*.012);c.drawImage(D.neb[0],Math.sin(t*.0022)*12-8,Math.cos(t*.0017)*9-6,VW+16,VH+12);
 c.globalAlpha=.5+.2*Math.sin(t*.009+1.3);c.drawImage(D.neb[1],-Math.sin(t*.0015)*16-12,Math.sin(t*.0021)*11-10,VW+24,VH+20);c.restore();
 c.save();c.globalCompositeOperation='lighter';
 for(i=0;i<D.dust.length;i++){var d=D.dust[i];d.x+=d.vx*d.z;d.y+=d.vy*d.z;
  var dx=d.x-b.x,dy=d.y-b.y,dd=dx*dx+dy*dy;if(dd<1600&&dd>1){var r=Math.sqrt(dd),f=(1-r/40)*.9*d.z;d.x+=dx/r*f;d.y+=dy/r*f;}
  if(d.y<-4)d.y=VH+4;if(d.y>VH+4)d.y=-4;if(d.x<-4)d.x=VW+4;if(d.x>VW+4)d.x=-4;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),a=(.12+.5*d.z)*tw,sz=.5+d.z*1.3;c.fillStyle=rgba(d.col,a);c.fillRect(d.x-sz/2,d.y-sz/2,sz,sz);}
 c.restore();
 /* R88 : aucun motif de décor dans la zone de réussite (ni voiles, ni anneaux, ni hélices) — on les masque autour du bassin */
 var cpz=lv.cup;c.save();if(cpz){c.beginPath();c.rect(-20,-20,VW+40,VH+40);c.rect(cpz[0]-16,cpz[1]-78,cpz[2]+32,96);c.clip('evenodd');}
 veils(c);
 if(D.wd===3)torusCells(c,VW*.62,VH*.30,78,11,.2);
 if(D.wd===8)ferro2(c,lv);
 if(D.mech&&D.mech.length)mechDeco(c);
 if(D.wd===3){drawRing(c);synchro(c);}
 else if(D.wd===2){
  if(t%70===0){var side=Math.floor(rnd(t)*3),x=side===0?-5:side===1?VW+5:rnd(t*1.7)*VW,y=side===2?VH+5:VH*.3+rnd(t*2.3)*VH*.6;
   spawnTrack(x,y,Math.atan2(VH*.5-y,VW*.5-x)+(rnd(t*3)-.5),2.2+rnd(t*4)*1.6,false);}
  c.save();c.globalCompositeOperation='lighter';
  for(i=0;i<D.tracks.length;i++){var tr=D.tracks[i];tr.age++;
   if(tr.v>.25){tr.a+=tr.q*tr.k*(3/tr.v);tr.v*=.985;tr.x+=Math.cos(tr.a)*tr.v;tr.y+=Math.sin(tr.a)*tr.v;if(tr.age%2===0)tr.pts.push([tr.x,tr.y]);if(tr.pts.length>140)tr.pts.shift();}
   var fd=Math.min(1,(tr.life-tr.age)/60)*Math.min(1,tr.age/6);
   for(var k=0;k<tr.pts.length;k++){c.fillStyle=rgba(tr.col,fd*(.25+.65*k/tr.pts.length)*.8);c.beginPath();c.arc(tr.pts[k][0],tr.pts[k][1],.7+(k%3===0?.6:0),0,6.2832);c.fill();}}
  D.tracks=D.tracks.filter(function(q){return q.age<q.life;});
  for(i=0;i<D.bubbles.length;i++){var bb=D.bubbles[i];bb.y-=bb.sp;bb.x+=Math.sin(t*.04+bb.ph)*.25;if(bb.y<-5){bb.y=VH+5;bb.x=rnd(t+bb.ph*99)*VW;}
   c.strokeStyle=rgba(C.white,.2);c.lineWidth=.7;c.beginPath();c.arc(bb.x,bb.y,bb.r,0,6.2832);c.stroke();}
  c.restore();
 }else{
  if(D.ghost)helix(c,D.ghost.x0,D.ghost.y0,D.ghost.x1,D.ghost.y1,30,2,.011,D.pal[0],D.pal[D.pal.length-1],.14,80);
  for(i=0;i<D.hel.length;i++){var h=D.hel[i];helix(c,h.x0,h.y0,h.x1,h.y1,h.amp,h.turns,h.sp,h.a,h.b,h.al);}
 }
 c.restore();
}

/* ============================ ZONES INTERDITES ============================ */
function nd(c,lv){var t=now();for(var i=0;i<lv.nd.length;i++){var r=lv.nd[i];
 c.save();c.beginPath();c.rect(r[0],r[1],r[2],r[3]);c.clip();var br=.5+.5*Math.sin(t*.03+i);var gz=c.createLinearGradient(r[0],r[1],r[0]+r[2],r[1]+r[3]);gz.addColorStop(0,'rgba(150,166,184,.20)');gz.addColorStop(1,'rgba(110,124,142,.13)');c.fillStyle=gz;c.fillRect(r[0],r[1],r[2],r[3]);
 c.strokeStyle='rgba(206,224,238,'+(.38+.10*br).toFixed(3)+')';c.lineWidth=1.8;var o=(t*.35)%14;c.beginPath();
 for(var k=-520;k<520;k+=14){c.moveTo(r[0]+k+o,r[1]);c.lineTo(r[0]+k+o+520,r[1]+520);}c.stroke();c.restore();
 c.save();c.strokeStyle='rgba(206,224,238,.5)';c.lineWidth=1.2;c.setLineDash([2,5]);c.strokeRect(r[0]+2.5,r[1]+2.5,r[2]-5,r[3]-5);c.setLineDash([]);c.restore();
 c.save();c.strokeStyle='rgba(214,230,242,.9)';c.lineWidth=2;var cc=12,cs=[[r[0],r[1],1,1],[r[0]+r[2],r[1],-1,1],[r[0],r[1]+r[3],1,-1],[r[0]+r[2],r[1]+r[3],-1,-1]];
 for(k=0;k<4;k++){var q=cs[k];if(q[0]<=0||q[0]>=VW||q[1]<=0||q[1]>=VH)continue;c.beginPath();c.moveTo(q[0]+q[2]*cc,q[1]);c.lineTo(q[0],q[1]);c.lineTo(q[0],q[1]+q[3]*cc);c.stroke();}
 c.restore();}}

/* ============================ STRUCTURES ============================ */
function beam(c,s,accent){var g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,'#3A5068');gr.addColorStop(1,'#18222E');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.strokeStyle='rgba(169,200,232,.95)';c.lineWidth=1.4;c.beginPath();var ns=Math.max(2,Math.round(g.len/13));
 for(var i=0;i<=ns;i++){q=i/ns*g.len;var off=(i%2?Dp-2.5:2.5),x=A[0]+g.ux*q+g.nx*off,y=A[1]+g.uy*q+g.ny*off;if(i)c.lineTo(x,y);else c.moveTo(x,y);}c.stroke();
 c.strokeStyle='rgba(191,212,228,.8)';c.beginPath();c.moveTo(A2[0]-g.nx*1.5,A2[1]-g.ny*1.5);c.lineTo(B2[0]-g.nx*1.5,B2[1]-g.ny*1.5);c.stroke();
 c.fillStyle='#9FB3C4';for(q=10;q<g.len-6;q+=34){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.5,A[1]+g.uy*q+g.ny*Dp*.5,1.5,0,6.2832);c.fill();}
 c.lineCap='round';c.strokeStyle=accent||'#A9C3D6';c.lineWidth=3.4;c.shadowColor=accent||'rgba(169,195,214,.6)';c.shadowBlur=accent?10:5;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle='rgba(241,244,246,.75)';c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function plate(c,s){var t=now(),g=geom(s),Dp=12,A=[s[0],s[1]],B=[s[2],s[3]],A2=[A[0]+g.nx*Dp,A[1]+g.ny*Dp],B2=[B[0]+g.nx*Dp,B[1]+g.ny*Dp],heat=.6+.4*Math.sin(t*.05+s[0]*.02),q;
 c.save();c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=10;c.shadowOffsetY=3;
 var gr=c.createLinearGradient(A[0],A[1],A2[0],A2[1]);gr.addColorStop(0,rgba(C.bounce,.9));gr.addColorStop(.35,'#6A2C12');gr.addColorStop(1,'#1A0C08');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B2[0],B2[1]);c.lineTo(A2[0],A2[1]);c.closePath();c.fill();c.shadowColor='transparent';
 c.save();c.clip();c.strokeStyle=rgba(C.bounce,.28*heat);c.lineWidth=2;
 for(q=((t*.4)%14)-14;q<g.len+14;q+=14){var x=A[0]+g.ux*q,y=A[1]+g.uy*q;c.beginPath();c.moveTo(x,y);c.lineTo(x+g.nx*Dp+g.ux*5,y+g.ny*Dp+g.uy*5);c.stroke();}c.restore();
 c.fillStyle=rgba(C.reward,.9);for(q=10;q<g.len-6;q+=30){c.beginPath();c.arc(A[0]+g.ux*q+g.nx*Dp*.6,A[1]+g.uy*q+g.ny*Dp*.6,1.6,0,6.2832);c.fill();}
 c.lineCap='round';c.shadowColor=rgba(C.bounce,1);c.shadowBlur=10+8*heat;c.strokeStyle=rgba(C.bounce,1);c.lineWidth=3.6;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.85);c.lineWidth=1.1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(B[0]-g.nx,B[1]-g.ny);c.stroke();c.restore();}

function boostPad(c,s){var t=now(),g=geom(s),A=[s[0],s[1]],dx=s[2]-s[0],dy=s[3]-s[1],len=g.len,ux=dx/len,uy=dy/len,Dp=11,i;
 var fl=0;for(i=0;i<D.flash.length;i++){var f=D.flash[i],pr=((f.x-A[0])*ux+(f.y-A[1])*uy);var pd=Math.abs((f.x-A[0])*g.nx+(f.y-A[1])*g.ny);if(pr>-15&&pr<len+15&&pd<25)fl=Math.max(fl,f.life);}
 c.save();
 // longeron sombre derrière la surface
 var gr=c.createLinearGradient(A[0],A[1],A[0]+g.nx*Dp,A[1]+g.ny*Dp);gr.addColorStop(0,'#3B2A5E');gr.addColorStop(1,'#140E22');
 c.fillStyle=gr;c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.lineTo(s[2]+g.nx*Dp,s[3]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 // chaîne de cellules (cavité RF) : une onde les parcourt dans le sens de la poussée
 var nc=Math.max(2,Math.floor(len/11)),step=len/nc,ang=Math.atan2(uy,ux);
 for(i=0;i<nc;i++){var q=(i+.5)*step,x=A[0]+ux*q+g.nx*Dp*.5,y=A[1]+uy*q+g.ny*Dp*.5,wave=.5+.5*Math.sin(i*.9-t*.22),e=Math.max(wave*.8,fl);
  c.save();c.translate(x,y);c.rotate(ang);
  var g2=c.createRadialGradient(0,0,0,0,0,6);g2.addColorStop(0,rgba(C.white,.25+.55*e));g2.addColorStop(.5,rgba(C.boost,.35+.5*e));g2.addColorStop(1,rgba(C.boost,.05));
  c.fillStyle=g2;c.beginPath();c.ellipse(0,0,step*.46,5,0,0,6.2832);c.fill();
  c.strokeStyle=rgba(C.boost,.6+.4*e);c.lineWidth=.9;c.stroke();
  c.strokeStyle=rgba(C.white,.35+.5*e);c.lineWidth=1;c.beginPath();c.moveTo(-1.5,-2.2);c.lineTo(1.5,0);c.lineTo(-1.5,2.2);c.stroke();   // chevron = sens de la poussée
  c.restore();}
 // surface de roulement exactement sur la ligne de collision
 c.lineCap='round';c.shadowColor=rgba(C.boost,1);c.shadowBlur=10+14*fl;c.strokeStyle=rgba(C.boost,1);c.lineWidth=3.4;
 c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(s[2],s[3]);c.stroke();c.shadowBlur=0;
 c.strokeStyle=rgba(C.white,.8);c.lineWidth=1;c.beginPath();c.moveTo(A[0]-g.nx,A[1]-g.ny);c.lineTo(s[2]-g.nx,s[3]-g.ny);c.stroke();
 c.restore();}
function spikes(c,s){var g=geom(s),Dp=7,A=[s[0],s[1]],B=[s[2],s[3]],i=0;
 c.save();c.fillStyle='#1B0F14';c.beginPath();c.moveTo(A[0],A[1]);c.lineTo(B[0],B[1]);c.lineTo(B[0]+g.nx*Dp,B[1]+g.ny*Dp);c.lineTo(A[0]+g.nx*Dp,A[1]+g.ny*Dp);c.closePath();c.fill();
 c.strokeStyle='rgba(255,82,82,.35)';c.lineWidth=1;c.stroke();c.shadowColor='#FF5252';c.shadowBlur=8;
 for(var q=4;q<g.len-3;q+=8.5,i++){var hh=7+rnd(i+s[0])*7,w=3+rnd(i*3+s[1])*1.6,x=A[0]+g.ux*q,y=A[1]+g.uy*q,tx=x-g.nx*hh,ty=y-g.ny*hh;
  var gr=c.createLinearGradient(x,y,tx,ty);gr.addColorStop(0,'#5A1418');gr.addColorStop(1,'#FF7A7A');
  c.fillStyle=gr;c.beginPath();c.moveTo(x-g.ux*w,y-g.uy*w);c.lineTo(tx,ty);c.lineTo(x+g.ux*w,y+g.uy*w);c.closePath();c.fill();}
 c.restore();}

function isCupWall(lv,s){if(!lv.cup)return false;var x=lv.cup[0],y=lv.cup[1],w=lv.cup[2];
 return (s[1]===y&&s[3]===y&&s[0]===x&&s[2]===x+w)||((s[0]===x||s[0]===x+w)&&s[1]===y&&s[2]===s[0]&&s[3]===y-56);}

function cupGlow(c,lv){var z=lv.zone,t=now(),pul=.5+.5*Math.sin(t*.05);if(!z)return;
 c.save();var gr=c.createLinearGradient(0,z[1],0,z[1]+z[3]);gr.addColorStop(0,'rgba(155,235,75,0)');gr.addColorStop(1,'rgba(155,235,75,'+(.16+.08*pul)+')');
 c.fillStyle=gr;c.fillRect(z[0],z[1],z[2],z[3]);c.strokeStyle='rgba(200,255,141,.55)';c.lineWidth=1.4;c.beginPath();
 for(var x=z[0]+2;x<=z[0]+z[2]-2;x+=3){var y=z[1]+z[3]-9+Math.sin(x*.12+t*.08)*1.6;if(x===z[0]+2)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();
 for(var i=0;i<5;i++){var px=z[0]+8+rnd(i)*(z[2]-16),py=z[1]+z[3]-((t*.4+rnd(i+9)*60)%44);c.fillStyle='rgba(155,235,75,.5)';c.beginPath();c.arc(px,py,1.2,0,6.2832);c.fill();}
 c.restore();}

function supports(c,lv){var deg={},i,s,k,p,j;
 for(i=0;i<lv.walls.length;i++){s=lv.walls[i];if(s[5]===1)continue;   /* les pièces courbes n'ont pas de jointures visibles */
  var e=[[s[0],s[1]],[s[2],s[3]]];for(j=0;j<2;j++){k=Math.round(e[j][0])+','+Math.round(e[j][1]);deg[k]=(deg[k]||0)+1;}}
 for(i=0;i<(lv.w||[]).length;i++){s=lv.w[i];if(s[4]!==0)continue;var g=geom(s),ends=[[s[0],s[1]],[s[2],s[3]]];
  for(j=0;j<2;j++){p=ends[j];if(p[0]<8||p[0]>VW-8)continue;k=Math.round(p[0])+','+Math.round(p[1]);
   if(p[1]<300){c.strokeStyle='rgba(138,151,166,.22)';c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]-2);c.lineTo(p[0],0);c.stroke();
    c.fillStyle='#8A97A6';c.beginPath();c.arc(p[0],p[1]-3,2,0,6.2832);c.fill();}
   else if(p[1]<455&&deg[k]<2){var x0=p[0]-3.5,y0=p[1]+g.ny*10,gp=c.createLinearGradient(0,y0,0,VH);gp.addColorStop(0,rgba(C.matter,.30));gp.addColorStop(1,rgba(C.matter,0));
    c.strokeStyle=gp;c.lineWidth=.8;c.beginPath();c.moveTo(x0,y0);c.lineTo(x0,VH);c.moveTo(x0+7,y0);c.lineTo(x0+7,VH);
    for(var y=y0,n=0;y<VH;y+=12,n++){c.moveTo(n%2?x0:x0+7,y);c.lineTo(n%2?x0+7:x0,y+12);}c.stroke();}}}   /* pylône : une colonne de lumière qui s'éteint vers le bas */
 /* les jonctions sont dessinées par la bibliothèque de connecteurs (joints) */}

/* murs fixes : renvoie la liste des segments que le rendu d'origine doit encore dessiner (élan, glace…) */
function fixed(c,segs,lv){var rest=[],i,s;cupGlow(c,lv);supports(c,lv);
 for(i=0;i<segs.length;i++){s=segs[i];
  if(s[4]===2)spikes(c,s);else if(s[4]===1)curve(c,[[s[0],s[1]],[s[2],s[3]]],1,{noHang:1});else if(s[4]===3)curve(c,[[s[0],s[1]],[s[2],s[3]]],3,{noHang:1});
  else if(s[4]===0){if(isCupWall(lv,s))curve(c,[[s[0],s[1]],[s[2],s[3]]],0,{noHang:1,accent:C.goal});else curve(c,[[s[0],s[1]],[s[2],s[3]]],0,{noHang:1});}
  else if(s[4]===4)curve(c,[[s[0],s[1]],[s[2],s[3]]],4,{noHang:1});else rest.push(s);}
 joints(c,segs,lv);
 drawImpacts(c);
 return rest;}

/* ══ JONCTION ADAPTATIVE UNIVERSELLE (R87) ══
   Toute rencontre de pièces — bouts qui se touchent (L, Y, étoile), bout posé sur le corps d'une autre (T), pièces qui se
   CROISENT (X) — devient un NŒUD. Un nœud est décrit par ses BRAS (une direction par pièce qui en part ; une pièce qui
   traverse donne deux bras opposés). Le dessin s'adapte à n'importe quel nombre de bras et d'angles :
   · chaque bras reçoit un MANCHON (bague serrée sur la pièce, deux anneaux, un boulon) ;
   · le cœur est la ENVELOPPE CONVEXE des manchons : une plaque d'acier qui épouse exactement la géométrie de la rencontre
     (ombre portée, dégradé, liseré, gorge intérieure) ;
   · au centre, un moyeu boulonné ; pour un croisement, deux traits de soudure marquent l'assemblage.
   Bouts libres : EMBOUT ; bouts contre un bord de l'écran : PLATINE murale. Les nœuds des pièces fixes sont calculés une
   fois par niveau (cache), les parois mobiles n'en ont pas. */
/* ══ CHOCS (R90) — petite bibliothèque d'animations d'impact, graduée par la force du choc (vitesse normale v) ══
   · effleurement (v < 1,6)  : trois grains de lumière ;
   · choc léger   (1,6–3)    : gerbe de poussière lumineuse très fine le long de la surface + micro‑éclat ;
   · choc moyen   (3–5)      : gerbe plus dense + 1 à 2 arcs électriques qui crépitent + anneau de choc ;
   · choc fort    (> 5)      : gerbe dense et longue + 3 à 4 arcs + onde de choc + éclat en étoile.
   Couleur : la matière touchée (rebond = ambre, tapis = violet, glace = givre, sinon cyan) mêlée de blanc. */
var IMP={dust:[],arcs:[],rings:[],stars:[]};
function impactFx(e){if(!e||!(e.v>.9))return;var v=e.v,m=e.mat,A=m===1?C.bounce:m===3?C.boost:m===4?[214,243,255]:C.matter,
 tx=-e.ny,ty=e.nx,lvl=v<1.6?0:v<3?1:v<5?2:3,n=[3,9,16,26][lvl],i;
 for(i=0;i<n;i++){var side=Math.random()<.5?-1:1,sp=(.6+Math.random()*1.4)*(.5+v*.35),spread=Math.random()*.9,
  vx=(tx*side*(1-spread)+e.nx*spread)*sp,vy=(ty*side*(1-spread)+e.ny*spread)*sp,life=22+Math.random()*(14+lvl*12);
  IMP.dust.push({x:e.x,y:e.y,vx:vx,vy:vy,life:life,max:life,col:Math.random()<.45?C.white:A,sz:.6+Math.random()*.9});}
 if(lvl>=2){var na=lvl===2?1+(Math.random()<.5?1:0):3+(Math.random()<.5?1:0);
  for(i=0;i<na;i++){var ang=Math.atan2(e.ny,e.nx)+(Math.random()-.5)*2.2;IMP.arcs.push({x:e.x,y:e.y,ang:ang,len:8+v*(2.6+Math.random()*1.8),life:11+lvl*3,max:11+lvl*3,col:A});}
  IMP.rings.push({x:e.x,y:e.y,r:3,vr:.9+v*.18,life:20+lvl*6,max:20+lvl*6,col:A});}
 if(lvl>=1)IMP.stars.push({x:e.x,y:e.y,s:3+v*(lvl>=3?2.2:1),life:9+lvl*3,max:9+lvl*3,col:A,a:Math.random()*.6});
 while(IMP.dust.length>260)IMP.dust.shift();}
function drawImpacts(c){if(!IMP.dust.length&&!IMP.arcs.length&&!IMP.rings.length&&!IMP.stars.length)return;var i,k;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<IMP.dust.length;i++){var d=IMP.dust[i];d.x+=d.vx;d.y+=d.vy;d.vx*=.94;d.vy=d.vy*.94+.025;d.life--;var a=d.life/d.max;
  c.fillStyle=rgba(d.col,.9*a);c.fillRect(d.x-d.sz/2,d.y-d.sz/2,d.sz,d.sz);
  if(a>.6){c.strokeStyle=rgba(d.col,.35*a);c.lineWidth=d.sz*.8;c.beginPath();c.moveTo(d.x,d.y);c.lineTo(d.x-d.vx*2.2,d.y-d.vy*2.2);c.stroke();}}
 IMP.dust=IMP.dust.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.arcs.length;i++){var r=IMP.arcs[i],a2=r.life/r.max,segs=5+Math.floor(r.len/6),x=r.x,y=r.y;r.life--;   /* éclair : ligne brisée re‑tirée à chaque image */
  c.strokeStyle=rgba(r.col,.35*a2);c.lineWidth=2.6;c.beginPath();c.moveTo(x,y);var pts=[[x,y]];
  for(k=1;k<=segs;k++){var f=k/segs,jit=(Math.random()-.5)*5*(1-f*.4),px=r.x+Math.cos(r.ang)*r.len*f-Math.sin(r.ang)*jit,py=r.y+Math.sin(r.ang)*r.len*f+Math.cos(r.ang)*jit;pts.push([px,py]);c.lineTo(px,py);}
  c.stroke();c.strokeStyle=rgba(C.white,.85*a2);c.lineWidth=.8;c.beginPath();pts.forEach(function(q,j){if(j)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);});c.stroke();
  if(Math.random()<.5&&segs>4){var b0=pts[Math.floor(segs/2)],ba=r.ang+(Math.random()<.5?-.9:.9);c.strokeStyle=rgba(r.col,.6*a2);c.lineWidth=.6;c.beginPath();c.moveTo(b0[0],b0[1]);
   c.lineTo(b0[0]+Math.cos(ba)*r.len*.35,b0[1]+Math.sin(ba)*r.len*.35);c.stroke();}}
 IMP.arcs=IMP.arcs.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.rings.length;i++){var g=IMP.rings[i],a3=g.life/g.max;g.r+=g.vr;g.vr*=.94;g.life--;c.strokeStyle=rgba(g.col,.55*a3);c.lineWidth=1.2*a3+.3;c.beginPath();c.arc(g.x,g.y,g.r,0,6.2832);c.stroke();}
 IMP.rings=IMP.rings.filter(function(q){return q.life>0;});
 for(i=0;i<IMP.stars.length;i++){var st=IMP.stars[i],a4=st.life/st.max,L2=st.s*(.6+a4*.6);st.life--;c.save();c.translate(st.x,st.y);c.rotate(st.a);
  var sg=c.createRadialGradient(0,0,0,0,0,L2*.7);sg.addColorStop(0,rgba(C.white,.9*a4));sg.addColorStop(1,rgba(st.col,0));c.fillStyle=sg;c.beginPath();c.arc(0,0,L2*.7,0,6.2832);c.fill();
  c.strokeStyle=rgba(C.white,.8*a4);c.lineWidth=.8;c.beginPath();c.moveTo(-L2,0);c.lineTo(L2,0);c.moveTo(0,-L2*.6);c.lineTo(0,L2*.6);c.stroke();c.restore();}
 IMP.stars=IMP.stars.filter(function(q){return q.life>0;});
 c.restore();}
function jointPal(m){return m===4?['#6FA6BF','#173040','rgba(214,243,255,.9)']:m===3?['#5A4488','#1B1230',rgba(C.boost,.9)]:m===1?['#8A4A2A','#2A120A',rgba(C.bounce,.9)]:['#5E7891','#1A2532','rgba(205,224,240,.95)'];}
function bolt(c,x,y,r){var g=c.createRadialGradient(x-r*.35,y-r*.35,0,x,y,r);g.addColorStop(0,'#F2F7FB');g.addColorStop(.55,'#93A9BC');g.addColorStop(1,'#2E3D4B');
 c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();c.strokeStyle='rgba(10,16,22,.6)';c.lineWidth=.6;c.beginPath();c.moveTo(x-r*.5,y);c.lineTo(x+r*.5,y);c.stroke();}
function metal(c,x0,y0,x1,y1,P){var g=c.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,P[0]);g.addColorStop(1,P[1]);return g;}
function jointsBuild(lv,segs){
 var P=[],E=[],i,j,k,a,b2;
 function piece(pts,m,pz){P.push({pts:pts,m:m,pz:pz||null});}
 for(i=0;i<segs.length;i++){var s=segs[i];if(s[5]===1||s[4]===2||isCupWall(lv,s))continue;piece([[s[0],s[1]],[s[2],s[3]]],s[4]);}
 var por=[];if(lv._cv)for(i=0;i<lv._cv.length;i++){if(lv._cv[i].pass&&!lv._cv[i].pz)por.push(lv._cv[i].pts);else piece(lv._cv[i].pts,lv._cv[i].m,lv._cv[i].pass?lv._cv[i].pz:null);}   /* R133 : la matière poreuse n'a ni nœud ni jonction */
 function nearPor(x,y){for(var q=0;q<por.length;q++)for(var r=0;r<por[q].length;r++)if(Math.hypot(por[q][r][0]-x,por[q][r][1]-y)<12)return true;return false;}
 var nodes=[];
 function addArm(x,y,dx,dy,m){var l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
  for(var q=0;q<nodes.length;q++){var n=nodes[q];if(Math.hypot(n.x-x,n.y-y)<9){
    for(var r=0;r<n.arms.length;r++)if(n.arms[r][0]*dx+n.arms[r][1]*dy>Math.cos(16*Math.PI/180))return;
    n.arms.push([dx,dy]);n.x=(n.x*n.k+x)/(n.k+1);n.y=(n.y*n.k+y)/(n.k+1);n.k++;if(n.m!==0&&m===0)n.m=0;return;}}
  nodes.push({x:x,y:y,k:1,m:m,arms:[[dx,dy]]});}
 /* bouts de pièces */
 P.forEach(function(p,pi){var A=p.pts;[[A[0],A[1]],[A[A.length-1],A[A.length-2]]].forEach(function(e){E.push({x:e[0][0],y:e[0][1],dx:e[1][0]-e[0][0],dy:e[1][1]-e[0][1],m:p.m,pi:pi});});});
 /* chaque bout : rejoint‑il un autre bout, ou le corps d'une autre pièce ? */
 E.forEach(function(e){var hit=false;
  E.forEach(function(f){if(f!==e&&f.pi!==e.pi&&Math.hypot(f.x-e.x,f.y-e.y)<9)hit=true;});
  P.forEach(function(p,pi){if(pi===e.pi)return;var A=p.pts;for(var q=1;q<A.length;q++){var ax=A[q][0]-A[q-1][0],ay=A[q][1]-A[q-1][1],l=ax*ax+ay*ay,u=l?Math.max(0,Math.min(1,((e.x-A[q-1][0])*ax+(e.y-A[q-1][1])*ay)/l)):0;
    var gl=(q-1+u)/(A.length-1);if(gl<.03||gl>.97)continue;
    if(Math.hypot(e.x-A[q-1][0]-u*ax,e.y-A[q-1][1]-u*ay)<8){addArm(e.x,e.y,ax,ay,p.m);addArm(e.x,e.y,-ax,-ay,p.m);hit=true;break;}}});
  e.joined=hit;if(hit)addArm(e.x,e.y,e.dx,e.dy,e.m);});
 /* croisements : intersections de corps à corps */
 for(i=0;i<P.length;i++)for(j=i+1;j<P.length;j++){var A1=P[i].pts,A2=P[j].pts;
  for(a=1;a<A1.length;a++)for(b2=1;b2<A2.length;b2++){var p1=A1[a-1],p2=A1[a],p3=A2[b2-1],p4=A2[b2],d=(p2[0]-p1[0])*(p4[1]-p3[1])-(p2[1]-p1[1])*(p4[0]-p3[0]);if(Math.abs(d)<1e-9)continue;
   var t1=((p3[0]-p1[0])*(p4[1]-p3[1])-(p3[1]-p1[1])*(p4[0]-p3[0]))/d,t2=((p3[0]-p1[0])*(p2[1]-p1[1])-(p3[1]-p1[1])*(p2[0]-p1[0]))/d;
   if(t1<0||t1>1||t2<0||t2>1)continue;var g1=(a-1+t1)/(A1.length-1),g2=(b2-1+t2)/(A2.length-1);if(g1<.03||g1>.97||g2<.03||g2>.97)continue;
   var x=p1[0]+(p2[0]-p1[0])*t1,y=p1[1]+(p2[1]-p1[1])*t1;if([P[i].pz,P[j].pz].some(function(z){return z&&Math.abs(x-z[0])<z[2]&&Math.abs(y-z[1])<z[3];}))continue;   /* R133 : croisement poreux, sans nœud */
   var ux=p2[0]-p1[0],uy=p2[1]-p1[1],vx=p4[0]-p3[0],vy=p4[1]-p3[1];
   addArm(x,y,ux,uy,P[i].m);addArm(x,y,-ux,-uy,P[i].m);addArm(x,y,vx,vy,P[j].m);addArm(x,y,-vx,-vy,P[j].m);nodes[nodes.length-1].cross=1;}}
 return {nodes:nodes,ends:E.filter(function(e){return !e.joined&&!nearPor(e.x,e.y);})};}
function hull(pts){pts=pts.slice().sort(function(a,b){return a[0]-b[0]||a[1]-b[1];});function cr(o,a,b){return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);}
 var lo=[],up=[],i;for(i=0;i<pts.length;i++){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],pts[i])<=0)lo.pop();lo.push(pts[i]);}
 for(i=pts.length-1;i>=0;i--){while(up.length>=2&&cr(up[up.length-2],up[up.length-1],pts[i])<=0)up.pop();up.push(pts[i]);}up.pop();lo.pop();return lo.concat(up);}
function joints(c,segs,lv){
 var key=segs.length+':'+(lv._cv?lv._cv.length:0)+':'+(lv.w?lv.w.length:0);
 if(!lv._jn||lv._jnKey!==key){lv._jn=jointsBuild(lv,segs);lv._jnKey=key;}
 var J=lv._jn,i,k;c.save();c.lineJoin=c.lineCap='round';
 var t=now(),Wc=C.white;
 J.nodes.forEach(function(n){if(n.arms.length<2)return;var A=lv.jA||(n.m===4?[214,243,255]:n.m===3?C.boost:n.m===1?C.bounce:C.matter),L=10,W=6.5,pts=[];
  n.arms.forEach(function(a){var nx=-a[1],ny=a[0];[[L,W],[L,-W],[2,W],[2,-W]].forEach(function(q){pts.push([n.x+a[0]*q[0]+nx*q[1],n.y+a[1]*q[0]+ny*q[1]]);});});
  var H=hull(pts);if(H.length<3)return;
  /* lentille : l'enveloppe des bras devient un verre de lumière (dégradé radial, liseré lumineux) */
  var lg=c.createRadialGradient(n.x,n.y,0,n.x,n.y,15);lg.addColorStop(0,rgba(A,.42));lg.addColorStop(.6,'rgba(12,20,36,.78)');lg.addColorStop(1,'rgba(8,12,24,.7)');
  c.fillStyle=lg;c.beginPath();c.moveTo(H[0][0],H[0][1]);for(k=1;k<H.length;k++)c.lineTo(H[k][0],H[k][1]);c.closePath();c.fill();
  c.globalCompositeOperation='lighter';c.strokeStyle=rgba(A,.22);c.lineWidth=4;c.stroke();c.strokeStyle=rgba(A,.8);c.lineWidth=.9;c.stroke();c.globalCompositeOperation='source-over';
  /* bagues de lumière sur chaque bras */
  n.arms.forEach(function(a){var nx=-a[1],ny=a[0],cx2=n.x+a[0]*(L-1.6),cy2=n.y+a[1]*(L-1.6);c.strokeStyle=rgba(Wc,.65);c.lineWidth=1;
   c.beginPath();c.moveTo(cx2+nx*W*.9,cy2+ny*W*.9);c.lineTo(cx2-nx*W*.9,cy2-ny*W*.9);c.stroke();});
  /* cœur : un petit atome — noyau blanc, halo, orbite elliptique qui tourne lentement */
  c.globalCompositeOperation='lighter';var hg=c.createRadialGradient(n.x,n.y,0,n.x,n.y,9);hg.addColorStop(0,rgba(Wc,.95));hg.addColorStop(.25,rgba(A,.7));hg.addColorStop(1,rgba(A,0));
  c.fillStyle=hg;c.beginPath();c.arc(n.x,n.y,9,0,6.2832);c.fill();
  var pr=((t*.008+n.x*.013+n.y*.007)%1);c.strokeStyle=rgba(A,.45*(1-pr));c.lineWidth=.8;c.beginPath();c.arc(n.x,n.y,5+pr*16,0,6.2832);c.stroke();   /* onde qui s'échappe */
  var ro=t*.02+n.x*.01;c.save();c.translate(n.x,n.y);c.rotate(ro);c.strokeStyle=rgba(A,.75);c.lineWidth=.8;c.beginPath();c.ellipse(0,0,6.5,2.4,0,0,6.2832);c.stroke();
  c.rotate(Math.PI/2.4);c.strokeStyle=rgba(Wc,.35);c.beginPath();c.ellipse(0,0,6.5,2.4,0,0,6.2832);c.stroke();
  var ea=t*.08;c.fillStyle=rgba(Wc,.95);c.beginPath();c.arc(Math.cos(ea)*6.5,Math.sin(ea)*2.4,1,0,6.2832);c.fill();c.restore();
  c.globalCompositeOperation='source-over';var Wc2=Wc;});
 J.ends.forEach(function(e){var A=lv.jA||(e.m===4?[214,243,255]:e.m===3?C.boost:e.m===1?C.bounce:C.matter);
  if(e.x<7||e.x>VW-7||e.y<7){ /* ancrage au bord : arc de lumière plaqué au bord, deux points d'ancrage */
   var px=e.x<7?0:e.x>VW-7?VW:e.x,py=e.y<7?0:e.y,vert=!(e.y<7);c.globalCompositeOperation='lighter';
   c.strokeStyle=rgba(A,.25);c.lineWidth=5;c.beginPath();if(vert){c.moveTo(px,py-11);c.lineTo(px,py+11);}else{c.moveTo(px-11,py);c.lineTo(px+11,py);}c.stroke();
   c.strokeStyle=rgba(Wc,.85);c.lineWidth=1.2;c.stroke();
   [-8,8].forEach(function(o){var ax=vert?px+(px<VW/2?2:-2):px+o,ay=vert?py+o:py+2;c.fillStyle=rgba(Wc,.9);c.beginPath();c.arc(ax,ay,1.3,0,6.2832);c.fill();});
   c.globalCompositeOperation='source-over';return;}
  /* bout libre : une perle de lumière */
  var pu=.85+.15*Math.sin(t*.06+e.x*.1);c.globalCompositeOperation='lighter';var pg=c.createRadialGradient(e.x,e.y,0,e.x,e.y,7*pu);pg.addColorStop(0,rgba(Wc,.95));pg.addColorStop(.3,rgba(A,.65));pg.addColorStop(1,rgba(A,0));
  c.fillStyle=pg;c.beginPath();c.arc(e.x,e.y,7*pu,0,6.2832);c.fill();c.globalCompositeOperation='source-over';
  c.strokeStyle=rgba(A,.8);c.lineWidth=.8;c.beginPath();c.arc(e.x,e.y,3.6,0,6.2832);c.stroke();});
 c.restore();}

/* trait du joueur : ruban d'énergie (structure) ou plaque (rebond). Renvoie false si non géré. */
function stroke(c,pts,mat,k){if(mat===1||mat===3){if(pts.length<2)return true;c.save();c.globalAlpha=k===undefined?1:k;curve(c,pts,mat,{noHang:1});c.restore();return true;}   /* R155 : le tracé rebond / accélérateur du joueur parle la même langue que les pièces du niveau (fines, lumineuses) */
 if(mat!==0)return false;var t=now();c.save();c.globalAlpha=k===undefined?1:k;c.lineCap='round';c.lineJoin='round';
 function path(){c.beginPath();for(var j=0;j<pts.length;j++){if(j)c.lineTo(pts[j][0],pts[j][1]);else c.moveTo(pts[j][0],pts[j][1]);}}
 c.shadowColor='#4DD7FF';c.shadowBlur=18;c.strokeStyle='rgba(77,215,255,.9)';c.lineWidth=5.5;path();c.stroke();
 c.shadowBlur=0;c.strokeStyle='#E8FBFF';c.lineWidth=1.6;path();c.stroke();
 c.setLineDash([3,11]);c.lineDashOffset=-t*.9;c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=2.6;path();c.stroke();c.setLineDash([]);
 c.restore();return true;}

/* ============================ NUAGES DE POINTS ============================ */
/* Références : illusions bistables (nuages de points en rotation 3D, sans indice
   de profondeur — le sens de rotation est ambigu : métaphore de la superposition). */
var SPH=[],CAP=[],RING=[],i;
for(i=0;i<150;i++){var yy=1-2*(i+.5)/150,rr=Math.sqrt(1-yy*yy),aa=i*2.39996;SPH.push([Math.cos(aa)*rr,yy,Math.sin(aa)*rr]);}
for(i=0;i<170;i++){var u=i/170,a2=i*2.39996,y2=u*2-1,cap=.55,x2,z2;
 if(Math.abs(y2)<cap){x2=Math.cos(a2);z2=Math.sin(a2);}else{var kq=(Math.abs(y2)-cap)/(1-cap),hq=Math.sqrt(Math.max(0,1-kq*kq));x2=Math.cos(a2)*hq;z2=Math.sin(a2)*hq;y2=(y2<0?-1:1)*(cap+kq*.55);}
 CAP.push([x2*.62,y2,z2*.62]);}
for(i=0;i<80;i++){var a3=i/80*6.2832;RING.push([Math.cos(a3),0,Math.sin(a3)]);}
function rot(p,ax,ay,az){var x=p[0],y=p[1],z=p[2],c1=Math.cos(ay),s1=Math.sin(ay),t;t=x*c1+z*s1;z=-x*s1+z*c1;x=t;
 c1=Math.cos(ax);s1=Math.sin(ax);t=y*c1-z*s1;z=y*s1+z*c1;y=t;if(az){c1=Math.cos(az);s1=Math.sin(az);t=x*c1-y*s1;y=x*s1+y*c1;x=t;}return [x,y,z];}
function cloud(c,pts,R,ax,ay,az,colf,sz){for(var j=0;j<pts.length;j++){var q=rot(pts[j],ax,ay,az);c.fillStyle=colf(pts[j]);c.fillRect(q[0]*R-sz/2,q[1]*R-sz/2,sz,sz);}}
function sphereCol(p){var f=(p[1]+1)/2;return rgba(f>.5?mix(C.pink,C.boost,(1-f)*2):mix(C.boost,C.matter,(.5-f)*2),.9);}

/* noyau : sphère bistable + anneau (Fonderie : capsule orange-or) */
function core(c,lv){
 /* NOYAU (R58) — d'après la vidéo fournie par Simon (fsaver_04673) : SURFACE D'ENNEPER en nuage de points très fin,
    projection orthogonale (rotation bistable), un tour en 6 s, axe incliné. Couleurs de la charte du noyau (or → ambre →
    rose → blanc chaud), pas l'arc‑en‑ciel de la vidéo. Taille ≈ 2 fois la particule : on ne peut plus les confondre
    (la particule reste la petite sphère cyan‑blanc cerclée de blanc). */
 if(!ENN)ennBuild();
 var st=lv.star,pulse=.5+.5*Math.sin(now()*.006),i,p;c.save();c.translate(st[0],st[1]);
 var gr=c.createRadialGradient(0,0,0,0,0,30);gr.addColorStop(0,rgba(C.reward,.16+.06*pulse));gr.addColorStop(.6,rgba([255,170,60],.05));gr.addColorStop(1,'rgba(0,0,0,0)');
 c.fillStyle=gr;c.fillRect(-30,-30,60,60);
 var a=((typeof OPT!=="undefined"&&OPT.rm)?0:(typeof performance!=='undefined'?performance.now():0)*.001047),ax=[1,.35,.15],l=Math.hypot(ax[0],ax[1],ax[2]);ax=[ax[0]/l,ax[1]/l,ax[2]/l];
 var ca=Math.cos(a),sa=Math.sin(a),k1=1-ca,X=ax[0],Y=ax[1],Z=ax[2],
  m00=ca+X*X*k1,m01=X*Y*k1-Z*sa,m10=Y*X*k1+Z*sa,m11=ca+Y*Y*k1,m02=X*Z*k1+Y*sa,m12=Y*Z*k1-X*sa,sc=21,ps=.95;
 c.globalCompositeOperation='lighter';
 for(i=0;i<ENN.length;i++){p=ENN[i];c.fillStyle=ENNC[p[3]]+'.5)';
  c.fillRect((m00*p[0]+m01*p[1]+m02*p[2])*sc-ps/2,(m10*p[0]+m11*p[1]+m12*p[2])*sc-ps/2,ps,ps);}
 c.restore();}

/* nuage d'Enneper (R57, utilisé par le noyau depuis R58) */
/* balle (R57) — d'après la vidéo de référence fournie par Simon (fsaver_04673) : analyse image par image —
   la forme est une SURFACE D'ENNEPER (surface minimale : un carré aux côtés creusés d'où sortent quatre lobes qui se
   replient) rendue en nuage de points très fin, sans contour, en projection orthogonale (d'où l'illusion bistable : on ne
   sait pas dans quel sens elle tourne). Couleur : teinte arc‑en‑ciel qui suit l'angle autour de la surface (saturation
   ≈ 0,6, points peu lumineux qui s'additionnent : les plis s'allument). Rotation régulière : un tour en 6 s, axe incliné.
   Collision inchangée (cercle de rayon R) : le dessin est mis à l'échelle pour rester proche de ce cercle. */
var ENN=null,ENNC=null;
function ennBuild(){var n=900,pts=[],i,mx=0,r,th,x,y,z;
 var seed=0,wmax=1.55*Math.pow(1+1.55*1.55,2);for(i=0;i<n;i++){ /* tirage uniforme SUR la surface : l'aire d'Enneper croît comme r(1+r²)² — le centre reste clairsemé comme dans la vidéo */
  do{seed++;r=rnd(seed*1.37+.5)*1.55;}while(rnd(seed*4.13+2.2)*wmax>r*Math.pow(1+r*r,2)&&seed<n*60);
  th=rnd(i*2.91+7.1)*6.2832;
  x=r*Math.cos(th)-r*r*r/3*Math.cos(3*th);y=-r*Math.sin(th)-r*r*r/3*Math.sin(3*th);z=r*r*Math.cos(2*th);
  pts.push([x,y,z,Math.floor((((th/6.2832)+.6)%1)*24)]);mx=Math.max(mx,Math.hypot(x,y,z));}
 for(i=0;i<n;i++){pts[i][0]/=mx;pts[i][1]/=mx;pts[i][2]/=mx;}
 ENN=pts;ENNC=[];
 /* palette du jeu, pas l'arc‑en‑ciel de la vidéo : or du noyau (reward) → ambre (bounce) → rose (pink) → blanc chaud, en boucle */
 var stops=[C.reward,[255,170,60],C.pink,[255,240,214],C.reward];
 for(i=0;i<24;i++){var u=i/24*4,k=Math.floor(u),f=u-k,A=stops[k],B=stops[k+1];
  ENNC.push('rgba('+Math.round(A[0]+(B[0]-A[0])*f)+','+Math.round(A[1]+(B[1]-A[1])*f)+','+Math.round(A[2]+(B[2]-A[2])*f)+',');}}
/* balle : particule en nuage de points (sphère bistable), cœur lumineux, contour net pour rester lisible */
function ball(c,x,y,ang,r,tint){var t=now();c.save();c.translate(x,y);
 var tc=tint?hex(tint):null;
 var gr=c.createRadialGradient(0,0,0,0,0,r*2.1);gr.addColorStop(0,rgba(tc||C.matter,.35));gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(-r*2.1,-r*2.1,r*4.2,r*4.2);
 gr=c.createRadialGradient(-r*.25,-r*.3,0,0,0,r);gr.addColorStop(0,'rgba(255,255,255,.55)');gr.addColorStop(.5,rgba(tc||C.boost,.28));gr.addColorStop(1,rgba(tc||C.matter,.12));
 c.fillStyle=gr;c.beginPath();c.arc(0,0,r,0,6.2832);c.fill();
 c.globalCompositeOperation='lighter';
 cloud(c,SPH,r*.96,.45,(ang||0)+t*.01,0,tc?function(){return rgba(tc,.9);}:sphereCol,1.25);
 c.globalCompositeOperation='source-over';c.strokeStyle=rgba(tc||C.white,.7);c.lineWidth=1;c.beginPath();c.arc(0,0,r,0,6.2832);c.stroke();
 c.restore();}
function hex(h){if(typeof h!=='string'||h.charAt(0)!=='#')return C.boost;return [parseInt(h.substr(1,2),16),parseInt(h.substr(3,2),16),parseInt(h.substr(5,2),16)];}

/* ============================ ACCUEIL ============================ */
var HD=null;
function hero(c,w,h){var t=now();
 if(!HD||HD.w!==w||HD.h!==h){HD={w:w,h:h,dust:[]};for(var j=0;j<90;j++)HD.dust.push({x:rnd(j)*w,y:rnd(j*1.7)*h,z:.3+rnd(j*2.3)*.7,ph:rnd(j*4.1)*6.28,col:[C.white,C.white,C.matter,C.boost][j%4]});}
 c.fillStyle='#070B14';c.fillRect(0,0,w,h);
 c.save();c.globalCompositeOperation='lighter';
 var b1=[[w*.2,h*.5,w*.55,C.boost,.16],[w*.78,h*.45,w*.45,C.matter,.14],[w*.55,h*.9,w*.4,C.reward,.06]];
 for(var i=0;i<b1.length;i++){var q=b1[i],x=q[0]+Math.sin(t*.004+i)*10,gr=c.createRadialGradient(x,q[1],0,x,q[1],q[2]);
  gr.addColorStop(0,rgba(q[3],q[4]*(.85+.15*Math.sin(t*.01+i))));gr.addColorStop(1,rgba(q[3],0));c.fillStyle=gr;c.fillRect(0,0,w,h);}
 for(i=0;i<HD.dust.length;i++){var d=HD.dust[i];d.x+=.08*d.z;d.y-=.03*d.z;if(d.x>w+3)d.x=-3;if(d.y<-3)d.y=h+3;
  var tw=.45+.55*Math.sin(t*.06*d.z+d.ph),s=.5+d.z*1.2;c.fillStyle=rgba(d.col,(.15+.5*d.z)*tw);c.fillRect(d.x,d.y,s,s);}
 c.restore();
 helix(c,-10,h*.78,w*.62,h*.18,11,3.2,.028,C.matter,C.boost,.55,70);
 var cx=w*.8,cy=h*.5,R=Math.min(h*.36,w*.16);
 c.save();c.translate(cx,cy);c.globalCompositeOperation='lighter';
 var g2=c.createRadialGradient(0,0,0,0,0,R*1.6);g2.addColorStop(0,rgba(C.boost,.22));g2.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g2;c.fillRect(-R*1.6,-R*1.6,R*3.2,R*3.2);
 cloud(c,SPH,R,.35,t*.012,0,sphereCol,1.6);
 cloud(c,RING,R*1.45,1.2+Math.sin(t*.003)*.15,-t*.009,0,function(p){return rgba(mix(C.reward,C.goal,(p[0]+1)/2),.7);},1.4);
 c.restore();}
function heroWall(c,q){stroke(c,[[q[0],q[1]],[q[2],q[3]]],0,1);}

/* pièce courbe (R82) : même langage que les poutres, plaques, tapis et glace droits — une bande avec sa profondeur (12 u),
   sa surface lumineuse, ses détails (treillis, cellules, reflets), mais continue et sans jointures */
/* ══ PIÈCE COURBE (R85) — finition « piste de montagnes russes » ══
   Construite à abscisse curviligne constante. Couches, de l'arrière vers l'avant :
   1. ombre portée douce sur le décor ;           2. suspentes fines vers le haut (comme les poutres droites) ;
   3. corps : âme en dégradé + membrure basse ;    4. traverses perpendiculaires et treillis de Warren, rivets aux nœuds ;
   5. rail de roulement en tube (trois passes : ombre, teinte, reflet) ; 6. lampes le long du rail qui s'allument au passage
   de la particule et une lueur lente qui parcourt la piste ; 7. platines d'about boulonnées aux extrémités.
   Glace : bloc translucide, givre intérieur, scintillements. Tapis : galets qui tournent dans le sens de poussée. */
function curve(c,P,mat,opt){opt=opt||{};if(P.length<2)return;var t=now(),Dp=12,i,k,N=[],Bt=[],cum=[0];
 for(i=1;i<P.length;i++)cum.push(cum[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));var Ltot=cum[cum.length-1];
 for(i=0;i<P.length;i++){var a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;N.push([-dy/l,dx/l]);}
 var sx=0,sy=0;for(i=0;i<N.length;i++){sx+=N[i][0];sy+=N[i][1];}var flip=(sy<0||(Math.abs(sy)<.2*N.length&&sx*(P[0][0]-VW/2)<0))?-1:1;
 for(i=0;i<N.length;i++){N[i][0]*=flip;N[i][1]*=flip;Bt.push([P[i][0]+N[i][0]*Dp,P[i][1]+N[i][1]*Dp]);}
 function at(s,off){s=Math.max(0,Math.min(Ltot,s));var j=1;while(j<cum.length-1&&cum[j]<s)j++;var u=(s-cum[j-1])/Math.max(1e-6,cum[j]-cum[j-1]),
  x=P[j-1][0]+(P[j][0]-P[j-1][0])*u,y=P[j-1][1]+(P[j][1]-P[j-1][1])*u,nx=N[j-1][0]+(N[j][0]-N[j-1][0])*u,ny=N[j-1][1]+(N[j][1]-N[j-1][1])*u,nl=Math.hypot(nx,ny)||1;
  return [x+nx/nl*off,y+ny/nl*off,nx/nl,ny/nl];}
 function line(off,from,to,step){c.beginPath();for(var s=from;s<=to+.01;s+=step){var q=at(s,off);if(s===from)c.moveTo(q[0],q[1]);else c.lineTo(q[0],q[1]);}}
 var ice=mat===4,belt=mat===3,hot=mat===1;
 /* R88 — langue « quantique onirique » : la pièce n'est plus de l'acier mais de la LUMIÈRE TENUE — un rail de photons,
    une âme translucide qui s'éteint en profondeur, un réseau fin comme une constellation, des nœuds qui scintillent. */
 var A=opt.accent||(ice?[214,243,255]:belt?C.boost:hot?C.bounce:C.matter),Wc=C.white;
 var bx=-999,by=-999;try{if(typeof S!=='undefined'&&S.ball){bx=S.ball.x;by=S.ball.y;}}catch(e){}
 c.save();c.lineJoin=c.lineCap='round';
 /* suspentes : fils de lumière très fins */
 if(!opt.noHang){c.strokeStyle=rgba(A,.10);c.lineWidth=.8;for(var sh=Math.min(40,Ltot/2);sh<Ltot;sh+=90){var h=at(sh,0);if(h[3]<-.3)continue;c.beginPath();c.moveTo(h[0],h[1]-3);c.lineTo(h[0],0);c.stroke();}}
 /* âme translucide : la couleur de la matière près du rail, qui s'éteint vers la profondeur */
 var mid=Math.floor(P.length/2),gr=c.createLinearGradient(P[mid][0],P[mid][1],Bt[mid][0],Bt[mid][1]);
 gr.addColorStop(0,rgba(A,ice?.30:.22));gr.addColorStop(.55,'rgba(10,16,30,.55)');gr.addColorStop(1,'rgba(5,7,13,.25)');
 c.fillStyle=gr;c.beginPath();c.moveTo(P[0][0],P[0][1]);for(i=1;i<P.length;i++)c.lineTo(P[i][0],P[i][1]);for(i=Bt.length-1;i>=0;i--)c.lineTo(Bt[i][0],Bt[i][1]);c.closePath();c.fill();
 /* membrure de profondeur : un filet */
 c.strokeStyle=rgba(A,.28);c.lineWidth=.8;line(Dp-.6,0,Ltot,3);c.stroke();
 if(belt){ /* tapis : anneaux de champ qui défilent dans le sens de poussée */
  var ofs=(t*.6)%12;for(var sg=ofs+4;sg<Ltot-3;sg+=12){var q3=at(sg,Dp*.5);c.strokeStyle=rgba(A,.7);c.lineWidth=1;c.beginPath();c.arc(q3[0],q3[1],3.6,0,6.2832);c.stroke();
   c.fillStyle=rgba(Wc,.5);c.beginPath();c.arc(q3[0],q3[1],1,0,6.2832);c.fill();}}
 else{ /* réseau en constellation : treillis fin + nœuds‑étoiles qui scintillent (glace : givre intérieur à la place) */
  var n=Math.max(2,Math.round(Ltot/14));
  if(!ice){c.strokeStyle=rgba(A,.30);c.lineWidth=.75;c.beginPath();for(k=0;k<=n;k++){var q2=at(k/n*Ltot,k%2?Dp-1.8:2.4);if(k)c.lineTo(q2[0],q2[1]);else c.moveTo(q2[0],q2[1]);}c.stroke();}
  else{c.strokeStyle=rgba(A,.13);c.lineWidth=.7;for(var g=3;g<Dp;g+=2.8){line(g,0,Ltot,4);c.stroke();}}
  c.globalCompositeOperation='lighter';
  for(k=0;k<=n;k++){var st=at(k/n*Ltot,k%2?Dp-1.8:2.4),tw=.35+.65*Math.max(0,Math.sin(t*.07+k*1.7));c.fillStyle=rgba(k%3?A:Wc,.35+.5*tw);
   c.beginPath();c.arc(st[0],st[1],.7+tw*.7,0,6.2832);c.fill();}
  c.globalCompositeOperation='source-over';}
 /* rail de photons : halo, couleur, cœur blanc */
 var br=.75+.25*Math.sin(t*.035+Ltot*.07);c.globalCompositeOperation='lighter';c.strokeStyle=rgba(A,.16*br);c.lineWidth=9;line(0,0,Ltot,2.5);c.stroke();
 c.strokeStyle=rgba(A,.55);c.lineWidth=3.6;line(0,0,Ltot,2.5);c.stroke();c.globalCompositeOperation='source-over';
 c.strokeStyle=rgba(Wc,.92);c.lineWidth=1.3;line(-.2,0,Ltot,2.5);c.stroke();
 /* R89 — petites animations : rebond = ondes qui battent sur la face ; tapis = éclair quand il pousse ; toutes = poussières
    de lumière qui se détachent du rail et montent doucement */
 if(hot){c.globalCompositeOperation='lighter';for(var so=8;so<Ltot-4;so+=14){var qo=at(so,0),ph=(t*.05+so*.21)%1,dd=Math.hypot(qo[0]-bx,qo[1]-by),k2=Math.max(ph<.5?ph*2:2-ph*2,dd<40?1-dd/40:0);
   c.strokeStyle=rgba(A,.15+.55*k2);c.lineWidth=1;c.beginPath();c.arc(qo[0]-qo[2]*2,qo[1]-qo[3]*2,3+2.5*k2,Math.atan2(-qo[3],-qo[2])-1,Math.atan2(-qo[3],-qo[2])+1);c.stroke();}c.globalCompositeOperation='source-over';}
 if(belt&&typeof D!=='undefined'&&D.flash)for(var fi=0;fi<D.flash.length;fi++){var fq=D.flash[fi];for(var sb=0;sb<Ltot;sb+=6){var qb=at(sb,0);if(Math.hypot(qb[0]-fq.x,qb[1]-fq.y)<22){
   c.globalCompositeOperation='lighter';c.strokeStyle=rgba(Wc,.5*fq.life);c.lineWidth=2.4;line(0,Math.max(0,sb-18),Math.min(Ltot,sb+18),3);c.stroke();c.globalCompositeOperation='source-over';break;}}}
 c.globalCompositeOperation='lighter';
 for(var mo=0;mo<Math.max(2,Ltot/34);mo++){var sm=((mo*61.7+Ltot)%Ltot),life=((t*.012+mo*.37)%1),qm=at(sm,0),rise=life*16;
  c.fillStyle=rgba(mo%2?A:Wc,.55*(1-life)*Math.min(1,life*5));c.beginPath();c.arc(qm[0]-qm[2]*rise+Math.sin(t*.03+mo)*1.5,qm[1]-qm[3]*rise,.9,0,6.2832);c.fill();}
 c.globalCompositeOperation='source-over';
 /* photons qui circulent le long du rail ; ils s'éveillent quand la particule approche */
 c.globalCompositeOperation='lighter';var fl=(t*.9)%26;
 for(var sl=fl;sl<Ltot;sl+=26){var lp=at(sl,0),d=Math.hypot(lp[0]-bx,lp[1]-by),e=Math.max(.25,1-d/60);
  var gl=c.createRadialGradient(lp[0],lp[1],0,lp[0],lp[1],3+5*e);gl.addColorStop(0,rgba(Wc,.85*e));gl.addColorStop(.4,rgba(A,.5*e));gl.addColorStop(1,rgba(A,0));
  c.fillStyle=gl;c.beginPath();c.arc(lp[0],lp[1],3+5*e,0,6.2832);c.fill();}
 c.globalCompositeOperation='source-over';
 /* 7. les extrémités sont traitées par la bibliothèque de connecteurs (joints) */
 c.restore();}
/* ══ R130 — PAROI TUNNEL (effet tunnel) ══ couleur propre (air #A9BCEB) ; deux rangées d'atomes qui glissent l'une dans l'autre
   (imbrication moléculaire) sur un voile pâle ; au passage d'une particule rapide, les atomes s'écartent et une onde se propage. */
var TUN=[];
function tunnel(c,P,pz){var t=now(),A=[169,188,235],Wc=[236,244,255],i,k,Q=[];
 for(i=0;i<P.length;i++){var q=P[i];if(!pz||(Math.abs(q[0]-pz[0])<pz[2]&&Math.abs(q[1]-pz[1])<pz[3]))Q.push(q);else if(Q.length>1)break;}
 if(Q.length<2)return;var cum=[0];for(i=1;i<Q.length;i++)cum.push(cum[i-1]+Math.hypot(Q[i][0]-Q[i-1][0],Q[i][1]-Q[i-1][1]));var L0=cum[cum.length-1];
 function at(d){d=Math.max(0,Math.min(L0,d));var j=1;while(j<Q.length-1&&cum[j]<d)j++;var u=(d-cum[j-1])/((cum[j]-cum[j-1])||1),x=Q[j-1][0]+(Q[j][0]-Q[j-1][0])*u,y=Q[j-1][1]+(Q[j][1]-Q[j-1][1])*u,dx=Q[j][0]-Q[j-1][0],dy=Q[j][1]-Q[j-1][1],l=Math.hypot(dx,dy)||1;return [x,y,-dy/l,dx/l];}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.shadowColor=rgba(A,.9);c.shadowBlur=14;c.strokeStyle=rgba(A,.16);c.lineWidth=20;c.beginPath();c.moveTo(Q[0][0],Q[0][1]);for(i=1;i<Q.length;i++)c.lineTo(Q[i][0],Q[i][1]);c.stroke();c.shadowBlur=0;   /* voile */
 for(k=0;k<2;k++){c.strokeStyle=rgba(k?Wc:A,.7);c.lineWidth=1.1;c.beginPath();for(var hd=0;hd<=L0;hd+=1.5){var hp=at(hd),ho=Math.sin(hd*.45-t*.08+k*Math.PI)*5*Math.min(1,Math.min(hd,L0-hd)/8);if(hd===0)c.moveTo(hp[0]+hp[2]*ho,hp[1]+hp[3]*ho);else c.lineTo(hp[0]+hp[2]*ho,hp[1]+hp[3]*ho);}c.stroke();}   /* deux brins imbriqués */
 for(k=0;k<2;k++){var ep=at(k?L0:0);c.strokeStyle=rgba(Wc,.6);c.lineWidth=1.4;c.beginPath();c.moveTo(ep[0]-ep[2]*9,ep[1]-ep[3]*9);c.lineTo(ep[0]+ep[2]*9,ep[1]+ep[3]*9);c.stroke();}   /* bornes de la zone */
 c.setLineDash([2,5]);c.lineDashOffset=-t*.25;c.strokeStyle=rgba(Wc,.55);c.lineWidth=1.2;c.stroke();c.setLineDash([]);
 for(k=-1;k<=1;k+=2)for(var d=0;d<L0;d+=7){var ph=(d+k*t*.12)%7,dd=d+(ph<0?ph+7:ph),p=at(dd),off=k*3.6+Math.sin(t*.05+dd*.3)*.8,x=p[0]+p[2]*off,y=p[1]+p[3]*off,push=0;
  for(var e=0;e<TUN.length;e++){var g=TUN[e],r=Math.hypot(x-g.x,y-g.y);if(r<26){push+=(26-r)/26*9*g.l;var ang=Math.atan2(y-g.y,x-g.x);x+=Math.cos(ang)*push;y+=Math.sin(ang)*push;}}
  var fade=Math.min(1,Math.min(dd,L0-dd)/10);c.fillStyle=rgba(k<0?A:Wc,(.75)*fade);c.beginPath();c.arc(x,y,k<0?1.6:1.2,0,6.2832);c.fill();}
 for(i=TUN.length-1;i>=0;i--){var g=TUN[i];c.strokeStyle=rgba(A,.5*g.l);c.lineWidth=1;c.beginPath();c.arc(g.x,g.y,8+(1-g.l)*30,0,6.2832);c.stroke();g.l-=.03;if(g.l<=0)TUN.splice(i,1);}
 c.restore();}
/* ══ R130 — POUSSIÈRE D'ÉTOILE QUI MONTRE LE CHEMIN ══ un filet de grains très fins dérive le long de lv.flow (vers l'entrée de
   la machine) ; discret, il naît et s'éteint en douceur. */
function flow(c,path){if(!path||path.length<2)return;var t=now(),i,F=path._f;
 if(!F){var cum=[0],tn=[],hot=[];for(i=1;i<path.length;i++)cum.push(cum[i-1]+Math.hypot(path[i][0]-path[i-1][0],path[i][1]-path[i-1][1]));
  for(i=1;i<path.length-1;i++){var a1=Math.atan2(path[i][1]-path[i-1][1],path[i][0]-path[i-1][0]),a2=Math.atan2(path[i+1][1]-path[i][1],path[i+1][0]-path[i][0]),da=Math.abs(((a2-a1+9.4248)%6.2832)-3.1416);
   if(da>.42&&(!hot.length||cum[i]-hot[hot.length-1]>40))hot.push(cum[i]);}   /* virages serrés : là où des grains décrochent */
  F=path._f={cum:cum,L0:cum[cum.length-1],hot:hot};}
 var cum=F.cum,L0=F.L0;
 function at(d){d=Math.max(0,Math.min(L0,d));var j=1;while(j<path.length-1&&cum[j]<d)j++;var sl=(cum[j]-cum[j-1])||1,u=(d-cum[j-1])/sl,dx=(path[j][0]-path[j-1][0])/sl,dy=(path[j][1]-path[j-1][1])/sl;
  return [path[j-1][0]+dx*sl*u,path[j-1][1]+dy*sl*u,dx,dy];}
 var n=Math.max(50,Math.min(280,Math.round(L0/4.2)));
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(var k=0;k<n;k++){var h1=Math.sin(k*12.9898)*43758.5453,j1=h1-Math.floor(h1),h2=Math.sin(k*78.233)*12543.17,j2=h2-Math.floor(h2),h3=Math.sin(k*39.425)*24634.63,j3=h3-Math.floor(h3),h4=Math.sin(k*93.989)*15731.71,j4=h4-Math.floor(h4);
  var sp=.35+j1*j1*1.6,span=L0+70,d=(t*sp+j2*span)%span,p,a=Math.min(1,d/34,Math.max(0,(L0-d)/34)),off=Math.sin(t*.025+k*1.3)*(1.2+j3*3.6),x,y,tx,ty;
  var fug=(k%5===0&&F.hot.length)?F.hot[(k/5|0)%F.hot.length]:-1;
  if(fug>=0&&d>fug){var e=d-fug;p=at(fug);tx=p[2];ty=p[3];var sg=(j3<.5)?1:-1;   /* le grain décroche de son orbite : il file tout droit et s'écarte doucement */
   x=p[0]+tx*e+(-ty)*sg*e*e*.004;y=p[1]+ty*e+tx*sg*e*e*.004;a=Math.min(1,fug/34)*Math.max(0,1-e/60);}
  else{if(d>L0)continue;p=at(d);tx=p[2];ty=p[3];x=p[0]-ty*off;y=p[1]+tx*off;}
  if(a<=0)continue;var al=a*(.12+.6*j4*j4)*(.7+.3*Math.sin(t*.05+k*2.1)),col=k%3?[214,236,255]:(k%7?[169,188,235]:[255,226,170]);
  if(sp>1.25){c.strokeStyle=rgba(col,al*.7);c.lineWidth=.7+j3*.6;c.beginPath();c.moveTo(x-tx*sp*4,y-ty*sp*4);c.lineTo(x,y);c.stroke();}   /* les plus rapides laissent un fil */
  c.fillStyle=rgba(col,al);c.beginPath();c.arc(x,y,.35+j3*j3*2.1,0,6.2832);c.fill();
  if(j3>.93){c.fillStyle=rgba(col,al*.18);c.beginPath();c.arc(x,y,4+j3*3,0,6.2832);c.fill();}}   /* quelques grains plus gros portent un halo */
 c.restore();}
/* ══ R139 — TOURBILLON ══ des filets d'air courbes tournent autour de l'œil (v=[cx,cy,R,sens]) : la colonne d'air devient cyclone. */
function vortex(c,v){var t=now(),cx=v[0],cy=v[1],R=v[2],sg=v[3]||1,i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.strokeStyle=rgba([168,200,232],.07);c.lineWidth=R*.5;c.beginPath();c.arc(cx,cy,R*.72,0,6.2832);c.stroke();
 for(k=0;k<26;k++){var h=Math.sin(k*12.9898)*43758.5453,j=h-Math.floor(h),r=R*(.3+.68*j),sp=.012+.02*(1-j),a0=sg*t*sp+k*2.39996,len=.5+.7*j;
  c.strokeStyle=rgba(k%4?[168,200,232]:[214,236,255],.16+.3*j);c.lineWidth=.8+1.4*j;c.beginPath();
  if(sg>0)c.arc(cx,cy,r,a0,a0+len);else c.arc(cx,cy,r,-a0-len,-a0);c.stroke();
  var ae=sg>0?a0+len:-a0-len,ex=cx+r*Math.cos(ae),ey=cy+r*Math.sin(ae);c.fillStyle=rgba([234,246,255],.35+.4*j);c.beginPath();c.arc(ex,ey,1+j*1.2,0,6.2832);c.fill();}
 c.restore();}
/* ══ R140 — COURANT ASCENDANT ══ u=[x,y,w,h] : des filets d'air ondulent et montent, plus denses au cœur, sans cadre. */
function updraft(c,u){var t=now(),x0=u[0],y0=u[1],W=u[2],H=u[3],k,s;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 var gr=c.createLinearGradient(x0,0,x0+W,0);gr.addColorStop(0,rgba([168,200,232],0));gr.addColorStop(.5,rgba([168,200,232],.07));gr.addColorStop(1,rgba([168,200,232],0));
 c.fillStyle=gr;c.fillRect(x0,y0,W,H);
 for(k=0;k<18;k++){var h=Math.sin(k*12.9898)*43758.5453,j=h-Math.floor(h),fx=x0+W*(k+.5)/18,edge=Math.sin(Math.PI*(k+.5)/18),sp=1.1+1.6*j,L=40+60*j,ph=(t*sp+j*H*3)%(H+L);
  for(s=0;s<2;s++){var yb=y0+H-((ph+s*(H+L)/2)%(H+L)),i;c.strokeStyle=rgba(k%3?[168,200,232]:[214,236,255],(.10+.22*j)*edge);c.lineWidth=.7+1.1*j;c.beginPath();
   for(i=0;i<=8;i++){var yy=yb+L*i/8;if(yy<y0||yy>y0+H)continue;var xx=fx+Math.sin(yy*.035+t*.03+k)*(3+4*j);if(i===0||yy-L/8<y0)c.moveTo(xx,yy);else c.lineTo(xx,yy);}c.stroke();}}
 for(k=0;k<30;k++){var h2=Math.sin(k*78.233)*12543.17,q=h2-Math.floor(h2),px=x0+W*q,py=y0+H-((t*(1.4+q*2)+q*H*5)%H),ed=Math.sin(Math.PI*q);
  c.fillStyle=rgba([234,246,255],.18+.3*q*ed);c.beginPath();c.arc(px+Math.sin(t*.04+k)*3,py,.6+q*1.1,0,6.2832);c.fill();}
 c.restore();}
/* ══ R140 — BIELLE À COULISSE ══ m.ck=[dy] : un disque tourne sous la pièce, son maneton glisse dans un coulisseau horizontal
   relié à la pièce par une tige : le mouvement sinusoïdal du moteur devient visible et exact. */
function yoke(c,m){var q=S.t*m.spd+(m.ph||0),s=m.seg,am=m.amp,o=Math.sin(q)*am,G=[224,178,76],Wc=[255,236,190],
 mx=(s[0]+s[2])/2,my=(s[1]+s[3])/2+o,cx=mx,cy=(s[1]+s[3])/2+(m.ck[0]||am+26),px=cx+Math.cos(q)*am,py=cy+Math.sin(q)*am;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 c.strokeStyle=rgba(G,.22);c.lineWidth=1;c.beginPath();c.arc(cx,cy,am,0,6.2832);c.stroke();          /* trajectoire du maneton */
 c.strokeStyle=rgba(G,.5);c.lineWidth=1.2;for(var k=0;k<3;k++){var a=q+k*2.0944;c.beginPath();c.moveTo(cx,cy);c.lineTo(cx+Math.cos(a)*am*.86,cy+Math.sin(a)*am*.86);c.stroke();}   /* rayons du disque */
 c.fillStyle=rgba(G,.5);c.beginPath();c.arc(cx,cy,2.6,0,6.2832);c.fill();
 c.strokeStyle=rgba(G,.55);c.lineWidth=2.2;c.beginPath();c.moveTo(cx-am-5,py);c.lineTo(cx+am+5,py);c.stroke();   /* coulisseau */
 c.strokeStyle=rgba(Wc,.35);c.lineWidth=1.4;c.beginPath();c.moveTo(mx,py);c.lineTo(mx,my+3);c.stroke();          /* tige */
 c.fillStyle=rgba(Wc,.85);c.shadowColor=rgba(G,.9);c.shadowBlur=8;c.beginPath();c.arc(px,py,3,0,6.2832);c.fill();   /* maneton */
 c.restore();}
/* ══ R140 — BALANCIER ══ p=[x,y,longueur,vitesse,amplitude(rad),phase] : le pendule bat la mesure de l'échappement ;
   l'ancre bascule avec lui et ses deux palettes répondent à celles qui ouvrent et ferment les paliers. */
function pendulum(c,p){var q=S.t*p[3]+(p[5]||0),th=p[4]*Math.sin(q),G=[224,178,76],Wc=[255,236,190],x=p[0],y=p[1],Lp=p[2],
 bx=x+Math.sin(th)*Lp,by=y+Math.cos(th)*Lp;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 c.strokeStyle=rgba(G,.16);c.lineWidth=1;c.beginPath();c.arc(x,y,Lp,Math.PI/2-p[4],Math.PI/2+p[4]);c.stroke();   /* arc de battement */
 c.strokeStyle=rgba(Wc,.55);c.lineWidth=1.6;c.beginPath();c.moveTo(x,y);c.lineTo(bx,by);c.stroke();
 var ax=Math.sin(th+.9)*26,ay=Math.cos(th+.9)*26,ax2=Math.sin(th-.9)*26,ay2=Math.cos(th-.9)*26;   /* ancre */
 c.strokeStyle=rgba(G,.75);c.lineWidth=2.4;c.beginPath();c.moveTo(x+ax,y+ay);c.quadraticCurveTo(x,y-8,x+ax2,y+ay2);c.stroke();
 c.fillStyle=rgba(G,.8);[[ax,ay],[ax2,ay2]].forEach(function(e){c.beginPath();c.arc(x+e[0],y+e[1],2.6,0,6.2832);c.fill();});
 c.fillStyle=rgba(Wc,.9);c.beginPath();c.arc(x,y,3,0,6.2832);c.fill();
 var gr=c.createRadialGradient(bx,by,1,bx,by,13);gr.addColorStop(0,rgba(Wc,.9));gr.addColorStop(.5,rgba(G,.55));gr.addColorStop(1,rgba(G,0));
 c.fillStyle=gr;c.beginPath();c.arc(bx,by,13,0,6.2832);c.fill();c.restore();}
/* ══ R142 — PUITS DE GRAVITÉ ══ w=[x,y,m,r] : la toile de l'espace-temps se creuse vers la masse (grille déformée, courbes de
   niveau qui respirent) ; plus on approche, plus les mailles plongent. Violet du monde Gravité. */
function well(c,w){var t=now(),x0=w[0],y0=w[1],m=w[2],V=[140,123,255],Rv=190,st=20,i,j;
 function dp(x,y){var dx=x-x0,dy=y-y0,d=Math.hypot(dx,dy)||1,k=Math.min(.55,m/(d*d+4200)*26);return [x-dx*k,y-dy*k,d];}
 c.save();c.lineWidth=.8;
 for(var pass=0;pass<2;pass++)for(i=-Rv;i<=Rv;i+=st){c.beginPath();var first=true;
  for(j=-Rv;j<=Rv;j+=6){var px=pass?x0+j:x0+i,py=pass?y0+i:y0+j,d0=Math.hypot(px-x0,py-y0);if(d0>Rv){first=true;continue;}
   var q=dp(px,py);if(first){c.moveTo(q[0],q[1]);first=false;}else c.lineTo(q[0],q[1]);}
  c.strokeStyle=rgba(V,.34);c.stroke();}
 for(i=1;i<=4;i++){var r=w[3]+i*26+Math.sin(t*.03-i)*2;c.strokeStyle=rgba(V,.22-.04*i);c.lineWidth=1;c.beginPath();c.arc(x0,y0,r*.8,0,6.2832);c.stroke();}   /* niveaux d'énergie */
 var g=c.createRadialGradient(x0,y0,2,x0,y0,w[3]*1.4);g.addColorStop(0,'rgba(255,255,255,.75)');g.addColorStop(.35,rgba(V,.55));g.addColorStop(1,rgba(V,0));
 c.globalCompositeOperation='lighter';c.fillStyle=g;c.beginPath();c.arc(x0,y0,w[3]*1.4,0,6.2832);c.fill();c.restore();}
/* ══ R142 — ZONE À SON PROPRE BAS (Escher, « Relativité ») ══ z=[x,y,w,h,gx,gy,1] : des lignes d'horizon perpendiculaires à
   la pesanteur locale glissent lentement vers son « bas », et une flèche de fil à plomb l'indique. */
function gzone(c,z){var t=now(),V=[140,123,255],gx=z[4],gy=z[5],L=Math.hypot(gx,gy)||1,ux=gx/L,uy=gy/L,k;
 c.save();c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.fillStyle=rgba(V,.13);c.fillRect(z[0],z[1],z[2],z[3]);
 var eg=c.createLinearGradient(z[0]+z[2]/2-ux*z[2]/2,z[1]+z[3]/2-uy*z[3]/2,z[0]+z[2]/2+ux*z[2]/2,z[1]+z[3]/2+uy*z[3]/2);eg.addColorStop(0,rgba(V,0));eg.addColorStop(1,rgba(V,.22));c.fillStyle=eg;c.fillRect(z[0],z[1],z[2],z[3]);   /* le « bas » local s'éclaire */
 var span=Math.abs(ux)*z[2]+Math.abs(uy)*z[3],cx=z[0]+z[2]/2,cy=z[1]+z[3]/2,sp=22;
 for(k=-span/2-sp;k<span/2+sp;k+=sp){var o=k+((t*.25)%sp),px=cx+ux*o,py=cy+uy*o;c.strokeStyle=rgba([196,186,255],.32+.25*Math.cos(o/span*Math.PI));c.lineWidth=1.3;
  c.beginPath();c.moveTo(px-uy*400,py+ux*400);c.lineTo(px+uy*400,py-ux*400);c.stroke();}
 c.restore();c.save();c.strokeStyle=rgba([196,186,255],.55);c.lineWidth=1.4;c.setLineDash([6,5]);c.lineDashOffset=-t*.3;c.strokeRect(z[0]+.7,z[1]+.7,z[2]-1.4,z[3]-1.4);c.setLineDash([]);var ax=cx-ux*22,ay=cy-uy*22,bx=cx+ux*22,by=cy+uy*22;c.strokeStyle=rgba([214,206,255],.85);c.lineWidth=2;c.lineCap='round';   /* fil à plomb */
 c.beginPath();c.moveTo(ax,ay);c.lineTo(bx,by);c.moveTo(bx-ux*6-uy*5,by-uy*6+ux*5);c.lineTo(bx,by);c.lineTo(bx-ux*6+uy*5,by-uy*6-ux*5);c.stroke();
 c.fillStyle=rgba(V,.7);c.beginPath();c.arc(bx+ux*3,by+uy*3,2.6,0,6.2832);c.fill();c.restore();}
/* ══ R143 — CHAMP MAGNÉTIQUE UNIFORME ══ z=[x,y,w,h,B] : la notation des physiciens — ⊙ (le champ sort de l'écran, B>0) ou ⊗
   (il y entre) — en trame régulière qui respire ; une onde de précession parcourt la trame. Rose du monde Magnétisme. */
function bfield(c,z){var t=now(),P=[255,111,181],sp=26,i,j,nx=Math.floor(z[2]/sp),ny=Math.floor(z[3]/sp),ox=z[0]+(z[2]-nx*sp)/2+sp/2,oy=z[1]+(z[3]-ny*sp)/2+sp/2;
 if(z[6]==='atom'){   /* R156 : la chambre de l'apothéose — un atome : halo, orbitales qui tournent, noyau ; pas de grille */
  var ax=z[0]+z[2]/2,ay=z[1]+z[3]/2,Rm=Math.max(z[2],z[3])*.55,V=[178,130,255],Cy=[90,220,255];c.save();
  var g0=c.createRadialGradient(ax,ay,0,ax,ay,Rm);g0.addColorStop(0,rgba(V,.16));g0.addColorStop(.6,rgba(Cy,.05));g0.addColorStop(1,rgba(V,0));c.fillStyle=g0;c.fillRect(z[0]-20,z[1]-20,z[2]+40,z[3]+40);
  c.globalCompositeOperation='lighter';for(i=0;i<3;i++){var ro=t*.004*(i%2?-1:1)+i*1.047;c.strokeStyle=rgba(i%2?Cy:V,.22);c.lineWidth=1;c.setLineDash([2,6]);c.lineDashOffset=-t*.3;c.beginPath();c.ellipse(ax,ay,Rm*.78,Rm*.26,ro,0,6.2832);c.stroke();c.setLineDash([]);
   var u=t*.03*(i%2?-1:1)+i*2.1,ex=Math.cos(u)*Rm*.78,ey=Math.sin(u)*Rm*.26,px=ax+ex*Math.cos(ro)-ey*Math.sin(ro),py=ay+ex*Math.sin(ro)+ey*Math.cos(ro);c.fillStyle=rgba([255,255,255],.7);c.beginPath();c.arc(px,py,1.5,0,6.2832);c.fill();}
  for(i=0;i<36;i++){var a1=i*2.39996,rr=Math.sqrt((i+.5)/36)*10,pu=.6+.4*Math.sin(t*.05+i);c.fillStyle=rgba(i%3?[255,206,110]:[255,240,220],.55*pu);c.fillRect(ax+Math.cos(a1+t*.01)*rr-.8,ay+Math.sin(a1+t*.01)*rr-.8,1.6,1.6);}
  var g1=c.createRadialGradient(ax,ay,0,ax,ay,18);g1.addColorStop(0,rgba([255,236,200],.35));g1.addColorStop(1,rgba([255,206,110],0));c.fillStyle=g1;c.beginPath();c.arc(ax,ay,18,0,6.2832);c.fill();
  c.restore();return;}
 c.save();
 /* R150 : la zone se lit — voile teinté qui respire, bande de lumière qui la balaie, liseré en pointillé et coins marqués */
 var br=.5+.5*Math.sin(t*.03),gf=c.createLinearGradient(z[0],z[1],z[0],z[1]+z[3]);gf.addColorStop(0,rgba(P,.05+.03*br));gf.addColorStop(.5,rgba(P,.1+.04*br));gf.addColorStop(1,rgba(P,.05+.03*br));
 c.fillStyle=gf;c.fillRect(z[0],z[1],z[2],z[3]);
 var sw=((t*.6)%(z[2]+z[3]+120))-60;c.save();c.beginPath();c.rect(z[0],z[1],z[2],z[3]);c.clip();c.globalCompositeOperation='lighter';
 var gs=c.createLinearGradient(z[0]+sw-40,z[1],z[0]+sw+40,z[1]+40);gs.addColorStop(0,rgba(P,0));gs.addColorStop(.5,rgba(P,.12));gs.addColorStop(1,rgba(P,0));c.fillStyle=gs;c.fillRect(z[0],z[1],z[2],z[3]);c.restore();
 c.strokeStyle=rgba(P,.45+.2*br);c.lineWidth=1.2;c.setLineDash([6,5]);c.lineDashOffset=-t*.3;c.strokeRect(z[0]+1,z[1]+1,z[2]-2,z[3]-2);c.setLineDash([]);
 c.strokeStyle=rgba([255,200,230],.8);c.lineWidth=2;var cc=12,cs=[[z[0],z[1],1,1],[z[0]+z[2],z[1],-1,1],[z[0],z[1]+z[3],1,-1],[z[0]+z[2],z[1]+z[3],-1,-1]];
 for(i=0;i<4;i++){var q=cs[i];c.beginPath();c.moveTo(q[0]+q[2]*cc,q[1]+q[3]*1);c.lineTo(q[0]+q[2]*1,q[1]+q[3]*1);c.lineTo(q[0]+q[2]*1,q[1]+q[3]*cc);c.stroke();}
 c.lineWidth=1;
 for(i=0;i<nx;i++)for(j=0;j<ny;j++){var x=ox+i*sp,y=oy+j*sp,e=Math.min(i+1,nx-i,j+1,ny-j),fade=Math.min(1,e/1.6),w=.5+.5*Math.sin(t*.04-(i+j)*.5),a=(.3+.32*w)*fade,r=3.6+.9*w;
  c.strokeStyle=rgba(P,a);c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();
  if(z[4]>0){c.fillStyle=rgba(P,a*1.6);c.beginPath();c.arc(x,y,1.1,0,6.2832);c.fill();}
  else{c.beginPath();c.moveTo(x-r*.7,y-r*.7);c.lineTo(x+r*.7,y+r*.7);c.moveTo(x+r*.7,y-r*.7);c.lineTo(x-r*.7,y+r*.7);c.stroke();}}
 c.restore();}
/* ══ R143 — FENTE ACCÉLÉRATRICE (cyclotron) ══ z=[x,y,w,h,a] : une tension alternative bat entre les deux « D » —
   des éclairs fins montent et descendent dans la fente, au rythme de la radiofréquence. */
/* R147 — BOBINE (canon de Gauss, monde Magnétisme) : spires de cuivre-violet vues de biais autour de l'axe ; au passage de la
   particule, la bobine s'allume (cyan), ses lignes de champ se referment en boucles et une flèche pousse vers l'avant. */
function coil(c,co,age){var t=now(),V=[168,120,255],Cy=[90,220,255],Wc=[236,248,255],n=Math.hypot(co[2],co[3])||1,ax=co[2]/n,ay=co[3]/n,px=-ay,py=ax,R=15,on=age<22?1-age/22:0,k,i;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 /* lignes de champ : boucles qui sortent d'un bout et rentrent par l'autre */
 for(k=1;k<=3;k++){var lw=R*(1+k*.55),lh=8+k*7,al=(.05+.22*on)*(1-k*.22);c.strokeStyle=rgba(on>.05?Cy:V,al);c.lineWidth=.7;
  for(var sd=-1;sd<=1;sd+=2){c.beginPath();for(i=0;i<=24;i++){var u=i/24*Math.PI,xa=Math.cos(u)*lh,xp=sd*(R*.6+Math.sin(u)*lw*.55);
    var X=co[0]+ax*xa+px*xp,Y=co[1]+ay*xa+py*xp;if(i)c.lineTo(X,Y);else c.moveTo(X,Y);}c.stroke();}}
 /* spires */
 for(k=-3;k<=3;k++){var o=k*2.6,cx=co[0]+ax*o,cy=co[1]+ay*o,ph=t*.05+k;
  c.strokeStyle=rgba(on>.05?Wc:V,.22+.5*on);c.lineWidth=on>.05?1.3:.9;c.beginPath();
  c.ellipse(cx,cy,R,4.2,Math.atan2(py,px),0,6.2832);c.stroke();}
 c.strokeStyle=rgba(V,.16+.3*on);c.lineWidth=7;c.beginPath();c.ellipse(co[0],co[1],R+1,6,Math.atan2(py,px),0,6.2832);c.stroke();
 /* bornes et courant qui circule */
 for(k=0;k<2;k++){var sg=k?1:-1,bx=co[0]+px*R*sg,by=co[1]+py*R*sg,g=c.createRadialGradient(bx,by,0,bx,by,5+on*6);g.addColorStop(0,rgba(on>.05?Cy:V,.8));g.addColorStop(1,rgba(V,0));c.fillStyle=g;c.beginPath();c.arc(bx,by,5+on*6,0,6.2832);c.fill();}
 var u2=(t*.12)%6.2832;c.fillStyle=rgba(Wc,.35+.6*on);c.beginPath();c.arc(co[0]+px*Math.cos(u2)*R+ax*Math.sin(u2)*1.5,co[1]+py*Math.cos(u2)*R+ay*Math.sin(u2)*1.5,1.3,0,6.2832);c.fill();
 if(on>.05){c.strokeStyle=rgba(Cy,.8*on);c.lineWidth=1.6;var tx=co[0]+ax*18,ty=co[1]+ay*18;c.beginPath();c.moveTo(co[0]-ax*6,co[1]-ay*6);c.lineTo(tx,ty);c.moveTo(tx,ty);c.lineTo(tx-ax*5+px*3.5,ty-ay*5+py*3.5);c.moveTo(tx,ty);c.lineTo(tx-ax*5-px*3.5,ty-ay*5-py*3.5);c.stroke();}
 c.restore();}
/* R147 — SPECTROMÈTRE (Aston, 1919) : demi-cercles de référence en pointillé fin (un par vitesse possible) qui naissent de la
   fente et retombent sur la plaque ; la plaque porte une graduation et des raies lumineuses aux points de chute. */
function spectro(c,sp){var t=now(),V=[168,120,255],Cy=[90,220,255],Wc=[236,248,255],i,k;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(i=0;i<sp.rs.length;i++){var r=sp.rs[i],cx=sp.x-r,ph=(t*.012+i*.7)%1;c.setLineDash([1.5,5]);c.lineDashOffset=-t*.3;c.strokeStyle=rgba(i===sp.hi?Cy:Wc,i===sp.hi?.5:.32);c.lineWidth=1;
  c.beginPath();c.arc(cx,sp.y,r,Math.PI,0,false);c.stroke();c.setLineDash([]);
  var a=Math.PI+ph*Math.PI,px=cx+Math.cos(a)*r,py=sp.y+Math.sin(a)*r;c.fillStyle=rgba(Wc,.5*(1-Math.abs(ph-.5)*1.2));c.beginPath();c.arc(px,py,1.4,0,6.2832);c.fill();   /* une particule fantôme parcourt chaque orbite */
  var lx=sp.x-2*r;c.strokeStyle=rgba(i===sp.hi?Cy:V,.45);c.lineWidth=1.4;c.beginPath();c.moveTo(lx,sp.p-2);c.lineTo(lx,sp.p-9);c.stroke();}   /* raie sur la plaque */
 c.strokeStyle=rgba(Wc,.25);c.lineWidth=.7;for(k=sp.p0;k<=sp.p1;k+=8){c.beginPath();c.moveTo(k,sp.p+3);c.lineTo(k,sp.p+(k%40===0?9:6));c.stroke();}   /* graduation */
 c.restore();}
function kickgap(c,z){var t=now(),P=[255,111,181],Wc=[255,230,245],k;c.save();c.globalCompositeOperation='lighter';
 var ph=.5+.5*Math.sin(t*.12),g=c.createLinearGradient(z[0],0,z[0]+z[2],0);g.addColorStop(0,rgba(P,0));g.addColorStop(.5,rgba(P,.10+.18*ph));g.addColorStop(1,rgba(P,0));
 c.fillStyle=g;c.fillRect(z[0],z[1],z[2],z[3]);
 for(k=0;k<5;k++){var y=z[1]+((t*1.6*(k%2?1:-1)+k*z[3]/5)%z[3]+z[3])%z[3];c.strokeStyle=rgba(Wc,.35+.4*ph);c.lineWidth=1;c.beginPath();
  c.moveTo(z[0]+2,y);c.lineTo(z[0]+z[2]/2,y+(k%2?5:-5));c.lineTo(z[0]+z[2]-2,y);c.stroke();}
 c.restore();}
/* ══ R144 — FAILLE ORIENTÉE ══ p=[ax,ay,bx,by,angle,1] : chaque bouche est un « corral quantique » — un anneau d'atomes où une onde
   stationnaire vibre (le microscope à effet tunnel les a photographiés) ; la sortie dit sa direction par des chevrons. Vert Faille. */
function rift(c,p){var t=now(),Gc=[92,232,168],Wc=[220,255,240],k,j;
 for(j=0;j<2;j++){var x=j?p[2]:p[0],y=j?p[3]:p[1];c.save();c.globalCompositeOperation='lighter';
  for(k=1;k<=4;k++){var r=k*4.2,a=.5+.5*Math.cos(t*.08-k*1.3);c.strokeStyle=rgba(Gc,.10+.22*a);c.lineWidth=1.2;c.beginPath();c.arc(x,y,r,0,6.2832);c.stroke();}   /* onde stationnaire */
  for(k=0;k<14;k++){var an=k/14*6.2832+(j?0:t*.004),ax=x+Math.cos(an)*20,ay=y+Math.sin(an)*20;var gr=c.createRadialGradient(ax,ay,0,ax,ay,4);gr.addColorStop(0,rgba(Wc,.9));gr.addColorStop(1,rgba(Gc,0));c.fillStyle=gr;c.beginPath();c.arc(ax,ay,4,0,6.2832);c.fill();}   /* atomes du corral */
  if(j){var pa=p[4]*Math.PI/180,ux=Math.cos(pa),uy=Math.sin(pa);for(k=0;k<3;k++){var o=26+k*10+((t*.6)%10),cx=x+ux*o,cy=y+uy*o;c.strokeStyle=rgba(Gc,.6-.17*k);c.lineWidth=1.6;c.beginPath();c.moveTo(cx-ux*5-uy*5,cy-uy*5+ux*5);c.lineTo(cx,cy);c.lineTo(cx-ux*5+uy*5,cy-uy*5-ux*5);c.stroke();}}
  c.restore();}
 c.save();c.strokeStyle=rgba(Gc,.22);c.setLineDash([2,6]);c.lineWidth=1;c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(p[2],p[3]);c.stroke();c.restore();}
/* ══ R144 — COUTURE TORIQUE ══ w=[y0,y1] : les bords gauche et droit sont un seul et même lieu ; deux coutures identiques battent
   à l'unisson et, quand la particule passe, l'éclair part d'un bord et arrive à l'autre. */
var SEAMF=[],SEAMON=false;
function seam(c,w){if(!SEAMON&&window.BUS){SEAMON=true;BUS.on('ball.wrap',function(e){SEAMF.push({y:e.y,l:1});});}var t=now(),Gc=[92,232,168],Wc=[220,255,240],k,i;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(k=0;k<2;k++){var x=k?358.5:1.5,g=c.createLinearGradient(k?360:0,0,k?344:16,0);g.addColorStop(0,rgba(Gc,.30));g.addColorStop(1,rgba(Gc,0));c.fillStyle=g;c.fillRect(k?344:0,w[0],16,w[1]-w[0]);
  for(i=0;i<(w[1]-w[0])/18;i++){var y=w[0]+((i*18+t*.5)%(w[1]-w[0]));c.strokeStyle=rgba(Wc,.35+.25*Math.sin(i*1.7));c.lineWidth=1.4;c.beginPath();c.moveTo(x,y);c.lineTo(x+(k?-5:5),y+5);c.stroke();}}
 for(i=SEAMF.length-1;i>=0;i--){var f=SEAMF[i];for(k=0;k<2;k++){var gg=c.createRadialGradient(k?360:0,f.y,0,k?360:0,f.y,40*(1.4-f.l));gg.addColorStop(0,rgba(Wc,.7*f.l));gg.addColorStop(1,rgba(Gc,0));c.fillStyle=gg;c.beginPath();c.arc(k?360:0,f.y,40*(1.4-f.l),0,6.2832);c.fill();}f.l-=.04;if(f.l<=0)SEAMF.splice(i,1);}
 c.restore();}
/* ══ R145 — CORDE DE HARPE ══ la corde élastique est dessinée comme une corde vibrante : le fil, son reflet par rapport à la
   corde au repos (l'enveloppe d'une onde stationnaire), un frémissement en mode 2 au repos, et deux chevilles. Or rosé Filaments. */
var HITS={},HARPON=false,SNAPS=[];
/* R146 — CORDES VIBRANTES (monde 10, « les modes de vibration ») : une corde frappée chante sur le mode dont le ventre est au point
   d'impact (n = 1/(2·min(u,1-u))) ; nœuds marqués, onde stationnaire qui s'éteint. Corde entraînée : fronde (tension → détente). */
function harp(c,P,i0,i1,R0,r){
 if(!HARPON&&window.BUS){HARPON=true;BUS.on('ball.rope',function(e){if(e.r==null||!window.QP)return;var R1=QP.ropes[e.r];if(!R1)return;var A=QP.p[R1.i0],B=QP.p[R1.i1],dx=B.x-A.x,dy=B.y-A.y,l2=dx*dx+dy*dy||1,u=((e.x-A.x)*dx+(e.y-A.y)*dy)/l2;u=u<.04?.04:u>.96?.96:u;
  var n=Math.max(1,Math.min(5,Math.round(1/(2*Math.min(u,1-u)))));HITS[e.r]={t:now(),n:n,a:Math.min(9,2+e.v*.9)};});}
 var t=now(),G=[232,150,190],Wc=[255,236,244],V=[178,130,255],A=P[i0],B=P[i1],dx=B.x-A.x,dy=B.y-A.y,L2=Math.hypot(dx,dy)||1,ux=dx/L2,uy=dy/L2,i,
  h=HITS[r],age=h?t-h.t:999,amp=h&&age<150?h.a*Math.exp(-age/40):0,n=h?h.n:1,idle=Math.sin(t*.09)*1.1,ten=R0&&R0.drv&&R0.u!=null&&R0.u<R0.drv.wv?R0.u/R0.drv.wv:0;
 function pt(i,mir){var p=P[i],u=((p.x-A.x)*ux+(p.y-A.y)*uy),v=((p.x-A.x)*-uy+(p.y-A.y)*ux),f=u/L2,sh=Math.sin(Math.PI*2*f)*idle+Math.sin(Math.PI*n*f)*Math.cos(age*.55)*amp;v=(mir?-v:v)+(mir?-sh:sh);return [A.x+ux*u-uy*v,A.y+uy*u+ux*v];}
 c.save();c.lineCap='round';c.lineJoin='round';c.globalCompositeOperation='lighter';
 if(amp>.4){c.beginPath();for(i=i0;i<=i1;i++){var q=pt(i,1);if(i===i0)c.moveTo(q[0],q[1]);else c.lineTo(q[0],q[1]);}c.strokeStyle=rgba(V,.35*Math.min(1,amp/4));c.lineWidth=1.1;c.stroke();   /* enveloppe miroir : le fuseau de l'onde stationnaire */
  c.fillStyle=rgba(Wc,.8*Math.min(1,amp/3));for(var k=1;k<n;k++){var f=k/n;c.beginPath();c.arc(A.x+dx*f,A.y+dy*f,1.7,0,6.2832);c.fill();}}   /* nœuds */
 c.beginPath();for(i=i0;i<=i1;i++){var q2=pt(i,0);if(i===i0)c.moveTo(q2[0],q2[1]);else c.lineTo(q2[0],q2[1]);}
 c.strokeStyle=rgba(G,.22+ten*.3);c.lineWidth=6+ten*4;c.stroke();c.strokeStyle=rgba(Wc,.85);c.lineWidth=1.8+amp*.08;c.stroke();
 [A,B].forEach(function(p){var g=c.createRadialGradient(p.x,p.y,0,p.x,p.y,7);g.addColorStop(0,rgba(Wc,.95));g.addColorStop(1,rgba(G,0));c.fillStyle=g;c.beginPath();c.arc(p.x,p.y,7,0,6.2832);c.fill();});
 c.restore();}
/* fronde : lv.fork={tips:[[x,y],[x,y]],base:[x,y],att:[[corde,0|1],…]} — un diapason lumineux (expérience de Melde) dont les
   branches tiennent les élastiques ; l'élastique s'étire et rougit pendant la tension, éclair et onde de choc à la détente. */
function fork(c,lv,QPv){var FF=lv.fork;if(!FF||!QPv)return;if(!FF.length)FF=[FF];for(var fi=0;fi<FF.length;fi++)fork1(c,FF[fi],QPv,fi);}
function fork1(c,F,QPv,fi){var t=now(),G=[232,150,190],Wc=[255,236,244],V=[178,130,255],Ho=[255,196,150],i,
 str=QPv.ropes.filter(function(r){return F.player?(r.drv&&!r.str):r.str;});
 var R0=F.player?str[0]:str[(F.att&&F.att[0])?F.att[0][0]:0],d=R0&&R0.drv,u=R0&&R0.u!=null?R0.u:0,k=d?d.wv:1,ten=u<k?u/k:0,tp=F.tips,b=F.base,jx=(tp[0][0]+tp[1][0])/2,jy=F.j?F.j-18:Math.max(tp[0][1],tp[1][1])+46;
 if(F.player&&R0)F.att=[[0,0],[0,1]];
 if(R0){if(R0.lu!=null&&R0.lu<k&&u>=k){var mi=(R0.i0+R0.i1)>>1;SNAPS.push({t:t,x:QPv.p[F.player?mi:R0.i1].x,y:QPv.p[F.player?mi:R0.i1].y});}R0.lu=u;}
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 /* diapason : manche, fourche en U, branches */
 c.strokeStyle=rgba(V,.18);c.lineWidth=9;c.beginPath();c.moveTo(b[0],b[1]);c.lineTo(jx,jy+18);c.stroke();
 for(var m=0;m<2;m++){c.strokeStyle=m?rgba(Wc,.32):rgba(V,.14);c.lineWidth=m?1.1:6;c.beginPath();c.moveTo(b[0],b[1]);c.lineTo(jx,jy+18);
  c.moveTo(tp[0][0],tp[0][1]);c.bezierCurveTo(tp[0][0],jy+8,jx-(jx-tp[0][0])*.4,jy+18,jx,jy+18);c.bezierCurveTo(jx+(tp[1][0]-jx)*.4,jy+18,tp[1][0],jy+8,tp[1][0],tp[1][1]);c.stroke();}
 /* résonance du diapason : anneaux qui partent des pointes */
 for(i=0;i<2;i++){var rr=((t*.6+i*9)%26);c.strokeStyle=rgba(V,.3*(1-rr/26));c.lineWidth=1;c.beginPath();c.arc(tp[i][0],tp[i][1],4+rr,0,6.2832);c.stroke();}
 /* élastiques : des pointes aux coins de la poche */
 if(F.player&&!R0){var pu=.35+.25*Math.sin(t*.08);c.strokeStyle=rgba(Wc,pu);c.lineWidth=1.2;c.setLineDash([3,5]);c.lineDashOffset=-t*.4;c.beginPath();c.moveTo(tp[0][0],tp[0][1]);c.quadraticCurveTo(jx,(tp[0][1]+tp[1][1])/2+34,tp[1][0],tp[1][1]);c.stroke();c.setLineDash([]);}   /* fronde vide : la poche à tendre, en pointillé */
 (F.player&&!R0?[]:(F.att||[])).forEach(function(a,ix){var R1=str[a[0]];if(!R1)return;var p=QPv.p[a[1]?R1.i1:R1.i0],q=tp[ix],len=Math.hypot(p.x-q[0],p.y-q[1]),col=[G[0]+(Ho[0]-G[0])*ten|0,G[1]+(Ho[1]-G[1])*ten|0,G[2]+(Ho[2]-G[2])*ten|0];
  var nx=-(p.y-q[1])/(len||1),ny=(p.x-q[0])/(len||1),wob=Math.sin(t*1.3)*(u>=k?4:u<.1?4*(1-u/.1):0);
  c.strokeStyle=rgba(col,.22+ten*.35);c.lineWidth=7-ten*3;c.beginPath();c.moveTo(q[0],q[1]);c.quadraticCurveTo((q[0]+p.x)/2+nx*wob,(q[1]+p.y)/2+ny*wob,p.x,p.y);c.stroke();
  c.strokeStyle=rgba(Wc,.8);c.lineWidth=1.4;c.setLineDash([2+ten*6,3]);c.lineDashOffset=-t*.6;c.stroke();c.setLineDash([]);
  var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],8);g.addColorStop(0,rgba(Wc,.95));g.addColorStop(1,rgba(V,0));c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],8,0,6.2832);c.fill();});
 /* détente : éclair et onde de choc */
 for(i=SNAPS.length-1;i>=0;i--){var sn=SNAPS[i],ag=t-sn.t;if(ag>34||ag<0){SNAPS.splice(i,1);continue;}var f=ag/34;
  c.strokeStyle=rgba(Wc,.7*(1-f));c.lineWidth=2.4*(1-f)+.5;c.beginPath();c.arc(sn.x,sn.y,8+f*70,0,6.2832);c.stroke();
  c.strokeStyle=rgba(G,.45*(1-f));c.lineWidth=1;c.beginPath();c.arc(sn.x,sn.y,4+f*44,0,6.2832);c.stroke();
  if(ag<6){var g2=c.createRadialGradient(sn.x,sn.y,0,sn.x,sn.y,30);g2.addColorStop(0,rgba(Wc,.8*(1-ag/6)));g2.addColorStop(1,rgba(G,0));c.fillStyle=g2;c.beginPath();c.arc(sn.x,sn.y,30,0,6.2832);c.fill();}}
 c.restore();}
window.VX={finale:finale,qent:qent,qgate:qgate,qsup:qsup,qdet:qdet,qtdil:qtdil,harp:harp,fork:fork,coil:coil,spectro:spectro,seam:seam,rift:rift,kickgap:kickgap,bfield:bfield,gzone:gzone,well:well,pendulum:pendulum,yoke:yoke,updraft:updraft,vortex:vortex,back:back,tunnel:tunnel,flow:flow,nd:nd,fixed:fixed,stroke:stroke,core:core,ball:ball,hero:hero,heroWall:heroWall,curve:curve,joints:joints};   /* R116 : joints exporté — le cadre des fiches du didacticiel parle la langue des murs */
})();
