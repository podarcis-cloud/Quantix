/* ══ HÉROS DE L'ACCUEIL (R188) — « L'odyssée » ══
   Une boucle de ≈ 21 s : la particule jaillit d'un vortex, traverse les onze mondes à toute allure — chaque monde est une
   figure de parcours qui lui est propre (trait tracé, rebonds, looping, pont de glace, colonne d'air et cyclone, escalier
   mécanique, gravité renversée, fronde magnétique, faille et portails, corde-tremplin, superposition) — puis tombe dans le
   bassin d'arrivée, qui s'ouvre en vortex et la renvoie au départ.
   Par moments la particule « décide » du décor (trait qui se trace devant elle, pont qui gèle, marches qui montent, gravité
   qui bascule, faille qui s'ouvre, dédoublement) : ralenti, onde, image dédoublée.
   Coordonnées : chaque monde est une scène de 360 × 480 unités (l'unité des niveaux), posées côte à côte ; la caméra suit.
   Rendu : les pièces viennent de visuals.js (VX.curve, VX.stroke, VX.ball, VX.updraft, VX.vortex) quand il est chargé ;
   fonds : dossier assets/img/hero, h01 à h11 en jpg (réductions des illustrations des mondes). Aucun texte propre : les noms des mondes
   viennent de WORLDS (levels.js) / WORLDS_EN (i18n.js). */
var QHERO=(function(){
 var UW=360,UH=480,R=10,PI=Math.PI;
 var COL=['#43D5F5','#FF8A3C','#A878FF','#8FE3FF','#A8C8E8','#E0B24C','#8C7BFF','#FF6FB5','#5CE8A8','#E8B98A','#A878FF','#9BEB4B'];
 var IMGS=[],imgBase='assets/img/hero/';
 function img(k){if(k>10)return null;if(!IMGS[k]){var im=new Image();im.decoding='async';
   im.src=(window.QHERO_IMG&&window.QHERO_IMG[k])||(imgBase+'h'+(k<9?'0':'')+(k+1)+'.jpg');IMGS[k]=im;}var I=IMGS[k];return I.complete&&I.naturalWidth?I:null;}
 function rgb(h){var n=parseInt(h.slice(1),16);return [n>>16&255,n>>8&255,n&255];}
 function rgba(h,a){var q=rgb(h);return 'rgba('+q[0]+','+q[1]+','+q[2]+','+a+')';}
 function cl(u){return u<0?0:u>1?1:u;}
 function ease(e,u){u=cl(u);switch(e){case 'in':return u*(.45+.55*u);case 'in3':return u*u*u;case 'out':return 1-(1-u)*(.45+.55*(1-u));   /* R190 : départs et arrivées jamais à vitesse nulle — le rythme coule d'un monde à l'autre */
  case 'io':return .5*u+.5*(u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2);case 'loop':return u-.07*Math.sin(2*PI*u);default:return u;}}
 function bz(a,b,c2,d,n){var o=[],i,u,v;n=n||28;for(i=0;i<=n;i++){u=i/n;v=1-u;o.push([v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c2[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c2[1]+u*u*u*d[1]]);}return o;}
 function lift(P,k){var o=[],i;for(i=0;i<P.length;i++){var a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],tx=b[0]-a[0],ty=b[1]-a[1],l=Math.hypot(tx,ty)||1,nx=ty/l,ny=-tx/l;if(ny>0){nx=-nx;ny=-ny;}o.push([P[i][0]+nx*k,P[i][1]+ny*k]);}return o;}
 function along(P,u){var L=[0],i;for(i=1;i<P.length;i++)L.push(L[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));var s=u*L[L.length-1];
  for(i=1;i<P.length;i++)if(L[i]>=s){var f=(s-L[i-1])/((L[i]-L[i-1])||1);return [P[i-1][0]+(P[i][0]-P[i-1][0])*f,P[i-1][1]+(P[i][1]-P[i-1][1])*f];}return P[P.length-1].slice();}
 /* segments : chacun part de la position courante */
 function Ln(b,d,e){return {k:'l',b:b,d:d,e:e};}
 function Jp(b,h,d,e){return {k:'j',b:b,h:h,d:d,e:e};}
 function Cv(P,d,e){return {k:'c',P:P,d:d,e:e};}
 function Fn(f,d,e){return {k:'f',f:f,d:d,e:e};}
 function Hd(d){return {k:'h',d:d};}
 function Tp(b,d){return {k:'t',b:b,d:d};}
 function sPos(s,a,u){var v=ease(s.e,u);
  if(s.k==='l')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v];
  if(s.k==='j')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v-4*s.h*v*(1-v)];
  if(s.k==='c')return along([a].concat(s.P),v);
  if(s.k==='f')return s.f(v,a);
  if(s.k==='t')return u<1?null:s.b.slice();
  return a.slice();}
 /* ——— les douze scènes ——— */
 var S1=bz([40,226],[118,330],[250,352],[362,288]);
 var LOOPC=[180,258],LOOPR=62;
 var STEPX=[40,100,160,220,280],STEPY=[410,350,290,230,170];
 var MAG=[190,250];
 var Z=[
  {w:0,start:[45,112],segs:[Hd(340),Ln([45,212],360,'in'),Cv(lift(S1,R+2),1280,'in')],
   pw:[[120,820]],ev:[[700,'hit',5.5,0]]},
  {w:1,segs:[Jp([80,384],40,400,'in'),Jp([190,322],120,500),Jp([300,240],140,500),Jp([362,172],50,280,'out')],ev:[[400,'hit',7,1],[900,'hit',7.5,1],[1400,'hit',8,1]]},
  {w:2,segs:[Ln([110,318],400,'in'),Ln([180,320],110),Fn(function(u){var a=PI/2-u*2*PI;return [LOOPC[0]+Math.cos(a)*LOOPR,LOOPC[1]+Math.sin(a)*LOOPR];},900,'loop'),Ln([362,318],300,'out')],ev:[[510,'hit',5,3],[1410,'boost']]},
  {w:3,segs:[Ln([300,338],720),Cv([[318,336],[336,326],[352,306]],170),Jp([362,290],8,80)],pw:[[0,520]],ev:[[0,'freeze'],[60,'hit',4.5,4]]},
  {w:4,segs:[Jp([150,330],24,380,'in'),Fn(function(u){return [150+22*Math.sin(u*PI*5),330-220*u];},880,'io'),Ln([214,130],150),
   Fn(function(u){var a=PI+u*2.5*PI;return [262+48*Math.cos(a),130+48*Math.sin(a)];},720,'in'),Ln([362,118],220,'out')],ev:[[380,'hit',5,0]]},
  {w:5,segs:[Jp([65,399],20,440,'in'),Jp([125,339],36,250),Jp([185,279],36,250),Jp([245,219],36,250),Jp([305,159],36,250),Jp([362,128],26,230,'out')],
   pw:[[300,1440]],ev:[[440,'hit',6,0],[690,'hit',4.5,0],[940,'hit',4.5,0],[1190,'hit',4.5,0],[1440,'hit',6.5,0]]},
  {w:6,segs:[Ln([95,41],420,'in'),Ln([270,41],620),Fn(function(u,a){return [a[0]+(362-a[0])*u,a[1]+(250-a[1])*u*u];},520)],pw:[[0,420],[1040,1560]],ev:[[420,'hit',6,0,0,1]]},
  {w:7,segs:[Ln([120,300],300,'in'),Fn(function(u){var a=2.52-u*3*PI,r=86-40*Math.sin(PI*u);return [MAG[0]+r*Math.cos(a),MAG[1]+r*Math.sin(a)];},1100,'in'),Ln([362,182],300,'out')]},
  {w:8,segs:[Ln([150,220],360,'in'),Tp([300,100],230),Fn(function(u){return [300+62*u,100+200*u*u];},420)],pw:[[0,600]],ev:[[360,'warp'],[590,'warp']]},
  {w:9,segs:[Jp([150,349],30,380,'in'),Ln([150,412],250,'out'),Jp([330,150],150,680,'out'),Ln([362,168],150)],ev:[[380,'hit',5,0],[630,'boost']]},
  {w:10,segs:[Ln([60,212],250),Fn(function(u){return [60+240*u,212+8*Math.sin(u*PI)];},900,'io'),Ln([362,252],260,'out')],pw:[[250,1150]],ev:[[1150,'collapse']]},
  {w:11,segs:[Jp([205,388],46,600,'in'),Hd(260),Fn(function(u,a){var r=18*(1-u),an=u*5*PI;return [205+r*Math.cos(an),372+(a[1]-372)*(1-u)+r*Math.sin(an)*.5];},1250,'in'),Hd(380)],ev:[[600,'hit',7,0],[2110,'flash']]}
 ];
 /* durées, départs, sorties */
 var TOT=0,i,j;
 (function(){var cur=Z[0].start.slice(),gx=0;for(i=0;i<Z.length;i++){var z=Z[i];z.t0=TOT;z.x0=i*UW;z.in=[cur[0]-(i?UW:0),cur[1]];if(!i)z.in=z.start.slice();
   var p=z.in.slice(),d=0;z.st=[];for(j=0;j<z.segs.length;j++){var s=z.segs[j];z.st.push({t:d,a:p.slice()});var q=sPos(s,p,1);p=q?q:p;d+=s.d;}
   z.d=d;z.out=p;TOT+=d;cur=[p[0],p[1]];}})();
 function local(z,lt){var k,pos=null,seg=null,su=0;for(k=0;k<z.segs.length;k++){var s=z.segs[k],st=z.st[k];if(lt<st.t+s.d||k===z.segs.length-1){su=cl((lt-st.t)/s.d);pos=sPos(s,st.a,su);seg=s;break;}}return {p:pos,s:seg,u:su};}
 /* état d'animation */
 var T0=null,last=0,hold=0,VQ=null,sq={t:0,nx:0,ny:-1},hits=[],FL0=S1.map(function(q){return [q[0],q[1]-R-2];}),BUB=[0,1,2].map(function(n){var o=[],th;for(th=0;th<14;th+=.22){var r=34*Math.exp(-.16*th);o.push([[52,182,300][n]+r*Math.cos(th*(n%2?-1:1)+n),[96,60,118][n]+r*Math.sin(th*(n%2?-1:1)+n)]);}return o;}),cam={x:0,y:240,ok:false},trail=[],parts=[],seen={},shake=0,flashA=0,lastZone=-1,label={k:-1,t:0};
 function burst(x,y,col,n,sp){for(var q=0;q<n;q++){var a=Math.random()*2*PI,v=sp*(.4+Math.random());parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1,c:col,s:.8+Math.random()*1.6});}}
 function spiral(c,x,y,Rm,al,rot,cols){c.save();c.translate(x,y);c.rotate(rot);c.globalCompositeOperation='lighter';c.lineCap='round';
  for(var a=0;a<6;a++){c.beginPath();for(var s=0;s<=40;s++){var u=s/40,r=Rm*u,an=a*PI/3+u*3.2;var px=Math.cos(an)*r,py=Math.sin(an)*r*.62;s?c.lineTo(px,py):c.moveTo(px,py);}
   c.strokeStyle=rgba(cols[a%cols.length],al*.8);c.lineWidth=2.2;c.stroke();}
  var g=c.createRadialGradient(0,0,0,0,0,Rm*.5);g.addColorStop(0,'rgba(241,244,246,'+al+')');g.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*.5,0,2*PI);c.fill();c.restore();}
 function wall(c,P,mat,col){var V=window.VX;if(V&&V.curve&&mat!=null){try{V.curve(c,P,mat,{noHang:1});return;}catch(x){}}
  c.save();c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.35);c.lineWidth=7;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=col;c.lineWidth=2;c.stroke();c.restore();}
 function glowLine(c,P,col,w,al){c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.25*al);c.lineWidth=w*4;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=rgba(col,al);c.lineWidth=w;c.stroke();c.restore();}
 function gear(c,x,y,r,rot,col,al){c.save();c.translate(x,y);c.rotate(rot);c.strokeStyle=rgba(col,al);c.lineWidth=1.4;c.beginPath();
  for(var k=0;k<=40;k++){var a=k/40*2*PI,rr=r*(k%4<2?1:.84);k?c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):c.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}c.stroke();
  c.beginPath();c.arc(0,0,r*.32,0,2*PI);c.stroke();c.restore();}
 /* ——— vortex d'arrivée : disque d'accrétion de matière lumineuse (grains des onze mondes), horizon sombre, anneau de photons,
    arc de lentille gravitationnelle au-dessus, bras en pointillés, arcs électriques — la langue des murs et des chocs du jeu ——— */
 function vortexQ(c,x,y,Rm,al,dt,suck,sd){var n,q,a0,rr,TL=-.18;   /* R223 : sd = rendu poussière d'étoile (fin) */
  if(!VQ){VQ=[];for(n=0;n<210;n++)VQ.push({r:Math.random(),a:Math.random()*2*PI,c:COL[n%12],w:.65+Math.random()*1.05});}
  c.save();c.translate(x,y);c.rotate(TL);c.lineCap='round';
  var Rh=Rm*.15,g=c.createRadialGradient(0,0,Rh,0,0,Rm*1.15);g.addColorStop(0,'rgba(140,123,255,'+(.32*al)+')');g.addColorStop(.45,'rgba(77,215,255,'+(.10*al)+')');g.addColorStop(1,'rgba(5,7,13,0)');
  c.save();c.scale(1,.54);c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*1.15,0,2*PI);c.fill();c.restore();   /* halo sans bord : le dégradé s'éteint avant l'ellipse */
  function grains(front){c.globalCompositeOperation='lighter';for(n=0;n<VQ.length;n++){q=VQ[n];
    if(front===null){var om=.0021/Math.pow(.12+q.r,1.5);q.a+=om*dt;q.r-=dt*.00009*(1+suck*4)*(1.2-q.r);if(q.r<.03){q.r=1;q.a=Math.random()*2*PI;}continue;}
    var s=Math.sin(q.a);if((s>0)!==front)continue;rr=Rh*1.15+q.r*(Rm-Rh*1.15);a0=q.a-Math.min(1.1,.16/Math.pow(.12+q.r,1.2));
    var lum=al*(.18+.75*(1-q.r))*(front?1:.55);
    if(sd){for(var kd=0;kd<4;kd++){var ad=q.a-(q.a-a0)*kd/3.2,sz=q.w*(1.5-q.r*.8)*(1-kd*.2);c.fillStyle=rgba(q.r<.22?'#F1F4F6':q.c,lum*(1-kd*.22));c.fillRect(Math.cos(ad)*rr-sz/2,Math.sin(ad)*rr*.42-sz/2,sz,sz);}continue;}
    c.strokeStyle=rgba(q.r<.22?'#F1F4F6':q.c,lum);c.lineWidth=q.w*(1.3-q.r*.7);
    c.beginPath();c.ellipse(0,0,rr,rr*.42,0,a0,q.a);c.stroke();}}
  grains(null);grains(false);
  if(sd){if(!VQD){VQD=[];for(n=0;n<520;n++)VQD.push({r:Math.random(),a:Math.random()*2*PI,c:COL[n%12],z:Math.random()});}c.globalCompositeOperation='lighter';   /* nuage de poussière fine en orbite (Kepler) */
   for(n=0;n<VQD.length;n++){q=VQD[n];q.a+=.0016/Math.pow(.1+q.r,1.5)*dt;q.r-=dt*.00006*(1+suck*5)*(1.15-q.r);if(q.r<.02){q.r=1;q.a=Math.random()*2*PI;}var rd=Rh*1.1+q.r*(Rm*1.25-Rh*1.1),tw=.5+.5*Math.sin(now0*.006+n),sz2=.6+1.1*q.z;
    c.fillStyle=rgba(q.r<.25?'#FFFFFF':q.c,al*(.15+.6*(1-q.r))*tw);c.fillRect(Math.cos(q.a)*rd,Math.sin(q.a)*rd*.42+(q.z-.5)*Rm*.06,sz2,sz2);}}
  /* bras en pointillés qui s'enroulent */
  c.globalCompositeOperation='lighter';for(n=0;n<4;n++){c.beginPath();for(var s2=0;s2<=30;s2++){var u=s2/30,th=n*PI/2-u*4.2+now0*.0011,r2=Rh*1.2+(Rm*.95-Rh*1.2)*Math.pow(u,1.25);var px=Math.cos(th)*r2,py=Math.sin(th)*r2*.42;s2?c.lineTo(px,py):c.moveTo(px,py);}
   c.setLineDash([1.2,5]);c.lineDashOffset=now0*.03;c.strokeStyle=rgba(COL[[0,2,7,11][n]],.55*al);c.lineWidth=1.1;c.stroke();}c.setLineDash([]);
  /* horizon et anneau de photons */
  c.globalCompositeOperation='source-over';c.fillStyle='rgba(3,4,8,'+(.96*al)+')';c.beginPath();c.arc(0,0,Rh,0,2*PI);c.fill();
  c.globalCompositeOperation='lighter';
  for(n=0;n<3;n++){c.strokeStyle=n?rgba(n===1?'#A878FF':'#43D5F5',(.5-.12*n)*al):'rgba(241,244,246,'+(.95*al)+')';c.lineWidth=n?3.5+n*3:1.3;c.beginPath();c.arc(0,0,Rh+.5+n*1.2,0,2*PI);c.stroke();}
  /* lentille : l'arrière du disque, courbé par-dessus l'horizon */
  for(n=0;n<7;n++){var ra=Rh*1.25+n*Rh*.16;c.strokeStyle=rgba(COL[(n*3)%12],(.42-.04*n)*al);c.lineWidth=.9;c.beginPath();c.ellipse(0,-Rh*.08,ra,ra*.92,0,PI*1.06,PI*1.94);c.stroke();}
  grains(true);
  /* arcs électriques qui crépitent sur le bord */
  if(!sd&&Math.random()<.35*al){var an=Math.random()*2*PI,len=Rh*(.8+Math.random()*1.4),px2=Math.cos(an)*Rh,py2=Math.sin(an)*Rh;c.strokeStyle='rgba(241,244,246,'+(.8*al)+')';c.lineWidth=.8;c.beginPath();c.moveTo(px2,py2);
   for(n=1;n<=6;n++){var f=n/6,jt=(Math.random()-.5)*6;c.lineTo(px2+Math.cos(an)*len*f-Math.sin(an)*jt,py2+Math.sin(an)*len*f*.6+Math.cos(an)*jt);}c.stroke();}
  c.restore();}
 var now0=0,dtD=16,VQD=null;
 /* ——— décors de scène (coordonnées locales) ——— */
 function deco(c,k,lt,B,T){var z=Z[k],col=COL[z.w],V=window.VX,n,q,u,x,y,p;
  switch(k){
  case 0:{ /* Atelier : vortex de départ, trait tracé par la particule */
   if(lt<900){var vc=1-ease('io',cl(lt/900));vortexQ(c,45,112,24+150*vc,vc,dtD,0);}   /* le vortex d'arrivée se referme au départ : la boucle */
   u=cl((lt-140)/560);n=Math.max(2,Math.round(u*(S1.length-1))+1);var sub=S1.slice(0,n);
   if(V&&V.flow){c.save();c.globalAlpha=.75;try{V.flow(c,FL0);}catch(x){}c.restore();}   /* poussière d'étoile : le chemin de la machine */
   if(V&&V.stroke)V.stroke(c,sub,0,1);else glowLine(c,sub,col,2.4,1);
   if(u>0&&u<1){q=sub[sub.length-1];var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],16);g.addColorStop(0,'rgba(241,244,246,.95)');g.addColorStop(.3,rgba(col,.5));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],16,0,2*PI);c.fill();}
   break;}
  case 1:{ /* Fonderie : plaques de rebond, sol de lave, braises */
   var g2=c.createLinearGradient(0,430,0,480);g2.addColorStop(0,'rgba(255,82,82,0)');g2.addColorStop(1,'rgba(255,120,40,.55)');c.fillStyle=g2;c.fillRect(-20,430,400,60);
   wall(c,[[0,454],[360,454]],2,'#FF5252');wall(c,[[46,404],[116,392]],1,col);wall(c,[[158,340],[222,328]],1,col);wall(c,[[270,258],[332,246]],1,col);
   c.save();c.globalCompositeOperation='lighter';for(n=0;n<3;n++){var bb=BUB[n],fb=((lt*.0007+n*.37)%1.25),nb=Math.min(bb.length,Math.round(fb*bb.length));   /* chambre à bulles : traces en spirale */
    for(q=0;q<nb;q++){c.fillStyle=rgba(q%3?'#FFAA3C':'#F1F4F6',.12+.5*q/bb.length);c.beginPath();c.arc(bb[q][0],bb[q][1],.7+(q%3===0?.5:0),0,2*PI);c.fill();}}c.restore();
   for(n=0;n<26;n++){x=(n*53+lt*.012*(1+n%3))%360;y=470-((lt*.06*(1+n%4)+n*37)%470);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.55*(1-y/480)+.1);c.fillRect(x,y,1.6,1.6);}
   break;}
  case 2:{ /* Chaîne : tapis d'élan et looping */
   wall(c,[[-14,186],[118,334]],3,col);var ring=[];for(n=0;n<=48;n++){var a=n/48*2*PI;ring.push([LOOPC[0]+Math.cos(a)*(LOOPR+R+3),LOOPC[1]+Math.sin(a)*(LOOPR+R+3)]);}
   wall(c,ring,3,col);wall(c,[[180,334],[372,330]],3,col);
   for(n=0;n<14;n++){x=((n*26+lt*.25)%390)-10;c.strokeStyle=rgba(col,.5);c.lineWidth=1;c.beginPath();c.moveTo(x,344);c.lineTo(x+6,344);c.stroke();}
   break;}
  case 3:{ /* Glacier : gouffre, pont qui gèle devant la particule, tremplin */
   wall(c,[[-10,350],[72,350]],4,col);c.fillStyle='rgba(5,7,13,.55)';c.fillRect(72,352,216,140);
   for(n=0;n<9;n++){x=80+n*24;c.strokeStyle=rgba(col,.45);c.beginPath();c.moveTo(x,352);c.lineTo(x+6,380+(n%3)*14);c.lineTo(x+12,352);c.stroke();}
   u=cl(lt/460);var br=[];for(n=0;n<=24;n++){var f=n/24*u;br.push([70+230*f,350+10*Math.sin(f*PI)]);}if(u>0)wall(c,br,4,col);
   wall(c,[[300,358],[330,352],[352,320],[356,306]],4,col);wall(c,[[300,360],[300,470]],0,col);
   for(n=0;n<30;n++){x=(n*47+lt*.01*(n%5))%360;y=(n*61+lt*.04*(1+n%3))%480;c.fillStyle='rgba(241,244,246,.5)';c.fillRect(x,y,1.3,1.3);}
   break;}
  case 4:{ /* Soufflerie : colonne d'air, cyclone */
   if(V&&V.updraft)V.updraft(c,[110,60,80,420]);else{c.fillStyle=rgba(col,.08);c.fillRect(110,60,80,420);}
   if(V&&V.vortex)V.vortex(c,[262,130,58,1]);else spiral(c,262,130,58,.6,lt*.01,[col]);
   for(n=0;n<18;n++){y=(n*31+lt*.3)%480;x=120+(n*17)%60;c.strokeStyle=rgba(col,.35);c.beginPath();c.moveTo(x,480-y);c.lineTo(x,480-y-14);c.stroke();}
   break;}
  case 5:{ /* Mécanique : engrenages, marches qui montent en rythme */
   gear(c,300,384,42,lt*.002,col,.35);gear(c,70,150,28,-lt*.003,col,.3);gear(c,206,86,20,lt*.004,col,.3);
   for(n=0;n<5;n++){var tn=300+n*250-180,rise=ease('out',cl((lt-tn)/200)),yy=STEPY[n]+(1-rise)*140;
    glowLine(c,[[STEPX[n],yy],[STEPX[n]+50,yy]],col,2.2,.9);glowLine(c,[[STEPX[n]+25,yy],[STEPX[n]+25,480]],col,1,.35);}
   break;}
  case 6:{ /* Gravité : plafond porteur, champ renversé */
   glowLine(c,[[40,28],[310,28]],col,2.4,.95);
   if(V&&V.well){c.save();c.globalAlpha=.55;V.well(c,[180,250,1100,26]);c.restore();}   /* puits : l'espace-temps courbé */
   for(n=0;n<24;n++){x=(n*41)%360;y=(n*67+lt*.03)%480;c.fillStyle=rgba(col,.35);c.fillRect(x,480-y,1.5,1.5);}
   break;}
  case 7:{ /* Magnétisme : aimant, anneaux de champ, gouttes de ferrofluide */
   for(n=1;n<=4;n++){c.strokeStyle=rgba(col,.32/n+.05*Math.sin(lt*.006+n));c.lineWidth=1;c.setLineDash([3,5]);c.lineDashOffset=-lt*.02*n;c.beginPath();c.arc(MAG[0],MAG[1],n*28,0,2*PI);c.stroke();}c.setLineDash([]);
   for(n=0;n<9;n++){var a2=n/9*2*PI+lt*.0015,r2=34+8*Math.sin(lt*.004+n);c.fillStyle=rgba(col,.35);c.beginPath();c.arc(MAG[0]+Math.cos(a2)*r2,MAG[1]+Math.sin(a2)*r2,3+2*Math.sin(n+lt*.005),0,2*PI);c.fill();}
   var g3=c.createRadialGradient(MAG[0],MAG[1],0,MAG[0],MAG[1],22);g3.addColorStop(0,'rgba(255,220,240,.95)');g3.addColorStop(1,rgba(col,0));c.fillStyle=g3;c.beginPath();c.arc(MAG[0],MAG[1],22,0,2*PI);c.fill();
   break;}
  case 8:{ /* Faille : la particule ouvre la faille, portails */
   u=cl(lt/360);c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.9);c.lineWidth=1.6;c.beginPath();
   for(n=0;n<=20;n++){y=140+n*8;x=150+(n%2?4:-4)*Math.sin(lt*.03+n);n?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();
   var op=ease('out',cl((lt-200)/220))*(lt<900?1:cl(1-(lt-900)/300));if(op>0){c.strokeStyle=rgba(col,op);c.lineWidth=2.2;c.beginPath();c.ellipse(150,220,8+26*op,62*op,0,0,2*PI);c.stroke();}
   var ob=ease('out',cl((lt-500)/200))*cl(1-(lt-1100)/300);if(ob>0){c.beginPath();c.ellipse(300,100,8+24*ob,30*ob+8,0,0,2*PI);c.stroke();}
   c.restore();if(V&&V.rift){c.save();c.globalAlpha=.8;V.rift(c,[150,220,300,100,70]);c.restore();}   /* corral d'atomes aux deux bouts de la faille */
   for(n=0;n<6;n++){y=(lt*.2+n*80)%480;c.fillStyle=rgba(col,.08);c.fillRect(0,y,360,1);}
   break;}
  case 9:{ /* Filaments : corde-tremplin qui ploie, harpe */
   var land=380,go=630;var sx=150,sy=360;if(lt>=land&&lt<=go&&B)sy=Math.max(360,B[1]+R);else if(lt>go){sy=360+52*Math.exp(-(lt-go)/160)*Math.cos((lt-go)*.06);}
   glowLine(c,[[50,360],[sx,sy],[250,360]],col,1.6,.95);
   for(n=0;n<6;n++){x=270+n*14;var vib=lt>go+150?4*Math.exp(-(lt-go-150-n*40)/260)*Math.sin(lt*.08+n):0;glowLine(c,[[x,60],[x+vib,150],[x,240]],col,1,.6);}
   break;}
  case 10:{ /* Quantique : dédoublement, détecteur */
   if(V&&V.qsup&&V.qdet){try{V.qsup(c,[22,190,44,44],lt*.06);V.qdet(c,[300,220,24,0],true,lt*.06,null);}catch(x){}for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}break;}
   var D=[300,220],ring2=6+4*Math.sin(lt*.01);c.strokeStyle='rgba(255,216,90,.8)';c.lineWidth=1.4;c.beginPath();c.arc(D[0],D[1],18+ring2,0,2*PI);c.stroke();
   c.beginPath();c.moveTo(D[0]-30,D[1]);c.lineTo(D[0]-12,D[1]);c.moveTo(D[0]+12,D[1]);c.lineTo(D[0]+30,D[1]);c.moveTo(D[0],D[1]-30);c.lineTo(D[0],D[1]-12);c.moveTo(D[0],D[1]+12);c.lineTo(D[0],D[1]+30);c.stroke();
   for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}
   break;}
  case 11:{ /* Arrivée : bassin, puis vortex */
   for(n=0;n<70;n++){x=(n*97)%360;y=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.25+.35*Math.sin(lt*.004+n*1.7))*.8);c.fillRect(x,y,1.3,1.3);}   /* ciel des onze mondes */
   glowLine(c,[[150,338],[150,398],[260,398],[260,338]],'#9BEB4B',2.2,.95*(1-.75*cl((lt-640)/600)));
   var vo=cl((lt-640)/800);if(vo>0)vortexQ(c,205,372,(30+175*ease('out',vo))*(1+2.2*ease('io',cl((lt-1700)/790))),ease('out',vo),dtD,lt>860?1:0);   /* le vortex s'élargit et engloutit l'image */
   break;}
  }
 }
 /* ——— image ——— */
 function frame(c,w,h,now,opt){
  now0=now;opt=opt||{};if(T0===null){T0=now;for(var pk=0;pk<11;pk++)img(pk);}var dt=Math.max(0,Math.min(60,now-(last||now)));last=now;dtD=dt;if(hold>0){T0+=Math.min(hold,dt);hold-=dt;}   /* arrêt sur image au choc fort */
  var t=(now-T0)%TOT,k=0;while(k<Z.length-1&&t>=Z[k].t0+Z[k].d)k++;
  var z=Z[k],lt=t-z.t0,LC=local(z,lt),B=LC.p,vis=!!B;if(!B)B=z.out;
  if(k!==lastZone){if(k===0){trail=[];cam.ok=false;seen={};}lastZone=k;label={k:k,t:now};}
  var gx=z.x0+B[0],gy=B[1];
  /* évènements */
  var V0=window.VX;(z.ev||[]).forEach(function(e,ei){var key=k+':'+ei;if(lt>=e[0]&&!seen[key]){seen[key]=1;var cc=COL[z.w];
    if(e[1]==='hit'){var hv=e[2]||5,hn=[e[4]||0,e[5]==null?-1:e[5]],ix=gx-hn[0]*R,iy=gy-hn[1]*R;   /* choc : bibliothèque d'impacts du jeu (poussière, arcs, onde, étoile), accentuée */
     if(V0&&V0.impact){V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv,mat:e[3]||0});if(hv>=6)V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv*.7,mat:e[3]||0});}
     burst(ix,iy,cc,10+hv*2,1.2+hv*.25);hits.push({x:ix,y:iy,c:cc,l:1,v:hv,n:hn});sq={t:1,nx:hn[0],ny:hn[1],k:Math.min(.42,hv/16)};shake=Math.max(shake,1+hv*.5);}
    else if(e[1]==='boost'){burst(gx,gy,cc,22,2.4);}
    else if(e[1]==='warp'){burst(gx,gy,cc,30,2.8);flashA=Math.max(flashA,.12);}
    else if(e[1]==='freeze'){burst(gx+40,gy,'#F1F4F6',24,1.2);}
    else if(e[1]==='collapse'){burst(gx,gy,'#FFD85A',36,2.6);flashA=Math.max(flashA,.15);}
    }});
  var power=(z.pw||[]).some(function(p){return lt>=p[0]&&lt<=p[1];});
  /* caméra */
  var tx=gx+40,ty=240+(gy-240)*.3,zoom=power?1.12:1,roll=0;
  if(k===6){roll=lt<420?PI*ease('io',lt/420):lt<1040?PI:PI+PI*ease('io',(lt-1040)/520);}
  if(!cam.ok){cam.x=tx;cam.y=ty;cam.z=zoom;cam.ok=true;}
  var fk=1-Math.pow(.0025,dt/1000);cam.x+=(tx-cam.x)*Math.min(1,fk*4);cam.y+=(ty-cam.y)*Math.min(1,fk*2);cam.z+=(zoom-cam.z)*Math.min(1,fk*3);
  var s=Math.min(w/UW,h/UH)*cam.z;
  /* fonds : illustration du monde, fondu au passage d'une frontière */
  c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  var f=cam.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0;
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){var kk=o[0],a=o[1];if(a<=0.01||kk<0||kk>11)return;var I=img(Z[kk].w);
   if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.12,dh=dw/ir,px=-(f-kk-.5)*w*.18;c.globalAlpha=a*.6;c.drawImage(I,(w-dw)/2+px,(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[Z[kk].w],.22*a));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}});
  var vg=c.createRadialGradient(w/2,h*.48,h*.1,w/2,h*.48,h*.85);vg.addColorStop(0,'rgba(5,7,13,.38)');vg.addColorStop(1,'rgba(5,7,13,.9)');c.fillStyle=vg;c.fillRect(0,0,w,h);
  /* monde */
  var sh=shake>0?shake:0;shake*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.rotate(roll);c.scale(s,s);c.translate(-cam.x,-cam.y);
  for(var kk=Math.max(0,k-1);kk<=Math.min(Z.length-1,k+1);kk++){var zz=Z[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);try{deco(c,kk,llt,kk===k?B:null,t);}catch(x){}c.restore();}
  /* chocs : éclair local + onde double */
  c.save();c.globalCompositeOperation='lighter';for(i=hits.length-1;i>=0;i--){var hh=hits[i];hh.l-=dt/520;if(hh.l<=0){hits.splice(i,1);continue;}var ra=(1-hh.l)*(26+hh.v*7),gg=c.createRadialGradient(hh.x,hh.y,0,hh.x,hh.y,18+hh.v*3);
   gg.addColorStop(0,'rgba(241,244,246,'+(.8*hh.l*hh.l)+')');gg.addColorStop(.35,rgba(hh.c,.45*hh.l));gg.addColorStop(1,rgba(hh.c,0));c.fillStyle=gg;c.beginPath();c.arc(hh.x,hh.y,18+hh.v*3,0,2*PI);c.fill();
   c.strokeStyle=rgba(hh.c,.7*hh.l);c.lineWidth=1.6*hh.l+.4;c.beginPath();c.ellipse(hh.x,hh.y,ra,ra*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();c.strokeStyle='rgba(241,244,246,'+(.5*hh.l)+')';c.lineWidth=.8;c.beginPath();c.ellipse(hh.x,hh.y,ra*.62,ra*.62*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();}c.restore();
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}
  /* traîne */
  if(vis){trail.push([gx,gy]);if(trail.length>26)trail.shift();}
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  for(i=1;i<trail.length;i++){var a=i/trail.length;c.strokeStyle=rgba(COL[z.w],a*.55);c.lineWidth=R*1.6*a;c.beginPath();c.moveTo(trail[i-1][0],trail[i-1][1]);c.lineTo(trail[i][0],trail[i][1]);c.stroke();}
  c.restore();
  /* éclats */
  c.save();c.globalCompositeOperation='lighter';for(i=parts.length-1;i>=0;i--){var p=parts[i];p.x+=p.vx*dt/16;p.y+=p.vy*dt/16;p.vx*=.96;p.vy*=.96;p.l-=dt/700;if(p.l<=0){parts.splice(i,1);continue;}
   c.fillStyle=rgba(p.c,p.l*.9);c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s);}c.restore();
  /* particule (dédoublée dans le monde quantique) */
  var V=window.VX;sq.t=Math.max(0,sq.t-dt/240);var sk=sq.t>0?(sq.k||.3)*Math.sin(sq.t*PI)*(sq.t):0;
  var drawB=function(x,y,al,sc){c.save();c.globalAlpha=al;c.translate(x,y);if(sk>0){var an=Math.atan2(sq.ny,sq.nx);c.rotate(an);c.scale(1-sk,1+sk*.7);c.rotate(-an);}if(V&&V.ball)V.ball(c,0,0,now*.004,R*(sc||1));else{c.fillStyle='#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();};
  if(k===10&&LC.s===z.segs[1]){var uu=ease('io',LC.u),up=bz([60,212],[150,90],[240,110],[300,220],40),dn=bz([60,212],[150,350],[240,330],[300,220],40),pa=along(up,uu),pb=along(dn,uu);
   c.save();c.strokeStyle='rgba(166,120,255,.45)';c.lineWidth=1;c.beginPath();for(i=0;i<=16;i++){var f2=i/16;c.lineTo(z.x0+pa[0]+(pb[0]-pa[0])*f2+6*Math.sin(f2*PI*6+now*.02),pa[1]+(pb[1]-pa[1])*f2);}c.stroke();c.restore();
   drawB(z.x0+pa[0],pa[1],.75);drawB(z.x0+pb[0],pb[1],.75);}
  else if(vis){var sc=k===11&&lt>860?Math.max(.15,1-(lt-860)/1250):1;
   if(power){c.save();c.globalCompositeOperation='lighter';drawB(gx-2.5,gy,.35,sc);drawB(gx+2.5,gy,.35,sc);c.restore();
    var pr=(now%600)/600;c.strokeStyle=rgba(COL[z.w],.6*(1-pr));c.lineWidth=1.2;c.beginPath();c.arc(gx,gy,R+pr*40,0,2*PI);c.stroke();}
   drawB(gx,gy,1,sc);}
  c.restore();
  /* passage de boucle : l'image plonge dans l'horizon, puis le départ émerge (aucun éclair) */
  var iris=k===11?ease('io',cl((lt-(z.d-620))/620)):k===0?1-ease('io',cl(lt/720)):0;if(iris>0){c.fillStyle='rgba(3,4,8,'+iris.toFixed(3)+')';c.fillRect(0,0,w,h);}
  /* flash, étiquette du monde */
  if(flashA>0){c.fillStyle='rgba(241,244,246,'+(flashA*.7)+')';c.fillRect(0,0,w,h);flashA=Math.max(0,flashA-dt/380);}
  if(opt.labels!==false&&z.w<11){var la=cl((now-label.t)/250)*cl(1-(now-label.t-1300)/400);if(la>0){var nm='';try{nm=typeof WN==='function'?WN(z.w):(typeof WORLDS!=='undefined'?WORLDS[z.w].n:'');}catch(x){}
    c.save();c.globalAlpha=la;c.font='500 10px "JetBrains Mono",ui-monospace,monospace';c.fillStyle=COL[z.w];c.textBaseline='alphabetic';
    var y0=opt.labelY||h-18,x0=16,tx0=(z.w+1<10?'0':'')+(z.w+1)+' · '+String(nm).toUpperCase();if(opt.labelC){c.textAlign='center';x0=w/2;}c.fillText(tx0,x0,y0);
    c.fillStyle=rgba(COL[z.w],.6);if(opt.labelC)c.fillRect(x0-30*la,y0+6,60*la,1);else c.fillRect(x0,y0+6,60*la,1);c.restore();}}
  return {world:z.w,power:power};
 }
 /* ——— R204 · ÉPILOGUE « Les retrouvailles » (docs/NARRATION.md) ———
    Poursuite de retour, même principe que le héros (scènes côte à côte, caméra qui suit), dans l'autre sens. Au monde
    Quantique la particule se dédouble : la compagne (violette, comme la branche de superposition du jeu) fait tout le retour
    avec elle, avec sa propre dynamique — tantôt en miroir, en tresse ou en patineurs, tantôt séparée pour franchir un
    autre obstacle ou passer autrement le même (la caméra recule pour les garder toutes deux). À l'origine elles se
    refondent ; leur réunion crée une sphère dans laquelle elles dansent (rotations à trois dimensions, la trace devient
    le nuage de points du noyau). ——— */
 var EP=null,ORG=[45,112],CYC=[180,240],PLN=[190,240],BOWL=function(x){var d=(x-180)/140;return 380-140*d*d;};
 function bwl(x){return BOWL(x)-R-2;}
 var LAX=function(e){return [330-300*e,330-190*e];},HAX=function(e){return [310-226*e,215-87*e];};
 var ZR=[
  {w:11,A:[Hd(600),Cv(bz([205,386],[205,300],[110,250],[-2,250],30).slice(1),1000,'in')],cam:function(lt){return lt<700?{z:.74,r:0}:{z:1.04,r:0};}},
  {w:10,A:[Ln([270,250],300),Cv(bz([270,250],[220,240],[190,150],[120,150],24).slice(1),600,'io'),Ln([60,150],700),Ln([-2,170],260,'out')],
   bIn:[270,250],B:[Hd(300),Cv(bz([270,250],[230,270],[230,330],[205,330],24).slice(1),500,'io'),Ln([110,330],560),Ln([-2,310],500,'out')],
   ev:[[300,'split']],evB:[[880,'tunnel']],cam:function(lt){return lt<420?{z:1.26,r:0,oy:-10}:{z:1.05,r:0};}},
  {w:9,A:[Ln([214,170],420),Ln([156,170],520,'io'),Cv(bz([156,170],[90,175],[60,226],[-2,232],24).slice(1),500,'out')],
   B:[Ln([214,310],640),Ln([156,310],520,'io'),Cv(bz([156,310],[90,305],[60,254],[-2,248],24).slice(1),280,'out')],ev:[[640,'slow',.5]],
   cam:function(lt){return lt>500&&lt<1100?{z:1.14,r:0,ox:20}:{z:1,r:0};}},
  {w:8,A:[Ln([236,232],300),Cv(bz([236,232],[196,250],[184,380],[180,496],24).slice(1),420,'in'),Tp([172,-16],40),Cv(bz([172,-16],[164,70],[140,150],[100,190],24).slice(1),420),Ln([-2,200],260,'out')],
   Bf:{lag:150,r:14,w:.006},ev:[[720,'seam',180,478],[760,'seam',172,2]],cam:function(lt){return lt>600&&lt<950?{z:.7,r:0,ty:240}:{z:1,r:0};}},
  {w:7,A:[Ln([180,228],440,'in'),Fn(function(u){var a=-PI/2-u*4*PI,r=12+78*u;return [CYC[0]+r*Math.cos(a),CYC[1]+r*Math.sin(a)];},1400,'in'),Ln([-2,150],260,'out')],
   Bf:{lag:210,r:0},cam:function(lt){var u=cl((lt-440)/1400);return lt<440?{z:1,r:0}:{z:1.4-.62*ease('io',u),r:0,tx:CYC[0],ty:CYC[1]};}},
  {w:6,A:[Ln([190,170],520,'in'),Fn(function(u){var a=-PI/2-u*2.5*PI;return [PLN[0]+70*Math.cos(a),PLN[1]+70*Math.sin(a)];},1500,'io'),Cv(bz([120,240],[100,200],[50,205],[-2,215],20).slice(1),380,'out')],
   Bf:{lag:430,r:0},
   cam:function(lt){if(lt<520)return {z:.95,r:0};var u=cl((lt-520)/1500);if(lt>2020)return {z:.95,r:0};return {z:.7+.26*Math.pow(Math.cos(PI*u),2),r:-.62*PI*Math.pow(Math.sin(PI*u),2),tx:PLN[0],ty:PLN[1]};}   /* la caméra bascule et revient : pas de tourbillon */},
  {w:5,A:[Cv(bz([358,215],[300,230],[262,339],[215,339],24).slice(1),460,'in'),Hd(160),Jp([46,246],110,640),Ln([-2,246],110)],
   Bf:{lag:110,r:20,w:.009},ev:[[620,'hit',7,0,-1,0],[620,'slow',.35]],cam:function(lt){return lt>380&&lt<860?{z:1.3,r:0,oy:30}:{z:.9,r:0};}},
  {w:4,A:[Fn(function(u,a){return [a[0]+(-2-a[0])*u,a[1]-20*u+34*Math.sin(u*3*PI)];},1250,'io')],Bf:{lag:0,r:28,w:.0075},cam:function(lt){return {z:1.02,r:0};}},
  {w:3,A:[Jp([320,bwl(320)],14,220),Fn(function(u){var x=180+140*Math.cos(u*3*PI);return [x,bwl(x)];},2200),Jp([-2,190],60,360,'out')],
   Bf:{lag:240,r:0},ev:[[220,'hit',4,4,0,-1],[587,'spray'],[1320,'spray'],[2053,'spray'],[2420,'launch']],
   cam:function(lt){var u=cl((lt-220)/2200),ph=u*3*PI,cr=Math.pow(Math.abs(Math.sin(ph)),3);if(lt<220)return {z:.78,r:0};if(lt>2420)return {z:.76,r:0};return {z:1.02+.24*cr,r:.035*Math.sin(ph)};}},
  {w:2,A:[Cv(bz([358,190],[350,260],[340,320],[330,330],12).slice(1),300,'in'),Fn(function(u){var e=ease('in3',u),P=LAX(e),o=10*Math.sin(e*7*PI)*(1-.3*e);return [P[0]+.535*o,P[1]-.845*o];},1500),Ln([-2,120],240)],
   B:[Cv(bz([358,214],[352,270],[342,322],[330,330],12).slice(1),300,'in'),Fn(function(u){var e=ease('in3',u),P=LAX(e),o=-10*Math.sin(e*7*PI)*(1-.3*e);return [P[0]+.535*o,P[1]-.845*o];},1500),Ln([-2,122],240)],
   ev:[[300,'slow',.45],[1650,'fast']],cam:function(lt){var u=cl((lt-300)/1500),e=ease('in3',u);if(lt<300)return {z:1.15,r:0};return {z:1.25-.5*e,r:0};}},
  {w:1,A:[Cv(bz([358,120],[340,112],[320,106],[296,104],12).slice(1),320),Cv(bz([296,104],[220,110],[170,250],[150,322],30).slice(1),900),Jp([-2,330],90,720)],
   B:[Cv(bz([358,122],[340,113],[320,106],[296,104],12).slice(1),320),Cv(bz([296,104],[230,96],[160,60],[96,74],30).slice(1),900),Cv(bz([96,74],[60,82],[24,92],[-2,96],16).slice(1),720)],
   ev:[[320,'pair',296,104],[320,'slow',.5],[1220,'hit',6,1,0,-1]],cam:function(lt){return lt<700?{z:1.12,r:0,oy:-30}:{z:.8,r:0};}},
  {w:0,A:[Cv(bz([358,330],[320,320],[318,250],[310,215],16).slice(1),760,'io'),Fn(function(u){var e=ease('io',u),P=HAX(e),o=26*Math.sin(e*4*PI);return [P[0]+.36*o,P[1]-.934*o];},2300)],
   B:[Cv(bz([358,96],[330,120],[318,180],[310,215],16).slice(1),760,'io'),Fn(function(u){var e=ease('io',u),P=HAX(e),o=-26*Math.sin(e*4*PI);return [P[0]+.36*o,P[1]-.934*o];},2300)],
   ev:[[760,'meet'],[760,'slow',.55]],cam:function(lt){var u=cl((lt-760)/2300);return lt<760?{z:.84,r:0}:{z:1.04+.2*ease('io',u),r:0,tx:lt>2300?118-40*ease('io',cl((lt-2300)/760)):null};}}
 ];
 function prepSegs(segs,p0){var p=p0.slice(),d=0,st=[];for(var b=0;b<segs.length;b++){var sg=segs[b];st.push({t:d,a:p.slice()});var q=sPos(sg,p,1);p=q?q:p;d+=sg.d;}return {st:st,d:d,out:p};}
 var TRT=0;(function(){var prev=null;for(var a=0;a<ZR.length;a++){var z=ZR[a];z.x0=z.w*UW;z.t0=TRT;
   z.inA=prev?[prev.x0+prev.outA[0]-z.x0,prev.outA[1]]:z.A[0]&&[205,386];var pa=prepSegs(z.A,z.inA);z.stA=pa.st;z.outA=pa.out;z.d=pa.d;
   if(z.B){z.inB=z.bIn||(prev&&prev.outB?[prev.x0+prev.outB[0]-z.x0,prev.outB[1]]:z.inA);var pb=prepSegs(z.B,z.inB);z.stB=pb.st;z.outB=pb.out;z.d=Math.max(z.d,pb.d);}
   else if(z.Bf){z.outB=z.outA.slice();}
   TRT+=z.d;prev=z;}})();
 function locS(segs,st,lt){for(var k=0;k<segs.length;k++){var sg=segs[k],q=st[k];if(lt<q.t+sg.d||k===segs.length-1){var su=cl((lt-q.t)/sg.d);return sPos(sg,q.a,su);}}return null;}
 var TH=2300;
 function bgImg(c,w,h,wi,a,px){var I=img(wi);if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.12,dh=dw/ir;c.globalAlpha=a;c.drawImage(I,(w-dw)/2+(px||0),(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[wi],.22*a));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}}
 function vign(c,w,h,a0,a1){var vg=c.createRadialGradient(w/2,h*.48,h*.1,w/2,h*.48,h*.85);vg.addColorStop(0,'rgba(5,7,13,'+a0+')');vg.addColorStop(1,'rgba(5,7,13,'+a1+')');c.fillStyle=vg;c.fillRect(0,0,w,h);}
 function eBall(c,x,y,al,sc,now,sx,sy){var V=window.VX;c.save();c.globalAlpha=al;c.translate(x,y);if(sx)c.scale(sx,sy);if(V&&V.ball)V.ball(c,0,0,now*.004,R*(sc||1));else{c.fillStyle='#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();}
 /* la compagne : exactement la branche de superposition du jeu (balle teintée violette, 94 %, opacité .72) */
 function comp(c,x,y,al,sc,now,sx,sy){var V=window.VX;c.save();c.globalAlpha=.72*al;c.translate(x,y);if(sx)c.scale(sx,sy);if(V&&V.ball)V.ball(c,0,0,-now*.004,R*.94*(sc||1),'#A878FF');else{c.fillStyle='#A878FF';c.beginPath();c.arc(0,0,R*.94*(sc||1),0,2*PI);c.fill();}c.restore();}
 function eParts(c,dt){c.save();c.globalCompositeOperation='lighter';for(var a=parts.length-1;a>=0;a--){var p=parts[a];p.x+=p.vx*dt/16;p.y+=p.vy*dt/16;p.vx*=.96;p.vy*=.96;p.l-=dt/700;if(p.l<=0){parts.splice(a,1);continue;}
   c.fillStyle=rgba(p.c,p.l*.9);c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s);}c.restore();}
 function eTrail(c,T,col,k){c.save();c.globalCompositeOperation='lighter';c.lineCap='round';for(var a=1;a<T.length;a++){var f=a/T.length;if(!T[a]||!T[a-1])continue;c.strokeStyle=rgba(col,f*.5);c.lineWidth=R*k*f;c.beginPath();c.moveTo(T[a-1][0],T[a-1][1]);c.lineTo(T[a][0],T[a][1]);c.stroke();}c.restore();}
 function gTrail(c,T){c.save();for(var a=0;a<T.length;a++){if(!T[a])continue;c.globalAlpha=a/T.length*.22;c.fillStyle='#A878FF';c.beginPath();c.arc(T[a][0],T[a][1],R*.4,0,2*PI);c.fill();}c.restore();}   /* traîne de la branche, comme dans le jeu */
 function eHits(c,dt){c.save();c.globalCompositeOperation='lighter';for(var a=EP.hit.length-1;a>=0;a--){var hh=EP.hit[a];hh.l-=dt/520;if(hh.l<=0){EP.hit.splice(a,1);continue;}var ra=(1-hh.l)*(26+hh.v*7),gg=c.createRadialGradient(hh.x,hh.y,0,hh.x,hh.y,18+hh.v*3);
   gg.addColorStop(0,'rgba(241,244,246,'+(.8*hh.l*hh.l)+')');gg.addColorStop(.35,rgba(hh.c,.45*hh.l));gg.addColorStop(1,rgba(hh.c,0));c.fillStyle=gg;c.beginPath();c.arc(hh.x,hh.y,18+hh.v*3,0,2*PI);c.fill();
   c.strokeStyle=rgba(hh.c,.7*hh.l);c.lineWidth=1.6*hh.l+.4;c.beginPath();c.ellipse(hh.x,hh.y,ra,ra*(hh.ny?.38:1),0,0,2*PI);c.stroke();}c.restore();}
 /* ——— décors du retour (coordonnées locales) ——— */
 function packet(c,P,now,lo,hi){var env=function(xx){return Math.exp(-(xx-P[0])*(xx-P[0])/700);};c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba('#A878FF',.75);c.lineWidth=1.2;c.beginPath();
  for(var n=0;n<=60;n++){var x=P[0]-60+n*2,y=P[1]+14*env(x)*Math.sin(x*.32-now*.02)*(x>lo&&x<hi?.45:1);n?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();c.restore();}
 function decoR(c,z,lt,A,B,now){var w=z.w,col=COL[w],n,x,y,u,V=window.VX;EP.mA=null;EP.mB=null;
  switch(w){
  case 11:deco(c,11,600,null,0);break;
  case 10:{ /* dédoublement ; l'une traverse le temps dilaté, l'autre la barrière par effet tunnel */
   if(V&&V.qsup){try{V.qsup(c,[244,222,52,56],now*.06);}catch(x2){}}
   if(V&&V.qtdil){try{V.qtdil(c,[30,104,124,92],now*.06);}catch(x2){}}
   var gb=c.createLinearGradient(150,0,195,0);gb.addColorStop(0,'rgba(168,120,255,.05)');gb.addColorStop(.5,'rgba(168,120,255,.26)');gb.addColorStop(1,'rgba(168,120,255,.05)');c.fillStyle=gb;c.fillRect(150,276,45,118);
   glowLine(c,[[150,276],[150,394]],'#A878FF',1,.55);glowLine(c,[[195,276],[195,394]],'#A878FF',1,.55);
   if(B&&B[0]>96&&B[0]<256){packet(c,B,now,150,195);EP.mB={al:B[0]>150&&B[0]<195?.35:.75};}
   if(A&&A[0]<150&&A[0]>40)EP.mA={slow:1};
   for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(now*.002+n)*20)%480;c.fillStyle=rgba(col,.22);c.fillRect(x,y,1.2,1.2);}break;}
  case 9:{ /* deux fentes plus étroites que la particule, une pour chacune */
   wall(c,[[184,30],[184,163]],0,col);wall(c,[[184,177],[184,303]],0,col);wall(c,[[184,317],[184,450]],0,col);
   for(n=0;n<6;n++){x=236+n*22;var am=A?5*Math.max(0,1-Math.abs(A[0]-x)/50):0;glowLine(c,[[x,70],[x+am*Math.sin(now*.06+n),240],[x,410]],col,1,.4);}
   if(A&&A[0]>162&&A[0]<206){u=1-Math.abs(A[0]-184)/22;EP.mA={sx:1+.5*u,sy:1-.45*u};}if(B&&B[0]>162&&B[0]<206){u=1-Math.abs(B[0]-184)/22;EP.mB={sx:1+.5*u,sy:1-.45*u};}break;}
  case 8:{ /* univers recousu : elles se croisent par les coutures */
   for(n=0;n<2;n++){y=n?478:2;c.save();c.setLineDash([6,5]);c.lineDashOffset=now*.04*(n?1:-1);glowLine(c,[[0,y],[360,y]],col,1.2,.7);c.restore();}
   for(n=0;n<14;n++){var aa=n/14*2*PI;c.fillStyle=rgba(col,.6);c.beginPath();c.arc(180+Math.cos(aa)*22,478+Math.sin(aa)*9,1.6,0,2*PI);c.fill();c.beginPath();c.arc(172+Math.cos(aa)*22,2+Math.sin(aa)*9,1.6,0,2*PI);c.fill();}
   for(n=0;n<6;n++){y=(now*.05+n*80)%480;c.fillStyle=rgba(col,.07);c.fillRect(0,y,360,1);}break;}
  case 7:{ /* cyclotron : charges opposées, spirales en miroir */
   if(V&&V.bfield){try{c.save();c.globalAlpha=.7;V.bfield(c,[70,130,220,220,1]);c.restore();}catch(x2){}}
   c.save();c.strokeStyle=rgba(col,.55);c.lineWidth=1.4;c.beginPath();c.arc(CYC[0]-5,CYC[1],100,PI/2,PI*1.5);c.closePath();c.stroke();c.beginPath();c.arc(CYC[0]+5,CYC[1],100,-PI/2,PI/2);c.closePath();c.stroke();c.restore();
   var kg=(A&&Math.abs(A[0]-180)<8)||(B&&Math.abs(B[0]-180)<8)?1:.25;glowLine(c,[[180,140],[180,340]],'#F1F4F6',1,kg*.6);break;}
  case 6:{ /* une planète : l'une passe dessus, l'autre dessous */
   if(V&&V.well){try{c.save();c.globalAlpha=.6;V.well(c,[PLN[0],PLN[1],1100,30]);c.restore();}catch(x2){}}
   var gp=c.createRadialGradient(PLN[0]-8,PLN[1]-8,2,PLN[0],PLN[1],30);gp.addColorStop(0,'rgba(220,255,200,.95)');gp.addColorStop(.5,rgba(col,.55));gp.addColorStop(1,rgba(col,.05));c.fillStyle=gp;c.beginPath();c.arc(PLN[0],PLN[1],30,0,2*PI);c.fill();
   for(n=0;n<24;n++){x=(n*41)%360;y=(n*67+now*.03)%480;c.fillStyle=rgba(col,.3);c.fillRect(x,480-y,1.5,1.5);}break;}
  case 5:{ /* pendule : l'une est frappée, l'autre le survole */
   if(V&&V.mech){try{V.mech(c,EP.MECH||(EP.MECH=[{t:'train',x:76,y:100,k:1.45,s:.8,ph:.4,d:1},{t:'escape',x:300,y:160,k:1.3,s:.7,ph:1.2,d:-1},{t:'crank',x:100,y:420,k:1.35,s:.9,ph:2,d:1},{t:'cam',x:316,y:424,k:1.3,s:.8,ph:.8,d:-1},{t:'train',x:44,y:290,k:1.05,s:.6,ph:3,d:-1}]));}catch(x2){}}
   wall(c,[[150,350],[372,350]],0,col);var om=2*PI/2000,th=-(lt<620?.8:.32)*Math.sin(om*(lt-620)),bx=235+280*Math.sin(th),by=40+280*Math.cos(th);
   glowLine(c,[[235,40],[bx,by]],col,1.4,.85);gear(c,235,40,13,now*.003,col,.6);
   var gb2=c.createRadialGradient(bx-5,by-5,2,bx,by,17);gb2.addColorStop(0,'rgba(255,240,200,.95)');gb2.addColorStop(1,rgba(col,.35));c.fillStyle=gb2;c.beginPath();c.arc(bx,by,17,0,2*PI);c.fill();
   gear(c,bx,by,11,-now*.004,'#F1F4F6',.5);break;}
  case 4:{ /* allée de tourbillons : elles l'épousent en contre-phase */
   var ring=[];for(n=0;n<=36;n++){var a3=n/36*2*PI;ring.push([300+22*Math.cos(a3),240+22*Math.sin(a3)]);}wall(c,ring,0,col);
   for(n=0;n<16;n++){y=40+n*28;x=360-((now*.25+n*53)%400);var dy=y<240?-1:1,bump=18*Math.exp(-(x-300)*(x-300)/900)*Math.exp(-(y-240)*(y-240)/2600)*dy;c.strokeStyle=rgba(col,.28);c.lineWidth=1;c.beginPath();c.moveTo(x,y+bump);c.lineTo(x-16,y+bump);c.stroke();}
   for(n=0;n<6;n++){x=262-((lt*.13+n*56)%300);y=240+(n%2?26:-26);spiral(c,x,y,14,.32,(n%2?1:-1)*now*.006,[col,'#F1F4F6']);}break;}
  case 3:{ /* demi-lune de glace : deux patineuses, la caméra se balance avec elles */
   if(!EP.ice){EP.ice=[];for(x=24;x<=336;x+=6)EP.ice.push([x,BOWL(x)]);EP.ice.unshift([-10,BOWL(24)]);EP.ice.push([370,BOWL(336)]);}wall(c,EP.ice,4,col);
   c.save();c.globalCompositeOperation='lighter';var gi=c.createRadialGradient(180,380,0,180,380,120);gi.addColorStop(0,'rgba(143,227,255,.18)');gi.addColorStop(1,'rgba(143,227,255,0)');c.fillStyle=gi;c.fillRect(0,250,360,260);c.restore();
   for(n=0;n<40;n++){x=(n*47+now*.01*(n%5))%360;y=(n*61+now*.04*(1+n%3))%480;c.fillStyle='rgba(241,244,246,'+(.3+.3*Math.sin(now*.004+n))+')';c.fillRect(x,y,1.3,1.3);}break;}
  case 2:{ /* accélérateur linéaire : chaîne de cavités ; elles s'y tressent et prennent de la vitesse */
   if(V&&V.torusCells){try{V.torusCells(c,250,96,62,10,.14);}catch(x2){}}
   var e=ease('in3',cl((lt-300)/1500));
   for(n=0;n<9;n++){var ek=n/8,P=LAX(ek),fl=Math.max(0,1-Math.abs(e-ek)*14)*(lt>300?1:0);
    c.save();c.translate(P[0],P[1]);c.rotate(Math.atan2(-190,-300));c.strokeStyle=rgba(col,.45+.5*fl);c.lineWidth=1.3;c.beginPath();c.ellipse(0,0,15,24,0,0,2*PI);c.stroke();
    c.strokeStyle=rgba('#F1F4F6',.15+.6*fl);c.lineWidth=.8;c.beginPath();c.moveTo(-15,-6);c.lineTo(-15,6);c.moveTo(15,-6);c.lineTo(15,6);c.stroke();
    if(fl>0){c.globalCompositeOperation='lighter';var gc=c.createRadialGradient(0,0,0,0,0,30);gc.addColorStop(0,rgba('#F1F4F6',.5*fl));gc.addColorStop(1,rgba(col,0));c.fillStyle=gc;c.beginPath();c.arc(0,0,30,0,2*PI);c.fill();}c.restore();}
   glowLine(c,[LAX(0),LAX(1)],col,1,.3);
   if(e>.35){c.save();c.globalCompositeOperation='lighter';for(n=0;n<14;n++){var o2=(n-7)*14,f2=((now*.004+n*.37)%1),Q=LAX(Math.min(1,e+.1-f2*.4));c.strokeStyle=rgba('#F1F4F6',.25*(e-.35)*(1-f2));c.lineWidth=1;c.beginPath();c.moveTo(Q[0]+.535*o2,Q[1]-.845*o2);c.lineTo(Q[0]+.535*o2+300*.12,Q[1]-.845*o2+190*.12);c.stroke();}c.restore();}
   break;}
  case 1:{ /* chambre à bulles : création de paire au sommet du V ; traces courbées en sens opposés ; plaque incandescente */
   c.save();c.translate(180,486);c.scale(1.45,.42);var g4=c.createRadialGradient(0,0,0,0,0,120);g4.addColorStop(0,'rgba(255,120,40,.55)');g4.addColorStop(.6,'rgba(255,82,82,.18)');g4.addColorStop(1,'rgba(255,82,82,0)');c.fillStyle=g4;c.beginPath();c.arc(0,0,120,0,2*PI);c.fill();c.restore();
   wall(c,[[126,334],[176,334]],1,col);
   if(lt<40){EP.bA=[];EP.bB=[];}if(A&&lt>260)EP.bA.push(A.slice());if(B&&lt>260)EP.bB.push(B.slice());
   c.save();c.globalCompositeOperation='lighter';[[EP.bA,col],[EP.bB,'#A878FF']].forEach(function(o){var T=o[0]||[];for(var m=0;m<T.length;m+=2){var jt=((m*7919)%5)-2;c.fillStyle=rgba(o[1],.25+.45*m/T.length);c.beginPath();c.arc(T[m][0]+jt*.6,T[m][1]-jt*.4,.9+((m*31)%3)*.4,0,2*PI);c.fill();}});c.restore();
   for(n=0;n<12;n++){x=(n*67+now*.01)%360;y=480-((now*.05*(1+n%3)+n*41)%480);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.35);c.beginPath();c.arc(x,y,1.2+(n%3)*.5,0,2*PI);c.fill();}
   break;}
  case 0:{ /* double hélice : elles en sont les deux brins ; le trait se trace devant elles, des barreaux restent derrière */
   var e3=ease('io',cl((lt-420)/1700)),HP=[];for(n=0;n<=40;n++){var f3=n/40*Math.min(1,e3+.14);HP.push(HAX(f3));}if(lt>760){glowLine(c,HP,col,.9,.42);var hq=HP[HP.length-1],gq=c.createRadialGradient(hq[0],hq[1],0,hq[0],hq[1],9);gq.addColorStop(0,'rgba(241,244,246,.8)');gq.addColorStop(1,rgba(col,0));c.fillStyle=gq;c.beginPath();c.arc(hq[0],hq[1],9,0,2*PI);c.fill();}   /* un trait fin se trace devant elles, sa pointe lumineuse en tête */
   if(V&&V.helix){try{V.helix(c,-10,430,370,350,22,3,.011,[77,215,255],[168,120,255],.16);V.helix(c,250,-10,330,250,16,2,.013,[168,120,255],[77,215,255],.12);}catch(x2){}}
   if(V&&V.flow){c.save();c.globalAlpha=.5;try{V.flow(c,FL0);}catch(x2){}c.restore();}
   var vo2=ease('io',cl((lt-1900)/1100));EP.vo0=vo2;if(vo2>0)vortexQ(c,ORG[0],ORG[1],60*vo2,vo2,EP.dt,0);   /* l'origine s'ouvre pendant qu'elles montent : pas de coupure */
   if(lt<40)EP.rungs=[];if(A&&B&&lt>420&&(!EP.rgt||now-EP.rgt>55)){EP.rgt=now;EP.rungs.push([A.slice(),B.slice(),1]);}
   c.save();c.globalCompositeOperation='lighter';for(n=EP.rungs.length-1;n>=0;n--){var rg=EP.rungs[n];rg[2]-=EP.dt/2400;if(rg[2]<=0){EP.rungs.splice(n,1);continue;}c.strokeStyle=rgba(n%2?'#A878FF':'#F1F4F6',.6*rg[2]);c.lineWidth=1.3;c.beginPath();c.moveTo(rg[0][0],rg[0][1]);c.lineTo(rg[1][0],rg[1][1]);c.stroke();}c.restore();
   if(lt>420){var dp=Math.cos(e3*4*PI);EP.mA={sc:.85+.22*dp,al:.8+.2*dp};EP.mB={sc:.85-.22*dp,al:.8-.2*dp};}
   break;}
  }}
 function event(z,e,P){var cc=COL[z.w],V0=window.VX,gx=z.x0+P[0],gy=P[1];
  if(e[1]==='hit'){var hv=e[2]||5,nx=e[4]||0,ny=e[5]==null?-1:e[5],ix=gx-nx*R,iy=gy-ny*R;if(V0&&V0.impact){try{V0.impact({x:ix,y:iy,nx:nx,ny:ny,v:hv,mat:e[3]||0});}catch(x){}}
   burst(ix,iy,cc,10+hv*2,1.2+hv*.25);EP.hit.push({x:ix,y:iy,c:cc,l:1,v:hv,ny:ny});EP.sh=Math.max(EP.sh,.5+hv*.2);}
  else if(e[1]==='split'){burst(gx,gy,'#A878FF',30,2.2);EP.hit.push({x:gx,y:gy,c:'#A878FF',l:1,v:7,ny:0});EP.sh=Math.max(EP.sh,3);EP.zk=1.15;EP.ts=.25;}
  else if(e[1]==='tunnel'){burst(z.x0+172,gy,'#A878FF',20,1.6);EP.hit.push({x:z.x0+172,y:gy,c:'#A878FF',l:1,v:5,ny:0});}
  else if(e[1]==='seam'||e[1]==='graze'||e[1]==='pair'){burst(z.x0+e[2],e[3],e[1]==='pair'?'#F1F4F6':cc,22,2);EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:5,ny:e[1]==='seam'?1:0});if(e[1]==='pair'){EP.sh=Math.max(EP.sh,3);EP.zk=1.25;}}
  else if(e[1]==='collide'){burst(z.x0+e[2],e[3],'#F1F4F6',26,2.6);EP.hit.push({x:z.x0+e[2],y:e[3],c:'#C8A8FF',l:1,v:8,ny:1});EP.sh=Math.max(EP.sh,4);EP.zk=1.2;}
  else if(e[1]==='spray'){burst(gx,gy+6,'#F1F4F6',18,2.2);burst(gx,gy+6,cc,10,1.6);}
  else if(e[1]==='launch'){burst(gx,gy,cc,24,2.4);EP.sh=Math.max(EP.sh,1.4);EP.ts=1.35;}
  else if(e[1]==='slow'){EP.ts=e[2]||.3;}
  else if(e[1]==='fast'){EP.ts=1.3;}
  else if(e[1]==='meet'){burst(gx,gy,'#F1F4F6',22,2);burst(gx,gy,'#A878FF',16,1.6);EP.hit.push({x:gx,y:gy,c:'#A878FF',l:1,v:6,ny:0});EP.zk=1.15;}}
 function dustPar(c,w,h,cm){if(!EP.DU){EP.DU=[];for(var a=0;a<70;a++)EP.DU.push([Math.random()*w*1.6,Math.random()*h,.3+Math.random()*.9,COL[a%12]]);}c.save();c.globalCompositeOperation='lighter';
  for(var b=0;b<EP.DU.length;b++){var q=EP.DU[b],x=((q[0]-cm.x*q[2]*.9)%(w*1.6)+w*1.6)%(w*1.6)-w*.3,y=((q[1]-cm.y*q[2]*.4)%h+h)%h;c.fillStyle=rgba(q[3],.12+.3*q[2]);c.fillRect(x,y,.6+q[2]*1.2,.6+q[2]*1.2);}c.restore();}
 function drawWorldBg(c,w,h,cm){var f=cm.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0;if(k0<0){k0=0;fr=0;}
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){if(o[1]>.01&&o[0]>=0&&o[0]<=11)bgImg(c,w,h,o[0],o[1]*.6,-(f-o[0]-.5)*w*.18);});vign(c,w,h,.38,.9);if(EP)dustPar(c,w,h,cm);}
 function epChase(c,w,h,now,t,dt,s0){var k=0;while(k<ZR.length-1&&t>=ZR[k].t0+ZR[k].d)k++;var z=ZR[k],lt=Math.min(z.d,t-z.t0);
  var A=locS(z.A,z.stA,lt),B=z.B?locS(z.B,z.stB,lt):null;
  if(z.Bf){var F=z.Bf,Bq=locS(z.A,z.stA,Math.max(0,lt-F.lag))||A,an=(F.w||0)*lt+(F.ph||0);B=Bq?[Bq[0]+(F.r||0)*Math.cos(an),Bq[1]+(F.r||0)*.75*Math.sin(an)]:null;}
  var visA=!!A,visB=!!B&&!(z.bIn&&lt<300);if(!A)A=EP.lA||z.inA;EP.lA=A;if(z.B&&!B)B=EP.lB||z.inB;if(B)EP.lB=B;
  var gA=[z.x0+A[0],A[1]],gB=B?[z.x0+B[0],B[1]]:null;
  if(gB&&EP.sB&&!(z.bIn&&lt<340)){var kb=1-Math.pow(.0004,dt/1000);EP.sB=[EP.sB[0]+(gB[0]-EP.sB[0])*kb,EP.sB[1]+(gB[1]-EP.sB[1])*kb];gB=EP.sB.slice();B=[gB[0]-z.x0,gB[1]];}else if(gB)EP.sB=gB.slice();
  (z.ev||[]).forEach(function(e,ei){var key=k+'a'+ei;if(lt>=e[0]&&!EP.seen[key]){EP.seen[key]=1;event(z,e,A);}});
  (z.evB||[]).forEach(function(e,ei){var key=k+'b'+ei;if(lt>=e[0]&&!EP.seen[key]&&B){EP.seen[key]=1;event(z,e,B);}});
  /* caméra : suit le couple, recule quand elles s'écartent, accents propres au monde */
  var mx=gA[0],my=gA[1],dx=0,dy=0;if(gB&&visB){mx=(gA[0]+gB[0])/2;my=(gA[1]+gB[1])/2;dx=Math.abs(gA[0]-gB[0]);dy=Math.abs(gA[1]-gB[1]);}
  var zc=z.cam?z.cam(lt):null,base=zc?zc.z:(k===0?1.04:.98),fit=Math.min(UW/(dx*1.25+150),UH/(dy*1.5+210)),zoom=Math.min(base,fit)*(EP.zk||1),roll=zc?zc.r:0;EP.zk=1+((EP.zk||1)-1)*Math.pow(.05,dt/1000);
  var cm=EP.cam,tx=zc&&zc.tx!=null?z.x0+zc.tx:mx-30+(zc&&zc.ox||0),ty=zc&&zc.ty!=null?zc.ty:240+(my-240)*.4+(zc&&zc.oy||0);if(!cm.ok){cm.x=tx;cm.y=ty;cm.z=.8;cm.r=0;cm.ok=true;}
  if(k!==EP.kc){if(EP.kc!=null){EP.zk=Math.min(EP.zk||1,.97);}EP.kc=k;while(cm.r<-PI)cm.r+=2*PI;while(cm.r>PI)cm.r-=2*PI;}
  var fk=1-Math.pow(.0025,dt/1000),fast=zc&&zc.fast?1.6:1;cm.x+=(tx-cm.x)*Math.min(1,fk*3.2*fast);cm.y+=(ty-cm.y)*Math.min(1,fk*2*fast);cm.z+=(zoom-cm.z)*Math.min(1,fk*1.8);cm.r+=(roll-cm.r)*Math.min(1,fk*1.6);
  drawWorldBg(c,w,h,cm);var s=s0*cm.z,sh=EP.sh;EP.sh*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.rotate(cm.r);c.scale(s,s);c.translate(-cm.x,-cm.y);
  var mA=null,mB=null;for(var kk=Math.max(0,k-1);kk<=Math.min(ZR.length-1,k+1);kk++){var zz=ZR[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);try{decoR(c,zz,llt,kk===k&&visA?A:null,kk===k&&visB?B:null,now);}catch(x){}c.restore();if(kk===k){mA=EP.mA;mB=EP.mB;}}
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}eHits(c,dt);
  EP.tr.push(visA?gA:null);if(EP.tr.length>28)EP.tr.shift();EP.trB.push(visB?gB:null);if(EP.trB.length>18)EP.trB.shift();
  eTrail(c,EP.tr,COL[z.w],1.4);gTrail(c,EP.trB);eParts(c,dt);
  if(visA&&visB){c.save();c.strokeStyle='#A878FF';c.globalAlpha=.22;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(gA[0],gA[1]);c.lineTo(gB[0],gB[1]);c.stroke();c.setLineDash([]);c.restore();}   /* frange entre les deux branches, comme dans le jeu */
  if(visB)comp(c,gB[0],gB[1],mB&&mB.al!=null?mB.al:1,mB&&mB.sc||1,now,mB&&mB.sx,mB&&mB.sy);
  if(visA){var al=mA&&mA.al!=null?mA.al:1,hg=c.createRadialGradient(gA[0],gA[1],0,gA[0],gA[1],R*3);hg.addColorStop(0,'rgba(241,244,246,'+(.3*al).toFixed(3)+')');hg.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=hg;c.beginPath();c.arc(gA[0],gA[1],R*3,0,2*PI);c.fill();
   eBall(c,gA[0],gA[1],al,mA&&mA.sc||1,now,mA&&mA.sx,mA&&mA.sy);}
  EP.gA=gA;EP.gB=gB;
  c.restore();
  var ir=1-ease('io',cl(t/900));if(ir>0){c.fillStyle='rgba(3,4,8,'+ir.toFixed(3)+')';c.fillRect(0,0,w,h);}}
 /* la refonte : à l'horizon d'origine, elles tournent l'une autour de l'autre et ne font plus qu'une */
 function epFuse(c,w,h,now,t,dt,s0){var C=[ORG[0],ORG[1]],cm=EP.cam,tx2=C[0],ty2=240+(C[1]-240)*.4;
  var fk=1-Math.pow(.0025,dt/1000);cm.x+=(tx2-cm.x)*Math.min(1,fk*3);cm.y+=(ty2-cm.y)*Math.min(1,fk*2);cm.z+=(1.6-cm.z)*Math.min(1,fk*1.6);cm.r+=(0-cm.r)*Math.min(1,fk*3);
  drawWorldBg(c,w,h,cm);var s=s0*cm.z;c.save();c.translate(w/2,h/2);c.rotate(cm.r);c.scale(s,s);c.translate(-cm.x,-cm.y);
  var vo=t<1700?Math.max(EP.vo0||0,ease('out',cl(t/500))):Math.max(0,1-(t-1700)/500);if(vo>0)vortexQ(c,ORG[0],ORG[1],60*vo,vo,dt,0);
  var u=cl(t/1700),sp=Math.pow(u,1.8),r=34*Math.pow(1-u,.9),a=-1.6+2*PI*3.6*sp,ox=Math.cos(a)*r,oy=Math.sin(a)*r*.42,shr=Math.max(.15,1-u*u*.85);   /* elles décrivent le disque du trou noir et y plongent */
  if(t<1700&&(!EP.rpt||now-EP.rpt>Math.max(90,340*(1-u)))){EP.rpt=now;EP.rip.push({l:0});}
  c.save();c.globalCompositeOperation='lighter';for(var q=EP.rip.length-1;q>=0;q--){var rp=EP.rip[q];rp.l+=dt/1300;if(rp.l>=1){EP.rip.splice(q,1);continue;}c.strokeStyle=rgba(q%2?'#A878FF':'#4DD7FF',.4*(1-rp.l));c.lineWidth=1.4*(1-rp.l)+.3;c.beginPath();c.ellipse(C[0],C[1],8+rp.l*170,(8+rp.l*170)*.62,0,0,2*PI);c.stroke();}c.restore();
  if(t<1700){c.save();c.strokeStyle='#A878FF';c.globalAlpha=.3+.4*u;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(C[0]+ox,C[1]+oy);c.lineTo(C[0]-ox,C[1]-oy);c.stroke();c.setLineDash([]);c.restore();
   var bw=ease('io',cl(t/450)),la=EP.gA||[C[0]+ox,C[1]+oy],lb=EP.gB||[C[0]-ox,C[1]-oy],Ax=la[0]+(C[0]+ox-la[0])*bw,Ay=la[1]+(C[1]+oy-la[1])*bw,Bx=lb[0]+(C[0]-ox-lb[0])*bw,By=lb[1]+(C[1]-oy-lb[1])*bw;
   comp(c,Bx,By,1-u*.5,shr,now);eBall(c,Ax,Ay,1-u*.4,shr,now);}
  eParts(c,dt);c.restore();
  var bl=t>1650?.78*ease('io',cl((t-1650)/650)):0;if(bl>0){c.fillStyle='rgba(5,7,13,'+bl.toFixed(3)+')';c.fillRect(0,0,w,h);var fl=Math.sin(PI*cl((t-1600)/900)),g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.45);g.addColorStop(0,'rgba(255,255,255,'+(.85*fl).toFixed(3)+')');g.addColorStop(.25,'rgba(200,170,255,'+(.35*fl).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}}
 /* la danse : leur réunion crée une sphère ; elles y tournent sur des grands cercles qui précessent, et leur trace
    devient le nuage de points du noyau (rotation à trois dimensions, profondeur rendue par la taille et l'éclat) */
 function rot3(p,ax,ay){var cy=Math.cos(ay),sy=Math.sin(ay),x=p[0]*cy+p[2]*sy,z=-p[0]*sy+p[2]*cy,cx=Math.cos(ax),sx=Math.sin(ax),y=p[1]*cx-z*sx;z=p[1]*sx+z*cx;return [x,y,z];}
 function orb(th,al,be){return rot3([Math.cos(th),Math.sin(th),0],al,be);}
 /* figures de la danse : antipodes sur des grands cercles qui précessent → poursuite sur la même orbite → orbites croisées
    (elles se frôlent aux nœuds) → loxodromies d'un pôle à l'autre ; chaque figure dure ≈ 4 s et se fond dans la suivante */
 function nrm(p){var l=Math.hypot(p[0],p[1],p[2])||1;return [p[0]/l,p[1]/l,p[2]/l];}
 function fig(m,t){var th=t*.0029,al=.9*Math.sin(t*.00041),be=t*.00023;
  if(m===0)return [orb(th,al,be),orb(th+PI,al+.5*Math.sin(t*.00033),be-.4*Math.cos(t*.00027))];
  if(m===1)return [orb(th*1.3,al,be),orb(th*1.3-.55,al,be)];
  if(m===2)return [orb(th,.2,be),orb(-th,1.1,be)];
  var la=1.25*Math.sin(t*.0011),lo=th*1.6;return [[Math.cos(la)*Math.cos(lo),Math.sin(la),Math.cos(la)*Math.sin(lo)],[Math.cos(-la)*Math.cos(lo+PI),Math.sin(-la),Math.cos(-la)*Math.sin(lo+PI)]];}
 function dancePos(t){var D=4200,k=Math.floor(t/D),f=(t-k*D)/D,m0=k%4,m1=(k+1)%4,wb=f>.72?ease('io',(f-.72)/.28):0,a=fig(m0,t),b=fig(m1,t),
  sl=function(u,v){var d=u[0]*v[0]+u[1]*v[1]+u[2]*v[2],g=Math.max(0,Math.min(1,(.2-d)/1.2))*1.2,E=[.31,.9,.3],
   mm=nrm([u[0]+v[0]+g*E[0],u[1]+v[1]+g*E[1],u[2]+v[2]+g*E[2]]),w1=(1-wb)*(1-wb),w2=2*wb*(1-wb),w3=wb*wb;
   return nrm([w1*u[0]+w2*mm[0]+w3*v[0],w1*u[1]+w2*mm[1]+w3*v[1],w1*u[2]+w2*mm[2]+w3*v[2]]);};
  return [sl(a[0],b[0]),sl(a[1],b[1])];}
 /* R229 : ruban lissé générique — Q tête d'abord, largeur et opacité par point ; trois couches remplies d'un seul tenant */
 function ribbon5(c,P0,W0,A0,col){var i,j,Q=[],QW=[],QA=[],P=[],Wd=[],Ad=[];for(i=0;i<P0.length;i++){if(P.length&&Math.hypot(P0[i][0]-P[P.length-1][0],P0[i][1]-P[P.length-1][1])<.8)continue;P.push(P0[i]);Wd.push(W0[i]);Ad.push(A0[i]);}if(P.length<2)return;   /* points trop proches écartés : plus de repli du ruban */
  for(i=0;i<P.length-1;i++){var p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)];
   for(j=0;j<4;j++){var u=j/4,u2=u*u,u3=u2*u;Q.push([.5*((2*p1[0])+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*((2*p1[1])+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)]);QW.push(Wd[i]+(Wd[i+1]-Wd[i])*u);QA.push(Ad[i]+(Ad[i+1]-Ad[i])*u);}}
  Q.push(P[P.length-1]);QW.push(Wd[Wd.length-1]);QA.push(Ad[Ad.length-1]);
  c.save();c.globalCompositeOperation='lighter';
  [[3,.42,col],[1.4,1,col],[.45,1,'#F1F4F6']].forEach(function(L){for(i=0;i<Q.length-1;i+=6){var e=Math.min(Q.length-1,i+6),Lf=[],Rt=[];   /* tronçons bord à bord */
    for(j=i;j<=e;j++){var a=Q[Math.max(0,j-1)],b=Q[Math.min(Q.length-1,j+1)],tx=b[0]-a[0],ty=b[1]-a[1],tl=Math.hypot(tx,ty)||1,ww=QW[j]*L[0]*.5;Lf.push([Q[j][0]-ty/tl*ww,Q[j][1]+tx/tl*ww]);Rt.push([Q[j][0]+ty/tl*ww,Q[j][1]-tx/tl*ww]);}
    var am=(QA[i]+QA[e])/2*L[1];if(am<=.003)continue;c.beginPath();c.moveTo(Lf[0][0],Lf[0][1]);for(j=1;j<Lf.length;j++)c.lineTo(Lf[j][0],Lf[j][1]);for(j=Rt.length-1;j>=0;j--)c.lineTo(Rt[j][0],Rt[j][1]);c.closePath();
    var g=c.createLinearGradient(Q[i][0],Q[i][1],Q[e][0],Q[e][1]);g.addColorStop(0,rgba(L[2],QA[i]*L[1]));g.addColorStop(1,rgba(L[2],QA[e]*L[1]));c.fillStyle=g;c.fill();}});
  c.restore();}
 function epDance(c,w,h,now,t,dt,s0){var n,q;c.fillStyle='#05070D';c.fillRect(0,0,w,h);bgImg(c,w,h,10,.12+.1*cl(t/1500),0);vign(c,w,h,.45,.92);
  var s=s0*(1.02+.08*ease('io',cl(t/9000))),C=[180,236],Rs=118*ease('out',cl(t/1400)),spin=t*.00042,tilt=.36;
  c.save();c.translate(w/2,h/2);c.scale(s,s);c.translate(-180,-240);
  /* étoiles */
  for(n=0;n<70;n++){var sx2=(n*97)%360,sy2=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.15+.25*Math.sin(now*.002+n*1.7))*cl(t/1500));c.fillRect(sx2,sy2,1.2,1.2);}
  /* mouvements propres : deux grands cercles qui précessent ; antipodes la plupart du temps, puis elles se rapprochent */
  var pr=dancePos(t),pA=pr[0],pB=pr[1];
  if(t>200){var oA=EP.oA||pA,oB=EP.oB||pB;var NS5=Math.min(60,Math.max(3,Math.ceil(Math.max(Math.hypot(pA[0]-oA[0],pA[1]-oA[1],pA[2]-oA[2]),Math.hypot(pB[0]-oB[0],pB[1]-oB[1],pB[2]-oB[2]))/.04)));for(var ii=1;ii<=NS5;ii++){var ff=ii/NS5,qa=[oA[0]+(pA[0]-oA[0])*ff,oA[1]+(pA[1]-oA[1])*ff,oA[2]+(pA[2]-oA[2])*ff],qb=[oB[0]+(pB[0]-oB[0])*ff,oB[1]+(pB[1]-oB[1])*ff,oB[2]+(pB[2]-oB[2])*ff],la=Math.hypot(qa[0],qa[1],qa[2])||1,lb=Math.hypot(qb[0],qb[1],qb[2])||1;EP.pts.push([qa[0]/la,qa[1]/la,qa[2]/la,0]);EP.pts.push([qb[0]/lb,qb[1]/lb,qb[2]/lb,1]);}if(EP.pts.length>2600)EP.pts.splice(0,EP.pts.length-2600);}EP.oA=pA;EP.oB=pB;
  var W2=function(p){var r=rot3(p,tilt,spin),f=1/(1-r[2]*.22);return [r[0]*f,r[1]*f,r[2]];};   /* légère perspective : le volume se lit */
  /* grands cercles de référence, très discrets (lecture 3D) */
  c.save();c.globalCompositeOperation='lighter';var fr=cl((t-800)/2000);
  for(var m=0;m<3;m++){c.beginPath();for(n=0;n<=48;n++){var pp=W2(rot3([Math.cos(n/48*2*PI),0,Math.sin(n/48*2*PI)],m*PI/3,0));var X=C[0]+pp[0]*Rs,Y=C[1]+pp[1]*Rs;n?c.lineTo(X,Y):c.moveTo(X,Y);}c.strokeStyle='rgba(77,215,255,'+(.11*fr).toFixed(3)+')';c.lineWidth=.8;c.stroke();}
  var lg=c.createRadialGradient(C[0],C[1],Rs*.82,C[0],C[1],Rs*1.12);lg.addColorStop(0,'rgba(168,120,255,0)');lg.addColorStop(.6,'rgba(168,120,255,'+(.1*fr).toFixed(3)+')');lg.addColorStop(1,'rgba(77,215,255,0)');c.fillStyle=lg;c.beginPath();c.arc(C[0],C[1],Rs*1.12,0,2*PI);c.fill();
  /* nuage de points déposés par les deux danseuses */
  /* R231 : la trace déposée est un fil continu (plus de pointillé de carrés) : un tracé par danseuse, par tronçons de 5 points,
     épaisseur et éclat selon la profondeur, extrémités rondes ; quelques perles rondes et douces le long du fil */
  c.lineCap='round';c.lineJoin='round';[0,1].forEach(function(fl){var P2=[],m2;for(m2=0;m2<EP.pts.length;m2++){q=EP.pts[m2];if((q[3]?1:0)===fl)P2.push(q);}
   for(m2=0;m2<P2.length-1;m2+=5){var e2=Math.min(P2.length-1,m2+5),dm=0,lt2=0;c.beginPath();for(var j2=m2;j2<=e2;j2++){var r2=W2(P2[j2]),X2=C[0]+r2[0]*Rs,Y2=C[1]+r2[1]*Rs;j2===m2?c.moveTo(X2,Y2):c.lineTo(X2,Y2);dm+=(r2[2]+1)/2;lt2+=(P2[j2][1]+1)/2;}
    dm/=(e2-m2+1);lt2/=(e2-m2+1);var cs=fl?[Math.round(168+60*lt2),Math.round(120-10*lt2),255]:[Math.round(77+150*lt2),Math.round(215-60*lt2),Math.round(255-60*lt2)];
    c.strokeStyle='rgba('+cs[0]+','+cs[1]+','+cs[2]+','+(.1+.42*dm).toFixed(3)+')';c.lineWidth=.6+1.3*dm;c.stroke();
    if(m2%40===0){var rp2=W2(P2[m2]),gp=c.createRadialGradient(C[0]+rp2[0]*Rs,C[1]+rp2[1]*Rs,0,C[0]+rp2[0]*Rs,C[1]+rp2[1]*Rs,2.6);gp.addColorStop(0,'rgba('+cs[0]+','+cs[1]+','+cs[2]+','+(.5*dm).toFixed(3)+')');gp.addColorStop(1,'rgba('+cs[0]+','+cs[1]+','+cs[2]+',0)');c.fillStyle=gp;c.fillRect(C[0]+rp2[0]*Rs-3,C[1]+rp2[1]*Rs-3,6,6);}}});
  c.restore();
  /* traînes */
  [[EP.dA,pA],[EP.dB,pB]].forEach(function(o){var T0=o[0],p=o[1],l0=T0[T0.length-1];if(l0){var ga=Math.acos(Math.max(-1,Math.min(1,(l0[0]*p[0]+l0[1]*p[1]+l0[2]*p[2])/((Math.hypot(l0[0],l0[1],l0[2])*Math.hypot(p[0],p[1],p[2]))||1))));if(ga>.1){var ns=Math.min(60,Math.ceil(ga/.05));for(var gi=1;gi<ns;gi++){var gf=gi/ns,gq=[l0[0]+(p[0]-l0[0])*gf,l0[1]+(p[1]-l0[1])*gf,l0[2]+(p[2]-l0[2])*gf],gl=Math.hypot(gq[0],gq[1],gq[2])||1,pl=Math.hypot(p[0],p[1],p[2])||1;T0.push([gq[0]/gl*pl,gq[1]/gl*pl,gq[2]/gl*pl]);}}}T0.push(p);while(T0.length>34+Math.min(60,T0.length>34?0:0))T0.shift();});
  [[EP.dA,'#F1F4F6'],[EP.dB,'#A878FF']].forEach(function(o){var T=o[0],Q=[],Wd=[],Ad=[];for(var a=T.length-1;a>=0;a--){var r2=W2(T[a]),d=(r2[2]+1)/2,f=a/T.length;Q.push([C[0]+r2[0]*Rs,C[1]+r2[1]*Rs]);Wd.push((1+3.5*d)*f);Ad.push(f*(.15+.5*d));}ribbon5(c,Q,Wd,Ad,o[1]);});   /* R229 : ruban continu, plus de tronçons */
  /* l'axe qui les relie passe par le centre : la corrélation */
  var rA=W2(pA),rB=W2(pB);c.save();c.strokeStyle='#A878FF';c.globalAlpha=.18;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(C[0]+rA[0]*Rs,C[1]+rA[1]*Rs);c.lineTo(C[0]+rB[0]*Rs,C[1]+rB[1]*Rs);c.stroke();c.setLineDash([]);c.restore();
  var cg=c.createRadialGradient(C[0],C[1],0,C[0],C[1],Rs*.5);cg.addColorStop(0,'rgba(241,244,246,'+(.12+.05*Math.sin(now*.003)).toFixed(3)+')');cg.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=cg;c.beginPath();c.arc(C[0],C[1],Rs*.5,0,2*PI);c.fill();
  /* les deux particules, la plus proche dessinée en dernier, taille selon la profondeur */
  var L2=[[rA,0],[rB,1]].sort(function(a,b){return a[0][2]-b[0][2];});L2.forEach(function(o){var r=o[0],sc=.72+.45*(r[2]+1)/2,x=C[0]+r[0]*Rs,y=C[1]+r[1]*Rs;if(o[1])comp(c,x,y,.7+.3*(r[2]+1)/2,sc,now);else eBall(c,x,y,.75+.25*(r[2]+1)/2,sc,now);});
  c.restore();
  var ir=1-ease('out',cl(t/700));if(ir>0){var g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.45);g.addColorStop(0,'rgba(255,255,255,'+(.8*ir).toFixed(3)+')');g.addColorStop(.25,'rgba(200,170,255,'+(.3*ir).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}
  var ttl=EP.title||'';if(ttl&&t>2600){var ta=ease('io',cl((t-2600)/2600)),sp2=Math.round(14-6*ta),fs=Math.round(Math.min(w*.09,36));c.save();c.font='300 '+fs+'px "Space Grotesk","Avenir Next",system-ui,sans-serif';c.textBaseline='middle';
   var ws=[],tw=0,q2;for(q2=0;q2<ttl.length;q2++){var cw=c.measureText(ttl[q2]).width;ws.push(cw);tw+=cw+(q2<ttl.length-1?sp2:0);}var x0=w/2-tw/2,y0=h*.14+(1-ta)*6;
   c.shadowColor='rgba(77,215,255,'+(.6*ta).toFixed(3)+')';c.shadowBlur=18*ta;for(q2=0;q2<ttl.length;q2++){var la=cl(ta*1.6-q2*.08);c.fillStyle='rgba(241,244,246,'+(.92*la).toFixed(3)+')';c.fillText(ttl[q2],x0,y0);x0+=ws[q2]+sp2;}
   c.shadowBlur=0;var lw=tw*.5*ta;c.fillStyle='rgba(168,120,255,'+(.45*ta).toFixed(3)+')';c.fillRect(w/2-lw/2,y0+fs*.72,lw,1);c.restore();}   /* titre final, lettre après lettre */
  return t>7000;}
 var FT0=null;
 function epilogue(c,w,h,now,opt){
  if(typeof window==='undefined'||window.QFIN_A!==false){if(FT0==null||now<FT0){FT0=now;fin5.reset();}var tt=now-FT0;fin5.render(c,w,h,tt,opt);return {t:tt,ground:tt>=fin5.total()-400};}   /* R233 : fin5 validée par Simon, jouée par défaut ; window.QFIN_A=false rétablit la fin R207 (banc) */
  if(!EP||now<EP.T0){EP={T0:now,last:now,cam:{ok:false},tr:[],trB:[],seen:{},hit:[],syn:[],rip:[],pts:[],dA:[],dB:[],sh:0,zk:1,ct:0,ts:1,tf:0,bA:[],bB:[],rungs:[]};for(var pk=0;pk<11;pk++)img(pk);parts=[];}
  var dt=Math.max(0,Math.min(60,now-EP.last));EP.last=now;EP.dt=dt;now0=now;dtD=dt;EP.title=opt&&opt.title||'';
  var t=now-EP.T0,s0=Math.min(w/UW,h/UH),done=false,SPD=1.12;
  c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  if(EP.ct<TRT){EP.ts+=(1-EP.ts)*(1-Math.pow(EP.ts<1?.12:.3,dt/1000));var dd=dt*SPD*EP.ts;EP.ct=Math.min(TRT,EP.ct+dd);epChase(c,w,h,now,EP.ct,dd,s0);if(EP.ct>=TRT)EP.tf=t;}
  else if(t-EP.tf<TH)epFuse(c,w,h,now,t-EP.tf,dt,s0);else done=epDance(c,w,h,now,t-EP.tf-TH,dt,s0);
  return {t:t,ground:done};
 }
 /* ══ R213 · fin5 — la fin, réécrite à partir du héros ══
   Méthode : le rendu du héros (traînée, éclats, ondes, vrais éléments VX), des scènes de ~2 s écrites une à une, UN choc par
   obstacle, des trajectoires issues d'une vraie mécanique (gravité g, rebonds, ressort de la corde, énergie du looping), des
   moments choisis où la physique est suspendue (superposition, portails, aspiration du vortex). Pas de plan de profondeur, pas
   de fil entre les particules, pas de roulis, pas de ralenti. Départ dans la coupe du dernier niveau ; fin : plongeon fluide
   dans le vortex puis l'atome des onze mondes.
   Insérée dans la portée de hero.js (outil de banc), exposée en QHERO.fin5. */
var fin5=(function(){
 var G=.0021,VA=.24;                       /* g (px/ms²) ; vitesse horizontale de croisière (px/ms) */
 function lerp(a,b,u){return a+(b-a)*u;}
 function tab(Pt,d){var n=Pt.length-1;return Fn(function(u){var f=cl(u)*n,i=Math.min(n-1,Math.floor(f)),k=f-i;return [Pt[i][0]+(Pt[i+1][0]-Pt[i][0])*k,Pt[i][1]+(Pt[i+1][1]-Pt[i][1])*k];},d);}
 /* ——— mécanique : pas de 1 ms, surfaces (sol / plafond, rigides ou à ressort), forces ——— */
 function sim(st,o){var x=st.x,y=st.y,vx=st.vx,vy=st.vy,t=0,P=[[x,y]],hits=[],S=o.surf||[],g=o.g==null?G:o.g,F=o.F,tMax=o.tMax||3000,xEnd=o.xEnd==null?-2:o.xEnd,on=null,i,k,sf;
  S.forEach(function(s){s._in=0;});
  while(t<tMax){
   for(k=0;k<4;k++){var ay=typeof g==='function'?g(x,y,t):g,ax=0;if(F){var f=F(x,y,vx,vy,t);ax=f[0];ay+=f[1];}
    vx+=ax;vy+=ay;x+=vx;y+=vy;t++;
    for(i=0;i<S.length;i++){sf=S[i];
     if((sf.x0!=null&&x<sf.x0)||(sf.x1!=null&&x>sf.x1)){if(on===sf)on=null;sf._in=0;continue;}
     var fy=sf.f(x),dir=sf.up?-1:1,pen=(y-fy)*dir;
     if(sf.k){if(pen>0){vy+=-(sf.k*pen*dir)-sf.c*vy;if(!sf._in){sf._in=1;hits.push({t:t,x:x,y:y,v:Math.abs(vy),nx:0,ny:-dir,sf:sf});}}else sf._in=0;continue;}
     var sl=(sf.f(x+1)-sf.f(x-1))/2,N=Math.sqrt(1+sl*sl),nx=(dir>0?sl:-sl)/N,ny=(dir>0?-1:1)/N;
     if(pen>0){y=fy;var vn=vx*nx+vy*ny;
      if(vn<0){if(-vn<(sf.vr||.05)){vx-=vn*nx;vy-=vn*ny;on=sf;}
       else{var e=sf.e==null?.4:sf.e;vx-=(1+e)*vn*nx;vy-=(1+e)*vn*ny;if(-vn>.12)hits.push({t:t,x:x,y:y,v:-vn,nx:nx,ny:ny,sf:sf});on=null;}}
      else on=sf;}
     else if(on===sf){if(-pen<1.2&&(vx*nx+vy*ny)<.03){y=fy;var vn2=vx*nx+vy*ny;vx-=vn2*nx;vy-=vn2*ny;}else on=null;}
    }}
   P.push([x,y]);
   if(o.until&&o.until({x:x,y:y,vx:vx,vy:vy,t:t}))break;
   if(x<=xEnd||x>720||y>900||y<-500)break;}
  return {P:P,d:t,st:{x:x,y:y,vx:vx,vy:vy},hits:hits};}
 function flat(y,e,o){o=o||{};return {f:function(){return y;},e:e,x0:o.x0,x1:o.x1,mat:o.mat||0,up:o.up};}
 /* ——— constructeur de trajectoire ——— */
 function Path(x,y,vx,vy){this.sx=x;this.sy=y;this.x=x;this.y=y;this.vx=vx||0;this.vy=vy||0;this.segs=[];this.ev=[];this.t=0;this.hits=[];}
 var PP=Path.prototype;
 PP.add=function(seg,x,y,vx,vy){this.segs.push(seg);this.t+=seg.d;this.x=x;this.y=y;this.vx=vx;this.vy=vy;return this;};
 PP.w=function(d){this.segs.push(Hd(d));this.t+=d;return this;};
 PP.kick=function(vx,vy){this.vx=vx;this.vy=vy;return this;};
 PP.e=function(type,a,b,c2,d2){this.ev.push([this.t,type,a,b,c2,d2]);return this;};
 /* R229 : réception lourde puis deux rebonds qui s'éteignent (choc sourd, puis petit, puis rien) */
 PP.bounce2=function(dir,dx1,h1,d1,dx2,h2,d2){var me=this;me.e('thud');[[dx1,h1,d1,4.5],[dx2,h2,d2,2.6]].forEach(function(b){var x0=me.x,y0=me.y,dx=dir*b[0],h=b[1],d=b[2];
   me.fn(function(u){return [x0+dx*u,y0-h*4*u*(1-u)];},d,x0+dx,y0,dx/d,4*h/d);me.hits.push({t:me.t,x:x0+dx,y:y0+11,v:b[3]/10});me.e('hit',b[3],0,0,-1);});me.vy=0;return me;};   /* R237 : la réception éteint la chute — sinon la trajectoire suivante plonge sous le sol (Mécanique, note de Simon) */
 PP.run=function(o){var me=this,r=sim(this,o);if(r.d<=0)return this;
  r.hits.forEach(function(h){var v=Math.min(8.5,2.6+h.v*7.5);me.ev.push([me.t+h.t,h.sf.evt||'hit',v,h.sf.mat||0,h.nx,h.ny]);me.hits.push({t:me.t+h.t,x:h.x,y:h.y,v:h.v,sf:h.sf});});
  return this.add(tab(r.P,r.d),r.st.x,r.st.y,r.st.vx,r.st.vy);};
 PP.ln=function(x,y,d,e){var v0=this;this.segs.push(Ln([x,y],d,e));this.t+=d;this.vx=(x-v0.x)/d;this.vy=(y-v0.y)/d;this.x=x;this.y=y;return this;};
 PP.tp=function(x,y,d){d=d||40;this.segs.push(Tp([x,y],d));this.t+=d;this.x=x;this.y=y;return this;};
 PP.fn=function(f,d,x,y,vx,vy){return this.add(Fn(f,d),x,y,vx==null?this.vx:vx,vy==null?this.vy:vy);};
 PP.glide=function(x,y,vx,vy,d){var x0=this.x,y0=this.y,m0x=this.vx,m0y=this.vy,dist=Math.hypot(x-x0,y-y0),sp=(Math.hypot(m0x,m0y)+Math.hypot(vx,vy))/2||.2;
  d=d||Math.max(160,Math.round(dist/Math.max(.14,sp)));
  var f=function(u){var u2=u*u,u3=u2*u,h00=2*u3-3*u2+1,h10=u3-2*u2+u,h01=-2*u3+3*u2,h11=u3-u2;return [h00*x0+h10*m0x*d+h01*x+h11*vx*d,h00*y0+h10*m0y*d+h01*y+h11*vy*d];};
  return this.add(Fn(f,d),x,y,vx,vy);};
 PP.scale=function(f){this.segs.forEach(function(g){g.d=Math.max(1,Math.round(g.d*f));});this.ev.forEach(function(e){e[0]*=f;});this.hits.forEach(function(h){h.t*=f;});this.t=this.segs.reduce(function(a,g){return a+g.d;},0);this.vx/=f;this.vy/=f;return this;};
 PP.safe=function(){if(this.x>-2)this.glide(-2,this.y,-.24,0);return this;};
 PP.pad=function(T){if(this.t<T-1){var d=T-this.t;this.ln(this.x+this.vx*d,this.y+this.vy*d,d);}return this;};
 /* trajectoire d'orbite : r(u), sweep total, vitesse angulaire ∝ 1/r² (seconde loi de Kepler) */
 function orbit(cx,cy,r0,th0,sweep,rf,d,sq){var N=60,W=[0],i,u,rr;sq=sq||1;
  for(i=1;i<=N;i++){u=(i-.5)/N;rr=rf(u);W.push(W[i-1]+1/(rr*rr));}
  var tot=W[N];return function(v){var f=cl(v)*N,j=Math.min(N-1,Math.floor(f)),k=f-j,w=(W[j]+(W[j+1]-W[j])*k)/tot,th=th0+sweep*w,r=rf(cl(v));return [cx+r*Math.cos(th),cy+r*Math.sin(th)*sq];};}
 /* ——— les scènes ——— */
 var RB=function(x){return 350;};
 var BEV=[];
 var SC=[];
 /* 11 · la coupe du dernier niveau */
 SC.push({w:11,nm:'la coupe',build:function(){
  var A=new Path(205,388,0,0).w(430).e('pulse',205,398).w(40).kick(-.19,-.72).run({until:function(s){return s.vy>=0;}}).glide(-2,250,-.22,0);
  return {A:A};},
  sqA:function(lt){if(lt<430)return {sx:1+.12*ease('io',lt/430),sy:1-.2*ease('io',lt/430)};if(lt<470)return {sx:1.12-.3*(lt-430)/40,sy:.8+.5*(lt-430)/40};if(lt<700){var u=(lt-470)/230;return {sx:.82+.18*u,sy:1.3-.3*u};}return null;},
  cam:function(lt){return {z:lt<700?1.2:.98,ty:lt<700?330:null};}});
 /* 10 · Quantique : le module de division sépare la particule ; l'une franchit le champ de temps dilaté, l'autre traverse le mur poreux (effet tunnel) */
 SC.push({w:10,nm:'Quantique',build:function(a){
  var A=new Path(a.x,a.y,-.22,0),dx=a.x-276,t0=Math.round(dx/.25);A.ln(276,250,t0).e('split').kick(-.22,-.50).run({until:function(s){return s.vy>=0;}}).glide(-2,150,-.24,0);
  var B=new Path(276,250,-.24,0),fl=[flat(350,.22,{mat:0})];
  B.kick(-.24,-.04).run({surf:fl,until:function(s){return s.x<=186;}}).e('tunnel').run({surf:fl,until:function(s){return s.x<=150;}}).run({surf:fl,xEnd:-2});
  return {A:A,B:B,B0:t0};},
  cam:function(lt){return {z:lt<500?1.14:1,oy:0};}});
 /* 9 · Filaments : A traverse la harpe (cordes qui chantent), tombe sur la corde-tremplin et en est catapultée ; B rebondit le long de la corde */
 var ROPE=function(x0){return {f:function(){return 350;},k:6.9e-4,c:.0042,x0:x0||30,x1:400,mat:0,evt:'twang'};};
 var WV={t0:300,d:1150};   /* R215 · la vague (Simon : « j'aime la vague ») : une impulsion transverse porte les deux particules, se réfléchit inversée au nœud */
 function strY5(x,lt){var y=300,xc,ap,e=WV.t0+WV.d;
  if(lt>=WV.t0&&lt<e){var u=(lt-WV.t0)/WV.d;xc=330-310*u;ap=70*ease('out',cl(u/.3))*(1-.3*u);y-=ap*Math.exp(-Math.pow((x-xc)/38,2));}
  else if(lt>=e){xc=10+(lt-e)*.3;ap=-40*Math.exp(-(lt-e)/600);y-=ap*Math.exp(-Math.pow((x-xc)/38,2));}
  return y+Math.sin(x*.05+now0*.004)*.8;}
 SC.push({w:9,nm:'Filaments',sync:1,build:function(a,b){
  var A=new Path(a.x,a.y,-.24,0);A.glide(330,288,-.15,.35,WV.t0).e('twang',6);
  A.fn(function(u){var lt=WV.t0+u*WV.d,x=330-310*u;return [x,strY5(x,lt)-12];},WV.d,20,strY5(20,WV.t0+WV.d)-12,-.27,0).e('boost');
  A.glide(-2,150,-.3,-.3,220);
  var u1=.12,lt1=WV.t0+u1*WV.d,xb=330-310*u1+44,B=new Path(b.x,b.y,-.24,0);B.glide(xb,strY5(xb,lt1)-12,-.2,.3,lt1).e('twang',4);
  B.fn(function(u){var v=u1+(1-u1)*u,lt=WV.t0+v*WV.d,x=330-310*v+44;return [x,strY5(x,lt)-12];},Math.round(WV.d*(1-u1)),64,strY5(64,WV.t0+WV.d)-12,-.27,0);
  B.glide(-2,180,-.3,-.2,200);
  return {A:A,B:B};},
  cam:function(lt){return {z:1.0};}});
 /* 8 · Faille : A franchit un portail et ressort de l'autre ; B tombe par le bas, reparaît par le haut (univers recousu) */
 var P2=[322,318],P1=[190,150];
 SC.push({w:8,nm:'Faille',build:function(a,b){
  var fl=[flat(330,.3,{x0:10,x1:250,mat:0})];
  var A=new Path(a.x,a.y,a.vx,a.vy);A.ln(P2[0],P2[1],Math.round(Math.hypot(a.x-P2[0],a.y-P2[1])/.2)).e('portal',P2[0],P2[1]).tp(P1[0],P1[1],50).e('portal',P1[0],P1[1])
   .kick(-.20,-.20).run({surf:fl,until:function(s){return s.x<=60;}}).glide(-2,330,-.24,0);
  var B=new Path(b.x,b.y,b.vx,b.vy);B.kick(-.24,0).run({until:function(s){return s.y>=492;}}).e('seam',0,0).tp(B.x,-18,30).run({surf:fl,until:function(s){return s.x<=60;}}).glide(-2,330,-.24,0);
  return {A:A,B:B};},
  cam:function(lt){return {z:1};}});

 /* 7 · Magnétisme : le cyclotron. Les deux dees sont séparés par une fente ; à chaque traversée la particule reçoit une poussée, son rayon croît (ω constant, r ∝ v).
    A (charge +) tourne dans un sens, B (charge −) dans l'autre ; elles se croisent dans la fente et sortent tangentiellement, très vite. */
 var MG=[190,340];
 function cyc(P,sg,th0,r0,rEnd,w,turns,sx,sy){
  var T=turns*2*PI/w,N=turns*2,g=(rEnd-r0)/N;
  function sm(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
  function rr(t){var q=w*t/PI,r=r0,k;for(k=0;k<N;k++)r+=g*sm((q-k+.22)/.44);return r;}
  function pos(t){var th=th0+sg*w*t,r=rr(t);return [MG[0]+r*Math.cos(th),MG[1]+r*Math.sin(th)];}
  var t0=P.t;
  P.fn(function(u){return pos(u*T);},Math.round(T),0,0);
  var e=pos(T),e0=pos(T-4);P.x=e[0];P.y=e[1];P.vx=(e[0]-e0[0])/4;P.vy=(e[1]-e0[1])/4;
  for(var k=1;k<N;k++){var q=pos(k*PI/w);P.ev.push([t0+k*PI/w,'gap',q[0],q[1]]);}
  return P;}
 /* trois temps : le rayon croît à chaque traversée de la fente, plateau à pleine vitesse, puis spirale d'effondrement vers le centre (ω croissant) où les deux particules se percutent */
 function cyc2(P,sg,th0,r0){var w=.0098,T1=Math.round(2.5*2*PI/w),N=5,R=84,g=(R-r0)/N,T2=720,T3=950,t0=P.t,T=T1+T2+T3,thE;
  function sm(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
  function rr(t){if(t<T1){var q=w*t/PI,r=r0,k;for(k=0;k<N;k++)r+=g*sm((q-k+.22)/.44);return r;}if(t<T1+T2)return R;var u=(t-T1-T2)/T3;return R*Math.pow(1-u,1.35);}
  function th(t){if(t<=T1+T2)return th0+sg*w*t;var u=(t-T1-T2)/T3;return th0+sg*(w*(T1+T2)+w*T3*(u+1.6*u*u*u));}
  function pos(t){var a=th(t),r=rr(t);return [MG[0]+r*Math.cos(a),MG[1]+r*Math.sin(a)];}
  P.fn(function(u){return pos(u*T);},T,0,0);
  var e=pos(T),e0=pos(T-4);P.x=e[0];P.y=e[1];P.vx=(e[0]-e0[0])/4;P.vy=(e[1]-e0[1])/4;
  for(var k=1;k<N;k++){var q=pos(k*PI/w);P.ev.push([t0+k*PI/w,'gap',q[0],q[1]]);}
  return P;}
 SC.push({w:7,nm:'Magnétisme',lag:120,build:function(a,b){
  var A=new Path(a.x,a.y,-.24,0),Bq=new Path(b.x,b.y,-.24,0),r0=22;
  A.ln(MG[0],MG[1]-r0,620);cyc2(A,-1,-PI/2,r0);
  A.w(70).e('coll',MG[0],MG[1]);A.kick(-.95,-.34).glide(-2,262,-.55,0,330);
  Bq.ln(MG[0],MG[1]+r0,620);cyc2(Bq,1,PI/2,r0);
  Bq.w(70);Bq.kick(-.9,.30).glide(-2,372,-.45,0,360);
  return {A:A,B:Bq};},
  cam:function(lt){var u=lt<1700?0:lt<4700?1:0;return {z:1.42,tx:190,ty:330};}});
 /* 6 · Gravité : A fait une fronde autour d'une planète (r(u) de Kepler : elle accélère au plus près) ; B traverse une zone de gravité inversée, monte au plafond (choc) puis retombe de l'autre côté */
 var PL=[170,330,32],ZG=[180,350],VCOL6='#8C7BFF';
 SC.push({w:6,nm:'Gravité',lag:260,tw:[[790,1075,-1,.9]],build:function(a,b){   /* R215 : planète retirée (Simon : kitsch) — zone Relativité du jeu, son propre bas */
  var A=new Path(a.x,a.y,-.24,0),Bq=new Path(b.x,b.y,-.24,0);
  var ceil=flat(40,.12,{up:true,x0:ZG[0]-10,x1:ZG[1]+10}),flo=flat(150,.25,{x0:-10,x1:ZG[0]});
  var gf=function(x,y){return (x>ZG[0]&&x<ZG[1])?-G*1.5:G;};
  A.glide(340,300,-.3,-.05,200).run({g:gf,surf:[ceil,flo],until:function(s){return s.x<=60&&s.y>=146;}}).glide(-2,150,-.3,0);
  Bq.glide(352,330,-.26,-.02,300).run({g:gf,surf:[ceil,flo],until:function(s){return s.x<=60&&s.y>=146;}}).glide(-2,150,-.3,0);
  return {A:A,B:Bq};},
  cam:function(lt){return {z:.95,ty:230};}});
 /* 5 · Mécanique : l'escalier se monte au rythme des chocs ; A rebondit marche par marche, B plus haut (elle double une marche) */
 var STX=[40,100,160,220,280],STY=[410,350,290,230,170],BASE5=456;
 function stairs(e){return STX.map(function(x,n){return flat(STY[n]-11,n?e:.45,{x0:n?x-5:-40,x1:x+55,mat:0});});}
 /* propulsion de la dernière marche : montée presque verticale, deux anneaux, puis arc vers la gauche (profil de vitesse par l'énergie) */
 var HP5=[[62,206],[8,176]];
 function launch5(P,k){var xs=P.x,ys=P.y,W=[[0,0],[2,-70],[2,-135],[0,-172],[-3,-193],[-22,-216],[-52,-226],[-82,-216],[-108,-190],[-126,-158]].map(function(q){return [xs+q[0],ys+q[1]*k];}),
   cr=function(a0,a1,a2,a3,u){return .5*((2*a1)+(-a0+a2)*u+(2*a0-5*a1+4*a2-a3)*u*u+(-a0+3*a1-3*a2+a3)*u*u*u);},
   pts=[],i,j,n=W.length,p0,p1,p2,p3,T5=[0],t=0,sp=function(y){return Math.sqrt(Math.max(.05,1.0-.0042*(ys-y)));};
  for(i=0;i<n-1;i++){p0=W[Math.max(0,i-1)];p1=W[i];p2=W[i+1];p3=W[Math.min(n-1,i+2)];for(j=0;j<12;j++){var u=j/12;pts.push([cr(p0[0],p1[0],p2[0],p3[0],u),cr(p0[1],p1[1],p2[1],p3[1],u)]);}}
  pts.push(W[n-1]);
  for(i=1;i<pts.length;i++){t+=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1])/((sp(pts[i][1])+sp(pts[i-1][1]))/2);T5.push(t);}
  var d=Math.round(t),f=function(u){var tm=cl(u)*d,lo=0,hi=T5.length-1,m;while(hi-lo>1){m=(lo+hi)>>1;if(T5[m]<=tm)lo=m;else hi=m;}var q=(tm-T5[lo])/Math.max(1e-6,T5[hi]-T5[lo]),a0=pts[lo],a1=pts[hi];return [a0[0]+(a1[0]-a0[0])*q,a0[1]+(a1[1]-a0[1])*q];},
   e=pts[pts.length-1],e0=pts[pts.length-4],el=Math.hypot(e[0]-e0[0],e[1]-e0[1])||1,ve=sp(e[1]);
  if(k===1)HP5=[W[4],W[6]];
  P.e('launch',0,0);return P.fn(f,d,e[0],e[1],ve*(e[0]-e0[0])/el,ve*(e[1]-e0[1])/el);}
 function mecaFly(P,x1,y1,d){var x0=P.x,y0=P.y,H=168;   /* vol balistique : départ presque vertical, apogée, réception douce */
  var f=function(u){var ux=u*u*(1.6-.6*u);return [x0+(x1-x0)*ux,y0-H*4*u*(1-u)*(1-.18*u)];};
  HP5=[f(.22),f(.5)];P.e('launch',0,0);var e=f(1),e0=f(1-8/d);return P.fn(f,d,e[0],e[1],(e[0]-e0[0])/8*.5,(e[1]-e0[1])/8*.35);}
 SC.push({w:5,nm:'Mécanique',build:function(a,b){
  var A=new Path(a.x,a.y,-.24,0),Bq=new Path(b.x,b.y,-.24,0);
  A.run({surf:stairs(.34),until:function(s){return s.x<=95&&s.y>=396;}});A.glide(66,399,-.12,0,220);
  Bq.run({surf:stairs(.45),until:function(s){return s.x<=150&&s.y>=326;}});
  var bx0=Bq.x,by0=Bq.y,HB=420;Bq.e('hit',4,0,0,-1);Bq.fn(function(u){return [bx0+(2-bx0)*u,by0+(399-by0)*u*u-34*4*u*(1-u)];},HB,2,399,(2-bx0)/HB*.7,0);   /* elle saute la dernière marche par-dessus la blanche */
  /* R227 : la violette ne s'arrête pas, elle passe devant et file au ras du sol ; la blanche, restée derrière depuis l'obstacle
     précédent, arrive sur la dernière marche qui l'éjecte : un grand arc, et elle se pose juste derrière sa compagne */
  var gap=Math.max(0,Bq.t+590-A.t);A.w(gap);var tB0=Bq.t,FL5=820,XL5=-150;A.e('thrust',0,0);mecaFly(A,XL5,399,FL5);A.bounce2(-1,26,22,300,13,8,190);
  Bq.bounce2(-1,22,16,260,10,6,170);Bq.glide(XL5-84,399,-.26,0,Math.max(300,A.t-Bq.t));
  return {A:A,B:Bq};},
  cam:function(lt){return {z:.95,ty:260};}});
 /* 4 · Soufflerie : la colonne d'air les hisse, le cyclone les capture ; elles y tournent (B à l'intérieur, plus vite, et dépasse A) puis sont éjectées vers la gauche */
 var VC=[130,138];
 function spin(P,r0,r1,th0,sweep,d){var fo=orbit(VC[0],VC[1],r0,th0,sweep,function(u){return r0+(r1-r0)*u;},d),en=fo(1),e0=fo(.99);
  return P.fn(fo,d,en[0],en[1],(en[0]-e0[0])/(.01*d),(en[1]-e0[1])/(.01*d));}
 SC.push({w:4,nm:'Soufflerie',lag:300,build:function(a,b){
  var A=new Path(a.x,a.y,a.vx,a.vy),Bq=new Path(b.x,b.y,b.vx,b.vy);
  [[A,192,62,50,1.25,760,1],[Bq,166,38,28,2.25,900,-1]].forEach(function(o){var P=o[0],X=o[1],R0=o[2],R1=o[3],T=o[4],D=o[5],sg=o[6];
   P.ln(X,399,Math.max(120,Math.round(Math.abs(P.x-X)/.34)));
   var y0=399,y1=VC[1],H=y0-y1,dl=720;
   P.fn(function(u){var e=Math.pow(u,1.4);return [X+sg*9*Math.sin(u*PI*3)*(1-u),y0-H*e];},dl,X,y1,0,-.45);
   P.e('vtx',VC[0],VC[1]);
   spin(P,R0,R1,0,-2*PI*T,D);
   P.e('eject',P.x,P.y);
   P.glide(-2,210,-.42,0);});
  return {A:A,B:Bq};},
  cam:function(lt){return {z:1.0,ty:230};}});
 /* 3 · Glacier : la piste glacée (niveau 6). Rail de glace sans frottement : la particule plonge, monte une boucle où elle ralentit presque à l'arrêt (énergie conservée), retombe et traverse sa propre piste par la zone poreuse. */
 var GLC=[175,305],GLR=72;   /* R216 : centre de la boucle = cœur du cyclone de glace */
 var GT=(function(){var o=[[400,210],[372,213],[346,228],[322,262],[302,318],[282,360],[258,376],[230,377],[202,377]],i,f;
  for(i=0;i<=30;i++){f=PI/2+2*PI*i/30;o.push([GLC[0]+GLR*Math.cos(f),GLC[1]+GLR*Math.sin(f)]);}
  o.push([148,377],[118,377],[88,372],[58,358],[30,338],[4,314],[-22,290],[-48,268]);return o;})();
 var GX=[0,0],CRS=[];
 var GD=(function(){var o=[],i,k,n=GT.length,p0,p1,p2,p3,u,u2,u3;
  for(i=0;i<n-1;i++){p0=GT[Math.max(0,i-1)];p1=GT[i];p2=GT[i+1];p3=GT[Math.min(n-1,i+2)];
   for(k=0;k<14;k++){u=k/14;u2=u*u;u3=u2*u;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*((2*p1[1])+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)]);}}
  o.push(GT[n-1]);return o;})();
 (function(){var i,j,a,b,c2,d,t,u,den,X;
  for(i=0;i<GD.length-1;i++)for(j=i+14;j<GD.length-1;j++){a=GD[i];b=GD[i+1];c2=GD[j];d=GD[j+1];den=(b[0]-a[0])*(d[1]-c2[1])-(b[1]-a[1])*(d[0]-c2[0]);if(Math.abs(den)<1e-9)continue;
   t=((c2[0]-a[0])*(d[1]-c2[1])-(c2[1]-a[1])*(d[0]-c2[0]))/den;u=((c2[0]-a[0])*(b[1]-a[1])-(c2[1]-a[1])*(b[0]-a[0]))/den;
   if(t>=0&&t<1&&u>=0&&u<1){X=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];if(!CRS.some(function(q){return Math.hypot(q[0]-X[0],q[1]-X[1])<14;}))CRS.push([X[0],X[1],i,j]);}}
  CRS.length=0;})();   /* R216 : la boucle ne se croise plus (entrée et sortie tangentes en bas) */
 function glRail(P,x0,v0){var i0=0,i,T=[0],t=0,pts=GD,v,ds,ny=0,tun=-1;
  while(i0<pts.length-1&&pts[i0][0]>x0)i0++;
  var sp=function(y){return Math.sqrt(Math.max(.034,v0*v0+2*G*.9*(y-210)));};
  var ie=i0;for(i=i0+1;i<pts.length;i++){ds=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);t+=ds/((sp(pts[i][1])+sp(pts[i-1][1]))/2);T.push(t);ie=i;if(pts[i][0]<=-2)break;}
  var d=Math.round(T[T.length-1]),seen=0,tt=0;
  for(i=i0+1;i<=ie;i++){if(Math.hypot(pts[i][0]-GX[0],pts[i][1]-GX[1])<5){seen++;if(seen===1&&i>i0+40)seen=1;}}
  var f=function(u){var tm=u*d,lo=0,hi=T.length-1,m;while(hi-lo>1){m=(lo+hi)>>1;if(T[m]<=tm)lo=m;else hi=m;}var k=(tm-T[lo])/Math.max(1e-6,T[hi]-T[lo]),a=pts[i0+lo],b=pts[i0+hi];return [a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k];};
  var ve=sp(pts[ie][1]),t0=P.t;
  /* instants de passage sur le croisement : le second est le franchissement par la zone poreuse */
  CRS.forEach(function(X){var j2=X[3];if(j2>=i0&&j2-i0<T.length)P.ev.push([t0+T[j2-i0],'pass',X[0]]);});P.ev.sort(function(p,q){return p[0]-q[0];});
  var ex=pts[ie][0]-pts[ie-3][0],ey=pts[ie][1]-pts[ie-3][1],el=Math.hypot(ex,ey)||1;P.fn(f,d,pts[ie][0],pts[ie][1],ve*ex/el,ve*ey/el);return P;}
 SC.push({w:3,nm:'Glacier',sync:1,build:function(a,b){
  var A=new Path(a.x,a.y,a.vx,a.vy),Bq=new Path(b.x,b.y,b.vx,b.vy);
  glRail(A,a.x,.42);Bq.w(170);glRail(Bq,b.x,.42);   /* R216 : B suit A sur la même piste, en train */
  return {A:A,B:Bq};},
  cam:function(lt){return {z:1.12,tx:185,ty:298};}});

 /* 2 · Chaîne : looping à pleine vitesse (énergie conservée), puis la rampe à tapis d'élan */
 var LP=[180,168],LR=62,FY2=230,BF=function(x){return x<=250?FY2:(x<330?FY2+.75*(x-250)*(x-250)/80:FY2+60+1.5*(x-330));};
 function loopPath(v0){var pts=[],th=Math.PI/2,t=0,e=Math.PI/2+2*Math.PI;pts.push([LP[0]+LR*Math.cos(th),LP[1]+LR*Math.sin(th)]);
  while(th<e-1e-6){var y0=LP[1]+LR*Math.sin(th),v=Math.sqrt(Math.max(.0004,v0*v0-2*G*((LP[1]+LR)-y0)));th=Math.min(e,th+v/LR*4);t+=4;pts.push([LP[0]+LR*Math.cos(th),LP[1]+LR*Math.sin(th)]);}
  return {P:pts,d:t};}
 var RAMP=function(x){return x<118?FY2-(118-x)*1.12:FY2;};
 SC.push({w:2,nm:'Chaîne',build:function(a,b){
  function lane(p0){var P=new Path(p0.x,p0.y,p0.vx,p0.vy),fl={f:BF,e:.2,x0:150,x1:420,mat:3},v0;
   P.run({surf:[fl],F:function(x){return x>250?[-.0019,-.0029]:[0,0];},until:function(s){v0=Math.hypot(s.vx,s.vy);return s.x<=182;}});v0=Math.max(.78,Math.hypot(P.vx,P.vy)+.12);
   var lp=loopPath(v0);P.add(tab(lp.P,lp.d),LP[0]+LR*Math.cos(Math.PI/2+2*Math.PI),LP[1]+LR,-v0,0).e('boost');
   var rp={f:RAMP,e:.2,x0:-30,x1:182,mat:3};
   P.run({surf:[rp],F:function(x){return x<118?[-.0007,-.0008]:[0,0];},until:function(s){return s.x<=40;}}).e('jump').run({until:function(s){return s.x<=-2;}});return P;}
  return {A:lane(a),B:lane(b)};},
  cam:function(lt){return {z:1.28};}});
 /* 1 · Fonderie : trois plaques de rebond au-dessus du bain de lave ; A rebondit de plaque en plaque, B plus mollement */
 var PLT=[[262,342,170,170],[170,250,250,250],[80,160,320,320],[-20,60,390,390]];   /* R216 : quatre plaques, plus haut, dans le champ */
 function plates(e){return PLT.map(function(q){return {f:function(x){return q[2]+(q[3]-q[2])*(x-q[0])/(q[1]-q[0]);},e:e,x0:q[0],x1:q[1],mat:1};});}
 SC.push({w:1,nm:'Fonderie',sync:1,tw:[[1195,1475,1,1.4]],build:function(a,b){   /* R217 : dessin de Simon — elles rebondissent entre plaques du sol et plaques du plafond, en zigzag descendant */
  PLT=[[245,325,215,215,1],[175,255,120,120,-1],[110,190,290,290,1],[50,130,195,195,-1],[-5,75,362,362,1]];
  function hop(P,x,y,d,up){var x0=P.x,y0=P.y,g=.0016,v0=(y-y0-.5*g*d*d)/d;P.fn(function(u){var t=u*d;return [x0+(x-x0)*u,y0+v0*t+.5*g*t*t];},d,x,y,(x-x0)/d,v0+g*d);P.hits.push({t:P.t,x:x,y:y+(up?-11:11),v:.35});P.e('hit',up?5.5:6.5,1,0,up?1:-1);return P;}   /* R218 : vols balistiques */
  function run(P,dx){hop(P,285+dx,215,380);hop(P,215+dx,120,240,1);hop(P,150+dx,290,320);hop(P,90+dx,195,240,1);hop(P,35+dx,362,330);P.bounce2(-1,20,18,260,10,7,170);P.glide(-2,282,-.32,-.42,220);return P;}
  var A=run(new Path(a.x,a.y,a.vx,a.vy),0),Bq=new Path(b.x,b.y,b.vx,b.vy);Bq.w(70);run(Bq,12);
  return {A:A,B:Bq};},
  cam:function(lt){return {z:.95,ty:300};}});


 /* 0 · Atelier (R223) : le dernier trait. Les particules roulent et accélèrent ; le trait accélère davantage et prend de l'avance :
    on le voit filer entre des zones interdites de tailles différentes (seul décor), dessiner un tremplin, puis entrer dans une zone
    interdite où il s'arrête et se délite en poussière ; cette poussière allume le trou noir. Les particules franchissent le tremplin,
    sautent et sont aspirées. */
 var DVW=-.01,ORGP=[-3420,230],FX0=340,FXE=-1130,FTS=4300,FTJ=5400,FR0=-840,FR1=-926,FZX=-930,FTF=3900;   /* R226 : la zone avale le trait à plat ; après le saut, vol libre (FTF) puis le vortex */   /* R225 : plus de temps pour le trait (vedette) et pour l'œil */   /* R224 : le trait monte, la zone le coupe : c'est la coupure qui fait le tremplin */
 var ZN=[[190,36,150,112],[-50,382,230,92],[-340,30,190,118],[-590,388,210,86],[-830,34,160,120],[-1200,112,270,270,1],[-1460,330,150,110]];   /* R225 : moins de zones, plus larges */
 var FYR=322+24*Math.sin((340-FR0)/210*PI);
 function TY(x){if(x>FR0)return 322+24*Math.sin((340-x)/210*PI)*Math.min(1,(FX0+48-x)/160);if(x<FZX){var uz=(FR0-FZX)/90;return FYR-34*uz*uz/(1+.35*uz)-(FZX-x)*.22;}var u=(FR0-x)/90;return FYR-34*u*u/(1+.35*u);}   /* il veut monter ; la zone l'en empêche ; il y entre presque à plat */
 var HD=1150;
 var TRP=(function(){var o=[];for(var x=FXE;x<=FX0;x+=4)o.push([x,TY(x)]);return o;})();   /* abscisses croissantes */
 function xTip(lt){if(lt<=300)return FX0+1;var u=cl((lt-300)/(FTS-300)),b=.6;return FX0-(FX0-FXE)*(b*u+(1-b)*u*u);}   /* le trait naît sous les particules à leur arrivée */
 function tTip(x){var k=cl((FX0-x)/(FX0-FXE)),b=.6;return 300+(-b+Math.sqrt(b*b+4*(1-b)*k))/(2*(1-b))*(FTS-300);}
 function xRun(t){var v=cl((t-300)/(FTJ-300)),a=.565;return 340-(340-FR1)*(a*v+(1-a)*v*v);}
 SC.push({w:0,nosafe:1,nm:'Atelier',tw:[],build:function(a,b){
  /* capture : à la fin du trait, la particule est happée par le trou noir ; elle spirale en rétrécissant (moment cinétique conservé : ω ∝ 1/r²) et finit sur l'ellipse du disque, là où la plongée reprend */
  function helix(P,sgn){var sw=sgn>0?3*PI:4*PI,th0=PI/2+.03,N=80,Wt=[0],i,tot,R0=Math.hypot(P.x-ORGP[0],P.y-ORGP[1]),r0=Math.max(80,Math.min(120,R0)),
   rf=function(u){return 30+(r0-30)*Math.pow(1-u,1.2);};
   for(i=1;i<=N;i++){var rr=rf((i-.5)/N);Wt.push(Wt[i-1]+1/(rr*rr));}tot=Wt[N];
   var F=function(u){var f=cl(u)*N,j=Math.min(N-1,Math.floor(f)),k=f-j,w=(Wt[j]+(Wt[j+1]-Wt[j])*k)/tot,th=th0+sw*w,r=rf(cl(u)),sq=.45+.55*cl((r-30)/72);return [ORGP[0]+r*Math.cos(th),ORGP[1]+r*Math.sin(th)*sq];};
   var e=F(1),e0=F(1-4/HD);P.fn(F,HD,e[0],e[1],(e[0]-e0[0])/4,(e[1]-e0[1])/4);}
  var A=new Path(a.x,a.y,a.vx,a.vy),Bq=new Path(b.x,b.y,b.vx,b.vy);
  /* R226 : spirale d'entrée tangente (aucun rebond) : elle arrive par la droite du trou noir en montant et s'enroule */
  function spF(){var r0=120,sw=3.2*PI,N=80,Wt=[0],i,tot,rf=function(u){return 30+(r0-30)*Math.pow(1-u,1.2);};for(i=1;i<=N;i++){var rr=rf((i-.5)/N);Wt.push(Wt[i-1]+1/(rr*rr));}tot=Wt[N];
   return function(u){var f=cl(u)*N,j=Math.min(N-1,Math.floor(f)),k=f-j,w=(Wt[j]+(Wt[j+1]-Wt[j])*k)/tot,th=-sw*w,r=rf(cl(u)),sq=.45+.55*cl((r-30)/72);return [ORGP[0]+r*Math.cos(th),ORGP[1]+r*Math.sin(th)*sq];};}
  /* R227 : vol libre en double hélice — les deux brins s'enroulent l'un autour de l'autre (antiphase), l'écart respire,
     s'ouvre après le saut et se referme à l'entrée de la spirale ; ligne médiane en Hermite, vitesse qui enfle puis se pose */
  function dnaFly(P,sg,D){var p0=[P.x,P.y],v0=[P.vx,P.vy],SF=spF(),p1=SF(0),q=SF(4/HD),v1=[(q[0]-p1[0])/4,(q[1]-p1[1])/4],a=.38,k0=D/(1-a);
   var m0=[v0[0]*k0,v0[1]*k0],m1=[v1[0]*k0,v1[1]*k0];
   function G(t){var t2=t*t,t3=t2*t,h00=2*t3-3*t2+1,h10=t3-2*t2+t,h01=-2*t3+3*t2,h11=t3-t2;return [h00*p0[0]+h10*m0[0]+h01*p1[0]+h11*m1[0],h00*p0[1]+h10*m0[1]+h01*p1[1]+h11*m1[1]];}
   function Gd(t){var t2=t*t,a0=6*t2-6*t,a1=3*t2-4*t+1,a2=-6*t2+6*t,a3=3*t2-2*t;return [a0*p0[0]+a1*m0[0]+a2*p1[0]+a3*m1[0],a0*p0[1]+a1*m0[1]+a2*p1[1]+a3*m1[1]];}
   var f=function(u){var sv=u-a*Math.sin(2*PI*u)/(2*PI),c0=G(sv),dd=Gd(sv),L=Math.hypot(dd[0],dd[1])||1,nx=-dd[1]/L,ny=dd[0]/L,
     R=30*Math.pow(Math.sin(PI*u),1.6)*(.8+.2*Math.sin(u*PI*5)),ph=2*PI*4.5*sv;return [c0[0]+sg*nx*R*Math.sin(ph),c0[1]+sg*ny*R*Math.sin(ph)];};
   return P.fn(f,D,p1[0],p1[1],v1[0],v1[1]);}
  function spiral(P,sgn){var r0=120,sw=3.2*PI,N=80,Wt=[0],i,tot,rf=function(u){return 30+(r0-30)*Math.pow(1-u,1.2);};for(i=1;i<=N;i++){var rr=rf((i-.5)/N);Wt.push(Wt[i-1]+1/(rr*rr));}tot=Wt[N];
   var F=function(u){var f=cl(u)*N,j=Math.min(N-1,Math.floor(f)),k=f-j,w=(Wt[j]+(Wt[j+1]-Wt[j])*k)/tot,th=-sw*w+(sgn<0?.0:0),r=rf(cl(u)),sq=.45+.55*cl((r-30)/72);return [ORGP[0]+r*Math.cos(th),ORGP[1]+r*Math.sin(th)*sq];};
   var e=F(1),e0=F(1-4/HD);P.fn(F,HD,e[0],e[1],(e[0]-e0[0])/4,(e[1]-e0[1])/4);}
  function go(P,dl,sg){if(dl)P.w(dl);P.glide(340,TY(340)-12,-.2,.1,300).e('hit',4,0,0,-1);
   P.fn(function(u){var x=xRun(300+u*(FTJ-300));return [x,TY(x)-12];},FTJ-300,FR1,TY(FR1)-12,-.5,-.25).e('boost');
   /* le saut, puis le vol libre en double hélice jusqu'à la spirale */
   dnaFly(P,sg,FTF+560-(dl||0));spiral(P,sg);return P;}
  go(A,0,1);A.e('absorb');go(Bq,90,-1);
  var SF5=spF(),q1=SF5(1),q0=SF5(1-2/HD),an5=function(p){return Math.atan2((p[1]-ORGP[1])/.45,p[0]-ORGP[0]);},da5=an5(q1)-an5(q0);if(da5>PI)da5-=2*PI;if(da5<-PI)da5+=2*PI;DVW=da5/2;   /* R228 : vitesse angulaire en fin de siphon, reprise par la plongée */
  return {A:A,B:Bq};},
  cam:function(lt){return {z:1.0,tx:null};}});

 /* ═══ assemblage : chaque scène s'appuie sur la sortie de la précédente (positions et vitesses) ═══ */
 var ZS=[],TRT5=0,DIVE=1700,ATOM=9800,NOMS={11:'la coupe',10:'Quantique',9:'Filaments',8:'Faille',7:'Magnétisme',6:'Gravité',5:'Mécanique',4:'Soufflerie',3:'Glacier',2:'Chaîne',1:'Fonderie',0:'Atelier'};
 (function(){var a={x:205,y:388,vx:0,vy:0},b=null;
  SC.forEach(function(s,i){var r=s.build(a,b||{x:a.x,y:a.y,vx:a.vx,vy:a.vy}),A=r.A,B=r.B,B0=r.B0||0,d;if(!s.nosafe){A.safe();if(B)B.safe();}if(s.stretch){A.scale(s.stretch);if(B)B.scale(s.stretch);}
   var tA=A.t,tB=B?B0+B.t:0;d=Math.max(tA,tB);
   if(B){var lm=s.sync?0:(s.lag==null?330:s.lag);
    if(tB-tA>lm&&(d-lm)/tA<=1.5)A.scale((d-lm)/tA);else if(tA-tB>lm&&(d-lm-B0)/B.t<=1.5)B.scale((d-lm-B0)/B.t);}
   A.pad(d);if(B)B.pad(d-B0);
   var z={w:s.w,nm:s.nm,x0:s.w*UW,t0:TRT5,d:d,cam:s.cam,sqA:s.sqA,sqB:s.sqB,B0:B0,tw:s.tw};
   z.A=A.segs;z.ev=A.ev.slice();z.inA=[A.sx,A.sy];var pa=prepSegs(z.A,z.inA);z.stA=pa.st;z.outA=pa.out;
   if(B){z.B=(B0>0?[Hd(B0)]:[]).concat(B.segs);z.evB=B.ev.map(function(e){var q=e.slice();q[0]+=B0;return q;});z.inB=[B.sx,B.sy];var pb=prepSegs(z.B,z.inB);z.stB=pb.st;z.outB=pb.out;}
   z.hitsA=A.hits;z.hitsB=B?B.hits.map(function(h){return {t:h.t+B0,x:h.x,y:h.y,v:h.v};}):[];z.vA=[A.vx,A.vy];if(B)z.vB=[B.vx,B.vy];
   ZS.push(z);TRT5+=d;
   a={x:A.x+360,y:A.y,vx:A.vx,vy:A.vy};b=B?{x:B.x+360,y:B.y,vx:B.vx,vy:B.vy}:null;});
  /* marches : chacune se lève un peu avant le premier choc d'A sur elle */
  var z5=ZS.filter(function(z){return z.w===5;})[0];z5.rise=STX.map(function(x,n){var t=0,dur=300+(BASE5-STY[n])*1.45;(z5.hitsA||[]).some(function(h){if(h.x>=x-5&&h.x<=x+55){t=h.t+50-dur;if(t<-150){dur=h.t+50+150;t=-150;}return true;}return false;});return [t,dur];});z5.thr=[z5.ev||[],z5.evB||[]].map(function(E){var t=null;E.forEach(function(e){if(e[1]==='thrust')t=e[0];});return t;});
 })();
 /* ═══ R230 · scénario vibratoire (proposition) : une partition par acte, en temps local (ms) — rythme, silences, crescendo.
    Principes : un motif par geste physique fort, jamais deux chocs lourds collés, des silences pour que les impacts comptent ;
    les mondes « doux » (Glacier, vol libre) ne vibrent presque pas ; la fin monte en tension jusqu'à l'aspiration. ═══ */
 var VIBSC=(function(){var tin=Math.round(tTip(FZX));return {
  'la coupe':[[120,'coeur'],[430,'lourd']],                                   /* le cœur bat, l'onde part */
  'Quantique':[[328,'portail'],[704,'portail']],                              /* dédoublement, effet tunnel */
  'Filaments':[[300,'rebond'],[443,'tic'],[1450,'propulse']],                 /* la corde claque, l'élan */
  'Faille':[[578,'portail'],[859,'portail'],[1429,'lourd']],                  /* couture, faille, réception */
  'Magnétisme':[[941,'tic'],[1261,'tic'],[1582,'rebond'],[1902,'rebond'],[2600,'tension'],[3963,'collision']],   /* l'accélérateur s'emballe */
  'Gravité':[[591,'lourd'],[1090,'rebond']],                                  /* la chute, le rebond */
  'Mécanique':[[256,'cliquet'],[692,'cliquet'],[1448,'lourd'],[1780,'tension'],[2038,'propulse'],[2858,'double']],   /* engrenages, violette posée, charge, éjection, double réception */
  'Soufflerie':[[200,'houle'],[840,'portail'],[1600,'envol']],                /* l'air monte, le cyclone, l'éjection */
  'Glacier':[[260,'givre'],[720,'givre'],[1180,'givre']],                     /* presque rien : la glace glisse */
  'Chaîne':[[77,'tic'],[868,'propulse'],[936,'rebond'],[1088,'envol']],
  'Fonderie':[[392,'rebond'],[640,'tic'],[970,'rebond'],[1218,'tic'],[1559,'double']],   /* sol lourd, plafond léger, dernière plaque */
  'Atelier':[[300,'tic'],[tin-2400,'crepite'],[tin-1500,'crepite'],[tin-800,'crepite'],[tin-300,'tension'],[tin,'annihile'],[tin+700,'crepite'],
             [FTJ,'propulse'],[FTJ+FTF-900,'tension'],[FTJ+FTF+560,'aspire']],   /* le trait s'électrise, l'impact, le saut, silence du vol, le siphon */
  _dive:[[300,'aspire'],[1530,'naissance']],
  _danse:[[4200,'coeur'],[8400,'coeur']]};})();
 function vib5(L,lt,key){if(!L||!window.QHAP||!QHAP.on||EP.warm||!(EP.dt>0)||!dtD)return;L.forEach(function(q,qi){var kq=key+qi;if(lt>=q[0]&&lt<q[0]+220&&!EP.seen[kq]){EP.seen[kq]=1;QHAP.play(q[1]);}});}
 /* ═══ décors (coordonnées locales de la scène) ═══ */
 function ring5(c,x,y,r,col,al,sy){c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,al);c.lineWidth=1.4;c.beginPath();c.ellipse(x,y,r,r*(sy||1),0,0,2*PI);c.stroke();c.restore();}
 function stars5(c,now,n0){for(var n=0;n<(n0||70);n++){var x=(n*97)%360,y=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.25+.35*Math.sin(now*.004+n*1.7))*.8);c.fillRect(x,y,1.3,1.3);}}
 function drift5(c,col,now,n0,up){for(var n=0;n<(n0||30);n++){var x=(n*47+now*.01*(n%5))%360,y=up?480-((n*61+now*.04*(1+n%3))%480):(n*61+now*.04*(1+n%3))%480;c.fillStyle=rgba(col,.35+.2*Math.sin(now*.004+n));c.fillRect(x,y,1.3,1.3);}}
 var DECO={};
 DECO[11]=function(c,z,lt,A,B,now){stars5(c,now);var fl=lt>430?Math.max(0,1-(lt-430)/900):0,pre=lt<430?lt/430:0;
  var g=c.createRadialGradient(205,390,0,205,390,70);g.addColorStop(0,'rgba(155,235,75,'+(.22*(.3+pre+fl*2)).toFixed(3)+')');g.addColorStop(1,'rgba(155,235,75,0)');c.save();c.globalCompositeOperation='lighter';c.fillStyle=g;c.fillRect(120,320,170,100);c.restore();
  glowLine(c,[[150,338],[150,398],[260,398],[260,338]],'#9BEB4B',2.2,.95);
  if(lt>=430&&lt<1300){var u=(lt-430)/870;ring5(c,205,396,10+110*ease('out',u),'#9BEB4B',.8*(1-u),.32);ring5(c,205,396,6+70*ease('out',u),'#F1F4F6',.5*(1-u),.32);}};
 DECO[10]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[10],n,x,y;
  if(V&&V.qtdil){try{V.qtdil(c,[30,104,124,92],now*.06);}catch(e){}}
  if(V&&V.qsup){try{V.qsup(c,[250,225,52,50],now*.06);}catch(e){}}
  wall(c,[[172,196],[172,298]],0,col);if(V&&V.tunnel){try{V.tunnel(c,[[172,298],[172,372]],null);}catch(e){}}else glowLine(c,[[172,298],[172,372]],col,1.4,.7);
  glowLine(c,[[-10,362],[372,362]],col,1.2,.45);
  if(B&&B[0]>96&&B[0]<256){packet(c,B,now,150,195);EP.mB={al:B[0]>150&&B[0]<195?.4:.75};}
  for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(now*.002+n)*20)%480;c.fillStyle=rgba(col,.22);c.fillRect(x,y,1.2,1.2);}};
 DECO[9]=function(c,z,lt,A,B,now){var col=COL[9],x,P=[];for(x=12;x<=348;x+=4)P.push([x,strY5(x,lt)]);glowLine(c,P,col,1.8,.95);
  [[12,300],[348,300]].forEach(function(q){glowLine(c,[[q[0],q[1]-9],[q[0],q[1]+9]],col,2,.8);c.fillStyle='rgba(241,244,246,.9)';c.beginPath();c.arc(q[0],q[1],2.6,0,2*PI);c.fill();});
  drift5(c,col,now,20,true);};
 function portal5(c,x,y,now,al){var col=COL[8];c.save();c.globalCompositeOperation='lighter';for(var k=0;k<3;k++){c.strokeStyle=rgba(k?'#F1F4F6':col,(.85-.25*k)*al);c.lineWidth=2.2-.6*k;c.beginPath();c.ellipse(x,y,12+k*3+2*Math.sin(now*.01+k),34+k*4,0,0,2*PI);c.stroke();}
  var g=c.createRadialGradient(x,y,0,x,y,40);g.addColorStop(0,rgba(col,.35*al));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(x,y,40,0,2*PI);c.fill();c.restore();}
 DECO[8]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[8],n;
  if(V&&V.rift){c.save();c.globalAlpha=.8;try{V.rift(c,[P1[0],P1[1],P2[0],P2[1],70]);}catch(e){}c.restore();}
  portal5(c,P2[0],P2[1],now,1);portal5(c,P1[0],P1[1],now,1);
  wall(c,[[10,342],[256,342]],0,col);
  for(n=0;n<2;n++){var y=n?478:2;c.save();c.setLineDash([6,5]);c.lineDashOffset=now*.04*(n?1:-1);glowLine(c,[[0,y],[360,y]],col,1.2,.7);c.restore();}
  for(n=0;n<6;n++){var yy=(now*.05+n*80)%480;c.fillStyle=rgba(col,.07);c.fillRect(0,yy,360,1);}};
 DECO[7]=function(c,z,lt,A,B,now){var col=COL[7],n,cx=MG[0],cy=MG[1],Rr=94,ph=lt*.0092;
  c.save();c.globalCompositeOperation='lighter';
  /* champ magnétique : croix ⊗ dans les dees */
  for(n=0;n<46;n++){var a2=n*2.39996,r2=10+Math.sqrt(n/46)*(Rr-10),x=cx+Math.cos(a2)*r2,y=cy+Math.sin(a2)*r2;c.strokeStyle=rgba(col,.16+.08*Math.sin(now*.003+n));c.lineWidth=.8;c.beginPath();c.moveTo(x-2.2,y-2.2);c.lineTo(x+2.2,y+2.2);c.moveTo(x+2.2,y-2.2);c.lineTo(x-2.2,y+2.2);c.stroke();}
  /* les deux dees */
  [[-PI/2+.05,PI/2-.05],[PI/2+.05,3*PI/2-.05]].forEach(function(ar,i){
   c.strokeStyle=rgba(col,.1);c.lineWidth=9;c.beginPath();c.arc(cx,cy,Rr+7,ar[0],ar[1]);c.stroke();
   c.strokeStyle=rgba(col,.75);c.lineWidth=2.2;c.beginPath();c.arc(cx,cy,Rr+7,ar[0],ar[1]);c.stroke();
   c.strokeStyle=rgba('#F1F4F6',.35);c.lineWidth=.8;c.beginPath();c.arc(cx,cy,Rr+3,ar[0],ar[1]);c.stroke();});
  /* la fente : champ électrique alterné, flèches qui basculent */
  var fa=.28+.4*Math.abs(Math.cos(ph*PI)),dir=Math.cos(ph*PI)>0?1:-1;
  for(var s=-1;s<=1;s+=2){var gy0=s<0?cy-Rr-8:cy+8,gy1=s<0?cy-8:cy+Rr+8;
   c.strokeStyle=rgba('#F1F4F6',fa*.8);c.lineWidth=1;c.setLineDash([3,4]);c.lineDashOffset=-now*.03*dir;
   [-4,4].forEach(function(o){c.beginPath();c.moveTo(cx+o,gy0);c.lineTo(cx+o,gy1);c.stroke();});c.setLineDash([]);
   for(n=0;n<4;n++){var yy=gy0+(gy1-gy0)*(n+.5)/4;c.strokeStyle=rgba(col,fa);c.lineWidth=1.2;c.beginPath();c.moveTo(cx-3*dir,yy-2.5);c.lineTo(cx+3*dir,yy);c.lineTo(cx-3*dir,yy+2.5);c.stroke();}}
  /* pôles : disques aux deux faces + halo */
  var g3=c.createRadialGradient(cx,cy,0,cx,cy,Rr);g3.addColorStop(0,rgba(col,.16));g3.addColorStop(1,rgba(col,0));c.fillStyle=g3;c.beginPath();c.arc(cx,cy,Rr,0,2*PI);c.fill();
  c.restore();};
 DECO[6]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[6],n;   /* R215 : composants du jeu seulement — zone Relativité, plafond et sol en murs du jeu */
  if(V&&V.gzone){try{V.gzone(c,[ZG[0],34,ZG[1]-ZG[0],300,0,-1]);}catch(e){}}
  c.save();c.globalCompositeOperation='lighter';
  for(n=0;n<30;n++){var x=ZG[0]+8+((n*37)%(ZG[1]-ZG[0]-16)),ph3=((now*(.00012+(n%4)*.00004)+n*.173)%1),y=334-296*Math.pow(ph3,1.5);c.fillStyle=rgba(col,.1+.5*Math.sin(ph3*PI));c.fillRect(x,y,1.6,5+4*ph3);}
  c.restore();
  wall(c,[[ZG[0]-10,36],[ZG[1]+10,36]],0,col);wall(c,[[-10,162],[ZG[0],162]],0,col);};
 DECO[5]=function(c,z,lt,A,B,now){var col=COL[5],n;
  HP5.forEach(function(h,hi){var near=0;[A,B].forEach(function(P){if(P)near=Math.max(near,cl(1-Math.hypot(P[0]-h[0],P[1]-h[1])/38));});var pr=cl((lt-(z.thr&&z.thr[0]!=null?z.thr[0]:1e9)+200)/500);
   c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba('#FFE9A8',(.12+.75*near)*pr);c.lineWidth=1.4+2*near;c.beginPath();c.arc(h[0],h[1],11+4*near,0,2*PI);c.stroke();c.strokeStyle=rgba(col,(.1+.4*near)*pr);c.lineWidth=1;c.beginPath();c.arc(h[0],h[1],17+9*near+2*Math.sin(now*.004+hi),0,2*PI);c.stroke();
   if(near>.05){var hg2=c.createRadialGradient(h[0],h[1],0,h[0],h[1],30);hg2.addColorStop(0,rgba('#FFE9A8',.35*near));hg2.addColorStop(1,rgba(col,0));c.fillStyle=hg2;c.fillRect(h[0]-30,h[1]-30,60,60);}c.restore();});
  var hs=hitSum(z,lt,260)*.6;gear(c,300,384,42,now*.002+hs,col,.35+.1*Math.min(1,hs));gear(c,70,150,28,-now*.003-hs*1.5,col,.3+.1*Math.min(1,hs));gear(c,206,86,20,now*.004+hs*2.2,col,.3+.1*Math.min(1,hs));
  for(n=0;n<5;n++){var rq=(z.rise&&z.rise[n])?z.rise[n]:[0,1],xx=cl((lt-rq[0])/rq[1]),ov=n===0?4.5:1.1,rise=xx>=1?1:(xx<=0?0:1+(ov+1)*Math.pow(xx-1,3)+ov*Math.pow(xx-1,2)),mv=xx>0&&xx<1?Math.sin(xx*PI):0,mv=xx>0&&xx<1?Math.sin(xx*PI):0,yy=STY[n]+(1-rise)*(BASE5-STY[n]),thr=0,tq=-1;if(n===0&&z.thr)z.thr.forEach(function(th){if(th!=null){var t2=lt-(th-70);if(t2>0){tq=Math.max(tq,t2);thr=Math.max(thr,96*(1-Math.exp(-t2/48))*Math.exp(-Math.max(0,t2-260)/520));}}});yy-=thr;if(n===0&&tq>0){var pyM=-1e9;[A,B].forEach(function(P){if(P&&P[0]>STX[0]-14&&P[0]<STX[0]+64)pyM=Math.max(pyM,P[1]);});if(pyM>-1e9&&yy<pyM+11)yy=pyM+11;}   /* R218 : la marche pousse, elle ne passe jamais au-dessus des particules */
   var hg=hitGlow(z,STX[n]-8,STX[n]+58,lt,320);if(window.VX&&VX.curve){try{VX.curve(c,[[STX[n],yy+62],[STX[n],yy+3],[STX[n]+3,yy],[STX[n]+50,yy]],0,{noHang:1,accent:[224,178,76]});}catch(e){}}else glowLine(c,[[STX[n],yy],[STX[n]+50,yy]],col,2.2,1);if(hg>.05)glowLine(c,[[STX[n],yy],[STX[n]+50,yy]],'#FFE9A8',1+1.8*hg,hg);if(hg>.05){c.save();c.globalCompositeOperation='lighter';var sg=c.createRadialGradient(STX[n]+25,yy,0,STX[n]+25,yy,46);sg.addColorStop(0,rgba('#FFE9A8',.3*hg));sg.addColorStop(1,rgba(col,0));c.fillStyle=sg;c.fillRect(STX[n]-30,yy-46,110,92);c.restore();}[STX[n]+19,STX[n]+31].forEach(function(rx){glowLine(c,[[rx,yy+3],[rx,480]],col,.8,.32);});glowLine(c,[[STX[n]+13,yy+90],[STX[n]+37,yy+90]],col,1.2,.4*rise);
   if(mv>.05){c.save();c.globalCompositeOperation='lighter';for(var q=0;q<7;q++){var qx=STX[n]+4+((q*13+n*5)%46),qy=yy+8+((now*.09*(1+q%3)+q*29)%60);c.fillStyle=rgba('#FFE9A8',.5*mv*(1-(qy-yy)/70));c.fillRect(qx,qy,1.4,1.4);}c.restore();}
   if(n===0&&tq>0&&tq<900){var f9=tq/900;c.save();c.globalCompositeOperation='lighter';var bg=c.createLinearGradient(0,yy,0,yy-150);bg.addColorStop(0,rgba('#FFE9A8',.45*(1-f9)));bg.addColorStop(1,rgba(col,0));c.fillStyle=bg;c.fillRect(STX[0]+6,yy-150,38,150);c.strokeStyle=rgba('#FFF2C4',.8*(1-f9));c.lineWidth=2;c.beginPath();c.ellipse(STX[0]+25,yy,10+26*f9,3+7*f9,0,0,2*PI);c.stroke();c.strokeStyle=rgba(col,.6*(1-f9));c.beginPath();c.ellipse(STX[0]+25,yy,6+40*f9,2+10*f9,0,0,2*PI);c.stroke();for(var q2=0;q2<12;q2++){var qa=(q2-5.5)*.22,qd=f9*90*(1+q2%3*.3);c.fillStyle=rgba('#FFE9A8',.8*(1-f9));c.fillRect(STX[0]+25-Math.sin(qa)*qd*.6-1,yy-Math.cos(qa)*qd*1.3-1,2,2);}c.restore();}}};
 DECO[4]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[4],n,act=0;
  [A,B].forEach(function(P){if(P){var d=Math.hypot(P[0]-VC[0],P[1]-VC[1]);act=Math.max(act,1-cl((d-40)/90));}});
  if(V&&V.updraft)V.updraft(c,[150,60,100,430]);else{c.fillStyle=rgba(col,.08);c.fillRect(150,60,100,430);}
  if(V&&V.vortex){try{V.vortex(c,[VC[0],VC[1],74,1]);if(act>0){c.save();c.globalAlpha=act;V.vortex(c,[VC[0],VC[1],52,1]);V.vortex(c,[VC[0],VC[1],92,1]);c.restore();}}catch(e){}}else spiral(c,VC[0],VC[1],74,.6,now*.01,[col]);
  c.save();c.globalCompositeOperation='lighter';
  var g=c.createRadialGradient(VC[0],VC[1],0,VC[0],VC[1],110);g.addColorStop(0,'rgba(214,236,255,'+(.05+.2*act).toFixed(3)+')');g.addColorStop(1,'rgba(168,200,232,0)');c.fillStyle=g;c.fillRect(VC[0]-110,VC[1]-110,220,220);
  for(n=0;n<3;n++){var rp=((now*.0009*(1+act*1.5)+n/3)%1);c.strokeStyle='rgba(214,236,255,'+((1-rp)*(.12+.3*act)).toFixed(3)+')';c.lineWidth=1;c.beginPath();c.ellipse(VC[0],VC[1],20+rp*90,20+rp*90,0,0,2*PI);c.stroke();}
  c.restore();
  wall(c,[[196,410],[372,410]],0,col);
  for(n=0;n<18;n++){var y=(n*31+now*.3)%480,x=160+(n*17)%80;c.strokeStyle=rgba(col,.35);c.beginPath();c.moveTo(x,480-y);c.lineTo(x,480-y-14);c.stroke();}};

 DECO[3]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[3],n,k,i,cx=GLC[0],cy=GLC[1];   /* R216 : le cyclone de glace au cœur d'une seule boucle, rail de glace du jeu */
  var act=0;[A,B].forEach(function(P){if(P){var dd=Math.hypot(P[0]-cx,P[1]-cy);act=Math.max(act,cl(1-(dd-GLR)/90));}});
  c.save();c.globalCompositeOperation='lighter';
  var gi=c.createRadialGradient(cx,cy,0,cx,cy,GLR+40);gi.addColorStop(0,'rgba(200,244,255,'+(.12+.22*act).toFixed(3)+')');gi.addColorStop(1,'rgba(143,227,255,0)');c.fillStyle=gi;c.beginPath();c.arc(cx,cy,GLR+40,0,2*PI);c.fill();
  var sp=now*.0007*(1+4*act);
  for(k=0;k<5;k++){c.beginPath();for(n=0;n<=48;n++){var r=4+n*1.18,th=k*2*PI/5+n*.075-sp,px=cx+Math.cos(th)*r,py=cy+Math.sin(th)*r;n?c.lineTo(px,py):c.moveTo(px,py);}
   c.strokeStyle=rgba(col,.16+.3*act);c.lineWidth=1;c.stroke();
   for(n=4;n<=48;n+=5){var r2=4+n*1.18,t2=k*2*PI/5+n*.075-sp;c.fillStyle=rgba('#F1F4F6',.3+.5*act+.15*Math.sin(now*.004+n+k));c.save();c.translate(cx+Math.cos(t2)*r2,cy+Math.sin(t2)*r2);c.rotate(t2+PI/4);c.fillRect(-1.6,-1.6,3.2,3.2);c.restore();}}
  c.restore();
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';   /* R218 : rafales de givre en orbite autour du cyclone ; elles s'emballent quand le couple entre dans la boucle */
  for(n=0;n<34;n++){var rr=GLR+12+((n*53)%230),fr=(rr-GLR)/240,om=(.0006+.0011*(1-fr))*(1+1.8*act),th3=n*2.399+now*om*(n%6===0?-1:1),ln3=(.22+.3*((n*7)%4)/3)*(1-.5*fr),fa=(.32+.42*act)*(1-.75*fr)*(.6+.4*Math.sin(now*.0025+n*1.3));
   if(fa<.03)continue;for(k=0;k<3;k++){c.strokeStyle=rgba(n%4?'#EAF8FF':col,fa*(1-k*.32));c.lineWidth=(1.5-k*.4)*(1-.4*fr)+.3;c.beginPath();c.arc(cx,cy,rr,th3-ln3*(k+1)/3*(n%6===0?-1:1),th3-ln3*k/3*(n%6===0?-1:1),n%6===0);c.stroke();}
   c.fillStyle=rgba('#FFFFFF',fa);c.beginPath();c.arc(cx+Math.cos(th3)*rr,cy+Math.sin(th3)*rr,1.1,0,2*PI);c.fill();}
  var rp=(now*.0012)%1;c.strokeStyle=rgba('#EAF8FF',(.12+.3*act)*(1-rp));c.lineWidth=1.2;c.beginPath();c.arc(cx,cy,GLR*(1+.7*rp),0,2*PI);c.stroke();
  var rp2=(now*.0012+.5)%1;c.strokeStyle=rgba(col,(.08+.22*act)*(1-rp2));c.beginPath();c.arc(cx,cy,GLR*(1+.7*rp2),0,2*PI);c.stroke();
  c.restore();
  var vis=GD.filter(function(q){return q[0]<=404;});
  if(V&&V.curve){try{V.curve(c,vis,4,{noHang:1});}catch(e){glowLine(c,vis,col,2,.9);}}else glowLine(c,vis,col,2,.9);
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';   /* givre derrière chaque particule */
  [A,B].forEach(function(P,pi){if(!P)return;var j0=0,j,bestd=1e9;for(j=0;j<GD.length;j++){var dd=Math.hypot(GD[j][0]-P[0],GD[j][1]-P[1]);if(dd<bestd){bestd=dd;j0=j;}}
   if(bestd>16)return;for(j=j0;j>Math.max(1,j0-26);j--){var f=1-(j0-j)/26;c.strokeStyle=rgba(pi?'#C6B5FF':'#EAF8FF',.6*f*f);c.lineWidth=1+4*f;c.beginPath();c.moveTo(GD[j][0],GD[j][1]);c.lineTo(GD[j-1][0],GD[j-1][1]);c.stroke();}});
  c.restore();};
 DECO[2]=function(c,z,lt,A,B,now){var col=COL[2],n,ring=[];
  wall(c,[[-14,94],[118,242]],3,col);for(n=0;n<=48;n++){var a=n/48*2*PI;ring.push([LP[0]+Math.cos(a)*(LR+R+3),LP[1]+Math.sin(a)*(LR+R+3)]);}
  wall(c,ring,3,col);(function(){var bp=[];for(var x=180;x<=420;x+=8)bp.push([x,BF(x)+12]);wall(c,bp,3,col);})();
  for(n=0;n<14;n++){var x=372-((n*26+now*.25)%390);c.strokeStyle=rgba(col,.5);c.lineWidth=1;c.beginPath();c.moveTo(x,BF(x)+24);c.lineTo(x+6,BF(x+6)+24);c.stroke();}
  (function(){var act=0;[A,B].forEach(function(P){if(P&&P[0]>200&&P[0]<430)act=1;});
   /* accélérateur : arcs électriques le long du tapis, spirale d'énergie autour de chaque bille qui s'y engage */
   c.save();c.globalCompositeOperation='lighter';c.lineJoin='round';
   [0,1].forEach(function(li){c.strokeStyle=rgba(li?'#FFFFFF':'#A878FF',(li?.6:.55)*(.3+.7*act));c.lineWidth=li?.8:1.8;c.beginPath();
    for(var x=430,i=0;x>=190;x-=6,i++){var jj=Math.sin(now*.05+i*2.3+li*1.9)*(3+3*act)*(i%2?1:-1),yy=BF(x)-8+jj;i?c.lineTo(x,yy):c.moveTo(x,yy);}c.stroke();});
   [A,B].forEach(function(P,pi){if(!P||P[0]<200||P[0]>430)return;var m=(BF(P[0]+2)-BF(P[0]-2))/4,an=Math.atan(m);
    for(var q=0;q<3;q++){var ph=now*.02*(q%2?-1:1);c.strokeStyle=rgba(pi?'#C6B5FF':'#FFE9A8',.55-q*.14);c.lineWidth=1.4;c.beginPath();c.ellipse(P[0]+q*5,P[1]+q*5*m,11+q*2,4.5+q,an,ph,ph+PI*1.4);c.stroke();}});
   c.restore();
   /* décor : pylône à bobine, ses arcs rejoignent le tapis quand on passe */
   var px=88,top=292;c.save();c.strokeStyle=rgba(col,.38);c.lineWidth=1.3;c.lineCap='round';
   c.beginPath();c.moveTo(px-20,480);c.lineTo(px-3,top);c.moveTo(px+20,480);c.lineTo(px+3,top);c.stroke();
   for(var yy2=top+18;yy2<478;yy2+=26){var hw=3+(yy2-top)/(480-top)*17;c.beginPath();c.moveTo(px-hw,yy2);c.lineTo(px+hw,yy2);c.moveTo(px-hw,yy2);c.lineTo(px+hw*.5+1,yy2+16);c.stroke();}
   c.lineWidth=2;c.beginPath();c.moveTo(px-24,top+6);c.lineTo(px+24,top+6);c.moveTo(px-14,top+22);c.lineTo(px+14,top+22);c.stroke();
   [[-24,top+6],[24,top+6],[-14,top+22],[14,top+22]].forEach(function(q){c.fillStyle=rgba('#E4D8FF',.7);c.fillRect(px+q[0]-1.5,q[1]-4,3,6);});
   c.globalCompositeOperation='lighter';var pg=c.createRadialGradient(px,top-4,0,px,top-4,34);pg.addColorStop(0,rgba('#C6B5FF',.3+.4*act));pg.addColorStop(1,rgba(col,0));c.fillStyle=pg;c.fillRect(px-34,top-38,68,68);
   c.fillStyle=rgba('#FFFFFF',.8);c.beginPath();c.arc(px,top-4,3.2,0,2*PI);c.fill();
   if(act){c.strokeStyle=rgba('#E4D8FF',.5+.3*Math.sin(now*.05));c.lineWidth=1;c.beginPath();c.moveTo(px,top-4);for(var k2=1;k2<=10;k2++){var u2=k2/10,tx2=px+(300-px)*u2,ty2=top-4+(BF(300)-8-top+4)*u2-Math.sin(u2*PI)*70;c.lineTo(tx2+Math.sin(now*.06+k2*3.1)*5,ty2+Math.cos(now*.05+k2*2.3)*4);}c.stroke();}
   c.restore();})();
  [A,B].forEach(function(P,i){if(!P)return;var d=Math.hypot(P[0]-LP[0],P[1]-LP[1]);if(Math.abs(d-LR)>16)return;var v=vel5(z,i,lt);if(!v)return;var sp=Math.hypot(v[0],v[1])/28;if(sp<.2)return;var ux=v[0]/(sp*28),uy=v[1]/(sp*28),L=60+130*Math.min(1,sp),gr=c.createLinearGradient(P[0],P[1],P[0]+ux*L,P[1]+uy*L);
   gr.addColorStop(0,'rgba(255,255,255,.9)');gr.addColorStop(.35,rgba('#A878FF',.55));gr.addColorStop(1,rgba('#4DD7FF',0));c.save();c.globalCompositeOperation='lighter';c.strokeStyle=gr;c.lineWidth=2.4;c.lineCap='round';c.beginPath();c.moveTo(P[0],P[1]);c.lineTo(P[0]+ux*L,P[1]+uy*L);c.stroke();c.lineWidth=7;c.globalAlpha=.25;c.stroke();c.restore();});};
 DECO[1]=function(c,z,lt,A,B,now){var col=COL[1],n,k,H=(z.hitsA||[]).concat(z.hitsB||[]),smf=function(v){v=cl(v);return v*v*(3-2*v);},YB=452,xq,fq,ps=[A,B].filter(Boolean);
  var wyf=function(x){return YB+Math.sin(x*.05+now*.003)*3+Math.sin(x*.13-now*.002)*1.6;};
  /* chaleur : voile orangé au ras du bain */
  c.save();c.globalCompositeOperation='lighter';
  for(xq=-24;xq<384;xq+=6){fq=smf((xq+14)/70)*smf((374-xq)/70);if(fq<.02)continue;
   [[392,64,.035],[410,48,.05],[426,34,.06],[438,22,.07]].forEach(function(q){c.fillStyle=rgba('#FF6A2A',q[2]*fq*(.85+.3*Math.sin(now*.003)));c.fillRect(xq,q[0],6.5,q[1]);});}
  c.restore();
  /* le bain : croûte sombre, veines incandescentes, bulles qui éclatent */
  c.save();var lg=c.createLinearGradient(0,YB-4,0,YB+36);lg.addColorStop(0,'#FF9A4A');lg.addColorStop(.18,'#E8421E');lg.addColorStop(.6,'#7A1410');lg.addColorStop(1,'#2A0808');
  for(xq=-24;xq<384;xq+=5){fq=smf((xq+14)/60)*smf((374-xq)/60);if(fq<.02)continue;var wy=wyf(xq);c.globalAlpha=.92*fq;c.fillStyle=lg;c.fillRect(xq,wy,5.5,36);}
  c.globalAlpha=1;c.globalCompositeOperation='lighter';
  for(k=0;k<3;k++){c.beginPath();var onl=false;for(xq=-24;xq<384;xq+=5){fq=smf((xq+14)/60)*smf((374-xq)/60);var vy=wyf(xq)+7+k*8+Math.sin(xq*.09+now*.0016*(k+1)+k*2)*2.4;if(fq<.05){onl=false;continue;}if(!onl){c.moveTo(xq,vy);onl=true;}else c.lineTo(xq,vy);}
   c.strokeStyle=rgba(k?'#FF7A2A':'#FFD08A',.4-k*.08);c.lineWidth=1.3-k*.3;c.stroke();}
  c.strokeStyle=rgba('#FFE0A8',.85);c.lineWidth=1.5;c.beginPath();onl=false;for(xq=-24;xq<384;xq+=5){fq=smf((xq+14)/60)*smf((374-xq)/60);if(fq<.05){onl=false;continue;}if(!onl){c.moveTo(xq,wyf(xq));onl=true;}else c.lineTo(xq,wyf(xq));}c.stroke();
  for(n=0;n<12;n++){var bx=14+((n*71)%340),ph=((now*.0005+n*.41)%1),bw=wyf(bx);if(smf((bx+14)/60)*smf((374-bx)/60)<.3)continue;
   if(ph<.78){var br=1+4.5*ph/.78;c.strokeStyle=rgba('#FFC070',.7);c.lineWidth=1;c.fillStyle=rgba('#FF6A2A',.25);c.beginPath();c.arc(bx,bw+5-br*.5,br,0,2*PI);c.fill();c.stroke();}
   else{var pe=(ph-.78)/.22;c.strokeStyle=rgba('#FFE0A8',.6*(1-pe));c.beginPath();c.arc(bx,bw+3,5+10*pe,PI,2*PI);c.stroke();for(var e=0;e<4;e++){c.fillStyle=rgba('#FFD85A',.8*(1-pe));c.fillRect(bx+(e-1.5)*6*pe,bw-12*pe*(1+e%2)+10*pe*pe-2,1.6,1.6);}}}
  c.restore();
  /* R216 : pointes du jeu (matière pointes) au ras du bain ; plaques = murs rebond du jeu, chauffés au choc */
  if(window.VX&&VX.spikes){try{VX.spikes(c,[-24,446,384,446,2]);}catch(e){}}else wall(c,[[-24,446],[384,446]],2,'#FF5252');
  PLT.forEach(function(q){var hg=hitGlow(z,q[0]-10,q[1]+10,lt,460),x0=q[0]+4,x1=q[1]-4,sd=(q[4]||1)*11,y0=q[2]+sd,y1=q[3]+sd;
   c.save();c.globalCompositeOperation='lighter';var pg=c.createRadialGradient((x0+x1)/2,(y0+y1)/2,0,(x0+x1)/2,(y0+y1)/2,70+40*hg);pg.addColorStop(0,rgba('#FFB060',.12+.42*hg));pg.addColorStop(1,rgba('#FF5252',0));c.fillStyle=pg;c.fillRect((x0+x1)/2-110,(y0+y1)/2-110,220,220);c.restore();
   wall(c,[[x0,y0],[x1,y1]],1,col);if(hg>.05)glowLine(c,[[x0,y0],[x1,y1]],'#FFE8C0',1.2+2*hg,hg);});
  /* étincelles aux chocs */
  c.save();c.globalCompositeOperation='lighter';
  H.forEach(function(h){var ag=lt-h.t;if(ag<0||ag>800)return;var as=ag/1000;for(var e=0;e<12;e++){var an=-PI*(.08+.84*e/11)+((e*7)%3-1)*.12,sp=70+((e*37)%5)*22,sx=h.x+Math.cos(an)*sp*as,sy=h.y+11+Math.sin(an)*sp*as+.5*420*as*as;c.fillStyle=rgba(e%3?'#FFB060':'#FFE8B0',.9*(1-ag/800));c.fillRect(sx-1,sy-1,2,2);}});
  c.restore();
  for(n=0;n<30;n++){var x3=(n*53+now*.012*(1+n%3))%360,y3=470-((now*.06*(1+n%4)+n*37)%470);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.55*(1-y3/480)+.1);c.fillRect(x3,y3,1.6,1.6);}};
 /* R226 · aura d'énergie de la pointe (le doigt du joueur) : langues de plasma rejetées vers l'arrière, cœur blanc, halo cyan-violet
    qui pulse, anneau de choc, étincelles qui ruissellent le long du trait */
 function kiAura(c,tip,seg,e,now,hot){var k,b=seg[Math.min(8,seg.length-1)],ang=Math.atan2(b[1]-tip[1],b[0]-tip[0]),fl=.85+.15*Math.sin(now*.05)+.08*Math.random();
  c.save();c.globalCompositeOperation='lighter';
  var R3=(30+70*e)*fl,g3=c.createRadialGradient(tip[0],tip[1],0,tip[0],tip[1],R3);g3.addColorStop(0,hot?'rgba(255,200,220,.35)':'rgba(190,240,255,.35)');g3.addColorStop(.45,rgba(hot?'#FF6A9A':'#A878FF',.16+.12*e));g3.addColorStop(1,'rgba(120,80,255,0)');c.fillStyle=g3;c.beginPath();c.arc(tip[0],tip[1],R3,0,2*PI);c.fill();
  for(k=0;k<9;k++){var a=ang+(k-4)*.2+(Math.random()-.5)*.15,L=(16+60*e)*(.55+.45*Math.random())*(1-Math.abs(k-4)*.08),wd=(4+7*e)*(1-Math.abs(k-4)*.1),ex=tip[0]+Math.cos(a)*L,ey=tip[1]+Math.sin(a)*L,nx=-Math.sin(a)*wd,ny=Math.cos(a)*wd;
   var lg=c.createLinearGradient(tip[0],tip[1],ex,ey);lg.addColorStop(0,'rgba(255,255,255,'+(.55*e+.2).toFixed(3)+')');lg.addColorStop(.35,rgba(hot?'#FF8AB0':'#6EE2FF',.35*e+.12));lg.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=lg;
   c.beginPath();c.moveTo(tip[0]+nx*.4,tip[1]+ny*.4);c.quadraticCurveTo(tip[0]+Math.cos(a)*L*.45+nx,tip[1]+Math.sin(a)*L*.45+ny,ex,ey);c.quadraticCurveTo(tip[0]+Math.cos(a)*L*.45-nx,tip[1]+Math.sin(a)*L*.45-ny,tip[0]-nx*.4,tip[1]-ny*.4);c.closePath();c.fill();}
  var rc=(5+7*e)*fl,g4=c.createRadialGradient(tip[0],tip[1],0,tip[0],tip[1],rc);g4.addColorStop(0,'rgba(255,255,255,1)');g4.addColorStop(.6,'rgba(230,250,255,.6)');g4.addColorStop(1,'rgba(200,240,255,0)');c.fillStyle=g4;c.beginPath();c.arc(tip[0],tip[1],rc,0,2*PI);c.fill();
  var rp=(now*.0025)%1;c.strokeStyle='rgba(230,250,255,'+(.4*e*(1-rp)).toFixed(3)+')';c.lineWidth=1.2;c.beginPath();c.arc(tip[0],tip[1],8+40*e*rp,0,2*PI);c.stroke();
  for(k=0;k<12;k++){var ph=((now*.0016)+k/12)%1,idx=Math.min(seg.length-1,Math.floor(ph*Math.min(60,seg.length-1))),q=seg[idx],jx=Math.sin(k*7.3+now*.01)*5*e,jy=Math.cos(k*5.1+now*.012)*5*e;c.fillStyle=rgba(k%3?'#E6FAFF':'#A878FF',(.7*(1-ph)*e).toFixed?.7*(1-ph)*e:0);c.fillRect(q[0]+jx-.9,q[1]+jy-.9,1.8,1.8);}
  c.restore();}
 function hh5(n){var v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);}
 /* R224 · zone interdite « cinéma » : un vide profond derrière une membrane d'énergie — paires virtuelles qui naissent et s'annihilent,
    nébuleuse qui respire, grain qui dérive, impulsions qui courent sur la membrane, coins repères ; à l'impact, la membrane frémit
    dans les deux sens et des ondes se propagent dans le vide. */
 function zoneFX(c,r,now,hot,imp,ri){var x=r[0],y=r[1],w=r[2],h=r[3],P=2*(w+h),k,i;   /* R225 : sobre — un voile, un liseré, un vide qui frémit à peine */
  function per(sv){sv=((sv%P)+P)%P;if(sv<w)return [x+sv,y];sv-=w;if(sv<h)return [x+w,y+sv];sv-=h;if(sv<w)return [x+w-sv,y+h];sv-=w;return [x,y+h-sv];}
  c.save();var ig=c.createLinearGradient(x,y,x,y+h);var hf=r[4]?.35:1;ig.addColorStop(0,'rgba(255,90,130,'+((.025+.05*hot)*hf).toFixed(3)+')');ig.addColorStop(1,'rgba(255,90,130,'+((.07+.08*hot)*hf).toFixed(3)+')');c.fillStyle=ig;c.fillRect(x,y,w,h);
  c.beginPath();c.rect(x,y,w,h);c.clip();c.globalCompositeOperation='lighter';
  if(r[4]){var NP=11;for(i=0;i<NP;i++){var b1=hh5(i*3.7+5),b2=hh5(i*9.1+2),b3=hh5(i*4.3+8),T0=3200+b3*1800,ph2=((now/T0)+b1*3)%1,bx=x+18+b1*(w-36),by=y+18+b2*(h-36),aa=b3*6.283+i;   /* R226 : comètes matière / antimatière qui errent, se retrouvent et s'annihilent */
    if(ph2<.72){var tl,ki;for(var cmt=0;cmt<2;cmt++){c.beginPath();for(ki=0;ki<14;ki++){tl=Math.max(0,ph2-ki*.014)/.72;var sp2=Math.sin(PI*tl),rr2=(22+38*b2)*sp2,an3=aa+(cmt?PI:0)+(cmt?-1:1)*tl*1.6,qx=bx+Math.cos(an3)*rr2+Math.sin(tl*9+i)*2,qy=by+Math.sin(an3)*rr2*.8;ki?c.lineTo(qx,qy):c.moveTo(qx,qy);}
      c.strokeStyle=cmt?'rgba(120,226,255,'+(.45*(.35+.65*hot)).toFixed(3)+')':'rgba(255,110,150,'+(.45*(.35+.65*hot)).toFixed(3)+')';c.lineWidth=1.7;c.lineCap='round';c.stroke();
      tl=ph2/.72;var sp3=Math.sin(PI*tl),hx=bx+Math.cos(aa+(cmt?PI:0)+(cmt?-1:1)*tl*1.6)*(22+38*b2)*sp3,hy=by+Math.sin(aa+(cmt?PI:0)+(cmt?-1:1)*tl*1.6)*(22+38*b2)*sp3*.8;var hg2=c.createRadialGradient(hx,hy,0,hx,hy,6);hg2.addColorStop(0,cmt?'rgba(220,250,255,.95)':'rgba(255,225,235,.95)');hg2.addColorStop(1,cmt?'rgba(80,200,255,0)':'rgba(255,90,140,0)');c.fillStyle=hg2;c.fillRect(hx-6,hy-6,12,12);}}
    else if(ph2<.8){var fq=(ph2-.72)/.08,gq=c.createRadialGradient(bx,by,0,bx,by,18);gq.addColorStop(0,'rgba(255,255,255,'+(.9*(1-fq)).toFixed(3)+')');gq.addColorStop(1,'rgba(255,160,200,0)');c.fillStyle=gq;c.fillRect(bx-18,by-18,36,36);
     c.strokeStyle='rgba(235,245,255,'+(.7*(1-fq)).toFixed(3)+')';c.lineWidth=.7;for(var ar=0;ar<4;ar++){var a4=ar*1.57+b1*3,px4=bx,py4=by;c.beginPath();c.moveTo(px4,py4);for(var st4=0;st4<3;st4++){a4+=(hh5(i+ar*3+st4)-.5)*1.2;px4+=Math.cos(a4)*3.2;py4+=Math.sin(a4)*3.2;c.lineTo(px4,py4);}c.stroke();}
     c.strokeStyle='rgba(255,200,220,'+(.5*(1-fq)).toFixed(3)+')';c.beginPath();c.arc(bx,by,3+22*fq,0,2*PI);c.stroke();}
    else{var dq=(ph2-.8)/.2;for(var gr2=0;gr2<7;gr2++){var a5=gr2*.9+dq*4+b1*6,r5=(9*(1-dq))*(.5+hh5(gr2+i)*.5);c.fillStyle='rgba(255,'+(200+gr2*7)+',230,'+(.6*(1-dq)).toFixed(3)+')';c.fillRect(bx+Math.cos(a5)*r5-.6,by+Math.sin(a5)*r5-.6,1.2,1.2);}}}}
  var N=r[4]?0:Math.max(3,Math.round(w*h/1100));for(i=0;i<N;i++){var a1=hh5(ri*97+i*1.3),a2=hh5(ri*31+i*2.7),a3=hh5(ri*13+i*5.1),px=x+6+a1*(w-12),py=y+6+a2*(h-12),ph=(now*.00045*(.6+a3)+a3*7)%1;
   if(ph<.8){var sn=Math.sin(PI*ph/.8),an=a3*20+ph,d=(1.5+4*a3)*sn,al=.35*sn*(.6+.4*hot);c.fillStyle='rgba(255,120,150,'+al.toFixed(3)+')';c.fillRect(px+Math.cos(an)*d-.6,py+Math.sin(an)*d-.6,1.2,1.2);c.fillStyle='rgba(150,220,255,'+al.toFixed(3)+')';c.fillRect(px-Math.cos(an)*d-.6,py-Math.sin(an)*d-.6,1.2,1.2);}}
  if(imp&&imp.t<1800){for(k=0;k<2;k++){var tq=imp.t-k*260;if(tq<0)continue;var pr=tq/1500;if(pr>1)continue;c.strokeStyle='rgba(255,226,236,'+(.35*(1-pr)*(1-pr)).toFixed(3)+')';c.lineWidth=1;c.beginPath();c.arc(imp.x,imp.y,4+pr*Math.max(w,h)*1.05,0,2*PI);c.stroke();}
   var lg=c.createRadialGradient(imp.x,imp.y,0,imp.x,imp.y,110);lg.addColorStop(0,'rgba(255,210,226,'+(.22*Math.max(0,1-imp.t/1200)).toFixed(3)+')');lg.addColorStop(1,'rgba(255,90,130,0)');c.fillStyle=lg;c.fillRect(x,y,w,h);}
  c.restore();
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  c.strokeStyle='rgba(255,90,130,'+(.035+.05*hot).toFixed(3)+')';c.lineWidth=7;c.strokeRect(x,y,w,h);
  c.strokeStyle='rgba(255,170,195,'+(.32+.35*hot).toFixed(3)+')';c.lineWidth=.8;c.strokeRect(x+.5,y+.5,w-1,h-1);
  var sv=now*.03+ri*170,L=Math.min(60,P/6);for(k=0;k<12;k++){var a=per(sv-L*k/12),b=per(sv-L*(k+1)/12);if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])>L)continue;c.strokeStyle='rgba(255,236,244,'+((.4+.4*hot)*(1-k/12)).toFixed(3)+')';c.lineWidth=1.1;c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke();}
  if(imp&&imp.t<1100){var s0i=w+(imp.y-y),pf=ease('out',imp.t/1100);[1,-1].forEach(function(sg){var sv2=s0i+sg*pf*P*.5;for(k=0;k<14;k++){var a=per(sv2-sg*k*3),b=per(sv2-sg*(k+1)*3);c.strokeStyle='rgba(255,255,255,'+(.8*(1-pf)*(1-k/14)).toFixed(3)+')';c.lineWidth=1.6;c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke();}});}
  c.restore();}
 DECO[0]=function(c,z,lt,A,B,now){var V=window.VX,col=COL[0],n,i,xt=xTip(lt),tin=tTip(FZX),tk=lt/16;
  /* 1 · zones interdites du jeu (rendu « vide quantique »), avec une aura qui respire ; la dernière s'éveille quand le trait approche */
  var near=cl(1-(xt-FZX)/260),tin0=tTip(FZX),imp=lt>tin0?{t:lt-tin0,x:FZX,y:TY(FZX)}:null;
  ZN.forEach(function(r,ri){zoneFX(c,r,now,r[4]?Math.max(near,imp&&imp.t<1400?1-imp.t/1400:0):0,r[4]?imp:null,ri);});
  /* 2 · le trait : se trace d'abord sous les particules puis les devance ; il s'électrise en accélérant */
  var cf=lt>FTJ+80?FR1+(lt-FTJ-80)*.75:-1e9;   /* après le saut, il se délite du tremplin vers l'arrière */
  var seg=[],zs=[],dust=[];TRP.forEach(function(q){if(q[0]<xt)return;if(q[0]<FZX){zs.push(q);return;}if(q[0]>cf)seg.push(q);else dust.push(q);});
  if(seg.length>1){if(V&&V.stroke)V.stroke(c,seg,0,1);else glowLine(c,seg,col,2.4,1);
   if(lt<tin){var tip=seg[0],eT=Math.pow(cl((FX0-tip[0])/(FX0-FZX)),1.15);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
    var m=Math.min(seg.length,70);for(var ly=0;ly<2;ly++){c.beginPath();for(n=0;n<m;n++){var q=seg[n],q2=seg[Math.min(seg.length-1,n+1)],q1=seg[Math.max(0,n-1)],tx2=q2[0]-q1[0],ty2=q2[1]-q1[1],tl=Math.hypot(tx2,ty2)||1,e=eT*(1-n/m),jt=(Math.random()-.5)*2*(1.5+7*e)*e;
      var px=q[0]-ty2/tl*jt,py=q[1]+tx2/tl*jt;n?c.lineTo(px,py):c.moveTo(px,py);}c.strokeStyle=ly?'rgba(241,244,246,'+(.3+.6*eT).toFixed(3)+')':rgba('#A878FF',.15+.45*eT);c.lineWidth=ly?.9+1.2*eT:3+5*eT;c.stroke();}
    var na=Math.round(1+6*eT);for(n=0;n<na;n++){if(Math.random()>eT*1.1+.1)continue;var an=PI+(Math.random()-.5)*2.6,L2=10+50*eT*Math.random(),x2=tip[0],y2=tip[1];   /* la pointe — le bout du doigt — émet l'énergie */
     c.strokeStyle=Math.random()<.6?'rgba(241,244,246,'+(.35+.55*eT).toFixed(3)+')':rgba('#A878FF',.4+.5*eT);c.lineWidth=.7+1.3*eT;c.beginPath();c.moveTo(x2,y2);for(var s3=0;s3<6;s3++){an+=(Math.random()-.5)*1.1;x2+=Math.cos(an)*L2/6;y2+=Math.sin(an)*L2/6;c.lineTo(x2,y2);}c.stroke();}
    kiAura(c,tip,seg,eT,now);
    c.restore();if(eT>.25&&Math.random()<eT*.5)burst(z.x0+tip[0],tip[1],Math.random()<.5?'#F1F4F6':'#A878FF',2,1.4+eT);}}
  if(lt>=tin&&lt<FTS&&zs.length){var tz=zs[0],eZ=1-cl((lt-tin)/(FTS-tin));kiAura(c,tz,zs.slice().reverse().concat(seg),.55+.45*eZ,now,1);}   /* la pointe s'enfonce dans la zone en brûlant */
  /* 3 · dans la zone : le trait se délite (le délitement du jeu, VX.ndDust), annihilation à l'entrée ; après le saut, tout le trait part en poussière */
  if(V&&V.ndDust){var G=[];if(zs.length>1)G.push({pts:zs.filter(function(q,qi){return qi%3===0;}).map(function(q){return [q[0],q[1],tTip(q[0])/16];}).reverse(),col:'#4DD7FF',done:true,sz:1.7,dn:2.2});
   if(dust.length>1)G.push({pts:dust.filter(function(q,qi){return qi%3===0;}).map(function(q){return [q[0],q[1],(FTJ+80+(q[0]-FR1)/.75)/16];}),col:'#4DD7FF',done:true,sz:1.5,dn:1.8});if(G.length){try{V.ndDust(c,G,tk);}catch(e){}}}
  var dk=lt-tin;  if(dk>0&&dk<900){var ex=FZX,ey=TY(FZX),pr=dk/900;c.save();c.globalCompositeOperation='lighter';
   c.strokeStyle='rgba(255,236,244,'+(.85*(1-pr)).toFixed(3)+')';c.lineWidth=2*(1-pr)+.4;c.beginPath();c.arc(ex,ey,6+46*ease('out',pr),0,2*PI);c.stroke();
   [[1,-1],[-1,1]].forEach(function(d,di){var L3=14+120*ease('out',pr),L4=Math.max(0,L3-26);c.strokeStyle=rgba(di?'#6EE2FF':'#FF5A7A',.8*(1-pr));c.lineWidth=1.3;c.beginPath();c.moveTo(ex+d[0]*L4*.6,ey+d[1]*L4);c.lineTo(ex+d[0]*L3*.6,ey+d[1]*L3);c.stroke();});   /* deux photons dos à dos */
   var fg=c.createRadialGradient(ex,ey,0,ex,ey,70);fg.addColorStop(0,'rgba(255,255,255,'+(.7*(1-pr)*(1-pr)).toFixed(3)+')');fg.addColorStop(1,'rgba(255,82,110,0)');c.fillStyle=fg;c.beginPath();c.arc(ex,ey,70,0,2*PI);c.fill();c.restore();}
  var vo=ease('io',cl((lt-(FTJ+FTF-1500))/2400));EP.vo0=vo;   /* R226 : il n'apparaît qu'après la course libre */if(vo>0)vortexQ(c,ORGP[0],ORGP[1],70*(.3+.7*vo),vo,EP.dt||16,0,1);};
  /* ═══ évènements ═══ */
 function ev5(z,e,P,who){var gx=z.x0+P[0],gy=P[1],cc=COL[z.w];
  switch(e[1]){
   case 'thud':event(z,['','hit',8.5,0,0,-1],P);burst(gx,gy+9,'#F1F4F6',34,3.2);burst(gx,gy+9,cc,26,2.6);EP.hit.push({x:gx,y:gy+10,c:'#FFFFFF',l:1,v:8.5,ny:-1});EP.hit.push({x:gx,y:gy+10,c:cc,l:1,v:6.5,ny:-1});EP.sh=Math.max(EP.sh,6.5);EP.zk=Math.max(EP.zk||1,1.1);EP['sq'+who]={t:1,nx:0,ny:-1,k:.52};break;
   case 'hit':event(z,e,P);EP.sh=Math.max(EP.sh,Math.min(4.5,(e[2]||5)*.5));EP.zk=Math.max(EP.zk||1,1+Math.min(.07,(e[2]||5)*.008));EP['sq'+who]={t:1,nx:e[4]||0,ny:e[5]==null?-1:e[5],k:Math.min(.4,(e[2]||5)/17)};break;
   case 'twang':event(z,['','hit',(e[2]||5)*.75,0,0,-1],P);burst(gx,gy+8,'#E896BE',10,1.6);EP['sq'+who]={t:1,nx:0,ny:-1,k:Math.min(.35,(e[2]||5)/20)};break;
   case 'pulse':burst(z.x0+e[2],e[3],'#9BEB4B',34,2.6);burst(z.x0+e[2],e[3],'#F1F4F6',16,2);EP.hit.push({x:z.x0+e[2],y:e[3],c:'#9BEB4B',l:1,v:7,ny:1});EP.sh=Math.max(EP.sh,2.4);EP.zk=1.07;break;
   case 'split':case 'tunnel':event(z,e,P);break;
   case 'portal':burst(z.x0+e[2],e[3],cc,26,2.2);EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:5,ny:0});EP.sh=Math.max(EP.sh,1.2);break;
   case 'seam':burst(gx,gy,'#F1F4F6',22,2.2);burst(gx,gy,cc,14,1.6);EP.hit.push({x:gx,y:gy,c:cc,l:1,v:5,ny:1});EP.sh=Math.max(EP.sh,1.6);break;
   case 'mag':burst(gx,gy,cc,18,1.8);break;
   case 'pass':burst(z.x0+e[2],gy,'#A9BCEB',20,1.8);EP.hit.push({x:z.x0+e[2],y:gy,c:'#A9BCEB',l:1,v:5,ny:0});break;
   case 'coll':burst(z.x0+e[2],e[3],'#FFFFFF',46,4.6);burst(z.x0+e[2],e[3],cc,34,3.4);EP.hit.push({x:z.x0+e[2],y:e[3],c:'#FFFFFF',l:1,v:8.5,ny:0});EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:7,ny:0});EP.sh=Math.max(EP.sh,5);EP.zk=Math.max(EP.zk||1,1.14);break;
   case 'gap':burst(z.x0+e[2],e[3],cc,16,2.2);burst(z.x0+e[2],e[3],'#F1F4F6',8,1.6);EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:6,ny:0});EP.sh=Math.max(EP.sh,1.4);EP.zk=Math.max(EP.zk||1,1.035);break;
   case 'vtx':burst(z.x0+e[2]+60,e[3],cc,22,2.4);EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:6,ny:0});EP.sh=Math.max(EP.sh,1.6);EP.zk=Math.max(EP.zk||1,1.04);break;
   case 'eject':burst(gx,gy,'#F1F4F6',20,3);burst(gx,gy,cc,16,2.4);EP.hit.push({x:gx,y:gy,c:'#F1F4F6',l:1,v:7,ny:0});EP.sh=Math.max(EP.sh,2.2);EP.zk=Math.max(EP.zk||1,1.06);break;
   case 'boost':burst(gx,gy,cc,26,2.6);EP.sh=Math.max(EP.sh,1.2);break;
   case 'absorb':break;}}
 /* ═══ rendu ═══ */
 function initEP5(){EP={v:5,T0:0,last:0,lt:-1e9,cam:{ok:false},tr:[],trB:[],seen:{},hit:[],rip:[],pts:[],dA:[],dB:[],sh:0,zk:1,ts:1,dt:16,sqA:null,sqB:null,kc:null,pr:{}};parts=[];for(var pk=0;pk<11;pk++)img(pk);}
 /* R229 : traînée en ruban continu — points lissés (Catmull-Rom), largeur qui s'effile, dégradé de la tête à la queue,
    deux couches (halo large, cœur fin) remplies d'un seul tenant : plus de tronçons visibles */
 function trail5(c,T,col,kw,LM){LM=LM||120;kw=kw||1.6;var n=T.length,i,j,P=[],L=0;if(n<2)return;
  for(i=n-1;i>=0;i--){if(!T[i])break;if(P.length){var q=P[P.length-1];if(Math.hypot(T[i][0]-q[0],T[i][1]-q[1])<.4)continue;}P.push(T[i]);}
  if(P.length<2)return;var Q=[P[0]];
  for(i=0;i<P.length-1;i++){var p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)];
   for(j=1;j<=4;j++){var u=j/4,u2=u*u,u3=u2*u;Q.push([.5*((2*p1[0])+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*((2*p1[1])+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)]);}}
  var D=[0];for(i=1;i<Q.length;i++){L+=Math.hypot(Q[i][0]-Q[i-1][0],Q[i][1]-Q[i-1][1]);D.push(L);if(L>=LM){Q.length=i+1;break;}}
  if(L<1)return;var LL=Math.min(L,LM),tail=Q[Q.length-1];
  function band(wk,al,cA){var Lf=[],Rt=[];for(i=0;i<Q.length;i++){var a=Q[Math.max(0,i-1)],b=Q[Math.min(Q.length-1,i+1)],tx=b[0]-a[0],ty=b[1]-a[1],tl=Math.hypot(tx,ty)||1,f=1-D[i]/LL,ww=R*kw*wk*Math.pow(Math.max(0,f),.75)*.5;
    Lf.push([Q[i][0]-ty/tl*ww,Q[i][1]+tx/tl*ww]);Rt.push([Q[i][0]+ty/tl*ww,Q[i][1]-tx/tl*ww]);}
   c.beginPath();c.moveTo(Lf[0][0],Lf[0][1]);for(i=1;i<Lf.length;i++)c.lineTo(Lf[i][0],Lf[i][1]);for(i=Rt.length-1;i>=0;i--)c.lineTo(Rt[i][0],Rt[i][1]);c.closePath();
   var g=c.createLinearGradient(Q[0][0],Q[0][1],tail[0],tail[1]);g.addColorStop(0,rgba(cA,al));g.addColorStop(.45,rgba(cA,al*.45));g.addColorStop(1,rgba(cA,0));c.fillStyle=g;c.fill();}
  c.save();c.globalCompositeOperation='lighter';band(1.9,.22,col);band(1,.42,col);band(.32,.5,'#F1F4F6');c.restore();}
 function streaks5(c,p,v,col){var sp=Math.hypot(v[0],v[1]);if(sp<.42)return;var L=Math.min(46,(sp-.3)*90),ux=v[0]/sp,uy=v[1]/sp;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  for(var k=-2;k<=2;k++){var off=k*3.2,x0=p[0]-uy*off*-1,y0=p[1]+ux*off*-1,l=L*(1-Math.abs(k)*.22);c.strokeStyle=rgba(k?col:'#F1F4F6',(.5-Math.abs(k)*.1)*Math.min(1,(sp-.38)*3));c.lineWidth=k?.8:1.3;c.beginPath();c.moveTo(x0-ux*R*.8,y0-uy*R*.8);c.lineTo(x0-ux*(R*.8+l),y0-uy*(R*.8+l));c.stroke();}c.restore();}
 function ball5(c,x,y,al,sc,now,sq,m,isB){c.save();c.globalAlpha=al;c.translate(x,y);
  var sx=1,sy=1;if(sq&&sq.t>0){var sk=sq.k*Math.sin(sq.t*PI)*sq.t,an=Math.atan2(sq.ny,sq.nx);c.rotate(an);c.scale(1-sk,1+sk*.7);c.rotate(-an);}
  if(m&&m.sx){c.scale(m.sx,m.sy);}
  var V=window.VX;if(V&&V.ball){if(isB){c.globalAlpha=al*.78;V.ball(c,0,0,-now*.004,R*.94*(sc||1),'#A878FF');}else V.ball(c,0,0,now*.004,R*(sc||1));}else{c.fillStyle=isB?'#A878FF':'#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();}
 /* fond : comme drawWorldBg du héros, mais l'image est assez large pour que le décalage de parallaxe ne laisse jamais de bande */
 function bg5(c,w,h,cm){var f=cm.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0,bo=1-(EP&&EP.bgOut||0)*.94;if(k0<0){k0=0;fr=0;}
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){if(o[1]>.01&&o[0]>=0&&o[0]<=11){var I=img(o[0]);
   if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.3,dh=dw/ir;c.globalAlpha=o[1]*.6*bo;c.drawImage(I,(w-dw)/2-(Math.max(f,.5)-o[0]-.5)*w*.12,(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[o[0]],.22*o[1]));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}}});
  vign(c,w,h,.38,.9);dustPar(c,w,h,cm);}
 /* réaction d'un élément au passage des billes : intensité (0..1) des chocs récents dont l'abscisse tombe dans [x0,x1] */
 function hitGlow(z,x0,x1,lt,tau){var m=0;[z.hitsA||[],z.hitsB||[]].forEach(function(H){H.forEach(function(h){if(h.t<=lt&&h.x>=x0&&h.x<=x1){var g=Math.exp(-(lt-h.t)/tau)*Math.min(1,.5+h.v*2);if(g>m)m=g;}});});return m;}
 function hitSum(z,lt,tau){var q=0;[z.hitsA||[],z.hitsB||[]].forEach(function(H){H.forEach(function(h){if(h.t<=lt)q+=Math.min(1.2,.4+h.v*2)*(1-Math.exp(-(lt-h.t)/tau));});});return q;}
 function vel5(z,which,lt){var S=which?z.B:z.A,st=which?z.stB:z.stA;if(!S)return null;var a=locS(S,st,Math.max(0,lt-14)),b=locS(S,st,lt+14);return a&&b?[b[0]-a[0],b[1]-a[1]]:null;}
 /* R215 · charte du jeu : le fond animé du monde (voiles, hélices, poussière, mécanique, anneau, bulles — VX.back) sous chaque
    scène, dessiné à 2× dans une toile à part puis fondu aux changements de monde */
 var BKL={},BKC=null;
 function backS5(c,z,lt,A){var V=window.VX;if(!V||!V.back||z.w===7||window.QBACK_OFF)return;   /* Magnétisme : le ferrofluide WebGL ne se lance pas en pleine animation */var fa=ease('io',cl(lt/450))*ease('io',cl((z.d-lt)/450));if(fa<.02)return;
  if(!BKC){BKC=document.createElement('canvas');BKC.width=720;BKC.height=960;}var g=BKC.getContext('2d'),lv=BKL[z.w]||(BKL[z.w]={idx:900+z.w,wd:z.w+1,walls:[],w:[],zone:[-300,-300,1,1],ball:[-300,-300],bf:[[0,0,0,0,0,0,'atom']]});
  var ob=(typeof S!=='undefined')?S.ball:null;if(typeof S!=='undefined')S.ball={x:A?A[0]:-99,y:A?A[1]:-99,vx:0,vy:0};
  g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,720,960);g.setTransform(2,0,0,2,0,0);try{V.back(g,lv);}catch(e){window.__derr='back '+(e&&e.stack||e);}
  g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='destination-in';[[0,0,0,960],[0,0,720,0]].forEach(function(q){var lg=g.createLinearGradient(q[0],q[1],q[2],q[3]);lg.addColorStop(0,'rgba(0,0,0,0)');lg.addColorStop(.16,'rgba(0,0,0,1)');lg.addColorStop(.84,'rgba(0,0,0,1)');lg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=lg;g.fillRect(0,0,720,960);});g.globalCompositeOperation='source-over';
  if(typeof S!=='undefined')S.ball=ob;c.save();c.globalAlpha=fa*.9;c.drawImage(BKC,z.x0,0,360,480);c.restore();}
 /* R226 · le vol libre : plus d'image de fond, seulement une poussière d'étoiles légère en arrière-plan et quelques éclats flous
    en avant-plan ; leur défilement dépend de la caméra, donc ils filent de plus en plus vite quand le couple accélère */
 function spaceDeco(c,w,h,cm,s0,fore){var a=EP.bgOut,n,sc=s0*cm.z;c.save();c.globalCompositeOperation='lighter';
  if(!fore){for(n=0;n<140;n++){var pz=.15+.55*hh5(n*1.7),px=((hh5(n*3.1)*w*3-cm.x*sc*pz)%(w*1.4)+w*1.4)%(w*1.4)-w*.2,py=((hh5(n*5.3)*h-cm.y*sc*pz*.4)%h+h)%h,tw=.55+.45*Math.sin(now0*.003+n);
    c.fillStyle=rgba(n%5?'#E6F2FF':(n%2?'#A878FF':'#4DD7FF'),(.15+.5*pz)*tw*a);var sz=.6+1.4*pz;c.fillRect(px,py,sz,sz);
    if(pz>.55){c.strokeStyle=rgba('#E6F2FF',.12*a*pz);c.lineWidth=sz*.6;c.beginPath();c.moveTo(px,py);c.lineTo(px+Math.min(40,(EP.cvx||0)*sc*pz*.6),py);c.stroke();}}}
  else{for(n=0;n<14;n++){var pz2=1.6+1.2*hh5(n*7.7),px2=((hh5(n*2.3)*w*4-cm.x*sc*pz2)%(w*1.6)+w*1.6)%(w*1.6)-w*.3,py2=hh5(n*4.9)*h,r2=(4+10*hh5(n*6.1))*s0;
    var g=c.createRadialGradient(px2,py2,0,px2,py2,r2);g.addColorStop(0,rgba(n%3?'#BFD8FF':'#C8A8FF',.16*a));g.addColorStop(1,'rgba(160,190,255,0)');c.fillStyle=g;c.beginPath();c.arc(px2,py2,r2,0,2*PI);c.fill();}}
  c.restore();}
 function filmAt(t){var k=0;while(k<ZS.length-1&&t>=ZS[k].t0+ZS[k].d)k++;return k;}
 function step(c,w,h,now,t,dt,s0){
  var k=filmAt(t),z=ZS[k],lt=Math.min(z.d,t-z.t0),dive=t>=TRT5?t-TRT5:-1,A=null,B=null,visA=false,visB=false,DU=0;if(dive>=0)lt=z.d+dive;
  if(dive>=0){DU=cl(dive/DIVE);var rr=30*Math.pow(1-DU,1.3),dA=DVW*DIVE*(DU-.28*DU*DU);   /* R228 : le siphon continue — chaque particule repart de sa place, de plus en plus vite, et s'enfonce */
   var oA=z.outA||[ORGP[0],ORGP[1]-13],oB=z.outB||oA,aA=Math.atan2((oA[1]-ORGP[1])/.45,oA[0]-ORGP[0])+dA,aB=Math.atan2((oB[1]-ORGP[1])/.45,oB[0]-ORGP[0])+dA;
   A=[ORGP[0]+rr*Math.cos(aA),ORGP[1]+rr*.45*Math.sin(aA)];B=[ORGP[0]+rr*Math.cos(aB),ORGP[1]+rr*.45*Math.sin(aB)];visA=visB=DU<.97;
   EP.dvm={al:1-ease('in',cl((DU-.5)/.42)),sc:1-.92*ease('io',cl(DU/.85))};}
  else{A=locS(z.A,z.stA,lt);if(z.B){B=locS(z.B,z.stB,lt);visB=lt>=z.B0&&!!B;}visA=!!A;
   if(z.tw&&A&&B)z.tw.forEach(function(w,wi){if(lt>w[0]&&lt<w[1]){var ku=(lt-w[0])/(w[1]-w[0]);[[0,'a'],[.94,'b']].forEach(function(m){var kq=k+'tw'+wi+m[1];if(ku>=m[0]&&!EP.seen[kq]){EP.seen[kq]=1;var ex=z.x0+(A[0]+B[0])/2,ey=(A[1]+B[1])/2;(EP.ech=EP.ech||[]).push({x:ex,y:ey,t:now});burst(ex,ey,'#F1F4F6',18,2.2);burst(ex,ey,'#A878FF',14,1.8);}});var u=(lt-w[0])/(w[1]-w[0]),e=ease('io',u),th=w[2]*2*PI*e,bl=1+w[3]*Math.sin(PI*u),mx=(A[0]+B[0])/2,my=(A[1]+B[1])/2,dx=(B[0]-A[0])/2*bl,dy=(B[1]-A[1])/2*bl,cs=Math.cos(th),sn=Math.sin(th),rx=dx*cs-dy*sn,ry=dx*sn+dy*cs;A=[mx-rx,my-ry];B=[mx+rx,my+ry];}});}   /* R218 : tournoiement du couple */
  if(!A)A=EP.lA||z.inA;EP.lA=A;if(z.B&&!B)B=EP.lB||z.inB;if(B)EP.lB=B;
  var gA=[z.x0+A[0],A[1]],gB=B?[z.x0+B[0],B[1]]:null;
  /* évènements */
  if(dive<0)vib5(VIBSC[z.nm],lt,'v'+k+'_');else vib5(VIBSC._dive,dive,'vd_');
  if(dive<0){(z.ev||[]).forEach(function(e,ei){var key=k+'a'+ei;if(lt>=e[0]&&!EP.seen[key]){EP.seen[key]=1;ev5(z,e,A,'A');}});
   (z.evB||[]).forEach(function(e,ei){var key=k+'b'+ei;if(lt>=e[0]&&!EP.seen[key]&&B){EP.seen[key]=1;ev5(z,e,B,'B');}});}
  /* caméra : suit le couple, recule quand elles s'écartent */
  var mx=gA[0],my=gA[1],dx=0,dy=0;if(gB&&visB){mx=(gA[0]*1.15+gB[0])/2.15;my=(gA[1]*1.15+gB[1])/2.15;dx=Math.abs(gA[0]-gB[0]);dy=Math.abs(gA[1]-gB[1]);}
  /* caméra : suit le couple ; les consignes de scène ne s'appliquent qu'en fondu (0,5 s) à l'entrée et à la sortie, jamais en saut */
  var zc=z.cam?z.cam(lt):null,wh=dive>=0?0:ease('io',cl(lt/520))*ease('io',cl((z.d-lt)/520)),base=1+((zc&&zc.z?zc.z:1)-1)*wh,
   fit=Math.min(UW/(dx*1.25+160),UH/(dy*1.5+220)),zoom=Math.min(base,fit)*(EP.zk||1);EP.zk=1+((EP.zk||1)-1)*Math.pow(.05,dt/1000);
  var fx=mx-26,fy=240+(my-240)*.45+(zc&&zc.oy||0),tx=zc&&zc.tx!=null?fx+(z.x0+zc.tx-fx)*wh:fx,ty=zc&&zc.ty!=null?fy+(zc.ty-fy)*wh:fy;
  if(dive<0&&z.w===0&&lt>300&&lt<FTJ+1600){var TIN=tTip(FZX),xtp=xTip(lt),prx=mx-z.x0,S0=TIN-1900,S1=TIN+1500;   /* R225 : trois cadrages fondus, jamais de saut */
   var l1=Math.min(xtp,prx),r1=Math.max(prx,l1+1),z1=Math.max(.72,Math.min(1,w/(s0*(r1-l1+220)))),x1=(l1+r1)/2,y1=272;
   var xs=lt<TIN?xtp:FZX,x2=xs-25,y2=TY(Math.max(xs,FZX))-12,z2=.96,kz=ease('io',cl((lt-(TIN-1200))/1500));   /* R228 : la zone vient au centre avant l'impact, léger dézoom anticipé, la caméra dérive toujours */
   x2=x2+((ZN[5][0]+ZN[5][2]*.5-.022*Math.max(0,lt-TIN))-x2)*kz*.9;y2=y2+((ZN[5][1]+ZN[5][3]*.5)-y2)*kz*.7;z2=z2+(.8-z2)*kz;
   var ka=ease('io',cl((lt-S0)/1100)),kb=ease('io',cl((lt-S1)/1400));
   var xx=x1+(x2-x1)*ka,yy=y1+(y2-y1)*ka,zl=Math.log(z1)+(Math.log(z2)-Math.log(z1))*ka;
   xx=xx+((tx-z.x0)-xx)*kb;yy=yy+(ty-yy)*kb;zl=zl+(Math.log(zoom)-zl)*kb;tx=z.x0+xx;ty=yy;zoom=Math.exp(zl);}
  if(dive<0&&z.w===0&&lt>FTJ+FTF-1200){var kv=ease('io',cl((lt-(FTJ+FTF-1200))/(z.d-FTJ-FTF+1200))),bxw=z.x0+ORGP[0]+10,zf=Math.max(.7,Math.min(1,w/(s0*(Math.abs(mx-bxw)+300))));   /* R227 */
   tx=tx+(bxw-tx)*kv;ty=ty+(ORGP[1]+60-ty)*kv;var zt=Math.min(zoom,zf);zoom=Math.exp(Math.log(zoom)+(Math.log(zt)-Math.log(zoom))*Math.min(1,kv*2));zoom=Math.exp(Math.log(zoom)+(Math.log(.86)-Math.log(zoom))*kv);}
  if(dive>=0){var du=ease('io',cl(dive/DIVE));tx=z.x0+ORGP[0]+10*(1-du);ty=ORGP[1]+60*(1-du);zoom=.86+1.29*du;}
  var cm=EP.cam;if(!cm.ok){cm.x=tx;cm.y=ty;cm.z=zoom;cm.ok=true;}
  if(k!==EP.kc){EP.kc=k;}
  var fk=1-Math.pow(.0025,dt/1000);cm.x+=(tx-cm.x)*Math.min(1,fk*3.2);cm.y+=(ty-cm.y)*Math.min(1,fk*2);cm.z+=(zoom-cm.z)*Math.min(1,fk*1.8);
  EP.bgOut=z.w===0?ease('io',cl(((dive>=0?z.d+dive:lt)-FTJ-200)/1600)):0;bg5(c,w,h,cm);if(EP.bgOut>0)spaceDeco(c,w,h,cm,s0,0);var s=s0*cm.z,sh=EP.sh;EP.sh*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.scale(s,s);c.rotate((dive<0&&z.w===7)?2*PI*ease('io',cl((lt-500)/2900)):(dive<0&&z.w===6)?-.3*Math.sin(PI*cl((lt-150)/Math.max(300,z.d-300))):0);c.translate(-cm.x,-cm.y);
  if(dive<0)backS5(c,z,lt,A);
  var mA=null,mB=null;
  var oBall=(typeof S!=='undefined')?S.ball:null;
  for(var kk=Math.max(0,k-1);kk<=Math.min(ZS.length-1,k+1);kk++){var zz=ZS[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);EP.mA=null;EP.mB=null;if(typeof S!=='undefined')S.ball=kk===k&&visA?{x:A[0],y:A[1],vx:0,vy:0}:{x:-999,y:-999,vx:0,vy:0};
   try{DECO[zz.w](c,zz,llt,kk===k&&visA?A:null,kk===k&&visB?B:null,now);}catch(x){window.__derr=zz.w+': '+(x&&x.stack||x);}c.restore();if(kk===k){mA=EP.mA;mB=EP.mB;}}
  if(typeof S!=='undefined')S.ball=oBall;
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}eHits(c,dt);
  if(EP.ech&&EP.ech.length){c.save();c.globalCompositeOperation='lighter';   /* R219 : échos à la rencontre — trois ondes décalées qui s'affaiblissent, comme une voix répétée */
   EP.ech=EP.ech.filter(function(e){return now-e.t<1100;});EP.ech.forEach(function(e){for(var q=0;q<3;q++){var ag=now-e.t-q*140;if(ag<0||ag>760)continue;var pr=ag/760,rr=5+pr*(46+q*14),al=.6*(1-pr)*(1-pr)*(1-q*.3);
     c.strokeStyle=rgba(q%2?'#A878FF':'#F1F4F6',al);c.lineWidth=1.6*(1-pr)+.4;c.beginPath();c.arc(e.x,e.y,rr,0,2*PI);c.stroke();
     for(var r2=0;r2<6;r2++){var an=r2*PI/3+q*.5+pr*.6,l1=rr*.55,l2=rr*.8;c.beginPath();c.moveTo(e.x+Math.cos(an)*l1,e.y+Math.sin(an)*l1);c.lineTo(e.x+Math.cos(an)*l2,e.y+Math.sin(an)*l2);c.stroke();}}});c.restore();}
  /* traînées (comme dans le héros) */
  if(dt>0){EP.tr.push(visA?gA:null);if(EP.tr.length>26)EP.tr.shift();EP.trB.push(visB?gB:null);if(EP.trB.length>26)EP.trB.shift();}
  trail5(c,EP.tr,dive>=0?'#F1F4F6':COL[z.w],dive>=0?.6:1.6,dive>=0?75:120);trail5(c,EP.trB,'#A878FF',dive>=0?.6:1.5,dive>=0?75:120);
  /* traits de vitesse */
  var vA=EP.pr.A?[(gA[0]-EP.pr.A[0])/Math.max(1,dt),(gA[1]-EP.pr.A[1])/Math.max(1,dt)]:[0,0];if(visA&&dt>0)streaks5(c,gA,vA,COL[z.w]);EP.pr.A=gA.slice();
  if(visB){var vB=EP.pr.B?[(gB[0]-EP.pr.B[0])/Math.max(1,dt),(gB[1]-EP.pr.B[1])/Math.max(1,dt)]:[0,0];if(dt>0)streaks5(c,gB,vB,'#A878FF');EP.pr.B=gB.slice();}else EP.pr.B=null;
  eParts(c,dt);
  /* squash */
  ['A','B'].forEach(function(q){var o=EP['sq'+q];if(o){o.t=Math.max(0,o.t-dt/240);if(o.t<=0)EP['sq'+q]=null;}});
  var sqa=z.sqA&&dive<0?z.sqA(lt):null,sqb=z.sqB&&dive<0?z.sqB(lt):null;
  if(dive>=0){
   var Rv=60+380*ease('in',DU);vortexQ(c,z.x0+ORGP[0],ORGP[1],Rv,1,dt,1,1);
   if(dive<1100&&(!EP.rpt||now-EP.rpt>150)){EP.rpt=now;EP.rip.push({l:0});}
   c.save();c.globalCompositeOperation='lighter';for(var q=EP.rip.length-1;q>=0;q--){var rp=EP.rip[q];rp.l+=dt/900;if(rp.l>=1){EP.rip.splice(q,1);continue;}c.strokeStyle=rgba(q%2?'#A878FF':'#4DD7FF',.45*(1-rp.l));c.lineWidth=1.4*(1-rp.l)+.3;c.beginPath();c.ellipse(z.x0+ORGP[0],ORGP[1],8+rp.l*150,(8+rp.l*150)*.5,0,0,2*PI);c.stroke();}c.restore();}
  if(dive>=0){mA=EP.dvm;mB=EP.dvm;if(DU>.9&&!EP.popped){EP.popped=1;burst(z.x0+ORGP[0],ORGP[1],'#F1F4F6',60,3.4);burst(z.x0+ORGP[0],ORGP[1],'#A878FF',36,2.8);EP.sh=Math.max(EP.sh,6);}EP.sh=Math.max(EP.sh,DU*3.2);}
  if(visB)ball5(c,gB[0],gB[1],mB&&mB.al!=null?mB.al:1,mB&&mB.sc||1,now,EP.sqB||sqb,mB,true);
  if(visA){var al=mA&&mA.al!=null?mA.al:1,hg=c.createRadialGradient(gA[0],gA[1],0,gA[0],gA[1],R*3);hg.addColorStop(0,'rgba(241,244,246,'+(.3*al).toFixed(3)+')');hg.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=hg;c.beginPath();c.arc(gA[0],gA[1],R*3,0,2*PI);c.fill();
   ball5(c,gA[0],gA[1],al,mA&&mA.sc||1,now,EP.sqA||sqa,mA,false);}
  if(window.__camlog&&dt>0)window.__camlog.push([t,cm.x,cm.y,cm.z,gA[0],gA[1],gB?gB[0]:null,gB?gB[1]:null,visB?1:0,k]);
  EP.gA=gA;EP.gB=gB;c.restore();if(EP.bgOut>0)spaceDeco(c,w,h,cm,s0,1);
  if(dive<0){var spd=Math.max(Math.hypot(vA[0],vA[1]),visB?Math.hypot(vB[0],vB[1]):0);if(spd>.45){var sa=Math.min(.2,(spd-.45)*.35);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
   for(var q3=0;q3<16;q3++){var yy=((q3*131.7)%1)*h,xx=((q3*53.3+now*(.9+(q3%4)*.35)*.9)%(w*1.4)),len=40+(q3%5)*30;xx=w-xx;c.strokeStyle='rgba(241,244,246,'+(sa*(.4+.6*((q3*7)%5)/5)).toFixed(3)+')';c.lineWidth=.8+(q3%3)*.5;c.beginPath();c.moveTo(xx,yy);c.lineTo(xx+len,yy+len*.04);c.stroke();}c.restore();}}
  var ir=1-ease('io',cl(t/380));if(ir>0){c.fillStyle='rgba(3,4,8,'+ir.toFixed(3)+')';c.fillRect(0,0,w,h);}
  if(dive>DIVE*.7){var fa=ease('io',cl((dive-DIVE*.7)/(DIVE*.3)));var g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.7);g.addColorStop(0,'rgba(255,255,255,'+(fa).toFixed(3)+')');g.addColorStop(.35,'rgba(214,226,255,'+(fa*.8).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,'+(fa*.55).toFixed(3)+')');c.fillStyle=g;c.fillRect(0,0,w,h);}}
 /* ═══ l'atome des onze mondes ═══ */
 function atom5(c,w,h,now,t,dt,s0){var n,i;c.fillStyle='#05070D';c.fillRect(0,0,w,h);bgImg(c,w,h,10,.10+.08*cl(t/2000),0);vign(c,w,h,.45,.92);
  var s=s0*(1.0+.06*ease('io',cl(t/9000))),C=[180,236],spin=t*.00026,tilt=.5+.25*Math.sin(t*.0003);
  c.save();c.translate(w/2,h/2);c.scale(s,s);c.translate(-180,-240);
  for(n=0;n<70;n++){c.fillStyle=rgba(COL[n%12],(.15+.25*Math.sin(now*.002+n*1.7))*cl(t/1200));c.fillRect((n*97)%360,(n*151)%480,1.2,1.2);}
  var W2=function(p){var r=rot3(p,tilt,spin),f=1/(1-r[2]*.0018*60);return [r[0],r[1],r[2]];};
  /* noyau */
  var core=cl(t/700),pul=1+.08*Math.sin(now*.004);
  c.save();c.globalCompositeOperation='lighter';
  var cg=c.createRadialGradient(C[0],C[1],0,C[0],C[1],46*core*pul);cg.addColorStop(0,'rgba(255,255,255,'+(.95*core).toFixed(3)+')');cg.addColorStop(.3,'rgba(214,200,255,'+(.5*core).toFixed(3)+')');cg.addColorStop(1,'rgba(155,235,75,0)');c.fillStyle=cg;c.beginPath();c.arc(C[0],C[1],46*core*pul,0,2*PI);c.fill();
  /* les onze orbites : une par monde, allumées l'une après l'autre */
  var orbs=[];
  for(i=0;i<11;i++){var on=ease('out',cl((t-500-i*170)/1100));if(on<=0)continue;var rr=(50+i*10.5)*on,al0=.9*(i%2?1:-1),be=i*0.58;
   var cols=COL[i];
   for(n=0;n<48;n++){var a1=n/48*2*PI,a2=(n+1)/48*2*PI,p1=W2(rot3([Math.cos(a1),Math.sin(a1),0],al0*.7+i*.32,be)),p2=W2(rot3([Math.cos(a2),Math.sin(a2),0],al0*.7+i*.32,be)),d=(p1[2]+1)/2;
    c.strokeStyle=rgba(cols,(.06+.26*d)*on);c.lineWidth=.8+.5*d;c.beginPath();c.moveTo(C[0]+p1[0]*rr,C[1]+p1[1]*rr);c.lineTo(C[0]+p2[0]*rr,C[1]+p2[1]*rr);c.stroke();}
   var th=now*.0021*(1.5-i*.08)+i*1.7,pe=W2(rot3([Math.cos(th),Math.sin(th),0],al0*.7+i*.32,be)),de=(pe[2]+1)/2;
   for(n=1;n<=10;n++){var tq=th-n*.09*(1.5-i*.08),pq=W2(rot3([Math.cos(tq),Math.sin(tq),0],al0*.7+i*.32,be));c.fillStyle=rgba(cols,(.5-.045*n)*on*(.4+.6*de));c.beginPath();c.arc(C[0]+pq[0]*rr,C[1]+pq[1]*rr,(1.6+1.3*de)*(1-n*.06),0,2*PI);c.fill();}
   orbs.push([C[0]+pe[0]*rr,C[1]+pe[1]*rr,cols,de,on]);}
  orbs.forEach(function(o){var g=c.createRadialGradient(o[0],o[1],0,o[0],o[1],7);g.addColorStop(0,rgba('#F1F4F6',.95*o[4]));g.addColorStop(.4,rgba(o[2],.6*o[4]));g.addColorStop(1,rgba(o[2],0));c.fillStyle=g;c.beginPath();c.arc(o[0],o[1],3+4*o[3],0,2*PI);c.fill();});
  c.restore();
  /* les deux particules : paire serrée sur l'orbite du noyau */
  var th0=now*.0043,R0=(15+11*ease('out',cl((t-300)/1500)));
  [[0,'#F1F4F6'],[Math.PI,'#A878FF']].forEach(function(q,qi){var p=W2(rot3([Math.cos(th0+q[0]),Math.sin(th0+q[0]),0],.35,spin*3)),d=(p[2]+1)/2,x=C[0]+p[0]*R0,y=C[1]+p[1]*R0;
   var T=qi?EP.dB:EP.dA;if(dt>0){T.push([x,y]);if(T.length>26)T.shift();}trail5(c,T,q[1],1.3);ball5(c,x,y,cl(t/500),(.7+.4*d)*(.8+.2*core),now,null,null,!!qi);});
  c.restore();
  var ir=1-ease('out',cl(t/900));if(ir>0){var g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.75);g.addColorStop(0,'rgba(255,255,255,'+(ir).toFixed(3)+')');g.addColorStop(.4,'rgba(214,226,255,'+(ir*.7).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,'+(ir*.4).toFixed(3)+')');c.fillStyle=g;c.fillRect(0,0,w,h);}
  var ttl=EP.title||'';if(ttl&&t>3200){var ta=ease('io',cl((t-3200)/2600)),sp2=Math.round(14-6*ta),fs=Math.round(Math.min(w*.09,36));c.save();c.font='300 '+fs+'px "Space Grotesk","Avenir Next",system-ui,sans-serif';c.textBaseline='middle';
   var ws=[],tw=0,q2;for(q2=0;q2<ttl.length;q2++){var cw=c.measureText(ttl[q2]).width;ws.push(cw);tw+=cw+(q2<ttl.length-1?sp2:0);}var x0=w/2-tw/2,y0=h*.14+(1-ta)*6;
   c.shadowColor='rgba(77,215,255,'+(.6*ta).toFixed(3)+')';c.shadowBlur=18*ta;for(q2=0;q2<ttl.length;q2++){var la=cl(ta*1.6-q2*.08);c.fillStyle='rgba(241,244,246,'+(.92*la).toFixed(3)+')';c.fillText(ttl[q2],x0,y0);x0+=ws[q2]+sp2;}
   c.shadowBlur=0;var lw=tw*.5*ta;c.fillStyle='rgba(168,120,255,'+(.45*ta).toFixed(3)+')';c.fillRect(w/2-lw/2,y0+fs*.72,lw,1);c.restore();}
  return t>7200;}
 /* ═══ API du banc ═══ */
 function render(c,w,h,t,opt){
  if(!EP||EP.v!==5)initEP5();
  var s0=Math.min(w/UW,h/UH),jump=Math.abs(t-EP.lt)>250||t<EP.lt,dt=jump?0:Math.min(50,t-EP.lt);EP.title=opt&&opt.title||'';now0=t;dtD=dt;EP.dt=dt||16;
  if(window.S){S.tick=Math.floor(t*.06);S.t=t*.001;}
  if(jump){var t0=Math.max(0,t-900);EP.cam={ok:false};EP.tr=[];EP.trB=[];EP.seen={};EP.hit=[];EP.rip=[];EP.sh=0;EP.zk=1;EP.pr={};EP.sqA=null;EP.sqB=null;EP.dA=[];EP.dB=[];EP.kc=null;EP.popped=0;EP.dOn=0;parts=[];
   var T1=TRT5+DIVE,tp=Math.min(t,T1),t0=Math.max(0,tp-900),tc=document.createElement('canvas');tc.width=90;tc.height=195;var x2=tc.getContext('2d'),s2=Math.min(90/UW,195/UH);
   for(var kk=0;kk<ZS.length;kk++){(ZS[kk].ev||[]).forEach(function(e,ei){if(ZS[kk].t0+e[0]<t0)EP.seen[kk+'a'+ei]=1;});(ZS[kk].evB||[]).forEach(function(e,ei){if(ZS[kk].t0+e[0]<t0)EP.seen[kk+'b'+ei]=1;});}
   EP.warm=1;for(var tt=t0;tt<tp-16;tt+=16)step(x2,90,195,tt,tt,16,s2);
   if(t>=T1){EP.pts=[];EP.dA=[];EP.dB=[];EP.oA=null;EP.oB=null;for(var t3=0;t3<t-T1-16;t3+=16)epDance(x2,90,195,T1+t3,t3,16,s2);}EP.warm=0;}
  EP.lt=t;c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  if(t<TRT5+DIVE)step(c,w,h,t,t,dt,s0);else{var td=t-TRT5-DIVE;if(!EP.dOn||td<EP.dT){EP.pts=[];EP.dA=[];EP.dB=[];EP.oA=null;EP.oB=null;}EP.dOn=1;EP.dT=td;vib5(VIBSC._danse,td,'vn_');return {t:t,ground:epDance(c,w,h,t,td,dt||16,s0)};}
  return {t:t,ground:false};}
 var TXT={11:['quitte la coupe, catapultée','—'],10:['franchit le champ de temps dilaté','traverse le mur poreux (effet tunnel)'],9:['traverse la harpe, rebondit sur la corde','rebondit le long de la corde'],8:['entre par un portail, sort par l\'autre','tombe par le bas, reparaît par le haut'],
  7:['attirée : s\'enroule autour de l\'aimant','repoussée : le contourne par le bas'],6:['déviée par le puits de gravité','gravité inversée : tombe vers le plafond'],5:['descend l\'escalier marche par marche','rebondit plus haut : saute des marches'],4:['monte dans la colonne d\'air','monte en zigzag, en contre-phase'],
  3:['glisse sur la glace, traverse deux murs poreux','même piste, un peu plus haut'],2:['looping à pleine vitesse','looping, juste derrière'],1:['rebondit de plaque en plaque','rebondit plus mollement'],0:['roule sur le trait, monte en hélice','roule sur le trait, monte en hélice']};
 var fin5o={total:function(){return TRT5+DIVE+ATOM;},chaseEnd:function(){return TRT5;},fuseEnd:function(){return TRT5+DIVE;},render:render,reset:function(){EP=null;parts=[];},
  acts:function(){return ZS.map(function(z,i){return {i:i,nm:z.nm,t0:z.t0,d:z.d,ev:(z.ev||[]).map(function(e){return [Math.round(e[0]),e[1],e[2]];}),evB:(z.evB||[]).map(function(e){return [Math.round(e[0]),e[1],e[2]];}),F:(TXT[z.w]||[''])[0],D:(TXT[z.w]||['',''])[1]};});},
  info:function(t){var k=filmAt(Math.min(t,TRT5-1)),z=ZS[k];return {act:k,nm:z.nm,F:(TXT[z.w]||[''])[0],D:(TXT[z.w]||['',''])[1],cf:0,dD:0,roll:0,z:EP&&EP.cam&&EP.cam.z||1,yB:1,film:t};},
  dbg:function(){return {X:EP&&EP.gA,Y:EP&&EP.gB,err:window.__derr||null};},table:function(){return ZS.map(function(z){return {hA:(z.hitsA||[]).map(function(h){return [Math.round(h.t),Math.round(h.x),Math.round(h.y)];}),thr:z.thr,w:z.w,t0:Math.round(z.t0),d:Math.round(z.d),inA:z.inA,outA:z.outA,inB:z.inB,outB:z.outB,vA:z.vA,vB:z.vB};});}};
 fin5o.DECO=DECO;fin5o.cues=function(){return {tin:Math.round(tTip(FZX)),FTJ:FTJ,FTF:FTF,DIVE:DIVE,ATOM:ATOM,VIB:VIBSC};};   /* R234 : repères pour la bande son (fin-sound.js) */fin5o.SC=SC;fin5o.prepSegs=prepSegs;fin5o.locS=locS;fin5o.sim=sim;fin5o.Path=Path;
 return fin5o;
})();


 return {fin5:fin5,frame:frame,epilogue:epilogue,epReset:function(){EP=null;FT0=null;},chaseT:function(){return TRT;},total:function(){return TOT;},reset:function(){T0=null;last=0;hold=0;flashA=0;},setBase:function(b){imgBase=b;}};
})();
if(typeof window!=='undefined')window.QHERO=QHERO;
