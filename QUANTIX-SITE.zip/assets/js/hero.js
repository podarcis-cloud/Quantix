/* ══ HÉROS DE L'ACCUEIL (R188) — « L'odyssée » ══
   Une boucle de ≈ 21 s : la particule jaillit d'un vortex, traverse les onze mondes à toute allure — chaque monde est une
   figure de parcours qui lui est propre (trait tracé, rebonds, looping, pont de glace, colonne d'air et cyclone, escalier
   mécanique, gravité renversée, fronde magnétique, faille et portails, corde-tremplin, superposition) — puis tombe dans le
   bassin d'arrivée, qui s'ouvre en vortex et la renvoie au départ.
   Par moments la particule « décide » du décor (trait qui se trace devant elle, pont qui gèle, marches qui montent, gravité
   qui bascule, faille qui s'ouvre, dédoublement) : ralenti, onde, image dédoublée.
   Coordonnées : chaque monde est une scène de 360 × 480 unités (l'unité des niveaux), posées côte à côte ; la caméra suit.
   Rendu : les pièces viennent de visuals.js (VX.curve, VX.stroke, VX.ball, VX.updraft, VX.vortex) quand il est chargé ;
   fonds : dossier assets/img/hero, h01 à h11 en jpg (réductions des illustrations des mondes). Aucun texte propre : les noms des mondes
   viennent de WORLDS (levels.js) / WORLDS_EN (i18n.js). */
var QHERO=(function(){
 var UW=360,UH=480,R=10,PI=Math.PI;
 var COL=['#43D5F5','#FF8A3C','#A878FF','#8FE3FF','#A8C8E8','#E0B24C','#8C7BFF','#FF6FB5','#5CE8A8','#E8B98A','#A878FF','#9BEB4B'];
 var IMGS=[],imgBase='assets/img/hero/';
 function img(k){if(k>10)return null;if(!IMGS[k]){var im=new Image();im.decoding='async';
   im.src=(window.QHERO_IMG&&window.QHERO_IMG[k])||(imgBase+'h'+(k<9?'0':'')+(k+1)+'.jpg');IMGS[k]=im;}var I=IMGS[k];return I.complete&&I.naturalWidth?I:null;}
 function rgb(h){var n=parseInt(h.slice(1),16);return [n>>16&255,n>>8&255,n&255];}
 function rgba(h,a){var q=rgb(h);return 'rgba('+q[0]+','+q[1]+','+q[2]+','+a+')';}
 function cl(u){return u<0?0:u>1?1:u;}
 function ease(e,u){u=cl(u);switch(e){case 'in':return u*(.45+.55*u);case 'in3':return u*u*u;case 'out':return 1-(1-u)*(.45+.55*(1-u));   /* R190 : départs et arrivées jamais à vitesse nulle — le rythme coule d'un monde à l'autre */
  case 'io':return .5*u+.5*(u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2);case 'loop':return u-.07*Math.sin(2*PI*u);default:return u;}}
 function bz(a,b,c2,d,n){var o=[],i,u,v;n=n||28;for(i=0;i<=n;i++){u=i/n;v=1-u;o.push([v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c2[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c2[1]+u*u*u*d[1]]);}return o;}
 function lift(P,k){var o=[],i;for(i=0;i<P.length;i++){var a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],tx=b[0]-a[0],ty=b[1]-a[1],l=Math.hypot(tx,ty)||1,nx=ty/l,ny=-tx/l;if(ny>0){nx=-nx;ny=-ny;}o.push([P[i][0]+nx*k,P[i][1]+ny*k]);}return o;}
 function along(P,u){var L=[0],i;for(i=1;i<P.length;i++)L.push(L[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));var s=u*L[L.length-1];
  for(i=1;i<P.length;i++)if(L[i]>=s){var f=(s-L[i-1])/((L[i]-L[i-1])||1);return [P[i-1][0]+(P[i][0]-P[i-1][0])*f,P[i-1][1]+(P[i][1]-P[i-1][1])*f];}return P[P.length-1].slice();}
 /* segments : chacun part de la position courante */
 function Ln(b,d,e){return {k:'l',b:b,d:d,e:e};}
 function Jp(b,h,d,e){return {k:'j',b:b,h:h,d:d,e:e};}
 function Cv(P,d,e){return {k:'c',P:P,d:d,e:e};}
 function Fn(f,d,e){return {k:'f',f:f,d:d,e:e};}
 function Hd(d){return {k:'h',d:d};}
 function Tp(b,d){return {k:'t',b:b,d:d};}
 function sPos(s,a,u){var v=ease(s.e,u);
  if(s.k==='l')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v];
  if(s.k==='j')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v-4*s.h*v*(1-v)];
  if(s.k==='c')return along([a].concat(s.P),v);
  if(s.k==='f')return s.f(v,a);
  if(s.k==='t')return u<1?null:s.b.slice();
  return a.slice();}
 /* ——— les douze scènes ——— */
 var S1=bz([40,226],[118,330],[250,352],[362,288]);
 var LOOPC=[180,258],LOOPR=62;
 var STEPX=[40,100,160,220,280],STEPY=[410,350,290,230,170];
 var MAG=[190,250];
 var Z=[
  {w:0,start:[45,112],segs:[Hd(340),Ln([45,212],360,'in'),Cv(lift(S1,R+2),1280,'in')],
   pw:[[120,820]],ev:[[700,'hit',5.5,0]]},
  {w:1,segs:[Jp([80,384],40,400,'in'),Jp([190,322],120,500),Jp([300,240],140,500),Jp([362,172],50,280,'out')],ev:[[400,'hit',7,1],[900,'hit',7.5,1],[1400,'hit',8,1]]},
  {w:2,segs:[Ln([110,318],400,'in'),Ln([180,320],110),Fn(function(u){var a=PI/2-u*2*PI;return [LOOPC[0]+Math.cos(a)*LOOPR,LOOPC[1]+Math.sin(a)*LOOPR];},900,'loop'),Ln([362,318],300,'out')],ev:[[510,'hit',5,3],[1410,'boost']]},
  {w:3,segs:[Ln([300,338],720),Cv([[318,336],[336,326],[352,306]],170),Jp([362,290],8,80)],pw:[[0,520]],ev:[[0,'freeze'],[60,'hit',4.5,4]]},
  {w:4,segs:[Jp([150,330],24,380,'in'),Fn(function(u){return [150+22*Math.sin(u*PI*5),330-220*u];},880,'io'),Ln([214,130],150),
   Fn(function(u){var a=PI+u*2.5*PI;return [262+48*Math.cos(a),130+48*Math.sin(a)];},720,'in'),Ln([362,118],220,'out')],ev:[[380,'hit',5,0]]},
  {w:5,segs:[Jp([65,399],20,440,'in'),Jp([125,339],36,250),Jp([185,279],36,250),Jp([245,219],36,250),Jp([305,159],36,250),Jp([362,128],26,230,'out')],
   pw:[[300,1440]],ev:[[440,'hit',6,0],[690,'hit',4.5,0],[940,'hit',4.5,0],[1190,'hit',4.5,0],[1440,'hit',6.5,0]]},
  {w:6,segs:[Ln([95,41],420,'in'),Ln([270,41],620),Fn(function(u,a){return [a[0]+(362-a[0])*u,a[1]+(250-a[1])*u*u];},520)],pw:[[0,420],[1040,1560]],ev:[[420,'hit',6,0,0,1]]},
  {w:7,segs:[Ln([120,300],300,'in'),Fn(function(u){var a=2.52-u*3*PI,r=86-40*Math.sin(PI*u);return [MAG[0]+r*Math.cos(a),MAG[1]+r*Math.sin(a)];},1100,'in'),Ln([362,182],300,'out')]},
  {w:8,segs:[Ln([150,220],360,'in'),Tp([300,100],230),Fn(function(u){return [300+62*u,100+200*u*u];},420)],pw:[[0,600]],ev:[[360,'warp'],[590,'warp']]},
  {w:9,segs:[Jp([150,349],30,380,'in'),Ln([150,412],250,'out'),Jp([330,150],150,680,'out'),Ln([362,168],150)],ev:[[380,'hit',5,0],[630,'boost']]},
  {w:10,segs:[Ln([60,212],250),Fn(function(u){return [60+240*u,212+8*Math.sin(u*PI)];},900,'io'),Ln([362,252],260,'out')],pw:[[250,1150]],ev:[[1150,'collapse']]},
  {w:11,segs:[Jp([205,388],46,600,'in'),Hd(260),Fn(function(u,a){var r=18*(1-u),an=u*5*PI;return [205+r*Math.cos(an),372+(a[1]-372)*(1-u)+r*Math.sin(an)*.5];},1250,'in'),Hd(380)],ev:[[600,'hit',7,0],[2110,'flash']]}
 ];
 /* durées, départs, sorties */
 var TOT=0,i,j;
 (function(){var cur=Z[0].start.slice(),gx=0;for(i=0;i<Z.length;i++){var z=Z[i];z.t0=TOT;z.x0=i*UW;z.in=[cur[0]-(i?UW:0),cur[1]];if(!i)z.in=z.start.slice();
   var p=z.in.slice(),d=0;z.st=[];for(j=0;j<z.segs.length;j++){var s=z.segs[j];z.st.push({t:d,a:p.slice()});var q=sPos(s,p,1);p=q?q:p;d+=s.d;}
   z.d=d;z.out=p;TOT+=d;cur=[p[0],p[1]];}})();
 function local(z,lt){var k,pos=null,seg=null,su=0;for(k=0;k<z.segs.length;k++){var s=z.segs[k],st=z.st[k];if(lt<st.t+s.d||k===z.segs.length-1){su=cl((lt-st.t)/s.d);pos=sPos(s,st.a,su);seg=s;break;}}return {p:pos,s:seg,u:su};}
 /* état d'animation */
 var T0=null,last=0,hold=0,VQ=null,sq={t:0,nx:0,ny:-1},hits=[],FL0=S1.map(function(q){return [q[0],q[1]-R-2];}),BUB=[0,1,2].map(function(n){var o=[],th;for(th=0;th<14;th+=.22){var r=34*Math.exp(-.16*th);o.push([[52,182,300][n]+r*Math.cos(th*(n%2?-1:1)+n),[96,60,118][n]+r*Math.sin(th*(n%2?-1:1)+n)]);}return o;}),cam={x:0,y:240,ok:false},trail=[],parts=[],seen={},shake=0,flashA=0,lastZone=-1,label={k:-1,t:0};
 function burst(x,y,col,n,sp){for(var q=0;q<n;q++){var a=Math.random()*2*PI,v=sp*(.4+Math.random());parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1,c:col,s:.8+Math.random()*1.6});}}
 function spiral(c,x,y,Rm,al,rot,cols){c.save();c.translate(x,y);c.rotate(rot);c.globalCompositeOperation='lighter';c.lineCap='round';
  for(var a=0;a<6;a++){c.beginPath();for(var s=0;s<=40;s++){var u=s/40,r=Rm*u,an=a*PI/3+u*3.2;var px=Math.cos(an)*r,py=Math.sin(an)*r*.62;s?c.lineTo(px,py):c.moveTo(px,py);}
   c.strokeStyle=rgba(cols[a%cols.length],al*.8);c.lineWidth=2.2;c.stroke();}
  var g=c.createRadialGradient(0,0,0,0,0,Rm*.5);g.addColorStop(0,'rgba(241,244,246,'+al+')');g.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*.5,0,2*PI);c.fill();c.restore();}
 function wall(c,P,mat,col){var V=window.VX;if(V&&V.curve&&mat!=null){try{V.curve(c,P,mat,{noHang:1});return;}catch(x){}}
  c.save();c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.35);c.lineWidth=7;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=col;c.lineWidth=2;c.stroke();c.restore();}
 function glowLine(c,P,col,w,al){c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.25*al);c.lineWidth=w*4;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=rgba(col,al);c.lineWidth=w;c.stroke();c.restore();}
 function gear(c,x,y,r,rot,col,al){c.save();c.translate(x,y);c.rotate(rot);c.strokeStyle=rgba(col,al);c.lineWidth=1.4;c.beginPath();
  for(var k=0;k<=40;k++){var a=k/40*2*PI,rr=r*(k%4<2?1:.84);k?c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):c.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}c.stroke();
  c.beginPath();c.arc(0,0,r*.32,0,2*PI);c.stroke();c.restore();}
 /* ——— vortex d'arrivée : disque d'accrétion de matière lumineuse (grains des onze mondes), horizon sombre, anneau de photons,
    arc de lentille gravitationnelle au-dessus, bras en pointillés, arcs électriques — la langue des murs et des chocs du jeu ——— */
 function vortexQ(c,x,y,Rm,al,dt,suck){var n,q,a0,rr,TL=-.18;
  if(!VQ){VQ=[];for(n=0;n<340;n++)VQ.push({r:Math.random(),a:Math.random()*2*PI,c:COL[n%12],w:.5+Math.random()*.9});}
  c.save();c.translate(x,y);c.rotate(TL);c.lineCap='round';
  var Rh=Rm*.15,g=c.createRadialGradient(0,0,Rh,0,0,Rm*1.15);g.addColorStop(0,'rgba(140,123,255,'+(.32*al)+')');g.addColorStop(.45,'rgba(77,215,255,'+(.10*al)+')');g.addColorStop(1,'rgba(5,7,13,0)');
  c.save();c.scale(1,.54);c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*1.15,0,2*PI);c.fill();c.restore();   /* halo sans bord : le dégradé s'éteint avant l'ellipse */
  function grains(front){c.globalCompositeOperation='lighter';for(n=0;n<VQ.length;n++){q=VQ[n];
    if(front===null){var om=.0021/Math.pow(.12+q.r,1.5);q.a+=om*dt;q.r-=dt*.00009*(1+suck*4)*(1.2-q.r);if(q.r<.03){q.r=1;q.a=Math.random()*2*PI;}continue;}
    var s=Math.sin(q.a);if((s>0)!==front)continue;rr=Rh*1.15+q.r*(Rm-Rh*1.15);a0=q.a-Math.min(1.1,.16/Math.pow(.12+q.r,1.2));
    var lum=al*(.18+.75*(1-q.r))*(front?1:.55);c.strokeStyle=rgba(q.r<.22?'#F1F4F6':q.c,lum);c.lineWidth=q.w*(1.3-q.r*.7);
    c.beginPath();c.ellipse(0,0,rr,rr*.42,0,a0,q.a);c.stroke();}}
  grains(null);grains(false);
  /* bras en pointillés qui s'enroulent */
  c.globalCompositeOperation='lighter';for(n=0;n<4;n++){c.beginPath();for(var s2=0;s2<=46;s2++){var u=s2/46,th=n*PI/2-u*4.2+now0*.0011,r2=Rh*1.2+(Rm*.95-Rh*1.2)*Math.pow(u,1.25);var px=Math.cos(th)*r2,py=Math.sin(th)*r2*.42;s2?c.lineTo(px,py):c.moveTo(px,py);}
   c.setLineDash([1.2,5]);c.lineDashOffset=now0*.03;c.strokeStyle=rgba(COL[[0,2,7,11][n]],.55*al);c.lineWidth=1.1;c.stroke();}c.setLineDash([]);
  /* horizon et anneau de photons */
  c.globalCompositeOperation='source-over';c.fillStyle='rgba(3,4,8,'+(.96*al)+')';c.beginPath();c.arc(0,0,Rh,0,2*PI);c.fill();
  c.globalCompositeOperation='lighter';
  for(n=0;n<3;n++){c.strokeStyle=n?rgba(n===1?'#A878FF':'#43D5F5',(.5-.12*n)*al):'rgba(241,244,246,'+(.95*al)+')';c.lineWidth=n?3.5+n*3:1.3;c.beginPath();c.arc(0,0,Rh+.5+n*1.2,0,2*PI);c.stroke();}
  /* lentille : l'arrière du disque, courbé par-dessus l'horizon */
  for(n=0;n<7;n++){var ra=Rh*1.25+n*Rh*.16;c.strokeStyle=rgba(COL[(n*3)%12],(.42-.04*n)*al);c.lineWidth=.9;c.beginPath();c.ellipse(0,-Rh*.08,ra,ra*.92,0,PI*1.06,PI*1.94);c.stroke();}
  grains(true);
  /* arcs électriques qui crépitent sur le bord */
  if(Math.random()<.35*al){var an=Math.random()*2*PI,len=Rh*(.8+Math.random()*1.4),px2=Math.cos(an)*Rh,py2=Math.sin(an)*Rh;c.strokeStyle='rgba(241,244,246,'+(.8*al)+')';c.lineWidth=.8;c.beginPath();c.moveTo(px2,py2);
   for(n=1;n<=6;n++){var f=n/6,jt=(Math.random()-.5)*6;c.lineTo(px2+Math.cos(an)*len*f-Math.sin(an)*jt,py2+Math.sin(an)*len*f*.6+Math.cos(an)*jt);}c.stroke();}
  c.restore();}
 var now0=0,dtD=16;
 /* ——— décors de scène (coordonnées locales) ——— */
 function deco(c,k,lt,B,T){var z=Z[k],col=COL[z.w],V=window.VX,n,q,u,x,y,p;
  switch(k){
  case 0:{ /* Atelier : vortex de départ, trait tracé par la particule */
   if(lt<900){var vc=1-ease('io',cl(lt/900));vortexQ(c,45,112,24+150*vc,vc,dtD,0);}   /* le vortex d'arrivée se referme au départ : la boucle */
   u=cl((lt-140)/560);n=Math.max(2,Math.round(u*(S1.length-1))+1);var sub=S1.slice(0,n);
   if(V&&V.flow){c.save();c.globalAlpha=.75;try{V.flow(c,FL0);}catch(x){}c.restore();}   /* poussière d'étoile : le chemin de la machine */
   if(V&&V.stroke)V.stroke(c,sub,0,1);else glowLine(c,sub,col,2.4,1);
   if(u>0&&u<1){q=sub[sub.length-1];var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],16);g.addColorStop(0,'rgba(241,244,246,.95)');g.addColorStop(.3,rgba(col,.5));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],16,0,2*PI);c.fill();}
   break;}
  case 1:{ /* Fonderie : plaques de rebond, sol de lave, braises */
   var g2=c.createLinearGradient(0,430,0,480);g2.addColorStop(0,'rgba(255,82,82,0)');g2.addColorStop(1,'rgba(255,120,40,.55)');c.fillStyle=g2;c.fillRect(-20,430,400,60);
   wall(c,[[0,454],[360,454]],2,'#FF5252');wall(c,[[46,404],[116,392]],1,col);wall(c,[[158,340],[222,328]],1,col);wall(c,[[270,258],[332,246]],1,col);
   c.save();c.globalCompositeOperation='lighter';for(n=0;n<3;n++){var bb=BUB[n],fb=((lt*.0007+n*.37)%1.25),nb=Math.min(bb.length,Math.round(fb*bb.length));   /* chambre à bulles : traces en spirale */
    for(q=0;q<nb;q++){c.fillStyle=rgba(q%3?'#FFAA3C':'#F1F4F6',.12+.5*q/bb.length);c.beginPath();c.arc(bb[q][0],bb[q][1],.7+(q%3===0?.5:0),0,2*PI);c.fill();}}c.restore();
   for(n=0;n<26;n++){x=(n*53+lt*.012*(1+n%3))%360;y=470-((lt*.06*(1+n%4)+n*37)%470);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.55*(1-y/480)+.1);c.fillRect(x,y,1.6,1.6);}
   break;}
  case 2:{ /* Chaîne : tapis d'élan et looping */
   wall(c,[[-14,186],[118,334]],3,col);var ring=[];for(n=0;n<=48;n++){var a=n/48*2*PI;ring.push([LOOPC[0]+Math.cos(a)*(LOOPR+R+3),LOOPC[1]+Math.sin(a)*(LOOPR+R+3)]);}
   wall(c,ring,3,col);wall(c,[[180,334],[372,330]],3,col);
   for(n=0;n<14;n++){x=((n*26+lt*.25)%390)-10;c.strokeStyle=rgba(col,.5);c.lineWidth=1;c.beginPath();c.moveTo(x,344);c.lineTo(x+6,344);c.stroke();}
   break;}
  case 3:{ /* Glacier : gouffre, pont qui gèle devant la particule, tremplin */
   wall(c,[[-10,350],[72,350]],4,col);c.fillStyle='rgba(5,7,13,.55)';c.fillRect(72,352,216,140);
   for(n=0;n<9;n++){x=80+n*24;c.strokeStyle=rgba(col,.45);c.beginPath();c.moveTo(x,352);c.lineTo(x+6,380+(n%3)*14);c.lineTo(x+12,352);c.stroke();}
   u=cl(lt/460);var br=[];for(n=0;n<=24;n++){var f=n/24*u;br.push([70+230*f,350+10*Math.sin(f*PI)]);}if(u>0)wall(c,br,4,col);
   wall(c,[[300,358],[330,352],[352,320],[356,306]],4,col);wall(c,[[300,360],[300,470]],0,col);
   for(n=0;n<30;n++){x=(n*47+lt*.01*(n%5))%360;y=(n*61+lt*.04*(1+n%3))%480;c.fillStyle='rgba(241,244,246,.5)';c.fillRect(x,y,1.3,1.3);}
   break;}
  case 4:{ /* Soufflerie : colonne d'air, cyclone */
   if(V&&V.updraft)V.updraft(c,[110,60,80,420]);else{c.fillStyle=rgba(col,.08);c.fillRect(110,60,80,420);}
   if(V&&V.vortex)V.vortex(c,[262,130,58,1]);else spiral(c,262,130,58,.6,lt*.01,[col]);
   for(n=0;n<18;n++){y=(n*31+lt*.3)%480;x=120+(n*17)%60;c.strokeStyle=rgba(col,.35);c.beginPath();c.moveTo(x,480-y);c.lineTo(x,480-y-14);c.stroke();}
   break;}
  case 5:{ /* Mécanique : engrenages, marches qui montent en rythme */
   gear(c,300,384,42,lt*.002,col,.35);gear(c,70,150,28,-lt*.003,col,.3);gear(c,206,86,20,lt*.004,col,.3);
   for(n=0;n<5;n++){var tn=300+n*250-180,rise=ease('out',cl((lt-tn)/200)),yy=STEPY[n]+(1-rise)*140;
    glowLine(c,[[STEPX[n],yy],[STEPX[n]+50,yy]],col,2.2,.9);glowLine(c,[[STEPX[n]+25,yy],[STEPX[n]+25,480]],col,1,.35);}
   break;}
  case 6:{ /* Gravité : plafond porteur, champ renversé */
   glowLine(c,[[40,28],[310,28]],col,2.4,.95);
   if(V&&V.well){c.save();c.globalAlpha=.55;V.well(c,[180,250,1100,26]);c.restore();}   /* puits : l'espace-temps courbé */
   for(n=0;n<24;n++){x=(n*41)%360;y=(n*67+lt*.03)%480;c.fillStyle=rgba(col,.35);c.fillRect(x,480-y,1.5,1.5);}
   break;}
  case 7:{ /* Magnétisme : aimant, anneaux de champ, gouttes de ferrofluide */
   for(n=1;n<=4;n++){c.strokeStyle=rgba(col,.32/n+.05*Math.sin(lt*.006+n));c.lineWidth=1;c.setLineDash([3,5]);c.lineDashOffset=-lt*.02*n;c.beginPath();c.arc(MAG[0],MAG[1],n*28,0,2*PI);c.stroke();}c.setLineDash([]);
   for(n=0;n<9;n++){var a2=n/9*2*PI+lt*.0015,r2=34+8*Math.sin(lt*.004+n);c.fillStyle=rgba(col,.35);c.beginPath();c.arc(MAG[0]+Math.cos(a2)*r2,MAG[1]+Math.sin(a2)*r2,3+2*Math.sin(n+lt*.005),0,2*PI);c.fill();}
   var g3=c.createRadialGradient(MAG[0],MAG[1],0,MAG[0],MAG[1],22);g3.addColorStop(0,'rgba(255,220,240,.95)');g3.addColorStop(1,rgba(col,0));c.fillStyle=g3;c.beginPath();c.arc(MAG[0],MAG[1],22,0,2*PI);c.fill();
   break;}
  case 8:{ /* Faille : la particule ouvre la faille, portails */
   u=cl(lt/360);c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.9);c.lineWidth=1.6;c.beginPath();
   for(n=0;n<=20;n++){y=140+n*8;x=150+(n%2?4:-4)*Math.sin(lt*.03+n);n?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();
   var op=ease('out',cl((lt-200)/220))*(lt<900?1:cl(1-(lt-900)/300));if(op>0){c.strokeStyle=rgba(col,op);c.lineWidth=2.2;c.beginPath();c.ellipse(150,220,8+26*op,62*op,0,0,2*PI);c.stroke();}
   var ob=ease('out',cl((lt-500)/200))*cl(1-(lt-1100)/300);if(ob>0){c.beginPath();c.ellipse(300,100,8+24*ob,30*ob+8,0,0,2*PI);c.stroke();}
   c.restore();if(V&&V.rift){c.save();c.globalAlpha=.8;V.rift(c,[150,220,300,100,70]);c.restore();}   /* corral d'atomes aux deux bouts de la faille */
   for(n=0;n<6;n++){y=(lt*.2+n*80)%480;c.fillStyle=rgba(col,.08);c.fillRect(0,y,360,1);}
   break;}
  case 9:{ /* Filaments : corde-tremplin qui ploie, harpe */
   var land=380,go=630;var sx=150,sy=360;if(lt>=land&&lt<=go&&B)sy=Math.max(360,B[1]+R);else if(lt>go){sy=360+52*Math.exp(-(lt-go)/160)*Math.cos((lt-go)*.06);}
   glowLine(c,[[50,360],[sx,sy],[250,360]],col,1.6,.95);
   for(n=0;n<6;n++){x=270+n*14;var vib=lt>go+150?4*Math.exp(-(lt-go-150-n*40)/260)*Math.sin(lt*.08+n):0;glowLine(c,[[x,60],[x+vib,150],[x,240]],col,1,.6);}
   break;}
  case 10:{ /* Quantique : dédoublement, détecteur */
   if(V&&V.qsup&&V.qdet){try{V.qsup(c,[22,190,44,44],lt*.06);V.qdet(c,[300,220,24,0],true,lt*.06,null);}catch(x){}for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}break;}
   var D=[300,220],ring2=6+4*Math.sin(lt*.01);c.strokeStyle='rgba(255,216,90,.8)';c.lineWidth=1.4;c.beginPath();c.arc(D[0],D[1],18+ring2,0,2*PI);c.stroke();
   c.beginPath();c.moveTo(D[0]-30,D[1]);c.lineTo(D[0]-12,D[1]);c.moveTo(D[0]+12,D[1]);c.lineTo(D[0]+30,D[1]);c.moveTo(D[0],D[1]-30);c.lineTo(D[0],D[1]-12);c.moveTo(D[0],D[1]+12);c.lineTo(D[0],D[1]+30);c.stroke();
   for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}
   break;}
  case 11:{ /* Arrivée : bassin, puis vortex */
   for(n=0;n<70;n++){x=(n*97)%360;y=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.25+.35*Math.sin(lt*.004+n*1.7))*.8);c.fillRect(x,y,1.3,1.3);}   /* ciel des onze mondes */
   glowLine(c,[[150,338],[150,398],[260,398],[260,338]],'#9BEB4B',2.2,.95*(1-.75*cl((lt-640)/600)));
   var vo=cl((lt-640)/800);if(vo>0)vortexQ(c,205,372,(30+175*ease('out',vo))*(1+2.2*ease('io',cl((lt-1700)/790))),ease('out',vo),dtD,lt>860?1:0);   /* le vortex s'élargit et engloutit l'image */
   break;}
  }
 }
 /* ——— image ——— */
 function frame(c,w,h,now,opt){
  now0=now;opt=opt||{};if(T0===null){T0=now;for(var pk=0;pk<11;pk++)img(pk);}var dt=Math.max(0,Math.min(60,now-(last||now)));last=now;dtD=dt;if(hold>0){T0+=Math.min(hold,dt);hold-=dt;}   /* arrêt sur image au choc fort */
  var t=(now-T0)%TOT,k=0;while(k<Z.length-1&&t>=Z[k].t0+Z[k].d)k++;
  var z=Z[k],lt=t-z.t0,LC=local(z,lt),B=LC.p,vis=!!B;if(!B)B=z.out;
  if(k!==lastZone){if(k===0){trail=[];cam.ok=false;seen={};}lastZone=k;label={k:k,t:now};}
  var gx=z.x0+B[0],gy=B[1];
  /* évènements */
  var V0=window.VX;(z.ev||[]).forEach(function(e,ei){var key=k+':'+ei;if(lt>=e[0]&&!seen[key]){seen[key]=1;var cc=COL[z.w];
    if(e[1]==='hit'){var hv=e[2]||5,hn=[e[4]||0,e[5]==null?-1:e[5]],ix=gx-hn[0]*R,iy=gy-hn[1]*R;   /* choc : bibliothèque d'impacts du jeu (poussière, arcs, onde, étoile), accentuée */
     if(V0&&V0.impact){V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv,mat:e[3]||0});if(hv>=6)V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv*.7,mat:e[3]||0});}
     burst(ix,iy,cc,10+hv*2,1.2+hv*.25);hits.push({x:ix,y:iy,c:cc,l:1,v:hv,n:hn});sq={t:1,nx:hn[0],ny:hn[1],k:Math.min(.42,hv/16)};shake=Math.max(shake,1+hv*.5);}
    else if(e[1]==='boost'){burst(gx,gy,cc,22,2.4);}
    else if(e[1]==='warp'){burst(gx,gy,cc,30,2.8);flashA=Math.max(flashA,.12);}
    else if(e[1]==='freeze'){burst(gx+40,gy,'#F1F4F6',24,1.2);}
    else if(e[1]==='collapse'){burst(gx,gy,'#FFD85A',36,2.6);flashA=Math.max(flashA,.15);}
    }});
  var power=(z.pw||[]).some(function(p){return lt>=p[0]&&lt<=p[1];});
  /* caméra */
  var tx=gx+40,ty=240+(gy-240)*.3,zoom=power?1.12:1,roll=0;
  if(k===6){roll=lt<420?PI*ease('io',lt/420):lt<1040?PI:PI+PI*ease('io',(lt-1040)/520);}
  if(!cam.ok){cam.x=tx;cam.y=ty;cam.z=zoom;cam.ok=true;}
  var fk=1-Math.pow(.0025,dt/1000);cam.x+=(tx-cam.x)*Math.min(1,fk*4);cam.y+=(ty-cam.y)*Math.min(1,fk*2);cam.z+=(zoom-cam.z)*Math.min(1,fk*3);
  var s=Math.min(w/UW,h/UH)*cam.z;
  /* fonds : illustration du monde, fondu au passage d'une frontière */
  c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  var f=cam.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0;
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){var kk=o[0],a=o[1];if(a<=0.01||kk<0||kk>11)return;var I=img(Z[kk].w);
   if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.12,dh=dw/ir,px=-(f-kk-.5)*w*.18;c.globalAlpha=a*.6;c.drawImage(I,(w-dw)/2+px,(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[Z[kk].w],.22*a));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}});
  var vg=c.createRadialGradient(w/2,h*.48,h*.1,w/2,h*.48,h*.85);vg.addColorStop(0,'rgba(5,7,13,.38)');vg.addColorStop(1,'rgba(5,7,13,.9)');c.fillStyle=vg;c.fillRect(0,0,w,h);
  /* monde */
  var sh=shake>0?shake:0;shake*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.rotate(roll);c.scale(s,s);c.translate(-cam.x,-cam.y);
  for(var kk=Math.max(0,k-1);kk<=Math.min(Z.length-1,k+1);kk++){var zz=Z[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);try{deco(c,kk,llt,kk===k?B:null,t);}catch(x){}c.restore();}
  /* chocs : éclair local + onde double */
  c.save();c.globalCompositeOperation='lighter';for(i=hits.length-1;i>=0;i--){var hh=hits[i];hh.l-=dt/520;if(hh.l<=0){hits.splice(i,1);continue;}var ra=(1-hh.l)*(26+hh.v*7),gg=c.createRadialGradient(hh.x,hh.y,0,hh.x,hh.y,18+hh.v*3);
   gg.addColorStop(0,'rgba(241,244,246,'+(.8*hh.l*hh.l)+')');gg.addColorStop(.35,rgba(hh.c,.45*hh.l));gg.addColorStop(1,rgba(hh.c,0));c.fillStyle=gg;c.beginPath();c.arc(hh.x,hh.y,18+hh.v*3,0,2*PI);c.fill();
   c.strokeStyle=rgba(hh.c,.7*hh.l);c.lineWidth=1.6*hh.l+.4;c.beginPath();c.ellipse(hh.x,hh.y,ra,ra*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();c.strokeStyle='rgba(241,244,246,'+(.5*hh.l)+')';c.lineWidth=.8;c.beginPath();c.ellipse(hh.x,hh.y,ra*.62,ra*.62*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();}c.restore();
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}
  /* traîne */
  if(vis){trail.push([gx,gy]);if(trail.length>26)trail.shift();}
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  for(i=1;i<trail.length;i++){var a=i/trail.length;c.strokeStyle=rgba(COL[z.w],a*.55);c.lineWidth=R*1.6*a;c.beginPath();c.moveTo(trail[i-1][0],trail[i-1][1]);c.lineTo(trail[i][0],trail[i][1]);c.stroke();}
  c.restore();
  /* éclats */
  c.save();c.globalCompositeOperation='lighter';for(i=parts.length-1;i>=0;i--){var p=parts[i];p.x+=p.vx*dt/16;p.y+=p.vy*dt/16;p.vx*=.96;p.vy*=.96;p.l-=dt/700;if(p.l<=0){parts.splice(i,1);continue;}
   c.fillStyle=rgba(p.c,p.l*.9);c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s);}c.restore();
  /* particule (dédoublée dans le monde quantique) */
  var V=window.VX;sq.t=Math.max(0,sq.t-dt/240);var sk=sq.t>0?(sq.k||.3)*Math.sin(sq.t*PI)*(sq.t):0;
  var drawB=function(x,y,al,sc){c.save();c.globalAlpha=al;c.translate(x,y);if(sk>0){var an=Math.atan2(sq.ny,sq.nx);c.rotate(an);c.scale(1-sk,1+sk*.7);c.rotate(-an);}if(V&&V.ball)V.ball(c,0,0,now*.004,R*(sc||1));else{c.fillStyle='#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();};
  if(k===10&&LC.s===z.segs[1]){var uu=ease('io',LC.u),up=bz([60,212],[150,90],[240,110],[300,220],40),dn=bz([60,212],[150,350],[240,330],[300,220],40),pa=along(up,uu),pb=along(dn,uu);
   c.save();c.strokeStyle='rgba(166,120,255,.45)';c.lineWidth=1;c.beginPath();for(i=0;i<=16;i++){var f2=i/16;c.lineTo(z.x0+pa[0]+(pb[0]-pa[0])*f2+6*Math.sin(f2*PI*6+now*.02),pa[1]+(pb[1]-pa[1])*f2);}c.stroke();c.restore();
   drawB(z.x0+pa[0],pa[1],.75);drawB(z.x0+pb[0],pb[1],.75);}
  else if(vis){var sc=k===11&&lt>860?Math.max(.15,1-(lt-860)/1250):1;
   if(power){c.save();c.globalCompositeOperation='lighter';drawB(gx-2.5,gy,.35,sc);drawB(gx+2.5,gy,.35,sc);c.restore();
    var pr=(now%600)/600;c.strokeStyle=rgba(COL[z.w],.6*(1-pr));c.lineWidth=1.2;c.beginPath();c.arc(gx,gy,R+pr*40,0,2*PI);c.stroke();}
   drawB(gx,gy,1,sc);}
  c.restore();
  /* passage de boucle : l'image plonge dans l'horizon, puis le départ émerge (aucun éclair) */
  var iris=k===11?ease('io',cl((lt-(z.d-620))/620)):k===0?1-ease('io',cl(lt/720)):0;if(iris>0){c.fillStyle='rgba(3,4,8,'+iris.toFixed(3)+')';c.fillRect(0,0,w,h);}
  /* flash, étiquette du monde */
  if(flashA>0){c.fillStyle='rgba(241,244,246,'+(flashA*.7)+')';c.fillRect(0,0,w,h);flashA=Math.max(0,flashA-dt/380);}
  if(opt.labels!==false&&z.w<11){var la=cl((now-label.t)/250)*cl(1-(now-label.t-1300)/400);if(la>0){var nm='';try{nm=typeof WN==='function'?WN(z.w):(typeof WORLDS!=='undefined'?WORLDS[z.w].n:'');}catch(x){}
    c.save();c.globalAlpha=la;c.font='500 10px "JetBrains Mono",ui-monospace,monospace';c.fillStyle=COL[z.w];c.textBaseline='alphabetic';
    var y0=opt.labelY||h-18,x0=16,tx0=(z.w+1<10?'0':'')+(z.w+1)+' · '+String(nm).toUpperCase();if(opt.labelC){c.textAlign='center';x0=w/2;}c.fillText(tx0,x0,y0);
    c.fillStyle=rgba(COL[z.w],.6);if(opt.labelC)c.fillRect(x0-30*la,y0+6,60*la,1);else c.fillRect(x0,y0+6,60*la,1);c.restore();}}
  return {world:z.w,power:power};
 }
 return {frame:frame,total:function(){return TOT;},reset:function(){T0=null;last=0;hold=0;flashA=0;},setBase:function(b){imgBase=b;}};
})();
if(typeof window!=='undefined')window.QHERO=QHERO;
