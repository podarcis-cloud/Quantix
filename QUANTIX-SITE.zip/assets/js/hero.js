/* ══ HÉROS DE L'ACCUEIL (R188) — « L'odyssée » ══
   Une boucle de ≈ 21 s : la particule jaillit d'un vortex, traverse les onze mondes à toute allure — chaque monde est une
   figure de parcours qui lui est propre (trait tracé, rebonds, looping, pont de glace, colonne d'air et cyclone, escalier
   mécanique, gravité renversée, fronde magnétique, faille et portails, corde-tremplin, superposition) — puis tombe dans le
   bassin d'arrivée, qui s'ouvre en vortex et la renvoie au départ.
   Par moments la particule « décide » du décor (trait qui se trace devant elle, pont qui gèle, marches qui montent, gravité
   qui bascule, faille qui s'ouvre, dédoublement) : ralenti, onde, image dédoublée.
   Coordonnées : chaque monde est une scène de 360 × 480 unités (l'unité des niveaux), posées côte à côte ; la caméra suit.
   Rendu : les pièces viennent de visuals.js (VX.curve, VX.stroke, VX.ball, VX.updraft, VX.vortex) quand il est chargé ;
   fonds : dossier assets/img/hero, h01 à h11 en jpg (réductions des illustrations des mondes). Aucun texte propre : les noms des mondes
   viennent de WORLDS (levels.js) / WORLDS_EN (i18n.js). */
var QHERO=(function(){
 var UW=360,UH=480,R=10,PI=Math.PI;
 var COL=['#43D5F5','#FF8A3C','#A878FF','#8FE3FF','#A8C8E8','#E0B24C','#8C7BFF','#FF6FB5','#5CE8A8','#E8B98A','#A878FF','#9BEB4B'];
 var IMGS=[],imgBase='assets/img/hero/';
 function img(k){if(k>10)return null;if(!IMGS[k]){var im=new Image();im.decoding='async';
   im.src=(window.QHERO_IMG&&window.QHERO_IMG[k])||(imgBase+'h'+(k<9?'0':'')+(k+1)+'.jpg');IMGS[k]=im;}var I=IMGS[k];return I.complete&&I.naturalWidth?I:null;}
 function rgb(h){var n=parseInt(h.slice(1),16);return [n>>16&255,n>>8&255,n&255];}
 function rgba(h,a){var q=rgb(h);return 'rgba('+q[0]+','+q[1]+','+q[2]+','+a+')';}
 function cl(u){return u<0?0:u>1?1:u;}
 function ease(e,u){u=cl(u);switch(e){case 'in':return u*(.45+.55*u);case 'in3':return u*u*u;case 'out':return 1-(1-u)*(.45+.55*(1-u));   /* R190 : départs et arrivées jamais à vitesse nulle — le rythme coule d'un monde à l'autre */
  case 'io':return .5*u+.5*(u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2);case 'loop':return u-.07*Math.sin(2*PI*u);default:return u;}}
 function bz(a,b,c2,d,n){var o=[],i,u,v;n=n||28;for(i=0;i<=n;i++){u=i/n;v=1-u;o.push([v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c2[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c2[1]+u*u*u*d[1]]);}return o;}
 function lift(P,k){var o=[],i;for(i=0;i<P.length;i++){var a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],tx=b[0]-a[0],ty=b[1]-a[1],l=Math.hypot(tx,ty)||1,nx=ty/l,ny=-tx/l;if(ny>0){nx=-nx;ny=-ny;}o.push([P[i][0]+nx*k,P[i][1]+ny*k]);}return o;}
 function along(P,u){var L=[0],i;for(i=1;i<P.length;i++)L.push(L[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]));var s=u*L[L.length-1];
  for(i=1;i<P.length;i++)if(L[i]>=s){var f=(s-L[i-1])/((L[i]-L[i-1])||1);return [P[i-1][0]+(P[i][0]-P[i-1][0])*f,P[i-1][1]+(P[i][1]-P[i-1][1])*f];}return P[P.length-1].slice();}
 /* segments : chacun part de la position courante */
 function Ln(b,d,e){return {k:'l',b:b,d:d,e:e};}
 function Jp(b,h,d,e){return {k:'j',b:b,h:h,d:d,e:e};}
 function Cv(P,d,e){return {k:'c',P:P,d:d,e:e};}
 function Fn(f,d,e){return {k:'f',f:f,d:d,e:e};}
 function Hd(d){return {k:'h',d:d};}
 function Tp(b,d){return {k:'t',b:b,d:d};}
 function sPos(s,a,u){var v=ease(s.e,u);
  if(s.k==='l')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v];
  if(s.k==='j')return [a[0]+(s.b[0]-a[0])*v,a[1]+(s.b[1]-a[1])*v-4*s.h*v*(1-v)];
  if(s.k==='c')return along([a].concat(s.P),v);
  if(s.k==='f')return s.f(v,a);
  if(s.k==='t')return u<1?null:s.b.slice();
  return a.slice();}
 /* ——— les douze scènes ——— */
 var S1=bz([40,226],[118,330],[250,352],[362,288]);
 var LOOPC=[180,258],LOOPR=62;
 var STEPX=[40,100,160,220,280],STEPY=[410,350,290,230,170];
 var MAG=[190,250];
 var Z=[
  {w:0,start:[45,112],segs:[Hd(340),Ln([45,212],360,'in'),Cv(lift(S1,R+2),1280,'in')],
   pw:[[120,820]],ev:[[700,'hit',5.5,0]]},
  {w:1,segs:[Jp([80,384],40,400,'in'),Jp([190,322],120,500),Jp([300,240],140,500),Jp([362,172],50,280,'out')],ev:[[400,'hit',7,1],[900,'hit',7.5,1],[1400,'hit',8,1]]},
  {w:2,segs:[Ln([110,318],400,'in'),Ln([180,320],110),Fn(function(u){var a=PI/2-u*2*PI;return [LOOPC[0]+Math.cos(a)*LOOPR,LOOPC[1]+Math.sin(a)*LOOPR];},900,'loop'),Ln([362,318],300,'out')],ev:[[510,'hit',5,3],[1410,'boost']]},
  {w:3,segs:[Ln([300,338],720),Cv([[318,336],[336,326],[352,306]],170),Jp([362,290],8,80)],pw:[[0,520]],ev:[[0,'freeze'],[60,'hit',4.5,4]]},
  {w:4,segs:[Jp([150,330],24,380,'in'),Fn(function(u){return [150+22*Math.sin(u*PI*5),330-220*u];},880,'io'),Ln([214,130],150),
   Fn(function(u){var a=PI+u*2.5*PI;return [262+48*Math.cos(a),130+48*Math.sin(a)];},720,'in'),Ln([362,118],220,'out')],ev:[[380,'hit',5,0]]},
  {w:5,segs:[Jp([65,399],20,440,'in'),Jp([125,339],36,250),Jp([185,279],36,250),Jp([245,219],36,250),Jp([305,159],36,250),Jp([362,128],26,230,'out')],
   pw:[[300,1440]],ev:[[440,'hit',6,0],[690,'hit',4.5,0],[940,'hit',4.5,0],[1190,'hit',4.5,0],[1440,'hit',6.5,0]]},
  {w:6,segs:[Ln([95,41],420,'in'),Ln([270,41],620),Fn(function(u,a){return [a[0]+(362-a[0])*u,a[1]+(250-a[1])*u*u];},520)],pw:[[0,420],[1040,1560]],ev:[[420,'hit',6,0,0,1]]},
  {w:7,segs:[Ln([120,300],300,'in'),Fn(function(u){var a=2.52-u*3*PI,r=86-40*Math.sin(PI*u);return [MAG[0]+r*Math.cos(a),MAG[1]+r*Math.sin(a)];},1100,'in'),Ln([362,182],300,'out')]},
  {w:8,segs:[Ln([150,220],360,'in'),Tp([300,100],230),Fn(function(u){return [300+62*u,100+200*u*u];},420)],pw:[[0,600]],ev:[[360,'warp'],[590,'warp']]},
  {w:9,segs:[Jp([150,349],30,380,'in'),Ln([150,412],250,'out'),Jp([330,150],150,680,'out'),Ln([362,168],150)],ev:[[380,'hit',5,0],[630,'boost']]},
  {w:10,segs:[Ln([60,212],250),Fn(function(u){return [60+240*u,212+8*Math.sin(u*PI)];},900,'io'),Ln([362,252],260,'out')],pw:[[250,1150]],ev:[[1150,'collapse']]},
  {w:11,segs:[Jp([205,388],46,600,'in'),Hd(260),Fn(function(u,a){var r=18*(1-u),an=u*5*PI;return [205+r*Math.cos(an),372+(a[1]-372)*(1-u)+r*Math.sin(an)*.5];},1250,'in'),Hd(380)],ev:[[600,'hit',7,0],[2110,'flash']]}
 ];
 /* durées, départs, sorties */
 var TOT=0,i,j;
 (function(){var cur=Z[0].start.slice(),gx=0;for(i=0;i<Z.length;i++){var z=Z[i];z.t0=TOT;z.x0=i*UW;z.in=[cur[0]-(i?UW:0),cur[1]];if(!i)z.in=z.start.slice();
   var p=z.in.slice(),d=0;z.st=[];for(j=0;j<z.segs.length;j++){var s=z.segs[j];z.st.push({t:d,a:p.slice()});var q=sPos(s,p,1);p=q?q:p;d+=s.d;}
   z.d=d;z.out=p;TOT+=d;cur=[p[0],p[1]];}})();
 function local(z,lt){var k,pos=null,seg=null,su=0;for(k=0;k<z.segs.length;k++){var s=z.segs[k],st=z.st[k];if(lt<st.t+s.d||k===z.segs.length-1){su=cl((lt-st.t)/s.d);pos=sPos(s,st.a,su);seg=s;break;}}return {p:pos,s:seg,u:su};}
 /* état d'animation */
 var T0=null,last=0,hold=0,VQ=null,sq={t:0,nx:0,ny:-1},hits=[],FL0=S1.map(function(q){return [q[0],q[1]-R-2];}),BUB=[0,1,2].map(function(n){var o=[],th;for(th=0;th<14;th+=.22){var r=34*Math.exp(-.16*th);o.push([[52,182,300][n]+r*Math.cos(th*(n%2?-1:1)+n),[96,60,118][n]+r*Math.sin(th*(n%2?-1:1)+n)]);}return o;}),cam={x:0,y:240,ok:false},trail=[],parts=[],seen={},shake=0,flashA=0,lastZone=-1,label={k:-1,t:0};
 function burst(x,y,col,n,sp){for(var q=0;q<n;q++){var a=Math.random()*2*PI,v=sp*(.4+Math.random());parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1,c:col,s:.8+Math.random()*1.6});}}
 function spiral(c,x,y,Rm,al,rot,cols){c.save();c.translate(x,y);c.rotate(rot);c.globalCompositeOperation='lighter';c.lineCap='round';
  for(var a=0;a<6;a++){c.beginPath();for(var s=0;s<=40;s++){var u=s/40,r=Rm*u,an=a*PI/3+u*3.2;var px=Math.cos(an)*r,py=Math.sin(an)*r*.62;s?c.lineTo(px,py):c.moveTo(px,py);}
   c.strokeStyle=rgba(cols[a%cols.length],al*.8);c.lineWidth=2.2;c.stroke();}
  var g=c.createRadialGradient(0,0,0,0,0,Rm*.5);g.addColorStop(0,'rgba(241,244,246,'+al+')');g.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*.5,0,2*PI);c.fill();c.restore();}
 function wall(c,P,mat,col){var V=window.VX;if(V&&V.curve&&mat!=null){try{V.curve(c,P,mat,{noHang:1});return;}catch(x){}}
  c.save();c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.35);c.lineWidth=7;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=col;c.lineWidth=2;c.stroke();c.restore();}
 function glowLine(c,P,col,w,al){c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';c.strokeStyle=rgba(col,.25*al);c.lineWidth=w*4;c.beginPath();P.forEach(function(q,k){k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});c.stroke();
  c.strokeStyle=rgba(col,al);c.lineWidth=w;c.stroke();c.restore();}
 function gear(c,x,y,r,rot,col,al){c.save();c.translate(x,y);c.rotate(rot);c.strokeStyle=rgba(col,al);c.lineWidth=1.4;c.beginPath();
  for(var k=0;k<=40;k++){var a=k/40*2*PI,rr=r*(k%4<2?1:.84);k?c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):c.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}c.stroke();
  c.beginPath();c.arc(0,0,r*.32,0,2*PI);c.stroke();c.restore();}
 /* ——— vortex d'arrivée : disque d'accrétion de matière lumineuse (grains des onze mondes), horizon sombre, anneau de photons,
    arc de lentille gravitationnelle au-dessus, bras en pointillés, arcs électriques — la langue des murs et des chocs du jeu ——— */
 function vortexQ(c,x,y,Rm,al,dt,suck){var n,q,a0,rr,TL=-.18;
  if(!VQ){VQ=[];for(n=0;n<210;n++)VQ.push({r:Math.random(),a:Math.random()*2*PI,c:COL[n%12],w:.65+Math.random()*1.05});}
  c.save();c.translate(x,y);c.rotate(TL);c.lineCap='round';
  var Rh=Rm*.15,g=c.createRadialGradient(0,0,Rh,0,0,Rm*1.15);g.addColorStop(0,'rgba(140,123,255,'+(.32*al)+')');g.addColorStop(.45,'rgba(77,215,255,'+(.10*al)+')');g.addColorStop(1,'rgba(5,7,13,0)');
  c.save();c.scale(1,.54);c.fillStyle=g;c.beginPath();c.arc(0,0,Rm*1.15,0,2*PI);c.fill();c.restore();   /* halo sans bord : le dégradé s'éteint avant l'ellipse */
  function grains(front){c.globalCompositeOperation='lighter';for(n=0;n<VQ.length;n++){q=VQ[n];
    if(front===null){var om=.0021/Math.pow(.12+q.r,1.5);q.a+=om*dt;q.r-=dt*.00009*(1+suck*4)*(1.2-q.r);if(q.r<.03){q.r=1;q.a=Math.random()*2*PI;}continue;}
    var s=Math.sin(q.a);if((s>0)!==front)continue;rr=Rh*1.15+q.r*(Rm-Rh*1.15);a0=q.a-Math.min(1.1,.16/Math.pow(.12+q.r,1.2));
    var lum=al*(.18+.75*(1-q.r))*(front?1:.55);c.strokeStyle=rgba(q.r<.22?'#F1F4F6':q.c,lum);c.lineWidth=q.w*(1.3-q.r*.7);
    c.beginPath();c.ellipse(0,0,rr,rr*.42,0,a0,q.a);c.stroke();}}
  grains(null);grains(false);
  /* bras en pointillés qui s'enroulent */
  c.globalCompositeOperation='lighter';for(n=0;n<4;n++){c.beginPath();for(var s2=0;s2<=30;s2++){var u=s2/30,th=n*PI/2-u*4.2+now0*.0011,r2=Rh*1.2+(Rm*.95-Rh*1.2)*Math.pow(u,1.25);var px=Math.cos(th)*r2,py=Math.sin(th)*r2*.42;s2?c.lineTo(px,py):c.moveTo(px,py);}
   c.setLineDash([1.2,5]);c.lineDashOffset=now0*.03;c.strokeStyle=rgba(COL[[0,2,7,11][n]],.55*al);c.lineWidth=1.1;c.stroke();}c.setLineDash([]);
  /* horizon et anneau de photons */
  c.globalCompositeOperation='source-over';c.fillStyle='rgba(3,4,8,'+(.96*al)+')';c.beginPath();c.arc(0,0,Rh,0,2*PI);c.fill();
  c.globalCompositeOperation='lighter';
  for(n=0;n<3;n++){c.strokeStyle=n?rgba(n===1?'#A878FF':'#43D5F5',(.5-.12*n)*al):'rgba(241,244,246,'+(.95*al)+')';c.lineWidth=n?3.5+n*3:1.3;c.beginPath();c.arc(0,0,Rh+.5+n*1.2,0,2*PI);c.stroke();}
  /* lentille : l'arrière du disque, courbé par-dessus l'horizon */
  for(n=0;n<7;n++){var ra=Rh*1.25+n*Rh*.16;c.strokeStyle=rgba(COL[(n*3)%12],(.42-.04*n)*al);c.lineWidth=.9;c.beginPath();c.ellipse(0,-Rh*.08,ra,ra*.92,0,PI*1.06,PI*1.94);c.stroke();}
  grains(true);
  /* arcs électriques qui crépitent sur le bord */
  if(Math.random()<.35*al){var an=Math.random()*2*PI,len=Rh*(.8+Math.random()*1.4),px2=Math.cos(an)*Rh,py2=Math.sin(an)*Rh;c.strokeStyle='rgba(241,244,246,'+(.8*al)+')';c.lineWidth=.8;c.beginPath();c.moveTo(px2,py2);
   for(n=1;n<=6;n++){var f=n/6,jt=(Math.random()-.5)*6;c.lineTo(px2+Math.cos(an)*len*f-Math.sin(an)*jt,py2+Math.sin(an)*len*f*.6+Math.cos(an)*jt);}c.stroke();}
  c.restore();}
 var now0=0,dtD=16;
 /* ——— décors de scène (coordonnées locales) ——— */
 function deco(c,k,lt,B,T){var z=Z[k],col=COL[z.w],V=window.VX,n,q,u,x,y,p;
  switch(k){
  case 0:{ /* Atelier : vortex de départ, trait tracé par la particule */
   if(lt<900){var vc=1-ease('io',cl(lt/900));vortexQ(c,45,112,24+150*vc,vc,dtD,0);}   /* le vortex d'arrivée se referme au départ : la boucle */
   u=cl((lt-140)/560);n=Math.max(2,Math.round(u*(S1.length-1))+1);var sub=S1.slice(0,n);
   if(V&&V.flow){c.save();c.globalAlpha=.75;try{V.flow(c,FL0);}catch(x){}c.restore();}   /* poussière d'étoile : le chemin de la machine */
   if(V&&V.stroke)V.stroke(c,sub,0,1);else glowLine(c,sub,col,2.4,1);
   if(u>0&&u<1){q=sub[sub.length-1];var g=c.createRadialGradient(q[0],q[1],0,q[0],q[1],16);g.addColorStop(0,'rgba(241,244,246,.95)');g.addColorStop(.3,rgba(col,.5));g.addColorStop(1,rgba(col,0));c.fillStyle=g;c.beginPath();c.arc(q[0],q[1],16,0,2*PI);c.fill();}
   break;}
  case 1:{ /* Fonderie : plaques de rebond, sol de lave, braises */
   var g2=c.createLinearGradient(0,430,0,480);g2.addColorStop(0,'rgba(255,82,82,0)');g2.addColorStop(1,'rgba(255,120,40,.55)');c.fillStyle=g2;c.fillRect(-20,430,400,60);
   wall(c,[[0,454],[360,454]],2,'#FF5252');wall(c,[[46,404],[116,392]],1,col);wall(c,[[158,340],[222,328]],1,col);wall(c,[[270,258],[332,246]],1,col);
   c.save();c.globalCompositeOperation='lighter';for(n=0;n<3;n++){var bb=BUB[n],fb=((lt*.0007+n*.37)%1.25),nb=Math.min(bb.length,Math.round(fb*bb.length));   /* chambre à bulles : traces en spirale */
    for(q=0;q<nb;q++){c.fillStyle=rgba(q%3?'#FFAA3C':'#F1F4F6',.12+.5*q/bb.length);c.beginPath();c.arc(bb[q][0],bb[q][1],.7+(q%3===0?.5:0),0,2*PI);c.fill();}}c.restore();
   for(n=0;n<26;n++){x=(n*53+lt*.012*(1+n%3))%360;y=470-((lt*.06*(1+n%4)+n*37)%470);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.55*(1-y/480)+.1);c.fillRect(x,y,1.6,1.6);}
   break;}
  case 2:{ /* Chaîne : tapis d'élan et looping */
   wall(c,[[-14,186],[118,334]],3,col);var ring=[];for(n=0;n<=48;n++){var a=n/48*2*PI;ring.push([LOOPC[0]+Math.cos(a)*(LOOPR+R+3),LOOPC[1]+Math.sin(a)*(LOOPR+R+3)]);}
   wall(c,ring,3,col);wall(c,[[180,334],[372,330]],3,col);
   for(n=0;n<14;n++){x=((n*26+lt*.25)%390)-10;c.strokeStyle=rgba(col,.5);c.lineWidth=1;c.beginPath();c.moveTo(x,344);c.lineTo(x+6,344);c.stroke();}
   break;}
  case 3:{ /* Glacier : gouffre, pont qui gèle devant la particule, tremplin */
   wall(c,[[-10,350],[72,350]],4,col);c.fillStyle='rgba(5,7,13,.55)';c.fillRect(72,352,216,140);
   for(n=0;n<9;n++){x=80+n*24;c.strokeStyle=rgba(col,.45);c.beginPath();c.moveTo(x,352);c.lineTo(x+6,380+(n%3)*14);c.lineTo(x+12,352);c.stroke();}
   u=cl(lt/460);var br=[];for(n=0;n<=24;n++){var f=n/24*u;br.push([70+230*f,350+10*Math.sin(f*PI)]);}if(u>0)wall(c,br,4,col);
   wall(c,[[300,358],[330,352],[352,320],[356,306]],4,col);wall(c,[[300,360],[300,470]],0,col);
   for(n=0;n<30;n++){x=(n*47+lt*.01*(n%5))%360;y=(n*61+lt*.04*(1+n%3))%480;c.fillStyle='rgba(241,244,246,.5)';c.fillRect(x,y,1.3,1.3);}
   break;}
  case 4:{ /* Soufflerie : colonne d'air, cyclone */
   if(V&&V.updraft)V.updraft(c,[110,60,80,420]);else{c.fillStyle=rgba(col,.08);c.fillRect(110,60,80,420);}
   if(V&&V.vortex)V.vortex(c,[262,130,58,1]);else spiral(c,262,130,58,.6,lt*.01,[col]);
   for(n=0;n<18;n++){y=(n*31+lt*.3)%480;x=120+(n*17)%60;c.strokeStyle=rgba(col,.35);c.beginPath();c.moveTo(x,480-y);c.lineTo(x,480-y-14);c.stroke();}
   break;}
  case 5:{ /* Mécanique : engrenages, marches qui montent en rythme */
   gear(c,300,384,42,lt*.002,col,.35);gear(c,70,150,28,-lt*.003,col,.3);gear(c,206,86,20,lt*.004,col,.3);
   for(n=0;n<5;n++){var tn=300+n*250-180,rise=ease('out',cl((lt-tn)/200)),yy=STEPY[n]+(1-rise)*140;
    glowLine(c,[[STEPX[n],yy],[STEPX[n]+50,yy]],col,2.2,.9);glowLine(c,[[STEPX[n]+25,yy],[STEPX[n]+25,480]],col,1,.35);}
   break;}
  case 6:{ /* Gravité : plafond porteur, champ renversé */
   glowLine(c,[[40,28],[310,28]],col,2.4,.95);
   if(V&&V.well){c.save();c.globalAlpha=.55;V.well(c,[180,250,1100,26]);c.restore();}   /* puits : l'espace-temps courbé */
   for(n=0;n<24;n++){x=(n*41)%360;y=(n*67+lt*.03)%480;c.fillStyle=rgba(col,.35);c.fillRect(x,480-y,1.5,1.5);}
   break;}
  case 7:{ /* Magnétisme : aimant, anneaux de champ, gouttes de ferrofluide */
   for(n=1;n<=4;n++){c.strokeStyle=rgba(col,.32/n+.05*Math.sin(lt*.006+n));c.lineWidth=1;c.setLineDash([3,5]);c.lineDashOffset=-lt*.02*n;c.beginPath();c.arc(MAG[0],MAG[1],n*28,0,2*PI);c.stroke();}c.setLineDash([]);
   for(n=0;n<9;n++){var a2=n/9*2*PI+lt*.0015,r2=34+8*Math.sin(lt*.004+n);c.fillStyle=rgba(col,.35);c.beginPath();c.arc(MAG[0]+Math.cos(a2)*r2,MAG[1]+Math.sin(a2)*r2,3+2*Math.sin(n+lt*.005),0,2*PI);c.fill();}
   var g3=c.createRadialGradient(MAG[0],MAG[1],0,MAG[0],MAG[1],22);g3.addColorStop(0,'rgba(255,220,240,.95)');g3.addColorStop(1,rgba(col,0));c.fillStyle=g3;c.beginPath();c.arc(MAG[0],MAG[1],22,0,2*PI);c.fill();
   break;}
  case 8:{ /* Faille : la particule ouvre la faille, portails */
   u=cl(lt/360);c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba(col,.9);c.lineWidth=1.6;c.beginPath();
   for(n=0;n<=20;n++){y=140+n*8;x=150+(n%2?4:-4)*Math.sin(lt*.03+n);n?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();
   var op=ease('out',cl((lt-200)/220))*(lt<900?1:cl(1-(lt-900)/300));if(op>0){c.strokeStyle=rgba(col,op);c.lineWidth=2.2;c.beginPath();c.ellipse(150,220,8+26*op,62*op,0,0,2*PI);c.stroke();}
   var ob=ease('out',cl((lt-500)/200))*cl(1-(lt-1100)/300);if(ob>0){c.beginPath();c.ellipse(300,100,8+24*ob,30*ob+8,0,0,2*PI);c.stroke();}
   c.restore();if(V&&V.rift){c.save();c.globalAlpha=.8;V.rift(c,[150,220,300,100,70]);c.restore();}   /* corral d'atomes aux deux bouts de la faille */
   for(n=0;n<6;n++){y=(lt*.2+n*80)%480;c.fillStyle=rgba(col,.08);c.fillRect(0,y,360,1);}
   break;}
  case 9:{ /* Filaments : corde-tremplin qui ploie, harpe */
   var land=380,go=630;var sx=150,sy=360;if(lt>=land&&lt<=go&&B)sy=Math.max(360,B[1]+R);else if(lt>go){sy=360+52*Math.exp(-(lt-go)/160)*Math.cos((lt-go)*.06);}
   glowLine(c,[[50,360],[sx,sy],[250,360]],col,1.6,.95);
   for(n=0;n<6;n++){x=270+n*14;var vib=lt>go+150?4*Math.exp(-(lt-go-150-n*40)/260)*Math.sin(lt*.08+n):0;glowLine(c,[[x,60],[x+vib,150],[x,240]],col,1,.6);}
   break;}
  case 10:{ /* Quantique : dédoublement, détecteur */
   if(V&&V.qsup&&V.qdet){try{V.qsup(c,[22,190,44,44],lt*.06);V.qdet(c,[300,220,24,0],true,lt*.06,null);}catch(x){}for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}break;}
   var D=[300,220],ring2=6+4*Math.sin(lt*.01);c.strokeStyle='rgba(255,216,90,.8)';c.lineWidth=1.4;c.beginPath();c.arc(D[0],D[1],18+ring2,0,2*PI);c.stroke();
   c.beginPath();c.moveTo(D[0]-30,D[1]);c.lineTo(D[0]-12,D[1]);c.moveTo(D[0]+12,D[1]);c.lineTo(D[0]+30,D[1]);c.moveTo(D[0],D[1]-30);c.lineTo(D[0],D[1]-12);c.moveTo(D[0],D[1]+12);c.lineTo(D[0],D[1]+30);c.stroke();
   for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(lt*.002+n)*20)%480;c.fillStyle=rgba(col,.25);c.fillRect(x,y,1.2,1.2);}
   break;}
  case 11:{ /* Arrivée : bassin, puis vortex */
   for(n=0;n<70;n++){x=(n*97)%360;y=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.25+.35*Math.sin(lt*.004+n*1.7))*.8);c.fillRect(x,y,1.3,1.3);}   /* ciel des onze mondes */
   glowLine(c,[[150,338],[150,398],[260,398],[260,338]],'#9BEB4B',2.2,.95*(1-.75*cl((lt-640)/600)));
   var vo=cl((lt-640)/800);if(vo>0)vortexQ(c,205,372,(30+175*ease('out',vo))*(1+2.2*ease('io',cl((lt-1700)/790))),ease('out',vo),dtD,lt>860?1:0);   /* le vortex s'élargit et engloutit l'image */
   break;}
  }
 }
 /* ——— image ——— */
 function frame(c,w,h,now,opt){
  now0=now;opt=opt||{};if(T0===null){T0=now;for(var pk=0;pk<11;pk++)img(pk);}var dt=Math.max(0,Math.min(60,now-(last||now)));last=now;dtD=dt;if(hold>0){T0+=Math.min(hold,dt);hold-=dt;}   /* arrêt sur image au choc fort */
  var t=(now-T0)%TOT,k=0;while(k<Z.length-1&&t>=Z[k].t0+Z[k].d)k++;
  var z=Z[k],lt=t-z.t0,LC=local(z,lt),B=LC.p,vis=!!B;if(!B)B=z.out;
  if(k!==lastZone){if(k===0){trail=[];cam.ok=false;seen={};}lastZone=k;label={k:k,t:now};}
  var gx=z.x0+B[0],gy=B[1];
  /* évènements */
  var V0=window.VX;(z.ev||[]).forEach(function(e,ei){var key=k+':'+ei;if(lt>=e[0]&&!seen[key]){seen[key]=1;var cc=COL[z.w];
    if(e[1]==='hit'){var hv=e[2]||5,hn=[e[4]||0,e[5]==null?-1:e[5]],ix=gx-hn[0]*R,iy=gy-hn[1]*R;   /* choc : bibliothèque d'impacts du jeu (poussière, arcs, onde, étoile), accentuée */
     if(V0&&V0.impact){V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv,mat:e[3]||0});if(hv>=6)V0.impact({x:ix,y:iy,nx:hn[0],ny:hn[1],v:hv*.7,mat:e[3]||0});}
     burst(ix,iy,cc,10+hv*2,1.2+hv*.25);hits.push({x:ix,y:iy,c:cc,l:1,v:hv,n:hn});sq={t:1,nx:hn[0],ny:hn[1],k:Math.min(.42,hv/16)};shake=Math.max(shake,1+hv*.5);}
    else if(e[1]==='boost'){burst(gx,gy,cc,22,2.4);}
    else if(e[1]==='warp'){burst(gx,gy,cc,30,2.8);flashA=Math.max(flashA,.12);}
    else if(e[1]==='freeze'){burst(gx+40,gy,'#F1F4F6',24,1.2);}
    else if(e[1]==='collapse'){burst(gx,gy,'#FFD85A',36,2.6);flashA=Math.max(flashA,.15);}
    }});
  var power=(z.pw||[]).some(function(p){return lt>=p[0]&&lt<=p[1];});
  /* caméra */
  var tx=gx+40,ty=240+(gy-240)*.3,zoom=power?1.12:1,roll=0;
  if(k===6){roll=lt<420?PI*ease('io',lt/420):lt<1040?PI:PI+PI*ease('io',(lt-1040)/520);}
  if(!cam.ok){cam.x=tx;cam.y=ty;cam.z=zoom;cam.ok=true;}
  var fk=1-Math.pow(.0025,dt/1000);cam.x+=(tx-cam.x)*Math.min(1,fk*4);cam.y+=(ty-cam.y)*Math.min(1,fk*2);cam.z+=(zoom-cam.z)*Math.min(1,fk*3);
  var s=Math.min(w/UW,h/UH)*cam.z;
  /* fonds : illustration du monde, fondu au passage d'une frontière */
  c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  var f=cam.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0;
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){var kk=o[0],a=o[1];if(a<=0.01||kk<0||kk>11)return;var I=img(Z[kk].w);
   if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.12,dh=dw/ir,px=-(f-kk-.5)*w*.18;c.globalAlpha=a*.6;c.drawImage(I,(w-dw)/2+px,(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[Z[kk].w],.22*a));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}});
  var vg=c.createRadialGradient(w/2,h*.48,h*.1,w/2,h*.48,h*.85);vg.addColorStop(0,'rgba(5,7,13,.38)');vg.addColorStop(1,'rgba(5,7,13,.9)');c.fillStyle=vg;c.fillRect(0,0,w,h);
  /* monde */
  var sh=shake>0?shake:0;shake*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.rotate(roll);c.scale(s,s);c.translate(-cam.x,-cam.y);
  for(var kk=Math.max(0,k-1);kk<=Math.min(Z.length-1,k+1);kk++){var zz=Z[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);try{deco(c,kk,llt,kk===k?B:null,t);}catch(x){}c.restore();}
  /* chocs : éclair local + onde double */
  c.save();c.globalCompositeOperation='lighter';for(i=hits.length-1;i>=0;i--){var hh=hits[i];hh.l-=dt/520;if(hh.l<=0){hits.splice(i,1);continue;}var ra=(1-hh.l)*(26+hh.v*7),gg=c.createRadialGradient(hh.x,hh.y,0,hh.x,hh.y,18+hh.v*3);
   gg.addColorStop(0,'rgba(241,244,246,'+(.8*hh.l*hh.l)+')');gg.addColorStop(.35,rgba(hh.c,.45*hh.l));gg.addColorStop(1,rgba(hh.c,0));c.fillStyle=gg;c.beginPath();c.arc(hh.x,hh.y,18+hh.v*3,0,2*PI);c.fill();
   c.strokeStyle=rgba(hh.c,.7*hh.l);c.lineWidth=1.6*hh.l+.4;c.beginPath();c.ellipse(hh.x,hh.y,ra,ra*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();c.strokeStyle='rgba(241,244,246,'+(.5*hh.l)+')';c.lineWidth=.8;c.beginPath();c.ellipse(hh.x,hh.y,ra*.62,ra*.62*(hh.n[1]?.38:1),0,0,2*PI);c.stroke();}c.restore();
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}
  /* traîne */
  if(vis){trail.push([gx,gy]);if(trail.length>26)trail.shift();}
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  for(i=1;i<trail.length;i++){var a=i/trail.length;c.strokeStyle=rgba(COL[z.w],a*.55);c.lineWidth=R*1.6*a;c.beginPath();c.moveTo(trail[i-1][0],trail[i-1][1]);c.lineTo(trail[i][0],trail[i][1]);c.stroke();}
  c.restore();
  /* éclats */
  c.save();c.globalCompositeOperation='lighter';for(i=parts.length-1;i>=0;i--){var p=parts[i];p.x+=p.vx*dt/16;p.y+=p.vy*dt/16;p.vx*=.96;p.vy*=.96;p.l-=dt/700;if(p.l<=0){parts.splice(i,1);continue;}
   c.fillStyle=rgba(p.c,p.l*.9);c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s);}c.restore();
  /* particule (dédoublée dans le monde quantique) */
  var V=window.VX;sq.t=Math.max(0,sq.t-dt/240);var sk=sq.t>0?(sq.k||.3)*Math.sin(sq.t*PI)*(sq.t):0;
  var drawB=function(x,y,al,sc){c.save();c.globalAlpha=al;c.translate(x,y);if(sk>0){var an=Math.atan2(sq.ny,sq.nx);c.rotate(an);c.scale(1-sk,1+sk*.7);c.rotate(-an);}if(V&&V.ball)V.ball(c,0,0,now*.004,R*(sc||1));else{c.fillStyle='#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();};
  if(k===10&&LC.s===z.segs[1]){var uu=ease('io',LC.u),up=bz([60,212],[150,90],[240,110],[300,220],40),dn=bz([60,212],[150,350],[240,330],[300,220],40),pa=along(up,uu),pb=along(dn,uu);
   c.save();c.strokeStyle='rgba(166,120,255,.45)';c.lineWidth=1;c.beginPath();for(i=0;i<=16;i++){var f2=i/16;c.lineTo(z.x0+pa[0]+(pb[0]-pa[0])*f2+6*Math.sin(f2*PI*6+now*.02),pa[1]+(pb[1]-pa[1])*f2);}c.stroke();c.restore();
   drawB(z.x0+pa[0],pa[1],.75);drawB(z.x0+pb[0],pb[1],.75);}
  else if(vis){var sc=k===11&&lt>860?Math.max(.15,1-(lt-860)/1250):1;
   if(power){c.save();c.globalCompositeOperation='lighter';drawB(gx-2.5,gy,.35,sc);drawB(gx+2.5,gy,.35,sc);c.restore();
    var pr=(now%600)/600;c.strokeStyle=rgba(COL[z.w],.6*(1-pr));c.lineWidth=1.2;c.beginPath();c.arc(gx,gy,R+pr*40,0,2*PI);c.stroke();}
   drawB(gx,gy,1,sc);}
  c.restore();
  /* passage de boucle : l'image plonge dans l'horizon, puis le départ émerge (aucun éclair) */
  var iris=k===11?ease('io',cl((lt-(z.d-620))/620)):k===0?1-ease('io',cl(lt/720)):0;if(iris>0){c.fillStyle='rgba(3,4,8,'+iris.toFixed(3)+')';c.fillRect(0,0,w,h);}
  /* flash, étiquette du monde */
  if(flashA>0){c.fillStyle='rgba(241,244,246,'+(flashA*.7)+')';c.fillRect(0,0,w,h);flashA=Math.max(0,flashA-dt/380);}
  if(opt.labels!==false&&z.w<11){var la=cl((now-label.t)/250)*cl(1-(now-label.t-1300)/400);if(la>0){var nm='';try{nm=typeof WN==='function'?WN(z.w):(typeof WORLDS!=='undefined'?WORLDS[z.w].n:'');}catch(x){}
    c.save();c.globalAlpha=la;c.font='500 10px "JetBrains Mono",ui-monospace,monospace';c.fillStyle=COL[z.w];c.textBaseline='alphabetic';
    var y0=opt.labelY||h-18,x0=16,tx0=(z.w+1<10?'0':'')+(z.w+1)+' · '+String(nm).toUpperCase();if(opt.labelC){c.textAlign='center';x0=w/2;}c.fillText(tx0,x0,y0);
    c.fillStyle=rgba(COL[z.w],.6);if(opt.labelC)c.fillRect(x0-30*la,y0+6,60*la,1);else c.fillRect(x0,y0+6,60*la,1);c.restore();}}
  return {world:z.w,power:power};
 }
 /* ——— R204 · ÉPILOGUE « Les retrouvailles » (docs/NARRATION.md) ———
    Poursuite de retour, même principe que le héros (scènes côte à côte, caméra qui suit), dans l'autre sens. Au monde
    Quantique la particule se dédouble : la compagne (violette, comme la branche de superposition du jeu) fait tout le retour
    avec elle, avec sa propre dynamique — tantôt en miroir, en tresse ou en patineurs, tantôt séparée pour franchir un
    autre obstacle ou passer autrement le même (la caméra recule pour les garder toutes deux). À l'origine elles se
    refondent ; leur réunion crée une sphère dans laquelle elles dansent (rotations à trois dimensions, la trace devient
    le nuage de points du noyau). ——— */
 var EP=null,ORG=[45,112],CYC=[180,240],PLN=[190,240],BOWL=function(x){var d=(x-180)/140;return 380-140*d*d;};
 function bwl(x){return BOWL(x)-R-2;}
 var LAX=function(e){return [330-300*e,330-190*e];},HAX=function(e){return [310-226*e,215-87*e];};
 var ZR=[
  {w:11,A:[Hd(600),Cv(bz([205,386],[205,300],[110,250],[-2,250],30).slice(1),1000,'in')],cam:function(lt){return lt<700?{z:.74,r:0}:{z:1.04,r:0};}},
  {w:10,A:[Ln([270,250],300),Cv(bz([270,250],[220,240],[190,150],[120,150],24).slice(1),600,'io'),Ln([60,150],700),Ln([-2,170],260,'out')],
   bIn:[270,250],B:[Hd(300),Cv(bz([270,250],[230,270],[230,330],[205,330],24).slice(1),500,'io'),Ln([110,330],560),Ln([-2,310],500,'out')],
   ev:[[300,'split']],evB:[[880,'tunnel']],cam:function(lt){return lt<420?{z:1.26,r:0,oy:-10}:{z:1.05,r:0};}},
  {w:9,A:[Ln([214,170],420),Ln([156,170],520,'io'),Cv(bz([156,170],[90,175],[60,226],[-2,232],24).slice(1),500,'out')],
   B:[Ln([214,310],640),Ln([156,310],520,'io'),Cv(bz([156,310],[90,305],[60,254],[-2,248],24).slice(1),280,'out')],ev:[[640,'slow',.5]],
   cam:function(lt){return lt>500&&lt<1100?{z:1.14,r:0,ox:20}:{z:1,r:0};}},
  {w:8,A:[Ln([236,232],300),Cv(bz([236,232],[196,250],[184,380],[180,496],24).slice(1),420,'in'),Tp([172,-16],40),Cv(bz([172,-16],[164,70],[140,150],[100,190],24).slice(1),420),Ln([-2,200],260,'out')],
   Bf:{lag:150,r:14,w:.006},ev:[[720,'seam',180,478],[760,'seam',172,2]],cam:function(lt){return lt>600&&lt<950?{z:.7,r:0,ty:240}:{z:1,r:0};}},
  {w:7,A:[Ln([180,228],440,'in'),Fn(function(u){var a=-PI/2-u*4*PI,r=12+78*u;return [CYC[0]+r*Math.cos(a),CYC[1]+r*Math.sin(a)];},1400,'in'),Ln([-2,150],260,'out')],
   Bf:{lag:210,r:0},cam:function(lt){var u=cl((lt-440)/1400);return lt<440?{z:1,r:0}:{z:1.4-.62*ease('io',u),r:0,tx:CYC[0],ty:CYC[1]};}},
  {w:6,A:[Ln([190,170],520,'in'),Fn(function(u){var a=-PI/2-u*2.5*PI;return [PLN[0]+70*Math.cos(a),PLN[1]+70*Math.sin(a)];},1500,'io'),Cv(bz([120,240],[100,200],[50,205],[-2,215],20).slice(1),380,'out')],
   Bf:{lag:430,r:0},
   cam:function(lt){if(lt<520)return {z:.95,r:0};var u=cl((lt-520)/1500);if(lt>2020)return {z:.95,r:0};return {z:.7+.26*Math.pow(Math.cos(PI*u),2),r:-.62*PI*Math.pow(Math.sin(PI*u),2),tx:PLN[0],ty:PLN[1]};}   /* la caméra bascule et revient : pas de tourbillon */},
  {w:5,A:[Cv(bz([358,215],[300,230],[262,339],[215,339],24).slice(1),460,'in'),Hd(160),Jp([46,246],110,640),Ln([-2,246],110)],
   Bf:{lag:110,r:20,w:.009},ev:[[620,'hit',7,0,-1,0],[620,'slow',.35]],cam:function(lt){return lt>380&&lt<860?{z:1.3,r:0,oy:30}:{z:.9,r:0};}},
  {w:4,A:[Fn(function(u,a){return [a[0]+(-2-a[0])*u,a[1]-20*u+34*Math.sin(u*3*PI)];},1250,'io')],Bf:{lag:0,r:28,w:.0075},cam:function(lt){return {z:1.02,r:0};}},
  {w:3,A:[Jp([320,bwl(320)],14,220),Fn(function(u){var x=180+140*Math.cos(u*3*PI);return [x,bwl(x)];},2200),Jp([-2,190],60,360,'out')],
   Bf:{lag:240,r:0},ev:[[220,'hit',4,4,0,-1],[587,'spray'],[1320,'spray'],[2053,'spray'],[2420,'launch']],
   cam:function(lt){var u=cl((lt-220)/2200),ph=u*3*PI,cr=Math.pow(Math.abs(Math.sin(ph)),3);if(lt<220)return {z:.78,r:0};if(lt>2420)return {z:.76,r:0};return {z:1.02+.24*cr,r:.035*Math.sin(ph)};}},
  {w:2,A:[Cv(bz([358,190],[350,260],[340,320],[330,330],12).slice(1),300,'in'),Fn(function(u){var e=ease('in3',u),P=LAX(e),o=10*Math.sin(e*7*PI)*(1-.3*e);return [P[0]+.535*o,P[1]-.845*o];},1500),Ln([-2,120],240)],
   B:[Cv(bz([358,214],[352,270],[342,322],[330,330],12).slice(1),300,'in'),Fn(function(u){var e=ease('in3',u),P=LAX(e),o=-10*Math.sin(e*7*PI)*(1-.3*e);return [P[0]+.535*o,P[1]-.845*o];},1500),Ln([-2,122],240)],
   ev:[[300,'slow',.45],[1650,'fast']],cam:function(lt){var u=cl((lt-300)/1500),e=ease('in3',u);if(lt<300)return {z:1.15,r:0};return {z:1.25-.5*e,r:0};}},
  {w:1,A:[Cv(bz([358,120],[340,112],[320,106],[296,104],12).slice(1),320),Cv(bz([296,104],[220,110],[170,250],[150,322],30).slice(1),900),Jp([-2,330],90,720)],
   B:[Cv(bz([358,122],[340,113],[320,106],[296,104],12).slice(1),320),Cv(bz([296,104],[230,96],[160,60],[96,74],30).slice(1),900),Cv(bz([96,74],[60,82],[24,92],[-2,96],16).slice(1),720)],
   ev:[[320,'pair',296,104],[320,'slow',.5],[1220,'hit',6,1,0,-1]],cam:function(lt){return lt<700?{z:1.12,r:0,oy:-30}:{z:.8,r:0};}},
  {w:0,A:[Cv(bz([358,330],[320,320],[318,250],[310,215],16).slice(1),760,'io'),Fn(function(u){var e=ease('io',u),P=HAX(e),o=26*Math.sin(e*4*PI);return [P[0]+.36*o,P[1]-.934*o];},2300)],
   B:[Cv(bz([358,96],[330,120],[318,180],[310,215],16).slice(1),760,'io'),Fn(function(u){var e=ease('io',u),P=HAX(e),o=-26*Math.sin(e*4*PI);return [P[0]+.36*o,P[1]-.934*o];},2300)],
   ev:[[760,'meet'],[760,'slow',.55]],cam:function(lt){var u=cl((lt-760)/2300);return lt<760?{z:.84,r:0}:{z:1.04+.2*ease('io',u),r:0,tx:lt>2300?118-40*ease('io',cl((lt-2300)/760)):null};}}
 ];
 function prepSegs(segs,p0){var p=p0.slice(),d=0,st=[];for(var b=0;b<segs.length;b++){var sg=segs[b];st.push({t:d,a:p.slice()});var q=sPos(sg,p,1);p=q?q:p;d+=sg.d;}return {st:st,d:d,out:p};}
 var TRT=0;(function(){var prev=null;for(var a=0;a<ZR.length;a++){var z=ZR[a];z.x0=z.w*UW;z.t0=TRT;
   z.inA=prev?[prev.x0+prev.outA[0]-z.x0,prev.outA[1]]:z.A[0]&&[205,386];var pa=prepSegs(z.A,z.inA);z.stA=pa.st;z.outA=pa.out;z.d=pa.d;
   if(z.B){z.inB=z.bIn||(prev&&prev.outB?[prev.x0+prev.outB[0]-z.x0,prev.outB[1]]:z.inA);var pb=prepSegs(z.B,z.inB);z.stB=pb.st;z.outB=pb.out;z.d=Math.max(z.d,pb.d);}
   else if(z.Bf){z.outB=z.outA.slice();}
   TRT+=z.d;prev=z;}})();
 function locS(segs,st,lt){for(var k=0;k<segs.length;k++){var sg=segs[k],q=st[k];if(lt<q.t+sg.d||k===segs.length-1){var su=cl((lt-q.t)/sg.d);return sPos(sg,q.a,su);}}return null;}
 var TH=2300;
 function bgImg(c,w,h,wi,a,px){var I=img(wi);if(I){var ir=I.naturalWidth/I.naturalHeight,dw=Math.max(w,h*ir)*1.12,dh=dw/ir;c.globalAlpha=a;c.drawImage(I,(w-dw)/2+(px||0),(h-dh)/2,dw,dh);c.globalAlpha=1;}
   else{var g=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,w*.9);g.addColorStop(0,rgba(COL[wi],.22*a));g.addColorStop(1,'rgba(5,7,13,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}}
 function vign(c,w,h,a0,a1){var vg=c.createRadialGradient(w/2,h*.48,h*.1,w/2,h*.48,h*.85);vg.addColorStop(0,'rgba(5,7,13,'+a0+')');vg.addColorStop(1,'rgba(5,7,13,'+a1+')');c.fillStyle=vg;c.fillRect(0,0,w,h);}
 function eBall(c,x,y,al,sc,now,sx,sy){var V=window.VX;c.save();c.globalAlpha=al;c.translate(x,y);if(sx)c.scale(sx,sy);if(V&&V.ball)V.ball(c,0,0,now*.004,R*(sc||1));else{c.fillStyle='#E8FBFF';c.beginPath();c.arc(0,0,R*(sc||1),0,2*PI);c.fill();}c.restore();}
 /* la compagne : exactement la branche de superposition du jeu (balle teintée violette, 94 %, opacité .72) */
 function comp(c,x,y,al,sc,now,sx,sy){var V=window.VX;c.save();c.globalAlpha=.72*al;c.translate(x,y);if(sx)c.scale(sx,sy);if(V&&V.ball)V.ball(c,0,0,-now*.004,R*.94*(sc||1),'#A878FF');else{c.fillStyle='#A878FF';c.beginPath();c.arc(0,0,R*.94*(sc||1),0,2*PI);c.fill();}c.restore();}
 function eParts(c,dt){c.save();c.globalCompositeOperation='lighter';for(var a=parts.length-1;a>=0;a--){var p=parts[a];p.x+=p.vx*dt/16;p.y+=p.vy*dt/16;p.vx*=.96;p.vy*=.96;p.l-=dt/700;if(p.l<=0){parts.splice(a,1);continue;}
   c.fillStyle=rgba(p.c,p.l*.9);c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s);}c.restore();}
 function eTrail(c,T,col,k){c.save();c.globalCompositeOperation='lighter';c.lineCap='round';for(var a=1;a<T.length;a++){var f=a/T.length;if(!T[a]||!T[a-1])continue;c.strokeStyle=rgba(col,f*.5);c.lineWidth=R*k*f;c.beginPath();c.moveTo(T[a-1][0],T[a-1][1]);c.lineTo(T[a][0],T[a][1]);c.stroke();}c.restore();}
 function gTrail(c,T){c.save();for(var a=0;a<T.length;a++){if(!T[a])continue;c.globalAlpha=a/T.length*.22;c.fillStyle='#A878FF';c.beginPath();c.arc(T[a][0],T[a][1],R*.4,0,2*PI);c.fill();}c.restore();}   /* traîne de la branche, comme dans le jeu */
 function eHits(c,dt){c.save();c.globalCompositeOperation='lighter';for(var a=EP.hit.length-1;a>=0;a--){var hh=EP.hit[a];hh.l-=dt/520;if(hh.l<=0){EP.hit.splice(a,1);continue;}var ra=(1-hh.l)*(26+hh.v*7),gg=c.createRadialGradient(hh.x,hh.y,0,hh.x,hh.y,18+hh.v*3);
   gg.addColorStop(0,'rgba(241,244,246,'+(.8*hh.l*hh.l)+')');gg.addColorStop(.35,rgba(hh.c,.45*hh.l));gg.addColorStop(1,rgba(hh.c,0));c.fillStyle=gg;c.beginPath();c.arc(hh.x,hh.y,18+hh.v*3,0,2*PI);c.fill();
   c.strokeStyle=rgba(hh.c,.7*hh.l);c.lineWidth=1.6*hh.l+.4;c.beginPath();c.ellipse(hh.x,hh.y,ra,ra*(hh.ny?.38:1),0,0,2*PI);c.stroke();}c.restore();}
 /* ——— décors du retour (coordonnées locales) ——— */
 function packet(c,P,now,lo,hi){var env=function(xx){return Math.exp(-(xx-P[0])*(xx-P[0])/700);};c.save();c.globalCompositeOperation='lighter';c.strokeStyle=rgba('#A878FF',.75);c.lineWidth=1.2;c.beginPath();
  for(var n=0;n<=60;n++){var x=P[0]-60+n*2,y=P[1]+14*env(x)*Math.sin(x*.32-now*.02)*(x>lo&&x<hi?.45:1);n?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();c.restore();}
 function decoR(c,z,lt,A,B,now){var w=z.w,col=COL[w],n,x,y,u,V=window.VX;EP.mA=null;EP.mB=null;
  switch(w){
  case 11:deco(c,11,600,null,0);break;
  case 10:{ /* dédoublement ; l'une traverse le temps dilaté, l'autre la barrière par effet tunnel */
   if(V&&V.qsup){try{V.qsup(c,[244,222,52,56],now*.06);}catch(x2){}}
   if(V&&V.qtdil){try{V.qtdil(c,[30,104,124,92],now*.06);}catch(x2){}}
   var gb=c.createLinearGradient(150,0,195,0);gb.addColorStop(0,'rgba(168,120,255,.05)');gb.addColorStop(.5,'rgba(168,120,255,.26)');gb.addColorStop(1,'rgba(168,120,255,.05)');c.fillStyle=gb;c.fillRect(150,276,45,118);
   glowLine(c,[[150,276],[150,394]],'#A878FF',1,.55);glowLine(c,[[195,276],[195,394]],'#A878FF',1,.55);
   if(B&&B[0]>96&&B[0]<256){packet(c,B,now,150,195);EP.mB={al:B[0]>150&&B[0]<195?.35:.75};}
   if(A&&A[0]<150&&A[0]>40)EP.mA={slow:1};
   for(n=0;n<40;n++){x=(n*29)%360;y=(n*53+Math.sin(now*.002+n)*20)%480;c.fillStyle=rgba(col,.22);c.fillRect(x,y,1.2,1.2);}break;}
  case 9:{ /* deux fentes plus étroites que la particule, une pour chacune */
   wall(c,[[184,30],[184,163]],0,col);wall(c,[[184,177],[184,303]],0,col);wall(c,[[184,317],[184,450]],0,col);
   for(n=0;n<6;n++){x=236+n*22;var am=A?5*Math.max(0,1-Math.abs(A[0]-x)/50):0;glowLine(c,[[x,70],[x+am*Math.sin(now*.06+n),240],[x,410]],col,1,.4);}
   if(A&&A[0]>162&&A[0]<206){u=1-Math.abs(A[0]-184)/22;EP.mA={sx:1+.5*u,sy:1-.45*u};}if(B&&B[0]>162&&B[0]<206){u=1-Math.abs(B[0]-184)/22;EP.mB={sx:1+.5*u,sy:1-.45*u};}break;}
  case 8:{ /* univers recousu : elles se croisent par les coutures */
   for(n=0;n<2;n++){y=n?478:2;c.save();c.setLineDash([6,5]);c.lineDashOffset=now*.04*(n?1:-1);glowLine(c,[[0,y],[360,y]],col,1.2,.7);c.restore();}
   for(n=0;n<14;n++){var aa=n/14*2*PI;c.fillStyle=rgba(col,.6);c.beginPath();c.arc(180+Math.cos(aa)*22,478+Math.sin(aa)*9,1.6,0,2*PI);c.fill();c.beginPath();c.arc(172+Math.cos(aa)*22,2+Math.sin(aa)*9,1.6,0,2*PI);c.fill();}
   for(n=0;n<6;n++){y=(now*.05+n*80)%480;c.fillStyle=rgba(col,.07);c.fillRect(0,y,360,1);}break;}
  case 7:{ /* cyclotron : charges opposées, spirales en miroir */
   if(V&&V.bfield){try{c.save();c.globalAlpha=.7;V.bfield(c,[70,130,220,220,1]);c.restore();}catch(x2){}}
   c.save();c.strokeStyle=rgba(col,.55);c.lineWidth=1.4;c.beginPath();c.arc(CYC[0]-5,CYC[1],100,PI/2,PI*1.5);c.closePath();c.stroke();c.beginPath();c.arc(CYC[0]+5,CYC[1],100,-PI/2,PI/2);c.closePath();c.stroke();c.restore();
   var kg=(A&&Math.abs(A[0]-180)<8)||(B&&Math.abs(B[0]-180)<8)?1:.25;glowLine(c,[[180,140],[180,340]],'#F1F4F6',1,kg*.6);break;}
  case 6:{ /* une planète : l'une passe dessus, l'autre dessous */
   if(V&&V.well){try{c.save();c.globalAlpha=.6;V.well(c,[PLN[0],PLN[1],1100,30]);c.restore();}catch(x2){}}
   var gp=c.createRadialGradient(PLN[0]-8,PLN[1]-8,2,PLN[0],PLN[1],30);gp.addColorStop(0,'rgba(220,255,200,.95)');gp.addColorStop(.5,rgba(col,.55));gp.addColorStop(1,rgba(col,.05));c.fillStyle=gp;c.beginPath();c.arc(PLN[0],PLN[1],30,0,2*PI);c.fill();
   for(n=0;n<24;n++){x=(n*41)%360;y=(n*67+now*.03)%480;c.fillStyle=rgba(col,.3);c.fillRect(x,480-y,1.5,1.5);}break;}
  case 5:{ /* pendule : l'une est frappée, l'autre le survole */
   if(V&&V.mech){try{V.mech(c,EP.MECH||(EP.MECH=[{t:'train',x:76,y:100,k:1.45,s:.8,ph:.4,d:1},{t:'escape',x:300,y:160,k:1.3,s:.7,ph:1.2,d:-1},{t:'crank',x:100,y:420,k:1.35,s:.9,ph:2,d:1},{t:'cam',x:316,y:424,k:1.3,s:.8,ph:.8,d:-1},{t:'train',x:44,y:290,k:1.05,s:.6,ph:3,d:-1}]));}catch(x2){}}
   wall(c,[[150,350],[372,350]],0,col);var om=2*PI/2000,th=-(lt<620?.8:.32)*Math.sin(om*(lt-620)),bx=235+280*Math.sin(th),by=40+280*Math.cos(th);
   glowLine(c,[[235,40],[bx,by]],col,1.4,.85);gear(c,235,40,13,now*.003,col,.6);
   var gb2=c.createRadialGradient(bx-5,by-5,2,bx,by,17);gb2.addColorStop(0,'rgba(255,240,200,.95)');gb2.addColorStop(1,rgba(col,.35));c.fillStyle=gb2;c.beginPath();c.arc(bx,by,17,0,2*PI);c.fill();
   gear(c,bx,by,11,-now*.004,'#F1F4F6',.5);break;}
  case 4:{ /* allée de tourbillons : elles l'épousent en contre-phase */
   var ring=[];for(n=0;n<=36;n++){var a3=n/36*2*PI;ring.push([300+22*Math.cos(a3),240+22*Math.sin(a3)]);}wall(c,ring,0,col);
   for(n=0;n<16;n++){y=40+n*28;x=360-((now*.25+n*53)%400);var dy=y<240?-1:1,bump=18*Math.exp(-(x-300)*(x-300)/900)*Math.exp(-(y-240)*(y-240)/2600)*dy;c.strokeStyle=rgba(col,.28);c.lineWidth=1;c.beginPath();c.moveTo(x,y+bump);c.lineTo(x-16,y+bump);c.stroke();}
   for(n=0;n<6;n++){x=262-((lt*.13+n*56)%300);y=240+(n%2?26:-26);spiral(c,x,y,14,.32,(n%2?1:-1)*now*.006,[col,'#F1F4F6']);}break;}
  case 3:{ /* demi-lune de glace : deux patineuses, la caméra se balance avec elles */
   if(!EP.ice){EP.ice=[];for(x=24;x<=336;x+=6)EP.ice.push([x,BOWL(x)]);EP.ice.unshift([-10,BOWL(24)]);EP.ice.push([370,BOWL(336)]);}wall(c,EP.ice,4,col);
   c.save();c.globalCompositeOperation='lighter';var gi=c.createRadialGradient(180,380,0,180,380,120);gi.addColorStop(0,'rgba(143,227,255,.18)');gi.addColorStop(1,'rgba(143,227,255,0)');c.fillStyle=gi;c.fillRect(60,260,240,140);c.restore();
   for(n=0;n<40;n++){x=(n*47+now*.01*(n%5))%360;y=(n*61+now*.04*(1+n%3))%480;c.fillStyle='rgba(241,244,246,'+(.3+.3*Math.sin(now*.004+n))+')';c.fillRect(x,y,1.3,1.3);}break;}
  case 2:{ /* accélérateur linéaire : chaîne de cavités ; elles s'y tressent et prennent de la vitesse */
   if(V&&V.torusCells){try{V.torusCells(c,250,96,62,10,.14);}catch(x2){}}
   var e=ease('in3',cl((lt-300)/1500));
   for(n=0;n<9;n++){var ek=n/8,P=LAX(ek),fl=Math.max(0,1-Math.abs(e-ek)*14)*(lt>300?1:0);
    c.save();c.translate(P[0],P[1]);c.rotate(Math.atan2(-190,-300));c.strokeStyle=rgba(col,.45+.5*fl);c.lineWidth=1.3;c.beginPath();c.ellipse(0,0,15,24,0,0,2*PI);c.stroke();
    c.strokeStyle=rgba('#F1F4F6',.15+.6*fl);c.lineWidth=.8;c.beginPath();c.moveTo(-15,-6);c.lineTo(-15,6);c.moveTo(15,-6);c.lineTo(15,6);c.stroke();
    if(fl>0){c.globalCompositeOperation='lighter';var gc=c.createRadialGradient(0,0,0,0,0,30);gc.addColorStop(0,rgba('#F1F4F6',.5*fl));gc.addColorStop(1,rgba(col,0));c.fillStyle=gc;c.beginPath();c.arc(0,0,30,0,2*PI);c.fill();}c.restore();}
   glowLine(c,[LAX(0),LAX(1)],col,1,.3);
   if(e>.35){c.save();c.globalCompositeOperation='lighter';for(n=0;n<14;n++){var o2=(n-7)*14,f2=((now*.004+n*.37)%1),Q=LAX(Math.min(1,e+.1-f2*.4));c.strokeStyle=rgba('#F1F4F6',.25*(e-.35)*(1-f2));c.lineWidth=1;c.beginPath();c.moveTo(Q[0]+.535*o2,Q[1]-.845*o2);c.lineTo(Q[0]+.535*o2+300*.12,Q[1]-.845*o2+190*.12);c.stroke();}c.restore();}
   break;}
  case 1:{ /* chambre à bulles : création de paire au sommet du V ; traces courbées en sens opposés ; plaque incandescente */
   c.save();c.translate(180,486);c.scale(1.45,.42);var g4=c.createRadialGradient(0,0,0,0,0,120);g4.addColorStop(0,'rgba(255,120,40,.55)');g4.addColorStop(.6,'rgba(255,82,82,.18)');g4.addColorStop(1,'rgba(255,82,82,0)');c.fillStyle=g4;c.beginPath();c.arc(0,0,120,0,2*PI);c.fill();c.restore();
   wall(c,[[126,334],[176,334]],1,col);
   if(lt<40){EP.bA=[];EP.bB=[];}if(A&&lt>260)EP.bA.push(A.slice());if(B&&lt>260)EP.bB.push(B.slice());
   c.save();c.globalCompositeOperation='lighter';[[EP.bA,col],[EP.bB,'#A878FF']].forEach(function(o){var T=o[0]||[];for(var m=0;m<T.length;m+=2){var jt=((m*7919)%5)-2;c.fillStyle=rgba(o[1],.25+.45*m/T.length);c.beginPath();c.arc(T[m][0]+jt*.6,T[m][1]-jt*.4,.9+((m*31)%3)*.4,0,2*PI);c.fill();}});c.restore();
   for(n=0;n<12;n++){x=(n*67+now*.01)%360;y=480-((now*.05*(1+n%3)+n*41)%480);c.fillStyle=rgba(n%3?'#FF8A3C':'#FFD85A',.35);c.beginPath();c.arc(x,y,1.2+(n%3)*.5,0,2*PI);c.fill();}
   break;}
  case 0:{ /* double hélice : elles en sont les deux brins ; le trait se trace devant elles, des barreaux restent derrière */
   var e3=ease('io',cl((lt-420)/1700)),HP=[];for(n=0;n<=40;n++){var f3=n/40*Math.min(1,e3+.14);HP.push(HAX(f3));}if(lt>760){glowLine(c,HP,col,.9,.42);var hq=HP[HP.length-1],gq=c.createRadialGradient(hq[0],hq[1],0,hq[0],hq[1],9);gq.addColorStop(0,'rgba(241,244,246,.8)');gq.addColorStop(1,rgba(col,0));c.fillStyle=gq;c.beginPath();c.arc(hq[0],hq[1],9,0,2*PI);c.fill();}   /* un trait fin se trace devant elles, sa pointe lumineuse en tête */
   if(V&&V.helix){try{V.helix(c,-10,430,370,350,22,3,.011,[77,215,255],[168,120,255],.16);V.helix(c,250,-10,330,250,16,2,.013,[168,120,255],[77,215,255],.12);}catch(x2){}}
   if(V&&V.flow){c.save();c.globalAlpha=.5;try{V.flow(c,FL0);}catch(x2){}c.restore();}
   var vo2=ease('io',cl((lt-1900)/1100));EP.vo0=vo2;if(vo2>0)vortexQ(c,ORG[0],ORG[1],60*vo2,vo2,EP.dt,0);   /* l'origine s'ouvre pendant qu'elles montent : pas de coupure */
   if(lt<40)EP.rungs=[];if(A&&B&&lt>420&&(!EP.rgt||now-EP.rgt>55)){EP.rgt=now;EP.rungs.push([A.slice(),B.slice(),1]);}
   c.save();c.globalCompositeOperation='lighter';for(n=EP.rungs.length-1;n>=0;n--){var rg=EP.rungs[n];rg[2]-=EP.dt/2400;if(rg[2]<=0){EP.rungs.splice(n,1);continue;}c.strokeStyle=rgba(n%2?'#A878FF':'#F1F4F6',.6*rg[2]);c.lineWidth=1.3;c.beginPath();c.moveTo(rg[0][0],rg[0][1]);c.lineTo(rg[1][0],rg[1][1]);c.stroke();}c.restore();
   if(lt>420){var dp=Math.cos(e3*4*PI);EP.mA={sc:.85+.22*dp,al:.8+.2*dp};EP.mB={sc:.85-.22*dp,al:.8-.2*dp};}
   break;}
  }}
 function event(z,e,P){var cc=COL[z.w],V0=window.VX,gx=z.x0+P[0],gy=P[1];
  if(e[1]==='hit'){var hv=e[2]||5,nx=e[4]||0,ny=e[5]==null?-1:e[5],ix=gx-nx*R,iy=gy-ny*R;if(V0&&V0.impact){try{V0.impact({x:ix,y:iy,nx:nx,ny:ny,v:hv,mat:e[3]||0});}catch(x){}}
   burst(ix,iy,cc,10+hv*2,1.2+hv*.25);EP.hit.push({x:ix,y:iy,c:cc,l:1,v:hv,ny:ny});EP.sh=Math.max(EP.sh,.5+hv*.2);}
  else if(e[1]==='split'){burst(gx,gy,'#A878FF',30,2.2);EP.hit.push({x:gx,y:gy,c:'#A878FF',l:1,v:7,ny:0});EP.sh=Math.max(EP.sh,3);EP.zk=1.15;EP.ts=.25;}
  else if(e[1]==='tunnel'){burst(z.x0+172,gy,'#A878FF',20,1.6);EP.hit.push({x:z.x0+172,y:gy,c:'#A878FF',l:1,v:5,ny:0});}
  else if(e[1]==='seam'||e[1]==='graze'||e[1]==='pair'){burst(z.x0+e[2],e[3],e[1]==='pair'?'#F1F4F6':cc,22,2);EP.hit.push({x:z.x0+e[2],y:e[3],c:cc,l:1,v:5,ny:e[1]==='seam'?1:0});if(e[1]==='pair'){EP.sh=Math.max(EP.sh,3);EP.zk=1.25;}}
  else if(e[1]==='collide'){burst(z.x0+e[2],e[3],'#F1F4F6',26,2.6);EP.hit.push({x:z.x0+e[2],y:e[3],c:'#C8A8FF',l:1,v:8,ny:1});EP.sh=Math.max(EP.sh,4);EP.zk=1.2;}
  else if(e[1]==='spray'){burst(gx,gy+6,'#F1F4F6',18,2.2);burst(gx,gy+6,cc,10,1.6);}
  else if(e[1]==='launch'){burst(gx,gy,cc,24,2.4);EP.sh=Math.max(EP.sh,1.4);EP.ts=1.35;}
  else if(e[1]==='slow'){EP.ts=e[2]||.3;}
  else if(e[1]==='fast'){EP.ts=1.3;}
  else if(e[1]==='meet'){burst(gx,gy,'#F1F4F6',22,2);burst(gx,gy,'#A878FF',16,1.6);EP.hit.push({x:gx,y:gy,c:'#A878FF',l:1,v:6,ny:0});EP.zk=1.15;}}
 function dustPar(c,w,h,cm){if(!EP.DU){EP.DU=[];for(var a=0;a<70;a++)EP.DU.push([Math.random()*w*1.6,Math.random()*h,.3+Math.random()*.9,COL[a%12]]);}c.save();c.globalCompositeOperation='lighter';
  for(var b=0;b<EP.DU.length;b++){var q=EP.DU[b],x=((q[0]-cm.x*q[2]*.9)%(w*1.6)+w*1.6)%(w*1.6)-w*.3,y=((q[1]-cm.y*q[2]*.4)%h+h)%h;c.fillStyle=rgba(q[3],.12+.3*q[2]);c.fillRect(x,y,.6+q[2]*1.2,.6+q[2]*1.2);}c.restore();}
 function drawWorldBg(c,w,h,cm){var f=cm.x/UW,k0=Math.floor(f-.5),fr=(f-.5)-k0;if(k0<0){k0=0;fr=0;}
  [[k0,1-ease('io',cl((fr-.6)/.4))],[k0+1,ease('io',cl((fr-.6)/.4))]].forEach(function(o){if(o[1]>.01&&o[0]>=0&&o[0]<=11)bgImg(c,w,h,o[0],o[1]*.6,-(f-o[0]-.5)*w*.18);});vign(c,w,h,.38,.9);if(EP)dustPar(c,w,h,cm);}
 function epChase(c,w,h,now,t,dt,s0){var k=0;while(k<ZR.length-1&&t>=ZR[k].t0+ZR[k].d)k++;var z=ZR[k],lt=Math.min(z.d,t-z.t0);
  var A=locS(z.A,z.stA,lt),B=z.B?locS(z.B,z.stB,lt):null;
  if(z.Bf){var F=z.Bf,Bq=locS(z.A,z.stA,Math.max(0,lt-F.lag))||A,an=(F.w||0)*lt+(F.ph||0);B=Bq?[Bq[0]+(F.r||0)*Math.cos(an),Bq[1]+(F.r||0)*.75*Math.sin(an)]:null;}
  var visA=!!A,visB=!!B&&!(z.bIn&&lt<300);if(!A)A=EP.lA||z.inA;EP.lA=A;if(z.B&&!B)B=EP.lB||z.inB;if(B)EP.lB=B;
  var gA=[z.x0+A[0],A[1]],gB=B?[z.x0+B[0],B[1]]:null;
  if(gB&&EP.sB&&!(z.bIn&&lt<340)){var kb=1-Math.pow(.0004,dt/1000);EP.sB=[EP.sB[0]+(gB[0]-EP.sB[0])*kb,EP.sB[1]+(gB[1]-EP.sB[1])*kb];gB=EP.sB.slice();B=[gB[0]-z.x0,gB[1]];}else if(gB)EP.sB=gB.slice();
  (z.ev||[]).forEach(function(e,ei){var key=k+'a'+ei;if(lt>=e[0]&&!EP.seen[key]){EP.seen[key]=1;event(z,e,A);}});
  (z.evB||[]).forEach(function(e,ei){var key=k+'b'+ei;if(lt>=e[0]&&!EP.seen[key]&&B){EP.seen[key]=1;event(z,e,B);}});
  /* caméra : suit le couple, recule quand elles s'écartent, accents propres au monde */
  var mx=gA[0],my=gA[1],dx=0,dy=0;if(gB&&visB){mx=(gA[0]+gB[0])/2;my=(gA[1]+gB[1])/2;dx=Math.abs(gA[0]-gB[0]);dy=Math.abs(gA[1]-gB[1]);}
  var zc=z.cam?z.cam(lt):null,base=zc?zc.z:(k===0?1.04:.98),fit=Math.min(UW/(dx*1.25+150),UH/(dy*1.5+210)),zoom=Math.min(base,fit)*(EP.zk||1),roll=zc?zc.r:0;EP.zk=1+((EP.zk||1)-1)*Math.pow(.05,dt/1000);
  var cm=EP.cam,tx=zc&&zc.tx!=null?z.x0+zc.tx:mx-30+(zc&&zc.ox||0),ty=zc&&zc.ty!=null?zc.ty:240+(my-240)*.4+(zc&&zc.oy||0);if(!cm.ok){cm.x=tx;cm.y=ty;cm.z=.8;cm.r=0;cm.ok=true;}
  if(k!==EP.kc){if(EP.kc!=null){EP.zk=Math.min(EP.zk||1,.97);}EP.kc=k;while(cm.r<-PI)cm.r+=2*PI;while(cm.r>PI)cm.r-=2*PI;}
  var fk=1-Math.pow(.0025,dt/1000),fast=zc&&zc.fast?1.6:1;cm.x+=(tx-cm.x)*Math.min(1,fk*3.2*fast);cm.y+=(ty-cm.y)*Math.min(1,fk*2*fast);cm.z+=(zoom-cm.z)*Math.min(1,fk*1.8);cm.r+=(roll-cm.r)*Math.min(1,fk*1.6);
  drawWorldBg(c,w,h,cm);var s=s0*cm.z,sh=EP.sh;EP.sh*=Math.pow(.02,dt/1000);
  c.save();c.translate(w/2+(Math.random()-.5)*sh,h/2+(Math.random()-.5)*sh);c.rotate(cm.r);c.scale(s,s);c.translate(-cm.x,-cm.y);
  var mA=null,mB=null;for(var kk=Math.max(0,k-1);kk<=Math.min(ZR.length-1,k+1);kk++){var zz=ZR[kk],llt=kk===k?lt:kk<k?zz.d:0;c.save();c.translate(zz.x0,0);try{decoR(c,zz,llt,kk===k&&visA?A:null,kk===k&&visB?B:null,now);}catch(x){}c.restore();if(kk===k){mA=EP.mA;mB=EP.mB;}}
  if(window.VX&&VX.impacts){try{VX.impacts(c);}catch(x){}}eHits(c,dt);
  EP.tr.push(visA?gA:null);if(EP.tr.length>28)EP.tr.shift();EP.trB.push(visB?gB:null);if(EP.trB.length>18)EP.trB.shift();
  eTrail(c,EP.tr,COL[z.w],1.4);gTrail(c,EP.trB);eParts(c,dt);
  if(visA&&visB){c.save();c.strokeStyle='#A878FF';c.globalAlpha=.22;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(gA[0],gA[1]);c.lineTo(gB[0],gB[1]);c.stroke();c.setLineDash([]);c.restore();}   /* frange entre les deux branches, comme dans le jeu */
  if(visB)comp(c,gB[0],gB[1],mB&&mB.al!=null?mB.al:1,mB&&mB.sc||1,now,mB&&mB.sx,mB&&mB.sy);
  if(visA){var al=mA&&mA.al!=null?mA.al:1,hg=c.createRadialGradient(gA[0],gA[1],0,gA[0],gA[1],R*3);hg.addColorStop(0,'rgba(241,244,246,'+(.3*al).toFixed(3)+')');hg.addColorStop(1,'rgba(241,244,246,0)');c.fillStyle=hg;c.beginPath();c.arc(gA[0],gA[1],R*3,0,2*PI);c.fill();
   eBall(c,gA[0],gA[1],al,mA&&mA.sc||1,now,mA&&mA.sx,mA&&mA.sy);}
  EP.gA=gA;EP.gB=gB;
  c.restore();
  var ir=1-ease('io',cl(t/900));if(ir>0){c.fillStyle='rgba(3,4,8,'+ir.toFixed(3)+')';c.fillRect(0,0,w,h);}}
 /* la refonte : à l'horizon d'origine, elles tournent l'une autour de l'autre et ne font plus qu'une */
 function epFuse(c,w,h,now,t,dt,s0){var C=[ORG[0],ORG[1]],cm=EP.cam,tx2=C[0],ty2=240+(C[1]-240)*.4;
  var fk=1-Math.pow(.0025,dt/1000);cm.x+=(tx2-cm.x)*Math.min(1,fk*3);cm.y+=(ty2-cm.y)*Math.min(1,fk*2);cm.z+=(1.6-cm.z)*Math.min(1,fk*1.6);cm.r+=(0-cm.r)*Math.min(1,fk*3);
  drawWorldBg(c,w,h,cm);var s=s0*cm.z;c.save();c.translate(w/2,h/2);c.rotate(cm.r);c.scale(s,s);c.translate(-cm.x,-cm.y);
  var vo=t<1700?Math.max(EP.vo0||0,ease('out',cl(t/500))):Math.max(0,1-(t-1700)/500);if(vo>0)vortexQ(c,ORG[0],ORG[1],60*vo,vo,dt,0);
  var u=cl(t/1700),sp=Math.pow(u,1.8),r=34*Math.pow(1-u,.9),a=-1.6+2*PI*3.6*sp,ox=Math.cos(a)*r,oy=Math.sin(a)*r*.42,shr=Math.max(.15,1-u*u*.85);   /* elles décrivent le disque du trou noir et y plongent */
  if(t<1700&&(!EP.rpt||now-EP.rpt>Math.max(90,340*(1-u)))){EP.rpt=now;EP.rip.push({l:0});}
  c.save();c.globalCompositeOperation='lighter';for(var q=EP.rip.length-1;q>=0;q--){var rp=EP.rip[q];rp.l+=dt/1300;if(rp.l>=1){EP.rip.splice(q,1);continue;}c.strokeStyle=rgba(q%2?'#A878FF':'#4DD7FF',.4*(1-rp.l));c.lineWidth=1.4*(1-rp.l)+.3;c.beginPath();c.ellipse(C[0],C[1],8+rp.l*170,(8+rp.l*170)*.62,0,0,2*PI);c.stroke();}c.restore();
  if(t<1700){c.save();c.strokeStyle='#A878FF';c.globalAlpha=.3+.4*u;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(C[0]+ox,C[1]+oy);c.lineTo(C[0]-ox,C[1]-oy);c.stroke();c.setLineDash([]);c.restore();
   var bw=ease('io',cl(t/450)),la=EP.gA||[C[0]+ox,C[1]+oy],lb=EP.gB||[C[0]-ox,C[1]-oy],Ax=la[0]+(C[0]+ox-la[0])*bw,Ay=la[1]+(C[1]+oy-la[1])*bw,Bx=lb[0]+(C[0]-ox-lb[0])*bw,By=lb[1]+(C[1]-oy-lb[1])*bw;
   comp(c,Bx,By,1-u*.5,shr,now);eBall(c,Ax,Ay,1-u*.4,shr,now);}
  eParts(c,dt);c.restore();
  var bl=t>1650?.78*ease('io',cl((t-1650)/650)):0;if(bl>0){c.fillStyle='rgba(5,7,13,'+bl.toFixed(3)+')';c.fillRect(0,0,w,h);var fl=Math.sin(PI*cl((t-1600)/900)),g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.45);g.addColorStop(0,'rgba(255,255,255,'+(.85*fl).toFixed(3)+')');g.addColorStop(.25,'rgba(200,170,255,'+(.35*fl).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}}
 /* la danse : leur réunion crée une sphère ; elles y tournent sur des grands cercles qui précessent, et leur trace
    devient le nuage de points du noyau (rotation à trois dimensions, profondeur rendue par la taille et l'éclat) */
 function rot3(p,ax,ay){var cy=Math.cos(ay),sy=Math.sin(ay),x=p[0]*cy+p[2]*sy,z=-p[0]*sy+p[2]*cy,cx=Math.cos(ax),sx=Math.sin(ax),y=p[1]*cx-z*sx;z=p[1]*sx+z*cx;return [x,y,z];}
 function orb(th,al,be){return rot3([Math.cos(th),Math.sin(th),0],al,be);}
 /* figures de la danse : antipodes sur des grands cercles qui précessent → poursuite sur la même orbite → orbites croisées
    (elles se frôlent aux nœuds) → loxodromies d'un pôle à l'autre ; chaque figure dure ≈ 4 s et se fond dans la suivante */
 function nrm(p){var l=Math.hypot(p[0],p[1],p[2])||1;return [p[0]/l,p[1]/l,p[2]/l];}
 function fig(m,t){var th=t*.0029,al=.9*Math.sin(t*.00041),be=t*.00023;
  if(m===0)return [orb(th,al,be),orb(th+PI,al+.5*Math.sin(t*.00033),be-.4*Math.cos(t*.00027))];
  if(m===1)return [orb(th*1.3,al,be),orb(th*1.3-.55,al,be)];
  if(m===2)return [orb(th,.2,be),orb(-th,1.1,be)];
  var la=1.25*Math.sin(t*.0011),lo=th*1.6;return [[Math.cos(la)*Math.cos(lo),Math.sin(la),Math.cos(la)*Math.sin(lo)],[Math.cos(-la)*Math.cos(lo+PI),Math.sin(-la),Math.cos(-la)*Math.sin(lo+PI)]];}
 function dancePos(t){var D=4200,k=Math.floor(t/D),f=(t-k*D)/D,m0=k%4,m1=(k+1)%4,wb=f>.72?ease('io',(f-.72)/.28):0,a=fig(m0,t),b=fig(m1,t);
  return [nrm([a[0][0]+(b[0][0]-a[0][0])*wb,a[0][1]+(b[0][1]-a[0][1])*wb,a[0][2]+(b[0][2]-a[0][2])*wb]),nrm([a[1][0]+(b[1][0]-a[1][0])*wb,a[1][1]+(b[1][1]-a[1][1])*wb,a[1][2]+(b[1][2]-a[1][2])*wb])];}
 function epDance(c,w,h,now,t,dt,s0){var n,q;c.fillStyle='#05070D';c.fillRect(0,0,w,h);bgImg(c,w,h,10,.12+.1*cl(t/1500),0);vign(c,w,h,.45,.92);
  var s=s0*(1.02+.08*ease('io',cl(t/9000))),C=[180,236],Rs=118*ease('out',cl(t/1400)),spin=t*.00042,tilt=.36;
  c.save();c.translate(w/2,h/2);c.scale(s,s);c.translate(-180,-240);
  /* étoiles */
  for(n=0;n<70;n++){var sx2=(n*97)%360,sy2=(n*151)%480;c.fillStyle=rgba(COL[n%12],(.15+.25*Math.sin(now*.002+n*1.7))*cl(t/1500));c.fillRect(sx2,sy2,1.2,1.2);}
  /* mouvements propres : deux grands cercles qui précessent ; antipodes la plupart du temps, puis elles se rapprochent */
  var pr=dancePos(t),pA=pr[0],pB=pr[1];
  if(t>200){var oA=EP.oA||pA,oB=EP.oB||pB;for(var ii=1;ii<=3;ii++){var ff=ii/3,qa=[oA[0]+(pA[0]-oA[0])*ff,oA[1]+(pA[1]-oA[1])*ff,oA[2]+(pA[2]-oA[2])*ff],qb=[oB[0]+(pB[0]-oB[0])*ff,oB[1]+(pB[1]-oB[1])*ff,oB[2]+(pB[2]-oB[2])*ff],la=Math.hypot(qa[0],qa[1],qa[2])||1,lb=Math.hypot(qb[0],qb[1],qb[2])||1;EP.pts.push([qa[0]/la,qa[1]/la,qa[2]/la,0]);EP.pts.push([qb[0]/lb,qb[1]/lb,qb[2]/lb,1]);}if(EP.pts.length>2600)EP.pts.splice(0,EP.pts.length-2600);}EP.oA=pA;EP.oB=pB;
  var W2=function(p){var r=rot3(p,tilt,spin),f=1/(1-r[2]*.22);return [r[0]*f,r[1]*f,r[2]];};   /* légère perspective : le volume se lit */
  /* grands cercles de référence, très discrets (lecture 3D) */
  c.save();c.globalCompositeOperation='lighter';var fr=cl((t-800)/2000);
  for(var m=0;m<3;m++){c.beginPath();for(n=0;n<=48;n++){var pp=W2(rot3([Math.cos(n/48*2*PI),0,Math.sin(n/48*2*PI)],m*PI/3,0));var X=C[0]+pp[0]*Rs,Y=C[1]+pp[1]*Rs;n?c.lineTo(X,Y):c.moveTo(X,Y);}c.strokeStyle='rgba(77,215,255,'+(.11*fr).toFixed(3)+')';c.lineWidth=.8;c.stroke();}
  var lg=c.createRadialGradient(C[0],C[1],Rs*.82,C[0],C[1],Rs*1.12);lg.addColorStop(0,'rgba(168,120,255,0)');lg.addColorStop(.6,'rgba(168,120,255,'+(.1*fr).toFixed(3)+')');lg.addColorStop(1,'rgba(77,215,255,0)');c.fillStyle=lg;c.beginPath();c.arc(C[0],C[1],Rs*1.12,0,2*PI);c.fill();
  /* nuage de points déposés par les deux danseuses */
  for(n=0;n<EP.pts.length;n++){q=EP.pts[n];var r=W2(q),d=(r[2]+1)/2,lat=(q[1]+1)/2;
   c.fillStyle=q[3]?'rgba('+Math.round(168+60*lat)+','+Math.round(120-10*lat)+',255,'+((.16+.68*d)).toFixed(3)+')':'rgba('+Math.round(77+150*lat)+','+Math.round(215-60*lat)+','+Math.round(255-60*lat)+','+((.16+.68*d)).toFixed(3)+')';
   var sz=.7+1.4*d;c.fillRect(C[0]+r[0]*Rs-sz/2,C[1]+r[1]*Rs-sz/2,sz,sz);}
  c.restore();
  /* traînes */
  EP.dA.push(pA);EP.dB.push(pB);if(EP.dA.length>34){EP.dA.shift();EP.dB.shift();}
  c.save();c.globalCompositeOperation='lighter';c.lineCap='round';[[EP.dA,'#F1F4F6'],[EP.dB,'#A878FF']].forEach(function(o){var T=o[0];for(var a=1;a<T.length;a++){var r1=W2(T[a-1]),r2=W2(T[a]),d=(r2[2]+1)/2,f=a/T.length;c.strokeStyle=rgba(o[1],f*(.15+.5*d));c.lineWidth=(1+3.5*d)*f;c.beginPath();c.moveTo(C[0]+r1[0]*Rs,C[1]+r1[1]*Rs);c.lineTo(C[0]+r2[0]*Rs,C[1]+r2[1]*Rs);c.stroke();}});c.restore();
  /* l'axe qui les relie passe par le centre : la corrélation */
  var rA=W2(pA),rB=W2(pB);c.save();c.strokeStyle='#A878FF';c.globalAlpha=.18;c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.moveTo(C[0]+rA[0]*Rs,C[1]+rA[1]*Rs);c.lineTo(C[0]+rB[0]*Rs,C[1]+rB[1]*Rs);c.stroke();c.setLineDash([]);c.restore();
  var cg=c.createRadialGradient(C[0],C[1],0,C[0],C[1],Rs*.5);cg.addColorStop(0,'rgba(241,244,246,'+(.12+.05*Math.sin(now*.003)).toFixed(3)+')');cg.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=cg;c.beginPath();c.arc(C[0],C[1],Rs*.5,0,2*PI);c.fill();
  /* les deux particules, la plus proche dessinée en dernier, taille selon la profondeur */
  var L2=[[rA,0],[rB,1]].sort(function(a,b){return a[0][2]-b[0][2];});L2.forEach(function(o){var r=o[0],sc=.72+.45*(r[2]+1)/2,x=C[0]+r[0]*Rs,y=C[1]+r[1]*Rs;if(o[1])comp(c,x,y,.7+.3*(r[2]+1)/2,sc,now);else eBall(c,x,y,.75+.25*(r[2]+1)/2,sc,now);});
  c.restore();
  var ir=1-ease('out',cl(t/700));if(ir>0){var g=c.createRadialGradient(w/2,h*.47,0,w/2,h*.47,w*.45);g.addColorStop(0,'rgba(255,255,255,'+(.8*ir).toFixed(3)+')');g.addColorStop(.25,'rgba(200,170,255,'+(.3*ir).toFixed(3)+')');g.addColorStop(1,'rgba(168,120,255,0)');c.fillStyle=g;c.fillRect(0,0,w,h);}
  var ttl=EP.title||'';if(ttl&&t>2600){var ta=ease('io',cl((t-2600)/2600)),sp2=Math.round(14-6*ta),fs=Math.round(Math.min(w*.09,36));c.save();c.font='300 '+fs+'px "Space Grotesk","Avenir Next",system-ui,sans-serif';c.textBaseline='middle';
   var ws=[],tw=0,q2;for(q2=0;q2<ttl.length;q2++){var cw=c.measureText(ttl[q2]).width;ws.push(cw);tw+=cw+(q2<ttl.length-1?sp2:0);}var x0=w/2-tw/2,y0=h*.14+(1-ta)*6;
   c.shadowColor='rgba(77,215,255,'+(.6*ta).toFixed(3)+')';c.shadowBlur=18*ta;for(q2=0;q2<ttl.length;q2++){var la=cl(ta*1.6-q2*.08);c.fillStyle='rgba(241,244,246,'+(.92*la).toFixed(3)+')';c.fillText(ttl[q2],x0,y0);x0+=ws[q2]+sp2;}
   c.shadowBlur=0;var lw=tw*.5*ta;c.fillStyle='rgba(168,120,255,'+(.45*ta).toFixed(3)+')';c.fillRect(w/2-lw/2,y0+fs*.72,lw,1);c.restore();}   /* titre final, lettre après lettre */
  return t>7000;}
 function epilogue(c,w,h,now,opt){
  if(!EP||now<EP.T0){EP={T0:now,last:now,cam:{ok:false},tr:[],trB:[],seen:{},hit:[],syn:[],rip:[],pts:[],dA:[],dB:[],sh:0,zk:1,ct:0,ts:1,tf:0,bA:[],bB:[],rungs:[]};for(var pk=0;pk<11;pk++)img(pk);parts=[];}
  var dt=Math.max(0,Math.min(60,now-EP.last));EP.last=now;EP.dt=dt;now0=now;dtD=dt;EP.title=opt&&opt.title||'';
  var t=now-EP.T0,s0=Math.min(w/UW,h/UH),done=false,SPD=1.12;
  c.fillStyle='#05070D';c.fillRect(0,0,w,h);
  if(EP.ct<TRT){EP.ts+=(1-EP.ts)*(1-Math.pow(EP.ts<1?.12:.3,dt/1000));var dd=dt*SPD*EP.ts;EP.ct=Math.min(TRT,EP.ct+dd);epChase(c,w,h,now,EP.ct,dd,s0);if(EP.ct>=TRT)EP.tf=t;}
  else if(t-EP.tf<TH)epFuse(c,w,h,now,t-EP.tf,dt,s0);else done=epDance(c,w,h,now,t-EP.tf-TH,dt,s0);
  return {t:t,ground:done};
 }
 return {frame:frame,epilogue:epilogue,epReset:function(){EP=null;},total:function(){return TOT;},reset:function(){T0=null;last=0;hold=0;flashA=0;},setBase:function(b){imgBase=b;}};
})();
if(typeof window!=='undefined')window.QHERO=QHERO;
