/* ===== ETAGE 8A DEBUT ===== R516 · Monde 8 (Magnétisme) — étage 8 des créatures actives, première créature : la CYDIPPE
   Fichier propre (aucune ligne des créatures existantes n'est touchée), chargé juste après qxetage7d.js.
   · PHYSIQUE : enveloppe FLUID.crForce / FLUID.crPos. Tout niveau sans cydippe : l'enveloppe appelle l'original et s'arrête là
     (trajectoires strictement inchangées).
   · RENDU : window.QXE6.cydippe (table de dessin appelée par qxcrea.js dessinerAct) ; corps pré-calculé en atlas (palettes qui battent).
   cydippe (cténophore Pleurobrachia, « groseille de mer ») : un œuf de gelée épais, huit rangées de palettes irisées qui battent en
          vagues, deux longs tentacules frangés qui traînent. Elle dérive lentement (x ± ax, y ± ay, pulsation w, phase ph).
          Elle porte un CHAMP VIVANT : tant que la particule passe près d'elle (poids gaussien exp(-d²/r²)), sa vitesse TOURNE de
          k radians par image × poids, dans le sens sg (+1 horaire à l'écran, -1 antihoraire). La vitesse n'est jamais ni prise ni
          réduite (rotation pure, comme la force de Lorentz) : pas de capture, la particule glisse en courbe le long de la créature.
          Effet neuf : une LENTILLE VIVANTE et mobile — ce n'est plus le décor qui courbe, c'est elle, là où elle se trouve à cet instant.
   Tout est fonction de S.frames et de la bille : solutions et rejeux exacts ; remise à zéro quand frames<=1 (crForce d'origine). */
(function (racine) {
'use strict';
const F = racine.FLUID;
if (!F || !F.crForce || F.e8a) return;
F.e8a = 1;
const oForce = F.crForce, oPos = F.crPos, CACHE = new WeakMap();
function aMiens(lv) { const cr = lv.cr; if (!cr) return false; let v = CACHE.get(cr); if (v === undefined) { v = cr.some(c => c.t === 'cydippe'); CACHE.set(cr, v); } return v; }
function cyPos(e, t) { const w = e.w || .006, ph = e.ph || 0; return [e.x + (e.ax || 0) * Math.sin(t * w + ph), e.y + (e.ay || 0) * Math.sin(t * w * .71 + ph * 1.3)]; }
F.crPos = function (e, t) { return e.t === 'cydippe' ? cyPos(e, t) : oPos(e, t); };
F.e8aPos = cyPos;
F.crForce = function (b, sub, lv, g) {
  if (!aMiens(lv)) return oForce(b, sub, lv, g);
  oForce(b, sub, lv, g);                                // autres créatures + remise à zéro (frames<=1)
  const t = S.frames, cs = b.cs || (b.cs = {}), cr = lv.cr;
  for (let i = 0; i < cr.length; i++) {
    const e = cr[i]; if (e.t !== 'cydippe') continue;
    const q = cyPos(e, t), dx = b.x - q[0], dy = b.y - q[1], r = e.r || 60, wg = Math.exp(-(dx * dx + dy * dy) / (r * r));
    const st = cs[i] || (cs[i] = { on: -99, wg: 0, tot: 0 });
    if (wg < .02) continue;
    const a = (e.k || .05) * wg * (e.sg < 0 ? -1 : 1) / (sub || 1), c = Math.cos(a), s = Math.sin(a), vx = b.vx;
    b.vx = vx * c - b.vy * s; b.vy = vx * s + b.vy * c;
    if (st.on < t - 30 && racine.BUS) BUS.emit('creature.catch', { x: b.x, y: b.y });
    st.on = t; st.wg = wg; st.tot += Math.abs(a);
  }
};

/* ───────────── RENDU : atlas pré-calculé (œuf de gelée épais éclairé, 8 rangées de palettes irisées, pharynx, poches tentaculaires)
   NA images d'un battement complet des palettes (vague de la bouche vers le pôle aboral) ; en jeu : drawImage incliné + roulis léger
   (largeur ≥ 0,84 : jamais plat), tentacules dessinés en direct (chaîne qui suit, franges de tentilles), lueur additive pré-rendue. */
const NA = 20, AW = 84, AH = 100, DPR = 2, RX = 25, RY = 33;
const PAL = { 1: { b0: '30,60,120', b1: '150,214,255', b2: '226,246,255', rim: '220,246,255', hue: 215 },
             '-1': { b0: '72,36,104', b1: '238,170,236', b2: '255,236,250', rim: '255,230,250', hue: 290 } };
const ATL = {};
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function atl(sg) { const k = sg < 0 ? '-1' : 1; return ATL[k] || (ATL[k] = { c: cv(AW * DPR * NA, AH * DPR), fait: new Uint8Array(NA), n: 0, k }); }
function atlasF(A, f) {
  if (A.fait[f]) return; A.fait[f] = 1; A.n++;
  const g = A.c.getContext('2d'), P = PAL[A.k], ph = f / NA * Math.PI * 2;
  g.save(); g.translate((f * AW + AW / 2) * DPR, (AH / 2 + 4) * DPR); g.scale(DPR, DPR); g.lineCap = 'round'; g.lineJoin = 'round';
  /* silhouette : œuf, bouche (haut, y<0) un peu plus étroite, pôle aboral arrondi ; légère pulsation du gel */
  const pu = 1 + .025 * Math.sin(ph), rx = RX * pu, ry = RY / Math.sqrt(pu);
  const prof = v => Math.sqrt(Math.max(0, 1 - v * v)) * (1 - .1 * Math.max(0, -v));     // v ∈ [-1,1] (−1 bouche)
  const corps = () => { g.beginPath(); for (let k = 0; k <= 48; k++) { const a = k / 48 * Math.PI * 2, v = -Math.cos(a); g.lineTo(rx * Math.sin(a) * (1 - .1 * Math.max(0, -v)), ry * v); } g.closePath(); };
  /* volume : dégradé radial décentré (lumière haut-gauche), bords sombres = épaisseur */
  corps(); let gr = g.createRadialGradient(-rx * .35, -ry * .4, 2, 0, 0, ry * 1.08);
  gr.addColorStop(0, 'rgba(' + P.b2 + ',.62)'); gr.addColorStop(.35, 'rgba(' + P.b1 + ',.42)'); gr.addColorStop(.78, 'rgba(' + P.b0 + ',.5)'); gr.addColorStop(1, 'rgba(' + P.b0 + ',.78)');
  g.fillStyle = gr; g.fill();
  g.save(); g.clip();
  /* pharynx (canal central lumineux) et canaux méridiens */
  gr = g.createLinearGradient(-6, 0, 6, 0); gr.addColorStop(0, 'rgba(' + P.b1 + ',0)'); gr.addColorStop(.5, 'rgba(' + P.b2 + ',.42)'); gr.addColorStop(1, 'rgba(' + P.b1 + ',0)');
  g.fillStyle = gr; g.beginPath(); g.ellipse(0, -ry * .25, 4.2 + .6 * Math.sin(ph * 2), ry * .62, 0, 0, 7); g.fill();
  g.fillStyle = 'rgba(' + P.b2 + ',.5)'; g.beginPath(); g.ellipse(0, ry * .62, 3, 2.4, 0, 0, 7); g.fill();          // statocyste (pôle aboral)
  /* poches tentaculaires (deux sacs latéraux, vus par transparence) */
  for (const sd of [-1, 1]) { g.fillStyle = 'rgba(' + P.b1 + ',.28)'; g.beginPath(); g.ellipse(sd * rx * .42, ry * .25, 4, 10, sd * .25, 0, 7); g.fill(); }
  /* 8 rangées de palettes : 5 visibles (avant) ; méridien φ, x = rx·sinφ·prof(v) ; palettes = petits traits dont la couleur glisse */
  for (let m = 0; m < 8; m++) {
    const phi = (m + .5) / 8 * Math.PI * 2, cz = Math.cos(phi); if (cz < -.25) continue;      // face cachée : on ne la voit pas
    const sx = Math.sin(phi), dep = .45 + .55 * Math.max(0, cz);
    g.beginPath(); for (let k = 0; k <= 20; k++) { const v = -.86 + k / 20 * 1.62; const x = rx * sx * prof(v), y = ry * v; k ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.strokeStyle = 'rgba(' + P.rim + ',' + (.16 * dep) + ')'; g.lineWidth = 1.6; g.stroke();
    g.globalCompositeOperation = 'lighter';
    for (let k = 0; k < 16; k++) {                    // palettes : petites lames qui diffractent (bleu → violet → rose, jamais d'or)
      const v = -.8 + k / 15 * 1.52, x = rx * sx * prof(v), y = ry * v, bat = Math.sin(ph - k * .62 + m * .4);
      const hu = (P.hue + 70 * Math.sin(ph - k * .5 + m) + 360) % 360, al = (.16 + .55 * Math.max(0, bat)) * dep;
      g.strokeStyle = 'hsla(' + hu.toFixed(0) + ',95%,70%,' + al.toFixed(2) + ')'; g.lineWidth = 2.1 + 1.2 * Math.max(0, bat);
      const l = 1.2 + 1.8 * Math.max(0, bat); g.beginPath(); g.moveTo(x - l * .5, y - 1.2); g.lineTo(x + l * .5, y + .4 + 1.2 * bat); g.stroke();
    }
    g.globalCompositeOperation = 'source-over';
  }
  g.restore();
  /* liseré (gel épais) + reflet haut */
  corps(); g.strokeStyle = 'rgba(' + P.rim + ',.72)'; g.lineWidth = 1.1; g.stroke();
  g.beginPath(); g.ellipse(-rx * .38, -ry * .45, rx * .28, ry * .16, -.5, Math.PI * 1.05, Math.PI * 1.85); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 2; g.stroke();
  /* bouche : lèvres */
  g.beginPath(); g.ellipse(0, -ry * .93, 5.5, 2, 0, 0, 7); g.strokeStyle = 'rgba(' + P.rim + ',.6)'; g.lineWidth = 1; g.stroke();
  g.restore();
}
function atlasTout(sg) { const A = atl(sg); for (let f = 0; f < NA; f++) atlasF(A, f); return A.c; }
let GLOW = null;
function glow() {
  if (GLOW) return GLOW; const s = 128, c = cv(s, s), g = c.getContext('2d'), r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  r.addColorStop(0, 'rgba(160,200,255,.5)'); r.addColorStop(.45, 'rgba(150,130,255,.16)'); r.addColorStop(1, 'rgba(110,90,220,0)'); g.fillStyle = r; g.fillRect(0, 0, s, s); return (GLOW = c);
}
const PRE = {};
function prechauffe8(sg) {                           // tranches de fond : ≤ 2 ms par image d'animation, jusqu'à l'atlas complet
  const A = atl(sg); if (PRE[A.k]) return; PRE[A.k] = 1; glow();
  const pas = () => { const t0 = performance.now(); let f = 0;
    while (A.n < NA && performance.now() - t0 < 2) { while (A.fait[f]) f++; atlasF(A, f); }
    if (A.n < NA) (racine.requestAnimationFrame || setTimeout)(pas); };
  pas();
}
function proche(A, fi) { if (A.fait[fi]) return fi; for (let d = 1; d < NA; d++) { const a = (fi + d) % NA, b = (fi - d + NA) % NA; if (A.fait[a]) return a; if (A.fait[b]) return b; } atlasF(A, fi); return fi; }
/* tentacule : chaîne de NT points qui suit l'attache (pas de saut), traîne derrière le mouvement et ondule de la base vers la pointe */
const NT = 16, SEG = 7.5;
function tentacule(ctx, T, ox, oy, dir, P, ondu, vers, al) {
  for (let k = 1; k < NT; k++) {
    const px = T[(k - 1) * 2], py = T[(k - 1) * 2 + 1], o = Math.sin(ondu - k * .55) * (.25 + k * .03);
    const tx = px + Math.cos(dir + o) * SEG + vers[0] * k * .06, ty = py + Math.sin(dir + o) * SEG + vers[1] * k * .06;
    T[k * 2] += (tx - T[k * 2]) * .22; T[k * 2 + 1] += (ty - T[k * 2 + 1]) * .22;
    const dx = T[k * 2] - px, dy = T[k * 2 + 1] - py, l = Math.hypot(dx, dy) || 1; T[k * 2] = px + dx / l * SEG; T[k * 2 + 1] = py + dy / l * SEG;
  }
  T[0] = ox; T[1] = oy;
  ctx.beginPath(); ctx.moveTo(T[0], T[1]); for (let k = 1; k < NT - 1; k++) ctx.quadraticCurveTo(T[k * 2], T[k * 2 + 1], (T[k * 2] + T[k * 2 + 2]) / 2, (T[k * 2 + 1] + T[k * 2 + 3]) / 2);
  ctx.strokeStyle = 'rgba(' + P.b1 + ',' + (.55 * al) + ')'; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.beginPath();                                    // tentilles (franges fines d'un seul côté, qui flottent)
  for (let k = 2; k < NT; k += 1) { const x = T[k * 2], y = T[k * 2 + 1], a = Math.atan2(y - T[k * 2 - 1], x - T[k * 2 - 2]) + 1.25 + .3 * Math.sin(ondu * 1.3 - k), l = 5 - k * .18;
    ctx.moveTo(x, y); ctx.quadraticCurveTo(x + Math.cos(a) * l * .6, y + Math.sin(a) * l * .6, x + Math.cos(a + .5) * l, y + Math.sin(a + .5) * l); }
  ctx.strokeStyle = 'rgba(' + P.rim + ',' + (.32 * al) + ')'; ctx.lineWidth = .6; ctx.stroke();
}
function dessinerCydippe(ctx, e, x, y, etat, st, b, T, dt, fr, run) {
  const c = e.c, sg = c.sg < 0 ? -1 : 1, A = atl(sg), G = glow(), P = PAL[A.k], s0 = c.s || 1; if (!PRE[A.k]) prechauffe8(sg);
  st = run ? (st || {}) : {};
  if (!run) e.idF = (e.idF == null ? 0 : e.idF) + dt * 60;
  const t = run ? fr : e.idF, q = cyPos(c, t), q1 = cyPos(c, t + 4), vx = q1[0] - q[0], vy = q1[1] - q[1];
  /* champ actif : poids lissé (montée douce, retombée lente) */
  const on = run && b && st.on != null && fr - st.on < 3 ? (st.wg || 0) : 0;
  e.lum8 = (e.lum8 == null ? 0 : e.lum8) + (on - (e.lum8 || 0)) * Math.min(1, dt * (on > e.lum8 ? 5 : 1.2));
  /* attitude : bouche vers le haut, inclinée vers la dérive (jamais de demi-tour) ; roulis lent ; vers la particule quand le champ agit */
  let tilt = Math.max(-.6, Math.min(.6, vx * .9)) + .12 * Math.sin(T * .37 + (c.ph || 0));
  if (b && run && e.lum8 > .05) tilt += Math.max(-.35, Math.min(.35, (b.x - q[0]) / 160)) * e.lum8;
  e.tl8 = (e.tl8 == null ? tilt : e.tl8 + (tilt - e.tl8) * Math.min(1, dt * 1.4));
  e.ph8 = ((e.ph8 || 0) + dt * (.42 + .9 * e.lum8)) % 1;            // battement des palettes : plus vif quand le champ agit
  const roll = .86 + .14 * Math.cos(T * .29 + (c.ph || 0)), fi = proche(A, Math.floor(e.ph8 * NA) % NA);
  const lum = .4 + .2 * Math.sin(T * .5 + (c.ph || 0)) + .6 * e.lum8;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const gs = (96 + 40 * e.lum8) * s0; ctx.globalAlpha = Math.min(1, .35 + .45 * lum); ctx.drawImage(G, q[0] - gs / 2, q[1] - gs / 2, gs, gs);
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  /* tentacules : attaches aux deux poches, traînent à l'opposé de la dérive + vers le bas ; se tendent vers la particule si le champ agit */
  if (!e.T8) { e.T8 = [new Float32Array(NT * 2), new Float32Array(NT * 2)]; e.T8i = 0; }
  const ca = Math.cos(e.tl8), sa = Math.sin(e.tl8), dirB = Math.atan2(-vy * 3 + 1, -vx * 3) , ondu = T * 1.1;
  let vers = [0, 0]; if (b && run && e.lum8 > .05) vers = [(b.x - q[0]) * .03 * e.lum8, (b.y - q[1]) * .03 * e.lum8];
  for (let j = 0; j < 2; j++) {
    const sd = j ? 1 : -1, lx = sd * RX * .5 * s0 * roll, ly = RY * .32 * s0, ox = q[0] + lx * ca - ly * sa, oy = q[1] + lx * sa + ly * ca, Tt = e.T8[j];
    if (!e.T8i || Math.hypot(Tt[0] - ox, Tt[1] - oy) > 80) for (let k = 0; k < NT; k++) { Tt[k * 2] = ox + Math.cos(dirB + sd * .2) * SEG * k; Tt[k * 2 + 1] = oy + Math.sin(dirB + sd * .2) * SEG * k; }
    tentacule(ctx, Tt, ox, oy, dirB + sd * .22, P, ondu + j * 1.7, vers, .8 + .2 * e.lum8);
  }
  e.T8i = 1;
  ctx.translate(q[0], q[1]); ctx.rotate(e.tl8); ctx.scale(s0 * roll, s0);
  ctx.drawImage(A.c, fi * AW * DPR, 0, AW * DPR, AH * DPR, -AW / 2, -AH / 2 - 4, AW, AH);
  if (e.lum8 > .03) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .5 * e.lum8; ctx.drawImage(A.c, fi * AW * DPR, 0, AW * DPR, AH * DPR, -AW / 2, -AH / 2 - 4, AW, AH); }
  ctx.restore();
  if (b && run && e.lum8 > .05) {   // la particule infléchie : petite lueur partagée qui s'éteint en douceur
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .5 * e.lum8; ctx.drawImage(G, b.x - 16, b.y - 16, 32, 32); ctx.restore();
  }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
(racine.QXE6 = racine.QXE6 || {}).cydippe = dessinerCydippe;
racine.QXE8A = { cydippe: dessinerCydippe, atlas: atlasTout, prechauffe: prechauffe8 };
function accroche() {
  const ll = racine.loadLevel; if (typeof ll !== 'function' || ll.e8a) return;
  const w = racine.loadLevel = function (i) { const r = ll.apply(this, arguments);
    try { const lv = racine.LEVELS && racine.LEVELS[i]; if (lv && lv.cr) lv.cr.forEach(c => { if (c.t === 'cydippe') prechauffe8(c.sg); }); } catch (e) {} return r; };
  w.e8a = 1;
}
if (typeof document !== 'undefined') { if (document.readyState === 'complete') accroche(); else racine.addEventListener('load', accroche); }
})(typeof window !== 'undefined' ? window : globalThis);
/* ===== ETAGE 8A FIN ===== */
