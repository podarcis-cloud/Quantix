/* ══ fin-sound.js — R234 · bande son de la fin « Les retrouvailles » (global QFINS) ══
   Partition écrite sur la chronologie de fin5 (QHERO.fin5.acts(), QHERO.fin5.cues()) : une couleur par monde traversé,
   le thème de cinq notes (le fil conducteur MOTIF de sound.js) partagé entre les deux particules — la blanche en verre,
   la violette en voix « guimauve » —, chaque geste physique fort ponctué, des silences pour que les chocs comptent.
   Tout en fa♯ lydien ; notes ≤ 520 Hz, partiels ≤ 1,5 kHz (charte F2) ; rien ne sature (compresseur doux en sortie).
   Synthèse WebAudio, aucun fichier son.
   Arc : la coupe (cœur, onde) → Quantique (le thème se dédouble) → Filaments, Faille, Magnétisme (l'accélérateur
   s'emballe) → Gravité (lourd) → Mécanique (horlogerie) → Soufflerie → Glacier (quintes, givre) → Chaîne → Fonderie
   (bulles, plaques) → Atelier (le trait s'électrise, l'impact, la poussière, le vol libre en double hélice, le siphon)
   → plongée (tout descend dans le grave) → naissance → danse : le thème à l'unisson, puis en accords, en boucle.
   API : QFINS.unlock() sur un geste ; QFINS.sync(tFilm, joue, vitesse) à chaque image ; QFINS.stop() ;
   QFINS.render(ctx, dest, t0, t1) planifie une plage dans un contexte hors ligne ; QFINS.set(bool), QFINS.vol(v). */
var QFINS=(function(){
'use strict';
var ROOT=54,LYD=[0,2,4,6,7,9,11],MOTIF=[0,2,4,3,1];
function mtof(n){return 440*Math.pow(2,(n-69)/12);}
function hz(deg,oct){var n=7,i=((deg%n)+n)%n;return mtof(ROOT+LYD[i]+12*(Math.floor(deg/n)+(oct||0)));}
function cap(f){while(f>523)f/=2;return f;}
function rnd(n){var x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);}
var CH={I:[0,2,4,6],II:[1,3,5,7],vi:[5,7,9,11],V:[4,6,8],iii:[2,4,6],Q:[0,4,8,12]};   /* Q : quintes empilées (Glacier) */

/* ───────── moteur (un par contexte audio) ───────── */
function impulse(ac,sec,decay){var n=Math.floor(ac.sampleRate*sec),b=ac.createBuffer(2,n,ac.sampleRate),c,i;
 for(c=0;c<2;c++){var d=b.getChannelData(c);for(i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,decay);}return b;}
function engine(ac,dest){var E={ac:ac,live:[],late:0};
 var master=ac.createGain();master.gain.value=.85;
 var guard=ac.createBiquadFilter();guard.type='lowpass';guard.frequency.value=5200;guard.Q.value=.5;
 var comp=ac.createDynamicsCompressor();comp.threshold.value=-14;comp.knee.value=12;comp.ratio.value=2.5;comp.attack.value=.012;comp.release.value=.3;
 master.connect(guard);guard.connect(comp);comp.connect(dest);
 var rev=ac.createConvolver();rev.buffer=impulse(ac,4.2,2.6);var rlp=ac.createBiquadFilter();rlp.type='lowpass';rlp.frequency.value=2600;
 var rg=ac.createGain();rg.gain.value=.62;rev.connect(rlp);rlp.connect(rg);rg.connect(master);
 var dIn=ac.createGain(),dl=ac.createDelay(2),dr=ac.createDelay(2),fb=ac.createGain(),dlp=ac.createBiquadFilter(),dg=ac.createGain();
 dl.delayTime.value=.42;dr.delayTime.value=.63;fb.gain.value=.32;dlp.type='lowpass';dlp.frequency.value=1300;dg.gain.value=.34;
 dIn.connect(dlp);dlp.connect(dl);dl.connect(dr);dr.connect(fb);fb.connect(dl);
 if(ac.createStereoPanner){var pl=ac.createStereoPanner(),pr=ac.createStereoPanner();pl.pan.value=-.7;pr.pan.value=.7;dl.connect(pl);dr.connect(pr);pl.connect(dg);pr.connect(dg);}else{dl.connect(dg);dr.connect(dg);}
 dg.connect(master);
 var nb=ac.createBuffer(1,ac.sampleRate*3,ac.sampleRate),nd=nb.getChannelData(0);for(var i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;
 E.master=master;E.rev=rev;E.dly=dIn;E.noise=nb;return E;}
/* sortie d'une voix : panoramique, réverbération, écho ; gardée pour pouvoir l'éteindre (recherche, pause) */
function out(E,node,pan,wet,dwet,srcs,end){var o=E.ac.createGain(),last=node;node.connect(o);
 if(pan&&E.ac.createStereoPanner){var p=E.ac.createStereoPanner();p.pan.value=Math.max(-1,Math.min(1,pan));o.connect(p);last=p;}else last=o;
 last.connect(E.master);if(wet){var r=E.ac.createGain();r.gain.value=wet;last.connect(r);r.connect(E.rev);}
 if(dwet){var d=E.ac.createGain();d.gain.value=dwet;last.connect(d);d.connect(E.dly);}
 E.live.push({o:o,s:srcs,end:end});return o;}
function env(E,g,t,atk,peak,dur){var a=Math.max(atk,E.late);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(peak,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+Math.max(a+.05,dur));}
function osc(E,type,f,t,end){var o=E.ac.createOscillator();o.type=type;o.frequency.setValueAtTime(f,t);o.start(t);o.stop(end);return o;}
function noiseSrc(E,t,end){var s=E.ac.createBufferSource();s.buffer=E.noise;s.loop=true;s.start(t,Math.random()*2);s.stop(end);return s;}

/* ───────── instruments ───────── */
var V={
 /* verre : fondamentale, double à 1,004, partiel inharmonique 2,76 très discret (la particule blanche) */
 bell:function(E,t,f,dur,g,pan,wet,dwet){f=cap(f);var e=E.ac.createGain(),lp=E.ac.createBiquadFilter(),end=t+dur+.1;lp.type='lowpass';lp.frequency.value=Math.min(1500,f*2.2);
  var a=osc(E,'sine',f,t,end),b=osc(E,'sine',f*1.004,t,end),c=osc(E,'sine',Math.min(1500,f*2.76),t,end),gc=E.ac.createGain();gc.gain.value=.05;
  a.connect(e);b.connect(e);c.connect(gc);gc.connect(e);e.connect(lp);env(E,e,t,.006,g,dur);out(E,lp,pan,wet==null?.45:wet,dwet||0,[a,b,c],end);},
 /* guimauve : triangle filtré, attaque douce, léger glissé d'arrivée (la particule violette) */
 mallow:function(E,t,f,dur,g,pan,wet,dwet,gl){f=cap(f);var e=E.ac.createGain(),lp=E.ac.createBiquadFilter(),end=t+dur+.1,o=osc(E,'triangle',f*(gl||1.012),t,end);
  o.frequency.exponentialRampToValueAtTime(f,t+.09);lp.type='lowpass';lp.Q.value=.4;lp.frequency.setValueAtTime(Math.min(1400,f*3.4),t);lp.frequency.exponentialRampToValueAtTime(Math.max(160,f*1.3),t+dur);
  o.connect(lp);lp.connect(e);env(E,e,t,.03,g,dur);out(E,e,pan,wet==null?.4:wet,dwet||0,[o],end);},
 /* corde pincée : dent de scie, filtre qui se referme vite (Filaments, Chaîne) */
 pluck:function(E,t,f,dur,g,pan,wet,dwet){f=cap(f);var e=E.ac.createGain(),lp=E.ac.createBiquadFilter(),end=t+dur+.1,o=osc(E,'sawtooth',f,t,end),o2=osc(E,'triangle',f*.5,t,end),g2=E.ac.createGain();g2.gain.value=.5;
  lp.type='lowpass';lp.Q.value=2;lp.frequency.setValueAtTime(Math.min(1500,f*6),t);lp.frequency.exponentialRampToValueAtTime(Math.max(120,f*1.1),t+dur*.6);
  o.connect(lp);o2.connect(g2);g2.connect(lp);lp.connect(e);env(E,e,t,.004,g,dur);out(E,e,pan,wet==null?.35:wet,dwet==null?.25:dwet,[o,o2],end);},
 /* nappe : deux triangles légèrement désaccordés par note, filtre fixe, naît et s'éteint lentement, sans glissement */
 pad:function(E,t,fs,dur,g,atk,rel,cut){var e=E.ac.createGain(),lp=E.ac.createBiquadFilter(),end=t+dur+rel+.2,src=[];lp.type='lowpass';lp.frequency.value=cut||820;lp.Q.value=.3;
  fs.forEach(function(f,k){f=cap(f);[-1,1].forEach(function(s){var o=osc(E,'triangle',f*(1+s*.0022),t,end);o.connect(lp);src.push(o);});});
  var a=Math.max(atk,E.late),pk=g/Math.sqrt(fs.length);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(pk,t+a);e.gain.setValueAtTime(pk,t+Math.max(a,dur));e.gain.exponentialRampToValueAtTime(.0001,t+Math.max(a,dur)+rel);
  lp.connect(e);out(E,e,0,.55,0,src,end);},
 /* grave tenu */
 sub:function(E,t,f,dur,g,atk){var e=E.ac.createGain(),end=t+dur+.2,o=osc(E,'sine',f,t,end);o.connect(e);g*=.55;
  var a=Math.max(atk||.4,E.late);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+a);e.gain.setValueAtTime(g,t+Math.max(a,dur-.6));e.gain.exponentialRampToValueAtTime(.0001,t+dur);out(E,e,0,.1,0,[o],end);},
 /* choc sourd : sinus qui chute (Gravité, réceptions) */
 thump:function(E,t,g,f0,f1,dur){dur=dur||.55;f0=Math.max(150,(f0||120)*1.6);f1=Math.max(62,(f1||44)*1.5);V.wood(E,t,f0*1.5,g*.18,0);var e=E.ac.createGain(),end=t+dur+.05,o=osc(E,'sine',f0,t,end);o.frequency.exponentialRampToValueAtTime(f1,t+dur*.7);
  o.connect(e);env(E,e,t,.004,g,dur);out(E,e,0,.18,0,[o],end);},
 /* souffle filtré qui glisse */
 breath:function(E,t,dur,f0,f1,g,q,pan,wet){var s=noiseSrc(E,t,t+dur+.1),bp=E.ac.createBiquadFilter(),e=E.ac.createGain();bp.type='bandpass';bp.Q.value=q||1.3;
  bp.frequency.setValueAtTime(f0,t);bp.frequency.exponentialRampToValueAtTime(f1,t+dur);s.connect(bp);bp.connect(e);
  var a=Math.max(dur*.4,E.late);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+a);e.gain.exponentialRampToValueAtTime(.0001,t+dur);out(E,e,pan||0,wet==null?.5:wet,0,[s],t+dur+.1);},
 /* grain : bruit très résonant, une hauteur fugitive (crépitement, poussière, givre) */
 grain:function(E,t,f,len,g,pan){var s=noiseSrc(E,t,t+len+.05),bp=E.ac.createBiquadFilter(),e=E.ac.createGain();bp.type='bandpass';bp.frequency.value=Math.min(1500,f);bp.Q.value=24;
  s.connect(bp);bp.connect(e);e.gain.setValueAtTime(0,t);e.gain.linearRampToValueAtTime(g,t+len*.4);e.gain.linearRampToValueAtTime(0,t+len);out(E,e,pan||0,.5,.2,[s],t+len+.05);},
 /* bois : trois modes (horlogerie, cliquets, petits chocs) */
 wood:function(E,t,f,g,pan){[[1,30,1],[2.76,24,.42],[5.4,18,.16]].forEach(function(m){var fr=f*m[0];if(fr>1500)return;var s=noiseSrc(E,t,t+.5),bp=E.ac.createBiquadFilter(),e=E.ac.createGain();bp.type='bandpass';bp.frequency.value=fr;bp.Q.value=m[1];
  s.connect(bp);bp.connect(e);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g*m[2]*7,t+.003);e.gain.exponentialRampToValueAtTime(.0001,t+.3/m[0]+.06);out(E,e,pan||0,.3,.12,[s],t+.5);});},
 /* goutte / bulle : sinus qui tombe d'une quinte */
 drop:function(E,t,f,g,pan){f=cap(f);var e=E.ac.createGain(),end=t+.3,o=osc(E,'sine',f*1.5,t,end);o.frequency.exponentialRampToValueAtTime(f,t+.03);
  o.connect(e);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+.004);e.gain.exponentialRampToValueAtTime(.0001,t+.22);out(E,e,pan||0,.5,.3,[o],end);},
 /* glissando de sinus (dédoublement, faille, spirale) */
 glide:function(E,t,f0,f1,dur,g,pan,wet){var e=E.ac.createGain(),end=t+dur+.1,o=osc(E,'sine',cap(f0),t,end);o.frequency.exponentialRampToValueAtTime(cap(f1),t+dur);
  o.connect(e);var a=Math.max(Math.min(.08,dur*.3),E.late);e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+a);e.gain.exponentialRampToValueAtTime(.0001,t+dur);out(E,e,pan||0,wet==null?.5:wet,.2,[o],end);},
 /* bouffée d'air (élan, saut, éjection, portail) : bruit passe-bas qui s'ouvre puis se referme */
 whoosh:function(E,t,dur,g,up,pan){var s=noiseSrc(E,t,t+dur+.1),lp=E.ac.createBiquadFilter(),e=E.ac.createGain();lp.type='lowpass';lp.Q.value=4;
  lp.frequency.setValueAtTime(up?260:1300,t);lp.frequency.exponentialRampToValueAtTime(up?1300:240,t+dur*.8);s.connect(lp);lp.connect(e);
  e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(g,t+dur*.45);e.gain.exponentialRampToValueAtTime(.0001,t+dur);out(E,e,pan||0,.45,.15,[s],t+dur+.1);},
 /* montée : grave qui enfle et s'ouvre (tension avant un geste) */
 riser:function(E,t,dur,f,g){var e=E.ac.createGain(),lp=E.ac.createBiquadFilter(),end=t+dur+.3,o=osc(E,'sawtooth',f,t,end),o2=osc(E,'sawtooth',f*1.007,t,end);
  lp.type='lowpass';lp.Q.value=5;lp.frequency.setValueAtTime(150,t);lp.frequency.exponentialRampToValueAtTime(1200,t+dur);o.connect(lp);o2.connect(lp);lp.connect(e);
  e.gain.setValueAtTime(.0001,t);e.gain.exponentialRampToValueAtTime(g,t+dur);e.gain.exponentialRampToValueAtTime(.0001,t+dur+.25);out(E,e,0,.35,0,[o,o2],end);},
 /* R234 c · bruitage d'impact : attaque claquée (bruit filtré 12 ms) + corps (sinus qui chute) + résonance de la matière.
    m = [corps Hz, résonance Hz, Q, durée de résonance s, part de bruit] — une matière par monde (voir MAT) */
 impact:function(E,t,g,m,pan){var ac=E.ac,b=m[0],r=Math.min(1900,m[1]),end=t+Math.max(.35,m[3])+.1;
  var s=noiseSrc(E,t,end),hp=ac.createBiquadFilter(),ec=ac.createGain();hp.type='bandpass';hp.frequency.value=Math.min(1900,r*1.6);hp.Q.value=.9;
  s.connect(hp);hp.connect(ec);ec.gain.setValueAtTime(.0001,t);ec.gain.linearRampToValueAtTime(g*m[4],t+.0015);ec.gain.exponentialRampToValueAtTime(.0001,t+.014);
  var bp=ac.createBiquadFilter(),er=ac.createGain();bp.type='bandpass';bp.frequency.value=r;bp.Q.value=m[2];s.connect(bp);bp.connect(er);
  er.gain.setValueAtTime(.0001,t);er.gain.linearRampToValueAtTime(g*.9*Math.sqrt(m[2]),t+.003);er.gain.exponentialRampToValueAtTime(.0001,t+m[3]);
  var o=osc(E,'sine',b*1.7,t,end),eb=ac.createGain();o.frequency.exponentialRampToValueAtTime(b,t+.05);o.connect(eb);
  eb.gain.setValueAtTime(.0001,t);eb.gain.linearRampToValueAtTime(g*.8,t+.002);eb.gain.exponentialRampToValueAtTime(.0001,t+.16+m[3]*.3);
  var mx=ac.createGain();ec.connect(mx);er.connect(mx);eb.connect(mx);out(E,mx,pan||0,.22,.06,[s,o],end);},
 /* souffle à l'envers : enfle de plus en plus vite puis s'arrête net (aspiration, siphon) */
 suck:function(E,t,dur,g){var s=noiseSrc(E,t,t+dur+.05),lp=E.ac.createBiquadFilter(),e=E.ac.createGain(),end=t+dur+.05;lp.type='lowpass';lp.frequency.setValueAtTime(200,t);lp.frequency.exponentialRampToValueAtTime(1400,t+dur);
  s.connect(lp);lp.connect(e);e.gain.setValueAtTime(.0001,t);e.gain.exponentialRampToValueAtTime(g,t+dur*.97);e.gain.linearRampToValueAtTime(.0001,t+dur);out(E,e,0,.6,0,[s],end);}
};

/* ───────── partition ───────── */
var PLAN=null,TRT=0,DIVE=1700,DANCE0=0;
function N(L,t,d,k){var a=Array.prototype.slice.call(arguments,4);L.push({t:t,d:d,k:k,a:a});}
function chord(name,oct){return CH[name].map(function(d){return hz(d,oct||0);});}
function motif(L,t,step,voice,deg0,oct,g,pan,dur,dir,dwet){var m=dir<0?MOTIF.slice().reverse():MOTIF;m.forEach(function(d,i){N(L,t+i*step,(dur||step*2.6),voice,hz(deg0+d,oct),(dur||step*2.6)/1000,g,pan,.5,dwet||0);});}
function build(){if(PLAN)return PLAN;var F=window.QHERO&&QHERO.fin5;if(!F||!F.acts)return null;
 var A={},L=[],acts=F.acts(),C=F.cues?F.cues():{tin:3900,FTJ:5400,FTF:3900,DIVE:1700},i;
 acts.forEach(function(a){A[a.nm]=a;});TRT=F.chaseEnd();DIVE=C.DIVE||1700;DANCE0=TRT+DIVE;
 function at(nm,lt){return A[nm].t0+lt;}
 function padAct(nm,ch,oct,g,cut,pre){var a=A[nm];oct=oct==null?0:oct+1;g=(g||.07)*.7;N(L,a.t0-(pre||300),a.d+(pre||300),'pad',chord(ch,oct),(a.d+(pre||300))/1000,g,.7,1.1,cut?cut*1.5:1100);}   /* R234b : nappes une octave plus haut (audibles sur un haut-parleur de téléphone), plus légères */
 /* la coupe : du silence, un cœur, l'onde part */
 var a=A['la coupe'];N(L,a.t0,3200,'pad',chord('I',0),3.0,.042,1.6,1.4,700);N(L,a.t0,3400,'sub',hz(0,-1),3.4,.12,1.4);
 N(L,at('la coupe',120),400,'thump',.16,70,40,.32);N(L,at('la coupe',300),400,'thump',.1,64,38,.28);
 N(L,at('la coupe',430),1200,'thump',.22,110,46,.7);N(L,at('la coupe',430),2600,'bell',hz(0,1),2.6,.11,0,.7,.25);N(L,at('la coupe',440),2400,'bell',hz(4,0),2.4,.06,-.3,.7,0);
 N(L,at('la coupe',350),1300,'breath',1.3,300,900,.035,1.1,0,.6);
 /* Quantique : le thème se dédouble (la blanche, puis la violette en canon) */
 N(L,at('Quantique',328),900,'glide',hz(4,0),hz(7,0),.9,.06,-.4,.6);N(L,at('Quantique',328),900,'glide',hz(4,0),hz(2,0),.9,.06,.4,.6);
 N(L,at('Quantique',704),700,'glide',hz(9,0),hz(4,0),.7,.035,0,.7);
 motif(L,at('Quantique',520),170,'bell',0,0,.08,-.35,500,1,.2);motif(L,at('Quantique',760),170,'mallow',-2,0,.07,.35,500,1,.15);
 /* Filaments : la corde (accord de II) */
 padAct('Filaments','II',-1,.06,760);
 N(L,at('Filaments',300),1600,'pluck',hz(1,-1),1.6,.13,-.2);[3,5,8].forEach(function(d,k){N(L,at('Filaments',330+k*70),1300,'pluck',hz(d,0),1.3,.06,.3*(k-1));});
 N(L,at('Filaments',443),900,'pluck',hz(5,0),.9,.05,.4);N(L,at('Filaments',1450),700,'whoosh',.7,.05,1,.2);N(L,at('Filaments',1500),1100,'pluck',hz(8,0),1.1,.06,.3);
 /* Faille : coutures, le thème à l'envers (miroir) */
 padAct('Faille','vi',-1,.06,700);
 [578,859,909].forEach(function(t,k){N(L,at('Faille',t),650,'glide',hz(9-k,0),hz(2-k,0),.6,.045,k%2?.5:-.5,.75);N(L,at('Faille',t),500,'whoosh',.5,.025,0,0);});
 motif(L,at('Faille',980),150,'bell',5,-1,.07,0,420,-1,.25);
 N(L,at('Faille',1429),600,'thump',.13,90,44,.45);N(L,at('Faille',1429),500,'wood',hz(5,-1),.05,0);
 /* Magnétisme : l'accélérateur s'emballe, la caméra tourne, collision */
 a=A['Magnétisme'];N(L,a.t0-300,2300,'pad',chord('II',0),2.3,.042,.7,1.0,760);N(L,a.t0+2000,a.d-1700,'pad',chord('V',0),(a.d-1700)/1000,.045,.9,1.2,820);
 N(L,a.t0,a.d,'sub',hz(1,-1),a.d/1000,.08,.8);
 [941,1261,1582,1902].forEach(function(t,k){N(L,at('Magnétisme',t),900,'bell',hz(1+2*k,0),.9,.08,k%2?.4:-.4,.4,.2);N(L,at('Magnétisme',t),300,'wood',hz(1+2*k,1),.035,k%2?.4:-.4);});
 (function(){var t=2050,st=230,k=0;while(t<3900){N(L,at('Magnétisme',t),600,k%2?'pluck':'bell',hz([4,6,8,11][k%4],0),.6,.045+.02*Math.min(1,(t-2050)/1800),Math.sin(k*.9)*.7,.35,.15);t+=st;st=Math.max(85,st*.9);k++;}})();
 N(L,at('Magnétisme',2600),1360,'riser',1.36,hz(4,-2),.05);
 N(L,at('Magnétisme',3963),1800,'thump',.2,130,46,.7);N(L,at('Magnétisme',3963),1600,'breath',1.6,1300,300,.06,.8,0,.8);
 chord('V',0).forEach(function(f,k){N(L,at('Magnétisme',3970+k*25),2200,'bell',f,2.2,.06,(k-1)*.5,.7,.2);});
 /* Gravité : lourd, ralenti, le thème dans le grave */
 padAct('Gravité','vi',-2,.075,520);N(L,A['Gravité'].t0,A['Gravité'].d,'sub',hz(5,-1),A['Gravité'].d/1000,.13,.3);
 N(L,at('Gravité',591),900,'thump',.26,100,38,.8);N(L,at('Gravité',688),500,'thump',.1,80,40,.4);N(L,at('Gravité',1090),600,'wood',hz(5,-1),.06,.2);N(L,at('Gravité',1090),500,'drop',hz(9,0),.05,.2);
 motif(L,at('Gravité',150),260,'mallow',5,-1,.075,0,700,1,0);
 /* Mécanique : horlogerie (cliquets euclidiens), charge, éjection, double réception */
 padAct('Mécanique','I',-1,.06,760);
 (function(){var pat=[1,0,1,1,0,1,0,1],k=0;for(var t=0;t<2000;t+=125,k++)if(pat[k%8])N(L,at('Mécanique',t),300,'wood',hz(k%4===0?0:4,0)*(k%8===0?1:1.5),.022+.01*(k%4===0),k%2?.35:-.35);})();
 [256,692].forEach(function(t){N(L,at('Mécanique',t),400,'wood',hz(0,-1),.06,0);N(L,at('Mécanique',t),300,'drop',hz(4,0),.04,0);});
 N(L,at('Mécanique',1448),700,'thump',.12,90,44,.5);N(L,at('Mécanique',1780),300,'riser',.3,hz(0,-2),.04);N(L,at('Mécanique',1600),440,'riser',.44,hz(4,-2),.045);
 N(L,at('Mécanique',2038),900,'whoosh',.9,.06,1,0);[0,2,4,7].forEach(function(d,k){N(L,at('Mécanique',2050+k*80),1200,'bell',hz(d,0),1.2,.07,-.3+.2*k,.5,.25);});
 N(L,at('Mécanique',2858),600,'thump',.2,110,42,.5);N(L,at('Mécanique',3020),500,'thump',.09,90,42,.35);
 [3158,3348].forEach(function(t,k){N(L,at('Mécanique',t),300,'wood',hz(4+k,0),.03,.2);});
 /* Soufflerie : la houle, le cyclone, l'éjection */
 padAct('Soufflerie','II',-1,.055,740);
 N(L,at('Soufflerie',150),1500,'breath',1.5,280,820,.06,1.2,-.4,.7);
 for(i=0;i<6;i++)N(L,at('Soufflerie',700+i*110),900,'breath',.9,500+i*90,300+i*60,.03,3,Math.sin(i*1.2)*.8,.6);
 N(L,at('Soufflerie',840),900,'glide',hz(8,0),hz(1,0),.9,.04,0,.7);
 N(L,at('Soufflerie',1600),800,'whoosh',.8,.06,1,.3);[1,3,5,8].forEach(function(d,k){N(L,at('Soufflerie',1620+k*90),900,'mallow',hz(d,0),.9,.06,.4,.45,.2);});
 /* Glacier : quintes, givre, réverbération longue */
 a=A['Glacier'];N(L,a.t0-200,a.d+700,'pad',chord('Q',0),(a.d+700)/1000,.049,.5,1.6,1000);
 [260,720,1180].forEach(function(t,k){var f=[hz(8,0),hz(5,0),hz(11,0)][k];N(L,at('Glacier',t),3000,'bell',f,3,.06,[-.5,.5,0][k],.85,.35);for(var j=0;j<4;j++)N(L,at('Glacier',t+j*45),300,'grain',f*2*(1+.02*j),.12,.025,[-.5,.5,0][k]);});
 /* Chaîne : paquets en ping-pong, élan, saut */
 padAct('Chaîne','V',-1,.06,780);
 (function(){for(var t=0;t<860;t+=135){var k=t/135|0;[0,1,2].forEach(function(j){N(L,at('Chaîne',t+j*35),400,'pluck',hz([4,6,8][j],0),.4,.035,k%2?.6:-.6,.25,.3);});}})();
 [77,936].forEach(function(t){N(L,at('Chaîne',t),300,'wood',hz(4,0),.04,0);});N(L,at('Chaîne',868),600,'whoosh',.6,.06,1,0);N(L,at('Chaîne',1088),700,'whoosh',.7,.05,1,.3);
 N(L,at('Chaîne',1090),900,'bell',hz(8,0),.9,.06,.3,.5,.3);
 /* Fonderie : bulles, plaques du sol (grave) et du plafond (aigu), tournoiement */
 padAct('Fonderie','vi',-1,.06,700);
 for(i=0;i<14;i++)N(L,at('Fonderie',80+i*150+rnd(i)*90),300,'drop',hz(7+Math.floor(rnd(i+3)*5),0),.018,(rnd(i+9)-.5)*1.2);
 [392,640,970,1218,1559,1827,2003].forEach(function(t,k){var floor=k%2===0;N(L,at('Fonderie',t),700,floor?'mallow':'bell',floor?hz(5+k,-1):hz(5+k,0),.7,floor?.08:.06,floor?-.3:.3,.45,.2);
  if(floor)N(L,at('Fonderie',t),400,'thump',.07,95,48,.3);});
 N(L,at('Fonderie',1559),700,'thump',.18,110,42,.6);
 /* Atelier : le trait s'électrise → impact → poussière → saut → vol libre en double hélice → siphon */
 a=A['Atelier'];var tin=C.tin,J=C.FTJ,FF=C.FTF;
 N(L,a.t0-300,tin+800,'pad',chord('I',0),(tin+800)/1000,.042,.9,.8,760);N(L,at('Atelier',300),300,'wood',hz(0,0),.04,0);
 N(L,at('Atelier',600),tin-600,'riser',(tin-600)/1000,hz(0,-2),.045);
 (function(){for(var t=tin-2600;t<tin;t+=40){var d=(t-(tin-2600))/2600;if(rnd(t)<.25+.6*d)N(L,at('Atelier',t),120,'grain',500+rnd(t*1.3)*900,.05+.06*rnd(t*2.1),.012+.03*d,(rnd(t*3.7)-.5)*1.4);}})();
 [tin-2400,tin-1500,tin-800].forEach(function(t){for(var j=0;j<6;j++)N(L,at('Atelier',t+j*28),120,'grain',700+j*110,.07,.035,(j%2?.5:-.5));});
 N(L,at('Atelier',tin),1400,'thump',.3,140,40,1.1);N(L,at('Atelier',tin),1800,'breath',1.8,900,180,.07,.7,0,.9);
 [0,4,7,9].forEach(function(d,k){N(L,at('Atelier',tin+k*12),3200,'bell',hz(d,0),3.2,.07,(k-1.5)*.4,.85,.3);});
 (function(){for(var j=0;j<40;j++){var t=tin+200+j*38+rnd(j)*30;N(L,at('Atelier',t),200,'grain',1300-j*24,.1,.022*(1-j/48),(rnd(j*2.2)-.5)*1.6);}})();
 N(L,at('Atelier',J),900,'whoosh',.9,.07,1,0);
 N(L,at('Atelier',J-100),FF+400,'pad',chord('I',0).concat([hz(1,0)]),(FF+400)/1000,.06,1.2,1.3,1000);N(L,at('Atelier',J),FF,'sub',hz(0,-1),FF/1000,.07,1.2);
 /* vol libre : le thème en double hélice — la blanche monte, la violette lui répond en miroir, entrelacées */
 (function(){var t0=J+500,s=270,k;for(k=0;k<10;k++){var up=MOTIF[k%5]+(k>=5?2:0),dn=-MOTIF[k%5]+(k>=5?4:2);
  N(L,at('Atelier',t0+k*s),900,'bell',hz(up,0),.95,.075,-.45*Math.cos(k*.8),.5,.3);N(L,at('Atelier',t0+k*s+s/2),900,'mallow',hz(dn,0),.95,.065,.45*Math.cos(k*.8),.45,.25);}})();
 /* siphon : spirale qui descend, de plus en plus serrée, puis l'aspiration */
 (function(){var t=J+FF-200,st=200,k=0,end=a.d-150;while(t<end){N(L,at('Atelier',t),500,k%2?'mallow':'bell',hz(11-k,0),.5,.05,Math.sin(k*1.1)*.8,.5,0);t+=st;st=Math.max(70,st*.88);k++;}})();
 N(L,at('Atelier',J+FF-900),a.d-(J+FF-900),'riser',(a.d-(J+FF-900))/1000,hz(0,-2),.035);
 N(L,at('Atelier',J+FF+560),a.d-(J+FF+560)+300,'suck',(a.d-(J+FF+560)+300)/1000,.09);
 /* plongée : tout descend dans le grave ; naissance */
 N(L,TRT,DIVE,'glide',hz(0,-1),hz(0,-3),DIVE/1000,.12,0,.4);N(L,TRT,DIVE,'sub',hz(0,-1),DIVE/1000,.1,.3);N(L,TRT+300,DIVE-350,'suck',(DIVE-350)/1000,.06);
 N(L,TRT+1530,2600,'thump',.16,60,36,1.2);N(L,TRT+1530,4200,'bell',hz(0,0),4.2,.09,0,.9,.3);N(L,TRT+1560,4000,'bell',hz(4,0),4,.06,-.4,.9,.3);N(L,TRT+1590,4000,'bell',hz(9,0),4,.05,.4,.9,.3);
 /* R234 c · bruitages : chaque choc des deux particules (la blanche à gauche, la violette à droite), matière du monde */
 var MAT={'Quantique':[420,1100,9,.5,.5],'Filaments':[260,700,6,.35,.6],'Faille':[360,950,10,.55,.45],'Magnétisme':[300,820,7,.4,.6],
  'Gravité':[95,260,3,.45,.9],'Mécanique':[240,1250,14,.28,.8],'Soufflerie':[300,600,2,.25,.7],'Glacier':[440,1500,16,.7,.4],
  'Chaîne':[210,520,4,.25,.9],'Fonderie':[190,640,11,.5,.85],'Atelier':[230,480,3,.22,.9],'la coupe':[200,500,3,.3,.8]};
 acts.forEach(function(a){var m=MAT[a.nm]||MAT['Atelier'];[[a.ev||[],-.25],[a.evB||[],.25]].forEach(function(q){q[0].forEach(function(e,j){var t=a.t0+e[0],k=e[1],B=q[1]>0;
   if(k==='hit')N(L,t,500,'impact',a.nm==='Gravité'?.32:.2*(B?.85:1),m,q[1]);
   else if(k==='thud'){N(L,t,600,'impact',.34,[m[0]*.7,m[1]*.7,m[2],m[3]*1.3,1],q[1]);N(L,t+150,500,'impact',.12,m,q[1]);}
   else if(k==='coll')N(L,t,600,'impact',.36,[180,900,6,.6,1],0);
   else if(B&&(k==='tunnel'||k==='seam'))N(L,t,500,'glide',hz(9,0),hz(4,0),.45,.04,.5,.6);
   else if(B&&k==='twang')N(L,t,900,'pluck',hz(3,0),.9,.06,.4);
   else if(B&&(k==='boost'||k==='jump'||k==='eject'))N(L,t,600,'whoosh',.6,.045,1,.4);
   else if(k==='launch'||k==='thrust')N(L,t,400,'impact',.22,[150,420,3,.3,1],0);});});});
 L.sort(function(p,q){return p.t-q.t;});PLAN=L;return L;}
/* danse : une figure = 4,2 s ; une boucle de quatre figures (I, II, vi, I) ; le thème à l'unisson, puis en tierces ; sans fin */
var FIG=4200,DPROG=['I','II','vi','I'],DROOT=[0,1,5,0];
function dance(from,to){var L=[],k0=Math.max(0,Math.floor((from-DANCE0)/FIG)),k1=Math.floor((to-DANCE0)/FIG);
 for(var k=k0;k<=k1;k++){var t0=DANCE0+k*FIG,c=k%4,cyc=Math.floor(k/4),d0=DROOT[c];
  N(L,t0-200,FIG+400,'pad',chord(DPROG[c],0),(FIG+400)/1000,.045,1.4,1.6,900);N(L,t0,FIG,'sub',hz(d0,-1),FIG/1000,.07,1);
  if(k===0||c===0&&cyc%2===0){motif(L,t0+400,420,'bell',d0,0,.07,-.25,1400,1,.25);motif(L,t0+400,420,'mallow',d0+(k===0?0:2),0,.06,.25,1400,1,.2);}   /* à l'unisson à la naissance, en tierces ensuite */
  else if(c===2){[0,2,4].forEach(function(d,j){N(L,t0+600+j*700,2400,'bell',hz(d0+d,0),2.4,.05,(j-1)*.5,.7,.3);});}
  else if(c===1&&cyc%2===0){motif(L,t0+800,520,'mallow',d0,0,.05,0,1300,-1,.2);}
  if(k===0)N(L,t0+3200,4000,'bell',hz(7,0),4,.06,0,.95,.35);   /* QUANTIX apparaît */
  if(k===1)N(L,t0+500,3600,'bell',hz(11,0),3.6,.04,.4,.9,.3);}
 return L.filter(function(n){return n.t>=from&&n.t<to||n.t<from&&n.t+n.d>from;});}
function notesIn(from,to){var P=build();if(!P)return [];var o=[];for(var i=0;i<P.length;i++){var n=P[i];if(n.t>=to)break;if(n.t>=from||n.t+n.d>from)o.push(n);}
 if(to>DANCE0-400)o=o.concat(dance(Math.max(from,DANCE0-400),to));return o;}
function play(E,n,when,cut){/* cut > 0 : la note a commencé avant (recherche) → départ immédiat, fondu court, durée raccourcie */
 var a=n.a.slice(),fn=V[n.k];if(!fn)return;E.late=cut>0?.25:0;
 if(cut>0){var rem=Math.max(.15,(n.d-cut)/1000),durIdx={bell:1,mallow:1,pluck:1,pad:1,sub:1,breath:0,glide:2,whoosh:0,riser:0,suck:0}[n.k];
  if(durIdx==null||rem<.3)return;a[durIdx]=Math.min(a[durIdx],rem);}
 try{fn.apply(null,[E,when].concat(a));}catch(e){}E.late=0;}

/* ───────── lecture en direct (banc, jeu) ───────── */
var AC=null,E=null,on=true,vol=1,st={run:false,f0:0,a0:0,sched:0};
function unlock(){try{if(!AC){var C=window.AudioContext||window.webkitAudioContext;if(!C)return;AC=(window.Audio1&&Audio1.ctx&&Audio1.ctx())||new C();   /* dans le jeu : le contexte déjà déverrouillé de sound.js */E=engine(AC,AC.destination);E.master.gain.value=.85*vol;}
 if(AC.state==='suspended')AC.resume();}catch(e){}}
function kill(){if(!E)return;var t=AC.currentTime;E.live.forEach(function(v){try{v.o.gain.cancelScheduledValues(t);v.o.gain.setTargetAtTime(0,t,.05);v.s.forEach(function(s){try{s.stop(t+.3);}catch(e){}});}catch(e){}});E.live=[];}
function prune(){if(!E)return;var t=AC.currentTime;E.live=E.live.filter(function(v){return v.end>t;});}
function sync(tf,playing,speed){if(!on||!AC||AC.state!=='running'){st.run=false;return;}
 if(!playing||(speed&&Math.abs(speed-1)>.01)){if(st.run){kill();st.run=false;}return;}
 var now=AC.currentTime,exp=st.f0+(now-st.a0)*1000;
 if(!st.run||Math.abs(exp-tf)>180){kill();st.f0=tf;st.a0=now+.06;st.sched=tf;st.run=true;
  notesIn(tf,tf+1).forEach(function(n){if(n.t<tf)play(E,n,st.a0,tf-n.t);});}
 else if(Math.abs(exp-tf)>30)st.a0+=(exp-tf)/1000*.25;   /* dérive douce : on recale l'horloge sans couper */
 var hor=st.f0+(now-st.a0)*1000+450;
 if(hor>st.sched){notesIn(st.sched,hor).forEach(function(n){if(n.t>=st.sched)play(E,n,st.a0+(n.t-st.f0)/1000,0);});st.sched=hor;}
 if(Math.random()<.05)prune();}
/* rendu hors ligne d'une plage du film (outil : fichier audio, vidéo) */
function render(ctx,dest,t0,t1){var R=engine(ctx,dest||ctx.destination);notesIn(t0,t1).forEach(function(n){if(n.t>=t0)play(R,n,(n.t-t0)/1000,0);else play(R,n,0,t0-n.t);});return R;}
return {unlock:unlock,sync:sync,stop:function(){kill();st.run=false;},render:render,plan:function(){return build();},
 set:function(b){on=!!b;if(!on){kill();st.run=false;}},vol:function(v){vol=v;if(E)E.master.gain.value=.85*v;},
 state:function(){return {ac:AC?AC.state:'none',run:st.run,voices:E?E.live.length:0};}};
})();
